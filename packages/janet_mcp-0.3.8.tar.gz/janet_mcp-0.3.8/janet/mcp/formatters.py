"""Format API responses into human-readable text for LLM consumption."""

from typing import Dict, List


def format_workspace_context(
    user_email: str,
    org_name: str,
    org_id: str,
    projects: List[Dict],
    projects_columns: Dict[str, List[Dict]],
    projects_members: Dict[str, List[Dict]],
    user_name: str = "",
    active_key_name: str = None,
    masked_key: str = None,
) -> str:
    """Format workspace context as readable text."""
    user_display = f"{user_name} ({user_email})" if user_name else user_email
    lines = [
        f"# Janet.ai Workspace",
        f"- User: {user_display}",
        f"- Organization: {org_name} ({org_id})",
    ]
    if active_key_name and masked_key:
        lines.append(f"- API Key: {active_key_name} ({masked_key})")
    lines += [
        f"- Projects: {len(projects)}",
        "",
    ]

    for p in projects:
        pid = p["id"]
        key = p.get("project_identifier", "?")
        name = p.get("project_name", "?")
        count = p.get("ticket_count", 0)

        lines.append(f"## {key}: {name} ({count} tickets)")

        columns = projects_columns.get(pid, [])
        if columns:
            statuses = [c.get("status_value", "?") for c in columns]
            lines.append(f"  Statuses: {', '.join(statuses)}")

        members = projects_members.get(pid, [])
        active = [m for m in members if m.get("status") == "active"]
        if active:
            member_strs = [
                f"{m.get('fullName', '?')} ({m.get('userEmail', '?')})"
                for m in active[:20]
            ]
            lines.append(f"  Members: {', '.join(member_strs)}")
            if len(active) > 20:
                lines.append(f"  ... and {len(active) - 20} more")

        lines.append("")

    return "\n".join(lines)


def format_ticket(ticket: Dict) -> str:
    """Format a single ticket with full details."""
    key = ticket.get("ticket_key", "")
    if not key:
        proj = ticket.get("project_identifier", "?")
        num = ticket.get("ticket_identifier", "?")
        key = f"{proj}-{num}"

    lines = [f"# {key}: {ticket.get('title', 'Untitled')}"]

    status = ticket.get("status", "?")
    priority = ticket.get("priority", "?")
    issue_type = ticket.get("issue_type", "?")
    lines.append(f"- Status: {status}")
    lines.append(f"- Priority: {priority}")
    lines.append(f"- Type: {issue_type}")

    assignees = ticket.get("assignees", [])
    if assignees:
        if isinstance(assignees[0], dict):
            emails = [a.get("email", a.get("userEmail", "?")) for a in assignees]
        else:
            emails = assignees
        lines.append(f"- Assignees: {', '.join(emails)}")

    labels = ticket.get("labels", []) or ticket.get("tags", [])
    if labels:
        if isinstance(labels[0], dict):
            label_names = [l.get("name", "?") for l in labels]
        else:
            label_names = labels
        lines.append(f"- Labels: {', '.join(label_names)}")

    due = ticket.get("due_date")
    if due:
        lines.append(f"- Due: {due}")

    creator = ticket.get("creator") or ticket.get("created_by")
    if creator:
        lines.append(f"- Creator: {creator}")

    created = ticket.get("created_at") or ticket.get("createdAt")
    if created:
        lines.append(f"- Created: {str(created)[:10]}")

    updated = ticket.get("updated_at") or ticket.get("updatedAt")
    if updated:
        lines.append(f"- Updated: {str(updated)[:10]}")

    sprint = ticket.get("sprint")
    if sprint:
        sname = sprint.get("sprint_name", "?") if isinstance(sprint, dict) else sprint
        lines.append(f"- Sprint: {sname}")

    desc = ticket.get("description", "")
    if desc:
        lines.append(f"\n## Description\n{desc}")

    # Child tasks
    child_tasks = ticket.get("childTasks", []) or ticket.get("child_tasks", [])
    if child_tasks:
        lines.append(f"\n## Child Tasks ({len(child_tasks)})")
        for ct in child_tasks:
            ct_id = ct.get("fullIdentifier", "?")
            ct_title = ct.get("title", "?")
            ct_status = ct.get("status", "?")
            ct_assignee = ct.get("assignee", "")
            assignee_str = f" @{ct_assignee}" if ct_assignee else ""
            lines.append(f"- {ct_id}: {ct_title} [{ct_status}]{assignee_str}")

    # Comments
    comments = ticket.get("comments", [])
    if comments:
        lines.append(f"\n## Comments ({len(comments)})")
        for c in comments:
            author = c.get("created_by", c.get("author_email", c.get("author", "?")))
            created = c.get("created_at", "")[:10]
            content = c.get("content", "")
            lines.append(f"- {author} ({created}): {content}")

    return "\n".join(lines)


def format_ticket_list(
    tickets: List[Dict],
    total_count: int = 0,
    all_tickets: List[Dict] = None,
) -> str:
    """Format a list of tickets as a concise table."""
    if not tickets:
        return "No tickets found."

    # Status breakdown from ALL tickets (not just displayed page)
    count_source = all_tickets if all_tickets else tickets
    status_counts: Dict[str, int] = {}
    for t in count_source:
        s = t.get("status", "Unknown")
        status_counts[s] = status_counts.get(s, 0) + 1
    breakdown = ", ".join(f"{count} {status}" for status, count in status_counts.items())

    total = total_count or len(count_source)
    if total > len(tickets):
        header = f"{total} total ticket(s) ({breakdown}), showing {len(tickets)} most recent:"
    else:
        header = f"Found {len(tickets)} ticket(s) ({breakdown}):"

    lines = [header, ""]
    for t in tickets:
        key = t.get("ticket_key", "")
        if not key:
            proj = t.get("project_identifier", "?")
            num = t.get("ticket_identifier", "?")
            key = f"{proj}-{num}"

        title = t.get("title", "Untitled")
        status = t.get("status", "?")
        priority = t.get("priority", "?")

        assignees = t.get("assignees", [])
        if assignees:
            if isinstance(assignees[0], dict):
                assignee_str = ", ".join(a.get("email", a.get("userEmail", "?")) for a in assignees)
            else:
                assignee_str = ", ".join(assignees)
        else:
            assignee_str = "unassigned"

        extras = []
        if priority and priority != "?":
            extras.append(priority)
        if assignees:
            extras.append(f"@{assignee_str}")
        line = f"- {key} [{status}] \"{title}\""
        if extras:
            line += f" ({', '.join(extras)})"
        lines.append(line)

    return "\n".join(lines)


def format_ticket_list_by_column(
    tickets_by_status: Dict[str, List[Dict]],
    total_count: int = 0,
) -> str:
    """Format tickets grouped by status column with numbered positions.

    Used when displaying kanban column order so the LLM can determine
    ordinal position for relative moves (e.g. "move ticket 1 down").
    """
    if not tickets_by_status or all(len(v) == 0 for v in tickets_by_status.values()):
        return "No tickets found."

    total = total_count or sum(len(v) for v in tickets_by_status.values())
    col_count = len(tickets_by_status)
    lines = [f"Found {total} ticket(s) across {col_count} column(s):", ""]

    for status, tickets in tickets_by_status.items():
        lines.append(f"## {status} ({len(tickets)} tickets)")

        for i, t in enumerate(tickets, 1):
            key = t.get("ticket_key", "")
            if not key:
                proj = t.get("project_identifier", "?")
                num = t.get("ticket_identifier", "?")
                key = f"{proj}-{num}"

            title = t.get("title", "Untitled")
            priority = t.get("priority", "?")

            assignees = t.get("assignees", [])
            if assignees:
                if isinstance(assignees[0], dict):
                    assignee_str = ", ".join(a.get("email", a.get("userEmail", "?")) for a in assignees)
                else:
                    assignee_str = ", ".join(assignees)
            else:
                assignee_str = "unassigned"

            extras = []
            if priority and priority != "?":
                extras.append(priority)
            if assignees:
                extras.append(f"@{assignee_str}")
            line = f"{i}. {key} [{status}] \"{title}\""
            if extras:
                line += f" ({', '.join(extras)})"
            lines.append(line)

        lines.append("")

    return "\n".join(lines)


def format_sprint_list(sprints: List[Dict]) -> str:
    """Format a list of sprints."""
    if not sprints:
        return "No sprints found."

    lines = [f"Found {len(sprints)} sprint(s):\n"]
    for s in sprints:
        name = s.get("sprint_name", "?")
        status = s.get("status", "?")
        start = (s.get("start_date") or "")[:10]
        end = (s.get("end_date") or "")[:10]
        lines.append(f"- {name} [{status}] {start} to {end}")

    return "\n".join(lines)


def format_child_tasks(child_tasks: List[Dict]) -> str:
    """Format a list of child tasks."""
    if not child_tasks:
        return "No child tasks found."

    lines = [f"Found {len(child_tasks)} child task(s):\n"]
    for ct in child_tasks:
        ct_id = ct.get("fullIdentifier", "?")
        title = ct.get("title", "?")
        status = ct.get("status", "?")
        priority = ct.get("priority", "")
        assignee = ct.get("assignee", "")
        p_str = f" P:{priority}" if priority else ""
        a_str = f" @{assignee}" if assignee else ""
        lines.append(f"- {ct_id}: {title} [{status}]{p_str}{a_str}")

        # Sub-tasks
        sub_tasks = ct.get("subTasks", []) or ct.get("sub_tasks", [])
        for st in sub_tasks:
            st_id = st.get("fullIdentifier", "?")
            st_title = st.get("title", "?")
            st_status = st.get("status", "?")
            lines.append(f"  - {st_id}: {st_title} [{st_status}]")

    return "\n".join(lines)


def format_comments(comments: List[Dict]) -> str:
    """Format a list of comments."""
    if not comments:
        return "No comments found."

    lines = [f"Found {len(comments)} comment(s):\n"]
    for c in comments:
        cid = c.get("id", "?")
        author = c.get("created_by", c.get("author_email", c.get("author", "?")))
        created = (c.get("created_at") or "")[:10]
        content = c.get("content", "")
        lines.append(f"- [{cid[:8]}] {author} ({created}): {content}")

    return "\n".join(lines)


def _yjs_binary_to_text(yjs_binary_b64: str) -> str:
    """Extract readable text from a base64-encoded Yjs binary.

    BlockNote stores text as plain UTF-8 strings inside the Yjs CRDT binary.
    Decodes the binary and filters out control characters and Yjs metadata.
    """
    import base64
    import re
    if not yjs_binary_b64:
        return ""
    try:
        raw = base64.b64decode(yjs_binary_b64)
        text = raw.decode("utf-8", errors="ignore")
        cleaned = []
        for ch in text:
            if ch in ("\n", "\t", " ") or (ch.isprintable() and ord(ch) >= 32):
                cleaned.append(ch)
            else:
                cleaned.append("\n")
        result = "".join(cleaned)
        lines = [line.strip() for line in result.split("\n") if line.strip()]
        uuid_re = re.compile(
            r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
            re.IGNORECASE,
        )
        blocknote_tags = {
            "blockGroup", "blockContainer", "paragraph", "heading",
            "bulletListItem", "numberedListItem", "image",
            "codeBlock", "table", "tableRow", "tableCell",
            "blocknote-editor",
        }
        filtered = []
        for line in lines:
            if line in blocknote_tags:
                continue
            if uuid_re.match(line):
                continue
            if len(line) <= 2:
                continue
            filtered.append(line)
        return "\n".join(filtered).strip()
    except Exception:
        return ""


def _blocks_to_text(content) -> str:
    """Extract plain text from BlockNote/Tiptap JSON content."""
    if not content:
        return ""

    def _walk(node) -> List[str]:
        parts: List[str] = []
        if isinstance(node, dict):
            if node.get("type") == "text":
                parts.append(node.get("text", ""))
            for child in node.get("content", []):
                parts.extend(_walk(child))
        elif isinstance(node, list):
            for child in node:
                parts.extend(_walk(child))
        return parts

    lines: List[str] = []
    root_content = content if isinstance(content, list) else content.get("content", [])
    for block in root_content:
        text = "".join(_walk(block)).strip()
        lines.append(text)

    return "\n".join(lines).strip()


def format_document_list(docs: List[Dict], scope_label: str = "Documents") -> str:
    """Format a list of documents for LLM consumption."""
    if not docs:
        return f"No {scope_label.lower()} found."

    lines = [f"{scope_label} ({len(docs)}):"]
    for d in docs:
        title = d.get("title") or "Untitled"
        doc_id = d.get("id", "?")
        role = d.get("user_role", "")
        is_private = d.get("is_private", False)
        updated = (d.get("updated_at") or "")[:10]
        visibility = "private" if is_private else "org-wide"
        line = f"- [{doc_id}] \"{title}\" ({visibility}, {role})"
        if updated:
            line += f" — updated {updated}"
        lines.append(line)
    return "\n".join(lines)


def format_document_detail(doc: Dict) -> str:
    """Format full document details and content for LLM consumption."""
    title = doc.get("title") or "Untitled"
    doc_id = doc.get("id", "?")
    created_by = doc.get("created_by", "?")
    updated_at = (doc.get("updated_at") or "")[:10]
    is_private = doc.get("is_private", False)
    user_role = doc.get("user_role", "viewer")
    permissions = doc.get("permissions", [])

    lines = [
        f"# {title}",
        f"ID: {doc_id}",
        (
            f"Created by: {created_by}  |  Updated: {updated_at}"
            f"  |  Visibility: {'private' if is_private else 'org-wide'}"
            f"  |  Your role: {user_role}"
        ),
    ]
    if permissions:
        perm_str = ", ".join(
            f"{p['user_email']} ({p['role']})" for p in permissions
        )
        lines.append(f"Shared with: {perm_str}")
    lines.append("")

    content_text = _blocks_to_text(doc.get("content"))
    if not content_text and doc.get("yjs_binary"):
        content_text = _yjs_binary_to_text(doc.get("yjs_binary"))
    lines.append(content_text if content_text else "(no content)")

    return "\n".join(lines)
