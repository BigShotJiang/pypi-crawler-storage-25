"""Click CLI — deterministic release sequence with one LLM turn for diff analysis."""

from __future__ import annotations

import asyncio
import os
import shutil
from datetime import date
from pathlib import Path

import click
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.theme import Theme

from rel_ease import __version__
from rel_ease import git_ops, release_build, version_bump
from rel_ease.assistant import DiffAnalysis, analyze_diff
from rel_ease.repo import RepoKind, detect_repo
from rel_ease.semver_util import bump_part

_theme = Theme(
    {
        "re.title": "bold bright_cyan",
        "re.accent": "bright_magenta",
        "re.dim": "dim",
        "re.ok": "green",
        "re.warn": "yellow",
        "re.step": "bold white",
    }
)
console = Console(theme=_theme)

_JUNK = {
    "dist", "__pycache__", ".venv", "venv", "node_modules",
    ".terraform", ".pytest_cache", ".ruff_cache",
}
_JUNK_EXTS = {".pyc", ".pyo", ".tfstate", ".log"}
_JUNK_NAMES = {".env", ".DS_Store"}


def _step(msg: str, status: str = "…") -> None:
    console.print(f"  [re.dim]{status}[/re.dim]  [re.step]{msg}[/re.step]")


def _ok(msg: str) -> None:
    console.print(f"  [re.ok]✓[/re.ok]  {msg}")


def _warn(msg: str) -> None:
    console.print(f"  [re.warn]![/re.warn]  {msg}")


def _fail(msg: str) -> None:
    console.print(f"  [re.warn]✗[/re.warn]  {msg}")


def _is_junk(path_str: str) -> bool:
    p = Path(path_str)
    if p.suffix in _JUNK_EXTS:
        return True
    if p.name in _JUNK_NAMES:
        return True
    for part in p.parts:
        if part in _JUNK:
            return True
    return False


def _files_to_stage(
    root: Path,
    status_files: list[dict],
    version_file: Path | None,
    extra: list[Path],
) -> list[str]:
    """Compute paths to stage: modified/added tracked files + version file + extras."""
    staged: list[str] = []
    all_untracked = status_files and all(
        f.get("index_worktree", "  ").strip() == "??" for f in status_files
    )

    if all_untracked:
        # Initial commit: add everything except junk
        for f in status_files:
            p = f["path"]
            if not _is_junk(p):
                staged.append(p)
    else:
        # Add modified/added tracked files; skip untracked (only explicit extras added)
        for f in status_files:
            xy = f.get("index_worktree", "  ")
            work_tree = xy[1] if len(xy) > 1 else " "
            index = xy[0]
            p = f["path"]
            if work_tree in ("M", "A", "D") or index in ("M", "A"):
                if not _is_junk(p):
                    staged.append(p)

    # Always include version file and extras (release_notes.md etc.)
    always = [str(p.relative_to(root)) for p in extra if p.exists()]
    if version_file:
        vf_rel = str(version_file.relative_to(root))
        if vf_rel not in staged:
            always.append(vf_rel)
    for a in always:
        if a not in staged:
            staged.append(a)

    return staged


def main() -> None:
    cli(obj={})


@click.group(invoke_without_command=True)
@click.version_option(__version__, prog_name="rel-ease")
@click.pass_context
def cli(ctx: click.Context) -> None:
    """Rel-Ease — AI-assisted release manager for Python, Node, and Rust."""
    if ctx.invoked_subcommand is None:
        console.print(
            Panel.fit(
                "[re.title]Rel-Ease[/re.title] [re.dim]—[/re.dim] [re.accent]ship with confidence[/re.accent]\n"
                "[re.dim]Run[/re.dim] [bold]rel-ease release[/bold] [re.dim]inside a git repo, or[/re.dim] "
                "[bold]rel-ease doctor[/bold] [re.dim]to check tooling.[/re.dim]",
                border_style="bright_cyan",
            )
        )
        console.print(ctx.get_help())


@cli.command("doctor")
@click.argument("path", type=click.Path(path_type=Path, file_okay=False), default=".")
def doctor(path: Path) -> None:
    """Check API key, git, uv, twine, npm, cargo."""
    root = path.resolve()
    rows: list[tuple[str, str, str]] = []

    def check(label: str, ok: bool, detail: str = "") -> None:
        icon = "[re.ok]●[/re.ok]" if ok else "[re.warn]○[/re.warn]"
        rows.append((icon, label, detail))

    ai_key = os.environ.get("AI_LAYER_KEY") or os.environ.get("AI_LAYER_API_KEY")
    check("AI_LAYER_KEY", bool(ai_key))
    check("git repo", (root / ".git").is_dir(), str(root))
    for bin_name in ("git", "uv", "twine", "npm", "cargo"):
        check(bin_name, shutil.which(bin_name) is not None)

    table = Table(show_header=False, box=None, padding=(0, 2))
    for s, lab, det in rows:
        table.add_row(s, lab, f"[re.dim]{det}[/re.dim]" if det else "")
    console.print(Rule("[re.title]Doctor[/re.title]", style="bright_cyan"))
    console.print(table)

    ctx = detect_repo(root)
    console.print(
        f"\n[re.accent]Detected:[/re.accent] [bold]{ctx.kind.value}[/bold]"
        f"  [re.dim]version[/re.dim] {ctx.current_version or '—'}"
    )


@cli.command("detect")
@click.argument("path", type=click.Path(path_type=Path, file_okay=False), default=".")
def detect_cmd(path: Path) -> None:
    """Print detected repo kind and version (no API calls)."""
    ctx = detect_repo(path)
    console.print(ctx.summary(), end="")


@cli.command("release")
@click.argument("path", type=click.Path(path_type=Path, file_okay=False), default=".")
@click.option("--hint", type=str, default=None, help="Extra guidance for the LLM (version choice, notes tone, etc.).")
@click.option(
    "--assistant-id",
    type=str,
    default=None,
    envvar="REL_EASE_AGENT_ID",
    help="ai-layer agent ID override.",
)
@click.option("--dry-run", is_flag=True, help="Analyze only — no version bump, commit, build, or upload.")
@click.option("--publish/--no-publish", default=True, help="Run uv build + twine upload for Python (default: on).")
@click.option("--no-gpg-sign", "no_gpg_sign", is_flag=True, help="Skip GPG commit signing.")
def release_cmd(
    path: Path,
    hint: str | None,
    assistant_id: str | None,
    dry_run: bool,
    publish: bool,
    no_gpg_sign: bool,
) -> None:
    """Analyze diff with Backboard, then run the full release sequence."""
    root = path.resolve()
    key = os.environ.get("AI_LAYER_KEY") or os.environ.get("AI_LAYER_API_KEY")
    if not key:
        raise click.ClickException("AI_LAYER_KEY not set (run: rel-ease doctor).")
    if not (root / ".git").is_dir():
        raise click.ClickException(f"Not a git repository: {root}")

    repo = detect_repo(root)
    console.print(
        Panel(
            f"[re.title]Rel-Ease[/re.title]  [re.dim]{root}[/re.dim]\n"
            f"[re.accent]{repo.kind.value}[/re.accent]  ·  "
            f"[re.dim]current version[/re.dim] {repo.current_version or '?'}",
            border_style="bright_magenta",
        )
    )

    # ── Step 1: read working tree ──────────────────────────────────────────
    _step("Reading git status + diff", "1")
    status = git_ops.git_status_porcelain(root)
    status_files = status.get("files", [])
    if not status_files:
        console.print(
            Panel(
                "[re.dim]Nothing to release — working tree is clean.[/re.dim]",
                border_style="yellow",
            )
        )
        return

    diff_result = git_ops.git_diff(root, stat=False)
    diff_text = diff_result.get("stdout", "")
    _ok(f"{len(status_files)} changed file(s)")

    # ── Step 2: LLM analysis ───────────────────────────────────────────────
    _step("Asking ai-layer to analyze diff…", "2")
    try:
        analysis: DiffAnalysis = asyncio.run(
            analyze_diff(
                diff=diff_text,
                status_files=status_files,
                repo_kind=repo.kind.value,
                current_version=repo.current_version,
                hint=hint,
                api_key=key,
                assistant_id=assistant_id,
            )
        )
    except Exception as e:
        raise click.ClickException(f"ai-layer error: {e}") from e

    part = analysis.semver_part if analysis.semver_part in ("patch", "minor", "major") else "patch"
    old_ver = repo.current_version or "0.0.0"
    new_ver = bump_part(old_ver, part)

    console.print(
        Panel(
            f"[re.dim]bump[/re.dim]   [bold]{old_ver}[/bold] → [re.ok]{new_ver}[/re.ok]  [re.dim]({part})[/re.dim]\n"
            f"[re.dim]why[/re.dim]    {analysis.reasoning}\n"
            f"[re.dim]commit[/re.dim] {analysis.commit_summary}",
            border_style="bright_cyan",
            title="[re.title]Decision[/re.title]",
        )
    )

    if dry_run:
        console.print(
            Panel(
                f"[re.warn]Dry run — stopping before mutations.[/re.warn]\n\n"
                f"[re.dim]Release notes preview:[/re.dim]\n{analysis.release_notes_md}",
                border_style="yellow",
                title="Dry Run",
            )
        )
        return

    # ── Step 3: bump version ───────────────────────────────────────────────
    _step(f"Bumping version → {new_ver}", "3")
    bump_result = version_bump.apply_bump(repo, part, None)
    if not bump_result.get("ok"):
        raise click.ClickException(f"Version bump failed: {bump_result.get('error')}")
    _ok(f"Updated {bump_result['file']}")

    if repo.kind == RepoKind.NODE:
        lock = version_bump.npm_install_package_lock_only(root)
        if lock.get("ok"):
            _ok("Refreshed package-lock.json")
        else:
            _warn("npm install --package-lock-only failed (continuing)")

    # ── Step 4: release notes ──────────────────────────────────────────────
    _step("Writing release_notes.md", "4")
    notes_path = root / "release_notes.md"
    mode = "append" if notes_path.exists() else "replace"
    today = date.today().strftime("%Y-%m-%d")
    pkg_name = repo.package_name or root.name
    bullets = analysis.release_notes_md.strip()
    notes_body = (
        f"## [{new_ver}] — {today}\n\n"
        f"{bullets}\n\n"
        f"---\n"
        f"*Released by [Rel-Ease](https://github.com/chrisk60331/Rel-Ease) · "
        f"[{pkg_name}](https://pypi.org/project/{pkg_name}/{new_ver}/)*"
    )
    notes_result = release_build.release_notes_write(root, notes_body, mode=mode)
    if not notes_result.get("ok"):
        _warn(f"Release notes: {notes_result.get('error')}")
    else:
        _ok(f"release_notes.md ({mode}d)")

    # ── Step 5: git add ────────────────────────────────────────────────────
    _step("Staging files", "5")
    extra_paths = [root / "release_notes.md"]
    if repo.kind == RepoKind.NODE:
        extra_paths.append(root / "package-lock.json")
    to_stage = _files_to_stage(root, status_files, repo.version_file, extra_paths)
    if not to_stage:
        raise click.ClickException("Nothing to stage — aborting.")
    add_result = git_ops.git_add(root, to_stage)
    if not add_result.get("ok"):
        raise click.ClickException(f"git add failed:\n{add_result.get('stderr')}")
    _ok(f"Staged {len(to_stage)} file(s)")

    # ── Step 6: git commit ─────────────────────────────────────────────────
    _step("Committing", "6")
    label = part.capitalize()
    commit_msg = f"v{new_ver} {label}: {analysis.commit_summary}"
    commit_result = git_ops.git_commit(root, commit_msg, no_gpg_sign=no_gpg_sign)
    if not commit_result.get("ok"):
        raise click.ClickException(f"git commit failed:\n{commit_result.get('stderr')}")
    _ok(commit_msg)

    # ── Step 7: tag ────────────────────────────────────────────────────────
    _step(f"Tagging v{new_ver}", "7")
    tag = f"v{new_ver}"
    tag_result = git_ops.git_tag(root, tag, message=commit_msg)
    if not tag_result.get("ok"):
        _warn(f"git tag failed: {tag_result.get('stderr', '').strip()}")
    else:
        _ok(tag)

    # ── Step 8: push ───────────────────────────────────────────────────────
    _step("Pushing (--follow-tags)", "8")
    push_result = git_ops.git_push(root, follow_tags=True)
    if not push_result.get("ok"):
        _fail("git push failed")
        console.print((push_result.get("stderr") or "").strip()[-2000:])
        raise click.ClickException("Push failed.")
    _ok("Pushed")

    # ── Step 9: GitHub release ─────────────────────────────────────────────
    _step("Creating GitHub release", "9")
    pkg_name = repo.package_name or root.name
    gh_body = f"{bullets}\n\n"
    if repo.kind == RepoKind.PYTHON:
        gh_body += f"```\npip install {pkg_name}=={new_ver}\n```\n"
    gh = git_ops.gh_release_create(root, tag, f"{tag} — {analysis.commit_summary}", gh_body)
    if gh.get("skipped"):
        _warn(f"Skipped: {gh.get('error')}")
    elif not gh.get("ok"):
        _warn(f"GitHub release failed: {gh.get('stderr', '').strip()}")
    else:
        _ok(gh.get("url") or tag)

    # ── Step 10: Python publish ────────────────────────────────────────────
    step_n = 10
    if repo.kind == RepoKind.PYTHON and publish:
        _step("Building package (uv build)", str(step_n))
        build = release_build.uv_build(root)
        if not build.get("ok"):
            _fail("uv build failed")
            console.print(build.get("stderr", "")[-3000:])
            raise click.ClickException("Build failed — not uploading.")
        _ok(f"Built: {', '.join(build.get('dist_files', []))}")

        step_n += 1
        _step("Publishing to PyPI (twine upload)", str(step_n))
        upload = release_build.twine_upload(root)
        if not upload.get("ok"):
            _fail("twine upload failed")
            err = (upload.get("stderr") or "") + "\n" + (upload.get("stdout") or "")
            console.print(err.strip()[-3000:])
            raise click.ClickException("Upload failed.")
        _ok("Uploaded to PyPI")

    # ── Done ───────────────────────────────────────────────────────────────
    console.print(Rule("[re.title]Release Notes[/re.title]", style="bright_cyan"))
    console.print(Markdown(notes_body))

    footer = f"[re.ok]✓ {tag} shipped.[/re.ok]"
    if repo.kind == RepoKind.RUST:
        footer += "  Run [bold]cargo publish[/bold] to push to crates.io."
    if repo.kind == RepoKind.PYTHON and not publish:
        footer += "  Run [bold]rel-ease release[/bold] (without --no-publish) to upload to PyPI."
    console.print(Panel(footer, border_style="green"))


if __name__ == "__main__":
    main()
