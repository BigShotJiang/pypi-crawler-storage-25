# SubstrAI - Open-source GenAI frameworks for serverless infrastructure.
"""SubstrAI: Production-grade GenAI frameworks for AWS Lambda."""

__version__ = "0.0.1"
__author__ = "Gaurav Kumar Sinha"
__email__ = "gaurav@substrai.dev"
