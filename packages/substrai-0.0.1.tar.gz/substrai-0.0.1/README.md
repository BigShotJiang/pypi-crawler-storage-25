# SubstrAI

**Open-source GenAI frameworks for serverless infrastructure.**

> This package is under active development. The first framework (LambdaLLM) will be released soon.

## What is SubstrAI?

SubstrAI is an open-source initiative producing enterprise-grade GenAI frameworks purpose-built for AWS Lambda and serverless infrastructure.

We solve the fundamental incompatibility between existing LLM frameworks (LangChain, LlamaIndex) and AWS Lambda's stateless, cold-start-optimized, timeout-constrained execution model.

## Planned Frameworks

| Framework | Description | Status |
|-----------|-------------|--------|
| **LambdaLLM** | Serverless-native LLM orchestration | In Development |
| **GuardrailGraph** | Composable AI safety pipelines | Planned |
| **CostSentinel** | Real-time GenAI cost governance | Planned |
| **PromptOps** | Infrastructure-as-Code for prompts | Planned |
| **EvalForge** | Automated LLM evaluation pipelines | Planned |
| **AgentDeploy** | Zero-to-production agent deployment | Planned |
| **RAGForge** | Enterprise RAG architecture generator | Planned |

## Design Principles

- **Lambda-first**: Purpose-built for serverless constraints (cold starts, 15-min timeout, stateless)
- **Convention over configuration**: Works in 5 minutes with zero config
- **Observable by default**: Every action traceable without extra setup
- **Cost-aware**: Built-in budget enforcement and model routing
- **Escape hatches**: Never trap the user

## Installation

```bash
pip install substrai
```

## Links

- **GitHub**: [github.com/substrai](https://github.com/substrai)
- **Website**: [substrai.dev](https://substrai.dev)
- **Documentation**: [docs.substrai.dev](https://docs.substrai.dev)

## Author

**Gaurav Kumar Sinha** — Founder, SubstrAI

- Email: gaurav@substrai.dev
- GitHub: [github.com/substrai](https://github.com/substrai)

## License

MIT License - see [LICENSE](LICENSE) for details.
