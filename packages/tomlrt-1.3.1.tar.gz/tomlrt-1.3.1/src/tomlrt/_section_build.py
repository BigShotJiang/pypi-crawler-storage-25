"""Section construction, cloning, and insertion helpers.

Builds new ``[name]`` / ``[[name]]`` blocks from scratch, deep-clones
existing sections (rebasing their key prefix), and splices blocks back
into a `DocumentNode`. The cloning paths reach into the logical
view layer (``AoT`` / ``_StdTable`` privates) by design — they are the
inverse of the view layer's "give me the CST that backs this view".
"""

from __future__ import annotations

from collections.abc import Sequence
from copy import deepcopy
from typing import TYPE_CHECKING

from tomlrt._errors import TOMLError
from tomlrt._nodes import (
    Key,
    KeyValueNode,
    NewlineNode,
    SectionNode,
    TableHeaderNode,
    Trivia,
    WhitespaceNode,
)
from tomlrt._synthesise import make_key_part
from tomlrt._trivia import _prepend_blank_line, _seam_blank_style

if TYPE_CHECKING:
    from collections.abc import Iterable

    from tomlrt._document import AoT, _StdTable
    from tomlrt._nodes import (
        CommentNode,
        DocumentNode,
        HeaderKind,
        InlineTableEntry,
        InlineTableNode,
    )


def _new_section(
    path: tuple[str, ...],
    *,
    kind: HeaderKind = "table",
    leading: Trivia | None = None,
    trailing: WhitespaceNode | None = None,
    trailing_comment: CommentNode | None = None,
) -> SectionNode:
    """Build an empty ``[path]`` (or ``[[path]]``) section.

    Trivia defaults to empty; pass ``leading`` / ``trailing`` /
    ``trailing_comment`` to carry over comment material from a node
    that the new section is replacing (used by the promotion paths).
    """
    parts = [make_key_part(p) for p in path]
    seps = ["."] * (len(parts) - 1)
    header = TableHeaderNode(
        leading=leading if leading is not None else Trivia(),
        kind=kind,
        inner_pre=None,
        key=Key(parts=parts, separators=seps),
        inner_post=None,
        trailing=trailing,
        trailing_comment=trailing_comment,
        newline=NewlineNode("\n"),
    )
    return SectionNode(header=header, entries=[])


def _kv_from_inline_entry(entry: InlineTableEntry, *, deep: bool) -> KeyValueNode:
    """Wrap an inline-table entry as a standalone ``key = value`` KV.

    Used by the promotion paths to convert inline-table contents into
    section entries. ``deep=True`` deep-clones the key and value (used
    when the source might still be reachable from elsewhere).
    """
    return KeyValueNode(
        leading=Trivia(),
        key=deepcopy(entry.key) if deep else entry.key,
        pre_eq=WhitespaceNode(" "),
        post_eq=WhitespaceNode(" "),
        value=deepcopy(entry.value) if deep else entry.value,
        trailing=None,
        trailing_comment=None,
        newline=NewlineNode("\n"),
    )


def _build_promoted_section(
    path: tuple[str, ...],
    inline: InlineTableNode,
    source_kv: KeyValueNode,
) -> SectionNode:
    """Build a ``[path]`` section containing ``inline``'s entries.

    Comments that lived above the original inline-table KV (its
    ``leading`` trivia) and any inline EOL comment are carried over to
    the new header so authoring intent is preserved.
    """
    section = _new_section(
        path,
        leading=Trivia(list(source_kv.leading.pieces)),
        trailing=source_kv.trailing,
        trailing_comment=source_kv.trailing_comment,
    )
    section.entries = [_kv_from_inline_entry(e, deep=False) for e in inline.entries]
    return section


def _build_promoted_aot_section(
    path: tuple[str, ...],
    inline: InlineTableNode,
) -> SectionNode:
    """Build a ``[[path]]`` section containing ``inline``'s entries.

    Used by [`Table.promote_array`][tomlrt.Table.promote_array] to
    convert each element of an
    inline array of inline tables into its own AoT entry.
    """
    section = _new_section(path, kind="array")
    section.entries = [_kv_from_inline_entry(e, deep=True) for e in inline.entries]
    return section


def _iter_rebased(
    sections: Iterable[SectionNode],
    src_path: tuple[str, ...],
    full_path: tuple[str, ...],
) -> Iterable[tuple[SectionNode, tuple[str, ...]]]:
    """Yield ``(sec, new_path)`` for sections rooted at ``src_path``.

    ``new_path`` is rebased onto ``full_path``. Implicit (header-less)
    and out-of-prefix sections are skipped.
    """
    splen = len(src_path)
    for sec in sections:
        hdr = sec.header
        if hdr is None or len(hdr.key.path) < splen or hdr.key.path[:splen] != src_path:
            continue
        yield sec, (*full_path, *hdr.key.path[splen:])


def _rebase_sections(
    sections: Iterable[SectionNode],
    src_path: tuple[str, ...],
    full_path: tuple[str, ...],
    *,
    clone: bool,
    head_kind: HeaderKind | None = None,
) -> list[SectionNode]:
    """Rebase header keys on every section under ``src_path`` onto ``full_path``.

    With ``clone=True`` each section is deep-copied first; with
    ``clone=False`` the originals are mutated in place. ``head_kind``,
    if given, forces the kind of the first section whose header lives
    exactly at ``full_path``.
    """
    out: list[SectionNode] = []
    for sec, new_path in _iter_rebased(sections, src_path, full_path):
        target = deepcopy(sec) if clone else sec
        assert target.header is not None
        target.header.key = _make_dotted_key(new_path)
        out.append(target)
    if head_kind is not None:
        for sec in out:
            assert sec.header is not None
            if len(sec.header.key.path) == len(full_path):
                sec.header.kind = head_kind
                break
    return out


def _clone_aot_sections(
    value: AoT,
    full_path: tuple[str, ...],
) -> list[SectionNode]:
    """Deep-clone every CST section that contributes to ``value``, rebased.

    Each AoT entry contributes its ``[[path]]`` header *and* any
    sub-sections in its owned range (e.g. ``[path.sub]`` /
    ``[[path.nested]]``). All of them are deep-cloned and have their
    header paths rewritten so the ``len(value._path)``-prefix is
    replaced by ``full_path``. Surrounding placement (insert index,
    blank-line policy, dict-storage sync) is the caller's job.
    """
    sections = _aot_owned_sections(value)
    return _rebase_sections(sections, value._path, full_path, clone=True)  # noqa: SLF001


def _rebase_aot_sections_inplace(
    value: AoT, full_path: tuple[str, ...]
) -> list[SectionNode]:
    """Live-attach analogue of `_clone_aot_sections`."""
    return _rebase_sections(
        _aot_owned_sections(value),
        value._path,  # noqa: SLF001
        full_path,
        clone=False,
    )


def _rebase_table_sections_inplace(
    value: _StdTable, full_path: tuple[str, ...]
) -> list[SectionNode]:
    """Live-attach a detached `_StdTable`; normalises head kind to ``"table"``."""
    return _rebase_sections(
        value._doc_node.sections,  # noqa: SLF001
        value._path,  # noqa: SLF001
        full_path,
        clone=False,
        head_kind="table",
    )


def _aot_owned_sections(value: AoT) -> list[SectionNode]:
    """All section nodes contributing to ``value``, in document order."""
    doc_node = value._doc_node  # noqa: SLF001
    blocks = (doc_node.aot_entry_block(header) for header in value._own_sections())  # noqa: SLF001
    return [sec for block in blocks for sec in block]


def _new_host_section(path: tuple[str, ...]) -> SectionNode:
    """Synthesize an empty ``[path]`` section, ready to host dotted KVs."""
    return SectionNode(
        header=TableHeaderNode(
            leading=Trivia(),
            kind="table",
            inner_pre=None,
            key=_make_dotted_key(path),
            inner_post=None,
            trailing=None,
            trailing_comment=None,
            newline=NewlineNode("\n"),
        ),
        entries=[],
    )


def _clone_table_sections(
    value: _StdTable,
    full_path: tuple[str, ...],
    *,
    head_kind: HeaderKind = "table",
) -> list[SectionNode]:
    """Deep-clone every CST section that contributes to ``value``, rebased.

    The returned sections are independent of ``value._doc_node`` and have
    their headers rewritten so the ``len(value._path)``-prefix is replaced
    by ``full_path``. Both sections at or below ``value._path`` and dotted
    KVs in ancestor sections that extend into ``value._path`` contribute
    (the latter cloned into a host section at ``full_path``, synthesised
    on demand). For a ``Document`` source (``value._path == ()``) the
    implicit pre-header section's entries are treated as ancestor extras.

    The leading section's header kind is forced to ``head_kind``: pass
    ``"table"`` (default) for a ``[full_path]`` standard section, or
    ``"array"`` for a ``[[full_path]]`` AoT entry. Without this
    normalisation an AoT-entry source cloned into a standard-table slot
    would keep its ``[[..]]`` header (and vice versa).
    """
    src_path = value._path  # noqa: SLF001
    fplen = len(full_path)
    doc = value._doc_node  # noqa: SLF001

    src_scope = value._scope()  # noqa: SLF001
    src_sections = src_scope if src_scope is not None else doc.sections
    new_secs = _rebase_sections(src_sections, src_path, full_path, clone=True)
    head = next(
        (
            s
            for s in new_secs
            if s.header is not None and len(s.header.key.path) == fplen
        ),
        None,
    )

    if len(src_path) == 0:
        extras = [
            (kv.key.path, kv)
            for sec in doc.sections
            if sec.header is None
            for kv in sec.entries
        ]
    else:
        extras = value._compute_extras() or []  # noqa: SLF001

    if extras:
        if head is None:
            head = _new_host_section(full_path)
            new_secs.insert(0, head)
        for rel_path, kv in extras:
            cloned_kv = deepcopy(kv)
            cloned_kv.key = _make_dotted_key(rel_path)
            head.entries.append(cloned_kv)

    if head is not None and head.header is not None:
        head.header.kind = head_kind

    return new_secs


def _apply_prior_leading(
    new_secs: Sequence[SectionNode],
    prior_leading: Trivia | None,
) -> None:
    """Transplant ``prior_leading`` onto the first new section's header.

    Used to preserve comments / blank lines that sat above a section
    being replaced. No-op when the new block is empty or its first
    section has no header.
    """
    if prior_leading is None or not new_secs:
        return
    first = new_secs[0]
    if first.header is None:
        return
    first.header.leading = prior_leading


def _insert_section_block(
    doc_node: DocumentNode,
    insert_at: int,
    new_secs: Sequence[SectionNode],
    *,
    separate_within: bool = True,
    add_blank: bool | None = None,
    bump_next: bool = False,
) -> None:
    """Splice a freshly-built block of ``[ ... ]`` / ``[[ ... ]]`` sections.

    ``add_blank`` controls whether a blank line precedes ``new_secs[0]``
    (when prior content exists) and -- with ``separate_within=True`` --
    between consecutive entries within ``new_secs``. ``None`` (the
    default) auto-detects from the doc's existing inter-section style;
    ``True``/``False`` force the policy. Callers that already sample
    style elsewhere (e.g. AoT entries reading sibling-vs-sibling gaps)
    pass an explicit value.

    ``bump_next=True`` independently prepends a blank to the section
    that will follow the new block; AoT entry inserts at non-end
    positions need this so two ``[[..]]`` headers don't render glued
    together. Pass ``separate_within=False`` when each section in
    ``new_secs`` already carries its own inter-header trivia (e.g.
    cloned sections from another document).
    """
    sections = doc_node.sections
    preceding_has_content = any(s.has_content() for s in sections[:insert_at])
    if add_blank is None:
        add_blank = preceding_has_content and _seam_blank_style(sections)
    if add_blank:
        for i, ns in enumerate(new_secs):
            if (i == 0 and preceding_has_content) or (i > 0 and separate_within):
                assert ns.header is not None
                _prepend_blank_line(ns.header.leading)
    if bump_next and insert_at < len(sections):
        next_hdr = sections[insert_at].header
        if next_hdr is not None:
            _prepend_blank_line(next_hdr.leading)
    if new_secs and new_secs[0].header is not None:
        doc_node.adopt_preamble_into(new_secs[0].header.leading)
    sections[insert_at:insert_at] = new_secs


def _parse_key_path(path: str | Sequence[str]) -> tuple[str, ...]:
    """Split a dotted key path string into its bare segments.

    A string is split on ``.`` (``"a.b.c"`` → ``("a", "b", "c")``).
    Any other sequence of strings is taken verbatim: use this form to
    express a single segment containing a literal dot (e.g.
    ``("foo.bar",)`` to name a table whose only key is the quoted name
    ``"foo.bar"``).
    """
    if isinstance(path, str):
        if not path:
            msg = "key path must not be empty"
            raise TOMLError(msg)
        str_parts = path.split(".")
        if any(not p for p in str_parts):
            msg = f"key path {path!r} contains an empty segment"
            raise TOMLError(msg)
        return tuple(str_parts)
    if not isinstance(path, Sequence):
        msg = (  # type: ignore[unreachable]
            f"key path must be str or sequence of str, not {type(path).__name__}"
        )
        raise TypeError(msg)
    parts = tuple(path)
    if not parts:
        msg = "key path must not be empty"
        raise TOMLError(msg)
    for p in parts:
        if not isinstance(p, str):
            msg = (  # type: ignore[unreachable]
                f"key path {parts!r} segment must be str, not {type(p).__name__}"
            )
            raise TypeError(msg)
    if any(p == "" for p in parts):
        msg = f"key path {parts!r} contains an empty segment"
        raise TOMLError(msg)
    return parts


def _section_insert_index(
    sections: list[SectionNode],
    full_path: tuple[str, ...],
) -> int:
    """Choose where to splice a new section with ``full_path``.

    Prefers placement immediately after the last section that shares
    ``full_path``'s parent prefix (so siblings group together); falls
    back to the end of the document.
    """
    parent = full_path[:-1]
    # Top-level: shared parent prefix is always empty, so just append.
    if not parent:
        return len(sections)
    last_sibling = -1
    for i, sec in enumerate(sections):
        hdr = sec.header
        if hdr is None:
            continue
        hpath = hdr.key.path
        if len(hpath) >= len(parent) and hpath[: len(parent)] == parent:
            last_sibling = i
    if last_sibling < 0:
        return len(sections)
    return last_sibling + 1


def _make_dotted_key(path: tuple[str, ...]) -> Key:
    parts = [make_key_part(p) for p in path]
    seps = ["."] * (len(parts) - 1)
    return Key(parts=parts, separators=seps)
