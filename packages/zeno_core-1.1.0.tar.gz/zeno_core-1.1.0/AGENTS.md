# zeno-core

The protocol-bearing package. Everything else in the workspace adapts to interfaces defined here. Has no third-party SDK dependencies — only `structlog`, `httpx`, `tenacity`, and stdlib.

## Public surface

`src/zeno/__init__.py` does **not exist** (PEP 420). Top-level submodules each declare `__all__`:

| Module | Owns |
| --- | --- |
| `zeno.agent` | `Agent`, `SubAgent`, `TurnBudget` |
| `zeno.app` | `ZenoApp` |
| `zeno.context` | `Ctx`, `bind_ctx`, `current_ctx` |
| `zeno.tool` | `@tool` decorator, `ToolError` |
| `zeno.builtin_tools` | `recall`, `remember` |
| `zeno.protocols.*` | `Provider`, `Channel`, `MemoryView`, `Secrets`, etc. |
| `zeno.runtime.*` | `TurnDispatcher`, `default_handler`, MCP plumbing — semi-public |
| `zeno.observability.*` | `Tracer`, structured event types |
| `zeno.testing` | `FakeChannel`, fixtures |

Adding or removing an `__all__` entry requires a matching edit in `tests/test_public_surface.py` in the same commit.

## Turn-worker invariants

`src/zeno/runtime/turn_worker.py` is the per-thread FIFO. Hold these contracts:

- **One worker per `(user_id, thread_key)` key.** Different keys process concurrently; the same key is strictly FIFO.
- **`Ctx` is constructed inside `bind_ctx` before the agent handler runs.** Tool ContextVars only propagate inside that scope. Provider construction must happen *inside* the bound scope, not outside it.
- **Auto-finalize unsealed `StreamBuffer`s at turn end.** The worker calls `buffer.finalize()` if the agent forgot.
- **Errors propagate to `on_turn_error`.** Don't swallow exceptions in tool handlers — the worker formats them for the model and dispatches the policy callback.

## Protocol contracts

`src/zeno/protocols/` defines the structural types adapter packages implement. When changing a Protocol:

1. Update the Protocol signature.
2. Update every implementer in the workspace (grep for `(MemoryView)` etc.).
3. Update the contract test suite if one exists (`zeno-chroma`, `zeno-qdrant` ship contract tests).
4. Bump major if the change breaks `__all__` callers.

## Tool decorator

`@tool` validates that `Ctx` is the first positional arg at registration. Don't work around this. Tools return `str` or JSON-serializable strings — the provider serializes the return value into the model's tool-result envelope. Errors propagate; don't catch them inside the tool body unless you're translating a domain-specific exception.

## Testing

- `pytest packages/zeno-core` runs the unit suite.
- `tests/test_public_surface.py` is the snapshot — failures here mean someone added/removed an `__all__` symbol without updating the snapshot.
- Mock only at system boundaries (HTTP, time, file system). Never mock internal collaborators.
