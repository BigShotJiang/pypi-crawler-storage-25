"""Tests for `zeno.runtime.working_memory_block.render` (R11–R15)."""

from __future__ import annotations

from datetime import UTC, datetime

from pydantic import BaseModel
from zeno.memory.protocols import WorkingMemoryRecord
from zeno.runtime.working_memory_block import BLOCK_HEADER, render


def _epoch(year: int, month: int, day: int) -> int:
    return int(datetime(year, month, day, tzinfo=UTC).timestamp())


class _UserCard(BaseModel):
    name: str | None = None
    role: str | None = None
    notes: str | None = None


def _record(field: str, value: str, when: int) -> WorkingMemoryRecord:
    return WorkingMemoryRecord(
        user_id="alice",
        agent_id="root",
        field_name=field,
        value=value,
        last_updated=when,
    )


def test_render_returns_empty_when_schema_is_none() -> None:
    assert render(None, {}) == ""


def test_render_with_no_records_emits_unknown_per_field() -> None:
    out = render(_UserCard, {})
    expected = f"{BLOCK_HEADER}\n- name: (unknown)\n- role: (unknown)\n- notes: (unknown)\n\n"
    assert out == expected


def test_render_with_partial_records_keeps_schema_order() -> None:
    records = {
        "role": _record("role", "Engineer", _epoch(2026, 4, 15)),
        "name": _record("name", "Niels", _epoch(2026, 4, 12)),
    }
    out = render(_UserCard, records)
    expected = (
        f"{BLOCK_HEADER}\n"
        "- name: Niels (updated 2026-04-12)\n"
        "- role: Engineer (updated 2026-04-15)\n"
        "- notes: (unknown)\n"
        "\n"
    )
    assert out == expected


def test_render_treats_empty_string_value_as_unknown() -> None:
    """An empty string is the clear sentinel — store may keep a row briefly."""
    records = {"name": _record("name", "", _epoch(2026, 4, 12))}
    out = render(_UserCard, records)
    assert "- name: (unknown)" in out
    assert "(updated" not in out.split("\n")[1]


def test_render_is_byte_stable_across_identical_inputs() -> None:
    records = {"name": _record("name", "Niels", _epoch(2026, 4, 12))}
    a = render(_UserCard, records)
    b = render(_UserCard, records)
    assert a == b


def test_render_is_byte_stable_within_same_day_jitter() -> None:
    """Two timestamps on the same UTC day render identically."""
    morning = int(datetime(2026, 4, 12, 1, 0, tzinfo=UTC).timestamp())
    evening = int(datetime(2026, 4, 12, 23, 0, tzinfo=UTC).timestamp())
    a = render(_UserCard, {"name": _record("name", "Niels", morning)})
    b = render(_UserCard, {"name": _record("name", "Niels", evening)})
    assert a == b


def test_render_changes_when_value_changes() -> None:
    a = render(_UserCard, {"name": _record("name", "Niels", _epoch(2026, 4, 12))})
    b = render(_UserCard, {"name": _record("name", "Bob", _epoch(2026, 4, 12))})
    assert a != b
