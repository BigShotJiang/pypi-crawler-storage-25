"""Tests for `Agent` / `SubAgent` pure-data invariants.

Provider-specific options assembly used to live here; it moved to
`packages/zeno-provider-claude/tests/test_agent_options.py` when the
Claude SDK translation moved out of core in 1.0.0rc2.
"""

from __future__ import annotations

import pytest
from pydantic import BaseModel
from zeno.agent import Agent, SubAgent
from zeno.exceptions import ZenoError


def test_agent_duplicate_sub_agent_names_rejected() -> None:
    sa_a = SubAgent(name="dup", instructions="a")
    sa_b = SubAgent(name="dup", instructions="b")

    with pytest.raises(ZenoError, match="duplicate sub-agent names"):
        Agent(name="root", instructions="i", sub_agents=[sa_a, sa_b])


# ---------------------------------------------------------------------------
# working_memory_schema (L2)
# ---------------------------------------------------------------------------


class _ValidCard(BaseModel):
    name: str | None = None
    role: str | None = None


def test_agent_accepts_valid_working_memory_schema() -> None:
    agent = Agent(name="a", instructions="i", working_memory_schema=_ValidCard)
    assert agent.working_memory_schema is _ValidCard


def test_agent_default_working_memory_schema_is_none() -> None:
    agent = Agent(name="a", instructions="i")
    assert agent.working_memory_schema is None


def test_agent_rejects_non_basemodel_schema() -> None:
    class NotAModel:
        pass

    with pytest.raises(TypeError, match="must be a Pydantic BaseModel"):
        Agent(
            name="a",
            instructions="i",
            working_memory_schema=NotAModel,  # type: ignore[arg-type]
        )


def test_agent_rejects_non_str_optional_field() -> None:
    class IntCard(BaseModel):
        count: int | None = None

    with pytest.raises(TypeError, match="must be `str \\| None`"):
        Agent(name="a", instructions="i", working_memory_schema=IntCard)


def test_agent_rejects_required_str_field_without_optional() -> None:
    class RequiredStr(BaseModel):
        name: str

    with pytest.raises(TypeError, match="must be `str \\| None`"):
        Agent(name="a", instructions="i", working_memory_schema=RequiredStr)
