"""Tests for `zeno.runtime.mcp.allowed_tool_names`.

The `build_mcp_server` round-trip test moved to
`packages/zeno-provider-claude/tests/test_mcp.py` along with the
function itself in 1.0.0rc2.
"""

from __future__ import annotations

from zeno.context import Ctx
from zeno.runtime.mcp import allowed_tool_names
from zeno.tool import get_spec, tool


def test_allowed_tool_names_format() -> None:
    @tool
    async def foo(ctx: Ctx) -> str:
        return "ok"

    @tool
    async def bar(ctx: Ctx, x: int) -> str:
        return "ok"

    specs = [get_spec(foo), get_spec(bar)]
    assert allowed_tool_names("zeno_app", specs) == [
        "mcp__zeno_app__foo",
        "mcp__zeno_app__bar",
    ]
