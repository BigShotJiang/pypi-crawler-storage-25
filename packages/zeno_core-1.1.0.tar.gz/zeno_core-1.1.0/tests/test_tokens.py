"""Tests for the token-counting heuristic and the `TokenCounter` seam."""

from __future__ import annotations

from zeno.runtime import TokenCounter, count_tokens


def test_count_tokens_empty_string_returns_zero() -> None:
    assert count_tokens("") == 0


def test_count_tokens_short_string_is_within_bounds() -> None:
    n = count_tokens("hello world")
    assert 1 <= n <= 11


def test_count_tokens_4000_char_string_is_about_1000() -> None:
    n = count_tokens("a" * 4000)
    assert n == 1000


def test_count_tokens_counts_whitespace() -> None:
    assert count_tokens("\n" * 100) == 25


def test_token_counter_protocol_accepts_custom_counter() -> None:
    counter: TokenCounter = lambda s: len(s.split())  # noqa: E731 — callable test
    assert counter("hello world") == 2
    assert counter("") == 0
