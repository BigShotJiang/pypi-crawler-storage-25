"""Tests for the `Channel` Protocol + message type contracts."""

from __future__ import annotations

import pickle
from collections.abc import AsyncIterator
from datetime import datetime

import pytest
from zeno.channels.messages import (
    Attachment,
    IncomingMessage,
    MessageBlock,
    OutgoingMessage,
)
from zeno.channels.protocol import Capabilities, Channel


class _StubChannel:
    name = "stub"
    capabilities = Capabilities(supports_streaming=True)

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        if False:
            yield  # pragma: no cover — async generator marker
        return

    async def send(self, message: OutgoingMessage) -> None:
        return None


def test_stub_channel_satisfies_protocol() -> None:
    channel = _StubChannel()
    assert isinstance(channel, Channel)


def test_capabilities_defaults_are_conservative() -> None:
    cap = Capabilities()
    assert cap.supports_threading is False
    assert cap.supports_images is False
    assert cap.supports_audio is False
    assert cap.supports_streaming is False
    assert cap.supports_reactions is False
    assert cap.supports_typing is False
    assert cap.max_message_length is None


def test_incoming_message_normalizes_empty_thread_key() -> None:
    msg = IncomingMessage(
        user_id="alice",
        text="hi",
        received_at=datetime(2026, 4, 19, 10, 0, 0),
        thread_key="",
    )
    assert msg.thread_key is None


def test_incoming_message_normalizes_whitespace_thread_key() -> None:
    msg = IncomingMessage(
        user_id="alice",
        text="hi",
        received_at=datetime(2026, 4, 19, 10, 0, 0),
        thread_key="   ",
    )
    assert msg.thread_key is None


def test_incoming_message_preserves_real_thread_key() -> None:
    msg = IncomingMessage(
        user_id="alice",
        text="hi",
        received_at=datetime(2026, 4, 19, 10, 0, 0),
        thread_key="thread-abc",
    )
    assert msg.thread_key == "thread-abc"


def test_empty_user_id_rejected() -> None:
    with pytest.raises(ValueError, match="user_id must be a non-empty string"):
        IncomingMessage(
            user_id="",
            text="hi",
            received_at=datetime(2026, 4, 19, 10, 0, 0),
        )


def test_outgoing_message_normalizes_reply_thread_key() -> None:
    msg = OutgoingMessage(text="hello", reply_to_thread_key="")
    assert msg.reply_to_thread_key is None


def test_incoming_message_pickles_round_trip() -> None:
    original = IncomingMessage(
        user_id="alice",
        text="hi",
        received_at=datetime(2026, 4, 19, 10, 0, 0),
        thread_key="t1",
        blocks=[MessageBlock(kind="text", text="hi")],
        attachments=[Attachment(kind="image", url="https://example.com/x.png")],
        raw={"source": "test"},
    )
    restored = pickle.loads(pickle.dumps(original))
    assert restored == original


def test_outgoing_message_pickles_round_trip() -> None:
    original = OutgoingMessage(
        text="hello",
        blocks=[MessageBlock(kind="markdown", text="**bold**")],
        suggested_replies=["yes", "no"],
    )
    restored = pickle.loads(pickle.dumps(original))
    assert restored == original
