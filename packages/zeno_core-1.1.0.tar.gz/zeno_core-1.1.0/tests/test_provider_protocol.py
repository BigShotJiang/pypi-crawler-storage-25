"""Tests for the `Provider` Protocol, `Capabilities` dataclass, and provider exceptions (IU1).

These tests pin the structural contract that every provider adapter must
satisfy: the shape of `Capabilities`, `isinstance` against the `Protocol`,
the exception constructors, and the `ZENO_PROVIDERS` entry-point group.

Follow the pattern in `test_plugins_discovery.py` for entry-point mocking.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from zeno.channels.messages import IncomingMessage
from zeno.exceptions import (
    ConfigurationError,
    ProviderCapabilityError,
    ProviderError,
    ZenoError,
)
from zeno.plugins.discovery import discover, discover_all
from zeno.plugins.groups import ALL_GROUPS, ZENO_PROVIDERS
from zeno.providers.protocol import Capabilities, Provider

# -----------------------------------------------------------------------------
# Capabilities dataclass
# -----------------------------------------------------------------------------


def test_capabilities_equality() -> None:
    a = Capabilities(
        supports_sub_agents=True,
        supports_built_in_tools=True,
        supports_permission_mode=True,
        supports_streaming=True,
    )
    b = Capabilities(
        supports_sub_agents=True,
        supports_built_in_tools=True,
        supports_permission_mode=True,
        supports_streaming=True,
    )
    assert a == b


def test_capabilities_hashable() -> None:
    a = Capabilities(
        supports_sub_agents=False,
        supports_built_in_tools=False,
        supports_permission_mode=False,
        supports_streaming=True,
    )
    # frozen + slots → hashable; must be usable in sets/dicts.
    assert {a} == {a}


def test_capabilities_distinct_values_not_equal() -> None:
    a = Capabilities(
        supports_sub_agents=True,
        supports_built_in_tools=True,
        supports_permission_mode=True,
        supports_streaming=True,
    )
    b = Capabilities(
        supports_sub_agents=False,
        supports_built_in_tools=True,
        supports_permission_mode=True,
        supports_streaming=True,
    )
    assert a != b


# -----------------------------------------------------------------------------
# Provider structural typing
# -----------------------------------------------------------------------------


class _DummyProvider:
    """Non-inheriting class that satisfies the `Provider` Protocol by shape."""

    @property
    def capabilities(self) -> Capabilities:
        return Capabilities(
            supports_sub_agents=False,
            supports_built_in_tools=False,
            supports_permission_mode=False,
            supports_streaming=False,
        )

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None

    async def run_turn(self, *, agent: Any, ctx: Any, msg: IncomingMessage) -> None:
        return None


def test_dummy_provider_passes_isinstance() -> None:
    assert isinstance(_DummyProvider(), Provider)


def test_incomplete_class_fails_isinstance() -> None:
    class _Incomplete:
        @property
        def capabilities(self) -> Capabilities:
            return Capabilities(
                supports_sub_agents=False,
                supports_built_in_tools=False,
                supports_permission_mode=False,
                supports_streaming=False,
            )

        async def start(self) -> None:
            return None

        # Missing: stop, run_turn.

    assert not isinstance(_Incomplete(), Provider)


# -----------------------------------------------------------------------------
# Exceptions
# -----------------------------------------------------------------------------


def test_provider_capability_error_message_format() -> None:
    err = ProviderCapabilityError(provider="OpenAIProvider", missing=["sub_agents", "WebSearch"])
    assert err.provider == "OpenAIProvider"
    assert err.missing == ["sub_agents", "WebSearch"]
    msg = str(err)
    # Lock the user-facing format — provider name, prose, list of misses.
    assert "OpenAIProvider" in msg
    assert "cannot run this Agent" in msg
    assert "sub_agents" in msg
    assert "WebSearch" in msg


def test_provider_capability_error_empty_missing_raises() -> None:
    with pytest.raises(ValueError):
        ProviderCapabilityError(provider="X", missing=[])


def test_provider_capability_error_is_zeno_error() -> None:
    err = ProviderCapabilityError(provider="X", missing=["a"])
    assert isinstance(err, ZenoError)


def test_provider_error_is_zeno_error() -> None:
    err = ProviderError("boom")
    assert isinstance(err, ZenoError)
    assert str(err) == "boom"


def test_configuration_error_is_zeno_error() -> None:
    err = ConfigurationError("missing provider=")
    assert isinstance(err, ZenoError)
    assert "missing provider=" in str(err)


# -----------------------------------------------------------------------------
# Entry-point group constant
# -----------------------------------------------------------------------------


def test_zeno_providers_group_constant() -> None:
    assert ZENO_PROVIDERS == "zeno.providers"


def test_zeno_providers_in_all_groups() -> None:
    assert ZENO_PROVIDERS in ALL_GROUPS


# -----------------------------------------------------------------------------
# Discovery integration
# -----------------------------------------------------------------------------


def _make_ep(name: str, value: str, group: str, dist_name: str) -> Any:
    """Same pattern as test_plugins_discovery._make_ep."""
    ep = MagicMock()
    ep.name = name
    ep.value = value
    ep.group = group
    dist = MagicMock()
    dist.name = dist_name
    ep.dist = dist
    return ep


def test_discovery_surfaces_provider_entry_points() -> None:
    ep = _make_ep(
        "openai",
        "zeno.providers.openai:OpenAIProvider",
        ZENO_PROVIDERS,
        "zeno-provider-openai",
    )
    with patch("zeno.plugins.discovery.entry_points", return_value=[ep]):
        result = discover(ZENO_PROVIDERS)
    assert "openai" in result
    assert result["openai"].value == "zeno.providers.openai:OpenAIProvider"


def test_discover_all_includes_zeno_providers_group() -> None:
    calls: list[str] = []

    def fake_ep(*, group: str) -> list[Any]:
        calls.append(group)
        return []

    with patch("zeno.plugins.discovery.entry_points", side_effect=fake_ep):
        result = discover_all(ALL_GROUPS)

    assert ZENO_PROVIDERS in calls
    assert ZENO_PROVIDERS in result
