"""Tests for `Tracer` Protocol, default implementations, and BackgroundDispatcher."""

from __future__ import annotations

import asyncio
import io
import json

from zeno.observability.events import (
    MemoryObserved,
    MemoryReflected,
    ToolCallCompleted,
    ToolCallStarted,
    TurnStarted,
    _Envelope,
    event_payload,
)
from zeno.observability.tracer import (
    BackgroundDispatcher,
    NoOpTracer,
    StdoutTracer,
    Tracer,
)


def _env(turn_id: str = "t1", seq: int = 0) -> _Envelope:
    return _Envelope(
        turn_id=turn_id,
        sequence=seq,
        user_id="alice",
        session_id="s1",
    )


def test_noop_tracer_discards_events() -> None:
    tracer = NoOpTracer()
    # Just make sure the Protocol is satisfied and no exceptions are raised.
    assert isinstance(tracer, Tracer)
    tracer.on_event(TurnStarted(envelope=_env(), channel="cli", thread_key=None))


def test_stdout_tracer_emits_one_json_line_per_event() -> None:
    buf = io.StringIO()
    tracer = StdoutTracer(stream=buf)
    tracer.on_event(TurnStarted(envelope=_env(), channel="cli", thread_key=None))
    tracer.on_event(ToolCallStarted(envelope=_env(seq=1), tool_name="greet", tool_use_id="u1"))

    lines = [line for line in buf.getvalue().splitlines() if line]
    assert len(lines) == 2
    rec0 = json.loads(lines[0])
    assert rec0["kind"] == "turn_started"
    assert rec0["turn_id"] == "t1"
    assert rec0["channel"] == "cli"
    rec1 = json.loads(lines[1])
    assert rec1["kind"] == "tool_call_started"
    assert rec1["tool_name"] == "greet"


def test_stdout_tracer_survives_unserializable_fields() -> None:
    buf = io.StringIO()
    tracer = StdoutTracer(stream=buf)
    # datetime is serialized via isoformat by event_payload.
    tracer.on_event(TurnStarted(envelope=_env(), channel="cli", thread_key=None))
    assert "emitted_at" in buf.getvalue()


def test_event_payload_includes_envelope_and_event_fields() -> None:
    ev = ToolCallCompleted(
        envelope=_env(seq=2),
        tool_name="search",
        tool_use_id="u2",
        duration_ms=42,
        error=False,
    )
    payload = event_payload(ev)
    assert payload["kind"] == "tool_call_completed"
    assert payload["turn_id"] == "t1"
    assert payload["sequence"] == 2
    assert payload["tool_name"] == "search"
    assert payload["duration_ms"] == 42
    assert payload["error"] is False
    assert "emitted_at" in payload


def test_memory_observed_event_payload_round_trip() -> None:
    """`MemoryObserved` serializes through `event_payload` with all fields."""
    ev = MemoryObserved(
        run_id="r1",
        user_id="alice",
        agent_id="root",
        thread_key="cli:alice",
        rounds_seen=3,
        observations_written=2,
        duration_ms=137,
    )
    payload = event_payload(ev)
    assert payload["kind"] == "memory_observed"
    assert payload["turn_id"] == "observer:r1"
    assert payload["user_id"] == "alice"
    assert payload["session_id"] is None
    assert payload["agent_id"] == "root"
    assert payload["thread_key"] == "cli:alice"
    assert payload["rounds_seen"] == 3
    assert payload["observations_written"] == 2
    assert payload["duration_ms"] == 137
    assert payload["error"] is False


def test_memory_observed_error_event_is_well_formed() -> None:
    ev = MemoryObserved(
        run_id="r2",
        user_id="alice",
        agent_id="root",
        thread_key=None,
        rounds_seen=0,
        observations_written=0,
        duration_ms=11,
        error=True,
    )
    payload = event_payload(ev)
    assert payload["error"] is True
    assert payload["thread_key"] is None
    assert payload["observations_written"] == 0


def test_memory_reflected_event_payload_round_trip() -> None:
    """`MemoryReflected` serializes through `event_payload` with all fields."""
    ev = MemoryReflected(
        run_id="r3",
        user_id="alice",
        proposals_generated=5,
        proposals_accepted=4,
        merges_applied=2,
        replaces_applied=1,
        deletes_applied=1,
        duration_ms=312,
    )
    payload = event_payload(ev)
    assert payload["kind"] == "memory_reflected"
    assert payload["turn_id"] == "reflector:r3"
    assert payload["user_id"] == "alice"
    assert payload["proposals_generated"] == 5
    assert payload["proposals_accepted"] == 4
    assert payload["merges_applied"] == 2
    assert payload["replaces_applied"] == 1
    assert payload["deletes_applied"] == 1
    assert payload["duration_ms"] == 312
    assert payload["error"] is False


def test_memory_reflected_error_event_is_well_formed() -> None:
    ev = MemoryReflected(
        run_id="r4",
        user_id="alice",
        proposals_generated=0,
        proposals_accepted=0,
        merges_applied=0,
        replaces_applied=0,
        deletes_applied=0,
        duration_ms=4,
        error=True,
    )
    payload = event_payload(ev)
    assert payload["error"] is True
    assert payload["proposals_generated"] == 0


def test_memory_observed_and_reflected_dispatched_through_tracer() -> None:
    """Integration: an in-memory tracer captures both events via `on_event`."""
    captured: list[object] = []

    class _ListTracer:
        def on_event(self, event: object) -> None:
            captured.append(event)

    tracer = _ListTracer()
    obs_event = MemoryObserved(
        run_id="r5",
        user_id="alice",
        agent_id="root",
        thread_key=None,
        rounds_seen=1,
        observations_written=1,
        duration_ms=10,
    )
    refl_event = MemoryReflected(
        run_id="r6",
        user_id="alice",
        proposals_generated=1,
        proposals_accepted=1,
        merges_applied=1,
        replaces_applied=0,
        deletes_applied=0,
        duration_ms=20,
    )
    tracer.on_event(obs_event)
    tracer.on_event(refl_event)
    assert captured == [obs_event, refl_event]


async def test_background_dispatcher_runs_fire_and_forget() -> None:
    done = asyncio.Event()

    async def work() -> None:
        await asyncio.sleep(0)
        done.set()

    dispatcher = BackgroundDispatcher()
    dispatcher.fire(work())
    await asyncio.wait_for(done.wait(), timeout=1.0)
    await dispatcher.drain()


async def test_background_dispatcher_swallows_errors() -> None:
    dispatcher = BackgroundDispatcher()

    async def boom() -> None:
        raise RuntimeError("boom")

    dispatcher.fire(boom())
    # Must not raise here; errors are logged inside the background task.
    await dispatcher.drain()


def test_background_dispatcher_without_loop_drops_task() -> None:
    dispatcher = BackgroundDispatcher()

    async def work() -> None:  # pragma: no cover
        return None

    coro = work()
    # Outside a running loop — the dispatcher must silently drop.
    dispatcher.fire(coro)
    coro.close()


async def test_stdout_tracer_does_not_raise_on_internal_error() -> None:
    """A broken stream should log but not propagate."""

    class _BrokenStream:
        def write(self, _: str) -> int:
            raise OSError("disk full")

        def flush(self) -> None: ...

    tracer = StdoutTracer(stream=_BrokenStream())
    tracer.on_event(TurnStarted(envelope=_env(), channel="cli", thread_key=None))
