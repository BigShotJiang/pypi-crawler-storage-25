"""Tests for the dynamic `update_working_memory` builtin tool factory (L2)."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel
from zeno.agent import Agent
from zeno.builtin_tools import make_update_working_memory_tool, recall, remember
from zeno.context import Ctx
from zeno.tool import get_spec


class UserCard(BaseModel):
    name: str | None = None
    role: str | None = None
    notes: str | None = None


# ---------------------------------------------------------------------------
# Test doubles
# ---------------------------------------------------------------------------


@dataclass
class _RecordingWorkingMemory:
    rows: dict[str, str] = field(default_factory=dict)
    updates: list[dict[str, str]] = field(default_factory=list)

    async def get(self) -> dict[str, Any]:
        return {}

    async def update(self, patch: dict[str, str]) -> None:
        self.updates.append(dict(patch))
        for k, v in patch.items():
            if v == "":
                self.rows.pop(k, None)
            else:
                self.rows[k] = v

    async def clear(self) -> None:
        self.rows.clear()


@dataclass
class _Memory:
    working_memory: _RecordingWorkingMemory


def _ctx(memory: _Memory) -> Ctx:
    async def _noop(_: Any = None) -> None:
        return None

    async def _stream(_: str) -> None:
        return None

    return Ctx(
        user_id="alice",
        session_id=None,
        channel="test",
        memory=memory,  # type: ignore[arg-type]
        reply=_noop,
        stream=_stream,
        finalize=_noop,
        http=None,  # type: ignore[arg-type]
        logger=logging.getLogger("test.update_working_memory"),
        tracer=None,
        state={},
    )


# ---------------------------------------------------------------------------
# Schema-side wiring
# ---------------------------------------------------------------------------


def test_factory_returns_tool_with_flat_field_schema() -> None:
    handler = make_update_working_memory_tool(UserCard)
    spec = get_spec(handler)
    assert spec.name == "update_working_memory"
    props = spec.schema["properties"]
    assert set(props) == {"name", "role", "notes"}
    # Each field is `string` (`anyOf`-with-null collapses to a simple string in
    # the @tool decoder, but pydantic emits `anyOf: [string, null]` here).
    for fname in ("name", "role", "notes"):
        f_schema = props[fname]
        if "anyOf" in f_schema:
            types_ = {b.get("type") for b in f_schema["anyOf"]}
            assert types_ == {"string", "null"}
        else:
            assert f_schema.get("type") == "string"


def test_factory_description_lists_field_names() -> None:
    handler = make_update_working_memory_tool(UserCard)
    spec = get_spec(handler)
    assert "name" in spec.description
    assert "role" in spec.description
    assert "notes" in spec.description


def test_agent_auto_wires_tool_when_schema_set() -> None:
    agent = Agent(
        name="root",
        instructions="i",
        tools=[recall, remember],
        working_memory_schema=UserCard,
    )
    names = [s.name for s in agent._tool_specs()]
    assert "update_working_memory" in names
    assert names.count("update_working_memory") == 1


def test_agent_does_not_wire_tool_without_schema() -> None:
    agent = Agent(name="root", instructions="i", tools=[recall, remember])
    names = [s.name for s in agent._tool_specs()]
    assert "update_working_memory" not in names


# ---------------------------------------------------------------------------
# Tool runtime behavior
# ---------------------------------------------------------------------------


async def test_update_writes_provided_fields() -> None:
    handler = make_update_working_memory_tool(UserCard)
    wm = _RecordingWorkingMemory()
    ctx = _ctx(_Memory(working_memory=wm))

    out = await handler(ctx, name="Niels", role="Engineer")

    assert out == "updated: name, role"
    assert wm.updates == [{"name": "Niels", "role": "Engineer"}]


async def test_update_skips_fields_not_provided() -> None:
    handler = make_update_working_memory_tool(UserCard)
    wm = _RecordingWorkingMemory()
    wm.rows["name"] = "Niels"
    ctx = _ctx(_Memory(working_memory=wm))

    out = await handler(ctx, role="Senior Engineer")

    assert out == "updated: role"
    assert wm.updates == [{"role": "Senior Engineer"}]
    assert wm.rows["name"] == "Niels"


async def test_update_empty_string_clears_field() -> None:
    handler = make_update_working_memory_tool(UserCard)
    wm = _RecordingWorkingMemory()
    wm.rows["role"] = "Engineer"
    ctx = _ctx(_Memory(working_memory=wm))

    out = await handler(ctx, role="")

    assert out == "updated: role"
    assert wm.updates == [{"role": ""}]
    assert "role" not in wm.rows


async def test_update_rejects_unknown_field_and_writes_nothing() -> None:
    handler = make_update_working_memory_tool(UserCard)
    wm = _RecordingWorkingMemory()
    ctx = _ctx(_Memory(working_memory=wm))

    out = await handler(ctx, unknown_field="x")

    assert out.startswith("invalid: ")
    assert wm.updates == []


async def test_update_with_no_fields_is_noop() -> None:
    handler = make_update_working_memory_tool(UserCard)
    wm = _RecordingWorkingMemory()
    ctx = _ctx(_Memory(working_memory=wm))

    out = await handler(ctx)

    assert out == "updated: (no fields)"
    assert wm.updates == []


async def test_update_with_explicit_none_is_skipped() -> None:
    """An explicit `None` means "don't change this field" — no-op rather than clear."""
    handler = make_update_working_memory_tool(UserCard)
    wm = _RecordingWorkingMemory()
    ctx = _ctx(_Memory(working_memory=wm))

    out = await handler(ctx, name=None, role="Engineer")

    assert out == "updated: role"
    assert wm.updates == [{"role": "Engineer"}]
