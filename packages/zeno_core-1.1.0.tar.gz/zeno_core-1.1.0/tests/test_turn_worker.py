"""Tests for the `TurnDispatcher` — per-thread FIFO, error policies."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from unittest.mock import MagicMock

import httpx
from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Capabilities
from zeno.context import Ctx, current_ctx
from zeno.runtime.turn_worker import TurnDispatcher


@dataclass
class _Ch:
    supports_streaming: bool = False
    name: str = "fake"
    sent: list[OutgoingMessage] = field(default_factory=list)
    send_raises: Exception | None = None

    @property
    def capabilities(self) -> Capabilities:
        return Capabilities(supports_streaming=self.supports_streaming)

    async def start(self) -> None: ...

    async def stop(self) -> None: ...

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        if False:
            yield  # pragma: no cover
        return

    async def send(self, msg: Any) -> None:
        if self.send_raises is not None:
            raise self.send_raises
        self.sent.append(msg)


def _msg(user_id: str = "alice", thread: str | None = None, text: str = "hi") -> IncomingMessage:
    return IncomingMessage(
        user_id=user_id,
        text=text,
        received_at=datetime(2026, 4, 19, 10, 0, 0),
        thread_key=thread,
    )


def _ctx_factory(
    memory: Any,
    http: httpx.AsyncClient,
    logger: Any = None,
    tracer: Any = None,
) -> Any:
    async def _placeholder_callable(*_a: Any, **_k: Any) -> None: ...

    async def _placeholder_stream(_c: str) -> None: ...

    async def _placeholder_finalize() -> None: ...

    def _factory(channel: Any, msg: IncomingMessage) -> Ctx:
        return Ctx(
            user_id=msg.user_id,
            session_id=None,
            channel=channel.name,
            memory=memory,
            reply=_placeholder_callable,
            stream=_placeholder_stream,
            finalize=_placeholder_finalize,
            http=http,
            logger=logger or MagicMock(),
            tracer=tracer or MagicMock(),
        )

    return _factory


async def test_happy_path_handler_streams_and_finalizes(fake_ctx: Ctx) -> None:
    ch = _Ch(supports_streaming=True)

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        await ctx.stream("hel")
        await ctx.stream("lo")
        await ctx.finalize()

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
    )
    await d.enqueue(ch, _msg())
    await d.drain_all()

    assert [m.text for m in ch.sent] == ["hel", "lo"]


async def test_non_streaming_channel_receives_single_consolidated(fake_ctx: Ctx) -> None:
    ch = _Ch(supports_streaming=False)

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        await ctx.stream("hel")
        await ctx.stream("lo")
        await ctx.finalize()

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
    )
    await d.enqueue(ch, _msg())
    await d.drain_all()

    assert len(ch.sent) == 1
    assert ch.sent[0].text == "hello"


async def test_same_thread_processes_serially(fake_ctx: Ctx) -> None:
    ch = _Ch(supports_streaming=False)
    order: list[str] = []
    gate_a = asyncio.Event()

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        if msg.text == "a":
            order.append("a-start")
            await gate_a.wait()
            order.append("a-end")
        else:
            order.append(f"{msg.text}-start")
            order.append(f"{msg.text}-end")
        await ctx.finalize()

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
    )
    await d.enqueue(ch, _msg(thread="t", text="a"))
    await d.enqueue(ch, _msg(thread="t", text="b"))

    # Give the first turn a moment to reach the gate.
    await asyncio.sleep(0.01)
    assert order == ["a-start"]
    gate_a.set()

    await d.drain_all()
    assert order == ["a-start", "a-end", "b-start", "b-end"]


async def test_different_threads_run_concurrently(fake_ctx: Ctx) -> None:
    ch = _Ch(supports_streaming=False)
    order: list[str] = []
    gate = asyncio.Event()

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        if msg.thread_key == "t1":
            order.append("t1-start")
            await gate.wait()
            order.append("t1-end")
        else:
            order.append("t2-start")
            order.append("t2-end")
            gate.set()
        await ctx.finalize()

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
    )
    await d.enqueue(ch, _msg(thread="t1"))
    await d.enqueue(ch, _msg(thread="t2"))

    await d.drain_all()
    # t2 completes first (it sets the gate that t1 is blocked on).
    assert order == ["t1-start", "t2-start", "t2-end", "t1-end"]


async def test_auto_finalize_on_turn_end(fake_ctx: Ctx) -> None:
    ch = _Ch(supports_streaming=False)

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        await ctx.stream("unfinalized")

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
    )
    await d.enqueue(ch, _msg())
    await d.drain_all()

    assert len(ch.sent) == 1
    assert ch.sent[0].text == "unfinalized"


async def test_reply_finalizes_inflight_stream_then_sends(fake_ctx: Ctx) -> None:
    ch = _Ch(supports_streaming=False)

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        await ctx.stream("partial")
        await ctx.reply(OutgoingMessage(text="explicit"))

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
    )
    await d.enqueue(ch, _msg())
    await d.drain_all()

    assert [m.text for m in ch.sent] == ["partial", "explicit"]


async def test_agent_error_invokes_default_apology(fake_ctx: Ctx) -> None:
    ch = _Ch(supports_streaming=False)

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        raise RuntimeError("boom")

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
    )
    await d.enqueue(ch, _msg())
    await d.drain_all()

    assert len(ch.sent) == 1
    assert "Sorry" in (ch.sent[0].text or "")


async def test_custom_on_turn_error_fires(fake_ctx: Ctx) -> None:
    ch = _Ch()
    errors: list[BaseException] = []

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        raise ValueError("nope")

    async def on_turn_error(ctx: Ctx, msg: IncomingMessage, exc: BaseException) -> None:
        errors.append(exc)

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
        on_turn_error=on_turn_error,
    )
    await d.enqueue(ch, _msg())
    await d.drain_all()

    assert len(errors) == 1
    assert isinstance(errors[0], ValueError)


async def test_same_thread_continues_after_error(fake_ctx: Ctx) -> None:
    ch = _Ch()

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        if msg.text == "bad":
            raise RuntimeError("boom")
        await ctx.reply(OutgoingMessage(text=f"ok: {msg.text}"))

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
    )
    await d.enqueue(ch, _msg(thread="t", text="bad"))
    await d.enqueue(ch, _msg(thread="t", text="good"))
    await d.drain_all()

    # First turn sent the apology; second turn sent its explicit reply.
    texts = [m.text for m in ch.sent]
    assert any("Sorry" in (t or "") for t in texts)
    assert "ok: good" in texts


async def test_default_error_path_logs_traceback_at_error_level(fake_ctx: Ctx) -> None:
    """Unit 11: handler exception is logged via ctx.logger.error before user delegation."""
    ch = _Ch()
    logger = MagicMock()

    async def handler(_ctx: Ctx, _msg: IncomingMessage) -> None:
        raise RuntimeError("boom")

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http, logger=logger),
    )
    await d.enqueue(ch, _msg())
    await d.drain_all()

    assert logger.error.called, "default turn-error path must log via ctx.logger.error"
    call = logger.error.call_args
    assert "exc_info" in call.kwargs
    assert isinstance(call.kwargs["exc_info"], RuntimeError)


async def test_logging_runs_before_user_on_turn_error(fake_ctx: Ctx) -> None:
    """Unit 11: runtime logs first even when on_turn_error is supplied (dev sees trace)."""
    ch = _Ch()
    logger = MagicMock()
    seen: list[str] = []

    async def handler(_ctx: Ctx, _msg: IncomingMessage) -> None:
        raise ValueError("kaboom")

    async def on_turn_error(_ctx: Ctx, _msg: IncomingMessage, _exc: BaseException) -> None:
        seen.append("user_handler")

    logger.error.side_effect = lambda *a, **k: seen.append("log")

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http, logger=logger),
        on_turn_error=on_turn_error,
    )
    await d.enqueue(ch, _msg())
    await d.drain_all()

    assert seen == ["log", "user_handler"]


async def test_send_failure_handler_invoked(fake_ctx: Ctx) -> None:
    ch = _Ch(send_raises=RuntimeError("wire down"))
    failures: list[BaseException] = []

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        await ctx.reply(OutgoingMessage(text="hi"))

    async def on_send_failure(channel: Any, msg: Any, exc: BaseException) -> None:
        failures.append(exc)

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
        on_send_failure=on_send_failure,
    )
    await d.enqueue(ch, _msg())
    await d.drain_all()

    assert len(failures) == 1
    assert "wire down" in str(failures[0])


async def test_current_ctx_available_inside_handler(fake_ctx: Ctx) -> None:
    ch = _Ch()
    observed_user: list[str] = []

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        # Verifies `bind_ctx` wraps the handler invocation.
        observed_user.append(current_ctx().user_id)

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
    )
    await d.enqueue(ch, _msg(user_id="bob"))
    await d.drain_all()

    assert observed_user == ["bob"]
