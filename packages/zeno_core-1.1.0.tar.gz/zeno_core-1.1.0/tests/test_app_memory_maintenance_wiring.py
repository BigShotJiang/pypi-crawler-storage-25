"""Integration tests for `ZenoApp(memory_maintenance=...)` wiring.

Mirrors `test_app_browser_wiring.py` for the memory-maintenance subsystem.
Covers:

- ``memory_maintenance=None`` (default) preserves prior behavior: no new
  task, ``ctx.state["memory_maintenance"]`` is not set.
- Maintenance wired: ``start()`` called exactly once on ``run()``, and
  ``stop()`` called at least once on shutdown.
- ``ctx.state["memory_maintenance"]`` is the exact instance during a turn.
- ``start()`` raising propagates through ``run()`` cleanly.
- No cross-package dependency: zeno-core tests use a local structural
  fake with just ``async start()`` / ``async stop()``.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from typing import Any

import pytest
from zeno.agent import Agent
from zeno.app import ZenoApp
from zeno.channels.messages import IncomingMessage
from zeno.context import Ctx
from zeno.testing import FakeChannel, FakeProvider


class _FakeMaintenance:
    """Structural stand-in for `MemoryMaintenance`.

    The wiring contract only requires ``async start()`` / ``async stop()``,
    so a minimal counter object exercises the lifecycle without dragging
    `zeno-memory` into `zeno-core`'s test surface. Exposes a ``started``
    `asyncio.Event` so tests can `wait_for` deterministic signals instead
    of polling a wall-clock sleep.
    """

    def __init__(self, fail_start: bool = False) -> None:
        self.start_calls = 0
        self.stop_calls = 0
        self._fail_start = fail_start
        self.started = asyncio.Event()

    async def start(self) -> None:
        self.start_calls += 1
        if self._fail_start:
            raise RuntimeError("maintenance.start() failed")
        self.started.set()

    async def stop(self) -> None:
        self.stop_calls += 1


def _msg(user_id: str = "alice", text: str = "hi") -> IncomingMessage:
    return IncomingMessage(
        user_id=user_id,
        text=text,
        received_at=datetime(2026, 4, 24, 12, 0, 0, tzinfo=UTC),
    )


async def test_memory_maintenance_none_no_state_injection(fake_ctx: Ctx) -> None:
    """Default `memory_maintenance=None` — key is absent on `ctx.state`."""
    ch = FakeChannel(name="cli")
    state_values: list[Any] = []
    handled = asyncio.Event()

    async def on_turn(_agent: Agent, ctx: Ctx, _m: IncomingMessage) -> None:
        state_values.append(ctx.state.get("memory_maintenance", "_MISSING_"))
        handled.set()

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
    )
    run_task = asyncio.create_task(app.run())
    await ch.inbound_put(_msg())
    await asyncio.wait_for(handled.wait(), timeout=3.0)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=3.0)

    assert state_values == ["_MISSING_"], (
        "ctx.state['memory_maintenance'] must be absent when not configured"
    )


async def test_memory_maintenance_start_stop_called(fake_ctx: Ctx) -> None:
    """`start()` runs once on `run()`; `stop()` runs at least once on shutdown."""
    maintenance = _FakeMaintenance()
    ch = FakeChannel(name="cli")
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(),
        http_client=fake_ctx.http,
        memory_maintenance=maintenance,
    )
    run_task = asyncio.create_task(app.run())
    await asyncio.wait_for(maintenance.started.wait(), timeout=3.0)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=3.0)

    assert maintenance.start_calls == 1
    # `stop()` may run from both _run_memory_maintenance's finally and
    # ZenoApp.run's finally (mirrors the browser/scheduler pattern).
    assert maintenance.stop_calls >= 1


async def test_memory_maintenance_in_ctx_state_during_turn(fake_ctx: Ctx) -> None:
    """`ctx.state["memory_maintenance"]` exposes the exact instance."""
    maintenance = _FakeMaintenance()
    ch = FakeChannel(name="cli")
    state_values: list[Any] = []
    handled = asyncio.Event()

    async def on_turn(_agent: Agent, ctx: Ctx, _m: IncomingMessage) -> None:
        state_values.append(ctx.state.get("memory_maintenance"))
        handled.set()

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
        memory_maintenance=maintenance,
    )
    run_task = asyncio.create_task(app.run())
    await ch.inbound_put(_msg())
    await asyncio.wait_for(handled.wait(), timeout=3.0)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=3.0)

    assert state_values, "on_turn was never called"
    assert state_values[0] is maintenance


async def test_memory_maintenance_start_failure_propagates(fake_ctx: Ctx) -> None:
    """`start()` raising unwinds `run()` without hanging."""
    maintenance = _FakeMaintenance(fail_start=True)
    ch = FakeChannel(name="cli")
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(),
        http_client=fake_ctx.http,
        memory_maintenance=maintenance,
    )
    with pytest.raises(BaseExceptionGroup) as excinfo:
        await asyncio.wait_for(app.run(), timeout=3.0)
    assert any(isinstance(exc, RuntimeError) for exc in excinfo.value.exceptions)
    assert ch.stopped is True
