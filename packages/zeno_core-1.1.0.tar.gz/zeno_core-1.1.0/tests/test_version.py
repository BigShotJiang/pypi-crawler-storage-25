"""Smoke test: zeno.version exposes a resolved __version__."""

from __future__ import annotations

import re

from zeno.version import __version__


def test_version_is_pep440_string() -> None:
    """`__version__` is a non-empty string in a PEP 440-ish shape."""
    assert isinstance(__version__, str)
    assert __version__
    assert re.match(r"^\d+\.\d+\.\d+", __version__) or "+unknown" in __version__
