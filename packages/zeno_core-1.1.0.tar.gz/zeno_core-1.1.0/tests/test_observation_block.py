"""Tests for `observation_block.render` — pure renderer for the L4 block.

Asserts:
  - emoji + token marker output
  - grouping by referenced_date with observation_date fallback
  - within-group sort by observation_date
  - relative-date formatting for today/yesterday/N days/weeks/months
  - byte-stability across same-day renders (R16)
  - empty-list shortcut returns ``""``
  - exact reference output matches the high-level technical-design block
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta
from typing import Literal

from zeno.runtime.observation_block import BLOCK_HEADER, GROUP_PREFIX, render


@dataclass(frozen=True, slots=True)
class _FakeObservation:
    """Minimal structural stand-in for `zeno.memory.protocols.Observation`."""

    text: str
    priority: Literal["high", "medium", "low"]
    observation_date: int
    referenced_date: int | None = None
    # Fields the renderer never reads — present so the dataclass is a
    # full structural twin if a test mistypes the protocol.
    id: int = 0
    user_id: str = "alice"
    agent_id: str = "root"
    source_round_ids: tuple[int, ...] = ()
    created_at: int = 0
    archived_at: int | None = None


def _ts(year: int, month: int, day: int, *, hour: int = 0, minute: int = 0) -> int:
    return int(datetime(year, month, day, hour, minute, tzinfo=UTC).timestamp())


def _now_at(d: date) -> int:
    return int(datetime(d.year, d.month, d.day, 12, 0, tzinfo=UTC).timestamp())


# ---------------------------------------------------------------------------
# Empty / shape
# ---------------------------------------------------------------------------


def test_empty_returns_empty_string() -> None:
    assert render([], priority_markers="emoji", now_fn=lambda: _now_at(date(2026, 4, 30))) == ""


def test_block_starts_with_header() -> None:
    obs = [_FakeObservation(text="hi", priority="low", observation_date=_ts(2026, 4, 30))]
    out = render(obs, priority_markers="emoji", now_fn=lambda: _now_at(date(2026, 4, 30)))
    assert out.startswith(f"{BLOCK_HEADER}\n")
    assert out.endswith("\n")


# ---------------------------------------------------------------------------
# Reference output (mirrors plan's High-Level Technical Design block)
# ---------------------------------------------------------------------------


def test_reference_block_matches_plan_design() -> None:
    today = date(2026, 4, 30)
    eight_days_ago_ts = _ts(2026, 4, 22, hour=9, minute=14)
    today_ts = _ts(2026, 4, 30, hour=11, minute=2)
    obs = [
        _FakeObservation(
            text="User decided to use Postgres for the new project",
            priority="high",
            observation_date=eight_days_ago_ts,
        ),
        _FakeObservation(
            text='User reads "Designing Data-Intensive Applications"',
            priority="medium",
            observation_date=eight_days_ago_ts,
        ),
        _FakeObservation(
            text="User mentioned weekend hike to Mt Tam",
            priority="low",
            observation_date=today_ts,
        ),
    ]
    out = render(obs, priority_markers="emoji", now_fn=lambda: _now_at(today))
    expected = (
        f"{BLOCK_HEADER}\n"
        f"{GROUP_PREFIX}2026-04-22\n"
        "🔴 09:14 User decided to use Postgres for the new project (8 days ago)\n"
        '🟡 09:14 User reads "Designing Data-Intensive Applications" (8 days ago)\n'
        f"{GROUP_PREFIX}2026-04-30\n"
        "🟢 11:02 User mentioned weekend hike to Mt Tam (today)\n"
        "\n"
    )
    assert out == expected


# ---------------------------------------------------------------------------
# Marker modes
# ---------------------------------------------------------------------------


def test_token_priority_markers() -> None:
    today = date(2026, 4, 30)
    obs = [
        _FakeObservation(text="x", priority="high", observation_date=_ts(2026, 4, 30, hour=8)),
        _FakeObservation(text="y", priority="medium", observation_date=_ts(2026, 4, 30, hour=9)),
        _FakeObservation(text="z", priority="low", observation_date=_ts(2026, 4, 30, hour=10)),
    ]
    out = render(obs, priority_markers="tokens", now_fn=lambda: _now_at(today))
    assert "[high] 08:00 x (today)" in out
    assert "[med] 09:00 y (today)" in out
    assert "[low] 10:00 z (today)" in out


# ---------------------------------------------------------------------------
# Grouping & sorting
# ---------------------------------------------------------------------------


def test_referenced_date_groups_when_set_and_falls_back_to_observation_date() -> None:
    today = date(2026, 4, 30)
    obs = [
        # observation_date today, but referenced_date is 2 days ago — group as 2 days ago.
        _FakeObservation(
            text="ref-set",
            priority="medium",
            observation_date=_ts(2026, 4, 30, hour=10),
            referenced_date=_ts(2026, 4, 28, hour=0),
        ),
        # No referenced_date — falls back to observation_date (today).
        _FakeObservation(
            text="ref-null",
            priority="low",
            observation_date=_ts(2026, 4, 30, hour=11),
            referenced_date=None,
        ),
    ]
    out = render(obs, priority_markers="emoji", now_fn=lambda: _now_at(today))
    # Group 2026-04-28 must appear before group 2026-04-30.
    idx_28 = out.index(f"{GROUP_PREFIX}2026-04-28")
    idx_30 = out.index(f"{GROUP_PREFIX}2026-04-30")
    assert idx_28 < idx_30
    # Each line lives in its own group.
    assert "10:00 ref-set" in out
    assert "11:00 ref-null" in out


def test_within_group_sorted_by_observation_date_ascending() -> None:
    today = date(2026, 4, 30)
    later = _FakeObservation(
        text="later", priority="low", observation_date=_ts(2026, 4, 30, hour=14)
    )
    earlier = _FakeObservation(
        text="earlier", priority="low", observation_date=_ts(2026, 4, 30, hour=8)
    )
    out = render([later, earlier], priority_markers="emoji", now_fn=lambda: _now_at(today))
    assert out.index("08:00 earlier") < out.index("14:00 later")


# ---------------------------------------------------------------------------
# Relative-date formatting
# ---------------------------------------------------------------------------


def test_relative_dates_today_yesterday_days_weeks_months() -> None:
    today = date(2026, 4, 30)

    def _make(days_ago: int) -> _FakeObservation:
        ts = (
            int(datetime(today.year, today.month, today.day, 9, 0, tzinfo=UTC).timestamp())
            - days_ago * 86_400
        )
        return _FakeObservation(text=f"d{days_ago}", priority="low", observation_date=ts)

    obs = [_make(0), _make(1), _make(3), _make(8), _make(14), _make(60)]
    out = render(obs, priority_markers="emoji", now_fn=lambda: _now_at(today))
    assert "(today)" in out
    assert "(yesterday)" in out
    assert "(3 days ago)" in out
    assert "(8 days ago)" in out
    assert "(2 weeks ago)" in out
    assert "(2 months ago)" in out


# ---------------------------------------------------------------------------
# Byte-stability (R16)
# ---------------------------------------------------------------------------


def test_byte_stable_across_same_day_now_calls() -> None:
    """Two `now_fn` values within the same UTC day must produce identical output."""
    today = date(2026, 4, 30)
    obs = [
        _FakeObservation(
            text="alpha", priority="medium", observation_date=_ts(2026, 4, 22, hour=9)
        ),
        _FakeObservation(text="beta", priority="high", observation_date=_ts(2026, 4, 30, hour=8)),
    ]
    morning = int(datetime(today.year, today.month, today.day, 1, 5, tzinfo=UTC).timestamp())
    evening = int(datetime(today.year, today.month, today.day, 23, 55, tzinfo=UTC).timestamp())
    out_morning = render(obs, priority_markers="emoji", now_fn=lambda: morning)
    out_evening = render(obs, priority_markers="emoji", now_fn=lambda: evening)
    assert out_morning == out_evening


def test_day_boundary_changes_relative_date_only() -> None:
    """A day boundary cross flips ``today`` to ``yesterday`` (documented behaviour)."""
    today = date(2026, 4, 30)
    tomorrow = today + timedelta(days=1)
    obs = [
        _FakeObservation(text="alpha", priority="low", observation_date=_ts(2026, 4, 30, hour=12)),
    ]
    today_render = render(obs, priority_markers="emoji", now_fn=lambda: _now_at(today))
    tomorrow_render = render(obs, priority_markers="emoji", now_fn=lambda: _now_at(tomorrow))
    assert "(today)" in today_render
    assert "(yesterday)" in tomorrow_render
