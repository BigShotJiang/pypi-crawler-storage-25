"""Tests for `recall` / `remember` built-in tools."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import pytest
from zeno.builtin_tools import recall, remember
from zeno.context import Ctx, bind_ctx
from zeno.tool import get_spec


@dataclass
class _Hit:
    text: str
    score: float
    meta: dict[str, Any] = field(default_factory=dict)


class _RecordingView:
    def __init__(self) -> None:
        self.rows: list[str] = []
        self.tiers: list[str] = []
        self.search_calls: list[tuple[str, int]] = []

    async def search(self, query: str, k: int = 5) -> list[_Hit]:
        self.search_calls.append((query, k))
        tokens = set(query.lower().split())
        hits: list[_Hit] = []
        for row in self.rows:
            overlap = tokens & set(row.lower().split())
            if overlap:
                hits.append(_Hit(text=row, score=float(len(overlap))))
        hits.sort(key=lambda h: h.score, reverse=True)
        return hits

    async def add(
        self,
        text: str,
        meta: dict[str, Any] | None = None,
        *,
        tier: str = "long",
    ) -> None:
        self.rows.append(text)
        self.tiers.append(tier)


@dataclass
class _Memory:
    user: _RecordingView
    knowledge: _RecordingView
    session: Any = None


def _ctx(memory: _Memory) -> Ctx:
    async def _noop(_: Any = None) -> None:
        return None

    async def _stream(_: str) -> None:
        return None

    return Ctx(
        user_id="alice",
        session_id=None,
        channel="test",
        memory=memory,  # type: ignore[arg-type]
        reply=_noop,
        stream=_stream,
        finalize=_noop,
        http=None,  # type: ignore[arg-type]
        logger=logging.getLogger("test.builtin_tools"),
        tracer=None,
        state={},
    )


async def test_recall_returns_newline_bullets() -> None:
    user = _RecordingView()
    user.rows.extend(["alice likes ramen", "alice lives in Amsterdam", "irrelevant"])
    memory = _Memory(user=user, knowledge=_RecordingView())
    ctx = _ctx(memory)

    result = await recall(ctx, "alice")

    assert "- alice likes ramen" in result
    assert "- alice lives in Amsterdam" in result
    assert "- irrelevant" not in result


async def test_recall_empty_result_is_human_friendly() -> None:
    memory = _Memory(user=_RecordingView(), knowledge=_RecordingView())
    ctx = _ctx(memory)

    result = await recall(ctx, "nothing")

    assert "No user memory hits" in result


async def test_remember_adds_fact_then_recall_finds_it() -> None:
    memory = _Memory(user=_RecordingView(), knowledge=_RecordingView())
    ctx = _ctx(memory)

    confirm = await remember(ctx, "alice's dog is named Otto")
    assert "Stored in user memory" in confirm

    # bind ctx so `current_ctx()` works if an inner call uses it
    with bind_ctx(ctx):
        result = await recall(ctx, "otto")

    assert "- alice's dog is named Otto" in result


async def test_remember_routes_to_knowledge_when_requested() -> None:
    memory = _Memory(user=_RecordingView(), knowledge=_RecordingView())
    ctx = _ctx(memory)

    await remember(ctx, "water is wet", memory="knowledge")

    assert memory.user.rows == []
    assert memory.knowledge.rows == ["water is wet"]


async def test_remember_default_tier_is_long() -> None:
    memory = _Memory(user=_RecordingView(), knowledge=_RecordingView())
    ctx = _ctx(memory)

    await remember(ctx, "alice likes ramen")

    assert memory.user.tiers == ["long"]


async def test_remember_passes_tier_to_user_view() -> None:
    memory = _Memory(user=_RecordingView(), knowledge=_RecordingView())
    ctx = _ctx(memory)

    await remember(ctx, "pinned fact", tier="permanent")
    await remember(ctx, "tentative fact", tier="short")

    assert memory.user.tiers == ["permanent", "short"]


async def test_recall_respects_k_limit() -> None:
    user = _RecordingView()
    memory = _Memory(user=user, knowledge=_RecordingView())
    ctx = _ctx(memory)

    await recall(ctx, "q", k=3)

    assert user.search_calls == [("q", 3)]


async def test_decorators_produce_toolspecs() -> None:
    recall_spec = get_spec(recall)
    remember_spec = get_spec(remember)

    assert recall_spec.name == "recall"
    assert "query" in recall_spec.schema["properties"]
    assert recall_spec.schema["properties"]["memory"]["enum"] == ["user", "knowledge"]

    assert remember_spec.name == "remember"
    assert "text" in remember_spec.schema["properties"]


async def test_pick_view_rejects_unknown_memory() -> None:
    from zeno.builtin_tools import _pick_view

    memory = _Memory(user=_RecordingView(), knowledge=_RecordingView())
    ctx = _ctx(memory)

    with pytest.raises(ValueError, match="Unknown memory kind"):
        _pick_view(ctx, "ephemeral")  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Unit 12: MemoryRead / MemoryWrite emission
# ---------------------------------------------------------------------------


class _RecordingTracer:
    def __init__(self) -> None:
        self.events: list[Any] = []

    def on_event(self, event: Any) -> None:
        self.events.append(event)


def _ctx_with_tracer(memory: _Memory, tracer: Any) -> Ctx:
    base = _ctx(memory)
    return Ctx(
        user_id=base.user_id,
        session_id=base.session_id,
        channel=base.channel,
        memory=base.memory,
        reply=base.reply,
        stream=base.stream,
        finalize=base.finalize,
        http=base.http,
        logger=base.logger,
        tracer=tracer,
        state=base.state,
        thread_key=base.thread_key,
        secrets=base.secrets,
        turn_id="turn-fixed-1",
    )


async def test_recall_emits_memory_read_with_hashed_query() -> None:
    from zeno.observability.events import MemoryRead

    user = _RecordingView()
    user.rows.append("alice likes ramen")
    memory = _Memory(user=user, knowledge=_RecordingView())
    tracer = _RecordingTracer()
    ctx = _ctx_with_tracer(memory, tracer)

    await recall(ctx, "alice")

    reads = [e for e in tracer.events if isinstance(e, MemoryRead)]
    assert len(reads) == 1
    event = reads[0]
    assert event.store == "user_memory"
    assert event.result_count == 1
    assert event.envelope.turn_id == "turn-fixed-1"
    # Hash, not the raw query.
    assert event.query_hash != "alice"
    assert event.query_hash is not None
    assert len(event.query_hash) == 12


async def test_remember_emits_memory_write() -> None:
    from zeno.observability.events import MemoryWrite

    memory = _Memory(user=_RecordingView(), knowledge=_RecordingView())
    tracer = _RecordingTracer()
    ctx = _ctx_with_tracer(memory, tracer)

    await remember(ctx, "alice's dog is named Otto")

    writes = [e for e in tracer.events if isinstance(e, MemoryWrite)]
    assert len(writes) == 1
    assert writes[0].store == "user_memory"
    assert writes[0].envelope.turn_id == "turn-fixed-1"


async def test_remember_knowledge_uses_knowledge_store_name() -> None:
    from zeno.observability.events import MemoryWrite

    memory = _Memory(user=_RecordingView(), knowledge=_RecordingView())
    tracer = _RecordingTracer()
    ctx = _ctx_with_tracer(memory, tracer)

    await remember(ctx, "water is wet", memory="knowledge")

    writes = [e for e in tracer.events if isinstance(e, MemoryWrite)]
    assert len(writes) == 1
    assert writes[0].store == "knowledge"


async def test_no_emission_when_memory_is_noop() -> None:
    from zeno.observability.events import MemoryRead, MemoryWrite
    from zeno.runtime.noop_memory import NoOpMemoryView

    tracer = _RecordingTracer()
    base = _ctx(_Memory(user=_RecordingView(), knowledge=_RecordingView()))
    ctx = Ctx(
        user_id=base.user_id,
        session_id=base.session_id,
        channel=base.channel,
        memory=NoOpMemoryView(),
        reply=base.reply,
        stream=base.stream,
        finalize=base.finalize,
        http=base.http,
        logger=base.logger,
        tracer=tracer,
        state=base.state,
        thread_key=base.thread_key,
        secrets=base.secrets,
    )

    await recall(ctx, "anything")
    await remember(ctx, "fact")

    assert not any(isinstance(e, MemoryRead | MemoryWrite) for e in tracer.events)


async def test_no_emission_when_tracer_is_none() -> None:
    memory = _Memory(user=_RecordingView(), knowledge=_RecordingView())
    ctx = _ctx(memory)  # tracer=None

    # Must not raise.
    await recall(ctx, "anything")
    await remember(ctx, "fact")
