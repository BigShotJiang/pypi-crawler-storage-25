"""Tests for the new `metadata` field on `IncomingMessage` (U0)."""

from __future__ import annotations

from dataclasses import FrozenInstanceError
from datetime import datetime

import pytest
from zeno.channels.messages import IncomingMessage


def _msg(**kwargs: object) -> IncomingMessage:
    defaults: dict[str, object] = {
        "user_id": "alice",
        "text": "hi",
        "received_at": datetime(2026, 4, 23, 12, 0, 0),
    }
    defaults.update(kwargs)
    return IncomingMessage(**defaults)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


def test_metadata_defaults_to_empty_dict() -> None:
    msg = _msg()
    assert msg.metadata == {}


def test_metadata_survives_round_trip() -> None:
    payload = {"scheduler": {"trigger_id": "t1", "fire_count": 3}}
    msg = _msg(metadata=payload)
    assert msg.metadata["scheduler"]["trigger_id"] == "t1"
    assert msg.metadata["scheduler"]["fire_count"] == 3


def test_metadata_with_various_value_types() -> None:
    payload: dict[str, object] = {
        "int_val": 42,
        "bool_val": True,
        "list_val": [1, 2, 3],
        "none_val": None,
    }
    msg = _msg(metadata=payload)
    assert msg.metadata["int_val"] == 42
    assert msg.metadata["bool_val"] is True
    assert msg.metadata["list_val"] == [1, 2, 3]
    assert msg.metadata["none_val"] is None


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


def test_incoming_message_is_frozen_field_reassignment_raises() -> None:
    """The dataclass is frozen — direct field assignment must raise."""
    msg = _msg()
    with pytest.raises(FrozenInstanceError):
        msg.metadata = {"new": "value"}  # type: ignore[misc]


def test_metadata_dict_contents_are_mutable() -> None:
    """Although the field reference is immutable, the dict contents can be mutated.

    This is consistent with `Ctx.state` semantics: the frozen dataclass freezes
    the reference, not the object pointed to.
    """
    inner: dict[str, object] = {"key": "original"}
    msg = _msg(metadata=inner)
    # Mutate through the original reference — the mutation is visible via msg.
    inner["key"] = "mutated"
    assert msg.metadata["key"] == "mutated"
    # Mutate through msg.metadata directly.
    msg.metadata["extra"] = "added"  # type: ignore[index]
    assert msg.metadata["extra"] == "added"


def test_other_fields_unaffected_by_metadata_addition() -> None:
    """Existing fields like `raw` and `thread_key` continue to work normally."""
    msg = _msg(raw={"channel_specific": True}, thread_key="thread-1")
    assert msg.raw == {"channel_specific": True}
    assert msg.thread_key == "thread-1"
    assert msg.metadata == {}
