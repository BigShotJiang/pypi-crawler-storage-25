"""IU4 tests: `ZenoApp` provider wiring + capability check + default handler.

Covers the plan's Test scenarios for IU4:
    - `ConfigurationError` when `provider=` is missing
    - Capability check passes for a full-true provider + complex Agent
    - Capability check collects every miss (built_in_tools, sub_agents,
      permission_mode, multiple misses, transitive sub-agent built_in_tools)
    - Plugin-discovered sub-agent participates in the capability check (G7)
    - Provider lifecycle: `start()` before messages pump, `stop()` after shutdown
    - Default handler composes system prompt into `ctx.state["composed_prompt"]`
    - `ctx.state` is per-turn scoped (distinct across turns)
    - `session_lookup=` kwarg is removed
    - Per-turn `turn_timeout` cancels wedged providers
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import datetime
from importlib.metadata import EntryPoint
from typing import Any

import pytest
from zeno.agent import Agent, SubAgent
from zeno.app import ZenoApp, _check_capabilities
from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Capabilities as ChannelCapabilities
from zeno.context import Ctx
from zeno.exceptions import ConfigurationError, ProviderCapabilityError
from zeno.testing import FakeProvider


@dataclass
class _FakeChannel:
    name: str = "cli"
    supports_streaming: bool = False
    inbox: asyncio.Queue[IncomingMessage] = field(default_factory=asyncio.Queue)
    sent: list[OutgoingMessage] = field(default_factory=list)
    started: bool = False
    stopped: bool = False
    started_event: asyncio.Event = field(default_factory=asyncio.Event)
    sent_event: asyncio.Event = field(default_factory=asyncio.Event)

    @property
    def capabilities(self) -> ChannelCapabilities:
        return ChannelCapabilities(supports_streaming=self.supports_streaming)

    async def start(self) -> None:
        self.started = True
        self.started_event.set()

    async def stop(self) -> None:
        self.stopped = True

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        while True:
            msg = await self.inbox.get()
            yield msg

    async def send(self, msg: Any) -> None:
        self.sent.append(msg)
        self.sent_event.set()

    async def wait_for_sent(self, n: int = 1, *, timeout: float = 3.0) -> None:
        async def _wait() -> None:
            while len(self.sent) < n:
                self.sent_event.clear()
                await self.sent_event.wait()

        await asyncio.wait_for(_wait(), timeout=timeout)


def _msg(user_id: str, text: str) -> IncomingMessage:
    return IncomingMessage(user_id=user_id, text=text, received_at=datetime(2026, 4, 22, 12, 0, 0))


# ---------------------------------------------------------------------------
# Constructor gate
# ---------------------------------------------------------------------------


def test_missing_provider_raises_configuration_error(fake_ctx: Ctx) -> None:
    with pytest.raises(ConfigurationError, match="provider="):
        ZenoApp(
            agent=Agent(name="root", instructions="noop"),
            memory=fake_ctx.memory,
            channels=[],
        )


def test_session_lookup_kwarg_removed(fake_ctx: Ctx) -> None:
    with pytest.raises(TypeError, match="session_lookup"):
        ZenoApp(  # type: ignore[call-arg]
            agent=Agent(name="root", instructions="noop"),
            memory=fake_ctx.memory,
            channels=[],
            provider=FakeProvider(),
            session_lookup=lambda *_args, **_kwargs: None,
        )


def test_agent_handler_kwarg_removed(fake_ctx: Ctx) -> None:
    async def handler(_ctx: Ctx, _msg: IncomingMessage) -> None:
        return None

    with pytest.raises(TypeError, match="agent_handler"):
        ZenoApp(  # type: ignore[call-arg]
            agent=Agent(name="root", instructions="noop"),
            memory=fake_ctx.memory,
            channels=[],
            provider=FakeProvider(),
            agent_handler=handler,
        )


# ---------------------------------------------------------------------------
# Capability check
# ---------------------------------------------------------------------------


async def test_start_succeeds_for_full_capability_match(fake_ctx: Ctx) -> None:
    sub = SubAgent(name="web", instructions="noop", built_in_tools=["WebFetch"])
    agent = Agent(
        name="root",
        instructions="noop",
        built_in_tools=["WebSearch"],
        sub_agents=[sub],
        permission_mode="bypassPermissions",
    )
    provider = FakeProvider()
    app = ZenoApp(
        agent=agent,
        memory=fake_ctx.memory,
        channels=[],
        provider=provider,
        http_client=fake_ctx.http,
    )
    await app.start()
    assert provider.start_calls == 1


async def test_start_is_idempotent(fake_ctx: Ctx) -> None:
    provider = FakeProvider()
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[],
        provider=provider,
        http_client=fake_ctx.http,
    )
    await app.start()
    await app.start()
    assert provider.start_calls == 1


def test_capability_error_missing_built_in_tools(fake_ctx: Ctx) -> None:
    agent = Agent(name="root", instructions="noop", built_in_tools=["WebSearch"])
    provider = FakeProvider(supports_built_in_tools=False)
    with pytest.raises(ProviderCapabilityError) as excinfo:
        _check_capabilities(agent, provider)
    assert "built_in_tools=['WebSearch']" in str(excinfo.value)
    assert excinfo.value.provider == "FakeProvider"


def test_capability_error_missing_sub_agents(fake_ctx: Ctx) -> None:
    agent = Agent(
        name="root",
        instructions="noop",
        sub_agents=[SubAgent(name="spec", instructions="noop")],
    )
    provider = FakeProvider(supports_sub_agents=False)
    with pytest.raises(ProviderCapabilityError) as excinfo:
        _check_capabilities(agent, provider)
    assert "sub_agents=[spec]" in str(excinfo.value)


def test_capability_error_missing_permission_mode(fake_ctx: Ctx) -> None:
    agent = Agent(name="root", instructions="noop", permission_mode="bypassPermissions")
    provider = FakeProvider(supports_permission_mode=False)
    with pytest.raises(ProviderCapabilityError) as excinfo:
        _check_capabilities(agent, provider)
    assert "permission_mode='bypassPermissions'" in str(excinfo.value)


def test_capability_error_multiple_missing_listed_together(fake_ctx: Ctx) -> None:
    agent = Agent(
        name="root",
        instructions="noop",
        built_in_tools=["WebSearch"],
        sub_agents=[SubAgent(name="spec", instructions="noop")],
        permission_mode="bypassPermissions",
    )
    provider = FakeProvider(
        supports_built_in_tools=False,
        supports_sub_agents=False,
        supports_permission_mode=False,
    )
    with pytest.raises(ProviderCapabilityError) as excinfo:
        _check_capabilities(agent, provider)
    message = str(excinfo.value)
    assert "built_in_tools=['WebSearch']" in message
    assert "sub_agents=[spec]" in message
    assert "permission_mode='bypassPermissions'" in message


def test_capability_error_sub_agent_transitive_built_in_tools(fake_ctx: Ctx) -> None:
    sub = SubAgent(name="web", instructions="noop", built_in_tools=["WebFetch"])
    agent = Agent(name="root", instructions="noop", sub_agents=[sub])
    provider = FakeProvider(supports_built_in_tools=False)
    with pytest.raises(ProviderCapabilityError) as excinfo:
        _check_capabilities(agent, provider)
    message = str(excinfo.value)
    assert "sub_agent 'web'" in message
    assert "['WebFetch']" in message


async def test_plugin_sub_agent_triggers_capability_error_at_start(
    monkeypatch: pytest.MonkeyPatch, fake_ctx: Ctx
) -> None:
    plugin_sub = SubAgent(name="plug", instructions="noop", built_in_tools=["WebSearch"])

    class _StubDist:
        name = "fake-dist"

    fake_ep = EntryPoint(name="plug", value="module:plug", group="zeno.sub_agents")
    object.__setattr__(fake_ep, "dist", _StubDist())

    def _fake_discover(_groups: Any) -> dict[str, dict[str, EntryPoint]]:
        return {"zeno.sub_agents": {"plug": fake_ep}}

    def _fake_load(self: EntryPoint) -> SubAgent:
        return plugin_sub

    monkeypatch.setattr("zeno.app.discover_all", _fake_discover)
    monkeypatch.setattr(EntryPoint, "load", _fake_load)

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[],
        provider=FakeProvider(supports_built_in_tools=False),
        http_client=fake_ctx.http,
    )
    with pytest.raises(ProviderCapabilityError) as excinfo:
        await app.start()
    assert "sub_agent 'plug'" in str(excinfo.value)


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


async def test_provider_start_before_pump_stop_after_shutdown(fake_ctx: Ctx) -> None:
    """Integration: `start()` runs before channels pump, `stop()` after shutdown."""
    provider = FakeProvider()
    channel = _FakeChannel()
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[channel],
        provider=provider,
        http_client=fake_ctx.http,
    )
    run_task = asyncio.create_task(app.run())

    await asyncio.wait_for(channel.started_event.wait(), timeout=3.0)
    assert provider.start_calls == 1
    assert provider.stop_calls == 0

    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=2.0)

    assert provider.stop_calls == 1


# ---------------------------------------------------------------------------
# Default handler behaviour
# ---------------------------------------------------------------------------


async def test_default_handler_writes_composed_prompt_to_ctx_state(fake_ctx: Ctx) -> None:
    recorded: list[str | None] = []

    async def on_turn(agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        recorded.append(ctx.state.get("composed_prompt"))
        await ctx.reply(OutgoingMessage(text="ok"))

    agent = Agent(name="root", instructions="BASE INSTR")
    provider = FakeProvider(on_turn=on_turn)
    channel = _FakeChannel()
    app = ZenoApp(
        agent=agent,
        memory=fake_ctx.memory,
        channels=[channel],
        provider=provider,
        http_client=fake_ctx.http,
    )
    run_task = asyncio.create_task(app.run())
    await channel.inbox.put(_msg("alice", "hello"))
    await channel.wait_for_sent(1)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=2.0)

    assert recorded == ["BASE INSTR"]


async def test_ctx_state_per_turn_scope(fake_ctx: Ctx) -> None:
    """KD7 invariant: each turn receives a fresh `ctx.state` dict."""
    observed_ids: list[int] = []

    async def on_turn(agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        observed_ids.append(id(ctx.state))
        await ctx.reply(OutgoingMessage(text="ok"))

    channel = _FakeChannel()
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[channel],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
    )
    run_task = asyncio.create_task(app.run())
    await channel.inbox.put(_msg("alice", "one"))
    await channel.inbox.put(_msg("alice", "two"))
    await channel.wait_for_sent(2)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=2.0)

    assert len(observed_ids) == 2
    assert observed_ids[0] != observed_ids[1]


async def test_turn_timeout_fires_on_hanging_provider(fake_ctx: Ctx) -> None:
    timeouts: list[BaseException] = []
    timeout_seen = asyncio.Event()

    async def on_turn_error(ctx: Ctx, msg: IncomingMessage, exc: BaseException) -> None:
        timeouts.append(exc)
        timeout_seen.set()

    async def slow(agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        await asyncio.sleep(5.0)

    channel = _FakeChannel()
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[channel],
        provider=FakeProvider(on_turn=slow),
        http_client=fake_ctx.http,
        turn_timeout=0.05,
        on_turn_error=on_turn_error,
    )
    run_task = asyncio.create_task(app.run())
    await channel.inbox.put(_msg("alice", "hang"))
    await asyncio.wait_for(timeout_seen.wait(), timeout=3.0)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=2.0)

    assert len(timeouts) == 1
    assert isinstance(timeouts[0], (asyncio.TimeoutError, TimeoutError))
