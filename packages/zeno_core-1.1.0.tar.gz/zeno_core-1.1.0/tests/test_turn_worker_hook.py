"""Tests for the `on_turn_complete` hook on `TurnDispatcher`.

The hook lets a memory-extraction (or analytics, or audit) layer plug
into the turn lifecycle without bloating the worker. These tests cover:
- Fires only on handler success.
- Receives the buffered assistant text *after* finalize.
- Runs fire-and-forget without blocking the user-facing reply.
- `drain_all()` waits for in-flight hooks at shutdown.
- Timeouts and errors are isolated -- never propagate.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from unittest.mock import MagicMock

import httpx
import pytest
from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Capabilities
from zeno.context import Ctx
from zeno.runtime.turn_worker import TurnDispatcher


@dataclass
class _Ch:
    supports_streaming: bool = False
    name: str = "fake"
    sent: list[OutgoingMessage] = field(default_factory=list)

    @property
    def capabilities(self) -> Capabilities:
        return Capabilities(supports_streaming=self.supports_streaming)

    async def start(self) -> None: ...

    async def stop(self) -> None: ...

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        if False:
            yield  # pragma: no cover
        return

    async def send(self, msg: Any) -> None:
        self.sent.append(msg)


def _msg(thread: str | None = None, text: str = "hi") -> IncomingMessage:
    return IncomingMessage(
        user_id="alice",
        text=text,
        received_at=datetime(2026, 4, 19, 10, 0, 0),
        thread_key=thread,
    )


def _ctx_factory(memory: Any, http: httpx.AsyncClient) -> Any:
    async def _ph(*_a: Any, **_k: Any) -> None: ...

    async def _ph_stream(_c: str) -> None: ...

    async def _ph_finalize() -> None: ...

    def _factory(channel: Any, msg: IncomingMessage) -> Ctx:
        return Ctx(
            user_id=msg.user_id,
            session_id="sess-1",
            channel=channel.name,
            memory=memory,
            reply=_ph,
            stream=_ph_stream,
            finalize=_ph_finalize,
            http=http,
            logger=MagicMock(),
            tracer=MagicMock(),
        )

    return _factory


async def test_hook_fires_with_buffered_text_after_success(fake_ctx: Ctx) -> None:
    captured: list[tuple[str, str, str]] = []

    async def hook(ctx: Ctx, msg: IncomingMessage, text: str) -> None:
        captured.append((ctx.user_id, msg.text, text))

    async def handler(ctx: Ctx, _msg: IncomingMessage) -> None:
        await ctx.stream("hel")
        await ctx.stream("lo")
        await ctx.finalize()

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
        on_turn_complete=hook,
    )
    await d.enqueue(_Ch(supports_streaming=True), _msg(text="who am i"))
    await d.drain_all()

    assert captured == [("alice", "who am i", "hello")]


async def test_hook_skipped_when_handler_raises(fake_ctx: Ctx) -> None:
    fired = False

    async def hook(_ctx: Ctx, _msg: IncomingMessage, _text: str) -> None:
        nonlocal fired
        fired = True

    async def handler(_ctx: Ctx, _msg: IncomingMessage) -> None:
        raise RuntimeError("boom")

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
        on_turn_complete=hook,
    )
    await d.enqueue(_Ch(), _msg())
    await d.drain_all()
    assert fired is False


async def test_hook_does_not_block_reply(fake_ctx: Ctx) -> None:
    """The reply must land before the (slow) hook completes."""
    hook_done = asyncio.Event()
    reply_observed_at: list[float] = []
    hook_finished_at: list[float] = []

    async def hook(_ctx: Ctx, _msg: IncomingMessage, _text: str) -> None:
        await asyncio.sleep(0.05)
        hook_finished_at.append(asyncio.get_event_loop().time())
        hook_done.set()

    async def handler(ctx: Ctx, _msg: IncomingMessage) -> None:
        await ctx.stream("done")
        await ctx.finalize()

    ch = _Ch(supports_streaming=True)
    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
        on_turn_complete=hook,
    )
    await d.enqueue(ch, _msg())

    # Wait for the worker to drain the queue (i.e. the reply has been sent).
    await asyncio.wait_for(asyncio.create_task(_wait_until_sent(ch)), timeout=1.0)
    reply_observed_at.append(asyncio.get_event_loop().time())

    # The hook should still be running -- the reply did not wait for it.
    assert not hook_done.is_set()

    await d.drain_all()
    assert hook_done.is_set()
    assert hook_finished_at[0] > reply_observed_at[0]


async def _wait_until_sent(ch: _Ch) -> None:
    while not ch.sent:
        await asyncio.sleep(0.001)


async def test_drain_all_waits_for_in_flight_hooks(fake_ctx: Ctx) -> None:
    completed = asyncio.Event()

    async def hook(_ctx: Ctx, _msg: IncomingMessage, _text: str) -> None:
        await asyncio.sleep(0.02)
        completed.set()

    async def handler(ctx: Ctx, _msg: IncomingMessage) -> None:
        await ctx.stream("ok")
        await ctx.finalize()

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
        on_turn_complete=hook,
    )
    await d.enqueue(_Ch(), _msg())
    await d.drain_all()
    assert completed.is_set(), "drain_all returned before the hook finished"


async def test_hook_exception_does_not_break_turn(fake_ctx: Ctx) -> None:
    async def hook(_ctx: Ctx, _msg: IncomingMessage, _text: str) -> None:
        raise RuntimeError("hook failed")

    async def handler(ctx: Ctx, _msg: IncomingMessage) -> None:
        await ctx.stream("ok")
        await ctx.finalize()

    ch = _Ch()
    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
        on_turn_complete=hook,
    )
    await d.enqueue(ch, _msg())
    # Must not raise at drain time even though the hook raised.
    await d.drain_all()
    assert ch.sent[0].text == "ok"


async def test_hook_timeout_logs_warning_and_returns(fake_ctx: Ctx) -> None:
    """A wedged hook should be cancelled at the configured timeout, never
    blocking shutdown forever."""
    started = asyncio.Event()

    async def hook(_ctx: Ctx, _msg: IncomingMessage, _text: str) -> None:
        started.set()
        await asyncio.sleep(10)  # would hang forever if timeout broken

    async def handler(ctx: Ctx, _msg: IncomingMessage) -> None:
        await ctx.stream("ok")
        await ctx.finalize()

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
        on_turn_complete=hook,
        on_turn_complete_timeout=0.05,
    )
    await d.enqueue(_Ch(), _msg())
    # If the timeout is broken this raises asyncio.TimeoutError on the test.
    await asyncio.wait_for(d.drain_all(), timeout=2.0)
    assert started.is_set()


async def test_no_hook_configured_runs_normally(fake_ctx: Ctx) -> None:
    async def handler(ctx: Ctx, _msg: IncomingMessage) -> None:
        await ctx.stream("ok")
        await ctx.finalize()

    ch = _Ch()
    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
    )
    await d.enqueue(ch, _msg())
    await d.drain_all()
    assert ch.sent[0].text == "ok"


async def test_hook_receives_text_even_when_handler_forgets_finalize(
    fake_ctx: Ctx,
) -> None:
    """The auto-finalize path must run before the hook fires so the buffer is sealed."""
    captured: list[str] = []

    async def hook(_ctx: Ctx, _msg: IncomingMessage, text: str) -> None:
        captured.append(text)

    async def handler(ctx: Ctx, _msg: IncomingMessage) -> None:
        await ctx.stream("first ")
        await ctx.stream("second")
        # No finalize() -- worker should auto-finalize.

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
        on_turn_complete=hook,
    )
    await d.enqueue(_Ch(), _msg())
    await d.drain_all()
    assert captured == ["first second"]


@pytest.mark.parametrize("handler_text", ["", "  "])
async def test_hook_fires_even_with_empty_assistant_text(fake_ctx: Ctx, handler_text: str) -> None:
    """The dispatcher does not gate on text -- callers (e.g. MemoryExtractor)
    decide whether to skip. The hook still fires so analytics get a signal."""
    captured: list[str] = []

    async def hook(_ctx: Ctx, _msg: IncomingMessage, text: str) -> None:
        captured.append(text)

    async def handler(ctx: Ctx, _msg: IncomingMessage) -> None:
        if handler_text:
            await ctx.stream(handler_text)
        await ctx.finalize()

    d = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=_ctx_factory(fake_ctx.memory, fake_ctx.http),
        on_turn_complete=hook,
    )
    await d.enqueue(_Ch(), _msg())
    await d.drain_all()
    assert captured == [handler_text]
