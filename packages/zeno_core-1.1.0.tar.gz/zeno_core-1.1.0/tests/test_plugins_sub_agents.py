"""Tests for `zeno.sub_agents` entry-point discovery wired into `ZenoApp`."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from zeno.agent import Agent, SubAgent
from zeno.app import ZenoApp
from zeno.context import Ctx
from zeno.exceptions import EntryPointCollisionError, ZenoError
from zeno.plugins.groups import ZENO_SUB_AGENTS
from zeno.testing import FakeProvider


def _make_ep(name: str, value: str, dist_name: str, loaded: Any) -> Any:
    ep = MagicMock()
    ep.name = name
    ep.value = value
    ep.group = ZENO_SUB_AGENTS
    ep.load.return_value = loaded
    dist = MagicMock()
    dist.name = dist_name
    ep.dist = dist
    return ep


def _fake_entry_points_factory(by_group: dict[str, list[Any]]) -> Any:
    def _fake(*, group: str) -> list[Any]:
        return by_group.get(group, [])

    return _fake


def test_happy_path_entry_point_sub_agent_merged_into_agent(fake_ctx: Ctx) -> None:
    helper = SubAgent(name="helper", instructions="Help.")
    ep = _make_ep("helper", "pkg.mod:helper", "zeno-subagent-helper", helper)
    eps_by_group = {ZENO_SUB_AGENTS: [ep]}

    with patch(
        "zeno.plugins.discovery.entry_points",
        side_effect=_fake_entry_points_factory(eps_by_group),
    ):
        app = ZenoApp(
            agent=Agent(name="root", instructions="i"),
            memory=fake_ctx.memory,
            channels=[],
            provider=FakeProvider(),
            http_client=fake_ctx.http,
        )

    names = [sa.name for sa in app.agent.sub_agents]
    assert names == ["helper"]


def test_native_and_plugin_sub_agents_coexist(fake_ctx: Ctx) -> None:
    native = SubAgent(name="researcher", instructions="Research.")
    plugin = SubAgent(name="helper", instructions="Help.")
    ep = _make_ep("helper", "pkg.mod:helper", "zeno-subagent-helper", plugin)

    with patch(
        "zeno.plugins.discovery.entry_points",
        side_effect=_fake_entry_points_factory({ZENO_SUB_AGENTS: [ep]}),
    ):
        app = ZenoApp(
            agent=Agent(name="root", instructions="i", sub_agents=[native]),
            memory=fake_ctx.memory,
            channels=[],
            provider=FakeProvider(),
            http_client=fake_ctx.http,
        )

    names = [sa.name for sa in app.agent.sub_agents]
    assert names == ["researcher", "helper"]


def test_no_entry_points_leaves_agent_unchanged(fake_ctx: Ctx) -> None:
    native = SubAgent(name="researcher", instructions="Research.")
    original = Agent(name="root", instructions="i", sub_agents=[native])

    with patch(
        "zeno.plugins.discovery.entry_points",
        side_effect=_fake_entry_points_factory({}),
    ):
        app = ZenoApp(
            agent=original,
            memory=fake_ctx.memory,
            channels=[],
            provider=FakeProvider(),
            http_client=fake_ctx.http,
        )

    # Identity preserved when nothing to merge — no pointless replace().
    assert app.agent is original


def test_entry_point_loading_non_sub_agent_raises(fake_ctx: Ctx) -> None:
    ep = _make_ep("helper", "pkg.mod:thing", "zeno-subagent-helper", "not a SubAgent")

    with (
        patch(
            "zeno.plugins.discovery.entry_points",
            side_effect=_fake_entry_points_factory({ZENO_SUB_AGENTS: [ep]}),
        ),
        pytest.raises(ZenoError) as exc_info,
    ):
        ZenoApp(
            agent=Agent(name="root", instructions="i"),
            memory=fake_ctx.memory,
            channels=[],
            provider=FakeProvider(),
            http_client=fake_ctx.http,
        )

    msg = str(exc_info.value)
    assert "helper" in msg
    assert "zeno-subagent-helper" in msg
    assert "pkg.mod:thing" in msg
    assert "SubAgent" in msg


def test_entry_point_name_mismatch_raises(fake_ctx: Ctx) -> None:
    loaded = SubAgent(name="internal-name", instructions="Help.")
    ep = _make_ep("helper", "pkg.mod:helper", "zeno-subagent-helper", loaded)

    with (
        patch(
            "zeno.plugins.discovery.entry_points",
            side_effect=_fake_entry_points_factory({ZENO_SUB_AGENTS: [ep]}),
        ),
        pytest.raises(ZenoError) as exc_info,
    ):
        ZenoApp(
            agent=Agent(name="root", instructions="i"),
            memory=fake_ctx.memory,
            channels=[],
            provider=FakeProvider(),
            http_client=fake_ctx.http,
        )

    msg = str(exc_info.value)
    assert "helper" in msg
    assert "internal-name" in msg


def test_entry_point_name_colliding_with_native_raises(fake_ctx: Ctx) -> None:
    native = SubAgent(name="helper", instructions="Native helper.")
    plugin = SubAgent(name="helper", instructions="Plugin helper.")
    ep = _make_ep("helper", "pkg.mod:helper", "zeno-subagent-helper", plugin)

    with (
        patch(
            "zeno.plugins.discovery.entry_points",
            side_effect=_fake_entry_points_factory({ZENO_SUB_AGENTS: [ep]}),
        ),
        pytest.raises(EntryPointCollisionError) as exc_info,
    ):
        ZenoApp(
            agent=Agent(name="root", instructions="i", sub_agents=[native]),
            memory=fake_ctx.memory,
            channels=[],
            provider=FakeProvider(),
            http_client=fake_ctx.http,
        )

    err = exc_info.value
    assert err.group == ZENO_SUB_AGENTS
    assert err.name == "helper"
    assert "<python-native>" in err.dists
    assert "zeno-subagent-helper" in err.dists
