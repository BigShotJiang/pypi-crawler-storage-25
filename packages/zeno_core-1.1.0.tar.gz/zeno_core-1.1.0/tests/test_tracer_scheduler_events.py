"""Tests for the 5 new scheduler TraceEvent variants (U0, C3)."""

from __future__ import annotations

import io
import json

import pytest
from zeno.observability.events import (
    SchedulerFireConsumed,
    SchedulerFireErrored,
    SchedulerFireQueued,
    TriggerCancelled,
    TriggerDropped,
    _Envelope,
    event_payload,
)
from zeno.observability.tracer import NoOpTracer, StdoutTracer

_SchedulerEvent = (
    SchedulerFireQueued
    | SchedulerFireConsumed
    | SchedulerFireErrored
    | TriggerCancelled
    | TriggerDropped
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _queued(trigger_id: str = "t1", fire_count: int = 1) -> SchedulerFireQueued:
    return SchedulerFireQueued(
        trigger_id=trigger_id,
        trigger_kind="cron",
        user_id="alice",
        fire_count=fire_count,
    )


def _consumed(trigger_id: str = "t1", fire_count: int = 1) -> SchedulerFireConsumed:
    return SchedulerFireConsumed(
        trigger_id=trigger_id,
        trigger_kind="cron",
        user_id="alice",
        fire_count=fire_count,
    )


def _errored(trigger_id: str = "t1", fire_count: int = 1) -> SchedulerFireErrored:
    return SchedulerFireErrored(
        trigger_id=trigger_id,
        trigger_kind="cron",
        user_id="alice",
        fire_count=fire_count,
        error="TimeoutError: turn exceeded 120s",
    )


def _cancelled(trigger_id: str = "t1", fire_count: int = 2) -> TriggerCancelled:
    return TriggerCancelled(
        trigger_id=trigger_id,
        trigger_kind="heartbeat",
        user_id="bob",
        fire_count=fire_count,
    )


def _dropped(trigger_id: str = "t1", fire_count: int = 5) -> TriggerDropped:
    return TriggerDropped(
        trigger_id=trigger_id,
        trigger_kind="schedule_once",
        user_id="carol",
        fire_count=fire_count,
        reason="queue_full",
    )


# ---------------------------------------------------------------------------
# C3: synthesized _Envelope
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "event,expected_turn_id,expected_seq",
    [
        (_queued("abc", 3), "trigger:abc", 3),
        (_consumed("xyz", 7), "trigger:xyz", 7),
        (_errored("err-id", 0), "trigger:err-id", 0),
        (_cancelled("can-id", 2), "trigger:can-id", 2),
        (_dropped("drp-id", 5), "trigger:drp-id", 5),
    ],
)
def test_synthesized_envelope_turn_id_and_sequence(
    event: _SchedulerEvent,
    expected_turn_id: str,
    expected_seq: int,
) -> None:
    assert isinstance(event.envelope, _Envelope)
    assert event.envelope.turn_id == expected_turn_id
    assert event.envelope.sequence == expected_seq


def test_synthesized_envelope_carries_user_id() -> None:
    ev = _queued()
    assert ev.envelope.user_id == "alice"


def test_synthesized_envelope_session_id_is_none() -> None:
    """Scheduler-synthesized envelopes have no session_id."""
    ev = _queued()
    assert ev.envelope.session_id is None


# ---------------------------------------------------------------------------
# event_payload: dict serialization + JSON round-trip
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "event,expected_kind",
    [
        (_queued(), "scheduler_fire_queued"),
        (_consumed(), "scheduler_fire_consumed"),
        (_errored(), "scheduler_fire_errored"),
        (_cancelled(), "trigger_cancelled"),
        (_dropped(), "trigger_dropped"),
    ],
)
def test_event_payload_returns_dict_without_raising(
    event: _SchedulerEvent, expected_kind: str
) -> None:
    payload = event_payload(event)
    assert isinstance(payload, dict)
    assert payload["kind"] == expected_kind


@pytest.mark.parametrize(
    "event",
    [_queued(), _consumed(), _errored(), _cancelled(), _dropped()],
)
def test_event_payload_json_round_trip(event: _SchedulerEvent) -> None:
    payload = event_payload(event)
    serialized = json.dumps(payload)
    recovered = json.loads(serialized)
    assert recovered["turn_id"] == payload["turn_id"]
    assert recovered["sequence"] == payload["sequence"]
    assert recovered["kind"] == payload["kind"]


def test_event_payload_scheduler_fire_queued_fields() -> None:
    ev = _queued("fire-1", 4)
    p = event_payload(ev)
    assert p["trigger_id"] == "fire-1"
    assert p["trigger_kind"] == "cron"
    assert p["user_id"] == "alice"
    assert p["fire_count"] == 4
    assert p["turn_id"] == "trigger:fire-1"
    assert p["sequence"] == 4
    assert "emitted_at" in p


def test_event_payload_scheduler_fire_errored_includes_error_field() -> None:
    ev = _errored()
    p = event_payload(ev)
    assert "error" in p
    assert "TimeoutError" in p["error"]


def test_event_payload_trigger_dropped_includes_reason_field() -> None:
    ev = _dropped()
    p = event_payload(ev)
    assert p["reason"] == "queue_full"


# ---------------------------------------------------------------------------
# Integration: Tracer.emit picks up new events
# ---------------------------------------------------------------------------


def test_noop_tracer_accepts_all_scheduler_events() -> None:
    tracer = NoOpTracer()
    events: list[_SchedulerEvent] = [_queued(), _consumed(), _errored(), _cancelled(), _dropped()]
    for ev in events:
        tracer.on_event(ev)


def test_stdout_tracer_emits_scheduler_events_as_json_lines() -> None:
    buf = io.StringIO()
    tracer = StdoutTracer(stream=buf)
    tracer.on_event(_queued("t9", 1))
    tracer.on_event(_errored("t9", 2))

    lines = [ln for ln in buf.getvalue().splitlines() if ln]
    assert len(lines) == 2
    r0 = json.loads(lines[0])
    assert r0["kind"] == "scheduler_fire_queued"
    assert r0["trigger_id"] == "t9"
    r1 = json.loads(lines[1])
    assert r1["kind"] == "scheduler_fire_errored"
    assert "error" in r1


# ---------------------------------------------------------------------------
# Frozen: event variants are immutable
# ---------------------------------------------------------------------------


def test_scheduler_fire_queued_is_frozen() -> None:
    from dataclasses import FrozenInstanceError

    ev = _queued()
    with pytest.raises(FrozenInstanceError):
        ev.trigger_id = "mutated"  # type: ignore[misc]
