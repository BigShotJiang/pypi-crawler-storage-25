"""Tests for the `WorkingMemoryUpdated` TraceEvent (R10)."""

from __future__ import annotations

import io
import json
import logging
from dataclasses import FrozenInstanceError, dataclass, field
from typing import Any

import pytest
from pydantic import BaseModel
from zeno.builtin_tools import make_update_working_memory_tool
from zeno.context import Ctx
from zeno.observability.events import WorkingMemoryUpdated, _Envelope, event_payload
from zeno.observability.tracer import NoOpTracer, StdoutTracer


def _envelope() -> _Envelope:
    return _Envelope(
        turn_id="turn-1",
        sequence=0,
        user_id="alice",
        session_id="sess-1",
    )


def _event(fields: tuple[str, ...] = ("name", "role")) -> WorkingMemoryUpdated:
    return WorkingMemoryUpdated(
        envelope=_envelope(),
        agent_id="root",
        fields_updated=fields,
    )


# ---------------------------------------------------------------------------
# Construction + payload shape
# ---------------------------------------------------------------------------


def test_event_kind() -> None:
    assert _event().kind == "working_memory_updated"


def test_event_payload_carries_fields() -> None:
    p = event_payload(_event())
    assert p["kind"] == "working_memory_updated"
    assert p["turn_id"] == "turn-1"
    assert p["agent_id"] == "root"
    assert p["fields_updated"] == ("name", "role")
    assert p["user_id"] == "alice"


def test_event_payload_json_round_trip() -> None:
    p = event_payload(_event(("name",)))
    p["fields_updated"] = list(p["fields_updated"])
    s = json.dumps(p)
    recovered = json.loads(s)
    assert recovered["kind"] == "working_memory_updated"
    assert recovered["fields_updated"] == ["name"]


def test_event_accepts_empty_fields_tuple() -> None:
    """Well-formed even though the tool body never emits one."""
    ev = _event(())
    assert ev.fields_updated == ()


def test_event_is_frozen() -> None:
    ev = _event()
    with pytest.raises(FrozenInstanceError):
        ev.agent_id = "other"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Tracer integration
# ---------------------------------------------------------------------------


def test_noop_tracer_accepts_working_memory_event() -> None:
    NoOpTracer().on_event(_event())


def test_stdout_tracer_emits_working_memory_event_json() -> None:
    buf = io.StringIO()
    tracer = StdoutTracer(stream=buf)
    tracer.on_event(_event())
    line = buf.getvalue().strip()
    payload = json.loads(line)
    assert payload["kind"] == "working_memory_updated"
    assert payload["agent_id"] == "root"


# ---------------------------------------------------------------------------
# End-to-end emission via the builtin tool
# ---------------------------------------------------------------------------


class _UserCard(BaseModel):
    name: str | None = None
    role: str | None = None


@dataclass
class _RecordingWorkingMemory:
    rows: dict[str, str] = field(default_factory=dict)

    async def get(self) -> dict[str, Any]:
        return {}

    async def update(self, patch: dict[str, str]) -> None:
        for k, v in patch.items():
            if v == "":
                self.rows.pop(k, None)
            else:
                self.rows[k] = v

    async def clear(self) -> None:
        self.rows.clear()


@dataclass
class _Memory:
    working_memory: _RecordingWorkingMemory


@dataclass
class _ListTracer:
    events: list[Any] = field(default_factory=list)

    def on_event(self, ev: Any) -> None:
        self.events.append(ev)


def _ctx(memory: _Memory, tracer: _ListTracer) -> Ctx:
    async def _noop(_: Any = None) -> None:
        return None

    async def _stream(_: str) -> None:
        return None

    return Ctx(
        user_id="alice",
        session_id=None,
        channel="test",
        memory=memory,  # type: ignore[arg-type]
        reply=_noop,
        stream=_stream,
        finalize=_noop,
        http=None,  # type: ignore[arg-type]
        logger=logging.getLogger("test.wm_event"),
        tracer=tracer,
        state={},
    )


async def test_tool_emits_working_memory_updated_event() -> None:
    handler = make_update_working_memory_tool(_UserCard, agent_name="root")
    wm = _RecordingWorkingMemory()
    tracer = _ListTracer()
    ctx = _ctx(_Memory(working_memory=wm), tracer)

    await handler(ctx, name="Niels", role="Engineer")

    assert len(tracer.events) == 1
    ev = tracer.events[0]
    assert isinstance(ev, WorkingMemoryUpdated)
    assert ev.agent_id == "root"
    assert ev.fields_updated == ("name", "role")


async def test_tool_does_not_emit_for_noop_patch() -> None:
    handler = make_update_working_memory_tool(_UserCard, agent_name="root")
    wm = _RecordingWorkingMemory()
    tracer = _ListTracer()
    ctx = _ctx(_Memory(working_memory=wm), tracer)

    await handler(ctx)  # no fields

    assert tracer.events == []


async def test_tool_does_not_emit_on_invalid_patch() -> None:
    handler = make_update_working_memory_tool(_UserCard, agent_name="root")
    wm = _RecordingWorkingMemory()
    tracer = _ListTracer()
    ctx = _ctx(_Memory(working_memory=wm), tracer)

    await handler(ctx, unknown_field="x")

    assert tracer.events == []


async def test_tool_swallows_tracer_failure() -> None:
    """A raising tracer must not break the tool body."""

    class _BadTracer:
        def on_event(self, _: Any) -> None:
            raise RuntimeError("tracer down")

    handler = make_update_working_memory_tool(_UserCard, agent_name="root")
    wm = _RecordingWorkingMemory()
    ctx = _ctx(_Memory(working_memory=wm), _BadTracer())  # type: ignore[arg-type]

    out = await handler(ctx, name="Niels")
    assert out == "updated: name"
    assert wm.rows == {"name": "Niels"}
