"""Tests for plugin entry-point discovery + `EntryPointCollisionError`."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from zeno.exceptions import EntryPointCollisionError
from zeno.plugins.discovery import discover, discover_all
from zeno.plugins.groups import ALL_GROUPS, ZENO_CHANNELS


def _make_ep(name: str, value: str, group: str, dist_name: str | None) -> Any:
    """Return a MagicMock shaped like `importlib.metadata.EntryPoint`.

    `discover` only touches `.name` and `.dist.name`; a real `EntryPoint` in
    3.12 exposes `.dist` as a descriptor backed by the metadata DB, which is
    not trivially mockable, so we stub the minimum surface.
    """
    ep = MagicMock()
    ep.name = name
    ep.value = value
    ep.group = group
    if dist_name is None:
        del ep.dist
    else:
        dist = MagicMock()
        dist.name = dist_name
        ep.dist = dist
    return ep


def test_empty_group_returns_empty_dict() -> None:
    with patch("zeno.plugins.discovery.entry_points", return_value=[]):
        assert discover(ZENO_CHANNELS) == {}


def test_two_distinct_names_returned() -> None:
    eps = [
        _make_ep("cli", "mod:A", ZENO_CHANNELS, "zeno-channel-cli"),
        _make_ep("imessage", "mod:B", ZENO_CHANNELS, "zeno-channel-imessage"),
    ]
    with patch("zeno.plugins.discovery.entry_points", return_value=eps):
        result = discover(ZENO_CHANNELS)
    assert set(result.keys()) == {"cli", "imessage"}


def test_collision_raises_with_both_dist_names() -> None:
    eps = [
        _make_ep("cli", "mod:A", ZENO_CHANNELS, "zeno-channel-cli"),
        _make_ep("cli", "mod:B", ZENO_CHANNELS, "other-cli-pkg"),
    ]
    with (
        patch("zeno.plugins.discovery.entry_points", return_value=eps),
        pytest.raises(EntryPointCollisionError) as exc_info,
    ):
        discover(ZENO_CHANNELS)
    err = exc_info.value
    assert err.group == ZENO_CHANNELS
    assert err.name == "cli"
    assert "zeno-channel-cli" in err.dists
    assert "other-cli-pkg" in err.dists


def test_collision_error_message_is_actionable() -> None:
    eps = [
        _make_ep("cli", "mod:A", ZENO_CHANNELS, "zeno-channel-cli"),
        _make_ep("cli", "mod:B", ZENO_CHANNELS, "other-cli-pkg"),
    ]
    with (
        patch("zeno.plugins.discovery.entry_points", return_value=eps),
        pytest.raises(EntryPointCollisionError) as exc_info,
    ):
        discover(ZENO_CHANNELS)
    msg = str(exc_info.value)
    assert "zeno-channel-cli" in msg
    assert "other-cli-pkg" in msg
    assert "Uninstall" in msg


def test_fail_fast_first_collision_only() -> None:
    # Three entries: first two collide on "cli", third collides on "other".
    # Only the first encountered collision is raised.
    eps = [
        _make_ep("cli", "mod:A", ZENO_CHANNELS, "pkg-a"),
        _make_ep("cli", "mod:B", ZENO_CHANNELS, "pkg-b"),
        _make_ep("other", "mod:C", ZENO_CHANNELS, "pkg-c"),
        _make_ep("other", "mod:D", ZENO_CHANNELS, "pkg-d"),
    ]
    with (
        patch("zeno.plugins.discovery.entry_points", return_value=eps),
        pytest.raises(EntryPointCollisionError) as exc_info,
    ):
        discover(ZENO_CHANNELS)
    assert exc_info.value.name == "cli"


def test_discover_all_groups_runs_all_known_groups() -> None:
    calls: list[str] = []

    def fake_ep(*, group: str) -> list[Any]:
        calls.append(group)
        return []

    with patch("zeno.plugins.discovery.entry_points", side_effect=fake_ep):
        result = discover_all(ALL_GROUPS)

    assert set(calls) == set(ALL_GROUPS)
    assert set(result.keys()) == set(ALL_GROUPS)
    for group in ALL_GROUPS:
        assert result[group] == {}


def test_unknown_dist_falls_back_to_placeholder() -> None:
    ep = _make_ep("cli", "mod:A", ZENO_CHANNELS, dist_name=None)
    with patch("zeno.plugins.discovery.entry_points", return_value=[ep]):
        result = discover(ZENO_CHANNELS)
    assert "cli" in result
