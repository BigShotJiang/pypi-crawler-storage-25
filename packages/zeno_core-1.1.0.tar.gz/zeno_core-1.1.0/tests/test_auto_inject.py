"""Tests for the auto-inject middleware (R23, R24)."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import pytest
from zeno.context import Ctx
from zeno.runtime.auto_inject import AutoInjectConfig, compose_system_prompt


@dataclass
class _StubHit:
    text: str
    score: float
    meta: dict[str, Any] = field(default_factory=dict)


class _StubUserView:
    def __init__(self, hits: list[_StubHit] | None = None) -> None:
        self.hits = hits or []
        self.calls: list[tuple[str, int]] = []
        self.fail: BaseException | None = None

    async def search(self, query: str, k: int = 5) -> list[_StubHit]:
        self.calls.append((query, k))
        if self.fail is not None:
            raise self.fail
        return self.hits

    async def add(self, text: str, meta: dict[str, Any] | None = None) -> None:
        self.hits.append(_StubHit(text=text, score=1.0, meta=meta or {}))


class _StubKnowledgeView(_StubUserView):
    pass


@dataclass
class _StubWorkingMemoryView:
    async def get(self) -> dict[str, Any]:
        return {}

    async def update(self, patch: dict[str, str]) -> None:
        return None

    async def clear(self) -> None:
        return None


@dataclass
class _StubMemory:
    user: _StubUserView
    knowledge: _StubKnowledgeView
    session: Any = None
    conversation: Any = None
    working_memory: _StubWorkingMemoryView = field(default_factory=_StubWorkingMemoryView)


def _ctx_with_memory(memory: _StubMemory) -> Ctx:
    async def _noop(_: Any = None) -> None:
        return None

    async def _stream(_: str) -> None:
        return None

    return Ctx(
        user_id="alice",
        session_id=None,
        channel="test",
        memory=memory,  # type: ignore[arg-type]
        reply=_noop,
        stream=_stream,
        finalize=_noop,
        http=None,  # type: ignore[arg-type]
        logger=logging.getLogger("test.auto_inject"),
        tracer=None,
        state={},
    )


async def test_prepends_block_when_hits_above_threshold() -> None:
    user = _StubUserView(
        hits=[
            _StubHit(text="alice likes ramen", score=0.9),
            _StubHit(text="alice lives in Amsterdam", score=0.8),
            _StubHit(text="alice prefers dark mode", score=0.7),
        ]
    )
    memory = _StubMemory(user=user, knowledge=_StubKnowledgeView())
    ctx = _ctx_with_memory(memory)

    out = await compose_system_prompt(ctx, "tell me about alice", "BASE")

    assert out.startswith("[CONTEXT — from user memory]\n")
    assert "- alice likes ramen" in out
    assert "- alice lives in Amsterdam" in out
    assert "- alice prefers dark mode" in out
    assert out.endswith("BASE")
    assert user.calls == [("tell me about alice", 5)]


async def test_prepends_nothing_when_store_empty() -> None:
    memory = _StubMemory(user=_StubUserView(), knowledge=_StubKnowledgeView())
    ctx = _ctx_with_memory(memory)

    out = await compose_system_prompt(ctx, "anything", "BASE")

    assert out == "BASE"


async def test_disabled_user_is_noop() -> None:
    user = _StubUserView(hits=[_StubHit(text="should not appear", score=1.0)])
    memory = _StubMemory(user=user, knowledge=_StubKnowledgeView())
    ctx = _ctx_with_memory(memory)

    out = await compose_system_prompt(
        ctx, "query", "BASE", config=AutoInjectConfig(enabled_user=False)
    )

    assert out == "BASE"
    assert user.calls == []


async def test_threshold_filters_low_score_hits() -> None:
    user = _StubUserView(
        hits=[
            _StubHit(text="above threshold", score=0.9),
            _StubHit(text="below threshold", score=0.2),
        ]
    )
    memory = _StubMemory(user=user, knowledge=_StubKnowledgeView())
    ctx = _ctx_with_memory(memory)

    # distance_threshold=0.35 → min score 0.65
    out = await compose_system_prompt(ctx, "q", "BASE")

    assert "- above threshold" in out
    assert "below threshold" not in out


async def test_all_below_threshold_prepends_nothing() -> None:
    user = _StubUserView(hits=[_StubHit(text="weak match", score=0.1)])
    memory = _StubMemory(user=user, knowledge=_StubKnowledgeView())
    ctx = _ctx_with_memory(memory)

    out = await compose_system_prompt(ctx, "q", "BASE")

    assert out == "BASE"


async def test_store_raises_is_absorbed(
    caplog: pytest.LogCaptureFixture,
) -> None:
    user = _StubUserView()
    user.fail = RuntimeError("chroma down")
    memory = _StubMemory(user=user, knowledge=_StubKnowledgeView())
    ctx = _ctx_with_memory(memory)

    with caplog.at_level(logging.WARNING, logger="test.auto_inject"):
        out = await compose_system_prompt(ctx, "q", "BASE")

    assert out == "BASE"
    assert any(
        "auto-inject" in record.message and "user.search failed" in record.message
        for record in caplog.records
    )


async def test_store_raises_with_no_logger_falls_back_to_module_logger(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """ZenoApp may be configured without a logger; ctx.logger is then None.

    Regression: auto_inject used to call ctx.logger.warning unconditionally,
    which raised AttributeError on the failure path and crashed the turn.
    """
    user = _StubUserView()
    user.fail = RuntimeError("chroma down")
    memory = _StubMemory(user=user, knowledge=_StubKnowledgeView())
    ctx = _ctx_with_memory(memory)
    object.__setattr__(ctx, "logger", None)

    with caplog.at_level(logging.WARNING, logger="zeno.runtime.auto_inject"):
        out = await compose_system_prompt(ctx, "q", "BASE")

    assert out == "BASE"
    assert any(
        "auto-inject" in record.message and "user.search failed" in record.message
        for record in caplog.records
    )


async def test_knowledge_opt_in_adds_hits() -> None:
    know = _StubKnowledgeView(hits=[_StubHit(text="shared fact", score=0.9)])
    memory = _StubMemory(user=_StubUserView(), knowledge=know)
    ctx = _ctx_with_memory(memory)

    out = await compose_system_prompt(
        ctx,
        "q",
        "BASE",
        config=AutoInjectConfig(enabled_user=False, enabled_knowledge=True),
    )

    assert "- shared fact" in out


async def test_alice_turn_only_sees_alice_facts() -> None:
    """S7 critical safety test: context-bound view is already alice-scoped."""
    # The handle-bound view is already user-scoped at turn entry; auto-inject
    # simply forwards that scoping. Alice's view returns only alice's hits.
    alice_view = _StubUserView(hits=[_StubHit(text="alice secret", score=1.0)])
    memory = _StubMemory(user=alice_view, knowledge=_StubKnowledgeView())
    ctx = _ctx_with_memory(memory)

    out = await compose_system_prompt(ctx, "secret", "BASE")

    assert "- alice secret" in out
    assert "bob" not in out


# ---------------------------------------------------------------------------
# Unit 12: MemoryRead emission from auto-inject
# ---------------------------------------------------------------------------


class _RecordingTracer:
    def __init__(self) -> None:
        self.events: list[Any] = []

    def on_event(self, event: Any) -> None:
        self.events.append(event)


def _ctx_with_tracer(memory: _StubMemory, tracer: Any) -> Ctx:
    async def _noop(_: Any = None) -> None:
        return None

    async def _stream(_: str) -> None:
        return None

    return Ctx(
        user_id="alice",
        session_id=None,
        channel="test",
        memory=memory,  # type: ignore[arg-type]
        reply=_noop,
        stream=_stream,
        finalize=_noop,
        http=None,  # type: ignore[arg-type]
        logger=logging.getLogger("test.auto_inject"),
        tracer=tracer,
        state={},
        turn_id="turn-fixed-1",
    )


async def test_auto_inject_emits_memory_read_per_store() -> None:
    from zeno.observability.events import MemoryRead

    user = _StubUserView(hits=[_StubHit(text="hit", score=0.9)])
    know = _StubKnowledgeView(hits=[_StubHit(text="kfact", score=0.9)])
    memory = _StubMemory(user=user, knowledge=know)
    tracer = _RecordingTracer()
    ctx = _ctx_with_tracer(memory, tracer)

    await compose_system_prompt(
        ctx, "q", "BASE", config=AutoInjectConfig(enabled_user=True, enabled_knowledge=True)
    )

    reads = [e for e in tracer.events if isinstance(e, MemoryRead)]
    stores = sorted(r.store for r in reads)
    assert stores == ["knowledge", "user_memory"]
    for r in reads:
        assert r.envelope.turn_id == "turn-fixed-1"
        assert r.query_hash is not None
        assert len(r.query_hash) == 12


async def test_auto_inject_no_emission_when_memory_is_noop() -> None:
    from zeno.observability.events import MemoryRead
    from zeno.runtime.noop_memory import NoOpMemoryView

    async def _noop(_: Any = None) -> None:
        return None

    async def _stream(_: str) -> None:
        return None

    tracer = _RecordingTracer()
    ctx = Ctx(
        user_id="alice",
        session_id=None,
        channel="test",
        memory=NoOpMemoryView(),
        reply=_noop,
        stream=_stream,
        finalize=_noop,
        http=None,  # type: ignore[arg-type]
        logger=logging.getLogger("test.auto_inject"),
        tracer=tracer,
        state={},
    )

    out = await compose_system_prompt(ctx, "q", "BASE")

    assert out == "BASE"
    assert not any(isinstance(e, MemoryRead) for e in tracer.events)
