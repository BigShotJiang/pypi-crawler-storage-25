"""Tests for `Ctx`, `bind_ctx()`, and `current_ctx()`."""

from __future__ import annotations

import asyncio
import dataclasses

import httpx
import pytest
from zeno.context import Ctx, bind_ctx, current_ctx
from zeno.runtime.http import create_http_client


def test_current_ctx_raises_outside_binding() -> None:
    with pytest.raises(LookupError):
        current_ctx()


def test_bind_ctx_sets_and_resets(fake_ctx: Ctx) -> None:
    with bind_ctx(fake_ctx):
        assert current_ctx() is fake_ctx
    with pytest.raises(LookupError):
        current_ctx()


def test_ctx_is_frozen(fake_ctx: Ctx) -> None:
    with pytest.raises(dataclasses.FrozenInstanceError):
        fake_ctx.user_id = "bob"  # type: ignore[misc]


def test_ctx_state_is_mutable(fake_ctx: Ctx) -> None:
    with bind_ctx(fake_ctx):
        current_ctx().state["myplugin.key"] = "value"
        assert current_ctx().state["myplugin.key"] == "value"


def test_nested_bind_restores_outer(fake_ctx: Ctx) -> None:
    # Use two separate Ctx instances; inner binding must be undone on exit.
    inner = Ctx(
        user_id="bob",
        session_id=fake_ctx.session_id,
        channel=fake_ctx.channel,
        memory=fake_ctx.memory,
        reply=fake_ctx.reply,
        stream=fake_ctx.stream,
        finalize=fake_ctx.finalize,
        http=fake_ctx.http,
        logger=fake_ctx.logger,
        tracer=fake_ctx.tracer,
    )
    with bind_ctx(fake_ctx):
        assert current_ctx().user_id == "alice"
        with bind_ctx(inner):
            assert current_ctx().user_id == "bob"
        assert current_ctx().user_id == "alice"


async def test_ctx_propagates_into_child_tasks(fake_ctx: Ctx) -> None:
    """ContextVar must cross the `asyncio.create_task` boundary."""
    observed: list[str] = []

    async def child() -> None:
        observed.append(current_ctx().user_id)

    with bind_ctx(fake_ctx):
        await asyncio.create_task(child())

    assert observed == ["alice"]


async def test_inner_state_mutation_does_not_leak(fake_ctx: Ctx) -> None:
    """Each bind_ctx scope gets its own logical Ctx; outer state is preserved
    when inner uses a different Ctx instance."""
    outer_state_snapshot: dict[str, object] = {}
    inner = Ctx(
        user_id="bob",
        session_id=fake_ctx.session_id,
        channel=fake_ctx.channel,
        memory=fake_ctx.memory,
        reply=fake_ctx.reply,
        stream=fake_ctx.stream,
        finalize=fake_ctx.finalize,
        http=fake_ctx.http,
        logger=fake_ctx.logger,
        tracer=fake_ctx.tracer,
    )
    with bind_ctx(fake_ctx):
        current_ctx().state["outer"] = 1
        with bind_ctx(inner):
            current_ctx().state["inner"] = 2
        outer_state_snapshot = dict(current_ctx().state)
    assert outer_state_snapshot == {"outer": 1}


async def test_http_client_factory_applies_defaults() -> None:
    client = create_http_client()
    try:
        assert isinstance(client, httpx.AsyncClient)
        # Timeout fields are set via httpx.Timeout; ensure the factory's
        # override path works too.
        t = client.timeout
        assert t.connect == 5.0
    finally:
        await client.aclose()


async def test_http_client_factory_overrides() -> None:
    custom = httpx.Timeout(connect=1.0, read=2.0, write=3.0, pool=4.0)
    client = create_http_client(timeout=custom)
    try:
        assert client.timeout.connect == 1.0
        assert client.timeout.read == 2.0
    finally:
        await client.aclose()


async def test_http_client_closed_refuses_new_request() -> None:
    client = create_http_client()
    await client.aclose()
    with pytest.raises(RuntimeError):
        await client.get("https://example.invalid")
