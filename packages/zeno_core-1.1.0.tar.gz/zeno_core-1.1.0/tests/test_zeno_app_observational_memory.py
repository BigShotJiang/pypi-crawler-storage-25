"""Integration tests for `ZenoApp(observational_memory=...)` wiring.

Mirrors `test_app_memory_maintenance_wiring.py` for the new L4 subsystem.

Covers:
  - lifecycle (start/stop called)
  - ``ctx.state["observational_memory"]`` exposure during a turn
  - ``on_turn_complete`` hook actually calls
    ``maybe_observe_and_reflect(ctx, agent_id=..., thread_key=...)``
  - auto-inject default flip when ``observational_memory=`` is configured
  - explicit ``auto_inject=`` overrides the default flip
  - ``ConfigurationError`` when both ``memory_maintenance=`` and
    ``observational_memory=`` are passed
  - ``DeprecationWarning`` on legacy ``memory_maintenance=`` path
  - default behaviour preserved when neither kwarg is set
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from typing import Any

import pytest
from zeno.agent import Agent
from zeno.app import ZenoApp
from zeno.channels.messages import IncomingMessage
from zeno.context import Ctx
from zeno.exceptions import ConfigurationError
from zeno.runtime.auto_inject import AutoInjectConfig
from zeno.testing import FakeChannel, FakeProvider


class _FakeObservationalMemory:
    """Structural stand-in for `ObservationalMemory`.

    Records `start()`, `stop()`, and `maybe_observe_and_reflect(...)` calls
    so tests can assert wiring without dragging `zeno-memory` in. Exposes
    `started` / `observed` `asyncio.Event`s so tests can `wait_for` deterministic
    signals instead of polling on a wall-clock sleep.
    """

    def __init__(self) -> None:
        self.start_calls = 0
        self.stop_calls = 0
        self.observe_calls: list[tuple[str | None, str, str | None]] = []
        # Tuples of (user_id, agent_id, thread_key) for each observe call.
        self.started = asyncio.Event()
        self.observed = asyncio.Event()

    async def start(self) -> None:
        self.start_calls += 1
        self.started.set()

    async def stop(self) -> None:
        self.stop_calls += 1

    async def maybe_observe_and_reflect(
        self, ctx: Ctx, *, agent_id: str, thread_key: str | None
    ) -> None:
        self.observe_calls.append((ctx.user_id, agent_id, thread_key))
        self.observed.set()


class _FakeMaintenance:
    """Minimal structural stand-in mirroring the legacy lifecycle."""

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        pass


def _msg(user_id: str = "alice", text: str = "hi") -> IncomingMessage:
    return IncomingMessage(
        user_id=user_id,
        text=text,
        received_at=datetime(2026, 4, 30, 12, 0, 0, tzinfo=UTC),
    )


# ---------------------------------------------------------------------------
# Construction guards — both kwargs / deprecation
# ---------------------------------------------------------------------------


def test_both_kwargs_raises_configuration_error(fake_ctx: Ctx) -> None:
    """Passing both legacy and new wiring is an error per R18."""
    with pytest.raises(ConfigurationError, match="Cannot configure both"):
        ZenoApp(
            agent=Agent(name="root", instructions="noop"),
            memory=fake_ctx.memory,
            channels=[FakeChannel(name="cli")],
            provider=FakeProvider(),
            http_client=fake_ctx.http,
            memory_maintenance=_FakeMaintenance(),
            observational_memory=_FakeObservationalMemory(),
        )


def test_legacy_memory_maintenance_emits_deprecation(fake_ctx: Ctx) -> None:
    with pytest.warns(DeprecationWarning, match="memory_maintenance"):
        ZenoApp(
            agent=Agent(name="root", instructions="noop"),
            memory=fake_ctx.memory,
            channels=[FakeChannel(name="cli")],
            provider=FakeProvider(),
            http_client=fake_ctx.http,
            memory_maintenance=_FakeMaintenance(),
        )


def test_neither_kwarg_no_warning(fake_ctx: Ctx) -> None:
    """Default construction (neither kwarg) still works without warnings."""
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)
        ZenoApp(
            agent=Agent(name="root", instructions="noop"),
            memory=fake_ctx.memory,
            channels=[FakeChannel(name="cli")],
            provider=FakeProvider(),
            http_client=fake_ctx.http,
        )


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


async def test_start_stop_called(fake_ctx: Ctx) -> None:
    om = _FakeObservationalMemory()
    ch = FakeChannel(name="cli")
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(),
        http_client=fake_ctx.http,
        observational_memory=om,
    )
    run_task = asyncio.create_task(app.run())
    await asyncio.wait_for(om.started.wait(), timeout=3.0)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=3.0)

    assert om.start_calls == 1
    assert om.stop_calls >= 1


# ---------------------------------------------------------------------------
# ctx.state exposure
# ---------------------------------------------------------------------------


async def test_observational_memory_in_ctx_state_during_turn(fake_ctx: Ctx) -> None:
    om = _FakeObservationalMemory()
    ch = FakeChannel(name="cli")
    state_values: list[Any] = []
    handled = asyncio.Event()

    async def on_turn(_agent: Agent, ctx: Ctx, _m: IncomingMessage) -> None:
        state_values.append(ctx.state.get("observational_memory"))
        handled.set()

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
        observational_memory=om,
    )
    run_task = asyncio.create_task(app.run())
    await ch.inbound_put(_msg())
    await asyncio.wait_for(handled.wait(), timeout=3.0)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=3.0)

    assert state_values, "on_turn was never called"
    assert state_values[0] is om


async def test_state_key_absent_when_not_configured(fake_ctx: Ctx) -> None:
    """Without `observational_memory=`, the ctx.state key is absent."""
    ch = FakeChannel(name="cli")
    state_values: list[Any] = []
    handled = asyncio.Event()

    async def on_turn(_agent: Agent, ctx: Ctx, _m: IncomingMessage) -> None:
        state_values.append(ctx.state.get("observational_memory", "_MISSING_"))
        handled.set()

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
    )
    run_task = asyncio.create_task(app.run())
    await ch.inbound_put(_msg())
    await asyncio.wait_for(handled.wait(), timeout=3.0)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=3.0)

    assert state_values == ["_MISSING_"]


# ---------------------------------------------------------------------------
# on_turn_complete hook
# ---------------------------------------------------------------------------


async def test_on_turn_complete_invokes_maybe_observe_and_reflect(fake_ctx: Ctx) -> None:
    om = _FakeObservationalMemory()
    ch = FakeChannel(name="cli")

    async def on_turn(_agent: Agent, ctx: Ctx, _m: IncomingMessage) -> None:
        await ctx.stream("hello")
        await ctx.finalize()

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
        observational_memory=om,
    )
    run_task = asyncio.create_task(app.run())
    await ch.inbound_put(_msg(user_id="alice"))
    await asyncio.wait_for(om.observed.wait(), timeout=3.0)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=3.0)

    assert om.observe_calls, "on_turn_complete hook never fired"
    user_id, agent_id, thread_key = om.observe_calls[0]
    assert user_id == "alice"
    assert agent_id == "root"
    assert thread_key is None


# ---------------------------------------------------------------------------
# Auto-inject default flip (R19)
# ---------------------------------------------------------------------------


async def test_auto_inject_default_flips_off_user_memory(fake_ctx: Ctx) -> None:
    """`observational_memory=` with no explicit auto_inject -> enabled_user=False."""
    om = _FakeObservationalMemory()
    ch = FakeChannel(name="cli")

    handler_invocations = 0
    handled = asyncio.Event()

    async def on_turn(_agent: Agent, ctx: Ctx, _m: IncomingMessage) -> None:
        nonlocal handler_invocations
        handler_invocations += 1
        # The composed prompt is what `compose_system_prompt` produced.
        # If user-memory was queried, we'd see the [CONTEXT — from user
        # memory] header. With the flip, we should not.
        assert "[CONTEXT — from user memory]" not in ctx.state["composed_prompt"]
        handled.set()

    app = ZenoApp(
        agent=Agent(name="root", instructions="base instructions"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
        observational_memory=om,
    )
    run_task = asyncio.create_task(app.run())
    await ch.inbound_put(_msg())
    await asyncio.wait_for(handled.wait(), timeout=3.0)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=3.0)

    assert handler_invocations == 1


async def test_explicit_auto_inject_overrides_default_flip(fake_ctx: Ctx) -> None:
    """Explicit `auto_inject=` wins; the default flip does not apply."""
    om = _FakeObservationalMemory()
    ch = FakeChannel(name="cli")
    explicit = AutoInjectConfig(enabled_user=True)

    captured_config: list[AutoInjectConfig] = []

    async def on_turn(_agent: Agent, _ctx: Ctx, _m: IncomingMessage) -> None:
        # Verifying enabled_user remained True is sufficient; we don't
        # need to assert on the actual prompt contents.
        captured_config.append(explicit)

    app = ZenoApp(
        agent=Agent(name="root", instructions="base"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
        observational_memory=om,
        auto_inject=explicit,
    )
    # Re-resolve via the private helper to keep the assertion focused on
    # the resolution logic rather than the full integration path.
    assert app._resolve_auto_inject() is explicit
    # Defensive: also exercise the default branch produces enabled_user=False.
    app2 = ZenoApp(
        agent=Agent(name="root", instructions="base"),
        memory=fake_ctx.memory,
        channels=[ch],
        provider=FakeProvider(),
        http_client=fake_ctx.http,
        observational_memory=om,
    )
    resolved = app2._resolve_auto_inject()
    assert resolved is not None
    assert resolved.enabled_user is False
