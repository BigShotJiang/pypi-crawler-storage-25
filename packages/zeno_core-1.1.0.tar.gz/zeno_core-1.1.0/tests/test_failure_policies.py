"""Tests for `default_on_turn_error` and `default_on_send_failure`."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.context import Ctx, bind_ctx
from zeno.observability.events import SendFailed, TurnFailed
from zeno.observability.policies import (
    APOLOGY_TEXT,
    default_on_send_failure,
    default_on_turn_error,
)


def _ctx(tracer: Any, reply: Any) -> Ctx:
    return Ctx(
        user_id="alice",
        session_id="s1",
        channel="cli",
        memory=MagicMock(),
        reply=reply,
        stream=AsyncMock(),
        finalize=AsyncMock(),
        http=MagicMock(),
        logger=MagicMock(),
        tracer=tracer,
    )


def _msg() -> IncomingMessage:
    return IncomingMessage(
        user_id="alice",
        text="hi",
        received_at=datetime(2026, 4, 19, 10, 0, 0),
        thread_key="t1",
    )


async def test_default_on_turn_error_replies_with_apology() -> None:
    tracer = MagicMock()
    reply = AsyncMock()
    ctx = _ctx(tracer=tracer, reply=reply)
    exc = RuntimeError("boom")

    await default_on_turn_error(ctx, _msg(), exc)

    reply.assert_awaited_once()
    assert reply.await_args is not None
    sent = reply.await_args.args[0]
    assert isinstance(sent, OutgoingMessage)
    assert sent.text == APOLOGY_TEXT
    assert sent.reply_to_thread_key == "t1"


async def test_default_on_turn_error_emits_turn_failed_event() -> None:
    tracer = MagicMock()
    ctx = _ctx(tracer=tracer, reply=AsyncMock())

    await default_on_turn_error(ctx, _msg(), ValueError("nope"))

    tracer.on_event.assert_called_once()
    event = tracer.on_event.call_args.args[0]
    assert isinstance(event, TurnFailed)
    assert event.error_type == "ValueError"
    assert event.error_message == "nope"
    assert event.envelope.user_id == "alice"
    assert event.envelope.session_id == "s1"


async def test_default_on_turn_error_survives_reply_failure() -> None:
    tracer = MagicMock()
    reply = AsyncMock(side_effect=RuntimeError("wire down"))
    ctx = _ctx(tracer=tracer, reply=reply)

    # Must not raise — the worker needs to continue to the next turn.
    await default_on_turn_error(ctx, _msg(), RuntimeError("boom"))

    # TurnFailed was still emitted before the apology attempt.
    tracer.on_event.assert_called_once()


async def test_default_on_send_failure_emits_send_failed_event() -> None:
    tracer = MagicMock()
    ctx = _ctx(tracer=tracer, reply=AsyncMock())

    channel = MagicMock()
    channel.name = "cli"
    exc = RuntimeError("pipe broken")

    with bind_ctx(ctx):
        await default_on_send_failure(channel, OutgoingMessage(text="hi"), exc)

    tracer.on_event.assert_called_once()
    event = tracer.on_event.call_args.args[0]
    assert isinstance(event, SendFailed)
    assert event.channel == "cli"
    assert event.error_type == "RuntimeError"
    assert event.error_message == "pipe broken"


async def test_default_on_send_failure_outside_ctx_logs_without_raising(
    caplog: pytest.LogCaptureFixture,
) -> None:
    channel = MagicMock()
    channel.name = "cli"
    with caplog.at_level("WARNING", logger="zeno.observability"):
        await default_on_send_failure(channel, OutgoingMessage(text="hi"), RuntimeError("x"))
    assert any("Send failed on channel=cli" in r.getMessage() for r in caplog.records)
