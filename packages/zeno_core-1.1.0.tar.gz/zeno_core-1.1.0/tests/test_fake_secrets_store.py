"""Tests for `FakeSecretsStore` in `zeno.testing` (U3)."""

from __future__ import annotations

import os

import pytest
from zeno.exceptions import SecretNotFoundError
from zeno.protocols.secrets import SecretsStore
from zeno.testing import FakeSecretsStore


async def test_returns_mapped_value() -> None:
    store = FakeSecretsStore({"A": "1"})
    assert await store.get("A") == "1"


async def test_missing_key_raises_not_found() -> None:
    store = FakeSecretsStore({"A": "1"})
    with pytest.raises(SecretNotFoundError) as excinfo:
        await store.get("B")
    assert excinfo.value.name == "B"


async def test_get_calls_records_call_order() -> None:
    store = FakeSecretsStore({"A": "1", "B": "2"})
    await store.get("A")
    await store.get("B")
    await store.get("A")
    assert store.get_calls == ["A", "B", "A"]


async def test_set_mutation_visible_to_subsequent_get() -> None:
    store = FakeSecretsStore({"A": "1"})
    assert await store.get("A") == "1"
    await store.set("A", "2")
    assert await store.get("A") == "2"


async def test_set_adds_new_key() -> None:
    store = FakeSecretsStore()
    with pytest.raises(SecretNotFoundError):
        await store.get("NEW")
    await store.set("NEW", "value")
    assert await store.get("NEW") == "value"


async def test_never_reads_os_environ(monkeypatch: pytest.MonkeyPatch) -> None:
    """Even when the real env holds the name, FakeSecretsStore must miss."""
    monkeypatch.setenv("ZENO_FAKE_LEAK_TEST", "from-env")
    store = FakeSecretsStore()  # no mapping
    with pytest.raises(SecretNotFoundError):
        await store.get("ZENO_FAKE_LEAK_TEST")
    # And confirm we didn't pollute the env in the other direction.
    assert os.environ.get("ZENO_FAKE_LEAK_TEST") == "from-env"


def test_matches_secrets_store_protocol() -> None:
    assert isinstance(FakeSecretsStore(), SecretsStore)


async def test_empty_default_mapping() -> None:
    store = FakeSecretsStore()
    with pytest.raises(SecretNotFoundError):
        await store.get("ANY")
    assert store.get_calls == ["ANY"]


async def test_empty_string_value_is_valid() -> None:
    store = FakeSecretsStore({"A": ""})
    assert await store.get("A") == ""
