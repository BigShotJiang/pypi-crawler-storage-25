"""Integration tests for the L4 observation block in `make_default_handler`.

Asserts that:
  - With `observation_priority_markers=None` (no observational memory) the
    handler omits the observation block entirely (current behaviour
    preserved).
  - With markers wired, the handler prepends the rendered block in the
    `wm + obs + compose` order.
  - When `list_active()` raises, the turn still succeeds and the
    observation block is silently dropped (soft input posture).
  - Two no-change turns produce identical `composed_prompt` strings
    (cache prefix stability, R16).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Literal

from zeno.agent import Agent
from zeno.channels.messages import IncomingMessage
from zeno.context import Ctx
from zeno.runtime.default_handler import make_default_handler
from zeno.testing import FakeProvider


@dataclass(frozen=True, slots=True)
class _FakeObservation:
    text: str
    priority: Literal["high", "medium", "low"]
    observation_date: int
    referenced_date: int | None = None
    id: int = 0
    user_id: str = "alice"
    agent_id: str = "root"
    source_round_ids: tuple[int, ...] = ()
    created_at: int = 0
    archived_at: int | None = None


@dataclass
class _ObsView:
    rows: list[_FakeObservation] = field(default_factory=list)
    raise_on_list: bool = False

    async def list_active(self) -> list[_FakeObservation]:
        if self.raise_on_list:
            raise RuntimeError("simulated store failure")
        return list(self.rows)


def _build_msg() -> IncomingMessage:
    return IncomingMessage(
        user_id="alice",
        text="hi",
        received_at=datetime(2026, 4, 30, 12, 0, tzinfo=UTC),
    )


def _ts(year: int, month: int, day: int, *, hour: int = 9, minute: int = 0) -> int:
    return int(datetime(year, month, day, hour, minute, tzinfo=UTC).timestamp())


async def test_no_observation_block_when_markers_none(fake_ctx: Ctx) -> None:
    """`observation_priority_markers=None` -> no observation block."""
    handler = make_default_handler(
        agent=Agent(name="root", instructions="base"),
        provider=FakeProvider(),
        observation_priority_markers=None,
    )
    await handler(fake_ctx, _build_msg())
    composed: str = fake_ctx.state["composed_prompt"]
    assert "## Observations" not in composed
    assert composed.endswith("base")


async def test_observation_block_inserted_when_rows_exist(fake_ctx: Ctx) -> None:
    """Active rows + markers wired -> block sits between WM and compose output."""
    obs_view = _ObsView(
        rows=[
            _FakeObservation(
                text="alpha",
                priority="high",
                observation_date=_ts(2026, 4, 30, hour=8),
            )
        ]
    )
    # Replace the conftest fake with our richer one for this test only.
    object.__setattr__(fake_ctx.memory, "observation_log", obs_view)

    handler = make_default_handler(
        agent=Agent(name="root", instructions="base"),
        provider=FakeProvider(),
        observation_priority_markers="emoji",
    )
    await handler(fake_ctx, _build_msg())
    composed: str = fake_ctx.state["composed_prompt"]
    assert "## Observations" in composed
    assert "🔴" in composed
    assert composed.index("## Observations") < composed.index("base")


async def test_observation_block_omitted_for_empty_list(fake_ctx: Ctx) -> None:
    """Empty `list_active` -> renderer returns empty; no block in composed."""
    handler = make_default_handler(
        agent=Agent(name="root", instructions="base"),
        provider=FakeProvider(),
        observation_priority_markers="emoji",
    )
    await handler(fake_ctx, _build_msg())
    composed: str = fake_ctx.state["composed_prompt"]
    assert "## Observations" not in composed


async def test_observation_block_failure_is_soft(fake_ctx: Ctx) -> None:
    """`list_active` raising -> turn succeeds; block omitted; warning logged."""
    obs_view = _ObsView(raise_on_list=True)
    object.__setattr__(fake_ctx.memory, "observation_log", obs_view)

    handler = make_default_handler(
        agent=Agent(name="root", instructions="base"),
        provider=FakeProvider(),
        observation_priority_markers="emoji",
    )
    await handler(fake_ctx, _build_msg())
    composed: str = fake_ctx.state["composed_prompt"]
    assert "## Observations" not in composed


async def test_two_consecutive_turns_same_composed_prompt(fake_ctx: Ctx) -> None:
    """Two no-change turns produce byte-identical composed prompts (R16)."""
    obs_view = _ObsView(
        rows=[
            _FakeObservation(
                text="stable",
                priority="medium",
                observation_date=_ts(2026, 4, 22, hour=14),
            )
        ]
    )
    object.__setattr__(fake_ctx.memory, "observation_log", obs_view)

    handler = make_default_handler(
        agent=Agent(name="root", instructions="base"),
        provider=FakeProvider(),
        observation_priority_markers="emoji",
    )
    await handler(fake_ctx, _build_msg())
    first: str = fake_ctx.state["composed_prompt"]
    captured: list[str] = []
    captured.append(first)
    fake_ctx.state.pop("composed_prompt")
    await handler(fake_ctx, _build_msg())
    second: str = fake_ctx.state["composed_prompt"]
    captured.append(second)

    # Both prompts are non-empty and observation block is present.
    assert all("## Observations" in p for p in captured)
    # Stability is per-day, so within the same test run they should be equal.
    assert captured[0] == captured[1]


async def test_handler_writes_state_for_provider(fake_ctx: Ctx) -> None:
    """Sanity: the provider sees `composed_prompt` populated."""
    captured: list[str] = []

    async def on_turn(_agent: Agent, ctx: Ctx, _m: IncomingMessage) -> None:
        captured.append(ctx.state["composed_prompt"])

    handler = make_default_handler(
        agent=Agent(name="root", instructions="base"),
        provider=FakeProvider(on_turn=on_turn),
        observation_priority_markers="emoji",
    )
    await handler(fake_ctx, _build_msg())
    assert captured
    assert isinstance(captured[0], str)


# Cast-import helper used by tests above to satisfy the type checker on
# `object.__setattr__` against a frozen dataclass.
def _cast(_obj: Any) -> Any:  # pragma: no cover — typing shim
    return _obj
