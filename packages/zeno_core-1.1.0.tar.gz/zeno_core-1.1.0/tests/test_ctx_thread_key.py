"""Tests for the new `thread_key` field on `Ctx` (U0)."""

from __future__ import annotations

from dataclasses import FrozenInstanceError
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from zeno.context import Ctx


def _make_ctx(**kwargs: object) -> Ctx:
    transport = httpx.MockTransport(lambda req: httpx.Response(200))
    http = httpx.AsyncClient(transport=transport)
    defaults: dict[str, object] = {
        "user_id": "alice",
        "session_id": None,
        "channel": "test",
        "memory": MagicMock(),
        "reply": AsyncMock(),
        "stream": AsyncMock(),
        "finalize": AsyncMock(),
        "http": http,
        "logger": MagicMock(),
        "tracer": MagicMock(),
    }
    defaults.update(kwargs)
    return Ctx(**defaults)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


def test_thread_key_defaults_to_none() -> None:
    """Backwards-compat: existing callers that don't pass thread_key get None."""
    ctx = _make_ctx()
    assert ctx.thread_key is None


def test_thread_key_set_to_string() -> None:
    ctx = _make_ctx(thread_key="thread-42")
    assert ctx.thread_key == "thread-42"


def test_thread_key_set_to_none_explicitly() -> None:
    ctx = _make_ctx(thread_key=None)
    assert ctx.thread_key is None


# ---------------------------------------------------------------------------
# Edge cases — backwards compatibility
# ---------------------------------------------------------------------------


def test_ctx_is_frozen_thread_key_reassignment_raises() -> None:
    ctx = _make_ctx(thread_key="t1")
    with pytest.raises(FrozenInstanceError):
        ctx.thread_key = "t2"  # type: ignore[misc]


def test_ctx_state_still_defaults_to_empty_dict() -> None:
    """Ensure the `thread_key` addition doesn't break `state` default."""
    ctx = _make_ctx()
    assert ctx.state == {}


def test_ctx_state_and_thread_key_coexist() -> None:
    ctx = _make_ctx(thread_key="t1", state={"plugin.key": 99})
    assert ctx.thread_key == "t1"
    assert ctx.state["plugin.key"] == 99
