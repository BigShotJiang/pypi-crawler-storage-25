"""Integration tests for `ZenoApp` lifecycle (characterization for v0.3.0)."""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Any

from zeno.agent import Agent
from zeno.app import ZenoApp
from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.context import Ctx
from zeno.testing import FakeChannel, FakeProvider


def _msg(user_id: str, text: str) -> IncomingMessage:
    return IncomingMessage(
        user_id=user_id,
        text=text,
        received_at=datetime(2026, 4, 19, 10, 0, 0),
    )


async def test_end_to_end_fake_channel_delivers_reply(fake_ctx: Ctx) -> None:
    channel = FakeChannel()

    async def on_turn(agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        await ctx.reply(OutgoingMessage(text=f"echo: {msg.text}"))

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[channel],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
    )

    run_task = asyncio.create_task(app.run())
    await channel.inbox.put(_msg("alice", "hi"))
    await channel.wait_for_sent(1)

    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=2.0)

    assert channel.started is True
    assert channel.stopped is True
    assert channel.sent[0].text == "echo: hi"


async def test_two_channels_run_concurrently(fake_ctx: Ctx) -> None:
    ch_a = FakeChannel(name="a")
    ch_b = FakeChannel(name="b")

    async def on_turn(agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        await ctx.reply(OutgoingMessage(text=f"{ctx.channel}:{msg.text}"))

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[ch_a, ch_b],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
    )

    run_task = asyncio.create_task(app.run())
    await ch_a.inbox.put(_msg("alice", "hi-a"))
    await ch_b.inbox.put(_msg("alice", "hi-b"))

    await asyncio.gather(ch_a.wait_for_sent(1), ch_b.wait_for_sent(1))

    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=2.0)

    assert ch_a.sent[0].text == "a:hi-a"
    assert ch_b.sent[0].text == "b:hi-b"


async def test_shutdown_closes_owned_http_client(fake_ctx: Ctx) -> None:
    # When no http_client is passed, the app owns one and must close it.
    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=fake_ctx.memory,
        channels=[],
        provider=FakeProvider(),
    )

    run_task = asyncio.create_task(app.run())
    await asyncio.sleep(0.05)
    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=2.0)


async def test_memory_binder_scopes_per_turn_user_id(fake_ctx: Ctx) -> None:
    """S7: a `MemoryBinderProtocol` must be called per turn with `msg.user_id`."""
    calls: list[tuple[str, str, str | None, str]] = []

    class _Binder:
        def view_for(
            self,
            *,
            user_id: str,
            channel: str,
            thread_key: str | None,
            agent_id: str,
        ) -> Any:
            calls.append((user_id, channel, thread_key, agent_id))
            return fake_ctx.memory

    channel = FakeChannel(name="cli")

    async def on_turn(agent: Agent, ctx: Ctx, msg: IncomingMessage) -> None:
        await ctx.reply(OutgoingMessage(text=f"{ctx.user_id}:{msg.text}"))

    app = ZenoApp(
        agent=Agent(name="root", instructions="noop"),
        memory=_Binder(),
        channels=[channel],
        provider=FakeProvider(on_turn=on_turn),
        http_client=fake_ctx.http,
    )

    run_task = asyncio.create_task(app.run())
    await channel.inbox.put(_msg("alice", "a1"))
    await channel.inbox.put(_msg("bob", "b1"))

    await channel.wait_for_sent(2)

    app.request_shutdown()
    await asyncio.wait_for(run_task, timeout=2.0)

    users_seen = {c[0] for c in calls}
    assert users_seen == {"alice", "bob"}, calls
    agent_ids_seen = {c[3] for c in calls}
    assert agent_ids_seen == {"root"}, calls
