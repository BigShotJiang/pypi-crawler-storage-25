"""Integration tests for working-memory rendering inside `make_default_handler`."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel
from zeno.agent import Agent
from zeno.channels.messages import IncomingMessage
from zeno.context import Ctx
from zeno.memory.protocols import WorkingMemoryRecord
from zeno.providers.protocol import Capabilities
from zeno.runtime.default_handler import make_default_handler
from zeno.runtime.working_memory_block import BLOCK_HEADER

_CAPS = Capabilities(
    supports_sub_agents=False,
    supports_built_in_tools=False,
    supports_permission_mode=False,
    supports_streaming=False,
)


class _UserCard(BaseModel):
    name: str | None = None
    role: str | None = None


@dataclass
class _RecordingWorkingMemory:
    rows: dict[str, WorkingMemoryRecord] = field(default_factory=dict)
    raise_on_get: bool = False

    async def get(self) -> dict[str, WorkingMemoryRecord]:
        if self.raise_on_get:
            raise RuntimeError("boom")
        return dict(self.rows)

    async def update(self, patch: dict[str, str]) -> None:  # pragma: no cover — unused here
        return None

    async def clear(self) -> None:  # pragma: no cover — unused here
        return None


@dataclass
class _Memory:
    working_memory: _RecordingWorkingMemory


@dataclass
class _RecordingProvider:
    captured_prompt: str | None = None

    @property
    def capabilities(self) -> Capabilities:
        return _CAPS

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None

    async def run_turn(self, *, agent: Any, ctx: Ctx, msg: Any) -> None:
        self.captured_prompt = ctx.state.get("composed_prompt")


def _ctx(memory: _Memory) -> Ctx:
    async def _noop(_: Any = None) -> None:
        return None

    async def _stream(_: str) -> None:
        return None

    return Ctx(
        user_id="alice",
        session_id=None,
        channel="test",
        memory=memory,  # type: ignore[arg-type]
        reply=_noop,
        stream=_stream,
        finalize=_noop,
        http=None,  # type: ignore[arg-type]
        logger=logging.getLogger("test.default_handler"),
        tracer=None,
        state={},
    )


def _msg() -> IncomingMessage:
    return IncomingMessage(
        user_id="alice",
        text="hello",
        received_at=datetime.now(tz=UTC),
        thread_key=None,
    )


async def test_handler_prepends_working_memory_block_when_schema_set() -> None:
    wm = _RecordingWorkingMemory(
        rows={
            "name": WorkingMemoryRecord(
                user_id="alice",
                agent_id="root",
                field_name="name",
                value="Niels",
                last_updated=1_712_966_400,  # 2024-04-13 UTC
            ),
        }
    )
    provider = _RecordingProvider()
    agent = Agent(
        name="root",
        instructions="You are helpful.",
        working_memory_schema=_UserCard,
    )
    handler = make_default_handler(agent=agent, provider=provider, turn_timeout=5.0)
    await handler(_ctx(_Memory(working_memory=wm)), _msg())

    assert provider.captured_prompt is not None
    assert provider.captured_prompt.startswith(BLOCK_HEADER + "\n")
    assert "- name: Niels (updated 2024-04-13)" in provider.captured_prompt
    assert "- role: (unknown)" in provider.captured_prompt
    assert "You are helpful." in provider.captured_prompt


async def test_handler_renders_unknown_for_every_field_when_records_empty() -> None:
    wm = _RecordingWorkingMemory(rows={})
    provider = _RecordingProvider()
    agent = Agent(
        name="root",
        instructions="i",
        working_memory_schema=_UserCard,
    )
    handler = make_default_handler(agent=agent, provider=provider, turn_timeout=5.0)
    await handler(_ctx(_Memory(working_memory=wm)), _msg())

    assert provider.captured_prompt is not None
    assert "- name: (unknown)" in provider.captured_prompt
    assert "- role: (unknown)" in provider.captured_prompt


async def test_handler_omits_block_when_schema_is_none() -> None:
    wm = _RecordingWorkingMemory(rows={})
    provider = _RecordingProvider()
    agent = Agent(name="root", instructions="i")  # no schema
    handler = make_default_handler(agent=agent, provider=provider, turn_timeout=5.0)
    await handler(_ctx(_Memory(working_memory=wm)), _msg())

    assert provider.captured_prompt == "i"


async def test_handler_swallows_working_memory_errors() -> None:
    wm = _RecordingWorkingMemory(rows={}, raise_on_get=True)
    provider = _RecordingProvider()
    agent = Agent(
        name="root",
        instructions="i",
        working_memory_schema=_UserCard,
    )
    handler = make_default_handler(agent=agent, provider=provider, turn_timeout=5.0)
    await handler(_ctx(_Memory(working_memory=wm)), _msg())

    # Block omitted when get() fails — turn proceeds with bare instructions.
    assert provider.captured_prompt == "i"


async def test_handler_block_is_byte_stable_across_no_change_turns() -> None:
    wm = _RecordingWorkingMemory(
        rows={
            "name": WorkingMemoryRecord(
                user_id="alice",
                agent_id="root",
                field_name="name",
                value="Niels",
                last_updated=1_712_966_400,
            ),
        }
    )
    agent = Agent(
        name="root",
        instructions="i",
        working_memory_schema=_UserCard,
    )

    p1 = _RecordingProvider()
    handler1 = make_default_handler(agent=agent, provider=p1, turn_timeout=5.0)
    await handler1(_ctx(_Memory(working_memory=wm)), _msg())

    p2 = _RecordingProvider()
    handler2 = make_default_handler(agent=agent, provider=p2, turn_timeout=5.0)
    await handler2(_ctx(_Memory(working_memory=wm)), _msg())

    assert p1.captured_prompt == p2.captured_prompt
