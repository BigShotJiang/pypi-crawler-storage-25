"""Regression test for C2: `_rebind_ctx` must preserve `ctx.thread_key` (U0).

Before the U0 fix, `_rebind_ctx` in `turn_worker.py` enumerated every Ctx
field manually when rebuilding the Ctx. Any new field not listed there would
be silently dropped, resetting to its default (`None` for `thread_key`).

This test exercises `_rebind_ctx` indirectly through `TurnDispatcher._run_turn`
(which always calls `_rebind_ctx`) and asserts that the `Ctx` seen by the
handler carries the same `thread_key` as the originating `IncomingMessage`.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import httpx
from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Capabilities
from zeno.context import Ctx
from zeno.runtime.turn_worker import TurnDispatcher, _rebind_ctx

# ---------------------------------------------------------------------------
# Minimal fake channel
# ---------------------------------------------------------------------------


@dataclass
class _FakeCh:
    name: str = "fake"
    sent: list[OutgoingMessage] = field(default_factory=list)

    @property
    def capabilities(self) -> Capabilities:
        return Capabilities(supports_streaming=False)

    async def start(self) -> None: ...

    async def stop(self) -> None: ...

    async def receive(self) -> AsyncIterator[IncomingMessage]:
        if False:
            yield  # pragma: no cover
        return

    async def send(self, msg: Any) -> None:
        self.sent.append(msg)


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _make_ctx(thread_key: str | None = None) -> Ctx:
    transport = httpx.MockTransport(lambda req: httpx.Response(200))
    http = httpx.AsyncClient(transport=transport)
    return Ctx(
        user_id="alice",
        session_id=None,
        channel="fake",
        memory=MagicMock(),
        reply=AsyncMock(),
        stream=AsyncMock(),
        finalize=AsyncMock(),
        http=http,
        logger=MagicMock(),
        tracer=MagicMock(),
        thread_key=thread_key,
    )


def _msg(thread_key: str | None = None) -> IncomingMessage:
    return IncomingMessage(
        user_id="alice",
        text="hello",
        received_at=datetime(2026, 4, 23, 12, 0, 0),
        thread_key=thread_key,
    )


# ---------------------------------------------------------------------------
# Unit: _rebind_ctx directly
# ---------------------------------------------------------------------------


def test_rebind_ctx_preserves_thread_key_when_set() -> None:
    ctx = _make_ctx(thread_key="t1")

    async def _noop_reply(_msg: Any) -> None: ...

    async def _noop_stream(_chunk: str) -> None: ...

    async def _noop_finalize() -> None: ...

    rebound = _rebind_ctx(ctx, reply=_noop_reply, stream=_noop_stream, finalize=_noop_finalize)
    assert rebound.thread_key == "t1"


def test_rebind_ctx_preserves_none_thread_key() -> None:
    ctx = _make_ctx(thread_key=None)

    async def _noop_reply(_msg: Any) -> None: ...

    async def _noop_stream(_chunk: str) -> None: ...

    async def _noop_finalize() -> None: ...

    rebound = _rebind_ctx(ctx, reply=_noop_reply, stream=_noop_stream, finalize=_noop_finalize)
    assert rebound.thread_key is None


# ---------------------------------------------------------------------------
# Integration: thread_key is preserved through a full TurnDispatcher turn
# ---------------------------------------------------------------------------


async def test_dispatcher_turn_handler_sees_correct_thread_key() -> None:
    """The Ctx delivered to the handler retains the thread_key from the message."""
    seen_thread_keys: list[str | None] = []

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        seen_thread_keys.append(ctx.thread_key)

    def ctx_factory(channel: Any, msg: IncomingMessage) -> Ctx:
        transport = httpx.MockTransport(lambda req: httpx.Response(200))
        http = httpx.AsyncClient(transport=transport)
        return Ctx(
            user_id=msg.user_id,
            session_id=None,
            channel=channel.name,
            memory=MagicMock(),
            reply=AsyncMock(),
            stream=AsyncMock(),
            finalize=AsyncMock(),
            http=http,
            logger=MagicMock(),
            tracer=MagicMock(),
            thread_key=msg.thread_key,
        )

    ch = _FakeCh()
    dispatcher = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=ctx_factory,
    )
    await dispatcher.enqueue(ch, _msg(thread_key="thread-99"))
    await dispatcher.drain_all()

    assert seen_thread_keys == ["thread-99"]


async def test_dispatcher_turn_handler_sees_none_thread_key_for_threadless_message() -> None:
    """A message without thread_key produces a Ctx with thread_key=None."""
    seen_thread_keys: list[str | None] = []

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        seen_thread_keys.append(ctx.thread_key)

    def ctx_factory(channel: Any, msg: IncomingMessage) -> Ctx:
        transport = httpx.MockTransport(lambda req: httpx.Response(200))
        http = httpx.AsyncClient(transport=transport)
        return Ctx(
            user_id=msg.user_id,
            session_id=None,
            channel=channel.name,
            memory=MagicMock(),
            reply=AsyncMock(),
            stream=AsyncMock(),
            finalize=AsyncMock(),
            http=http,
            logger=MagicMock(),
            tracer=MagicMock(),
            thread_key=msg.thread_key,
        )

    ch = _FakeCh()
    dispatcher = TurnDispatcher(
        agent_handler=handler,
        ctx_factory=ctx_factory,
    )
    await dispatcher.enqueue(ch, _msg(thread_key=None))
    await dispatcher.drain_all()

    assert seen_thread_keys == [None]


async def test_rebind_ctx_does_not_change_other_fields() -> None:
    """Rebinding only replaces reply/stream/finalize; all other fields are preserved."""
    ctx = _make_ctx(thread_key="t2")
    ctx_with_state = Ctx(
        user_id=ctx.user_id,
        session_id="sess-1",
        channel=ctx.channel,
        memory=ctx.memory,
        reply=ctx.reply,
        stream=ctx.stream,
        finalize=ctx.finalize,
        http=ctx.http,
        logger=ctx.logger,
        tracer=ctx.tracer,
        state={"plugin.data": 42},
        thread_key="t2",
    )

    async def _r(_m: Any) -> None: ...
    async def _s(_c: str) -> None: ...
    async def _f() -> None: ...

    rebound = _rebind_ctx(ctx_with_state, reply=_r, stream=_s, finalize=_f)
    assert rebound.user_id == "alice"
    assert rebound.session_id == "sess-1"
    assert rebound.thread_key == "t2"
    assert rebound.state == {"plugin.data": 42}
    assert rebound.reply is _r
    assert rebound.stream is _s
    assert rebound.finalize is _f
