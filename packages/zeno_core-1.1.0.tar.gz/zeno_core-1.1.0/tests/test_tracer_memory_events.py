"""Tests for the four memory TraceEvent variants.

`MemoryExtracted` is turn-scoped — it carries a real ``_Envelope`` because
extraction runs as a background task spawned by the turn worker.
``MemoryDecayed``, ``MemoryPruned``, and ``MemoryConsolidated`` are
maintenance-scoped: they synthesize an envelope rooted at
``memory_maintenance:<run_id>`` so tracers can group runs without a turn id.
"""

from __future__ import annotations

import io
import json
from dataclasses import FrozenInstanceError

import pytest
from zeno.observability.events import (
    MemoryConsolidated,
    MemoryDecayed,
    MemoryExtracted,
    MemoryPruned,
    _Envelope,
    event_payload,
)
from zeno.observability.tracer import NoOpTracer, StdoutTracer

_MaintenanceEvent = MemoryDecayed | MemoryPruned | MemoryConsolidated


def _envelope() -> _Envelope:
    return _Envelope(
        turn_id="turn-1",
        sequence=0,
        user_id="alice",
        session_id="sess-1",
    )


def _extracted(*, error: bool = False) -> MemoryExtracted:
    return MemoryExtracted(
        envelope=_envelope(),
        candidate_count=4,
        inserted_count=3,
        duration_ms=42,
        error=error,
    )


def _decayed(run_id: str = "r1", tier: str = "short") -> MemoryDecayed:
    return MemoryDecayed(
        run_id=run_id,
        tier=tier,
        candidates_seen=10,
        promoted=2,
        archived=5,
        duration_ms=88,
    )


def _pruned(run_id: str = "r1") -> MemoryPruned:
    return MemoryPruned(
        run_id=run_id,
        pruned_count=12,
        archived_before=1_700_000_000,
        duration_ms=15,
    )


def _consolidated(run_id: str = "r1") -> MemoryConsolidated:
    return MemoryConsolidated(
        run_id=run_id,
        proposals_generated=20,
        proposals_accepted=14,
        merges_applied=8,
        replaces_applied=4,
        deletes_applied=2,
        duration_ms=1234,
    )


# ---------------------------------------------------------------------------
# MemoryExtracted: turn-scoped envelope
# ---------------------------------------------------------------------------


def test_memory_extracted_keeps_passed_envelope() -> None:
    ev = _extracted()
    assert ev.envelope.turn_id == "turn-1"
    assert ev.envelope.user_id == "alice"
    assert ev.envelope.session_id == "sess-1"


def test_memory_extracted_kind() -> None:
    assert _extracted().kind == "memory_extracted"


def test_memory_extracted_error_defaults_false() -> None:
    assert _extracted().error is False


def test_memory_extracted_error_propagates_to_payload() -> None:
    p = event_payload(_extracted(error=True))
    assert p["error"] is True
    assert p["candidate_count"] == 4
    assert p["inserted_count"] == 3
    assert p["duration_ms"] == 42


# ---------------------------------------------------------------------------
# Maintenance events: synthesized envelope shape
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "event,expected_turn_id",
    [
        (_decayed("abc"), "memory_maintenance:abc"),
        (_pruned("xyz"), "memory_maintenance:xyz"),
        (_consolidated("999"), "memory_maintenance:999"),
    ],
)
def test_maintenance_events_synthesize_envelope(
    event: _MaintenanceEvent, expected_turn_id: str
) -> None:
    assert isinstance(event.envelope, _Envelope)
    assert event.envelope.turn_id == expected_turn_id
    assert event.envelope.sequence == 0
    assert event.envelope.user_id is None
    assert event.envelope.session_id is None


# ---------------------------------------------------------------------------
# event_payload: dict + JSON round-trip
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "event,expected_kind",
    [
        (_extracted(), "memory_extracted"),
        (_decayed(), "memory_decayed"),
        (_pruned(), "memory_pruned"),
        (_consolidated(), "memory_consolidated"),
    ],
)
def test_event_payload_kind(event: object, expected_kind: str) -> None:
    payload = event_payload(event)  # type: ignore[arg-type]
    assert isinstance(payload, dict)
    assert payload["kind"] == expected_kind


@pytest.mark.parametrize(
    "event",
    [_extracted(), _decayed(), _pruned(), _consolidated()],
)
def test_event_payload_json_round_trip(event: object) -> None:
    payload = event_payload(event)  # type: ignore[arg-type]
    serialized = json.dumps(payload)
    recovered = json.loads(serialized)
    assert recovered["kind"] == payload["kind"]
    assert recovered["turn_id"] == payload["turn_id"]


def test_event_payload_decayed_fields() -> None:
    p = event_payload(_decayed("run-7", tier="long"))
    assert p["run_id"] == "run-7"
    assert p["tier"] == "long"
    assert p["candidates_seen"] == 10
    assert p["promoted"] == 2
    assert p["archived"] == 5
    assert p["duration_ms"] == 88


def test_event_payload_pruned_fields() -> None:
    p = event_payload(_pruned("run-9"))
    assert p["run_id"] == "run-9"
    assert p["pruned_count"] == 12
    assert p["archived_before"] == 1_700_000_000


def test_event_payload_consolidated_fields() -> None:
    p = event_payload(_consolidated("run-c"))
    assert p["proposals_generated"] == 20
    assert p["proposals_accepted"] == 14
    assert p["merges_applied"] == 8
    assert p["replaces_applied"] == 4
    assert p["deletes_applied"] == 2


# ---------------------------------------------------------------------------
# Tracer integration
# ---------------------------------------------------------------------------


def test_noop_tracer_accepts_memory_events() -> None:
    tracer = NoOpTracer()
    for ev in (_extracted(), _decayed(), _pruned(), _consolidated()):
        tracer.on_event(ev)


def test_stdout_tracer_emits_memory_events_as_json_lines() -> None:
    buf = io.StringIO()
    tracer = StdoutTracer(stream=buf)
    tracer.on_event(_extracted())
    tracer.on_event(_decayed("rd"))
    tracer.on_event(_pruned("rp"))
    tracer.on_event(_consolidated("rc"))

    lines = [ln for ln in buf.getvalue().splitlines() if ln]
    assert len(lines) == 4
    kinds = [json.loads(ln)["kind"] for ln in lines]
    assert kinds == [
        "memory_extracted",
        "memory_decayed",
        "memory_pruned",
        "memory_consolidated",
    ]


# ---------------------------------------------------------------------------
# Frozen: variants are immutable
# ---------------------------------------------------------------------------


def test_memory_extracted_is_frozen() -> None:
    ev = _extracted()
    with pytest.raises(FrozenInstanceError):
        ev.candidate_count = 99  # type: ignore[misc]


def test_memory_decayed_is_frozen() -> None:
    ev = _decayed()
    with pytest.raises(FrozenInstanceError):
        ev.tier = "permanent"  # type: ignore[misc]
