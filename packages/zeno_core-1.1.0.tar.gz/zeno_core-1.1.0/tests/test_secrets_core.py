"""Tests for the zeno-core secrets broker: protocol, defaults, exceptions (U1).

Covers `SecretsStore` protocol structural matching, `EnvSecretsStore`
hit/miss/empty, and `FileSecretsStore` load-once semantics with quoting
and error paths.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from zeno.exceptions import (
    ConfigurationError,
    SecretNotFoundError,
    SecretsBackendError,
    SecretsError,
    ZenoError,
)
from zeno.protocols.secrets import SecretsStore
from zeno.secrets import EnvSecretsStore, FileSecretsStore

# ---------------------------------------------------------------------------
# Protocol structural matching
# ---------------------------------------------------------------------------


def test_env_store_matches_protocol() -> None:
    assert isinstance(EnvSecretsStore(), SecretsStore)


def test_file_store_matches_protocol(tmp_path: Path) -> None:
    env = tmp_path / ".env"
    env.write_text("X=y\n")
    assert isinstance(FileSecretsStore(env), SecretsStore)


def test_duck_typed_object_matches_protocol() -> None:
    """A plain object with an `async def get(str) -> str` is a SecretsStore."""

    class Duck:
        async def get(self, name: str) -> str:
            return "ok"

    assert isinstance(Duck(), SecretsStore)


# ---------------------------------------------------------------------------
# EnvSecretsStore
# ---------------------------------------------------------------------------


async def test_env_store_returns_env_var(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ZENO_TEST_A", "value-a")
    store = EnvSecretsStore()
    assert await store.get("ZENO_TEST_A") == "value-a"


async def test_env_store_raises_not_found_on_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("ZENO_TEST_MISSING", raising=False)
    store = EnvSecretsStore()
    with pytest.raises(SecretNotFoundError) as excinfo:
        await store.get("ZENO_TEST_MISSING")
    assert excinfo.value.name == "ZENO_TEST_MISSING"
    # The message should name the missing key for operators.
    assert "ZENO_TEST_MISSING" in str(excinfo.value)


async def test_env_store_returns_empty_string_verbatim(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Empty string is a valid return value, not a miss."""
    monkeypatch.setenv("ZENO_TEST_EMPTY", "")
    store = EnvSecretsStore()
    assert await store.get("ZENO_TEST_EMPTY") == ""


# ---------------------------------------------------------------------------
# FileSecretsStore
# ---------------------------------------------------------------------------


async def test_file_store_roundtrips_simple_value(tmp_path: Path) -> None:
    env = tmp_path / ".env"
    env.write_text("ALPHA=one\nBETA=two\n")
    store = FileSecretsStore(env)
    assert await store.get("ALPHA") == "one"
    assert await store.get("BETA") == "two"


async def test_file_store_handles_quoted_value_with_spaces(tmp_path: Path) -> None:
    """python-dotenv strips surrounding quotes and preserves inner spaces."""
    env = tmp_path / ".env"
    env.write_text('GREETING="hello world"\n')
    store = FileSecretsStore(env)
    assert await store.get("GREETING") == "hello world"


async def test_file_store_bare_key_becomes_empty_string(tmp_path: Path) -> None:
    env = tmp_path / ".env"
    env.write_text("BARE=\n")
    store = FileSecretsStore(env)
    assert await store.get("BARE") == ""


async def test_file_store_raises_not_found_on_missing(tmp_path: Path) -> None:
    env = tmp_path / ".env"
    env.write_text("ONLY=here\n")
    store = FileSecretsStore(env)
    with pytest.raises(SecretNotFoundError) as excinfo:
        await store.get("NOPE")
    assert excinfo.value.name == "NOPE"


def test_file_store_missing_path_raises_configuration_error(tmp_path: Path) -> None:
    missing = tmp_path / "does-not-exist.env"
    with pytest.raises(ConfigurationError) as excinfo:
        FileSecretsStore(missing)
    assert str(missing) in str(excinfo.value)


def test_file_store_does_not_mutate_os_environ(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Load-once into memory; do not touch os.environ."""
    env = tmp_path / ".env"
    env.write_text("ZENO_FILESTORE_LEAKED=yes\n")
    monkeypatch.delenv("ZENO_FILESTORE_LEAKED", raising=False)
    FileSecretsStore(env)  # construct; discard
    import os as _os

    assert "ZENO_FILESTORE_LEAKED" not in _os.environ


# ---------------------------------------------------------------------------
# Exception hierarchy
# ---------------------------------------------------------------------------


def test_secret_not_found_is_secrets_error_is_zeno_error() -> None:
    err = SecretNotFoundError("X")
    assert isinstance(err, SecretsError)
    assert isinstance(err, ZenoError)


def test_secrets_backend_is_secrets_error() -> None:
    err = SecretsBackendError("boom")
    assert isinstance(err, SecretsError)
    assert isinstance(err, ZenoError)


# ---------------------------------------------------------------------------
# Unit 11: actionable recovery URLs for well-known credential names
# ---------------------------------------------------------------------------


def test_secret_not_found_anthropic_includes_obtain_url() -> None:
    err = SecretNotFoundError("ANTHROPIC_API_KEY")
    assert "https://console.anthropic.com/settings/keys" in str(err)
    assert "ANTHROPIC_API_KEY" in str(err)


def test_secret_not_found_openai_includes_obtain_url() -> None:
    err = SecretNotFoundError("OPENAI_API_KEY")
    assert "https://platform.openai.com/api-keys" in str(err)
    assert "OPENAI_API_KEY" in str(err)


def test_secret_not_found_unknown_key_stays_generic() -> None:
    err = SecretNotFoundError("MY_CUSTOM_THING")
    message = str(err)
    assert "MY_CUSTOM_THING" in message
    assert "https://" not in message
