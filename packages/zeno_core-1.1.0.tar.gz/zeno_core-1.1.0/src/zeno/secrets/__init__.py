"""Default `SecretsStore` implementations shipped with `zeno-core`.

Two stores live here:

- `EnvSecretsStore` — reads `os.environ`. The zero-config default
  wired into `Ctx.secrets` when the app passes no `secrets=` kwarg.
- `FileSecretsStore` — loads a `.env`-style file once at construction
  via `python-dotenv`'s `dotenv_values`. Does not mutate `os.environ`.

Both are intentionally tiny — no caching, no I/O beyond the obvious.
Heavier adapters (1Password, Vault, AWS Secrets Manager) live in their
own packages behind `zeno-framework` extras.
"""

from __future__ import annotations

import os
from pathlib import Path

from zeno.exceptions import ConfigurationError, SecretNotFoundError


class EnvSecretsStore:
    """Read secrets from `os.environ`.

    The default `Ctx.secrets` when `ZenoApp(secrets=...)` is not passed.
    `get(name)` raises `SecretNotFoundError` if `name` is absent from
    the process environment. An empty string is returned verbatim — it
    is not treated as a miss.
    """

    async def get(self, name: str) -> str:
        try:
            return os.environ[name]
        except KeyError as exc:
            raise SecretNotFoundError(name) from exc


class FileSecretsStore:
    """Read secrets from a `.env`-style file loaded once at construction.

    Uses `python-dotenv`'s `dotenv_values(path)` which correctly handles
    quoting, `export` prefixes, and multiline values without mutating
    the process environment. The file is read eagerly; reconstruct the
    store to pick up later edits.

    Raises `ConfigurationError` at construction time if `path` does not
    exist. Raises `SecretNotFoundError` on `get` miss.
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        if not self._path.is_file():
            raise ConfigurationError(f"FileSecretsStore: file not found: {self._path}")
        # Lazy import keeps the python-dotenv cost off the critical import
        # path for apps that only use EnvSecretsStore.
        from dotenv import dotenv_values

        values = dotenv_values(self._path)
        # dotenv_values may yield None for bare keys like `FOO=`. Coerce
        # to empty string so `get` returns a str, matching the protocol.
        self._values: dict[str, str] = {k: (v or "") for k, v in values.items()}

    async def get(self, name: str) -> str:
        try:
            return self._values[name]
        except KeyError as exc:
            raise SecretNotFoundError(name) from exc


__all__ = ["EnvSecretsStore", "FileSecretsStore"]
