"""`ZenoApp` — lifecycle glue binding channels, agent, memory, provider, and tracer.

    app = ZenoApp(
        agent=root_agent,
        channels=[CliChannel()],
        provider=ClaudeSDKProvider(),
        tracer=StdoutTracer(),
    )
    await app.run()

The `memory=` argument is optional — when omitted, `ZenoApp` injects a
`NoOpMemoryView` so the rest of the runtime keeps the non-optional
`Ctx.memory` invariant. Pass a real binder (e.g., `ThreeLayer`) to enable
session, conversation, and user-memory persistence.

`app.run()` opens one shared `httpx.AsyncClient`, runs the capability
check (`ZenoApp.start()`), starts every channel, spawns a dispatcher per
channel that routes incoming messages into the per-thread FIFO turn
worker, and waits for shutdown. The `provider` argument replaces the
v0.2 `agent_handler=` seam — Zeno itself now owns the default handler
(see `zeno.runtime.default_handler`).

Lifecycle:
    1. `ZenoApp.start()` — runs the capability check against `self.agent`
       and `provider.capabilities`; raises `ProviderCapabilityError` if
       the agent requires features the provider does not declare, then
       awaits `provider.start()`. Safe to call explicitly; `run()` calls
       it implicitly.
    2. `ZenoApp.run()` — opens the HTTP client (if not user-supplied),
       starts channels, pumps messages through the default handler,
       waits for `request_shutdown()`. On exit, stops channels, drains
       workers, calls `provider.stop()`, and closes the owned HTTP
       client.

**Provider contract invariants**:
- Providers must construct their upstream client inside ``run_turn`` so
  `Ctx` ContextVars propagate (``bind_ctx`` runs in the turn worker).
- The default handler writes `ctx.state["composed_prompt"]` before
  invoking ``run_turn``; providers read but must not mutate that key.
- `turn_timeout` (constructor kwarg) caps each `run_turn` call via
  ``asyncio.wait_for`` so a wedged provider cannot block the per-thread
  FIFO forever.

**Optional subsystem kwargs** (``scheduler=``, ``browser=``, ``memory_maintenance=``,
``observational_memory=``):
- Each accepts any object exposing ``async start()`` / ``async stop()``.
  ``run()`` spawns a parked task inside the ``TaskGroup`` so the
  lifecycle follows channel shutdown; ``stop()`` runs in the ``finally``
  block and is wrapped in ``contextlib.suppress(Exception)`` so a
  misbehaving subsystem cannot stop the rest of the app from shutting
  down. When passed, the object is exposed to every turn via
  ``ctx.state["scheduler"]`` / ``ctx.state["browser"]`` /
  ``ctx.state["memory_maintenance"]`` / ``ctx.state["observational_memory"]``
  respectively — tools look it up structurally, no zeno-core dependency
  on the subsystem package.

``memory_maintenance=`` is deprecated as of v0.4 and emits ``DeprecationWarning``;
new code should pass ``observational_memory=`` instead. Passing both raises
``ConfigurationError``. When ``observational_memory=`` is wired, ``ZenoApp``
also installs a ``TurnDispatcher.on_turn_complete`` hook that calls
``observational_memory.maybe_observe_and_reflect`` after every successful
turn, and flips the auto-inject default for ``user_memory`` to off so the
observation block becomes the canonical user-memory channel.
"""

from __future__ import annotations

import asyncio
import contextlib
import dataclasses
import uuid
import warnings
from collections.abc import Awaitable, Callable
from importlib.metadata import EntryPoint
from typing import TYPE_CHECKING, Any

from zeno.agent import Agent, SubAgent
from zeno.channels.messages import IncomingMessage
from zeno.channels.protocol import Channel
from zeno.context import Ctx
from zeno.exceptions import (
    ConfigurationError,
    EntryPointCollisionError,
    ProviderCapabilityError,
    ZenoError,
)
from zeno.plugins.discovery import discover_all
from zeno.plugins.groups import ALL_GROUPS, ZENO_SUB_AGENTS
from zeno.providers.protocol import Provider
from zeno.runtime.auto_inject import AutoInjectConfig
from zeno.runtime.default_handler import make_default_handler
from zeno.runtime.http import create_http_client
from zeno.runtime.noop_memory import NoOpMemoryView
from zeno.runtime.turn_worker import (
    SendErrorHandler,
    TurnDispatcher,
    TurnErrorHandler,
)
from zeno.secrets import EnvSecretsStore

if TYPE_CHECKING:
    import httpx
    from zeno.protocols.memory import MemoryBinderProtocol, MemoryViewProtocol
    from zeno.protocols.secrets import SecretsStore

__all__ = [
    "ZenoApp",
]


class ZenoApp:
    """Top-level application — binds channels, agent, memory, provider, tracer."""

    def __init__(
        self,
        *,
        agent: Agent,
        memory: MemoryBinderProtocol | MemoryViewProtocol | None = None,
        channels: list[Channel],
        provider: Provider | None = None,
        scheduler: Any | None = None,
        browser: Any | None = None,
        memory_maintenance: Any | None = None,
        observational_memory: Any | None = None,
        secrets: SecretsStore | None = None,
        tracer: Any | None = None,
        logger: Any | None = None,
        auto_inject: AutoInjectConfig | None = None,
        on_turn_error: TurnErrorHandler | None = None,
        on_send_failure: SendErrorHandler | None = None,
        http_client: httpx.AsyncClient | None = None,
        turn_timeout: float = 120.0,
    ) -> None:
        if provider is None:
            raise ConfigurationError(
                "ZenoApp requires a provider= argument. "
                "Pass `ClaudeSDKProvider()`, `OpenAIProvider(...)`, or a custom `Provider` impl."
            )
        if memory_maintenance is not None and observational_memory is not None:
            raise ConfigurationError(
                "Cannot configure both memory_maintenance= (deprecated) and "
                "observational_memory=. Choose one."
            )
        if memory_maintenance is not None:
            warnings.warn(
                "ZenoApp(memory_maintenance=...) is deprecated; use "
                "ZenoApp(observational_memory=...) instead. See MIGRATION.md.",
                DeprecationWarning,
                stacklevel=2,
            )

        # Fail fast on plugin collisions before any channel starts.
        discovered = discover_all(ALL_GROUPS)

        self.agent = _merge_plugin_sub_agents(agent, discovered.get(ZENO_SUB_AGENTS, {}))
        self.memory = memory if memory is not None else NoOpMemoryView()
        self.channels = channels
        self._provider = provider
        self._scheduler = scheduler
        self._browser = browser
        self._memory_maintenance = memory_maintenance
        self._observational_memory = observational_memory
        self._secrets = secrets
        self.tracer = tracer
        self.logger = logger
        self._auto_inject = auto_inject
        self._on_turn_error = on_turn_error
        self._on_send_failure = on_send_failure
        self._http_client = http_client
        self._owns_http = http_client is None
        self._turn_timeout = turn_timeout
        self._shutdown = asyncio.Event()
        self._started = False

    @property
    def provider(self) -> Provider:
        return self._provider

    async def start(self) -> None:
        """Validate capabilities against the configured agent, then start the provider.

        Idempotent: calling twice is a no-op after the first successful run.
        """
        if self._started:
            return
        _check_capabilities(self.agent, self._provider)
        await self._provider.start()
        self._started = True

    async def run(self) -> None:
        """Capability-check, start channels, pump messages, wait for shutdown."""
        await self.start()
        http = self._http_client or create_http_client()
        handler = make_default_handler(
            agent=self.agent,
            provider=self._provider,
            auto_inject=self._resolve_auto_inject(),
            turn_timeout=self._turn_timeout,
            observation_priority_markers=self._resolve_observation_markers(),
        )
        on_turn_complete = self._build_on_turn_complete()
        dispatcher_kwargs: dict[str, Any] = {
            "agent_handler": handler,
            "ctx_factory": self._make_ctx_factory(http),
            "on_turn_error": self._on_turn_error,
            "on_send_failure": self._on_send_failure,
        }
        if on_turn_complete is not None:
            dispatcher_kwargs["on_turn_complete"] = on_turn_complete
        dispatcher = TurnDispatcher(**dispatcher_kwargs)
        try:
            async with asyncio.TaskGroup() as tg:
                dispatcher.bind_taskgroup(tg)
                for ch in self.channels:
                    await ch.start()
                for ch in self.channels:
                    tg.create_task(self._pump(ch, dispatcher))
                if self._scheduler is not None:
                    self._scheduler.bind_channels({ch.name: ch for ch in self.channels})
                    tg.create_task(self._run_scheduler())
                if self._browser is not None:
                    tg.create_task(self._run_browser())
                if self._memory_maintenance is not None:
                    tg.create_task(self._run_memory_maintenance())
                if self._observational_memory is not None:
                    tg.create_task(self._run_observational_memory())
                await self._shutdown.wait()
                raise _ShutdownRequested
        except* _ShutdownRequested:
            pass
        finally:
            if self._scheduler is not None:
                with contextlib.suppress(Exception):
                    await self._scheduler.stop()
            if self._browser is not None:
                with contextlib.suppress(Exception):
                    await self._browser.stop()
            if self._memory_maintenance is not None:
                with contextlib.suppress(Exception):
                    await self._memory_maintenance.stop()
            if self._observational_memory is not None:
                with contextlib.suppress(Exception):
                    await self._observational_memory.stop()
            for ch in self.channels:
                with contextlib.suppress(Exception):
                    await ch.stop()
            await dispatcher.drain_all()
            with contextlib.suppress(Exception):
                await self._provider.stop()
            if self._owns_http:
                await http.aclose()

    def request_shutdown(self) -> None:
        self._shutdown.set()

    async def _pump(self, channel: Channel, dispatcher: TurnDispatcher) -> None:
        async for msg in channel.receive():
            await dispatcher.enqueue(channel, msg)

    async def _run_scheduler(self) -> None:
        """Start the scheduler and idle until the TaskGroup is cancelled."""
        await self._scheduler.start()  # type: ignore[union-attr]
        try:
            # Scheduler owns its internal worker task; we simply park here
            # so the TaskGroup knows we're alive and can cancel us on shutdown.
            await asyncio.Event().wait()  # never set — cancellation ends this
        finally:
            with contextlib.suppress(Exception):
                await self._scheduler.stop()  # type: ignore[union-attr]

    async def _run_browser(self) -> None:
        """Start the browser pool and idle until the TaskGroup is cancelled."""
        await self._browser.start()  # type: ignore[union-attr]
        try:
            await asyncio.Event().wait()  # never set — cancellation ends this
        finally:
            with contextlib.suppress(Exception):
                await self._browser.stop()  # type: ignore[union-attr]

    async def _run_memory_maintenance(self) -> None:
        """Start the memory maintenance loop and idle until cancelled.

        Mirrors `_run_scheduler` / `_run_browser`: the subsystem owns its
        own internal task; we park the TaskGroup task here so cancellation
        on shutdown propagates and runs the ``finally`` ``stop()``.
        """
        await self._memory_maintenance.start()  # type: ignore[union-attr]
        try:
            await asyncio.Event().wait()  # never set — cancellation ends this
        finally:
            with contextlib.suppress(Exception):
                await self._memory_maintenance.stop()  # type: ignore[union-attr]

    async def _run_observational_memory(self) -> None:
        """Start the observational-memory orchestrator and idle until cancelled."""
        await self._observational_memory.start()  # type: ignore[union-attr]
        try:
            await asyncio.Event().wait()  # never set — cancellation ends this
        finally:
            with contextlib.suppress(Exception):
                await self._observational_memory.stop()  # type: ignore[union-attr]

    def _resolve_observation_markers(self) -> Any:
        """Read `priority_markers` off the orchestrator, if any.

        The handler treats ``None`` as "no observation block", so apps
        without ``observational_memory=`` get an empty result here.
        Reading the attribute structurally keeps `zeno-core` from
        depending on `zeno-memory`'s `Literal` type.
        """
        if self._observational_memory is None:
            return None
        return getattr(self._observational_memory, "priority_markers", "emoji")

    def _resolve_auto_inject(self) -> AutoInjectConfig | None:
        """Apply the R19 default flip when ``observational_memory=`` is wired.

        Caller-supplied ``auto_inject=`` always wins. If the caller did not
        configure auto-inject explicitly and observational memory is on, the
        observation block becomes the user-memory channel — auto-inject's
        ``user_memory`` lookup defaults to off so the two do not compete for
        the same prompt prefix.
        """
        if self._auto_inject is not None:
            return self._auto_inject
        if self._observational_memory is None:
            return None
        return AutoInjectConfig(enabled_user=False)

    def _build_on_turn_complete(
        self,
    ) -> Callable[[Ctx, IncomingMessage, str], Awaitable[None]] | None:
        """Build the post-turn hook that drives observational memory."""
        om = self._observational_memory
        if om is None:
            return None
        agent_id = self.agent.name

        async def _on_turn_complete(ctx: Ctx, _msg: IncomingMessage, _text: str) -> None:
            await om.maybe_observe_and_reflect(ctx, agent_id=agent_id, thread_key=ctx.thread_key)

        return _on_turn_complete

    def _make_ctx_factory(
        self, http: httpx.AsyncClient
    ) -> Callable[[Channel, IncomingMessage], Ctx]:
        from typing import cast as _cast

        from zeno.protocols.memory import (
            MemoryBinderProtocol as _Binder,
        )
        from zeno.protocols.memory import (
            MemoryViewProtocol as _View,
        )

        memory = self.memory
        binder = _cast(_Binder, memory) if hasattr(memory, "view_for") else None
        static_view = _cast(_View, memory) if binder is None else None
        agent_id = self.agent.name
        tracer = self.tracer
        logger = self.logger
        scheduler = self._scheduler
        browser = self._browser
        memory_maintenance = self._memory_maintenance
        observational_memory = self._observational_memory
        # Resolve the default here — once per app lifetime — so every turn
        # shares the same `EnvSecretsStore` instance rather than allocating
        # a fresh one per `Ctx`. `self._secrets` stays `None`-observable so
        # tests can assert "user passed no secrets store".
        secrets = self._secrets if self._secrets is not None else EnvSecretsStore()

        def _factory(channel: Channel, msg: IncomingMessage) -> Ctx:
            view: _View
            if binder is not None:
                view = binder.view_for(
                    user_id=msg.user_id,
                    channel=channel.name,
                    thread_key=msg.thread_key,
                    agent_id=agent_id,
                )
            else:
                assert static_view is not None
                view = static_view
            state: dict[str, Any] = {}
            if scheduler is not None:
                state["scheduler"] = scheduler
            if browser is not None:
                state["browser"] = browser
            if memory_maintenance is not None:
                state["memory_maintenance"] = memory_maintenance
            if observational_memory is not None:
                state["observational_memory"] = observational_memory
            return Ctx(
                user_id=msg.user_id,
                session_id=None,
                channel=channel.name,
                memory=view,
                reply=_unbound_callable,
                stream=_unbound_stream,
                finalize=_unbound_finalize,
                http=http,
                logger=logger,
                tracer=tracer,
                state=state,
                thread_key=msg.thread_key,
                secrets=secrets,
                turn_id=uuid.uuid4().hex,
            )

        return _factory


class _ShutdownRequested(Exception):
    """Sentinel raised to unwind `TaskGroup` cleanly on shutdown."""


async def _unbound_callable(_msg: Any) -> None:
    raise RuntimeError("Ctx.reply called outside a turn worker; the turn worker rebinds this.")


async def _unbound_stream(_chunk: str) -> None:
    raise RuntimeError("Ctx.stream called outside a turn worker; the turn worker rebinds this.")


async def _unbound_finalize() -> None:
    raise RuntimeError("Ctx.finalize called outside a turn worker; the turn worker rebinds this.")


def _check_capabilities(agent: Agent, provider: Provider) -> None:
    """Walk `agent` against `provider.capabilities`; raise if any feature is missing.

    Runs after `_merge_plugin_sub_agents`, so plugin-discovered sub-agents are
    part of the same check (G7). All violations are collected into a single
    `ProviderCapabilityError` so operators see every mismatch in one pass.
    """
    caps = provider.capabilities
    missing: list[str] = []
    if agent.built_in_tools and not caps.supports_built_in_tools:
        missing.append(
            f"built_in_tools={agent.built_in_tools} "
            "(provider does not support built-in vendor tools)"
        )
    if agent.sub_agents and not caps.supports_sub_agents:
        names = ", ".join(sa.name for sa in agent.sub_agents)
        missing.append(f"sub_agents=[{names}] (provider does not support sub-agent dispatch)")
    if agent.permission_mode and not caps.supports_permission_mode:
        missing.append(
            f"permission_mode={agent.permission_mode!r} "
            "(provider does not support permission modes)"
        )
    for sa in agent.sub_agents:
        if sa.built_in_tools and not caps.supports_built_in_tools:
            missing.append(f"sub_agent {sa.name!r} built_in_tools={sa.built_in_tools}")
    if missing:
        raise ProviderCapabilityError(provider=type(provider).__name__, missing=missing)


def _merge_plugin_sub_agents(agent: Agent, sub_agent_entry_points: dict[str, EntryPoint]) -> Agent:
    """Load `zeno.sub_agents` entry-points and merge them into `agent.sub_agents`.

    `Agent` is `frozen=True, slots=True` — we rebuild it via
    `dataclasses.replace` rather than mutating the sub-agent list in place.
    """
    if not sub_agent_entry_points:
        return agent

    native_names = {sa.name for sa in agent.sub_agents}
    loaded: list[SubAgent] = []
    for ep_name, ep in sub_agent_entry_points.items():
        obj = ep.load()
        if not isinstance(obj, SubAgent):
            dist = _entry_point_dist(ep)
            raise ZenoError(
                f"Entry-point '{ep_name}' in group '{ZENO_SUB_AGENTS}' "
                f"(from distribution '{dist}', attribute '{ep.value}') loaded "
                f"{type(obj).__name__}, expected SubAgent."
            )
        if obj.name != ep_name:
            dist = _entry_point_dist(ep)
            raise ZenoError(
                f"Entry-point '{ep_name}' in group '{ZENO_SUB_AGENTS}' "
                f"(from distribution '{dist}') loaded a SubAgent named "
                f"'{obj.name}'; entry-point name must match SubAgent.name."
            )
        if obj.name in native_names:
            dist = _entry_point_dist(ep)
            raise EntryPointCollisionError(
                group=ZENO_SUB_AGENTS,
                name=obj.name,
                dists=["<python-native>", dist],
            )
        loaded.append(obj)

    return dataclasses.replace(agent, sub_agents=[*agent.sub_agents, *loaded])


def _entry_point_dist(ep: EntryPoint) -> str:
    dist = getattr(ep, "dist", None)
    if dist is None:
        return "<unknown>"
    name = getattr(dist, "name", None)
    if name is not None:
        return str(name)
    metadata = getattr(dist, "metadata", None)
    if metadata is not None:
        return str(metadata.get("Name", "<unknown>"))
    return "<unknown>"
