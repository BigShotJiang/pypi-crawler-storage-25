"""The `@tool` decorator + `ToolSpec` (R17, R18, R19).

Plugin authors write ergonomic async functions:

    @tool
    async def add_note(ctx: Ctx, text: str, tags: list[str] | None = None) -> str:
        \"\"\"Add a note to the user's memory.\"\"\"
        await ctx.memory.user.add(text, meta={"tags": tags or []})
        return "ok"

The decorator:
  1. Introspects the signature; the first parameter must be `Ctx`.
  2. Derives a JSON schema from the remaining typed kwargs.
  3. Attaches a `ToolSpec(name, description, schema, handler)` via the
     `__zeno_tool__` attribute on the wrapped function.

Provider adapters wrap `ToolSpec` into their SDK's tool shape — e.g.
`zeno-provider-claude` produces an `SdkMcpTool` via its `_mcp.to_sdk_tool`.
Core does not depend on any provider SDK.

Unsupported parameter types fail fast at decoration time with a
`ZenoError` naming the offending parameter — never silently at LLM
invocation.
"""

from __future__ import annotations

import datetime as _dt
import enum
import inspect
import typing
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Annotated, Any, Literal, TypedDict, Union, get_args, get_origin, overload

from zeno.context import Ctx
from zeno.exceptions import ZenoError

__all__ = [
    "ToolHandler",
    "ToolSpec",
    "get_spec",
    "tool",
]

try:
    from pydantic import BaseModel
except ImportError:  # pragma: no cover — pydantic is an optional schema producer
    BaseModel = None  # type: ignore[assignment,misc]


_NoneType = type(None)

ToolHandler = Callable[..., Awaitable[Any]]


@dataclass(frozen=True, slots=True)
class ToolSpec:
    """Everything a provider adapter needs to register a tool with its SDK.

    `handler` is the *original* async function (first arg is `Ctx`). Provider
    adapters wrap it for whatever transport their SDK expects; core does not
    perform any wrapping of its own.
    """

    name: str
    description: str
    schema: dict[str, Any]
    handler: ToolHandler
    _param_decoders: dict[str, Callable[[Any], Any]]


@overload
def tool(fn: ToolHandler, /) -> ToolHandler: ...
@overload
def tool(
    *,
    name: str | None = None,
    description: str | None = None,
) -> Callable[[ToolHandler], ToolHandler]: ...
def tool(
    fn: ToolHandler | None = None,
    /,
    *,
    name: str | None = None,
    description: str | None = None,
) -> ToolHandler | Callable[[ToolHandler], ToolHandler]:
    """Decorator turning an async function into a Zeno tool.

    Usage:
        @tool
        async def foo(ctx: Ctx, x: int) -> str: ...

        @tool(name="custom.name", description="override")
        async def bar(ctx: Ctx, y: str) -> str: ...
    """

    def _wrap(user_fn: ToolHandler) -> ToolHandler:
        spec = _build_spec(user_fn, name=name, description=description)
        user_fn.__zeno_tool__ = spec  # type: ignore[attr-defined]
        return user_fn

    if fn is not None:
        return _wrap(fn)
    return _wrap


def get_spec(fn: ToolHandler) -> ToolSpec:
    """Return the `ToolSpec` attached by `@tool`, or raise."""
    spec = getattr(fn, "__zeno_tool__", None)
    if spec is None:
        raise ZenoError(f"Function '{fn.__name__}' is not decorated with @tool")
    return spec  # type: ignore[no-any-return]


def _build_spec(
    fn: ToolHandler,
    *,
    name: str | None,
    description: str | None,
) -> ToolSpec:
    if not inspect.iscoroutinefunction(fn):
        raise ZenoError(f"@tool requires an async function; '{fn.__name__}' is sync")

    hints = typing.get_type_hints(fn, include_extras=True)
    sig = inspect.signature(fn)
    params = list(sig.parameters.values())
    if not params:
        raise ZenoError(f"@tool function '{fn.__name__}' must take Ctx as its first parameter")
    first = params[0]
    first_hint = hints.get(first.name)
    if first_hint is not Ctx:
        raise ZenoError(
            f"@tool function '{fn.__name__}' first parameter must be annotated as Ctx, "
            f"got {first_hint!r}"
        )

    properties: dict[str, Any] = {}
    required: list[str] = []
    decoders: dict[str, Callable[[Any], Any]] = {}

    for param in params[1:]:
        if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
            raise ZenoError(
                f"@tool function '{fn.__name__}' cannot use *args or **kwargs; "
                f"declare each parameter explicitly"
            )
        hint = hints.get(param.name, Any)
        try:
            field_schema, decoder, is_optional = _schema_for(hint)
        except _UnsupportedType as exc:
            raise ZenoError(
                f"@tool function '{fn.__name__}' parameter '{param.name}' has "
                f"unsupported type {exc.type_name}"
            ) from None

        has_default = param.default is not inspect.Parameter.empty
        if has_default:
            field_schema = dict(field_schema)
            field_schema["default"] = param.default

        if not has_default and not is_optional:
            required.append(param.name)

        properties[param.name] = field_schema
        if decoder is not None:
            decoders[param.name] = decoder

    schema: dict[str, Any] = {"type": "object", "properties": properties}
    if required:
        schema["required"] = required

    doc = inspect.getdoc(fn) or ""
    first_line = doc.split("\n", 1)[0].strip() if doc else ""

    return ToolSpec(
        name=name or fn.__name__,
        description=description or first_line,
        schema=schema,
        handler=fn,
        _param_decoders=decoders,
    )


class _UnsupportedType(Exception):
    def __init__(self, type_name: str) -> None:
        self.type_name = type_name


def _schema_for(
    hint: Any,
) -> tuple[dict[str, Any], Callable[[Any], Any] | None, bool]:
    """Return (schema, optional-decoder, is_optional).

    `is_optional` means the type admits `None` (via `Optional` / `T | None`)
    and therefore the parameter is not required regardless of default.
    """
    origin = get_origin(hint)

    # Annotated[T, "desc", ...] — description from the first str metadata.
    if origin is Annotated:
        real, *meta = get_args(hint)
        schema, decoder, optional = _schema_for(real)
        for m in meta:
            if isinstance(m, str):
                schema = {**schema, "description": m}
                break
        return schema, decoder, optional

    # Union / Optional / PEP 604 `T | U`.
    if origin is Union or origin is typing.Union or _is_union_origin(origin):
        non_none = [a for a in get_args(hint) if a is not _NoneType]
        is_optional = len(non_none) != len(get_args(hint))
        if len(non_none) == 1:
            inner_schema, decoder, _ = _schema_for(non_none[0])
            return inner_schema, decoder, is_optional
        branch_schemas = [_schema_for(a)[0] for a in non_none]
        return {"anyOf": branch_schemas}, None, is_optional

    # Literal["a", "b", 1].
    if origin is Literal:
        lit_values = list(get_args(hint))
        if all(isinstance(v, str) for v in lit_values):
            return {"type": "string", "enum": lit_values}, None, False
        if all(isinstance(v, bool) for v in lit_values):
            return {"type": "boolean", "enum": lit_values}, None, False
        if all(isinstance(v, int) for v in lit_values):
            return {"type": "integer", "enum": lit_values}, None, False
        return {"enum": lit_values}, None, False

    # list[T].
    if origin in (list, typing.List):  # noqa: UP006
        (item_t,) = get_args(hint) or (Any,)
        item_schema, _, _ = _schema_for(item_t)
        return {"type": "array", "items": item_schema}, None, False

    # dict[str, T].
    if origin in (dict, typing.Dict):  # noqa: UP006
        dict_args = get_args(hint)
        value_t = dict_args[1] if len(dict_args) == 2 else Any
        value_schema, _, _ = _schema_for(value_t)
        return {"type": "object", "additionalProperties": value_schema}, None, False

    # Bare `list` / `dict` / `Any`.
    if hint is list:
        return {"type": "array"}, None, False
    if hint is dict:
        return {"type": "object"}, None, False
    if hint is Any:
        return {}, None, False

    # Primitives.
    if hint is str:
        return {"type": "string"}, None, False
    if hint is bool:
        return {"type": "boolean"}, None, False
    if hint is int:
        return {"type": "integer"}, None, False
    if hint is float:
        return {"type": "number"}, None, False

    # datetime / date (order matters: datetime is a subclass of date).
    if isinstance(hint, type) and issubclass(hint, _dt.datetime):
        return {"type": "string", "format": "date-time"}, _dt.datetime.fromisoformat, False
    if isinstance(hint, type) and issubclass(hint, _dt.date):
        return {"type": "string", "format": "date"}, _dt.date.fromisoformat, False

    # Enum.
    if isinstance(hint, type) and issubclass(hint, enum.Enum):
        members = [m.value for m in hint]
        enum_schema: dict[str, Any]
        if all(isinstance(m, str) for m in members):
            enum_schema = {"type": "string", "enum": members}
        elif all(isinstance(m, int) for m in members):
            enum_schema = {"type": "integer", "enum": members}
        else:
            enum_schema = {"enum": members}
        return enum_schema, hint, False

    # Pydantic BaseModel.
    if BaseModel is not None and isinstance(hint, type) and issubclass(hint, BaseModel):
        model_schema = hint.model_json_schema()
        model_cls = hint
        return model_schema, lambda v: model_cls.model_validate(v), False

    # TypedDict.
    if _is_typed_dict(hint):
        td_props: dict[str, Any] = {}
        td_required: list[str] = []
        annotations = getattr(hint, "__annotations__", {})
        # TypedDict `total` semantics.
        total = getattr(hint, "__total__", True)
        explicit_required = getattr(hint, "__required_keys__", None)
        explicit_optional = getattr(hint, "__optional_keys__", None)
        for key, t in annotations.items():
            field_schema, _, _ = _schema_for(t)
            td_props[key] = field_schema
            if explicit_required is not None:
                if key in explicit_required:
                    td_required.append(key)
            elif total or (explicit_optional is not None and key not in explicit_optional):
                td_required.append(key)
        td_schema: dict[str, Any] = {"type": "object", "properties": td_props}
        if td_required:
            td_schema["required"] = td_required
        return td_schema, None, False

    type_name = getattr(hint, "__name__", repr(hint))
    raise _UnsupportedType(type_name)


def _is_union_origin(origin: Any) -> bool:
    # PEP 604: `int | str` has origin `types.UnionType`.
    import types as _t

    return origin is getattr(_t, "UnionType", None)


def _is_typed_dict(hint: Any) -> bool:
    if not isinstance(hint, type) or not issubclass(hint, dict):
        return False
    if hint is TypedDict:
        return False
    return hasattr(hint, "__annotations__") and (
        hasattr(hint, "__required_keys__") or hasattr(hint, "__total__")
    )
