"""Protocol surface for the secrets store a turn's `Ctx` exposes.

Concrete stores live either in `zeno.secrets` (env- and `.env`-backed
defaults, zero-dep stdlib + python-dotenv) or in adapter packages like
`zeno-secrets-1password`. `zeno-core` only knows about the protocol;
adapters stay out of the core import graph.

Return values are secret material. Callers must not log them, trace
them, or include them in error messages. The 0.6 release does not ship
an automatic scrubbing layer; that is an explicit future improvement.

An empty string is a valid return value — not a miss. Adapters that
want empty-string-equals-miss semantics should raise
`SecretNotFoundError` themselves.

Protocol shape is single-user by design: `get(name)` has no `user_id`
parameter. Per-user / per-session scoping is deferred to a future
`SecretsBinder.view_for(user_id)` seam, mirroring
`MemoryBinderProtocol`.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class SecretsStore(Protocol):
    """The `Ctx.secrets` surface every tool reaches.

    Implementations resolve a caller-supplied logical name to a secret
    string. Name semantics are adapter-specific: `EnvSecretsStore`
    treats names as env-var keys; `OpCliSecretsStore` treats names
    either as 1Password secret references (`op://...`) or as keys in a
    constructor-supplied reference map.
    """

    async def get(self, name: str) -> str: ...
