"""Protocol surfaces for the memory views a turn's `Ctx` exposes.

These are the only types `zeno-core` knows about. Concrete stores
(`SqliteSessionStore`, `VectorBackedUserMemoryStore`,
`SqliteConversationStore`, etc.) live in `zeno-memory` and the adapter
packages. `zeno-core` never imports those — it just types `Ctx.memory`
against `MemoryViewProtocol`.

Each `*ViewProtocol` is `runtime_checkable`, allowing tests and lightweight
runtime assertions without creating import-time coupling.

``ConversationHandle`` is re-exported here as a type alias so callers can
annotate arguments without importing from ``zeno-memory``. The alias is
``Any`` at runtime — the real dataclass lives in
``zeno.memory.handles.ConversationHandle`` and callers that need its
methods can import it directly.
"""

from __future__ import annotations

from typing import Any, Literal, Protocol, runtime_checkable

ConversationHandle = Any  # Opaque alias; real type in zeno.memory.handles.

MemoryTier = Literal["short", "long", "permanent"]
"""Tier name accepted by `UserMemoryViewProtocol.add`.

Mirrors `zeno.memory.protocols.MemoryTier` — the literal is duplicated
here so `zeno-core` does not need to import `zeno-memory`. Concrete
stores in `zeno-memory` accept the same string set, so the two
declarations are structurally compatible.
"""


@runtime_checkable
class MemoryHit(Protocol):
    """Structural shape of a single search hit (text + score + meta).

    The concrete dataclass lives in ``zeno.memory.protocols`` (zeno-memory)
    and satisfies this Protocol structurally. Defining the shape here lets
    ``zeno-core`` type view-side returns concretely without importing
    ``zeno-memory`` (which would invert the dependency direction).
    """

    text: str
    score: float
    meta: dict[str, Any]


@runtime_checkable
class UserMemoryViewProtocol(Protocol):
    """Context-bound view of the current user's memory (R25).

    No `user_id` parameter: the binding is carried by the view itself,
    established at turn entry from `Ctx.user_id`.
    """

    async def search(self, query: str, k: int = 5) -> list[MemoryHit]: ...

    async def add(
        self,
        text: str,
        meta: dict[str, Any] | None = None,
        *,
        tier: MemoryTier = "long",
    ) -> None: ...


@runtime_checkable
class KnowledgeViewProtocol(Protocol):
    """Context-bound view of the knowledge base.

    Multi-tenant by default: the underlying adapter filters by the same
    `user_id` that bound this view.
    """

    async def search(self, query: str, k: int = 5) -> list[MemoryHit]: ...

    async def add(self, text: str, meta: dict[str, Any] | None = None) -> None: ...


@runtime_checkable
class WorkingMemoryViewProtocol(Protocol):
    """Context-bound view of the agent's per-`(user_id, agent_id)` working-memory card.

    Bound at turn entry by the runtime; tools see only the three verbs
    below. Empty-string values in the patch dict mean "clear this field" —
    the underlying store enforces that contract.
    """

    async def get(self) -> dict[str, Any]: ...

    async def update(self, patch: dict[str, str]) -> None: ...

    async def clear(self) -> None: ...


@runtime_checkable
class ObservationViewProtocol(Protocol):
    """Context-bound view of the agent's `(user_id, agent_id)` observation log.

    Read-only at the per-turn surface. The Observer and Reflector mutate
    the underlying store from background coroutines owned by
    ``ObservationalMemory``; per-turn handlers only render the active
    rows. ``list_active`` returns the current `Observation` rows
    structurally (concrete dataclass lives in
    ``zeno.memory.protocols.Observation``).
    """

    async def list_active(self) -> list[Any]: ...


@runtime_checkable
class MemoryViewProtocol(Protocol):
    """Composite view exposing every per-turn handle (user, knowledge, session, etc.).

    ``session`` and ``conversation`` are intentionally untyped here —
    ``session`` is a ``SessionStore`` adapter pointer the turn worker uses
    out-of-band, and ``conversation`` is a ``ConversationHandle`` whose
    real definition lives in ``zeno.memory.handles`` (see the module-level
    ``ConversationHandle`` alias for annotations).

    ``working_memory`` is a ``WorkingMemoryViewProtocol`` pinned to
    ``(user_id, agent_id)`` by the binder before the turn starts.

    ``observation_log`` is the L4 read handle bound to the same
    ``(user_id, agent_id)``. Mutations happen through
    ``ObservationalMemory`` from background coroutines; the per-turn
    handler only reads.
    """

    user: UserMemoryViewProtocol
    knowledge: KnowledgeViewProtocol
    session: Any
    conversation: Any
    working_memory: WorkingMemoryViewProtocol
    observation_log: ObservationViewProtocol


@runtime_checkable
class MemoryBinderProtocol(Protocol):
    """Builds a fresh per-turn `MemoryViewProtocol` bound to `user_id` and `agent_id`.

    Implementations (e.g. `zeno.memory.ThreeLayer`) own references to the
    concrete stores and materialize a `MemoryView` per turn so cross-user
    isolation (S7) is enforced structurally — the handle a tool sees has
    already captured `user_id`, and there is no path back to another user's
    rows without going around the handle entirely.

    The binder is agent-aware (mirroring how IU2 made it thread-aware) so
    that working-memory cards are correctly namespaced per active agent —
    renaming an agent creates a new card.
    """

    def view_for(
        self,
        *,
        user_id: str,
        channel: str,
        thread_key: str | None,
        agent_id: str,
    ) -> MemoryViewProtocol: ...
