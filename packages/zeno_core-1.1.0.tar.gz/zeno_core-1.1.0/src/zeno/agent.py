"""`Agent` / `SubAgent` composition (R10–R12).

Agent authors compose an assistant as:

    root = Agent(
        name="root",
        instructions="You are a helpful personal assistant.",
        tools=[recall, add_note],
        built_in_tools=["WebSearch", "WebFetch"],
        permission_mode="bypassPermissions",
        sub_agents=[
            SubAgent(
                name="researcher",
                instructions="...",
                tools=[web_search],
                built_in_tools=["WebFetch"],
            ),
        ],
    )

`Agent` and `SubAgent` are pure data — provider adapters consume them
and translate to whatever shape their SDK requires. Translation to the
Claude Agent SDK's `ClaudeAgentOptions` lives in
`zeno-provider-claude` (see `agent_to_claude_options`).

Semantics defined here:
  - First positional of every `@tool` function is `Ctx`; see `zeno.tool`.
  - Sub-agent names must be unique within an `Agent` — a duplicate
    raises `ZenoError` at construction time.
  - `built_in_tools` names provider-native tools (e.g. ``"WebSearch"``,
    ``"WebFetch"``, ``"Bash"`` on Claude). Names pass through unvalidated;
    semantics are the provider's responsibility. Order is preserved and
    duplicates are deduped at translation time, not here.
  - `permission_mode` is a free-form string per provider; the Claude
    adapter passes it through as-is.
  - `instructions` is the default system prompt; per-turn override flows
    through ``ctx.state["composed_prompt"]`` (see `protocols/protocol.py`).
"""

from __future__ import annotations

import types
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Union, get_args, get_origin

from pydantic import BaseModel
from zeno.exceptions import ZenoError
from zeno.tool import ToolSpec, get_spec

if TYPE_CHECKING:
    from zeno.tool import ToolHandler

__all__ = [
    "Agent",
    "SubAgent",
]


@dataclass(frozen=True, slots=True)
class SubAgent:
    """A specialist agent delegated to via a provider's sub-agent dispatch.

    `max_turns` caps the internal loop of a single dispatch — how many model
    calls this specialist may make before the provider forces it to return.
    On Claude it maps to `AgentDefinition.maxTurns` and is orthogonal to
    `TurnBudget.max_dispatches`, which caps how many times the orchestrator
    may invoke any sub-agent per turn.

    `built_in_tools` names provider-native tools (e.g. ``"WebSearch"``,
    ``"WebFetch"``, ``"Bash"``) this sub-agent is allowed to call. Names
    pass through to the provider verbatim — no validation — so new
    built-ins work without a Zeno release. Duplicates are deduped while
    preserving order at translation time.
    """

    name: str
    instructions: str
    tools: list[ToolHandler] = field(default_factory=list)
    model: str | None = None
    max_turns: int | None = None
    built_in_tools: list[str] = field(default_factory=list)

    def _tool_specs(self) -> list[ToolSpec]:
        return [get_spec(t) for t in self.tools]


def _validate_working_memory_schema(agent_name: str, schema: type[BaseModel]) -> None:
    """Reject schemas that aren't a Pydantic v2 ``BaseModel`` of ``str | None`` fields.

    v1 stores every field as a string. Pydantic would silently coerce
    ``int``/``bool`` annotations into bad shapes the moment the model
    submits an update; rejecting them at construction time turns that
    into a clear `TypeError` at app boot.
    """
    if not (isinstance(schema, type) and issubclass(schema, BaseModel)):
        raise TypeError(
            f"Agent '{agent_name}': working_memory_schema must be a Pydantic BaseModel "
            f"subclass, got {schema!r}."
        )
    for field_name, info in schema.model_fields.items():
        ann = info.annotation
        origin = get_origin(ann)
        if origin in (Union, types.UnionType):
            args = get_args(ann)
            if set(args) != {str, type(None)}:
                raise TypeError(
                    f"Agent '{agent_name}': working_memory_schema field '{field_name}' "
                    f"must be `str | None`, got {ann!r}."
                )
        else:
            raise TypeError(
                f"Agent '{agent_name}': working_memory_schema field '{field_name}' "
                f"must be `str | None`, got {ann!r}."
            )


@dataclass(frozen=True, slots=True)
class Agent:
    """Composite agent: instructions + tools + optional sub-agents.

    `sub_agents` is a plain list by type, but `Agent` is frozen — callers
    wiring in discovered sub-agents (entry-point plugins) must rebuild the
    root via `dataclasses.replace(agent, sub_agents=[...])` rather than
    mutating in place.

    `built_in_tools` names provider-native tools (e.g. ``"WebSearch"``,
    ``"WebFetch"``, ``"Bash"`` on Claude) the orchestrator is allowed to
    call. Names pass through to the provider verbatim — no validation —
    so new built-ins work without a Zeno release. Sub-agents declare
    their own ``built_in_tools`` independently.

    `permission_mode` is provider-specific. The Claude adapter accepts
    ``"default"`` (prompt), ``"acceptEdits"``, ``"bypassPermissions"``,
    ``"plan"``. For non-interactive channels (Slack, cron, headless apps),
    set ``"bypassPermissions"`` explicitly — otherwise the provider may
    block on prompts that nobody can answer.

    `working_memory_schema` opts the agent into the L2 working-memory tier.
    Declare a Pydantic ``BaseModel`` whose every field is ``str | None``;
    the framework auto-wires the ``update_working_memory`` builtin tool,
    persists fields under ``(user_id, agent.name)``, and renders a stable
    Markdown card at the top of every system prompt. Values are stored as
    strings; richer types (numbers, dates) are a follow-up.
    """

    name: str
    instructions: str
    tools: list[ToolHandler] = field(default_factory=list)
    sub_agents: list[SubAgent] = field(default_factory=list)
    model: str | None = None
    built_in_tools: list[str] = field(default_factory=list)
    permission_mode: str | None = None
    working_memory_schema: type[BaseModel] | None = None

    def __post_init__(self) -> None:
        names = [sa.name for sa in self.sub_agents]
        dupes = {n for n in names if names.count(n) > 1}
        if dupes:
            raise ZenoError(f"Agent '{self.name}' has duplicate sub-agent names: {sorted(dupes)}")
        if self.working_memory_schema is not None:
            _validate_working_memory_schema(self.name, self.working_memory_schema)

    def _tool_specs(self) -> list[ToolSpec]:
        specs = [get_spec(t) for t in self.tools]
        if self.working_memory_schema is not None:
            from zeno.builtin_tools import make_update_working_memory_tool

            specs.append(
                get_spec(
                    make_update_working_memory_tool(
                        self.working_memory_schema, agent_name=self.name
                    )
                )
            )
        return specs
