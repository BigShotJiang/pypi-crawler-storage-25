"""Built-in `recall` / `remember` tools (R23, R24).

These are opt-in — users attach them explicitly:

    from zeno.builtin_tools import recall, remember
    agent = Agent(name="root", instructions="...", tools=[recall, remember])

`recall` lets the model fetch facts that the auto-inject middleware may
not have surfaced (different phrasing, higher-k search, explicit
knowledge lookup). `remember` is how the model persists a fact it just
learned from the user ("my dog's name is Otto"). Both are first-class
`@tool`s, so they get validated schemas and flow through the same MCP
registration path as user-defined tools.

Semantics:
  - Both tools require the current `Ctx`; they read memory views off
    `ctx.memory`. The `@tool` wrapper enforces the `Ctx`-first signature.
  - `memory` arg is a `Literal["user", "knowledge"]` — no typos.
  - `recall` returns a newline-joined `- {text}` bullet list (model-friendly).
  - `remember` returns a short confirmation string.
"""

from __future__ import annotations

import contextlib
import hashlib
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, ValidationError, create_model
from zeno.context import Ctx
from zeno.observability.events import MemoryRead, MemoryWrite, WorkingMemoryUpdated, _Envelope
from zeno.protocols.memory import (
    KnowledgeViewProtocol,
    MemoryTier,
    UserMemoryViewProtocol,
)
from zeno.runtime.noop_memory import NoOpMemoryView
from zeno.tool import ToolHandler, ToolSpec, tool

__all__ = [
    "make_update_working_memory_tool",
    "recall",
    "remember",
]

_MemoryName = Literal["user", "knowledge"]

_STORE_NAMES: dict[_MemoryName, str] = {
    "user": "user_memory",
    "knowledge": "knowledge",
}


@tool
async def recall(
    ctx: Ctx,
    query: str,
    memory: _MemoryName = "user",
    k: int = 5,
) -> str:
    """Search user memory or knowledge for facts matching `query`."""
    view = _pick_view(ctx, memory)
    hits = await view.search(query, k=k)
    _emit_memory_read(ctx, _STORE_NAMES[memory], query, len(hits))
    if not hits:
        return f"No {memory} memory hits for: {query}"
    lines = [f"- {hit.text}" for hit in hits]
    return "\n".join(lines)


@tool
async def remember(
    ctx: Ctx,
    text: str,
    memory: _MemoryName = "user",
    tier: MemoryTier = "long",
) -> str:
    """Persist a fact to user memory or knowledge for later recall.

    `tier` chooses the lifecycle bucket on the user-memory side:
      - ``short``  — easily decayed; for tentative observations.
      - ``long``   — default; promoted from short on repeat hits.
      - ``permanent`` — never decayed; pinned facts the model wants kept.
    Ignored when ``memory="knowledge"`` (the knowledge store has no tiers).
    """
    if memory == "user":
        await ctx.memory.user.add(text, tier=tier)
    else:
        await ctx.memory.knowledge.add(text)
    _emit_memory_write(ctx, _STORE_NAMES[memory])
    return f"Stored in {memory} memory: {text}"


def _pick_view(ctx: Ctx, memory: _MemoryName) -> UserMemoryViewProtocol | KnowledgeViewProtocol:
    if memory == "user":
        return ctx.memory.user
    if memory == "knowledge":
        return ctx.memory.knowledge
    # Literal narrowing should make this unreachable, but keep a safety net
    # for callers that bypass the type system.
    raise ValueError(f"Unknown memory kind: {memory!r}")


def _emit_memory_read(ctx: Ctx, store: str, query: str, result_count: int) -> None:
    if ctx.tracer is None or isinstance(ctx.memory, NoOpMemoryView):
        return
    query_hash = hashlib.sha256(query.encode("utf-8")).hexdigest()[:12]
    with contextlib.suppress(Exception):
        ctx.tracer.on_event(
            MemoryRead(
                envelope=_Envelope(
                    turn_id=ctx.turn_id,
                    sequence=0,
                    user_id=ctx.user_id,
                    session_id=ctx.session_id,
                ),
                store=store,
                query_hash=query_hash,
                result_count=result_count,
            )
        )


def _emit_memory_write(ctx: Ctx, store: str) -> None:
    if ctx.tracer is None or isinstance(ctx.memory, NoOpMemoryView):
        return
    with contextlib.suppress(Exception):
        ctx.tracer.on_event(
            MemoryWrite(
                envelope=_Envelope(
                    turn_id=ctx.turn_id,
                    sequence=0,
                    user_id=ctx.user_id,
                    session_id=ctx.session_id,
                ),
                store=store,
            )
        )


def _emit_working_memory_updated(ctx: Ctx, agent_id: str, fields_updated: tuple[str, ...]) -> None:
    if ctx.tracer is None or isinstance(ctx.memory, NoOpMemoryView):
        return
    with contextlib.suppress(Exception):
        ctx.tracer.on_event(
            WorkingMemoryUpdated(
                envelope=_Envelope(
                    turn_id=ctx.turn_id,
                    sequence=0,
                    user_id=ctx.user_id,
                    session_id=ctx.session_id,
                ),
                agent_id=agent_id,
                fields_updated=fields_updated,
            )
        )


# ---------------------------------------------------------------------------
# update_working_memory — dynamic per-agent factory (L2)
# ---------------------------------------------------------------------------


def make_update_working_memory_tool(
    schema: type[BaseModel], *, agent_name: str = ""
) -> ToolHandler:
    """Build the per-agent `update_working_memory` tool from `schema`.

    Returns a `ToolHandler` whose JSON schema mirrors the agent's
    declared field names. Every field is `str | None` with default `None`
    (per `Agent.__post_init__`'s validator); empty string is forwarded to
    `ctx.memory.working_memory.update({field: ""})`, which the store
    interprets as a clear (R7).

    `agent_name` is captured so the tool can stamp the `agent_id` on the
    emitted `WorkingMemoryUpdated` event. `Agent._tool_specs()` passes
    `Agent.name`; standalone callers (tests) can omit it.

    Validation rejects unknown fields via Pydantic's ``extra="forbid"``;
    on failure the handler returns a ``"invalid: ..."`` string and writes
    nothing.
    """
    field_names = list(schema.model_fields.keys())
    input_fields: dict[str, Any] = {name: (str | None, None) for name in field_names}
    InputModel = create_model(  # noqa: N806 — dynamic Pydantic model
        "UpdateWorkingMemoryInput",
        __config__=ConfigDict(extra="forbid"),
        **input_fields,
    )
    json_schema = InputModel.model_json_schema()
    json_schema.pop("title", None)

    description = (
        "Persist agent-scoped working memory under your namespace. Allowed fields: "
        + ", ".join(field_names)
        + ". Pass an empty string to clear a field. Use this only for the structured "
        "fields above; use `remember` for free-form facts."
    )

    async def update_working_memory(ctx: Ctx, **patch: Any) -> str:
        try:
            validated = InputModel.model_validate(patch)
        except ValidationError as exc:
            first = exc.errors()[0]
            loc = ".".join(str(p) for p in first.get("loc", ())) or "<input>"
            return f"invalid: {loc}: {first.get('msg', 'validation error')}"
        # Forward only explicitly-set fields; treat None as "don't touch".
        to_update = {
            k: v for k, v in validated.model_dump(exclude_unset=True).items() if v is not None
        }
        if not to_update:
            return "updated: (no fields)"
        await ctx.memory.working_memory.update(to_update)
        _emit_working_memory_updated(ctx, agent_name, tuple(to_update.keys()))
        return "updated: " + ", ".join(to_update.keys())

    spec = ToolSpec(
        name="update_working_memory",
        description=description,
        schema=json_schema,
        handler=update_working_memory,
        _param_decoders={},
    )
    update_working_memory.__zeno_tool__ = spec  # type: ignore[attr-defined]
    return update_working_memory
