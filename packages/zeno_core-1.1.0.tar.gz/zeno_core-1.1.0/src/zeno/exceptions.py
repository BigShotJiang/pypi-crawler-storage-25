"""Exception hierarchy for the Zeno framework.

All framework-level errors subclass `ZenoError`. Callers in application code
are expected to catch either the specific subclass they care about or
`ZenoError` as a fallback — never bare `Exception`.
"""

from __future__ import annotations

__all__ = [
    "ChannelError",
    "ConfigurationError",
    "EntryPointCollisionError",
    "MemoryError",
    "ProviderCapabilityError",
    "ProviderError",
    "SecretNotFoundError",
    "SecretsBackendError",
    "SecretsError",
    "ToolError",
    "ZenoError",
]


class ZenoError(Exception):
    """Base class for every error raised by the Zeno framework."""


class EntryPointCollisionError(ZenoError):
    """Two or more distributions register the same entry-point name.

    Raised by the plugin discovery layer at `ZenoApp` construction. The
    message names both the colliding name and the source distributions so
    the operator knows what to uninstall.
    """

    def __init__(self, group: str, name: str, dists: list[str]) -> None:
        self.group = group
        self.name = name
        self.dists = dists
        dists_fmt = ", ".join(dists)
        super().__init__(
            f"Multiple distributions registered '{name}' in group '{group}': "
            f"{dists_fmt}. Uninstall one or contact the plugin authors."
        )


class ChannelError(ZenoError):
    """Raised by channels when a transport-layer operation fails irrecoverably."""


class MemoryError(ZenoError):  # noqa: A001 — intentional shadow
    """Raised by memory stores for adapter-level failures (connection, schema, etc.)."""


class ToolError(ZenoError):
    """Raised at `@tool` decoration time for invalid signatures or unsupported types."""


class ConfigurationError(ZenoError):
    """Raised at `ZenoApp` construction when a required argument is missing or invalid.

    This is distinct from `ValueError` so operators can catch configuration
    problems separately from bad runtime input.
    """


class ProviderError(ZenoError):
    """Raised by provider adapters for transport- or upstream-level failures.

    Provider authors wrap HTTP errors, timeouts, auth failures, etc. into a
    `ProviderError` (or subclass) before re-raising. The turn worker catches
    this during `run_turn` and runs the configured `on_turn_error` handler.
    """


class SecretsError(ZenoError):
    """Base class for secrets-broker failures.

    Callers who want to distinguish "configure the key" from "the
    backend is broken" catch `SecretNotFoundError` and
    `SecretsBackendError` respectively. Catching `SecretsError` itself
    is appropriate when the caller only cares that *something* went
    wrong retrieving the value.
    """


class SecretNotFoundError(SecretsError):
    """Raised when the requested secret is absent from the store.

    `name` is the caller-supplied key (env var, reference map key, or
    `op://...` reference). Stored as an attribute so callers can
    surface it in their own error messages without re-parsing.

    For well-known credential names (e.g. `ANTHROPIC_API_KEY`,
    `OPENAI_API_KEY`), the message appends the URL where the user obtains
    the key so first-time setup mistakes resolve themselves without a
    docs round-trip. Unknown names get a generic message — the runtime
    does not invent recovery URLs.
    """

    _RECOVERY_URLS: dict[str, str] = {
        "ANTHROPIC_API_KEY": "https://console.anthropic.com/settings/keys",
        "OPENAI_API_KEY": "https://platform.openai.com/api-keys",
    }

    def __init__(self, name: str) -> None:
        self.name = name
        message = f"Secret not found: {name!r}"
        recovery_url = self._RECOVERY_URLS.get(name)
        if recovery_url is not None:
            message = f"{message}. Obtain a key at {recovery_url}"
        super().__init__(message)


class SecretsBackendError(SecretsError):
    """Raised when the secrets backend fails for non-"not found" reasons.

    Covers transport failures, auth errors, CLI timeouts, and malformed
    responses. Adapters SHOULD include the upstream error text in the
    message, but MUST NOT include any secret material.
    """


class ProviderCapabilityError(ZenoError):
    """Raised at `ZenoApp.start()` when the configured `Provider` cannot serve the `Agent`.

    The message lists every capability the Agent requires that the provider
    does not declare (e.g. sub-agents, built-in tools, permission modes).
    Construction with an empty `missing` list is a programmer error and
    raises `ValueError` — we never want a silent "capability error with no
    reasons" surfacing in logs.
    """

    def __init__(self, provider: str, missing: list[str]) -> None:
        if not missing:
            raise ValueError("ProviderCapabilityError requires a non-empty `missing` list")
        self.provider = provider
        self.missing = missing
        missing_fmt = ", ".join(missing)
        super().__init__(f"Provider {provider} cannot run this Agent: {missing_fmt}")
