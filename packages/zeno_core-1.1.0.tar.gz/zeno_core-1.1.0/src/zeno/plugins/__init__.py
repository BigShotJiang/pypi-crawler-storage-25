"""Plugin entry-point discovery and canonical group name constants."""

from __future__ import annotations

from zeno.plugins.discovery import discover, discover_all
from zeno.plugins.groups import (
    ALL_GROUPS,
    ZENO_CHANNELS,
    ZENO_MEMORY_STORES,
    ZENO_PROVIDERS,
    ZENO_SUB_AGENTS,
    ZENO_TOOLS,
    ZENO_VECTORSTORES,
)

__all__ = [
    # Discovery helpers
    "discover",
    "discover_all",
    # Group name constants
    "ALL_GROUPS",
    "ZENO_CHANNELS",
    "ZENO_MEMORY_STORES",
    "ZENO_PROVIDERS",
    "ZENO_SUB_AGENTS",
    "ZENO_TOOLS",
    "ZENO_VECTORSTORES",
]
