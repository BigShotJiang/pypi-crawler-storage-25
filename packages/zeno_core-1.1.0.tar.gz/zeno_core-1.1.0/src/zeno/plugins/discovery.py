"""Plugin entry-point discovery with fail-fast collision detection (R36–R41).

    from zeno.plugins.discovery import discover
    from zeno.plugins.groups import ZENO_CHANNELS

    channels = discover(ZENO_CHANNELS)  # dict[str, EntryPoint]
    CliChannel = channels["cli"].load()

`EntryPointCollisionError` is raised on the first name collision within a
group so the operator sees exactly one actionable error and the offending
distribution names at once. No silent overwrite; no aggregation.
"""

from __future__ import annotations

from importlib.metadata import EntryPoint, entry_points
from typing import TYPE_CHECKING

from zeno.exceptions import EntryPointCollisionError

if TYPE_CHECKING:
    pass


def discover(group: str) -> dict[str, EntryPoint]:
    """Return every entry point in `group` keyed by `.name`.

    Raises `EntryPointCollisionError` on the first duplicate name.
    """
    results: dict[str, EntryPoint] = {}
    seen_dists: dict[str, list[str]] = {}
    for ep in entry_points(group=group):
        dist_name = _dist_name(ep)
        if ep.name in results:
            prior_dist = seen_dists.get(ep.name, ["<unknown>"])[-1]
            raise EntryPointCollisionError(
                group=group,
                name=ep.name,
                dists=[prior_dist, dist_name],
            )
        results[ep.name] = ep
        seen_dists.setdefault(ep.name, []).append(dist_name)
    return results


def discover_all(groups: tuple[str, ...]) -> dict[str, dict[str, EntryPoint]]:
    """Run `discover` across every group, fail-fast on the first collision."""
    return {g: discover(g) for g in groups}


def _dist_name(ep: EntryPoint) -> str:
    dist = getattr(ep, "dist", None)
    if dist is None:
        return "<unknown>"
    name = getattr(dist, "name", None)
    if name is not None:
        return str(name)
    metadata = getattr(dist, "metadata", None)
    if metadata is not None:
        return str(metadata.get("Name", "<unknown>"))
    return "<unknown>"
