"""Canonical entry-point group names for Zeno plugins (R36–R41).

Plugin distributions register under these groups in their `pyproject.toml`:

    [project.entry-points."zeno.channels"]
    cli = "zeno.channels.cli.channel:CliChannel"

    [project.entry-points."zeno.vectorstores"]
    chroma = "zeno.chroma.store:ChromaKnowledgeStore"

`ZenoApp` startup calls `discover(group)` for each known group; collisions
abort with a clear, actionable error listing the conflicting distributions.
"""

from __future__ import annotations

ZENO_CHANNELS = "zeno.channels"
ZENO_VECTORSTORES = "zeno.vectorstores"
ZENO_MEMORY_STORES = "zeno.memory_stores"
ZENO_TOOLS = "zeno.tools"
ZENO_SUB_AGENTS = "zeno.sub_agents"
ZENO_PROVIDERS = "zeno.providers"

ALL_GROUPS: tuple[str, ...] = (
    ZENO_CHANNELS,
    ZENO_VECTORSTORES,
    ZENO_MEMORY_STORES,
    ZENO_TOOLS,
    ZENO_SUB_AGENTS,
    ZENO_PROVIDERS,
)
