"""Pure renderer for the L4 observation system-prompt block.

The renderer turns a list of active `Observation` rows into the stable
Markdown block that sits between the L2 working-memory block and
`compose_system_prompt`'s output (R14, R15). It is a pure free function
with no I/O so unit tests can assert exact byte-equal output across
no-change turns (R16).

Rendering rules:

  - Group by `referenced_date` when set, falling back to
    `observation_date` for the grouping key. Each group has a
    `### YYYY-MM-DD` heading. Groups are emitted oldest-to-newest by the
    group key.
  - Within a group, sort observations by `observation_date` ascending.
    Each line is ``<priority> <HH:MM> <text> (<relative_date>)``.
  - ``<priority>`` is ``🔴``/``🟡``/``🟢`` in emoji mode (default) or
    ``[high]``/``[med]``/``[low]`` in tokens mode.
  - ``<HH:MM>`` is the `observation_date` time-of-day in UTC.
  - ``<relative_date>`` is computed from the per-row date (referenced
    if set, else observation) versus a UTC-day-snapped ``now`` derived
    from ``now_fn()``. Snapping to the start of the UTC day means two
    renders within the same day produce byte-identical output, even
    if ``now_fn()`` returns slightly different timestamps (R16).
  - Header is ``BLOCK_HEADER`` (``## Observations``); group prefix is
    ``GROUP_PREFIX`` (``### ``). The block ends with a trailing blank
    line so the next block can start cleanly.
  - When the input list is empty, the renderer returns ``""`` — the
    handler does not prepend an empty observation block.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import UTC, date, datetime, timedelta
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence


BLOCK_HEADER = "## Observations"
GROUP_PREFIX = "### "

PriorityMarkers = Literal["emoji", "tokens"]

_EMOJI_MARKERS: dict[str, str] = {
    "high": "🔴",
    "medium": "🟡",
    "low": "🟢",
}

_TOKEN_MARKERS: dict[str, str] = {
    "high": "[high]",
    "medium": "[med]",
    "low": "[low]",
}


def render(
    observations: Sequence[Any],
    *,
    priority_markers: PriorityMarkers = "emoji",
    now_fn: Callable[[], int],
) -> str:
    """Return the rendered observation block, or `""` for an empty list.

    ``observations`` is the result of
    ``ObservationView.list_active()`` — already filtered to active rows.
    Each row is read structurally for the attributes ``text``,
    ``priority``, ``observation_date``, and ``referenced_date``; the
    concrete dataclass is ``zeno.memory.protocols.Observation`` but
    the renderer keeps the input ``Any``-typed so ``zeno-core`` does
    not depend on ``zeno-memory``.

    ``now_fn`` returns the current UTC unix timestamp (seconds). The
    renderer snaps it to the start of the UTC day for relative-date
    computation so the rendered block is byte-stable across turns
    within the same day.
    """
    if not observations:
        return ""

    markers = _EMOJI_MARKERS if priority_markers == "emoji" else _TOKEN_MARKERS
    today = _utc_date(now_fn())

    groups: dict[date, list[Any]] = defaultdict(list)
    for obs in observations:
        key_ts = obs.referenced_date if obs.referenced_date is not None else obs.observation_date
        groups[_utc_date(key_ts)].append(obs)

    lines: list[str] = [BLOCK_HEADER]
    for group_day in sorted(groups):
        lines.append(f"{GROUP_PREFIX}{group_day.isoformat()}")
        for obs in sorted(groups[group_day], key=lambda o: o.observation_date):
            marker = markers[obs.priority]
            time_of_day = datetime.fromtimestamp(obs.observation_date, tz=UTC).strftime("%H:%M")
            row_ts = (
                obs.referenced_date if obs.referenced_date is not None else obs.observation_date
            )
            relative = _relative_date(_utc_date(row_ts), today)
            lines.append(f"{marker} {time_of_day} {obs.text} ({relative})")
    lines.append("")
    return "\n".join(lines) + "\n"


def _utc_date(timestamp: int) -> date:
    return datetime.fromtimestamp(timestamp, tz=UTC).date()


def _relative_date(target: date, today: date) -> str:
    """Render ``target`` relative to ``today`` ("today", "N days ago", ...)."""
    if target == today:
        return "today"
    delta = today - target
    if delta == timedelta(days=1):
        return "yesterday"
    if delta < timedelta(days=0):
        # Future date — preserve the absolute "in N days" form rather
        # than emitting a negative count. Observations referencing the
        # future are unusual but possible (e.g. "Niels has a meeting
        # tomorrow").
        ahead = (target - today).days
        if ahead == 1:
            return "tomorrow"
        return f"in {ahead} days"
    days = delta.days
    # Bands chosen to match the plan's reference block (8 days reads as
    # "8 days ago", not "1 week ago"). We promote to weeks at 14 days,
    # to months at 60 days. Coarser units are intentional: an
    # observation that says "5 weeks ago" is a vague timestamp anyway,
    # so the block does not pretend to be precise.
    if days < 14:
        return f"{days} days ago"
    if days < 60:
        weeks = days // 7
        return f"{weeks} week ago" if weeks == 1 else f"{weeks} weeks ago"
    months = days // 30
    return f"{months} month ago" if months == 1 else f"{months} months ago"


__all__ = [
    "BLOCK_HEADER",
    "GROUP_PREFIX",
    "PriorityMarkers",
    "render",
]
