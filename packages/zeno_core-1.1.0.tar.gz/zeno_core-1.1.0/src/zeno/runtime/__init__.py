"""Runtime utilities for Zeno — auto-inject, turn dispatch, and streaming."""

from __future__ import annotations

from zeno.runtime.auto_inject import AutoInjectConfig, compose_system_prompt
from zeno.runtime.streaming import StreamBuffer
from zeno.runtime.tokens import TokenCounter, count_tokens
from zeno.runtime.turn_worker import (
    AgentHandler,
    SendErrorHandler,
    TurnDispatcher,
    TurnErrorHandler,
)

__all__ = [
    # Auto-inject middleware
    "AutoInjectConfig",
    "compose_system_prompt",
    # Streaming
    "StreamBuffer",
    # Tokens
    "TokenCounter",
    "count_tokens",
    # Turn dispatch
    "AgentHandler",
    "SendErrorHandler",
    "TurnDispatcher",
    "TurnErrorHandler",
]
