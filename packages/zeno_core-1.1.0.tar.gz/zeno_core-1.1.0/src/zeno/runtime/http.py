"""Shared `httpx.AsyncClient` factory.

The process-wide HTTP client is owned by the `ZenoApp` and threaded through
turns via `Ctx.http`. Tool authors reach it via `current_ctx().http`; plugin
authors should never instantiate their own.

The factory applies the defaults captured in research:
    Timeout(connect=5, read=60, write=10, pool=5)
    Limits(max_connections=100, max_keepalive_connections=20)

Callers close the client exactly once at app shutdown.
"""

from __future__ import annotations

import httpx

_DEFAULT_TIMEOUT = httpx.Timeout(connect=5.0, read=60.0, write=10.0, pool=5.0)
_DEFAULT_LIMITS = httpx.Limits(max_connections=100, max_keepalive_connections=20)


def create_http_client(
    *,
    timeout: httpx.Timeout | None = None,
    limits: httpx.Limits | None = None,
    headers: dict[str, str] | None = None,
) -> httpx.AsyncClient:
    """Build the app-scoped `httpx.AsyncClient` with Zeno's defaults."""
    return httpx.AsyncClient(
        timeout=timeout if timeout is not None else _DEFAULT_TIMEOUT,
        limits=limits if limits is not None else _DEFAULT_LIMITS,
        headers=headers,
    )
