"""Auto-inject middleware: prepend recalled user-memory facts to the system prompt.

This middleware implements R23/R24 of the v0.1 plan. It runs inside the
agent handler, **before** the provider builds its native options object.
The default handler writes the composed prompt to `ctx.state["composed_prompt"]`
and providers read it from there:

    from zeno.runtime.auto_inject import compose_system_prompt, AutoInjectConfig

    async def handler(ctx, msg):
        sp = await compose_system_prompt(
            ctx, msg.text, agent.instructions, config=AutoInjectConfig()
        )
        ctx.state["composed_prompt"] = sp
        ...

Why a free function and not a `ctx.compose_system_prompt` method? The
context object is a frozen dataclass of request-scoped handles; keeping
this plumbing out of it prevents `Ctx` from growing to include every
compositional helper we ever add. The handler already has `ctx` — one
extra import is the cost of avoiding coupling.

Failure posture: if the memory search raises, the middleware logs via
`ctx.logger` and returns the unmodified base instructions. A flaky
vector store MUST NOT fail the turn; memory is a soft input.
"""

from __future__ import annotations

import contextlib
import hashlib
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from zeno.observability.events import MemoryRead, _Envelope
from zeno.runtime.noop_memory import NoOpMemoryView

if TYPE_CHECKING:
    from zeno.context import Ctx

_LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class AutoInjectConfig:
    """Tunables for auto-inject behavior.

    - `enabled_user`: whether to query `ctx.memory.user`
    - `enabled_knowledge`: whether to query `ctx.memory.knowledge`
      (off by default — knowledge is shared across users and adds cost)
    - `k`: max hits per store
    - `distance_threshold`: max cosine distance for a hit to qualify.
      Stores return similarity scores in `[0, 1]` (1 = identical); we
      treat `score >= 1 - distance_threshold` as "close enough". Helios
      uses `0.35` as its production default.
    """

    enabled_user: bool = True
    enabled_knowledge: bool = False
    k: int = 5
    distance_threshold: float = 0.35


_BLOCK_HEADER = "[CONTEXT — from user memory]"
_BLOCK_FOOTER = "[END CONTEXT]"


async def compose_system_prompt(
    ctx: Ctx,
    inbound_text: str,
    base_instructions: str,
    *,
    config: AutoInjectConfig | None = None,
) -> str:
    """Return `base_instructions` with a recalled-memory block prepended.

    Prepends nothing when:
      - `config.enabled_user` is False and `config.enabled_knowledge` is False
      - the store returns no hits that pass `distance_threshold`
      - the store raises (failure is logged, not propagated)
    """
    cfg = config or AutoInjectConfig()
    lines: list[str] = []

    if cfg.enabled_user:
        lines.extend(await _safe_collect(ctx, "user", inbound_text, cfg))
    if cfg.enabled_knowledge:
        lines.extend(await _safe_collect(ctx, "knowledge", inbound_text, cfg))

    if not lines:
        return base_instructions

    block = "\n".join([_BLOCK_HEADER, *lines, _BLOCK_FOOTER])
    return f"{block}\n\n{base_instructions}"


_AUTOINJECT_STORE: dict[str, str] = {
    "user": "user_memory",
    "knowledge": "knowledge",
}


async def _safe_collect(ctx: Ctx, store_name: str, query: str, cfg: AutoInjectConfig) -> list[str]:
    """Call the named memory view's `search`; return `- text` lines or `[]`."""
    view = getattr(ctx.memory, store_name, None)
    if view is None:  # memory view not wired in — silently skip.
        return []
    try:
        hits = await view.search(query, k=cfg.k)
    except Exception as exc:  # noqa: BLE001
        log = ctx.logger if ctx.logger is not None else _LOGGER
        log.warning("auto-inject: %s.search failed; skipping block: %s", store_name, exc)
        return []

    _emit_memory_read(ctx, _AUTOINJECT_STORE.get(store_name, store_name), query, len(hits))

    threshold = 1.0 - cfg.distance_threshold
    lines: list[str] = []
    for hit in hits:
        if hit.score >= threshold:
            lines.append(f"- {hit.text}")
    return lines


def _emit_memory_read(ctx: Ctx, store: str, query: str, result_count: int) -> None:
    if ctx.tracer is None or isinstance(ctx.memory, NoOpMemoryView):
        return
    query_hash = hashlib.sha256(query.encode("utf-8")).hexdigest()[:12]
    with contextlib.suppress(Exception):
        ctx.tracer.on_event(
            MemoryRead(
                envelope=_Envelope(
                    turn_id=ctx.turn_id,
                    sequence=0,
                    user_id=ctx.user_id,
                    session_id=ctx.session_id,
                ),
                store=store,
                query_hash=query_hash,
                result_count=result_count,
            )
        )
