"""Pure renderer for the L2 working-memory system-prompt block.

The renderer turns the agent's `working_memory_schema` and a snapshot of
its persisted fields into a stable Markdown block that prepends the
existing `compose_system_prompt` output (R11). It is deliberately a free
function with no I/O so unit tests can assert exact byte-equal output
across no-change turns (R14).

Rendering rules:
  - Field order = ``schema.model_fields.keys()`` (Pydantic preserves
    declaration order). Never sort by update time.
  - One bullet per field: ``- {name}: {value}`` followed by an
    ``(updated YYYY-MM-DD)`` suffix when the field has a record. Unset
    fields render as ``- {name}: (unknown)`` with no suffix (R12, R13).
  - Header is the module constant `BLOCK_HEADER`; the block ends with a
    trailing blank line so the next block can start cleanly.
  - When `schema is None`, the renderer returns an empty string — agents
    without a declared schema see no block (R15 keep-it-off-by-default).
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pydantic import BaseModel
    from zeno.memory.protocols import WorkingMemoryRecord


BLOCK_HEADER = "## Working memory"


def render(
    schema: type[BaseModel] | None,
    records: dict[str, WorkingMemoryRecord],
) -> str:
    """Return the rendered working-memory block, or `""` when no schema is set."""
    if schema is None:
        return ""

    lines: list[str] = [BLOCK_HEADER]
    for field_name in schema.model_fields:
        record = records.get(field_name)
        if record is None or record.value == "":
            lines.append(f"- {field_name}: (unknown)")
        else:
            day = datetime.fromtimestamp(record.last_updated, tz=UTC).strftime("%Y-%m-%d")
            lines.append(f"- {field_name}: {record.value} (updated {day})")
    lines.append("")
    return "\n".join(lines) + "\n"
