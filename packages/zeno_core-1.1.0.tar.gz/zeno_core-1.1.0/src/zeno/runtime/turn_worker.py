"""Per-thread FIFO turn worker.

Each `(user_id, thread_key)` key gets a dedicated async worker that drains
messages in arrival order. Different keys process concurrently. Keys with
no pending messages are reaped.

The worker owns:
  - `Ctx` construction for the turn (user_id, session_id, channel, memory, http, tracer, logger)
  - the channel-bound `reply` / `stream` / `finalize` callables plumbed onto `Ctx`
  - delegation into the user-supplied agent handler under `bind_ctx`
  - auto-finalization of any unsealed `StreamBuffer` at turn end
  - `on_turn_error` / `on_send_failure` policy dispatch

The agent handler is a `Callable[[Ctx, IncomingMessage], Awaitable[None]]`
supplied by the app (typically wrapping `ClaudeSDKClient` construction
inside the `bind_ctx` scope — see the `ZenoApp` docstring for the
ContextVar-propagation invariant).
"""

from __future__ import annotations

import asyncio
import contextlib
import sys
import traceback
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from zeno.channels.messages import IncomingMessage, OutgoingMessage
from zeno.channels.protocol import Channel
from zeno.context import Ctx, bind_ctx
from zeno.runtime.streaming import StreamBuffer

AgentHandler = Callable[[Ctx, IncomingMessage], Awaitable[None]]
TurnErrorHandler = Callable[[Ctx, IncomingMessage, BaseException], Awaitable[None]]
SendErrorHandler = Callable[[Channel, OutgoingMessage, BaseException], Awaitable[None]]
TurnCompleteHook = Callable[[Ctx, IncomingMessage, str], Awaitable[None]]
"""Fires after a successful turn with the assistant's full text.

Spawned fire-and-forget so it never delays the user-facing reply, but
tracked by `TurnDispatcher` so `drain_all()` can await pending hooks
during shutdown. Errors are caught and logged; a hook crash never
affects the conversation.

The third argument is whatever the handler streamed via `ctx.stream(...)`
joined into one string. It is **empty** when the handler replied via
`ctx.reply(OutgoingMessage(...))` without streaming — hook implementations
should treat empty text as a no-op rather than assume non-empty content.

Wired by `ZenoApp` to drive `ObservationalMemory.maybe_observe_and_reflect`
in production, but the seam is generic — operators can plug analytics,
custom logging, or any post-turn side effect without touching the
worker."""


@dataclass
class _ThreadWorker:
    """FIFO queue + driver coroutine for one `(user_id, thread_key)` key."""

    key: tuple[str, str | None]
    queue: asyncio.Queue[tuple[Channel, IncomingMessage]] = field(default_factory=asyncio.Queue)
    task: asyncio.Task[None] | None = None


class TurnDispatcher:
    """Routes incoming messages to per-thread FIFO workers."""

    def __init__(
        self,
        *,
        agent_handler: AgentHandler,
        ctx_factory: Callable[[Channel, IncomingMessage], Ctx],
        on_turn_error: TurnErrorHandler | None = None,
        on_send_failure: SendErrorHandler | None = None,
        on_turn_complete: TurnCompleteHook | None = None,
        on_turn_complete_timeout: float | None = 60.0,
    ) -> None:
        self._handler = agent_handler
        self._ctx_factory = ctx_factory
        self._on_turn_error = on_turn_error or _default_turn_error_reply
        self._on_send_failure = on_send_failure
        self._on_turn_complete = on_turn_complete
        self._on_turn_complete_timeout = on_turn_complete_timeout
        self._workers: dict[tuple[str, str | None], _ThreadWorker] = {}
        # Tracks fire-and-forget post-turn hooks so `drain_all()` can wait
        # for them at shutdown — without a reference, asyncio will GC the
        # task and silently cancel it.
        self._pending_hooks: set[asyncio.Task[None]] = set()
        self._tg: asyncio.TaskGroup | None = None

    def bind_taskgroup(self, tg: asyncio.TaskGroup) -> None:
        self._tg = tg

    async def enqueue(self, channel: Channel, msg: IncomingMessage) -> None:
        key = (msg.user_id, msg.thread_key)
        worker = self._workers.get(key)
        if worker is None:
            worker = _ThreadWorker(key=key)
            self._workers[key] = worker
            worker.task = asyncio.create_task(self._drain(worker))
        await worker.queue.put((channel, msg))

    async def drain_all(self) -> None:
        """Wait for every worker queue to empty, then cancel driver tasks.

        Also awaits any in-flight post-turn hooks (e.g. memory extraction)
        so they finish their writes before the process exits.
        """
        for worker in list(self._workers.values()):
            await worker.queue.join()
        for worker in list(self._workers.values()):
            if worker.task is not None:
                worker.task.cancel()
        for worker in list(self._workers.values()):
            if worker.task is not None:
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await worker.task
        self._workers.clear()
        # Drain pending post-turn hooks (suppress per-task errors so one
        # bad hook does not block shutdown of the rest).
        if self._pending_hooks:
            pending = list(self._pending_hooks)
            for task in pending:
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await task
            self._pending_hooks.clear()

    async def _drain(self, worker: _ThreadWorker) -> None:
        while True:
            channel, msg = await worker.queue.get()
            try:
                await self._run_turn(channel, msg)
            finally:
                worker.queue.task_done()

    async def _run_turn(self, channel: Channel, msg: IncomingMessage) -> None:
        buffer = StreamBuffer(
            channel=channel,
            reply_to_thread_key=msg.thread_key,
        )

        async def _stream(chunk: str) -> None:
            await buffer.emit_chunk(chunk)

        async def _finalize() -> None:
            await buffer.finalize()

        async def _reply(reply_msg: Any) -> None:
            await buffer.finalize()
            try:
                await channel.send(reply_msg)
            except Exception as exc:  # noqa: BLE001
                if self._on_send_failure is not None:
                    await self._on_send_failure(channel, reply_msg, exc)
                else:
                    raise

        ctx = self._ctx_factory(channel, msg)
        ctx = _rebind_ctx(ctx, reply=_reply, stream=_stream, finalize=_finalize)

        handler_succeeded = False
        try:
            with bind_ctx(ctx):
                await self._handler(ctx, msg)
            handler_succeeded = True
        except Exception as exc:  # noqa: BLE001
            _log_turn_error(ctx, exc)
            await self._on_turn_error(ctx, msg, exc)
        finally:
            if not buffer.is_finalized:
                with contextlib.suppress(Exception):
                    await buffer.finalize()

        # Spawn the post-turn hook AFTER the buffer is finalized so the
        # final assistant text is fully captured. Only fires on success —
        # a failed turn produces nothing useful to extract.
        if handler_succeeded and self._on_turn_complete is not None:
            self._spawn_turn_complete_hook(ctx, msg, buffer.buffered_text)

    def _spawn_turn_complete_hook(
        self, ctx: Ctx, msg: IncomingMessage, assistant_text: str
    ) -> None:
        hook = self._on_turn_complete
        if hook is None:
            return  # pragma: no cover — guarded by caller
        timeout = self._on_turn_complete_timeout

        async def _run() -> None:
            try:
                if timeout is None:
                    await hook(ctx, msg, assistant_text)
                else:
                    await asyncio.wait_for(hook(ctx, msg, assistant_text), timeout=timeout)
            except TimeoutError:
                _log_hook_warning(ctx, f"on_turn_complete hook exceeded {timeout}s timeout")
            except Exception as exc:  # noqa: BLE001
                _log_hook_error(ctx, exc)

        task = asyncio.create_task(_run(), name=f"zeno.turn_complete:{ctx.turn_id}")
        self._pending_hooks.add(task)
        task.add_done_callback(self._pending_hooks.discard)


def _rebind_ctx(
    ctx: Ctx,
    *,
    reply: Callable[[Any], Awaitable[None]],
    stream: Callable[[str], Awaitable[None]],
    finalize: Callable[[], Awaitable[None]],
) -> Ctx:
    """Return a new `Ctx` with channel-bound callbacks substituted."""
    return Ctx(
        user_id=ctx.user_id,
        session_id=ctx.session_id,
        channel=ctx.channel,
        memory=ctx.memory,
        reply=reply,
        stream=stream,
        finalize=finalize,
        http=ctx.http,
        logger=ctx.logger,
        tracer=ctx.tracer,
        state=ctx.state,
        thread_key=ctx.thread_key,
        secrets=ctx.secrets,
        turn_id=ctx.turn_id,
    )


async def _default_turn_error_reply(ctx: Ctx, msg: IncomingMessage, exc: BaseException) -> None:
    """Default error policy: send an apology reply and log."""
    # Best-effort — the send-failure handler (if any) already ran.
    with contextlib.suppress(Exception):
        await ctx.reply(
            OutgoingMessage(
                text="Sorry — something went wrong handling that message.",
                reply_to_thread_key=msg.thread_key,
            )
        )


def _log_turn_error(ctx: Ctx, exc: BaseException) -> None:
    """Log the original exception with full traceback before delegating to `on_turn_error`.

    Runs unconditionally so a developer pasting the hello-world snippet
    without wiring `on_turn_error` still sees the failing line in their
    terminal. Prefers `ctx.logger` when configured; falls back to
    `traceback.print_exception` on stderr so the trace appears even if
    logging is not configured.
    """
    if ctx.logger is not None:
        try:
            ctx.logger.error("Turn handler raised", exc_info=exc)
            return
        except Exception:  # noqa: BLE001
            pass
    traceback.print_exception(type(exc), exc, exc.__traceback__, file=sys.stderr)


def _log_hook_error(ctx: Ctx, exc: BaseException) -> None:
    """Log a post-turn hook failure without ever propagating."""
    if ctx.logger is not None:
        try:
            ctx.logger.error("Post-turn hook raised", exc_info=exc)
            return
        except Exception:  # noqa: BLE001
            pass
    traceback.print_exception(type(exc), exc, exc.__traceback__, file=sys.stderr)


def _log_hook_warning(ctx: Ctx, message: str) -> None:
    """Log a post-turn hook warning (e.g. timeout) without propagating."""
    if ctx.logger is not None:
        try:
            ctx.logger.warning(message)
            return
        except Exception:  # noqa: BLE001
            pass
    print(f"WARNING: {message}", file=sys.stderr)
