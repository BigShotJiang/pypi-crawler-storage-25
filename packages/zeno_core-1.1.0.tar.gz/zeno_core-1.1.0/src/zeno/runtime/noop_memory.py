"""`NoOpMemoryView` — default memory view for stateless `ZenoApp`.

Constructed by `ZenoApp` when `memory=` is omitted, satisfying the
non-optional `Ctx.memory` invariant without forcing the user to wire any
storage. Every search returns `[]`, every write is a no-op, and the
`conversation` handle returns no prior messages.

Internal default: not exported from `zeno-core`'s public API.
"""

from __future__ import annotations

from typing import Any

from zeno.protocols.memory import (
    KnowledgeViewProtocol,
    MemoryHit,
    MemoryTier,
    ObservationViewProtocol,
    UserMemoryViewProtocol,
    WorkingMemoryViewProtocol,
)


class _NoOpUserView:
    async def search(self, query: str, k: int = 5) -> list[MemoryHit]:
        return []

    async def add(
        self,
        text: str,
        meta: dict[str, Any] | None = None,
        *,
        tier: MemoryTier = "long",
    ) -> None:
        return None


class _NoOpKnowledgeView:
    async def search(self, query: str, k: int = 5) -> list[MemoryHit]:
        return []

    async def add(self, text: str, meta: dict[str, Any] | None = None) -> None:
        return None


class _NoOpConversation:
    async def load(self) -> list[Any]:
        return []

    async def append(self, messages: Any) -> None:
        return None


class _NoOpWorkingMemory:
    async def get(self) -> dict[str, Any]:
        return {}

    async def update(self, patch: dict[str, str]) -> None:
        return None

    async def clear(self) -> None:
        return None


class _NoOpObservationLog:
    async def list_active(self) -> list[Any]:
        return []


class NoOpMemoryView:
    """Empty `MemoryViewProtocol` impl used when no memory binder is configured."""

    def __init__(self) -> None:
        self.user: UserMemoryViewProtocol = _NoOpUserView()
        self.knowledge: KnowledgeViewProtocol = _NoOpKnowledgeView()
        self.session: Any = None
        self.conversation: _NoOpConversation = _NoOpConversation()
        self.working_memory: WorkingMemoryViewProtocol = _NoOpWorkingMemory()
        self.observation_log: ObservationViewProtocol = _NoOpObservationLog()
