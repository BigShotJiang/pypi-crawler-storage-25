"""Tool name conventions shared across providers.

The canonical Zeno tool name as seen by an LLM-side allow-list is
``mcp__<server_key>__<tool_name>``. This format is consumed verbatim by
the Claude Agent SDK and ignored (or remapped) by other providers, but
keeping it in core means provider adapters do not each invent their
own naming scheme.

Wrapping a `ToolSpec` into a provider-specific tool object lives in the
provider package — see e.g. `zeno-provider-claude`'s `_mcp.to_sdk_tool`.
"""

from __future__ import annotations

from zeno.tool import ToolSpec


def allowed_tool_names(server_key: str, specs: list[ToolSpec]) -> list[str]:
    """Return the `mcp__<server>__<tool>` names the SDK expects in `allowed_tools`."""
    return [f"mcp__{server_key}__{spec.name}" for spec in specs]
