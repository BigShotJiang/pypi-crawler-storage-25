"""Default turn handler — composes system prompt then dispatches to the provider.

The v0.3.0 replacement for the user-supplied ``agent_handler`` seam. `ZenoApp.run()`
wires `make_default_handler(...)` into `TurnDispatcher` as the `AgentHandler`. The
handler is a tiny closure:

1. Render the L2 working-memory block (when an `agent.working_memory_schema` is set).
2. Render the L4 observation block (when `observational_memory=` is wired and the
   per-turn `ctx.memory.observation_log.list_active()` returns rows).
3. Call `compose_system_prompt(ctx, msg.text, agent.instructions, config=auto_inject)`.
4. Concatenate ``wm_block + obs_block + compose_output`` and write it into
   ``ctx.state["composed_prompt"]`` — a well-known key providers read (see `Provider`
   protocol docstring). Providers MUST NOT mutate it.
5. Invoke `provider.run_turn(...)` wrapped in `asyncio.wait_for(..., turn_timeout)` so a
   wedged provider cannot block the per-thread FIFO forever (KD11). A timeout raises
   `asyncio.TimeoutError`, which the turn worker catches as `on_turn_error`.

Kept as a free factory (not a `ZenoApp` method) so `TurnDispatcher` keeps its
existing `agent_handler: AgentHandler` seam — unit tests can substitute a different
handler without reaching into `ZenoApp`.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING

from zeno.runtime.auto_inject import AutoInjectConfig, compose_system_prompt
from zeno.runtime.observation_block import render as render_observation_block
from zeno.runtime.working_memory_block import render as render_working_memory_block

if TYPE_CHECKING:
    from zeno.agent import Agent
    from zeno.channels.messages import IncomingMessage
    from zeno.context import Ctx
    from zeno.providers.protocol import Provider
    from zeno.runtime.observation_block import PriorityMarkers
    from zeno.runtime.turn_worker import AgentHandler


_LOGGER = logging.getLogger(__name__)


def make_default_handler(
    *,
    agent: Agent,
    provider: Provider,
    auto_inject: AutoInjectConfig | None = None,
    turn_timeout: float = 120.0,
    observation_priority_markers: PriorityMarkers | None = None,
) -> AgentHandler:
    """Build the closure wired into `TurnDispatcher` as `agent_handler`.

    ``observation_priority_markers`` selects the priority style for the
    L4 observation block. ``None`` (default) means "no observation block";
    `ZenoApp` resolves the orchestrator's ``priority_markers`` at run time
    and threads it through here so the renderer stays decoupled from
    `zeno-memory`.
    """
    cfg = auto_inject or AutoInjectConfig()

    async def handler(ctx: Ctx, msg: IncomingMessage) -> None:
        wm_block = await _safe_render_working_memory(ctx, agent)
        obs_block = await _safe_render_observations(ctx, observation_priority_markers)
        composed = await compose_system_prompt(ctx, msg.text, agent.instructions, config=cfg)
        prefix = wm_block + obs_block
        if prefix:
            composed = prefix + "\n" + composed
        ctx.state["composed_prompt"] = composed
        await asyncio.wait_for(
            provider.run_turn(agent=agent, ctx=ctx, msg=msg), timeout=turn_timeout
        )

    return handler


async def _safe_render_working_memory(ctx: Ctx, agent: Agent) -> str:
    """Read working memory and render the prompt block; on failure, return ``""``.

    Working memory is a soft input. A flaky store MUST NOT fail the turn —
    the renderer logs and yields an empty block, mirroring the auto-inject
    posture (`compose_system_prompt`'s `_safe_collect`).
    """
    if agent.working_memory_schema is None:
        return ""
    try:
        records = await ctx.memory.working_memory.get()
    except Exception as exc:  # noqa: BLE001
        log = ctx.logger if ctx.logger is not None else _LOGGER
        log.warning("working-memory: get failed; skipping block: %s", exc)
        return ""
    return render_working_memory_block(agent.working_memory_schema, records)


async def _safe_render_observations(ctx: Ctx, priority_markers: PriorityMarkers | None) -> str:
    """Read active observations and render the L4 block; on failure, return ``""``.

    Observations are a soft input — a flaky store MUST NOT fail the turn.
    Returns ``""`` when `observation_priority_markers` is ``None`` (no
    observational memory wired) or when `list_active()` raises / yields
    no rows.
    """
    if priority_markers is None:
        return ""
    try:
        rows = await ctx.memory.observation_log.list_active()
    except Exception as exc:  # noqa: BLE001
        log = ctx.logger if ctx.logger is not None else _LOGGER
        log.warning("observations: list_active failed; skipping block: %s", exc)
        return ""
    if not rows:
        return ""
    return render_observation_block(rows, priority_markers=priority_markers, now_fn=_now_unix)


def _now_unix() -> int:
    return int(time.time())
