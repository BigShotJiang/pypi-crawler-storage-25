"""Per-turn streaming buffer + channel fan-out.

Core invariant: one in-flight `StreamBuffer` per
`(channel.name, user_id, thread_key)` — the same key the turn worker uses
to serialize turns. That means two sequential turns on the same thread never
race their streams, and two concurrent threads fan out in parallel.

Streaming-capable channels receive partial `OutgoingMessage(text=chunk)`
envelopes as `stream(chunk)` fires. Non-streaming channels wait for
`finalize()` and receive one consolidated `OutgoingMessage` with the full
concatenated text.

`reply(msg)` mid-stream implicitly finalizes the partial stream first, then
emits the explicit message. The turn worker also auto-finalizes unsealed
buffers when a turn ends.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from zeno.channels.messages import OutgoingMessage
from zeno.channels.protocol import Channel


@dataclass
class StreamBuffer:
    """Accumulator for one in-flight stream keyed to (channel, user, thread)."""

    channel: Channel
    reply_to_thread_key: str | None = None
    _parts: list[str] = field(default_factory=list, repr=False)
    _finalized: bool = False

    async def emit_chunk(self, chunk: str) -> None:
        if self._finalized:
            return
        self._parts.append(chunk)
        if self.channel.capabilities.supports_streaming:
            await self.channel.send(
                OutgoingMessage(
                    text=chunk,
                    reply_to_thread_key=self.reply_to_thread_key,
                )
            )

    async def finalize(self) -> None:
        if self._finalized:
            return
        self._finalized = True
        if self.channel.capabilities.supports_streaming:
            # Streaming channels already received each chunk; the final envelope
            # is a no-op for them unless the channel wants a terminal marker.
            return
        full = "".join(self._parts)
        if not full:
            return
        await self.channel.send(
            OutgoingMessage(
                text=full,
                reply_to_thread_key=self.reply_to_thread_key,
            )
        )

    @property
    def is_finalized(self) -> bool:
        return self._finalized

    @property
    def buffered_text(self) -> str:
        return "".join(self._parts)
