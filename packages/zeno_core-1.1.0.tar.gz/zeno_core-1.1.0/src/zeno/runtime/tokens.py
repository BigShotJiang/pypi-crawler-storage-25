"""Token-counting helper for threshold checks in observational memory.

The default `count_tokens` is a cheap heuristic (`len(text) // 4`) that
approximates token count for English-prose-like text. It may be off by
~30% on code-heavy or non-English inputs. For accuracy at scale, pass a
tokenizer-backed `TokenCounter` (e.g. `tiktoken`) into
`ObservationalMemory`.
"""

from __future__ import annotations

from collections.abc import Callable

TokenCounter = Callable[[str], int]


def count_tokens(text: str) -> int:
    """Return an approximate token count for `text` using a 4-chars-per-token heuristic."""
    if not text:
        return 0
    return max(1, len(text) // 4)


__all__ = ["TokenCounter", "count_tokens"]
