"""The `Channel` Protocol + `Capabilities` contract (R27, R30, R31, R33).

Every channel plugin (CLI, iMessage, Slack, etc.) implements `Channel`.
Core treats channels through this protocol only — transport is the channel's
responsibility, including HTTP if needed. Core never imports FastAPI or
knows anything about webhooks.

`Capabilities` describes what the channel can handle; the turn worker uses
it to decide whether to stream tokens, send typing indicators, split long
replies, etc. Defaults are the lowest common denominator so missing a
capability never silently breaks a channel.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from zeno.channels.messages import IncomingMessage, OutgoingMessage


@dataclass(frozen=True, slots=True)
class Capabilities:
    """Static capability descriptor a channel publishes to core."""

    supports_threading: bool = False
    supports_images: bool = False
    supports_audio: bool = False
    supports_streaming: bool = False
    supports_reactions: bool = False
    supports_typing: bool = False
    max_message_length: int | None = None


@runtime_checkable
class Channel(Protocol):
    """Contract every channel plugin must satisfy.

    **Authenticity contract:** Channels are the trust boundary for
    ``IncomingMessage.user_id``. Core and every ``(user_id, thread_key)``-
    keyed subsystem downstream (memory binder, scheduler, browser session
    pool, etc.) treats ``user_id`` as authentic — isolation of sessions,
    conversation history, and browser cookies all rely on it. Channels
    must derive ``user_id`` from an authenticated source (verified
    signatures, OAuth identity, trusted handle) and must not accept
    client-asserted identities. A channel that lets a caller forge
    ``user_id`` breaks every downstream isolation guarantee.
    """

    @property
    def name(self) -> str:
        """Stable identifier surfaced on `Ctx.channel` and used for routing."""

    @property
    def capabilities(self) -> Capabilities:
        """Static capability descriptor. Real channels typically return a constant."""

    async def start(self) -> None:
        """Begin accepting inbound traffic (open sockets, subscribe, poll)."""

    async def stop(self) -> None:
        """Drain and shut down; must be idempotent."""

    def receive(self) -> AsyncIterator[IncomingMessage]:
        """Yield incoming messages; awaited for the lifetime of the app."""

    async def send(self, message: OutgoingMessage) -> None:
        """Deliver an outgoing message to the wire."""

    # NOTE: `inbound_put(self, message: IncomingMessage) -> None` is an
    # OPTIONAL extension method used by zeno-scheduler to inject synthetic
    # messages (proactive triggers) into a channel's receive() path.
    # It is NOT part of the required Protocol so that existing third-party
    # channels do not need to implement it; `runtime_checkable` isinstance
    # checks would break if it were declared here as an abstract member.
    # The scheduler detects support via `hasattr(channel, "inbound_put")`.
    # Channels that want to support proactive triggers must implement:
    #
    #   async def inbound_put(self, message: IncomingMessage) -> None: ...
    #
    # First-party channels that implement this: CliChannel, SendblueChannel.
