"""Incoming / outgoing message types exchanged between channels and core (R27, R30, R31, R33).

Channel plugins translate wire-format events (iMessage JSON, CLI keystrokes,
Slack Events API payloads, etc.) into `IncomingMessage` and push them into
`Channel.receive()`. Core then translates the turn result into an
`OutgoingMessage` and calls `Channel.send(...)`.

`thread_key` is always `str | None` — never `""`. Empty strings coming in
from a channel collapse to `None` so turn workers can key `(user_id, thread_key)`
cleanly without worrying about "empty thread" vs "no thread".

`user_id` must always be a non-empty string; a missing user is a channel bug
and should fail loudly.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Literal


@dataclass(frozen=True, slots=True)
class Attachment:
    """Inline attachment (image, file) sent to or from a channel."""

    kind: Literal["image", "audio", "file"]
    url: str | None = None
    data: bytes | None = None
    mime_type: str | None = None
    filename: str | None = None


@dataclass(frozen=True, slots=True)
class MessageBlock:
    """Optional rich content block — channels may ignore unsupported types."""

    kind: Literal["text", "markdown", "code", "quote", "divider"]
    text: str | None = None
    language: str | None = None


def _normalize_thread_key(value: str | None) -> str | None:
    if value is None:
        return None
    stripped = value.strip()
    return stripped or None


@dataclass(frozen=True, slots=True)
class IncomingMessage:
    """A message received from a channel."""

    user_id: str
    text: str
    received_at: datetime
    thread_key: str | None = None
    blocks: list[MessageBlock] = field(default_factory=list)
    attachments: list[Attachment] = field(default_factory=list)
    raw: Any = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.user_id:
            raise ValueError("IncomingMessage.user_id must be a non-empty string")
        object.__setattr__(self, "thread_key", _normalize_thread_key(self.thread_key))


@dataclass(frozen=True, slots=True)
class OutgoingMessage:
    """A message the runtime asks a channel to deliver."""

    text: str | None = None
    blocks: list[MessageBlock] | None = None
    attachments: list[Attachment] | None = None
    reply_to_thread_key: str | None = None
    suggested_replies: list[str] | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "reply_to_thread_key",
            _normalize_thread_key(self.reply_to_thread_key),
        )
