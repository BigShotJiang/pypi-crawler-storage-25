"""The per-turn `Ctx` and its ContextVar plumbing (R13, R14, R15, R16).

Every tool, agent handler, and memory view inside a running turn reaches
its `Ctx` through `current_ctx()`. `bind_ctx()` sets the ContextVar for
the duration of a `with` block and resets it on exit — matching the
helios `set_current_turn` / `reset_current_turn` pattern.

`Ctx` is frozen (`dataclass(frozen=True, slots=True)`) so callers cannot
reassign the user-identity or memory handles mid-turn. `Ctx.state` is a
mutable `dict[str, Any]` — the field reference is immutable, but its
contents may be mutated in place (e.g. `ctx.state["myplugin.cache"] = ...`).
Plugins should namespace their keys (`"myplugin.mykey"`).

`turn_id` is the per-turn identity carried on every observability event
emitted while the turn is bound. The runtime mints it once per inbound
message in `TurnDispatcher`; the field's `default_factory` mints a fresh
hex string when an ad-hoc `Ctx` is built (test fixtures, scripts) so the
field is never empty.
"""

from __future__ import annotations

import uuid
from collections.abc import Awaitable, Callable, Iterator
from contextlib import contextmanager
from contextvars import ContextVar, Token
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from zeno.secrets import EnvSecretsStore

if TYPE_CHECKING:
    import httpx
    from zeno.protocols.memory import MemoryViewProtocol
    from zeno.protocols.secrets import SecretsStore

__all__ = [
    "Ctx",
    "FinalizeCallable",
    "ReplyCallable",
    "StreamCallable",
    "bind_ctx",
    "current_ctx",
]

# Typed aliases for the turn-scoped callbacks the runtime installs on `Ctx`.
# They accept `Any` for message payloads so `zeno-core` does not need to
# import `OutgoingMessage` from `zeno/channels/messages.py` here (Unit 6).
ReplyCallable = Callable[[Any], Awaitable[None]]
StreamCallable = Callable[[str], Awaitable[None]]
FinalizeCallable = Callable[[], Awaitable[None]]


@dataclass(frozen=True, slots=True)
class Ctx:
    """The per-turn context bound into a ContextVar at turn entry.

    Passed as the first positional argument to every `@tool`-decorated
    function. Tools should treat every field as read-only except
    `state`, whose contents are mutable.
    """

    user_id: str
    session_id: str | None
    channel: str
    memory: MemoryViewProtocol
    reply: ReplyCallable
    stream: StreamCallable
    finalize: FinalizeCallable
    http: httpx.AsyncClient
    logger: Any
    tracer: Any
    state: dict[str, Any] = field(default_factory=dict)
    thread_key: str | None = None
    secrets: SecretsStore = field(default_factory=EnvSecretsStore)
    turn_id: str = field(default_factory=lambda: uuid.uuid4().hex)


_CTX_VAR: ContextVar[Ctx] = ContextVar("zeno_ctx")


def current_ctx() -> Ctx:
    """Return the `Ctx` bound to the current task, or raise `LookupError`.

    Fail-loudly on miss: we never want a tool silently picking up a stale
    or default context. Callers that might legitimately run outside a turn
    should wrap this in `try: ... except LookupError:`.
    """
    return _CTX_VAR.get()


@contextmanager
def bind_ctx(ctx: Ctx) -> Iterator[Ctx]:
    """Bind `ctx` to the current async context for the duration of the `with` block.

    Resets the ContextVar on exit via the token returned by `set()`. Nested
    binds are supported: inner mutations to `ctx.state` do not leak out
    once the inner block exits, because the outer block's `Ctx` instance
    is restored.
    """
    token: Token[Ctx] = _CTX_VAR.set(ctx)
    try:
        yield ctx
    finally:
        _CTX_VAR.reset(token)
