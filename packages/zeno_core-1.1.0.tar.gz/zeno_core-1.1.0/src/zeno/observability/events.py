"""Typed trace events emitted by the runtime and consumed by `Tracer` (R47, R48).

Each event carries a small envelope (`turn_id`, `sequence`, `emitted_at`,
`user_id`, `session_id`) plus event-specific fields. Events are emitted via
`Tracer.on_event(event)` from within the turn worker, hook bridge, and
policy layer.

Design constraints:
  - Events are plain frozen dataclasses — cheap to build, easy to serialize.
  - No inheritance hierarchy beyond the `TraceEvent` union; keeps pattern
    matching obvious for consumers.
  - Sensitive payload (prompt text, tool arguments, memory contents) is
    **never** stored on the event by default. A consumer that wants
    content-level tracing opts in by setting `ZENO_TRACE_CONTENT=1`, which
    the `StdoutTracer` honors.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

EventKind = str


def _utcnow() -> datetime:
    return datetime.now(UTC)


@dataclass(frozen=True, slots=True)
class _Envelope:
    """Fields carried by every event. Events inherit via composition."""

    turn_id: str
    sequence: int
    user_id: str | None
    session_id: str | None
    emitted_at: datetime = field(default_factory=_utcnow)


@dataclass(frozen=True, slots=True)
class TurnStarted:
    envelope: _Envelope
    channel: str
    thread_key: str | None
    kind: EventKind = "turn_started"


@dataclass(frozen=True, slots=True)
class TurnCompleted:
    envelope: _Envelope
    duration_ms: int
    kind: EventKind = "turn_completed"


@dataclass(frozen=True, slots=True)
class TurnFailed:
    envelope: _Envelope
    error_type: str
    error_message: str
    kind: EventKind = "turn_failed"


@dataclass(frozen=True, slots=True)
class ToolCallStarted:
    envelope: _Envelope
    tool_name: str
    tool_use_id: str | None
    kind: EventKind = "tool_call_started"


@dataclass(frozen=True, slots=True)
class ToolCallCompleted:
    envelope: _Envelope
    tool_name: str
    tool_use_id: str | None
    duration_ms: int | None
    error: bool = False
    kind: EventKind = "tool_call_completed"


@dataclass(frozen=True, slots=True)
class SubAgentStarted:
    envelope: _Envelope
    sub_agent_name: str
    kind: EventKind = "sub_agent_started"


@dataclass(frozen=True, slots=True)
class SubAgentCompleted:
    envelope: _Envelope
    sub_agent_name: str
    duration_ms: int | None
    error: bool = False
    kind: EventKind = "sub_agent_completed"


@dataclass(frozen=True, slots=True)
class MemoryRead:
    envelope: _Envelope
    store: str  # "session" | "user_memory" | "knowledge"
    query_hash: str | None  # sha256(query)[:12], not the raw query — see SECURITY.md
    result_count: int
    kind: EventKind = "memory_read"


@dataclass(frozen=True, slots=True)
class MemoryWrite:
    envelope: _Envelope
    store: str
    kind: EventKind = "memory_write"


@dataclass(frozen=True, slots=True)
class WorkingMemoryUpdated:
    """Emitted after `update_working_memory` writes one or more fields (R10).

    `agent_id` is the active agent's ``Agent.name`` — the working-memory
    namespace key. `fields_updated` lists the schema fields touched by
    the patch in the order the tool body forwarded them; an empty tuple
    is well-formed but the tool body never emits one (no-op patches
    short-circuit before the write path).
    """

    envelope: _Envelope
    agent_id: str
    fields_updated: tuple[str, ...]
    kind: EventKind = "working_memory_updated"


@dataclass(frozen=True, slots=True)
class MemoryExtracted:
    """Emitted after post-turn extraction completes (success or skip).

    Turn-scoped: extraction runs as a fire-and-forget task spawned by the
    handler after `provider.run_turn` returns, so the envelope still
    references the originating turn. ``error=True`` means extraction
    raised — the turn itself succeeded; only the extraction side effect
    failed (logged, never propagated to the user).
    """

    envelope: _Envelope
    candidate_count: int
    inserted_count: int
    duration_ms: int
    error: bool = False
    kind: EventKind = "memory_extracted"


@dataclass(frozen=True, slots=True)
class MemoryDecayed:
    """Emitted when a maintenance decay sweep finishes for one tier.

    Decay is cross-user — `user_id` is `None` on the synthesized envelope.
    Each sweep visits one tier (``short`` or ``long``), promotes rows that
    cleared the hit threshold, archives the rest, and reports counts.
    """

    run_id: str
    tier: str
    candidates_seen: int
    promoted: int
    archived: int
    duration_ms: int
    error: bool = False
    kind: EventKind = "memory_decayed"

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "envelope",
            _Envelope(
                turn_id=f"memory_maintenance:{self.run_id}",
                sequence=0,
                user_id=None,
                session_id=None,
            ),
        )

    envelope: _Envelope = field(init=False)


@dataclass(frozen=True, slots=True)
class MemoryPruned:
    """Emitted when the optional prune pass hard-deletes archived rows.

    `archived_before` is the cutoff timestamp (unix seconds): rows whose
    ``archived_at`` is older than this were eligible for deletion.
    ``error=True`` means the sweep raised; ``pruned_count`` is then a
    partial result (zero, in practice, since the failure is at list time).
    """

    run_id: str
    pruned_count: int
    archived_before: int
    duration_ms: int
    error: bool = False
    kind: EventKind = "memory_pruned"

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "envelope",
            _Envelope(
                turn_id=f"memory_maintenance:{self.run_id}",
                sequence=0,
                user_id=None,
                session_id=None,
            ),
        )

    envelope: _Envelope = field(init=False)


@dataclass(frozen=True, slots=True)
class MemoryObserved:
    """Emitted after one Observer run finishes (success, skip, or error).

    Window-scoped: the Observer runs as a fire-and-forget task spawned by
    `ObservationalMemory` after a turn crosses the observer threshold.
    `observations_written` is zero on no-op runs (empty unprocessed
    window) and on error runs. ``error=True`` means the run raised or
    the LLM reply could not be parsed; the watermark is left unchanged
    so the next threshold crossing retries the same window.
    """

    run_id: str
    user_id: str
    agent_id: str
    thread_key: str | None
    rounds_seen: int
    observations_written: int
    duration_ms: int
    error: bool = False
    kind: EventKind = "memory_observed"

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "envelope",
            _Envelope(
                turn_id=f"observer:{self.run_id}",
                sequence=0,
                user_id=self.user_id,
                session_id=None,
            ),
        )

    envelope: _Envelope = field(init=False)


@dataclass(frozen=True, slots=True)
class MemoryConsolidated:
    """Emitted when the daily 3-phase consolidation pipeline completes.

    The pipeline runs proposer → adversary → judge. Counts report the
    proposals generated, those accepted by the judge, and how the
    accepted proposals broke down across the structured edit verbs
    (``merge``, ``replace``, ``delete``).
    """

    run_id: str
    proposals_generated: int
    proposals_accepted: int
    merges_applied: int
    replaces_applied: int
    deletes_applied: int
    duration_ms: int
    kind: EventKind = "memory_consolidated"

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "envelope",
            _Envelope(
                turn_id=f"memory_maintenance:{self.run_id}",
                sequence=0,
                user_id=None,
                session_id=None,
            ),
        )

    envelope: _Envelope = field(init=False)


@dataclass(frozen=True, slots=True)
class MemoryReflected:
    """Emitted after one Reflector run finishes (success or error).

    The Reflector compresses an active observation set: an LLM proposer
    emits ``Merge``/``Replace``/``Delete`` edits which the store applies
    atomically. ``proposals_generated`` is the count returned by the
    proposer (after id-validation drops); ``proposals_accepted`` is what
    the optional adversary/judge — or, in v1's single-phase default, the
    proposer itself — let through. Mutation counts (``merges_applied``
    etc.) come from the store's apply phase and may be lower than the
    accepted count when a source row was archived between proposer and
    apply. ``error=True`` means a phase raised; the apply path was
    skipped and the active set is unchanged.
    """

    run_id: str
    user_id: str
    proposals_generated: int
    proposals_accepted: int
    merges_applied: int
    replaces_applied: int
    deletes_applied: int
    duration_ms: int
    error: bool = False
    kind: EventKind = "memory_reflected"

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "envelope",
            _Envelope(
                turn_id=f"reflector:{self.run_id}",
                sequence=0,
                user_id=self.user_id,
                session_id=None,
            ),
        )

    envelope: _Envelope = field(init=False)


@dataclass(frozen=True, slots=True)
class InboundMessage:
    envelope: _Envelope
    channel: str
    thread_key: str | None
    text_length: int
    kind: EventKind = "inbound_message"


@dataclass(frozen=True, slots=True)
class OutboundDispatched:
    envelope: _Envelope
    channel: str
    text_length: int
    streaming: bool
    kind: EventKind = "outbound_dispatched"


@dataclass(frozen=True, slots=True)
class OutboundConfirmed:
    envelope: _Envelope
    channel: str
    kind: EventKind = "outbound_confirmed"


@dataclass(frozen=True, slots=True)
class SendFailed:
    envelope: _Envelope
    channel: str
    error_type: str
    error_message: str
    kind: EventKind = "send_failed"


@dataclass(frozen=True, slots=True)
class SchedulerFireQueued:
    """Emitted when a scheduler trigger fires and a synthetic turn is enqueued."""

    trigger_id: str
    trigger_kind: str
    user_id: str
    fire_count: int
    kind: EventKind = "scheduler_fire_queued"

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "envelope",
            _Envelope(
                turn_id=f"trigger:{self.trigger_id}",
                sequence=self.fire_count,
                user_id=self.user_id,
                session_id=None,
            ),
        )

    # envelope is synthesized by __post_init__; declare it with a sentinel default
    # so the frozen dataclass machinery doesn't complain.
    envelope: _Envelope = field(init=False)


@dataclass(frozen=True, slots=True)
class SchedulerFireConsumed:
    """Emitted when the synthetic turn for a scheduler fire completes successfully."""

    trigger_id: str
    trigger_kind: str
    user_id: str
    fire_count: int
    kind: EventKind = "scheduler_fire_consumed"

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "envelope",
            _Envelope(
                turn_id=f"trigger:{self.trigger_id}",
                sequence=self.fire_count,
                user_id=self.user_id,
                session_id=None,
            ),
        )

    envelope: _Envelope = field(init=False)


@dataclass(frozen=True, slots=True)
class SchedulerFireErrored:
    """Emitted when the synthetic turn for a scheduler fire raises an exception."""

    trigger_id: str
    trigger_kind: str
    user_id: str
    fire_count: int
    error: str
    kind: EventKind = "scheduler_fire_errored"

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "envelope",
            _Envelope(
                turn_id=f"trigger:{self.trigger_id}",
                sequence=self.fire_count,
                user_id=self.user_id,
                session_id=None,
            ),
        )

    envelope: _Envelope = field(init=False)


@dataclass(frozen=True, slots=True)
class TriggerCancelled:
    """Emitted when a trigger is explicitly cancelled by the user or scheduler."""

    trigger_id: str
    trigger_kind: str
    user_id: str
    fire_count: int
    kind: EventKind = "trigger_cancelled"

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "envelope",
            _Envelope(
                turn_id=f"trigger:{self.trigger_id}",
                sequence=self.fire_count,
                user_id=self.user_id,
                session_id=None,
            ),
        )

    envelope: _Envelope = field(init=False)


@dataclass(frozen=True, slots=True)
class TriggerDropped:
    """Emitted when a trigger fire is dropped (e.g. queue full, limit exceeded)."""

    trigger_id: str
    trigger_kind: str
    user_id: str
    fire_count: int
    reason: str
    kind: EventKind = "trigger_dropped"

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "envelope",
            _Envelope(
                turn_id=f"trigger:{self.trigger_id}",
                sequence=self.fire_count,
                user_id=self.user_id,
                session_id=None,
            ),
        )

    envelope: _Envelope = field(init=False)


TraceEvent = (
    TurnStarted
    | TurnCompleted
    | TurnFailed
    | ToolCallStarted
    | ToolCallCompleted
    | SubAgentStarted
    | SubAgentCompleted
    | MemoryRead
    | MemoryWrite
    | WorkingMemoryUpdated
    | MemoryExtracted
    | MemoryObserved
    | MemoryDecayed
    | MemoryPruned
    | MemoryConsolidated
    | MemoryReflected
    | InboundMessage
    | OutboundDispatched
    | OutboundConfirmed
    | SendFailed
    | SchedulerFireQueued
    | SchedulerFireConsumed
    | SchedulerFireErrored
    | TriggerCancelled
    | TriggerDropped
)


def event_payload(event: TraceEvent) -> dict[str, Any]:
    """Serialize an event to a dict suitable for JSON tracers."""
    env = event.envelope
    base: dict[str, Any] = {
        "kind": event.kind,
        "turn_id": env.turn_id,
        "sequence": env.sequence,
        "emitted_at": env.emitted_at.isoformat(),
        "user_id": env.user_id,
        "session_id": env.session_id,
    }
    for name in type(event).__slots__:
        if name in ("envelope", "kind"):
            continue
        value = getattr(event, name)
        if isinstance(value, datetime):
            value = value.isoformat()
        base[name] = value
    return base
