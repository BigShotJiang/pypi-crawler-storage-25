"""Default failure policies (R42, R43, R44, R45, R46).

`default_on_turn_error`:
  - Sends a short apology reply via `ctx.reply`.
  - Emits `TurnFailed` on the tracer.
  - Swallows any secondary error raised by the apology send itself;
    the worker must continue to the next turn.

`default_on_send_failure`:
  - Emits `SendFailed` on the tracer.
  - Does NOT re-queue — v0.1 treats send failures as terminal for the
    current outbound message.

Both policies are safe to bind as the `on_turn_error` / `on_send_failure`
handlers on `ZenoApp`. Applications that need richer behavior (retry,
dead-letter, out-of-band alerting) wrap these.
"""

from __future__ import annotations

import logging
import uuid
from typing import TYPE_CHECKING

from zeno.channels.messages import OutgoingMessage
from zeno.observability.events import SendFailed, TurnFailed, _Envelope

if TYPE_CHECKING:
    from zeno.channels.messages import IncomingMessage
    from zeno.channels.protocol import Channel
    from zeno.context import Ctx
    from zeno.observability.tracer import Tracer

logger = logging.getLogger("zeno.observability")

APOLOGY_TEXT = "Sorry, something went wrong. Please try again."


async def default_on_turn_error(ctx: Ctx, msg: IncomingMessage, exc: BaseException) -> None:
    """Reply with an apology and emit `TurnFailed`."""
    _emit_turn_failed(ctx, exc)
    try:
        await ctx.reply(
            OutgoingMessage(
                text=APOLOGY_TEXT,
                reply_to_thread_key=msg.thread_key,
            )
        )
    except Exception:  # noqa: BLE001
        logger.exception("default_on_turn_error failed to deliver apology; worker will continue")


async def default_on_send_failure(
    channel: Channel, msg: OutgoingMessage, exc: BaseException
) -> None:
    """Emit `SendFailed`; v0.1 does not re-queue."""
    tracer: Tracer | None = _tracer_from_current_ctx()
    if tracer is None:
        logger.warning(
            "Send failed on channel=%s: %s (%s); no tracer on current ctx",
            channel.name,
            type(exc).__name__,
            exc,
        )
        return
    env = _Envelope(
        turn_id=_new_turn_id(),
        sequence=0,
        user_id=None,
        session_id=None,
    )
    tracer.on_event(
        SendFailed(
            envelope=env,
            channel=channel.name,
            error_type=type(exc).__name__,
            error_message=str(exc),
        )
    )


def _emit_turn_failed(ctx: Ctx, exc: BaseException) -> None:
    tracer = getattr(ctx, "tracer", None)
    if tracer is None:
        return
    env = _Envelope(
        turn_id=_new_turn_id(),
        sequence=0,
        user_id=ctx.user_id,
        session_id=ctx.session_id,
    )
    tracer.on_event(
        TurnFailed(
            envelope=env,
            error_type=type(exc).__name__,
            error_message=str(exc),
        )
    )


def _tracer_from_current_ctx() -> Tracer | None:
    """Try to pull the tracer off the current turn's `Ctx` if any."""
    try:
        from zeno.context import current_ctx

        return getattr(current_ctx(), "tracer", None)
    except LookupError:
        return None


def _new_turn_id() -> str:
    return uuid.uuid4().hex
