"""`Tracer` protocol + default implementations (R47, R48).

Contract:
  - `Tracer.on_event(event)` is sync and must never raise into the caller.
    The runtime emits events from hot paths (turn worker, hook bridge) and
    a raising tracer would destabilize the system.
  - Implementations that need async work must fire-and-forget an internal
    task, pinning it to a set so it's not garbage-collected mid-flight.
    See `BackgroundDispatcher` for the reference pattern.

Defaults:
  - `NoOpTracer` — library default. Zero overhead, zero side effects.
  - `StdoutTracer` — developer default for CLI runs. One JSON line per
    event to stdout. Metadata-only unless `ZENO_TRACE_CONTENT=1`.

The tracer is plugged into `ZenoApp(tracer=...)` and propagated onto each
`Ctx` at turn entry. Tools reach it via `current_ctx().tracer`.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import sys
from collections.abc import Awaitable, Callable
from typing import Protocol, runtime_checkable

from zeno.observability.events import TraceEvent, event_payload

logger = logging.getLogger("zeno.observability")

TRACE_CONTENT_ENV = "ZENO_TRACE_CONTENT"


@runtime_checkable
class Tracer(Protocol):
    """Contract every tracer implementation must satisfy."""

    def on_event(self, event: TraceEvent) -> None:
        """Record a trace event. Must not raise."""


class NoOpTracer:
    """Default tracer — discards every event. Zero overhead."""

    def on_event(self, event: TraceEvent) -> None:  # noqa: ARG002
        return None


class StdoutTracer:
    """Dev tracer — emits one JSON line per event to stdout.

    Metadata-only by default. Set `ZENO_TRACE_CONTENT=1` in the environment
    to include content fields (prompt text, tool arguments, memory results).
    v0.1 events already exclude raw content at construction time, so this
    flag is forward-compatible rather than currently load-bearing; it's
    honored here so library consumers can rely on the same gate regardless
    of event shape evolution.
    """

    def __init__(self, *, stream: object | None = None) -> None:
        self._stream = stream if stream is not None else sys.stdout
        self._content_enabled = os.environ.get(TRACE_CONTENT_ENV) == "1"

    def on_event(self, event: TraceEvent) -> None:
        try:
            payload = event_payload(event)
            if not self._content_enabled:
                # No-op for v0.1 — events are already metadata-only.
                # Documented so future event fields carrying content can
                # be stripped here without a tracer API change.
                pass
            line = json.dumps(payload, default=str)
            print(line, file=self._stream, flush=True)  # type: ignore[arg-type]
        except Exception:  # noqa: BLE001
            logger.exception("StdoutTracer failed to emit event")


class BackgroundDispatcher:
    """Fire-and-forget wrapper that runs async work without awaiting it.

    Pins tasks to an internal set so Python's GC cannot drop them mid-flight
    (the canonical `asyncio.create_task` gotcha — see helios
    `assistant/tracing/publisher.py:74–76`).

    Not a `Tracer` itself — a utility tracers compose with when they need
    I/O (e.g., ship events to a remote collector).
    """

    def __init__(self) -> None:
        self._tasks: set[asyncio.Task[None]] = set()

    def fire(self, coro: Awaitable[None]) -> None:
        """Schedule `coro` and return immediately. Errors are logged."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No running loop — tracer invoked outside async context.
            # Drop the work; logging-only tracers shouldn't need a loop.
            logger.debug("BackgroundDispatcher.fire called outside an event loop")
            return

        task = loop.create_task(_guarded(coro))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def drain(self) -> None:
        """Wait for in-flight tasks to finish. Best-effort — swallows errors."""
        if not self._tasks:
            return
        with contextlib.suppress(Exception):
            await asyncio.gather(*self._tasks, return_exceptions=True)


async def _guarded(coro: Awaitable[None]) -> None:
    try:
        await coro
    except Exception:  # noqa: BLE001
        logger.exception("Background trace task failed")


OnEvent = Callable[[TraceEvent], None]
