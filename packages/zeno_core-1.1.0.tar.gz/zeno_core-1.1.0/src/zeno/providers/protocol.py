"""The `Provider` Protocol + `Capabilities` contract (R1, R2, R5, R6).

Every provider adapter (Claude Agent SDK, OpenAI Chat Completions, local
Ollama, etc.) implements `Provider`. Core treats providers through this
protocol only — transport, tool-call loops, streaming shape, and
conversation history are each provider's responsibility.

`Capabilities` describes what the adapter can do. `ZenoApp.start()` walks
the configured `Agent` and raises `ProviderCapabilityError` if the agent
requires a feature the provider does not declare (sub-agents, built-in
tools, permission modes, streaming). That check is the mechanism behind
the "switch providers without changing your Agent" promise: compatibility
is verified once at startup instead of failing mid-turn.

### Well-known `ctx.state` keys

The default handler writes the composed system prompt into
``ctx.state["composed_prompt"]`` before invoking ``run_turn``. Provider
adapters SHOULD read this key when they need the per-turn system prompt
(e.g. to pass it as the first message with role ``"system"``). Providers
MUST NOT mutate this key — ``ctx.state`` is per-turn-scoped, but that
invariant is maintained by the turn worker, not by the provider.

### Namespace

``zeno.providers`` is a PEP 420 implicit namespace package. ``zeno-core``
ships only ``zeno.providers.protocol`` (the contract). Adapter packages
populate the namespace by placing their modules under
``zeno.providers.<name>`` — ``zeno-provider-claude`` ships
``zeno.providers.claude_sdk`` and ``zeno-provider-openai`` ships
``zeno.providers.openai``. Do **not** add ``zeno/providers/__init__.py``
to this package — doing so would convert it to a regular package and
shadow every downstream adapter.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from zeno.agent import Agent
    from zeno.channels.messages import IncomingMessage
    from zeno.context import Ctx


@dataclass(frozen=True, slots=True)
class Capabilities:
    """Static capability descriptor a provider publishes to core.

    The four flags here are intentionally the dimensions that differ across
    SDKs today — not a generic "feature bag". Adding a flag is a conscious
    contract change and should be paired with a migration note.

    ``supports_sub_agents``
        The adapter can dispatch to ``AgentDefinition``-style specialists.
        Only the Claude Agent SDK supports this in v0.3.0.

    ``supports_built_in_tools``
        The adapter exposes SDK-native tools (``WebSearch``, ``WebFetch``,
        ``Bash``, etc.). OpenAI-compatible providers must set this to
        ``False``.

    ``supports_permission_mode``
        The adapter honours ``Agent.permission_mode`` (``"default"``,
        ``"acceptEdits"``, ``"bypassPermissions"``, ``"plan"``).

    ``supports_streaming``
        The adapter emits per-chunk assistant text via ``ctx.stream(...)``.
    """

    supports_sub_agents: bool
    supports_built_in_tools: bool
    supports_permission_mode: bool
    supports_streaming: bool


@runtime_checkable
class Provider(Protocol):
    """Contract every provider adapter must satisfy.

    ``capabilities`` is a property (typically returning a module-level
    constant) so ``ZenoApp.start()`` can read it without constructing a
    live connection. ``start()`` / ``stop()`` bracket the adapter's
    lifecycle and are invoked by ``ZenoApp`` — ``start()`` runs after the
    capability check; ``stop()`` runs during the ``run()`` finally block.
    Both MUST be idempotent so shutdown during a failed startup does not
    raise.

    ``run_turn`` is called once per dequeued incoming message. Providers
    are expected to:

    1. Read ``ctx.state["composed_prompt"]`` for the per-turn system prompt.
    2. Load prior conversation state (if applicable) via
       ``ctx.memory.conversation`` — the ``ClaudeSDKProvider`` skips this.
    3. Stream assistant text through ``ctx.stream(...)``.
    4. Dispatch tool calls against the ``Agent``'s registered tools.
    5. Persist any new messages back through ``ctx.memory.conversation``.
    6. Return. The turn worker handles finalization in its ``finally``.
    """

    @property
    def capabilities(self) -> Capabilities:
        """Static capability descriptor. Real providers return a constant."""

    async def start(self) -> None:
        """Initialise any long-lived resources. Must be idempotent."""

    async def stop(self) -> None:
        """Drain and shut down. Must be idempotent and safe after a failed `start`."""

    async def run_turn(
        self,
        *,
        agent: Agent,
        ctx: Ctx,
        msg: IncomingMessage,
    ) -> None:
        """Run one turn against the upstream LLM for the given message.

        Raises `ProviderError` (or subclass) on transport- or upstream-level
        failures. The turn worker catches these and runs ``on_turn_error``.
        """
