# zeno-core

Core runtime for the [Zeno](https://github.com/nkootstra/zeno) framework.

## Install

```bash
uv add zeno-framework
```

Public surface:

- `Ctx`, ContextVar plumbing, `@tool` decorator, `Agent` / `SubAgent`.
- `ZenoApp` — binds channels, agent, memory, provider, tracer.
- `Provider` protocol + `Capabilities` dataclass + `ProviderCapabilityError`.
- `Channel` protocol, turn worker, streaming, tracer, failure policies.
- `MemoryBinderProtocol`, `SecretsStore`, and other extension protocols.
- Plugin entry-point discovery (`zeno.sub_agents`, `zeno.providers`,
  `zeno.tools`, `zeno.channels`, `zeno.vectorstores`).

Concrete `Provider` adapters live in sibling packages:
[`zeno-provider-claude`](https://github.com/nkootstra/zeno/tree/main/packages/zeno-provider-claude)
and
[`zeno-provider-openai`](https://github.com/nkootstra/zeno/tree/main/packages/zeno-provider-openai).

Part of a lockstep `1.x` release. Install via the `zeno-framework` meta-package:

```bash
uv add 'zeno-framework[cli]'          # Claude Agent SDK backend (default)
uv add 'zeno-framework[openai,cli]'   # OpenAI-compatible backend
```

Part of the [Zeno framework](https://github.com/nkootstra/zeno).
