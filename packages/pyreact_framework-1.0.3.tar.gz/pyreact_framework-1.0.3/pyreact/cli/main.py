"""
PyReact CLI
===========

Command-line interface for PyReact development.
"""

import argparse
import os
import sys
from pathlib import Path


def create_project(name: str) -> None:
    """Create a new PyReact project"""
    project_dir = Path(name)

    if project_dir.exists():
        print(f"Error: Directory '{name}' already exists")
        sys.exit(1)

    # Create directory structure
    dirs = [
        'src/components',
        'src/hooks',
        'src/pages',
        'src/styles',
        'src/utils',
        'public',
        'tests',
    ]

    for dir_path in dirs:
        (project_dir / dir_path).mkdir(parents=True, exist_ok=True)

    # Create pyproject.toml
    pyproject_content = '''[tool.pyreact]
entry = "src/index.py"
output = "dist"
dev_port = 3000
ssr = true
css_modules = true
source_maps = true
'''
    (project_dir / 'pyproject.toml').write_text(pyproject_content, encoding='utf-8')

    # Create main index file
    index_content = '''"""
Main entry point for PyReact application
"""

from pyreact import h, render, use_state


def App(props):
    """Main application component - A simple greeting app"""
    name, set_name = use_state('')
    
    return h('div', {'className': 'app', 'style': {'padding': '20px', 'maxWidth': '600px', 'margin': '0 auto'}},
        h('h1', {'style': {'color': '#007bff', 'marginBottom': '20px'}}, 'Welcome to PyReact!'),
        h('p', {'style': {'fontSize': '18px', 'marginBottom': '20px'}}, 
            f'Hello, {name}!' if name else 'Enter your name below:'
        ),
        h('input', {
            'type': 'text',
            'placeholder': 'Type your name...',
            'value': name,
            'onInput': lambda e: set_name(e.target.value),
            'style': {
                'padding': '10px',
                'fontSize': '16px',
                'borderRadius': '4px',
                'border': '1px solid #ccc',
                'width': '100%',
                'maxWidth': '300px'
            }
        }),
        h('p', {'style': {'marginTop': '20px', 'color': '#666', 'fontSize': '14px'}}, 
            'Edit src/index.py to customize this app.'
        )
    )


if __name__ == '__main__':
    from pyreact.dom.dom_operations import document

    root = document.create_element('div')
    root.attributes['id'] = 'root'
    document.body.append_child(root)

    render(h(App, {}), root)
'''
    (project_dir / 'src' / 'index.py').write_text(index_content, encoding='utf-8')

    # Create __init__.py files
    init_content = '"""PyReact application package"""'
    (project_dir / 'src' / '__init__.py').write_text(init_content, encoding='utf-8')
    (project_dir / 'src' / 'components' / '__init__.py').write_text(init_content, encoding='utf-8')
    (project_dir / 'src' / 'hooks' / '__init__.py').write_text(init_content, encoding='utf-8')
    (project_dir / 'src' / 'pages' / '__init__.py').write_text(init_content, encoding='utf-8')

    # Create README
    readme_content = f'''# {name}

A PyReact application.

## Getting Started

```bash
# Install dependencies
pip install pyreact

# Run development server
pyreact dev

# Build for production
pyreact build
```

## Project Structure

```
{name}/
├── src/
│   ├── components/    # Reusable components
│   ├── hooks/         # Custom hooks
│   ├── pages/         # Page components
│   ├── styles/        # CSS files
│   └── index.py       # Entry point
├── public/            # Static assets
├── tests/             # Test files
└── pyproject.toml     # Configuration
```
'''
    (project_dir / 'README.md').write_text(readme_content, encoding='utf-8')

    # Create test file
    test_content = '''"""
Tests for the application
"""

from pyreact.testing import render, screen, fireEvent
from pyreact import h


def test_app_renders():
    """Test that the app renders"""
    # Add your tests here
    pass


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])
'''
    (project_dir / 'tests' / 'test_app.py').write_text(test_content, encoding='utf-8')

    print(f"[OK] Created project '{name}'")
    print(f"\nNext steps:")
    print(f"  cd {name}")
    print(f"  pyreact dev")


def generate_component(name: str, component_type: str = 'functional') -> None:
    """Generate a new component"""
    # Determine output directory
    components_dir = Path('src/components')
    if not components_dir.exists():
        components_dir = Path('components')

    if not components_dir.exists():
        print("Error: Could not find components directory")
        sys.exit(1)

    # Create component file
    if component_type == 'class':
        content = f'''"""
{name} Component
"""

from pyreact import h, Component


class {name}(Component):
    """Class component: {name}"""

    def __init__(self, props):
        super().__init__(props)
        self.state = {{}}

    def render(self):
        return h('div', {{'className': '{name.lower()}'}},
            h('h2', None, '{name}'),
            self.props.get('children', None)
        )
'''
    else:
        content = f'''"""
{name} Component
"""

from pyreact import h, use_state


def {name}(props):
    """Functional component: {name}"""
    return h('div', {{'className': '{name.lower()}'}},
        h('h2', None, '{name}'),
        props.get('children', None)
    )
'''

    file_path = components_dir / f'{name}.py'
    file_path.write_text(content, encoding='utf-8')

    print(f"[OK] Created component '{name}' at {file_path}")


def generate_hook(name: str) -> None:
    """Generate a new custom hook"""
    hooks_dir = Path('src/hooks')
    if not hooks_dir.exists():
        hooks_dir = Path('hooks')

    if not hooks_dir.exists():
        print("Error: Could not find hooks directory")
        sys.exit(1)

    # Remove 'use' prefix if present
    if name.startswith('use_'):
        name = name[4:]
    elif name.startswith('use'):
        name = name[3:]

    hook_name = f'use_{name.lower()}'

    content = f'''"""
{name} Hook
"""

from pyreact import use_state, use_effect


def {hook_name}(initial_value=None):
    """
    Custom hook: {hook_name}

    Args:
        initial_value: Initial value

    Returns:
        tuple: (value, setter)
    """
    value, set_value = use_state(initial_value)

    @use_effect([])
    def setup():
        # Setup logic here
        return lambda: None  # Cleanup

    return value, set_value
'''

    file_path = hooks_dir / f'{hook_name}.py'
    file_path.write_text(content, encoding='utf-8')

    print(f"[OK] Created hook '{hook_name}' at {file_path}")


def run_dev_server(port: int = 3000) -> None:
    """Run development server"""
    import http.server
    import socketserver
    import threading
    import time
    import webbrowser
    from pathlib import Path

    # Check if we're in a PyReact project
    if not Path('pyproject.toml').exists():
        print("Error: Not a PyReact project. Run 'pyreact create <name>' first.", flush=True)
        sys.exit(1)

    # Check if src/index.py exists
    index_path = Path('src/index.py')
    if not index_path.exists():
        print("Error: src/index.py not found", flush=True)
        sys.exit(1)

    # Create public directory if it doesn't exist
    Path('public').mkdir(exist_ok=True)

    # Read the user's index.py file
    user_code = index_path.read_text(encoding='utf-8')

    # Generate HTML file with PyReact runtime
    html_content = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PyReact App</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }
        #root {
            max-width: 1200px;
            margin: 0 auto;
        }
        .pyreact-loading {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        .pyreact-error {
            background: #fee;
            border: 1px solid #f00;
            padding: 20px;
            border-radius: 8px;
            color: #c00;
        }
    </style>
</head>
<body>
    <div id="root">
        <div class="pyreact-loading">Loading PyReact App...</div>
    </div>
    <script>
        // PyReact Runtime - Browser Implementation
        const PyReact = {
            h: function(type, props, ...children) {
                return {
                    type,
                    props: props || {},
                    children: children.flat().filter(c => c !== null && c !== undefined)
                };
            },
            
            render: function(vnode, container) {
                container.innerHTML = '';
                const dom = this.createDom(vnode);
                container.appendChild(dom);
            },
            
            createDom: function(vnode) {
                if (vnode === null || vnode === undefined) {
                    return document.createTextNode('');
                }
                if (typeof vnode === 'string' || typeof vnode === 'number') {
                    return document.createTextNode(String(vnode));
                }
                if (!vnode || !vnode.type) {
                    return document.createTextNode('');
                }
                
                // Component (function)
                if (typeof vnode.type === 'function') {
                    try {
                        const rendered = vnode.type(vnode.props);
                        return this.createDom(rendered);
                    } catch (e) {
                        console.error('Component render error:', e);
                        const errorDiv = document.createElement('div');
                        errorDiv.className = 'pyreact-error';
                        errorDiv.textContent = 'Error: ' + e.message;
                        return errorDiv;
                    }
                }
                
                // HTML element
                const dom = document.createElement(vnode.type);
                
                // Apply props
                for (const [key, value] of Object.entries(vnode.props || {})) {
                    if (key === 'className') {
                        dom.className = value;
                    } else if (key === 'htmlFor') {
                        dom.htmlFor = value;
                    } else if (key.startsWith('on') && typeof value === 'function') {
                        const event = key[2].toLowerCase() + key.slice(3);
                        dom.addEventListener(event, value);
                    } else if (key === 'style') {
                        if (typeof value === 'string') {
                            dom.style.cssText = value;
                        } else if (typeof value === 'object') {
                            Object.assign(dom.style, value);
                        }
                    } else if (key === 'value') {
                        dom.value = value;
                    } else if (key === 'checked') {
                        dom.checked = value;
                    } else if (key === 'disabled') {
                        dom.disabled = value;
                    } else if (key === 'href' || key === 'src' || key === 'id' || key === 'type' || key === 'name' || key === 'placeholder') {
                        dom.setAttribute(key, value);
                    } else if (key !== 'children' && key !== 'key' && key !== 'ref') {
                        dom.setAttribute(key, value);
                    }
                }
                
                // Render children
                for (const child of vnode.children || []) {
                    dom.appendChild(this.createDom(child));
                }
                
                return dom;
            }
        };
        
        // State management for hooks simulation
        let stateValues = [];
        let stateIndex = 0;
        
        function useState(initialValue) {
            const currentIndex = stateIndex;
            if (stateValues[currentIndex] === undefined) {
                stateValues[currentIndex] = initialValue;
            }
            const setValue = (newValue) => {
                if (typeof newValue === 'function') {
                    stateValues[currentIndex] = newValue(stateValues[currentIndex]);
                } else {
                    stateValues[currentIndex] = newValue;
                }
                stateIndex = 0;
                render();
            };
            stateIndex++;
            return [stateValues[currentIndex], setValue];
        }
        
        // Effect management
        let effectDeps = [];
        let effectIndex = 0;
        
        function useEffect(callback, deps) {
            const prevDeps = effectDeps[effectIndex];
            let shouldRun = !prevDeps || deps.some((d, i) => d !== prevDeps[i]);
            
            if (shouldRun) {
                const cleanup = callback();
                if (typeof cleanup === 'function') {
                    // Store cleanup for later
                }
            }
            effectDeps[effectIndex] = deps;
            effectIndex++;
        }
        
        // Context
        const contexts = {};
        
        function createContext(defaultValue) {
            const id = Math.random().toString(36).substr(2, 9);
            contexts[id] = { defaultValue, value: defaultValue };
            return { id, Provider: 'Provider' };
        }
        
        function useContext(context) {
            return contexts[context.id]?.value || context.defaultValue;
        }
        
        // Ref
        function useRef(initialValue) {
            return { current: initialValue };
        }
        
        // Memo
        function useMemo(factory, deps) {
            return factory();
        }
        
        function useCallback(callback, deps) {
            return callback;
        }
        
        // Router simulation
        function useParams() {
            return {};
        }
        
        function useLocation() {
            return { pathname: window.location.pathname, search: window.location.search };
        }
        
        function useHistory() {
            return {
                push: (path) => { window.location.href = path; },
                replace: (path) => { window.location.replace(path); }
            };
        }
        
        // Theme
        const ThemeContext = createContext({ primary: '#007bff' });
        
        function useTheme() {
            return useContext(ThemeContext);
        }
        
        // Expose globals for user code
        window.h = PyReact.h;
        window.render = PyReact.render;
        window.useState = useState;
        window.useEffect = useEffect;
        window.useContext = useContext;
        window.useRef = useRef;
        window.useMemo = useMemo;
        window.useCallback = useCallback;
        window.createContext = createContext;
        window.useParams = useParams;
        window.useLocation = useLocation;
        window.useHistory = useHistory;
        window.useTheme = useTheme;
        window.ThemeContext = ThemeContext;
        window.PyReact = PyReact;
        
        console.log('PyReact dev server running.');
        console.log('Edit src/index.py to see changes (refresh page to reload).');
    </script>
</body>
</html>'''
    
    # Transpile user's Python code to JavaScript
    user_js = _transpile_python_to_js(user_code)
    
    # Append user's transpiled code to the HTML
    html_with_user = html_content.replace('</body>', f'''
    <script>
    // User's application code (transpiled from src/index.py)
    {user_js}
    </script>
    </body>''')
    
    html_path = Path('public/index.html')
    html_path.write_text(html_with_user, encoding='utf-8')

    # Change to public directory
    original_dir = os.getcwd()
    os.chdir('public')

    # Create custom handler
    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, format, *args):
            # Suppress default logging
            pass

    # Start server
    try:
        # Allow address reuse
        socketserver.TCPServer.allow_reuse_address = True
        with socketserver.TCPServer(("", port), Handler) as httpd:
            url = f"http://localhost:{port}"
            print(f"[OK] Development server running at {url}", flush=True)
            print(f"\nPress Ctrl+C to stop the server", flush=True)

            # Open browser after a short delay
            def open_browser():
                time.sleep(1.5)
                try:
                    webbrowser.open(url)
                except:
                    pass

            browser_thread = threading.Thread(target=open_browser, daemon=True)
            browser_thread.start()

            # Serve forever
            try:
                httpd.serve_forever()
            except KeyboardInterrupt:
                pass
            finally:
                os.chdir(original_dir)
    except OSError as e:
        os.chdir(original_dir)
        if 'Address already in use' in str(e) or e.errno == 10048:  # Port already in use (Windows)
            print(f"Error: Port {port} is already in use", flush=True)
            print(f"Try: pyreact dev --port {port + 1}", flush=True)
        else:
            print(f"Error: {e}", flush=True)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n[OK] Server stopped", flush=True)


def _transpile_python_to_js(python_code: str) -> str:
    """
    Transpile Python PyReact code to JavaScript.
    This is a simplified transpilation that handles basic PyReact patterns.
    """
    import re
    
    js_code = python_code
    
    # Remove Python docstrings (triple quotes)
    js_code = re.sub(r'"""[\s\S]*?"""', '', js_code)
    js_code = re.sub(r"'''[\s\S]*?'''", '', js_code)
    
    # Remove Python comments (but preserve # in strings)
    lines = js_code.split('\n')
    cleaned_lines = []
    for line in lines:
        if '#' in line:
            in_string = False
            string_char = None
            result = []
            for i, char in enumerate(line):
                if char in ('"', "'") and (i == 0 or line[i-1] != '\\'):
                    if not in_string:
                        in_string = True
                        string_char = char
                    elif char == string_char:
                        in_string = False
                        string_char = None
                elif char == '#' and not in_string:
                    break
                result.append(char)
            cleaned_lines.append(''.join(result))
        else:
            cleaned_lines.append(line)
    js_code = '\n'.join(cleaned_lines)
    
    # Remove import statements
    js_code = re.sub(r'^from\s+\w+[\w.]*\s+import\s+.*$', '', js_code, flags=re.MULTILINE)
    js_code = re.sub(r'^import\s+.*$', '', js_code, flags=re.MULTILINE)
    
    # Convert Python function definitions to JS (including nested functions)
    js_code = re.sub(r'def\s+(\w+)\s*\(([^)]*)\):', r'function \1(\2) {', js_code)
    
    # Convert Python tuple unpacking to JS array destructuring
    # name, set_name = use_state('') -> const [name, set_name] = useState('')
    js_code = re.sub(r'(\w+(?:\s*,\s*\w+)*)\s*=\s*use_state\(', r'const [\1] = useState(', js_code)
    js_code = re.sub(r'(\w+(?:\s*,\s*\w+)*)\s*=\s*use_effect\(', r'const [\1] = useEffect(', js_code)
    
    # Convert Python ternary expressions FIRST (before f-string conversion)
    # Handle: f'Hello, {name}!' if name else 'Enter your name below:'
    def convert_ternary_fstring(match):
        true_val_content = match.group(1)  # Hello, {name}!
        condition = match.group(2)  # name
        false_val = match.group(3)  # Enter your name below:
        # Convert f-string content to template literal
        true_val = re.sub(r'\{([^}]+)\}', r'${\1}', true_val_content)
        return f'{condition} ? `{true_val}` : \'{false_val}\''
    
    # Match: f'...' if condition else '...'
    js_code = re.sub(r"f'([^']+)' if (\w+) else '([^']+)'", convert_ternary_fstring, js_code)
    
    # Match: '...' if condition else '...'
    def convert_ternary_string(match):
        true_val = match.group(1)
        condition = match.group(2)
        false_val = match.group(3)
        return f'{condition} ? \'{true_val}\' : \'{false_val}\''
    
    js_code = re.sub(r"'([^']+)' if (\w+) else '([^']+)'", convert_ternary_string, js_code)
    
    # Convert f-strings to template literals (after ternary conversion)
    def convert_fstring_single(match):
        content = match.group(1)
        content = re.sub(r'\{([^}]+)\}', r'${\1}', content)
        return f'`{content}`'
    
    def convert_fstring_double(match):
        content = match.group(1)
        content = re.sub(r'\{([^}]+)\}', r'${\1}', content)
        return f'`{content}`'
    
    # Handle f-strings with single quotes
    js_code = re.sub(r"f'([^']*?\{[^}]*\}[^']*)'", convert_fstring_single, js_code)
    # Handle f-strings with double quotes
    js_code = re.sub(r'f"([^"]*?\{[^}]*\}[^"]*)"', convert_fstring_double, js_code)
    
    # Convert Python booleans
    js_code = re.sub(r'\bTrue\b', 'true', js_code)
    js_code = re.sub(r'\bFalse\b', 'false', js_code)
    js_code = re.sub(r'\bNone\b', 'null', js_code)
    
    # Convert Python 'and' and 'or'
    js_code = re.sub(r'\band\b', '&&', js_code)
    js_code = re.sub(r'\bor\b', '||', js_code)
    js_code = re.sub(r'\bnot\s+', '!', js_code)
    
    # Convert Python control structures (only for function bodies, not nested)
    # if condition: -> if (condition) {
    # js_code = re.sub(r'\bif\s+([^:]+):', r'if (\1) {', js_code)
    # else: -> } else {
    # js_code = re.sub(r'\belse\s*:', '} else {', js_code)
    # elif condition: -> } else if (condition) {
    # js_code = re.sub(r'\belif\s+([^:]+):', r'} else if (\1) {', js_code)
    # return value -> return value;
    # js_code = re.sub(r'\breturn\s+([^\n]+)', r'return \1;', js_code)
    
    # Convert lambda to arrow functions
    js_code = re.sub(r'lambda\s+(\w*)\s*:', r'(\1) =>', js_code)
    
    # Handle props objects - remove quotes from keys
    js_code = re.sub(r"\{'([^']+)':\s*", r"{\1: ", js_code)
    js_code = re.sub(r",\s*'([^']+)':\s*", r", \1: ", js_code)
    
    # Convert .get() to optional chaining
    def convert_get(match):
        obj = match.group(1)
        key = match.group(2)
        default = match.group(3) if match.group(3) else 'undefined'
        return f"({obj}?.{key} ?? {default})"
    
    js_code = re.sub(r"(\w+)\.get\('(\w+)'(?:,\s*([^)]+))?\)", convert_get, js_code)
    
    # Convert use_state to useState (for non-destructuring cases)
    js_code = re.sub(r'\buse_state\b', 'useState', js_code)
    js_code = re.sub(r'\buse_effect\b', 'useEffect', js_code)
    js_code = re.sub(r'\buse_context\b', 'useContext', js_code)
    js_code = re.sub(r'\buse_ref\b', 'useRef', js_code)
    js_code = re.sub(r'\buse_memo\b', 'useMemo', js_code)
    js_code = re.sub(r'\buse_callback\b', 'useCallback', js_code)
    
    # Handle if __name__ == '__main__': blocks - remove them
    js_code = re.sub(r"if\s+__name__\s*==\s*['\"]__main__['\"]\s*:\s*", '', js_code)
    
    # Remove document.create_element and related Python DOM code
    js_code = re.sub(r"from\s+pyreact\.dom\.dom_operations\s+import\s+document\s*", '', js_code)
    js_code = re.sub(r"root\s*=\s*document\.create_element\(['\"][^'\"]+['\"]\)\s*", '', js_code)
    js_code = re.sub(r"root\.attributes\[['\"][^'\"]+['\"]\]\s*=\s*['\"][^'\"]+['\"]\s*", '', js_code)
    js_code = re.sub(r"document\.body\.append_child\(root\)\s*", '', js_code)
    js_code = re.sub(r"render\(h\(App[^)]*\),\s*root\)\s*", '', js_code)
    
    # Convert render(h(App, {}), root='root')
    js_code = re.sub(r"render\(([^,]+),\s*root\s*=\s*['\"]root['\"]\)", 
                     r'render(\1, document.getElementById("root"))', js_code)
    
    # Clean up multiple empty lines
    js_code = re.sub(r'\n\s*\n\s*\n', '\n\n', js_code)
    
    # Add render call at the end if there's an App component
    if 'function App' in js_code or 'App = function' in js_code or 'App(' in js_code:
        render_call = '''
        
        // Auto-render the App component
        render = function() {
            stateIndex = 0;
            effectIndex = 0;
            const root = document.getElementById('root');
            PyReact.render(h(App, {}), root);
        };
        
        // Initial render
        render();
        '''
        js_code += render_call
    
    return js_code


def build_project() -> None:
    """Build project for production"""
    import shutil
    from pathlib import Path

    # Check if we're in a PyReact project
    if not Path('pyproject.toml').exists():
        print("Error: Not a PyReact project")
        sys.exit(1)

    # Create dist directory
    dist_dir = Path('dist')
    if dist_dir.exists():
        shutil.rmtree(dist_dir)
    dist_dir.mkdir()

    # Copy public files
    public_dir = Path('public')
    if public_dir.exists():
        for file in public_dir.rglob('*'):
            if file.is_file():
                dest = dist_dir / file.relative_to(public_dir)
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(file, dest)

    print("[OK] Build complete")
    print(f"Output: {dist_dir.absolute()}")


def run_tests() -> None:
    """Run tests"""
    import subprocess

    result = subprocess.run(
        ['python', '-m', 'pytest', 'tests/', '-v'],
        capture_output=True,
        text=True
    )
    print(result.stdout)
    if result.returncode != 0:
        print(result.stderr)
    sys.exit(result.returncode)


def serve_build(port: int = 5000, directory: str = 'dist') -> None:
    """Serve production build"""
    import http.server
    import socketserver

    # Check if directory exists
    if not Path(directory).exists():
        print(f"Error: Directory '{directory}' not found")
        print("Run 'pyreact build' first")
        sys.exit(1)

    os.chdir(directory)

    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, format, *args):
            print(f"[OK] {args[0]}")

    try:
        with socketserver.TCPServer(("", port), Handler) as httpd:
            print(f"[OK] Serving at http://localhost:{port}")
            print("Press Ctrl+C to stop")
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[OK] Server stopped")


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description='PyReact CLI - Build modern web apps with Python',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  pyreact create my-app     Create a new project
  pyreact dev               Start development server
  pyreact build             Build for production
  pyreact serve             Serve production build
  pyreact test              Run tests
  pyreact generate component MyComponent
  pyreact generate hook useLocalStorage
'''
    )

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Create command
    create_parser = subparsers.add_parser('create', help='Create a new project')
    create_parser.add_argument('name', help='Project name')

    # Dev command
    dev_parser = subparsers.add_parser('dev', help='Start development server')
    dev_parser.add_argument('--port', type=int, default=3000, help='Port number')

    # Build command
    subparsers.add_parser('build', help='Build for production')

    # Serve command
    serve_parser = subparsers.add_parser('serve', help='Serve production build')
    serve_parser.add_argument('--port', type=int, default=5000, help='Port number')
    serve_parser.add_argument('--dir', default='dist', help='Directory to serve')

    # Test command
    subparsers.add_parser('test', help='Run tests')

    # Generate command
    gen_parser = subparsers.add_parser('generate', help='Generate code')
    gen_parser.add_argument('type', choices=['component', 'hook'], help='Type to generate')
    gen_parser.add_argument('name', help='Name')
    gen_parser.add_argument('--class', action='store_true', dest='class_type',
                            help='Generate class component')

    args = parser.parse_args()

    if args.command == 'create':
        create_project(args.name)
    elif args.command == 'dev':
        run_dev_server(args.port)
    elif args.command == 'build':
        build_project()
    elif args.command == 'serve':
        serve_build(args.port, args.dir)
    elif args.command == 'test':
        run_tests()
    elif args.command == 'generate':
        if args.type == 'component':
            component_type = 'class' if args.class_type else 'functional'
            generate_component(args.name, component_type)
        elif args.type == 'hook':
            generate_hook(args.name)
        else:
            parser.print_help()
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
