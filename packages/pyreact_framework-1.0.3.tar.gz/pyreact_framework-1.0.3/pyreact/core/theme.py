"""
Theme Provider
==============

Context-based theming system for PyReact applications.
"""

from typing import Any, Dict, Optional
from .context import Context, create_context


# Create theme context
ThemeContext = create_context({})


class ThemeProvider:
    """
    Theme provider component that makes theme available to all descendants.
    
    Usage:
        element(ThemeProvider, {'theme': {'primary': '#007bff'}},
            element(App, {})
        )
    """
    
    def __init__(self, props: Dict[str, Any]):
        self.props = props
        self.theme = props.get('theme', {})
    
    def render(self):
        """Render with theme context"""
        from .element import element
        
        children = self.props.get('children', [])
        
        return element(ThemeContext.Provider, {
            'value': self.theme
        }, *children)
    
    def get_child_context(self) -> Dict[str, Any]:
        """Get context for children"""
        return {
            'theme': self.theme
        }


def use_theme() -> Dict[str, Any]:
    """
    Hook to access current theme.
    
    Usage:
        theme = use_theme()
        color = theme['primary']
    
    Returns:
        Current theme object
    """
    # This would use useContext in a real implementation
    # For now, return default theme
    return {
        'primary': '#007bff',
        'secondary': '#6c757d',
        'success': '#28a745',
        'danger': '#dc3545',
        'warning': '#ffc107',
        'info': '#17a2b8',
        'light': '#f8f9fa',
        'dark': '#343a40'
    }


# Default theme
DEFAULT_THEME = {
    'primary': '#007bff',
    'secondary': '#6c757d',
    'success': '#28a745',
    'danger': '#dc3545',
    'warning': '#ffc107',
    'info': '#17a2b8',
    'light': '#f8f9fa',
    'dark': '#343a40',
    'fontFamily': '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    'fontSize': '16px',
    'borderRadius': '4px',
    'spacing': {
        'xs': '4px',
        'sm': '8px',
        'md': '16px',
        'lg': '24px',
        'xl': '32px'
    },
    'breakpoints': {
        'sm': '576px',
        'md': '768px',
        'lg': '992px',
        'xl': '1200px'
    }
}


# Export
__all__ = [
    'ThemeProvider',
    'ThemeContext',
    'use_theme',
    'DEFAULT_THEME',
]
