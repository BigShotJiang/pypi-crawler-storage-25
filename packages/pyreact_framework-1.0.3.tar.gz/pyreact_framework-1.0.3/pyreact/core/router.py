"""
Router Module
=============

Declarative routing for Single Page Applications.
"""

from typing import Any, Callable, Dict, List, Optional, Union
from .element import VNode, h
from .component import Component


class Router(Component):
    """
    Main router component that manages navigation state.
    
    Usage:
        element(Router, {},
            element(Route, {'path': '/', 'component': Home}),
            element(Route, {'path': '/about', 'component': About})
        )
    """
    
    def __init__(self, props: Dict[str, Any]):
        super().__init__(props)
        self.state = {
            'path': self._get_current_path()
        }
        self._setup_listeners()
    
    def _get_current_path(self) -> str:
        """Get current path from window location"""
        # In browser environment, get from window.location
        # For SSR, get from props or default to '/'
        return self.props.get('initialPath', '/')
    
    def _setup_listeners(self):
        """Setup popstate listener for browser navigation"""
        # In browser, would add event listener
        # For now, this is a placeholder
        pass
    
    def navigate(self, path: str):
        """Navigate to a new path"""
        self.setState({'path': path})
    
    def get_context_value(self) -> Dict[str, Any]:
        """Get router context value"""
        return {
            'path': self.state['path'],
            'navigate': self.navigate,
            'params': {},
            'query': {}
        }
    
    def render(self) -> VNode:
        """Render router and children"""
        children = self.props.get('children', [])
        
        # Find matching route
        for child in children:
            if hasattr(child, 'props') and child.props.get('path') == self.state['path']:
                component = child.props.get('component')
                if component:
                    if callable(component):
                        return component()
                    else:
                        return h(component, {})
        
        # No matching route, render 404 or nothing
        return h('div', {}, '404 - Page Not Found')


class Route(Component):
    """
    Route component that defines a path and its component.
    
    Usage:
        element(Route, {'path': '/', 'component': Home})
    """
    
    def render(self) -> VNode:
        """Route doesn't render directly, it's used by Router"""
        # This is a declarative component, Router handles rendering
        return None


class Link(Component):
    """
    Navigation link component.
    
    Usage:
        element(Link, {'to': '/about'}, 'About Page')
    """
    
    def __init__(self, props: Dict[str, Any]):
        super().__init__(props)
        self.handleClick = self._handle_click
    
    def _handle_click(self, event):
        """Handle click event"""
        # Prevent default link behavior
        if hasattr(event, 'preventDefault'):
            event.preventDefault()
        
        # Navigate to new path
        to = self.props.get('to', '/')
        
        # In browser, would use history.pushState
        # For now, just update state
        print(f"Navigate to: {to}")
    
    def render(self) -> VNode:
        """Render link element"""
        to = self.props.get('to', '/')
        children = self.props.get('children', [])
        
        return h('a', {
            'href': to,
            'onClick': self.handleClick,
            'style': {'cursor': 'pointer'}
        }, *children)


class Redirect(Component):
    """
    Redirect component that navigates to a new path.
    
    Usage:
        element(Redirect, {'to': '/login'})
    """
    
    def component_did_mount(self):
        """Redirect when mounted"""
        to = self.props.get('to', '/')
        # In browser, would use history.replaceState
        print(f"Redirect to: {to}")
    
    def render(self) -> VNode:
        """Redirect doesn't render anything"""
        return None


class Switch(Component):
    """
    Switch component that renders the first matching Route.
    
    Usage:
        element(Switch, {},
            element(Route, {'path': '/', 'component': Home}),
            element(Route, {'path': '/about', 'component': About}),
            element(Route, {'component': NotFound})  # 404 fallback
        )
    """
    
    def render(self) -> VNode:
        """Render first matching route"""
        children = self.props.get('children', [])
        
        for child in children:
            if hasattr(child, 'props'):
                path = child.props.get('path')
                component = child.props.get('component')
                
                # If no path, it's a fallback (404)
                if path is None:
                    if component:
                        if callable(component):
                            return component()
                        else:
                            return h(component, {})
                
                # Check if path matches
                # TODO: Implement proper path matching with params
                if path == self._get_current_path():
                    if component:
                        if callable(component):
                            return component()
                        else:
                            return h(component, {})
        
        return None
    
    def _get_current_path(self) -> str:
        """Get current path"""
        # TODO: Get from Router context
        return '/'


# Hook functions for functional components

def useParams() -> Dict[str, str]:
    """
    Get route parameters.
    
    Usage:
        params = useParams()
        user_id = params['id']
    """
    # TODO: Implement with context
    return {}


def useLocation() -> Dict[str, Any]:
    """
    Get current location information.
    
    Usage:
        location = useLocation()
        query = location.get('query', '')
    """
    # TODO: Implement with context
    return {
        'pathname': '/',
        'search': '',
        'hash': ''
    }


def useHistory():
    """
    Get history object for programmatic navigation.
    
    Usage:
        history = useHistory()
        history.push('/new-path')
    """
    class History:
        def push(self, path: str):
            """Navigate to new path"""
            print(f"Navigate to: {path}")
        
        def replace(self, path: str):
            """Replace current path"""
            print(f"Replace with: {path}")
        
        def go_back(self):
            """Go back in history"""
            print("Go back")
        
        def go_forward(self):
            """Go forward in history"""
            print("Go forward")
    
    return History()


# Export router components
__all__ = [
    'Router',
    'Route',
    'Link',
    'Redirect',
    'Switch',
    'useParams',
    'useLocation',
    'useHistory',
]
