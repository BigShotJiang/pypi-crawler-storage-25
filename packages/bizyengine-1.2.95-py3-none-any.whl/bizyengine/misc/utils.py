import asyncio
import base64
import concurrent.futures
import errno
import json
import logging
import os
import pickle
import re
import threading
import time
import urllib.parse
import urllib.request
import zlib
from typing import Callable, Dict, Generic, List, Optional, Tuple, TypeVar, Union

import numpy as np

from bizyengine.bizy_server.api_client import APIClient
from bizyengine.bizy_server.errno import errnos
from bizyengine.core import pop_api_key_and_prompt_id
from bizyengine.core.common import client
from bizyengine.core.common.env_var import BIZYAIR_SERVER_ADDRESS

BIZYAIR_DEBUG = os.getenv("BIZYAIR_DEBUG", False)


#
# TODO: Deprecated, delete this
def send_post_request(api_url, payload, headers):
    import warnings

    warnings.warn(message=f"send_post_request is deprecated")
    """
    Sends a POST request to the specified API URL with the given payload and headers.

    Args:
        api_url (str): The URL of the API endpoint.
        payload (dict): The payload to send in the POST request.
        headers (dict): The headers to include in the POST request.

    Raises:
        Exception: If there is an error connecting to the server or the request fails.
    """
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(api_url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=3600) as response:
            response_data = response.read().decode("utf-8")
        return response_data
    except urllib.error.URLError as e:
        if "Unauthorized" in str(e):
            raise Exception(
                "Key is invalid, please refer to https://cloud.siliconflow.cn to get the API key.\n"
                "If you have the key, please click the 'BizyAir Key' button at the bottom right to set the key."
            )
        else:
            raise Exception(
                f"Failed to connect to the server: {e}, if you have no key, "
            )


def serialize_and_encode(obj: Union[np.ndarray], compress=True) -> Tuple[str, bool]:
    """
    Serializes a Python object, optionally compresses it, and then encodes it in base64.

    Args:
        obj: The Python object to serialize.
        compress (bool): Whether to compress the serialized object using zlib. Default is True.

    Returns:
        str: The base64 encoded string of the serialized (and optionally compressed) object.
    """
    serialized_obj = pickle.dumps(obj)

    if compress:
        serialized_obj = zlib.compress(serialized_obj)

    if BIZYAIR_DEBUG:
        print(
            f"serialize_and_encode: size of bytes is {format_bytes(len(serialized_obj))}"
        )

    encoded_obj = base64.b64encode(serialized_obj).decode("utf-8")

    if BIZYAIR_DEBUG:
        print(
            f"serialize_and_encode: size of base64 text is {format_bytes(len(serialized_obj))}"
        )

    return (encoded_obj, compress)


def decode_and_deserialize(response_text) -> np.ndarray:
    if BIZYAIR_DEBUG:
        print(
            f"decode_and_deserialize: size of text is {format_bytes(len(response_text))}"
        )

    ret = json.loads(response_text)

    if "result" in ret:
        msg = json.loads(ret["result"])
    else:
        msg = ret
    if msg["type"] not in (
        "comfyair",
        "bizyair",
    ):  # DO NOT CHANGE THIS LINE: "comfyair" is the type from the server node
        # TODO: change both server and client "comfyair" to "bizyair"
        raise Exception(f"Unexpected response type: {msg}")

    data = msg["data"]

    tensor_bytes = base64.b64decode(data["payload"])
    if data.get("is_compress", None):
        tensor_bytes = zlib.decompress(tensor_bytes)

    if BIZYAIR_DEBUG:
        print(
            f"decode_and_deserialize: size of bytes is {format_bytes(len(tensor_bytes))}"
        )

    deserialized_object = pickle.loads(tensor_bytes)
    return deserialized_object


def format_bytes(num_bytes: int) -> str:
    """
    Converts a number of bytes to a human-readable string with units (B, KB, or MB).

    :param num_bytes: The number of bytes to convert.
    :return: A string representing the number of bytes in a human-readable format.
    """
    if num_bytes < 1024:
        return f"{num_bytes} B"
    elif num_bytes < 1024 * 1024:
        return f"{num_bytes / 1024:.2f} KB"
    else:
        return f"{num_bytes / (1024 * 1024):.2f} MB"


def get_llm_response(
    model: str,
    system_prompt: str,
    user_prompt: str,
    max_tokens: int = 1024,
    temperature: float = 0.7,
    **kwargs,
):
    api_url = f"{BIZYAIR_SERVER_ADDRESS}/chat/completions"
    extra_data = pop_api_key_and_prompt_id(kwargs)
    headers = client.headers(api_key=extra_data["api_key"])

    # 如果model已不可用，选择第一个可用model
    if _MODELS_CACHE.get("llm_models") is None:
        cache_models(extra_data["api_key"])
    llm_models = _MODELS_CACHE.get("llm_models")
    if llm_models is None:
        logging.warning(f"No LLM models available, keeping the original model {model}")
    elif model not in llm_models:
        logging.warning(
            f"Model {model} is not available, using the first available model {llm_models[0]}"
        )
        model = llm_models[0]

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "max_tokens": max_tokens,
        "temperature": temperature,
        "top_p": 0.9,
        "top_k": 50,
        "stream": False,
        "n": 1,
    }
    if "prompt_id" in extra_data:
        payload["prompt_id"] = extra_data["prompt_id"]
    data = json.dumps(payload).encode("utf-8")

    response = client.send_request(
        url=api_url,
        data=data,
        headers=headers,
        callback=None,
    )
    return response


def get_vlm_response(
    model: str,
    system_prompt: str,
    user_prompt: str,
    base64_images: List[str],
    max_tokens: int = 1024,
    temperature: float = 0.7,
    detail: str = "auto",
    **kwargs,
):
    api_url = f"{BIZYAIR_SERVER_ADDRESS}/chat/completions"
    extra_data = pop_api_key_and_prompt_id(kwargs)
    headers = client.headers(api_key=extra_data["api_key"])

    # 如果model已不可用，选择第一个可用model
    if _MODELS_CACHE.get("vlm_models") is None:
        cache_models(extra_data["api_key"])
    vlm_models = _MODELS_CACHE.get("vlm_models")
    if vlm_models is None:
        logging.warning(f"No VLM models available, keeping the original model {model}")
    elif model not in vlm_models:
        logging.warning(
            f"Model {model} is not available, using the first available model {vlm_models[0]}"
        )
        model = vlm_models[0]

    messages = [
        {
            "role": "system",
            "content": [{"type": "text", "text": system_prompt}],
        },  # 此方法皆适用于两种 VL 模型
        # {
        #     "role": "system",
        #     "content": system_prompt,
        # },  # role 为 "system" 的这种方式只适用于 QwenVL 系列模型,并不适用于 InternVL 系列模型
    ]

    user_content = []
    for base64_image in base64_images:
        user_content.append(
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/webp;base64,{base64_image}",
                    "detail": detail,
                },
            }
        )
    user_content.append({"type": "text", "text": user_prompt})

    messages.append({"role": "user", "content": user_content})

    payload = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "top_p": 0.9,
        "top_k": 50,
        "stream": False,
        "n": 1,
    }
    if "prompt_id" in extra_data:
        payload["prompt_id"] = extra_data["prompt_id"]
    data = json.dumps(payload).encode("utf-8")

    response = client.send_request(
        url=api_url,
        headers=headers,
        data=data,
        callback=None,
    )
    return response


K = TypeVar("K")
V = TypeVar("V")
R = TypeVar("R")


class TTLCache(Generic[K, V]):
    """线程安全 TTL 内存缓存（仅依赖标准库）"""

    def __init__(self, ttl_sec: float):
        self.ttl = ttl_sec
        self._data: Dict[K, tuple[V, float]] = {}
        self._lock = threading.RLock()
        self._stop_evt = threading.Event()
        # 后台清扫线程
        self._cleaner = threading.Thread(target=self._cleanup, daemon=True)
        self._cleaner.start()

    # ---------- 公共 API ----------
    def set(self, key: K, value: V) -> None:
        """写入/刷新键值"""
        with self._lock:
            self._data[key] = (value, time.time() + self.ttl)

    def get(self, key: K) -> Optional[V]:
        """读取键值；不存在或已过期返回 None"""
        with self._lock:
            val, expire = self._data.get(key, (None, 0))
            if val is None or time.time() > expire:
                self._data.pop(key, None)
                return None
            return val

    def delete(self, key: K) -> None:
        """手动删除"""
        with self._lock:
            self._data.pop(key, None)

    def stop(self):
        """停止后台线程（程序退出前调用）"""
        self._stop_evt.set()
        self._cleaner.join(timeout=self.ttl + 1)

    # ---------- 内部 ----------
    def _cleanup(self):
        """周期清扫过期键"""
        while not self._stop_evt.wait(self.ttl / 2):
            with self._lock:
                now = time.time()
                for key, (_, expire) in list(self._data.items()):
                    if now > expire:
                        self._data.pop(key, None)


class SingleFlight(Generic[R]):
    """
    最终正确版 SingleFlight

    核心设计：
    1. 全局锁保护 _call_map
    2. 每个 call 有自己的 Condition 用于等待/通知
    3. 引用计数（waiters）跟踪等待者数量
    4. 最后一个等待者负责清理 map
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._call_map: dict[str, "SingleFlight._Call[R]"] = {}

    class _Call(Generic[R]):
        __slots__ = ("cond", "done", "result", "err", "waiters")

        def __init__(self):
            self.cond = threading.Condition()
            self.done = False
            self.result: Optional[R] = None
            self.err: Optional[BaseException] = None
            self.waiters = 0

    def do(
        self, key: str, fn: Callable[[], R]
    ) -> tuple[Optional[R], bool, Optional[BaseException]]:
        """
        执行 fn，相同 key 的并发请求会合并

        返回: (result, shared, exception)
        - shared=False: 本次是 leader，实际执行了 fn
        - shared=True: 本次是 follower，复用了 leader 的结果
        - exception: 执行过程中的异常（仅对 follower 有效）
        """
        call = None
        is_leader = False

        # 阶段1：获取或创建 call
        with self._lock:
            call = self._call_map.get(key)
            if call is None:
                # 创建新 call
                call = self._Call[R]()
                call.waiters = 1
                self._call_map[key] = call
                is_leader = True
            else:
                # 复用已有 call
                call.waiters += 1
                is_leader = False

        if is_leader:
            # Leader：实际执行 fn
            exception_to_raise = None
            try:
                try:
                    result = fn()
                    with call.cond:
                        call.result = result
                        call.done = True
                        call.cond.notify_all()
                except BaseException as e:
                    with call.cond:
                        call.err = e
                        call.done = True
                        call.cond.notify_all()
                    exception_to_raise = e
            finally:
                # 清理：递减 waiters，如果为0则从 map 移除
                with self._lock:
                    call.waiters -= 1
                    if call.waiters == 0:
                        self._call_map.pop(key, None)

            if exception_to_raise is not None:
                raise exception_to_raise
            return call.result, False, None

        else:
            # Follower：等待 leader 完成
            with call.cond:
                while not call.done:
                    call.cond.wait()
                result, err = call.result, call.err

            # 清理
            with self._lock:
                call.waiters -= 1
                if call.waiters == 0:
                    self._call_map.pop(key, None)

            return result, True, err


# ==================== 完整测试套件 ====================

# class TestSingleFlightFinal(unittest.TestCase):
#     """SingleFlightFinal 完整测试"""

#     def setUp(self):
#         self.sf = SingleFlightFinal[str]()

#     def test_basic_concurrent_merge(self):
#         """基础测试：10个并发请求合并为1次执行"""
#         execute_count = [0]
#         lock = threading.Lock()

#         def fn():
#             with lock:
#                 execute_count[0] += 1
#             time.sleep(0.05)
#             return "result"

#         barrier = threading.Barrier(10)
#         results = []

#         def worker():
#             barrier.wait()
#             results.append(self.sf.do("key", fn))

#         threads = [threading.Thread(target=worker) for _ in range(10)]
#         for t in threads:
#             t.start()
#         for t in threads:
#             t.join()

#         self.assertEqual(execute_count[0], 1, f"应该只执行1次，实际{execute_count[0]}次")

#         shared_count = sum(1 for r in results if r[1])
#         self.assertEqual(shared_count, 9, "9个follower")
#         print(f"✅ 基础并发合并：执行{execute_count[0]}次，{shared_count}个follower")

#     def test_exception_propagation(self):
#         """异常传播测试"""
#         def failing_fn():
#             time.sleep(0.01)
#             raise ValueError("test error")

#         barrier = threading.Barrier(5)
#         exceptions = []
#         results = []

#         def worker():
#             barrier.wait()
#             try:
#                 result, shared, err = self.sf.do("key", failing_fn)
#                 results.append((result, shared, err))
#             except Exception as e:
#                 exceptions.append(e)

#         threads = [threading.Thread(target=worker) for _ in range(5)]
#         for t in threads:
#             t.start()
#         for t in threads:
#             t.join()

#         # 1个leader抛出，4个follower通过err返回
#         self.assertEqual(len(exceptions), 1)
#         self.assertEqual(len(results), 4)

#         for r in results:
#             self.assertIsInstance(r[2], ValueError)
#         print(f"✅ 异常传播：{len(exceptions)}抛出，{len(results)}个通过err返回")

#     def test_memory_cleanup(self):
#         """内存清理测试"""
#         def fn():
#             return "data"

#         barrier = threading.Barrier(5)

#         def worker():
#             barrier.wait()
#             return self.sf.do("key", fn)

#         threads = [threading.Thread(target=worker) for _ in range(5)]
#         for t in threads:
#             t.start()
#         for t in threads:
#             t.join()

#         time.sleep(0.01)
#         self.assertEqual(len(self.sf._call_map), 0, "call应该被清理")
#         print(f"✅ 内存清理通过")

#     def test_multi_key_isolation(self):
#         """多key隔离测试"""
#         call_counts = {}
#         lock = threading.Lock()

#         def make_fn(key):
#             def fn():
#                 with lock:
#                     call_counts[key] = call_counts.get(key, 0) + 1
#                 time.sleep(0.01)
#                 return f"result_{key}"
#             return fn

#         # 3个key各5个并发
#         threads = []
#         for key in ["a", "b", "c"]:
#             barrier = threading.Barrier(5)
#             def worker(k, b):
#                 b.wait()
#                 return self.sf.do(k, make_fn(k))
#             for _ in range(5):
#                 threads.append(threading.Thread(target=worker, args=(key, barrier)))

#         for t in threads:
#             t.start()
#         for t in threads:
#             t.join()

#         self.assertEqual(len(call_counts), 3)
#         self.assertTrue(all(c == 1 for c in call_counts.values()))
#         print(f"✅ 多key隔离：{call_counts}")

#     def test_high_concurrency_single_key(self):
#         """单key高并发测试"""
#         counter = [0]
#         lock = threading.Lock()

#         def fn():
#             with lock:
#                 counter[0] += 1
#             time.sleep(0.005)
#             return "ok"

#         barrier = threading.Barrier(100)

#         def worker():
#             barrier.wait()
#             return self.sf.do("key", fn)

#         threads = [threading.Thread(target=worker) for _ in range(100)]
#         for t in threads:
#             t.start()
#         for t in threads:
#             t.join()

#         # 单key高并发下，合并率应该很高（通常99%+）
#         self.assertLessEqual(counter[0], 5, f"执行{counter[0]}次，应该接近1次")
#         print(f"✅ 单key高并发：100线程，执行{counter[0]}次")


# def realistic_stress_test():
#     """真实场景压力测试"""
#     print("\n" + "="*60)
#     print("真实场景压力测试：50并发/key，10keys")
#     print("="*60)

#     for round_num in range(3):
#         sf = SingleFlightFinal[int]()
#         call_counts = {}
#         errors = []
#         lock = threading.Lock()

#         def make_fn(key_id):
#             def fn():
#                 with lock:
#                     call_counts[key_id] = call_counts.get(key_id, 0) + 1
#                 time.sleep(0.001)  # 1ms工作
#                 return key_id
#             return fn

#         # 50并发/key，10keys = 500线程
#         concurrency_per_key = 50
#         num_keys = 10
#         total = concurrency_per_key * num_keys

#         barrier = threading.Barrier(total)

#         def worker(key_id):
#             try:
#                 barrier.wait()
#                 return sf.do(f"key_{key_id}", make_fn(key_id))
#             except Exception as e:
#                 with lock:
#                     errors.append(str(e))
#                 raise

#         threads = []
#         for k in range(num_keys):
#             for _ in range(concurrency_per_key):
#                 threads.append(threading.Thread(target=worker, args=(k,)))

#         start = time.time()
#         for t in threads:
#             t.start()
#         for t in threads:
#             t.join()
#         elapsed = time.time() - start

#         total_creations = sum(call_counts.values())
#         merge_rate = (total - total_creations) / total * 100

#         print(f"轮{round_num+1}: {total}请求，执行{total_creations}次，合并率{merge_rate:.1f}%，耗时{elapsed:.3f}s")

#         if errors:
#             print(f"   错误: {len(errors)}个")


# if __name__ == "__main__":
#     print("="*60)
#     print("SingleFlightFinal 完整测试")
#     print("="*60)

#     suite = unittest.TestLoader().loadTestsFromTestCase(TestSingleFlightFinal)
#     runner = unittest.TextTestRunner(verbosity=2)
#     result = runner.run(suite)

#     if result.wasSuccessful():
#         realistic_stress_test()
#         print("\n🎉 所有测试通过！")
#     else:
#         print("\n❌ 测试失败")


_MODELS_CACHE = TTLCache[str, list[str]](ttl_sec=600)
_TRD_MODELS_CACHE = TTLCache[str, dict](ttl_sec=600)
_SF = SingleFlight[None]()


def cache_models(request_api_key: str):
    # TODO: 效果待验证，目前节点只会被ComfyUI串行执行，所以不会出现竞争
    # 重试最多五次
    max_retries = 5
    for i in range(max_retries):
        try:
            _, shared, e = _SF.do(
                "_cache_models", lambda: _cache_models(request_api_key)
            )
            if e is not None:
                raise e
            return
        except Exception:
            logging.error(f"Failed to cache models on try #{i+1}")
            if i < max_retries - 1:
                time.sleep(5)
    logging.error(f"Failed to cache models after {max_retries} retries")


def _cache_models(request_api_key: str):
    # ① 开一条新线程专门跑协程 - 应该不需要在prompt那层上锁，因为并发只有1
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        api_client = APIClient()
        all_models = pool.submit(
            asyncio.run, api_client.fetch_all_llm_models(request_api_key)
        ).result()
        if len(all_models) == 0:
            raise Exception(f"{errnos.NO_MODEL_FOUND}")
        llm_models = [
            model
            for model in all_models
            if not (re.search(r"\d+(\.\d+)?v", model.lower()) or "vl" in model.lower())
        ]
        vlm_models = [
            model
            for model in all_models
            if re.search(r"\d+(\.\d+)?v", model.lower()) or "vl" in model.lower()
        ]
        _MODELS_CACHE.set("llm_models", llm_models)
        _MODELS_CACHE.set("vlm_models", vlm_models)


def get_trd_models(type: str):
    return _TRD_MODELS_CACHE.get(type)


def cache_trd_models(type, request_api_key: str):
    # TODO: 效果待验证，目前节点只会被ComfyUI串行执行，所以不会出现竞争
    # 重试最多五次
    max_retries = 5
    for i in range(max_retries):
        try:
            _, shared, e = _SF.do(
                f"_cache_trd_models_{type}",
                lambda: _cache_trd_models(type, request_api_key),
            )
            logging.debug(
                f"cache_trd_models_{type} called, shared: {shared}, e: {str(e)}"
            )
            if e is not None:
                raise e
            return
        except Exception as ex:
            logging.error(f"Failed to cache trd models on try #{i+1}, error: {str(ex)}")
            if i < max_retries - 1:
                time.sleep(5)
    logging.error(f"Failed to cache trd models after {max_retries} retries")


def _cache_trd_models(type, request_api_key: str):
    # ① 开一条新线程专门跑协程 - 应该不需要在prompt那层上锁，因为并发只有1
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        api_client = APIClient()
        models, err = pool.submit(
            asyncio.run, api_client.get_trd_nodes_by_type(type, request_api_key)
        ).result()
        logging.debug(f"_cache_trd_models got response: {models}")
        if err is not None:
            raise Exception(f"{err}")
        if not models or "nodes" not in models:
            raise Exception(f"{errnos.NO_MODEL_FOUND}")
        _TRD_MODELS_CACHE.set(type, models)


class AsyncAtomicCounter(object):
    """An atomic, async counter"""

    def __init__(self, initial=0):
        self._value = initial
        self._lock = asyncio.Lock()

    async def increment(self, num=1):
        """Atomically increment the counter by num and return the new value"""
        async with self._lock:
            self._value += num
            return self._value

    async def value(self):
        """Get the current value (this read is also atomic due to the lock)"""
        async with self._lock:
            return self._value
