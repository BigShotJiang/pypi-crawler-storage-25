from __future__ import annotations

import subprocess
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

from hyperloop.cli.app import cli
from hyperloop.reconciliation.models.configuration import Configuration


def _git_init(path: Path) -> None:
    subprocess.run(
        ["git", "init", str(path)],
        check=True,
        capture_output=True,
    )


class TestInitCreatesOverlay:
    def test_creates_kustomization_yaml(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        kustomization = tmp_path / ".hyperloop" / "agents" / "kustomization.yaml"
        assert kustomization.is_file()

    def test_kustomization_references_base_templates(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])
        assert result.exit_code == 0

        kustomization = tmp_path / ".hyperloop" / "agents" / "kustomization.yaml"
        content = yaml.safe_load(kustomization.read_text())
        assert content["apiVersion"] == "kustomize.config.k8s.io/v1beta1"
        assert content["kind"] == "Kustomization"
        assert len(content["resources"]) == 1
        resource = content["resources"][0]
        assert "github.com" in resource
        assert "//base" in resource
        assert "?ref=" in resource

    def test_overlay_directory_exists_after_init(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])
        assert result.exit_code == 0

        overlay = tmp_path / ".hyperloop" / "agents"
        assert overlay.is_dir()


class TestInitIdempotent:
    def test_does_not_overwrite_existing_kustomization(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        overlay_dir = tmp_path / ".hyperloop" / "agents"
        overlay_dir.mkdir(parents=True)
        kustomization = overlay_dir / "kustomization.yaml"
        custom_content = "apiVersion: custom\nkind: Kustomization\n"
        kustomization.write_text(custom_content)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        assert kustomization.read_text() == custom_content

    def test_exits_successfully_when_already_initialized(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        overlay_dir = tmp_path / ".hyperloop" / "agents"
        overlay_dir.mkdir(parents=True)
        (overlay_dir / "kustomization.yaml").write_text("existing: true\n")

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0


class TestInitNonGitDirectory:
    def test_fails_with_non_zero_exit_code(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code != 0

    def test_error_mentions_git_repository(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert "git repository" in result.output.lower()


class TestInitOverlayPathValidation:
    def test_scaffolded_overlay_passes_configuration_validator(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])
        assert result.exit_code == 0

        overlay = tmp_path / ".hyperloop" / "agents"
        assert overlay.is_dir()
        Configuration.overlay_path_must_exist(str(overlay))


class TestInitEdgeCases:
    def test_fails_when_hyperloop_dir_is_a_file(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".hyperloop").write_text("not a directory")

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code != 0


class TestInitCreatesConfigFile:
    def test_creates_hyperloop_yaml(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        config_file = tmp_path / ".hyperloop.yaml"
        assert config_file.is_file()

    def test_config_file_contains_all_fields(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])
        assert result.exit_code == 0

        config_file = tmp_path / ".hyperloop.yaml"
        content = yaml.safe_load(config_file.read_text())
        for field_name in Configuration.model_fields:
            assert field_name in content, f"Missing field: {field_name}"

    def test_config_file_has_default_values(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])
        assert result.exit_code == 0

        config_file = tmp_path / ".hyperloop.yaml"
        content = yaml.safe_load(config_file.read_text())
        assert content["convergence_bound"] == 3
        assert content["trunk_branch"] == "main"
        assert content["integration_strategy"] == "pr"
        assert content["specs_directory"] == "specs/"
        assert content["spec_glob"] == "*.spec.md"

    def test_config_file_loadable_by_from_yaml(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)
        (tmp_path / "specs").mkdir()

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])
        assert result.exit_code == 0

        config = Configuration.from_yaml(tmp_path / ".hyperloop.yaml")
        assert config.convergence_bound == 3
        assert config.trunk_branch == "main"


class TestInitConfigCliOverrides:
    def test_trunk_branch_override(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init", "--trunk-branch", "develop"])
        assert result.exit_code == 0

        content = yaml.safe_load((tmp_path / ".hyperloop.yaml").read_text())
        assert content["trunk_branch"] == "develop"

    def test_integration_strategy_override(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init", "--integration-strategy", "pr_automerge"])
        assert result.exit_code == 0

        content = yaml.safe_load((tmp_path / ".hyperloop.yaml").read_text())
        assert content["integration_strategy"] == "pr_automerge"

    def test_multiple_overrides(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(
            cli,
            [
                "init",
                "--trunk-branch",
                "develop",
                "--integration-strategy",
                "pr_automerge",
            ],
        )
        assert result.exit_code == 0

        content = yaml.safe_load((tmp_path / ".hyperloop.yaml").read_text())
        assert content["trunk_branch"] == "develop"
        assert content["integration_strategy"] == "pr_automerge"
        assert content["convergence_bound"] == 3

    def test_specs_directory_override(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init", "--specs-directory", "doc/specs/"])
        assert result.exit_code == 0

        content = yaml.safe_load((tmp_path / ".hyperloop.yaml").read_text())
        assert content["specs_directory"] == "doc/specs/"

    def test_spec_glob_override(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init", "--spec-glob", "*.md"])
        assert result.exit_code == 0

        content = yaml.safe_load((tmp_path / ".hyperloop.yaml").read_text())
        assert content["spec_glob"] == "*.md"


class TestInitValidatesOverrides:
    def test_convergence_bound_zero_fails(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init", "--convergence-bound", "0"])

        assert result.exit_code != 0
        assert (tmp_path / ".hyperloop.yaml").exists() is False

    def test_convergence_bound_negative_fails(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init", "--convergence-bound", "-1"])

        assert result.exit_code != 0
        assert (tmp_path / ".hyperloop.yaml").exists() is False

    def test_invalid_integration_strategy_fails(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init", "--integration-strategy", "invalid"])

        assert result.exit_code != 0

    def test_no_config_created_on_validation_failure(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        runner.invoke(cli, ["init", "--convergence-bound", "0"])

        assert not (tmp_path / ".hyperloop.yaml").exists()
        assert not (tmp_path / ".hyperloop" / "agents").exists()


class TestInitDoesNotOverwriteConfig:
    def test_preserves_existing_config(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        config_file = tmp_path / ".hyperloop.yaml"
        custom_content = "trunk_branch: custom\n"
        config_file.write_text(custom_content)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        assert config_file.read_text() == custom_content

    def test_preserves_existing_config_with_overrides(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        config_file = tmp_path / ".hyperloop.yaml"
        custom_content = "trunk_branch: custom\n"
        config_file.write_text(custom_content)

        runner = CliRunner()
        result = runner.invoke(cli, ["init", "--trunk-branch", "develop"])

        assert result.exit_code == 0
        assert config_file.read_text() == custom_content


class TestInitBothArtifactsIndependent:
    def test_creates_config_when_overlay_exists(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        overlay_dir = tmp_path / ".hyperloop" / "agents"
        overlay_dir.mkdir(parents=True)
        (overlay_dir / "kustomization.yaml").write_text("existing: true\n")

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        assert (tmp_path / ".hyperloop.yaml").is_file()
        assert (overlay_dir / "kustomization.yaml").read_text() == "existing: true\n"

    def test_creates_overlay_when_config_exists(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        config_file = tmp_path / ".hyperloop.yaml"
        config_file.write_text("trunk_branch: custom\n")

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        assert (tmp_path / ".hyperloop" / "agents" / "kustomization.yaml").is_file()
        assert config_file.read_text() == "trunk_branch: custom\n"

    def test_both_created_from_scratch(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        assert (tmp_path / ".hyperloop.yaml").is_file()
        assert (tmp_path / ".hyperloop" / "agents" / "kustomization.yaml").is_file()

    def test_already_initialized_when_both_exist(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        overlay_dir = tmp_path / ".hyperloop" / "agents"
        overlay_dir.mkdir(parents=True)
        (overlay_dir / "kustomization.yaml").write_text("existing: true\n")
        (tmp_path / ".hyperloop.yaml").write_text("trunk_branch: custom\n")

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        assert "Already initialized" in result.output


class TestInitNextSteps:
    def test_shows_next_steps(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        assert "Next steps:" in result.output
        assert "specs/" in result.output
        assert "*.spec.md" in result.output
        assert "uvx hyperloop run" in result.output

    def test_shows_overlay_creation_message(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        assert "Initialized hyperloop in" in result.output

    def test_shows_config_creation_message(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        assert "Created .hyperloop.yaml" in result.output

    def test_no_next_steps_when_already_initialized(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        overlay_dir = tmp_path / ".hyperloop" / "agents"
        overlay_dir.mkdir(parents=True)
        (overlay_dir / "kustomization.yaml").write_text("existing: true\n")
        (tmp_path / ".hyperloop.yaml").write_text("trunk_branch: main\n")

        runner = CliRunner()
        result = runner.invoke(cli, ["init"])

        assert result.exit_code == 0
        assert "Next steps:" not in result.output


class TestInitNextStepsReflectOverrides:
    def test_specs_directory_reflected(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _git_init(tmp_path)
        monkeypatch.chdir(tmp_path)

        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["init", "--specs-directory", "doc/specs/", "--spec-glob", "*.md"],
        )

        assert result.exit_code == 0
        assert "doc/specs/" in result.output
        assert "*.md" in result.output


class TestInitRegistered:
    def test_init_appears_in_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])

        assert "init" in result.output
