from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

from hyperloop.reconciliation.adapters.git_workspace_manager import (
    GitWorkspaceManager,
)
from hyperloop.reconciliation.models.integration_poll_result import (
    IntegrationPollResult,
    IntegrationPollStatus,
)
from hyperloop.reconciliation.models.integration_strategy import IntegrationStrategy
from hyperloop.reconciliation.models.merge_result import MergeOutcome, MergeResult
from hyperloop.reconciliation.models.rebase_result import RebaseOutcome, RebaseResult


def _git(
    repo: Path, *args: str, input: str | None = None, check: bool = True
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=repo,
        capture_output=True,
        text=True,
        input=input,
        check=check,
    )


def _branch_exists_local(repo: Path, branch: str) -> bool:
    result = _git(repo, "rev-parse", "--verify", f"refs/heads/{branch}", check=False)
    return result.returncode == 0


def _branch_exists_remote(remote: Path, branch: str) -> bool:
    result = _git(remote, "rev-parse", "--verify", f"refs/heads/{branch}", check=False)
    return result.returncode == 0


def _create_work_commit(repo: Path, branch: str, filename: str, content: str) -> None:
    _git(repo, "checkout", branch)
    (repo / filename).write_text(content)
    _git(repo, "add", filename)
    _git(repo, "commit", "-m", f"Add {filename}")
    _git(repo, "checkout", "main")


def _create_trunk_commit(repo: Path, filename: str, content: str) -> None:
    (repo / filename).write_text(content)
    _git(repo, "add", filename)
    _git(repo, "commit", "-m", f"Add {filename}")
    _git(repo, "push", "origin", "main")


def _push_branch(repo: Path, branch: str) -> None:
    _git(repo, "push", "origin", branch)


BRANCH_PREFIX = "hyperloop/"
TRUNK = "main"
BLOB_SHA = "abc123"


def _setup_fake_gh(tmp_path: Path, response: str) -> Path:
    bin_dir = tmp_path / "fakebin"
    bin_dir.mkdir(exist_ok=True)
    args_file = tmp_path / "gh_args.txt"
    response_file = tmp_path / "gh_response.txt"
    response_file.write_text(response)
    script = bin_dir / "gh"
    script.write_text(f'#!/bin/bash\necho "$@" > {args_file}\ncat "{response_file}"\n')
    script.chmod(0o755)
    os.environ["PATH"] = f"{bin_dir}:{os.environ.get('PATH', '')}"
    return args_file


def _setup_fake_gh_multi(tmp_path: Path, response: str) -> Path:
    bin_dir = tmp_path / "fakebin"
    bin_dir.mkdir(exist_ok=True)
    args_log = tmp_path / "gh_args_log.txt"
    response_file = tmp_path / "gh_response.txt"
    response_file.write_text(response)
    script = bin_dir / "gh"
    script.write_text(f'#!/bin/bash\necho "$@" >> {args_log}\ncat "{response_file}"\n')
    script.chmod(0o755)
    os.environ["PATH"] = f"{bin_dir}:{os.environ.get('PATH', '')}"
    return args_log


def _setup_failing_gh(tmp_path: Path, stderr_message: str) -> None:
    bin_dir = tmp_path / "fakebin"
    bin_dir.mkdir(exist_ok=True)
    script = bin_dir / "gh"
    script.write_text(f'#!/bin/bash\necho "{stderr_message}" >&2\nexit 1\n')
    script.chmod(0o755)
    os.environ["PATH"] = f"{bin_dir}:{os.environ.get('PATH', '')}"


def _setup_fake_gh_first_succeeds_then_fails(
    tmp_path: Path, success_response: str
) -> None:
    bin_dir = tmp_path / "fakebin"
    bin_dir.mkdir(exist_ok=True)
    counter_file = tmp_path / "gh_call_count"
    script = bin_dir / "gh"
    script.write_text(
        f"#!/bin/bash\n"
        f'count=$(cat "{counter_file}" 2>/dev/null || echo 0)\n'
        f"count=$((count + 1))\n"
        f'echo $count > "{counter_file}"\n'
        f'if [ "$count" -eq 1 ]; then\n'
        f'    echo "{success_response}"\n'
        f"    exit 0\n"
        f"fi\n"
        f'echo "GraphQL: Protected branch rules not configured" >&2\n'
        f"exit 1\n"
    )
    script.chmod(0o755)
    os.environ["PATH"] = f"{bin_dir}:{os.environ.get('PATH', '')}"


def _setup_fake_gh_auto_fails_direct_succeeds(
    tmp_path: Path, success_response: str
) -> Path:
    bin_dir = tmp_path / "fakebin"
    bin_dir.mkdir(exist_ok=True)
    counter_file = tmp_path / "gh_call_count"
    args_log = tmp_path / "gh_args_log.txt"
    script = bin_dir / "gh"
    script.write_text(
        f"#!/bin/bash\n"
        f'echo "$@" >> "{args_log}"\n'
        f'count=$(cat "{counter_file}" 2>/dev/null || echo 0)\n'
        f"count=$((count + 1))\n"
        f'echo $count > "{counter_file}"\n'
        f'if [ "$count" -eq 1 ]; then\n'
        f'    echo "{success_response}"\n'
        f"    exit 0\n"
        f"fi\n"
        f'if echo "$@" | grep -q -- "--auto"; then\n'
        f'    echo "GraphQL: Protected branch rules not configured" >&2\n'
        f"    exit 1\n"
        f"fi\n"
        f"exit 0\n"
    )
    script.chmod(0o755)
    os.environ["PATH"] = f"{bin_dir}:{os.environ.get('PATH', '')}"
    return args_log


def _make_manager(
    repo_path: Path,
    *,
    integration_strategy: IntegrationStrategy = IntegrationStrategy.PR,
) -> GitWorkspaceManager:
    return GitWorkspaceManager(
        repo_path,
        branch_prefix=BRANCH_PREFIX,
        trunk_branch=TRUNK,
        remote="origin",
        integration_strategy=integration_strategy,
    )


def _delivery(blob_sha: str) -> str:
    return f"{BRANCH_PREFIX}spec/{blob_sha}/delivery"


def _task(blob_sha: str, task_id: int) -> str:
    return f"{BRANCH_PREFIX}spec/{blob_sha}/task/{task_id}"


def _verifier(blob_sha: str) -> str:
    return f"{BRANCH_PREFIX}spec/{blob_sha}/verifier"


class TestCreateDeliveryWorkspace:
    def test_creates_branch_from_trunk_head(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        trunk_head = _git(local, "rev-parse", "main").stdout.strip()

        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        delivery_head = _git(local, "rev-parse", _delivery(BLOB_SHA)).stdout.strip()
        assert delivery_head == trunk_head

    def test_returns_workspace_id(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)

        workspace_id = manager.create_delivery_workspace(BLOB_SHA)

        assert workspace_id == f"delivery/{BLOB_SHA}"

    def test_idempotent(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)

        first = manager.create_delivery_workspace(BLOB_SHA)
        second = manager.create_delivery_workspace(BLOB_SHA)

        assert first == second

    def test_pushes_branch_to_remote(self, git_env: tuple[Path, Path]) -> None:
        local, remote = git_env
        manager = _make_manager(local)

        manager.create_delivery_workspace(BLOB_SHA)

        assert _branch_exists_remote(remote, _delivery(BLOB_SHA))

    def test_separate_workspaces_per_blob_sha(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)

        ws1 = manager.create_delivery_workspace("abc123")
        ws2 = manager.create_delivery_workspace("def456")

        assert ws1 != ws2
        assert _branch_exists_local(local, _delivery("abc123"))
        assert _branch_exists_local(local, _delivery("def456"))


class TestCreateTaskWorkspace:
    def test_creates_branch_from_delivery(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        delivery_head = _git(local, "rev-parse", _delivery(BLOB_SHA)).stdout.strip()

        manager.create_task_workspace(BLOB_SHA, 5, "implement login")

        parent_of_briefing = _git(
            local, "rev-parse", f"{_task(BLOB_SHA, 5)}~1"
        ).stdout.strip()
        assert parent_of_briefing == delivery_head

    def test_returns_workspace_id(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        workspace_id = manager.create_task_workspace(BLOB_SHA, 5, "implement login")

        assert workspace_id == f"task/{BLOB_SHA}/5"

    def test_creates_empty_commit_with_briefing(
        self, git_env: tuple[Path, Path]
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        briefing = "Task 5: implement login\nSpec: auth.spec.md"
        manager.create_task_workspace(BLOB_SHA, 5, briefing)

        message = _git(
            local, "log", "-1", "--format=%B", _task(BLOB_SHA, 5)
        ).stdout.strip()
        assert "implement login" in message
        assert "auth.spec.md" in message

    def test_briefing_commit_has_no_file_changes(
        self, git_env: tuple[Path, Path]
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "implement login")

        result = _git(
            local,
            "diff-tree",
            "--no-commit-id",
            "--name-only",
            "-r",
            _task(BLOB_SHA, 5),
        )
        assert result.stdout.strip() == ""

    def test_pushes_branch_to_remote(self, git_env: tuple[Path, Path]) -> None:
        local, remote = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        manager.create_task_workspace(BLOB_SHA, 5, "implement login")

        assert _branch_exists_remote(remote, _task(BLOB_SHA, 5))

    def test_idempotent(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        first = manager.create_task_workspace(BLOB_SHA, 5, "task 5")
        second = manager.create_task_workspace(BLOB_SHA, 5, "task 5")

        assert first == second

    def test_multiple_tasks_for_same_spec(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        ws1 = manager.create_task_workspace(BLOB_SHA, 5, "task 5")
        ws2 = manager.create_task_workspace(BLOB_SHA, 6, "task 6")

        assert ws1 != ws2
        assert _branch_exists_local(local, _task(BLOB_SHA, 5))
        assert _branch_exists_local(local, _task(BLOB_SHA, 6))


class TestCreateVerificationWorkspace:
    def test_creates_branch_from_delivery(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        delivery_head = _git(local, "rev-parse", _delivery(BLOB_SHA)).stdout.strip()

        manager.create_verification_workspace(BLOB_SHA)

        verifier_head = _git(local, "rev-parse", _verifier(BLOB_SHA)).stdout.strip()
        assert verifier_head == delivery_head

    def test_returns_workspace_id(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        workspace_id = manager.create_verification_workspace(BLOB_SHA)

        assert workspace_id == f"verification/{BLOB_SHA}"

    def test_recreates_on_second_call(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        manager.create_verification_workspace(BLOB_SHA)

        _create_work_commit(local, _verifier(BLOB_SHA), "check.txt", "checking")
        old_head = _git(local, "rev-parse", _verifier(BLOB_SHA)).stdout.strip()

        manager.create_verification_workspace(BLOB_SHA)

        new_head = _git(local, "rev-parse", _verifier(BLOB_SHA)).stdout.strip()
        assert new_head != old_head

        delivery_head = _git(local, "rev-parse", _delivery(BLOB_SHA)).stdout.strip()
        assert new_head == delivery_head

    def test_pushes_branch_to_remote(self, git_env: tuple[Path, Path]) -> None:
        local, remote = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        manager.create_verification_workspace(BLOB_SHA)

        assert _branch_exists_remote(remote, _verifier(BLOB_SHA))


class TestMergeTask:
    def test_clean_merge_returns_success(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")

        task_branch = _task(BLOB_SHA, 5)
        _create_work_commit(local, task_branch, "login.py", "def login(): pass")
        _push_branch(local, task_branch)

        result = manager.merge_task(BLOB_SHA, 5)

        assert result.outcome == MergeOutcome.SUCCESS
        assert result.conflict_details is None

    def test_merge_incorporates_task_work(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")

        task_branch = _task(BLOB_SHA, 5)
        _create_work_commit(local, task_branch, "login.py", "def login(): pass")
        _push_branch(local, task_branch)

        manager.merge_task(BLOB_SHA, 5)

        result = _git(local, "show", f"{_delivery(BLOB_SHA)}:login.py")
        assert "def login(): pass" in result.stdout

    def test_deletes_local_task_branch_on_success(
        self, git_env: tuple[Path, Path]
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")

        task_branch = _task(BLOB_SHA, 5)
        _create_work_commit(local, task_branch, "login.py", "def login(): pass")
        _push_branch(local, task_branch)

        manager.merge_task(BLOB_SHA, 5)

        assert not _branch_exists_local(local, task_branch)

    def test_deletes_remote_task_branch_on_success(
        self, git_env: tuple[Path, Path]
    ) -> None:
        local, remote = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")

        task_branch = _task(BLOB_SHA, 5)
        _create_work_commit(local, task_branch, "login.py", "def login(): pass")
        _push_branch(local, task_branch)

        manager.merge_task(BLOB_SHA, 5)

        assert not _branch_exists_remote(remote, task_branch)

    def test_pushes_merged_delivery_branch(self, git_env: tuple[Path, Path]) -> None:
        local, remote = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")

        task_branch = _task(BLOB_SHA, 5)
        _create_work_commit(local, task_branch, "login.py", "def login(): pass")
        _push_branch(local, task_branch)

        manager.merge_task(BLOB_SHA, 5)

        delivery_branch = _delivery(BLOB_SHA)
        local_head = _git(local, "rev-parse", delivery_branch).stdout.strip()
        remote_head = _git(
            remote, "rev-parse", f"refs/heads/{delivery_branch}"
        ).stdout.strip()
        assert local_head == remote_head

    def test_conflict_returns_conflict_result(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")

        delivery_branch = _delivery(BLOB_SHA)
        task_branch = _task(BLOB_SHA, 5)

        _create_work_commit(local, delivery_branch, "shared.py", "delivery version")
        _push_branch(local, delivery_branch)
        _create_work_commit(local, task_branch, "shared.py", "task version")
        _push_branch(local, task_branch)

        result = manager.merge_task(BLOB_SHA, 5)

        assert result.outcome == MergeOutcome.CONFLICT
        assert result.conflict_details is not None

    def test_conflict_preserves_task_branch(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")

        delivery_branch = _delivery(BLOB_SHA)
        task_branch = _task(BLOB_SHA, 5)

        _create_work_commit(local, delivery_branch, "shared.py", "delivery version")
        _push_branch(local, delivery_branch)
        _create_work_commit(local, task_branch, "shared.py", "task version")
        _push_branch(local, task_branch)

        manager.merge_task(BLOB_SHA, 5)

        assert _branch_exists_local(local, task_branch)


class TestIntegrate:
    _PR_URL = "https://github.com/test/repo/pull/1"

    def test_pushes_delivery_branch_to_remote(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, remote = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        delivery_branch = _delivery(BLOB_SHA)
        _create_work_commit(local, delivery_branch, "login.py", "def login(): pass")

        _setup_fake_gh(tmp_path, self._PR_URL)
        integration_id = manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        local_head = _git(local, "rev-parse", delivery_branch).stdout.strip()
        remote_head = _git(
            remote, "rev-parse", f"refs/heads/{delivery_branch}"
        ).stdout.strip()
        assert local_head == remote_head
        assert isinstance(integration_id, str)
        assert len(integration_id) > 0

    def test_pr_forwards_title_and_body(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        _create_work_commit(local, _delivery(BLOB_SHA), "auth.py", "pass")

        args_file = _setup_fake_gh(tmp_path, self._PR_URL)
        manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        captured_args = args_file.read_text()
        assert "Implement auth" in captured_args
        assert "Auth module" in captured_args

    def test_pr_targets_trunk(self, git_env: tuple[Path, Path], tmp_path: Path) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        _create_work_commit(local, _delivery(BLOB_SHA), "auth.py", "pass")

        args_file = _setup_fake_gh(tmp_path, self._PR_URL)
        manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        captured_args = args_file.read_text()
        assert TRUNK in captured_args

    def test_truncates_long_title(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        _create_work_commit(local, _delivery(BLOB_SHA), "auth.py", "pass")

        long_title = "A" * 500
        args_file = _setup_fake_gh(tmp_path, self._PR_URL)
        manager.integrate(BLOB_SHA, "specs/auth.spec.md", long_title, "body")

        captured_args = args_file.read_text()
        assert "A" * 256 in captured_args
        assert "A" * 257 not in captured_args

    def test_returns_pr_url(self, git_env: tuple[Path, Path], tmp_path: Path) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        _create_work_commit(local, _delivery(BLOB_SHA), "auth.py", "pass")

        _setup_fake_gh(tmp_path, self._PR_URL)
        url = manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        assert url == self._PR_URL


class TestIntegrateGhFailure:
    def test_gh_failure_includes_stderr_in_error(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        _create_work_commit(local, _delivery(BLOB_SHA), "auth.py", "pass")

        _setup_failing_gh(tmp_path, "pull request already exists for branch")

        with pytest.raises(RuntimeError, match="pull request already exists"):
            manager.integrate(
                BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
            )

    def test_gh_failure_does_not_expose_full_command(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        _create_work_commit(local, _delivery(BLOB_SHA), "auth.py", "pass")

        _setup_failing_gh(tmp_path, "not found")

        with pytest.raises(RuntimeError) as exc_info:
            manager.integrate(
                BLOB_SHA,
                "specs/auth.spec.md",
                "Title",
                "Very long body that should not appear in the error message",
            )

        error_msg = str(exc_info.value)
        assert "Very long body" not in error_msg
        assert "not found" in error_msg

    def test_existing_pr_returns_url_from_error(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        _create_work_commit(local, _delivery(BLOB_SHA), "auth.py", "pass")

        existing_url = "https://github.com/test/repo/pull/42"
        _setup_failing_gh(
            tmp_path,
            f"a pull request already exists: {existing_url}",
        )
        url = manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        assert url == existing_url

    def test_already_exists_without_url_still_raises(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        _create_work_commit(local, _delivery(BLOB_SHA), "auth.py", "pass")

        _setup_failing_gh(tmp_path, "pull request already exists for branch")

        with pytest.raises(RuntimeError, match="pull request already exists"):
            manager.integrate(
                BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
            )


class TestIntegratePrAutomerge:
    _PR_URL = "https://github.com/test/repo/pull/1"

    def _add_delivery_work(self, local: Path) -> None:
        _create_work_commit(local, _delivery(BLOB_SHA), "auth.py", "pass")

    def test_creates_pr_and_enables_automerge(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(
            local, integration_strategy=IntegrationStrategy.PR_AUTOMERGE
        )
        manager.create_delivery_workspace(BLOB_SHA)
        self._add_delivery_work(local)

        args_log = _setup_fake_gh_multi(tmp_path, self._PR_URL)
        manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        log_content = args_log.read_text()
        lines = log_content.strip().splitlines()
        assert len(lines) == 2
        assert "pr create" in lines[0]
        assert "pr merge" in lines[1]
        assert "--auto" in lines[1]
        assert "--merge" in lines[1]

    def test_returns_pr_url(self, git_env: tuple[Path, Path], tmp_path: Path) -> None:
        local, _ = git_env
        manager = _make_manager(
            local, integration_strategy=IntegrationStrategy.PR_AUTOMERGE
        )
        manager.create_delivery_workspace(BLOB_SHA)
        self._add_delivery_work(local)

        _setup_fake_gh_multi(tmp_path, self._PR_URL)
        url = manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        assert url == self._PR_URL

    def test_forwards_title_and_body(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(
            local, integration_strategy=IntegrationStrategy.PR_AUTOMERGE
        )
        manager.create_delivery_workspace(BLOB_SHA)
        self._add_delivery_work(local)

        args_log = _setup_fake_gh_multi(tmp_path, self._PR_URL)
        manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        create_line = args_log.read_text().strip().splitlines()[0]
        assert "Implement auth" in create_line
        assert "Auth module" in create_line

    def test_automerge_failure_still_returns_pr_url(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(
            local, integration_strategy=IntegrationStrategy.PR_AUTOMERGE
        )
        manager.create_delivery_workspace(BLOB_SHA)
        self._add_delivery_work(local)

        _setup_fake_gh_first_succeeds_then_fails(tmp_path, self._PR_URL)
        url = manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        assert url == self._PR_URL

    def test_automerge_failure_falls_back_to_direct_merge(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(
            local, integration_strategy=IntegrationStrategy.PR_AUTOMERGE
        )
        manager.create_delivery_workspace(BLOB_SHA)
        self._add_delivery_work(local)

        args_log = _setup_fake_gh_auto_fails_direct_succeeds(tmp_path, self._PR_URL)
        manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        lines = args_log.read_text().strip().splitlines()
        assert len(lines) == 3
        assert "pr create" in lines[0]
        assert "--auto" in lines[1]
        assert "--auto" not in lines[2]
        assert "pr merge" in lines[2]
        assert "--merge" in lines[2]


class TestIntegrateNoopWhenDeliveryMatchesTrunk:
    def test_empty_diff_returns_noop_id(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(
            local, integration_strategy=IntegrationStrategy.PR_AUTOMERGE
        )
        manager.create_delivery_workspace(BLOB_SHA)

        integration_id = manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "No changes", "Nothing"
        )

        assert integration_id.startswith("noop:")

    def test_noop_polls_as_merged(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(
            local, integration_strategy=IntegrationStrategy.PR_AUTOMERGE
        )
        manager.create_delivery_workspace(BLOB_SHA)

        integration_id = manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "No changes", "Nothing"
        )
        result = manager.poll_integration(integration_id)

        assert result.status == IntegrationPollStatus.MERGED

    def test_non_empty_diff_creates_pr(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(
            local, integration_strategy=IntegrationStrategy.PR_AUTOMERGE
        )
        manager.create_delivery_workspace(BLOB_SHA)

        delivery_branch = _delivery(BLOB_SHA)
        _create_work_commit(local, delivery_branch, "new.py", "print('hello')")

        pr_url = "https://github.com/test/repo/pull/99"
        _setup_fake_gh_multi(tmp_path, pr_url)
        integration_id = manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Add code", "Something changed"
        )

        assert not integration_id.startswith("noop:")


class TestIntegrateDirect:
    def test_merges_delivery_into_trunk_locally(
        self, git_env: tuple[Path, Path]
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local, integration_strategy=IntegrationStrategy.DIRECT)
        manager.create_delivery_workspace(BLOB_SHA)

        delivery_branch = _delivery(BLOB_SHA)
        _create_work_commit(local, delivery_branch, "login.py", "def login(): pass")

        manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        content = _git(local, "show", f"{TRUNK}:login.py").stdout.strip()
        assert "def login(): pass" in content

    def test_pushes_trunk_to_remote(self, git_env: tuple[Path, Path]) -> None:
        local, remote = git_env
        manager = _make_manager(local, integration_strategy=IntegrationStrategy.DIRECT)
        manager.create_delivery_workspace(BLOB_SHA)

        delivery_branch = _delivery(BLOB_SHA)
        _create_work_commit(local, delivery_branch, "login.py", "def login(): pass")

        manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        local_head = _git(local, "rev-parse", TRUNK).stdout.strip()
        remote_head = _git(remote, "rev-parse", f"refs/heads/{TRUNK}").stdout.strip()
        assert local_head == remote_head

    def test_returns_direct_prefixed_id(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local, integration_strategy=IntegrationStrategy.DIRECT)
        manager.create_delivery_workspace(BLOB_SHA)

        delivery_branch = _delivery(BLOB_SHA)
        _create_work_commit(local, delivery_branch, "login.py", "def login(): pass")

        integration_id = manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        assert integration_id.startswith("direct:")

    def test_poll_direct_returns_merged(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local, integration_strategy=IntegrationStrategy.DIRECT)
        manager.create_delivery_workspace(BLOB_SHA)

        delivery_branch = _delivery(BLOB_SHA)
        _create_work_commit(local, delivery_branch, "login.py", "def login(): pass")

        integration_id = manager.integrate(
            BLOB_SHA, "specs/auth.spec.md", "Implement auth", "Auth module"
        )

        result = manager.poll_integration(integration_id)
        assert result.status == IntegrationPollStatus.MERGED


class TestCleanup:
    def test_deletes_delivery_branch(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        manager.cleanup(BLOB_SHA)

        assert not _branch_exists_local(local, _delivery(BLOB_SHA))

    def test_deletes_task_branches(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")
        manager.create_task_workspace(BLOB_SHA, 6, "task 6")

        manager.cleanup(BLOB_SHA)

        assert not _branch_exists_local(local, _task(BLOB_SHA, 5))
        assert not _branch_exists_local(local, _task(BLOB_SHA, 6))

    def test_deletes_verifier_branch(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_verification_workspace(BLOB_SHA)

        manager.cleanup(BLOB_SHA)

        assert not _branch_exists_local(local, _verifier(BLOB_SHA))

    def test_deletes_remote_refs(self, git_env: tuple[Path, Path]) -> None:
        local, remote = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")
        manager.create_verification_workspace(BLOB_SHA)

        manager.cleanup(BLOB_SHA)

        assert not _branch_exists_remote(remote, _delivery(BLOB_SHA))
        assert not _branch_exists_remote(remote, _task(BLOB_SHA, 5))
        assert not _branch_exists_remote(remote, _verifier(BLOB_SHA))

    def test_does_not_affect_other_specs(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace("abc123")
        manager.create_delivery_workspace("def456")
        manager.create_task_workspace("def456", 7, "task 7")

        manager.cleanup("abc123")

        assert _branch_exists_local(local, _delivery("def456"))
        assert _branch_exists_local(local, _task("def456", 7))

    def test_idempotent(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        manager.cleanup(BLOB_SHA)
        manager.cleanup(BLOB_SHA)

        assert not _branch_exists_local(local, _delivery(BLOB_SHA))


class TestCleanupVerification:
    def test_deletes_verifier_branch(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_verification_workspace(BLOB_SHA)

        manager.cleanup_verification(BLOB_SHA)

        assert not _branch_exists_local(local, _verifier(BLOB_SHA))

    def test_deletes_remote_verifier_branch(self, git_env: tuple[Path, Path]) -> None:
        local, remote = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_verification_workspace(BLOB_SHA)

        manager.cleanup_verification(BLOB_SHA)

        assert not _branch_exists_remote(remote, _verifier(BLOB_SHA))

    def test_preserves_delivery_branch(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_verification_workspace(BLOB_SHA)

        manager.cleanup_verification(BLOB_SHA)

        assert _branch_exists_local(local, _delivery(BLOB_SHA))

    def test_preserves_task_branches(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")
        manager.create_verification_workspace(BLOB_SHA)

        manager.cleanup_verification(BLOB_SHA)

        assert _branch_exists_local(local, _task(BLOB_SHA, 5))

    def test_idempotent(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        manager.cleanup_verification(BLOB_SHA)

        assert _branch_exists_local(local, _delivery(BLOB_SHA))


class TestCustomBranchPrefix:
    def test_create_delivery_uses_prefix(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        prefix = "myloop/"
        manager = GitWorkspaceManager(
            local, branch_prefix=prefix, trunk_branch=TRUNK, remote="origin"
        )

        manager.create_delivery_workspace(BLOB_SHA)

        assert _branch_exists_local(local, f"{prefix}spec/{BLOB_SHA}/delivery")

    def test_create_task_uses_prefix(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        prefix = "myloop/"
        manager = GitWorkspaceManager(
            local, branch_prefix=prefix, trunk_branch=TRUNK, remote="origin"
        )

        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")

        assert _branch_exists_local(local, f"{prefix}spec/{BLOB_SHA}/task/5")

    def test_cleanup_uses_prefix(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        prefix = "myloop/"
        manager = GitWorkspaceManager(
            local, branch_prefix=prefix, trunk_branch=TRUNK, remote="origin"
        )

        manager.create_delivery_workspace(BLOB_SHA)
        manager.create_task_workspace(BLOB_SHA, 5, "task 5")
        manager.cleanup(BLOB_SHA)

        assert not _branch_exists_local(local, f"{prefix}spec/{BLOB_SHA}/delivery")
        assert not _branch_exists_local(local, f"{prefix}spec/{BLOB_SHA}/task/5")


class TestProtocolConformance:
    def test_has_create_delivery_workspace(self) -> None:
        from typing import get_type_hints

        hints = get_type_hints(GitWorkspaceManager.create_delivery_workspace)
        assert hints["blob_sha"] is str
        assert hints["return"] is str

    def test_has_create_task_workspace(self) -> None:
        from typing import get_type_hints

        hints = get_type_hints(GitWorkspaceManager.create_task_workspace)
        assert hints["blob_sha"] is str
        assert hints["task_id"] is int
        assert hints["briefing"] is str
        assert hints["return"] is str

    def test_has_create_verification_workspace(self) -> None:
        from typing import get_type_hints

        hints = get_type_hints(GitWorkspaceManager.create_verification_workspace)
        assert hints["blob_sha"] is str
        assert hints["return"] is str

    def test_has_merge_task(self) -> None:
        from typing import get_type_hints

        hints = get_type_hints(GitWorkspaceManager.merge_task)
        assert hints["blob_sha"] is str
        assert hints["task_id"] is int
        assert hints["return"] is MergeResult

    def test_has_integrate(self) -> None:
        from typing import get_type_hints

        hints = get_type_hints(GitWorkspaceManager.integrate)
        assert hints["blob_sha"] is str
        assert hints["spec_path"] is str
        assert hints["title"] is str
        assert hints["body"] is str
        assert hints["return"] is str

    def test_has_cleanup(self) -> None:
        from typing import get_type_hints

        hints = get_type_hints(GitWorkspaceManager.cleanup)
        assert hints["blob_sha"] is str
        assert hints["return"] is type(None)

    def test_has_cleanup_verification(self) -> None:
        from typing import get_type_hints

        hints = get_type_hints(GitWorkspaceManager.cleanup_verification)
        assert hints["blob_sha"] is str
        assert hints["return"] is type(None)

    def test_has_poll_integration(self) -> None:
        from typing import get_type_hints

        hints = get_type_hints(GitWorkspaceManager.poll_integration)
        assert hints["integration_id"] is str
        assert hints["return"] is IntegrationPollResult

    def test_has_rebase_delivery(self) -> None:
        from typing import get_type_hints

        hints = get_type_hints(GitWorkspaceManager.rebase_delivery)
        assert hints["blob_sha"] is str
        assert hints["return"] is RebaseResult

    def test_adapter_imports_from_domain(self) -> None:
        import inspect

        import hyperloop.reconciliation.adapters.git_workspace_manager as module

        source = inspect.getsource(module)
        assert "hyperloop.reconciliation.models" in source


class TestPollIntegration:
    def test_pending_pr_returns_pending(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)

        _setup_fake_gh(
            tmp_path,
            json.dumps({"state": "OPEN", "mergeable": "MERGEABLE"}),
        )

        result = manager.poll_integration("https://github.com/test/repo/pull/1")

        assert result.status == IntegrationPollStatus.PENDING
        assert result.conflict_details is None

    def test_merged_pr_returns_merged(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)

        _setup_fake_gh(
            tmp_path,
            json.dumps({"state": "MERGED", "mergeable": "UNKNOWN"}),
        )

        result = manager.poll_integration("https://github.com/test/repo/pull/1")

        assert result.status == IntegrationPollStatus.MERGED

    def test_conflicting_pr_returns_conflict(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)

        _setup_fake_gh(
            tmp_path,
            json.dumps({"state": "OPEN", "mergeable": "CONFLICTING"}),
        )

        result = manager.poll_integration("https://github.com/test/repo/pull/1")

        assert result.status == IntegrationPollStatus.CONFLICT
        assert result.conflict_details is not None

    def test_closed_pr_returns_closed(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)

        _setup_fake_gh(
            tmp_path,
            json.dumps({"state": "CLOSED", "mergeable": "UNKNOWN"}),
        )

        result = manager.poll_integration("https://github.com/test/repo/pull/1")

        assert result.status == IntegrationPollStatus.CLOSED

    def test_direct_integration_returns_merged(
        self, git_env: tuple[Path, Path]
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)

        result = manager.poll_integration("direct:abc123def456")

        assert result.status == IntegrationPollStatus.MERGED

    def test_passes_pr_url_to_gh(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)

        pr_url = "https://github.com/test/repo/pull/42"
        args_file = _setup_fake_gh(
            tmp_path,
            json.dumps({"state": "OPEN", "mergeable": "MERGEABLE"}),
        )

        manager.poll_integration(pr_url)

        captured_args = args_file.read_text()
        assert pr_url in captured_args

    def test_gh_failure_returns_failed(
        self, git_env: tuple[Path, Path], tmp_path: Path
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)

        bin_dir = tmp_path / "fakebin"
        bin_dir.mkdir(exist_ok=True)
        script = bin_dir / "gh"
        script.write_text("#!/bin/bash\nexit 1\n")
        script.chmod(0o755)
        os.environ["PATH"] = f"{bin_dir}:{os.environ.get('PATH', '')}"

        result = manager.poll_integration("https://github.com/test/repo/pull/1")

        assert result.status == IntegrationPollStatus.FAILED


class TestRebaseDelivery:
    def test_clean_rebase_returns_success(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        _create_work_commit(
            local, _delivery(BLOB_SHA), "feature.py", "def feature(): pass"
        )
        _push_branch(local, _delivery(BLOB_SHA))
        _create_trunk_commit(local, "hotfix.py", "def hotfix(): pass")

        result = manager.rebase_delivery(BLOB_SHA)

        assert result.outcome == RebaseOutcome.SUCCESS
        assert result.conflict_details is None

    def test_rebase_updates_delivery_onto_trunk(
        self, git_env: tuple[Path, Path]
    ) -> None:
        local, remote = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        _create_work_commit(
            local, _delivery(BLOB_SHA), "feature.py", "def feature(): pass"
        )
        _push_branch(local, _delivery(BLOB_SHA))
        _create_trunk_commit(local, "hotfix.py", "def hotfix(): pass")
        trunk_head = _git(local, "rev-parse", TRUNK).stdout.strip()

        manager.rebase_delivery(BLOB_SHA)

        delivery_head = _git(local, "rev-parse", _delivery(BLOB_SHA)).stdout.strip()
        merge_base = _git(
            local, "merge-base", TRUNK, _delivery(BLOB_SHA)
        ).stdout.strip()
        assert merge_base == trunk_head
        assert delivery_head != trunk_head

        file_content = _git(
            local, "show", f"{_delivery(BLOB_SHA)}:feature.py"
        ).stdout.strip()
        assert "def feature(): pass" in file_content

    def test_rebase_pushes_to_remote(self, git_env: tuple[Path, Path]) -> None:
        local, remote = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        _create_work_commit(
            local, _delivery(BLOB_SHA), "feature.py", "def feature(): pass"
        )
        _push_branch(local, _delivery(BLOB_SHA))
        _create_trunk_commit(local, "hotfix.py", "def hotfix(): pass")

        manager.rebase_delivery(BLOB_SHA)

        local_head = _git(local, "rev-parse", _delivery(BLOB_SHA)).stdout.strip()
        remote_head = _git(
            remote, "rev-parse", f"refs/heads/{_delivery(BLOB_SHA)}"
        ).stdout.strip()
        assert local_head == remote_head

    def test_rebase_conflict_returns_conflict(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        _create_work_commit(local, _delivery(BLOB_SHA), "shared.py", "delivery version")
        _push_branch(local, _delivery(BLOB_SHA))
        _create_trunk_commit(local, "shared.py", "trunk version")

        result = manager.rebase_delivery(BLOB_SHA)

        assert result.outcome == RebaseOutcome.CONFLICT
        assert result.conflict_details is not None

    def test_already_up_to_date_returns_success(
        self, git_env: tuple[Path, Path]
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        _create_work_commit(
            local, _delivery(BLOB_SHA), "feature.py", "def feature(): pass"
        )
        _push_branch(local, _delivery(BLOB_SHA))

        result = manager.rebase_delivery(BLOB_SHA)

        assert result.outcome == RebaseOutcome.SUCCESS

    def test_success_includes_trunk_changes(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        _create_work_commit(
            local, _delivery(BLOB_SHA), "feature.py", "def feature(): pass"
        )
        _push_branch(local, _delivery(BLOB_SHA))
        _create_trunk_commit(local, "hotfix.py", "def hotfix(): pass")

        result = manager.rebase_delivery(BLOB_SHA)

        assert result.outcome == RebaseOutcome.SUCCESS
        assert result.trunk_changes is not None
        assert "hotfix.py" in result.trunk_changes

    def test_already_up_to_date_has_no_trunk_changes(
        self, git_env: tuple[Path, Path]
    ) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        _create_work_commit(
            local, _delivery(BLOB_SHA), "feature.py", "def feature(): pass"
        )
        _push_branch(local, _delivery(BLOB_SHA))

        result = manager.rebase_delivery(BLOB_SHA)

        assert result.outcome == RebaseOutcome.SUCCESS
        assert result.trunk_changes is None

    def test_preserves_all_delivery_commits(self, git_env: tuple[Path, Path]) -> None:
        local, _ = git_env
        manager = _make_manager(local)
        manager.create_delivery_workspace(BLOB_SHA)

        _create_work_commit(local, _delivery(BLOB_SHA), "a.py", "a")
        _create_work_commit(local, _delivery(BLOB_SHA), "b.py", "b")
        _push_branch(local, _delivery(BLOB_SHA))
        _create_trunk_commit(local, "hotfix.py", "fix")

        manager.rebase_delivery(BLOB_SHA)

        a_content = _git(local, "show", f"{_delivery(BLOB_SHA)}:a.py").stdout.strip()
        b_content = _git(local, "show", f"{_delivery(BLOB_SHA)}:b.py").stdout.strip()
        assert a_content == "a"
        assert b_content == "b"
