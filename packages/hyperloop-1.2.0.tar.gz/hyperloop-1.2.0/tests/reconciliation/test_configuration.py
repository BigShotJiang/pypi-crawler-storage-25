from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from hyperloop.reconciliation.models import Configuration
from hyperloop.reconciliation.models.executor_type import ExecutorType
from hyperloop.reconciliation.models.integration_strategy import IntegrationStrategy
from hyperloop.reconciliation.models.observer_adapter import ObserverAdapter


@pytest.fixture()
def specs_dir(tmp_path: Path) -> Path:
    d = tmp_path / "specs"
    d.mkdir()
    return d


@pytest.fixture()
def overlay_dir(tmp_path: Path) -> Path:
    d = tmp_path / "overlay"
    d.mkdir()
    return d


def _write_yaml(path: Path, data: dict[str, object]) -> None:
    path.write_text(yaml.dump(data))


class TestDefaultValues:
    def test_convergence_bound_defaults_to_3(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.convergence_bound == 3

    def test_max_task_retries_defaults_to_3(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.max_task_retries == 3

    def test_max_redecompositions_defaults_to_1(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.max_redecompositions == 1

    def test_max_concurrent_tasks_defaults_to_5(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.max_concurrent_tasks == 5

    def test_cycle_interval_seconds_defaults_to_30(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.cycle_interval_seconds == 30

    def test_specs_directory_defaults_to_specs(self, overlay_dir: Path) -> None:
        config = Configuration(overlay_path=str(overlay_dir))
        assert config.specs_directory == "specs/"

    def test_spec_glob_defaults_to_spec_md(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.spec_glob == "*.spec.md"

    def test_overlay_path_defaults_to_hyperloop_agents(self) -> None:
        assert Configuration.model_fields["overlay_path"].default == ".hyperloop/agents"

    def test_plan_branch_defaults_to_hyperloop_plan(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.plan_branch == "hyperloop/plan"

    def test_trunk_branch_defaults_to_main(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.trunk_branch == "main"

    def test_branch_prefix_defaults_to_hyperloop_slash(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.branch_prefix == "hyperloop/"

    def test_observer_adapters_defaults_to_empty_list(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.observer_adapters == []

    def test_model_fields_default_to_none(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.implementation_model is None
        assert config.verification_model is None
        assert config.decomposition_model is None

    def test_executor_type_defaults_to_claude_sdk(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.executor_type == ExecutorType.CLAUDE_SDK

    def test_integration_strategy_defaults_to_pr(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.integration_strategy == IntegrationStrategy.PR

    def test_repository_url_defaults_to_none(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.repository_url is None

    def test_project_name_defaults_to_none(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.project_name is None

    def test_executor_timeout_seconds_defaults_to_2700(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.executor_timeout_seconds == 2700

    def test_executor_max_retries_defaults_to_3(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        assert config.executor_max_retries == 3


class TestValidation:
    def test_convergence_bound_zero_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="convergence_bound"):
            Configuration(
                convergence_bound=0,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_convergence_bound_negative_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="convergence_bound"):
            Configuration(
                convergence_bound=-1,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_convergence_bound_one_accepted(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            convergence_bound=1,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.convergence_bound == 1

    def test_max_task_retries_negative_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="max_task_retries"):
            Configuration(
                max_task_retries=-1,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_max_task_retries_zero_accepted(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            max_task_retries=0,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.max_task_retries == 0

    def test_max_redecompositions_negative_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="max_redecompositions"):
            Configuration(
                max_redecompositions=-1,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_max_redecompositions_zero_accepted(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            max_redecompositions=0,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.max_redecompositions == 0

    def test_max_concurrent_tasks_zero_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="max_concurrent_tasks"):
            Configuration(
                max_concurrent_tasks=0,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_max_concurrent_tasks_negative_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="max_concurrent_tasks"):
            Configuration(
                max_concurrent_tasks=-1,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_max_concurrent_tasks_one_accepted(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            max_concurrent_tasks=1,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.max_concurrent_tasks == 1

    def test_cycle_interval_seconds_zero_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="cycle_interval_seconds"):
            Configuration(
                cycle_interval_seconds=0,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_cycle_interval_seconds_negative_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="cycle_interval_seconds"):
            Configuration(
                cycle_interval_seconds=-1,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_cycle_interval_seconds_one_accepted(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            cycle_interval_seconds=1,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.cycle_interval_seconds == 1

    def test_executor_timeout_seconds_zero_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="executor_timeout_seconds"):
            Configuration(
                executor_timeout_seconds=0,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_executor_timeout_seconds_negative_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="executor_timeout_seconds"):
            Configuration(
                executor_timeout_seconds=-1,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_executor_timeout_seconds_one_accepted(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            executor_timeout_seconds=1,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.executor_timeout_seconds == 1

    def test_executor_max_retries_negative_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="executor_max_retries"):
            Configuration(
                executor_max_retries=-1,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_executor_max_retries_zero_accepted(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            executor_max_retries=0,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.executor_max_retries == 0

    def test_specs_directory_nonexistent_rejected(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="specs_directory"):
            Configuration(specs_directory=str(tmp_path / "nonexistent"))

    def test_specs_directory_existing_accepted(self, tmp_path: Path) -> None:
        specs = tmp_path / "my_specs"
        specs.mkdir()
        overlay = tmp_path / "overlay"
        overlay.mkdir()
        config = Configuration(specs_directory=str(specs), overlay_path=str(overlay))
        assert config.specs_directory == str(specs)

    def test_overlay_path_nonexistent_rejected(self, specs_dir: Path) -> None:
        with pytest.raises(ValueError, match="overlay_path"):
            Configuration(
                specs_directory=str(specs_dir),
                overlay_path="/nonexistent/overlay/path",
            )

    def test_overlay_path_file_rejected(self, specs_dir: Path, tmp_path: Path) -> None:
        file_path = tmp_path / "not_a_dir.txt"
        file_path.touch()
        with pytest.raises(ValueError, match="overlay_path"):
            Configuration(specs_directory=str(specs_dir), overlay_path=str(file_path))

    def test_overlay_path_existing_accepted(self, tmp_path: Path) -> None:
        specs = tmp_path / "specs"
        specs.mkdir()
        overlay = tmp_path / "overlay"
        overlay.mkdir()
        config = Configuration(specs_directory=str(specs), overlay_path=str(overlay))
        assert config.overlay_path == str(overlay)

    def test_overlay_path_error_suggests_hyperloop_init(self, specs_dir: Path) -> None:
        with pytest.raises(ValueError, match="hyperloop init"):
            Configuration(
                specs_directory=str(specs_dir),
                overlay_path="/nonexistent/overlay/path",
            )

    def test_invalid_integration_strategy_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError):
            Configuration(
                integration_strategy="webhook",  # type: ignore[arg-type]
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_spec_glob_custom_value_accepted(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            spec_glob="*.md",
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.spec_glob == "*.md"

    def test_valid_configuration_accepted(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            convergence_bound=5,
            max_task_retries=2,
            max_redecompositions=3,
            max_concurrent_tasks=10,
            cycle_interval_seconds=60,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
            implementation_model="claude-sonnet",
            verification_model="gemini-pro",
        )
        assert config.convergence_bound == 5
        assert config.max_task_retries == 2
        assert config.max_concurrent_tasks == 10
        assert config.implementation_model == "claude-sonnet"
        assert config.verification_model == "gemini-pro"


class TestExecutorConfiguration:
    def test_claude_sdk_executor_type_accepted(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            executor_type=ExecutorType.CLAUDE_SDK,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.executor_type == ExecutorType.CLAUDE_SDK

    def test_ambient_executor_type_accepted_with_required_fields(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            executor_type=ExecutorType.AMBIENT,
            repository_url="https://github.com/org/repo.git",
            project_name="my-project",
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.executor_type == ExecutorType.AMBIENT
        assert config.repository_url == "https://github.com/org/repo.git"
        assert config.project_name == "my-project"

    def test_ambient_without_repository_url_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="repository_url"):
            Configuration(
                executor_type=ExecutorType.AMBIENT,
                project_name="my-project",
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_ambient_without_project_name_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="project_name"):
            Configuration(
                executor_type=ExecutorType.AMBIENT,
                repository_url="https://github.com/org/repo.git",
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_ambient_without_both_fields_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError, match="repository_url"):
            Configuration(
                executor_type=ExecutorType.AMBIENT,
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_claude_sdk_ignores_ambient_fields(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            executor_type=ExecutorType.CLAUDE_SDK,
            repository_url="https://github.com/org/repo.git",
            project_name="my-project",
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.executor_type == ExecutorType.CLAUDE_SDK

    def test_unknown_executor_type_rejected(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        with pytest.raises(ValueError):
            Configuration(
                executor_type="unknown",  # type: ignore[arg-type]
                specs_directory=str(specs_dir),
                overlay_path=str(overlay_dir),
            )

    def test_executor_type_from_string_in_yaml(
        self, specs_dir: Path, overlay_dir: Path, tmp_path: Path
    ) -> None:
        config_file = tmp_path / "hyperloop.yaml"
        _write_yaml(
            config_file,
            {
                "executor_type": "claude-sdk",
                "specs_directory": str(specs_dir),
                "overlay_path": str(overlay_dir),
            },
        )
        config = Configuration.from_yaml(config_file)
        assert config.executor_type == ExecutorType.CLAUDE_SDK

    def test_ambient_from_yaml_with_required_fields(
        self, specs_dir: Path, overlay_dir: Path, tmp_path: Path
    ) -> None:
        config_file = tmp_path / "hyperloop.yaml"
        _write_yaml(
            config_file,
            {
                "executor_type": "ambient",
                "repository_url": "https://github.com/org/repo.git",
                "project_name": "my-project",
                "specs_directory": str(specs_dir),
                "overlay_path": str(overlay_dir),
            },
        )
        config = Configuration.from_yaml(config_file)
        assert config.executor_type == ExecutorType.AMBIENT
        assert config.repository_url == "https://github.com/org/repo.git"
        assert config.project_name == "my-project"


class TestIntegrationStrategyConfiguration:
    def test_pr_strategy_accepted(self, specs_dir: Path, overlay_dir: Path) -> None:
        config = Configuration(
            integration_strategy=IntegrationStrategy.PR,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.integration_strategy == IntegrationStrategy.PR

    def test_pr_automerge_strategy_accepted(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            integration_strategy=IntegrationStrategy.PR_AUTOMERGE,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.integration_strategy == IntegrationStrategy.PR_AUTOMERGE

    def test_direct_strategy_accepted(self, specs_dir: Path, overlay_dir: Path) -> None:
        config = Configuration(
            integration_strategy=IntegrationStrategy.DIRECT,
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
        )
        assert config.integration_strategy == IntegrationStrategy.DIRECT

    def test_strategy_from_string_in_yaml(
        self, specs_dir: Path, overlay_dir: Path, tmp_path: Path
    ) -> None:
        config_file = tmp_path / "hyperloop.yaml"
        _write_yaml(
            config_file,
            {
                "integration_strategy": "pr_automerge",
                "specs_directory": str(specs_dir),
                "overlay_path": str(overlay_dir),
            },
        )
        config = Configuration.from_yaml(config_file)
        assert config.integration_strategy == IntegrationStrategy.PR_AUTOMERGE

    def test_direct_strategy_from_yaml(
        self, specs_dir: Path, overlay_dir: Path, tmp_path: Path
    ) -> None:
        config_file = tmp_path / "hyperloop.yaml"
        _write_yaml(
            config_file,
            {
                "integration_strategy": "direct",
                "specs_directory": str(specs_dir),
                "overlay_path": str(overlay_dir),
            },
        )
        config = Configuration.from_yaml(config_file)
        assert config.integration_strategy == IntegrationStrategy.DIRECT

    def test_invalid_strategy_from_yaml_rejected(
        self, specs_dir: Path, overlay_dir: Path, tmp_path: Path
    ) -> None:
        config_file = tmp_path / "hyperloop.yaml"
        _write_yaml(
            config_file,
            {
                "integration_strategy": "webhook",
                "specs_directory": str(specs_dir),
                "overlay_path": str(overlay_dir),
            },
        )
        with pytest.raises(ValueError):
            Configuration.from_yaml(config_file)


class TestImmutability:
    def test_cannot_modify_convergence_bound(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        with pytest.raises(ValueError):
            config.convergence_bound = 10  # type: ignore[misc]

    def test_cannot_modify_trunk_branch(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        with pytest.raises(ValueError):
            config.trunk_branch = "develop"  # type: ignore[misc]

    def test_cannot_modify_observer_adapters(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        with pytest.raises(ValueError):
            config.observer_adapters = [ObserverAdapter.STRUCTLOG]  # type: ignore[misc]

    def test_cannot_modify_executor_type(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        with pytest.raises(ValueError):
            config.executor_type = ExecutorType.AMBIENT  # type: ignore[misc]

    def test_cannot_modify_integration_strategy(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir), overlay_path=str(overlay_dir)
        )
        with pytest.raises(ValueError):
            config.integration_strategy = IntegrationStrategy.DIRECT  # type: ignore[misc]


class TestYamlLoading:
    def test_load_from_yaml_with_all_fields(self, tmp_path: Path) -> None:
        specs = tmp_path / "doc" / "specs"
        specs.mkdir(parents=True)
        overlay = tmp_path / "overlays"
        overlay.mkdir()
        config_file = tmp_path / "hyperloop.yaml"
        _write_yaml(
            config_file,
            {
                "convergence_bound": 5,
                "max_task_retries": 2,
                "max_redecompositions": 3,
                "max_concurrent_tasks": 10,
                "cycle_interval_seconds": 60,
                "implementation_model": "claude-sonnet",
                "verification_model": "gemini-pro",
                "decomposition_model": "claude-haiku",
                "specs_directory": str(specs),
                "overlay_path": str(overlay),
                "observer_adapters": ["structlog"],
                "plan_branch": "hyperloop/state",
                "trunk_branch": "develop",
                "branch_prefix": "hl/",
            },
        )
        config = Configuration.from_yaml(config_file)
        assert config.convergence_bound == 5
        assert config.max_task_retries == 2
        assert config.max_redecompositions == 3
        assert config.max_concurrent_tasks == 10
        assert config.cycle_interval_seconds == 60
        assert config.implementation_model == "claude-sonnet"
        assert config.verification_model == "gemini-pro"
        assert config.decomposition_model == "claude-haiku"
        assert config.specs_directory == str(specs)
        assert config.overlay_path == str(overlay)
        assert config.observer_adapters == [ObserverAdapter.STRUCTLOG]
        assert config.plan_branch == "hyperloop/state"
        assert config.trunk_branch == "develop"
        assert config.branch_prefix == "hl/"

    def test_missing_yaml_uses_defaults(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        (tmp_path / "specs").mkdir()
        (tmp_path / ".hyperloop" / "agents").mkdir(parents=True)
        monkeypatch.chdir(tmp_path)
        config = Configuration.from_yaml(tmp_path / "nonexistent.yaml")
        assert config.convergence_bound == 3
        assert config.max_task_retries == 3
        assert config.max_concurrent_tasks == 5
        assert config.specs_directory == "specs/"
        assert config.overlay_path == ".hyperloop/agents"

    def test_yaml_with_spec_glob(
        self, specs_dir: Path, overlay_dir: Path, tmp_path: Path
    ) -> None:
        config_file = tmp_path / "hyperloop.yaml"
        _write_yaml(
            config_file,
            {
                "spec_glob": "*.md",
                "specs_directory": str(specs_dir),
                "overlay_path": str(overlay_dir),
            },
        )
        config = Configuration.from_yaml(config_file)
        assert config.spec_glob == "*.md"

    def test_partial_yaml_fills_defaults(
        self, specs_dir: Path, overlay_dir: Path, tmp_path: Path
    ) -> None:
        config_file = tmp_path / "hyperloop.yaml"
        _write_yaml(
            config_file,
            {
                "convergence_bound": 7,
                "specs_directory": str(specs_dir),
                "overlay_path": str(overlay_dir),
            },
        )
        config = Configuration.from_yaml(config_file)
        assert config.convergence_bound == 7
        assert config.max_task_retries == 3
        assert config.trunk_branch == "main"

    def test_yaml_with_invalid_values_raises(
        self, specs_dir: Path, overlay_dir: Path, tmp_path: Path
    ) -> None:
        config_file = tmp_path / "hyperloop.yaml"
        _write_yaml(
            config_file,
            {
                "convergence_bound": 0,
                "specs_directory": str(specs_dir),
                "overlay_path": str(overlay_dir),
            },
        )
        with pytest.raises(ValueError, match="convergence_bound"):
            Configuration.from_yaml(config_file)


class TestModelSelection:
    def test_different_models_for_different_roles(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
            implementation_model="claude-sonnet",
            verification_model="gemini-pro",
            decomposition_model="claude-haiku",
        )
        assert config.implementation_model == "claude-sonnet"
        assert config.verification_model == "gemini-pro"
        assert config.decomposition_model == "claude-haiku"

    def test_verification_can_differ_from_implementation(
        self, specs_dir: Path, overlay_dir: Path
    ) -> None:
        config = Configuration(
            specs_directory=str(specs_dir),
            overlay_path=str(overlay_dir),
            implementation_model="claude-sonnet",
            verification_model="gemini-pro",
        )
        assert config.implementation_model != config.verification_model
