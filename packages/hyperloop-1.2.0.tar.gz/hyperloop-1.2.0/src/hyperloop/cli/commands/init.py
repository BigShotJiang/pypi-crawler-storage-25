from __future__ import annotations

from enum import StrEnum
from pathlib import Path

import click
import yaml
from pydantic import ValidationError

from hyperloop.cli.git import find_git_root
from hyperloop.reconciliation.models.configuration import (
    DEFAULT_CONFIG_FILENAME,
    Configuration,
)
from hyperloop.reconciliation.models.integration_strategy import IntegrationStrategy


_DEFAULT_OVERLAY_PATH = Configuration.model_fields["overlay_path"].default
_BASE_TEMPLATES_REPO = "https://github.com/jsell-rh/hyperloop.git"
_BASE_TEMPLATES_PATH = "base"
_BASE_TEMPLATES_REF = "main"


def _build_config_dict(overrides: dict[str, object]) -> dict[str, object]:
    config_dict: dict[str, object] = {}
    for name, field_info in Configuration.model_fields.items():
        default = field_info.default
        if isinstance(default, StrEnum):
            config_dict[name] = default.value
        elif isinstance(default, list):
            config_dict[name] = [
                item.value if isinstance(item, StrEnum) else item for item in default
            ]
        else:
            config_dict[name] = default

    for key, value in overrides.items():
        if isinstance(value, StrEnum):
            config_dict[key] = value.value
        else:
            config_dict[key] = value

    return config_dict


def _validate_config_dict(config_dict: dict[str, object]) -> None:
    validation_dict = dict(config_dict)
    validation_dict["specs_directory"] = "."
    validation_dict["overlay_path"] = "."
    Configuration.model_validate(validation_dict)


def _format_next_steps(specs_directory: str, spec_glob: str, overlay_path: str) -> str:
    return (
        f"\nNext steps:\n"
        f"  1. Place your specs in {specs_directory} (files must match {spec_glob})\n"
        f"  2. Optionally customize agent prompts in {overlay_path}/\n"
        f"  3. Run the reconciler:\n"
        f"\n"
        f"     uvx hyperloop run\n"
    )


def _create_overlay(repo_path: Path) -> bool:
    overlay_dir = repo_path / _DEFAULT_OVERLAY_PATH
    kustomization_path = overlay_dir / "kustomization.yaml"

    if kustomization_path.exists():
        return False

    overlay_dir.mkdir(parents=True, exist_ok=True)

    resource_url = (
        f"{_BASE_TEMPLATES_REPO}//{_BASE_TEMPLATES_PATH}?ref={_BASE_TEMPLATES_REF}"
    )
    content = {
        "apiVersion": "kustomize.config.k8s.io/v1beta1",
        "kind": "Kustomization",
        "resources": [resource_url],
    }
    kustomization_path.write_text(
        yaml.dump(content, default_flow_style=False, sort_keys=False)
    )
    return True


def _create_config_file(repo_path: Path, config_dict: dict[str, object]) -> bool:
    config_path = repo_path / DEFAULT_CONFIG_FILENAME

    if config_path.exists():
        return False

    config_path.write_text(
        yaml.dump(config_dict, default_flow_style=False, sort_keys=False)
    )
    return True


@click.command()
@click.option("--trunk-branch", default=None, help="Trunk branch name")
@click.option(
    "--integration-strategy",
    type=click.Choice([s.value for s in IntegrationStrategy], case_sensitive=False),
    default=None,
    help="Integration strategy",
)
@click.option("--convergence-bound", type=int, default=None, help="Convergence bound")
@click.option("--specs-directory", default=None, help="Specs directory path")
@click.option("--spec-glob", default=None, help="Spec file glob pattern")
def init(
    trunk_branch: str | None,
    integration_strategy: str | None,
    convergence_bound: int | None,
    specs_directory: str | None,
    spec_glob: str | None,
) -> None:
    """Scaffold default Hyperloop configuration in the current repository."""
    try:
        repo_path = find_git_root()
    except click.ClickException:
        raise
    except Exception as exc:
        raise click.ClickException(str(exc)) from exc

    overrides: dict[str, object] = {}
    if trunk_branch is not None:
        overrides["trunk_branch"] = trunk_branch
    if integration_strategy is not None:
        overrides["integration_strategy"] = integration_strategy
    if convergence_bound is not None:
        overrides["convergence_bound"] = convergence_bound
    if specs_directory is not None:
        overrides["specs_directory"] = specs_directory
    if spec_glob is not None:
        overrides["spec_glob"] = spec_glob

    config_dict = _build_config_dict(overrides)

    try:
        _validate_config_dict(config_dict)
    except ValidationError as exc:
        raise click.ClickException(str(exc)) from exc

    overlay_created = _create_overlay(repo_path)
    config_created = _create_config_file(repo_path, config_dict)

    if not overlay_created and not config_created:
        click.echo("Already initialized.")
        return

    if overlay_created:
        overlay_dir = repo_path / _DEFAULT_OVERLAY_PATH
        click.echo(f"Initialized hyperloop in {overlay_dir}")
    if config_created:
        click.echo(f"Created {DEFAULT_CONFIG_FILENAME}")

    effective_specs_dir = str(config_dict["specs_directory"])
    effective_spec_glob = str(config_dict["spec_glob"])
    effective_overlay = str(config_dict["overlay_path"])
    click.echo(
        _format_next_steps(effective_specs_dir, effective_spec_glob, effective_overlay)
    )
