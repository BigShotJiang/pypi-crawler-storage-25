class ExecutorTimeoutError(Exception):
    pass
