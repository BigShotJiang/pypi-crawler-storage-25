from __future__ import annotations

from typing import Protocol

from hyperloop.reconciliation.models.integration_poll_result import (
    IntegrationPollResult,
)
from hyperloop.reconciliation.models.merge_result import MergeResult
from hyperloop.reconciliation.models.rebase_result import RebaseResult


class WorkspaceManager(Protocol):
    def create_delivery_workspace(self, blob_sha: str) -> str: ...

    def create_task_workspace(
        self, blob_sha: str, task_id: int, briefing: str
    ) -> str: ...

    def create_verification_workspace(self, blob_sha: str) -> str: ...

    def merge_task(self, blob_sha: str, task_id: int) -> MergeResult: ...

    def integrate(
        self, blob_sha: str, spec_path: str, title: str, body: str
    ) -> str: ...

    def poll_integration(self, integration_id: str) -> IntegrationPollResult: ...

    def rebase_delivery(self, blob_sha: str) -> RebaseResult: ...

    def cleanup(self, blob_sha: str) -> None: ...

    def cleanup_verification(self, blob_sha: str) -> None: ...
