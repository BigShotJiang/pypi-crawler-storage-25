# CHANGELOG

<!-- version list -->

## v1.2.0 (2026-05-21)


## v1.1.0 (2026-05-21)


## v1.0.1 (2026-05-21)

### Bug Fixes

- Restrict CI to repo owners, members, and collaborators
  ([`325183b`](https://github.com/jsell-rh/hyperloop/commit/325183bd03aeb5938d865e1d1c93f060fa15a5c1))


## v1.0.0 (2026-05-21)

- Initial Release
