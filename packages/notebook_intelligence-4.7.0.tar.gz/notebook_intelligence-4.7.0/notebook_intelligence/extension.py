# Copyright (c) Mehmet Bektas <mbektasgh@outlook.com>

import asyncio
import atexit
import base64
from dataclasses import asdict, dataclass
import json
from os import path
import datetime as dt
import os
import shutil
import tempfile
from typing import Union
import uuid
import threading
import logging
import tiktoken

from jupyter_server.extension.application import ExtensionApp
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join
import tornado
from tornado import websocket
from traitlets import Bool, Enum as TraitletEnum, Int, List, Unicode
from notebook_intelligence.api import CancelToken, ChatMode, ChatResponse, ChatRequest, ContextRequest, ContextRequestType, RequestDataType, RequestToolSelection, ResponseStreamData, ResponseStreamDataType, BackendMessageType, SignalImpl
from notebook_intelligence.ai_service_manager import AIServiceManager
from notebook_intelligence.cell_output import coerce_payload as _coerce_output_context, format_output_context as _format_output_context
from notebook_intelligence.feature_flags import (
    CHAT_MODEL_OVERRIDES,
    CLAUDE_CODE_TOOLS_ID,
    CLAUDE_SETTINGS_OVERRIDES,
    INLINE_COMPLETION_MODEL_OVERRIDES,
    JUPYTER_UI_TOOLS_ID,
    POLICY_FORCE_OFF,
    POLICY_FORCE_ON,
    POLICY_USER_CHOICE,
    VALID_POLICIES,
    apply_claude_policies,
    apply_string_overrides,
    is_locked,
    resolve_feature_flag,
)
from notebook_intelligence.claude import ClaudeCodeChatParticipant, fetch_claude_models
from notebook_intelligence.claude_sessions import (
    NBI_CONTEXT_PREFIX,
    get_sessions_dir as get_claude_sessions_dir,
    list_all_sessions as list_all_claude_sessions,
)
import notebook_intelligence.github_copilot as github_copilot
from notebook_intelligence.built_in_toolsets import built_in_toolsets
from notebook_intelligence.util import ThreadSafeWebSocketConnector, get_jupyter_root_dir, set_jupyter_root_dir, is_builtin_tool_enabled_in_env, is_provider_enabled_in_env
from notebook_intelligence.context_factory import RuleContextFactory
from notebook_intelligence.skillset import SKILL_NAME_REGEX

ai_service_manager: AIServiceManager = None
log = logging.getLogger(__name__)
tiktoken_encoding = tiktoken.encoding_for_model('gpt-4o')
thread_safe_websocket_connector: ThreadSafeWebSocketConnector = None


def _token_count(text: str) -> int:
    return len(tiktoken_encoding.encode(text))


def _truncate_context_content(content: str, token_budget: int) -> str:
    if token_budget <= 0 or content == '':
        return ''

    encoded = tiktoken_encoding.encode(content)
    if len(encoded) <= token_budget:
        return content

    truncated = tiktoken_encoding.decode(encoded[:token_budget]).rstrip()
    if truncated == '':
        return ''

    return truncated + "\n...[truncated]"


def _build_additional_context_message(
    file_path: str,
    context_filename: str,
    start_line: int,
    end_line: int,
    context_content: str,
    current_cell_context: str = ''
) -> str:
    message = (
        f"This file was provided as additional context: '{context_filename}' "
        f"at path '{file_path}', lines: {start_line} - {end_line}."
    )

    if current_cell_context:
        message += f" {current_cell_context}"

    if context_content != '':
        message += f"\n\nFile contents:\n```\n{context_content}\n```"

    return message

def _build_cell_output_features_response(
    explain_error_policy: str,
    output_followup_policy: str,
    output_toolbar_policy: str,
    nbi_config,
) -> dict:
    explain_enabled, explain_locked = resolve_feature_flag(
        explain_error_policy, nbi_config.enable_explain_error
    )
    followup_enabled, followup_locked = resolve_feature_flag(
        output_followup_policy, nbi_config.enable_output_followup
    )
    toolbar_enabled, toolbar_locked = resolve_feature_flag(
        output_toolbar_policy, nbi_config.enable_output_toolbar
    )
    return {
        "explain_error": {"enabled": explain_enabled, "locked": explain_locked},
        "output_followup": {
            "enabled": followup_enabled,
            "locked": followup_locked,
        },
        "output_toolbar": {
            "enabled": toolbar_enabled,
            "locked": toolbar_locked,
        },
    }


def _resolve_supports_vision(ai_service_manager) -> bool:
    """Whether the active chat model can render images.

    In Claude Code mode the active model is Claude (always vision-capable),
    not ``ai_service_manager.chat_model`` (which still reflects the user's
    most recent non-Claude selection). Fall through to the regular chat
    model's capability otherwise.
    """
    if ai_service_manager.is_claude_code_mode:
        return True
    chat_model = ai_service_manager.chat_model
    return chat_model.supports_vision if chat_model is not None else False


def _resolve_policy_with_env(env_var_name: str, traitlet_value: str) -> str:
    """Resolve a feature policy: env var wins if valid, else traitlet."""
    env_value = os.environ.get(env_var_name, "").strip()
    if env_value:
        if env_value in VALID_POLICIES:
            return env_value
        log.warning(
            "Ignoring %s=%r: must be one of %s",
            env_var_name,
            env_value,
            ", ".join(VALID_POLICIES),
        )
    return traitlet_value


# Single source of truth for the boolean policies. Each entry is
# ``(policy_name, env_var, traitlet_attr)``. Drives env-var resolution, the
# capabilities response, and the lock-rejection set in ConfigHandler.
FEATURE_POLICY_SPEC = (
    ("explain_error", "NBI_EXPLAIN_ERROR_POLICY", "explain_error_policy"),
    ("output_followup", "NBI_OUTPUT_FOLLOWUP_POLICY", "output_followup_policy"),
    ("output_toolbar", "NBI_OUTPUT_TOOLBAR_POLICY", "output_toolbar_policy"),
    ("claude_mode", "NBI_CLAUDE_MODE_POLICY", "claude_mode_policy"),
    (
        "claude_continue_conversation",
        "NBI_CLAUDE_CONTINUE_CONVERSATION_POLICY",
        "claude_continue_conversation_policy",
    ),
    (
        "claude_code_tools",
        "NBI_CLAUDE_CODE_TOOLS_POLICY",
        "claude_code_tools_policy",
    ),
    (
        "claude_jupyter_ui_tools",
        "NBI_CLAUDE_JUPYTER_UI_TOOLS_POLICY",
        "claude_jupyter_ui_tools_policy",
    ),
    (
        "claude_setting_source_user",
        "NBI_CLAUDE_SETTING_SOURCE_USER_POLICY",
        "claude_setting_source_user_policy",
    ),
    (
        "claude_setting_source_project",
        "NBI_CLAUDE_SETTING_SOURCE_PROJECT_POLICY",
        "claude_setting_source_project_policy",
    ),
    (
        "store_github_access_token",
        "NBI_STORE_GITHUB_ACCESS_TOKEN_POLICY",
        "store_github_access_token_policy",
    ),
)
FEATURE_POLICY_NAMES = tuple(name for name, _, _ in FEATURE_POLICY_SPEC)

# ``(setting_lock_name, env_var)`` pairs for the value-presence-locks. The
# claude_api_key entry maps to ANTHROPIC_API_KEY (the SDK's native convention)
# rather than an NBI-prefixed env var. Same for claude_base_url.
STRING_OVERRIDE_SPEC = (
    ("chat_model_provider", "NBI_CHAT_MODEL_PROVIDER"),
    ("chat_model_id", "NBI_CHAT_MODEL_ID"),
    ("inline_completion_model_provider", "NBI_INLINE_COMPLETION_MODEL_PROVIDER"),
    ("inline_completion_model_id", "NBI_INLINE_COMPLETION_MODEL_ID"),
    ("claude_chat_model", "NBI_CLAUDE_CHAT_MODEL"),
    ("claude_inline_completion_model", "NBI_CLAUDE_INLINE_COMPLETION_MODEL"),
    ("claude_api_key", "ANTHROPIC_API_KEY"),
    ("claude_base_url", "ANTHROPIC_BASE_URL"),
)
SETTING_LOCK_NAMES = tuple(name for name, _ in STRING_OVERRIDE_SPEC)


def _build_feature_policies_response(policies: dict, nbi_config) -> dict:
    """Resolve every boolean policy against the user's stored config.

    Returns ``{name: {enabled, locked}}`` for every name in
    FEATURE_POLICY_NAMES. The frontend iterates this dict, so adding a new
    feature only needs an entry here plus a matching env-var resolution.
    """
    claude_settings = nbi_config.claude_settings or {}
    tools = claude_settings.get("tools") or []
    sources = claude_settings.get("setting_sources") or []

    user_values = {
        "explain_error": nbi_config.enable_explain_error,
        "output_followup": nbi_config.enable_output_followup,
        "output_toolbar": nbi_config.enable_output_toolbar,
        "claude_mode": bool(claude_settings.get("enabled", False)),
        "claude_continue_conversation": bool(
            claude_settings.get("continue_conversation", False)
        ),
        "claude_code_tools": CLAUDE_CODE_TOOLS_ID in tools,
        "claude_jupyter_ui_tools": JUPYTER_UI_TOOLS_ID in tools,
        "claude_setting_source_user": "user" in sources,
        "claude_setting_source_project": "project" in sources,
        "store_github_access_token": bool(nbi_config.store_github_access_token),
    }

    response = {}
    for name in FEATURE_POLICY_NAMES:
        enabled, locked = resolve_feature_flag(
            policies.get(name, POLICY_USER_CHOICE), user_values[name]
        )
        response[name] = {"enabled": enabled, "locked": locked}
    return response


def _build_setting_locks_response(string_overrides: dict) -> dict:
    """Surface lock state for non-boolean settings (model pickers, API key, base URL).

    The values themselves are still served through their existing capabilities
    fields (chat_model, claude_settings, ...). This dict only carries the
    locked flag so the frontend knows which inputs to disable.
    """
    return {
        name: {"locked": bool(string_overrides.get(name))}
        for name in SETTING_LOCK_NAMES
    }


def _scrub_credentials_for_wire(claude_settings: dict, string_overrides: dict) -> dict:
    """Strip the api_key from the capabilities response when locked by env.

    The Anthropic SDK reads ANTHROPIC_API_KEY directly; surfacing the value
    through the frontend would leak the credential.
    """
    if not string_overrides.get("claude_api_key"):
        return claude_settings
    result = dict(claude_settings or {})
    result["api_key"] = ""
    return result


class GetCapabilitiesHandler(APIHandler):
    disabled_tools = []
    allow_enabling_tools_with_env = False
    disabled_providers = []
    allow_enabling_providers_with_env = False
    enable_chat_feedback = False
    feature_policies = {}
    string_overrides = {}

    @tornado.web.authenticated
    def get(self):
        ai_service_manager.nbi_config.load()
        ai_service_manager.update_models_from_config()
        nbi_config = ai_service_manager.nbi_config
        def is_tool_enabled(tool: str) -> bool:
            if self.disabled_tools is None:
                return True
            return tool not in self.disabled_tools or (self.allow_enabling_tools_with_env and is_builtin_tool_enabled_in_env(tool))
        def is_provider_enabled(provider_id: str) -> bool:
            if self.disabled_providers is None:
                return True
            return provider_id not in self.disabled_providers or \
                   (self.allow_enabling_providers_with_env and is_provider_enabled_in_env(provider_id))
        allowed_builtin_toolsets = [{"id": toolset.id, "name": toolset.name, "description": toolset.description} for toolset in built_in_toolsets.values() if is_tool_enabled(toolset.id)]
        llm_providers = [p for p in ai_service_manager.llm_providers.values() if is_provider_enabled(p.id)]
        mcp_servers = ai_service_manager.get_mcp_servers()
        mcp_server_tools = [{
            "id": mcp_server.name,
            "status": mcp_server.status,
            "tools": [{"name": tool.name, "description": tool.description} for tool in mcp_server.get_tools()],
            "prompts": [{"name": prompt.name, "description": prompt.description, "arguments": [{"name": argument.name, "description": argument.description, "required": argument.required} for argument in prompt.arguments]} for prompt in mcp_server.get_prompts()]
        } for mcp_server in mcp_servers]
        # sort by server id
        mcp_server_tools.sort(key=lambda server: server["id"])

        extensions = []
        for extension_id, toolsets in ai_service_manager.get_extension_toolsets().items():
            ts = []
            for toolset in toolsets:
                tools = []
                for tool in toolset.tools:
                    tools.append({"name": tool.name, "description": tool.description})
                # sort by tool name
                tools.sort(key=lambda tool: tool["name"])
                ts.append({
                    "id": toolset.id,
                    "name": toolset.name,
                    "description": toolset.description,
                    "tools": tools
                })
            # sort by toolset name
            ts.sort(key=lambda toolset: toolset["name"])
            extension = ai_service_manager.get_extension(extension_id)
            extensions.append({
                "id": extension_id,
                "name": extension.name,
                "toolsets": ts
            })
        # sort by extension id
        extensions.sort(key=lambda extension: extension["id"])

        response = {
            "user_home_dir": os.path.expanduser('~'),
            "nbi_user_config_dir": nbi_config.nbi_user_dir,
            "using_github_copilot_service": nbi_config.using_github_copilot_service,
            "llm_providers": [{"id": provider.id, "name": provider.name} for provider in llm_providers],
            "chat_models": ai_service_manager.chat_model_ids,
            "inline_completion_models": ai_service_manager.inline_completion_model_ids,
            "embedding_models": ai_service_manager.embedding_model_ids,
            "chat_model": nbi_config.chat_model,
            "chat_model_supports_vision": _resolve_supports_vision(
                ai_service_manager
            ),
            "inline_completion_model": nbi_config.inline_completion_model,
            "embedding_model": nbi_config.embedding_model,
            "chat_participants": [],
            "store_github_access_token": nbi_config.store_github_access_token,
            "inline_completion_debouncer_delay": nbi_config.inline_completion_debouncer_delay,
            "tool_config": {
                "builtinToolsets": allowed_builtin_toolsets,
                "mcpServers": mcp_server_tools,
                "extensions": extensions
            },
            "mcp_server_settings": nbi_config.mcp_server_settings,
            "claude_settings": _scrub_credentials_for_wire(
                nbi_config.claude_settings, self.string_overrides
            ),
            "claude_models": ai_service_manager.claude_models,
            # Drives launcher-tile visibility (issue #183).
            "claude_cli_available": shutil.which("claude") is not None,
            "default_chat_mode": nbi_config.default_chat_mode,
            "chat_feedback_enabled": self.enable_chat_feedback,
            "cell_output_features": _build_cell_output_features_response(
                self.feature_policies.get("explain_error", POLICY_USER_CHOICE),
                self.feature_policies.get("output_followup", POLICY_USER_CHOICE),
                self.feature_policies.get("output_toolbar", POLICY_USER_CHOICE),
                nbi_config,
            ),
            "feature_policies": _build_feature_policies_response(
                self.feature_policies, nbi_config
            ),
            "setting_locks": _build_setting_locks_response(self.string_overrides),
        }
        for participant_id in ai_service_manager.chat_participants:
            participant = ai_service_manager.chat_participants[participant_id]
            # prevent duplicate participants
            if participant.id in [p["id"] for p in response["chat_participants"]]:
                continue
            response["chat_participants"].append({
                "id": participant.id,
                "name": participant.name,
                "description": participant.description,
                "iconPath": participant.icon_path,
                "commands": [command.name for command in participant.commands]
            })
        self.finish(json.dumps(response))

class ConfigHandler(APIHandler):
    feature_policies = {}
    string_overrides = {}

    @tornado.web.authenticated
    def post(self):
        data = json.loads(self.request.body)
        valid_keys = set([
            "default_chat_mode",
            "chat_model",
            "inline_completion_model",
            "store_github_access_token",
            "inline_completion_debouncer_delay",
            "mcp_server_settings",
            "claude_settings",
            "enable_explain_error",
            "enable_output_followup",
            "enable_output_toolbar",
        ])
        # Top-level keys whose write is rejected outright when locked.
        locked_keys = set()
        if is_locked(self.feature_policies.get("explain_error", POLICY_USER_CHOICE)):
            locked_keys.add("enable_explain_error")
        if is_locked(self.feature_policies.get("output_followup", POLICY_USER_CHOICE)):
            locked_keys.add("enable_output_followup")
        if is_locked(self.feature_policies.get("output_toolbar", POLICY_USER_CHOICE)):
            locked_keys.add("enable_output_toolbar")
        if is_locked(self.feature_policies.get("store_github_access_token", POLICY_USER_CHOICE)):
            locked_keys.add("store_github_access_token")
        # chat_model / inline_completion_model are locked when *either* of their
        # provider/id env vars is set; the resolver below preserves the locked
        # subfield so a user can still update the unlocked one.
        chat_model_locked = bool(
            self.string_overrides.get("chat_model_provider")
            or self.string_overrides.get("chat_model_id")
        )
        inline_model_locked = bool(
            self.string_overrides.get("inline_completion_model_provider")
            or self.string_overrides.get("inline_completion_model_id")
        )

        has_model_change = False
        has_claude_settings_change = False
        for key in data:
            if key in locked_keys:
                continue
            if key not in valid_keys:
                continue
            value = data[key]
            # Re-apply the env override after the user's POST so locked fields
            # stay pinned; non-locked fields keep the user's value.
            if key == "chat_model":
                value = apply_string_overrides(
                    value, self.string_overrides, CHAT_MODEL_OVERRIDES
                )
                if chat_model_locked and value == ai_service_manager.nbi_config.chat_model:
                    continue
                has_model_change = True
            elif key == "inline_completion_model":
                value = apply_string_overrides(
                    value, self.string_overrides, INLINE_COMPLETION_MODEL_OVERRIDES
                )
                if (
                    inline_model_locked
                    and value == ai_service_manager.nbi_config.inline_completion_model
                ):
                    continue
                has_model_change = True
            elif key == "claude_settings":
                value = apply_claude_policies(value, self.feature_policies)
                value = apply_string_overrides(
                    value, self.string_overrides, CLAUDE_SETTINGS_OVERRIDES
                )
                # ANTHROPIC_API_KEY is a credential; don't persist it to
                # config.json. The SDK reads it from process env directly when
                # claude_settings.api_key is empty.
                if self.string_overrides.get("claude_api_key"):
                    value = dict(value)
                    value["api_key"] = ""
            ai_service_manager.nbi_config.set(key, value)
            if key == "store_github_access_token":
                if value:
                    github_copilot.store_github_access_token()
                else:
                    github_copilot.delete_stored_github_access_token()
            elif key == "mcp_server_settings":
                disabled_mcp_servers = []
                for server_id in value:
                    server_settings = value[server_id]
                    if server_settings.get("disabled") == True:
                        disabled_mcp_servers.append(server_id)
                ai_service_manager.update_mcp_server_connections(disabled_mcp_servers)
            elif key == "claude_settings":
                has_claude_settings_change = True
                default_chat_participant = ai_service_manager.default_chat_participant
                if isinstance(default_chat_participant, ClaudeCodeChatParticipant):
                    # needed to disconnect
                    default_chat_participant.update_client_debounced()

        ai_service_manager.nbi_config.save()
        if has_model_change or has_claude_settings_change:
            ai_service_manager.update_models_from_config()
        if has_claude_settings_change:
            default_chat_participant = ai_service_manager.default_chat_participant
            if isinstance(default_chat_participant, ClaudeCodeChatParticipant):
                # needed to reconnect / update
                default_chat_participant.update_client_debounced()

        self.finish(json.dumps({}))

class UpdateProviderModelsHandler(APIHandler):
    @tornado.web.authenticated
    def post(self):
        data = json.loads(self.request.body)
        if data.get("provider") == "ollama":
            ai_service_manager.ollama_llm_provider.update_chat_model_list()
        elif data.get("provider") == "claude":
            claude_settings = ai_service_manager.nbi_config.claude_settings
            fetch_claude_models(
                api_key=claude_settings.get('api_key', None),
                base_url=claude_settings.get('base_url', None)
            )
        self.finish(json.dumps({}))

class MCPConfigFileHandler(APIHandler):
    @tornado.web.authenticated
    def get(self):
        ai_service_manager.nbi_config.load()
        mcp_config = ai_service_manager.nbi_config.mcp.copy()
        if "mcpServers" not in mcp_config:
            mcp_config["mcpServers"] = {}
        self.finish(json.dumps(mcp_config))

    @tornado.web.authenticated
    def post(self):
        try:
            data = json.loads(self.request.body)
            ai_service_manager.nbi_config.user_mcp = data
            ai_service_manager.nbi_config.save()
            ai_service_manager.nbi_config.load()
            ai_service_manager.update_mcp_servers()
            self.finish(json.dumps({"status": "ok"}))
        except Exception as e:
            self.finish(json.dumps({"status": "error", "message": str(e)}))
            return

class ReloadMCPServersHandler(APIHandler):
    @tornado.web.authenticated
    def post(self):
        ai_service_manager.nbi_config.load()
        ai_service_manager.update_mcp_servers()
        self.finish(json.dumps({
            "mcpServers": [{"id": server.name} for server in ai_service_manager.get_mcp_servers()]
        }))

class EmitTelemetryEventHandler(APIHandler):
    @tornado.web.authenticated
    def post(self):
        event = json.loads(self.request.body)
        log.debug(f"Telemetry event received: type={event.get('type')}, data={json.dumps(event.get('data', {}))}")
        thread = threading.Thread(target=asyncio.run, args=(ai_service_manager.emit_telemetry_event(event),))
        thread.start()
        self.finish(json.dumps({}))

class GetGitHubLoginStatusHandler(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def get(self):
        self.finish(json.dumps(github_copilot.get_login_status()))

class PostGitHubLoginHandler(APIHandler):
    @tornado.web.authenticated
    def post(self):
        device_verification_info = github_copilot.login()
        if device_verification_info is None:
            self.set_status(500)
            self.finish(json.dumps({
                "error": "Failed to get device verification info from GitHub Copilot"
            }))
            return
        self.finish(json.dumps(device_verification_info))

class GetGitHubLogoutHandler(APIHandler):
    @tornado.web.authenticated
    def get(self):
        self.finish(json.dumps(github_copilot.logout()))

class RulesListHandler(APIHandler):
    @tornado.web.authenticated
    def get(self):
        """Get list of all rules with their status."""
        rule_manager = ai_service_manager.get_rule_manager()
        if not rule_manager:
            self.finish(json.dumps({"rules": [], "enabled": False}))
            return
        
        rules_summary = rule_manager.get_rules_summary()
        all_rules = rule_manager.ruleset.get_all_rules()
        
        rules_data = []
        for rule in all_rules:
            rules_data.append({
                "filename": rule.filename,
                "active": rule.active,
                "mode": rule.mode,
                "apply": rule.apply,
                "priority": rule.priority,
                "scope": rule.scope.__dict__,
                "content_preview": rule.content[:200] + "..." if len(rule.content) > 200 else rule.content
            })
        
        response = {
            "enabled": ai_service_manager.nbi_config.rules_enabled,
            "rules": rules_data,
            "summary": rules_summary
        }
        self.finish(json.dumps(response))

class RulesToggleHandler(APIHandler):
    @tornado.web.authenticated
    def put(self, rule_filename):
        """Toggle a rule's active state."""
        data = json.loads(self.request.body)
        active = data.get('active', True)
        
        rule_manager = ai_service_manager.get_rule_manager()
        if not rule_manager:
            self.set_status(404)
            self.finish(json.dumps({"error": "Rule system not enabled"}))
            return
        
        success = rule_manager.toggle_rule(rule_filename, active)
        if success:
            # Also update config
            ai_service_manager.nbi_config.set_rule_active(rule_filename, active)
            self.finish(json.dumps({"success": True}))
        else:
            self.set_status(404)
            self.finish(json.dumps({"error": "Rule not found"}))

class RulesReloadHandler(APIHandler):
    @tornado.web.authenticated
    def post(self):
        """Reload rules from disk."""
        rule_manager = ai_service_manager.get_rule_manager()
        if not rule_manager:
            self.set_status(404)
            self.finish(json.dumps({"error": "Rule system not enabled"}))
            return

        try:
            rule_manager.load_rules(force_reload=True)
            summary = rule_manager.get_rules_summary()
            self.finish(json.dumps({"success": True, "summary": summary}))
        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))


class SkillsBaseHandler(APIHandler):
    """Shared helpers for skills endpoints."""

    @property
    def skill_manager(self):
        return ai_service_manager.get_skill_manager()

    def _error(self, exc):
        if isinstance(exc, FileExistsError):
            self.set_status(409)
        elif isinstance(exc, FileNotFoundError):
            self.set_status(404)
        else:
            self.set_status(400)
        self.finish(json.dumps({"error": str(exc)}))

    def _bundle_rel_path(self):
        rel_path = self.get_query_argument("path", default=None)
        if not rel_path:
            self.set_status(400)
            self.finish(json.dumps({"error": "Missing required 'path' query parameter"}))
            return None
        return rel_path

    def _parse_json_body(self):
        try:
            return json.loads(self.request.body)
        except json.JSONDecodeError as e:
            self.set_status(400)
            self.finish(json.dumps({"error": f"Invalid JSON: {e}"}))
            return None


class SkillsListHandler(SkillsBaseHandler):
    @tornado.web.authenticated
    def get(self):
        # Skip the per-bundle file walk — the list view only needs metadata.
        skills = [s.to_dict(include_files=False) for s in self.skill_manager.list_skills()]
        self.finish(json.dumps({"skills": skills}))

    @tornado.web.authenticated
    def post(self):
        data = self._parse_json_body()
        if data is None:
            return
        try:
            skill = self.skill_manager.create_skill(
                scope=data["scope"],
                name=data["name"],
                description=data.get("description", ""),
                allowed_tools=data.get("allowed_tools", []),
                body=data.get("body", ""),
            )
            self.finish(json.dumps({"skill": skill.to_dict(include_body=True)}))
        except (FileExistsError, FileNotFoundError, ValueError, KeyError) as e:
            self._error(e)


class SkillsContextHandler(SkillsBaseHandler):
    @tornado.web.authenticated
    def get(self):
        project_root = get_jupyter_root_dir() or ""
        project_name = os.path.basename(os.path.normpath(project_root)) if project_root else ""
        self.finish(json.dumps({
            "project_root": project_root,
            "project_name": project_name,
            "user_skills_dir": str(self.skill_manager.scope_dir("user")),
            "project_skills_dir": str(self.skill_manager.scope_dir("project")),
        }))


class SkillDetailHandler(SkillsBaseHandler):
    @tornado.web.authenticated
    def get(self, scope, name):
        try:
            skill = self.skill_manager.get_skill(scope, name)
        except ValueError as e:
            self._error(e)
            return
        if skill is None:
            self.set_status(404)
            self.finish(json.dumps({"error": f"Skill '{name}' not found in {scope} scope"}))
            return
        self.finish(json.dumps({"skill": skill.to_dict(include_body=True)}))

    @tornado.web.authenticated
    def put(self, scope, name):
        data = self._parse_json_body()
        if data is None:
            return
        try:
            skill = self.skill_manager.update_skill(
                scope=scope,
                name=name,
                description=data.get("description"),
                allowed_tools=data.get("allowed_tools"),
                body=data.get("body"),
            )
            self.finish(json.dumps({"skill": skill.to_dict(include_body=True)}))
        except (FileNotFoundError, ValueError) as e:
            self._error(e)

    @tornado.web.authenticated
    def delete(self, scope, name):
        try:
            self.skill_manager.delete_skill(scope, name)
            self.finish(json.dumps({"success": True}))
        except (FileNotFoundError, ValueError) as e:
            self._error(e)


class SkillsImportPreviewHandler(SkillsBaseHandler):
    @tornado.web.authenticated
    def post(self):
        data = self._parse_json_body()
        if data is None:
            return
        url = data.get("url")
        if not url:
            self.set_status(400)
            self.finish(json.dumps({"error": "Missing required 'url'"}))
            return
        try:
            preview = self.skill_manager.preview_github_import(url)
            self.finish(json.dumps({"preview": preview}))
        except (FileNotFoundError, ValueError) as e:
            self._error(e)


class SkillsImportHandler(SkillsBaseHandler):
    @tornado.web.authenticated
    def post(self):
        data = self._parse_json_body()
        if data is None:
            return
        url = data.get("url")
        scope = data.get("scope")
        if not url or scope not in ("user", "project"):
            self.set_status(400)
            self.finish(json.dumps({
                "error": "Missing 'url' or invalid 'scope' (must be 'user' or 'project')"
            }))
            return
        try:
            skill = self.skill_manager.import_from_github(
                url=url,
                scope=scope,
                name_override=data.get("name"),
                overwrite=bool(data.get("overwrite", False)),
            )
            self.finish(json.dumps({"skill": skill.to_dict(include_body=True)}))
        except (FileExistsError, FileNotFoundError, ValueError) as e:
            self._error(e)


class SkillsReconcileHandler(SkillsBaseHandler):
    """Manual trigger for the managed-skills reconciler."""

    @tornado.web.authenticated
    async def post(self):
        reconciler = ai_service_manager.get_skill_reconciler()
        if reconciler is None:
            self.set_status(409)
            self.finish(json.dumps({
                "error": "No managed-skills manifest configured (set NBI_SKILLS_MANIFEST)."
            }))
            return
        # reconcile() does blocking HTTP + tarball extraction; run off the event loop.
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, reconciler.reconcile)
        self.finish(json.dumps(result.to_dict()))


class SkillRenameHandler(SkillsBaseHandler):
    @tornado.web.authenticated
    def post(self, scope, name):
        data = self._parse_json_body()
        if data is None:
            return
        new_name = data.get("new_name")
        if not new_name:
            self.set_status(400)
            self.finish(json.dumps({"error": "Missing required 'new_name'"}))
            return
        try:
            skill = self.skill_manager.rename_skill(scope, name, new_name)
            self.finish(json.dumps({"skill": skill.to_dict(include_body=True)}))
        except (FileExistsError, FileNotFoundError, ValueError) as e:
            self._error(e)


class SkillBundleFileHandler(SkillsBaseHandler):
    @tornado.web.authenticated
    def get(self, scope, name):
        rel_path = self._bundle_rel_path()
        if rel_path is None:
            return
        try:
            content = self.skill_manager.read_bundle_file(scope, name, rel_path)
            self.finish(json.dumps({"content": content}))
        except (FileNotFoundError, ValueError) as e:
            self._error(e)

    @tornado.web.authenticated
    def put(self, scope, name):
        rel_path = self._bundle_rel_path()
        if rel_path is None:
            return
        data = self._parse_json_body()
        if data is None:
            return
        if "content" not in data:
            self.set_status(400)
            self.finish(json.dumps({"error": "Missing required 'content' field"}))
            return
        try:
            self.skill_manager.write_bundle_file(scope, name, rel_path, data["content"])
            self.finish(json.dumps({"success": True}))
        except (FileNotFoundError, ValueError) as e:
            self._error(e)

    @tornado.web.authenticated
    def delete(self, scope, name):
        rel_path = self._bundle_rel_path()
        if rel_path is None:
            return
        try:
            self.skill_manager.delete_bundle_file(scope, name, rel_path)
            self.finish(json.dumps({"success": True}))
        except (FileNotFoundError, ValueError) as e:
            self._error(e)


class SkillBundleFileRenameHandler(SkillsBaseHandler):
    @tornado.web.authenticated
    def post(self, scope, name):
        data = self._parse_json_body()
        if data is None:
            return
        try:
            old_path = data["from"]
            new_path = data["to"]
        except KeyError as e:
            self.set_status(400)
            self.finish(json.dumps({"error": f"Invalid request: missing {e}"}))
            return
        try:
            self.skill_manager.rename_bundle_file(scope, name, old_path, new_path)
            self.finish(json.dumps({"success": True}))
        except (FileExistsError, FileNotFoundError, ValueError) as e:
            self._error(e)


_upload_dir: str | None = None

def _get_upload_dir() -> str:
    """Return a temp directory for uploaded files, creating it on first call."""
    global _upload_dir
    if _upload_dir is None:
        _upload_dir = tempfile.mkdtemp(prefix="nbi-uploads-")
        atexit.register(lambda d=_upload_dir: shutil.rmtree(d, ignore_errors=True))
    return _upload_dir

class FileUploadHandler(APIHandler):
    """Accepts a file upload and stores it in a temp directory.

    Returns the absolute server-side path so the frontend can reference it
    in chat context and Claude Code can read it natively.
    """

    @tornado.web.authenticated
    def post(self):
        fileinfo = self.request.files.get("file")
        if not fileinfo or len(fileinfo) == 0:
            self.set_status(400)
            self.finish(json.dumps({"error": "No file provided"}))
            return

        upload = fileinfo[0]
        original_name = upload.get("filename", "upload")
        # Sanitise filename: keep only the basename to prevent path traversal.
        safe_name = path.basename(original_name)
        if not safe_name:
            safe_name = "upload"

        upload_id = uuid.uuid4().hex[:12]
        dest_dir = path.join(_get_upload_dir(), upload_id)
        os.makedirs(dest_dir, exist_ok=True)
        dest_path = path.join(dest_dir, safe_name)

        with open(dest_path, "wb") as fh:
            fh.write(upload["body"])

        self.finish(json.dumps({
            "serverPath": dest_path,
            "filename": safe_name,
        }))


class ClaudeSessionsListHandler(APIHandler):
    """Lists Claude Code sessions for both pickers.

    Both pickers (chat sidebar and launcher tile) consume this endpoint
    via the same ``list_all_sessions`` backend so they cannot disagree on
    previews. ``?scope=cwd`` filters the response down to sessions whose
    transcript lives under the current Jupyter cwd (the chat sidebar
    case); ``?scope=all`` (the default) returns every project's sessions
    (the launcher tile case).

    ``current_cwd`` is the realpath-resolved Jupyter root the chat picker
    pairs with the session id to render ``cd ... && claude --resume <id>``.

    Guarded by ``is_claude_code_mode`` because both consumers are
    Claude-Code-specific surfaces — the launcher tile literally launches
    the ``claude`` CLI in a terminal.
    """

    @tornado.web.authenticated
    def get(self):
        if not ai_service_manager.is_claude_code_mode:
            self.set_status(404)
            self.finish(json.dumps({"error": "Claude Code mode is not enabled"}))
            return

        scope = self.get_query_argument("scope", "all")
        try:
            cwd = get_jupyter_root_dir()
            sessions = list_all_claude_sessions(cwd=cwd)
            if scope == "cwd" and cwd:
                target = str(get_claude_sessions_dir(cwd))
                sessions = [
                    s for s in sessions if os.path.dirname(s.path) == target
                ]
            self.finish(json.dumps({
                "sessions": [asdict(s) for s in sessions],
                "current_cwd": os.path.realpath(cwd) if cwd else "",
            }))
        except Exception as e:
            log.exception("Failed to list Claude sessions")
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))


class ClaudeSessionsResumeHandler(APIHandler):
    """Reconnects the Claude client so the next query resumes a session."""

    @tornado.web.authenticated
    def post(self):
        if not ai_service_manager.is_claude_code_mode:
            self.set_status(404)
            self.finish(json.dumps({"error": "Claude Code mode is not enabled"}))
            return

        try:
            body = json.loads(self.request.body or b"{}")
        except json.JSONDecodeError:
            self.set_status(400)
            self.finish(json.dumps({"error": "Request body must be JSON"}))
            return

        session_id = body.get("session_id")
        if not isinstance(session_id, str) or not session_id:
            self.set_status(400)
            self.finish(json.dumps({"error": "session_id is required"}))
            return

        default_chat_participant = ai_service_manager.default_chat_participant
        if not isinstance(default_chat_participant, ClaudeCodeChatParticipant):
            self.set_status(404)
            self.finish(json.dumps({"error": "Claude Code mode is not enabled"}))
            return

        try:
            default_chat_participant.resume_session(session_id)
        except Exception as e:
            log.exception("Failed to resume Claude session %s", session_id)
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))
            return

        self.finish(json.dumps({"success": True, "session_id": session_id}))

class ChatHistory:
    """
    History of chat messages, key is chat id, value is list of messages
    keep the last 10 messages in the same chat participant
    """
    MAX_MESSAGES = 10

    def __init__(self):
        self.messages = {}

    def clear(self, chatId = None):
        if chatId is None:
            self.messages = {}
            return True
        elif chatId in self.messages:
            del self.messages[chatId]
            return True

        return False

    def add_message(self, chatId, message):
        if chatId not in self.messages:
            self.messages[chatId] = []

        # clear the chat history if participant changed
        if message["role"] == "user":
            existing_messages = self.messages[chatId]
            prev_user_message = next((m for m in reversed(existing_messages) if m["role"] == "user"), None)
            if prev_user_message is not None:
                current_prompt_parts = AIServiceManager.parse_prompt(message["content"])
                prev_prompt_parts = AIServiceManager.parse_prompt(prev_user_message["content"])
                if current_prompt_parts.participant != prev_prompt_parts.participant:
                    self.messages[chatId] = []

        self.messages[chatId].append(message)
        # limit number of messages kept in history
        if len(self.messages[chatId]) > ChatHistory.MAX_MESSAGES:
            self.messages[chatId] = self.messages[chatId][-ChatHistory.MAX_MESSAGES:]

    def get_history(self, chatId):
        return self.messages.get(chatId, [])

class WebsocketCopilotResponseEmitter(ChatResponse):
    def __init__(self, chatId, messageId, websocket_handler, chat_history):
        super().__init__()
        self.chatId = chatId
        self.messageId = messageId
        self.websocket_handler = websocket_handler
        self.chat_history = chat_history
        self.streamed_contents = []
        self.streamed_reasoning_contents = []

    @property
    def chat_id(self) -> str:
        return self.chatId

    @property
    def message_id(self) -> str:
        return self.messageId

    def stream(self, data: Union[ResponseStreamData, dict]):
        data_type = ResponseStreamDataType.LLMRaw if type(data) is dict else data.data_type

        if data_type == ResponseStreamDataType.Markdown:
            self.chat_history.add_message(self.chatId, {"role": "assistant", "content": data.content, "reasoning_content": data.reasoning_content})
            data = {
                "choices": [
                    {
                        "delta": {
                            "nbiContent": {
                                "type": data_type,
                                "content": data.content,
                                "reasoning_content": data.reasoning_content,
                                "detail": data.detail
                            },
                            "content": "",
                            "role": "assistant"
                        }
                    }
                ]
            }
        elif data_type == ResponseStreamDataType.Image:
            data = {
                "choices": [
                    {
                        "delta": {
                            "nbiContent": {
                                "type": data_type,
                                "content": data.content
                            },
                            "content": "",
                            "role": "assistant"
                        }
                    }
                ]
            }
        elif data_type == ResponseStreamDataType.HTMLFrame:
            data = {
                "choices": [
                    {
                        "delta": {
                            "nbiContent": {
                                "type": data_type,
                                "content" : {
                                    "source": data.source,
                                    "height": data.height
                                }
                            },
                            "content": "",
                            "role": "assistant"
                        }
                    }
                ]
            }
        elif data_type == ResponseStreamDataType.Anchor:
            data = {
                "choices": [
                    {
                        "delta": {
                            "nbiContent": {
                                "type": data_type,
                                "content": {
                                    "uri": data.uri,
                                    "title": data.title
                                }
                            },
                            "content": "",
                            "role": "assistant"
                        }
                    }
                ]
            }
        elif data_type == ResponseStreamDataType.Button:
            data = {
                "choices": [
                    {
                        "delta": {
                            "nbiContent": {
                                "type": data_type,
                                "content": {
                                    "title": data.title,
                                    "commandId": data.commandId,
                                    "args": data.args if data.args is not None else {}
                                }
                            },
                            "content": "",
                            "role": "assistant"
                        }
                    }
                ]
            }
        elif data_type == ResponseStreamDataType.Progress:
            data = {
                "choices": [
                    {
                        "delta": {
                            "nbiContent": {
                                "type": data_type,
                                "content": data.title
                            },
                            "content": "",
                            "role": "assistant"
                        }
                    }
                ]
            }
        elif data_type == ResponseStreamDataType.Confirmation:
            data = {
                "choices": [
                    {
                        "delta": {
                            "nbiContent": {
                                "type": data_type,
                                "content": {
                                    "title": data.title,
                                    "message": data.message,
                                    "confirmArgs": data.confirmArgs if data.confirmArgs is not None else {},
                                    "confirmSessionArgs": data.confirmSessionArgs,
                                    "cancelArgs": data.cancelArgs if data.cancelArgs is not None else {},
                                    "confirmLabel": data.confirmLabel if data.confirmLabel is not None else "Approve",
                                    "confirmSessionLabel": data.confirmSessionLabel if data.confirmSessionLabel is not None else "Approve for this request",
                                    "cancelLabel": data.cancelLabel if data.cancelLabel is not None else "Cancel"
                                }
                            },
                            "content": "",
                            "role": "assistant"
                        }
                    }
                ]
            }
        elif data_type == ResponseStreamDataType.AskUserQuestion:
            data = {
                "choices": [
                    {
                        "delta": {
                            "nbiContent": {
                                "type": data_type,
                                "content": {
                                    "identifier": data.identifier,
                                    "title": data.title,
                                    "message": data.message,
                                    "questions": data.questions if data.questions is not None else [],
                                    "submitLabel": data.submitLabel if data.submitLabel is not None else "Submit",
                                    "cancelLabel": data.cancelLabel if data.cancelLabel is not None else "Cancel"
                                }
                            },
                            "content": "",
                            "role": "assistant"
                        }
                    }
                ]
            }
        elif data_type == ResponseStreamDataType.MarkdownPart:
            content = data.content
            reasoning_content = data.reasoning_content
            data = {
                "choices": [
                    {
                        "delta": {
                            "nbiContent": {
                                "type": data_type,
                                "content": data.content,
                                "reasoning_content": data.reasoning_content
                            },
                            "content": "",
                            "role": "assistant"
                        }
                    }
                ]
            }
            if content is not None:
                self.streamed_contents.append(content)
            if reasoning_content is not None:
                self.streamed_reasoning_contents.append(reasoning_content)
        else: # ResponseStreamDataType.LLMRaw
            if len(data.get("choices", [])) > 0:
                delta = data["choices"][0].get("delta", {})
                content = delta.get("content", "")
                reasoning_content = delta.get("reasoning_content", "")
                if content is not None:
                    self.streamed_contents.append(content)
                if reasoning_content is not None:
                    self.streamed_reasoning_contents.append(reasoning_content)

        self.websocket_handler.write_message({
            "id": self.messageId,
            "participant": self.participant_id,
            "type": BackendMessageType.StreamMessage,
            "data": data,
            "created": dt.datetime.now().isoformat()
        })

    def finish(self) -> None:
        self.chat_history.add_message(self.chatId, {"role": "assistant", "content": "".join(self.streamed_contents), "reasoning_content": "".join(self.streamed_reasoning_contents)})
        self.streamed_contents = []
        self.streamed_reasoning_contents = []
        self.websocket_handler.write_message({
            "id": self.messageId,
            "participant": self.participant_id,
            "type": BackendMessageType.StreamEnd,
            "data": {}
        })

    async def run_ui_command(self, command: str, args: dict = {}) -> None:
        callback_id = str(uuid.uuid4())
        self.websocket_handler.write_message({
            "id": self.messageId,
            "participant": self.participant_id,
            "type": BackendMessageType.RunUICommand,
            "data": {
                "callback_id": callback_id,
                "commandId": command,
                "args": args
            }
        })
        response = await ChatResponse.wait_for_run_ui_command_response(self, callback_id)
        return response

class CancelTokenImpl(CancelToken):
    def __init__(self):
        super().__init__()
        self._cancellation_signal = SignalImpl()

    def cancel_request(self) -> None:
        self._cancellation_requested = True
        self._cancellation_signal.emit()

@dataclass
class MessageCallbackHandlers:
    response_emitter: WebsocketCopilotResponseEmitter
    cancel_token: CancelTokenImpl

class WebsocketCopilotHandler(websocket.WebSocketHandler):
    # Cap WS message size at 4 MiB. Largest legitimate payload is a chat
    # request with ~10 attached output-context items (each capped at 1 MiB
    # by `coerce_payload`) + chat history; 4 MiB covers that without
    # leaving the default 10 MiB headroom for memory amplification.
    max_message_size = 4 * 1024 * 1024

    def __init__(self, application, request, context_factory=None, **kwargs):
        super().__init__(application, request, **kwargs)
        # TODO: cleanup
        self._messageCallbackHandlers: dict[str, MessageCallbackHandlers] = {}
        self.chat_history = ChatHistory()
        self._context_factory = context_factory or RuleContextFactory()
        ws_connector = ThreadSafeWebSocketConnector(self)
        ai_service_manager.websocket_connector = ws_connector
        github_copilot.websocket_connector = ws_connector

    def open(self):
        pass

    def on_message(self, message):
        msg = json.loads(message)

        messageId = msg['id']
        messageType = msg['type']
        if messageType == RequestDataType.ChatRequest:
            data = msg['data']
            chatId = data['chatId']
            prompt = data['prompt']
            language = data['language']
            filename = data['filename']
            additionalContext = data.get('additionalContext', [])
            chat_mode = ChatMode('agent', 'Agent') if data.get('chatMode', 'ask') == 'agent' else ChatMode('ask', 'Ask')
            toolSelections = data.get('toolSelections', {})
            tool_selection = RequestToolSelection(
                built_in_toolsets=toolSelections.get('builtinToolsets', []),
                mcp_server_tools=toolSelections.get('mcpServers', {}),
                extension_tools=toolSelections.get('extensions', {})
            )

            is_claude_code_mode = ai_service_manager.is_claude_code_mode
            chat_history = self.chat_history.get_history(chatId)
            chat_history_initial_size = len(chat_history)

            current_directory = data.get('currentDirectory')
            if (is_claude_code_mode or chat_mode.id == 'agent') and current_directory is not None:
                current_directory_file_msg = f"{NBI_CONTEXT_PREFIX} '{current_directory}'"
                if filename != '':
                    current_directory_file_msg += f" and current file is: '{filename}'"
                chat_history.append({"role": "user", "content": current_directory_file_msg})

            token_limit = 100 if ai_service_manager.chat_model is None else ai_service_manager.chat_model.context_window
            remaining_token_budget = int(0.8 * token_limit)

            for context in additionalContext:
                if remaining_token_budget <= 0:
                    break

                output_context = _coerce_output_context(context.get("outputContext"))
                if output_context is not None:
                    # Estimate cost without re-encoding the whole formatted
                    # message: per-bundle token counts are precomputed by the
                    # client (and capped by `coerce_payload`'s size limits);
                    # `cellSource` we count once. ~50-token allowance for the
                    # wrapper text is comfortably above the actual envelope.
                    bundle_tokens = sum(
                        b.get("sizeTokens", 0)
                        for b in output_context.get("mimeBundles", [])
                    )
                    cell_source = output_context.get("cellSource", "")
                    cell_source_tokens = _token_count(cell_source) if cell_source else 0
                    estimated_tokens = bundle_tokens + cell_source_tokens + 50
                    if estimated_tokens > remaining_token_budget:
                        log.info(
                            "Skipping output context: estimated %d tokens exceeds remaining budget %d",
                            estimated_tokens,
                            remaining_token_budget,
                        )
                        continue
                    supports_vision = _resolve_supports_vision(ai_service_manager)
                    context_message = _format_output_context(output_context, supports_vision=supports_vision)
                    remaining_token_budget -= estimated_tokens
                    chat_history.append({"role": "user", "content": context_message})
                    continue

                is_upload = context.get("isUpload", False)
                is_image = context.get("isImage", False)
                file_path = context["filePath"]
                if not is_upload:
                    file_path = path.join(NotebookIntelligence.root_dir, file_path)
                context_filename = path.basename(file_path)

                if is_image and is_upload:
                    if is_claude_code_mode:
                        # Claude Code CLI takes text only; pass file path so agent can read the image
                        chat_history.append({
                            "role": "user",
                            "content": f"The user pasted an image. It is saved at this path: '{file_path}'. Please read and analyze it."
                        })
                    else:
                        # Use OpenAI vision format for non-Claude-Code providers
                        mime_type = context.get("mimeType", "image/png")
                        try:
                            with open(file_path, "rb") as img_f:
                                b64_data = base64.b64encode(img_f.read()).decode("utf-8")
                            chat_history.append({
                                "role": "user",
                                "content": [
                                    {"type": "text", "text": f"The user pasted an image '{context_filename}':"},
                                    {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{b64_data}"}}
                                ]
                            })
                        except Exception as e:
                            log.warning(f"Failed to read pasted image '{file_path}': {e}")
                    continue

                start_line = context["startLine"]
                end_line = context["endLine"]
                current_cell_contents = context["currentCellContents"]
                current_cell_input = current_cell_contents["input"] if current_cell_contents is not None else ""
                current_cell_output = current_cell_contents["output"] if current_cell_contents is not None else ""
                current_cell_context = f"This is a Jupyter notebook and currently selected cell input is: ```{current_cell_input}``` and currently selected cell output is: ```{current_cell_output}```. If user asks a question about 'this' cell then assume that user is referring to currently selected cell." if current_cell_contents is not None else ""
                context_content = context.get("content", "")

                if context_content:
                    context_content = _truncate_context_content(
                        context_content,
                        remaining_token_budget
                    )

                if context_content == "" and remaining_token_budget <= 0:
                    break

                # For uploaded binary files (images, PDFs, etc.) where no
                # text content was extracted, tell Claude to read the file
                # from disk so it can handle it natively.
                if is_upload and context_content == "":
                    context_message = (
                        f"The user attached a file '{context_filename}' "
                        f"at path '{file_path}'. Read this file to see its contents."
                    )
                else:
                    context_message = _build_additional_context_message(
                        file_path=file_path,
                        context_filename=context_filename,
                        start_line=start_line,
                        end_line=end_line,
                        context_content=context_content,
                        current_cell_context=current_cell_context
                    )
                remaining_token_budget -= _token_count(context_message)
                chat_history.append({"role": "user", "content": context_message})

            chat_history.append({"role": "user", "content": prompt})

            response_emitter = WebsocketCopilotResponseEmitter(chatId, messageId, self, self.chat_history)
            cancel_token = CancelTokenImpl()
            self._messageCallbackHandlers[messageId] = MessageCallbackHandlers(response_emitter, cancel_token)
            
            # Create rule context for rule evaluation
            rule_context = self._context_factory.create(
                filename=filename,
                language=language,
                chat_mode_id=chat_mode.id,
                root_dir=NotebookIntelligence.root_dir
            )

            # last prompt is added later
            request_chat_history = chat_history[chat_history_initial_size:-1] if is_claude_code_mode else chat_history[:-1]
            thread = threading.Thread(target=asyncio.run, args=(ai_service_manager.handle_chat_request(ChatRequest(chat_mode=chat_mode, tool_selection=tool_selection, prompt=prompt, chat_history=request_chat_history, cancel_token=cancel_token, rule_context=rule_context), response_emitter),))
            thread.start()
        elif messageType == RequestDataType.GenerateCode:
            data = msg['data']
            chatId = data['chatId']
            prompt = data['prompt']
            prefix = data['prefix']
            suffix = data['suffix']
            existing_code = data['existingCode']
            language = data['language']
            filename = data['filename']
            is_claude_code_mode = ai_service_manager.is_claude_code_mode
            chat_mode = ChatMode('inline-chat', 'Inline Chat') if is_claude_code_mode else ChatMode('ask', 'Ask')
            if prefix != '':
                self.chat_history.add_message(chatId, {"role": "user", "content": f"This code section comes before the code section you will generate, use as context. Leading content: ```{prefix}```"})
            if suffix != '':
                self.chat_history.add_message(chatId, {"role": "user", "content": f"This code section comes after the code section you will generate, use as context. Trailing content: ```{suffix}```"})
            if existing_code != '':
                self.chat_history.add_message(chatId, {"role": "user", "content": f"You are asked to modify the existing code. Generate a replacement for this existing code : ```{existing_code}```"})
            self.chat_history.add_message(chatId, {"role": "user", "content": f"Generate code for: {prompt}"})
            response_emitter = WebsocketCopilotResponseEmitter(chatId, messageId, self, self.chat_history)
            cancel_token = CancelTokenImpl()
            self._messageCallbackHandlers[messageId] = MessageCallbackHandlers(response_emitter, cancel_token)
            existing_code_message = " Update the existing code section and return a modified version. Don't just return the update, recreate the existing code section with the update." if existing_code != '' else ''
            
            # Create rule context for rule evaluation
            # Note: Using 'inline-chat' mode for rule matching even though chat_mode is 'ask' for handler compatibility
            rule_context = self._context_factory.create(
                filename=filename,
                language=language,
                chat_mode_id='inline-chat',
                root_dir=NotebookIntelligence.root_dir
            )
            
            thread = threading.Thread(target=asyncio.run, args=(ai_service_manager.handle_chat_request(ChatRequest(chat_mode=chat_mode, prompt=prompt, chat_history=self.chat_history.get_history(chatId), cancel_token=cancel_token, rule_context=rule_context), response_emitter, options={"system_prompt": f"You are an assistant that generates code for '{language}' language. You generate code between existing leading and trailing code sections.{existing_code_message} Be concise and return only code as a response. Don't include leading content or trailing content in your response, they are provided only for context. You can reuse methods and symbols defined in leading and trailing content."}),))
            thread.start()
        elif messageType == RequestDataType.InlineCompletionRequest:
            data = msg['data']
            chatId = data['chatId']
            prefix = data['prefix']
            suffix = data['suffix']
            language = data['language']
            filename = data['filename']
            chat_history = ChatHistory()

            response_emitter = WebsocketCopilotResponseEmitter(chatId, messageId, self, chat_history)
            cancel_token = CancelTokenImpl()
            self._messageCallbackHandlers[messageId] = MessageCallbackHandlers(response_emitter, cancel_token)

            thread = threading.Thread(target=asyncio.run, args=(WebsocketCopilotHandler.handle_inline_completions(prefix, suffix, language, filename, response_emitter, cancel_token),))
            thread.start()
        elif messageType == RequestDataType.ChatUserInput:
            handlers = self._messageCallbackHandlers.get(messageId)
            if handlers is None:
                return
            handlers.response_emitter.on_user_input(msg['data'])
        elif messageType == RequestDataType.ClearChatHistory:
            is_claude_code_mode = ai_service_manager.is_claude_code_mode
            if is_claude_code_mode:
                default_chat_participant = ai_service_manager.default_chat_participant
                if isinstance(default_chat_participant, ClaudeCodeChatParticipant):
                    default_chat_participant.clear_chat_history()
            self.chat_history.clear()
        elif messageType == RequestDataType.RunUICommandResponse:
            handlers = self._messageCallbackHandlers.get(messageId)
            if handlers is None:
                return
            handlers.response_emitter.on_run_ui_command_response(msg['data'])
        elif messageType == RequestDataType.CancelChatRequest or  messageType == RequestDataType.CancelInlineCompletionRequest:
            handlers = self._messageCallbackHandlers.get(messageId)
            if handlers is None:
                return
            handlers.cancel_token.cancel_request()
 
    def on_close(self):
        pass

    async def handle_inline_completions(prefix, suffix, language, filename, response_emitter, cancel_token):
        if ai_service_manager.inline_completion_model is None:
            response_emitter.finish()
            return

        context = await ai_service_manager.get_completion_context(ContextRequest(ContextRequestType.InlineCompletion, prefix, suffix, language, filename, participant=ai_service_manager.get_chat_participant(prefix), cancel_token=cancel_token))

        if cancel_token.is_cancel_requested:
            response_emitter.finish()
            return

        completions = ai_service_manager.inline_completion_model.inline_completions(prefix, suffix, language, filename, context, cancel_token)
        if cancel_token.is_cancel_requested:
            response_emitter.finish()
            return

        response_emitter.stream({"completions": completions})
        response_emitter.finish()

class NotebookIntelligence(ExtensionApp):
    name = "notebook_intelligence"
    default_url = "/notebook-intelligence"
    load_other_extensions = True
    file_url_prefix = "/render"

    static_paths = []
    template_paths = []
    settings = {}
    handlers = []
    root_dir = ''

    disabled_providers = List(
        trait=Unicode(),
        default_value=None,
        help="""
        List of LLM providers to disable. Valid provider IDs: github-copilot, openai-compatible, litellm-compatible, ollama.

        Example: ['ollama', 'litellm-compatible']
        """,
        allow_none=True,
        config=True,
    )

    allow_enabling_providers_with_env = Bool(
        default_value=False,
        help="""
        Allow enabling disabled providers with environment variable (NBI_ENABLED_PROVIDERS).
        """,
        allow_none=True,
        config=True,
    )

    disabled_tools = List(
        trait=Unicode(),
        default_value=None,
        help="""
        List of built-in tools to disable. Valid tool names: nbi-notebook-edit, nbi-notebook-execute, nbi-python-file-edit, nbi-file-edit, nbi-file-read, nbi-command-execute.

        Example: ['nbi-python-file-edit', 'nbi-command-execute']
        """,
        allow_none=True,
        config=True,
    )

    allow_enabling_tools_with_env = Bool(
        default_value=False,
        help="""
        Allow enabling disabled tools with environment variable (NBI_ENABLED_BUILTIN_TOOLS).
        """,
        allow_none=True,
        config=True,
    )

    enable_chat_feedback = Bool(
        default_value=False,
        help="""
        Enable chat (thumb up/down) feedback feature.
        """,
        allow_none=True,
        config=True,
    )

    explain_error_policy = TraitletEnum(
        list(VALID_POLICIES),
        default_value=POLICY_USER_CHOICE,
        help="""
        Org-wide policy for the inline error-explanation feature on failed
        cells. "user-choice" (default) lets users toggle the feature in the
        Settings panel. "force-on" locks it enabled, "force-off" locks it
        disabled. Overridden by the NBI_EXPLAIN_ERROR_POLICY env var.
        """,
        config=True,
    )

    output_followup_policy = TraitletEnum(
        list(VALID_POLICIES),
        default_value=POLICY_USER_CHOICE,
        help="""
        Org-wide policy for the "Ask about this output" affordance on cell
        outputs. Same semantics as explain_error_policy. Overridden by the
        NBI_OUTPUT_FOLLOWUP_POLICY env var.
        """,
        config=True,
    )

    output_toolbar_policy = TraitletEnum(
        list(VALID_POLICIES),
        default_value=POLICY_USER_CHOICE,
        help="""
        Org-wide policy for the hover toolbar over cell outputs that
        surfaces Explain / Ask / Troubleshoot buttons. Same semantics as
        explain_error_policy. Overridden by the NBI_OUTPUT_TOOLBAR_POLICY
        env var.
        """,
        config=True,
    )

    claude_mode_policy = TraitletEnum(
        list(VALID_POLICIES),
        default_value=POLICY_USER_CHOICE,
        help="""
        Org-wide policy for whether Claude mode is enabled. Same semantics as
        explain_error_policy. Overridden by the NBI_CLAUDE_MODE_POLICY env var.
        """,
        config=True,
    )

    claude_continue_conversation_policy = TraitletEnum(
        list(VALID_POLICIES),
        default_value=POLICY_USER_CHOICE,
        help="""
        Org-wide policy for whether Claude remembers conversation history.
        Overridden by the NBI_CLAUDE_CONTINUE_CONVERSATION_POLICY env var.
        """,
        config=True,
    )

    claude_code_tools_policy = TraitletEnum(
        list(VALID_POLICIES),
        default_value=POLICY_USER_CHOICE,
        help="""
        Org-wide policy for whether the Claude Code built-in tool set is
        granted to the agent. Overridden by the NBI_CLAUDE_CODE_TOOLS_POLICY
        env var.
        """,
        config=True,
    )

    claude_jupyter_ui_tools_policy = TraitletEnum(
        list(VALID_POLICIES),
        default_value=POLICY_USER_CHOICE,
        help="""
        Org-wide policy for whether the Jupyter UI tool set is granted to
        Claude. Overridden by the NBI_CLAUDE_JUPYTER_UI_TOOLS_POLICY env var.
        """,
        config=True,
    )

    claude_setting_source_user_policy = TraitletEnum(
        list(VALID_POLICIES),
        default_value=POLICY_USER_CHOICE,
        help="""
        Org-wide policy for whether Claude reads the user-scoped settings
        source (~/.claude/settings.json). Overridden by the
        NBI_CLAUDE_SETTING_SOURCE_USER_POLICY env var.
        """,
        config=True,
    )

    claude_setting_source_project_policy = TraitletEnum(
        list(VALID_POLICIES),
        default_value=POLICY_USER_CHOICE,
        help="""
        Org-wide policy for whether Claude reads the project-scoped settings
        source. Overridden by the NBI_CLAUDE_SETTING_SOURCE_PROJECT_POLICY
        env var.
        """,
        config=True,
    )

    store_github_access_token_policy = TraitletEnum(
        list(VALID_POLICIES),
        default_value=POLICY_USER_CHOICE,
        help="""
        Org-wide policy for whether the GitHub Copilot access token is
        persisted to disk. Overridden by the
        NBI_STORE_GITHUB_ACCESS_TOKEN_POLICY env var.
        """,
        config=True,
    )

    skills_manifest = Unicode(
        default_value="",
        help="""
        URL or filesystem path to a YAML/JSON manifest describing managed
        Claude skills to install and keep in sync. Empty disables the feature.
        Overridden by the NBI_SKILLS_MANIFEST environment variable.
        """,
        config=True,
    )

    skills_manifest_interval = Int(
        default_value=86400,
        help="""
        Interval in seconds between managed-skills reconciles.
        Overridden by the NBI_SKILLS_MANIFEST_INTERVAL environment variable.
        """,
        config=True,
    )

    managed_skills_token = Unicode(
        default_value="",
        help="""
        Optional bearer token used for ALL managed-skills GitHub operations:
        fetching the manifest, probing commits, and downloading skill tarballs.
        Lets an org scope a minimal-privilege token for the whole managed
        pathway without affecting user-initiated imports (which continue to use
        GITHUB_TOKEN / GH_TOKEN / `gh auth`). Overridden by the
        NBI_MANAGED_SKILLS_TOKEN environment variable.
        """,
        config=True,
    )

    def initialize_settings(self):
        pass

    def _publish_policies(self, feature_policies: dict, string_overrides: dict) -> None:
        """Wire the resolved policies into the HTTP handlers.

        ``nbi_config`` is already configured during ``AIServiceManager.__init__``
        so its model-bootstrap path sees the policy-resolved values.
        """
        GetCapabilitiesHandler.feature_policies = feature_policies
        GetCapabilitiesHandler.string_overrides = string_overrides
        ConfigHandler.feature_policies = feature_policies
        ConfigHandler.string_overrides = string_overrides

    def initialize_handlers(self):
        NotebookIntelligence.root_dir = self.serverapp.root_dir
        set_jupyter_root_dir(NotebookIntelligence.root_dir)
        server_root_dir = os.path.expanduser(self.serverapp.web_app.settings["server_root_dir"])
        # Resolve admin policies first so the AI service sees the locked
        # values during its initial model bootstrap (e.g. NBI_CLAUDE_MODE_POLICY
        # =force-on actually starts Claude mode rather than waiting for the
        # first capabilities GET).
        feature_policies = {
            name: _resolve_policy_with_env(env_var, getattr(self, attr))
            for name, env_var, attr in FEATURE_POLICY_SPEC
        }
        string_overrides = {
            name: os.environ.get(env_var, "").strip()
            for name, env_var in STRING_OVERRIDE_SPEC
        }
        self.initialize_ai_service(
            server_root_dir, feature_policies, string_overrides
        )
        self._setup_handlers(self.serverapp.web_app, feature_policies, string_overrides)
        self.serverapp.log.info(f"Registered {self.name} server extension")

    def initialize_ai_service(
        self,
        server_root_dir: str,
        feature_policies: dict,
        string_overrides: dict,
    ):
        global ai_service_manager
        manifest_source = os.environ.get("NBI_SKILLS_MANIFEST", "").strip() or self.skills_manifest.strip()
        managed_token = (
            os.environ.get("NBI_MANAGED_SKILLS_TOKEN", "").strip()
            or self.managed_skills_token.strip()
        )
        interval_env = os.environ.get("NBI_SKILLS_MANIFEST_INTERVAL", "").strip()
        manifest_interval = self.skills_manifest_interval
        if interval_env:
            try:
                manifest_interval = int(interval_env)
            except ValueError:
                log.warning(
                    "Ignoring invalid NBI_SKILLS_MANIFEST_INTERVAL=%r", interval_env
                )
        ai_service_manager = AIServiceManager({
            "server_root_dir": server_root_dir,
            "skills_manifest": manifest_source,
            "skills_manifest_interval": manifest_interval,
            "managed_skills_token": managed_token,
            "feature_policies": feature_policies,
            "string_overrides": string_overrides,
        })

    def initialize_templates(self):
        pass

    async def stop_extension(self):
        log.info(f"Stopping {self.name} extension...")
        github_copilot.handle_stop_request()
        ai_service_manager.handle_stop_request()

    def _setup_handlers(self, web_app, feature_policies: dict, string_overrides: dict):
        host_pattern = ".*$"

        base_url = web_app.settings["base_url"]
        route_pattern_capabilities = url_path_join(base_url, "notebook-intelligence", "capabilities")
        route_pattern_config = url_path_join(base_url, "notebook-intelligence", "config")
        route_pattern_update_provider_models = url_path_join(base_url, "notebook-intelligence", "update-provider-models")
        route_pattern_mcp_config_file = url_path_join(base_url, "notebook-intelligence", "mcp-config-file")
        route_pattern_reload_mcp_servers = url_path_join(base_url, "notebook-intelligence", "reload-mcp-servers")
        route_pattern_emit_telemetry_event = url_path_join(base_url, "notebook-intelligence", "emit-telemetry-event")
        route_pattern_github_login_status = url_path_join(base_url, "notebook-intelligence", "gh-login-status")
        route_pattern_github_login = url_path_join(base_url, "notebook-intelligence", "gh-login")
        route_pattern_github_logout = url_path_join(base_url, "notebook-intelligence", "gh-logout")
        route_pattern_copilot = url_path_join(base_url, "notebook-intelligence", "copilot")
        route_pattern_rules = url_path_join(base_url, "notebook-intelligence", "rules")
        route_pattern_rules_toggle = url_path_join(base_url, "notebook-intelligence", "rules", r"([^/]+)", "toggle")
        route_pattern_rules_reload = url_path_join(base_url, "notebook-intelligence", "rules", "reload")
        skill_name = f"({SKILL_NAME_REGEX})"
        route_pattern_skills = url_path_join(base_url, "notebook-intelligence", "skills")
        route_pattern_skills_context = url_path_join(base_url, "notebook-intelligence", "skills", "context")
        route_pattern_skills_import_preview = url_path_join(base_url, "notebook-intelligence", "skills", "import", "preview")
        route_pattern_skills_import = url_path_join(base_url, "notebook-intelligence", "skills", "import")
        route_pattern_skills_reconcile = url_path_join(base_url, "notebook-intelligence", "skills", "reconcile")
        route_pattern_skill_detail = url_path_join(base_url, "notebook-intelligence", "skills", r"(user|project)", skill_name)
        route_pattern_skill_rename = url_path_join(base_url, "notebook-intelligence", "skills", r"(user|project)", skill_name, "rename")
        route_pattern_skill_bundle_file = url_path_join(base_url, "notebook-intelligence", "skills", r"(user|project)", skill_name, "files")
        route_pattern_skill_bundle_file_rename = url_path_join(base_url, "notebook-intelligence", "skills", r"(user|project)", skill_name, "files", "rename")
        route_pattern_upload_file = url_path_join(base_url, "notebook-intelligence", "upload-file")
        route_pattern_claude_sessions = url_path_join(base_url, "notebook-intelligence", "claude-sessions")
        route_pattern_claude_sessions_resume = url_path_join(base_url, "notebook-intelligence", "claude-sessions", "resume")
        GetCapabilitiesHandler.disabled_tools = self.disabled_tools
        GetCapabilitiesHandler.allow_enabling_tools_with_env = self.allow_enabling_tools_with_env
        GetCapabilitiesHandler.disabled_providers = self.disabled_providers
        GetCapabilitiesHandler.allow_enabling_providers_with_env = self.allow_enabling_providers_with_env
        GetCapabilitiesHandler.enable_chat_feedback = self.enable_chat_feedback
        self._publish_policies(feature_policies, string_overrides)
        NotebookIntelligence.handlers = [
            (route_pattern_capabilities, GetCapabilitiesHandler),
            (route_pattern_config, ConfigHandler),
            (route_pattern_update_provider_models, UpdateProviderModelsHandler),
            (route_pattern_mcp_config_file, MCPConfigFileHandler),
            (route_pattern_reload_mcp_servers, ReloadMCPServersHandler),
            (route_pattern_emit_telemetry_event, EmitTelemetryEventHandler),
            (route_pattern_github_login_status, GetGitHubLoginStatusHandler),
            (route_pattern_github_login, PostGitHubLoginHandler),
            (route_pattern_github_logout, GetGitHubLogoutHandler),
            (route_pattern_rules, RulesListHandler),
            (route_pattern_rules_toggle, RulesToggleHandler),
            (route_pattern_rules_reload, RulesReloadHandler),
            # Skill routes: order matters. Tornado matches in registration order, and the
            # SKILL_NAME_REGEX in `skill_detail` would otherwise eat "import", "context", etc.
            # Always register more specific routes before the {scope}/{name} catch-all.
            (route_pattern_skills, SkillsListHandler),
            (route_pattern_skills_context, SkillsContextHandler),
            (route_pattern_skills_import_preview, SkillsImportPreviewHandler),
            (route_pattern_skills_import, SkillsImportHandler),
            (route_pattern_skills_reconcile, SkillsReconcileHandler),
            (route_pattern_skill_bundle_file_rename, SkillBundleFileRenameHandler),
            (route_pattern_skill_bundle_file, SkillBundleFileHandler),
            (route_pattern_skill_rename, SkillRenameHandler),
            (route_pattern_skill_detail, SkillDetailHandler),
            (route_pattern_upload_file, FileUploadHandler),
            (route_pattern_claude_sessions_resume, ClaudeSessionsResumeHandler),
            (route_pattern_claude_sessions, ClaudeSessionsListHandler),
            (route_pattern_copilot, WebsocketCopilotHandler),
        ]
        web_app.add_handlers(host_pattern, NotebookIntelligence.handlers)
