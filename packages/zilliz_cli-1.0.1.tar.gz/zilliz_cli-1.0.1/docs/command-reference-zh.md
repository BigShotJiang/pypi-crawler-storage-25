# Zilliz CLI 命令参考手册

> **[English Version](command-reference.md)**

Zilliz CLI (`zilliz`) 是一个用于管理 Zilliz Cloud 集群和操作 Milvus 向量数据库的命令行工具。

## 目录

- [Zilliz CLI 命令参考手册](#zilliz-cli-命令参考手册)
  - [目录](#目录)
  - [全局选项](#全局选项)
  - [Endpoint 架构](#endpoint-架构)
  - [认证与配置](#认证与配置)
    - [login](#login)
    - [logout](#logout)
    - [auth](#auth)
      - [auth status](#auth-status)
      - [auth switch](#auth-switch)
    - [configure](#configure)
      - [configure（交互式）](#configure交互式)
      - [configure set](#configure-set)
      - [configure get](#configure-get)
      - [configure list](#configure-list)
      - [configure clear](#configure-clear)
    - [context](#context)
      - [context set](#context-set)
      - [context current](#context-current)
  - [集群管理](#集群管理)
    - [cluster create](#cluster-create)
    - [cluster list](#cluster-list)
    - [cluster describe](#cluster-describe)
    - [cluster modify](#cluster-modify)
    - [cluster suspend](#cluster-suspend)
    - [cluster resume](#cluster-resume)
    - [cluster delete](#cluster-delete)
    - [cluster providers](#cluster-providers)
    - [cluster regions](#cluster-regions)
  - [项目管理](#项目管理)
    - [project create](#project-create)
    - [project list](#project-list)
    - [project describe](#project-describe)
    - [project upgrade](#project-upgrade)
  - [Collection 管理](#collection-管理)
    - [collection create](#collection-create)
    - [collection list](#collection-list)
    - [collection describe](#collection-describe)
    - [collection drop](#collection-drop)
    - [collection rename](#collection-rename)
    - [collection load](#collection-load)
    - [collection release](#collection-release)
    - [collection get-load-state](#collection-get-load-state)
    - [collection get-stats](#collection-get-stats)
    - [collection has](#collection-has)
    - [collection flush](#collection-flush)
    - [collection compact](#collection-compact)
  - [向量操作](#向量操作)
    - [vector insert](#vector-insert)
    - [vector upsert](#vector-upsert)
    - [vector search](#vector-search)
    - [vector hybrid-search](#vector-hybrid-search)
    - [vector query](#vector-query)
    - [vector get](#vector-get)
    - [vector delete](#vector-delete)
  - [数据库管理](#数据库管理)
    - [database create](#database-create)
    - [database list](#database-list)
    - [database describe](#database-describe)
    - [database drop](#database-drop)
  - [索引管理](#索引管理)
    - [index create](#index-create)
    - [index list](#index-list)
    - [index describe](#index-describe)
    - [index drop](#index-drop)
  - [分区管理](#分区管理)
    - [partition create](#partition-create)
    - [partition list](#partition-list)
    - [partition drop](#partition-drop)
    - [partition has](#partition-has)
    - [partition get-stats](#partition-get-stats)
    - [partition load](#partition-load)
    - [partition release](#partition-release)
  - [用户管理](#用户管理)
    - [user create](#user-create)
    - [user list](#user-list)
    - [user describe](#user-describe)
    - [user drop](#user-drop)
    - [user update-password](#user-update-password)
    - [user grant-role](#user-grant-role)
    - [user revoke-role](#user-revoke-role)
  - [角色管理](#角色管理)
    - [role create](#role-create)
    - [role list](#role-list)
    - [role describe](#role-describe)
    - [role drop](#role-drop)
    - [role grant-privilege](#role-grant-privilege)
    - [role revoke-privilege](#role-revoke-privilege)
  - [别名管理](#别名管理)
    - [alias create](#alias-create)
    - [alias list](#alias-list)
    - [alias describe](#alias-describe)
    - [alias alter](#alias-alter)
    - [alias drop](#alias-drop)
  - [备份管理](#备份管理)
    - [backup create](#backup-create)
    - [backup list](#backup-list)
    - [backup describe](#backup-describe)
    - [backup delete](#backup-delete)
    - [backup export](#backup-export)
    - [backup restore-cluster](#backup-restore-cluster)
    - [backup restore-collection](#backup-restore-collection)
    - [backup describe-policy](#backup-describe-policy)
    - [backup update-policy](#backup-update-policy)
  - [导入管理](#导入管理)
    - [import start](#import-start)
    - [import list](#import-list)
    - [import status](#import-status)
  - [存储卷管理](#存储卷管理)
    - [volume create](#volume-create)
    - [volume list](#volume-list)
    - [volume delete](#volume-delete)
  - [账单](#账单)
    - [billing usage](#billing-usage)
    - [billing invoices](#billing-invoices)
    - [billing bind-card](#billing-bind-card)
  - [任务管理](#任务管理)
    - [job describe](#job-describe)
  - [告警管理](#告警管理)
    - [alert list](#alert-list)
    - [alert create](#alert-create)
    - [alert update](#alert-update)
    - [alert delete](#alert-delete)
    - [alert enable](#alert-enable)
    - [alert disable](#alert-disable)
  - [集群指标](#集群指标)
    - [cluster metrics](#cluster-metrics)
  - [Shell 自动补全](#shell-自动补全)
    - [completion install](#completion-install)
    - [completion uninstall](#completion-uninstall)
    - [completion status](#completion-status)
    - [completion show](#completion-show)
  - [版本信息](#版本信息)
  - [快速上手](#快速上手)
  - [使用技巧](#使用技巧)
    - [API Key 优先级顺序](#api-key-优先级顺序)
    - [文件输入](#文件输入)
    - [分页](#分页)
    - [输出格式](#输出格式)

---

## 全局选项

所有命令都支持以下全局选项：

| 选项        | 简写 | 说明                                    |
| ----------- | ---- | --------------------------------------- |
| `--output`  | `-o` | 输出格式：`json`、`table`、`text`、`yaml`、`csv` |
| `--api-key` |      | API Key（优先级高于配置文件和环境变量） |
| `--help`    |      | 显示帮助信息                            |
| `--version` |      | 显示 CLI 版本                           |

```bash
# 示例
zilliz cluster list --output json
zilliz cluster list --api-key <YOUR_API_KEY>
```

---

## Endpoint 架构

CLI 连接两种类型的 API 端点：

| 类型                        | Endpoint                       | 用途                                                                          |
| --------------------------- | ------------------------------ | ----------------------------------------------------------------------------- |
| **Control Plane（控制面）** | `https://api.cloud.zilliz.com` | 项目、集群、备份、导入、存储卷、账单管理                                      |
| **Data Plane（数据面）**    | 集群专属 endpoint              | 数据操作（collection、vector、database、index、partition、user、role、alias） |

Data Plane 命令需要先通过 `zilliz context set` 设置集群上下文。

---

## 认证与配置

### login

登录 Zilliz Cloud。支持浏览器 OAuth 登录和 API Key 登录两种方式。

```
zilliz login [OPTIONS]
```

| 参数           | 是否必填 | 类型 | 说明                            |
| -------------- | -------- | ---- | ------------------------------- |
| `--no-browser` | 否       | flag | 不自动打开浏览器进行 OAuth 认证 |
| `--api-key`    | 否       | flag | 使用 API Key 认证代替浏览器登录 |

```bash
# 浏览器登录（默认）
zilliz login

# API Key 登录
zilliz login --api-key

# 不自动打开浏览器
zilliz login --no-browser
```

---

### logout

清除所有已保存的凭据和登录数据。

```
zilliz logout
```

无参数。

```bash
zilliz logout
```

---

### auth

管理认证状态和组织切换。

#### auth status

显示当前认证状态（用户、组织、API Key）。

```
zilliz auth status
```

```bash
zilliz auth status
```

#### auth switch

切换到其他组织。

```
zilliz auth switch [ORG_ID]
```

| 参数     | 是否必填 | 类型   | 说明                              |
| -------- | -------- | ------ | --------------------------------- |
| `ORG_ID` | 否       | string | 组织 ID。省略时显示交互式选择界面 |

```bash
# 交互式选择组织
zilliz auth switch

# 切换到指定组织
zilliz auth switch <ORG_ID>
```

---

### configure

管理 CLI 配置（API Key 等）。

#### configure（交互式）

交互式配置凭据。

```bash
zilliz configure
```

#### configure set

设置配置项。

```
zilliz configure set KEY [VALUE]
```

| 参数    | 是否必填 | 类型   | 说明                                 |
| ------- | -------- | ------ | ------------------------------------ |
| `KEY`   | 是       | string | 配置键名（例如 `api_key`）           |
| `VALUE` | 否       | string | 配置值。凭据类项省略时会安全提示输入 |

```bash
# 设置 API Key（安全提示输入）
zilliz configure set api_key

# 直接设置 API Key
zilliz configure set api_key <YOUR_API_KEY>
```

#### configure get

获取配置项的值。

```
zilliz configure get KEY
```

```bash
zilliz configure get api_key
```

#### configure list

列出所有配置项。

```bash
zilliz configure list
```

#### configure clear

清除所有已存储的凭据。

```bash
zilliz configure clear
```

---

### context

管理集群上下文，用于 Data Plane 操作。

#### context set

设置当前集群上下文。Data Plane 命令（collection、vector 等）将使用此端点。

```
zilliz context set [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                                          |
| -------------- | -------- | ------ | --------------------------------------------- |
| `--cluster-id` | 否       | string | 集群 ID。省略时显示交互式选择界面             |
| `--endpoint`   | 否       | string | 集群 endpoint URL。省略时自动从集群信息中获取 |
| `--database`   | 否       | string | 默认数据库名称                                |

```bash
# 交互式选择集群
zilliz context set

# 通过集群 ID 设置上下文（自动获取 endpoint）
zilliz context set --cluster-id <CLUSTER_ID>

# 设置上下文并指定数据库
zilliz context set --cluster-id <CLUSTER_ID> --database my_database
```

#### context current

显示当前集群上下文。

```
zilliz context current [OPTIONS]
```

| 参数       | 是否必填 | 类型   | 说明                              |
| ---------- | -------- | ------ | --------------------------------- |
| `--output` | 否       | string | 输出格式：`json`、`table`、`text` |

```bash
zilliz context current
zilliz context current -o json
```

---

## 集群管理

### cluster create

创建新的云集群。缺少必填参数时支持交互式提示。

```
zilliz cluster create [OPTIONS]
```

| 参数           | 是否必填 | 类型    | 说明                                                                     |
| -------------- | -------- | ------- | ------------------------------------------------------------------------ |
| `--name`       | 是       | string  | 集群显示名称                                                             |
| `--type`       | 是       | string  | 集群类型：`serverless`、`free`、`dedicated`                              |
| `--project-id` | 是       | string  | 目标项目 ID                                                              |
| `--region`     | 是       | string  | 云区域（例如 `aws-us-west-2`）                                           |
| `--cu-type`    | 否       | string  | CU 类型：`Performance-optimized`、`Capacity-optimized`（仅 dedicated）   |
| `--cu-size`    | 否       | integer | 计算单元数量（仅 dedicated）                                             |
| `--plan`       | 否       | string  | 订阅计划：`Free`、`Serverless`、`Standard`、`Enterprise`（仅 dedicated） |
| `--output`     | 否       | string  | 输出格式：`json`、`table`、`text`                                        |

```bash
# 创建 serverless 集群
zilliz cluster create --name my-cluster --type serverless --project-id <PROJECT_ID> --region aws-us-west-2

# 创建 dedicated 集群
zilliz cluster create --name my-cluster --type dedicated --project-id <PROJECT_ID> --region aws-us-west-2 --cu-size 2 --plan Standard

# 交互模式（缺少参数时自动提示）
zilliz cluster create
```

---

### cluster list

列出所有集群。

```
zilliz cluster list [OPTIONS]
```

| 参数          | 是否必填 | 类型    | 说明                              |
| ------------- | -------- | ------- | --------------------------------- |
| `--page-size` | 否       | integer | 每页条数（默认：100）             |
| `--page`      | 否       | integer | 页码                              |
| `--all`       | 否       | flag    | 获取所有分页数据                  |
| `--output`    | 否       | string  | 输出格式：`json`、`table`、`text` |

```bash
# 列出所有集群
zilliz cluster list

# 获取所有分页
zilliz cluster list --all

# JSON 格式输出
zilliz cluster list -o json
```

---

### cluster describe

查看集群详细信息。

```
zilliz cluster describe [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                                |
| -------------- | -------- | ------ | ----------------------------------- |
| `--cluster-id` | **是**   | string | 集群 ID（例如 `in01-xxxxxxxxxxxx`） |
| `--output`     | 否       | string | 输出格式：`json`、`table`、`text`   |

```bash
zilliz cluster describe --cluster-id <CLUSTER_ID>
```

---

### cluster modify

修改集群配置（扩缩容 CU 或副本数）。

```
zilliz cluster modify [OPTIONS]
```

| 参数           | 是否必填 | 类型    | 说明                              |
| -------------- | -------- | ------- | --------------------------------- |
| `--cluster-id` | **是**   | string  | 要修改的集群 ID                   |
| `--cu-size`    | 否       | integer | 计算单元数量                      |
| `--replica`    | 否       | integer | 副本数量                          |
| `--body`       | 否       | string  | 请求体 JSON 或 `file://path.json` |
| `--output`     | 否       | string  | 输出格式：`json`、`table`、`text` |

```bash
# 扩容到 2 个 CU
zilliz cluster modify --cluster-id <CLUSTER_ID> --cu-size 2

# 设置副本数
zilliz cluster modify --cluster-id <CLUSTER_ID> --replica 2
```

---

### cluster suspend

暂停运行中的集群。暂停后停止计算费用。

```
zilliz cluster suspend [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明            |
| -------------- | -------- | ------ | --------------- |
| `--cluster-id` | **是**   | string | 要暂停的集群 ID |

```bash
zilliz cluster suspend --cluster-id <CLUSTER_ID>
```

---

### cluster resume

恢复已暂停的集群。

```
zilliz cluster resume [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明            |
| -------------- | -------- | ------ | --------------- |
| `--cluster-id` | **是**   | string | 要恢复的集群 ID |

```bash
zilliz cluster resume --cluster-id <CLUSTER_ID>
```

---

### cluster delete

删除集群。此操作不可逆。

```
zilliz cluster delete [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明            |
| -------------- | -------- | ------ | --------------- |
| `--cluster-id` | **是**   | string | 要删除的集群 ID |
| `-y`           | 否       | flag   | 跳过确认提示    |

```bash
zilliz cluster delete --cluster-id <CLUSTER_ID>

# 跳过确认提示
zilliz cluster delete --cluster-id <CLUSTER_ID> -y
```

---

### cluster providers

列出所有云服务商（aws、gcp、azure）。

```
zilliz cluster providers
```

无参数。

```bash
zilliz cluster providers
```

---

### cluster regions

列出指定云服务商的可用区域。

```
zilliz cluster regions [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明                            |
| ------------ | -------- | ------ | ------------------------------- |
| `--cloud-id` | 否       | string | 云服务商：`aws`、`gcp`、`azure` |

```bash
# 列出所有区域
zilliz cluster regions

# 仅列出 AWS 区域
zilliz cluster regions --cloud-id aws
```

---

## 项目管理

### project create

创建新项目。

```
zilliz project create [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明                                                     |
| -------- | -------- | ------ | -------------------------------------------------------- |
| `--name` | **是**   | string | 项目名称                                                 |
| `--plan` | **是**   | string | 订阅计划：`Free`、`Serverless`、`Standard`、`Enterprise` |

```bash
zilliz project create --name my-project --plan Standard
```

---

### project list

列出所有项目。

```
zilliz project list
```

无参数。

```bash
zilliz project list
```

---

### project describe

查看项目详细信息。

```
zilliz project describe [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明    |
| -------------- | -------- | ------ | ------- |
| `--project-id` | **是**   | string | 项目 ID |

```bash
zilliz project describe --project-id <PROJECT_ID>
```

---

### project upgrade

升级项目订阅计划。

```
zilliz project upgrade [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                                             |
| -------------- | -------- | ------ | ------------------------------------------------ |
| `--project-id` | **是**   | string | 项目 ID                                          |
| `--plan`       | 否       | string | 目标计划：`Serverless`、`Standard`、`Enterprise` |

```bash
zilliz project upgrade --project-id <PROJECT_ID> --plan Enterprise
```

---

## Collection 管理

> Data Plane 命令 - 需要先设置集群上下文（`zilliz context set`）。

### collection create

创建新的 collection。

```
zilliz collection create [OPTIONS]
```

| 参数              | 是否必填                | 类型    | 说明                                   |
| ----------------- | ----------------------- | ------- | -------------------------------------- |
| `--name`          | **是**                  | string  | Collection 名称                        |
| `--dimension`     | 是（除非使用 `--body`） | integer | 向量维度                               |
| `--metric-type`   | 否                      | string  | 距离度量：`COSINE`（默认）、`L2`、`IP` |
| `--id-type`       | 否                      | string  | 主键类型：`Int64`、`VarChar`           |
| `--auto-id`       | 否                      | boolean | 自动生成主键                           |
| `--primary-field` | 否                      | string  | 主键字段名                             |
| `--vector-field`  | 否                      | string  | 向量字段名                             |
| `--database`      | 否                      | string  | 数据库名称                             |
| `--body`          | 否                      | string  | 完整 schema JSON 或 `file://path.json` |

```bash
# 使用默认值快速创建（COSINE 度量，自动 schema）
zilliz collection create --name my_collection --dimension 768

# 使用 L2 度量和 VarChar 主键创建
zilliz collection create --name my_collection --dimension 768 --metric-type L2 --id-type VarChar

# 通过 JSON body 创建完整 schema
zilliz collection create --name my_collection --body file://schema.json
```

---

### collection list

列出所有 collection。

```
zilliz collection list [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明       |
| ------------ | -------- | ------ | ---------- |
| `--database` | 否       | string | 数据库名称 |

```bash
zilliz collection list
zilliz collection list --database my_database
```

---

### collection describe

查看 collection 详细信息。

```
zilliz collection describe [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明            |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **是**   | string | Collection 名称 |
| `--database` | 否       | string | 数据库名称      |

```bash
zilliz collection describe --name my_collection
```

---

### collection drop

删除 collection。此操作不可逆。

```
zilliz collection drop [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明                     |
| ------------ | -------- | ------ | ------------------------ |
| `--name`     | **是**   | string | 要删除的 collection 名称 |
| `--database` | 否       | string | 数据库名称               |

```bash
zilliz collection drop --name my_collection
```

---

### collection rename

重命名 collection。

```
zilliz collection rename [OPTIONS]
```

| 参数             | 是否必填 | 类型   | 说明                                   |
| ---------------- | -------- | ------ | -------------------------------------- |
| `--name`         | **是**   | string | 当前 collection 名称                   |
| `--new-name`     | **是**   | string | 新的 collection 名称                   |
| `--database`     | 否       | string | 当前数据库名称                         |
| `--new-database` | 否       | string | 目标数据库名称（跨数据库重命名时使用） |

```bash
zilliz collection rename --name old_collection --new-name new_collection
```

---

### collection load

将 collection 加载到内存中以供搜索使用。

```
zilliz collection load [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明            |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **是**   | string | Collection 名称 |
| `--database` | 否       | string | 数据库名称      |

```bash
zilliz collection load --name my_collection
```

---

### collection release

从内存中释放 collection。

```
zilliz collection release [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明            |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **是**   | string | Collection 名称 |
| `--database` | 否       | string | 数据库名称      |

```bash
zilliz collection release --name my_collection
```

---

### collection get-load-state

获取 collection 的加载状态。

```
zilliz collection get-load-state [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明            |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **是**   | string | Collection 名称 |
| `--database` | 否       | string | 数据库名称      |

```bash
zilliz collection get-load-state --name my_collection
```

---

### collection get-stats

获取 collection 统计信息（行数等）。

```
zilliz collection get-stats [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明            |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **是**   | string | Collection 名称 |
| `--database` | 否       | string | 数据库名称      |

```bash
zilliz collection get-stats --name my_collection
```

---

### collection has

检查 collection 是否存在。

```
zilliz collection has [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明            |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **是**   | string | Collection 名称 |
| `--database` | 否       | string | 数据库名称      |

```bash
zilliz collection has --name my_collection
```

---

### collection flush

将 collection 数据刷新到磁盘。

```
zilliz collection flush [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明            |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **是**   | string | Collection 名称 |
| `--database` | 否       | string | 数据库名称      |

```bash
zilliz collection flush --name my_collection
```

---

### collection compact

压缩 collection 的 segment 以优化存储。

```
zilliz collection compact [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明            |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **是**   | string | Collection 名称 |
| `--database` | 否       | string | 数据库名称      |

```bash
zilliz collection compact --name my_collection
```

---

## 向量操作

> Data Plane 命令 - 需要先设置集群上下文（`zilliz context set`）。

### vector insert

向 collection 中插入实体。

```
zilliz vector insert [OPTIONS]
```

| 参数           | 是否必填                | 类型         | 说明                                |
| -------------- | ----------------------- | ------------ | ----------------------------------- |
| `--collection` | **是**                  | string       | Collection 名称                     |
| `--data`       | 是（除非使用 `--body`） | array (JSON) | 实体 JSON 数组或 `file://path.json` |
| `--database`   | 否                      | string       | 数据库名称                          |
| `--body`       | 否                      | string       | 请求体 JSON 或 `file://path.json`   |

```bash
# 使用内联 JSON 插入
zilliz vector insert --collection my_col --data '[{"id": 1, "vector": [0.1, 0.2, 0.3]}]'

# 从 JSON 文件插入
zilliz vector insert --collection my_col --data file:///path/to/data.json
```

---

### vector upsert

Upsert 实体（存在则更新，不存在则插入）。

```
zilliz vector upsert [OPTIONS]
```

| 参数           | 是否必填                | 类型         | 说明                                |
| -------------- | ----------------------- | ------------ | ----------------------------------- |
| `--collection` | **是**                  | string       | Collection 名称                     |
| `--data`       | 是（除非使用 `--body`） | array (JSON) | 实体 JSON 数组或 `file://path.json` |
| `--partition`  | 否                      | string       | 分区名称                            |
| `--database`   | 否                      | string       | 数据库名称                          |
| `--body`       | 否                      | string       | 请求体 JSON 或 `file://path.json`   |

```bash
# 使用内联 JSON upsert
zilliz vector upsert --collection my_col --data '[{"id": 1, "vector": [0.1, 0.2, 0.3]}]'

# 从 JSON 文件 upsert
zilliz vector upsert --collection my_col --data file:///path/to/data.json
```

---

### vector search

搜索相似向量。

```
zilliz vector search [OPTIONS]
```

| 参数              | 是否必填 | 类型         | 说明                       |
| ----------------- | -------- | ------------ | -------------------------- |
| `--collection`    | **是**   | string       | Collection 名称            |
| `--data`          | **是**   | array (JSON) | 查询向量 JSON 数组         |
| `--anns-field`    | 否       | string       | 要搜索的向量字段           |
| `--limit`         | 否       | integer      | 最大返回结果数（默认：10） |
| `--filter`        | 否       | string       | 标量过滤表达式             |
| `--output-fields` | 否       | array (JSON) | 要返回的字段 JSON 数组     |
| `--database`      | 否       | string       | 数据库名称                 |

```bash
# 基本向量搜索
zilliz vector search --collection my_col --data '[[0.1, 0.2, 0.3]]' --limit 10

# 带标量过滤的搜索
zilliz vector search --collection my_col --data '[[0.1, 0.2]]' --filter 'age > 18' --output-fields '["name", "age"]'
```

---

### vector hybrid-search

执行多向量混合搜索并重排序。

```
zilliz vector hybrid-search [OPTIONS]
```

| 参数              | 是否必填                | 类型          | 说明                              |
| ----------------- | ----------------------- | ------------- | --------------------------------- |
| `--collection`    | **是**                  | string        | Collection 名称                   |
| `--search`        | 是（除非使用 `--body`） | array (JSON)  | 搜索请求 JSON 数组                |
| `--rerank`        | 是（除非使用 `--body`） | object (JSON) | 重排序策略 JSON                   |
| `--limit`         | 否                      | integer       | 最大返回结果数（默认：10）        |
| `--output-fields` | 否                      | array (JSON)  | 要返回的字段 JSON 数组            |
| `--database`      | 否                      | string        | 数据库名称                        |
| `--body`          | 否                      | string        | 请求体 JSON 或 `file://path.json` |

```bash
# 使用 JSON body 文件进行混合搜索
zilliz vector hybrid-search --collection my_col --body file://hybrid-search.json
```

---

### vector query

通过标量过滤表达式查询实体。

```
zilliz vector query [OPTIONS]
```

| 参数              | 是否必填 | 类型         | 说明                       |
| ----------------- | -------- | ------------ | -------------------------- |
| `--collection`    | **是**   | string       | Collection 名称            |
| `--filter`        | **是**   | string       | 标量过滤表达式             |
| `--limit`         | 否       | integer      | 最大返回结果数（默认：10） |
| `--output-fields` | 否       | array (JSON) | 要返回的字段 JSON 数组     |
| `--database`      | 否       | string       | 数据库名称                 |

```bash
zilliz vector query --collection my_col --filter 'id > 100' --limit 10
```

---

### vector get

通过主键 ID 获取实体。

```
zilliz vector get [OPTIONS]
```

| 参数              | 是否必填 | 类型         | 说明                   |
| ----------------- | -------- | ------------ | ---------------------- |
| `--collection`    | **是**   | string       | Collection 名称        |
| `--id`            | **是**   | array (JSON) | 主键 ID JSON 数组      |
| `--output-fields` | 否       | array (JSON) | 要返回的字段 JSON 数组 |
| `--database`      | 否       | string       | 数据库名称             |

```bash
zilliz vector get --collection my_col --id '[1, 2, 3]'
```

---

### vector delete

通过过滤表达式删除实体。

```
zilliz vector delete [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                 |
| -------------- | -------- | ------ | -------------------- |
| `--collection` | **是**   | string | Collection 名称      |
| `--filter`     | **是**   | string | 删除实体的过滤表达式 |
| `--partition`  | 否       | string | 分区名称             |
| `--database`   | 否       | string | 数据库名称           |

```bash
zilliz vector delete --collection my_col --filter 'id in [1, 2, 3]'
```

---

## 数据库管理

> Data Plane 命令 - 需要先设置集群上下文。数据库的创建/查看/删除仅限 Dedicated 集群。

### database create

创建新数据库。（仅 Dedicated 集群）

```
zilliz database create [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明                              |
| -------- | -------- | ------ | --------------------------------- |
| `--name` | **是**   | string | 数据库名称                        |
| `--body` | 否       | string | 请求体 JSON 或 `file://path.json` |

```bash
zilliz database create --name my_database
```

---

### database list

列出所有数据库。

```
zilliz database list
```

无参数。

```bash
zilliz database list
```

---

### database describe

查看数据库详细信息。（仅 Dedicated 集群）

```
zilliz database describe [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明       |
| -------- | -------- | ------ | ---------- |
| `--name` | **是**   | string | 数据库名称 |

```bash
zilliz database describe --name my_database
```

---

### database drop

删除数据库。（仅 Dedicated 集群）

```
zilliz database drop [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明               |
| -------- | -------- | ------ | ------------------ |
| `--name` | **是**   | string | 要删除的数据库名称 |

```bash
zilliz database drop --name my_database
```

---

## 索引管理

> Data Plane 命令 - 需要先设置集群上下文（`zilliz context set`）。

### index create

在 collection 字段上创建索引。

```
zilliz index create [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                                                     |
| -------------- | -------- | ------ | -------------------------------------------------------- |
| `--collection` | **是**   | string | Collection 名称                                          |
| `--database`   | 否       | string | 数据库名称                                               |
| `--body`       | 否       | string | 包含 `indexParams` 的索引规格 JSON 或 `file://path.json` |

```bash
zilliz index create --collection my_col --body '{"indexParams": [{"fieldName": "vector", "indexType": "AUTOINDEX"}]}'
```

---

### index list

列出 collection 上的所有索引。

```
zilliz index list [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明            |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **是**   | string | Collection 名称 |
| `--database`   | 否       | string | 数据库名称      |

```bash
zilliz index list --collection my_collection
```

---

### index describe

查看索引详细信息。

```
zilliz index describe [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明            |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **是**   | string | Collection 名称 |
| `--index-name` | **是**   | string | 索引名称        |
| `--database`   | 否       | string | 数据库名称      |

```bash
zilliz index describe --collection my_collection --index-name my_index
```

---

### index drop

删除索引。

```
zilliz index drop [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明             |
| -------------- | -------- | ------ | ---------------- |
| `--collection` | **是**   | string | Collection 名称  |
| `--index-name` | **是**   | string | 要删除的索引名称 |
| `--database`   | 否       | string | 数据库名称       |

```bash
zilliz index drop --collection my_collection --index-name my_index
```

---

## 分区管理

> Data Plane 命令 - 需要先设置集群上下文（`zilliz context set`）。

### partition create

在 collection 中创建分区。

```
zilliz partition create [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明            |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **是**   | string | Collection 名称 |
| `--partition`  | **是**   | string | 分区名称        |
| `--database`   | 否       | string | 数据库名称      |

```bash
zilliz partition create --collection my_collection --partition my_partition
```

---

### partition list

列出 collection 中的所有分区。

```
zilliz partition list [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明            |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **是**   | string | Collection 名称 |
| `--database`   | 否       | string | 数据库名称      |

```bash
zilliz partition list --collection my_collection
```

---

### partition drop

删除分区。

```
zilliz partition drop [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明             |
| -------------- | -------- | ------ | ---------------- |
| `--collection` | **是**   | string | Collection 名称  |
| `--partition`  | **是**   | string | 要删除的分区名称 |
| `--database`   | 否       | string | 数据库名称       |

```bash
zilliz partition drop --collection my_collection --partition my_partition
```

---

### partition has

检查分区是否存在。

```
zilliz partition has [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明            |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **是**   | string | Collection 名称 |
| `--partition`  | **是**   | string | 分区名称        |
| `--database`   | 否       | string | 数据库名称      |

```bash
zilliz partition has --collection my_collection --partition my_partition
```

---

### partition get-stats

获取分区统计信息。

```
zilliz partition get-stats [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明            |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **是**   | string | Collection 名称 |
| `--partition`  | **是**   | string | 分区名称        |
| `--database`   | 否       | string | 数据库名称      |

```bash
zilliz partition get-stats --collection my_collection --partition my_partition
```

---

### partition load

将分区加载到内存中。

```
zilliz partition load [OPTIONS]
```

| 参数           | 是否必填 | 类型         | 说明               |
| -------------- | -------- | ------------ | ------------------ |
| `--collection` | **是**   | string       | Collection 名称    |
| `--names`      | **是**   | array (JSON) | 分区名称 JSON 数组 |
| `--database`   | 否       | string       | 数据库名称         |

```bash
zilliz partition load --collection my_collection --names '["p1", "p2"]'
```

---

### partition release

从内存中释放分区。

```
zilliz partition release [OPTIONS]
```

| 参数           | 是否必填 | 类型         | 说明               |
| -------------- | -------- | ------------ | ------------------ |
| `--collection` | **是**   | string       | Collection 名称    |
| `--names`      | **是**   | array (JSON) | 分区名称 JSON 数组 |
| `--database`   | 否       | string       | 数据库名称         |

```bash
zilliz partition release --collection my_collection --names '["p1", "p2"]'
```

---

## 用户管理

> Data Plane 命令 - 仅限 Dedicated 集群。需要先设置集群上下文（`zilliz context set`）。

### user create

创建新的数据库用户。

```
zilliz user create [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明   |
| ------------ | -------- | ------ | ------ |
| `--user`     | **是**   | string | 用户名 |
| `--password` | **是**   | string | 密码   |

```bash
zilliz user create --user <USERNAME> --password <PASSWORD>
```

---

### user list

列出所有数据库用户。

```
zilliz user list
```

无参数。

```bash
zilliz user list
```

---

### user describe

查看用户详细信息。

```
zilliz user describe [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明   |
| -------- | -------- | ------ | ------ |
| `--user` | **是**   | string | 用户名 |

```bash
zilliz user describe --user <USERNAME>
```

---

### user drop

删除数据库用户。

```
zilliz user drop [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明           |
| -------- | -------- | ------ | -------------- |
| `--user` | **是**   | string | 要删除的用户名 |

```bash
zilliz user drop --user <USERNAME>
```

---

### user update-password

更新用户密码。

```
zilliz user update-password [OPTIONS]
```

| 参数             | 是否必填 | 类型   | 说明     |
| ---------------- | -------- | ------ | -------- |
| `--user`         | **是**   | string | 用户名   |
| `--password`     | **是**   | string | 当前密码 |
| `--new-password` | **是**   | string | 新密码   |

```bash
zilliz user update-password --user <USERNAME> --password <OLD_PASSWORD> --new-password <NEW_PASSWORD>
```

---

### user grant-role

为用户授予角色。

```
zilliz user grant-role [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明           |
| -------- | -------- | ------ | -------------- |
| `--user` | **是**   | string | 用户名         |
| `--role` | **是**   | string | 要授予的角色名 |

```bash
zilliz user grant-role --user <USERNAME> --role admin
```

---

### user revoke-role

撤销用户的角色。

```
zilliz user revoke-role [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明           |
| -------- | -------- | ------ | -------------- |
| `--user` | **是**   | string | 用户名         |
| `--role` | **是**   | string | 要撤销的角色名 |

```bash
zilliz user revoke-role --user <USERNAME> --role admin
```

---

## 角色管理

> Data Plane 命令 - 仅限 Dedicated 集群。需要先设置集群上下文（`zilliz context set`）。

### role create

创建新角色。

```
zilliz role create [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明     |
| -------- | -------- | ------ | -------- |
| `--role` | **是**   | string | 角色名称 |

```bash
zilliz role create --role my_role
```

---

### role list

列出所有角色。

```
zilliz role list
```

无参数。

```bash
zilliz role list
```

---

### role describe

查看角色详细信息和权限。

```
zilliz role describe [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明     |
| -------- | -------- | ------ | -------- |
| `--role` | **是**   | string | 角色名称 |

```bash
zilliz role describe --role my_role
```

---

### role drop

删除角色。

```
zilliz role drop [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明             |
| -------- | -------- | ------ | ---------------- |
| `--role` | **是**   | string | 要删除的角色名称 |

```bash
zilliz role drop --role my_role
```

---

### role grant-privilege

为角色授予权限。

```
zilliz role grant-privilege [OPTIONS]
```

| 参数            | 是否必填 | 类型   | 说明                                                    |
| --------------- | -------- | ------ | ------------------------------------------------------- |
| `--role`        | **是**   | string | 角色名称                                                |
| `--object-type` | **是**   | string | 对象类型：`Global`、`Collection`、`Database`            |
| `--object-name` | **是**   | string | 对象名称（`*` 表示全部）                                |
| `--privilege`   | **是**   | string | 权限名称（例如 `Search`、`Insert`、`CreateCollection`） |
| `--database`    | 否       | string | 数据库名称                                              |

```bash
# 授予指定 collection 的搜索权限
zilliz role grant-privilege --role my_role --object-type Collection --object-name my_col --privilege Search

# 授予所有 collection 的所有权限
zilliz role grant-privilege --role my_role --object-type Collection --object-name '*' --privilege '*'
```

---

### role revoke-privilege

撤销角色的权限。

```
zilliz role revoke-privilege [OPTIONS]
```

| 参数            | 是否必填 | 类型   | 说明                                         |
| --------------- | -------- | ------ | -------------------------------------------- |
| `--role`        | **是**   | string | 角色名称                                     |
| `--object-type` | **是**   | string | 对象类型：`Global`、`Collection`、`Database` |
| `--object-name` | **是**   | string | 对象名称（`*` 表示全部）                     |
| `--privilege`   | **是**   | string | 权限名称                                     |
| `--database`    | 否       | string | 数据库名称                                   |

```bash
zilliz role revoke-privilege --role my_role --object-type Collection --object-name my_col --privilege Search
```

---

## 别名管理

> Data Plane 命令 - 需要先设置集群上下文（`zilliz context set`）。

### alias create

创建指向 collection 的别名。

```
zilliz alias create [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                 |
| -------------- | -------- | ------ | -------------------- |
| `--collection` | **是**   | string | 目标 collection 名称 |
| `--alias`      | **是**   | string | 别名                 |
| `--database`   | 否       | string | 数据库名称           |

```bash
zilliz alias create --collection my_collection --alias my_alias
```

---

### alias list

列出所有别名。

```
zilliz alias list [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                   |
| -------------- | -------- | ------ | ---------------------- |
| `--database`   | **是**   | string | 数据库名称             |
| `--collection` | 否       | string | 按 collection 名称过滤 |

```bash
zilliz alias list --database default
```

---

### alias describe

查看别名详细信息。

```
zilliz alias describe [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明       |
| ------------ | -------- | ------ | ---------- |
| `--alias`    | **是**   | string | 别名       |
| `--database` | 否       | string | 数据库名称 |

```bash
zilliz alias describe --alias my_alias
```

---

### alias alter

将别名重新指向另一个 collection。

```
zilliz alias alter [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                |
| -------------- | -------- | ------ | ------------------- |
| `--collection` | **是**   | string | 新的目标 collection |
| `--alias`      | **是**   | string | 要重新指向的别名    |
| `--database`   | 否       | string | 数据库名称          |

```bash
zilliz alias alter --collection new_collection --alias my_alias
```

---

### alias drop

删除别名。

```
zilliz alias drop [OPTIONS]
```

| 参数         | 是否必填 | 类型   | 说明         |
| ------------ | -------- | ------ | ------------ |
| `--alias`    | **是**   | string | 要删除的别名 |
| `--database` | 否       | string | 数据库名称   |

```bash
zilliz alias drop --alias my_alias
```

---

## 备份管理

### backup create

为集群创建备份。

```
zilliz backup create [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                                  |
| -------------- | -------- | ------ | ------------------------------------- |
| `--cluster-id` | **是**   | string | 集群 ID                               |
| `--database`   | 否       | string | 数据库名称（用于 collection 级备份）  |
| `--collection` | 否       | string | Collection 名称（省略则为全集群备份） |
| `--body`       | 否       | string | 请求体 JSON 或 `file://path.json`     |

```bash
# 全集群备份（默认）
zilliz backup create --cluster-id <CLUSTER_ID>

# Collection 级备份
zilliz backup create --cluster-id <CLUSTER_ID> --database default --collection my_col
```

---

### backup list

列出所有备份。

```
zilliz backup list [OPTIONS]
```

| 参数                | 是否必填 | 类型    | 说明                                    |
| ------------------- | -------- | ------- | --------------------------------------- |
| `--project-id`      | 否       | string  | 按项目 ID 过滤                          |
| `--cluster-id`      | 否       | string  | 按集群 ID 过滤                          |
| `--creation-method` | 否       | string  | 按创建方式过滤：`manual`、`auto`        |
| `--backup-type`     | 否       | string  | 按备份类型过滤：`CLUSTER`、`COLLECTION` |
| `--page-size`       | 否       | integer | 每页条数                                |
| `--page`            | 否       | integer | 页码                                    |
| `--all`             | 否       | flag    | 获取所有分页数据                        |

```bash
# 列出所有备份
zilliz backup list

# 列出指定集群的备份
zilliz backup list --cluster-id <CLUSTER_ID>
```

---

### backup describe

查看备份详细信息。

```
zilliz backup describe [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明    |
| -------------- | -------- | ------ | ------- |
| `--cluster-id` | **是**   | string | 集群 ID |
| `--backup-id`  | **是**   | string | 备份 ID |

```bash
zilliz backup describe --cluster-id <CLUSTER_ID> --backup-id <BACKUP_ID>
```

---

### backup delete

删除备份。

```
zilliz backup delete [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明            |
| -------------- | -------- | ------ | --------------- |
| `--cluster-id` | **是**   | string | 集群 ID         |
| `--backup-id`  | **是**   | string | 要删除的备份 ID |

```bash
zilliz backup delete --cluster-id <CLUSTER_ID> --backup-id <BACKUP_ID>
```

---

### backup export

将备份导出到外部存储。

```
zilliz backup export [OPTIONS]
```

| 参数               | 是否必填 | 类型   | 说明                 |
| ------------------ | -------- | ------ | -------------------- |
| `--cluster-id`     | **是**   | string | 集群 ID              |
| `--backup-id`      | **是**   | string | 备份 ID              |
| `--integration-id` | **是**   | string | 存储集成 ID          |
| `--directory`      | 否       | string | 外部存储中的目标目录 |

```bash
zilliz backup export --cluster-id <CLUSTER_ID> --backup-id <BACKUP_ID> --integration-id <INTEGRATION_ID>
```

---

### backup restore-cluster

将备份恢复到新集群。

```
zilliz backup restore-cluster [OPTIONS]
```

| 参数                  | 是否必填 | 类型    | 说明                                             |
| --------------------- | -------- | ------- | ------------------------------------------------ |
| `--cluster-id`        | **是**   | string  | 源集群 ID                                        |
| `--backup-id`         | **是**   | string  | 要恢复的备份 ID                                  |
| `--project-id`        | **是**   | string  | 目标项目 ID                                      |
| `--name`              | **是**   | string  | 新集群名称                                       |
| `--cu-size`           | **是**   | integer | 新集群的计算单元数                               |
| `--collection-status` | **是**   | string  | 恢复后 collection 的状态：`LOADED`、`NOT_LOADED` |

```bash
# 恢复并加载 collection
zilliz backup restore-cluster \
  --cluster-id <CLUSTER_ID> \
  --backup-id <BACKUP_ID> \
  --project-id <PROJECT_ID> \
  --name restored-cluster \
  --cu-size 1 \
  --collection-status LOADED
```

---

### backup restore-collection

从备份中恢复指定的 collection。

```
zilliz backup restore-collection [OPTIONS]
```

| 参数                | 是否必填 | 类型   | 说明                         |
| ------------------- | -------- | ------ | ---------------------------- |
| `--cluster-id`      | **是**   | string | 源集群 ID                    |
| `--backup-id`       | **是**   | string | 备份 ID                      |
| `--dest-cluster-id` | **是**   | string | 目标集群 ID                  |
| `--body`            | 否       | string | 指定恢复 collection 的请求体 |

```bash
zilliz backup restore-collection --cluster-id <CLUSTER_ID> --backup-id <BACKUP_ID> --dest-cluster-id <DEST_CLUSTER_ID>
```

---

### backup describe-policy

查看集群的备份策略。

```
zilliz backup describe-policy [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明    |
| -------------- | -------- | ------ | ------- |
| `--cluster-id` | **是**   | string | 集群 ID |

```bash
zilliz backup describe-policy --cluster-id <CLUSTER_ID>
```

---

### backup update-policy

更新集群的备份策略。

```
zilliz backup update-policy [OPTIONS]
```

| 参数               | 是否必填                    | 类型    | 说明                                                                             |
| ------------------ | --------------------------- | ------- | -------------------------------------------------------------------------------- |
| `--cluster-id`     | **是**                      | string  | 集群 ID                                                                          |
| `--auto-backup`    | **是**                      | boolean | 开启（`true`）或关闭（`false`）自动备份                                          |
| `--frequency`      | `--auto-backup true` 时必填 | string  | `daily`、`weekdays`、`weekends` 或星期数字 `1-7`（1=周一，7=周日），例如 `1,3,5` |
| `--start-time`     | `--auto-backup true` 时必填 | string  | UTC 开始时间，例如 `02:00`                                                       |
| `--retention-days` | `--auto-backup true` 时必填 | integer | 备份保留天数（1-30）                                                             |
| `--body`           | 否                          | string  | 请求体 JSON 或 `file://path.json`                                                |

```bash
# 启用每日凌晨 2 点 UTC 备份，保留 7 天
zilliz backup update-policy --cluster-id <CLUSTER_ID> --auto-backup true --frequency daily --start-time 02:00 --retention-days 7

# 启用周一/周三/周五凌晨 3 点 UTC 备份
zilliz backup update-policy --cluster-id <CLUSTER_ID> --auto-backup true --frequency 1,3,5 --start-time 03:00 --retention-days 14

# 关闭自动备份
zilliz backup update-policy --cluster-id <CLUSTER_ID> --auto-backup false
```

---

## 导入管理

### import start

启动数据导入任务。

```
zilliz import start [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                                |
| -------------- | -------- | ------ | ----------------------------------- |
| `--cluster-id` | **是**   | string | 目标集群 ID                         |
| `--collection` | **是**   | string | 目标 collection 名称                |
| `--body`       | 否       | string | 导入规格 JSON 或 `file://path.json` |

```bash
# 从 S3 导入
zilliz import start --cluster-id <CLUSTER_ID> --collection my_col --body '{"files": [["s3://bucket/data.json"]]}'

# 使用 JSON 文件导入
zilliz import start --cluster-id <CLUSTER_ID> --collection my_col --body file://import-spec.json
```

---

### import list

列出集群的导入任务。

```
zilliz import list [OPTIONS]
```

| 参数           | 是否必填 | 类型    | 说明       |
| -------------- | -------- | ------- | ---------- |
| `--cluster-id` | **是**   | string  | 集群 ID    |
| `--page-size`  | 否       | integer | 每页条数   |
| `--page`       | 否       | integer | 页码       |
| `--database`   | 否       | string  | 数据库名称 |

```bash
zilliz import list --cluster-id <CLUSTER_ID>
```

---

### import status

获取导入任务的状态。

```
zilliz import status [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明        |
| -------------- | -------- | ------ | ----------- |
| `--job-id`     | **是**   | string | 导入任务 ID |
| `--cluster-id` | **是**   | string | 集群 ID     |

```bash
zilliz import status --job-id <JOB_ID> --cluster-id <CLUSTER_ID>
```

---

## 存储卷管理

### volume create

创建新的存储卷。

```
zilliz volume create [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                           |
| -------------- | -------- | ------ | ------------------------------ |
| `--project-id` | **是**   | string | 项目 ID                        |
| `--region`     | **是**   | string | 云区域（例如 `aws-us-west-2`） |
| `--name`       | **是**   | string | 存储卷名称                     |

```bash
zilliz volume create --project-id <PROJECT_ID> --region aws-us-west-2 --name my-volume
```

---

### volume list

列出项目中的所有存储卷。

```
zilliz volume list [OPTIONS]
```

| 参数           | 是否必填 | 类型    | 说明             |
| -------------- | -------- | ------- | ---------------- |
| `--project-id` | **是**   | string  | 项目 ID          |
| `--page-size`  | 否       | integer | 每页条数         |
| `--page`       | 否       | integer | 页码             |
| `--all`        | 否       | flag    | 获取所有分页数据 |

```bash
zilliz volume list --project-id <PROJECT_ID>
```

---

### volume delete

删除存储卷。

```
zilliz volume delete [OPTIONS]
```

| 参数     | 是否必填 | 类型   | 说明               |
| -------- | -------- | ------ | ------------------ |
| `--name` | **是**   | string | 要删除的存储卷名称 |

```bash
zilliz volume delete --name my-volume
```

---

## 账单

### billing usage

查询用量费用，支持灵活的时间范围选项。

```
zilliz billing usage [OPTIONS]
```

| 参数       | 是否必填 | 类型   | 说明                                    |
| ---------- | -------- | ------ | --------------------------------------- |
| `--last`   | 否       | string | 相对时间：`7d`、`30d`、`3m`、`1y`       |
| `--month`  | 否       | string | 月份：`2026-01`、`last`、`this`         |
| `--start`  | 否       | string | 起始日期：`YYYY-MM-DD` 或 ISO-8601 格式 |
| `--end`    | 否       | string | 结束日期：`YYYY-MM-DD` 或 ISO-8601 格式 |
| `--output` | 否       | string | 输出格式：`json`、`table`、`text`       |

不指定时间范围时默认显示当天用量。

```bash
# 当天用量
zilliz billing usage

# 最近 7 天
zilliz billing usage --last 7d

# 指定月份
zilliz billing usage --month 2026-01

# 上个月
zilliz billing usage --month last

# 日期范围
zilliz billing usage --start 2026-01-01 --end 2026-02-01
```

---

### billing invoices

列出或查看发票详情。

```
zilliz billing invoices [OPTIONS]
```

| 参数           | 是否必填 | 类型    | 说明                              |
| -------------- | -------- | ------- | --------------------------------- |
| `--invoice-id` | 否       | string  | 发票 ID（省略则列出所有发票）     |
| `--page-size`  | 否       | integer | 每页条数                          |
| `--page`       | 否       | integer | 页码                              |
| `--all`        | 否       | flag    | 获取所有分页数据                  |
| `--output`     | 否       | string  | 输出格式：`json`、`table`、`text` |

```bash
# 列出所有发票
zilliz billing invoices

# 查看指定发票
zilliz billing invoices --invoice-id <INVOICE_ID>
```

---

### billing bind-card

绑定信用卡到账户。

```
zilliz billing bind-card [OPTIONS]
```

| 参数            | 是否必填 | 类型    | 说明                  |
| --------------- | -------- | ------- | --------------------- |
| `--card-number` | **是**   | string  | 信用卡号              |
| `--exp-month`   | **是**   | integer | 过期月份（1-12）      |
| `--exp-year`    | **是**   | integer | 过期年份（例如 2026） |
| `--cvc`         | **是**   | string  | 卡验证码              |

```bash
zilliz billing bind-card --card-number <CARD_NUMBER> --exp-month 12 --exp-year 2026 --cvc <CVC>
```

---

## 任务管理

### job describe

查询异步任务（备份、恢复、迁移、导入等）的状态。可选轮询等待任务完成。

```
zilliz job describe [OPTIONS]
```

| 参数         | 是否必填 | 类型    | 说明                                 |
| ------------ | -------- | ------- | ------------------------------------ |
| `--job-id`   | **是**   | string  | 任务 ID（例如 job-xxxxxxxxxxxxxxxxxxxx） |
| `--wait`     | 否       | flag    | 轮询等待任务到达终态                 |
| `--timeout`  | 否       | integer | 最大等待秒数（默认：1800）           |
| `--interval` | 否       | integer | 轮询间隔秒数（默认：5）             |

```bash
# 查看任务状态
zilliz job describe --job-id job-03e1eefbd82dmo2oeb8pe2

# 等待任务完成
zilliz job describe --job-id job-03e1eefbd82dmo2oeb8pe2 --wait

# 自定义超时时间
zilliz job describe --job-id job-03e1eefbd82dmo2oeb8pe2 --wait --timeout 600
```

---

## 告警管理

管理集群指标和账单的告警规则。

### alert list

列出项目的告警规则。

```
zilliz alert list [OPTIONS]
```

| 参数           | 是否必填 | 类型    | 说明                    |
| -------------- | -------- | ------- | ----------------------- |
| `--project-id` | **是**   | string  | 项目 ID                 |
| `--page-size`  | 否       | integer | 每页条数（默认：10）    |
| `--page`       | 否       | integer | 页码（默认：1）         |

```bash
zilliz alert list --project-id proj-xxxx
zilliz alert list --project-id proj-xxxx --page-size 20 --page 2 -o json
```

---

### alert create

创建新的告警规则。

```
zilliz alert create [OPTIONS]
```

| 参数                 | 是否必填 | 类型    | 说明                                                       |
| -------------------- | -------- | ------- | ---------------------------------------------------------- |
| `--project-id`       | **是**   | string  | 项目 ID                                                    |
| `--metric-name`      | **是**   | string  | 监控指标（例如 CU_COMPUTATION、WALLET_BALANCE）             |
| `--threshold`        | **是**   | string  | 阈值                                                       |
| `--comparison`       | **是**   | string  | 比较运算符：`>`、`<`、`>=`、`<=`、`=`                      |
| `--rule-name`        | 否       | string  | 告警规则显示名称                                           |
| `--level`            | 否       | string  | 严重级别：`WARNING`（默认）、`CRITICAL`                    |
| `--window-size`      | 否       | string  | 监控窗口（例如 5m、15m、1h）                                |
| `--cluster-id`       | 否       | string  | 目标集群 ID（可重复指定）                                  |
| `--action`           | 否       | string  | 通知动作，格式为 `type:config`（可重复指定）               |
| `--send-resolved`    | 否       | flag    | 告警恢复时发送通知                                         |
| `--repeat-interval`  | 否       | integer | 重复通知间隔秒数                                           |
| `--enabled`          | 否       | flag    | 启用规则（默认启用）                                       |

支持的通知类型：`email`、`slack`、`webhook`、`pagerduty`、`opsgenie`、`wecom`、`dingtalk`、`lark`。

```bash
# 基本告警
zilliz alert create --project-id proj-xxx --metric-name CU_COMPUTATION --threshold 80 --comparison ">"

# 带通知的告警
zilliz alert create --project-id proj-xxx --metric-name WALLET_BALANCE --threshold 100 \
    --comparison "<" --level CRITICAL --action email:admin@example.com

# 针对特定集群的 Slack 通知告警
zilliz alert create --project-id proj-xxx --metric-name CU_COMPUTATION --threshold 90 \
    --comparison ">=" --cluster-id in01-xxx --action slack:https://hooks.slack.com/xxx
```

---

### alert update

更新已有的告警规则。

```
zilliz alert update [OPTIONS]
```

| 参数                 | 是否必填 | 类型    | 说明                                    |
| -------------------- | -------- | ------- | --------------------------------------- |
| `--id`               | **是**   | string  | 告警规则 ID                             |
| `--project-id`       | 否       | string  | 项目 ID（用于交互式选择 ID）            |
| `--rule-name`        | 否       | string  | 新的显示名称                            |
| `--metric-name`      | 否       | string  | 新的监控指标                            |
| `--threshold`        | 否       | string  | 新的阈值                                |
| `--comparison`       | 否       | string  | 新的比较运算符                          |
| `--level`            | 否       | string  | 新的严重级别                            |
| `--action`           | 否       | string  | 新的通知动作（可重复指定，替换现有配置）|
| `--enabled`          | 否       | flag    | 启用或禁用规则                          |

```bash
zilliz alert update --id alert-xxx --threshold 90
zilliz alert update --id alert-xxx --level CRITICAL --action email:new@example.com
```

---

### alert delete

删除告警规则。

```
zilliz alert delete [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                           |
| -------------- | -------- | ------ | ------------------------------ |
| `--id`         | **是**   | string | 告警规则 ID                    |
| `--project-id` | 否       | string | 项目 ID（用于交互式选择 ID）   |
| `-y`、`--yes`  | 否       | flag   | 跳过确认提示                   |

```bash
zilliz alert delete --id alert-xxx
zilliz alert delete --id alert-xxx -y
```

---

### alert enable

启用告警规则。

```
zilliz alert enable [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                           |
| -------------- | -------- | ------ | ------------------------------ |
| `--id`         | **是**   | string | 告警规则 ID                    |
| `--project-id` | 否       | string | 项目 ID（用于交互式选择 ID）   |

```bash
zilliz alert enable --id alert-xxx
```

---

### alert disable

禁用告警规则。

```
zilliz alert disable [OPTIONS]
```

| 参数           | 是否必填 | 类型   | 说明                           |
| -------------- | -------- | ------ | ------------------------------ |
| `--id`         | **是**   | string | 告警规则 ID                    |
| `--project-id` | 否       | string | 项目 ID（用于交互式选择 ID）   |

```bash
zilliz alert disable --id alert-xxx
```

---

## 集群指标

### cluster metrics

查询集群性能指标（QPS、延迟、存储等），支持交互式指标选择。

```
zilliz cluster metrics [OPTIONS]
```

| 参数            | 是否必填 | 类型   | 说明                                                        |
| --------------- | -------- | ------ | ----------------------------------------------------------- |
| `--cluster-id`  | **是**   | string | 集群 ID                                                     |
| `--metric`、`-m`| **是**   | string | 指标名称（可重复指定），参见下方可用指标                    |
| `--period`      | 否       | string | 相对时间段（例如 1h、24h、7d），默认：1h                    |
| `--start`       | 否       | string | 开始时间（ISO 8601：YYYY-MM-DD 或 YYYY-MM-DDTHH:MM:SSZ）   |
| `--end`         | 否       | string | 结束时间（ISO 8601）                                        |
| `--granularity`、`-g` | 否 | string | 数据点间隔（例如 30s、5m、1h），默认：自动                  |

**可用指标：**

| 分类     | 指标                                                                                       |
| -------- | ------------------------------------------------------------------------------------------ |
| 资源     | CU_COMPUTATION、CU_CAPACITY、CU_SIZE、REPLICA_COUNT、STORAGE                               |
| QPS      | SEARCH_QPS、QUERY_QPS、INSERT_QPS、UPSERT_QPS、DELETE_QPS、BULK_INSERT_QPS                  |
| 延迟     | SEARCH_LATENCY_AVG、SEARCH_LATENCY_P99、QUERY_LATENCY_AVG、QUERY_LATENCY_P99 等            |
| VPS      | SEARCH_VPS、INSERT_VPS、UPSERT_VPS、DELETE_VPS、BULK_INSERT_VPS                             |
| 失败率   | SEARCH_FAIL_RATE、QUERY_FAIL_RATE、INSERT_FAIL_RATE、UPSERT_FAIL_RATE 等                   |
| 数据     | ENTITIES、ENTITIES_LOADED、ENTITIES_INDEXED、COLLECTIONS、SLOW_QUERIES                      |
| Serverless | READ_VCU、WRITE_VCU                                                                       |

```bash
# 查询最近一小时的搜索 QPS
zilliz cluster metrics --cluster-id in01-xxx -m SEARCH_QPS

# 查询最近 24 小时的多个指标
zilliz cluster metrics --cluster-id in01-xxx -m SEARCH_QPS -m SEARCH_LATENCY_P99 --period 24h

# 自定义数据粒度
zilliz cluster metrics --cluster-id in01-xxx -m CU_COMPUTATION --period 7d -g 1h

# 使用绝对时间范围查询
zilliz cluster metrics --cluster-id in01-xxx -m STORAGE --start 2026-03-01 --end 2026-03-15
```

---

## Shell 自动补全

### completion install

为指定 shell 安装自动补全。

```
zilliz completion install [SHELL]
```

| 参数      | 是否必填 | 类型   | 说明                                                                  |
| --------- | -------- | ------ | --------------------------------------------------------------------- |
| `SHELL`   | 否       | string | Shell 类型：`bash`、`zsh`、`fish`。省略时从 `$SHELL` 环境变量自动检测 |
| `--apply` | 否       | flag   | 自动写入 shell RC 文件                                                |

```bash
# 为当前 shell 安装
zilliz completion install

# 为指定 shell 安装
zilliz completion install zsh

# 安装并自动应用到 RC 文件
zilliz completion install --apply
```

---

### completion uninstall

移除 shell 自动补全。

```
zilliz completion uninstall [SHELL]
```

```bash
zilliz completion uninstall zsh
```

---

### completion status

检查 shell 自动补全是否已安装。

```
zilliz completion status [SHELL]
```

```bash
zilliz completion status zsh
```

---

### completion show

显示自动补全脚本内容。

```
zilliz completion show [SHELL]
```

```bash
zilliz completion show zsh
```

---

## 版本信息

显示 CLI 版本。

```
zilliz version [OPTIONS]
```

| 参数       | 是否必填 | 类型   | 说明                              |
| ---------- | -------- | ------ | --------------------------------- |
| `--output` | 否       | string | 输出格式：`json`、`table`、`text` |

```bash
zilliz version
```

---

## 快速上手

```bash
# 1. 安装
pip install zilliz-cli

# 2. 配置 API Key（二选一）
zilliz configure                        # 交互式配置
export ZILLIZ_API_KEY=<YOUR_API_KEY>    # 环境变量

# 3. 查看集群列表
zilliz cluster list

# 4. 设置集群上下文（自动获取 endpoint）
zilliz context set --cluster-id <CLUSTER_ID>

# 5. 创建 collection
zilliz collection create --name my_collection --dimension 768

# 6. 插入数据
zilliz vector insert --collection my_collection --data '[{"vector": [0.1, 0.2, ...]}]'

# 7. 搜索
zilliz vector search --collection my_collection --data '[[0.1, 0.2, ...]]' --limit 5
```

---

## 使用技巧

### API Key 优先级顺序

1. `--api-key` 命令行参数（最高优先级）
2. `ZILLIZ_API_KEY` 环境变量
3. 配置文件（`~/.zilliz/credentials`）

### 文件输入

许多命令支持通过 `file://` 前缀从文件加载 JSON：

```bash
zilliz collection create --name my_col --body file://schema.json
zilliz vector insert --collection my_col --data file:///path/to/data.json
```

### 分页

返回列表的命令支持分页：

```bash
# 手动分页
zilliz cluster list --page 1 --page-size 20

# 自动获取所有分页
zilliz cluster list --all
```

### 输出格式

```bash
# 表格格式（默认）- 适合人类阅读
zilliz cluster list

# JSON 格式 - 适合程序处理
zilliz cluster list -o json

# 文本格式 - 纯文本键值对
zilliz cluster list -o text
```
