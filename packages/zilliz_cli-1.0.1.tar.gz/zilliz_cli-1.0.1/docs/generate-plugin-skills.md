# Generate Plugin Skills

`scripts/generate_plugin_skills.py` reads the JSON model files (`control-plane.json`, `data-plane.json`) and hand-written overlay files, then generates the `SKILL.md` files for the [zilliz-plugin](https://github.com/zilliztech/zilliz-plugin) project.

## Prerequisites

- Python 3.10+
- PyYAML: `pip install pyyaml`

## Quick Start

```bash
cd vdc/zilliz-cli

# Preview generated skills to stdout (dry run)
python scripts/generate_plugin_skills.py

# Write to the zilliz-plugin skills directory
python scripts/generate_plugin_skills.py --output ../../../zilliz-plugin/skills

# Generate a single skill only
python scripts/generate_plugin_skills.py --output ../../../zilliz-plugin/skills --skill cluster

# CI drift detection (exits 1 if any skill file is out of date)
python scripts/generate_plugin_skills.py --check ../../../zilliz-plugin/skills
```

## How It Works

### Data Flow

```
builtin_models/control-plane.json  ──┐
                                     ├──  generate_plugin_skills.py  ──>  skills/*/SKILL.md
builtin_models/data-plane.json     ──┤
                                     │
scripts/skill_config.yaml          ──┤  (resource-to-skill mapping)
scripts/skill_overlays/*/          ──┘  (hand-written guidance & extra content)
```

### Three Input Sources

| Source | What it provides | When to edit |
|---|---|---|
| `builtin_models/*.json` | API operations, params, examples | Adding/changing CLI commands |
| `scripts/skill_config.yaml` | Skill metadata (description, prerequisites, resource mapping) | Adding a new skill or changing how resources map to skills |
| `scripts/skill_overlays/` | Hand-written Guidance sections, extra commands, extra sections | Updating domain-specific guidance |

### Generated SKILL.md Structure

Each generated skill file follows this structure:

```
---
name: <skill-name>
description: <from skill_config.yaml>
---

## Prerequisites          <-- from skill_config.yaml
## Commands Reference     <-- auto-generated from JSON models + extra_commands.md overlay
## <Extra Sections>       <-- from guidance.md overlay (e.g., Filter Expression Syntax)
## Guidance               <-- from guidance.md overlay
```

## File Layout

```
scripts/
  generate_plugin_skills.py       # Generator script
  skill_config.yaml               # Resource-to-skill mapping & metadata
  skill_overlays/
    cluster/guidance.md            # Hand-written guidance
    collection/guidance.md
    vector/guidance.md             # Includes Filter Expression Syntax table
    database/guidance.md
    index/guidance.md
    partition/guidance.md
    user-role/guidance.md
    backup/guidance.md
    import/guidance.md             # Includes Integration Setup section
    billing/
      guidance.md
      extra_commands.md            # Hand-written: usage, invoices commands
    project-region/guidance.md
    setup/SKILL.md                 # Fully hand-written, copied as-is
    monitoring/SKILL.md            # Fully hand-written, copied as-is
```

## Common Tasks

### Add a new API operation to an existing resource

1. Add the operation to the appropriate JSON model file (`control-plane.json` or `data-plane.json`).
2. Regenerate:
   ```bash
   python scripts/generate_plugin_skills.py --output /path/to/zilliz-plugin/skills
   ```
3. No overlay changes needed -- the new operation appears automatically.

### Add a new resource that maps to an existing skill

1. Add the resource to the JSON model file.
2. Edit `scripts/skill_config.yaml` -- add a new entry under the skill's `resources` list:
   ```yaml
   resources:
     - plane: data
       resource: new-resource
       section_title: New Resource  # optional, creates a sub-section
   ```
3. Regenerate.

### Add a new skill

1. Add a new skill entry in `scripts/skill_config.yaml` with description, prerequisites, and resource mapping.
2. Create `scripts/skill_overlays/<skill-name>/guidance.md` with the Guidance section.
3. Regenerate.
4. The new `skills/<skill-name>/SKILL.md` will be created in the output directory.

### Add hand-written commands not in JSON models

Create `scripts/skill_overlays/<skill-name>/extra_commands.md` with the markdown content. These commands are inserted into the Commands Reference section **before** the auto-generated ones. See `billing/extra_commands.md` for an example.

### Add a fully hand-written skill (no JSON model)

1. Add the skill to `skill_config.yaml` with `hand_written: true`.
2. Create `scripts/skill_overlays/<skill-name>/SKILL.md` with the full content.
3. The file will be copied as-is during generation.

### Update guidance for an existing skill

Edit the corresponding `scripts/skill_overlays/<skill-name>/guidance.md` file and regenerate.

## CI Integration

Use `--check` mode in CI to detect when JSON model changes haven't been propagated to the plugin:

```bash
python scripts/generate_plugin_skills.py --check /path/to/zilliz-plugin/skills
```

Output:
```
OK:      skills/cluster/SKILL.md
OK:      skills/collection/SKILL.md
DRIFT:   skills/vector/SKILL.md       # <-- needs regeneration
```

Exit code 1 if any drift is detected, 0 if all match.

## Resource-to-Skill Mapping

Some skills combine multiple JSON resources:

| Skill | JSON Resources |
|---|---|
| `cluster` | control-plane: `cluster` |
| `collection` | data-plane: `collection` + `alias` |
| `vector` | data-plane: `vector` |
| `database` | data-plane: `database` |
| `index` | data-plane: `index` |
| `partition` | data-plane: `partition` |
| `user-role` | data-plane: `user` + `role` |
| `backup` | control-plane: `backup` |
| `import` | control-plane: `import` |
| `billing` | control-plane: `billing` + hand-written `extra_commands.md` |
| `project-region` | control-plane: `project` + `volume` |
| `setup` | Fully hand-written |
| `monitoring` | Fully hand-written |
