# Zilliz CLI Command Reference

> **[中文版](command-reference-zh.md)**

Zilliz CLI (`zilliz`) is a command-line tool for managing Zilliz Cloud clusters and performing Milvus vector database operations.

## Table of Contents

- [Zilliz CLI Command Reference](#zilliz-cli-command-reference)
  - [Table of Contents](#table-of-contents)
  - [Global Options](#global-options)
  - [Endpoint Architecture](#endpoint-architecture)
  - [Authentication \& Configuration](#authentication--configuration)
    - [login](#login)
    - [logout](#logout)
    - [auth](#auth)
      - [auth status](#auth-status)
      - [auth switch](#auth-switch)
    - [configure](#configure)
      - [configure (interactive)](#configure-interactive)
      - [configure set](#configure-set)
      - [configure get](#configure-get)
      - [configure list](#configure-list)
      - [configure clear](#configure-clear)
    - [context](#context)
      - [context set](#context-set)
      - [context current](#context-current)
  - [Cluster Management](#cluster-management)
    - [cluster create](#cluster-create)
    - [cluster list](#cluster-list)
    - [cluster describe](#cluster-describe)
    - [cluster modify](#cluster-modify)
    - [cluster suspend](#cluster-suspend)
    - [cluster resume](#cluster-resume)
    - [cluster delete](#cluster-delete)
    - [cluster providers](#cluster-providers)
    - [cluster regions](#cluster-regions)
  - [Project Management](#project-management)
    - [project create](#project-create)
    - [project list](#project-list)
    - [project describe](#project-describe)
    - [project upgrade](#project-upgrade)
  - [Collection Management](#collection-management)
    - [collection create](#collection-create)
    - [collection list](#collection-list)
    - [collection describe](#collection-describe)
    - [collection drop](#collection-drop)
    - [collection rename](#collection-rename)
    - [collection load](#collection-load)
    - [collection release](#collection-release)
    - [collection get-load-state](#collection-get-load-state)
    - [collection get-stats](#collection-get-stats)
    - [collection has](#collection-has)
    - [collection flush](#collection-flush)
    - [collection compact](#collection-compact)
  - [Vector Operations](#vector-operations)
    - [vector insert](#vector-insert)
    - [vector upsert](#vector-upsert)
    - [vector search](#vector-search)
    - [vector hybrid-search](#vector-hybrid-search)
    - [vector query](#vector-query)
    - [vector get](#vector-get)
    - [vector delete](#vector-delete)
  - [Database Management](#database-management)
    - [database create](#database-create)
    - [database list](#database-list)
    - [database describe](#database-describe)
    - [database drop](#database-drop)
  - [Index Management](#index-management)
    - [index create](#index-create)
    - [index list](#index-list)
    - [index describe](#index-describe)
    - [index drop](#index-drop)
  - [Partition Management](#partition-management)
    - [partition create](#partition-create)
    - [partition list](#partition-list)
    - [partition drop](#partition-drop)
    - [partition has](#partition-has)
    - [partition get-stats](#partition-get-stats)
    - [partition load](#partition-load)
    - [partition release](#partition-release)
  - [User Management](#user-management)
    - [user create](#user-create)
    - [user list](#user-list)
    - [user describe](#user-describe)
    - [user drop](#user-drop)
    - [user update-password](#user-update-password)
    - [user grant-role](#user-grant-role)
    - [user revoke-role](#user-revoke-role)
  - [Role Management](#role-management)
    - [role create](#role-create)
    - [role list](#role-list)
    - [role describe](#role-describe)
    - [role drop](#role-drop)
    - [role grant-privilege](#role-grant-privilege)
    - [role revoke-privilege](#role-revoke-privilege)
  - [Alias Management](#alias-management)
    - [alias create](#alias-create)
    - [alias list](#alias-list)
    - [alias describe](#alias-describe)
    - [alias alter](#alias-alter)
    - [alias drop](#alias-drop)
  - [Backup Management](#backup-management)
    - [backup create](#backup-create)
    - [backup list](#backup-list)
    - [backup describe](#backup-describe)
    - [backup delete](#backup-delete)
    - [backup export](#backup-export)
    - [backup restore-cluster](#backup-restore-cluster)
    - [backup restore-collection](#backup-restore-collection)
    - [backup describe-policy](#backup-describe-policy)
    - [backup update-policy](#backup-update-policy)
  - [Import Management](#import-management)
    - [import start](#import-start)
    - [import list](#import-list)
    - [import status](#import-status)
  - [Volume Management](#volume-management)
    - [volume create](#volume-create)
    - [volume list](#volume-list)
    - [volume delete](#volume-delete)
  - [Billing](#billing)
    - [billing usage](#billing-usage)
    - [billing invoices](#billing-invoices)
    - [billing bind-card](#billing-bind-card)
  - [Job Management](#job-management)
    - [job describe](#job-describe)
  - [Alert Management](#alert-management)
    - [alert list](#alert-list)
    - [alert create](#alert-create)
    - [alert update](#alert-update)
    - [alert delete](#alert-delete)
    - [alert enable](#alert-enable)
    - [alert disable](#alert-disable)
  - [Cluster Metrics](#cluster-metrics)
    - [cluster metrics](#cluster-metrics-1)
  - [Shell Completion](#shell-completion)
    - [completion install](#completion-install)
    - [completion uninstall](#completion-uninstall)
    - [completion status](#completion-status)
    - [completion show](#completion-show)
  - [Version](#version)
  - [Quick Start Guide](#quick-start-guide)
  - [Tips](#tips)
    - [API Key Resolution Order](#api-key-resolution-order)
    - [File Input](#file-input)
    - [Pagination](#pagination)
    - [Output Formats](#output-formats)

---

## Global Options

All commands support the following global options:

| Option      | Short | Description                                              |
| ----------- | ----- | -------------------------------------------------------- |
| `--output`  | `-o`  | Output format: `json`, `table`, `text`, `yaml`, `csv`    |
| `--api-key` |       | API Key (overrides config file and environment variable) |
| `--help`    |       | Show help message                                        |
| `--version` |       | Show CLI version                                         |

```bash
# Example
zilliz cluster list --output json
zilliz cluster list --api-key <YOUR_API_KEY>
```

---

## Endpoint Architecture

CLI connects to two types of API endpoints:

| Type              | Endpoint                       | Purpose                                                                             |
| ----------------- | ------------------------------ | ----------------------------------------------------------------------------------- |
| **Control Plane** | `https://api.cloud.zilliz.com` | Project, cluster, backup, import, volume, billing management                        |
| **Data Plane**    | Cluster-specific endpoint      | Data operations (collection, vector, database, index, partition, user, role, alias) |

Data Plane commands require setting a cluster context first via `zilliz context set`.

---

## Authentication & Configuration

### login

Authenticate with Zilliz Cloud. Supports browser-based OAuth and API key authentication.

```
zilliz login [OPTIONS]
```

| Parameter      | Required | Type | Description                                   |
| -------------- | -------- | ---- | --------------------------------------------- |
| `--no-browser` | No       | flag | Do not automatically open browser for OAuth   |
| `--api-key`    | No       | flag | Use API key authentication instead of browser |

```bash
# Browser-based login (default)
zilliz login

# API key login
zilliz login --api-key

# Login without opening browser automatically
zilliz login --no-browser
```

---

### logout

Clear all stored credentials and login data.

```
zilliz logout
```

No parameters.

```bash
zilliz logout
```

---

### auth

Manage authentication state and organization switching.

#### auth status

Show current authentication status (user, organization, API key).

```
zilliz auth status
```

```bash
zilliz auth status
```

#### auth switch

Switch to a different organization.

```
zilliz auth switch [ORG_ID]
```

| Parameter | Required | Type   | Description                                              |
| --------- | -------- | ------ | -------------------------------------------------------- |
| `ORG_ID`  | No       | string | Organization ID. If omitted, shows interactive selection |

```bash
# Interactive organization selection
zilliz auth switch

# Switch to a specific organization
zilliz auth switch <ORG_ID>
```

---

### configure

Manage CLI configuration (API key, etc.).

#### configure (interactive)

Interactively configure credentials.

```bash
zilliz configure
```

#### configure set

Set a configuration value.

```
zilliz configure set KEY [VALUE]
```

| Parameter | Required | Type   | Description                                         |
| --------- | -------- | ------ | --------------------------------------------------- |
| `KEY`     | Yes      | string | Configuration key (e.g., `api_key`)                 |
| `VALUE`   | No       | string | Value. For credentials, prompts securely if omitted |

```bash
# Set API key (secure prompt)
zilliz configure set api_key

# Set API key directly
zilliz configure set api_key <YOUR_API_KEY>
```

#### configure get

Get a configuration value.

```
zilliz configure get KEY
```

```bash
zilliz configure get api_key
```

#### configure list

List all configuration values.

```bash
zilliz configure list
```

#### configure clear

Clear all stored credentials.

```bash
zilliz configure clear
```

---

### context

Manage cluster context for Data Plane operations.

#### context set

Set the current cluster context. Data Plane commands (collection, vector, etc.) use this endpoint.

```
zilliz context set [OPTIONS]
```

| Parameter      | Required | Type   | Description                                                 |
| -------------- | -------- | ------ | ----------------------------------------------------------- |
| `--cluster-id` | No       | string | Cluster ID. Interactive selection if omitted                |
| `--endpoint`   | No       | string | Cluster endpoint URL. Auto-resolved from cluster if omitted |
| `--database`   | No       | string | Default database name                                       |

```bash
# Interactive cluster selection
zilliz context set

# Set context by cluster ID (endpoint auto-resolved)
zilliz context set --cluster-id <CLUSTER_ID>

# Set context with specific database
zilliz context set --cluster-id <CLUSTER_ID> --database my_database
```

#### context current

Show the current cluster context.

```
zilliz context current [OPTIONS]
```

| Parameter  | Required | Type   | Description                            |
| ---------- | -------- | ------ | -------------------------------------- |
| `--output` | No       | string | Output format: `json`, `table`, `text` |

```bash
zilliz context current
zilliz context current -o json
```

---

## Cluster Management

### cluster create

Create a new cloud cluster. Supports interactive prompts for missing required parameters.

```
zilliz cluster create [OPTIONS]
```

| Parameter      | Required | Type    | Description                                                                        |
| -------------- | -------- | ------- | ---------------------------------------------------------------------------------- |
| `--name`       | Yes      | string  | Cluster display name                                                               |
| `--type`       | Yes      | string  | Cluster type: `serverless`, `free`, `dedicated`                                    |
| `--project-id` | Yes      | string  | Project ID to create in                                                            |
| `--region`     | Yes      | string  | Cloud region (e.g., `aws-us-west-2`)                                               |
| `--cu-type`    | No       | string  | CU type: `Performance-optimized`, `Capacity-optimized` (dedicated only)            |
| `--cu-size`    | No       | integer | Number of compute units (dedicated only)                                           |
| `--plan`       | No       | string  | Subscription plan: `Free`, `Serverless`, `Standard`, `Enterprise` (dedicated only) |
| `--output`     | No       | string  | Output format: `json`, `table`, `text`                                             |

```bash
# Create a serverless cluster
zilliz cluster create --name my-cluster --type serverless --project-id <PROJECT_ID> --region aws-us-west-2

# Create a dedicated cluster
zilliz cluster create --name my-cluster --type dedicated --project-id <PROJECT_ID> --region aws-us-west-2 --cu-size 2 --plan Standard

# Interactive mode (prompts for missing parameters)
zilliz cluster create
```

---

### cluster list

List all clusters.

```
zilliz cluster list [OPTIONS]
```

| Parameter     | Required | Type    | Description                            |
| ------------- | -------- | ------- | -------------------------------------- |
| `--page-size` | No       | integer | Items per page (default: 100)          |
| `--page`      | No       | integer | Page number                            |
| `--all`       | No       | flag    | Fetch all pages                        |
| `--output`    | No       | string  | Output format: `json`, `table`, `text` |

```bash
# List all clusters
zilliz cluster list

# Fetch all pages
zilliz cluster list --all

# JSON output
zilliz cluster list -o json
```

---

### cluster describe

Get details of a cluster.

```
zilliz cluster describe [OPTIONS]
```

| Parameter      | Required | Type   | Description                            |
| -------------- | -------- | ------ | -------------------------------------- |
| `--cluster-id` | **Yes**  | string | Cluster ID (e.g., `in01-xxxxxxxxxxxx`) |
| `--output`     | No       | string | Output format: `json`, `table`, `text` |

```bash
zilliz cluster describe --cluster-id <CLUSTER_ID>
```

---

### cluster modify

Modify cluster configuration (scale CU or replicas).

```
zilliz cluster modify [OPTIONS]
```

| Parameter      | Required | Type    | Description                                |
| -------------- | -------- | ------- | ------------------------------------------ |
| `--cluster-id` | **Yes**  | string  | Cluster ID to modify                       |
| `--cu-size`    | No       | integer | Number of compute units                    |
| `--replica`    | No       | integer | Number of replicas                         |
| `--body`       | No       | string  | Request body as JSON or `file://path.json` |
| `--output`     | No       | string  | Output format: `json`, `table`, `text`     |

```bash
# Scale to 2 CUs
zilliz cluster modify --cluster-id <CLUSTER_ID> --cu-size 2

# Set replicas
zilliz cluster modify --cluster-id <CLUSTER_ID> --replica 2
```

---

### cluster suspend

Suspend a running cluster. Suspending stops compute charges.

```
zilliz cluster suspend [OPTIONS]
```

| Parameter      | Required | Type   | Description           |
| -------------- | -------- | ------ | --------------------- |
| `--cluster-id` | **Yes**  | string | Cluster ID to suspend |

```bash
zilliz cluster suspend --cluster-id <CLUSTER_ID>
```

---

### cluster resume

Resume a suspended cluster.

```
zilliz cluster resume [OPTIONS]
```

| Parameter      | Required | Type   | Description          |
| -------------- | -------- | ------ | -------------------- |
| `--cluster-id` | **Yes**  | string | Cluster ID to resume |

```bash
zilliz cluster resume --cluster-id <CLUSTER_ID>
```

---

### cluster delete

Delete a cluster. This action is irreversible.

```
zilliz cluster delete [OPTIONS]
```

| Parameter      | Required | Type   | Description              |
| -------------- | -------- | ------ | ------------------------ |
| `--cluster-id` | **Yes**  | string | Cluster ID to delete     |
| `-y`           | No       | flag   | Skip confirmation prompt |

```bash
zilliz cluster delete --cluster-id <CLUSTER_ID>

# Skip confirmation prompt
zilliz cluster delete --cluster-id <CLUSTER_ID> -y
```

---

### cluster providers

List all cloud providers (aws, gcp, azure).

```
zilliz cluster providers
```

No parameters.

```bash
zilliz cluster providers
```

---

### cluster regions

List available regions for a cloud provider.

```
zilliz cluster regions [OPTIONS]
```

| Parameter    | Required | Type   | Description                           |
| ------------ | -------- | ------ | ------------------------------------- |
| `--cloud-id` | No       | string | Cloud provider: `aws`, `gcp`, `azure` |

```bash
# List all regions
zilliz cluster regions

# List AWS regions only
zilliz cluster regions --cloud-id aws
```

---

## Project Management

### project create

Create a new project.

```
zilliz project create [OPTIONS]
```

| Parameter | Required | Type   | Description                                                       |
| --------- | -------- | ------ | ----------------------------------------------------------------- |
| `--name`  | **Yes**  | string | Project name                                                      |
| `--plan`  | **Yes**  | string | Subscription plan: `Free`, `Serverless`, `Standard`, `Enterprise` |

```bash
zilliz project create --name my-project --plan Standard
```

---

### project list

List all projects.

```
zilliz project list
```

No parameters.

```bash
zilliz project list
```

---

### project describe

Get details of a project.

```
zilliz project describe [OPTIONS]
```

| Parameter      | Required | Type   | Description |
| -------------- | -------- | ------ | ----------- |
| `--project-id` | **Yes**  | string | Project ID  |

```bash
zilliz project describe --project-id <PROJECT_ID>
```

---

### project upgrade

Upgrade project plan.

```
zilliz project upgrade [OPTIONS]
```

| Parameter      | Required | Type   | Description                                         |
| -------------- | -------- | ------ | --------------------------------------------------- |
| `--project-id` | **Yes**  | string | Project ID                                          |
| `--plan`       | No       | string | Target plan: `Serverless`, `Standard`, `Enterprise` |

```bash
zilliz project upgrade --project-id <PROJECT_ID> --plan Enterprise
```

---

## Collection Management

> Data Plane commands - requires cluster context (`zilliz context set`).

### collection create

Create a new collection.

```
zilliz collection create [OPTIONS]
```

| Parameter         | Required              | Type    | Description                                     |
| ----------------- | --------------------- | ------- | ----------------------------------------------- |
| `--name`          | **Yes**               | string  | Collection name                                 |
| `--dimension`     | Yes (unless `--body`) | integer | Vector dimension                                |
| `--metric-type`   | No                    | string  | Distance metric: `COSINE` (default), `L2`, `IP` |
| `--id-type`       | No                    | string  | Primary key type: `Int64`, `VarChar`            |
| `--auto-id`       | No                    | boolean | Auto-generate primary key                       |
| `--primary-field` | No                    | string  | Primary key field name                          |
| `--vector-field`  | No                    | string  | Vector field name                               |
| `--database`      | No                    | string  | Database name                                   |
| `--body`          | No                    | string  | Full schema as JSON or `file://path.json`       |

```bash
# Quick create with defaults (COSINE metric, auto schema)
zilliz collection create --name my_collection --dimension 768

# Create with L2 metric and VarChar primary key
zilliz collection create --name my_collection --dimension 768 --metric-type L2 --id-type VarChar

# Create with full schema via JSON body
zilliz collection create --name my_collection --body file://schema.json
```

---

### collection list

List all collections.

```
zilliz collection list [OPTIONS]
```

| Parameter    | Required | Type   | Description   |
| ------------ | -------- | ------ | ------------- |
| `--database` | No       | string | Database name |

```bash
zilliz collection list
zilliz collection list --database my_database
```

---

### collection describe

Get details of a collection.

```
zilliz collection describe [OPTIONS]
```

| Parameter    | Required | Type   | Description     |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **Yes**  | string | Collection name |
| `--database` | No       | string | Database name   |

```bash
zilliz collection describe --name my_collection
```

---

### collection drop

Drop a collection. This action is irreversible.

```
zilliz collection drop [OPTIONS]
```

| Parameter    | Required | Type   | Description             |
| ------------ | -------- | ------ | ----------------------- |
| `--name`     | **Yes**  | string | Collection name to drop |
| `--database` | No       | string | Database name           |

```bash
zilliz collection drop --name my_collection
```

---

### collection rename

Rename a collection.

```
zilliz collection rename [OPTIONS]
```

| Parameter        | Required | Type   | Description                                |
| ---------------- | -------- | ------ | ------------------------------------------ |
| `--name`         | **Yes**  | string | Current collection name                    |
| `--new-name`     | **Yes**  | string | New collection name                        |
| `--database`     | No       | string | Current database name                      |
| `--new-database` | No       | string | Target database name (for cross-db rename) |

```bash
zilliz collection rename --name old_collection --new-name new_collection
```

---

### collection load

Load a collection into memory for search.

```
zilliz collection load [OPTIONS]
```

| Parameter    | Required | Type   | Description     |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **Yes**  | string | Collection name |
| `--database` | No       | string | Database name   |

```bash
zilliz collection load --name my_collection
```

---

### collection release

Release a collection from memory.

```
zilliz collection release [OPTIONS]
```

| Parameter    | Required | Type   | Description     |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **Yes**  | string | Collection name |
| `--database` | No       | string | Database name   |

```bash
zilliz collection release --name my_collection
```

---

### collection get-load-state

Get collection load state.

```
zilliz collection get-load-state [OPTIONS]
```

| Parameter    | Required | Type   | Description     |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **Yes**  | string | Collection name |
| `--database` | No       | string | Database name   |

```bash
zilliz collection get-load-state --name my_collection
```

---

### collection get-stats

Get collection statistics (row count, etc.).

```
zilliz collection get-stats [OPTIONS]
```

| Parameter    | Required | Type   | Description     |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **Yes**  | string | Collection name |
| `--database` | No       | string | Database name   |

```bash
zilliz collection get-stats --name my_collection
```

---

### collection has

Check if a collection exists.

```
zilliz collection has [OPTIONS]
```

| Parameter    | Required | Type   | Description     |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **Yes**  | string | Collection name |
| `--database` | No       | string | Database name   |

```bash
zilliz collection has --name my_collection
```

---

### collection flush

Flush collection data to disk.

```
zilliz collection flush [OPTIONS]
```

| Parameter    | Required | Type   | Description     |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **Yes**  | string | Collection name |
| `--database` | No       | string | Database name   |

```bash
zilliz collection flush --name my_collection
```

---

### collection compact

Compact collection segments to optimize storage.

```
zilliz collection compact [OPTIONS]
```

| Parameter    | Required | Type   | Description     |
| ------------ | -------- | ------ | --------------- |
| `--name`     | **Yes**  | string | Collection name |
| `--database` | No       | string | Database name   |

```bash
zilliz collection compact --name my_collection
```

---

## Vector Operations

> Data Plane commands - requires cluster context (`zilliz context set`).

### vector insert

Insert entities into a collection.

```
zilliz vector insert [OPTIONS]
```

| Parameter      | Required              | Type         | Description                                  |
| -------------- | --------------------- | ------------ | -------------------------------------------- |
| `--collection` | **Yes**               | string       | Collection name                              |
| `--data`       | Yes (unless `--body`) | array (JSON) | Entities as JSON array or `file://path.json` |
| `--database`   | No                    | string       | Database name                                |
| `--body`       | No                    | string       | Request body as JSON or `file://path.json`   |

```bash
# Insert with inline JSON
zilliz vector insert --collection my_col --data '[{"id": 1, "vector": [0.1, 0.2, 0.3]}]'

# Insert from a JSON file
zilliz vector insert --collection my_col --data file:///path/to/data.json
```

---

### vector upsert

Upsert entities (insert or update if exists).

```
zilliz vector upsert [OPTIONS]
```

| Parameter      | Required              | Type         | Description                                  |
| -------------- | --------------------- | ------------ | -------------------------------------------- |
| `--collection` | **Yes**               | string       | Collection name                              |
| `--data`       | Yes (unless `--body`) | array (JSON) | Entities as JSON array or `file://path.json` |
| `--partition`  | No                    | string       | Partition name                               |
| `--database`   | No                    | string       | Database name                                |
| `--body`       | No                    | string       | Request body as JSON or `file://path.json`   |

```bash
# Upsert with inline JSON
zilliz vector upsert --collection my_col --data '[{"id": 1, "vector": [0.1, 0.2, 0.3]}]'

# Upsert from a JSON file
zilliz vector upsert --collection my_col --data file:///path/to/data.json
```

---

### vector search

Search for similar vectors.

```
zilliz vector search [OPTIONS]
```

| Parameter         | Required | Type         | Description                         |
| ----------------- | -------- | ------------ | ----------------------------------- |
| `--collection`    | **Yes**  | string       | Collection name                     |
| `--data`          | **Yes**  | array (JSON) | Query vectors as JSON array         |
| `--anns-field`    | No       | string       | Vector field to search on           |
| `--limit`         | No       | integer      | Max results to return (default: 10) |
| `--filter`        | No       | string       | Scalar filter expression            |
| `--output-fields` | No       | array (JSON) | Fields to return as JSON array      |
| `--database`      | No       | string       | Database name                       |

```bash
# Basic vector search
zilliz vector search --collection my_col --data '[[0.1, 0.2, 0.3]]' --limit 10

# Search with scalar filter
zilliz vector search --collection my_col --data '[[0.1, 0.2]]' --filter 'age > 18' --output-fields '["name", "age"]'
```

---

### vector hybrid-search

Perform hybrid search with multiple vectors and reranking.

```
zilliz vector hybrid-search [OPTIONS]
```

| Parameter         | Required              | Type          | Description                                |
| ----------------- | --------------------- | ------------- | ------------------------------------------ |
| `--collection`    | **Yes**               | string        | Collection name                            |
| `--search`        | Yes (unless `--body`) | array (JSON)  | Search requests as JSON array              |
| `--rerank`        | Yes (unless `--body`) | object (JSON) | Reranking strategy as JSON                 |
| `--limit`         | No                    | integer       | Max results to return (default: 10)        |
| `--output-fields` | No                    | array (JSON)  | Fields to return as JSON array             |
| `--database`      | No                    | string        | Database name                              |
| `--body`          | No                    | string        | Request body as JSON or `file://path.json` |

```bash
# Hybrid search using JSON body file
zilliz vector hybrid-search --collection my_col --body file://hybrid-search.json
```

---

### vector query

Query entities by scalar filter expression.

```
zilliz vector query [OPTIONS]
```

| Parameter         | Required | Type         | Description                         |
| ----------------- | -------- | ------------ | ----------------------------------- |
| `--collection`    | **Yes**  | string       | Collection name                     |
| `--filter`        | **Yes**  | string       | Scalar filter expression            |
| `--limit`         | No       | integer      | Max results to return (default: 10) |
| `--output-fields` | No       | array (JSON) | Fields to return as JSON array      |
| `--database`      | No       | string       | Database name                       |

```bash
zilliz vector query --collection my_col --filter 'id > 100' --limit 10
```

---

### vector get

Get entities by primary key IDs.

```
zilliz vector get [OPTIONS]
```

| Parameter         | Required | Type         | Description                    |
| ----------------- | -------- | ------------ | ------------------------------ |
| `--collection`    | **Yes**  | string       | Collection name                |
| `--id`            | **Yes**  | array (JSON) | Primary key IDs as JSON array  |
| `--output-fields` | No       | array (JSON) | Fields to return as JSON array |
| `--database`      | No       | string       | Database name                  |

```bash
zilliz vector get --collection my_col --id '[1, 2, 3]'
```

---

### vector delete

Delete entities by filter expression.

```
zilliz vector delete [OPTIONS]
```

| Parameter      | Required | Type   | Description                              |
| -------------- | -------- | ------ | ---------------------------------------- |
| `--collection` | **Yes**  | string | Collection name                          |
| `--filter`     | **Yes**  | string | Filter expression for entities to delete |
| `--partition`  | No       | string | Partition name                           |
| `--database`   | No       | string | Database name                            |

```bash
zilliz vector delete --collection my_col --filter 'id in [1, 2, 3]'
```

---

## Database Management

> Data Plane commands - requires cluster context. Database create/describe/drop are Dedicated clusters only.

### database create

Create a new database. (Dedicated only)

```
zilliz database create [OPTIONS]
```

| Parameter | Required | Type   | Description                                |
| --------- | -------- | ------ | ------------------------------------------ |
| `--name`  | **Yes**  | string | Database name                              |
| `--body`  | No       | string | Request body as JSON or `file://path.json` |

```bash
zilliz database create --name my_database
```

---

### database list

List all databases.

```
zilliz database list
```

No parameters.

```bash
zilliz database list
```

---

### database describe

Get details of a database. (Dedicated only)

```
zilliz database describe [OPTIONS]
```

| Parameter | Required | Type   | Description   |
| --------- | -------- | ------ | ------------- |
| `--name`  | **Yes**  | string | Database name |

```bash
zilliz database describe --name my_database
```

---

### database drop

Drop a database. (Dedicated only)

```
zilliz database drop [OPTIONS]
```

| Parameter | Required | Type   | Description           |
| --------- | -------- | ------ | --------------------- |
| `--name`  | **Yes**  | string | Database name to drop |

```bash
zilliz database drop --name my_database
```

---

## Index Management

> Data Plane commands - requires cluster context (`zilliz context set`).

### index create

Create an index on a collection field.

```
zilliz index create [OPTIONS]
```

| Parameter      | Required | Type   | Description                                                 |
| -------------- | -------- | ------ | ----------------------------------------------------------- |
| `--collection` | **Yes**  | string | Collection name                                             |
| `--database`   | No       | string | Database name                                               |
| `--body`       | No       | string | Index spec with `indexParams` as JSON or `file://path.json` |

```bash
zilliz index create --collection my_col --body '{"indexParams": [{"fieldName": "vector", "indexType": "AUTOINDEX"}]}'
```

---

### index list

List indexes on a collection.

```
zilliz index list [OPTIONS]
```

| Parameter      | Required | Type   | Description     |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **Yes**  | string | Collection name |
| `--database`   | No       | string | Database name   |

```bash
zilliz index list --collection my_collection
```

---

### index describe

Get details of an index.

```
zilliz index describe [OPTIONS]
```

| Parameter      | Required | Type   | Description     |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **Yes**  | string | Collection name |
| `--index-name` | **Yes**  | string | Index name      |
| `--database`   | No       | string | Database name   |

```bash
zilliz index describe --collection my_collection --index-name my_index
```

---

### index drop

Drop an index.

```
zilliz index drop [OPTIONS]
```

| Parameter      | Required | Type   | Description        |
| -------------- | -------- | ------ | ------------------ |
| `--collection` | **Yes**  | string | Collection name    |
| `--index-name` | **Yes**  | string | Index name to drop |
| `--database`   | No       | string | Database name      |

```bash
zilliz index drop --collection my_collection --index-name my_index
```

---

## Partition Management

> Data Plane commands - requires cluster context (`zilliz context set`).

### partition create

Create a partition in a collection.

```
zilliz partition create [OPTIONS]
```

| Parameter      | Required | Type   | Description     |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **Yes**  | string | Collection name |
| `--partition`  | **Yes**  | string | Partition name  |
| `--database`   | No       | string | Database name   |

```bash
zilliz partition create --collection my_collection --partition my_partition
```

---

### partition list

List partitions in a collection.

```
zilliz partition list [OPTIONS]
```

| Parameter      | Required | Type   | Description     |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **Yes**  | string | Collection name |
| `--database`   | No       | string | Database name   |

```bash
zilliz partition list --collection my_collection
```

---

### partition drop

Drop a partition.

```
zilliz partition drop [OPTIONS]
```

| Parameter      | Required | Type   | Description            |
| -------------- | -------- | ------ | ---------------------- |
| `--collection` | **Yes**  | string | Collection name        |
| `--partition`  | **Yes**  | string | Partition name to drop |
| `--database`   | No       | string | Database name          |

```bash
zilliz partition drop --collection my_collection --partition my_partition
```

---

### partition has

Check if a partition exists.

```
zilliz partition has [OPTIONS]
```

| Parameter      | Required | Type   | Description     |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **Yes**  | string | Collection name |
| `--partition`  | **Yes**  | string | Partition name  |
| `--database`   | No       | string | Database name   |

```bash
zilliz partition has --collection my_collection --partition my_partition
```

---

### partition get-stats

Get partition statistics.

```
zilliz partition get-stats [OPTIONS]
```

| Parameter      | Required | Type   | Description     |
| -------------- | -------- | ------ | --------------- |
| `--collection` | **Yes**  | string | Collection name |
| `--partition`  | **Yes**  | string | Partition name  |
| `--database`   | No       | string | Database name   |

```bash
zilliz partition get-stats --collection my_collection --partition my_partition
```

---

### partition load

Load partitions into memory.

```
zilliz partition load [OPTIONS]
```

| Parameter      | Required | Type         | Description                   |
| -------------- | -------- | ------------ | ----------------------------- |
| `--collection` | **Yes**  | string       | Collection name               |
| `--names`      | **Yes**  | array (JSON) | Partition names as JSON array |
| `--database`   | No       | string       | Database name                 |

```bash
zilliz partition load --collection my_collection --names '["p1", "p2"]'
```

---

### partition release

Release partitions from memory.

```
zilliz partition release [OPTIONS]
```

| Parameter      | Required | Type         | Description                   |
| -------------- | -------- | ------------ | ----------------------------- |
| `--collection` | **Yes**  | string       | Collection name               |
| `--names`      | **Yes**  | array (JSON) | Partition names as JSON array |
| `--database`   | No       | string       | Database name                 |

```bash
zilliz partition release --collection my_collection --names '["p1", "p2"]'
```

---

## User Management

> Data Plane commands - Dedicated clusters only. Requires cluster context (`zilliz context set`).

### user create

Create a new database user.

```
zilliz user create [OPTIONS]
```

| Parameter    | Required | Type   | Description |
| ------------ | -------- | ------ | ----------- |
| `--user`     | **Yes**  | string | Username    |
| `--password` | **Yes**  | string | Password    |

```bash
zilliz user create --user <USERNAME> --password <PASSWORD>
```

---

### user list

List all database users.

```
zilliz user list
```

No parameters.

```bash
zilliz user list
```

---

### user describe

Get details of a user.

```
zilliz user describe [OPTIONS]
```

| Parameter | Required | Type   | Description |
| --------- | -------- | ------ | ----------- |
| `--user`  | **Yes**  | string | Username    |

```bash
zilliz user describe --user <USERNAME>
```

---

### user drop

Drop a database user.

```
zilliz user drop [OPTIONS]
```

| Parameter | Required | Type   | Description      |
| --------- | -------- | ------ | ---------------- |
| `--user`  | **Yes**  | string | Username to drop |

```bash
zilliz user drop --user <USERNAME>
```

---

### user update-password

Update user password.

```
zilliz user update-password [OPTIONS]
```

| Parameter        | Required | Type   | Description      |
| ---------------- | -------- | ------ | ---------------- |
| `--user`         | **Yes**  | string | Username         |
| `--password`     | **Yes**  | string | Current password |
| `--new-password` | **Yes**  | string | New password     |

```bash
zilliz user update-password --user <USERNAME> --password <OLD_PASSWORD> --new-password <NEW_PASSWORD>
```

---

### user grant-role

Grant a role to a user.

```
zilliz user grant-role [OPTIONS]
```

| Parameter | Required | Type   | Description        |
| --------- | -------- | ------ | ------------------ |
| `--user`  | **Yes**  | string | Username           |
| `--role`  | **Yes**  | string | Role name to grant |

```bash
zilliz user grant-role --user <USERNAME> --role admin
```

---

### user revoke-role

Revoke a role from a user.

```
zilliz user revoke-role [OPTIONS]
```

| Parameter | Required | Type   | Description         |
| --------- | -------- | ------ | ------------------- |
| `--user`  | **Yes**  | string | Username            |
| `--role`  | **Yes**  | string | Role name to revoke |

```bash
zilliz user revoke-role --user <USERNAME> --role admin
```

---

## Role Management

> Data Plane commands - Dedicated clusters only. Requires cluster context (`zilliz context set`).

### role create

Create a new role.

```
zilliz role create [OPTIONS]
```

| Parameter | Required | Type   | Description |
| --------- | -------- | ------ | ----------- |
| `--role`  | **Yes**  | string | Role name   |

```bash
zilliz role create --role my_role
```

---

### role list

List all roles.

```
zilliz role list
```

No parameters.

```bash
zilliz role list
```

---

### role describe

Get details and privileges of a role.

```
zilliz role describe [OPTIONS]
```

| Parameter | Required | Type   | Description |
| --------- | -------- | ------ | ----------- |
| `--role`  | **Yes**  | string | Role name   |

```bash
zilliz role describe --role my_role
```

---

### role drop

Drop a role.

```
zilliz role drop [OPTIONS]
```

| Parameter | Required | Type   | Description       |
| --------- | -------- | ------ | ----------------- |
| `--role`  | **Yes**  | string | Role name to drop |

```bash
zilliz role drop --role my_role
```

---

### role grant-privilege

Grant a privilege to a role.

```
zilliz role grant-privilege [OPTIONS]
```

| Parameter       | Required | Type   | Description                                                   |
| --------------- | -------- | ------ | ------------------------------------------------------------- |
| `--role`        | **Yes**  | string | Role name                                                     |
| `--object-type` | **Yes**  | string | Object type: `Global`, `Collection`, `Database`               |
| `--object-name` | **Yes**  | string | Object name (or `*` for all)                                  |
| `--privilege`   | **Yes**  | string | Privilege name (e.g., `Search`, `Insert`, `CreateCollection`) |
| `--database`    | No       | string | Database name                                                 |

```bash
# Grant search on a specific collection
zilliz role grant-privilege --role my_role --object-type Collection --object-name my_col --privilege Search

# Grant all privileges on all collections
zilliz role grant-privilege --role my_role --object-type Collection --object-name '*' --privilege '*'
```

---

### role revoke-privilege

Revoke a privilege from a role.

```
zilliz role revoke-privilege [OPTIONS]
```

| Parameter       | Required | Type   | Description                                     |
| --------------- | -------- | ------ | ----------------------------------------------- |
| `--role`        | **Yes**  | string | Role name                                       |
| `--object-type` | **Yes**  | string | Object type: `Global`, `Collection`, `Database` |
| `--object-name` | **Yes**  | string | Object name (or `*` for all)                    |
| `--privilege`   | **Yes**  | string | Privilege name                                  |
| `--database`    | No       | string | Database name                                   |

```bash
zilliz role revoke-privilege --role my_role --object-type Collection --object-name my_col --privilege Search
```

---

## Alias Management

> Data Plane commands - requires cluster context (`zilliz context set`).

### alias create

Create an alias pointing to a collection.

```
zilliz alias create [OPTIONS]
```

| Parameter      | Required | Type   | Description            |
| -------------- | -------- | ------ | ---------------------- |
| `--collection` | **Yes**  | string | Target collection name |
| `--alias`      | **Yes**  | string | Alias name             |
| `--database`   | No       | string | Database name          |

```bash
zilliz alias create --collection my_collection --alias my_alias
```

---

### alias list

List all aliases.

```
zilliz alias list [OPTIONS]
```

| Parameter      | Required | Type   | Description               |
| -------------- | -------- | ------ | ------------------------- |
| `--database`   | **Yes**  | string | Database name             |
| `--collection` | No       | string | Filter by collection name |

```bash
zilliz alias list --database default
```

---

### alias describe

Get details of an alias.

```
zilliz alias describe [OPTIONS]
```

| Parameter    | Required | Type   | Description   |
| ------------ | -------- | ------ | ------------- |
| `--alias`    | **Yes**  | string | Alias name    |
| `--database` | No       | string | Database name |

```bash
zilliz alias describe --alias my_alias
```

---

### alias alter

Reassign an alias to another collection.

```
zilliz alias alter [OPTIONS]
```

| Parameter      | Required | Type   | Description            |
| -------------- | -------- | ------ | ---------------------- |
| `--collection` | **Yes**  | string | New target collection  |
| `--alias`      | **Yes**  | string | Alias name to reassign |
| `--database`   | No       | string | Database name          |

```bash
zilliz alias alter --collection new_collection --alias my_alias
```

---

### alias drop

Drop an alias.

```
zilliz alias drop [OPTIONS]
```

| Parameter    | Required | Type   | Description        |
| ------------ | -------- | ------ | ------------------ |
| `--alias`    | **Yes**  | string | Alias name to drop |
| `--database` | No       | string | Database name      |

```bash
zilliz alias drop --alias my_alias
```

---

## Backup Management

### backup create

Create a backup for a cluster.

```
zilliz backup create [OPTIONS]
```

| Parameter      | Required | Type   | Description                                    |
| -------------- | -------- | ------ | ---------------------------------------------- |
| `--cluster-id` | **Yes**  | string | Cluster ID                                     |
| `--database`   | No       | string | Database name (for collection-level backup)    |
| `--collection` | No       | string | Collection name (omit for full cluster backup) |
| `--body`       | No       | string | Request body as JSON or `file://path.json`     |

```bash
# Full cluster backup (default)
zilliz backup create --cluster-id <CLUSTER_ID>

# Collection-level backup
zilliz backup create --cluster-id <CLUSTER_ID> --database default --collection my_col
```

---

### backup list

List all backups.

```
zilliz backup list [OPTIONS]
```

| Parameter           | Required | Type    | Description                                    |
| ------------------- | -------- | ------- | ---------------------------------------------- |
| `--project-id`      | No       | string  | Filter by project ID                           |
| `--cluster-id`      | No       | string  | Filter by cluster ID                           |
| `--creation-method` | No       | string  | Filter by creation method: `manual`, `auto`    |
| `--backup-type`     | No       | string  | Filter by backup type: `CLUSTER`, `COLLECTION` |
| `--page-size`       | No       | integer | Items per page                                 |
| `--page`            | No       | integer | Page number                                    |
| `--all`             | No       | flag    | Fetch all pages                                |

```bash
# List all backups
zilliz backup list

# List backups for a specific cluster
zilliz backup list --cluster-id <CLUSTER_ID>
```

---

### backup describe

Get details of a backup.

```
zilliz backup describe [OPTIONS]
```

| Parameter      | Required | Type   | Description |
| -------------- | -------- | ------ | ----------- |
| `--cluster-id` | **Yes**  | string | Cluster ID  |
| `--backup-id`  | **Yes**  | string | Backup ID   |

```bash
zilliz backup describe --cluster-id <CLUSTER_ID> --backup-id <BACKUP_ID>
```

---

### backup delete

Delete a backup.

```
zilliz backup delete [OPTIONS]
```

| Parameter      | Required | Type   | Description         |
| -------------- | -------- | ------ | ------------------- |
| `--cluster-id` | **Yes**  | string | Cluster ID          |
| `--backup-id`  | **Yes**  | string | Backup ID to delete |

```bash
zilliz backup delete --cluster-id <CLUSTER_ID> --backup-id <BACKUP_ID>
```

---

### backup export

Export a backup to external storage.

```
zilliz backup export [OPTIONS]
```

| Parameter          | Required | Type   | Description                          |
| ------------------ | -------- | ------ | ------------------------------------ |
| `--cluster-id`     | **Yes**  | string | Cluster ID                           |
| `--backup-id`      | **Yes**  | string | Backup ID                            |
| `--integration-id` | **Yes**  | string | Storage integration ID               |
| `--directory`      | No       | string | Target directory in external storage |

```bash
zilliz backup export --cluster-id <CLUSTER_ID> --backup-id <BACKUP_ID> --integration-id <INTEGRATION_ID>
```

---

### backup restore-cluster

Restore a backup to a new cluster.

```
zilliz backup restore-cluster [OPTIONS]
```

| Parameter             | Required | Type    | Description                                            |
| --------------------- | -------- | ------- | ------------------------------------------------------ |
| `--cluster-id`        | **Yes**  | string  | Source cluster ID                                      |
| `--backup-id`         | **Yes**  | string  | Backup ID to restore                                   |
| `--project-id`        | **Yes**  | string  | Target project ID                                      |
| `--name`              | **Yes**  | string  | New cluster name                                       |
| `--cu-size`           | **Yes**  | integer | Compute units for new cluster                          |
| `--collection-status` | **Yes**  | string  | Collection state after restore: `LOADED`, `NOT_LOADED` |

```bash
# Restore with collections loaded
zilliz backup restore-cluster \
  --cluster-id <CLUSTER_ID> \
  --backup-id <BACKUP_ID> \
  --project-id <PROJECT_ID> \
  --name restored-cluster \
  --cu-size 1 \
  --collection-status LOADED
```

---

### backup restore-collection

Restore specific collections from a backup.

```
zilliz backup restore-collection [OPTIONS]
```

| Parameter           | Required | Type   | Description                           |
| ------------------- | -------- | ------ | ------------------------------------- |
| `--cluster-id`      | **Yes**  | string | Source cluster ID                     |
| `--backup-id`       | **Yes**  | string | Backup ID                             |
| `--dest-cluster-id` | **Yes**  | string | Destination cluster ID                |
| `--body`            | No       | string | Request body for specific collections |

```bash
zilliz backup restore-collection --cluster-id <CLUSTER_ID> --backup-id <BACKUP_ID> --dest-cluster-id <DEST_CLUSTER_ID>
```

---

### backup describe-policy

Describe backup policy for a cluster.

```
zilliz backup describe-policy [OPTIONS]
```

| Parameter      | Required | Type   | Description |
| -------------- | -------- | ------ | ----------- |
| `--cluster-id` | **Yes**  | string | Cluster ID  |

```bash
zilliz backup describe-policy --cluster-id <CLUSTER_ID>
```

---

### backup update-policy

Update backup policy for a cluster.

```
zilliz backup update-policy [OPTIONS]
```

| Parameter          | Required                           | Type    | Description                                                                         |
| ------------------ | ---------------------------------- | ------- | ----------------------------------------------------------------------------------- |
| `--cluster-id`     | **Yes**                            | string  | Cluster ID                                                                          |
| `--auto-backup`    | **Yes**                            | boolean | Turn auto-backup on (`true`) or off (`false`)                                       |
| `--frequency`      | Required when `--auto-backup true` | string  | `daily`, `weekdays`, `weekends`, or day numbers `1-7` (1=Mon, 7=Sun), e.g., `1,3,5` |
| `--start-time`     | Required when `--auto-backup true` | string  | Start hour in UTC, e.g., `02:00`                                                    |
| `--retention-days` | Required when `--auto-backup true` | integer | Days to retain backups (1-30)                                                       |
| `--body`           | No                                 | string  | Request body as JSON or `file://path.json`                                          |

```bash
# Enable daily backup at 2am UTC with 7-day retention
zilliz backup update-policy --cluster-id <CLUSTER_ID> --auto-backup true --frequency daily --start-time 02:00 --retention-days 7

# Enable backup on Mon/Wed/Fri at 3am UTC
zilliz backup update-policy --cluster-id <CLUSTER_ID> --auto-backup true --frequency 1,3,5 --start-time 03:00 --retention-days 14

# Disable auto-backup
zilliz backup update-policy --cluster-id <CLUSTER_ID> --auto-backup false
```

---

## Import Management

### import start

Start a data import job.

```
zilliz import start [OPTIONS]
```

| Parameter      | Required | Type   | Description                               |
| -------------- | -------- | ------ | ----------------------------------------- |
| `--cluster-id` | **Yes**  | string | Target cluster ID                         |
| `--collection` | **Yes**  | string | Target collection name                    |
| `--body`       | No       | string | Import spec as JSON or `file://path.json` |

```bash
# Import from S3
zilliz import start --cluster-id <CLUSTER_ID> --collection my_col --body '{"files": [["s3://bucket/data.json"]]}'

# Import using a JSON file
zilliz import start --cluster-id <CLUSTER_ID> --collection my_col --body file://import-spec.json
```

---

### import list

List import jobs for a cluster.

```
zilliz import list [OPTIONS]
```

| Parameter      | Required | Type    | Description    |
| -------------- | -------- | ------- | -------------- |
| `--cluster-id` | **Yes**  | string  | Cluster ID     |
| `--page-size`  | No       | integer | Items per page |
| `--page`       | No       | integer | Page number    |
| `--database`   | No       | string  | Database name  |

```bash
zilliz import list --cluster-id <CLUSTER_ID>
```

---

### import status

Get status of an import job.

```
zilliz import status [OPTIONS]
```

| Parameter      | Required | Type   | Description   |
| -------------- | -------- | ------ | ------------- |
| `--job-id`     | **Yes**  | string | Import job ID |
| `--cluster-id` | **Yes**  | string | Cluster ID    |

```bash
zilliz import status --job-id <JOB_ID> --cluster-id <CLUSTER_ID>
```

---

## Volume Management

### volume create

Create a new volume.

```
zilliz volume create [OPTIONS]
```

| Parameter      | Required | Type   | Description                          |
| -------------- | -------- | ------ | ------------------------------------ |
| `--project-id` | **Yes**  | string | Project ID                           |
| `--region`     | **Yes**  | string | Cloud region (e.g., `aws-us-west-2`) |
| `--name`       | **Yes**  | string | Volume name                          |

```bash
zilliz volume create --project-id <PROJECT_ID> --region aws-us-west-2 --name my-volume
```

---

### volume list

List all volumes in a project.

```
zilliz volume list [OPTIONS]
```

| Parameter      | Required | Type    | Description     |
| -------------- | -------- | ------- | --------------- |
| `--project-id` | **Yes**  | string  | Project ID      |
| `--page-size`  | No       | integer | Items per page  |
| `--page`       | No       | integer | Page number     |
| `--all`        | No       | flag    | Fetch all pages |

```bash
zilliz volume list --project-id <PROJECT_ID>
```

---

### volume delete

Delete a volume.

```
zilliz volume delete [OPTIONS]
```

| Parameter | Required | Type   | Description           |
| --------- | -------- | ------ | --------------------- |
| `--name`  | **Yes**  | string | Volume name to delete |

```bash
zilliz volume delete --name my-volume
```

---

## Billing

### billing usage

Query usage costs with flexible time range options.

```
zilliz billing usage [OPTIONS]
```

| Parameter  | Required | Type   | Description                                |
| ---------- | -------- | ------ | ------------------------------------------ |
| `--last`   | No       | string | Relative duration: `7d`, `30d`, `3m`, `1y` |
| `--month`  | No       | string | Month: `2026-01`, `last`, `this`           |
| `--start`  | No       | string | Start date: `YYYY-MM-DD` or ISO-8601       |
| `--end`    | No       | string | End date: `YYYY-MM-DD` or ISO-8601         |
| `--output` | No       | string | Output format: `json`, `table`, `text`     |

If no time range is specified, defaults to today's usage.

```bash
# Today's usage
zilliz billing usage

# Last 7 days
zilliz billing usage --last 7d

# Specific month
zilliz billing usage --month 2026-01

# Last month
zilliz billing usage --month last

# Date range
zilliz billing usage --start 2026-01-01 --end 2026-02-01
```

---

### billing invoices

List or view invoice details.

```
zilliz billing invoices [OPTIONS]
```

| Parameter      | Required | Type    | Description                                 |
| -------------- | -------- | ------- | ------------------------------------------- |
| `--invoice-id` | No       | string  | Invoice ID (if omitted, lists all invoices) |
| `--page-size`  | No       | integer | Items per page                              |
| `--page`       | No       | integer | Page number                                 |
| `--all`        | No       | flag    | Fetch all pages                             |
| `--output`     | No       | string  | Output format: `json`, `table`, `text`      |

```bash
# List all invoices
zilliz billing invoices

# View specific invoice
zilliz billing invoices --invoice-id <INVOICE_ID>
```

---

### billing bind-card

Bind a credit card to your account.

```
zilliz billing bind-card [OPTIONS]
```

| Parameter       | Required | Type    | Description                  |
| --------------- | -------- | ------- | ---------------------------- |
| `--card-number` | **Yes**  | string  | Credit card number           |
| `--exp-month`   | **Yes**  | integer | Expiration month (1-12)      |
| `--exp-year`    | **Yes**  | integer | Expiration year (e.g., 2026) |
| `--cvc`         | **Yes**  | string  | Card verification code       |

```bash
zilliz billing bind-card --card-number <CARD_NUMBER> --exp-month 12 --exp-year 2026 --cvc <CVC>
```

---

## Job Management

### job describe

Get the status of an async job (backup, restore, migration, import, etc.). Optionally poll until the job reaches a terminal state.

```
zilliz job describe [OPTIONS]
```

| Parameter    | Required | Type    | Description                                |
| ------------ | -------- | ------- | ------------------------------------------ |
| `--job-id`   | **Yes**  | string  | Job ID (e.g. job-xxxxxxxxxxxxxxxxxxxx)     |
| `--wait`     | No       | flag    | Poll until the job reaches a terminal state |
| `--timeout`  | No       | integer | Max seconds to wait (default: 1800)        |
| `--interval` | No       | integer | Poll interval in seconds (default: 5)      |

```bash
# Check job status
zilliz job describe --job-id job-03e1eefbd82dmo2oeb8pe2

# Wait for job to complete
zilliz job describe --job-id job-03e1eefbd82dmo2oeb8pe2 --wait

# Wait with custom timeout
zilliz job describe --job-id job-03e1eefbd82dmo2oeb8pe2 --wait --timeout 600
```

---

## Alert Management

Manage alert rules for monitoring cluster metrics and billing.

### alert list

List alert rules for a project.

```
zilliz alert list [OPTIONS]
```

| Parameter      | Required | Type    | Description                  |
| -------------- | -------- | ------- | ---------------------------- |
| `--project-id` | **Yes**  | string  | Project ID                   |
| `--page-size`  | No       | integer | Items per page (default: 10) |
| `--page`       | No       | integer | Page number (default: 1)     |

```bash
zilliz alert list --project-id proj-xxxx
zilliz alert list --project-id proj-xxxx --page-size 20 --page 2 -o json
```

---

### alert create

Create a new alert rule.

```
zilliz alert create [OPTIONS]
```

| Parameter            | Required | Type    | Description                                                        |
| -------------------- | -------- | ------- | ------------------------------------------------------------------ |
| `--project-id`       | **Yes**  | string  | Project ID                                                         |
| `--metric-name`      | **Yes**  | string  | Metric to monitor (e.g. CU_COMPUTATION, WALLET_BALANCE)            |
| `--threshold`        | **Yes**  | string  | Threshold value                                                    |
| `--comparison`       | **Yes**  | string  | Comparison operator: `>`, `<`, `>=`, `<=`, `=`                     |
| `--rule-name`        | No       | string  | Display name for the alert rule                                    |
| `--level`            | No       | string  | Severity: `WARNING` (default), `CRITICAL`                          |
| `--window-size`      | No       | string  | Monitoring window (e.g. 5m, 15m, 1h)                               |
| `--cluster-id`       | No       | string  | Target cluster ID (repeatable)                                     |
| `--action`           | No       | string  | Notification action as `type:config` (repeatable)                  |
| `--send-resolved`    | No       | flag    | Send notification when alert resolves                              |
| `--repeat-interval`  | No       | integer | Repeat notification interval in seconds                            |
| `--enabled`          | No       | flag    | Enable the rule (default: enabled)                                 |

Supported action types: `email`, `slack`, `webhook`, `pagerduty`, `opsgenie`, `wecom`, `dingtalk`, `lark`.

```bash
# Basic alert
zilliz alert create --project-id proj-xxx --metric-name CU_COMPUTATION --threshold 80 --comparison ">"

# Alert with notification
zilliz alert create --project-id proj-xxx --metric-name WALLET_BALANCE --threshold 100 \
    --comparison "<" --level CRITICAL --action email:admin@example.com

# Alert with Slack notification targeting specific cluster
zilliz alert create --project-id proj-xxx --metric-name CU_COMPUTATION --threshold 90 \
    --comparison ">=" --cluster-id in01-xxx --action slack:https://hooks.slack.com/xxx
```

---

### alert update

Update an existing alert rule.

```
zilliz alert update [OPTIONS]
```

| Parameter            | Required | Type    | Description                                       |
| -------------------- | -------- | ------- | ------------------------------------------------- |
| `--id`               | **Yes**  | string  | Alert rule ID                                     |
| `--project-id`       | No       | string  | Project ID (for interactive ID selection)          |
| `--rule-name`        | No       | string  | New display name                                  |
| `--metric-name`      | No       | string  | New metric name                                   |
| `--threshold`        | No       | string  | New threshold value                               |
| `--comparison`       | No       | string  | New comparison operator                           |
| `--level`            | No       | string  | New severity level                                |
| `--action`           | No       | string  | New notification actions (repeatable, replaces existing) |
| `--enabled`          | No       | flag    | Enable or disable the rule                        |

```bash
zilliz alert update --id alert-xxx --threshold 90
zilliz alert update --id alert-xxx --level CRITICAL --action email:new@example.com
```

---

### alert delete

Delete an alert rule.

```
zilliz alert delete [OPTIONS]
```

| Parameter      | Required | Type   | Description                              |
| -------------- | -------- | ------ | ---------------------------------------- |
| `--id`         | **Yes**  | string | Alert rule ID                            |
| `--project-id` | No       | string | Project ID (for interactive ID selection) |
| `-y`, `--yes`  | No       | flag   | Skip confirmation prompt                 |

```bash
zilliz alert delete --id alert-xxx
zilliz alert delete --id alert-xxx -y
```

---

### alert enable

Enable an alert rule.

```
zilliz alert enable [OPTIONS]
```

| Parameter      | Required | Type   | Description                              |
| -------------- | -------- | ------ | ---------------------------------------- |
| `--id`         | **Yes**  | string | Alert rule ID                            |
| `--project-id` | No       | string | Project ID (for interactive ID selection) |

```bash
zilliz alert enable --id alert-xxx
```

---

### alert disable

Disable an alert rule.

```
zilliz alert disable [OPTIONS]
```

| Parameter      | Required | Type   | Description                              |
| -------------- | -------- | ------ | ---------------------------------------- |
| `--id`         | **Yes**  | string | Alert rule ID                            |
| `--project-id` | No       | string | Project ID (for interactive ID selection) |

```bash
zilliz alert disable --id alert-xxx
```

---

## Cluster Metrics

### cluster metrics

Query cluster performance metrics (QPS, latency, storage, etc.) with interactive metric selection.

```
zilliz cluster metrics [OPTIONS]
```

| Parameter       | Required | Type   | Description                                                 |
| --------------- | -------- | ------ | ----------------------------------------------------------- |
| `--cluster-id`  | **Yes**  | string | Cluster ID                                                  |
| `--metric`, `-m`| **Yes**  | string | Metric name (repeatable). See available metrics below       |
| `--period`      | No       | string | Relative time period from now (e.g. 1h, 24h, 7d). Default: 1h |
| `--start`       | No       | string | Start time (ISO 8601: YYYY-MM-DD or YYYY-MM-DDTHH:MM:SSZ)  |
| `--end`         | No       | string | End time (ISO 8601)                                         |
| `--granularity`, `-g` | No | string | Data point interval (e.g. 30s, 5m, 1h). Default: auto      |

**Available Metrics:**

| Category     | Metrics                                                                                   |
| ------------ | ----------------------------------------------------------------------------------------- |
| Resource     | CU_COMPUTATION, CU_CAPACITY, CU_SIZE, REPLICA_COUNT, STORAGE                              |
| QPS          | SEARCH_QPS, QUERY_QPS, INSERT_QPS, UPSERT_QPS, DELETE_QPS, BULK_INSERT_QPS                |
| Latency      | SEARCH_LATENCY_AVG, SEARCH_LATENCY_P99, QUERY_LATENCY_AVG, QUERY_LATENCY_P99, etc.       |
| VPS          | SEARCH_VPS, INSERT_VPS, UPSERT_VPS, DELETE_VPS, BULK_INSERT_VPS                           |
| Failure Rate | SEARCH_FAIL_RATE, QUERY_FAIL_RATE, INSERT_FAIL_RATE, UPSERT_FAIL_RATE, etc.               |
| Data         | ENTITIES, ENTITIES_LOADED, ENTITIES_INDEXED, COLLECTIONS, SLOW_QUERIES                    |
| Serverless   | READ_VCU, WRITE_VCU                                                                       |

```bash
# Query search QPS for last hour
zilliz cluster metrics --cluster-id in01-xxx -m SEARCH_QPS

# Query multiple metrics for last 24 hours
zilliz cluster metrics --cluster-id in01-xxx -m SEARCH_QPS -m SEARCH_LATENCY_P99 --period 24h

# Query with custom granularity
zilliz cluster metrics --cluster-id in01-xxx -m CU_COMPUTATION --period 7d -g 1h

# Query with absolute time range
zilliz cluster metrics --cluster-id in01-xxx -m STORAGE --start 2026-03-01 --end 2026-03-15
```

---

## Shell Completion

### completion install

Install shell completion for the specified shell.

```
zilliz completion install [SHELL]
```

| Parameter | Required | Type   | Description                                                              |
| --------- | -------- | ------ | ------------------------------------------------------------------------ |
| `SHELL`   | No       | string | Shell type: `bash`, `zsh`, `fish`. Auto-detects from `$SHELL` if omitted |
| `--apply` | No       | flag   | Auto-write to shell RC file                                              |

```bash
# Install for current shell
zilliz completion install

# Install for specific shell
zilliz completion install zsh

# Install and auto-apply to RC file
zilliz completion install --apply
```

---

### completion uninstall

Remove shell completion.

```
zilliz completion uninstall [SHELL]
```

```bash
zilliz completion uninstall zsh
```

---

### completion status

Check if shell completion is installed.

```
zilliz completion status [SHELL]
```

```bash
zilliz completion status zsh
```

---

### completion show

Show the completion script content.

```
zilliz completion show [SHELL]
```

```bash
zilliz completion show zsh
```

---

## Version

Show CLI version.

```
zilliz version [OPTIONS]
```

| Parameter  | Required | Type   | Description                            |
| ---------- | -------- | ------ | -------------------------------------- |
| `--output` | No       | string | Output format: `json`, `table`, `text` |

```bash
zilliz version
```

---

## Quick Start Guide

```bash
# 1. Install
pip install zilliz-cli

# 2. Configure API Key (choose one)
zilliz configure                        # Interactive
export ZILLIZ_API_KEY=<YOUR_API_KEY>    # Environment variable

# 3. List clusters
zilliz cluster list

# 4. Set cluster context (auto-resolves endpoint)
zilliz context set --cluster-id <CLUSTER_ID>

# 5. Create a collection
zilliz collection create --name my_collection --dimension 768

# 6. Insert data
zilliz vector insert --collection my_collection --data '[{"vector": [0.1, 0.2, ...]}]'

# 7. Search
zilliz vector search --collection my_collection --data '[[0.1, 0.2, ...]]' --limit 5
```

---

## Tips

### API Key Resolution Order

1. `--api-key` CLI flag (highest priority)
2. `ZILLIZ_API_KEY` environment variable
3. Config file (`~/.zilliz/credentials`)

### File Input

Many commands support loading JSON from files using the `file://` prefix:

```bash
zilliz collection create --name my_col --body file://schema.json
zilliz vector insert --collection my_col --data file:///path/to/data.json
```

### Pagination

Commands that return lists support pagination:

```bash
# Manual pagination
zilliz cluster list --page 1 --page-size 20

# Fetch all pages automatically
zilliz cluster list --all
```

### Output Formats

```bash
# Table format (default) - human-readable
zilliz cluster list

# JSON format - machine-readable
zilliz cluster list -o json

# Text format - plain key-value pairs
zilliz cluster list -o text
```
