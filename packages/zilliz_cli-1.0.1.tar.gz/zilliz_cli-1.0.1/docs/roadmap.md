# Zilliz CLI Roadmap

## Current Status

Zilliz CLI currently supports **120+ commands** across 16 个命令组，覆盖了 Zilliz Cloud REST API 的核心功能。

### 已实现功能概览

| 类别 | 命令数 | 覆盖范围 |
|------|--------|----------|
| Cluster 管理 | 10 | list, describe, create, modify, suspend, resume, delete, providers, regions, metrics |
| Project 管理 | 4 | create, list, describe, upgrade |
| Backup 管理 | 9 | create, list, describe, delete, export, restore-cluster, restore-collection, describe-policy, update-policy |
| Import 管理 | 3 | start, list, status |
| Volume 管理 | 3 | create, list, delete |
| Billing 管理 | 3 | bind-card, usage, invoices |
| Alert 管理 | 6 | create, list, update, delete, enable, disable |
| Collection 操作 | 12 | create, list, describe, drop, rename, load, release, get-load-state, get-stats, has, flush, compact |
| Vector 操作 | 7 | insert, upsert, search, hybrid-search, query, get, delete |
| Database 操作 | 4 | create, list, describe, drop |
| Index 操作 | 4 | create, list, describe, drop |
| Partition 操作 | 7 | create, list, drop, has, get-stats, load, release |
| User 操作 | 7 | create, list, describe, drop, update-password, grant-role, revoke-role |
| Role 操作 | 6 | create, list, describe, drop, grant-privilege, revoke-privilege |
| Alias 操作 | 5 | create, list, describe, alter, drop |
| 认证/配置/工具 | 17 | login, logout, auth, configure, context, completion, version |

### 已实现的全局选项

| 选项 | 说明 |
|------|------|
| `--output json/table/text/yaml/csv` | 多种输出格式 |
| `--no-header` | 省略表头（table/csv 输出），便于脚本集成 |
| `--query` / `-q` | JMESPath 表达式过滤输出 |
| `-y` / `--yes` | 跳过删除等危险操作的确认提示 |

---

### 已覆盖但可增强的功能

| 功能 | 当前状态 | 增强方向 |
|------|----------|----------|
| `cluster create` | 统一创建入口 | 可增加 `createFree`/`createDedicated`/`createServerless` 快捷命令 |
| `cluster modify` | 支持 cu-size 和 replica | 可增加 `modifyReplica` 专用端点 |
| `collection create` | 支持基本 schema | 增强复杂 schema 交互式创建（多字段、动态字段等） |
| `vector search` | 基本搜索 | 增强搜索参数支持（searchParams、range filter、grouping） |
| `index create` | 需要 --body JSON | 增强交互式索引参数配置 |

---

## Iteration Plan

### P0: 基础体验优化 (短期)

核心目标：提升日常使用体验，降低使用门槛。

#### 1. 交互式增强
- [ ] `collection create` 支持交互式多字段 schema 定义
- [ ] `index create` 支持交互式索引参数选择（indexType、metric_type 等）
- [ ] `vector search` 支持交互式构建搜索参数

#### 2. 错误提示改进
- [X] 常见错误的友好提示和修复建议
- [ ] 参数校验前置（在发送请求前校验明显的错误参数）
- [X] 网络错误自动重试机制

#### 3. Cloud Job 查询
- [X] `job describe --job-id <JOB_ID>` 查看异步任务状态
- [ ] 长时操作（create cluster、backup restore 等）自动轮询任务进度
- [ ] `--wait` 选项：同步等待异步操作完成

---

### P1: 功能增强 (中期)

核心目标：增强现有命令的能力，提升搜索和操作体验。

#### 1. 搜索能力增强
- [ ] `vector search` 增加 `--search-params` 支持（nprobe、ef 等）
- [ ] `vector search` 增加 `--range-filter` 范围搜索
- [ ] `vector search` 增加 `--grouping-field` 分组搜索
- [ ] `vector search` 增加 `--partition` 指定分区搜索
- [ ] `vector hybrid-search` 增加交互式多路搜索构建

---

### P2: 企业级功能 (中长期)

核心目标：支持企业级场景，增加高级管理能力。

#### 1. 云迁移 (`migration` 命令组)
- [ ] `migration to-new` - 迁移数据到新 Dedicated 集群 (`POST /v2/migrations/toNewDedicated`)
- [ ] `migration to-existing` - 迁移数据到已有集群 (`POST /v2/migrations/toExisting`)
- [ ] `migration status` - 查看迁移任务状态（依赖 Cloud Job API）
- [ ] 交互式迁移向导（选择源集群、目标配置等）

**实现方式**: 在 `control-plane.json` 中新增 `migration` resource。

#### 2. 多上下文管理
- [ ] `context list` - 列出所有已保存的集群上下文
- [ ] `context delete` - 删除已保存的上下文
- [ ] `context rename` - 重命名上下文
- [ ] 支持命名上下文（类似 kubectl context）
- [ ] `--context <name>` 全局选项临时切换上下文

#### 3. 批量操作支持
- [ ] `collection drop --all` 批量删除 collection（带安全确认）
- [ ] `vector insert --batch-size` 大文件自动分批插入
- [ ] `vector delete --file` 从文件读取删除条件
- [ ] `backup create --all-clusters` 批量备份

---

### P3: 高级功能与生态 (长期)

核心目标：构建完整的 CLI 生态，支持自动化和集成场景。

#### 1. ELT / 数据管道
- [ ] `data merge` - 数据合并（`POST /v2/etl/merge`，为已有 collection 添加字段）

#### 2. 配置文件驱动
- [ ] 支持 `zilliz.yaml` 项目级配置文件
- [ ] `apply -f config.yaml` 声明式资源管理（类 kubectl apply）
- [ ] `export --format yaml` 导出当前资源为配置文件

---

## Technical Debt & Infrastructure

### 测试覆盖
- [ ] 所有 model-driven 命令的单元测试覆盖率提升至 90%+
- [ ] 增加 E2E 测试覆盖所有 control-plane 命令
- [ ] 增加 E2E 测试覆盖所有 data-plane 命令
- [ ] 性能基准测试（大数据量插入、搜索延迟）

### 文档
- [ ] 每个命令的 man page 生成
- [ ] 交互式教程 (`zilliz tutorial`)
- [ ] 常见场景 cookbook（RAG 工作流、数据迁移、备份恢复等）
- [ ] API 版本变更自动检测和提示

### 发布与分发
- [ ] PyPI 发布
- [ ] Homebrew formula (`brew install zilliz-cli`)
- [ ] Docker 镜像（`docker run zilliz/cli`)
- [ ] 预编译二进制（不依赖 Python 环境）
- [ ] 自动更新检测和提示

### 架构改进
- [ ] Model JSON 版本管理 - 支持多 API 版本切换
- [ ] 请求/响应日志 (`--debug` / `--verbose`)
- [ ] HTTP 请求缓存（对 list 类操作短时缓存）
- [ ] 配置文件加密存储（API Key 等敏感信息）
- [ ] 支持 HTTP proxy 配置

---
