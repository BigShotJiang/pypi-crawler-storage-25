# Contributing to Zilliz CLI

Thank you for your interest in contributing to `zilliz-cli`. This guide covers the development workflow, conventions, and how to submit changes.

## Prerequisites

- Python 3.10+
- [uv](https://docs.astral.sh/uv/) (recommended) or pip
- Git

## Getting Started

1. Clone the repository and navigate to the CLI directory:
  ```bash
   cd vdc/zilliz-cli
  ```
2. Install the project with development dependencies:
  ```bash
   pip install -e ".[dev]"
  ```
3. Verify the installation:
  ```bash
   zilliz --help
  ```

## Project Structure

```
src/zilliz_cli/
  auth/             # Authentication, config, and credential management
  builtin_models/   # JSON model definitions (control-plane.json, data-plane.json)
  commands/         # Hand-written commands (configure, context, auth, etc.)
  core/             # Model loader, command factory, API caller
  formatter/        # Output formatting (json, table, text)
  cli.py            # CLI entry point

tests/
  unit/             # Unit tests (click.testing.CliRunner + pytest-httpx)
  e2e/              # End-to-end tests (subprocess against real APIs)
  acceptance/       # Full lifecycle acceptance tests
```

## Architecture Overview

Zilliz CLI uses a **model-driven architecture**. Most commands are auto-generated from JSON model files rather than hand-written. Before contributing, understand the distinction:

- **Model-driven commands**: Defined in `src/zilliz_cli/builtin_models/control-plane.json` or `data-plane.json`. The `CommandFactory` auto-generates Click commands from these definitions.
- **Hand-written commands**: Located in `src/zilliz_cli/commands/`. Used only when custom logic is required (interactive prompts, multi-step workflows, special formatting).

**Rule of thumb**: If a new command maps directly to an API endpoint, add it to a JSON model file. Only write Python when the command needs logic beyond what the model supports.

## Development Workflow

### Running Tests

```bash
# Run all unit tests
pytest tests/unit/

# Run a specific test file
pytest tests/unit/test_cluster_cmd.py

# Run a specific test by name
pytest tests/unit/test_cluster_cmd.py -k "test_name"

# Run E2E tests (requires a valid API key)
ZILLIZ_API_KEY=your-key pytest -m e2e

# Run acceptance tests
ZILLIZ_API_KEY=your-key pytest -m acceptance
```

### Linting and Type Checking

```bash
# Lint with ruff
ruff check src/ tests/

# Auto-fix lint issues
ruff check --fix src/ tests/

# Type check with mypy
mypy src/
```

All lint and type checks must pass before submitting a pull request.

### Code Style

- Line length: 120 characters
- Linting rules: ruff with `E`, `F`, `W`, `I` rule sets
- Target Python version: 3.10
- Follow existing patterns in the codebase

## Adding a New API Command

### Option 1: Model-Driven (Preferred)

Add the operation to the appropriate JSON model file:

- `src/zilliz_cli/builtin_models/control-plane.json` for cloud management APIs (clusters, projects, backups, billing)
- `src/zilliz_cli/builtin_models/data-plane.json` for Milvus data APIs (collections, vectors, indexes, partitions)

The `CommandFactory` will auto-generate the CLI command, options, validation, and output formatting.

### Option 2: Hand-Written

Create a new file in `src/zilliz_cli/commands/` only if the command requires:

- Interactive prompts or multi-step workflows
- Custom output formatting beyond what the model supports
- Complex parameter validation or transformation

Hand-written commands are injected into model-driven groups in `cli.py`.

## Testing Guidelines

- **Unit tests are required** for all new functionality.
- Use `click.testing.CliRunner` to invoke commands in tests.
- Use `pytest-httpx` to mock HTTP calls -- do not make real API calls in unit tests.
- Isolate config state using the `tmp_path` fixture.
- Place tests in the appropriate directory:
  - `tests/unit/` for unit tests
  - `tests/e2e/` for end-to-end tests (marked with `@pytest.mark.e2e`)
  - `tests/acceptance/` for full lifecycle tests (marked with `@pytest.mark.acceptance`)

## Keeping zilliz-plugin in Sync

The [zilliz-plugin](https://github.com/zilliztech/zilliz-plugin) repository is a **Claude Code plugin** that teaches Claude how to use `zilliz-cli`. It contains no Python code -- only Markdown skill files (in `skills/`) and slash commands (in `commands/`) that document exact CLI invocations, flag names, `--body` JSON schemas, and expected `--output json` response formats. When a user asks Claude to perform Zilliz operations, Claude reads these skill files and executes the documented `zilliz` commands via bash.

**If you change the CLI interface, you must update the plugin**, otherwise Claude Code users will hit broken commands.

### What counts as a breaking change for the plugin


| Change in zilliz-cli                                                         | Impact on zilliz-plugin                                                                       |
| ---------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| Rename/remove a command group or subcommand                                  | Breaks the corresponding `skills/*/SKILL.md`                                                  |
| Rename/remove a flag (e.g. `--cluster-id`)                                   | Breaks all skills that reference that flag                                                    |
| Change `--output json` response structure                                    | Breaks `commands/status.md` and `skills/monitoring/SKILL.md` which parse JSON output          |
| Change `--body` JSON schema (collection schema, index params, search syntax) | Breaks creation/search flows in `skills/vector/`, `skills/collection/`, `skills/index/`, etc. |
| Add a new subcommand                                                         | Plugin still works but Claude won't know about the new command until the skill is updated     |


### Plugin files to update


| CLI area changed                          | Plugin files to check                              |
| ----------------------------------------- | -------------------------------------------------- |
| Auth / context / config                   | `skills/setup/SKILL.md`, `commands/quickstart.md`  |
| `zilliz cluster *`                        | `skills/cluster/SKILL.md`, `commands/status.md`    |
| `zilliz collection *` / `zilliz alias *`  | `skills/collection/SKILL.md`                       |
| `zilliz vector *` (search, insert, query) | `skills/vector/SKILL.md`                           |
| `zilliz index *`                          | `skills/index/SKILL.md`                            |
| `zilliz database *`                       | `skills/database/SKILL.md`                         |
| `zilliz user *` / `zilliz role *`         | `skills/user-role/SKILL.md`                        |
| `zilliz backup *`                         | `skills/backup/SKILL.md`                           |
| `zilliz import *`                         | `skills/import/SKILL.md`                           |
| `zilliz partition *`                      | `skills/partition/SKILL.md`                        |
| `zilliz project *` / `zilliz volume *`    | `skills/project-region/SKILL.md`                   |
| `zilliz billing *`                        | `skills/billing/SKILL.md`                          |
| JSON output format                        | `commands/status.md`, `skills/monitoring/SKILL.md` |


Before merging CLI changes that affect the command interface or output schema, open a corresponding PR in `zilliz-plugin` to keep both projects aligned.

## Updating the Version

When releasing a new version:

1. Update the `version` field in `pyproject.toml`:
  ```toml
   version = "1.0.0"
  ```
2. Run `uv lock` to regenerate the lock file:
  ```bash
   uv lock
  ```
3. Commit both `pyproject.toml` and `uv.lock` together.

## Submitting Changes

1. Create a branch from `master`. Do not use `/` in branch names.
2. Make your changes and add tests.
3. Ensure all checks pass:
  ```bash
   ruff check src/ tests/
   ruff format --check src/ tests/
   mypy src/
   pytest tests/unit/
  ```
4. Commit using [Conventional Commits](https://www.conventionalcommits.org/) format:
  ```
   feat(cli): add support for new-resource commands
   fix(auth): handle expired token refresh
  ```
5. Open a pull request against `master` with a clear description of the change.

## Roadmap

See the [Zilliz CLI Roadmap](https://zilliverse.feishu.cn/docx/KzQfdvzPCoAUH7xmoGzc8VkYnL0) for planned features and priorities.

## Reporting Issues

If you encounter a bug or have a feature request, open an issue in the repository with:

- Steps to reproduce (for bugs)
- Expected vs actual behavior
- CLI version (`zilliz version`)
- Python version and OS

