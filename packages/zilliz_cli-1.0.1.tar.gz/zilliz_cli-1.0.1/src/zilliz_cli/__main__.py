from zilliz_cli.cli import main

main()
