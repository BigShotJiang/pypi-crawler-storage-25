# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import sys

import click
import questionary

from zilliz_cli.auth.config import get_config_manager
from zilliz_cli.auth.credentials import resolve_api_key
from zilliz_cli.core.api_caller import APICaller
from zilliz_cli.core.command_factory import SmartGroup
from zilliz_cli.core.exceptions import APIError, CredentialError
from zilliz_cli.formatter.base import get_formatter


@click.group(cls=SmartGroup)
def context():
    """Manage current cluster context."""
    pass


@context.command("set")
@click.option("--cluster-id", default=None, help="Cluster ID.")
@click.option("--endpoint", default=None, help="Cluster endpoint URL (optional, auto-resolved from cluster-id).")
@click.option("--database", default=None, help="Database name.")
@click.pass_context
def context_set(ctx, cluster_id, endpoint, database):
    """Set the current cluster context."""
    mgr = get_config_manager(ctx.obj)

    if database and not cluster_id:
        mgr.set_context(database=database)
        click.echo(f"Database set to: {database}")
        return

    def _get_api_key():
        try:
            return resolve_api_key(ctx.obj.get("api_key"), mgr)
        except CredentialError as e:
            raise click.ClickException(str(e))

    # Interactive prompt if no params provided
    if cluster_id is None:
        if not sys.stdin.isatty():
            raise click.UsageError("Provide at least --cluster-id or --database.")

        api_key = _get_api_key()
        caller = APICaller(api_key=api_key)
        cluster_id = _prompt_cluster(caller)
        if cluster_id is None:
            return

    # Resolve endpoint and plan from cluster API
    plan = None
    if endpoint is None:
        api_key = _get_api_key()
        caller = APICaller(api_key=api_key)
        try:
            cluster_info = caller.call("GET", "/v2/clusters/{clusterId}", path_params={"clusterId": cluster_id})
            if not cluster_info:
                raise click.ClickException(f"Cluster {cluster_id} returned no data. Use --endpoint to set manually.")
            endpoint = cluster_info.get("connectAddress", "")
            plan = cluster_info.get("deploymentOption", "") or cluster_info.get("plan", "")
            if not endpoint:
                raise click.ClickException(
                    f"Cluster {cluster_id} has no connectAddress. Use --endpoint to set manually."
                )
        except APIError as e:
            raise click.ClickException(f"Failed to resolve endpoint: {e}")

    # Resolve database: prompt from cluster's actual databases if not specified
    if database is None:
        try:
            api_key = _get_api_key()
            database = _resolve_database(api_key, endpoint)
        except click.ClickException:
            database = "default"
    # Clear old context first to avoid stale fields (e.g. plan from previous cluster)
    mgr.clear_context()
    mgr.set_context(cluster_id=cluster_id, endpoint=endpoint, database=database, plan=plan)
    click.echo(f"Context set: cluster={cluster_id}, endpoint={endpoint}, database={database}")


@context.command("current")
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None)
@click.pass_context
def context_current(ctx, output):
    """Show the current context."""
    mgr = get_config_manager(ctx.obj)
    context_data = mgr.get_context()
    output_format = output or ctx.obj.get("output_format") or "text"
    fmt = get_formatter(output_format)
    if context_data["cluster_id"] is None:
        msg = 'No context set. Run "zilliz context set --cluster-id <id>" first.'
        click.echo(fmt.format_error(0, msg), err=True)
        ctx.exit(1)
        return
    click.echo(fmt.format_success(context_data))


def _prompt_cluster(caller):
    """Fetch clusters and present a selection list."""
    try:
        result = caller.call("GET", "/v2/clusters", return_raw=True)
        response_data = result.get("data", result) if isinstance(result, dict) else result
        items = response_data if isinstance(response_data, list) else response_data.get("clusters", [])

        if not items:
            click.echo("No clusters found.")
            return click.prompt("  clusterId", type=str).strip()

        choices = []
        for item in items:
            cid = item.get("clusterId")
            name = item.get("clusterName", cid)
            status = item.get("status", "")
            if cid:
                display = f"{name} [{status}] ({cid})"
                choices.append(questionary.Choice(title=display, value=cid))

        if not choices:
            return click.prompt("  clusterId", type=str).strip()

        if len(choices) == 1:
            click.echo(f"  cluster: {choices[0].title} (auto-selected)")
            return choices[0].value

        selected = questionary.select("  Select cluster:", choices=choices, use_shortcuts=True).ask()
        if selected is None:
            raise click.Abort()
        return selected
    except (APIError, KeyError, TypeError, ValueError):
        return click.prompt("  clusterId", type=str).strip()


def _resolve_database(api_key, endpoint):
    """Fetch databases from cluster and auto-select or prompt."""
    try:
        caller = APICaller(api_key=api_key, base_url=endpoint)
        result = caller.call("POST", "/v2/vectordb/databases/list", return_raw=True)
        data = result.get("data", []) if isinstance(result, dict) else []
        dbs = [d for d in data if isinstance(d, str)]

        if not dbs:
            return "default"

        if len(dbs) == 1:
            click.echo(f"  database: {dbs[0]} (auto-selected)")
            return dbs[0]

        if sys.stdin.isatty():
            choices = [questionary.Choice(title=d, value=d) for d in dbs]
            selected = questionary.select("  Select database:", choices=choices, use_shortcuts=True).ask()
            if selected is None:
                raise click.Abort()
            return selected

        return dbs[0]
    except (APIError, KeyError, TypeError, ValueError):
        return "default"
