# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

"""Authentication commands for Zilliz CLI."""

import sys

import click
import httpx
import questionary

from zilliz_cli.auth.config import get_config_manager
from zilliz_cli.auth.oauth import OAuthError, perform_device_code_login
from zilliz_cli.core.command_factory import SmartGroup
from zilliz_cli.core.exceptions import APIError


def _mask_api_key(key: str) -> str:
    """Mask API key for display."""
    if len(key) >= 16:
        return key[:4] + "****" + key[-4:]
    return "****"


def _login_with_api_key(ctx, mgr):
    """Login using manually provided API key."""
    from zilliz_cli.auth.validation import validate_api_key

    click.echo("\nAPI Key Authentication")
    click.echo("You can find your API key in the Zilliz Cloud console under API Keys.")
    click.echo()

    api_key = click.prompt("Please paste your API key", hide_input=True).strip()

    if not api_key:
        raise click.ClickException("API key cannot be empty")

    validate_api_key(api_key)

    # Save API key to config
    mgr.save_api_key_only(api_key)

    click.echo("\nSuccessfully configured API key!")
    click.echo(f"  API Key: {_mask_api_key(api_key)}")
    click.echo("\nNote: You're using API key authentication. Some features may be limited.")


def _login_with_browser(ctx, mgr, no_browser):
    """Login using OAuth Device Code Flow."""
    click.echo("Starting browser-based login...")

    try:
        # Perform device code flow to get access token
        token_resp, auth_config = perform_device_code_login(
            open_browser=not no_browser,
            echo_func=click.echo,
        )

        click.echo("\nExchanging token for credentials...")

        # Call the CLI login endpoint to get user info and API keys
        cli_login_url = f"{auth_config.login_api}/account/v1/cli/login"

        with httpx.Client(timeout=30.0) as client:
            resp = client.post(
                cli_login_url,
                headers={"Authorization": f"Bearer {token_resp.access_token}"},
            )

        if resp.status_code != 200:
            try:
                error_data = resp.json()
                message = error_data.get("msg", error_data.get("message", "Unknown error"))
            except (ValueError, httpx.DecodingError):
                message = resp.text
            raise APIError(resp.status_code, f"Login failed: {message}")

        data = resp.json()
        # Support both lowercase and uppercase field names
        code = data.get("code") or data.get("Code")
        if code not in (0, 200):
            msg = data.get("msg") or data.get("Message") or "Login failed"
            raise APIError(code or 0, msg)

        result = data.get("data") or data.get("Data") or {}
        user = result.get("user", {})
        orgs = result.get("orgs", [])

        # Save login data
        mgr.save_login_data(
            user_id=user.get("userId", ""),
            email=user.get("email", ""),
            name=user.get("name", ""),
            orgs=orgs,
        )

        click.echo("\nSuccessfully logged in!")
        click.echo(f"  User: {user.get('name', '')} ({user.get('email', '')})")

        if orgs:
            first_org = orgs[0]
            click.echo(f"  Organization: {first_org.get('name', '')} ({first_org.get('orgId', '')})")

            if len(orgs) > 1:
                click.echo(f"\n{len(orgs)} organizations available. Use 'zilliz auth switch' to change.")

    except OAuthError as e:
        raise click.ClickException(str(e))
    except APIError as e:
        raise click.ClickException(f"API Error ({e.code}): {e.message}")
    except httpx.HTTPError as e:
        raise click.ClickException(f"Network error: {e}")


@click.group(cls=SmartGroup)
def auth():
    """Authentication commands."""
    pass


@auth.command("status")
@click.pass_context
def auth_status(ctx):
    """Show current authentication status."""
    mgr = get_config_manager(ctx.obj)
    user_info = mgr.get_user_info()

    if not user_info or not user_info.email:
        # Check if there's a manual API key configured
        api_key = mgr.get_credential("api_key")
        if api_key:
            click.echo("Not logged in (using manually configured API key)")
            click.echo(f"  API Key: {_mask_api_key(api_key)}")
        else:
            click.echo("Not logged in")
            click.echo('\nRun "zilliz login" to authenticate.')
        return

    click.echo("Logged in")
    click.echo(f"  User: {user_info.name} ({user_info.email})")

    current_org = mgr.get_current_org()
    if current_org:
        click.echo(f"  Organization: {current_org.name} ({current_org.org_id})")
        if current_org.api_key:
            click.echo(f"  API Key: {_mask_api_key(current_org.api_key)}")

    orgs = mgr.get_all_orgs()
    if len(orgs) > 1:
        click.echo(f"\nAvailable organizations ({len(orgs)}):")
        for org in orgs:
            marker = "*" if current_org and org.org_id == current_org.org_id else " "
            click.echo(f"  {marker} {org.name} ({org.org_id})")


@click.command()
@click.option("--no-browser", is_flag=True, default=False, help="Don't automatically open the browser")
@click.option("--api-key", is_flag=True, default=False, help="Login with API key instead of browser")
@click.pass_context
def login(ctx, no_browser, api_key):
    """Log in to Zilliz Cloud.

    Supports browser-based OAuth login (default) or API key authentication.
    """
    mgr = get_config_manager(ctx.obj)

    # Check if already logged in (before tty check so non-interactive callers can exit cleanly)
    user_info = mgr.get_user_info()
    existing_api_key = mgr.get_credential("api_key")

    if user_info and user_info.email:
        click.echo(f"Already logged in as {user_info.email}")
        if not click.confirm("Do you want to re-authenticate?"):
            return
    elif existing_api_key:
        click.echo("Already logged in with API key")
        if not click.confirm("Do you want to re-authenticate?"):
            return

    if not api_key and not sys.stdin.isatty():
        raise click.ClickException(
            'No interactive terminal detected. Please run "zilliz login --api-key <api-key>" instead.'
        )

    # Let user choose authentication method if not specified
    if not api_key:
        choices = [
            questionary.Choice(title="Login with browser (recommended)", value="browser"),
            questionary.Choice(title="Paste an API key", value="apikey"),
        ]

        method = questionary.select(
            "How would you like to authenticate?",
            choices=choices,
        ).ask()

        if method is None:
            # User cancelled
            return

        api_key = method == "apikey"

    mgr.clear_context()
    if api_key:
        _login_with_api_key(ctx, mgr)
    else:
        _login_with_browser(ctx, mgr, no_browser)


@click.command()
@click.pass_context
def logout(ctx):
    """Log out from Zilliz Cloud and clear stored credentials."""
    mgr = get_config_manager(ctx.obj)
    user_info = mgr.get_user_info()
    api_key = mgr.get_credential("api_key")

    if user_info and user_info.email:
        email = user_info.email
        mgr.clear_login_data()
        mgr.clear_context()
        click.echo(f"Logged out from {email}")
    elif api_key:
        mgr.clear_login_data()
        mgr.clear_context()
        click.echo("Cleared API key credentials.")
    else:
        click.echo("Not logged in.")


@auth.command("switch")
@click.argument("org_id", required=False)
@click.pass_context
def auth_switch(ctx, org_id):
    """Switch to a different organization.

    If ORG_ID is not provided, shows an interactive selection list.
    """
    mgr = get_config_manager(ctx.obj)
    user_info = mgr.get_user_info()

    if not user_info or not user_info.email:
        raise click.ClickException("Not logged in. Run 'zilliz login' first.")

    orgs = mgr.get_all_orgs()
    if not orgs:
        raise click.ClickException("No organizations found. Try logging in again.")

    current_org = mgr.get_current_org()

    if not org_id:
        if not sys.stdin.isatty():
            raise click.ClickException(
                'No interactive terminal detected. Please provide ORG_ID: "zilliz auth switch <org_id>".'
            )

        # Interactive selection with arrow keys
        choices = []
        for org in orgs:
            is_current = current_org and org.org_id == current_org.org_id
            label = f"{org.name} ({org.org_id})"
            if is_current:
                label = f"{org.name} ({org.org_id}) [current]"
            choices.append(questionary.Choice(title=label, value=org.org_id))

        selected_org_id = questionary.select(
            "Select organization:",
            choices=choices,
        ).ask()

        if selected_org_id is None:
            # User cancelled (Ctrl+C)
            return

        # Find selected org
        selected = None
        for org in orgs:
            if org.org_id == selected_org_id:
                selected = org
                break

        if selected is None:
            # User cancelled (Ctrl+C)
            return

        if current_org and selected.org_id == current_org.org_id:
            click.echo(f"Already using {selected.name}")
            return

        mgr.set_current_org(selected.org_id)
        mgr.clear_context()
        click.echo(f"Switched to {selected.name} ({selected.org_id})")
        return

    # Find the org
    target_org = None
    for org in orgs:
        if org.org_id == org_id or org.name.lower() == org_id.lower():
            target_org = org
            break

    if not target_org:
        raise click.ClickException(f"Organization '{org_id}' not found.")

    mgr.set_current_org(target_org.org_id)
    mgr.clear_context()
    click.echo(f"Switched to {target_org.name} ({target_org.org_id})")


# Export login and logout as top-level commands too
# These will be registered in cli.py
