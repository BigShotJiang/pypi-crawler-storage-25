import click
from rich.console import Console

from zilliz_cli.core.command_factory import GroupedCommand
from zilliz_cli.core.exceptions import APIError
from zilliz_cli.core.helpers import build_caller
from zilliz_cli.core.job_waiter import wait_for_job
from zilliz_cli.formatter.base import get_formatter

_DESCRIBE_EPILOG = """\b
Examples:
  $ zilliz job describe --job-id job-03e1eefbd82dmo2oeb8pe2
  $ zilliz job describe --job-id job-03e1eefbd82dmo2oeb8pe2 -o json
  $ zilliz job describe --job-id job-03e1eefbd82dmo2oeb8pe2 --wait
  $ zilliz job describe --job-id job-03e1eefbd82dmo2oeb8pe2 --wait --timeout 600"""


@click.command(name="describe", cls=GroupedCommand, epilog=_DESCRIBE_EPILOG)
@click.option("--job-id", required=True, help="Job ID (e.g. job-xxxxxxxxxxxxxxxxxxxx).")
@click.option("--wait", "wait_flag", is_flag=True, default=False, help="Poll until the job reaches a terminal state.")
@click.option("--timeout", type=int, default=1800, help="Max seconds to wait (default: 1800).")
@click.option("--interval", type=int, default=5, help="Poll interval in seconds (default: 5).")
@click.option(
    "--output", "-o", type=click.Choice(["json", "table", "text", "yaml", "csv"]), default=None, help="Output format."
)
@click.pass_context
def describe_job(ctx, job_id, wait_flag, timeout, interval, output):
    """Get status of an async job (backup, restore, migration, import, etc.)."""
    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)

    caller = build_caller(ctx)
    console = Console(stderr=True)

    try:
        if wait_flag:
            result = wait_for_job(caller, job_id, timeout=timeout, interval=interval)
        else:
            with console.status("[cyan]Loading...[/cyan]", spinner="dots"):
                result = caller.call("GET", "/v2/jobs/{jobId}", path_params={"jobId": job_id})

        click.echo(fmt.format_success(result))

        if isinstance(result, dict) and result.get("status") == "FAILED":
            ctx.exit(1)

    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)
