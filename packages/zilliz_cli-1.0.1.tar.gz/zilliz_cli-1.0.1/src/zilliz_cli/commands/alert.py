# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import sys

import click
import questionary
from rich.console import Console
from rich.table import Table
from rich.text import Text

from zilliz_cli.core.command_factory import GroupedCommand, OrderedGroup
from zilliz_cli.core.exceptions import APIError
from zilliz_cli.core.helpers import build_caller
from zilliz_cli.formatter.base import get_formatter

_KNOWN_METRICS = [
    "CU_COMPUTATION",
    "CU_CAPACITY",
    "REQ_SEARCH_COUNT",
    "REQ_QUERY_COUNT",
    "REQ_SEARCH_LATENCY_P99",
    "REQ_QUERY_LATENCY_P99",
    "REQ_SEARCH_FAILURE_RATE",
    "REQ_QUERY_FAILURE_RATE",
    "TOTAL_ENTITIES",
    "CREDIT_CARD_EXPIRATION",
    "FREE_CREDITS_BALANCE",
    "WALLET_BALANCE",
    "DAILY_USAGE",
]

_COMPARISON_MAP = {
    ">": "GREATER_THAN",
    "gt": "GREATER_THAN",
    "greater_than": "GREATER_THAN",
    "<": "LESS_THAN",
    "lt": "LESS_THAN",
    "less_than": "LESS_THAN",
    ">=": "GREATER_THAN_OR_EQUAL",
    "gte": "GREATER_THAN_OR_EQUAL",
    "greater_than_or_equal": "GREATER_THAN_OR_EQUAL",
    "<=": "LESS_THAN_OR_EQUAL",
    "lte": "LESS_THAN_OR_EQUAL",
    "less_than_or_equal": "LESS_THAN_OR_EQUAL",
    "=": "EQUAL",
    "eq": "EQUAL",
    "equal": "EQUAL",
}

_COMPARISON_SYMBOLS = {
    "GREATER_THAN": ">",
    "LESS_THAN": "<",
    "GREATER_THAN_OR_EQUAL": ">=",
    "LESS_THAN_OR_EQUAL": "<=",
    "EQUAL": "=",
}

_ACTION_CONFIG_BUILDERS = {
    "email": lambda val: {"email": val},
    "slack": lambda val: {"webhookUrl": val},
    "webhook": lambda val: {"url": val},
    "pagerduty": lambda val: {"routingKey": val},
    "opsgenie": lambda val: {"apiKey": val},
    "wecom": lambda val: {"webhookUrl": val},
    "dingtalk": lambda val: {"webhookUrl": val},
    "lark": lambda val: {"webhookUrl": val},
}

_VALID_ACTION_TYPES = list(_ACTION_CONFIG_BUILDERS.keys())


def _resolve_comparison(value: str) -> str:
    """Convert user-friendly comparison operator to API enum value."""
    result = _COMPARISON_MAP.get(value.lower().strip())
    if not result:
        raise click.BadParameter(f"Invalid comparison '{value}'. Use: >, <, >=, <=, = (or gt, lt, gte, lte, eq)")
    return result


def _parse_action(action_str: str) -> dict:
    """Parse action string 'type:config_value' into API action dict."""
    parts = action_str.split(":", 1)
    if len(parts) != 2:
        raise click.BadParameter(f"Invalid action format '{action_str}'. Use type:config (e.g. email:user@example.com)")
    action_type, config_value = parts[0].lower().strip(), parts[1].strip()
    builder = _ACTION_CONFIG_BUILDERS.get(action_type)
    if not builder:
        raise click.BadParameter(f"Unknown action type '{action_type}'. Valid types: {', '.join(_VALID_ACTION_TYPES)}")
    return {"type": action_type.upper(), "config": builder(config_value)}


def _resolve_alert_id(ctx, project_id: str | None = None) -> str:
    """Resolve alert ID interactively by listing existing alerts."""
    if not sys.stdin.isatty():
        raise click.ClickException("Missing --id.")

    # Need project_id to list alerts
    if not project_id:
        project_id = _resolve_project_id(ctx)

    caller = build_caller(ctx)
    try:
        result = caller.call("GET", "/v2/alertRules", body={"projectId": project_id, "pageSize": 100, "currentPage": 1})
        alerts = result.get("alertRules", []) if isinstance(result, dict) else []
    except (APIError, KeyError, TypeError):
        return click.prompt("  Alert rule ID", type=str).strip()

    if not alerts:
        return click.prompt("  Alert rule ID", type=str).strip()

    choices = []
    for a in alerts:
        aid = a.get("id", "")
        name = a.get("ruleName") or a.get("metricName", aid)
        enabled = a.get("enabled", False)
        status = "on" if enabled else "off"
        display = f"{name} [{status}] ({aid})"
        choices.append(questionary.Choice(title=display, value=aid))

    if len(choices) == 1:
        click.echo(f"  alert: {choices[0].title} (auto-selected)")
        return str(choices[0].value)

    selected = questionary.select("  Select alert rule:", choices=choices, use_shortcuts=True).ask()
    if selected is None:
        raise click.Abort()
    return str(selected)


def _resolve_project_id(ctx) -> str:
    """Resolve project ID interactively."""
    if not sys.stdin.isatty():
        raise click.ClickException("Missing --project-id.")

    caller = build_caller(ctx)
    try:
        result = caller.call("GET", "/v2/projects", return_raw=True)
        response_data = result.get("data", result) if isinstance(result, dict) else result
        items = (
            response_data
            if isinstance(response_data, list)
            else (response_data.get("projects", []) if response_data else [])
        )
    except (APIError, KeyError, TypeError):
        return click.prompt("  Project ID", type=str).strip()

    if not items:
        return click.prompt("  Project ID", type=str).strip()

    choices = []
    for item in items:
        pid = item.get("projectId", "")
        name = item.get("projectName", pid)
        if not pid:
            continue
        display = f"{name} ({pid})"
        choices.append(questionary.Choice(title=display, value=pid))

    if not choices:
        return click.prompt("  Project ID", type=str).strip()

    if len(choices) == 1:
        click.echo(f"  project: {choices[0].title} (auto-selected)")
        return str(choices[0].value)

    selected = questionary.select("  Select project:", choices=choices, use_shortcuts=True).ask()
    if selected is None:
        raise click.Abort()
    return str(selected)


def _print_alert_table(alerts: list):
    """Print alert rules as a Rich table."""
    if not alerts:
        click.echo("No alert rules found.")
        return

    table = Table(show_header=True, header_style="bold", padding=(0, 1))
    table.add_column("ID", no_wrap=True)
    table.add_column("Rule Name", no_wrap=True)
    table.add_column("Metric", no_wrap=True)
    table.add_column("Level", no_wrap=True)
    table.add_column("Enabled", no_wrap=True)
    table.add_column("Condition", no_wrap=True)
    table.add_column("Actions", no_wrap=True)

    for a in alerts:
        level = a.get("level", "-")
        level_style = "red" if level == "CRITICAL" else "yellow" if level == "WARNING" else ""
        enabled = a.get("enabled", False)
        enabled_style = "green" if enabled else "dim"

        threshold = a.get("threshold", "?")
        symbol = _COMPARISON_SYMBOLS.get(a.get("comparisonMethod", ""), "?")
        condition = f"{symbol} {threshold}"

        actions = a.get("actions") or []
        action_summary = ", ".join(str(ac.get("type", "?")).lower() for ac in actions) if actions else "-"

        table.add_row(
            a.get("id", "-"),
            a.get("ruleName", "-"),
            a.get("metricName", "-"),
            Text(level, style=level_style),
            Text(str(enabled).lower(), style=enabled_style),
            condition,
            action_summary,
        )

    Console().print(table)


# -- Command Group --


@click.group(cls=OrderedGroup)
def alert():
    """Manage alert rules for monitoring cluster metrics and billing."""
    pass


# -- list --

_LIST_EPILOG = """\b
Examples:
  $ zilliz alert list --project-id proj-xxxx
  $ zilliz alert list --project-id proj-xxxx --page-size 20 --page 2 -o json"""


@click.command(name="list", cls=GroupedCommand, epilog=_LIST_EPILOG)
@click.option("--project-id", default=None, help="Project ID (required by API).")
@click.option("--page-size", type=int, default=None, help="Items per page (default: 10).")
@click.option("--page", type=int, default=None, help="Page number (default: 1).")
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None, help="Output format.")
@click.pass_context
def list_alerts(ctx, project_id, page_size, page, output):
    """List alert rules for a project."""
    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)

    if not project_id:
        project_id = _resolve_project_id(ctx)

    caller = build_caller(ctx)
    stderr_console = Console(stderr=True)

    params = {"projectId": project_id}
    if page_size:
        params["pageSize"] = page_size
    if page:
        params["currentPage"] = page

    try:
        with stderr_console.status("[cyan]Loading...[/cyan]", spinner="dots"):
            result = caller.call("GET", "/v2/alertRules", body=params)

        if output_format != "table":
            click.echo(fmt.format_success(result))
            return

        alerts = result.get("alertRules", []) if isinstance(result, dict) else []
        _print_alert_table(alerts)

    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)


# -- create --

_CREATE_EPILOG = """\b
Examples:
  $ zilliz alert create --project-id proj-xxx --metric-name CU_COMPUTATION --threshold 80 --comparison ">"
  $ zilliz alert create --project-id proj-xxx --metric-name WALLET_BALANCE --threshold 100 \\
      --comparison "<" --level CRITICAL --action email:admin@example.com
  $ zilliz alert create --project-id proj-xxx --metric-name CU_COMPUTATION --threshold 90 \\
      --comparison ">=" --cluster-id in01-xxx --action slack:https://hooks.slack.com/xxx"""


@click.command(name="create", cls=GroupedCommand, epilog=_CREATE_EPILOG)
@click.option("--project-id", default=None, help="Project ID.")
@click.option("--metric-name", default=None, help="Metric to monitor (e.g. CU_COMPUTATION, WALLET_BALANCE).")
@click.option("--threshold", default=None, help="Threshold value.")
@click.option("--comparison", default=None, help="Comparison operator: >, <, >=, <=, = (or gt, lt, gte, lte, eq).")
@click.option("--rule-name", default=None, help="Display name for the alert rule.")
@click.option(
    "--level",
    type=click.Choice(["WARNING", "CRITICAL"], case_sensitive=False),
    default=None,
    help="Alert severity (default: WARNING).",
)
@click.option("--window-size", default=None, help="Monitoring window (e.g. 5m, 15m, 1h).")
@click.option("--cluster-id", multiple=True, help="Target cluster ID (repeatable).")
@click.option(
    "--action", multiple=True, help="Notification action as type:config (repeatable). e.g. email:user@example.com"
)
@click.option("--send-resolved/--no-send-resolved", default=None, help="Send notification when alert resolves.")
@click.option("--repeat-interval", type=int, default=None, help="Repeat notification interval in seconds.")
@click.option("--enabled/--no-enabled", default=None, help="Enable the rule (default: enabled).")
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None, help="Output format.")
@click.pass_context
def create_alert(
    ctx,
    project_id,
    metric_name,
    threshold,
    comparison,
    rule_name,
    level,
    window_size,
    cluster_id,
    action,
    send_resolved,
    repeat_interval,
    enabled,
    output,
):
    """Create a new alert rule."""
    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)

    # Resolve required params interactively if missing
    if not project_id:
        project_id = _resolve_project_id(ctx)

    if not metric_name:
        if not sys.stdin.isatty():
            raise click.ClickException("Missing --metric-name.")
        choices = [questionary.Choice(title=m, value=m) for m in _KNOWN_METRICS]
        metric_name = questionary.select("  Select metric:", choices=choices, use_shortcuts=True).ask()
        if metric_name is None:
            raise click.Abort()

    if not threshold:
        if not sys.stdin.isatty():
            raise click.ClickException("Missing --threshold.")
        threshold = click.prompt("  Threshold value", type=str).strip()

    if not comparison:
        if not sys.stdin.isatty():
            raise click.ClickException("Missing --comparison.")
        comp_choices = [
            questionary.Choice(title="> (greater than)", value=">"),
            questionary.Choice(title="< (less than)", value="<"),
            questionary.Choice(title=">= (greater than or equal)", value=">="),
            questionary.Choice(title="<= (less than or equal)", value="<="),
            questionary.Choice(title="= (equal)", value="="),
        ]
        comparison = questionary.select("  Comparison operator:", choices=comp_choices).ask()
        if comparison is None:
            raise click.Abort()

    try:
        comparison_method = _resolve_comparison(comparison)
    except click.BadParameter as e:
        click.echo(f"Error: {e.format_message()}", err=True)
        ctx.exit(1)
        return

    metric_upper = metric_name.upper()
    body = {
        "projectId": project_id,
        "metricName": metric_upper,
        "threshold": threshold,
        "comparisonMethod": comparison_method,
        "ruleName": rule_name or f"{metric_upper} alert",
        "level": (level or "WARNING").upper(),
    }
    if window_size:
        body["windowSize"] = window_size
    if cluster_id:
        body["targetInstanceIds"] = list(cluster_id)
    if action:
        try:
            body["actions"] = [_parse_action(a) for a in action]
        except click.BadParameter as e:
            click.echo(f"Error: {e.format_message()}", err=True)
            ctx.exit(1)
            return
    if send_resolved is not None:
        body["sendResolved"] = send_resolved
    if repeat_interval is not None:
        body["repeatIntervalSeconds"] = repeat_interval
    if enabled is not None:
        body["enabled"] = enabled

    caller = build_caller(ctx)
    stderr_console = Console(stderr=True)

    try:
        with stderr_console.status("[cyan]Creating alert rule...[/cyan]", spinner="dots"):
            result = caller.call("POST", "/v2/alertRules", body=body)

        if output_format != "table":
            click.echo(fmt.format_success(result))
        else:
            click.echo("Alert rule created successfully.")
            if isinstance(result, dict) and result.get("id"):
                click.echo(f"  ID: {result['id']}")

    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)


# -- update --

_UPDATE_EPILOG = """\b
Examples:
  $ zilliz alert update --id alert-xxx --threshold 90
  $ zilliz alert update --id alert-xxx --level CRITICAL --action email:new@example.com"""


@click.command(name="update", cls=GroupedCommand, epilog=_UPDATE_EPILOG)
@click.option("--id", "alert_id", default=None, help="Alert rule ID.")
@click.option("--project-id", default=None, help="Project ID (needed for interactive --id selection).")
@click.option("--rule-name", default=None, help="New display name.")
@click.option("--metric-name", default=None, help="New metric name.")
@click.option("--threshold", default=None, help="New threshold value.")
@click.option("--comparison", default=None, help="New comparison operator: >, <, >=, <=, =")
@click.option(
    "--level",
    type=click.Choice(["WARNING", "CRITICAL"], case_sensitive=False),
    default=None,
    help="New severity level.",
)
@click.option("--window-size", default=None, help="New monitoring window.")
@click.option("--cluster-id", multiple=True, help="Target cluster IDs (repeatable, replaces existing).")
@click.option("--action", multiple=True, help="Notification actions (repeatable, replaces existing).")
@click.option("--send-resolved/--no-send-resolved", default=None, help="Send resolved notifications.")
@click.option("--repeat-interval", type=int, default=None, help="New repeat interval in seconds.")
@click.option("--enabled/--no-enabled", default=None, help="Enable or disable the rule.")
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None, help="Output format.")
@click.pass_context
def update_alert(
    ctx,
    alert_id,
    project_id,
    rule_name,
    metric_name,
    threshold,
    comparison,
    level,
    window_size,
    cluster_id,
    action,
    send_resolved,
    repeat_interval,
    enabled,
    output,
):
    """Update an existing alert rule."""
    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)

    if not alert_id:
        alert_id = _resolve_alert_id(ctx, project_id)

    body = {}
    if rule_name is not None:
        body["ruleName"] = rule_name
    if metric_name is not None:
        body["metricName"] = metric_name.upper()
    if threshold is not None:
        body["threshold"] = threshold
    if comparison is not None:
        try:
            body["comparisonMethod"] = _resolve_comparison(comparison)
        except click.BadParameter as e:
            click.echo(f"Error: {e.format_message()}", err=True)
            ctx.exit(1)
            return
    if level is not None:
        body["level"] = level.upper()
    if window_size is not None:
        body["windowSize"] = window_size
    if cluster_id:
        body["targetInstanceIds"] = list(cluster_id)
    if action:
        try:
            body["actions"] = [_parse_action(a) for a in action]
        except click.BadParameter as e:
            click.echo(f"Error: {e.format_message()}", err=True)
            ctx.exit(1)
            return
    if send_resolved is not None:
        body["sendResolved"] = send_resolved
    if repeat_interval is not None:
        body["repeatIntervalSeconds"] = repeat_interval
    if enabled is not None:
        body["enabled"] = enabled

    if not body:
        click.echo("No fields to update. Specify at least one option.", err=True)
        ctx.exit(1)
        return

    caller = build_caller(ctx)
    stderr_console = Console(stderr=True)

    try:
        with stderr_console.status("[cyan]Updating alert rule...[/cyan]", spinner="dots"):
            result = caller.call("PUT", "/v2/alertRules/{id}", body=body, path_params={"id": alert_id})

        if output_format != "table":
            click.echo(fmt.format_success(result))
        else:
            click.echo(f"Alert rule {alert_id} updated successfully.")

    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)


# -- delete --

_DELETE_EPILOG = """\b
Examples:
  $ zilliz alert delete --id alert-xxx
  $ zilliz alert delete --id alert-xxx -y"""


@click.command(name="delete", cls=GroupedCommand, epilog=_DELETE_EPILOG)
@click.option("--id", "alert_id", default=None, help="Alert rule ID.")
@click.option("--project-id", default=None, help="Project ID (needed for interactive --id selection).")
@click.option("-y", "--yes", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None, help="Output format.")
@click.pass_context
def delete_alert(ctx, alert_id, project_id, yes, output):
    """Delete an alert rule."""
    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)

    if not alert_id:
        alert_id = _resolve_alert_id(ctx, project_id)

    if not yes:
        if not click.confirm(f"  Delete alert rule {alert_id}?"):
            click.echo("Cancelled.")
            return

    caller = build_caller(ctx)
    stderr_console = Console(stderr=True)

    try:
        with stderr_console.status("[cyan]Deleting alert rule...[/cyan]", spinner="dots"):
            caller.call("DELETE", "/v2/alertRules/{id}", path_params={"id": alert_id})

        click.echo(f"Alert rule {alert_id} deleted.")

    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)


# -- enable --

_ENABLE_EPILOG = """\b
Examples:
  $ zilliz alert enable --id alert-xxx"""


@click.command(name="enable", cls=GroupedCommand, epilog=_ENABLE_EPILOG)
@click.option("--id", "alert_id", default=None, help="Alert rule ID.")
@click.option("--project-id", default=None, help="Project ID (needed for interactive --id selection).")
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None, help="Output format.")
@click.pass_context
def enable_alert(ctx, alert_id, project_id, output):
    """Enable an alert rule."""
    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)

    if not alert_id:
        alert_id = _resolve_alert_id(ctx, project_id)

    caller = build_caller(ctx)
    stderr_console = Console(stderr=True)

    try:
        with stderr_console.status("[cyan]Enabling alert rule...[/cyan]", spinner="dots"):
            caller.call("PUT", "/v2/alertRules/{id}", body={"enabled": True}, path_params={"id": alert_id})

        click.echo(f"Alert rule {alert_id} enabled.")

    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)


# -- disable --

_DISABLE_EPILOG = """\b
Examples:
  $ zilliz alert disable --id alert-xxx"""


@click.command(name="disable", cls=GroupedCommand, epilog=_DISABLE_EPILOG)
@click.option("--id", "alert_id", default=None, help="Alert rule ID.")
@click.option("--project-id", default=None, help="Project ID (needed for interactive --id selection).")
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None, help="Output format.")
@click.pass_context
def disable_alert(ctx, alert_id, project_id, output):
    """Disable an alert rule."""
    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)

    if not alert_id:
        alert_id = _resolve_alert_id(ctx, project_id)

    caller = build_caller(ctx)
    stderr_console = Console(stderr=True)

    try:
        with stderr_console.status("[cyan]Disabling alert rule...[/cyan]", spinner="dots"):
            caller.call("PUT", "/v2/alertRules/{id}", body={"enabled": False}, path_params={"id": alert_id})

        click.echo(f"Alert rule {alert_id} disabled.")

    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)


# -- Register subcommands --

alert.add_command(list_alerts)
alert.add_command(create_alert)
alert.add_command(update_alert)
alert.add_command(delete_alert)
alert.add_command(enable_alert)
alert.add_command(disable_alert)

# Mark required options for GroupedCommand help display
_REQUIRED_OPTIONS_MAP = {
    list_alerts: {"--project-id"},
    create_alert: {"--project-id", "--metric-name", "--threshold", "--comparison"},
    update_alert: {"--id"},
    delete_alert: {"--id"},
    enable_alert: {"--id"},
    disable_alert: {"--id"},
}

for cmd, required_opts in _REQUIRED_OPTIONS_MAP.items():
    for param in cmd.params:
        if isinstance(param, click.Option):
            param._model_required = bool(set(param.opts) & required_opts)  # type: ignore[attr-defined]
