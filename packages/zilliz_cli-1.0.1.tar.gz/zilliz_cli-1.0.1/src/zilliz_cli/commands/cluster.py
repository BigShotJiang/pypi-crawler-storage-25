# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import sys

import click
import questionary
from rich.console import Console

from zilliz_cli.core.command_factory import GroupedCommand
from zilliz_cli.core.exceptions import APIError
from zilliz_cli.core.helpers import build_caller
from zilliz_cli.formatter.base import get_formatter

_CLUSTER_TYPE_PATHS = {
    "serverless": "/v2/clusters/createServerless",
    "free": "/v2/clusters/createFree",
    "dedicated": "/v2/clusters/createDedicated",
}

_REQUIRED_OPTIONS = {"--name", "--type", "--project-id", "--region"}


_CREATE_EPILOG = """\b
Examples:
  Dedicated cluster:
    zilliz cluster create --name my-cluster --type dedicated --project-id proj-xxxx --region aws-us-west-2 --cu-type Performance-optimized --cu-size 1

  Serverless cluster:
    zilliz cluster create --name my-cluster --type serverless --project-id proj-xxxx --region aws-us-west-2

  Free-tier cluster:
    zilliz cluster create --name my-cluster --type free --project-id proj-xxxx --region gcp-us-west1"""


@click.command(name="create", cls=GroupedCommand, epilog=_CREATE_EPILOG)
@click.option("--name", help="cluster display name")
@click.option(
    "--type",
    "cluster_type",
    type=click.Choice(["serverless", "free", "dedicated"], case_sensitive=False),
    metavar="[serverless|free|dedicated]",
    help="cluster type",
)
@click.option("--project-id", help="project to create the cluster in")
@click.option("--region", help="cloud region (e.g. aws-us-west-2)")
@click.option(
    "--cu-type",
    type=click.Choice(["Performance-optimized", "Capacity-optimized"], case_sensitive=False),
    metavar="TYPE",
    default=None,
    help="compute unit type (dedicated only)  [Performance-optimized, Capacity-optimized]",
)
@click.option("--cu-size", type=int, default=None, help="number of compute units (dedicated only)")
@click.option(
    "--plan",
    type=click.Choice(["Free", "Serverless", "Standard", "Enterprise"], case_sensitive=False),
    metavar="PLAN",
    default=None,
    help="subscription plan (dedicated only)  [Free, Serverless, Standard, Enterprise]",
)
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None, help="Output format.")
@click.pass_context
def create_cluster(ctx, name, cluster_type, project_id, region, cu_type, cu_size, plan, output):
    """Create a new cluster."""
    # Validate required params - prompt interactively if missing
    missing = []
    if not name:
        missing.append("--name")
    if not cluster_type:
        missing.append("--type")
    if not project_id:
        missing.append("--project-id")
    if not region:
        missing.append("--region")

    if missing and not sys.stdin.isatty():
        raise click.ClickException(f"Missing required options: {', '.join(missing)}")

    if missing:
        caller = build_caller(ctx)
        click.echo("Please provide the required parameters:\n")
        if not name:
            name = click.prompt("  clusterName", type=str).strip()
        if not cluster_type:
            cluster_type = questionary.select(
                "  Select cluster type:",
                choices=["serverless", "free", "dedicated"],
                use_shortcuts=True,
            ).ask()
            if cluster_type is None:
                raise click.Abort()
        if not project_id:
            project_id = _prompt_select(
                caller, "project", "GET", "/v2/projects", "data", "projectId", "projectName", ["plan"]
            )
        if not region:
            region = _prompt_select(caller, "region", "GET", "/v2/regions", "data", "regionId", "regionId")
        click.echo()

    cluster_type = cluster_type.lower()

    # Validate dedicated-only params
    if cluster_type == "dedicated":
        if not cu_type or not cu_size:
            if not sys.stdin.isatty():
                missing_ded = []
                if not cu_type:
                    missing_ded.append("--cu-type")
                if not cu_size:
                    missing_ded.append("--cu-size")
                raise click.ClickException(f"Missing required options for dedicated clusters: {', '.join(missing_ded)}")
            if not cu_type:
                cu_type = questionary.select(
                    "  Select cuType:",
                    choices=[
                        questionary.Choice("Performance-optimized (recommended)", value="Performance-optimized"),
                        questionary.Choice("Capacity-optimized (more storage)", value="Capacity-optimized"),
                    ],
                    use_shortcuts=True,
                ).ask()
                if cu_type is None:
                    raise click.Abort()
            if not cu_size:
                cu_size = click.prompt("  cuSize", type=int)

    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)
    if not missing:
        caller = build_caller(ctx)

    body = {
        "clusterName": name,
        "projectId": project_id,
        "regionId": region,
    }

    if cluster_type == "dedicated":
        body["cuType"] = cu_type
        body["cuSize"] = cu_size
        if plan:
            body["plan"] = plan

    path = _CLUSTER_TYPE_PATHS[cluster_type]

    stderr_console = Console(stderr=True)
    try:
        with stderr_console.status("[cyan]Loading...[/cyan]", spinner="dots"):
            result = caller.call("POST", path, body=body, path_params={})
        click.echo(fmt.format_success(result))
    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)


def _prompt_select(caller, label, method, path, data_field, id_field, name_field, extra_fields=None):
    """Fetch options from API and present a selection list."""
    try:
        result = caller.call(method, path, return_raw=True)
        response_data = result.get("data", result) if isinstance(result, dict) else result
        items = response_data if isinstance(response_data, list) else response_data.get(data_field, [])

        if not items:
            return click.prompt(f"  {label}Id", type=str).strip()

        choices = []
        for item in items:
            item_id = item.get(id_field)
            item_name = item.get(name_field, item_id)
            if not item_id:
                continue
            extra_parts = [str(item[f]) for f in (extra_fields or []) if item.get(f)]
            if extra_parts:
                display = f"{item_name} [{', '.join(extra_parts)}] ({item_id})"
            elif item_name != item_id:
                display = f"{item_name} ({item_id})"
            else:
                display = item_id
            choices.append(questionary.Choice(title=display, value=item_id))

        if not choices:
            return click.prompt(f"  {label}Id", type=str).strip()

        if len(choices) == 1:
            click.echo(f"  {label}: {choices[0].title} (auto-selected)")
            return choices[0].value

        selected = questionary.select(f"  Select {label}:", choices=choices, use_shortcuts=True).ask()
        if selected is None:
            raise click.Abort()
        return selected
    except (APIError, KeyError, TypeError, ValueError):
        return click.prompt(f"  {label}Id", type=str).strip()


# Mark required options for GroupedCommand section grouping
for param in create_cluster.params:
    if isinstance(param, click.Option):
        decls = set(param.opts)
        param._model_required = bool(decls & _REQUIRED_OPTIONS)  # type: ignore[attr-defined]
