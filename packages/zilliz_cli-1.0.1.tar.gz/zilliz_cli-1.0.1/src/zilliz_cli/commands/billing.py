# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import re
from datetime import datetime, timedelta, timezone

import click
from rich.console import Console
from rich.table import Table
from rich.text import Text

from zilliz_cli.core.exceptions import APIError
from zilliz_cli.core.helpers import build_caller
from zilliz_cli.formatter.base import get_formatter


def _parse_relative(value: str) -> timedelta:
    """Parse relative duration like '7d', '30d', '3m', '1y'."""
    m = re.fullmatch(r"(\d+)([dmyDMY])", value)
    if not m:
        raise click.BadParameter(f"Invalid duration '{value}'. Use format like: 7d, 30d, 3m, 1y")
    num = int(m.group(1))
    unit = m.group(2).lower()
    if unit == "d":
        return timedelta(days=num)
    if unit == "m":
        return timedelta(days=num * 30)
    if unit == "y":
        return timedelta(days=num * 365)
    raise click.BadParameter(f"Unknown unit '{unit}'")


def _parse_month(value: str) -> tuple[str, str]:
    """Parse month specifier into (start, end) ISO-8601 strings.

    Supports: '2026-01', 'last', 'this'
    """
    now = datetime.now(timezone.utc)

    if value == "this":
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        # end = now (up to current moment)
        end = now
    elif value == "last":
        first_of_this = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        end = first_of_this
        start = (first_of_this - timedelta(days=1)).replace(day=1)
    else:
        m = re.fullmatch(r"(\d{4})-(\d{2})", value)
        if not m:
            raise click.BadParameter(f"Invalid month '{value}'. Use format: 2026-01, 'last', or 'this'")
        year, month = int(m.group(1)), int(m.group(2))
        start = datetime(year, month, 1, tzinfo=timezone.utc)
        if month == 12:
            end = datetime(year + 1, 1, 1, tzinfo=timezone.utc)
        else:
            end = datetime(year, month + 1, 1, tzinfo=timezone.utc)

    return start.strftime("%Y-%m-%dT%H:%M:%SZ"), end.strftime("%Y-%m-%dT%H:%M:%SZ")


def _resolve_time_range(last, month, start, end) -> tuple[str, str]:
    """Resolve the time range from the various input options.

    Priority: --last > --month > --start/--end > default (today)
    """
    now = datetime.now(timezone.utc)

    if last:
        delta = _parse_relative(last)
        t_end = now
        t_start = now - delta
        return (
            t_start.strftime("%Y-%m-%dT%H:%M:%SZ"),
            t_end.strftime("%Y-%m-%dT%H:%M:%SZ"),
        )

    if month:
        return _parse_month(month)

    if start or end:
        if not start or not end:
            raise click.UsageError("--start and --end must be used together.")
        # Allow short date format: 2026-01-01 -> 2026-01-01T00:00:00Z
        for label, val in [("--start", start), ("--end", end)]:
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", val):
                continue
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z?", val):
                continue
            raise click.BadParameter(f"Invalid date for {label}: {val}. Use YYYY-MM-DD or ISO-8601.")
        if not start.endswith("Z") and "T" not in start:
            start = start + "T00:00:00Z"
        if not end.endswith("Z") and "T" not in end:
            end = end + "T00:00:00Z"
        if not start.endswith("Z"):
            start = start + "Z"
        if not end.endswith("Z"):
            end = end + "Z"
        return start, end

    # Default: today
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    return (
        today_start.strftime("%Y-%m-%dT%H:%M:%SZ"),
        now.strftime("%Y-%m-%dT%H:%M:%SZ"),
    )


@click.command(
    epilog="\b\nExamples:\n"
    "  $ zilliz billing usage                              # today\n"
    "  $ zilliz billing usage --last 7d                    # last 7 days\n"
    "  $ zilliz billing usage --last 30d                   # last 30 days\n"
    "  $ zilliz billing usage --month 2026-01              # January 2026\n"
    "  $ zilliz billing usage --month last                 # last month\n"
    "  $ zilliz billing usage --start 2026-01-01 --end 2026-02-01\n"
)
@click.option("--last", default=None, help="Relative time range: d=days, m=30d, y=365d (e.g. 7d, 3m).")
@click.option("--month", default=None, help="Query by month (e.g. 2026-01, 'last', 'this').")
@click.option("--start", default=None, help="Start date (YYYY-MM-DD or ISO-8601).")
@click.option("--end", default=None, help="End date (YYYY-MM-DD or ISO-8601).")
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None, help="Output format.")
@click.pass_context
def usage(ctx, last, month, start, end, output):
    """Query usage costs for a time range. Defaults to today."""
    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)
    caller = build_caller(ctx)

    start_time, end_time = _resolve_time_range(last, month, start, end)

    stderr_console = Console(stderr=True)

    try:
        with stderr_console.status("[cyan]Loading...[/cyan]", spinner="dots"):
            result = caller.call(
                "POST",
                "/v2/usage/query",
                body={"start": start_time, "end": end_time},
                path_params={},
            )

        if output_format != "table":
            click.echo(fmt.format_success(result))
            return

        _print_usage_table(result)

    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)


def _format_amount(value) -> str:
    """Format a monetary amount."""
    if value is None:
        return "-"
    v = float(value)
    if v == 0:
        return "$0.00"
    if v < 0.01:
        return f"${v:.4f}"
    return f"${v:,.2f}"


def _format_date(iso_str: str) -> str:
    """Extract date part from ISO-8601 string."""
    return iso_str[:10] if iso_str else "-"


def _display_id(full_id: str | None) -> str:
    """Return ID for display, or dash if empty."""
    return full_id if full_id else "-"


def _print_usage_table(result: dict):
    """Print usage data as a readable Rich table."""
    results = result.get("results", [])

    # Filter out zero-usage days
    non_zero = [r for r in results if float(r.get("total", 0)) > 0]

    if not non_zero:
        click.echo("No usage in this period.")
        return

    table = Table(show_header=True, header_style="bold", padding=(0, 1))
    table.add_column("Date", style="cyan", no_wrap=True)
    table.add_column("Type", no_wrap=True)
    table.add_column("Detail", no_wrap=True)
    table.add_column("Unit Price", justify="right", no_wrap=True)
    table.add_column("Amount", justify="right", style="green", no_wrap=True)
    table.add_column("Resource", no_wrap=True)

    grand_total = 0.0

    for day in non_zero:
        date_str = _format_date(day.get("intervalStart", ""))
        day_total = float(day.get("total", 0))
        grand_total += day_total
        items = day.get("items", [])

        for i, item in enumerate(items):
            props = item.get("properties", {})
            cost_type = item.get("costType", "-")
            quantity = item.get("quantity", 0)
            unit = item.get("unit", "")
            amount = float(item.get("amount", 0))
            price_obj = item.get("price", {}) or {}
            unit_price = price_obj.get("unitPrice")

            # First item of the day shows the date, rest show empty
            show_date = date_str if i == 0 else ""

            qty_str = f"{quantity:g} {unit}"
            up_str = f"${float(unit_price):g}/{unit}" if unit_price else "-"

            cluster_id = props.get("clusterId")
            project_id = props.get("projectId")
            cu_type = props.get("cuType")
            identifier = cluster_id or project_id or "-"
            if cu_type:
                # Shorten common cuType names for compact display
                short_cu = cu_type.replace("Performance-optimized", "Perf").replace("Capacity-optimized", "Cap")
                identifier += f" [{short_cu}]"

            table.add_row(
                show_date,
                cost_type,
                qty_str,
                up_str,
                _format_amount(amount),
                identifier,
            )

        # Add separator between days if multiple items
        if len(items) > 1:
            table.add_row(
                "",
                "",
                "",
                "",
                Text("subtotal", style="dim"),
                Text(_format_amount(day_total), style="bold green"),
            )

    # Grand total
    table.add_section()
    table.add_row(
        "",
        "",
        "",
        "",
        Text("Total", style="bold"),
        Text(_format_amount(grand_total), style="bold green"),
    )

    stdout_console = Console()
    stdout_console.print(table)


# -- invoices command (list + describe in one) --


@click.command(
    epilog="\b\nExamples:\n"
    "  $ zilliz billing invoices                                 # list all\n"
    "  $ zilliz billing invoices --all                           # fetch all pages\n"
    "  $ zilliz billing invoices --invoice-id inv-xxxxxxxxxxxx   # get details\n"
)
@click.option("--invoice-id", default=None, help="Invoice ID. If provided, show details of this invoice.")
@click.option("--page-size", type=int, default=None, help="Number of items per page.")
@click.option("--page", type=int, default=None, help="Page number to retrieve.")
@click.option("--all", "-a", "fetch_all", is_flag=True, default=False, help="Fetch all pages.")
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None, help="Output format.")
@click.pass_context
def invoices(ctx, invoice_id, page_size, page, fetch_all, output):
    """List invoices, or get details of a specific invoice."""
    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)
    caller = build_caller(ctx)

    stderr_console = Console(stderr=True)

    try:
        if invoice_id:
            # Describe single invoice
            with stderr_console.status("[cyan]Loading...[/cyan]", spinner="dots"):
                result = caller.call("GET", f"/v2/invoices/{invoice_id}", body={}, path_params={})
            if output_format != "table":
                click.echo(fmt.format_success(result))
            else:
                _print_invoice_detail(result)
        elif fetch_all:
            # Fetch all pages
            all_invoices = []
            current_page = 1
            size = page_size or 20
            while True:
                with stderr_console.status("[cyan]Loading...[/cyan]", spinner="dots"):
                    result = caller.call(
                        "GET",
                        "/v2/invoices",
                        body={"pageSize": size, "currentPage": current_page},
                        path_params={},
                    )
                items = result.get("invoices", [])
                all_invoices.extend(items)
                total = int(result.get("count", 0) or 0)
                if current_page * size >= total or not items:
                    break
                current_page += 1
            if output_format != "table":
                click.echo(fmt.format_success(all_invoices))
            else:
                _print_invoice_list(all_invoices)
        else:
            # List with pagination (server requires pageSize and currentPage)
            body = {
                "pageSize": page_size or 20,
                "currentPage": page or 1,
            }
            with stderr_console.status("[cyan]Loading...[/cyan]", spinner="dots"):
                result = caller.call("GET", "/v2/invoices", body=body, path_params={})
            invoice_list = result.get("invoices", [])
            if output_format != "table":
                click.echo(fmt.format_success(invoice_list))
            else:
                _print_invoice_list(invoice_list)
    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)


# -- Invoice status styling --

_STATUS_STYLES = {
    "paid": "green",
    "unbilled": "cyan",
    "unpaid": "yellow",
    "overdue": "red",
    "void": "dim",
}


def _cents_to_dollars(cents) -> str:
    """Convert cents (Long) to dollar string."""
    if cents is None:
        return "$0.00"
    v = float(cents) / 100
    if v == 0:
        return "$0.00"
    return f"${v:,.2f}"


def _print_invoice_list(invoice_list: list):
    """Print invoices as a readable table."""
    if not invoice_list:
        click.echo("No invoices found.")
        return

    table = Table(show_header=True, header_style="bold", padding=(0, 1))
    table.add_column("Invoice ID", no_wrap=True)
    table.add_column("Period", no_wrap=True)
    table.add_column("Status", no_wrap=True)
    table.add_column("Amount Due", justify="right", style="green", no_wrap=True)
    table.add_column("Due Date", no_wrap=True)

    for inv in invoice_list:
        status = inv.get("status", "-")
        style = _STATUS_STYLES.get(status, "")

        # Compact period: just show start month (YYYY-MM)
        period_start = inv.get("periodStart", "")[:7]  # "2026-03"
        period_end = inv.get("periodEnd", "")[:7]
        period = f"{period_start} ~ {period_end}" if period_start != period_end else period_start

        table.add_row(
            inv.get("id", "-"),
            period,
            Text(status, style=style),
            _cents_to_dollars(inv.get("amountDue")),
            _format_date(inv.get("dueDate", "")),
        )

    Console().print(table)


def _print_invoice_detail(inv: dict):
    """Print single invoice detail as key-value pairs."""
    table = Table(show_header=False, padding=(0, 2), box=None)
    table.add_column("Field", style="bold", no_wrap=True)
    table.add_column("Value")

    status = inv.get("status", "-")
    style = _STATUS_STYLES.get(status, "")

    table.add_row("Invoice ID", inv.get("id", "-"))
    table.add_row("Status", Text(status, style=style))
    table.add_row("Period", f"{_format_date(inv.get('periodStart', ''))} ~ {_format_date(inv.get('periodEnd', ''))}")
    table.add_row("Invoice Date", _format_date(inv.get("invoiceDate", "")))
    table.add_row("Due Date", _format_date(inv.get("dueDate", "")))
    table.add_row("Currency", inv.get("currency", "-"))
    table.add_row("", "")
    table.add_row("Usage", _cents_to_dollars(inv.get("usageAmount")))
    table.add_row("Credits Applied", _cents_to_dollars(inv.get("creditsApplied")))
    table.add_row("Already Billed", _cents_to_dollars(inv.get("alreadyBilledAmount")))
    table.add_row("Subtotal", _cents_to_dollars(inv.get("subtotal")))
    table.add_row("Tax", _cents_to_dollars(inv.get("tax")))
    table.add_row("Total", Text(_cents_to_dollars(inv.get("total")), style="bold"))
    table.add_row("Advance Pay", _cents_to_dollars(inv.get("advancePayAmount")))
    table.add_row("Amount Due", Text(_cents_to_dollars(inv.get("amountDue")), style="bold green"))

    Console().print(table)
