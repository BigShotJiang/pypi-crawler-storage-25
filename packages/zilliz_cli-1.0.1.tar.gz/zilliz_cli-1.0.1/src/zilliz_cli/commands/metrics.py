# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import re
import sys
from datetime import datetime

import click
import questionary
from rich.console import Console
from rich.table import Table

from zilliz_cli.auth.config import get_config_manager
from zilliz_cli.core.command_factory import GroupedCommand
from zilliz_cli.core.exceptions import APIError
from zilliz_cli.core.helpers import build_caller
from zilliz_cli.formatter.base import get_formatter

# CLI-friendly name -> backend metric name
_METRIC_MAP = {
    # --- Resource ---
    "CU_COMPUTATION": "CU_COMPUTATION",
    "CU_CAPACITY": "CU_CAPACITY",
    "CU_SIZE": "CU_SIZE",
    "REPLICA_COUNT": "REPLICA_COUNT",
    "STORAGE": "STORAGE_USE",
    # --- QPS ---
    "SEARCH_QPS": "REQ_SEARCH_COUNT",
    "QUERY_QPS": "REQ_QUERY_COUNT",
    "INSERT_QPS": "REQ_INSERT_COUNT",
    "UPSERT_QPS": "REQ_UPSERT_COUNT",
    "DELETE_QPS": "REQ_DELETE_COUNT",
    "BULK_INSERT_QPS": "REQ_BULK_INSERT_COUNT",
    # --- Latency ---
    "SEARCH_LATENCY_AVG": "REQ_SEARCH_LATENCY_AVG",
    "SEARCH_LATENCY_P99": "REQ_SEARCH_LATENCY_P99",
    "QUERY_LATENCY_AVG": "REQ_QUERY_LATENCY_AVG",
    "QUERY_LATENCY_P99": "REQ_QUERY_LATENCY_P99",
    "INSERT_LATENCY_AVG": "REQ_INSERT_LATENCY_AVG",
    "INSERT_LATENCY_P99": "REQ_INSERT_LATENCY_P99",
    "UPSERT_LATENCY_AVG": "REQ_UPSERT_LATENCY_AVG",
    "UPSERT_LATENCY_P99": "REQ_UPSERT_LATENCY_P99",
    "DELETE_LATENCY_AVG": "REQ_DELETE_LATENCY_AVG",
    "DELETE_LATENCY_P99": "REQ_DELETE_LATENCY_P99",
    # --- VPS (vectors per second) ---
    "SEARCH_VPS": "VECTOR_REQ_SEARCH_COUNT",
    "INSERT_VPS": "VECTOR_REQ_INSERT_COUNT",
    "UPSERT_VPS": "VECTOR_REQ_UPSERT_COUNT",
    "DELETE_VPS": "VECTOR_REQ_DELETE_COUNT",
    "BULK_INSERT_VPS": "VECTOR_REQ_BULK_INSERT_COUNT",
    # --- Failure Rate ---
    "SEARCH_FAIL_RATE": "REQ_FAIL_RATE_SEARCH",
    "QUERY_FAIL_RATE": "REQ_FAIL_RATE_QUERY",
    "INSERT_FAIL_RATE": "REQ_FAIL_RATE_INSERT",
    "UPSERT_FAIL_RATE": "REQ_FAIL_RATE_UPSERT",
    "DELETE_FAIL_RATE": "REQ_FAIL_RATE_DELETE",
    "BULK_INSERT_FAIL_RATE": "REQ_FAIL_RATE_BULK_INSERT",
    # --- Data ---
    "ENTITIES": "ENTITIES_COUNT",
    "ENTITIES_LOADED": "ENTITIES_LOADED",
    "ENTITIES_INDEXED": "ENTITIES_INDEXED",
    "COLLECTIONS": "COLLECTIONS_COUNT",
    "SLOW_QUERIES": "SLOW_QUERY_COUNT",
    # --- Serverless (FreeTier + Serverless only) ---
    "READ_VCU": "READ_VCU",
    "WRITE_VCU": "WRITE_VCU",
}

_VALID_METRICS = list(_METRIC_MAP.keys())

# Grouped for interactive selection and help display
_METRIC_GROUPS = [
    ("Resource", ["CU_COMPUTATION", "CU_CAPACITY", "CU_SIZE", "REPLICA_COUNT", "STORAGE"]),
    ("QPS", ["SEARCH_QPS", "QUERY_QPS", "INSERT_QPS", "UPSERT_QPS", "DELETE_QPS", "BULK_INSERT_QPS"]),
    (
        "Latency",
        [
            "SEARCH_LATENCY_AVG",
            "SEARCH_LATENCY_P99",
            "QUERY_LATENCY_AVG",
            "QUERY_LATENCY_P99",
            "INSERT_LATENCY_AVG",
            "INSERT_LATENCY_P99",
            "UPSERT_LATENCY_AVG",
            "UPSERT_LATENCY_P99",
            "DELETE_LATENCY_AVG",
            "DELETE_LATENCY_P99",
        ],
    ),
    ("VPS (vectors/sec)", ["SEARCH_VPS", "INSERT_VPS", "UPSERT_VPS", "DELETE_VPS", "BULK_INSERT_VPS"]),
    (
        "Failure Rate",
        [
            "SEARCH_FAIL_RATE",
            "QUERY_FAIL_RATE",
            "INSERT_FAIL_RATE",
            "UPSERT_FAIL_RATE",
            "DELETE_FAIL_RATE",
            "BULK_INSERT_FAIL_RATE",
        ],
    ),
    ("Data", ["ENTITIES", "ENTITIES_LOADED", "ENTITIES_INDEXED", "COLLECTIONS", "SLOW_QUERIES"]),
    ("Serverless", ["READ_VCU", "WRITE_VCU"]),
]


def _human_to_iso_duration(value: str) -> str:
    """Convert human-friendly duration to ISO 8601 duration.

    Examples: '30s' -> 'PT30S', '5m' -> 'PT5M', '1h' -> 'PT1H', '7d' -> 'PT168H'

    Days are normalized to hours because the backend API uses PT (time) durations.
    Not reusing billing's _parse_relative because 'm' means months there vs minutes here.
    """
    m = re.fullmatch(r"(\d+)([smhdSMHD])", value)
    if not m:
        raise click.BadParameter(f"Invalid duration '{value}'. Use format like: 30s, 5m, 1h, 24h, 7d")
    num = int(m.group(1))
    unit = m.group(2).lower()
    if unit == "s":
        return f"PT{num}S"
    if unit == "m":
        return f"PT{num}M"
    if unit == "h":
        return f"PT{num}H"
    if unit == "d":
        return f"PT{num * 24}H"
    raise click.BadParameter(f"Unknown unit '{unit}'")


def _iso_duration_to_hours(iso: str) -> float:
    """Convert ISO 8601 PT duration to approximate hours for granularity calculation."""
    m = re.fullmatch(r"PT(\d+)([SMH])", iso)
    if not m:
        return 1.0
    num = int(m.group(1))
    unit = m.group(2)
    if unit == "S":
        return num / 3600
    if unit == "M":
        return num / 60
    return float(num)


def _default_granularity(period_iso: str | None, start: str | None, end: str | None) -> str:
    """Pick a sensible default granularity based on the time range.

    The backend requires granularity. We auto-select to keep ~60-200 data points.
    """
    if period_iso:
        hours = _iso_duration_to_hours(period_iso)
    elif start and end:
        try:
            s = datetime.fromisoformat(start.replace("Z", "+00:00"))
            e = datetime.fromisoformat(end.replace("Z", "+00:00"))
            hours = (e - s).total_seconds() / 3600
        except (ValueError, TypeError):
            hours = 1.0
    else:
        hours = 1.0

    if hours <= 1:
        return "PT1M"
    if hours <= 6:
        return "PT5M"
    if hours <= 24:
        return "PT15M"
    if hours <= 168:  # 7 days
        return "PT1H"
    return "PT6H"


def _resolve_metrics_time_range(
    period: str | None,
    start: str | None,
    end: str | None,
) -> tuple[str | None, str | None, str | None]:
    """Resolve time range for metrics query.

    Returns (start_iso, end_iso, period_iso).
    The backend accepts either period (relative to now) OR start+end (absolute range).
    """
    if period and (start or end):
        raise click.UsageError("Cannot use --period with --start/--end. Choose one.")

    if period:
        return None, None, _human_to_iso_duration(period)

    if start or end:
        if not start or not end:
            raise click.UsageError("--start and --end must be used together.")
        # Normalize to full ISO 8601 with Z suffix
        start = _normalize_timestamp(start, "--start")
        end = _normalize_timestamp(end, "--end")
        return start, end, None

    # Default: last 1 hour
    return None, None, "PT1H"


def _normalize_timestamp(value: str, label: str) -> str:
    """Normalize a timestamp to full ISO 8601 format."""
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        return value + "T00:00:00Z"
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z?", value):
        return value if value.endswith("Z") else value + "Z"
    raise click.BadParameter(
        f"Invalid timestamp for {label}: {value}. Use ISO 8601 format: YYYY-MM-DD or YYYY-MM-DDTHH:MM:SSZ"
    )


def _format_timestamp(ts: str) -> str:
    """Format ISO timestamp as 'MM-DD HH:MM:SS' for compact display."""
    if not ts:
        return "-"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%m-%d %H:%M:%S")
    except (ValueError, TypeError):
        return ts


def _format_metric_value(value: str) -> str:
    """Format metric value for display."""
    if value is None or value == "-" or value == "":
        return "-"
    try:
        v = float(value)
        if v == int(v) and abs(v) < 1e9:
            return f"{int(v)}"
        if abs(v) < 0.01 and v != 0:
            return f"{v:.4f}"
        return f"{v:,.2f}"
    except (ValueError, TypeError):
        return str(value)


def _print_metrics_table(result: dict):
    """Print metrics time-series data as a Rich table."""
    results = result.get("results") if isinstance(result, dict) else None
    if not results:
        click.echo("No metrics data available.")
        return

    table = Table(show_header=True, header_style="bold", padding=(0, 1))
    table.add_column("Timestamp", style="cyan", no_wrap=True)

    for metric_result in results:
        name = metric_result.get("name", "?")
        unit = metric_result.get("unit", "")
        header = f"{name} ({unit})" if unit else name
        table.add_column(header, justify="right", no_wrap=True)

    # Collect and sort all unique timestamps
    ts_set: set[str] = set()
    for metric_result in results:
        for v in metric_result.get("values", []):
            ts_set.add(v.get("timestamp", ""))
    sorted_ts = sorted(ts_set)

    # Build lookup: metric_name -> {timestamp -> value}
    metric_lookup: dict[str, dict[str, str]] = {}
    for metric_result in results:
        name = metric_result.get("name", "?")
        metric_lookup[name] = {v.get("timestamp", ""): v.get("value", "-") for v in metric_result.get("values", [])}

    for ts in sorted_ts:
        row = [_format_timestamp(ts)]
        for metric_result in results:
            name = metric_result.get("name", "?")
            value = metric_lookup.get(name, {}).get(ts, "-")
            row.append(_format_metric_value(value))
        table.add_row(*row)

    Console().print(table)


def _resolve_cluster_id(ctx) -> str:
    """Resolve cluster ID: CLI flag > context > interactive prompt."""
    mgr = get_config_manager(ctx.obj)
    context_data = mgr.get_context()
    context_cluster = context_data.get("cluster_id")

    if context_cluster:
        click.echo(f"  Using cluster from context: {context_cluster}")
        return context_cluster

    if not sys.stdin.isatty():
        raise click.ClickException("Missing --cluster-id and no context set.")

    caller = build_caller(ctx)
    try:
        result = caller.call("GET", "/v2/clusters", return_raw=True)
        response_data = result.get("data", result) if isinstance(result, dict) else result
        items = (
            response_data
            if isinstance(response_data, list)
            else (response_data.get("clusters", []) if response_data else [])
        )

        if not items:
            return click.prompt("  clusterId", type=str).strip()

        choices = []
        for item in items:
            cid = item.get("clusterId")
            name = item.get("clusterName", cid)
            status = item.get("status", "")
            if not cid:
                continue
            display = f"{name} [{status}] ({cid})" if status else f"{name} ({cid})"
            choices.append(questionary.Choice(title=display, value=cid))

        if not choices:
            return click.prompt("  clusterId", type=str).strip()

        if len(choices) == 1:
            click.echo(f"  cluster: {choices[0].title} (auto-selected)")
            return str(choices[0].value)

        selected = questionary.select("  Select cluster:", choices=choices, use_shortcuts=True).ask()
        if selected is None:
            raise click.Abort()
        return selected
    except (APIError, KeyError, TypeError, ValueError):
        return click.prompt("  clusterId", type=str).strip()


def _resolve_metrics_list(ctx) -> tuple[str, ...]:
    """Resolve metrics list interactively when not provided."""
    if not sys.stdin.isatty():
        raise click.ClickException("Missing --metric / -m.")

    choices: list = []
    for group_name, metric_names in _METRIC_GROUPS:
        choices.append(questionary.Separator(f"── {group_name} ──"))
        for m in metric_names:
            choices.append(questionary.Choice(title=m, value=m))

    selected = questionary.checkbox("  Select metric(s):", choices=choices).ask()
    if not selected:
        raise click.Abort()
    return tuple(selected)


def _build_metrics_epilog() -> str:
    lines = ["\b", "Available metrics:"]
    for group_name, metric_names in _METRIC_GROUPS:
        lines.append(f"  {group_name}:")
        lines.append(f"    {', '.join(metric_names)}")
    lines.append("")
    lines.append("Examples:")
    lines.append("  $ zilliz cluster metrics --cluster-id in01-xxx -m SEARCH_QPS")
    lines.append("  $ zilliz cluster metrics --cluster-id in01-xxx -m SEARCH_QPS -m SEARCH_LATENCY_P99 --period 24h")
    lines.append("  $ zilliz cluster metrics --cluster-id in01-xxx -m CU_COMPUTATION --period 7d -g 1h")
    lines.append("  $ zilliz cluster metrics --cluster-id in01-xxx -m STORAGE --start 2026-03-01 --end 2026-03-15")
    return "\n".join(lines)


_METRICS_EPILOG = _build_metrics_epilog()


@click.command(name="metrics", cls=GroupedCommand, epilog=_METRICS_EPILOG)
@click.option("--cluster-id", default=None, help="Cluster ID (e.g. in01-xxxxxxxxxxxx).")
@click.option(
    "--metric",
    "-m",
    "metrics_list",
    multiple=True,
    type=click.Choice(_VALID_METRICS, case_sensitive=False),
    metavar="METRIC",
    help="Metric name(s). Can be repeated. See available metrics below.",
)
@click.option("--period", default=None, help="Relative time period from now (e.g. 1h, 24h, 7d). Default: 1h.")
@click.option("--start", default=None, help="Start time, e.g. 2026-03-01 or 2026-03-01T10:00:00Z.")
@click.option("--end", default=None, help="End time, e.g. 2026-03-15 or 2026-03-15T18:00:00Z.")
@click.option("--granularity", "-g", default=None, help="Data point interval (e.g. 30s, 5m, 1h). Default: auto.")
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None, help="Output format.")
@click.pass_context
def metrics(ctx, cluster_id, metrics_list, period, start, end, granularity, output):
    """Query cluster performance metrics (QPS, latency, storage, etc.)."""
    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)

    # Resolve cluster-id: flag > context > interactive
    if not cluster_id:
        cluster_id = _resolve_cluster_id(ctx)

    # Resolve metrics: flag > interactive
    if not metrics_list:
        metrics_list = _resolve_metrics_list(ctx)

    try:
        start_time, end_time, period_iso = _resolve_metrics_time_range(period, start, end)
    except (click.UsageError, click.BadParameter) as e:
        click.echo(f"Error: {e.format_message()}", err=True)
        ctx.exit(1)
        return

    # Parse user-provided granularity or auto-select a default
    if granularity:
        try:
            granularity_iso = _human_to_iso_duration(granularity)
        except click.BadParameter as e:
            click.echo(f"Error: {e.format_message()}", err=True)
            ctx.exit(1)
            return
    else:
        granularity_iso = _default_granularity(period_iso, start_time, end_time)

    body: dict = {
        "metricQueries": [{"name": _METRIC_MAP[m.upper()]} for m in metrics_list],
        "granularity": granularity_iso,
    }
    if period_iso:
        body["period"] = period_iso
    if start_time:
        body["start"] = start_time
    if end_time:
        body["end"] = end_time

    caller = build_caller(ctx)
    stderr_console = Console(stderr=True)

    try:
        with stderr_console.status("[cyan]Loading...[/cyan]", spinner="dots"):
            result = caller.call(
                "POST",
                "/v2/clusters/{clusterId}/metrics/query",
                body=body,
                path_params={"clusterId": cluster_id},
            )

        if output_format != "table":
            click.echo(fmt.format_success(result))
            return

        _print_metrics_table(result)

    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)


# Mark required options for GroupedCommand help display
_REQUIRED_OPTIONS = {"--cluster-id", "--metric", "-m"}
for param in metrics.params:
    if isinstance(param, click.Option):
        param._model_required = bool(set(param.opts) & _REQUIRED_OPTIONS)  # type: ignore[attr-defined]
