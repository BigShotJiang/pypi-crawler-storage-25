# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

"""Styling configuration for CLI output."""

from __future__ import annotations

from rich.style import Style

# Status colors mapping
STATUS_STYLES = {
    # Cluster status
    "RUNNING": Style(color="green", bold=True),
    "HEALTHY": Style(color="green", bold=True),
    "ACTIVE": Style(color="green", bold=True),
    "READY": Style(color="green", bold=True),
    "LOADED": Style(color="green", bold=True),
    "SUCCEEDED": Style(color="green", bold=True),
    "SUCCESS": Style(color="green", bold=True),
    # Warning status
    "STOPPED": Style(color="yellow", bold=True),
    "STOPPING": Style(color="yellow"),
    "PENDING": Style(color="yellow"),
    "SUSPENDING": Style(color="yellow"),
    "SUSPENDED": Style(color="yellow", bold=True),
    "RESUMING": Style(color="yellow"),
    "UNLOADED": Style(color="yellow"),
    # In progress status
    "CREATING": Style(color="cyan"),
    "STARTING": Style(color="cyan"),
    "SCALING": Style(color="cyan"),
    "MODIFYING": Style(color="cyan"),
    "LOADING": Style(color="cyan"),
    "BUILDING": Style(color="cyan"),
    "IMPORTING": Style(color="cyan"),
    "INPROGRESS": Style(color="cyan"),
    "IN_PROGRESS": Style(color="cyan"),
    # Error status
    "FAILED": Style(color="red", bold=True),
    "ERROR": Style(color="red", bold=True),
    "DELETED": Style(color="red"),
    "DELETING": Style(color="red"),
    "ABNORMAL": Style(color="red", bold=True),
}

# Key fields that should be highlighted
KEY_FIELDS = {
    "clusterId": Style(color="cyan"),
    "clusterName": Style(bold=True),
    "collectionName": Style(bold=True),
    "name": Style(bold=True),
    "endpoint": Style(color="blue", underline=True),
    "connectAddress": Style(color="blue", underline=True),
    "publicEndpoint": Style(color="blue", underline=True),
    "privateEndpoint": Style(color="blue"),
}

# Status field names (for auto-detection)
STATUS_FIELDS = {"status", "state", "clusterStatus", "indexState", "loadState"}

# Success/Error styles
SUCCESS_STYLE = Style(color="green", bold=True)
ERROR_STYLE = Style(color="red", bold=True)
WARNING_STYLE = Style(color="yellow", bold=True)

# Symbols
SUCCESS_SYMBOL = "[green bold]\u2714[/green bold]"  # checkmark
ERROR_SYMBOL = "[red bold]\u2718[/red bold]"  # x mark
WARNING_SYMBOL = "[yellow bold]\u26a0[/yellow bold]"  # warning
INFO_SYMBOL = "[cyan]\u2139[/cyan]"  # info


def get_status_style(status: str) -> Style | None:
    """Get style for a status value."""
    if not status:
        return None
    return STATUS_STYLES.get(status.upper())


def get_field_style(field_name: str) -> Style | None:
    """Get style for a field name."""
    return KEY_FIELDS.get(field_name)


def is_status_field(field_name: str) -> bool:
    """Check if a field is a status field."""
    return field_name.lower() in STATUS_FIELDS or field_name.lower().endswith("status")
