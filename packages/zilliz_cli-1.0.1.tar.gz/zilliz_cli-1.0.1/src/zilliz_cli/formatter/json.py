import json

from zilliz_cli.formatter.base import BaseFormatter


class JsonFormatter(BaseFormatter):
    def format_success(self, data) -> str:
        return json.dumps(data, indent=2, ensure_ascii=False)

    def format_error(self, code: int, message: str) -> str:
        return json.dumps({"error": {"code": code, "message": message}}, indent=2)
