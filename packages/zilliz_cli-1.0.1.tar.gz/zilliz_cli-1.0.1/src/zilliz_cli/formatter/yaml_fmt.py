"""YAML output formatter."""

import yaml

from zilliz_cli.formatter.base import BaseFormatter


class YamlFormatter(BaseFormatter):
    def format_success(self, data) -> str:
        return yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False).rstrip("\n")

    def format_error(self, code: int, message: str) -> str:
        return yaml.dump(
            {"error": {"code": code, "message": message}},
            default_flow_style=False,
            sort_keys=False,
        ).rstrip("\n")
