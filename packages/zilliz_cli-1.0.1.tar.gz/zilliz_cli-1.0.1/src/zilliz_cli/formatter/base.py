from __future__ import annotations

from abc import ABC, abstractmethod


class BaseFormatter(ABC):
    @abstractmethod
    def format_success(self, data) -> str:
        pass

    @abstractmethod
    def format_error(self, code: int, message: str) -> str:
        pass


def get_formatter(output_format: str, no_header: bool = False) -> BaseFormatter:
    from zilliz_cli.formatter.csv_fmt import CsvFormatter
    from zilliz_cli.formatter.json import JsonFormatter
    from zilliz_cli.formatter.table import TableFormatter
    from zilliz_cli.formatter.text import TextFormatter
    from zilliz_cli.formatter.yaml_fmt import YamlFormatter

    if output_format == "csv":
        return CsvFormatter(no_header=no_header)
    if output_format == "table":
        return TableFormatter(no_header=no_header)

    formatters: dict[str, type[BaseFormatter]] = {
        "json": JsonFormatter,
        "text": TextFormatter,
        "yaml": YamlFormatter,
    }
    cls = formatters.get(output_format)
    if cls is None:
        raise ValueError(f"Unknown output format: {output_format}")
    return cls()  # type: ignore[abstract]
