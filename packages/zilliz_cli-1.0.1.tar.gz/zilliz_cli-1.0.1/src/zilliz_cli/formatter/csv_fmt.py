"""CSV output formatter."""

from __future__ import annotations

import csv
import io

from zilliz_cli.formatter.base import BaseFormatter


class CsvFormatter(BaseFormatter):
    def __init__(self, no_header: bool = False):
        self.no_header = no_header

    def format_success(self, data) -> str:
        if isinstance(data, dict):
            # Single dict -> treat as one-row table
            data = [data]
        if isinstance(data, list):
            return self._format_list(data)
        return str(data)

    def format_error(self, code: int, message: str) -> str:
        return f"Error [{code}]: {message}"

    def _format_list(self, items: list) -> str:
        if not items:
            return ""

        buf = io.StringIO()
        writer = csv.writer(buf)

        if isinstance(items[0], dict):
            keys = list(items[0].keys())
            if not self.no_header:
                writer.writerow(keys)
            for item in items:
                writer.writerow(str(item.get(k, "")) for k in keys)
        else:
            if not self.no_header:
                writer.writerow(["value"])
            for item in items:
                writer.writerow([str(item)])

        return buf.getvalue().rstrip("\n")
