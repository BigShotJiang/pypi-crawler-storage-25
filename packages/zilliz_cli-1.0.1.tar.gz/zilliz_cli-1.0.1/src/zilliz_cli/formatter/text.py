# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

"""Plain text formatter with basic styling."""

from rich.console import Console
from rich.text import Text

from zilliz_cli.formatter.base import BaseFormatter
from zilliz_cli.formatter.styles import (
    ERROR_SYMBOL,
    get_status_style,
    is_status_field,
)


class TextFormatter(BaseFormatter):
    def format_success(self, data) -> str:
        if isinstance(data, list):
            return "\n".join(self._format_item(item) for item in data)
        elif isinstance(data, dict):
            return self._format_item(data)
        return str(data)

    def format_error(self, code: int, message: str) -> str:
        console = Console(force_terminal=True)
        with console.capture() as capture:
            console.print(f"{ERROR_SYMBOL} Error [{code}]: {message}")
        return capture.get().strip()

    def _format_item(self, item) -> str:
        if isinstance(item, dict):
            lines = []
            for k, v in item.items():
                styled_value = self._style_value(k, v)
                lines.append(f"{k}: {styled_value}")
            return "\n".join(lines)
        return str(item)

    def _style_value(self, field_name: str, value) -> str:
        """Apply styling to status values."""
        str_value = str(value) if value is not None else ""

        if is_status_field(field_name):
            status_style = get_status_style(str_value)
            if status_style:
                console = Console(force_terminal=True)
                text = Text(str_value, style=status_style)
                with console.capture() as capture:
                    console.print(text, end="")
                return capture.get()

        return str_value
