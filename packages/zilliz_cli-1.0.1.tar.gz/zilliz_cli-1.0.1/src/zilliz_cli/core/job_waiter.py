import sys
import time

import click
from rich.console import Console

from zilliz_cli.core.api_caller import APICaller
from zilliz_cli.core.exceptions import APIError

_TERMINAL_STATES = {"SUCCESSFUL", "FAILED", "CANCELED"}
_DEFAULT_INTERVAL = 5
_DEFAULT_TIMEOUT = 1800  # 30 minutes
_MAX_CONSECUTIVE_ERRORS = 3


def wait_for_job(
    caller: APICaller,
    job_id: str,
    timeout: int = _DEFAULT_TIMEOUT,
    interval: int = _DEFAULT_INTERVAL,
) -> dict:
    """Poll a Cloud Job until it reaches a terminal state.

    Returns the final job data dict.
    Raises click.ClickException on timeout or repeated API failures.
    """
    console = Console(stderr=True)
    start = time.monotonic()
    consecutive_errors = 0
    last_result: dict = {}

    try:
        with console.status(f"[cyan]Waiting for job {job_id}...[/cyan]", spinner="dots") as status:
            while True:
                elapsed = time.monotonic() - start
                if elapsed >= timeout:
                    raise click.ClickException(
                        f"Timeout after {timeout}s. Last status: {last_result.get('status', 'UNKNOWN')}"
                    )

                try:
                    result = caller.call("GET", "/v2/jobs/{jobId}", path_params={"jobId": job_id})
                    consecutive_errors = 0
                except APIError as e:
                    consecutive_errors += 1
                    if consecutive_errors >= _MAX_CONSECUTIVE_ERRORS:
                        raise click.ClickException(f"Job query failed {_MAX_CONSECUTIVE_ERRORS} times: {e.message}")
                    console.print(f"[yellow]Warning: request failed ({e.message}), retrying...[/yellow]")
                    time.sleep(interval)
                    continue

                if not isinstance(result, dict):
                    result = {}
                last_result = result

                job_status = result.get("status", "UNKNOWN")
                progress = result.get("progress") or "?"
                status.update(f"[cyan]Job {job_id}: {job_status} ({progress}%)[/cyan]")

                if job_status in _TERMINAL_STATES:
                    return result

                time.sleep(interval)
    except KeyboardInterrupt:
        console.print(f"\n[yellow]Interrupted. Last status: {last_result.get('status', 'UNKNOWN')}[/yellow]")
        if last_result:
            return last_result
        sys.exit(130)
