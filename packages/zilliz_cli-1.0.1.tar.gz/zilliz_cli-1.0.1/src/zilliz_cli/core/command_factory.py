# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import difflib
import json
import re
import sys
from pathlib import Path

import click
import questionary
from rich.console import Console

from zilliz_cli.auth.config import get_config_manager
from zilliz_cli.auth.credentials import resolve_api_key
from zilliz_cli.core.api_caller import APICaller
from zilliz_cli.core.exceptions import APIError, CredentialError
from zilliz_cli.core.model import CliModel, Operation, Param, Resource
from zilliz_cli.formatter.base import get_formatter


class DidYouMeanMixin:
    """Mixin that suggests similar commands on typos."""

    def resolve_command(self, ctx, args):
        try:
            return super().resolve_command(ctx, args)
        except click.UsageError:
            cmd_name = args[0] if args else ""
            matches = difflib.get_close_matches(cmd_name, self.list_commands(ctx), n=3, cutoff=0.65)
            if matches:
                hint = " or ".join(f"'{m}'" for m in matches)
                ctx.fail(f"No such command '{cmd_name}'. Did you mean {hint}?")
            raise


class SmartGroup(DidYouMeanMixin, click.Group):
    """click.Group with 'Did you mean?' suggestions on typos."""

    pass


class OrderedGroup(DidYouMeanMixin, click.Group):
    """Group that preserves command registration order and suggests similar commands on typos."""

    def list_commands(self, ctx):
        return list(self.commands)


class GroupedCommand(click.Command):
    """Command that groups options into Required and Optional sections in help."""

    def format_epilog(self, ctx, formatter):
        """Write epilog as-is without Click's paragraph wrapping."""
        if self.epilog:
            formatter.write("\n")
            # Strip the \b marker if present
            text = self.epilog.lstrip("\b").rstrip()
            for line in text.split("\n"):
                formatter.write(f"  {line}\n")
            formatter.write("\n")

    def format_options(self, ctx, formatter):
        required = []
        optional = []
        for param in self.get_params(ctx):
            rv = param.get_help_record(ctx)
            if rv is not None:
                if getattr(param, "_model_required", False):
                    required.append(rv)
                else:
                    optional.append(rv)

        if required:
            with formatter.section("Required Options"):
                formatter.write_dl(required)
        if optional:
            with formatter.section("Options"):
                formatter.write_dl(optional)


class CommandFactory:
    def __init__(self, model: CliModel, endpoint_resolver=None, context_provider=None):
        self.model = model
        self.endpoint_resolver = endpoint_resolver
        self.context_provider = context_provider

    def create_groups(self) -> dict[str, click.Group]:
        groups = {}
        for resource_name, resource in self.model.resources.items():
            group = self._build_group(resource_name, resource)
            groups[resource_name] = group
        return groups

    def _build_group(self, name: str, resource: Resource) -> click.Group:
        group = OrderedGroup(name=name)

        if resource.description:
            group.help = resource.description

        for op_name, operation in resource.operations.items():
            cmd = self._build_command(op_name, operation)
            group.add_command(cmd)
        return group

    def _build_command(self, name: str, operation: Operation) -> click.Command:
        is_dangerous = name in _DANGEROUS_OPERATIONS
        params: list[click.Parameter] = []

        for p in operation.params:
            param_type = _CLICK_TYPE_MAP.get(p.type, click.STRING)
            metavar = f"<{p.cli_name.lstrip('-')}>"

            if p.choices:
                param_type = click.Choice(p.choices, case_sensitive=False)
                choices_str = "|".join(p.choices)
                if len(choices_str) <= 30:
                    # Short enums: show in metavar e.g. [COSINE|L2|IP]
                    metavar = f"[{choices_str}]"
                else:
                    # Long enums: short metavar, values in description
                    metavar = p.cli_name.split("-")[-1].upper()

            # Build help text
            if p.description:
                help_text = p.description
            else:
                help_text = p.name

            if p.required_unless:
                help_text += " (unless --body)"

            if p.required_when:
                for dep_name, dep_value in p.required_when.items():
                    dep_p = next((pp for pp in operation.params if pp.name == dep_name), None)
                    dep_cli = dep_p.cli_name if dep_p else f"--{dep_name}"
                    help_text += f" (required when {dep_cli}={dep_value})"

            if p.default is not None:
                help_text += f" (default: {p.default})"

            # Long enums: append to description in brackets
            if p.choices:
                choices_str = "|".join(p.choices)
                if len(choices_str) > 30:
                    help_text += "  [" + ", ".join(p.choices) + "]"

            # Make params not required at Click level - we'll handle it interactively.
            # Store original required status for section grouping in help output.
            option = click.Option(
                param_decls=[p.cli_name],
                required=False,
                default=p.default,
                type=param_type,
                metavar=metavar,
                help=help_text,
            )
            option._model_required = p.required or (p.required_unless is not None)  # type: ignore[attr-defined]
            params.append(option)

        params.append(
            click.Option(
                ["--output", "-o"],
                type=click.Choice(["json", "table", "text", "yaml", "csv"]),
                default=None,
                help="Output format.",
            )
        )

        params.append(
            click.Option(
                ["--no-header"],
                is_flag=True,
                default=False,
                help="Omit header row (table/csv output).",
            )
        )

        params.append(
            click.Option(
                ["--query", "-q"],
                type=click.STRING,
                default=None,
                help="JMESPath expression to filter output.",
            )
        )

        if operation.pagination:
            params.append(
                click.Option(
                    ["--all", "-a"],
                    is_flag=True,
                    default=False,
                    help="Fetch all pages.",
                )
            )

        if operation.body_param:
            params.append(
                click.Option(
                    [operation.body_param],
                    type=click.STRING,
                    default=None,
                    metavar="<json>",
                    help="Raw JSON body (or file://path).",
                )
            )

        # Add --yes flag for dangerous operations
        if is_dangerous:
            params.append(
                click.Option(
                    ["--yes", "-y"],
                    is_flag=True,
                    default=False,
                    help="Skip confirmation prompt.",
                )
            )

        def make_callback(op: Operation, op_name: str, body_param_key: str | None = None, dangerous: bool = False):
            @click.pass_context
            def callback(ctx, **kwargs):
                output = kwargs.pop("output", None) or kwargs.pop("o", None)
                no_header = kwargs.pop("no_header", False) or ctx.obj.get("no_header", False)
                query_expr = kwargs.pop("query", None) or kwargs.pop("q", None) or ctx.obj.get("query")
                raw_body = kwargs.pop(body_param_key, None) if body_param_key else None
                fetch_all = kwargs.pop("all", False) if op.pagination else False
                skip_confirm = kwargs.pop("yes", False) if dangerous else True
                output_format = output or ctx.obj.get("output_format") or "table"
                fmt = get_formatter(output_format, no_header=no_header)

                mgr = get_config_manager(ctx.obj)
                try:
                    api_key = resolve_api_key(ctx.obj.get("api_key"), mgr)
                except CredentialError as e:
                    raise click.ClickException(str(e))

                endpoint = None
                if self.endpoint_resolver:
                    endpoint = self.endpoint_resolver(ctx.obj)
                if not endpoint and self.model.endpoint:
                    endpoint = self.model.endpoint
                if not endpoint:
                    raise click.ClickException(
                        'No endpoint configured. Set a context with "zilliz context set --cluster-id <id>" first.'
                    )
                # Check cluster plan restriction before making API calls
                if op.dedicated_only:
                    context_data = mgr.get_context() if hasattr(mgr, "get_context") else {}
                    plan = (context_data.get("plan") or "").lower()
                    if plan in ("free", "serverless"):
                        click.echo(
                            fmt.format_error(
                                0,
                                f"This command is only available on Dedicated clusters. "
                                f"Your current cluster plan is {context_data.get('plan', 'unknown')}.",
                            ),
                            err=True,
                        )
                        ctx.exit(1)

                caller = APICaller(api_key=api_key, base_url=endpoint)

                # Prompt for missing required parameters (interactive mode)
                # Pass raw_body so we can skip conditionally required params when --body is provided
                kwargs = _prompt_for_missing_params(
                    op.params, kwargs, caller, has_body=bool(raw_body), op_name=op_name, api_path=op.path
                )

                # Interactive prompts from bodyTransform (e.g. backup scope selection)
                extra_body: dict = {}
                if op.body_transform and not raw_body and sys.stdin.isatty():
                    kwargs, extra_body = _process_interactive_prompts(op, kwargs, caller, op_name=op_name)

                path_params = {}
                body = {}

                if raw_body:
                    body = _parse_body_value(raw_body)

                for p in op.params:
                    cli_key = p.cli_name.lstrip("-").replace("-", "_")
                    value = kwargs.get(cli_key)
                    if value is None:
                        continue
                    if p.position == "path":
                        path_params[p.name] = value
                    elif not raw_body or p.name not in body:
                        if p.type in ("array", "object") and isinstance(value, str):
                            if value.startswith("file://"):
                                file_path = value[7:]
                                if not Path(file_path).is_file():
                                    raise click.ClickException(f"File not found: {file_path}")
                                with open(file_path) as f:
                                    try:
                                        value = json.load(f)
                                    except json.JSONDecodeError as e:
                                        raise click.ClickException(f"Invalid JSON in {file_path}: {e}")
                            else:
                                try:
                                    value = json.loads(value)
                                except json.JSONDecodeError:
                                    raise click.ClickException(f"Invalid JSON for {p.cli_name}: {value}")
                        # Apply param-level transform (e.g. dayOfWeek, timeWindow)
                        value = _apply_param_transform(p, value)
                        body[p.name] = value

                # Merge fields from interactive prompts
                body.update(extra_body)

                # Apply body defaults (fields not set by user but required by API)
                for k, v in op.body_defaults.items():
                    if k not in body:
                        body[k] = v

                # Apply body transform rules (derive + compose)
                if op.body_transform:
                    body = _apply_body_transform(body, op.body_transform)

                # Normalize schema field params -> elementTypeParams
                body = _normalize_schema_params(body)

                # Auto-inject dbName from context
                if self.context_provider and "dbName" not in body:
                    has_dbname_param = any(p.name == "dbName" for p in op.params)
                    if has_dbname_param:
                        ctx_data = self.context_provider(ctx.obj)
                        db = ctx_data.get("database", "default")
                        if db and db != "default":
                            body["dbName"] = db

                # Confirmation for dangerous operations
                if dangerous and not skip_confirm:
                    target_desc = _describe_target(body, path_params)
                    click.secho(f"Warning: You are about to {op_name} {target_desc}", fg="yellow")
                    if not click.confirm("Are you sure you want to continue?"):
                        click.echo("Aborted.")
                        ctx.exit(0)

                stderr_console = Console(stderr=True)
                try:
                    with stderr_console.status("[cyan]Loading...[/cyan]", spinner="dots"):
                        if fetch_all and op.pagination:
                            result = _fetch_all_pages(caller, op, body, path_params)
                        else:
                            result = caller.call(op.method, op.path, body=body, path_params=path_params)
                    result = _normalize_array_fields(result)
                    if query_expr:
                        from zilliz_cli.core.query_filter import apply_query

                        try:
                            result = apply_query(result, query_expr)
                        except ValueError as e:
                            raise click.ClickException(str(e))
                    click.echo(fmt.format_success(result))
                except APIError as e:
                    click.echo(fmt.format_error(e.code, e.message), err=True)
                    ctx.exit(1)

            return callback

        bp_key = None
        if operation.body_param:
            bp_key = operation.body_param.lstrip("-").replace("-", "_")

        # Build help text
        help_text = operation.description or f"{name.capitalize()} operation."

        # Build epilog for examples (shown after Options)
        epilog = None
        if operation.examples:
            # \b tells Click not to reformat the following block
            epilog = "\b\nExamples:\n"
            for ex in operation.examples:
                epilog += f"  {ex}\n"

        cmd = GroupedCommand(
            name=name,
            callback=make_callback(operation, op_name=name, body_param_key=bp_key, dangerous=is_dangerous),
            params=params,
            help=help_text,
            epilog=epilog,
        )
        return cmd


def _parse_json_value(value: str, label: str = "body"):
    """Parse a JSON string or read from a file:// path. Returns any JSON type."""
    if value.startswith("file://"):
        path = value[7:]
        if not Path(path).is_file():
            raise click.ClickException(f"File not found: {path}")
        with open(path) as f:
            try:
                return json.load(f)
            except json.JSONDecodeError as e:
                raise click.ClickException(f"Invalid JSON in {path}: {e}")
    try:
        return json.loads(value)
    except json.JSONDecodeError as e:
        raise click.ClickException(f"Invalid JSON for {label}: {e}")


def _parse_body_value(value: str) -> dict:
    return _parse_json_value(value, "body")


def _normalize_schema_params(body: dict) -> dict:
    """Normalize schema field 'params' to 'elementTypeParams' for Milvus v2 REST API.

    Users intuitively write {"params": {"dim": 128}} but the API expects
    {"elementTypeParams": {"dim": "128"}}.  This rewrites the body in-place
    so both forms are accepted.
    """
    schema = body.get("schema")
    if not isinstance(schema, dict):
        return body
    fields = schema.get("fields")
    if not isinstance(fields, list):
        return body
    for field in fields:
        if not isinstance(field, dict):
            continue
        if "params" in field and "elementTypeParams" not in field:
            params = field.pop("params")
            # API expects string values in elementTypeParams
            field["elementTypeParams"] = {k: str(v) for k, v in params.items()}
    return body


def _unwrap_protobuf_value(value: object) -> object:
    """Unwrap a single protobuf-style Array value like {"Data": {"StringData": {"data": [...]}}}."""
    if not isinstance(value, dict):
        return value
    data_inner = value.get("Data")
    if not isinstance(data_inner, dict) or len(data_inner) != 1:
        return value
    type_wrapper = next(iter(data_inner.values()))
    if not isinstance(type_wrapper, dict):
        return value
    actual = type_wrapper.get("data")
    if actual is not None:
        return actual
    return value


def _normalize_array_fields(result: object) -> object:
    """Flatten protobuf-style Array fields in API response data.

    Milvus v2 REST API returns Array fields as:
        {"Data": {"StringData": {"data": ["a", "b"]}}}
    This rewrites them to plain arrays: ["a", "b"]
    """
    if isinstance(result, list):
        for item in result:
            if isinstance(item, dict):
                for key, value in item.items():
                    item[key] = _unwrap_protobuf_value(value)
    elif isinstance(result, dict):
        for key, value in result.items():
            result[key] = _unwrap_protobuf_value(value)
    return result


def _apply_body_transform(body: dict, transform: dict) -> dict:
    """Apply bodyTransform rules to derive and compose body fields from flat params."""
    # 1. derive: set field value based on presence of another field (skip if already set)
    for field_name, rule in transform.get("derive", {}).items():
        if field_name in body:
            continue  # Already set (e.g., by interactive prompt)
        source = rule["from"]
        if source in body and body[source] not in (None, ""):
            body[field_name] = rule["present"]
        else:
            body[field_name] = rule["absent"]

    # 2. compose: build nested structures from flat params
    for field_name, rule in transform.get("compose", {}).items():
        condition_field = rule.get("when")
        if condition_field and (condition_field not in body or not body[condition_field]):
            continue
        template = rule["template"]
        result = json.loads(json.dumps(template))  # deep copy
        # Replace {placeholder} tokens with actual values
        _replace_placeholders(result, body)
        body[field_name] = result
        # Remove consumed params from body
        for consumed in rule.get("consume", []):
            body.pop(consumed, None)

    return body


def _replace_placeholders(obj: object, values: dict) -> None:
    """Recursively replace {key} placeholders in a JSON structure."""
    if isinstance(obj, list):
        for i, item in enumerate(obj):
            if isinstance(item, str) and item.startswith("{") and item.endswith("}"):
                key = item[1:-1]
                if key in values:
                    obj[i] = values[key]
            elif isinstance(item, (dict, list)):
                _replace_placeholders(item, values)
    elif isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, str) and v.startswith("{") and v.endswith("}"):
                key = v[1:-1]
                if key in values:
                    obj[k] = values[key]
            elif isinstance(v, (dict, list)):
                _replace_placeholders(v, values)


_CLICK_TYPE_MAP = {
    "string": click.STRING,
    "integer": click.INT,
    "boolean": click.BOOL,
    "array": click.STRING,
    "object": click.STRING,
}

# Dangerous operations that require confirmation
_DANGEROUS_OPERATIONS = {"delete", "drop", "release", "reset", "clear", "remove"}

# (name_field, parent_field_or_None, template)
# First match wins; template uses {name} and optionally {parent}.
_TARGET_FIELD_PRIORITY: list[tuple[str, str | None, str]] = [
    ("partitionName", "collectionName", "partition '{name}' from collection '{parent}'"),
    ("partitionName", None, "partition '{name}'"),
    ("aliasName", None, "alias '{name}'"),
    ("indexName", "collectionName", "index '{name}' on collection '{parent}'"),
    ("indexName", None, "index '{name}'"),
    ("userName", None, "user '{name}'"),
    ("roleName", None, "role '{name}'"),
    ("collectionName", None, "collection '{name}'"),
    ("clusterId", None, "cluster '{name}'"),
    ("dbName", None, "database '{name}'"),
]


def _describe_target(body: dict, path_params: dict) -> str:
    """Build a human-readable description of the resource being affected."""

    def _get(field: str) -> str | None:
        return body.get(field) or path_params.get(field)

    for name_field, parent_field, template in _TARGET_FIELD_PRIORITY:
        name = _get(name_field)
        if name:
            parent = _get(parent_field) if parent_field else None
            if parent_field and not parent:
                continue
            return template.format(name=name, parent=parent)
    return "'this resource'"


def _process_interactive_prompts(
    op: Operation, kwargs: dict, caller: APICaller | None = None, op_name: str = ""
) -> tuple[dict, dict]:
    """Process interactivePrompt rules from bodyTransform.

    Shows user-friendly selections for virtual fields (e.g. backup scope),
    then prompts for conditional params based on the selection.
    For conditional params that need data-plane APIs (e.g. collectionName),
    resolves cluster endpoint and creates a data-plane caller automatically.

    Returns:
        (updated_kwargs, extra_body_fields)
    """
    prompts = (op.body_transform or {}).get("interactivePrompt", {})
    if not prompts:
        return kwargs, {}

    extra_body: dict = {}
    param_map = {p.name: p for p in op.params}

    for field_name, config in prompts.items():
        # Skip if the derive source param is already provided via CLI
        derive_rules = (op.body_transform or {}).get("derive", {})
        if field_name in derive_rules:
            source = derive_rules[field_name]["from"]
            source_param = param_map.get(source)
            if source_param:
                cli_key = source_param.cli_name.lstrip("-").replace("-", "_")
                if kwargs.get(cli_key) is not None:
                    continue  # Value derivable from CLI args, skip prompt

        # Show selection with friendly display names
        choices_map: dict[str, str] = config.get("choices", {})
        choices = [questionary.Choice(title=display, value=api_val) for display, api_val in choices_map.items()]
        selected = questionary.select(f"  {config.get('prompt', field_name)}:", choices=choices).ask()
        if selected is None:
            raise click.Abort()

        extra_body[field_name] = selected

        # Prompt for conditional params triggered by the selection
        triggered_params = config.get("conditionalParams", {}).get(selected, [])
        if not triggered_params:
            continue

        # Resolve data-plane caller if conditional params need it (e.g. collectionName)
        data_caller = _resolve_data_plane_caller(caller, kwargs, param_map)

        for param_name in triggered_params:
            p = param_map.get(param_name)
            if not p:
                continue
            cli_key = p.cli_name.lstrip("-").replace("-", "_")
            if kwargs.get(cli_key) is not None:
                continue  # Already provided via CLI

            # Try smart prompt with data-plane caller, then fallback
            # Pass empty op_name to bypass exclude_ops (these are explicitly triggered selections)
            value = _smart_prompt_param(p, data_caller, op_name="", kwargs=kwargs)
            if value is None:
                prompt_text = f"  {p.name}"
                value = click.prompt(prompt_text, type=str).strip()

            kwargs[cli_key] = value

    return kwargs, extra_body


def _resolve_data_plane_caller(caller: APICaller | None, kwargs: dict, param_map: dict[str, Param]) -> APICaller | None:
    """Resolve a data-plane APICaller from the selected clusterId.

    For control-plane commands that need to fetch data-plane resources
    (e.g. collections, databases), this looks up the cluster's connectAddress
    and creates a new APICaller pointing to it.
    """
    if caller is None:
        return None

    # Find clusterId from kwargs
    cluster_param = param_map.get("clusterId")
    if not cluster_param:
        return caller
    cli_key = cluster_param.cli_name.lstrip("-").replace("-", "_")
    cluster_id = kwargs.get(cli_key)
    if not cluster_id:
        return caller

    try:
        cluster_info = caller.call("GET", "/v2/clusters/{clusterId}", path_params={"clusterId": cluster_id})
        endpoint = cluster_info.get("connectAddress", "") if isinstance(cluster_info, dict) else ""
        if not endpoint:
            return caller
        return APICaller(api_key=caller.api_key, base_url=endpoint)
    except (APIError, KeyError, TypeError, ValueError):
        return caller


def _prompt_for_missing_params(
    params: list[Param],
    kwargs: dict,
    caller: APICaller | None = None,
    has_body: bool = False,
    op_name: str = "",
    api_path: str = "",
) -> dict:
    """Prompt user for missing required parameters if running interactively.

    Three-phase prompting:
      Phase 1: Unconditionally required params
      Phase 2: Conditionally required params (requiredWhen)
      Phase 3: Optional params (user chooses whether to configure)

    For known parameters like projectId, regionId, clusterId, this function will
    fetch available options from the API and present them as a selection list.

    Args:
        params: List of parameter definitions
        kwargs: Current parameter values
        caller: API caller for smart prompts
        has_body: Whether --body was provided (skips conditionally required params)
        op_name: Current operation name (e.g. "create", "describe")
    """

    def _cli_key(p: Param) -> str:
        return p.cli_name.lstrip("-").replace("-", "_")

    def _is_missing(p: Param) -> bool:
        return kwargs.get(_cli_key(p)) is None

    def _is_unconditionally_required(p: Param) -> bool:
        if p.required:
            return True
        if p.required_unless == "body" and not has_body:
            return True
        return False

    def _check_required_when(p: Param) -> bool:
        """Check if param's requiredWhen condition is met based on current kwargs."""
        if not p.required_when:
            return False
        for dep_name, dep_value in p.required_when.items():
            dep_param = next((pp for pp in params if pp.name == dep_name), None)
            if dep_param:
                actual = kwargs.get(_cli_key(dep_param))
                if actual == dep_value:
                    return True
        return False

    # Phase 1: Unconditionally required params
    missing_required = [p for p in params if _is_missing(p) and _is_unconditionally_required(p)]

    # Non-interactive mode: collect all missing (required + conditionally required) and error
    if not sys.stdin.isatty():
        all_missing = list(missing_required)
        for p in params:
            if _is_missing(p) and not _is_unconditionally_required(p) and _check_required_when(p):
                all_missing.append(p)
        if all_missing:
            missing_names = ", ".join(p.cli_name for p in all_missing)
            raise click.ClickException(f"Missing required options: {missing_names}")
        return kwargs

    # Interactive mode
    if missing_required:
        click.echo("Please provide the required parameters:\n")
        for p in missing_required:
            kwargs[_cli_key(p)] = _prompt_single_param(p, caller, op_name, kwargs, api_path=api_path)
        click.echo()

    # Phase 2: Conditionally required params (requiredWhen)
    conditional_missing = [p for p in params if _is_missing(p) and _check_required_when(p)]
    if conditional_missing:
        for p in conditional_missing:
            kwargs[_cli_key(p)] = _prompt_single_param(p, caller, op_name, kwargs, api_path=api_path)
        click.echo()

    # Phase 3: Optional params (user chooses whether to configure)
    optional_missing = [
        p
        for p in params
        if _is_missing(p)
        and not _is_unconditionally_required(p)
        and not _check_required_when(p)
        and p.position != "path"
    ]
    if optional_missing and click.confirm("Configure additional options?", default=False):
        for p in optional_missing:
            value = _prompt_optional_param(p, caller, op_name, kwargs, api_path=api_path)
            if value is not None:
                kwargs[_cli_key(p)] = value

    return kwargs


_DAY_NAME_MAP = {
    "mon": "1",
    "tue": "2",
    "wed": "3",
    "thu": "4",
    "fri": "5",
    "sat": "6",
    "sun": "7",
}
_FREQUENCY_PRESETS = {
    "daily": "1,2,3,4,5,6,7",
    "weekdays": "1,2,3,4,5",
    "weekends": "6,7",
}
_DAY_DISPLAY = {
    "1": "Monday",
    "2": "Tuesday",
    "3": "Wednesday",
    "4": "Thursday",
    "5": "Friday",
    "6": "Saturday",
    "7": "Sunday",
}


def _transform_day_of_week(value: str) -> str:
    """Transform user-friendly frequency input to backend format (comma-separated 1-7)."""
    v = value.strip().lower()
    if v in _FREQUENCY_PRESETS:
        return _FREQUENCY_PRESETS[v]
    # Day names: mon,wed,fri -> 1,3,5
    parts = [p.strip() for p in v.split(",")]
    if all(p in _DAY_NAME_MAP for p in parts):
        return ",".join(_DAY_NAME_MAP[p] for p in parts)
    # Already numeric: validate
    if re.match(r"^[1-7](,[1-7])*$", v):
        return v
    raise click.ClickException(
        f"Invalid --frequency '{value}'. Use 'daily', 'weekdays', 'weekends', or numbers 1-7 (1=Mon, 7=Sun) e.g. 1,3,5"
    )


def _transform_time_window(value: str, window_hours: int = 2) -> str:
    """Transform time input to backend format HH:00-HH:00.

    Accepts:
      - Single time: '02:00' -> '02:00-04:00' (auto-expand by windowHours)
      - Full window: '02:00-06:00' -> '02:00-06:00' (pass through)
    """
    v = value.strip()
    # Full window: validate and pass through
    if "-" in v:
        if re.match(r"^([01]?[0-9]|2[0-3]):00-([01]?[0-9]|2[0-3]):00$", v):
            return v
        raise click.ClickException(f"Invalid --start-time '{value}'. Use whole hours, e.g. '02:00-06:00'")
    # Single time: expand to window
    m = re.match(r"^([01]?[0-9]|2[0-3]):00$", v)
    if not m:
        raise click.ClickException(
            f"Invalid --start-time '{value}'. Use a whole hour like '02:00', or a window like '02:00-06:00'"
        )
    start_h = int(m.group(1))
    end_h = (start_h + window_hours) % 24
    return f"{start_h:02d}:00-{end_h:02d}:00"


def _apply_param_transform(p: Param, value: object) -> object:
    """Apply param-level transform if configured. Returns transformed value."""
    if not p.transform or value is None:
        return value
    t = p.transform["type"]
    if t == "dayOfWeek":
        return _transform_day_of_week(str(value))
    if t == "timeWindow":
        return _transform_time_window(str(value), p.transform.get("windowHours", 2))
    return value


def _interactive_day_of_week() -> str:
    """Interactive multi-select for days of week. Returns backend format."""
    presets = [
        questionary.Choice(title="daily (every day)", value="daily"),
        questionary.Choice(title="weekdays (Mon-Fri)", value="weekdays"),
        questionary.Choice(title="weekends (Sat-Sun)", value="weekends"),
        questionary.Choice(title="custom (pick specific days)", value="custom"),
    ]
    selected = questionary.select("  Select backup frequency:", choices=presets).ask()
    if selected is None:
        raise click.Abort()
    if selected != "custom":
        return _FREQUENCY_PRESETS[selected]

    day_choices = [questionary.Choice(title=name, value=num, checked=False) for num, name in _DAY_DISPLAY.items()]
    days = questionary.checkbox("  Select backup days:", choices=day_choices).ask()
    if days is None:
        raise click.Abort()
    if not days:
        raise click.ClickException("At least one day must be selected")
    return ",".join(days)


def _interactive_time_window(window_hours: int = 2) -> str:
    """Interactive prompt for backup start time. Returns backend format."""
    while True:
        raw = click.prompt("  start-time (UTC, e.g. 02:00 or 02:00-04:00)", type=str).strip()
        try:
            return _transform_time_window(raw, window_hours)
        except click.ClickException as e:
            click.echo(f"  {e.format_message()}")


def _prompt_single_param(
    p: Param, caller: APICaller | None, op_name: str, kwargs: dict, api_path: str = ""
) -> str | int | bool:
    """Prompt for a single required parameter. Always returns a value."""
    # Use interactive transform prompts when available (e.g. dayOfWeek multi-select)
    if p.transform and sys.stdin.isatty():
        t = p.transform["type"]
        if t == "dayOfWeek":
            return _interactive_day_of_week()
        if t == "timeWindow":
            return _interactive_time_window(p.transform.get("windowHours", 2))

    value = _smart_prompt_param(p, caller, op_name=op_name, kwargs=kwargs, api_path=api_path)
    if value is not None:
        return value

    display_name = p.cli_name.lstrip("-")
    prompt_text = f"  {display_name}"
    is_secret = getattr(p, "sensitive", False) or "password" in p.name.lower() or "secret" in p.name.lower()
    if p.choices:
        choices = [questionary.Choice(title=c, value=c) for c in p.choices]
        value = questionary.select(f"  Select {display_name}:", choices=choices, use_shortcuts=True).ask()
        if value is None:
            raise click.Abort()
    elif p.type == "integer":
        value = click.prompt(prompt_text, type=int)
    elif p.type == "boolean":
        value = click.confirm(prompt_text)
    else:
        value = click.prompt(prompt_text, type=str, hide_input=is_secret).strip()

    return value


def _prompt_optional_param(
    p: Param, caller: APICaller | None, op_name: str, kwargs: dict, api_path: str = ""
) -> str | int | bool | None:
    """Prompt for a single optional parameter. Returns None if skipped."""
    value = _smart_prompt_param(p, caller, op_name=op_name, kwargs=kwargs, api_path=api_path)
    if value is not None:
        return value

    display_name = p.cli_name.lstrip("-")
    prompt_text = f"  {display_name}"
    if p.choices:
        choices = [questionary.Choice(title="(skip)", value=None)]
        choices.extend(questionary.Choice(title=c, value=c) for c in p.choices)
        selected = questionary.select(f"  {display_name}:", choices=choices, use_shortcuts=True).ask()
        if selected is None:
            raise click.Abort()
        return selected
    elif p.type == "integer":
        raw = click.prompt(prompt_text, default="", show_default=False)
        if not raw:
            return None
        try:
            return int(raw)
        except ValueError:
            return None
    elif p.type == "boolean":
        raw = click.prompt(prompt_text + " [y/n/skip]", default="skip")
        if raw.lower() in ("skip", "s", ""):
            return None
        return raw.lower() in ("y", "yes", "true", "1")
    else:
        raw = click.prompt(prompt_text, default="", show_default=False)
        return raw.strip() if raw.strip() else None


# Mapping of parameter names to their API fetch configuration
# Each config: {api, data_field, id_field, name_field, extra_fields (optional)}
# Or static choices: {choices: [(display, value), ...]}
_SMART_PARAM_FETCHERS: dict[str, dict] = {
    "projectId": {
        "api": "GET /v2/projects",
        "data_field": "data",
        "id_field": "projectId",
        "name_field": "projectName",
        "extra_fields": ["plan"],
    },
    "regionId": {
        "api": "GET /v2/regions",
        "data_field": "data",
        "id_field": "regionId",
        "name_field": "regionId",
    },
    "clusterId": {
        "api": "GET /v2/clusters",
        "data_field": "clusters",
        "id_field": "clusterId",
        "name_field": "clusterName",
    },
    "collectionName": {
        "api": "POST /v2/vectordb/collections/list",
        "data_field": "data",
        "id_field": "collectionName",
        "name_field": "collectionName",
        "exclude_ops": {"create"},
        "body_params": {"dbName": "database"},
    },
    "dbName": {
        "api": "POST /v2/vectordb/databases/list",
        "data_field": "data",
        "id_field": None,
        "name_field": None,
        "exclude_ops": {"create"},
    },
    "indexName": {
        "api": "POST /v2/vectordb/indexes/list",
        "data_field": "data",
        "id_field": "indexName",
        "name_field": "indexName",
        "body_params": {"collectionName": "collection"},
    },
    "roleName": {
        "api": "POST /v2/vectordb/roles/list",
        "data_field": "data",
        "id_field": "roleName",
        "name_field": "roleName",
        "exclude_ops": {"create"},
    },
    "userName": {
        "api": "POST /v2/vectordb/users/list",
        "data_field": "data",
        "id_field": "userName",
        "name_field": "userName",
        "exclude_ops": {"create"},
    },
    "partitionName": {
        "api": "POST /v2/vectordb/partitions/list",
        "data_field": "data",
        "id_field": None,
        "name_field": None,
        "body_params": {"collectionName": "collection"},
        "exclude_ops": {"create"},
    },
    "backupId": {
        "api": "GET /v2/backups",
        "data_field": "backups",
        "id_field": "backupId",
        "name_field": "backupName",
        "body_params": {"clusterId": "cluster_id"},
    },
    "destClusterId": {
        "api": "GET /v2/clusters",
        "data_field": "clusters",
        "id_field": "clusterId",
        "name_field": "clusterName",
    },
    "objectName": {
        "dynamic": "_resolve_object_name",
    },
    "privilege": {
        "dynamic": "_resolve_privilege",
    },
    "cuType": {
        "choices": [
            ("Performance-optimized (recommended)", "Performance-optimized"),
            ("Capacity-optimized (more storage)", "Capacity-optimized"),
        ],
    },
}


def _resolve_object_name(param: Param, caller: APICaller | None, kwargs: dict | None = None) -> str | None:
    """Resolve objectName based on the selected objectType."""
    object_type = (kwargs or {}).get("object_type")
    if not object_type or caller is None:
        return None

    if object_type == "Global":
        click.echo("  objectName: * (auto-selected for Global)")
        return "*"

    if object_type == "Collection":
        try:
            result = caller.call("POST", "/v2/vectordb/collections/list", return_raw=True)
            items = result.get("data", []) if isinstance(result, dict) else []
            names = [item if isinstance(item, str) else item.get("collectionName", "") for item in items]
            names = [n for n in names if n]
        except (APIError, KeyError, TypeError, ValueError):
            return None
    elif object_type == "Database":
        try:
            result = caller.call("POST", "/v2/vectordb/databases/list", return_raw=True)
            names = result.get("data", []) if isinstance(result, dict) else []
            names = [n for n in names if isinstance(n, str)]
        except (APIError, KeyError, TypeError, ValueError):
            return None
    else:
        return None

    if not names:
        return None

    choices = [questionary.Choice(title="* (all)", value="*")]
    for n in names:
        choices.append(questionary.Choice(title=n, value=n))

    selected = questionary.select(f"  Select {object_type.lower()} name:", choices=choices, use_shortcuts=True).ask()
    if selected is None:
        raise click.Abort()
    return selected


# Milvus v1 privileges per object type
_PRIVILEGES_BY_OBJECT_TYPE: dict[str, list[str]] = {
    "Collection": [
        "Search",
        "Query",
        "Insert",
        "Delete",
        "Upsert",
        "Import",
        "GetStatistics",
        "Load",
        "Release",
        "GetLoadState",
        "GetLoadingProgress",
        "CreateIndex",
        "DropIndex",
        "IndexDetail",
        "CreatePartition",
        "DropPartition",
        "ShowPartitions",
        "HasPartition",
        "Compaction",
        "GetCompactionState",
        "FlushAll",
        "GetFlushState",
    ],
    "Database": [
        "CreateCollection",
        "DropCollection",
        "DescribeCollection",
        "ShowCollections",
        "ListCollections",
        "AlterCollection",
        "AlterDatabase",
        "DescribeDatabase",
    ],
    "Global": [
        "All",
        "CreateCollection",
        "DropCollection",
        "DescribeCollection",
        "ShowCollections",
        "CreateOwnership",
        "DropOwnership",
        "SelectOwnership",
        "ManageOwnership",
        "CreateDatabase",
        "DropDatabase",
        "ListDatabases",
        "AlterDatabase",
        "DescribeDatabase",
        "CreateResourceGroup",
        "DropResourceGroup",
        "DescribeResourceGroup",
        "ListResourceGroups",
        "FlushAll",
        "CreateAlias",
        "DropAlias",
        "DescribeAlias",
        "ListAliases",
    ],
}


def _resolve_privilege(param: Param, caller: APICaller | None, kwargs: dict | None = None) -> str | None:
    """Resolve privilege based on the selected objectType."""
    object_type = (kwargs or {}).get("object_type")
    if not object_type:
        return None

    privileges = _PRIVILEGES_BY_OBJECT_TYPE.get(object_type)
    if not privileges:
        return None

    choices = [questionary.Choice(title="* (all privileges)", value="*")]
    for p in sorted(privileges):
        choices.append(questionary.Choice(title=p, value=p))

    selected = questionary.select(f"  Select privilege ({object_type}):", choices=choices, use_shortcuts=True).ask()
    if selected is None:
        raise click.Abort()
    return selected


_DYNAMIC_RESOLVERS = {
    "_resolve_object_name": _resolve_object_name,
    "_resolve_privilege": _resolve_privilege,
}


def _smart_prompt_param(
    param: Param,
    caller: APICaller | None,
    op_name: str = "",
    kwargs: dict | None = None,
    api_path: str = "",
) -> str | int | None:
    """Try to fetch options for known parameters and present a selection.

    Returns the selected value, or None if smart prompt is not available.
    """
    config = _SMART_PARAM_FETCHERS.get(param.name)
    if config is None:
        return None

    # Skip smart prompt for excluded operations (e.g. "create" needs a new name, not a selection)
    # But only when this param is the primary target of the operation, not a parent reference.
    # We determine this by comparing the operation's API path with the fetcher's resource type.
    # e.g. collectionName fetcher API is "POST /v2/vectordb/collections/list" -> resource "collections"
    #   - "collection create" path "/v2/vectordb/collections/create" contains "/collections/" -> exclude
    #   - "partition create" path "/v2/vectordb/partitions/create" does NOT -> show selection
    if op_name and op_name in config.get("exclude_ops", set()):
        fetcher_api_path = config.get("api", "")
        # Extract resource segment from fetcher API (e.g. "collections" from ".../collections/list")
        fetcher_path = fetcher_api_path.split(" ", 1)[-1] if " " in fetcher_api_path else fetcher_api_path
        resource_segment = fetcher_path.rsplit("/", 1)[0].rsplit("/", 1)[-1]  # e.g. "collections"
        if not api_path or f"/{resource_segment}/" in api_path:
            return None
        # Current operation targets a different resource -> this param is a parent reference, don't skip

    # Handle dynamic resolvers (depend on other param values)
    if "dynamic" in config:
        resolver = _DYNAMIC_RESOLVERS.get(config["dynamic"])
        if resolver:
            return resolver(param, caller, kwargs=kwargs)
        return None

    # Handle static choices (no API call needed)
    if "choices" in config:
        choices = [questionary.Choice(title=display, value=value) for display, value in config["choices"]]
        selected = questionary.select(
            f"  Select {param.name}:",
            choices=choices,
            use_shortcuts=True,
        ).ask()
        if selected is None:
            raise click.Abort()
        return selected

    # Need API caller for dynamic options
    if caller is None:
        return None

    api_spec = config["api"]
    data_field = config["data_field"]
    id_field = config["id_field"]
    name_field = config["name_field"]
    extra_fields = config.get("extra_fields", [])

    try:
        # Parse API spec
        method, path = api_spec.split(" ", 1)

        # Build request body from dependent parameters
        body = {}
        for body_key, kwargs_key in config.get("body_params", {}).items():
            val = (kwargs or {}).get(kwargs_key)
            if val:
                body[body_key] = val

        result = caller.call(method, path, body=body or None, return_raw=True)

        if not isinstance(result, dict):
            return None

        # Handle response structure: {"code": 0, "data": [...]} or direct data
        response_data = result.get("data", result)

        # Get the list of items
        if isinstance(response_data, list):
            items = response_data
        elif isinstance(response_data, dict):
            items = response_data.get(data_field, [])
            if not isinstance(items, list):
                items = [items] if items else []
        else:
            return None

        if not items:
            click.echo(f"  No {param.name.replace('Id', '')}s found.")
            return None

        # Build choices for questionary
        choices = []
        for item in items:
            # Handle both string items (e.g. collection names) and dict items
            if isinstance(item, str):
                choices.append(questionary.Choice(title=item, value=item))
                continue

            item_id = item.get(id_field)
            item_name = item.get(name_field, item_id)
            if item_id:
                # Build display string: "name (id)" or "name [extra1, extra2] (id)"
                extra_parts = []
                for field in extra_fields:
                    val = item.get(field)
                    if val:
                        extra_parts.append(str(val))

                if extra_parts:
                    extra_str = ", ".join(extra_parts)
                    display = f"{item_name} [{extra_str}] ({item_id})"
                elif item_name != item_id:
                    display = f"{item_name} ({item_id})"
                else:
                    display = item_id
                choices.append(questionary.Choice(title=display, value=item_id))

        if not choices:
            return None

        # If only one option, auto-select it
        if len(choices) == 1:
            selected = choices[0].value
            click.echo(f"  {param.name}: {choices[0].title} (auto-selected)")
            return selected

        # Present selection
        selected = questionary.select(
            f"  Select {param.name.replace('Id', '')}:",
            choices=choices,
            use_shortcuts=True,
        ).ask()
        if selected is None:
            raise click.Abort()

        return selected

    except APIError:
        # API error (auth failure, network issue) -> fall back to manual input
        return None
    except (KeyError, TypeError, ValueError):
        # Malformed response -> fall back to manual input
        return None


_MAX_PAGES = 1000


def _fetch_all_pages(caller: APICaller, op: Operation, body: dict, path_params: dict) -> list:
    """Fetch all pages of paginated results."""
    assert op.pagination is not None
    pg = op.pagination
    all_results = []
    page = 1
    page_size = body.get(pg.page_size_param, pg.default_page_size)

    while page <= _MAX_PAGES:
        req_body = body.copy()
        req_body[pg.page_size_param] = page_size
        req_body[pg.page_param] = page

        result = caller.call(
            op.method,
            op.path,
            body=req_body or None,
            path_params=path_params,
            return_raw=True,
        )

        if not isinstance(result, dict):
            raise APIError(0, f"Unexpected response type on page {page}: {type(result).__name__}")

        # return_raw gives {"code": 0, "data": {...}}, extract the data part
        response_data = result.get("data", result)

        data = response_data.get(pg.data_field, [])
        if isinstance(data, list):
            all_results.extend(data)
        else:
            all_results.append(data)

        total = int(response_data.get(pg.count_field, 0) or 0)
        if page * page_size >= total or not data:
            break
        page += 1

    if page > _MAX_PAGES:
        click.echo(f"Warning: Reached max page limit ({_MAX_PAGES}).", err=True)

    return all_results
