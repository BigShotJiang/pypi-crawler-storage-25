# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

from dataclasses import dataclass, field


@dataclass
class Param:
    name: str
    type: str
    cli_name: str
    required: bool = False
    default: str | int | bool | None = None
    position: str | None = None
    required_unless: str | None = None  # Required unless this other param is provided
    required_when: dict | None = None  # Required when another param has a specific value
    description: str | None = None
    choices: list[str] | None = None
    transform: dict | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "Param":
        return cls(
            name=d["name"],
            type=d.get("type", "string"),
            cli_name=d.get("cli", f"--{d['name']}"),
            required=d.get("required", False),
            default=d.get("default"),
            position=d.get("position"),
            required_unless=d.get("requiredUnless"),
            required_when=d.get("requiredWhen"),
            description=d.get("description"),
            choices=d.get("choices"),
            transform=d.get("transform"),
        )


@dataclass
class Pagination:
    page_size_param: str = "pageSize"
    page_param: str = "currentPage"
    count_field: str = "count"
    data_field: str = "data"
    default_page_size: int = 100

    @classmethod
    def from_dict(cls, d: dict) -> "Pagination":
        return cls(
            page_size_param=d.get("pageSizeParam", "pageSize"),
            page_param=d.get("pageParam", "currentPage"),
            count_field=d.get("countField", "count"),
            data_field=d.get("dataField", "data"),
            default_page_size=d.get("defaultPageSize", 100),
        )


@dataclass
class Operation:
    method: str
    path: str
    params: list[Param] = field(default_factory=list)
    body_param: str | None = None
    output: dict = field(default_factory=dict)
    pagination: Pagination | None = None
    description: str | None = None
    examples: list[str] = field(default_factory=list)
    dedicated_only: bool = False
    body_transform: dict | None = None
    body_defaults: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict) -> "Operation":
        http = d.get("http", {})
        pagination = None
        if "pagination" in d:
            pagination = Pagination.from_dict(d["pagination"])
        return cls(
            method=http.get("method", "GET"),
            path=http.get("path", ""),
            params=[Param.from_dict(p) for p in d.get("params", [])],
            body_param=d.get("bodyParam"),
            output=d.get("output", {}),
            pagination=pagination,
            description=d.get("description"),
            examples=d.get("examples", []),
            dedicated_only=d.get("dedicatedOnly", False),
            body_transform=d.get("bodyTransform"),
            body_defaults=d.get("bodyDefaults", {}),
        )


@dataclass
class Resource:
    description: str | None = None
    dedicated_only: bool = False
    operations: dict[str, Operation] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict) -> "Resource":
        ops = {}
        res_dedicated = d.get("dedicatedOnly", False)
        for name, op_dict in d.get("operations", {}).items():
            op = Operation.from_dict(op_dict)
            # Inherit dedicatedOnly from resource level
            if res_dedicated and not op.dedicated_only:
                op.dedicated_only = True
            ops[name] = op
        return cls(description=d.get("description"), dedicated_only=res_dedicated, operations=ops)


@dataclass
class AuthConfig:
    auth0_domain: str = ""
    client_id: str = ""
    login_api: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> "AuthConfig":
        return cls(
            auth0_domain=d.get("auth0_domain", ""),
            client_id=d.get("client_id", ""),
            login_api=d.get("login_api", ""),
        )


@dataclass
class CliModel:
    version: str = ""
    min_cli_version: str = ""
    endpoint: str | None = None
    auth: AuthConfig | None = None
    resources: dict[str, Resource] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict) -> "CliModel":
        resources = {}
        for name, res_dict in d.get("resources", {}).items():
            resources[name] = Resource.from_dict(res_dict)
        auth = None
        if "auth" in d:
            auth = AuthConfig.from_dict(d["auth"])
        return cls(
            version=d.get("version", ""),
            min_cli_version=d.get("minCliVersion", ""),
            endpoint=d.get("endpoint"),
            auth=auth,
            resources=resources,
        )
