"""JMESPath query filtering for CLI output."""

from __future__ import annotations

import jmespath
from jmespath.exceptions import ParseError


def apply_query(data, expression: str | None):
    """Apply a JMESPath expression to data. Returns data unchanged if expression is None."""
    if expression is None:
        return data
    try:
        result = jmespath.search(expression, data)
    except ParseError as e:
        raise ValueError(f"Invalid JMESPath expression: {e}")
    return result
