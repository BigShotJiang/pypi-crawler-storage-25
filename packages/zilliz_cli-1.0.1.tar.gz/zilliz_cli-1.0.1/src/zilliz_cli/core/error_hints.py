"""Friendly error hints for common API errors."""

from __future__ import annotations


def get_error_hint(code: int, message: str, status_code: int | None = None) -> str | None:
    """Return a helpful hint for a given error, or None if no hint applies."""
    msg_lower = message.lower()

    # Auth errors
    if status_code in (401, 403) or code == 80001:
        return 'Check your API key with "zilliz configure get api_key" or re-run "zilliz login".'

    # Permission denied
    if "permissiondenied" in msg_lower or "permission deny" in msg_lower:
        return "This may require a Dedicated cluster plan, or your API key may lack the required permissions."

    # Rate limiting
    if status_code == 429 or "rate limit" in msg_lower:
        return "Rate limit reached. Wait a moment and retry, or reduce request frequency."

    # Timeout / connection errors
    if "timeout" in msg_lower or "timed out" in msg_lower:
        return "Request timed out. Check your network connection and try again."

    if "connection" in msg_lower or "connect" in msg_lower:
        return "Connection failed. Check your network and that the endpoint is reachable."

    # Server errors
    if status_code is not None and 500 <= status_code < 600:
        return "Server error. This is usually temporary -- retry in a few seconds."

    return None
