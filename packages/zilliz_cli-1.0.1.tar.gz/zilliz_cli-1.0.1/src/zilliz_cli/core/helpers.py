# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import click

from zilliz_cli.auth.config import get_config_manager
from zilliz_cli.auth.credentials import resolve_api_key
from zilliz_cli.core.api_caller import APICaller
from zilliz_cli.core.exceptions import CredentialError
from zilliz_cli.core.model_loader import ModelLoader


def get_control_plane_endpoint() -> str:
    """Get control-plane API endpoint from the model definition."""
    try:
        model = ModelLoader().load("control-plane")
        return model.endpoint or "https://api.cloud.zilliz.com"
    except FileNotFoundError:
        return "https://api.cloud.zilliz.com"


def build_caller(ctx) -> APICaller:
    """Build an APICaller with API key from context and control-plane endpoint."""
    mgr = get_config_manager(ctx.obj)
    try:
        api_key = resolve_api_key(ctx.obj.get("api_key"), mgr)
    except CredentialError as e:
        raise click.ClickException(str(e))

    endpoint = get_control_plane_endpoint()
    return APICaller(api_key=api_key, base_url=endpoint)
