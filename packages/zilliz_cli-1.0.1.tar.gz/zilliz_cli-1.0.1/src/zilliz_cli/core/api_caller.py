# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import json
import time
from urllib.parse import quote

import httpx

from zilliz_cli.core.error_hints import get_error_hint
from zilliz_cli.core.exceptions import APIError

_MAX_RETRIES = 3
_BACKOFF_FACTOR = 0.5
_RETRYABLE_STATUS_CODES = {500, 502, 503, 504}


class APICaller:
    def __init__(self, api_key: str, base_url: str = "https://api.cloud.zilliz.com"):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")

    def call(
        self,
        method: str,
        path: str,
        body: dict | None = None,
        path_params: dict | None = None,
        return_raw: bool = False,
    ) -> dict | list | None:
        if path_params:
            for key, value in path_params.items():
                path = path.replace(f"{{{key}}}", quote(str(value), safe=""))

        url = f"{self.base_url}{path}"
        headers = {"Authorization": f"Bearer {self.api_key}"}

        last_error: APIError | None = None
        for attempt in range(_MAX_RETRIES):
            try:
                with httpx.Client(timeout=30.0) as client:
                    if method.upper() == "GET":
                        resp = client.request(method, url, headers=headers, params=body or None)
                    else:
                        resp = client.request(method, url, headers=headers, json=body if body is not None else {})
            except (httpx.ConnectError, httpx.TimeoutException) as e:
                last_error = APIError(0, f"Failed to connect: {e}")
                if attempt < _MAX_RETRIES - 1:
                    time.sleep(_BACKOFF_FACTOR * (2**attempt))
                    continue
                hint = get_error_hint(0, str(e), status_code=None)
                if hint:
                    last_error = APIError(0, f"Failed to connect: {e}\nHint: {hint}")
                raise last_error
            except httpx.HTTPError as e:
                raise APIError(0, f"HTTP error: {e}")

            # Check if we got a retryable server error
            if resp.status_code in _RETRYABLE_STATUS_CODES:
                last_error = APIError(resp.status_code, f"Server error (HTTP {resp.status_code})")
                if attempt < _MAX_RETRIES - 1:
                    time.sleep(_BACKOFF_FACTOR * (2**attempt))
                    continue
                # Last attempt - fall through to parse response normally

            return self._parse_response(resp, return_raw=return_raw)

        # Should not reach here, but just in case
        raise last_error or APIError(0, "Request failed after retries")

    def _parse_response(self, resp: httpx.Response, return_raw: bool = False) -> dict | list | None:
        """Parse Zilliz API response envelope: {"code": N, "data": ...}."""
        try:
            data = resp.json()
        except json.JSONDecodeError:
            raise APIError(resp.status_code, f"Invalid JSON response: {resp.text}")

        # Zilliz v2 APIs always return {"code": N, "data": ...} envelope.
        if not isinstance(data, dict):
            raise APIError(resp.status_code, f"Unexpected response format: {resp.text}")

        code = data.get("code", 0)

        if code in (0, 200) and resp.status_code < 400:
            if return_raw:
                return data
            return data.get("data")

        message = data.get("message") or "Unknown error"

        is_permission_denied = "PermissionDenied" in message or "permission deny" in message.lower()

        if is_permission_denied:
            message += (
                "\n\nThis may be a cluster plan restriction. "
                "Some operations (user/role management, multi-database) are only available on Dedicated clusters."
            )
        elif resp.status_code in (401, 403) or code in (80001,):
            message = f'{message}. Check your API Key with "zilliz configure get api_key".'

        # Append error hint if available
        hint = get_error_hint(code, message, status_code=resp.status_code)
        if hint:
            message += f"\nHint: {hint}"

        raise APIError(code, message)
