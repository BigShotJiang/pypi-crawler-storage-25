# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import configparser
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

_DEFAULT_CONFIG_DIR = Path.home() / ".zilliz"
_ORG_SECTION_PREFIX = "org."


@dataclass
class UserInfo:
    user_id: str
    email: str
    name: str


@dataclass
class OrgInfo:
    org_id: str
    name: str
    api_key: Optional[str] = None


class ConfigManager:
    def __init__(self, config_dir: Path | None = None):
        if config_dir is None:
            env_dir = os.environ.get("ZILLIZ_CONFIG_DIR")
            config_dir = Path(env_dir) if env_dir else _DEFAULT_CONFIG_DIR
        self.config_dir = config_dir
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self._credentials_path = self.config_dir / "credentials"
        self._config_path = self.config_dir / "config"

    # --- Credentials ---

    def get_credential(self, key: str) -> Optional[str]:
        cp = self._read_ini(self._credentials_path)
        return cp.get("default", key, fallback=None)

    def set_credential(self, key: str, value: str):
        cp = self._read_ini(self._credentials_path)
        if not cp.has_section("default"):
            cp.add_section("default")
        cp.set("default", key, value)
        self._write_ini(self._credentials_path, cp)

    # --- Config ---

    def get_config(self, section: str, key: str, fallback=None) -> Optional[str]:
        cp = self._read_ini(self._config_path)
        return cp.get(section, key, fallback=fallback)

    def set_config(self, section: str, key: str, value: str):
        cp = self._read_ini(self._config_path)
        if not cp.has_section(section):
            cp.add_section(section)
        cp.set(section, key, value)
        self._write_ini(self._config_path, cp)

    # --- Context ---

    def get_context(self) -> dict:
        cp = self._read_ini(self._config_path)
        return {
            "cluster_id": cp.get("context", "cluster_id", fallback=None),
            "endpoint": cp.get("context", "endpoint", fallback=None),
            "database": cp.get("context", "database", fallback="default"),
            "plan": cp.get("context", "plan", fallback=None),
        }

    def set_context(
        self,
        cluster_id: str | None = None,
        endpoint: str | None = None,
        database: str | None = None,
        plan: str | None = None,
    ):
        cp = self._read_ini(self._config_path)
        if not cp.has_section("context"):
            cp.add_section("context")
        if cluster_id is not None:
            cp.set("context", "cluster_id", cluster_id)
        if endpoint is not None:
            cp.set("context", "endpoint", endpoint)
        if database is not None:
            cp.set("context", "database", database)
        if plan is not None:
            cp.set("context", "plan", plan)
        self._write_ini(self._config_path, cp)

    def clear_context(self):
        """Clear the current cluster context."""
        cp = self._read_ini(self._config_path)
        if cp.has_section("context"):
            cp.remove_section("context")
        self._write_ini(self._config_path, cp)

    # --- Login Data ---

    def get_user_info(self) -> Optional[UserInfo]:
        """Get current logged-in user info."""
        cp = self._read_ini(self._credentials_path)
        if not cp.has_section("user"):
            return None
        user_id = cp.get("user", "user_id", fallback=None)
        email = cp.get("user", "email", fallback=None)
        name = cp.get("user", "name", fallback="")
        if not email:
            return None
        return UserInfo(user_id=user_id or "", email=email, name=name)

    def save_login_data(self, user_id: str, email: str, name: str, orgs: List[dict]):
        """Save login data from CLI login response.

        Format:
            [user]
            email = xxx
            name = xxx

            [default]
            api_key = xxx
            org_id = xxx
            org_name = xxx

            [org.org-xxx]
            api_key = xxx
            org_name = xxx
        """
        cp = self._read_ini(self._credentials_path)

        # Clear old org sections and legacy [orgs] section
        for section in list(cp.sections()):
            if section.startswith(_ORG_SECTION_PREFIX) or section == "orgs":
                cp.remove_section(section)

        # Save user info
        if not cp.has_section("user"):
            cp.add_section("user")
        cp.set("user", "user_id", user_id)
        cp.set("user", "email", email)
        cp.set("user", "name", name)

        # Set first org as default (before org sections for ordering)
        if orgs:
            first_org = orgs[0]
            first_org_id = first_org.get("orgId", "")
            first_org_name = first_org.get("name", "")
            first_api_keys = first_org.get("apiKeys", [])
            first_api_key = first_api_keys[0].get("key", "") if first_api_keys else ""

            if not cp.has_section("default"):
                cp.add_section("default")
            cp.set("default", "org_id", first_org_id)
            cp.set("default", "org_name", first_org_name)
            if first_api_key:
                cp.set("default", "api_key", first_api_key)

        # Save each org as a separate section
        for org in orgs:
            org_id = org.get("orgId", "")
            org_name = org.get("name", "")
            api_keys = org.get("apiKeys", [])
            api_key = api_keys[0].get("key", "") if api_keys else ""

            section_name = f"{_ORG_SECTION_PREFIX}{org_id}"
            if not cp.has_section(section_name):
                cp.add_section(section_name)
            cp.set(section_name, "org_name", org_name)
            if api_key:
                cp.set(section_name, "api_key", api_key)

        self._write_ini(self._credentials_path, cp)

    def save_api_key_only(self, api_key: str):
        """Save only API key without user info (for manual API key login).

        Format:
            [default]
            api_key = xxx
        """
        cp = self._read_ini(self._credentials_path)

        # Clear all existing login data
        if cp.has_section("user"):
            cp.remove_section("user")

        for section in list(cp.sections()):
            if section.startswith(_ORG_SECTION_PREFIX) or section == "orgs":
                cp.remove_section(section)

        # Save only the API key in default section
        if not cp.has_section("default"):
            cp.add_section("default")
        cp.set("default", "api_key", api_key)
        # Remove org_id and org_name if they exist
        if cp.has_option("default", "org_id"):
            cp.remove_option("default", "org_id")
        if cp.has_option("default", "org_name"):
            cp.remove_option("default", "org_name")

        self._write_ini(self._credentials_path, cp)

    def clear_login_data(self):
        """Clear login data but keep manual config."""
        cp = self._read_ini(self._credentials_path)

        # Remove user section
        if cp.has_section("user"):
            cp.remove_section("user")

        # Remove all org sections and legacy [orgs] section
        for section in list(cp.sections()):
            if section.startswith(_ORG_SECTION_PREFIX) or section == "orgs":
                cp.remove_section(section)

        # Remove default section (login-related)
        if cp.has_section("default"):
            cp.remove_section("default")

        self._write_ini(self._credentials_path, cp)

    def get_all_orgs(self) -> List[OrgInfo]:
        """Get all organizations for current user."""
        cp = self._read_ini(self._credentials_path)
        orgs = []
        for section in cp.sections():
            if section.startswith(_ORG_SECTION_PREFIX):
                org_id = section[len(_ORG_SECTION_PREFIX) :]
                org_name = cp.get(section, "org_name", fallback="")
                api_key = cp.get(section, "api_key", fallback=None)
                orgs.append(OrgInfo(org_id=org_id, name=org_name, api_key=api_key))
        return orgs

    def get_current_org(self) -> Optional[OrgInfo]:
        """Get current organization from [default] section."""
        cp = self._read_ini(self._credentials_path)
        if not cp.has_section("default"):
            return None
        org_id = cp.get("default", "org_id", fallback=None)
        if not org_id:
            return None
        return OrgInfo(
            org_id=org_id,
            name=cp.get("default", "org_name", fallback=""),
            api_key=cp.get("default", "api_key", fallback=None),
        )

    def set_current_org(self, org_id: str):
        """Set current organization by copying org info to [default] section.

        Raises:
            ValueError: If the organization is not found in credentials.
        """
        cp = self._read_ini(self._credentials_path)

        # Find the org section
        section_name = f"{_ORG_SECTION_PREFIX}{org_id}"
        if not cp.has_section(section_name):
            raise ValueError(f"Organization '{org_id}' not found in credentials")

        org_name = cp.get(section_name, "org_name", fallback="")
        api_key = cp.get(section_name, "api_key", fallback=None)

        # Update default section
        if not cp.has_section("default"):
            cp.add_section("default")
        cp.set("default", "org_id", org_id)
        cp.set("default", "org_name", org_name)
        if api_key:
            cp.set("default", "api_key", api_key)

        self._write_ini(self._credentials_path, cp)

    # --- List all ---

    def list_all(self) -> dict:
        creds_cp = self._read_ini(self._credentials_path)
        config_cp = self._read_ini(self._config_path)

        credentials = {}
        if creds_cp.has_section("default"):
            credentials = dict(creds_cp.items("default"))

        config = {}
        if config_cp.has_section("default"):
            config.update(dict(config_cp.items("default")))
        if config_cp.has_section("context"):
            config.update(dict(config_cp.items("context")))

        return {"credentials": credentials, "config": config}

    # --- Clear ---

    def clear_credentials(self):
        """Remove all stored credentials."""
        if self._credentials_path.exists():
            self._credentials_path.unlink()

    # --- Internal ---

    def _read_ini(self, path: Path) -> configparser.ConfigParser:
        cp = configparser.ConfigParser()
        if path.exists():
            cp.read(path)
        return cp

    def _write_ini(self, path: Path, cp: configparser.ConfigParser):
        with open(path, "w") as f:
            cp.write(f)
        if path == self._credentials_path:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)


def get_config_manager(ctx_obj: dict) -> "ConfigManager":
    """Get or create a cached ConfigManager from click context object."""
    if "config_manager" not in ctx_obj:
        config_dir = ctx_obj.get("config_dir")
        ctx_obj["config_manager"] = ConfigManager(config_dir) if config_dir else ConfigManager()
    mgr: ConfigManager = ctx_obj["config_manager"]
    return mgr
