import os

from zilliz_cli.auth.config import ConfigManager
from zilliz_cli.core.exceptions import CredentialError


def _validate_api_key(api_key: str, source: str) -> str:
    """Validate that API key contains only ASCII characters (required by HTTP headers)."""
    try:
        api_key.encode("ascii")
    except UnicodeEncodeError:
        raise CredentialError(
            f'API key from {source} contains non-ASCII characters. Please re-configure with "zilliz configure".'
        )
    return api_key


def resolve_api_key(cli_api_key: str | None, config_manager: ConfigManager) -> str:
    """Resolve API key: CLI arg > env var > config file."""
    if cli_api_key:
        return _validate_api_key(cli_api_key, "--api-key argument")

    env_key = os.environ.get("ZILLIZ_API_KEY")
    if env_key:
        return _validate_api_key(env_key, "ZILLIZ_API_KEY environment variable")

    file_key = config_manager.get_credential("api_key")
    if file_key:
        return _validate_api_key(file_key, "~/.zilliz/credentials")

    raise CredentialError(
        'No API key found. Run "zilliz configure" to set up credentials, or set ZILLIZ_API_KEY environment variable.'
    )
