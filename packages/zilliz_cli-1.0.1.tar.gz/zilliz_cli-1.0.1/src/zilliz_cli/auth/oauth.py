# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

"""Auth0 Device Code Flow implementation for CLI login."""

import time
import webbrowser
from dataclasses import dataclass

import httpx

from zilliz_cli.core.exceptions import ZillizCLIError
from zilliz_cli.core.model_loader import ModelLoader


class OAuthError(ZillizCLIError):
    """OAuth-specific errors."""

    pass


@dataclass
class DeviceCodeResponse:
    """Response from Auth0 device authorization endpoint."""

    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str
    expires_in: int
    interval: int


@dataclass
class TokenResponse:
    """Response from Auth0 token endpoint."""

    access_token: str
    token_type: str
    expires_in: int


@dataclass
class AuthConfig:
    """Auth configuration loaded from control-plane.json."""

    auth0_domain: str
    client_id: str
    login_api: str


def load_auth_config() -> AuthConfig:
    """Load auth configuration from control-plane.json."""
    model = ModelLoader().load("control-plane")
    if not model.auth:
        raise OAuthError("Auth configuration not found in control-plane.json")
    return AuthConfig(
        auth0_domain=model.auth.auth0_domain,
        client_id=model.auth.client_id,
        login_api=model.auth.login_api,
    )


class Auth0DeviceCodeFlow:
    """Implements Auth0 Device Code Flow for CLI authentication."""

    def __init__(self, config: AuthConfig):
        self.config = config
        self.client = httpx.Client(timeout=30.0)

    def request_device_code(self) -> DeviceCodeResponse:
        """
        Request a device code from Auth0.

        Returns:
            DeviceCodeResponse with device_code, user_code, and verification URLs
        """
        url = f"{self.config.auth0_domain}/oauth/device/code"
        data = {
            "client_id": self.config.client_id,
            "scope": "openid email profile",
        }

        response = self.client.post(url, data=data)

        if response.status_code != 200:
            raise OAuthError(f"Failed to request device code: {response.text}")

        result = response.json()
        try:
            return DeviceCodeResponse(
                device_code=result["device_code"],
                user_code=result["user_code"],
                verification_uri=result["verification_uri"],
                verification_uri_complete=result["verification_uri_complete"],
                expires_in=result["expires_in"],
                interval=result.get("interval", 5),
            )
        except KeyError as e:
            raise OAuthError(f"Invalid Auth0 response: missing field {e}")

    def poll_for_token(self, device_code: str, interval: int = 5, timeout: int = 300) -> TokenResponse:
        """
        Poll Auth0 for access token after user authenticates.

        Args:
            device_code: The device code from request_device_code()
            interval: Polling interval in seconds
            timeout: Maximum time to wait for authentication in seconds

        Returns:
            TokenResponse with access_token

        Raises:
            OAuthError: If authentication fails or times out
        """
        url = f"{self.config.auth0_domain}/oauth/token"
        data = {
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            "device_code": device_code,
            "client_id": self.config.client_id,
        }

        start_time = time.time()

        while time.time() - start_time < timeout:
            response = self.client.post(url, data=data)
            result = response.json()

            if response.status_code == 200:
                try:
                    return TokenResponse(
                        access_token=result["access_token"],
                        token_type=result["token_type"],
                        expires_in=result["expires_in"],
                    )
                except KeyError as e:
                    raise OAuthError(f"Invalid Auth0 token response: missing field {e}")

            error = result.get("error")

            if error == "authorization_pending":
                time.sleep(interval)
                continue
            elif error == "slow_down":
                interval = min(interval + 5, 60)  # Cap at 60 seconds max
                time.sleep(interval)
                continue
            elif error == "expired_token":
                raise OAuthError("Authentication timed out. Please try again.")
            elif error == "access_denied":
                raise OAuthError("Authentication was denied.")
            else:
                error_desc = result.get("error_description", "Unknown error")
                raise OAuthError(f"Authentication failed: {error_desc}")

        raise OAuthError("Authentication timed out. Please try again.")

    def open_browser(self, verification_uri_complete: str) -> bool:
        """Open the browser to the verification URL."""
        try:
            return webbrowser.open(verification_uri_complete)
        except Exception:
            return False

    def close(self):
        """Close the HTTP client."""
        self.client.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False


def perform_device_code_login(open_browser: bool = True, echo_func=None) -> tuple[TokenResponse, AuthConfig]:
    """
    Perform complete device code flow login.

    Args:
        open_browser: Whether to automatically open the browser
        echo_func: Optional function for output (e.g., click.echo)

    Returns:
        Tuple of (TokenResponse with access_token, AuthConfig)
    """

    def echo(msg):
        if echo_func:
            echo_func(msg)
        else:
            print(msg)

    config = load_auth_config()

    with Auth0DeviceCodeFlow(config) as auth:
        device_code_resp = auth.request_device_code()

        echo(f"\nYour verification code: {device_code_resp.user_code}")
        echo(f"Please visit: {device_code_resp.verification_uri_complete}")

        if open_browser:
            echo("\nOpening browser to complete login...")
            if not auth.open_browser(device_code_resp.verification_uri_complete):
                echo("Could not open browser. Please visit the URL above manually.")
        else:
            echo("\nPlease visit the URL above to complete login.")

        echo("\nWaiting for authentication...")

        token_resp = auth.poll_for_token(
            device_code_resp.device_code,
            interval=device_code_resp.interval,
        )

        return token_resp, config
