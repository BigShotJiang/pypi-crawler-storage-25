# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import json
import sys

import click

from zilliz_cli import __version__
from zilliz_cli.auth.config import get_config_manager
from zilliz_cli.commands.alert import alert
from zilliz_cli.commands.auth import auth, login, logout
from zilliz_cli.commands.completion import completion
from zilliz_cli.commands.configure import configure
from zilliz_cli.commands.context import context
from zilliz_cli.commands.version import version
from zilliz_cli.core.command_factory import CommandFactory, SmartGroup
from zilliz_cli.core.model_loader import ModelLoader


class _SectionGroup(SmartGroup):
    """Group that organizes subcommands into labeled sections for cleaner help."""

    def __init__(self, *args, **kwargs):
        self.sections: list[tuple[str, list[str]]] = []
        super().__init__(*args, **kwargs)

    def add_section(self, title: str, commands: list[str]):
        self.sections.append((title, commands))

    def format_commands(self, ctx, formatter):
        if not self.sections:
            return super().format_commands(ctx, formatter)

        commands = {}
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is not None:
                commands[name] = cmd

        for title, names in self.sections:
            rows = []
            for name in names:
                cmd = commands.pop(name, None)
                if cmd is None:
                    continue
                help_text = cmd.get_short_help_str(limit=formatter.width)
                rows.append((name, help_text))
            if rows:
                with formatter.section(title):
                    formatter.write_dl(rows)

        # Remaining non-hidden commands go to "Other"
        visible = {n: c for n, c in commands.items() if not c.hidden}
        if visible:
            rows = [(name, visible[name].get_short_help_str(limit=formatter.width)) for name in sorted(visible)]
            with formatter.section("Other"):
                formatter.write_dl(rows)


@click.group(cls=_SectionGroup)
@click.version_option(__version__, prog_name="zilliz")
@click.option(
    "--output", "-o", type=click.Choice(["json", "table", "text", "yaml", "csv"]), default=None, help="Output format."
)
@click.option("--api-key", default=None, help="Zilliz Cloud API Key.", envvar="ZILLIZ_API_KEY")
@click.option("--no-header", is_flag=True, default=False, help="Omit header row (table/csv output).")
@click.option("--query", "-q", default=None, help="JMESPath expression to filter output.")
@click.pass_context
def main(ctx, output, api_key, no_header, query):
    """Zilliz Cloud CLI - Manage clusters, collections, and vectors."""
    ctx.ensure_object(dict)
    ctx.obj["output_format"] = output
    ctx.obj["api_key"] = api_key
    ctx.obj["no_header"] = no_header
    ctx.obj["query"] = query


def _resolve_control_plane_endpoint(ctx_obj):
    """Resolve the control plane endpoint, respecting user's base_url config."""
    mgr = get_config_manager(ctx_obj)
    base_url = mgr.get_config("default", "base_url")
    return base_url  # None means fall back to model.endpoint


def _resolve_data_plane_endpoint(ctx_obj):
    """Resolve the data plane endpoint from user's current context."""
    mgr = get_config_manager(ctx_obj)
    context_data = mgr.get_context()
    endpoint = context_data.get("endpoint")
    if not endpoint:
        raise click.ClickException('No context set. Run "zilliz context set --cluster-id <id>" first.')
    return endpoint


def _get_context_data(ctx_obj):
    """Read current context data."""
    mgr = get_config_manager(ctx_obj)
    return mgr.get_context()


# Hand-written commands
main.add_command(completion)
main.add_command(configure)
main.add_command(context)
main.add_command(version)
main.add_command(auth)
main.add_command(login)
main.add_command(logout)
main.add_command(alert)

# Model-driven commands (control plane)
_cp_groups = {}
try:
    _cp_model = ModelLoader().load("control-plane")
    _cp_factory = CommandFactory(_cp_model, endpoint_resolver=_resolve_control_plane_endpoint)
    _cp_groups = _cp_factory.create_groups()
    for _name, _group in _cp_groups.items():
        main.add_command(_group)

    # Inject hand-written commands into model-driven groups
    if "cluster" in _cp_groups:
        from zilliz_cli.commands.cluster import create_cluster
        from zilliz_cli.commands.metrics import metrics

        _cp_groups["cluster"].add_command(create_cluster)
        _cp_groups["cluster"].add_command(metrics)
    if "billing" in _cp_groups:
        from zilliz_cli.commands.billing import invoices, usage

        _cp_groups["billing"].add_command(usage)
        _cp_groups["billing"].add_command(invoices)
    if "job" in _cp_groups:
        from zilliz_cli.commands.job import describe_job

        _cp_groups["job"].add_command(describe_job)
except FileNotFoundError:
    pass
except json.JSONDecodeError as e:
    print(f"Warning: failed to load control-plane commands: {e}", file=sys.stderr)

# Model-driven commands (data plane)
try:
    _dp_model = ModelLoader().load("data-plane")
    _dp_factory = CommandFactory(
        _dp_model, endpoint_resolver=_resolve_data_plane_endpoint, context_provider=_get_context_data
    )
    for _name, _group in _dp_factory.create_groups().items():
        main.add_command(_group)
except FileNotFoundError:
    pass
except json.JSONDecodeError as e:
    print(f"Warning: failed to load data-plane commands: {e}", file=sys.stderr)

# Define top-level command sections for help display
main.add_section(
    "Cloud Management",
    [
        "cluster",
        "project",
        "backup",
        "volume",
        "import",
        "billing",
        "alert",
        "job",
    ],
)

main.add_section(
    "Data Operations",
    [
        "collection",
        "vector",
        "database",
        "index",
        "partition",
        "user",
        "role",
        "alias",
    ],
)

main.add_section(
    "Configuration",
    [
        "login",
        "logout",
        "auth",
        "configure",
        "context",
        "completion",
    ],
)
