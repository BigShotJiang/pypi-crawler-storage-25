import json

import pytest


@pytest.mark.acceptance
class TestVersion:
    def test_version_default(self, run_cli):
        result = run_cli("version")
        assert result.returncode == 0
        assert "0.1.0" in result.stdout

    def test_version_json(self, run_cli):
        result = run_cli("version", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data["version"] == "0.1.0"


@pytest.mark.acceptance
class TestHelp:
    def test_main_help(self, run_cli):
        result = run_cli("--help")
        assert result.returncode == 0
        # All 14 resource groups must appear
        for cmd in (
            "cluster",
            "collection",
            "vector",
            "configure",
            "context",
            "version",
            "project",
            "backup",
            "region",
            "import-job",
            "volume",
            "database",
            "index",
            "partition",
            "user",
            "role",
            "alias",
        ):
            assert cmd in result.stdout, f"Missing command: {cmd}"

    def test_cluster_help(self, run_cli):
        result = run_cli("cluster", "--help")
        assert result.returncode == 0
        for sub in (
            "list",
            "describe",
            "create",
            "create-free",
            "create-dedicated",
            "delete",
            "suspend",
            "resume",
            "modify",
        ):
            assert sub in result.stdout, f"Missing cluster subcommand: {sub}"

    def test_collection_help(self, run_cli):
        result = run_cli("collection", "--help")
        assert result.returncode == 0
        for sub in (
            "list",
            "describe",
            "create",
            "drop",
            "has",
            "rename",
            "load",
            "release",
            "get-stats",
            "get-load-state",
            "flush",
            "compact",
        ):
            assert sub in result.stdout, f"Missing collection subcommand: {sub}"

    def test_vector_help(self, run_cli):
        result = run_cli("vector", "--help")
        assert result.returncode == 0
        for sub in (
            "search",
            "query",
            "insert",
            "hybrid-search",
            "upsert",
            "get",
            "delete",
        ):
            assert sub in result.stdout, f"Missing vector subcommand: {sub}"

    def test_project_help(self, run_cli):
        result = run_cli("project", "--help")
        assert result.returncode == 0
        for sub in ("list", "describe", "create", "upgrade"):
            assert sub in result.stdout, f"Missing project subcommand: {sub}"

    def test_backup_help(self, run_cli):
        result = run_cli("backup", "--help")
        assert result.returncode == 0
        for sub in (
            "create",
            "list",
            "describe",
            "delete",
            "export",
            "restore-cluster",
            "restore-collection",
            "get-policy",
            "set-policy",
        ):
            assert sub in result.stdout, f"Missing backup subcommand: {sub}"

    def test_region_help(self, run_cli):
        result = run_cli("region", "--help")
        assert result.returncode == 0
        for sub in ("list-providers", "list"):
            assert sub in result.stdout, f"Missing region subcommand: {sub}"

    def test_import_job_help(self, run_cli):
        result = run_cli("import-job", "--help")
        assert result.returncode == 0
        for sub in ("create", "list", "get-progress"):
            assert sub in result.stdout, f"Missing import-job subcommand: {sub}"

    def test_volume_help(self, run_cli):
        result = run_cli("volume", "--help")
        assert result.returncode == 0
        for sub in ("create", "list", "delete"):
            assert sub in result.stdout, f"Missing volume subcommand: {sub}"

    def test_database_help(self, run_cli):
        result = run_cli("database", "--help")
        assert result.returncode == 0
        for sub in ("create", "list", "describe", "drop"):
            assert sub in result.stdout, f"Missing database subcommand: {sub}"

    def test_index_help(self, run_cli):
        result = run_cli("index", "--help")
        assert result.returncode == 0
        for sub in ("create", "list", "describe", "drop"):
            assert sub in result.stdout, f"Missing index subcommand: {sub}"

    def test_partition_help(self, run_cli):
        result = run_cli("partition", "--help")
        assert result.returncode == 0
        for sub in ("create", "list", "has", "get-stats", "load", "release", "drop"):
            assert sub in result.stdout, f"Missing partition subcommand: {sub}"

    def test_user_help(self, run_cli):
        result = run_cli("user", "--help")
        assert result.returncode == 0
        for sub in (
            "create",
            "list",
            "describe",
            "drop",
            "update-password",
            "grant-role",
            "revoke-role",
        ):
            assert sub in result.stdout, f"Missing user subcommand: {sub}"

    def test_role_help(self, run_cli):
        result = run_cli("role", "--help")
        assert result.returncode == 0
        for sub in (
            "create",
            "list",
            "describe",
            "drop",
            "grant-privilege",
            "revoke-privilege",
        ):
            assert sub in result.stdout, f"Missing role subcommand: {sub}"

    def test_alias_help(self, run_cli):
        result = run_cli("alias", "--help")
        assert result.returncode == 0
        for sub in ("create", "list", "describe", "alter", "drop"):
            assert sub in result.stdout, f"Missing alias subcommand: {sub}"


@pytest.mark.acceptance
class TestConfigure:
    def test_configure_set_get_list(self, run_cli):
        # set
        result = run_cli("configure", "set", "output", "json")
        assert result.returncode == 0
        assert "json" in result.stdout

        # get
        result = run_cli("configure", "get", "output")
        assert result.returncode == 0
        assert "json" in result.stdout

        # list
        result = run_cli("configure", "list")
        assert result.returncode == 0
        assert "output" in result.stdout
