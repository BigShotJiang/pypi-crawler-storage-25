import json
import secrets

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestPartitionLifecycle:
    """Test partition create -> list -> has -> get-stats -> drop lifecycle."""

    def test_partition_lifecycle(self, run_cli, test_collection):
        partition_name = f"test_part_{secrets.token_hex(4)}"

        # Create
        result = run_cli(
            "partition",
            "create",
            "--collection",
            test_collection,
            "--name",
            partition_name,
            "-o",
            "json",
        )
        assert result.returncode == 0
        _log(f"Created partition '{partition_name}' in '{test_collection}'")

        try:
            # List
            result = run_cli(
                "partition",
                "list",
                "--collection",
                test_collection,
                "-o",
                "json",
            )
            assert result.returncode == 0
            data = json.loads(result.stdout)
            assert isinstance(data, list)
            assert partition_name in data or partition_name in str(data)
            _log(f"Partitions: {data}")

            # Has
            result = run_cli(
                "partition",
                "has",
                "--collection",
                test_collection,
                "--name",
                partition_name,
                "-o",
                "json",
            )
            assert result.returncode == 0
            data = json.loads(result.stdout)
            assert data.get("has") is True
            _log(f"Partition '{partition_name}' exists: {data.get('has')}")

            # Get stats
            result = run_cli(
                "partition",
                "get-stats",
                "--collection",
                test_collection,
                "--name",
                partition_name,
                "-o",
                "json",
            )
            assert result.returncode == 0
            data = json.loads(result.stdout)
            _log(f"Partition stats: rowCount={data.get('rowCount')}")
        finally:
            # Always clean up: release then drop
            run_cli(
                "partition",
                "release",
                "--collection",
                test_collection,
                "--names",
                partition_name,
                "-o",
                "json",
            )
            drop_result = run_cli(
                "partition",
                "drop",
                "--collection",
                test_collection,
                "--name",
                partition_name,
                "-o",
                "json",
            )
            if drop_result.returncode == 0:
                _log(f"Dropped partition '{partition_name}'")
            else:
                _log(f"WARNING: Failed to drop partition '{partition_name}': {drop_result.stdout}")

        # Verify dropped
        result = run_cli(
            "partition",
            "has",
            "--collection",
            test_collection,
            "--name",
            partition_name,
            "-o",
            "json",
        )
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data.get("has") is False
        _log(f"Verified partition '{partition_name}' no longer exists")
