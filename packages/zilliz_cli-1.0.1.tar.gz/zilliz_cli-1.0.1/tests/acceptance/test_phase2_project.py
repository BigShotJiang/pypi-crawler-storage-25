import json

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestProjectList:
    """Test project list with various output formats."""

    def test_project_list_json(self, run_cli, api_key):
        result = run_cli("project", "list", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert isinstance(data, list)
        assert len(data) > 0
        first = data[0]
        assert "projectId" in first
        assert "projectName" in first
        _log(f"Listed {len(data)} projects, first: {first['projectName']} ({first['projectId']})")

    def test_project_list_table(self, run_cli, api_key):
        result = run_cli("project", "list", "-o", "table")
        assert result.returncode == 0
        assert len(result.stdout.strip()) > 0

    def test_project_list_text(self, run_cli, api_key):
        result = run_cli("project", "list", "-o", "text")
        assert result.returncode == 0
        assert len(result.stdout.strip()) > 0


@pytest.mark.acceptance
class TestProjectDescribe:
    """Test project describe using project_id discovered from cloud_info."""

    def test_project_describe_json(self, run_cli, cloud_info):
        project_id = cloud_info["project_id"]
        result = run_cli("project", "describe", "--project-id", project_id, "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data["projectId"] == project_id
        assert "projectName" in data
        _log(f"Project {project_id}: name={data['projectName']}, plan={data.get('plan')}")

    def test_project_describe_table(self, run_cli, cloud_info):
        project_id = cloud_info["project_id"]
        result = run_cli("project", "describe", "--project-id", project_id, "-o", "table")
        assert result.returncode == 0
        assert project_id in result.stdout
