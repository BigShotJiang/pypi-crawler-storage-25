import json

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestContextResolve:
    """Test context commands with real cluster."""

    def test_context_set_auto_resolve(self, run_cli, test_cluster):
        result = run_cli("context", "set", "--cluster-id", test_cluster)
        assert result.returncode == 0
        assert test_cluster in result.stdout
        _log(f"Auto-resolved endpoint for cluster {test_cluster}")

    def test_context_set_with_database(self, run_cli, test_cluster):
        # First ensure context is set with cluster
        run_cli("context", "set", "--cluster-id", test_cluster)
        result = run_cli("context", "set", "--database", "mydb")
        assert result.returncode == 0
        _log("Set database to 'mydb'")
        # Restore to default database to avoid polluting subsequent tests
        run_cli("context", "set", "--database", "default")
        _log("Restored database to 'default'")

    def test_context_current(self, run_cli, test_context):
        result = run_cli("context", "current")
        assert result.returncode == 0
        assert test_context in result.stdout

    def test_context_current_json(self, run_cli, test_context):
        result = run_cli("context", "current", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data["cluster_id"] == test_context
        assert data["endpoint"] is not None
        _log(
            f"Current context: cluster={data['cluster_id']}, "
            f"endpoint={data['endpoint'][:60]}, "
            f"database={data.get('database', 'N/A')}"
        )
