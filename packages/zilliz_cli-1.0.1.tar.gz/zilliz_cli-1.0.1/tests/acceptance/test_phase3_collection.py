import json

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestCollectionLifecycle:
    """Test collection create -> list -> describe -> drop."""

    def test_collection_create_quick(self, run_cli, test_context):
        """Create collection with --dimension shortcut."""
        name = "zilliz_cli_test_quick"
        result = run_cli(
            "collection",
            "create",
            "--name",
            name,
            "--dimension",
            "4",
            "--metric-type",
            "COSINE",
        )
        assert result.returncode == 0
        _log(f"Quick-created collection '{name}'")

        # Cleanup
        run_cli("collection", "drop", "--name", name)
        _log(f"Dropped temp collection '{name}'")

    def test_collection_list_json(self, run_cli, test_collection):
        result = run_cli("collection", "list", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert isinstance(data, list)
        assert test_collection in data
        _log(f"Collections: {data}")

    def test_collection_list_table(self, run_cli, test_collection):
        result = run_cli("collection", "list", "-o", "table")
        assert result.returncode == 0
        assert len(result.stdout.strip()) > 0

    def test_collection_describe(self, run_cli, test_collection):
        result = run_cli("collection", "describe", "--name", test_collection, "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data["collectionName"] == test_collection
        _log(
            f"Collection schema: name={data['collectionName']}, "
            f"shardsNum={data.get('shardsNum')}, "
            f"fields={len(data.get('fields', []))}"
        )
        for f in data.get("fields", []):
            _log(
                f"  field: name={f.get('name')}, type={f.get('type')}, "
                f"primaryKey={f.get('primaryKey', False)}, autoId={f.get('autoId', False)}"
            )

    def test_collection_describe_nonexistent(self, run_cli, test_context):
        result = run_cli("collection", "describe", "--name", "nonexistent_xyz_999")
        assert result.returncode != 0
        _log("Describe nonexistent collection -> correctly returned error")

    def test_collection_drop(self, run_cli, test_context):
        """Create a temp collection and drop it."""
        name = "zilliz_cli_test_drop_me"
        run_cli("collection", "create", "--name", name, "--dimension", "4")
        result = run_cli("collection", "drop", "--name", name)
        assert result.returncode == 0
        _log(f"Create + drop lifecycle for '{name}' succeeded")


@pytest.mark.acceptance
class TestCollectionNewOps:
    """Test new collection operations: has, get-stats, get-load-state, flush, compact."""

    def test_collection_has(self, run_cli, test_collection):
        result = run_cli("collection", "has", "--name", test_collection, "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data.get("has") is True
        _log(f"Collection '{test_collection}' exists: {data.get('has')}")

    def test_collection_has_nonexistent(self, run_cli, test_context):
        result = run_cli("collection", "has", "--name", "nonexistent_xyz_999", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data.get("has") is False

    def test_collection_get_stats(self, run_cli, test_collection):
        result = run_cli("collection", "get-stats", "--name", test_collection, "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert "rowCount" in data
        _log(f"Collection '{test_collection}' stats: rowCount={data.get('rowCount')}")

    def test_collection_get_load_state(self, run_cli, test_collection):
        result = run_cli("collection", "get-load-state", "--name", test_collection, "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert "loadState" in data
        _log(f"Collection '{test_collection}' load state: {data.get('loadState')}")

    def test_collection_flush(self, run_cli, test_collection):
        result = run_cli("collection", "flush", "--name", test_collection, "-o", "json")
        assert result.returncode == 0
        _log(f"Flushed collection '{test_collection}'")

    def test_collection_compact(self, run_cli, test_collection):
        result = run_cli("collection", "compact", "--name", test_collection, "-o", "json")
        assert result.returncode == 0
        _log(f"Compacted collection '{test_collection}'")
