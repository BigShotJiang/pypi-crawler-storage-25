import json

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestIndexLifecycle:
    """Test index list and describe on the test collection.

    Note: The test collection is auto-indexed on creation (quick setup with
    --dimension creates an AUTOINDEX). We verify list and describe operations
    rather than create/drop to avoid disrupting the collection state.
    """

    def test_index_list(self, run_cli, test_collection):
        result = run_cli(
            "index",
            "list",
            "--collection",
            test_collection,
            "-o",
            "json",
        )
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert isinstance(data, list)
        _log(f"Indexes on '{test_collection}': {len(data)} index(es)")
        if data:
            _log(f"  First index: {data[0]}")

    def test_index_describe(self, run_cli, test_collection):
        # First get index name from list
        list_result = run_cli(
            "index",
            "list",
            "--collection",
            test_collection,
            "-o",
            "json",
        )
        assert list_result.returncode == 0
        indexes = json.loads(list_result.stdout)
        if not indexes:
            pytest.skip("No indexes found on test collection")

        # index list returns a list of strings (field names that have indexes)
        index_name = indexes[0] if isinstance(indexes[0], str) else indexes[0].get("indexName", "")
        if not index_name:
            pytest.skip("Could not determine index name")

        result = run_cli(
            "index",
            "describe",
            "--collection",
            test_collection,
            "--index-name",
            index_name,
            "-o",
            "json",
        )
        assert result.returncode == 0
        data = json.loads(result.stdout)
        # index describe may return a list or a dict
        if isinstance(data, list) and data:
            first = data[0]
            _log(
                f"Index '{index_name}' details: fieldName={first.get('fieldName')}, "
                f"indexState={first.get('indexState')}"
            )
        elif isinstance(data, dict):
            _log(
                f"Index '{index_name}' details: metricType={data.get('metricType')}, indexType={data.get('indexType')}"
            )
        else:
            _log(f"Index '{index_name}' details: {data}")
