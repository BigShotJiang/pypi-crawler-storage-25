import json
import os

import pytest

requires_cluster_and_collection = pytest.mark.skipif(
    not os.environ.get("ZILLIZ_API_KEY")
    or not os.environ.get("ZILLIZ_CLUSTER_ID")
    or not os.environ.get("ZILLIZ_COLLECTION_NAME"),
    reason="ZILLIZ_API_KEY, ZILLIZ_CLUSTER_ID and ZILLIZ_COLLECTION_NAME required",
)


@pytest.mark.e2e
@requires_cluster_and_collection
class TestVectorE2E:
    def _setup_context(self, run_cli):
        cluster_id = os.environ["ZILLIZ_CLUSTER_ID"]
        result = run_cli("context", "set", "--cluster-id", cluster_id)
        assert result.returncode == 0

    def test_vector_search(self, run_cli):
        self._setup_context(run_cli)
        collection = os.environ["ZILLIZ_COLLECTION_NAME"]
        dim = int(os.environ.get("ZILLIZ_VECTOR_DIM", "3"))
        vector = [0.1] * dim
        data_json = json.dumps([vector])

        result = run_cli(
            "vector", "search", "--collection", collection, "--data", data_json, "--limit", "3", "--output", "json"
        )
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert isinstance(data, list)

    def test_vector_query(self, run_cli):
        self._setup_context(run_cli)
        collection = os.environ["ZILLIZ_COLLECTION_NAME"]

        result = run_cli(
            "vector", "query", "--collection", collection, "--filter", "id >= 0", "--limit", "3", "--output", "json"
        )
        assert result.returncode == 0
