import json
import os

import pytest

requires_cluster = pytest.mark.skipif(
    not os.environ.get("ZILLIZ_API_KEY") or not os.environ.get("ZILLIZ_CLUSTER_ID"),
    reason="ZILLIZ_API_KEY and ZILLIZ_CLUSTER_ID required",
)


@pytest.mark.e2e
@requires_cluster
class TestCollectionE2E:
    def _setup_context(self, run_cli):
        """Set cluster context before data plane operations."""
        cluster_id = os.environ["ZILLIZ_CLUSTER_ID"]
        result = run_cli("context", "set", "--cluster-id", cluster_id)
        assert result.returncode == 0

    def test_collection_list_json(self, run_cli):
        self._setup_context(run_cli)
        result = run_cli("collection", "list", "--output", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert isinstance(data, list)

    def test_collection_list_table(self, run_cli):
        self._setup_context(run_cli)
        result = run_cli("collection", "list", "--output", "table")
        assert result.returncode == 0

    def test_collection_describe_nonexistent(self, run_cli):
        self._setup_context(run_cli)
        result = run_cli("collection", "describe", "--name", "nonexistent_collection_xyz", "--output", "json")
        assert result.returncode != 0
