import os
import subprocess

import pytest

requires_api_key = pytest.mark.skipif(not os.environ.get("ZILLIZ_API_KEY"), reason="ZILLIZ_API_KEY required")


@pytest.fixture
def run_cli(tmp_path):
    """Run the zilliz CLI as a subprocess with isolated config directory."""

    def _run(*args):
        env = os.environ.copy()
        env["ZILLIZ_CONFIG_DIR"] = str(tmp_path / ".zilliz")
        return subprocess.run(
            ["zilliz", *args],
            capture_output=True,
            text=True,
            env=env,
            timeout=30,
        )

    return _run
