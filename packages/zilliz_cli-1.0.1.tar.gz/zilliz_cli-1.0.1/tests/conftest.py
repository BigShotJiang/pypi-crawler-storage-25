import pytest
from click.testing import CliRunner


@pytest.fixture
def cli_runner():
    """Click CLI test runner."""
    return CliRunner()


@pytest.fixture
def config_dir(tmp_path):
    """Temporary config directory for testing (~/.zilliz/ replacement)."""
    d = tmp_path / ".zilliz"
    d.mkdir()
    return d
