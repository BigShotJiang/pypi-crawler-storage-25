from zilliz_cli.core.error_hints import get_error_hint


class TestErrorHints:
    def test_auth_error_suggestion(self):
        hint = get_error_hint(80001, "Unauthorized", status_code=401)
        assert hint is not None
        assert "API" in hint or "api" in hint.lower()

    def test_network_timeout_suggestion(self):
        hint = get_error_hint(0, "Connection timed out", status_code=None)
        assert hint is not None
        assert "network" in hint.lower() or "connection" in hint.lower() or "timeout" in hint.lower()

    def test_rate_limit_suggestion(self):
        hint = get_error_hint(0, "Rate limit exceeded", status_code=429)
        assert hint is not None
        assert "rate" in hint.lower() or "retry" in hint.lower() or "wait" in hint.lower()

    def test_permission_denied_suggestion(self):
        hint = get_error_hint(0, "PermissionDenied", status_code=403)
        assert hint is not None

    def test_no_hint_for_unknown_error(self):
        hint = get_error_hint(99999, "Something weird happened", status_code=200)
        assert hint is None

    def test_server_error_suggestion(self):
        hint = get_error_hint(0, "Internal server error", status_code=500)
        assert hint is not None
