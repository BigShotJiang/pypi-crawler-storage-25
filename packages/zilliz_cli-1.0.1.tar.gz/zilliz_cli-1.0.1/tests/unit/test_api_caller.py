import json
from unittest.mock import MagicMock, patch

import httpx
import pytest

from zilliz_cli.core.api_caller import APICaller
from zilliz_cli.core.exceptions import APIError


def _mock_response(status_code=200, json_data=None):
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_data or {}
    resp.text = json.dumps(json_data or {})
    resp.headers = {}
    return resp


class TestAPICallerSuccess:
    def test_get_request(self):
        resp = _mock_response(200, {"code": 0, "data": [{"clusterId": "c1"}]})
        with patch.object(httpx.Client, "request", return_value=resp) as mock_req:
            caller = APICaller(api_key="test-key", base_url="https://api.example.com")
            result = caller.call("GET", "/v2/clusters")

            assert result == [{"clusterId": "c1"}]
            mock_req.assert_called_once()
            call_kwargs = mock_req.call_args
            assert call_kwargs.kwargs["headers"]["Authorization"] == "Bearer test-key"

    def test_post_request_with_body(self):
        resp = _mock_response(200, {"code": 0, "data": {"clusterId": "new-1"}})
        with patch.object(httpx.Client, "request", return_value=resp):
            caller = APICaller(api_key="test-key", base_url="https://api.example.com")
            result = caller.call(
                "POST", "/v2/clusters/createServerless", body={"clusterName": "test", "projectId": "p1"}
            )
            assert result["clusterId"] == "new-1"

    def test_path_param_substitution(self):
        resp = _mock_response(200, {"code": 0, "data": {"clusterId": "c1", "status": "RUNNING"}})
        with patch.object(httpx.Client, "request", return_value=resp) as mock_req:
            caller = APICaller(api_key="test-key", base_url="https://api.example.com")
            caller.call("GET", "/v2/clusters/{clusterId}", path_params={"clusterId": "c1"})
            call_args = mock_req.call_args
            # url is the 2nd positional arg: client.request(method, url, ...)
            assert "/v2/clusters/c1" in call_args.args[1]

    def test_response_with_code_200(self):
        resp = _mock_response(200, {"code": 200, "data": {"clusterId": "c1"}})
        with patch.object(httpx.Client, "request", return_value=resp):
            caller = APICaller(api_key="test-key", base_url="https://api.example.com")
            result = caller.call("GET", "/v2/clusters/c1")
            assert result["clusterId"] == "c1"


class TestAPICallerErrors:
    def test_api_error_nonzero_code(self):
        resp = _mock_response(200, {"code": 80001, "message": "Invalid API key"})
        with patch.object(httpx.Client, "request", return_value=resp):
            caller = APICaller(api_key="bad-key", base_url="https://api.example.com")
            with pytest.raises(APIError) as exc_info:
                caller.call("GET", "/v2/clusters")
            assert exc_info.value.code == 80001
            assert "Invalid API key" in exc_info.value.message

    def test_http_401_error(self):
        resp = _mock_response(401, {"code": 80001, "message": "Unauthorized"})
        with patch.object(httpx.Client, "request", return_value=resp):
            caller = APICaller(api_key="bad-key", base_url="https://api.example.com")
            with pytest.raises(APIError) as exc_info:
                caller.call("GET", "/v2/clusters")
            assert "API" in str(exc_info.value)

    def test_http_500_error(self):
        resp = _mock_response(500, {"code": 50000, "message": "Internal error"})
        with patch.object(httpx.Client, "request", return_value=resp):
            caller = APICaller(api_key="key", base_url="https://api.example.com")
            with pytest.raises(APIError):
                caller.call("GET", "/v2/clusters")

    def test_network_error(self):
        with patch.object(httpx.Client, "request", side_effect=httpx.ConnectError("Connection refused")):
            caller = APICaller(api_key="key", base_url="https://api.example.com")
            with pytest.raises(APIError, match="connect"):
                caller.call("GET", "/v2/clusters")


class TestAPICallerRetry:
    def test_retry_on_network_error(self):
        """Should retry on ConnectError with exponential backoff and eventually succeed."""
        success_resp = _mock_response(200, {"code": 0, "data": {"ok": True}})
        side_effects = [httpx.ConnectError("fail"), httpx.ConnectError("fail"), success_resp]
        with patch.object(httpx.Client, "request", side_effect=side_effects) as mock_req:
            with patch("zilliz_cli.core.api_caller.time.sleep") as mock_sleep:
                caller = APICaller(api_key="key", base_url="https://api.example.com")
                result = caller.call("GET", "/v2/clusters")
                assert result == {"ok": True}
                assert mock_req.call_count == 3
                assert mock_sleep.call_count == 2

    def test_retry_on_server_error(self):
        """Should retry on 500/502/503 responses."""
        error_resp = _mock_response(502, {"code": 50000, "message": "Bad Gateway"})
        success_resp = _mock_response(200, {"code": 0, "data": {"ok": True}})
        with patch.object(httpx.Client, "request", side_effect=[error_resp, success_resp]) as mock_req:
            with patch("zilliz_cli.core.api_caller.time.sleep"):
                caller = APICaller(api_key="key", base_url="https://api.example.com")
                result = caller.call("GET", "/v2/clusters")
                assert result == {"ok": True}
                assert mock_req.call_count == 2

    def test_no_retry_on_client_error(self):
        """Should NOT retry on 400/401/404 errors."""
        error_resp = _mock_response(401, {"code": 80001, "message": "Unauthorized"})
        with patch.object(httpx.Client, "request", return_value=error_resp) as mock_req:
            caller = APICaller(api_key="key", base_url="https://api.example.com")
            with pytest.raises(APIError):
                caller.call("GET", "/v2/clusters")
            assert mock_req.call_count == 1

    def test_max_retries_exhausted(self):
        """Should raise after max retries are exhausted."""
        with patch.object(httpx.Client, "request", side_effect=httpx.ConnectError("fail")):
            with patch("zilliz_cli.core.api_caller.time.sleep"):
                caller = APICaller(api_key="key", base_url="https://api.example.com")
                with pytest.raises(APIError, match="connect"):
                    caller.call("GET", "/v2/clusters")

    def test_retry_on_timeout(self):
        """Should retry on TimeoutException."""
        success_resp = _mock_response(200, {"code": 0, "data": {"ok": True}})
        side_effects = [httpx.TimeoutException("timeout"), success_resp]
        with patch.object(httpx.Client, "request", side_effect=side_effects):
            with patch("zilliz_cli.core.api_caller.time.sleep"):
                caller = APICaller(api_key="key", base_url="https://api.example.com")
                result = caller.call("GET", "/v2/clusters")
                assert result == {"ok": True}
