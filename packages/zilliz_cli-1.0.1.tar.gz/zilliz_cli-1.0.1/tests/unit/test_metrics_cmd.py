# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import json
from unittest.mock import patch

import click
import pytest
from click.testing import CliRunner

from zilliz_cli.cli import main
from zilliz_cli.commands.metrics import _METRIC_MAP, _default_granularity, _human_to_iso_duration


class TestClusterMetrics:
    def setup_method(self):
        self.runner = CliRunner()

    def _invoke(self, args, config_dir):
        return self.runner.invoke(
            main,
            ["--api-key", "test-key", "cluster", "metrics", *args],
            obj={"config_dir": config_dir},
        )

    def test_metrics_single_metric_json(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "results": [
                    {
                        "name": "REQ_SEARCH_COUNT",
                        "unit": "qps",
                        "values": [
                            {"timestamp": "2026-03-15T10:00:00Z", "value": "42.5"},
                            {"timestamp": "2026-03-15T10:05:00Z", "value": "45.0"},
                        ],
                    }
                ]
            }

            result = self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "SEARCH_QPS", "-o", "json"],
                config_dir,
            )

            assert result.exit_code == 0
            data = json.loads(result.output)
            assert len(data["results"]) == 1
            assert data["results"][0]["name"] == "REQ_SEARCH_COUNT"

    def test_metrics_name_mapping(self, config_dir):
        """CLI names are mapped to backend metric names in API body."""
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "STORAGE", "--metric", "CU_COMPUTATION", "-o", "json"],
                config_dir,
            )

            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["metricQueries"][0] == {"name": "STORAGE_USE"}
            assert body["metricQueries"][1] == {"name": "CU_COMPUTATION"}

    def test_metrics_multiple_metrics(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "SEARCH_QPS", "--metric", "STORAGE", "-o", "json"],
                config_dir,
            )

            assert result.exit_code == 0
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert len(body["metricQueries"]) == 2

    def test_metrics_default_period(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "SEARCH_QPS", "-o", "json"],
                config_dir,
            )

            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["period"] == "PT1H"

    def test_metrics_default_granularity_sent(self, config_dir):
        """granularity is always sent (backend requires it)."""
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "SEARCH_QPS", "-o", "json"],
                config_dir,
            )

            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert "granularity" in body
            assert body["granularity"] == "PT1M"  # default for 1h period

    def test_metrics_with_period(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "SEARCH_QPS", "--period", "24h", "-o", "json"],
                config_dir,
            )

            assert result.exit_code == 0
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["period"] == "PT24H"
            assert body["granularity"] == "PT15M"  # auto for 24h

    def test_metrics_with_start_end(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self._invoke(
                [
                    "--cluster-id",
                    "in01-abc",
                    "--metric",
                    "CU_COMPUTATION",
                    "--start",
                    "2026-03-01",
                    "--end",
                    "2026-03-15",
                    "-o",
                    "json",
                ],
                config_dir,
            )

            assert result.exit_code == 0
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["start"] == "2026-03-01T00:00:00Z"
            assert body["end"] == "2026-03-15T00:00:00Z"
            assert "period" not in body
            assert body["granularity"] == "PT6H"  # auto for 14-day range

    def test_metrics_period_and_start_end_conflict(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller"):
            result = self._invoke(
                [
                    "--cluster-id",
                    "in01-abc",
                    "--metric",
                    "SEARCH_QPS",
                    "--period",
                    "1h",
                    "--start",
                    "2026-03-01",
                    "--end",
                    "2026-03-15",
                ],
                config_dir,
            )

            assert result.exit_code != 0

    def test_metrics_start_without_end(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller"):
            result = self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "SEARCH_QPS", "--start", "2026-03-01"],
                config_dir,
            )

            assert result.exit_code != 0

    def test_metrics_with_granularity(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "SEARCH_QPS", "--granularity", "5m", "-o", "json"],
                config_dir,
            )

            assert result.exit_code == 0
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["granularity"] == "PT5M"

    def test_metrics_table_output(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "results": [
                    {
                        "name": "REQ_SEARCH_COUNT",
                        "unit": "qps",
                        "values": [
                            {"timestamp": "2026-03-15T10:00:00Z", "value": "42"},
                        ],
                    }
                ]
            }

            result = self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "SEARCH_QPS"],
                config_dir,
            )

            assert result.exit_code == 0
            assert "REQ_SEARCH_COUNT" in result.output
            assert "42" in result.output

    def test_metrics_empty_results(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "SEARCH_QPS"],
                config_dir,
            )

            assert result.exit_code == 0
            assert "No metrics" in result.output

    def test_metrics_missing_cluster_id_non_interactive(self, config_dir):
        """Without cluster-id and no context, non-interactive mode should fail."""
        result = self._invoke(["--metric", "SEARCH_QPS", "-o", "json"], config_dir)
        assert result.exit_code != 0

    def test_metrics_uses_context_cluster(self, config_dir):
        """When no --cluster-id, should use context cluster_id."""
        config_path = config_dir / "config"
        config_path.write_text("[context]\ncluster_id = in01-from-context\nendpoint = https://example.com\n")

        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self._invoke(
                ["--metric", "SEARCH_QPS", "-o", "json"],
                config_dir,
            )

            assert result.exit_code == 0
            call_args = mock_instance.call.call_args
            path_params = call_args[1].get("path_params") or call_args[0][3]
            assert path_params["clusterId"] == "in01-from-context"

    def test_metrics_api_error(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            from zilliz_cli.core.exceptions import APIError

            mock_instance = MockCaller.return_value
            mock_instance.call.side_effect = APIError(400, "Invalid metric name")

            result = self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "SEARCH_QPS", "-o", "json"],
                config_dir,
            )

            assert result.exit_code != 0

    def test_metrics_path_params(self, config_dir):
        """Verify clusterId is passed as path parameter."""
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            self._invoke(
                ["--cluster-id", "in01-test123", "--metric", "SEARCH_QPS", "-o", "json"],
                config_dir,
            )

            call_args = mock_instance.call.call_args
            path_params = call_args[1].get("path_params") or call_args[0][3]
            assert path_params["clusterId"] == "in01-test123"

    def test_metrics_case_insensitive(self, config_dir):
        """Metric names should be case-insensitive."""
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self._invoke(
                ["--cluster-id", "in01-abc", "--metric", "search_qps", "-o", "json"],
                config_dir,
            )

            assert result.exit_code == 0
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["metricQueries"][0] == {"name": "REQ_SEARCH_COUNT"}


class TestDurationParsing:
    def test_seconds(self):
        assert _human_to_iso_duration("30s") == "PT30S"

    def test_minutes(self):
        assert _human_to_iso_duration("5m") == "PT5M"

    def test_hours(self):
        assert _human_to_iso_duration("24h") == "PT24H"

    def test_days(self):
        assert _human_to_iso_duration("7d") == "PT168H"

    def test_case_insensitive(self):
        assert _human_to_iso_duration("5M") == "PT5M"
        assert _human_to_iso_duration("1H") == "PT1H"
        assert _human_to_iso_duration("30S") == "PT30S"

    def test_invalid_format(self):
        with pytest.raises(click.BadParameter):
            _human_to_iso_duration("invalid")

    def test_no_unit(self):
        with pytest.raises(click.BadParameter):
            _human_to_iso_duration("100")

    def test_large_values(self):
        assert _human_to_iso_duration("365d") == "PT8760H"
        assert _human_to_iso_duration("3600s") == "PT3600S"


class TestDefaultGranularity:
    def test_1h_period(self):
        assert _default_granularity("PT1H", None, None) == "PT1M"

    def test_6h_period(self):
        assert _default_granularity("PT6H", None, None) == "PT5M"

    def test_24h_period(self):
        assert _default_granularity("PT24H", None, None) == "PT15M"

    def test_7d_period(self):
        assert _default_granularity("PT168H", None, None) == "PT1H"

    def test_30d_period(self):
        assert _default_granularity("PT720H", None, None) == "PT6H"

    def test_start_end_range(self):
        assert _default_granularity(None, "2026-03-01T00:00:00Z", "2026-03-15T00:00:00Z") == "PT6H"

    def test_short_start_end_range(self):
        assert _default_granularity(None, "2026-03-15T10:00:00Z", "2026-03-15T11:00:00Z") == "PT1M"


class TestMetricMap:
    def test_all_cli_names_have_backend_mapping(self):
        """Every CLI metric name must map to a backend name."""
        for cli_name, backend_name in _METRIC_MAP.items():
            assert backend_name, f"{cli_name} has empty backend mapping"
            assert isinstance(backend_name, str)

    def test_metric_count(self):
        """Ensure all 39 metrics are present."""
        assert len(_METRIC_MAP) == 39

    def test_new_resource_metrics(self):
        assert _METRIC_MAP["CU_SIZE"] == "CU_SIZE"
        assert _METRIC_MAP["REPLICA_COUNT"] == "REPLICA_COUNT"

    def test_new_qps_metrics(self):
        assert _METRIC_MAP["BULK_INSERT_QPS"] == "REQ_BULK_INSERT_COUNT"

    def test_new_latency_metrics(self):
        assert _METRIC_MAP["UPSERT_LATENCY_AVG"] == "REQ_UPSERT_LATENCY_AVG"
        assert _METRIC_MAP["UPSERT_LATENCY_P99"] == "REQ_UPSERT_LATENCY_P99"
        assert _METRIC_MAP["DELETE_LATENCY_AVG"] == "REQ_DELETE_LATENCY_AVG"
        assert _METRIC_MAP["DELETE_LATENCY_P99"] == "REQ_DELETE_LATENCY_P99"

    def test_new_vps_metrics(self):
        assert _METRIC_MAP["UPSERT_VPS"] == "VECTOR_REQ_UPSERT_COUNT"
        assert _METRIC_MAP["DELETE_VPS"] == "VECTOR_REQ_DELETE_COUNT"
        assert _METRIC_MAP["BULK_INSERT_VPS"] == "VECTOR_REQ_BULK_INSERT_COUNT"

    def test_new_fail_rate_metrics(self):
        assert _METRIC_MAP["SEARCH_FAIL_RATE"] == "REQ_FAIL_RATE_SEARCH"
        assert _METRIC_MAP["QUERY_FAIL_RATE"] == "REQ_FAIL_RATE_QUERY"
        assert _METRIC_MAP["INSERT_FAIL_RATE"] == "REQ_FAIL_RATE_INSERT"
        assert _METRIC_MAP["UPSERT_FAIL_RATE"] == "REQ_FAIL_RATE_UPSERT"
        assert _METRIC_MAP["DELETE_FAIL_RATE"] == "REQ_FAIL_RATE_DELETE"
        assert _METRIC_MAP["BULK_INSERT_FAIL_RATE"] == "REQ_FAIL_RATE_BULK_INSERT"

    def test_new_data_metrics(self):
        assert _METRIC_MAP["ENTITIES_LOADED"] == "ENTITIES_LOADED"
        assert _METRIC_MAP["ENTITIES_INDEXED"] == "ENTITIES_INDEXED"

    def test_new_serverless_metrics(self):
        assert _METRIC_MAP["READ_VCU"] == "READ_VCU"
        assert _METRIC_MAP["WRITE_VCU"] == "WRITE_VCU"
