import json
from unittest.mock import patch

from click.testing import CliRunner

from zilliz_cli.cli import main


class TestJobDescribe:
    def setup_method(self):
        self.runner = CliRunner()

    def _invoke(self, args, config_dir):
        return self.runner.invoke(
            main,
            ["--api-key", "test-key", "job", "describe", *args],
            obj={"config_dir": config_dir},
        )

    def test_describe_json(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "jobId": "job-abc123",
                "type": "BACKUP",
                "status": "SUCCESSFUL",
                "progress": "100",
                "startTime": "2025-01-01T00:00:00Z",
                "endTime": "2025-01-01T00:10:00Z",
                "reason": "",
            }

            result = self._invoke(["--job-id", "job-abc123", "-o", "json"], config_dir)

            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["jobId"] == "job-abc123"
            assert data["status"] == "SUCCESSFUL"
            mock_instance.call.assert_called_once_with("GET", "/v2/jobs/{jobId}", path_params={"jobId": "job-abc123"})

    def test_describe_table(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "jobId": "job-abc123",
                "type": "MIGRATION",
                "status": "IN_PROGRESS",
                "progress": "50",
                "startTime": "2025-01-01T00:00:00Z",
                "endTime": "",
                "reason": "",
            }

            result = self._invoke(["--job-id", "job-abc123"], config_dir)

            assert result.exit_code == 0
            assert "job-abc123" in result.output

    def test_describe_failed_job_exits_nonzero(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "jobId": "job-fail",
                "type": "IMPORT",
                "status": "FAILED",
                "progress": "30",
                "startTime": "2025-01-01T00:00:00Z",
                "endTime": "2025-01-01T00:05:00Z",
                "reason": "collection not found",
            }

            result = self._invoke(["--job-id", "job-fail", "-o", "json"], config_dir)

            assert result.exit_code == 1

    def test_describe_api_error(self, config_dir):
        from zilliz_cli.core.exceptions import APIError

        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.side_effect = APIError(80001, "Invalid API key")

            result = self._invoke(["--job-id", "job-xxx"], config_dir)

            assert result.exit_code == 1
            assert "Invalid API key" in result.output

    def test_describe_missing_job_id(self, config_dir):
        result = self.runner.invoke(
            main,
            ["--api-key", "test-key", "job", "describe"],
            obj={"config_dir": config_dir},
        )

        assert result.exit_code != 0
        assert "job-id" in result.output.lower() or "required" in result.output.lower()
