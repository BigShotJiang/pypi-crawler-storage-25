# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import pytest

from zilliz_cli.core.model import CliModel
from zilliz_cli.core.model_loader import ModelLoader


class TestModelLoaderBuiltin:
    def test_load_control_plane(self):
        loader = ModelLoader()
        model = loader.load("control-plane")
        assert isinstance(model, CliModel)
        assert "cluster" in model.resources
        assert "project" in model.resources
        assert model.endpoint == "https://api.cloud.zilliz.com"

    def test_load_nonexistent_raises(self):
        loader = ModelLoader()
        with pytest.raises(FileNotFoundError):
            loader.load("nonexistent-plane")

    def test_builtin_cluster_operations(self):
        loader = ModelLoader()
        model = loader.load("control-plane")
        cluster = model.resources["cluster"]
        assert "list" in cluster.operations
        assert "describe" in cluster.operations
        assert "delete" in cluster.operations
        assert "suspend" in cluster.operations
        assert "resume" in cluster.operations
        assert "modify" in cluster.operations
        assert "providers" in cluster.operations
        assert "regions" in cluster.operations

    def test_builtin_project_operations(self):
        loader = ModelLoader()
        model = loader.load("control-plane")
        project = model.resources["project"]
        assert "list" in project.operations
        assert "describe" in project.operations
        assert "create" in project.operations
        assert "upgrade" in project.operations

    def test_builtin_backup_operations(self):
        loader = ModelLoader()
        model = loader.load("control-plane")
        assert "backup" in model.resources
        backup = model.resources["backup"]
        assert "create" in backup.operations
        assert "list" in backup.operations
        assert "describe" in backup.operations
        assert "delete" in backup.operations
        assert "export" in backup.operations
        assert "restore-cluster" in backup.operations
        assert "restore-collection" in backup.operations
        assert "describe-policy" in backup.operations
        assert "update-policy" in backup.operations

    def test_builtin_import_operations(self):
        loader = ModelLoader()
        model = loader.load("control-plane")
        assert "import" in model.resources
        import_res = model.resources["import"]
        assert "start" in import_res.operations
        assert "list" in import_res.operations
        assert "status" in import_res.operations

    def test_builtin_billing_operations(self):
        loader = ModelLoader()
        model = loader.load("control-plane")
        assert "billing" in model.resources
        billing = model.resources["billing"]
        assert "bind-card" in billing.operations

    def test_backup_describe_has_two_path_params(self):
        loader = ModelLoader()
        model = loader.load("control-plane")
        describe = model.resources["backup"].operations["describe"]
        path_params = [p for p in describe.params if p.position == "path"]
        assert len(path_params) == 2
        names = {p.name for p in path_params}
        assert names == {"clusterId", "backupId"}

    def test_project_upgrade_uses_patch(self):
        loader = ModelLoader()
        model = loader.load("control-plane")
        upgrade = model.resources["project"].operations["upgrade"]
        assert upgrade.method == "PATCH"

    def test_load_with_cache_dir(self, config_dir):
        loader = ModelLoader(cache_dir=config_dir / "models")
        model = loader.load("control-plane")
        assert isinstance(model, CliModel)


class TestModelLoaderDataPlane:
    def test_load_data_plane(self):
        loader = ModelLoader()
        model = loader.load("data-plane")

        assert isinstance(model, CliModel)
        assert "collection" in model.resources
        assert "vector" in model.resources
        assert model.endpoint is None

    def test_data_plane_collection_operations(self):
        loader = ModelLoader()
        model = loader.load("data-plane")
        collection = model.resources["collection"]

        assert "list" in collection.operations
        assert "describe" in collection.operations
        assert "create" in collection.operations
        assert "drop" in collection.operations
        assert "has" in collection.operations
        assert "rename" in collection.operations
        assert "load" in collection.operations
        assert "release" in collection.operations
        assert "get-stats" in collection.operations
        assert "get-load-state" in collection.operations
        assert "flush" in collection.operations
        assert "compact" in collection.operations

    def test_data_plane_vector_operations(self):
        loader = ModelLoader()
        model = loader.load("data-plane")
        vector = model.resources["vector"]

        assert "search" in vector.operations
        assert "hybrid-search" in vector.operations
        assert "query" in vector.operations
        assert "insert" in vector.operations
        assert "upsert" in vector.operations
        assert "get" in vector.operations
        assert "delete" in vector.operations

    def test_collection_create_has_body_param(self):
        loader = ModelLoader()
        model = loader.load("data-plane")
        create_op = model.resources["collection"].operations["create"]

        assert create_op.body_param == "--body"

    def test_collection_create_required_params(self):
        """Verify collection create has correct required parameters."""
        loader = ModelLoader()
        model = loader.load("data-plane")
        create_op = model.resources["collection"].operations["create"]

        required_params = {p.name for p in create_op.params if p.required}
        assert "collectionName" in required_params

        # dimension is conditionally required (required unless --body is provided)
        dimension_param = next(p for p in create_op.params if p.name == "dimension")
        assert dimension_param.required_unless == "body"

    def test_data_plane_database_operations(self):
        loader = ModelLoader()
        model = loader.load("data-plane")
        assert "database" in model.resources
        db = model.resources["database"]
        assert "create" in db.operations
        assert "list" in db.operations
        assert "describe" in db.operations
        assert "drop" in db.operations

    def test_data_plane_index_operations(self):
        loader = ModelLoader()
        model = loader.load("data-plane")
        assert "index" in model.resources
        index = model.resources["index"]
        assert "create" in index.operations
        assert "list" in index.operations
        assert "describe" in index.operations
        assert "drop" in index.operations

    def test_data_plane_partition_operations(self):
        loader = ModelLoader()
        model = loader.load("data-plane")
        assert "partition" in model.resources
        partition = model.resources["partition"]
        assert "create" in partition.operations
        assert "list" in partition.operations
        assert "has" in partition.operations
        assert "get-stats" in partition.operations
        assert "load" in partition.operations
        assert "release" in partition.operations
        assert "drop" in partition.operations

    def test_data_plane_user_operations(self):
        loader = ModelLoader()
        model = loader.load("data-plane")
        assert "user" in model.resources
        user = model.resources["user"]
        assert "create" in user.operations
        assert "list" in user.operations
        assert "describe" in user.operations
        assert "drop" in user.operations
        assert "update-password" in user.operations
        assert "grant-role" in user.operations
        assert "revoke-role" in user.operations

    def test_data_plane_role_operations(self):
        loader = ModelLoader()
        model = loader.load("data-plane")
        assert "role" in model.resources
        role = model.resources["role"]
        assert "create" in role.operations
        assert "list" in role.operations
        assert "describe" in role.operations
        assert "drop" in role.operations
        assert "grant-privilege" in role.operations
        assert "revoke-privilege" in role.operations

    def test_data_plane_alias_operations(self):
        loader = ModelLoader()
        model = loader.load("data-plane")
        assert "alias" in model.resources
        alias = model.resources["alias"]
        assert "create" in alias.operations
        assert "list" in alias.operations
        assert "describe" in alias.operations
        assert "alter" in alias.operations
        assert "drop" in alias.operations

    def test_hybrid_search_has_body_param(self):
        loader = ModelLoader()
        model = loader.load("data-plane")
        hs = model.resources["vector"].operations["hybrid-search"]
        assert hs.body_param == "--body"

    def test_hybrid_search_has_array_and_object_params(self):
        loader = ModelLoader()
        model = loader.load("data-plane")
        hs = model.resources["vector"].operations["hybrid-search"]
        search_param = next(p for p in hs.params if p.name == "search")
        rerank_param = next(p for p in hs.params if p.name == "rerank")
        assert search_param.type == "array"
        assert rerank_param.type == "object"
