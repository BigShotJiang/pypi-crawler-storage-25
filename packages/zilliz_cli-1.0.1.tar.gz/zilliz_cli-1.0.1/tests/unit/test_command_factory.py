# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

from unittest.mock import MagicMock, patch

import click
from click.testing import CliRunner

from zilliz_cli.core.command_factory import (
    _SMART_PARAM_FETCHERS,
    CommandFactory,
    _apply_param_transform,
    _normalize_array_fields,
    _normalize_schema_params,
    _parse_json_value,
    _prompt_for_missing_params,
    _smart_prompt_param,
    _transform_day_of_week,
    _transform_time_window,
)
from zilliz_cli.core.model import CliModel, Param

SAMPLE_MODEL_DICT = {
    "version": "2026-01-27",
    "endpoint": "https://api.example.com",
    "resources": {
        "cluster": {
            "operations": {
                "list": {"http": {"method": "GET", "path": "/v2/clusters"}, "params": []},
                "describe": {
                    "http": {"method": "GET", "path": "/v2/clusters/{clusterId}"},
                    "params": [
                        {
                            "name": "clusterId",
                            "type": "string",
                            "required": True,
                            "cli": "--cluster-id",
                            "position": "path",
                        }
                    ],
                },
                "create": {
                    "http": {"method": "POST", "path": "/v2/clusters/createServerless"},
                    "params": [
                        {"name": "clusterName", "type": "string", "required": True, "cli": "--name"},
                        {"name": "projectId", "type": "string", "required": True, "cli": "--project-id"},
                        {"name": "regionId", "type": "string", "required": True, "cli": "--region"},
                    ],
                },
            }
        }
    },
}


class TestCommandFactoryStructure:
    def test_creates_group(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        assert "cluster" in groups
        assert isinstance(groups["cluster"], click.MultiCommand)

    def test_group_has_commands(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        result = runner.invoke(cluster_group, ["--help"])
        assert "list" in result.output
        assert "describe" in result.output
        assert "create" in result.output

    def test_command_has_options(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        result = runner.invoke(cluster_group, ["describe", "--help"])
        assert "--cluster-id" in result.output

    def test_required_option_enforced(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        result = runner.invoke(
            cluster_group, ["describe"], obj={"api_key": "test", "output_format": "json", "config_dir": None}
        )
        assert result.exit_code != 0


class TestCommandFactoryExecution:
    def test_list_calls_api(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [{"clusterId": "c1", "clusterName": "test"}]
            result = runner.invoke(
                cluster_group, ["list"], obj={"api_key": "test-key", "output_format": "json", "config_dir": None}
            )
            assert result.exit_code == 0
            assert "c1" in result.output
            mock_instance.call.assert_called_once_with("GET", "/v2/clusters", body={}, path_params={})

    def test_describe_with_path_param(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"clusterId": "c1", "status": "RUNNING"}
            result = runner.invoke(
                cluster_group,
                ["describe", "--cluster-id", "c1"],
                obj={"api_key": "test-key", "output_format": "json", "config_dir": None},
            )
            assert result.exit_code == 0
            assert "RUNNING" in result.output
            mock_instance.call.assert_called_once_with(
                "GET", "/v2/clusters/{clusterId}", body={}, path_params={"clusterId": "c1"}
            )

    def test_create_with_body_params(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"clusterId": "new-1"}
            result = runner.invoke(
                cluster_group,
                ["create", "--name", "my-cluster", "--project-id", "p1", "--region", "aws-us-east-1"],
                obj={"api_key": "test-key", "output_format": "json", "config_dir": None},
            )
            assert result.exit_code == 0
            mock_instance.call.assert_called_once_with(
                "POST",
                "/v2/clusters/createServerless",
                body={"clusterName": "my-cluster", "projectId": "p1", "regionId": "aws-us-east-1"},
                path_params={},
            )

    def test_api_error_displayed(self):
        from zilliz_cli.core.exceptions import APIError

        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.side_effect = APIError(80001, "Invalid API key")
            result = runner.invoke(
                cluster_group, ["list"], obj={"api_key": "bad-key", "output_format": "json", "config_dir": None}
            )
            assert result.exit_code == 1
            assert "80001" in result.output


class TestCommandFactoryEndpointResolver:
    def test_custom_endpoint_resolver(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)

        def resolver(ctx_obj):
            return "https://custom-endpoint.example.com"

        factory = CommandFactory(model, endpoint_resolver=resolver)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]

        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [{"clusterId": "c1"}]

            result = runner.invoke(
                cluster_group, ["list"], obj={"api_key": "test-key", "output_format": "json", "config_dir": None}
            )

            assert result.exit_code == 0
            MockCaller.assert_called_once_with(api_key="test-key", base_url="https://custom-endpoint.example.com")

    def test_resolver_returns_none_falls_back_to_model_endpoint(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)

        def resolver(ctx_obj):
            return None  # no user override

        factory = CommandFactory(model, endpoint_resolver=resolver)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]

        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [{"clusterId": "c1"}]

            result = runner.invoke(
                cluster_group, ["list"], obj={"api_key": "test-key", "output_format": "json", "config_dir": None}
            )

            assert result.exit_code == 0
            MockCaller.assert_called_once_with(api_key="test-key", base_url="https://api.example.com")

    def test_resolver_overrides_model_endpoint(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)

        def resolver(ctx_obj):
            return "https://api.cloud-uat3.zilliz.com"

        factory = CommandFactory(model, endpoint_resolver=resolver)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]

        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [{"clusterId": "c1"}]

            result = runner.invoke(
                cluster_group, ["list"], obj={"api_key": "test-key", "output_format": "json", "config_dir": None}
            )

            assert result.exit_code == 0
            MockCaller.assert_called_once_with(api_key="test-key", base_url="https://api.cloud-uat3.zilliz.com")

    def test_resolver_error_displayed(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)

        def resolver(ctx_obj):
            raise click.ClickException('No context set. Run "zilliz context set --cluster-id <id>" first.')

        factory = CommandFactory(model, endpoint_resolver=resolver)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]

        runner = CliRunner()
        result = runner.invoke(
            cluster_group, ["list"], obj={"api_key": "test-key", "output_format": "json", "config_dir": None}
        )

        assert result.exit_code != 0
        assert "context" in result.output.lower()


VECTOR_MODEL_DICT = {
    "version": "1",
    "resources": {
        "vector": {
            "operations": {
                "search": {
                    "http": {"method": "POST", "path": "/v2/vectordb/entities/search"},
                    "params": [
                        {"name": "collectionName", "type": "string", "required": True, "cli": "--collection"},
                        {"name": "data", "type": "array", "required": True, "cli": "--data"},
                        {"name": "limit", "type": "integer", "default": 10, "cli": "--limit"},
                        {"name": "outputFields", "type": "array", "cli": "--output-fields"},
                    ],
                }
            }
        }
    },
}


def _mock_endpoint_resolver(ctx_obj):
    return "https://test-endpoint.example.com"


class TestCommandFactoryArrayParams:
    def test_array_param_parsed_as_json(self):
        model = CliModel.from_dict(VECTOR_MODEL_DICT)
        factory = CommandFactory(model, endpoint_resolver=_mock_endpoint_resolver)
        groups = factory.create_groups()
        vector_group = groups["vector"]

        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [{"id": 1, "distance": 0.9}]

            result = runner.invoke(
                vector_group,
                [
                    "search",
                    "--collection",
                    "my_col",
                    "--data",
                    "[[0.1, 0.2, 0.3]]",
                    "--output-fields",
                    '["id", "score"]',
                ],
                obj={"api_key": "test-key", "output_format": "json", "config_dir": None},
            )

            assert result.exit_code == 0
            call_args = mock_instance.call.call_args
            body = call_args.kwargs.get("body") or call_args[1].get("body")
            assert body["data"] == [[0.1, 0.2, 0.3]]
            assert body["outputFields"] == ["id", "score"]

    def test_array_param_invalid_json_error(self):
        model = CliModel.from_dict(VECTOR_MODEL_DICT)
        factory = CommandFactory(model, endpoint_resolver=_mock_endpoint_resolver)
        groups = factory.create_groups()
        vector_group = groups["vector"]

        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller"):
            result = runner.invoke(
                vector_group,
                [
                    "search",
                    "--collection",
                    "my_col",
                    "--data",
                    "not-json",
                ],
                obj={"api_key": "test-key", "output_format": "json", "config_dir": None},
            )

            assert result.exit_code != 0
            assert "json" in result.output.lower() or "JSON" in result.output


class TestSmartParamFetchersConfig:
    """Tests for smart parameter fetchers configuration."""

    def test_project_id_config_exists(self):
        """projectId should have smart prompt config."""
        assert "projectId" in _SMART_PARAM_FETCHERS
        config = _SMART_PARAM_FETCHERS["projectId"]
        assert config["api"] == "GET /v2/projects"
        assert config["id_field"] == "projectId"
        assert config["name_field"] == "projectName"
        assert "plan" in config.get("extra_fields", [])

    def test_region_id_config_exists(self):
        """regionId should have smart prompt config."""
        assert "regionId" in _SMART_PARAM_FETCHERS
        config = _SMART_PARAM_FETCHERS["regionId"]
        assert config["api"] == "GET /v2/regions"

    def test_cluster_id_config_exists(self):
        """clusterId should have smart prompt config."""
        assert "clusterId" in _SMART_PARAM_FETCHERS
        config = _SMART_PARAM_FETCHERS["clusterId"]
        assert config["api"] == "GET /v2/clusters"

    def test_cu_type_static_choices(self):
        """cuType should have static choices (no API)."""
        assert "cuType" in _SMART_PARAM_FETCHERS
        config = _SMART_PARAM_FETCHERS["cuType"]
        assert "choices" in config
        choices = config["choices"]
        assert len(choices) == 2
        # Check both options exist
        values = [c[1] for c in choices]
        assert "Performance-optimized" in values
        assert "Capacity-optimized" in values


class TestSmartPromptParam:
    """Tests for _smart_prompt_param function."""

    def test_returns_none_for_unknown_param(self):
        """Unknown parameters should return None."""
        param = Param(name="unknownParam", type="string", required=True, cli_name="--unknown")
        result = _smart_prompt_param(param, caller=None)
        assert result is None

    def test_returns_none_when_caller_is_none_for_api_param(self):
        """API-based params should return None when caller is None."""
        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        result = _smart_prompt_param(param, caller=None)
        assert result is None

    def test_static_choices_work_without_caller(self):
        """Static choice params (cuType) should work without API caller."""
        param = Param(name="cuType", type="string", required=True, cli_name="--cu-type")
        with patch("zilliz_cli.core.command_factory.questionary") as mock_q:
            mock_q.select.return_value.ask.return_value = "Performance-optimized"
            mock_q.Choice = MagicMock(side_effect=lambda title, value: {"title": title, "value": value})
            result = _smart_prompt_param(param, caller=None)
            assert result == "Performance-optimized"
            mock_q.select.assert_called_once()

    def test_api_param_fetches_and_presents_choices(self):
        """API-based params should fetch options and present selection."""
        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        mock_caller = MagicMock()
        mock_caller.call.return_value = {
            "code": 0,
            "data": [
                {"projectId": "proj-1", "projectName": "Project One", "plan": "Enterprise"},
                {"projectId": "proj-2", "projectName": "Project Two", "plan": "Standard"},
            ],
        }
        with patch("zilliz_cli.core.command_factory.questionary") as mock_q:
            mock_q.select.return_value.ask.return_value = "proj-1"
            mock_q.Choice = MagicMock(side_effect=lambda title, value: {"title": title, "value": value})
            result = _smart_prompt_param(param, caller=mock_caller)
            assert result == "proj-1"
            mock_caller.call.assert_called_once_with("GET", "/v2/projects", body=None, return_raw=True)

    def test_auto_select_when_single_option(self):
        """When only one option exists, it should be auto-selected."""
        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        mock_caller = MagicMock()
        mock_caller.call.return_value = {
            "code": 0,
            "data": [
                {"projectId": "proj-only", "projectName": "Only Project", "plan": "Free"},
            ],
        }
        with patch("zilliz_cli.core.command_factory.questionary") as mock_q:
            mock_q.Choice = MagicMock(side_effect=lambda title, value: MagicMock(title=title, value=value))
            result = _smart_prompt_param(param, caller=mock_caller)
            assert result == "proj-only"
            # questionary.select should NOT be called for single option
            mock_q.select.assert_not_called()

    def test_returns_none_on_api_error(self):
        """API errors should return None (fallback to manual input)."""
        from zilliz_cli.core.exceptions import APIError

        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        mock_caller = MagicMock()
        mock_caller.call.side_effect = APIError(401, "Unauthorized")
        result = _smart_prompt_param(param, caller=mock_caller)
        assert result is None

    def test_returns_none_when_no_items(self):
        """Empty list should return None."""
        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        mock_caller = MagicMock()
        mock_caller.call.return_value = {"code": 0, "data": []}
        result = _smart_prompt_param(param, caller=mock_caller)
        assert result is None

    def test_extra_fields_displayed(self):
        """Extra fields (like plan) should be included in display."""
        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        mock_caller = MagicMock()
        mock_caller.call.return_value = {
            "code": 0,
            "data": [
                {"projectId": "proj-1", "projectName": "My Project", "plan": "Enterprise"},
                {"projectId": "proj-2", "projectName": "Other", "plan": "Standard"},
            ],
        }
        captured_choices = []
        with patch("zilliz_cli.core.command_factory.questionary") as mock_q:

            def capture_choice(title, value):
                captured_choices.append(title)
                return MagicMock(title=title, value=value)

            mock_q.Choice = capture_choice
            mock_q.select.return_value.ask.return_value = "proj-1"
            _smart_prompt_param(param, caller=mock_caller)
            # Check that plan is included in the display
            assert any("Enterprise" in c for c in captured_choices)
            assert any("Standard" in c for c in captured_choices)


class TestRequiredWhen:
    """Tests for requiredWhen conditional parameter prompting."""

    def test_param_from_dict_parses_required_when(self):
        p = Param.from_dict(
            {
                "name": "frequency",
                "type": "string",
                "cli": "--frequency",
                "requiredWhen": {"enabled": True},
            }
        )
        assert p.required_when == {"enabled": True}

    def test_param_from_dict_no_required_when(self):
        p = Param.from_dict({"name": "foo", "type": "string", "cli": "--foo"})
        assert p.required_when is None

    def test_non_interactive_errors_when_condition_met(self):
        """Non-interactive mode should error when requiredWhen condition is met."""
        params = [
            Param(name="enabled", type="boolean", cli_name="--enabled", required=True),
            Param(name="frequency", type="string", cli_name="--frequency", required_when={"enabled": True}),
        ]
        kwargs = {"enabled": True}  # enabled=True but no frequency
        with patch("zilliz_cli.core.command_factory.sys") as mock_sys:
            mock_sys.stdin.isatty.return_value = False
            import pytest

            with pytest.raises(click.ClickException, match="--frequency"):
                _prompt_for_missing_params(params, kwargs)

    def test_non_interactive_ok_when_condition_not_met(self):
        """Non-interactive mode should NOT error when requiredWhen condition is not met."""
        params = [
            Param(name="enabled", type="boolean", cli_name="--enabled", required=True),
            Param(name="frequency", type="string", cli_name="--frequency", required_when={"enabled": True}),
        ]
        kwargs = {"enabled": False}
        with patch("zilliz_cli.core.command_factory.sys") as mock_sys:
            mock_sys.stdin.isatty.return_value = False
            result = _prompt_for_missing_params(params, kwargs)
            assert result == {"enabled": False}

    def test_interactive_prompts_conditional_param(self):
        """Interactive mode should prompt for requiredWhen param when condition is met."""
        params = [
            Param(name="enabled", type="boolean", cli_name="--enabled", required=True),
            Param(name="frequency", type="string", cli_name="--frequency", required_when={"enabled": True}),
        ]
        kwargs = {"enabled": True}
        with (
            patch("zilliz_cli.core.command_factory.sys") as mock_sys,
            patch("zilliz_cli.core.command_factory.click") as mock_click,
        ):
            mock_sys.stdin.isatty.return_value = True
            mock_click.prompt.return_value = "1,2,3,4,5,6,7"
            mock_click.confirm.return_value = False  # "Configure additional options?" -> No
            result = _prompt_for_missing_params(params, kwargs)
            assert result["frequency"] == "1,2,3,4,5,6,7"

    def test_interactive_skips_conditional_when_not_met(self):
        """Interactive mode should NOT prompt for requiredWhen param when condition is not met."""
        params = [
            Param(name="enabled", type="boolean", cli_name="--enabled", required=True),
            Param(name="frequency", type="string", cli_name="--frequency", required_when={"enabled": True}),
        ]
        kwargs = {"enabled": False}
        with (
            patch("zilliz_cli.core.command_factory.sys") as mock_sys,
            patch("zilliz_cli.core.command_factory.click") as mock_click,
        ):
            mock_sys.stdin.isatty.return_value = True
            mock_click.confirm.return_value = False  # "Configure additional options?" -> No
            result = _prompt_for_missing_params(params, kwargs)
            assert "frequency" not in result

    def test_help_text_shows_required_when(self):
        """Help output should show requiredWhen condition."""
        model_dict = {
            "version": "1",
            "endpoint": "https://api.example.com",
            "resources": {
                "backup": {
                    "operations": {
                        "update-policy": {
                            "http": {"method": "POST", "path": "/v2/policy"},
                            "params": [
                                {"name": "enabled", "type": "boolean", "required": True, "cli": "--auto-backup"},
                                {
                                    "name": "frequency",
                                    "type": "string",
                                    "cli": "--frequency",
                                    "requiredWhen": {"enabled": True},
                                },
                            ],
                        }
                    }
                }
            },
        }
        model = CliModel.from_dict(model_dict)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        runner = CliRunner()
        result = runner.invoke(groups["backup"], ["update-policy", "--help"])
        assert "required when --auto-backup=True" in result.output


class TestOptionalParamPrompting:
    """Tests for Phase 3 optional param prompting."""

    def test_optional_params_offered_after_required(self):
        """After required params, user should be asked about optional params."""
        params = [
            Param(name="clusterId", type="string", cli_name="--cluster-id", required=True),
            Param(name="note", type="string", cli_name="--note"),
        ]
        kwargs = {"cluster_id": "c1"}  # required already provided
        with (
            patch("zilliz_cli.core.command_factory.sys") as mock_sys,
            patch("zilliz_cli.core.command_factory.click") as mock_click,
        ):
            mock_sys.stdin.isatty.return_value = True
            mock_click.confirm.return_value = True  # yes, configure
            mock_click.prompt.return_value = "my note"
            result = _prompt_for_missing_params(params, kwargs)
            assert result["note"] == "my note"

    def test_optional_params_skipped_when_declined(self):
        """User declining optional config should skip all optional params."""
        params = [
            Param(name="clusterId", type="string", cli_name="--cluster-id", required=True),
            Param(name="note", type="string", cli_name="--note"),
        ]
        kwargs = {"cluster_id": "c1"}
        with (
            patch("zilliz_cli.core.command_factory.sys") as mock_sys,
            patch("zilliz_cli.core.command_factory.click") as mock_click,
        ):
            mock_sys.stdin.isatty.return_value = True
            mock_click.confirm.return_value = False
            result = _prompt_for_missing_params(params, kwargs)
            assert "note" not in result

    def test_optional_param_skipped_with_empty_input(self):
        """Empty input for optional param should skip it."""
        params = [
            Param(name="clusterId", type="string", cli_name="--cluster-id", required=True),
            Param(name="note", type="string", cli_name="--note"),
        ]
        kwargs = {"cluster_id": "c1"}
        with (
            patch("zilliz_cli.core.command_factory.sys") as mock_sys,
            patch("zilliz_cli.core.command_factory.click") as mock_click,
        ):
            mock_sys.stdin.isatty.return_value = True
            mock_click.confirm.return_value = True
            mock_click.prompt.return_value = ""  # empty -> skip
            result = _prompt_for_missing_params(params, kwargs)
            assert "note" not in result

    def test_path_params_not_offered_as_optional(self):
        """Path params should never appear in optional prompts."""
        params = [
            Param(name="clusterId", type="string", cli_name="--cluster-id", required=True, position="path"),
            Param(name="backupId", type="string", cli_name="--backup-id", position="path"),
        ]
        kwargs = {"cluster_id": "c1"}
        with (
            patch("zilliz_cli.core.command_factory.sys") as mock_sys,
            patch("zilliz_cli.core.command_factory.click") as mock_click,
        ):
            mock_sys.stdin.isatty.return_value = True
            # confirm should NOT be called since there are no optional params
            _prompt_for_missing_params(params, kwargs)
            mock_click.confirm.assert_not_called()


class TestParamTransform:
    """Tests for param-level transforms (dayOfWeek, timeWindow)."""

    # --- dayOfWeek transform ---

    def test_day_of_week_preset_daily(self):
        assert _transform_day_of_week("daily") == "1,2,3,4,5,6,7"

    def test_day_of_week_preset_weekdays(self):
        assert _transform_day_of_week("weekdays") == "1,2,3,4,5"

    def test_day_of_week_preset_weekends(self):
        assert _transform_day_of_week("weekends") == "6,7"

    def test_day_of_week_preset_case_insensitive(self):
        assert _transform_day_of_week("Daily") == "1,2,3,4,5,6,7"
        assert _transform_day_of_week("WEEKDAYS") == "1,2,3,4,5"

    def test_day_of_week_numeric_passthrough(self):
        assert _transform_day_of_week("1,3,5") == "1,3,5"
        assert _transform_day_of_week("7") == "7"

    def test_day_of_week_invalid_raises(self):
        import pytest

        with pytest.raises(click.ClickException, match="Invalid --frequency"):
            _transform_day_of_week("monthly")
        with pytest.raises(click.ClickException, match="Invalid --frequency"):
            _transform_day_of_week("0,8")

    # --- timeWindow transform ---

    def test_time_window_single_hour(self):
        assert _transform_time_window("02:00") == "02:00-04:00"

    def test_time_window_wraps_midnight(self):
        assert _transform_time_window("22:00") == "22:00-00:00"
        assert _transform_time_window("23:00") == "23:00-01:00"

    def test_time_window_passthrough_full_window(self):
        assert _transform_time_window("03:00-07:00") == "03:00-07:00"

    def test_time_window_invalid_minute_raises(self):
        import pytest

        with pytest.raises(click.ClickException, match="Invalid --start-time"):
            _transform_time_window("02:30")

    def test_time_window_invalid_format_raises(self):
        import pytest

        with pytest.raises(click.ClickException, match="Invalid --start-time"):
            _transform_time_window("2am")

    # --- _apply_param_transform integration ---

    def test_apply_param_transform_day_of_week(self):
        p = Param(name="frequency", type="string", cli_name="--frequency", transform={"type": "dayOfWeek"})
        assert _apply_param_transform(p, "daily") == "1,2,3,4,5,6,7"

    def test_apply_param_transform_time_window(self):
        p = Param(
            name="startTime", type="string", cli_name="--start-time", transform={"type": "timeWindow", "windowHours": 2}
        )
        assert _apply_param_transform(p, "02:00") == "02:00-04:00"

    def test_apply_param_transform_none_passthrough(self):
        p = Param(name="retentionDays", type="integer", cli_name="--retention-days")
        assert _apply_param_transform(p, 7) == 7

    def test_apply_param_transform_none_value(self):
        p = Param(name="frequency", type="string", cli_name="--frequency", transform={"type": "dayOfWeek"})
        assert _apply_param_transform(p, None) is None

    # --- model parsing ---

    def test_param_from_dict_parses_transform(self):
        p = Param.from_dict(
            {
                "name": "frequency",
                "type": "string",
                "cli": "--frequency",
                "transform": {"type": "dayOfWeek"},
            }
        )
        assert p.transform == {"type": "dayOfWeek"}

    def test_param_from_dict_no_transform(self):
        p = Param.from_dict({"name": "name", "type": "string", "cli": "--name"})
        assert p.transform is None

    # --- interactive mode uses transform prompts ---

    def test_interactive_day_of_week_preset(self):
        """Interactive mode should use multi-select for dayOfWeek transform."""
        params = [
            Param(name="enabled", type="boolean", cli_name="--enabled", required=True),
            Param(
                name="frequency",
                type="string",
                cli_name="--frequency",
                required_when={"enabled": True},
                transform={"type": "dayOfWeek"},
            ),
        ]
        kwargs = {"enabled": True}
        with (
            patch("zilliz_cli.core.command_factory.sys") as mock_sys,
            patch("zilliz_cli.core.command_factory.questionary") as mock_q,
            patch("zilliz_cli.core.command_factory.click") as mock_click,
        ):
            mock_sys.stdin.isatty.return_value = True
            mock_q.select.return_value.ask.return_value = "daily"
            mock_click.confirm.return_value = False
            result = _prompt_for_missing_params(params, kwargs)
            assert result["frequency"] == "1,2,3,4,5,6,7"

    def test_interactive_time_window(self):
        """Interactive mode should prompt for time input for timeWindow transform."""
        params = [
            Param(name="enabled", type="boolean", cli_name="--enabled", required=True),
            Param(
                name="startTime",
                type="string",
                cli_name="--start-time",
                required_when={"enabled": True},
                transform={"type": "timeWindow", "windowHours": 2},
            ),
        ]
        kwargs = {"enabled": True}
        with (
            patch("zilliz_cli.core.command_factory.sys") as mock_sys,
            patch("zilliz_cli.core.command_factory.click") as mock_click,
        ):
            mock_sys.stdin.isatty.return_value = True
            mock_click.prompt.return_value = "02:00"
            mock_click.confirm.return_value = False
            result = _prompt_for_missing_params(params, kwargs)
            assert result["start_time"] == "02:00-04:00"


class TestNormalizeSchemaParams:
    """BUG-003: params should be normalized to elementTypeParams for Milvus v2 API."""

    def test_params_renamed_to_element_type_params(self):
        body = {
            "collectionName": "test",
            "schema": {
                "fields": [
                    {"fieldName": "id", "dataType": "Int64", "isPrimary": True},
                    {"fieldName": "vec", "dataType": "FloatVector", "params": {"dim": 128}},
                ]
            },
        }
        result = _normalize_schema_params(body)
        vec_field = result["schema"]["fields"][1]
        assert "params" not in vec_field
        assert vec_field["elementTypeParams"] == {"dim": "128"}

    def test_element_type_params_not_overwritten(self):
        body = {
            "schema": {
                "fields": [
                    {
                        "fieldName": "vec",
                        "dataType": "FloatVector",
                        "elementTypeParams": {"dim": "256"},
                        "params": {"dim": 128},
                    },
                ]
            },
        }
        result = _normalize_schema_params(body)
        vec_field = result["schema"]["fields"][0]
        assert vec_field["elementTypeParams"] == {"dim": "256"}
        assert "params" in vec_field  # not removed when elementTypeParams already exists

    def test_values_converted_to_strings(self):
        body = {
            "schema": {
                "fields": [
                    {"fieldName": "vec", "dataType": "FloatVector", "params": {"dim": 768, "foo": True}},
                ]
            },
        }
        result = _normalize_schema_params(body)
        assert result["schema"]["fields"][0]["elementTypeParams"] == {"dim": "768", "foo": "True"}

    def test_no_schema_passthrough(self):
        body = {"collectionName": "test", "dimension": 128}
        assert _normalize_schema_params(body) == body

    def test_no_fields_passthrough(self):
        body = {"schema": {"description": "test"}}
        assert _normalize_schema_params(body) == body

    def test_fields_without_params_unchanged(self):
        body = {
            "schema": {
                "fields": [
                    {"fieldName": "id", "dataType": "Int64", "isPrimary": True},
                ]
            },
        }
        result = _normalize_schema_params(body)
        assert result["schema"]["fields"][0] == {"fieldName": "id", "dataType": "Int64", "isPrimary": True}


class TestParseJsonValue:
    """BUG-004: --data and other JSON params should support file:// prefix."""

    def test_parse_inline_json_array(self):
        result = _parse_json_value('[{"id": 1}]', "--data")
        assert result == [{"id": 1}]

    def test_parse_inline_json_object(self):
        result = _parse_json_value('{"key": "val"}', "--body")
        assert result == {"key": "val"}

    def test_parse_file_json(self, tmp_path):
        f = tmp_path / "data.json"
        f.write_text('[{"id": 1, "vector": [0.1, 0.2]}]')
        result = _parse_json_value(f"file://{f}", "--data")
        assert result == [{"id": 1, "vector": [0.1, 0.2]}]

    def test_parse_file_not_found(self):
        import pytest

        with pytest.raises(click.ClickException, match="File not found"):
            _parse_json_value("file:///no/such/file.json", "--data")

    def test_parse_file_invalid_json(self, tmp_path):
        import pytest

        f = tmp_path / "bad.json"
        f.write_text("not json")
        with pytest.raises(click.ClickException, match="Invalid JSON in"):
            _parse_json_value(f"file://{f}", "--data")

    def test_parse_invalid_inline_json(self):
        import pytest

        with pytest.raises(click.ClickException, match="Invalid JSON for --data"):
            _parse_json_value("not json", "--data")


class TestNormalizeArrayFields:
    """BUG-006: Array fields should be flattened from protobuf structure to plain arrays."""

    def test_string_array_flattened(self):
        result = [{"doc_id": 1, "tags": {"Data": {"StringData": {"data": ["a", "b"]}}}}]
        assert _normalize_array_fields(result) == [{"doc_id": 1, "tags": ["a", "b"]}]

    def test_int_array_flattened(self):
        result = [{"id": 1, "scores": {"Data": {"LongData": {"data": [10, 20]}}}}]
        assert _normalize_array_fields(result) == [{"id": 1, "scores": [10, 20]}]

    def test_float_array_flattened(self):
        result = [{"id": 1, "vals": {"Data": {"FloatData": {"data": [1.1, 2.2]}}}}]
        assert _normalize_array_fields(result) == [{"id": 1, "vals": [1.1, 2.2]}]

    def test_non_array_fields_unchanged(self):
        result = [{"id": 1, "name": "test", "score": 0.95}]
        assert _normalize_array_fields(result) == [{"id": 1, "name": "test", "score": 0.95}]

    def test_mixed_fields(self):
        result = [{"id": 1, "name": "doc", "tags": {"Data": {"StringData": {"data": ["x"]}}}}]
        normalized = _normalize_array_fields(result)
        assert normalized == [{"id": 1, "name": "doc", "tags": ["x"]}]

    def test_dict_result(self):
        result = {"count": 5, "tags": {"Data": {"StringData": {"data": ["a"]}}}}
        assert _normalize_array_fields(result) == {"count": 5, "tags": ["a"]}

    def test_regular_nested_dict_unchanged(self):
        """Normal nested dicts that don't match protobuf pattern should be untouched."""
        result = [{"id": 1, "meta": {"key": "val", "num": 42}}]
        assert _normalize_array_fields(result) == [{"id": 1, "meta": {"key": "val", "num": 42}}]

    def test_none_and_primitives_passthrough(self):
        assert _normalize_array_fields(None) is None
        assert _normalize_array_fields("text") == "text"
        assert _normalize_array_fields(42) == 42

    def test_empty_list(self):
        assert _normalize_array_fields([]) == []
