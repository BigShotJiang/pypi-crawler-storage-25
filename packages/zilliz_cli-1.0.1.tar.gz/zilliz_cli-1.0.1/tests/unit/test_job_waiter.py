from unittest.mock import MagicMock, patch

import click
import pytest

from zilliz_cli.core.exceptions import APIError
from zilliz_cli.core.job_waiter import wait_for_job


class TestWaitForJob:
    def _make_caller(self, side_effects):
        caller = MagicMock()
        caller.call = MagicMock(side_effect=side_effects)
        return caller

    @patch("zilliz_cli.core.job_waiter.time.sleep", return_value=None)
    def test_immediate_success(self, mock_sleep):
        caller = self._make_caller(
            [
                {"jobId": "job-1", "status": "SUCCESSFUL", "progress": "100"},
            ]
        )

        result = wait_for_job(caller, "job-1", timeout=60, interval=1)

        assert result["status"] == "SUCCESSFUL"
        assert result["progress"] == "100"
        caller.call.assert_called_once()
        mock_sleep.assert_not_called()

    @patch("zilliz_cli.core.job_waiter.time.sleep", return_value=None)
    def test_polls_until_success(self, mock_sleep):
        caller = self._make_caller(
            [
                {"jobId": "job-1", "status": "PENDING", "progress": "0"},
                {"jobId": "job-1", "status": "IN_PROGRESS", "progress": "50"},
                {"jobId": "job-1", "status": "SUCCESSFUL", "progress": "100"},
            ]
        )

        result = wait_for_job(caller, "job-1", timeout=60, interval=1)

        assert result["status"] == "SUCCESSFUL"
        assert caller.call.call_count == 3
        assert mock_sleep.call_count == 2

    @patch("zilliz_cli.core.job_waiter.time.sleep", return_value=None)
    def test_stops_on_failed(self, mock_sleep):
        caller = self._make_caller(
            [
                {"jobId": "job-1", "status": "IN_PROGRESS", "progress": "30"},
                {"jobId": "job-1", "status": "FAILED", "progress": "30", "reason": "disk full"},
            ]
        )

        result = wait_for_job(caller, "job-1", timeout=60, interval=1)

        assert result["status"] == "FAILED"
        assert result["reason"] == "disk full"

    @patch("zilliz_cli.core.job_waiter.time.sleep", return_value=None)
    def test_stops_on_canceled(self, mock_sleep):
        caller = self._make_caller(
            [
                {"jobId": "job-1", "status": "CANCELED", "progress": "10"},
            ]
        )

        result = wait_for_job(caller, "job-1", timeout=60, interval=1)

        assert result["status"] == "CANCELED"

    @patch("zilliz_cli.core.job_waiter.time.monotonic")
    @patch("zilliz_cli.core.job_waiter.time.sleep", return_value=None)
    def test_timeout(self, mock_sleep, mock_monotonic):
        # Simulate time passing beyond timeout
        mock_monotonic.side_effect = [0, 0, 100]

        caller = self._make_caller(
            [
                {"jobId": "job-1", "status": "IN_PROGRESS", "progress": "50"},
                {"jobId": "job-1", "status": "IN_PROGRESS", "progress": "60"},
            ]
        )

        with pytest.raises(click.ClickException, match="Timeout"):
            wait_for_job(caller, "job-1", timeout=30, interval=1)

    @patch("zilliz_cli.core.job_waiter.time.sleep", return_value=None)
    def test_retries_on_api_error(self, mock_sleep):
        caller = self._make_caller(
            [
                APIError(500, "Server error"),
                {"jobId": "job-1", "status": "SUCCESSFUL", "progress": "100"},
            ]
        )

        result = wait_for_job(caller, "job-1", timeout=60, interval=1)

        assert result["status"] == "SUCCESSFUL"
        assert caller.call.call_count == 2

    @patch("zilliz_cli.core.job_waiter.time.sleep", return_value=None)
    def test_fails_after_consecutive_errors(self, mock_sleep):
        caller = self._make_caller(
            [
                APIError(500, "Error 1"),
                APIError(500, "Error 2"),
                APIError(500, "Error 3"),
            ]
        )

        with pytest.raises(click.ClickException, match="failed 3 times"):
            wait_for_job(caller, "job-1", timeout=60, interval=1)

    @patch("zilliz_cli.core.job_waiter.time.sleep", side_effect=KeyboardInterrupt)
    def test_keyboard_interrupt(self, mock_sleep):
        caller = self._make_caller(
            [
                {"jobId": "job-1", "status": "IN_PROGRESS", "progress": "50"},
            ]
        )

        result = wait_for_job(caller, "job-1", timeout=60, interval=1)

        assert result["status"] == "IN_PROGRESS"
