# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import json
from unittest.mock import patch

import click
import pytest
from click.testing import CliRunner

from zilliz_cli.cli import main
from zilliz_cli.commands.alert import _parse_action, _resolve_comparison


class TestAlertList:
    def setup_method(self):
        self.runner = CliRunner()

    def _invoke(self, args, config_dir):
        return self.runner.invoke(
            main,
            ["--api-key", "test-key", "alert", "list", *args],
            obj={"config_dir": config_dir},
        )

    def test_list_json(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "count": 2,
                "currentPage": 1,
                "pageSize": 10,
                "alertRules": [
                    {
                        "id": "alert-001",
                        "ruleName": "High CU",
                        "metricName": "CU_COMPUTATION",
                        "level": "WARNING",
                        "enabled": True,
                        "threshold": "80",
                        "comparisonMethod": "GREATER_THAN",
                        "actions": [{"type": "EMAIL", "config": {"email": "a@b.com"}}],
                    },
                    {
                        "id": "alert-002",
                        "ruleName": "Low Balance",
                        "metricName": "WALLET_BALANCE",
                        "level": "CRITICAL",
                        "enabled": False,
                        "threshold": "100",
                        "comparisonMethod": "LESS_THAN",
                        "actions": [],
                    },
                ],
            }

            result = self._invoke(["--project-id", "proj-xxx", "-o", "json"], config_dir)

            assert result.exit_code == 0
            data = json.loads(result.output)
            assert len(data["alertRules"]) == 2

    def test_list_table(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "count": 1,
                "currentPage": 1,
                "pageSize": 10,
                "alertRules": [
                    {
                        "id": "alert-001",
                        "ruleName": "High CU",
                        "metricName": "CU_COMPUTATION",
                        "level": "WARNING",
                        "enabled": True,
                        "threshold": "80",
                        "comparisonMethod": "GREATER_THAN",
                        "actions": [],
                    },
                ],
            }

            result = self._invoke(["--project-id", "proj-xxx"], config_dir)

            assert result.exit_code == 0
            assert "High CU" in result.output
            assert "CU_COMPUTATI" in result.output

    def test_list_empty(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "count": 0,
                "currentPage": 1,
                "pageSize": 10,
                "alertRules": [],
            }

            result = self._invoke(["--project-id", "proj-xxx"], config_dir)

            assert result.exit_code == 0
            assert "No alert rules" in result.output

    def test_list_with_project_id(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"count": 0, "alertRules": []}

            self._invoke(["--project-id", "proj-xxx"], config_dir)

            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["projectId"] == "proj-xxx"

    def test_list_with_pagination(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"count": 0, "alertRules": []}

            self._invoke(["--project-id", "proj-xxx", "--page-size", "20", "--page", "3"], config_dir)

            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["pageSize"] == 20
            assert body["currentPage"] == 3

    def test_list_api_error(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            from zilliz_cli.core.exceptions import APIError

            mock_instance = MockCaller.return_value
            mock_instance.call.side_effect = APIError(403, "Permission denied")

            result = self._invoke(["--project-id", "proj-xxx", "-o", "json"], config_dir)

            assert result.exit_code != 0


class TestAlertCreate:
    def setup_method(self):
        self.runner = CliRunner()

    def _invoke(self, args, config_dir):
        return self.runner.invoke(
            main,
            ["--api-key", "test-key", "alert", "create", *args],
            obj={"config_dir": config_dir},
        )

    def test_create_basic(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"id": "alert-new"}

            result = self._invoke(
                [
                    "--project-id",
                    "proj-xxx",
                    "--metric-name",
                    "CU_COMPUTATION",
                    "--threshold",
                    "80",
                    "--comparison",
                    ">",
                    "-o",
                    "json",
                ],
                config_dir,
            )

            assert result.exit_code == 0
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["projectId"] == "proj-xxx"
            assert body["metricName"] == "CU_COMPUTATION"
            assert body["threshold"] == "80"
            assert body["comparisonMethod"] == "GREATER_THAN"

    def test_create_with_all_options(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"id": "alert-new"}

            result = self._invoke(
                [
                    "--project-id",
                    "proj-xxx",
                    "--metric-name",
                    "CU_COMPUTATION",
                    "--threshold",
                    "90",
                    "--comparison",
                    ">=",
                    "--rule-name",
                    "My Alert",
                    "--level",
                    "CRITICAL",
                    "--window-size",
                    "5m",
                    "--cluster-id",
                    "in01-aaa",
                    "--cluster-id",
                    "in01-bbb",
                    "--action",
                    "email:admin@example.com",
                    "--action",
                    "slack:https://hooks.slack.com/xxx",
                    "--send-resolved",
                    "--repeat-interval",
                    "300",
                    "--enabled",
                    "-o",
                    "json",
                ],
                config_dir,
            )

            assert result.exit_code == 0
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["ruleName"] == "My Alert"
            assert body["level"] == "CRITICAL"
            assert body["windowSize"] == "5m"
            assert body["targetInstanceIds"] == ["in01-aaa", "in01-bbb"]
            assert len(body["actions"]) == 2
            assert body["actions"][0]["type"] == "EMAIL"
            assert body["actions"][1]["type"] == "SLACK"
            assert body["sendResolved"] is True
            assert body["repeatIntervalSeconds"] == 300
            assert body["enabled"] is True

    def test_create_missing_required_non_interactive(self, config_dir):
        """Non-interactive mode should fail when required params are missing."""
        result = self._invoke(
            ["--project-id", "proj-xxx", "--metric-name", "CU_COMPUTATION", "-o", "json"],
            config_dir,
        )
        assert result.exit_code != 0

    def test_create_comparison_aliases(self, config_dir):
        """Various comparison aliases should work."""
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"id": "alert-new"}

            for alias, expected in [("gt", "GREATER_THAN"), ("lt", "LESS_THAN"), ("lte", "LESS_THAN_OR_EQUAL")]:
                self._invoke(
                    [
                        "--project-id",
                        "proj-xxx",
                        "--metric-name",
                        "CU_COMPUTATION",
                        "--threshold",
                        "80",
                        "--comparison",
                        alias,
                        "-o",
                        "json",
                    ],
                    config_dir,
                )
                body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
                assert body["comparisonMethod"] == expected


class TestAlertUpdate:
    def setup_method(self):
        self.runner = CliRunner()

    def _invoke(self, args, config_dir):
        return self.runner.invoke(
            main,
            ["--api-key", "test-key", "alert", "update", *args],
            obj={"config_dir": config_dir},
        )

    def test_update_threshold(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"id": "alert-001"}

            result = self._invoke(
                ["--id", "alert-001", "--threshold", "90", "-o", "json"],
                config_dir,
            )

            assert result.exit_code == 0
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["threshold"] == "90"
            path_params = mock_instance.call.call_args[1].get("path_params")
            assert path_params["id"] == "alert-001"

    def test_update_no_fields(self, config_dir):
        """Should fail when no update fields are provided."""
        with patch("zilliz_cli.core.helpers.APICaller"):
            result = self._invoke(["--id", "alert-001"], config_dir)
            assert result.exit_code != 0

    def test_update_multiple_fields(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"id": "alert-001"}

            result = self._invoke(
                [
                    "--id",
                    "alert-001",
                    "--level",
                    "CRITICAL",
                    "--threshold",
                    "95",
                    "--comparison",
                    ">=",
                    "-o",
                    "json",
                ],
                config_dir,
            )

            assert result.exit_code == 0
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["level"] == "CRITICAL"
            assert body["threshold"] == "95"
            assert body["comparisonMethod"] == "GREATER_THAN_OR_EQUAL"


class TestAlertDelete:
    def setup_method(self):
        self.runner = CliRunner()

    def _invoke(self, args, config_dir, input_text=None):
        return self.runner.invoke(
            main,
            ["--api-key", "test-key", "alert", "delete", *args],
            obj={"config_dir": config_dir},
            input=input_text,
        )

    def test_delete_with_yes_flag(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = None

            result = self._invoke(["--id", "alert-001", "-y"], config_dir)

            assert result.exit_code == 0
            assert "deleted" in result.output
            path_params = mock_instance.call.call_args[1].get("path_params")
            assert path_params["id"] == "alert-001"

    def test_delete_confirm_yes(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = None

            result = self._invoke(["--id", "alert-001"], config_dir, input_text="y\n")

            assert result.exit_code == 0
            assert "deleted" in result.output

    def test_delete_confirm_no(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller"):
            result = self._invoke(["--id", "alert-001"], config_dir, input_text="n\n")

            assert result.exit_code == 0
            assert "Cancelled" in result.output


class TestAlertEnable:
    def setup_method(self):
        self.runner = CliRunner()

    def _invoke(self, args, config_dir):
        return self.runner.invoke(
            main,
            ["--api-key", "test-key", "alert", "enable", *args],
            obj={"config_dir": config_dir},
        )

    def test_enable(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {}

            result = self._invoke(["--id", "alert-001"], config_dir)

            assert result.exit_code == 0
            assert "enabled" in result.output
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["enabled"] is True


class TestAlertDisable:
    def setup_method(self):
        self.runner = CliRunner()

    def _invoke(self, args, config_dir):
        return self.runner.invoke(
            main,
            ["--api-key", "test-key", "alert", "disable", *args],
            obj={"config_dir": config_dir},
        )

    def test_disable(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {}

            result = self._invoke(["--id", "alert-001"], config_dir)

            assert result.exit_code == 0
            assert "disabled" in result.output
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert body["enabled"] is False


class TestResolveComparison:
    def test_symbols(self):
        assert _resolve_comparison(">") == "GREATER_THAN"
        assert _resolve_comparison("<") == "LESS_THAN"
        assert _resolve_comparison(">=") == "GREATER_THAN_OR_EQUAL"
        assert _resolve_comparison("<=") == "LESS_THAN_OR_EQUAL"
        assert _resolve_comparison("=") == "EQUAL"

    def test_aliases(self):
        assert _resolve_comparison("gt") == "GREATER_THAN"
        assert _resolve_comparison("lt") == "LESS_THAN"
        assert _resolve_comparison("gte") == "GREATER_THAN_OR_EQUAL"
        assert _resolve_comparison("lte") == "LESS_THAN_OR_EQUAL"
        assert _resolve_comparison("eq") == "EQUAL"

    def test_full_names(self):
        assert _resolve_comparison("greater_than") == "GREATER_THAN"
        assert _resolve_comparison("LESS_THAN") == "LESS_THAN"

    def test_case_insensitive(self):
        assert _resolve_comparison("GT") == "GREATER_THAN"
        assert _resolve_comparison("Gte") == "GREATER_THAN_OR_EQUAL"

    def test_invalid(self):
        with pytest.raises(click.BadParameter):
            _resolve_comparison("!=")


class TestParseAction:
    def test_email(self):
        result = _parse_action("email:user@example.com")
        assert result == {"type": "EMAIL", "config": {"email": "user@example.com"}}

    def test_slack(self):
        result = _parse_action("slack:https://hooks.slack.com/xxx")
        assert result == {"type": "SLACK", "config": {"webhookUrl": "https://hooks.slack.com/xxx"}}

    def test_webhook(self):
        result = _parse_action("webhook:https://my-server.com/hook")
        assert result == {"type": "WEBHOOK", "config": {"url": "https://my-server.com/hook"}}

    def test_pagerduty(self):
        result = _parse_action("pagerduty:ROUTING_KEY_123")
        assert result == {"type": "PAGERDUTY", "config": {"routingKey": "ROUTING_KEY_123"}}

    def test_case_insensitive(self):
        result = _parse_action("Email:user@example.com")
        assert result["type"] == "EMAIL"

    def test_invalid_format(self):
        with pytest.raises(click.BadParameter):
            _parse_action("invalid-no-colon")

    def test_unknown_type(self):
        with pytest.raises(click.BadParameter):
            _parse_action("sms:1234567890")
