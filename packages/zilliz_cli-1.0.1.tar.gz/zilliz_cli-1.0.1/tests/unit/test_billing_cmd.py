# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

from unittest.mock import patch

from click.testing import CliRunner

from zilliz_cli.cli import main


class TestBillingUsage:
    def setup_method(self):
        self.runner = CliRunner()

    def test_usage_default_today(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "billing", "usage", "--output", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            mock_instance.call.assert_called_once()
            call_args = mock_instance.call.call_args
            assert call_args[0][0] == "POST"
            assert "/v2/usage/query" in call_args[0][1]

    def test_usage_last_7d(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "billing", "usage", "--last", "7d", "-o", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            body = mock_instance.call.call_args[1].get("body") or mock_instance.call.call_args[0][2]
            assert "start" in body
            assert "end" in body

    def test_usage_month(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "billing", "usage", "--month", "last", "-o", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0

    def test_usage_start_end(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "billing",
                    "usage",
                    "--start",
                    "2026-01-01",
                    "--end",
                    "2026-02-01",
                    "-o",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0

    def test_usage_start_without_end_errors(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"results": []}

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "billing", "usage", "--start", "2026-01-01", "-o", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code != 0

    def test_usage_table_output_with_data(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "results": [
                    {
                        "intervalStart": "2026-01-15T00:00:00Z",
                        "total": 1.23,
                        "items": [
                            {
                                "costType": "compute",
                                "quantity": 24,
                                "unit": "CU-hour",
                                "amount": 1.23,
                                "price": {"unitPrice": 0.05},
                                "properties": {"clusterId": "in01-xxx"},
                            }
                        ],
                    }
                ]
            }

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "billing", "usage"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            assert "1.23" in result.output or "$1.23" in result.output


class TestBillingInvoices:
    def setup_method(self):
        self.runner = CliRunner()

    def test_list_invoices_json(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "invoices": [{"id": "inv-001", "status": "paid", "amountDue": 1000}],
                "count": 1,
            }

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "billing", "invoices", "-o", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            assert "inv-001" in result.output

    def test_describe_invoice(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "id": "inv-001",
                "status": "paid",
                "amountDue": 1000,
                "total": 1500,
                "currency": "USD",
            }

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "billing", "invoices", "--invoice-id", "inv-001"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            assert "inv-001" in result.output
