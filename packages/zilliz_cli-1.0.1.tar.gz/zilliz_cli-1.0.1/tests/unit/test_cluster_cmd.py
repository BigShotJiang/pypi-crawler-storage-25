# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import json
from unittest.mock import patch

from click.testing import CliRunner

from zilliz_cli.cli import main


class TestClusterList:
    def setup_method(self):
        self.runner = CliRunner()

    def test_cluster_list_json(self, config_dir):
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [
                {"clusterId": "in01-abc", "clusterName": "dev", "status": "RUNNING"},
                {"clusterId": "in01-def", "clusterName": "prod", "status": "RUNNING"},
            ]

            result = self.runner.invoke(
                main, ["--api-key", "test-key", "cluster", "list", "--output", "json"], obj={"config_dir": config_dir}
            )

            assert result.exit_code == 0
            data = json.loads(result.output)
            assert len(data) == 2
            assert data[0]["clusterId"] == "in01-abc"

    def test_cluster_list_table(self, config_dir):
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [
                {"clusterId": "in01-abc", "clusterName": "dev"},
            ]

            result = self.runner.invoke(
                main, ["--api-key", "test-key", "cluster", "list"], obj={"config_dir": config_dir}
            )

            assert result.exit_code == 0
            assert "in01-abc" in result.output


class TestClusterDescribe:
    def setup_method(self):
        self.runner = CliRunner()

    def test_describe_by_id(self, config_dir):
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"clusterId": "in01-abc", "clusterName": "dev", "status": "RUNNING"}

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "cluster", "describe", "--cluster-id", "in01-abc", "--output", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["status"] == "RUNNING"


class TestClusterCreate:
    def setup_method(self):
        self.runner = CliRunner()

    def test_create_cluster(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"clusterId": "in01-new"}

            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "cluster",
                    "create",
                    "--name",
                    "my-cluster",
                    "--type",
                    "serverless",
                    "--project-id",
                    "p1",
                    "--region",
                    "gcp-us-west1",
                    "--output",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            assert "in01-new" in result.output


class TestClusterDelete:
    def setup_method(self):
        self.runner = CliRunner()

    def test_delete_cluster(self, config_dir):
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {}

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "cluster", "delete", "--cluster-id", "in01-abc", "--yes", "--output", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
