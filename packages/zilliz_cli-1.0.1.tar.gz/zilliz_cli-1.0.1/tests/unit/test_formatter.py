# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import json

import pytest
import yaml

from zilliz_cli.formatter.base import get_formatter
from zilliz_cli.formatter.csv_fmt import CsvFormatter
from zilliz_cli.formatter.json import JsonFormatter
from zilliz_cli.formatter.table import TableFormatter
from zilliz_cli.formatter.text import TextFormatter
from zilliz_cli.formatter.yaml_fmt import YamlFormatter


class TestGetFormatter:
    def test_get_json(self):
        assert isinstance(get_formatter("json"), JsonFormatter)

    def test_get_table(self):
        assert isinstance(get_formatter("table"), TableFormatter)

    def test_get_text(self):
        assert isinstance(get_formatter("text"), TextFormatter)

    def test_get_yaml(self):
        assert isinstance(get_formatter("yaml"), YamlFormatter)

    def test_get_csv(self):
        assert isinstance(get_formatter("csv"), CsvFormatter)

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown"):
            get_formatter("xml")


class TestJsonFormatter:
    def setup_method(self):
        self.fmt = JsonFormatter()

    def test_format_dict(self):
        result = self.fmt.format_success({"id": "abc", "name": "test"})
        parsed = json.loads(result)
        assert parsed["id"] == "abc"

    def test_format_list(self):
        result = self.fmt.format_success([{"id": 1}, {"id": 2}])
        parsed = json.loads(result)
        assert len(parsed) == 2

    def test_format_error(self):
        result = self.fmt.format_error(80001, "Invalid API key")
        parsed = json.loads(result)
        assert parsed["error"]["code"] == 80001
        assert parsed["error"]["message"] == "Invalid API key"


class TestTableFormatter:
    def setup_method(self):
        self.fmt = TableFormatter()

    def test_format_list_of_dicts(self):
        data = [{"id": "c1", "name": "cluster1"}, {"id": "c2", "name": "cluster2"}]
        result = self.fmt.format_success(data)
        assert "c1" in result
        assert "cluster2" in result

    def test_format_single_dict(self):
        data = {"id": "c1", "name": "cluster1", "status": "RUNNING"}
        result = self.fmt.format_success(data)
        assert "c1" in result
        assert "RUNNING" in result

    def test_format_empty_list(self):
        result = self.fmt.format_success([])
        assert "No data" in result

    def test_format_empty_dict(self):
        """Empty dict (e.g., from create operations) should show Success."""
        result = self.fmt.format_success({})
        assert "Success" in result

    def test_format_error(self):
        result = self.fmt.format_error(80001, "Invalid API key")
        assert "80001" in result
        assert "Invalid API key" in result


class TestTextFormatter:
    def setup_method(self):
        self.fmt = TextFormatter()

    def test_format_dict(self):
        result = self.fmt.format_success({"id": "abc", "name": "test"})
        assert "id: abc" in result
        assert "name: test" in result

    def test_format_list(self):
        result = self.fmt.format_success([{"id": 1}, {"id": 2}])
        assert "id: 1" in result
        assert "id: 2" in result

    def test_format_error(self):
        result = self.fmt.format_error(80001, "Invalid API key")
        assert "80001" in result


class TestTableFormatterPagination:
    """Tests for paginated response extraction."""

    def setup_method(self):
        self.fmt = TableFormatter()

    def test_extract_clusters_from_paginated_response(self):
        """Paginated response with clusters should be extracted and displayed as table."""
        data = {
            "count": 2,
            "currentPage": 1,
            "pageSize": 10,
            "clusters": [
                {"clusterId": "c1", "clusterName": "cluster1", "status": "RUNNING"},
                {"clusterId": "c2", "clusterName": "cluster2", "status": "STOPPED"},
            ],
        }
        result = self.fmt.format_success(data)
        # Should show cluster data, not the pagination wrapper
        assert "c1" in result
        assert "cluster1" in result
        assert "c2" in result
        assert "cluster2" in result
        # Should not show pagination metadata as field names
        assert "currentPage" not in result

    def test_extract_backups_from_paginated_response(self):
        """Paginated response with backups should be extracted."""
        data = {
            "count": 1,
            "currentPage": 1,
            "pageSize": 10,
            "backups": [
                {"backupId": "b1", "backupName": "backup1"},
            ],
        }
        result = self.fmt.format_success(data)
        assert "b1" in result
        assert "backup1" in result

    def test_non_paginated_dict_unchanged(self):
        """Regular dict without pagination fields should be displayed as key-value."""
        data = {"clusterId": "c1", "clusterName": "test", "status": "RUNNING"}
        result = self.fmt.format_success(data)
        assert "clusterId" in result
        assert "c1" in result

    def test_dict_with_list_but_no_pagination_fields(self):
        """Dict with list[dict] should render as sub-table."""
        data = {"items": [{"id": 1}, {"id": 2}]}
        result = self.fmt.format_success(data)
        # list[dict] should be rendered as sub-table with header
        assert "Items:" in result
        assert "1" in result
        assert "2" in result

    def test_shows_pagination_info_when_total_exceeds_page_size(self):
        """Should show 'Showing X of Y (page Z)' when total > pageSize."""
        data = {
            "count": 25,
            "currentPage": 1,
            "pageSize": 10,
            "clusters": [{"clusterId": "c1"}, {"clusterId": "c2"}],
        }
        result = self.fmt.format_success(data)
        assert "Showing 2 of 25" in result
        assert "page 1" in result

    def test_hides_pagination_info_when_total_within_page_size(self):
        """Should not show pagination info when total <= pageSize."""
        data = {
            "count": 2,
            "currentPage": 1,
            "pageSize": 10,
            "clusters": [{"clusterId": "c1"}, {"clusterId": "c2"}],
        }
        result = self.fmt.format_success(data)
        assert "Showing" not in result
        assert "page" not in result


class TestTableFormatterNestedDisplay:
    """Tests for nested dict display (describe commands)."""

    def setup_method(self):
        self.fmt = TableFormatter()

    def test_nested_list_dict_as_sub_table(self):
        """list[dict] fields should render as sub-tables."""
        data = {
            "name": "test",
            "status": "RUNNING",
            "fields": [
                {"name": "id", "type": "Int64", "primaryKey": True},
                {"name": "vector", "type": "FloatVector", "primaryKey": False},
            ],
        }
        result = self.fmt.format_success(data)
        # Simple fields in main section
        assert "name" in result
        assert "test" in result
        assert "RUNNING" in result
        # Nested list as sub-table
        assert "Fields:" in result
        assert "Int64" in result
        assert "FloatVector" in result

    def test_boolean_values_as_yes_no(self):
        """Boolean values in nested tables should show as Yes/No."""
        data = {
            "items": [{"enabled": True}, {"enabled": False}],
        }
        result = self.fmt.format_success(data)
        assert "Yes" in result
        assert "No" in result

    def test_empty_list_as_dash(self):
        """Empty list should display as dash."""
        data = {"name": "test", "aliases": []}
        result = self.fmt.format_success(data)
        assert "-" in result

    def test_key_value_params_formatted(self):
        """Params like [{key: 'dim', value: '768'}] should show as dim=768."""
        data = {
            "fields": [
                {"name": "vector", "params": [{"key": "dim", "value": "768"}]},
            ],
        }
        result = self.fmt.format_success(data)
        assert "dim=768" in result


class TestTableFormatterColumnFiltering:
    """Tests for column filtering with many fields."""

    def setup_method(self):
        self.fmt = TableFormatter()

    def test_priority_fields_shown_first(self):
        """Priority fields should be shown when there are too many columns."""
        data = [
            {
                "clusterName": "test",
                "clusterId": "c1",
                "status": "RUNNING",
                "plan": "Enterprise",
                "regionId": "aws-us-west-2",
                "cuType": "Performance-optimized",
                "cuSize": 1,
                "createTime": "2026-01-01",
                "description": "desc",
                "connectAddress": "https://...",
                "privateLinkAddress": "",
                "projectId": "proj-xxx",
                "deploymentOption": "Dedicated",
            }
        ]
        result = self.fmt.format_success(data)
        # Priority fields should be present
        assert "clusterName" in result or "test" in result
        assert "status" in result or "RUNNING" in result
        # Should be limited to avoid truncation (some fields may be hidden)

    def test_few_columns_show_all(self):
        """When columns are few, all should be shown."""
        data = [{"cloudId": "aws", "regionId": "aws-us-west-2", "domain": "api.example.com"}]
        result = self.fmt.format_success(data)
        assert "aws" in result
        assert "aws-us-west-2" in result
        assert "api.example.com" in result


class TestTableFieldsPriority:
    """BUG-008: collection describe table should show type, primaryKey, params columns."""

    def setup_method(self):
        self.fmt = TableFormatter()

    def test_fields_subtable_shows_type_and_primary_key(self):
        data = {
            "collectionName": "test_col",
            "fields": [
                {
                    "autoId": False,
                    "clusteringKey": False,
                    "description": "pk",
                    "id": 100,
                    "name": "id",
                    "nullable": False,
                    "partitionKey": False,
                    "primaryKey": True,
                    "type": "Int64",
                },
                {
                    "autoId": False,
                    "clusteringKey": False,
                    "description": "",
                    "id": 101,
                    "name": "vec",
                    "nullable": False,
                    "params": [{"key": "dim", "value": "128"}],
                    "partitionKey": False,
                    "primaryKey": False,
                    "type": "FloatVector",
                },
            ],
        }
        result = self.fmt.format_success(data)
        # type column must be present
        assert "Int64" in result
        assert "FloatVector" in result
        # primaryKey column must be present
        assert "primaryKey" in result
        # name column must be present
        assert "vec" in result

    def test_fields_subtable_shows_params(self):
        data = {
            "collectionName": "test_col",
            "fields": [
                {
                    "autoId": False,
                    "clusteringKey": False,
                    "description": "",
                    "id": 101,
                    "name": "vec",
                    "nullable": False,
                    "params": [{"key": "dim", "value": "128"}],
                    "partitionKey": False,
                    "primaryKey": False,
                    "type": "FloatVector",
                },
            ],
        }
        result = self.fmt.format_success(data)
        assert "dim=128" in result

    def test_few_field_columns_show_all(self):
        """When fields have few keys, all should be shown without priority filtering."""
        data = {
            "collectionName": "test_col",
            "fields": [
                {"name": "id", "type": "Int64", "primaryKey": True},
            ],
        }
        result = self.fmt.format_success(data)
        assert "Int64" in result
        assert "name" in result


class TestTableDimensionColumn:
    """Collection describe should show a dedicated dimension column for vector fields."""

    def setup_method(self):
        self.fmt = TableFormatter()

    def test_vector_field_shows_dimension(self):
        """Vector field with params dim should show the value in a dimension column."""
        data = {
            "collectionName": "test_col",
            "fields": [
                {"name": "vec", "type": "FloatVector", "params": [{"key": "dim", "value": "768"}]},
            ],
        }
        result = self.fmt.format_success(data)
        assert "dimension" in result
        assert "768" in result

    def test_non_vector_field_shows_dash_for_dimension(self):
        """Non-vector fields without dim param should show '-' in the dimension column."""
        data = {
            "collectionName": "test_col",
            "fields": [
                {"name": "id", "type": "Int64", "primaryKey": True},
                {"name": "vec", "type": "FloatVector", "params": [{"key": "dim", "value": "128"}]},
            ],
        }
        result = self.fmt.format_success(data)
        assert "dimension" in result
        assert "128" in result

    def test_field_without_params_shows_dash(self):
        """Field with no params key at all should show '-' in dimension column."""
        data = {
            "collectionName": "test_col",
            "fields": [
                {"name": "id", "type": "Int64"},
            ],
        }
        result = self.fmt.format_success(data)
        assert "dimension" in result


class TestTableDynamicFieldLabel:
    """enableDynamicField should display as dynamicField in table output."""

    def setup_method(self):
        self.fmt = TableFormatter()

    def test_enable_dynamic_field_renamed(self):
        data = {
            "collectionName": "test_col",
            "enableDynamicField": True,
        }
        result = self.fmt.format_success(data)
        assert "dynamicField" in result
        assert "enableDynamicField" not in result


class TestYamlFormatter:
    def setup_method(self):
        self.fmt = YamlFormatter()

    def test_yaml_format_dict(self):
        data = {"id": "abc", "name": "test"}
        result = self.fmt.format_success(data)
        parsed = yaml.safe_load(result)
        assert parsed["id"] == "abc"
        assert parsed["name"] == "test"

    def test_yaml_format_list(self):
        data = [{"id": 1}, {"id": 2}]
        result = self.fmt.format_success(data)
        parsed = yaml.safe_load(result)
        assert len(parsed) == 2
        assert parsed[0]["id"] == 1

    def test_yaml_format_error(self):
        result = self.fmt.format_error(80001, "Invalid API key")
        parsed = yaml.safe_load(result)
        assert parsed["error"]["code"] == 80001
        assert parsed["error"]["message"] == "Invalid API key"

    def test_yaml_format_empty_dict(self):
        result = self.fmt.format_success({})
        parsed = yaml.safe_load(result)
        assert parsed == {}

    def test_yaml_format_nested(self):
        data = {"cluster": {"id": "c1", "tags": ["a", "b"]}}
        result = self.fmt.format_success(data)
        parsed = yaml.safe_load(result)
        assert parsed["cluster"]["tags"] == ["a", "b"]


class TestCsvFormatter:
    def setup_method(self):
        self.fmt = CsvFormatter()

    def test_csv_format_list_of_dicts(self):
        data = [{"id": "c1", "name": "cluster1"}, {"id": "c2", "name": "cluster2"}]
        result = self.fmt.format_success(data)
        lines = result.strip().splitlines()
        assert lines[0] == "id,name"
        assert lines[1] == "c1,cluster1"
        assert lines[2] == "c2,cluster2"

    def test_csv_format_single_dict(self):
        data = {"id": "c1", "name": "cluster1"}
        result = self.fmt.format_success(data)
        lines = result.strip().splitlines()
        assert lines[0] == "id,name"
        assert lines[1] == "c1,cluster1"

    def test_csv_values_with_commas(self):
        data = [{"name": "hello, world", "id": "1"}]
        result = self.fmt.format_success(data)
        lines = result.strip().split("\n")
        # Value with comma should be quoted
        assert '"hello, world"' in lines[1]

    def test_csv_no_header(self):
        fmt = CsvFormatter(no_header=True)
        data = [{"id": "c1", "name": "cluster1"}]
        result = fmt.format_success(data)
        lines = result.strip().split("\n")
        assert len(lines) == 1
        assert "c1" in lines[0]

    def test_csv_format_error(self):
        result = self.fmt.format_error(80001, "Invalid API key")
        assert "80001" in result
        assert "Invalid API key" in result

    def test_csv_empty_list(self):
        result = self.fmt.format_success([])
        assert result == ""

    def test_csv_non_dict_list(self):
        data = ["a", "b", "c"]
        result = self.fmt.format_success(data)
        lines = result.strip().splitlines()
        assert lines[0] == "value"
        assert lines[1] == "a"


class TestTableNoHeader:
    def test_table_no_header(self):
        fmt = TableFormatter(no_header=True)
        data = [{"id": "c1", "name": "cluster1"}]
        result = fmt.format_success(data)
        # Should contain data but not column headers
        assert "c1" in result
        # Column names should not appear as header
        assert "id" not in result.split("\n")[0]
        assert "name" not in result.split("\n")[0]
