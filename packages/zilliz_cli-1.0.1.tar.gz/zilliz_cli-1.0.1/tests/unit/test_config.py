from zilliz_cli.auth.config import ConfigManager


class TestCredentials:
    def test_set_and_get_api_key(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "test-key-123")
        assert mgr.get_credential("api_key") == "test-key-123"

    def test_get_credential_missing(self, config_dir):
        mgr = ConfigManager(config_dir)
        assert mgr.get_credential("api_key") is None

    def test_credentials_file_created(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "test-key")
        assert (config_dir / "credentials").exists()

    def test_credentials_file_permissions(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "test-key")
        mode = (config_dir / "credentials").stat().st_mode & 0o777
        assert mode == 0o600

    def test_overwrite_credential(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "old-key")
        mgr.set_credential("api_key", "new-key")
        assert mgr.get_credential("api_key") == "new-key"


class TestConfig:
    def test_set_and_get_config(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_config("default", "output", "json")
        assert mgr.get_config("default", "output") == "json"

    def test_get_config_default(self, config_dir):
        mgr = ConfigManager(config_dir)
        assert mgr.get_config("default", "output", fallback="table") == "table"

    def test_config_file_created(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_config("default", "output", "json")
        assert (config_dir / "config").exists()


class TestContext:
    def test_set_and_get_context(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_context(cluster_id="in01-xxxx", endpoint="https://in01-xxxx.example.com")
        ctx = mgr.get_context()
        assert ctx["cluster_id"] == "in01-xxxx"
        assert ctx["endpoint"] == "https://in01-xxxx.example.com"
        assert ctx["database"] == "default"

    def test_set_context_with_database(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_context(cluster_id="in01-xxxx", endpoint="https://example.com", database="mydb")
        ctx = mgr.get_context()
        assert ctx["database"] == "mydb"

    def test_update_database_only(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_context(cluster_id="in01-xxxx", endpoint="https://example.com")
        mgr.set_context(database="newdb")
        ctx = mgr.get_context()
        assert ctx["cluster_id"] == "in01-xxxx"
        assert ctx["database"] == "newdb"

    def test_get_context_empty(self, config_dir):
        mgr = ConfigManager(config_dir)
        ctx = mgr.get_context()
        assert ctx["cluster_id"] is None
        assert ctx["endpoint"] is None
        assert ctx["database"] == "default"

    def test_list_all_config(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "test-key")
        mgr.set_config("default", "output", "json")
        mgr.set_context(cluster_id="in01-xxxx", endpoint="https://example.com")
        all_config = mgr.list_all()
        assert "credentials" in all_config
        assert "config" in all_config
        assert all_config["credentials"]["api_key"] == "test-key"
        assert all_config["config"]["output"] == "json"
        assert all_config["config"]["cluster_id"] == "in01-xxxx"
