from unittest.mock import patch

from click.testing import CliRunner

from zilliz_cli.auth.config import ConfigManager
from zilliz_cli.cli import main


class TestLoginNonTTY:
    """BUG-001: zilliz login should fail gracefully in non-TTY environments."""

    def setup_method(self):
        self.runner = CliRunner()

    def test_login_non_tty_without_api_key_flag_shows_error(self, config_dir):
        """Non-TTY stdin without --api-key should show a friendly error."""
        with patch("sys.stdin") as mock_stdin:
            mock_stdin.isatty.return_value = False
            result = self.runner.invoke(main, ["login"], obj={"config_dir": config_dir})
        assert result.exit_code != 0
        assert "interactive terminal" in result.output

    def test_login_non_tty_with_api_key_flag_proceeds(self, config_dir):
        """Non-TTY stdin with --api-key should bypass the TTY check."""
        with (
            patch("sys.stdin") as mock_stdin,
            patch("zilliz_cli.commands.auth._login_with_api_key") as mock_login,
        ):
            mock_stdin.isatty.return_value = False
            result = self.runner.invoke(main, ["login", "--api-key"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        mock_login.assert_called_once()


class TestLoginAlreadyLoggedIn:
    def setup_method(self):
        self.runner = CliRunner()

    def test_login_already_logged_in_decline_reauth(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.save_login_data(user_id="u1", email="test@test.com", name="Test", orgs=[])
        result = self.runner.invoke(main, ["login"], input="n\n", obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "Already logged in" in result.output

    def test_login_already_has_api_key_decline_reauth(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "test-key-123")
        result = self.runner.invoke(main, ["login"], input="n\n", obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "Already logged in with API key" in result.output


class TestLoginWithApiKeyFlag:
    def setup_method(self):
        self.runner = CliRunner()

    def test_login_api_key_success(self, config_dir):
        with patch("zilliz_cli.auth.validation.validate_api_key"):
            result = self.runner.invoke(
                main, ["login", "--api-key"], input="test-api-key-1234\n", obj={"config_dir": config_dir}
            )
        assert result.exit_code == 0
        assert "Successfully configured API key" in result.output
        mgr = ConfigManager(config_dir)
        assert mgr.get_credential("api_key") == "test-api-key-1234"

    def test_login_api_key_empty_aborts(self, config_dir):
        result = self.runner.invoke(main, ["login", "--api-key"], input="\n", obj={"config_dir": config_dir})
        assert result.exit_code != 0


class TestLogout:
    def setup_method(self):
        self.runner = CliRunner()

    def test_logout_when_logged_in(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.save_login_data(user_id="u1", email="test@test.com", name="Test", orgs=[])
        result = self.runner.invoke(main, ["logout"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "Logged out from test@test.com" in result.output

    def test_logout_with_api_key(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "test-key")
        result = self.runner.invoke(main, ["logout"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "Cleared API key" in result.output

    def test_logout_when_not_logged_in(self, config_dir):
        result = self.runner.invoke(main, ["logout"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "Not logged in" in result.output


class TestAuthStatus:
    def setup_method(self):
        self.runner = CliRunner()

    def test_status_not_logged_in(self, config_dir):
        result = self.runner.invoke(main, ["auth", "status"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "Not logged in" in result.output

    def test_status_logged_in(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.save_login_data(user_id="u1", email="test@test.com", name="Test User", orgs=[])
        result = self.runner.invoke(main, ["auth", "status"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "Logged in" in result.output
        assert "test@test.com" in result.output

    def test_status_api_key_only(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "test-key-abcd1234")
        result = self.runner.invoke(main, ["auth", "status"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "API Key" in result.output
