import pytest

from zilliz_cli.core.query_filter import apply_query


class TestQueryFilter:
    def test_simple_key_extraction(self):
        data = {"clusterId": "c1", "name": "test"}
        result = apply_query(data, "clusterId")
        assert result == "c1"

    def test_array_projection(self):
        data = [{"clusterId": "c1"}, {"clusterId": "c2"}]
        result = apply_query(data, "[].clusterId")
        assert result == ["c1", "c2"]

    def test_filter_expression(self):
        data = [
            {"name": "a", "status": "RUNNING"},
            {"name": "b", "status": "STOPPED"},
        ]
        result = apply_query(data, "[?status=='RUNNING']")
        assert len(result) == 1
        assert result[0]["name"] == "a"

    def test_invalid_expression(self):
        with pytest.raises(ValueError, match="Invalid"):
            apply_query({"a": 1}, "[[invalid")

    def test_no_query_passthrough(self):
        data = {"a": 1}
        result = apply_query(data, None)
        assert result == data

    def test_nested_key(self):
        data = {"cluster": {"id": "c1", "status": "RUNNING"}}
        result = apply_query(data, "cluster.id")
        assert result == "c1"

    def test_empty_result(self):
        data = [{"status": "STOPPED"}]
        result = apply_query(data, "[?status=='RUNNING']")
        assert result == []
