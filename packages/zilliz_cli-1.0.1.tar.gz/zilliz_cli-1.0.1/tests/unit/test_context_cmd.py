from unittest.mock import patch

from click.testing import CliRunner

from zilliz_cli.auth.config import ConfigManager
from zilliz_cli.cli import main


class TestContextSet:
    def setup_method(self):
        self.runner = CliRunner()

    def test_set_cluster(self, config_dir):
        result = self.runner.invoke(
            main,
            ["context", "set", "--cluster-id", "in01-xxxx", "--endpoint", "https://in01-xxxx.example.com"],
            obj={"config_dir": config_dir},
        )
        assert result.exit_code == 0
        assert "in01-xxxx" in result.output
        mgr = ConfigManager(config_dir)
        ctx = mgr.get_context()
        assert ctx["cluster_id"] == "in01-xxxx"
        assert ctx["endpoint"] == "https://in01-xxxx.example.com"
        assert ctx["database"] == "default"

    def test_set_with_database(self, config_dir):
        result = self.runner.invoke(
            main,
            ["context", "set", "--cluster-id", "in01-xxxx", "--endpoint", "https://example.com", "--database", "mydb"],
            obj={"config_dir": config_dir},
        )
        assert result.exit_code == 0
        mgr = ConfigManager(config_dir)
        assert mgr.get_context()["database"] == "mydb"

    def test_set_database_only(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_context(cluster_id="in01-xxxx", endpoint="https://example.com")
        result = self.runner.invoke(main, ["context", "set", "--database", "newdb"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        ctx = mgr.get_context()
        assert ctx["cluster_id"] == "in01-xxxx"
        assert ctx["database"] == "newdb"

    def test_set_requires_cluster_or_database(self, config_dir):
        result = self.runner.invoke(main, ["context", "set"], obj={"config_dir": config_dir})
        assert result.exit_code != 0

    def test_set_cluster_without_endpoint_error(self, config_dir):
        """Without --endpoint and without API key, auto-resolve fails with credential error."""
        result = self.runner.invoke(
            main, ["context", "set", "--cluster-id", "in01-xxxx"], obj={"config_dir": config_dir}
        )
        assert result.exit_code != 0


class TestContextCurrent:
    def setup_method(self):
        self.runner = CliRunner()

    def test_current_with_context(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_context(cluster_id="in01-xxxx", endpoint="https://example.com", database="mydb")
        result = self.runner.invoke(main, ["context", "current"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "in01-xxxx" in result.output
        assert "mydb" in result.output

    def test_current_no_context(self, config_dir):
        result = self.runner.invoke(main, ["context", "current"], obj={"config_dir": config_dir})
        assert result.exit_code == 1
        assert "no context" in result.output.lower() or "not set" in result.output.lower()

    def test_current_no_context_json_output(self, config_dir):
        result = self.runner.invoke(main, ["context", "current", "--output", "json"], obj={"config_dir": config_dir})
        assert result.exit_code == 1
        import json

        data = json.loads(result.output)
        assert "error" in data
        assert data["error"]["message"].startswith("No context set")

    def test_current_json_output(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_context(cluster_id="in01-xxxx", endpoint="https://example.com")
        result = self.runner.invoke(main, ["context", "current", "--output", "json"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert '"cluster_id"' in result.output


class TestContextSetAutoResolve:
    def setup_method(self):
        self.runner = CliRunner()

    def test_auto_resolve_endpoint(self, config_dir):
        with patch("zilliz_cli.commands.context.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "clusterId": "in01-xxxx",
                "connectAddress": "https://in01-xxxx.serverless.gcp-us-west1.cloud.zilliz.com",
            }

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "context", "set", "--cluster-id", "in01-xxxx"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            assert "in01-xxxx" in result.output

            mgr = ConfigManager(config_dir)
            ctx = mgr.get_context()
            assert ctx["cluster_id"] == "in01-xxxx"
            assert "in01-xxxx" in ctx["endpoint"]

    def test_manual_endpoint_overrides(self, config_dir):
        """--endpoint flag skips API call."""
        result = self.runner.invoke(
            main,
            ["context", "set", "--cluster-id", "in01-xxxx", "--endpoint", "https://manual.example.com"],
            obj={"config_dir": config_dir},
        )

        assert result.exit_code == 0
        mgr = ConfigManager(config_dir)
        ctx = mgr.get_context()
        assert ctx["endpoint"] == "https://manual.example.com"

    def test_auto_resolve_fails_gracefully(self, config_dir):
        from zilliz_cli.core.exceptions import APIError

        with patch("zilliz_cli.commands.context.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.side_effect = APIError(80001, "Invalid API key")

            result = self.runner.invoke(
                main,
                ["--api-key", "bad-key", "context", "set", "--cluster-id", "in01-xxxx"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code != 0
            assert "API" in result.output or "error" in result.output.lower()
