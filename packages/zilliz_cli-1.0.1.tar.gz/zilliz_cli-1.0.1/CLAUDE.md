# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Zilliz CLI (`zilliz-cli`) is a Python CLI tool for managing Zilliz Cloud clusters and performing Milvus vector database operations. It uses a **model-driven architecture** where most commands are auto-generated from JSON model definitions rather than hand-written.

## Development Setup

```bash
# Install with dev dependencies (uses uv for package management)
pip install -e ".[dev]"
```

Requires Python 3.10+. Key dependencies: click (CLI framework), httpx (HTTP client), rich (output formatting), questionary (interactive prompts).

## Common Commands

```bash
# Run all unit tests
pytest tests/unit/

# Run a specific test file
pytest tests/unit/test_cluster_cmd.py

# Run a specific test by name
pytest tests/unit/test_cluster_cmd.py -k "test_name"

# Run E2E tests (requires ZILLIZ_API_KEY)
ZILLIZ_API_KEY=your-key pytest -m e2e

# Lint
ruff check src/ tests/

# Type check
mypy src/
```

## Architecture

### Model-Driven Command Generation

The core design pattern: CLI commands are generated from JSON model files, not hand-coded.

1. **JSON Models** (`src/zilliz_cli/builtin_models/`): Two model files define all API operations:
   - `control-plane.json` - Cloud management APIs (clusters, projects, backups, billing)
   - `data-plane.json` - Milvus data APIs (collections, vectors, indexes, partitions, users, roles, aliases, databases)

2. **Model Layer** (`core/model.py`): Dataclasses (`CliModel`, `Resource`, `Operation`, `Param`) that represent the parsed JSON models.

3. **ModelLoader** (`core/model_loader.py`): Loads JSON models from the builtin_models directory.

4. **CommandFactory** (`core/command_factory.py`): Reads the model and auto-generates Click command groups, subcommands, options, and argument handling. Handles parameter validation, pagination, body transforms, and output formatting.

5. **APICaller** (`core/api_caller.py`): HTTP client that calls Zilliz Cloud APIs. Handles the `{"code": N, "data": ...}` response envelope, path parameter substitution, and error messages.

### Control Plane vs Data Plane

- **Control plane**: Cloud management (clusters, projects, billing). Uses a global endpoint (`api.cloud.zilliz.com`). Resolved via `_resolve_control_plane_endpoint`.
- **Data plane**: Milvus operations (collections, vectors). Uses a per-cluster endpoint resolved from the user's context (`zilliz context set --cluster-id ...`). Resolved via `_resolve_data_plane_endpoint`.

### Hand-Written vs Model-Driven Commands

Most commands are model-driven, but a few are hand-written in `commands/`:
- `configure.py`, `context.py`, `version.py`, `completion.py`, `auth.py` - Always hand-written
- `cluster.py` (create_cluster), `billing.py` (usage, invoices) - Hand-written commands injected into model-driven groups

The injection happens in `cli.py` after model-driven groups are created.

### Output Formatting

`formatter/` provides pluggable output formats (json, table, text) controlled by `--output` flag. The `get_formatter()` factory selects the right formatter.

### Auth & Config

- `auth/config.py` - Config file management (`~/.zilliz/config`, `~/.zilliz/credentials`)
- `auth/credentials.py` - API key resolution chain: CLI flag > env var > config file
- `auth/oauth.py` - OAuth/device flow login
- `auth/validation.py` - API key validation

## Testing Patterns

- **Unit tests** (`tests/unit/`): Use `click.testing.CliRunner` and `pytest-httpx` to mock HTTP calls. Config isolation via `tmp_path` fixture.
- **E2E tests** (`tests/e2e/`): Run CLI as subprocess against real APIs. Marked with `@pytest.mark.e2e`.
- **Acceptance tests** (`tests/acceptance/`): Full lifecycle tests. Marked with `@pytest.mark.acceptance`. Phased: phase1 (local), phase2 (cloud resources), phase3 (data operations).

## Adding a New API Command

For most new commands, add the operation to the appropriate JSON model file (`control-plane.json` or `data-plane.json`) rather than writing Python code. The CommandFactory will auto-generate the CLI command. Only write Python for commands that need custom logic (interactive prompts, multi-step workflows, special output formatting).
