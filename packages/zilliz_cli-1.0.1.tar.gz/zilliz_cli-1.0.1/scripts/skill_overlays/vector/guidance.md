## Filter Expression Syntax

Common filter patterns:

| Expression | Example |
|---|---|
| Comparison | `age > 20` |
| Equality | `status == "active"` |
| IN list | `id in [1, 2, 3]` |
| AND/OR | `age > 20 and status == "active"` |
| String match | `text like "hello%"` |
| Array contains | `tags array_contains "ml"` |

## Guidance

- The `--data` parameter accepts a JSON array of vectors. Each vector is an array of floats.
- Before searching, inspect the collection schema with `zilliz collection describe` to understand field names and vector dimensions.
- The collection must be loaded before search/query operations.
- For search, the `--data` value must match the collection's vector dimension exactly.
- Use `--anns-field` to specify which vector field to search on when the collection has multiple vector fields.
- When the user provides a text query and wants semantic search, explain that they need to convert text to vectors first (using an embedding model) before passing to `--data`.
- For large insert operations, suggest writing data to a JSON file first, then using `zilliz vector insert --collection <name> --data "$(cat data.json)"`.
- Always show `--output-fields` when the user wants specific fields in results.
- Or use `--body` for complex hybrid search configurations.
