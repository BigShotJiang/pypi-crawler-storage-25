## Guidance

- Every collection has a default `_default` partition.
- Partitions allow organizing data for more targeted searches.
- A partition must be loaded before it can be searched.
- Before dropping a partition, confirm with the user -- all data in it will be deleted.
- Use partition stats to check row counts per partition.
- For filter expression syntax used in vector operations on partitions, see the vector skill.
