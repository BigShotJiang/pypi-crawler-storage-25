## Guidance

- Billing commands require OAuth login, not API Key authentication.
- When the user asks about costs or spending, use `billing usage` with an appropriate time range.
- The `bind-card` command handles sensitive card data -- always instruct the user to run it in their own terminal, never inside Claude Code.
