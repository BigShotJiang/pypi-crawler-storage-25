### Query Usage

```bash
# Last N days
zilliz billing usage --last 7d

# Current month
zilliz billing usage --month this

# Last month
zilliz billing usage --month last

# Specific month
zilliz billing usage --month 2026-01

# Custom date range
zilliz billing usage --start 2026-01-01 --end 2026-01-31
```

### List Invoices

```bash
# List all invoices (paginated)
zilliz billing invoices

# Fetch all pages
zilliz billing invoices --all

# Paginate manually
zilliz billing invoices --page-size 10 --page 1
```

### View Invoice Details

```bash
zilliz billing invoices --invoice-id inv-xxxxxxxxxxxx
```
