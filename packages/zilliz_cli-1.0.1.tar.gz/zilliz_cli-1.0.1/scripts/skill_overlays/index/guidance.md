## Index Types

Common index types:
- `AUTOINDEX` -- recommended, automatically selects the best index
- `IVF_FLAT`, `IVF_SQ8`, `HNSW` -- manual selection for advanced users

Common metric types:
- `COSINE` -- cosine similarity (default)
- `L2` -- Euclidean distance
- `IP` -- inner product

## Guidance

- On Zilliz Cloud, `AUTOINDEX` is recommended for most use cases.
- An index is required before loading a collection for search.
- Before creating an index, check the collection schema to identify vector fields.
- After creating an index, remind the user to load the collection.
