#!/usr/bin/env python3
"""Generate zilliz-plugin SKILL.md files from zilliz-cli JSON model definitions.

This script reads the JSON model files (control-plane.json, data-plane.json),
combines them with hand-written guidance overlays, and generates the SKILL.md
files for the zilliz-plugin project.

Usage:
    # Preview to stdout (dry run)
    python scripts/generate_plugin_skills.py

    # Write to zilliz-plugin directory
    python scripts/generate_plugin_skills.py --output /path/to/zilliz-plugin/skills

    # Check if generated output matches existing files (CI mode)
    python scripts/generate_plugin_skills.py --check /path/to/zilliz-plugin/skills
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

import yaml

SCRIPT_DIR = Path(__file__).resolve().parent
MODELS_DIR = SCRIPT_DIR.parent / "src" / "zilliz_cli" / "builtin_models"
OVERLAYS_DIR = SCRIPT_DIR / "skill_overlays"
CONFIG_PATH = SCRIPT_DIR / "skill_config.yaml"


def load_models() -> dict[str, dict]:
    """Load and return both JSON model files keyed by plane name."""
    models = {}
    for plane in ("control", "data"):
        filename = f"{plane}-plane.json"
        path = MODELS_DIR / filename
        with open(path) as f:
            models[plane] = json.load(f)
    return models


def load_config() -> dict:
    """Load the skill configuration YAML."""
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)


def load_overlay(skill_name: str, filename: str) -> str | None:
    """Load an overlay file if it exists, return its content or None."""
    path = OVERLAYS_DIR / skill_name / filename
    if path.exists():
        return path.read_text().rstrip("\n")
    return None


def _singularize(name: str) -> str:
    """Rough singularize: 'clusters' -> 'Cluster', 'aliases' -> 'Alias'."""
    word = name.replace("-", " ").title()
    # Already singular common cases
    if word.lower() in ("alias", "index", "status", "database", "bus"):
        return word
    if word.endswith("ies"):
        return word[:-3] + "y"
    if word.endswith("ses"):
        return word[:-2]
    if word.endswith("s") and not word.endswith("ss"):
        return word[:-1]
    return word


def _pluralize_title(name: str) -> str:
    """'cluster' -> 'Clusters', 'alias' -> 'Aliases', 'index' -> 'Indexes'."""
    word = name.replace("-", " ").title()
    if word.endswith("y") and word[-2:] not in ("ay", "ey", "oy", "uy"):
        return word[:-1] + "ies"
    if word.endswith(("s", "sh", "ch", "x")):
        return word + "es"
    return word + "s"


def _article(word: str) -> str:
    """Return 'an' if word starts with a vowel sound, else 'a'.

    Handles common exceptions: 'User' starts with consonant /juː/ sound,
    while 'Alias' and 'Index' start with vowel sounds.
    """
    lower = word.lower()
    # Words starting with 'u' that have consonant /juː/ sound
    if lower.startswith(("user", "uni", "use")):
        return "a"
    return "an" if lower[0:1] in "aeiou" else "a"


# Maps op_name -> title template.
# {R} = singular resource, {Rs} = plural, {a} = "a"/"an" article.
_TITLE_TEMPLATES: dict[str, str] = {
    "list": "List {Rs}",
    "describe": "Describe {a} {R}",
    "create": "Create {a} {R}",
    "delete": "Delete {a} {R}",
    "drop": "Drop {a} {R}",
    "modify": "Modify {a} {R}",
    "suspend": "Suspend {a} {R}",
    "resume": "Resume {a} {R}",
    "load": "Load {a} {R}",
    "release": "Release {a} {R}",
    "rename": "Rename {a} {R}",
    "has": "Check if {a} {R} Exists",
    "flush": "Flush {a} {R}",
    "compact": "Compact {a} {R}",
    "insert": "Insert Vectors",
    "upsert": "Upsert Vectors",
    "search": "Vector Search",
    "hybrid-search": "Hybrid Search",
    "query": "Query by Filter",
    "get": "Get by ID",
    "start": "Start an Import Job",
    "status": "Check Import Status",
    "export": "Export a Backup",
    "providers": "List Cloud Providers",
    "regions": "List Regions",
    "alter": "Alter an Alias",
    "bind-card": "Bind a Credit Card",
    "get-load-state": "Get Load State",
    "get-stats": "Get Statistics",
    "restore-cluster": "Restore to a New Cluster",
    "restore-collection": "Restore Specific Collections",
    "describe-policy": "Describe Backup Policy",
    "update-policy": "Update Backup Policy",
    "update-password": "Update Password",
    "grant-role": "Grant a Role to a User",
    "revoke-role": "Revoke a Role from a User",
    "grant-privilege": "Grant a Privilege",
    "revoke-privilege": "Revoke a Privilege",
    "upgrade": "Upgrade a Project",
}


def format_operation_title(op_name: str, description: str, resource_name: str) -> str:
    """Build a concise, readable section title.

    Tries _TITLE_TEMPLATES first, then falls back to the operation
    description (with parenthetical notes stripped).
    """
    singular = _singularize(resource_name)
    plural = _pluralize_title(resource_name)

    if op_name in _TITLE_TEMPLATES:
        return _TITLE_TEMPLATES[op_name].format(
            R=singular, Rs=plural, a=_article(singular)
        )

    # Fallback: clean up description
    desc = description.rstrip(".").strip()
    if desc:
        desc_clean = re.sub(r"\s*\(.*?\)\s*$", "", desc).strip()
        if desc_clean:
            return desc_clean

    # Last resort: title-case the operation name
    return op_name.replace("-", " ").title()


# Concrete JSON examples for array/object params, keyed by
# (resource, operation, paramName).  Falls back to (*, *, paramName).
_JSON_PARAM_EXAMPLES: dict[tuple[str, str, str], str] = {
    # vector insert / upsert  --data
    ("vector", "insert", "data"):
        """'[{"id": 1, "vector": [0.1, 0.2, ...], "text": "hello"}]'""",
    ("vector", "upsert", "data"):
        """'[{"id": 1, "vector": [0.1, 0.2, ...], "text": "hello"}]'""",
    # vector search  --data  (query vectors, not entities)
    ("vector", "search", "data"):
        """'[[0.1, 0.2, 0.3, ...]]'""",
    # hybrid search
    ("vector", "hybrid-search", "search"):
        ("""'[{"data": [[0.1, ...]], "annsField": "dense_vector", "limit": 10},"""
         """ {"data": [["search text"]], "annsField": "sparse_vector", "limit": 10}]'"""),
    ("vector", "hybrid-search", "rerank"):
        """'{"strategy": "rrf", "params": {"k": 60}}'""",
    # vector get  --id
    ("vector", "get", "id"):
        "'[1, 2, 3]'",
    # partition load / release  --names
    ("partition", "load", "partitionNames"):
        """'["partition1", "partition2"]'""",
    ("partition", "release", "partitionNames"):
        """'["partition1", "partition2"]'""",
    # wildcard: outputFields used in many vector operations
    ("*", "*", "outputFields"):
        """'["field1", "field2"]'""",
}

# Concrete --body examples keyed by (resource, operation).
_BODY_EXAMPLES: dict[tuple[str, str], str] = {
    ("collection", "create"):
        """--body '{"schema": {"fields": ["""
        """{"fieldName": "id", "dataType": "Int64", "isPrimary": true}, """
        """{"fieldName": "vector", "dataType": "FloatVector", """
        """"elementTypeParams": {"dim": "768"}}]}}'""",
    ("index", "create"):
        ("""--body '{"indexParams": ["""
         """{"fieldName": "vector", "indexType": "AUTOINDEX", "metricType": "COSINE"}"""
         """]}'"""),
    ("import", "start"):
        """--body '{"files": [["s3://bucket/path/data.parquet"]]}'""",
    ("cluster", "modify"):
        """--body '{"cuSize": 2, "replica": 2}'""",
    ("backup", "restore-collection"):
        """--body '{"collections": [{"source": "col1", "target": "col1_restored"}]}'""",
    ("database", "create"):
        """--body '{"properties": {}}'""",
}


def _build_placeholder(
    param: dict,
    resource_name: str = "",
    op_name: str = "",
) -> str:
    """Build a placeholder string for a parameter value.

    For array/object params, looks up a concrete JSON example first.
    For scalar params, builds a descriptive <placeholder>.
    """
    ptype = param.get("type", "string")
    pname = param.get("name", "")

    if ptype == "boolean":
        return "<true|false>"

    if param.get("choices"):
        return "<" + "|".join(str(c) for c in param["choices"]) + ">"

    # Array / object: look up a concrete JSON example
    if ptype in ("array", "object"):
        example = (
            _JSON_PARAM_EXAMPLES.get((resource_name, op_name, pname))
            or _JSON_PARAM_EXAMPLES.get(("*", "*", pname))
        )
        if example:
            return example
        return "'[...]'" if ptype == "array" else "'{...}'"

    # Build from description: "cluster ID (e.g. in01-xxx)" -> "cluster-id"
    desc = param.get("description", "")
    if desc:
        # Strip parenthetical notes and "e.g." clauses
        desc_clean = re.sub(r"\s*\(.*?\)", "", desc)
        desc_clean = re.sub(r"\s*e\.g\..*$", "", desc_clean, flags=re.IGNORECASE)
        desc_clean = desc_clean.strip()

        # If description is a short label (no pipes, no commas, <= 30 chars),
        # convert to kebab-case placeholder
        if (
            desc_clean
            and "|" not in desc_clean
            and "," not in desc_clean
            and len(desc_clean) <= 30
        ):
            placeholder = re.sub(r"\s+", "-", desc_clean.lower())
            placeholder = re.sub(r"[^a-z0-9*-]", "", placeholder)
            if placeholder:
                return f"<{placeholder}>"

    # Fallback: derive from cli flag name
    cli_flag = param.get("cli", f"--{param['name']}")
    return f"<{cli_flag.lstrip('-')}>"


def _build_flag(
    param: dict,
    resource_name: str = "",
    op_name: str = "",
) -> str:
    """Build 'flag placeholder' pair for a single param."""
    cli_flag = param.get("cli", f"--{param['name']}")
    placeholder = _build_placeholder(param, resource_name, op_name)
    return f"{cli_flag} {placeholder}"


# Maximum number of flags on a single line before switching to multiline.
_MULTILINE_THRESHOLD = 2


def _format_command(prefix: str, flags: list[str]) -> str:
    """Format a CLI command, wrapping to multiline when flags > threshold.

    Single-line:  zilliz cluster describe --cluster-id <cluster-id>
    Multi-line:
        zilliz role grant-privilege \\
          --role <role-name> \\
          --object-type <Collection|Global|Database> \\
          --object-name <name-or-*> \\
          --privilege <privilege-name>
    """
    if len(flags) <= _MULTILINE_THRESHOLD:
        parts = [prefix] + flags
        return " ".join(parts)

    result_lines = [f"{prefix} \\"]
    for i, flag in enumerate(flags):
        is_last = i == len(flags) - 1
        result_lines.append(f"  {flag}" if is_last else f"  {flag} \\")
    return "\n".join(result_lines)


def _is_required(param: dict) -> bool:
    """Return True if a param is required (or effectively required)."""
    return bool(
        param.get("required")
        or param.get("requiredUnless")
    )


def _is_pagination(param: dict) -> bool:
    """Return True if a param is a pagination control param."""
    return param.get("name", "") in ("pageSize", "currentPage")


def build_command_block(resource_name: str, op_name: str, operation: dict) -> str:
    """Build markdown for a single operation's command block."""
    lines: list[str] = []
    description = operation.get("description", "")
    title = format_operation_title(op_name, description, resource_name)

    lines.append(f"### {title}")
    lines.append("")

    params = operation.get("params", [])
    has_body_param = bool(operation.get("bodyParam"))
    has_pagination = bool(operation.get("pagination"))

    # Separate required vs optional params (skip pagination params)
    required_params = [p for p in params if _is_required(p) and not _is_pagination(p)]
    optional_params = [
        p for p in params
        if not _is_required(p) and not _is_pagination(p)
    ]

    # Build the primary command
    prefix = f"zilliz {resource_name} {op_name}"
    required_flags = [_build_flag(p, resource_name, op_name) for p in required_params]
    cmd = _format_command(prefix, required_flags)

    lines.append("```bash")
    lines.append(cmd)

    # Show optional params as comments
    if optional_params:
        opt_strs = [_build_flag(p, resource_name, op_name) for p in optional_params]
        if len(opt_strs) <= 2:
            lines.append(f"# Optional: {', '.join(opt_strs)}")
        else:
            lines.append("# Optional:")
            for opt in opt_strs:
                lines.append(f"#   {opt}")

    # Show --body example when operation supports raw JSON body
    if has_body_param:
        body_example = _BODY_EXAMPLES.get((resource_name, op_name))
        if body_example:
            lines.append(f"# Or use raw JSON: {body_example}")
        else:
            body_flag = operation["bodyParam"]
            lines.append(f"# Or use raw JSON: {body_flag} '{{...}}'")

    # Show pagination hint
    if has_pagination:
        lines.append("# Pagination: --page-size <n> --page <n>")
        lines.append("# Fetch all pages: --all")

    lines.append("```")

    # Note for dedicated-only operations
    if operation.get("dedicatedOnly"):
        lines.append("")
        lines.append(f"*{description}*")

    return "\n".join(lines)


def build_resource_commands(
    resource_name: str,
    resource_data: dict,
    section_title: str | None = None,
) -> str:
    """Build the full commands reference for one resource."""
    lines: list[str] = []

    if section_title:
        lines.append(f"### {section_title}")
        lines.append("")

    operations = resource_data.get("operations", {})
    for op_name, operation in operations.items():
        block = build_command_block(resource_name, op_name, operation)
        # If we have a section_title, demote ### to #### within the block
        if section_title:
            block = block.replace("### ", "#### ", 1)
        lines.append(block)
        lines.append("")

    return "\n".join(lines).rstrip("\n")


def generate_skill(skill_name: str, skill_config: dict, models: dict) -> str:
    """Generate the full SKILL.md content for a skill."""

    # Hand-written skills: return the overlay SKILL.md as-is
    if skill_config.get("hand_written"):
        content = load_overlay(skill_name, "SKILL.md")
        if content:
            return content + "\n"
        raise FileNotFoundError(
            f"Hand-written skill '{skill_name}' missing "
            f"overlay at {OVERLAYS_DIR / skill_name / 'SKILL.md'}"
        )

    parts: list[str] = []

    # --- Frontmatter ---
    description = skill_config["description"]
    parts.append("---")
    parts.append(f"name: {skill_name}")
    parts.append(f"description: {description}")
    parts.append("---")
    parts.append("")

    # --- Prerequisites ---
    prerequisites = skill_config.get("prerequisites", "").strip()
    if prerequisites:
        parts.append("## Prerequisites")
        parts.append("")
        parts.append(prerequisites)
        parts.append("")

    # --- Commands Reference ---
    parts.append("## Commands Reference")
    parts.append("")

    # Optional header text
    header = skill_config.get("header")
    if header:
        parts.append(header.strip())
        parts.append("")

    # Extra hand-written commands that go BEFORE auto-generated ones
    extra_commands = load_overlay(skill_name, "extra_commands.md")
    if extra_commands:
        parts.append(extra_commands)
        parts.append("")

    # Auto-generate commands from JSON model resources
    resources = skill_config.get("resources", [])
    for res_entry in resources:
        plane = res_entry["plane"]
        resource_key = res_entry["resource"]
        section_title = res_entry.get("section_title")

        model = models.get(plane)
        if not model:
            print(
                f"Warning: plane '{plane}' not found for "
                f"skill '{skill_name}'",
                file=sys.stderr,
            )
            continue

        resource_data = model.get("resources", {}).get(resource_key)
        if not resource_data:
            print(
                f"Warning: resource '{resource_key}' not found in "
                f"{plane}-plane.json for skill '{skill_name}'",
                file=sys.stderr,
            )
            continue

        commands_md = build_resource_commands(
            resource_key, resource_data, section_title
        )
        parts.append(commands_md)
        parts.append("")

    # --- Guidance and extra sections from overlay ---
    guidance = load_overlay(skill_name, "guidance.md")
    if guidance:
        parts.append(guidance)
        parts.append("")

    return "\n".join(parts).rstrip("\n") + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate zilliz-plugin SKILL.md files from JSON models."
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Output directory (zilliz-plugin/skills/). "
        "If omitted, prints to stdout.",
    )
    parser.add_argument(
        "--check",
        type=Path,
        help="Check mode: compare generated output against existing files "
        "in the given directory. Exit 1 if any differ.",
    )
    parser.add_argument(
        "--skill",
        type=str,
        help="Generate only a specific skill (by name).",
    )
    args = parser.parse_args()

    config = load_config()
    models = load_models()
    skills = config.get("skills", {})

    if args.skill:
        if args.skill not in skills:
            print(f"Error: skill '{args.skill}' not found in config", file=sys.stderr)
            sys.exit(1)
        skills = {args.skill: skills[args.skill]}

    drift_found = False

    for skill_name, skill_config in skills.items():
        content = generate_skill(skill_name, skill_config, models)

        if args.check:
            existing_path = args.check / skill_name / "SKILL.md"
            if not existing_path.exists():
                print(f"MISSING: {existing_path}")
                drift_found = True
                continue
            existing = existing_path.read_text()
            if existing != content:
                print(f"DRIFT:   {existing_path}")
                drift_found = True
            else:
                print(f"OK:      {existing_path}")

        elif args.output:
            out_dir = args.output / skill_name
            out_dir.mkdir(parents=True, exist_ok=True)
            out_path = out_dir / "SKILL.md"
            out_path.write_text(content)
            print(f"Generated: {out_path}")

        else:
            # Dry run: print to stdout
            separator = "=" * 60
            print(f"{separator}")
            print(f"# skills/{skill_name}/SKILL.md")
            print(f"{separator}")
            print(content)
            print()

    if args.check and drift_found:
        print(
            "\nDrift detected! Run the generator to update plugin skills.",
            file=sys.stderr,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
