# Changelog

All notable changes to zilliz-cli will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [1.0.1] - 2026-04-01

### Fixed

- Replace interactive backup-type prompt with explicit `--backup-type` flag for scriptability
- Fix backup list `--creation-method` choices to use correct uppercase values (`MANUAL`, `AUTO`)

### Improved

- Add dimension column to collection describe field table for vector fields
- Rename `enableDynamicField` display label to `dynamicField` in table output

## [1.0.0] - 2026-03-26

First stable release of Zilliz CLI -- the official command-line tool for Zilliz Cloud and Milvus.

### Highlights

- Full Zilliz Cloud control plane coverage: cluster, project, backup, import, volume, and billing management
- Full Milvus data plane coverage: collection, vector, index, partition, database, user, role, and alias operations
- Browser-based OAuth login and API key authentication
- Interactive prompts for guided workflows (cluster create, alert create, metrics query, etc.)
- Multiple output formats: table, JSON, text, YAML, CSV
- Output filtering with `--query` (JMESPath expressions)
- Shell completion for Bash, Zsh, and Fish
- File input support (`file://path.json`) for complex payloads

### Cloud Management

- **Cluster**: list, describe, create (interactive), modify (scale CU/replicas), suspend, resume, delete, providers, regions
- **Cluster Metrics**: query performance metrics (QPS, latency, storage, etc.) with interactive metric selection
- **Project**: list, describe, create, upgrade
- **Backup**: list, describe, create, delete, export, restore-cluster, restore-collection, describe-policy, update-policy
- **Import**: start, list, status
- **Volume**: list, create, delete
- **Billing**: usage query with flexible time ranges, invoice listing, credit card binding
- **Job**: describe async job status with optional `--wait` polling
- **Alert**: create, list, update, delete, enable, disable alert rules with multiple notification channels (email, Slack, webhook, PagerDuty, OpsGenie, WeCom, DingTalk, Lark)

### Data Operations

- **Collection**: list, describe, create (quick + full schema), drop, rename, load, release, get-load-state, get-stats, has, flush, compact
- **Vector**: search, hybrid-search (multi-vector with reranking), query, get, insert, upsert, delete
- **Index**: list, describe, create, drop
- **Partition**: list, create, drop, has, get-stats, load, release
- **Database**: list, describe, create, drop
- **User**: list, describe, create, drop, update-password, grant-role, revoke-role
- **Role**: list, describe, create, drop, grant-privilege, revoke-privilege
- **Alias**: list, describe, create, alter, drop

### Authentication & Configuration

- OAuth 2.0 Device Code Flow browser login
- API key authentication (CLI flag, environment variable, or config file)
- Organization switching for multi-org users
- Cluster context management with automatic endpoint resolution
- Credential resolution chain: `--api-key` flag > `ZILLIZ_API_KEY` env var > config file

### Developer Experience

- Model-driven architecture: most commands auto-generated from JSON API definitions
- Pagination support with `--all` flag for automatic page traversal
- `--no-header` option for table output (useful for scripting)
- Retry with error hints on API failures
- Context-aware data plane endpoint resolution
