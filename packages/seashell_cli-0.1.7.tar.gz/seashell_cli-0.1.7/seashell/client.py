"""HTTP client for the Seashell API."""

import json
import sys
import threading
import time

import requests


class SeashellClient(object):
    def __init__(self, server_url, api_key):
        self.server = server_url.rstrip("/")
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers["X-API-Key"] = api_key

    def query(self, query_text):
        """Send a GQL query and return the result dict."""
        resp = self.session.post(
            self.server + "/query",
            json={"query": query_text},
            timeout=600,
        )
        if resp.status_code == 403:
            raise PermissionError(resp.json().get("detail", "Access denied"))
        if resp.status_code == 429:
            retry = resp.headers.get("Retry-After", "60")
            raise RuntimeError("Rate limited. Try again in %s seconds." % retry)
        if resp.status_code != 200:
            detail = ""
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise RuntimeError("Query failed (%d): %s" % (resp.status_code, detail))
        return resp.json()

    def health(self):
        """Check server health. Returns dict with status, patient_count, etc."""
        try:
            resp = self.session.get(self.server + "/health", timeout=10)
            if resp.status_code == 200:
                return resp.json()
        except Exception:
            pass
        return None

    def wake(self):
        """Pre-warm the institution's EC2 instance. Fire-and-forget."""
        def _wake():
            try:
                self.session.post(self.server + "/wake", timeout=5)
            except Exception:
                pass
        t = threading.Thread(target=_wake, daemon=True)
        t.start()

    def poll_job(self, endpoint, job_id, callback=None):
        """Poll an async job (export/upload) until completion.

        Args:
            endpoint: "export" or "ingest_gql"
            job_id: the job ID returned by the initial request
            callback: optional function called with job dict on each poll
        """
        url = "%s/%s/%s" % (self.server, endpoint, job_id)
        while True:
            try:
                resp = self.session.get(url, timeout=30)
                if resp.status_code != 200:
                    return {"status": "error", "detail": resp.text}
                job = resp.json()
                if callback:
                    callback(job)
                status = job.get("status", "")
                if status in ("complete", "complete_with_errors", "error", "failed"):
                    return job
            except Exception as e:
                sys.stderr.write("Poll error: %s\n" % str(e))
            time.sleep(3)
