"""Seashell CLI — interactive genomic query tool."""

import getpass
import json
import sys
import threading

from seashell.client import SeashellClient
from seashell.config import load_config, save_config, clear_config, DEFAULT_SERVER
from seashell.display import display_result, print_job_progress, infer_action, show_more
from seashell.help import HELP_TEXT, welcome_banner, CYAN, BOLD, DIM, RESET, WHITE, BLUE


def _prompt_login():
    """Interactive login flow. Returns (client, config) or exits on failure."""
    print(welcome_banner())

    config = load_config()
    server = config.get("server", DEFAULT_SERVER)

    # Check for cached credentials
    if config.get("api_key") and config.get("email"):
        print(DIM + "  Reconnecting as %s (%s)..." % (config["email"], config.get("institution", "?")) + RESET)
        client = SeashellClient(server, config["api_key"])
        client.wake()  # pre-warm while we verify
        health = client.health()
        if health:
            count = health.get("patients", health.get("patient_count", "?"))
            print(BOLD + "  Ready." + RESET + " %s patients loaded.\n" % count)
            return client, config
        else:
            print("  Server unreachable. Re-enter credentials.\n")

    # Fresh login
    api_key = input(CYAN + "  API Key: " + RESET).strip()
    if not api_key:
        print("  No API key provided. Exiting.")
        sys.exit(1)

    # Immediately start warming up the instance (API key identifies institution)
    client = SeashellClient(server, api_key)
    client.wake()

    # Verify the key and get institution name
    health = client.health()
    if health:
        inst = health.get("institution", "your institution")
        print(DIM + "  Institution: %s " % inst + CYAN + "(warming up...)" + RESET)
    else:
        inst = "unknown"
        print("  Could not reach server at %s" % server)
        print("  Will retry on first query.\n")

    email = input(CYAN + "  Username: " + RESET).strip()
    password = getpass.getpass(CYAN + "  Password: " + RESET)

    # Verify credentials
    try:
        resp = client.session.post(server + "/auth/login", json={
            "email": email,
            "password": password,
        }, timeout=15)
        if resp.status_code != 200:
            detail = ""
            try:
                detail = resp.json().get("detail", "")
            except Exception:
                pass
            print("\n  Login failed: %s" % (detail or "invalid credentials"))
            sys.exit(1)
        login_data = resp.json()
    except Exception as e:
        print("\n  Connection error: %s" % str(e))
        sys.exit(1)

    # Save credentials
    config = {
        "server": server,
        "api_key": api_key,
        "institution": inst if inst != "unknown" else login_data.get("institution", ""),
        "email": email,
        "session_token": login_data.get("token", ""),
    }
    save_config(config)

    # Check patient count
    health = client.health()
    count = health.get("patients", health.get("patient_count", "?")) if health else "?"
    print("\n  " + BOLD + "Authenticated." + RESET + " %s patients loaded. Ready.\n" % count)
    return client, config


def _run_query(client, query_text, output_format="table", repl_state=None):
    """Execute a single query and display the result.

    If repl_state is provided, caches the result + action for the `more` command.
    """
    query_upper = query_text.strip().upper()

    # Detect async operations (upload/export) that need job polling
    is_upload = query_upper.startswith("UPLOAD ") or query_upper.startswith("INGEST ")
    is_export = query_upper.startswith("EXPORT ")

    try:
        result = client.query(query_text)
    except PermissionError as e:
        sys.stderr.write("  Permission denied: %s\n" % str(e))
        return
    except RuntimeError as e:
        sys.stderr.write("  %s\n" % str(e))
        return
    except Exception as e:
        sys.stderr.write("  Error: %s\n" % str(e))
        return

    # Handle async jobs
    job_id = result.get("job_id")
    if job_id and (is_upload or is_export):
        endpoint = "ingest_gql" if is_upload else "export"
        print("  Job started: %s" % job_id)
        print("  Patients: %s" % result.get("patients", result.get("num_patients", "?")))
        print()
        final = client.poll_job(endpoint, job_id, callback=print_job_progress)
        print()
        if final.get("errors"):
            for err in final["errors"]:
                sys.stderr.write("  Error: %s - %s\n" % (
                    err.get("patient_id", "?"), err.get("error", "?")))
        elapsed = final.get("completed_at", 0) - final.get("started_at", 0)
        if elapsed > 0:
            print("  Completed in %.1fs" % elapsed)
        return

    action = infer_action(query_text)
    display_result(result, output_format, action=action)

    # Cache result for `more` command
    if repl_state is not None:
        repl_state["last_result"] = result
        repl_state["last_action"] = action
        repl_state["last_offset"] = 25  # default page size already shown


def _repl(client, config):
    """Interactive REPL loop."""
    repl_state = {"last_result": None, "last_action": None, "last_offset": 0}

    while True:
        try:
            query = input(CYAN + "seashell> " + RESET).strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Goodbye.")
            break

        if not query:
            continue

        lower = query.lower()

        if lower in ("exit", "quit", "q"):
            print("  Goodbye.")
            break
        elif lower == "help":
            print(HELP_TEXT)
        elif lower == "status":
            print("  Server:      %s" % config.get("server", "?"))
            print("  Institution: %s" % config.get("institution", "?"))
            print("  User:        %s" % config.get("email", "?"))
            health = client.health()
            if health:
                print("  Patients:    %s" % health.get("patients", health.get("patient_count", "?")))
                print("  Engine:      %s" % health.get("status", "?"))
            else:
                print("  Server:      unreachable")
        elif lower == "logout":
            clear_config()
            print("  Credentials cleared. Run 'seashell' to log in again.")
            break
        elif lower in ("more", "next"):
            if repl_state["last_result"] is None:
                print("  No previous query to expand. Run a query first.")
            else:
                new_offset = show_more(
                    repl_state["last_result"],
                    repl_state["last_action"],
                    repl_state["last_offset"])
                if new_offset is not None:
                    repl_state["last_offset"] = new_offset
        else:
            _run_query(client, query, repl_state=repl_state)


def main():
    """Entry point for the seashell CLI."""
    args = sys.argv[1:]

    # --help flag
    if args and args[0] in ("--help", "-h"):
        print("Usage:")
        print("  seashell                              Interactive mode")
        print("  seashell \"LIST PATIENTS\"               Single query")
        print("  seashell --server URL                  Set server URL")
        print("  seashell --format json \"LIST PATIENTS\" Output as JSON")
        print()
        print(HELP_TEXT)
        return

    # Parse flags
    server_override = None
    output_format = "table"
    query_parts = []

    i = 0
    while i < len(args):
        if args[i] == "--server" and i + 1 < len(args):
            server_override = args[i + 1]
            i += 2
        elif args[i] == "--format" and i + 1 < len(args):
            output_format = args[i + 1]
            i += 2
        elif args[i] == "--json":
            output_format = "json"
            i += 1
        elif args[i] == "--tsv":
            output_format = "tsv"
            i += 1
        else:
            query_parts.append(args[i])
            i += 1

    # Apply server override
    if server_override:
        config = load_config()
        config["server"] = server_override
        save_config(config)

    if query_parts:
        # Single query mode
        query_text = " ".join(query_parts)
        config = load_config()
        if not config.get("api_key"):
            # Not logged in — prompt first
            client, config = _prompt_login()
        else:
            client = SeashellClient(
                config.get("server", DEFAULT_SERVER),
                config["api_key"])
        _run_query(client, query_text, output_format)
    else:
        # Interactive mode
        client, config = _prompt_login()
        _repl(client, config)


if __name__ == "__main__":
    main()
