# collective.html2blocks — Local Claude Instructions

> Fill in the placeholders below with your local context.


## obsidian-scribe

* repo: collective.html2blocks
* category: Plone Community Project
* tags: plone/dev, plone/volto, codebase/python
* github: git@github.com:collective/collective.html2blocks.git


## Project Overview

- **Repo**: git@github.com:collective/collective.html2blocks.git
- **Description**: Converts HTML to Volto-compatible block structures for migrating content from older Plone versions and other CMS platforms.
- **Stack**: Python 3.12+, BeautifulSoup4, typer (CLI), FastAPI
- **Entry point**: `collective.html2blocks.cli:cli` (command: `html2blocks`)

## Current Focus

<!-- What are you currently working on? -->
- Working on issue #22: Table parsing and conversion improvements

## Architecture Notes

<!-- Add any non-obvious design decisions or constraints you want Claude to know -->
- Core converter (`converter.py`) transforms HTML to Volto blocks using registered block handlers
- Block handlers live in `blocks/` directory (table.py, image.py, video.py, etc.)
- Utilities in `utils/` handle markup parsing, Slate (rich text editor) conversion, and block generation
- Uses towncrier for changelog management with `news/` fragments

## Local Dev Setup

<!-- Any local quirks, paths, or env vars needed -->
- Install: `make install` or `uv sync`
- Test: `make test` or `uv run pytest`
- Lint: `make lint` (includes ruff, pyroma, check-python-versions, mypy)
- Format: `make format` (ruff format + import sorting)
- Coverage: `make test-coverage`

## Constraints & Preferences

<!-- Things Claude should always or never do in this codebase -->
- Uses `uv` for dependency management (never raw pip)
- Type hints required; mypy with `ignore_missing_imports = true`
- reStructuredText docstrings (`:param:`, `:returns:`, `:raises:`)
- Towncrier for changelog: create `news/` fragments for all changes
- No `Co-Authored-By:` in commits (per personal guidelines)

## Related Repos / External Resources

<!-- Other repos, docs, or references Claude should be aware of -->
- Volto: https://github.com/plone/volto (block-based frontend)
- Plone REST API: https://github.com/plone/plone.restapi
- Documentation: https://collective.github.io/collective.html2blocks
- GitHub Issues: https://github.com/collective/collective.html2blocks/issues
