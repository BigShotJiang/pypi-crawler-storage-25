class BanterError(Exception):
    pass

class HTTPException(BanterError):

    def __init__(self, status, code, message):
        self.status = status
        self.code = code
        self.message = message
        super().__init__(f'{status} {code}: {message}')

class Forbidden(HTTPException):
    pass

class NotFound(HTTPException):
    pass

class RateLimited(HTTPException):

    def __init__(self, status, code, message, retry_after):
        super().__init__(status, code, message)
        self.retry_after = retry_after

class GatewayError(BanterError):
    pass

class LoginFailure(BanterError):
    pass

class MissingPermissions(BanterError):

    def __init__(self, missing):
        self.missing = missing
        names = ', '.join(missing) if missing else 'unknown'
        super().__init__(f'Missing permissions: {names}')
