from powerball import *



def test_lottery_nums_len():

	# Ensure the lenght of lottery numbers are always 5
	roll = generate_lottery_numbers(1)
	assert len(roll[0][0].split("-")) == 5
	
	
def test_lottery_nums_range():

	# Ensure the lenght of lottery numbers are always 5
	roll = generate_lottery_numbers(1)
	for num in [int(i) for i in roll[0][0].split("-")]:
		assert 1 <= num <= 69


def test_lottery_gen_len():
    rolls = generate_lottery_numbers(10)
    assert len(rolls) == 10
