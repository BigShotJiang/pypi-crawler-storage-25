from .powerball import print_lottery_numbers

def run():
    num_runs = int(input("Enter the number of lottery tickets to generate: ")) 
    print_lottery_numbers(num_runs) 

if __name__ == "__main__":
    run()
                         