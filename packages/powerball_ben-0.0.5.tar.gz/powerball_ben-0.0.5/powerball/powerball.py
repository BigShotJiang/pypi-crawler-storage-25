import secrets
import random

def generate_lottery_numbers(num_runs : int = 1,y=1) -> list:
    '''Generates lottery numbers using the secrets module for cryptographic randomness.'''
    # secrets doesn't have a built-in 'sample' method, 
    # so we use SystemRandom which uses the OS's secure source.
    secure_gen = random.SystemRandom()
    runs = []
    for _ in range(num_runs):  
        # Generate a unique numbers (1-69)
        main_nums = secure_gen.sample(range(1, 70), 5)
        main_nums.sort()
        
        # Generate 1 Powerball (1-26)
        # secrets.randbelow(26) returns 0-25, so we add 1
        powerball = secrets.randbelow(26) + 1

        # Format numbers with leading zeros
        formatted_main = "-".join([f"{num:02d}" for num in main_nums])
        formatted_pb = f"{powerball:02d}"
        runs.append((formatted_main, formatted_pb))

    return runs


def print_lottery_numbers(num_runs: int = 1):
    '''Prints the generated lottery numbers in a readable format.'''
    numbers = generate_lottery_numbers(num_runs)
    for idx, (main, pb) in enumerate(numbers, 1):
        print(f"Ticket {idx}: Main Numbers: {main} | Powerball: {pb}")


if __name__ == "__main__":
   print_lottery_numbers(2)
