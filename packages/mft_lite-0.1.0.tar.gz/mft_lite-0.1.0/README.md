# mft-lite

`mft-lite` is a lightweight secure file-transfer SDK and CLI for enterprise data movement. It supports local files, SFTP, Google Cloud Storage, and Amazon S3 with retries, streaming chunks, and SHA-256 checksums.

## Install

```bash
pip install mft-lite
pip install "mft-lite[gcp]"   # Google Cloud Storage support
pip install "mft-lite[aws]"   # Amazon S3 support
pip install "mft-lite[all]"   # Both GCP and AWS
```

## CLI examples

```bash
mft-lite transfer ./file.txt ./copy.txt
mft-lite transfer ./file.txt sftp://user@sftp.example.com:22/drop/file.txt
mft-lite transfer gs://source-bucket/file.txt sftp://user@sftp.example.com/drop/file.txt
mft-lite transfer s3://source-bucket/file.txt gs://target-bucket/file.txt
```

For SFTP authentication:

```bash
export MFT_LITE_SFTP_USERNAME=user
export MFT_LITE_SFTP_PASSWORD='secret'
# or
export MFT_LITE_SFTP_KEY_FILE=/path/to/private_key
```

## Python API

```python
from mft_lite import transfer

result = transfer(
    source="./file.txt",
    destination="./copy.txt",
    retries=3,
)
print(result.bytes_transferred, result.checksum_sha256)
```

## Development

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pytest
ruff check src tests
python -m build
python -m twine check dist/*
```

## Publish

```bash
python -m twine upload dist/*
```

Use `__token__` as username and your PyPI API token as password.

## Security note

SFTP uses system known-hosts validation and rejects unknown host keys by default. Add trusted host keys to `~/.ssh/known_hosts` before production use.

## License

MIT

Author: Raghava Chellu

MIT License is freely usable for academic, personal, and commercial projects.
