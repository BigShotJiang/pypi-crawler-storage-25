from __future__ import annotations

import hashlib
import shutil
import time
from datetime import datetime, timezone

from .models import TransferResult
from .providers.base import StorageProvider
from .providers.local import LocalProvider
from .providers.sftp import SFTPProvider
from .uri import TransferURI, parse_uri


def _provider(uri: TransferURI) -> StorageProvider:
    if uri.scheme == "file":
        return LocalProvider()
    if uri.scheme == "sftp":
        return SFTPProvider()
    if uri.scheme == "gcs":
        from .providers.gcs import GCSProvider
        return GCSProvider()
    if uri.scheme == "s3":
        from .providers.s3 import S3Provider
        return S3Provider()
    raise ValueError(f"Unsupported scheme: {uri.scheme}")


def transfer(
    source: str,
    destination: str,
    chunk_size: int = 1024 * 1024,
    retries: int = 3,
    retry_delay: float = 2.0,
    checksum: bool = True,
) -> TransferResult:
    """Transfer bytes from source URI to destination URI.

    Supported URIs:
    - local path or file:///path/file.txt
    - sftp://user@host:22/path/file.txt
    - gcs://bucket/path/file.txt or gs://bucket/path/file.txt
    - s3://bucket/path/file.txt
    """
    if retries < 1:
        raise ValueError("retries must be >= 1")
    src = parse_uri(source)
    dst = parse_uri(destination)
    src_provider = _provider(src)
    dst_provider = _provider(dst)

    last_exc: Exception | None = None
    for attempt in range(1, retries + 1):
        started_at = datetime.now(timezone.utc)
        sha = hashlib.sha256()
        total = 0
        try:
            with src_provider.open_read(src) as reader, dst_provider.open_write(dst) as writer:
                while True:
                    chunk = reader.read(chunk_size)
                    if not chunk:
                        break
                    writer.write(chunk)
                    total += len(chunk)
                    if checksum:
                        sha.update(chunk)
            return TransferResult(
                source=source,
                destination=destination,
                bytes_transferred=total,
                started_at=started_at,
                completed_at=datetime.now(timezone.utc),
                checksum_sha256=sha.hexdigest() if checksum else None,
                attempts=attempt,
                success=True,
            )
        except Exception as exc:
            last_exc = exc
            if attempt < retries:
                time.sleep(retry_delay)
    raise RuntimeError(f"Transfer failed after {retries} attempt(s): {last_exc}") from last_exc
