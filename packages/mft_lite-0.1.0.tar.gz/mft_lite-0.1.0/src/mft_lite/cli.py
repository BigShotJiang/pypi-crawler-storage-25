from __future__ import annotations

import json

import typer
from rich.console import Console

from .core import transfer as run_transfer

app = typer.Typer(help="Lightweight secure file transfer CLI")
console = Console()


@app.command()
def transfer(
    source: str = typer.Argument(..., help="Source URI or local path"),
    destination: str = typer.Argument(..., help="Destination URI or local path"),
    retries: int = typer.Option(3, "--retries", "-r"),
    chunk_size: int = typer.Option(1024 * 1024, "--chunk-size"),
    no_checksum: bool = typer.Option(False, "--no-checksum"),
):
    """Transfer a file between local, SFTP, GCS, or S3 endpoints."""
    try:
        result = run_transfer(
            source=source,
            destination=destination,
            retries=retries,
            chunk_size=chunk_size,
            checksum=not no_checksum,
        )
    except Exception as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1)
    console.print(json.dumps(result.model_dump(mode="json"), indent=2))
