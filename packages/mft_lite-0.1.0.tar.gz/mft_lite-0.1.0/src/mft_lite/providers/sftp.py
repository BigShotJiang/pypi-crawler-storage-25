from __future__ import annotations

import os
from typing import BinaryIO

import paramiko

from .base import StorageProvider
from ..uri import TransferURI


class SFTPProvider(StorageProvider):
    def _client(self, uri: TransferURI):
        username = uri.username or os.getenv("MFT_LITE_SFTP_USERNAME")
        password = os.getenv("MFT_LITE_SFTP_PASSWORD")
        key_file = os.getenv("MFT_LITE_SFTP_KEY_FILE")
        client = paramiko.SSHClient()
        client.load_system_host_keys()
        client.set_missing_host_key_policy(paramiko.RejectPolicy())
        kwargs = {"hostname": uri.host, "port": uri.port or 22, "username": username, "timeout": 20}
        if key_file:
            kwargs["key_filename"] = key_file
        elif password:
            kwargs["password"] = password
        client.connect(**kwargs)
        return client, client.open_sftp()

    def open_read(self, uri: TransferURI) -> BinaryIO:
        client, sftp = self._client(uri)
        f = sftp.open(uri.path, "rb")
        original_close = f.close
        def close():
            original_close(); sftp.close(); client.close()
        f.close = close
        return f

    def open_write(self, uri: TransferURI) -> BinaryIO:
        client, sftp = self._client(uri)
        f = sftp.open(uri.path, "wb")
        original_close = f.close
        def close():
            original_close(); sftp.close(); client.close()
        f.close = close
        return f
