from __future__ import annotations

from pathlib import Path
from typing import BinaryIO

from .base import StorageProvider
from ..uri import TransferURI


class LocalProvider(StorageProvider):
    def open_read(self, uri: TransferURI) -> BinaryIO:
        return open(uri.path, "rb")

    def open_write(self, uri: TransferURI) -> BinaryIO:
        Path(uri.path).parent.mkdir(parents=True, exist_ok=True)
        return open(uri.path, "wb")
