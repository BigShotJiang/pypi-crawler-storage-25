from __future__ import annotations

from abc import ABC, abstractmethod
from typing import BinaryIO

from ..uri import TransferURI


class StorageProvider(ABC):
    @abstractmethod
    def open_read(self, uri: TransferURI) -> BinaryIO:
        raise NotImplementedError

    @abstractmethod
    def open_write(self, uri: TransferURI) -> BinaryIO:
        raise NotImplementedError
