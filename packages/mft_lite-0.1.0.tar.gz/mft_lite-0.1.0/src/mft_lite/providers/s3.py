from __future__ import annotations

from tempfile import SpooledTemporaryFile
from typing import BinaryIO

from .base import StorageProvider
from ..uri import TransferURI


class S3Provider(StorageProvider):
    def __init__(self):
        try:
            import boto3
        except ImportError as exc:
            raise RuntimeError("Install S3 support with: pip install 'mft-lite[aws]'") from exc
        self.client = boto3.client("s3")

    def open_read(self, uri: TransferURI) -> BinaryIO:
        tmp = SpooledTemporaryFile(max_size=64 * 1024 * 1024)
        self.client.download_fileobj(uri.bucket, uri.path, tmp)
        tmp.seek(0)
        return tmp

    def open_write(self, uri: TransferURI) -> BinaryIO:
        tmp = SpooledTemporaryFile(max_size=64 * 1024 * 1024)
        original_close = tmp.close
        def close():
            tmp.seek(0)
            self.client.upload_fileobj(tmp, uri.bucket, uri.path)
            original_close()
        tmp.close = close
        return tmp
