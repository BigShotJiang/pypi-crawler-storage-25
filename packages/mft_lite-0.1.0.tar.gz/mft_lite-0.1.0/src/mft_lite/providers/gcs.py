from __future__ import annotations

from tempfile import SpooledTemporaryFile
from typing import BinaryIO

from .base import StorageProvider
from ..uri import TransferURI


class GCSProvider(StorageProvider):
    def __init__(self):
        try:
            from google.cloud import storage
        except ImportError as exc:
            raise RuntimeError("Install GCS support with: pip install 'mft-lite[gcp]'") from exc
        self.client = storage.Client()

    def open_read(self, uri: TransferURI) -> BinaryIO:
        blob = self.client.bucket(uri.bucket).blob(uri.path)
        tmp = SpooledTemporaryFile(max_size=64 * 1024 * 1024)
        blob.download_to_file(tmp)
        tmp.seek(0)
        return tmp

    def open_write(self, uri: TransferURI) -> BinaryIO:
        blob = self.client.bucket(uri.bucket).blob(uri.path)
        tmp = SpooledTemporaryFile(max_size=64 * 1024 * 1024)
        original_close = tmp.close
        def close():
            tmp.seek(0)
            blob.upload_from_file(tmp)
            original_close()
        tmp.close = close
        return tmp
