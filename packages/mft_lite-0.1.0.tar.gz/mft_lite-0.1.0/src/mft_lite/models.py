from __future__ import annotations

from datetime import datetime, timezone
from pydantic import BaseModel, Field


class TransferResult(BaseModel):
    source: str
    destination: str
    bytes_transferred: int
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None
    checksum_sha256: str | None = None
    attempts: int = 1
    success: bool = True
