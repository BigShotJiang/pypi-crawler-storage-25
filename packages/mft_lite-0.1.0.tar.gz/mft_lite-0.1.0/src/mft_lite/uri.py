from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urlparse, unquote


@dataclass(frozen=True)
class TransferURI:
    raw: str
    scheme: str
    bucket: str | None
    path: str
    host: str | None = None
    username: str | None = None
    port: int | None = None


def parse_uri(value: str) -> TransferURI:
    if not value:
        raise ValueError("URI is required")
    parsed = urlparse(value)
    scheme = parsed.scheme or "file"

    if scheme == "file":
        path = parsed.path if parsed.scheme else value
        return TransferURI(raw=value, scheme="file", bucket=None, path=unquote(path))

    if scheme in {"s3", "gs", "gcs"}:
        if not parsed.netloc:
            raise ValueError(f"{scheme} URI requires bucket, example {scheme}://bucket/path")
        return TransferURI(raw=value, scheme="gcs" if scheme == "gs" else scheme, bucket=parsed.netloc, path=unquote(parsed.path.lstrip("/")))

    if scheme == "sftp":
        if not parsed.hostname:
            raise ValueError("sftp URI requires host")
        return TransferURI(raw=value, scheme="sftp", bucket=None, path=unquote(parsed.path), host=parsed.hostname, username=parsed.username, port=parsed.port or 22)

    raise ValueError(f"Unsupported URI scheme: {scheme}")
