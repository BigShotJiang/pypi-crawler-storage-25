from mft_lite.uri import parse_uri


def test_local_path():
    uri = parse_uri("/tmp/a.txt")
    assert uri.scheme == "file"
    assert uri.path == "/tmp/a.txt"


def test_gcs_alias():
    uri = parse_uri("gs://bucket/path/a.txt")
    assert uri.scheme == "gcs"
    assert uri.bucket == "bucket"
    assert uri.path == "path/a.txt"


def test_sftp():
    uri = parse_uri("sftp://user@example.com:2222/drop/a.txt")
    assert uri.scheme == "sftp"
    assert uri.username == "user"
    assert uri.host == "example.com"
    assert uri.port == 2222
