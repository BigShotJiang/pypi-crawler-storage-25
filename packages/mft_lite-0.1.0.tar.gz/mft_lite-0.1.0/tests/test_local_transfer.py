from pathlib import Path

from mft_lite import transfer


def test_local_transfer(tmp_path: Path):
    src = tmp_path / "src.txt"
    dst = tmp_path / "out" / "dst.txt"
    src.write_text("hello")
    result = transfer(str(src), str(dst))
    assert result.bytes_transferred == 5
    assert dst.read_text() == "hello"
