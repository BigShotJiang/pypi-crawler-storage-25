from datetime import UTC, datetime
from typing import Self
from uuid import UUID, uuid4

from aio_pika.abc import AbstractIncomingMessage
from google.cloud.pubsub_v1.subscriber.message import Message as PubSubMessage
from nexo.enums.service import FullServiceTypeMixin, ServiceType
from nexo.schemas.mixins.identity import IdentifierMixin, UUIDId, UUIDPrincipalId
from nexo.types.datetime import OptDatetime
from nexo.types.string import ManyStrs, OptStr
from nexo.types.uuid import OptUUID
from pydantic import model_validator

from ..enums.deployment import Trigger, TriggerMixin
from ..enums.deployment_configuration import (
    IdentifierType as DeploymentConfigurationIdentifierType,
)
from ..enums.deployment_configuration import (
    Restart,
)
from ..mixins.common import Message, MessageId, PublishedAt, ServiceKey
from ..mixins.deployment import IdDeploymentIdentifier
from ..mixins.deployment_configuration import (
    ConfigurationId,
    DeploymentConfigurationIdentifier,
    Registry,
    RegistryUrl,
    Tag,
    Target,
)
from .deployment_configuration import DeploymentConfigurationDTO, RunArgs, RunArgsMixin


class ImagePushedMessage(
    Tag[str],
    Registry[str],
    ServiceKey,
):
    pass


class TriggerDTO(
    Message[ImagePushedMessage | None],
    PublishedAt[OptDatetime],
    MessageId[OptStr],
    UUIDPrincipalId[OptUUID],
    TriggerMixin[Trigger],
):
    @model_validator(mode="after")
    def validate_conditions(self) -> Self:
        if self.trigger is Trigger.MANUAL:
            if self.principal_id is None:
                raise ValueError(
                    "Principal ID can not be None for manual-triggered deployment"
                )
            if (
                self.message_id is not None
                or self.published_at is not None
                or self.message is not None
            ):
                raise ValueError(
                    "Message related fields must be None "
                    "for manual-triggered deployment"
                )
        elif self.trigger is Trigger.MESSAGE:
            if self.principal_id is not None:
                raise ValueError(
                    "Principal ID must be None for message-triggered deployment"
                )
            if (
                self.message_id is None
                or self.published_at is None
                or self.message is None
            ):
                raise ValueError(
                    "Message related fields can not be None "
                    "for message-triggered deployment"
                )
        return self

    @classmethod
    def from_manual(cls, principal_id: UUID) -> Self:
        return cls(
            trigger=Trigger.MANUAL,
            principal_id=principal_id,
            message_id=None,
            published_at=None,
            message=None,
        )

    @classmethod
    def from_message(cls, message: AbstractIncomingMessage | PubSubMessage) -> Self:
        if isinstance(message, AbstractIncomingMessage):
            message_id = message.message_id or str(uuid4())
            published_at = message.timestamp or datetime.now(UTC)
            raw = message.body.decode("utf-8")
        elif isinstance(message, PubSubMessage):
            message_id = message.message_id
            published_at = message.publish_time
            raw = message.data.decode("utf-8")
        return cls(
            trigger=Trigger.MESSAGE,
            principal_id=None,
            message_id=message_id,
            published_at=published_at,
            message=ImagePushedMessage.model_validate_json(raw),
        )

    @property
    def configuration_identifier(self) -> DeploymentConfigurationIdentifier:
        if self.message is None:
            raise ValueError(
                "Message is None, can not create deployment configuration identifier"
            )
        return DeploymentConfigurationIdentifier(
            type=DeploymentConfigurationIdentifierType.SERVICE_KEY,
            value=self.message.service_key,
        )


class InsertData(
    TriggerDTO,
    Target[str],
    RunArgs[Restart],
    Tag[str],
    RegistryUrl[str],
    FullServiceTypeMixin[ServiceType],
    ServiceKey[str],
    ConfigurationId[UUID],
):
    @classmethod
    def new(
        cls,
        configuration: DeploymentConfigurationDTO,
        target: str,
        trigger: TriggerDTO,
    ) -> Self:
        return cls(
            configuration_id=configuration.id,
            service_key=configuration.service_key,
            service_type=configuration.service_type,
            registry_url=configuration.registry_url,
            tag=configuration.tag,
            restart=configuration.restart,
            volumes=configuration.volumes,
            extra=configuration.extra,
            target=target,
            trigger=trigger.trigger,
            principal_id=trigger.principal_id,
            message_id=trigger.message_id,
            published_at=trigger.published_at,
            message=trigger.message,
        )


class DeploymentDTO(
    TriggerDTO,
    Target[str],
    RunArgs[Restart],
    Tag[str],
    RegistryUrl[str],
    FullServiceTypeMixin[ServiceType],
    ServiceKey[str],
    UUIDId[UUID],
):
    @property
    def _identifiers(self) -> tuple[IdDeploymentIdentifier]:
        return (IdDeploymentIdentifier(value=self.id),)

    @property
    def _identifier_mixins(self) -> tuple[IdentifierMixin[IdDeploymentIdentifier]]:
        (id_identifier,) = self._identifiers

        return (IdentifierMixin(identifier=id_identifier),)

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            identifier.model_dump_json() for identifier in self._identifier_mixins
        )


class DeployMessage(
    RunArgsMixin[Restart],
    Tag[str],
    Registry[str],
    FullServiceTypeMixin[ServiceType],
    ServiceKey,
):
    @classmethod
    def from_dto(cls, dto: DeploymentDTO) -> Self:
        tag = (
            dto.tag
            if dto.service_type is ServiceType.BACKEND
            else f"{dto.target}-{dto.tag}"
        )
        args = RunArgs(
            restart=dto.restart,
            volumes=dto.volumes,
            extra=dto.extra,
        )
        return cls(
            service_key=dto.service_key,
            service_type=dto.service_type,
            registry=dto.registry_url,
            tag=tag,
            args=args,
        )
