from typing import Annotated
from uuid import UUID

from nexo.enums.service import FullServiceTypeMixin, ServiceType
from nexo.enums.status import DataStatus, SimpleDataStatusMixin
from nexo.schemas.mixins.identity import IdentifierMixin, UUIDId
from nexo.types.string import ListOfStrs, ManyStrs, OptListOfStrs
from pydantic import BaseModel, Field

from ..enums.deployment_configuration import (
    OptRestart,
    Restart,
    RestartMixin,
)
from ..mixins.common import ServiceKey
from ..mixins.deployment_configuration import (
    Extra,
    IdDeploymentConfigurationIdentifier,
    IsAutoDeploy,
    RegistryUrl,
    ServiceKeyDeploymentConfigurationIdentifier,
    Tag,
    Targets,
    Volumes,
)


class RunArgs[T: OptRestart](
    Extra[OptListOfStrs],
    Volumes[OptListOfStrs],
    RestartMixin[T],
):
    volumes: Annotated[
        OptListOfStrs, Field(None, description="Volumes", min_length=1)
    ] = None
    extra: Annotated[OptListOfStrs, Field(None, description="Extra", min_length=1)] = (
        None
    )


class RunArgsMixin[T: OptRestart](BaseModel):
    args: Annotated[RunArgs[T], Field(..., description="Docker run arguments")]


class DeploymentConfigurationDTO(
    IsAutoDeploy[bool],
    Targets[ListOfStrs],
    RunArgs[Restart],
    Tag[str],
    RegistryUrl[str],
    FullServiceTypeMixin[ServiceType],
    ServiceKey[str],
    SimpleDataStatusMixin[DataStatus],
    UUIDId[UUID],
):
    @property
    def _identifiers(
        self,
    ) -> tuple[
        IdDeploymentConfigurationIdentifier,
        ServiceKeyDeploymentConfigurationIdentifier,
    ]:
        return (
            IdDeploymentConfigurationIdentifier(value=self.id),
            ServiceKeyDeploymentConfigurationIdentifier(value=self.service_key),
        )

    @property
    def _identifier_mixins(
        self,
    ) -> tuple[
        IdentifierMixin[IdDeploymentConfigurationIdentifier],
        IdentifierMixin[ServiceKeyDeploymentConfigurationIdentifier],
    ]:
        id_identifier, service_key_identifier = self._identifiers

        return (
            IdentifierMixin(identifier=id_identifier),
            IdentifierMixin(identifier=service_key_identifier),
        )

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            identifier.model_dump_json() for identifier in self._identifier_mixins
        )
