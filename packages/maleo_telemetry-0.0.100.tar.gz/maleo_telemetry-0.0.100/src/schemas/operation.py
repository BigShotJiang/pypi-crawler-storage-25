import json
from datetime import UTC, datetime
from typing import Annotated, Literal, Self, overload
from uuid import UUID, uuid4

from aio_pika.abc import AbstractIncomingMessage
from google.cloud.pubsub_v1.subscriber.message import Message
from nexo.enums.environment import EnvironmentsMixin, OptListOfEnvironments
from nexo.enums.status import FULL_DATA_STATUSES, ListOfDataStatuses
from nexo.schemas.connection import ConnectionContextMixin, OptConnectionContext
from nexo.schemas.error import ErrorMixin, OptAnyError
from nexo.schemas.error.enums import FullErrorTypesMixin, OptListOfErrorTypes
from nexo.schemas.mixins.filter import ListOfRangeFilters
from nexo.schemas.mixins.filter import convert as convert_filter
from nexo.schemas.mixins.general import Success
from nexo.schemas.mixins.identity import UUIDId, UUIDIds
from nexo.schemas.mixins.sort import ListOfSortColumns
from nexo.schemas.mixins.sort import convert as convert_sort
from nexo.schemas.mixins.timestamp import CreationTimestamp
from nexo.schemas.operation.action.common import (
    OperationActionsMixin,
    OptListOfOperationActions,
)
from nexo.schemas.operation.context import ContextMixin
from nexo.schemas.operation.enums import (
    LayersMixin,
    OperationType,
    OperationTypeMixin,
    OperationTypesMixin,
    OptListOfLayers,
    OptListOfOperationTypes,
    OptListOfOrigins,
    OptListOfTargets,
    OriginsMixin,
    TargetsMixin,
)
from nexo.schemas.operation.mixins import Summary, TimestampMixin
from nexo.schemas.pagination import Limit
from nexo.schemas.parameter import (
    ReadPaginatedMultipleParameter,
)
from nexo.schemas.parameter import (
    ReadSingleParameter as BaseReadSingleParameter,
)
from nexo.schemas.resource import OptResource, ResourceMixin
from nexo.schemas.response import (
    OptAnyResponse,
    OptResponseContext,
    ResponseContextMixin,
    ResponseMixin,
)
from nexo.schemas.security.authentication import (
    AuthenticationMixin,
    OptAnyAuthentication,
)
from nexo.schemas.security.authorization import AuthorizationMixin, OptAnyAuthorization
from nexo.schemas.security.impersonation import ImpersonationMixin, OptImpersonation
from nexo.types.boolean import OptBool
from nexo.types.dict import StrToAnyDict
from nexo.types.string import OptListOfStrs, OptStr
from nexo.types.uuid import OptListOfUUIDs
from pydantic import Field

from ..enums.operation import IdentifierType
from ..mixins.common import (
    ApplicationContext,
    InstanceIds,
    MessageIds,
    MessageInfo,
    ServiceKeys,
)
from ..mixins.operation import (
    CustomnId,
    CustomnIds,
    OperationActionMixin,
    OperationIdentifier,
)
from ..types.operation import IdentifierValueType


class SimpleOperationData(
    ResponseMixin[OptAnyResponse],
    Success[bool],
    TimestampMixin,
    ResourceMixin[OptResource],
    OperationActionMixin,
    ContextMixin,
    OperationTypeMixin[OperationType],
    CustomnId[UUID],
):
    resource: Annotated[OptResource, Field(None, description="Resource")] = None
    response: Annotated[OptAnyResponse, Field(None, description="Response")] = None


class FullOperationData(
    ResponseContextMixin[OptResponseContext],
    ResponseMixin[OptAnyResponse],
    ImpersonationMixin[OptImpersonation],
    AuthorizationMixin[OptAnyAuthorization],
    AuthenticationMixin[OptAnyAuthentication],
    ConnectionContextMixin[OptConnectionContext],
    ErrorMixin[OptAnyError],
    Success[bool],
    Summary,
    TimestampMixin,
    ResourceMixin[OptResource],
    OperationActionMixin,
    ContextMixin,
    OperationTypeMixin[OperationType],
    CustomnId[UUID],
):
    resource: Annotated[OptResource, Field(None, description="Resource")] = None
    error: Annotated[OptAnyError, Field(None, description="Error")] = None
    connection_context: Annotated[
        OptConnectionContext, Field(None, description="Connection context")
    ] = None
    authentication: Annotated[
        OptAnyAuthentication, Field(None, description="Authentication")
    ] = None
    authorization: Annotated[
        OptAnyAuthorization, Field(None, description="Authorization")
    ] = None
    impersonation: Annotated[
        OptImpersonation, Field(None, description="Impersonation")
    ] = None
    response: Annotated[OptAnyResponse, Field(None, description="Response")] = None
    response_context: Annotated[
        OptResponseContext, Field(None, description="Response's context")
    ] = None


class CreateParameter(
    FullOperationData,
    ApplicationContext,
    MessageInfo,
):
    @classmethod
    def from_message(cls, message: Message | AbstractIncomingMessage) -> Self:
        # 1. build raw data
        if isinstance(message, AbstractIncomingMessage):
            raw_payload = json.loads(message.body.decode("utf-8"))
            headers = message.headers or {}
            message_id = message.message_id or str(uuid4())
            published_at = message.timestamp or datetime.now(UTC)
            data = {
                **raw_payload,
                **headers,
                "message_id": message_id,
                "published_at": published_at,
            }
        elif isinstance(message, Message):
            raw_payload = json.loads(message.data.decode("utf-8"))
            attributes = message.attributes
            data = {
                **raw_payload,
                **attributes,
                "message_id": message.message_id,
                "published_at": message.publish_time,
            }

        # 2. Force the model to "bake" its internal state immediately
        # Pydantic v2's model_validate runs in Rust. We need to force it
        # to move its data into the Python dictionary.
        obj = cls.model_validate(data)

        # 3. Force the model to hydrate its internal fields by accessing them
        # This ensures that even if the Rust pointer breaks later,
        # the Python data is already safe in the object's __dict__
        _ = obj.model_dump()

        return obj


class ReadMultipleParameter(
    ReadPaginatedMultipleParameter,
    FullErrorTypesMixin[OptListOfErrorTypes],
    Success[OptBool],
    OperationActionsMixin[OptListOfOperationActions],
    TargetsMixin[OptListOfTargets],
    LayersMixin[OptListOfLayers],
    OriginsMixin[OptListOfOrigins],
    OperationTypesMixin[OptListOfOperationTypes],
    CustomnIds[OptListOfUUIDs],
    ServiceKeys[OptListOfStrs],
    EnvironmentsMixin[OptListOfEnvironments],
    InstanceIds[OptListOfStrs],
    MessageIds[OptListOfStrs],
    UUIDIds[OptListOfUUIDs],
):
    ids: Annotated[OptListOfUUIDs, Field(None, description="Ids")] = None
    message_ids: Annotated[
        OptListOfStrs, Field(None, description="Message's IDs", min_length=1)
    ] = None
    instance_ids: Annotated[
        OptListOfStrs, Field(None, description="Instance's IDs", min_length=1)
    ] = None
    environments: Annotated[
        OptListOfEnvironments, Field(None, description="Environments", min_length=1)
    ] = None
    service_keys: Annotated[
        OptListOfStrs,
        Field(None, description="Service's Keys", min_length=1),
    ] = None
    ids_: Annotated[OptListOfUUIDs, Field(None, description="Ids_", min_length=1)] = (
        None
    )
    types: Annotated[
        OptListOfOperationTypes,
        Field(None, description="Operation's Types", min_length=1),
    ] = None
    origins: Annotated[
        OptListOfOrigins, Field(None, description="Operation's Origins", min_length=1)
    ] = None
    layers: Annotated[
        OptListOfLayers, Field(None, description="Operation's Layers", min_length=1)
    ] = None
    targets: Annotated[
        OptListOfTargets, Field(None, description="Operation's Targets", min_length=1)
    ] = None
    actions: Annotated[
        OptListOfOperationActions,
        Field(None, description="Operation's Actions", min_length=1),
    ] = None
    success: Annotated[OptBool, Field(None, description="Success")] = None
    error_types: Annotated[
        OptListOfErrorTypes,
        Field(None, description="Error's Types", min_length=1),
    ] = None

    @classmethod
    def new(
        cls,
        ids: OptListOfUUIDs = None,
        range_filters: ListOfRangeFilters = ListOfRangeFilters(),
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        message_ids: OptListOfStrs = None,
        instance_ids: OptListOfStrs = None,
        environments: OptListOfEnvironments = None,
        service_keys: OptListOfStrs = None,
        ids_: OptListOfUUIDs = None,
        types: OptListOfOperationTypes = None,
        origins: OptListOfOrigins = None,
        layers: OptListOfLayers = None,
        targets: OptListOfTargets = None,
        actions: OptListOfOperationActions = None,
        success: OptBool = None,
        error_types: OptListOfErrorTypes = None,
        search: OptStr = None,
        sort_columns: ListOfSortColumns = ListOfSortColumns(),
        page: int = 1,
        limit: Limit = Limit.LIM_10,
        use_cache: bool = True,
    ) -> Self:
        return cls(
            ids=ids,
            range_filters=range_filters,
            statuses=statuses,
            message_ids=message_ids,
            instance_ids=instance_ids,
            environments=environments,
            service_keys=service_keys,
            ids_=ids_,
            types=types,
            origins=origins,
            layers=layers,
            targets=targets,
            actions=actions,
            success=success,
            error_types=error_types,
            search=search,
            sort_columns=sort_columns,
            page=page,
            limit=limit,
            use_cache=use_cache,
        )

    @property
    def _query_param_fields(self) -> set[str]:
        return {
            "ids",
            "statuses",
            "message_ids",
            "instance_ids",
            "environments",
            "service_keys",
            "ids_",
            "types",
            "origins",
            "layers",
            "targets",
            "actions",
            "success",
            "error_types",
            "search",
            "page",
            "limit",
            "use_cache",
        }

    def to_query_params(self) -> StrToAnyDict:
        params = self.model_dump(
            mode="json", include=self._query_param_fields, exclude_none=True
        )
        params["filters"] = convert_filter(self.range_filters)
        params["sorts"] = convert_sort(self.sort_columns)
        params = {k: v for k, v in params.items()}
        return params


class ReadSingleParameter(BaseReadSingleParameter[OperationIdentifier]):
    @classmethod
    def from_identifier(
        cls,
        identifier: OperationIdentifier,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter":
        return cls(identifier=identifier, statuses=statuses, use_cache=use_cache)

    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.ID],
        identifier_value: UUID,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.MESSAGE_ID],
        identifier_value: str,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter": ...
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter":
        return cls(
            identifier=OperationIdentifier(
                type=identifier_type, value=identifier_value
            ),
            statuses=statuses,
            use_cache=use_cache,
        )

    def to_query_params(self) -> StrToAnyDict:
        return self.model_dump(
            mode="json", include={"statuses", "use_cache"}, exclude_none=True
        )


class OperationSchema(
    SimpleOperationData,
    ApplicationContext,
    MessageInfo,
    CreationTimestamp,
    UUIDId[UUID],
):
    pass
