import json
from datetime import UTC, datetime
from typing import Self
from uuid import UUID, uuid4

from aio_pika.abc import AbstractIncomingMessage
from google.cloud.pubsub_v1.subscriber.message import Message
from nexo.infra.heartbeat.schemas import Heartbeat
from nexo.schemas.mixins.identity import UUIDId
from nexo.schemas.mixins.timestamp import CreationTimestamp

from ..mixins.common import ApplicationContext, MessageInfo


class CreateParameter(
    Heartbeat,
    ApplicationContext,
    MessageInfo,
):
    @classmethod
    def from_message(cls, message: Message | AbstractIncomingMessage) -> Self:
        if isinstance(message, AbstractIncomingMessage):
            message_id = message.message_id or str(uuid4())
            published_at = message.timestamp or datetime.now(UTC)
            return cls.model_validate(
                {
                    **json.loads(message.body.decode("utf-8")),
                    **(message.headers or {}),
                    "message_id": message_id,
                    "published_at": published_at,
                }
            )
        elif isinstance(message, Message):
            return cls.model_validate(
                {
                    **json.loads(message.data.decode("utf-8")),
                    **message.attributes,
                    "message_id": message.message_id,
                    "published_at": message.publish_time,
                }
            )


class HeartbeatSchema(
    CreateParameter,
    CreationTimestamp,
    UUIDId[UUID],
):
    pass
