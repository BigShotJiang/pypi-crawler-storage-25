import json
from datetime import UTC, datetime
from typing import Annotated, Self
from uuid import UUID, uuid4

from aio_pika.abc import AbstractIncomingMessage
from google.cloud.pubsub_v1.subscriber.message import Message
from nexo.infra.resource.enums import Status
from nexo.infra.resource.schemas import Usage
from nexo.schemas.mixins.identity import UUIDId
from nexo.schemas.mixins.timestamp import CreationTimestamp
from pydantic import Field

from ..mixins.common import ApplicationContext, MessageInfo


class CreateParameter(
    ApplicationContext,
    MessageInfo,
):
    measured_at: Annotated[datetime, Field(..., description="Measured at timestamp")]
    status: Annotated[Status, Field(..., description="Aggregate status")]
    usage: Annotated[Usage, Field(..., description="Resource usage")]

    @classmethod
    def from_message(cls, message: Message | AbstractIncomingMessage) -> Self:
        if isinstance(message, AbstractIncomingMessage):
            message_id = message.message_id or str(uuid4())
            published_at = message.timestamp or datetime.now(UTC)
            return cls.model_validate(
                {
                    **json.loads(message.body.decode("utf-8")),
                    **(message.headers or {}),
                    "message_id": message_id,
                    "published_at": published_at,
                }
            )
        elif isinstance(message, Message):
            return cls.model_validate(
                {
                    **json.loads(message.data.decode("utf-8")),
                    **message.attributes,
                    "message_id": message.message_id,
                    "published_at": message.publish_time,
                }
            )


class ResourceMeasurementSchema(
    CreateParameter,
    CreationTimestamp,
    UUIDId[UUID],
):
    pass
