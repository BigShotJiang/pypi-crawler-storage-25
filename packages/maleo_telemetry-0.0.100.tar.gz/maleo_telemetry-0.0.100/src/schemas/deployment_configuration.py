from typing import Annotated, Literal, Self, overload
from uuid import UUID

from nexo.enums.service import (
    FullServiceTypeMixin,
    FullServiceTypesMixin,
    OptListOfServiceTypes,
    ServiceType,
)
from nexo.enums.status import (
    FULL_DATA_STATUSES,
    DataStatus,
    ListOfDataStatuses,
    SimpleDataStatusMixin,
)
from nexo.schemas.mixins.filter import ListOfRangeFilters
from nexo.schemas.mixins.filter import convert as convert_filter
from nexo.schemas.mixins.identity import (
    IdentifierMixin,
    UUIDId,
    UUIDIds,
)
from nexo.schemas.mixins.sort import ListOfSortColumns
from nexo.schemas.mixins.sort import convert as convert_sort
from nexo.schemas.operation.enums import ResourceOperationStatusUpdateType
from nexo.schemas.pagination import Limit
from nexo.schemas.parameter import (
    DeleteSingleParameter as BaseDeleteSingleParameter,
)
from nexo.schemas.parameter import (
    ReadPaginatedMultipleParameter,
)
from nexo.schemas.parameter import (
    ReadSingleParameter as BaseReadSingleParameter,
)
from nexo.schemas.parameter import (
    StatusUpdateParameter as BaseStatusUpdateParameter,
)
from nexo.types.boolean import OptBool
from nexo.types.dict import StrToAnyDict
from nexo.types.string import ListOfStrs, OptListOfStrs, OptStr
from nexo.types.uuid import OptListOfUUIDs
from pydantic import BaseModel, Field

from ..dtos.deployment_configuration import RunArgs
from ..enums.deployment_configuration import IdentifierType, OptRestart, Restart
from ..mixins.common import Service, ServiceKey, ServiceKeys
from ..mixins.deployment_configuration import (
    DeploymentConfigurationIdentifier,
    IsAutoDeploy,
    RegistryUrl,
    Tag,
    Targets,
)
from ..types.deployment_configuration import IdentifierValueType


class CreateData(
    IsAutoDeploy[bool],
    Targets[ListOfStrs],
    RunArgs[OptRestart],
    Tag[OptStr],
    RegistryUrl[str],
    ServiceKey[str],
):
    tag: Annotated[OptStr, Field(None, description="Tag")] = None
    restart: Annotated[OptRestart, Field(None, description="Restart Policy")] = None


class CreateParameter(
    IsAutoDeploy[bool],
    Targets[ListOfStrs],
    RunArgs[OptRestart],
    Tag[OptStr],
    RegistryUrl[str],
    FullServiceTypeMixin[ServiceType],
    ServiceKey[str],
):
    tag: Annotated[OptStr, Field(None, description="Tag")] = None
    restart: Annotated[OptRestart, Field(None, description="Restart Policy")] = None

    @classmethod
    def from_data(
        cls,
        data: CreateData,
        service_type: ServiceType,
    ) -> Self:
        return cls.model_validate({**data.model_dump(), "service_type": service_type})


class ReadMultipleParameter(
    ReadPaginatedMultipleParameter,
    FullServiceTypesMixin[OptListOfServiceTypes],
    ServiceKeys[OptListOfStrs],
    UUIDIds[OptListOfUUIDs],
):
    ids: Annotated[OptListOfUUIDs, Field(None, description="Ids")] = None
    service_keys: Annotated[
        OptListOfStrs, Field(None, description="Service's Keys")
    ] = None
    service_types: Annotated[
        OptListOfServiceTypes, Field(None, description="Service Types")
    ] = None

    @classmethod
    def new(
        cls,
        ids: OptListOfUUIDs = None,
        range_filters: ListOfRangeFilters = ListOfRangeFilters(),
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        service_keys: OptListOfStrs = None,
        service_types: OptListOfServiceTypes = None,
        search: OptStr = None,
        sort_columns: ListOfSortColumns = ListOfSortColumns(),
        page: int = 1,
        limit: Limit = Limit.LIM_10,
        use_cache: bool = True,
    ) -> Self:
        return cls(
            ids=ids,
            service_keys=service_keys,
            service_types=service_types,
            range_filters=range_filters,
            statuses=statuses,
            search=search,
            sort_columns=sort_columns,
            page=page,
            limit=limit,
            use_cache=use_cache,
        )

    @property
    def _query_param_fields(self) -> set[str]:
        return {
            "ids",
            "statuses",
            "service_keys",
            "service_types",
            "search",
            "page",
            "limit",
            "use_cache",
        }

    def to_query_params(self) -> StrToAnyDict:
        params = self.model_dump(
            mode="json", include=self._query_param_fields, exclude_none=True
        )
        params["filters"] = convert_filter(self.range_filters)
        params["sorts"] = convert_sort(self.sort_columns)
        params = {k: v for k, v in params.items()}
        return params


class ReadSingleParameter(BaseReadSingleParameter[DeploymentConfigurationIdentifier]):
    @classmethod
    def from_identifier(
        cls,
        identifier: DeploymentConfigurationIdentifier,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter":
        return cls(identifier=identifier, statuses=statuses, use_cache=use_cache)

    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.ID],
        identifier_value: UUID,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.SERVICE_KEY],
        identifier_value: str,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter": ...
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        statuses: ListOfDataStatuses = FULL_DATA_STATUSES,
        use_cache: bool = True,
    ) -> "ReadSingleParameter":
        return cls(
            identifier=DeploymentConfigurationIdentifier(
                type=identifier_type, value=identifier_value
            ),
            statuses=statuses,
            use_cache=use_cache,
        )

    def to_query_params(self) -> StrToAnyDict:
        return self.model_dump(
            mode="json", include={"statuses", "use_cache"}, exclude_none=True
        )


class FullUpdateData(
    IsAutoDeploy[bool],
    Targets[ListOfStrs],
    RunArgs[Restart],
    Tag[str],
    RegistryUrl[str],
):
    pass


class PartialUpdateData(
    IsAutoDeploy[OptBool],
    Targets[OptListOfStrs],
    RunArgs[OptRestart],
    Tag[OptStr],
    RegistryUrl[OptStr],
):
    registry_url: Annotated[OptStr, Field(None, description="Registry URL")] = None
    tag: Annotated[OptStr, Field(None, description="Tag")] = None
    restart: Annotated[OptRestart, Field(None, description="Restart Policy")] = None
    volumes: Annotated[
        OptListOfStrs, Field(None, description="Volumes", min_length=1)
    ] = None
    extra: Annotated[OptListOfStrs, Field(None, description="Extra", min_length=1)] = (
        None
    )
    targets: Annotated[
        OptListOfStrs, Field(None, description="Targets", min_length=1)
    ] = None
    is_auto_deploy: Annotated[
        OptBool, Field(None, description="Whether is auto deploy")
    ] = None


AnyUpdateData = FullUpdateData | PartialUpdateData


class UpdateDataMixin[T: AnyUpdateData](BaseModel):
    data: Annotated[T, Field(..., description="Update data")]


class UpdateParameter[T: AnyUpdateData](
    UpdateDataMixin[T],
    IdentifierMixin[DeploymentConfigurationIdentifier],
):
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.ID],
        identifier_value: UUID,
        data: T,
    ) -> "UpdateParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.SERVICE_KEY],
        identifier_value: str,
        data: T,
    ) -> "UpdateParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        data: T,
    ) -> "UpdateParameter": ...
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        data: T,
    ) -> "UpdateParameter":
        return cls(
            identifier=DeploymentConfigurationIdentifier(
                type=identifier_type, value=identifier_value
            ),
            data=data,
        )


class StatusUpdateParameter(
    BaseStatusUpdateParameter[DeploymentConfigurationIdentifier],
):
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.ID],
        identifier_value: UUID,
        type: ResourceOperationStatusUpdateType,
    ) -> "StatusUpdateParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: Literal[IdentifierType.SERVICE_KEY],
        identifier_value: str,
        type: ResourceOperationStatusUpdateType,
    ) -> "StatusUpdateParameter": ...
    @overload
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        type: ResourceOperationStatusUpdateType,
    ) -> "StatusUpdateParameter": ...
    @classmethod
    def new(
        cls,
        identifier_type: IdentifierType,
        identifier_value: IdentifierValueType,
        type: ResourceOperationStatusUpdateType,
    ) -> "StatusUpdateParameter":
        return cls(
            identifier=DeploymentConfigurationIdentifier(
                type=identifier_type, value=identifier_value
            ),
            type=type,
        )


class DeleteSingleParameter(
    BaseDeleteSingleParameter[DeploymentConfigurationIdentifier]
):
    @overload
    @classmethod
    def new(
        cls, identifier_type: Literal[IdentifierType.ID], identifier_value: UUID
    ) -> "DeleteSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls, identifier_type: Literal[IdentifierType.SERVICE_KEY], identifier_value: str
    ) -> "DeleteSingleParameter": ...
    @overload
    @classmethod
    def new(
        cls, identifier_type: IdentifierType, identifier_value: IdentifierValueType
    ) -> "DeleteSingleParameter": ...
    @classmethod
    def new(
        cls, identifier_type: IdentifierType, identifier_value: IdentifierValueType
    ) -> "DeleteSingleParameter":
        return cls(
            identifier=DeploymentConfigurationIdentifier(
                type=identifier_type, value=identifier_value
            )
        )


class DeploymentConfigurationSchema(
    Targets[ListOfStrs],
    RunArgs[Restart],
    Tag[str],
    RegistryUrl[str],
    Service,
    SimpleDataStatusMixin[DataStatus],
    UUIDId[UUID],
):
    pass
