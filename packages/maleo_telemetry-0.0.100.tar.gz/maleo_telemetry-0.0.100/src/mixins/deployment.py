from typing import Annotated, Literal, TypeGuard
from uuid import UUID

from nexo.schemas.mixins.identity import Identifier
from pydantic import Field

from ..enums.deployment import IdentifierType
from ..types.deployment import IdentifierValueType


class DeploymentIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    @property
    def column_and_value(self) -> tuple[str, IdentifierValueType]:
        return self.type.column, self.value


class IdDeploymentIdentifier(Identifier[Literal[IdentifierType.ID], UUID]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID


AnyDeploymentIdentifier = DeploymentIdentifier | IdDeploymentIdentifier


def is_id_identifier(
    identifier: AnyDeploymentIdentifier,
) -> TypeGuard[IdDeploymentIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, UUID)
