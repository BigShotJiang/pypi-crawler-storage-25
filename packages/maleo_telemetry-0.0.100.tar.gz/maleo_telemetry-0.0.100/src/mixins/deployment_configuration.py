from typing import Annotated, Literal, TypeGuard
from uuid import UUID

from nexo.schemas.mixins.identity import Identifier
from nexo.types.boolean import OptBool
from nexo.types.string import OptListOfStrs, OptStr
from nexo.types.uuid import OptListOfUUIDs, OptUUID
from pydantic import BaseModel, Field

from ..enums.deployment_configuration import IdentifierType
from ..types.deployment_configuration import IdentifierValueType


class ConfigurationId[T: OptUUID](BaseModel):
    configuration_id: Annotated[T, Field(..., description="Configuration's ID")]


class ConfigurationIds[T: OptListOfUUIDs](BaseModel):
    configuration_ids: Annotated[
        T, Field(..., description="Configuration's IDs", min_length=1)
    ]


class Registry[T: OptStr](BaseModel):
    registry: Annotated[T, Field(..., description="Registry")]


class RegistryUrl[T: OptStr](BaseModel):
    registry_url: Annotated[T, Field(..., description="Registry URL")]


class Tag[T: OptStr](BaseModel):
    tag: Annotated[T, Field(..., description="Tag")]


class Volumes[T: OptListOfStrs](BaseModel):
    volumes: Annotated[T, Field(..., description="Volumes", min_length=1)]


class Extra[T: OptListOfStrs](BaseModel):
    extra: Annotated[T, Field(..., description="Extra", min_length=1)]


class Target[T: OptStr](BaseModel):
    target: Annotated[T, Field(..., description="Target")]


class Targets[T: OptListOfStrs](BaseModel):
    targets: Annotated[T, Field(..., description="Targets", min_length=1)]


class IsAutoDeploy[T: OptBool](BaseModel):
    is_auto_deploy: Annotated[T, Field(..., description="Whether is auto deploy")]


class DeploymentConfigurationIdentifier(
    Identifier[IdentifierType, IdentifierValueType]
):
    @property
    def column_and_value(self) -> tuple[str, IdentifierValueType]:
        return self.type.column, self.value


class IdDeploymentConfigurationIdentifier(Identifier[Literal[IdentifierType.ID], UUID]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID


class ServiceKeyDeploymentConfigurationIdentifier(
    Identifier[Literal[IdentifierType.SERVICE_KEY], str]
):
    type: Annotated[
        Literal[IdentifierType.SERVICE_KEY],
        Field(IdentifierType.SERVICE_KEY, description="Identifier's type"),
    ] = IdentifierType.SERVICE_KEY


AnyDeploymentConfigurationIdentifier = (
    DeploymentConfigurationIdentifier
    | IdDeploymentConfigurationIdentifier
    | ServiceKeyDeploymentConfigurationIdentifier
)


def is_id_identifier(
    identifier: AnyDeploymentConfigurationIdentifier,
) -> TypeGuard[IdDeploymentConfigurationIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, UUID)


def is_service_key_identifier(
    identifier: AnyDeploymentConfigurationIdentifier,
) -> TypeGuard[ServiceKeyDeploymentConfigurationIdentifier]:
    return identifier.type is IdentifierType.SERVICE_KEY and isinstance(
        identifier.value, str
    )
