from datetime import datetime
from typing import Annotated

from maleo.identity.schemas.service import StandardServiceSchema
from nexo.enums.environment import Environment, EnvironmentMixin
from nexo.types.datetime import OptDatetime
from nexo.types.string import OptListOfStrs, OptStr
from pydantic import BaseModel, Field


class MessageId[T: OptStr](BaseModel):
    message_id: Annotated[T, Field(..., description="Message's ID")]


class MessageIds[T: OptListOfStrs](BaseModel):
    message_ids: Annotated[T, Field(..., description="Message's IDs", min_length=1)]


class Message[T: BaseModel | None](BaseModel):
    message: Annotated[T, Field(..., description="Message")]


class PublishedAt[T: OptDatetime](BaseModel):
    published_at: Annotated[T, Field(..., description="Published At")]


class MessageInfo(PublishedAt[datetime], MessageId[str]):
    pass


class InstanceId(BaseModel):
    instance_id: Annotated[str, Field(..., description="Instance's ID")]


class InstanceIds[T: OptListOfStrs](BaseModel):
    instance_ids: Annotated[T, Field(..., description="Instance's IDs", min_length=1)]


class ServiceKey[T: OptStr](BaseModel):
    service_key: Annotated[T, Field(..., description="Service's Key")]


class ServiceKeys[T: OptListOfStrs](BaseModel):
    service_keys: Annotated[T, Field(..., description="Service's Keys", min_length=1)]


class Service(BaseModel):
    service: Annotated[StandardServiceSchema, Field(..., description="Service")]


class ApplicationContext(
    ServiceKey[str],
    EnvironmentMixin[Environment],
    InstanceId,
):
    pass
