from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class IdentifierType(StrEnum):
    ID = "id"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]

    @property
    def column(self) -> str:
        return self.value


class Trigger(StrEnum):
    MANUAL = "manual"
    MESSAGE = "message"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptTrigger = Trigger | None


class TriggerMixin[T: OptTrigger](BaseModel):
    trigger: Annotated[T, Field(..., description="Trigger")]
