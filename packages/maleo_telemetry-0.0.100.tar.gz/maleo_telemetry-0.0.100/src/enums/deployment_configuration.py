from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class IdentifierType(StrEnum):
    ID = "id"
    SERVICE_KEY = "service_key"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]

    @property
    def column(self) -> str:
        return self.value


class Restart(StrEnum):
    NO = "no"
    ALWAYS = "always"
    UNLESS_STOPPED = "unless-stopped"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptRestart = Restart | None


class RestartMixin[T: OptRestart](BaseModel):
    restart: Annotated[T, Field(..., description="Restart Policy")]
