"""Read/write ~/.sintropi/config.json and ~/.sintropi/credentials.json.

config.json:
{
  "current": "https://gateway.acme.eight20.com",
  "gateways": {
    "https://gateway.acme.eight20.com": {
      "keycloak_url": "https://auth.acme.eight20.com",
      "realm": "acme",
      "client_id": "sintropi-cli",
      "current_sha": "abc123...",
      "current_version": "2605.11.1545",
      "last_check": "2025-05-11T16:30:00Z"
    }
  }
}

credentials.json (per-gateway map):
{
  "https://gateway.acme.eight20.com": {
    "access_token": "...",
    "refresh_token": "...",
    "expires_at": 1715450000,
    "token_type": "Bearer"
  }
}
"""

import json
import time
from typing import Optional

from .paths import CONFIG_FILE, CREDENTIALS_FILE, ensure_home


def _load(path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _save(path, data: dict) -> None:
    ensure_home()
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    if path == CREDENTIALS_FILE:
        try:
            path.chmod(0o600)
        except OSError:
            pass


def load_config() -> dict:
    cfg = _load(CONFIG_FILE)
    cfg.setdefault("gateways", {})
    cfg.setdefault("current", None)
    return cfg


def save_config(cfg: dict) -> None:
    _save(CONFIG_FILE, cfg)


def get_gateway_entry(cfg: dict, gateway_url: str) -> dict:
    return cfg["gateways"].setdefault(gateway_url, {})


def set_current_gateway(gateway_url: str) -> None:
    cfg = load_config()
    cfg["current"] = gateway_url
    cfg["gateways"].setdefault(gateway_url, {})
    save_config(cfg)


def current_gateway() -> Optional[str]:
    return load_config().get("current")


def update_gateway_meta(
    gateway_url: str,
    keycloak_url: str,
    realm: str,
    client_id: str,
    current_sha: str,
    current_version: str,
) -> None:
    cfg = load_config()
    entry = get_gateway_entry(cfg, gateway_url)
    entry.update({
        "keycloak_url": keycloak_url,
        "realm": realm,
        "client_id": client_id,
        "current_sha": current_sha,
        "current_version": current_version,
        "last_check": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    })
    save_config(cfg)


def load_credentials() -> dict:
    return _load(CREDENTIALS_FILE)


def save_credentials(creds: dict) -> None:
    _save(CREDENTIALS_FILE, creds)


def get_token_for(gateway_url: str) -> Optional[dict]:
    return load_credentials().get(gateway_url)


def set_token_for(gateway_url: str, token: dict) -> None:
    creds = load_credentials()
    creds[gateway_url] = token
    save_credentials(creds)
