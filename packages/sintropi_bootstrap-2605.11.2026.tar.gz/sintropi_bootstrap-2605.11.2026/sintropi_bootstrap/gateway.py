"""HTTP client for the gateway bootstrap endpoints.

Endpoints (provided by sintropi-gateway):
- GET /api/bootstrap/config  (public) → keycloak_url, realm, client_id, current_sha, current_version
- GET /api/bootstrap/download (Bearer + realm role 'sintropi-code') → wheel bytes (octet-stream)
"""

import hashlib

import requests

DEFAULT_TIMEOUT = 30
DOWNLOAD_TIMEOUT = 600
CHUNK_SIZE = 256 * 1024  # 256 KB


class GatewayUnavailableError(RuntimeError):
    """Raised when the gateway is temporarily unreachable (502/503/504)."""


def _extract_message(resp) -> str:
    """Return the human-readable message from an error response body."""
    try:
        body = resp.json()
        return body.get("message") or body.get("error") or resp.text[:300]
    except ValueError:
        return resp.text[:300] or f"HTTP {resp.status_code}"


def fetch_config(gateway_url: str) -> dict:
    """Returns: { keycloak_url, realm, client_id, current_sha, current_version, package_name }."""
    url = f"{gateway_url.rstrip('/')}/api/bootstrap/config"
    try:
        resp = requests.get(url, timeout=DEFAULT_TIMEOUT)
    except requests.exceptions.ConnectionError:
        raise GatewayUnavailableError(
            f"Impossibile connettersi al gateway: {gateway_url}\n"
            "  Verifica che l'URL sia corretto e che il servizio sia raggiungibile."
        )
    except requests.exceptions.Timeout:
        raise GatewayUnavailableError(
            f"Timeout durante la connessione al gateway ({DEFAULT_TIMEOUT}s)."
        )

    if resp.status_code in (502, 503, 504):
        msg = _extract_message(resp)
        raise GatewayUnavailableError(
            f"Il gateway è temporaneamente non disponibile (HTTP {resp.status_code}).\n"
            f"  Dettaglio: {msg}\n"
            "  Il servizio builder potrebbe essere in fase di avvio — riprova tra qualche secondo."
        )
    if resp.status_code != 200:
        msg = _extract_message(resp)
        raise RuntimeError(
            f"Errore dal gateway (HTTP {resp.status_code}): {msg}"
        )

    data = resp.json()
    required = {"keycloak_url", "realm", "client_id", "current_sha", "current_version"}
    missing = required - data.keys()
    if missing:
        raise RuntimeError(f"Risposta config gateway invalida — campi mancanti: {missing}")
    return data


class MissingRoleError(PermissionError):
    """Raised when the gateway returns 403 with code=MISSING_ROLE."""

    def __init__(self, payload: dict):
        self.payload = payload
        super().__init__(payload.get("message", "Ruolo mancante"))


def download_wheel(gateway_url: str, access_token: str, dest_path) -> tuple[int, str]:
    """Stream the wheel to dest_path. Returns (bytes_written, sha256_hex)."""
    url = f"{gateway_url.rstrip('/')}/api/bootstrap/download"
    headers = {"Authorization": f"Bearer {access_token}"}

    with requests.get(url, headers=headers, stream=True, timeout=DOWNLOAD_TIMEOUT) as resp:
        if resp.status_code == 401:
            raise PermissionError("Token non valido o scaduto")
        if resp.status_code == 403:
            payload = {}
            try:
                payload = resp.json()
            except ValueError:
                pass
            if payload.get("code") == "MISSING_ROLE":
                raise MissingRoleError(payload)
            raise PermissionError(
                payload.get("message")
                or "Permesso negato: serve il ruolo realm 'sintropi-code' per scaricare l'engine"
            )
        if resp.status_code != 200:
            raise RuntimeError(f"Download fallito ({resp.status_code}): {resp.text[:500]}")

        sha = hashlib.sha256()
        total = 0
        with open(dest_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=CHUNK_SIZE):
                if not chunk:
                    continue
                f.write(chunk)
                sha.update(chunk)
                total += len(chunk)

    return total, sha.hexdigest()
