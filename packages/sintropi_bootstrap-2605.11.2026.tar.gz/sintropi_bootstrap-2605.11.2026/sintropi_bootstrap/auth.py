"""Token lifecycle: load → refresh if expired → fall back to PKCE login."""

from . import config, keycloak


def get_valid_token(
    gateway_url: str,
    keycloak_url: str,
    realm: str,
    client_id: str,
    force_login: bool = False,
) -> str:
    """Return a valid access_token for the given gateway, refreshing or
    re-running the PKCE flow as needed.
    """
    existing = None if force_login else config.get_token_for(gateway_url)

    if existing and not keycloak.token_expired(existing):
        return existing["access_token"]

    if existing and existing.get("refresh_token"):
        try:
            refreshed = keycloak.refresh_token(
                keycloak_url, realm, client_id, existing["refresh_token"],
            )
            config.set_token_for(gateway_url, refreshed)
            return refreshed["access_token"]
        except Exception:
            pass  # fall through to fresh login

    token = keycloak.login_pkce(keycloak_url, realm, client_id)
    config.set_token_for(gateway_url, token)
    return token["access_token"]
