"""Filesystem layout shared between sintropi-bootstrap and sintropi-code."""

import os
from pathlib import Path

# Allow override for tests / containers
HOME = Path(os.environ.get("SINTROPI_HOME", str(Path.home() / ".sintropi")))

CREDENTIALS_FILE = HOME / "credentials.json"
CONFIG_FILE = HOME / "config.json"
VERSIONS_DIR = HOME / "versions"


def ensure_home() -> Path:
    HOME.mkdir(parents=True, exist_ok=True)
    VERSIONS_DIR.mkdir(parents=True, exist_ok=True)
    return HOME


def version_dir(sha: str) -> Path:
    return VERSIONS_DIR / sha


def venv_dir(sha: str) -> Path:
    return version_dir(sha) / ".venv"


def venv_python(sha: str) -> Path:
    if os.name == "nt":
        return venv_dir(sha) / "Scripts" / "python.exe"
    return venv_dir(sha) / "bin" / "python"
