"""sintropi-bootstrap — thin client that authenticates against a Sintropi gateway
and installs the matching sintropi-code engine version locally.

Two console scripts:
- `sintropi-bootstrap <gateway>` — idempotent setup/switch
- `sintropi-code [args]` — launcher that auto-detects + dispatches engine version
"""

__version__ = "0.0.0"
