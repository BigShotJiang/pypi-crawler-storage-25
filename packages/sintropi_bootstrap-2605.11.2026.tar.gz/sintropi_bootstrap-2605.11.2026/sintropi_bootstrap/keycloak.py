"""Authorization Code + PKCE flow on a loopback redirect (RFC 8252).

Used by sintropi-bootstrap to authenticate against Keycloak without storing
a client secret. Spins up a temporary HTTP server on a random localhost port,
opens the browser on Keycloak's auth endpoint, captures the redirect with the
auth code, and exchanges the code for a token.
"""

import base64
import hashlib
import http.server
import secrets
import socket
import sys
import threading
import time
import urllib.parse
import webbrowser

import requests

DEFAULT_SCOPES = "openid profile email offline_access"
CALLBACK_TIMEOUT_SECONDS = 300  # 5 minutes


def _pkce_pair() -> tuple[str, str]:
    verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).rstrip(b"=").decode()
    challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode()).digest()
    ).rstrip(b"=").decode()
    return verifier, challenge


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def login_pkce(
    keycloak_url: str,
    realm: str,
    client_id: str,
    open_browser: bool = True,
    scopes: str = DEFAULT_SCOPES,
) -> dict:
    """Run the full PKCE login flow and return the token response dict.

    Returned dict contains: access_token, refresh_token, expires_in,
    refresh_expires_in, token_type, scope, id_token.
    """
    verifier, challenge = _pkce_pair()
    state = secrets.token_urlsafe(24)
    port = _find_free_port()
    redirect_uri = f"http://localhost:{port}/callback"

    auth_url = (
        f"{keycloak_url.rstrip('/')}/realms/{realm}/protocol/openid-connect/auth?"
        + urllib.parse.urlencode({
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": scopes,
            "state": state,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
        })
    )

    captured = {}
    done_event = threading.Event()

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            params = {k: v[0] for k, v in urllib.parse.parse_qs(parsed.query).items()}
            captured.update(params)

            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            if "code" in params:
                msg = (
                    "<!doctype html><html><head><title>Sintropi</title></head>"
                    "<body style='font-family:sans-serif;text-align:center;margin-top:80px'>"
                    "<h1>Login completato</h1>"
                    "<p>Puoi chiudere questa finestra e tornare al terminale.</p>"
                    "</body></html>"
                )
            else:
                err = params.get("error", "unknown_error")
                desc = params.get("error_description", "")
                msg = f"<h1>Errore: {err}</h1><p>{desc}</p>"
            self.wfile.write(msg.encode("utf-8"))
            done_event.set()

        def log_message(self, *_):
            pass  # suppress noisy stdout

    server = http.server.HTTPServer(("127.0.0.1", port), Handler)
    server.timeout = CALLBACK_TIMEOUT_SECONDS

    print(f"\nApri questo URL nel browser per autenticarti:\n  {auth_url}\n", file=sys.stderr)
    if open_browser:
        try:
            webbrowser.open(auth_url)
        except Exception:
            pass

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    if not done_event.wait(timeout=CALLBACK_TIMEOUT_SECONDS):
        server.shutdown()
        raise TimeoutError(
            f"Timeout dopo {CALLBACK_TIMEOUT_SECONDS}s in attesa del redirect Keycloak"
        )

    server.shutdown()

    if "error" in captured:
        raise RuntimeError(
            f"Errore login Keycloak: {captured['error']} — {captured.get('error_description', '')}"
        )

    if captured.get("state") != state:
        raise RuntimeError("State mismatch: possibile attacco CSRF, login rifiutato")

    code = captured.get("code")
    if not code:
        raise RuntimeError("Nessun authorization code ricevuto dal redirect")

    token = exchange_code(keycloak_url, realm, client_id, code, redirect_uri, verifier)
    token["_obtained_at"] = int(time.time())
    return token


def exchange_code(
    keycloak_url: str,
    realm: str,
    client_id: str,
    code: str,
    redirect_uri: str,
    verifier: str,
) -> dict:
    resp = requests.post(
        f"{keycloak_url.rstrip('/')}/realms/{realm}/protocol/openid-connect/token",
        data={
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
            "client_id": client_id,
            "code_verifier": verifier,
        },
        timeout=30,
    )
    if resp.status_code != 200:
        raise RuntimeError(
            f"Token exchange fallito ({resp.status_code}): {resp.text}"
        )
    return resp.json()


def refresh_token(keycloak_url: str, realm: str, client_id: str, refresh_token: str) -> dict:
    resp = requests.post(
        f"{keycloak_url.rstrip('/')}/realms/{realm}/protocol/openid-connect/token",
        data={
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
        },
        timeout=30,
    )
    if resp.status_code != 200:
        raise RuntimeError(f"Refresh fallito ({resp.status_code}): {resp.text}")
    token = resp.json()
    token["_obtained_at"] = int(time.time())
    return token


def token_expired(token: dict, margin_seconds: int = 30) -> bool:
    obtained = token.get("_obtained_at", 0)
    expires_in = token.get("expires_in", 0)
    return time.time() >= (obtained + expires_in - margin_seconds)
