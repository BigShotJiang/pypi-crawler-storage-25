"""Human-readable messages shared between sintropi-bootstrap and sintropi-code."""

import sys


def print_missing_role_guide(payload: dict, *, stream=sys.stderr) -> None:
    """Render the 'request access' panel when the gateway returned 403 / MISSING_ROLE."""
    required = payload.get("required_role", "sintropi-code")
    realm = payload.get("realm", "")
    user = payload.get("user", "")
    admin_url = payload.get("keycloak_admin_url", "")
    message = payload.get("message", "")

    bar = "─" * 72
    print(f"\n{bar}", file=stream)
    print(" Permesso negato: ruolo mancante", file=stream)
    print(bar, file=stream)
    print(file=stream)
    print(f" Utente:        {user}", file=stream)
    print(f" Realm:         {realm}", file=stream)
    print(f" Ruolo serve:   {required}", file=stream)
    print(file=stream)
    print(" Come richiedere l'accesso:", file=stream)
    print(file=stream)
    print(
        f" 1. Contatta l'amministratore Keycloak del realm '{realm}' e chiedi",
        file=stream,
    )
    print(f"    di assegnarti il ruolo realm '{required}'.", file=stream)
    print(file=stream)
    if admin_url:
        print(" 2. L'admin può farlo dalla console Keycloak:", file=stream)
        print(f"    {admin_url}", file=stream)
        if user:
            print(f"    → Users → {user} → Role mapping → Assign role → {required}", file=stream)
        else:
            print(f"    → Users → <tuo utente> → Role mapping → Assign role → {required}",
                  file=stream)
        print(file=stream)
    print(
        " 3. Una volta assegnato il ruolo, rilancia lo stesso comando:",
        file=stream,
    )
    print("    il token verrà rinnovato automaticamente e il download partirà.", file=stream)
    print(file=stream)
    if message:
        print(f" Dettaglio dal server: {message}", file=stream)
    print(bar + "\n", file=stream)
