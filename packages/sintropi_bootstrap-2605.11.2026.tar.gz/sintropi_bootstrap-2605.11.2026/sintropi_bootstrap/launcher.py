"""sintropi-code launcher — verifies version, auto-updates, exec's into engine venv.

Workflow on each invocation:
1. Read current gateway from ~/.sintropi/config.json
2. Hit GET {gateway}/api/bootstrap/config (with TTL cache, 5 min) → expected_sha
3. If versions/{expected_sha}/.venv missing → re-auth + download + install
4. exec {venv}/bin/python -m sintropi_agents.main <args>
"""

import os
import sys
import tempfile
import time
from pathlib import Path

from . import auth, config, gateway, installer, messages
from .paths import ensure_home, venv_python

CHECK_INTERVAL_SECONDS = 300  # 5 minutes — TTL on /api/bootstrap/config


def _should_check(entry: dict) -> bool:
    last = entry.get("last_check")
    if not last:
        return True
    try:
        ts = time.strptime(last, "%Y-%m-%dT%H:%M:%SZ")
        last_epoch = int(time.mktime(ts))
    except ValueError:
        return True
    return (time.time() - last_epoch) > CHECK_INTERVAL_SECONDS


def cli():
    ensure_home()

    args = sys.argv[1:]

    explicit_gateway = None
    if args and args[0] == "--gateway" and len(args) >= 2:
        explicit_gateway = args[1].rstrip("/")
        args = args[2:]

    cfg = config.load_config()
    gateway_url = explicit_gateway or cfg.get("current")

    if not gateway_url:
        sys.stderr.write(
            "Nessun gateway configurato.\n"
            "Lancia prima: sintropi-bootstrap https://gateway.acme.eight20.com\n"
        )
        sys.exit(1)

    entry = cfg.get("gateways", {}).get(gateway_url, {})
    expected_sha = entry.get("current_sha")
    keycloak_url = entry.get("keycloak_url")
    realm = entry.get("realm")
    client_id = entry.get("client_id")

    if not expected_sha or _should_check(entry):
        try:
            fresh = gateway.fetch_config(gateway_url)
            expected_sha = fresh["current_sha"]
            keycloak_url = fresh["keycloak_url"]
            realm = fresh["realm"]
            client_id = fresh["client_id"]
            config.update_gateway_meta(
                gateway_url, keycloak_url, realm, client_id,
                expected_sha, fresh["current_version"],
            )
        except Exception as e:
            if not expected_sha:
                sys.stderr.write(f"Impossibile leggere config gateway: {e}\n")
                sys.exit(1)
            sys.stderr.write(
                f"[warn] gateway irraggiungibile ({e}), uso cache locale\n"
            )

    if not venv_python(expected_sha).exists():
        sys.stderr.write(
            f"→ Scarico engine sha {expected_sha[:12]} per {gateway_url}\n"
        )
        try:
            token = auth.get_valid_token(gateway_url, keycloak_url, realm, client_id)
        except Exception as e:
            sys.stderr.write(f"Autenticazione fallita: {e}\n")
            sys.exit(1)

        with tempfile.NamedTemporaryFile(
            prefix="sintropi-engine-", suffix=".whl", delete=False,
        ) as tmp:
            wheel_path = Path(tmp.name)
        try:
            _, sha256 = gateway.download_wheel(gateway_url, token, wheel_path)
            installer.install_engine(
                expected_sha, wheel_path,
                entry.get("current_version", "unknown"),
                gateway_url, sha256,
            )
        except gateway.MissingRoleError as e:
            messages.print_missing_role_guide(e.payload)
            sys.exit(2)
        except PermissionError as e:
            sys.stderr.write(f"{e}\n")
            sys.exit(2)
        except Exception as e:
            sys.stderr.write(f"Download/install fallito: {e}\n")
            sys.exit(1)
        finally:
            wheel_path.unlink(missing_ok=True)

    python = str(venv_python(expected_sha))
    exec_args = [python, "-m", "sintropi_agents.main", *args]
    os.execv(python, exec_args)


if __name__ == "__main__":
    cli()
