"""sintropi-bootstrap CLI — idempotent setup/switch entrypoint."""

import sys
import tempfile
from pathlib import Path

import click

from . import auth, config, gateway, installer, messages
from .paths import ensure_home


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.argument("gateway_url")
@click.option(
    "--force-login",
    is_flag=True,
    help="Re-run PKCE login anche se esistono già credenziali valide.",
)
def cli(gateway_url: str, force_login: bool):
    """Configura un gateway Sintropi (dev/qa/prod/customer) e scarica
    l'engine sintropi-code corrispondente.

    Idempotente: rilanciato con un altro gateway, fa lo switch dell'ambiente
    attivo e (se necessario) scarica la versione dell'engine relativa.
    """
    gateway_url = gateway_url.rstrip("/")
    ensure_home()

    click.echo(f"→ Leggo config del gateway: {gateway_url}")
    try:
        cfg = gateway.fetch_config(gateway_url)
    except gateway.GatewayUnavailableError as e:
        click.echo(f"  ✗ {e}", err=True)
        sys.exit(2)
    except Exception as e:
        click.echo(f"  ✗ {e}", err=True)
        sys.exit(1)

    keycloak_url = cfg["keycloak_url"]
    realm = cfg["realm"]
    client_id = cfg["client_id"]
    current_sha = cfg["current_sha"]
    current_version = cfg["current_version"]

    click.echo(f"  ✓ Engine attuale: {current_version} (sha {current_sha[:12]})")

    config.update_gateway_meta(
        gateway_url, keycloak_url, realm, client_id, current_sha, current_version,
    )
    config.set_current_gateway(gateway_url)

    if installer.venv_python(current_sha).exists():
        click.echo(f"  ✓ Engine già in cache: ~/.sintropi/versions/{current_sha[:12]}/")
        click.echo(f"\n✓ Gateway attivo: {gateway_url}")
        click.echo("  Usa: sintropi-code [args]")
        return

    click.echo(f"→ Autenticazione Keycloak ({keycloak_url}, realm '{realm}')")
    try:
        access_token = auth.get_valid_token(
            gateway_url, keycloak_url, realm, client_id, force_login=force_login,
        )
    except Exception as e:
        click.echo(f"  ✗ {e}", err=True)
        sys.exit(1)

    click.echo(f"→ Scarico engine wheel...")
    with tempfile.NamedTemporaryFile(
        prefix="sintropi-engine-", suffix=".whl", delete=False,
    ) as tmp:
        wheel_path = Path(tmp.name)

    try:
        size, sha256 = gateway.download_wheel(gateway_url, access_token, wheel_path)
        click.echo(f"  ✓ {size / 1024:.1f} KB — sha256 {sha256[:16]}...")

        click.echo(f"→ Installo engine in venv isolato...")
        installer.install_engine(
            current_sha, wheel_path, current_version, gateway_url, sha256,
        )
        click.echo(f"  ✓ Installato in ~/.sintropi/versions/{current_sha[:12]}/.venv/")
    except gateway.MissingRoleError as e:
        messages.print_missing_role_guide(e.payload)
        sys.exit(2)
    except PermissionError as e:
        click.echo(f"  ✗ {e}", err=True)
        sys.exit(2)
    except Exception as e:
        click.echo(f"  ✗ {e}", err=True)
        sys.exit(1)
    finally:
        wheel_path.unlink(missing_ok=True)

    click.echo(f"\n✓ Gateway attivo: {gateway_url}")
    click.echo(f"  Engine: sintropi-agents {current_version} (sha {current_sha[:12]})")
    click.echo(f"  Usa: sintropi-code [args]")


if __name__ == "__main__":
    cli()
