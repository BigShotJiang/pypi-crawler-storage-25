"""Per-sha venv creation and wheel install."""

import json
import shutil
import subprocess
import sys
import tempfile
import venv
from pathlib import Path

from .paths import VERSIONS_DIR, venv_dir, venv_python, version_dir


def install_engine(
    sha: str,
    wheel_path: Path,
    version: str,
    gateway_url: str,
    sha256: str,
) -> Path:
    """Create ~/.sintropi/versions/{sha}/.venv and pip install the wheel into it.

    Returns the venv's python executable path.
    Idempotent: if the venv already exists, returns it without reinstalling.
    """
    if venv_python(sha).exists():
        return venv_python(sha)

    target = version_dir(sha)
    target.mkdir(parents=True, exist_ok=True)

    tmp_venv = Path(tempfile.mkdtemp(prefix=f"sintropi-venv-{sha[:8]}-"))
    try:
        venv.create(tmp_venv, with_pip=True, symlinks=(sys.platform != "win32"))
        tmp_python = tmp_venv / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")

        subprocess.run(
            [str(tmp_python), "-m", "pip", "install", "--no-cache-dir", "--quiet", str(wheel_path)],
            check=True,
        )

        final = venv_dir(sha)
        if final.exists():
            shutil.rmtree(final)
        shutil.move(str(tmp_venv), str(final))

        manifest = {
            "sha": sha,
            "version": version,
            "gateway_url": gateway_url,
            "wheel_filename": wheel_path.name,
            "sha256": sha256,
        }
        (target / "manifest.json").write_text(
            json.dumps(manifest, indent=2), encoding="utf-8"
        )

        return venv_python(sha)
    except Exception:
        shutil.rmtree(tmp_venv, ignore_errors=True)
        raise


def list_installed_versions() -> list[dict]:
    if not VERSIONS_DIR.exists():
        return []
    out = []
    for d in sorted(VERSIONS_DIR.iterdir()):
        manifest = d / "manifest.json"
        if manifest.exists():
            try:
                out.append(json.loads(manifest.read_text(encoding="utf-8")))
            except json.JSONDecodeError:
                pass
    return out
