from collections import defaultdict
from typing import List, Dict

from loguru import logger

from pit38.domain.stock.operations.service_fee import ServiceFee
from pit38.domain.stock.operations.dividend import Dividend
from pit38.domain.stock.operations.stock_split import StockSplit
from pit38.domain.stock.profit.per_stock_calculator import PerStockProfitCalculator
from pit38.domain.tax_service.profit_per_year import ProfitPerYear
from pit38.domain.stock.profit.stock_split_handler import StockSplitHandler
from pit38.domain.transactions.transaction import Transaction
from pit38.domain.currency_exchange_service.exchanger import Exchanger


class ProfitCalculator:
    def __init__(self, exchanger: Exchanger, per_stock_calculator: PerStockProfitCalculator):
        self.exchanger = exchanger
        self.per_stock_calculator = per_stock_calculator
    def calculate_cumulative_cost_and_income(
        self,
        transactions: List[Transaction],
        stock_splits: List[StockSplit],
        dividends: List[Dividend],
        service_fees: List[ServiceFee]) -> ProfitPerYear:

        profit_from_transactions = self.handle_transactions(transactions, stock_splits, service_fees)
        profit_from_dividends = self.handle_dividends(dividends)

        return profit_from_transactions, profit_from_dividends

    def handle_transactions(
        self,
        transactions: List[Transaction],
        stock_splits: List[StockSplit],
        service_fees: List[ServiceFee]) -> ProfitPerYear:

        profit_transactions = ProfitPerYear()
        stock_splits_by_company = self._group_stock_split_by_stock(stock_splits)

        for company, transactions in self._group_transaction_by_stock(transactions).items():
            transactions_adjusted = StockSplitHandler.incorporate_stock_splits_into_transactions(
                transactions, stock_splits_by_company[company])
            profit_transactions += self.per_stock_calculator.calculate_cost_and_income(transactions_adjusted)

        logger.info("Processing service fees")
        for service_fee in service_fees:
            cost = self.exchanger.exchange(service_fee.date, service_fee.value)
            profit_transactions.add_cost(service_fee.date.year, cost)

        logger.info(f"Profit per year from transactions: {profit_transactions}")
        return profit_transactions

    def handle_dividends(self, dividends: List[Dividend]) -> ProfitPerYear:
        profit_dividends = ProfitPerYear()

        for dividend in dividends:
            income = self.exchanger.exchange(dividend.date, dividend.value)
            profit_dividends.add_income(dividend.date.year, income)

        logger.info(f"Profit per year from dividends: {profit_dividends}")
        return profit_dividends

    def _group_transaction_by_stock(self, transactions: List[Transaction]) -> Dict[str, List[Transaction]]:
        grouped_transactions = defaultdict(list)
        for transaction in transactions:
            company_name = transaction.asset.asset_name
            grouped_transactions[company_name].append(transaction)
        return grouped_transactions

    def _group_stock_split_by_stock(self, stock_splits: List[StockSplit]) -> Dict[str, List[StockSplit]]:
        stock_splits_by_stock = defaultdict(list)
        for stock_split in stock_splits:
            stock_splits_by_stock[stock_split.stock].append(stock_split)
        return stock_splits_by_stock
