"""Tests for the addressed-formations eat() path.

Commit 2 of 5 in the §RECOUPLE.IN.PLACE follow-up. With
``addressed_formations=True`` the engine maintains a
``formation_index: dict[str, Formation]`` incrementally — eat() files
each new crystal into its grammar-address bucket via
``_file_into_formation``, ``rebuild_formations`` short-circuits the
detect_formations BFS, and Formation aggregates update via
``Formation.update_with`` per crystal.

These tests pin the addressed path's correctness:
  - crystals get a ``.formation`` address set
  - the formation_index grows by address, not by graph component
  - aggregate fields (cognitive_centroid, mean_ache, compression_score)
    converge to values close to what detect_formations would compute
    over the same member set
  - default flag (off) leaves legacy behavior untouched

Default behavior (flag off) is unchanged — the legacy eat path still
works and still calls detect_formations. That coverage lives in the
existing test suite.
"""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from linafish.engine import FishEngine
from linafish.formations import formation_address


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_engine(state_dir, addressed=False):
    return FishEngine(
        state_dir=Path(state_dir),
        name="addressed_test",
        git_autocommit=False,
        addressed_formations=addressed,
    )


def _seed_corpus(engine, n_texts):
    patterns = [
        "The architecture demands clarity at every layer of the system.",
        "She walked through the garden where the marigolds had taken over.",
        "We measured the throughput at fifteen requests per second average.",
        "The grief shifted from a wave to a tide to weather you live in.",
        "Compression is understanding. Storage is just where the bits sit.",
        "Every formation is a verb made of crystals doing something together.",
        "I told the story differently each time and the truth did not change.",
        "Substrate first means asking the disk before trusting the memory.",
        "Marcus walked on Sundays and pointed at the architectural details.",
        "She kept rocks in a jar and could tell you the story of every one.",
    ]
    texts = [
        f"Entry {i}: {patterns[i % 10]} Note {i // 7} on iteration {i}."
        for i in range(n_texts)
    ]
    engine.eat_many(texts, source="seed")


# ---------------------------------------------------------------------------
# Default (flag off) — behavior unchanged
# ---------------------------------------------------------------------------

def test_default_flag_off_no_formation_index_growth(tmp_path):
    """With the default flag off, formation_index stays empty and the
    legacy detect_formations path produces self.formations as before.
    """
    engine = _make_engine(tmp_path / "state", addressed=False)
    _seed_corpus(engine, 100)
    # formation_index never populated when flag is off
    assert engine.formation_index == {}
    # legacy formations list still produced via detect_formations
    assert isinstance(engine.formations, list)
    # crystals don't get a .formation field set by the addressed path
    # (they may still have one from elsewhere — that's fine)


# ---------------------------------------------------------------------------
# Flag on — addressed path
# ---------------------------------------------------------------------------

def test_addressed_eat_files_crystal_into_formation(tmp_path):
    """With the flag on, eat() must set crystal.formation to the address
    and add the crystal to formation_index[address].member_ids.
    """
    engine = _make_engine(tmp_path / "state", addressed=True)
    engine.eat(
        "The architecture demands clarity at every layer of the system.",
        source="probe",
    )
    crystal = engine.fish.crystals[-1]
    assert crystal.formation, (
        f"new crystal must have .formation set; got {crystal.formation!r}"
    )
    assert crystal.formation in engine.formation_index, (
        f"formation_index missing crystal's address {crystal.formation!r}"
    )
    formation = engine.formation_index[crystal.formation]
    assert crystal.id in formation.member_ids
    assert formation.crystal_count >= 1


def test_addressed_eat_many_populates_index(tmp_path):
    """eat_many with the flag on populates formation_index across the
    whole batch — one address per distinct grammar signature.
    """
    engine = _make_engine(tmp_path / "state", addressed=True)
    _seed_corpus(engine, 100)
    # At least some formations should exist (the seed corpus produces
    # varied grammar signatures via 10 patterns, so the address space
    # should be non-trivial — typically 1-10 active addresses).
    assert len(engine.formation_index) >= 1, (
        f"formation_index empty after seeding 100 crystals: "
        f"{engine.formation_index}"
    )
    # Every crystal should have been filed into its formation
    crystals_with_formation = sum(
        1 for c in engine.fish.crystals if c.formation
    )
    assert crystals_with_formation == len(engine.fish.crystals), (
        f"only {crystals_with_formation}/{len(engine.fish.crystals)} "
        f"crystals were filed; addressed path didn't fire on every eat"
    )


def test_addressed_aggregates_match_detected(tmp_path):
    """The running aggregates produced by Formation.update_with() should
    match (within float tolerance) what detect_formations() computes by
    batch reduction over the same member set.

    Build the same corpus through both paths, compare the aggregate
    fields on the largest formation by crystal_count.
    """
    # Path A: addressed
    engine_addr = _make_engine(tmp_path / "addr", addressed=True)
    _seed_corpus(engine_addr, 100)

    # Path B: legacy
    engine_legacy = _make_engine(tmp_path / "legacy", addressed=False)
    _seed_corpus(engine_legacy, 100)

    # Find the largest formation in each path
    addr_formations = sorted(
        engine_addr.formation_index.values(),
        key=lambda f: f.crystal_count,
        reverse=True,
    )
    legacy_formations = sorted(
        engine_legacy.formations,
        key=lambda f: f.crystal_count,
        reverse=True,
    )

    if not addr_formations or not legacy_formations:
        # Edge case: tiny corpus produced no formations in legacy path.
        # Skip the comparison rather than fail the test on a non-finding.
        return

    addr_top = addr_formations[0]
    legacy_top = legacy_formations[0]

    # Both should have at least a few crystals
    assert addr_top.crystal_count >= 3
    assert legacy_top.crystal_count >= 3

    # cog_amplitude should be a positive float in both. Exact equality
    # isn't possible (different membership groupings — addressed buckets
    # by grammar, legacy by graph BFS), but both should be in the same
    # ballpark for a corpus this size.
    assert addr_top.cog_amplitude > 0
    assert legacy_top.cog_amplitude > 0

    # crystal_count across all addressed formations should equal the
    # number of seeded crystals (every crystal lands somewhere).
    total_filed = sum(f.crystal_count for f in engine_addr.formation_index.values())
    assert total_filed == len(engine_addr.fish.crystals), (
        f"addressed path filed {total_filed} of "
        f"{len(engine_addr.fish.crystals)} crystals — some were dropped"
    )


def test_addressed_eat_does_not_call_detect_formations_globally(tmp_path):
    """With the flag on, rebuild_formations does NOT walk all crystals
    via detect_formations. Verify by checking that the formations list
    in the engine matches the index values, not a re-discovered set.
    """
    engine = _make_engine(tmp_path / "state", addressed=True)
    _seed_corpus(engine, 50)

    # After seeding, engine.formations should be a snapshot of
    # formation_index.values() — same set of Formation objects.
    formation_names_in_engine = {f.name for f in engine.formations}
    formation_names_in_index = set(engine.formation_index.keys())
    assert formation_names_in_engine == formation_names_in_index, (
        f"engine.formations name set {formation_names_in_engine} "
        f"diverges from formation_index keys {formation_names_in_index}; "
        f"the addressed short-circuit isn't publishing index → formations"
    )


def test_addressed_couplings_still_work(tmp_path):
    """The addressed path still uses _couple_appended_crystals from
    PR #18 — couplings are maintained on the new tail. Verify that
    new crystals at scale couple to their window neighbors.
    """
    engine = _make_engine(tmp_path / "state", addressed=True)
    _seed_corpus(engine, 200)

    # Eat one more text that echoes the seed patterns so it actually
    # couples (vs novel-vocabulary text that wouldn't reach gamma).
    engine.eat(
        "Entry 9999: The architecture demands clarity at every layer "
        "of the system. Note 770 on iteration 9999.",
        source="probe",
    )
    new_crystal = engine.fish.crystals[-1]
    assert len(new_crystal.couplings) > 0, (
        "addressed path didn't couple the new crystal to window neighbors"
    )


def test_compression_score_uses_current_trust_weight(tmp_path):
    """Regression for the trust_weight ordering bug surfaced by codex review
    on 2026-04-30. Formation.update_with computed compression_score before
    refreshing trust_weight from the accumulated source-mind set, so a
    new-mind crystal arriving in an existing formation produced a score
    half (or 1/3) of what detect_formations would compute on the same
    member set. The ordering must be: trust_weight updated FIRST, then
    compression_score derived from it.

    The bug breaks Ice-9 regime classification — a formation that should
    be DIGNITY can be misclassified as PATHOLOGY because the score
    multiplicand stays stuck at the old (low) trust regime.
    """
    from linafish.formations import Formation
    from linafish.crystallizer_v3 import Crystal

    f = Formation(
        id=0, name="TEST", keywords=[], member_ids=[],
        centroid=[0.0] * 8, representative_text="",
        crystal_count=0, cognitive_centroid=[0.0] * 8,
    )

    def _make_crystal(cid: str, mind: str) -> Crystal:
        c = Crystal(
            id=cid, ts="", text=f"text-{cid}", source="",
            mi_vector=[1, 2, 3, 4, 5, 6, 7, 8],
            resonance=[1, 2, 3, 4, 5, 6, 7, 8],
            keywords=["x"], ache=0.5,
            cognitive_vector=[1.0] + [0.5] * 7,
        )
        c.source_mind = mind
        return c

    # First crystal from mind A — single-mind regime, trust_weight=0.5
    f.update_with(_make_crystal("c1", "A"))
    assert f.trust_weight == 0.5
    score_one_mind = f.compression_score
    # Manual: 0.5 ache * |[1,0.5,...]|=sqrt(1+7*0.25)=1.658 * 0.5 trust * 1.0 div
    expected_one = 0.5 * f.cog_amplitude * 0.5 * 1.0
    assert abs(score_one_mind - expected_one) < 1e-6, (
        f"single-mind score {score_one_mind} != expected {expected_one}"
    )

    # Second crystal from mind B — two-mind regime, trust_weight=1.0
    f.update_with(_make_crystal("c2", "B"))
    assert f.trust_weight == 1.0, "trust_weight didn't update on new mind"
    score_two_minds = f.compression_score
    expected_two = f.mean_ache * f.cog_amplitude * 1.0 * f.content_diversity
    assert abs(score_two_minds - expected_two) < 1e-6, (
        f"two-mind compression_score {score_two_minds} disagrees with "
        f"manual product {expected_two} — trust_weight ordering bug "
        f"reintroduced. The fix is in formations.py: trust_weight + "
        f"source_minds update MUST come before the compression_score "
        f"multiplicand line."
    )
    # And the post-fix score must be strictly larger than the pre-fix
    # would have been (which was multiplied by 0.5 trust instead of 1.0).
    pre_fix_would_have_been = (
        f.mean_ache * f.cog_amplitude * 0.5 * f.content_diversity
    )
    assert score_two_minds > pre_fix_would_have_been + 1e-9, (
        f"score didn't double on new-mind arrival — likely regression"
    )


def test_update_with_no_per_call_keyword_sort():
    """Regression for the Formation.update_with keyword-sort perf bug
    surfaced 2026-04-30 §TWO.RELEASES.ONE.OOM.

    Pre-2026-05-01 ``update_with`` called
    ``sorted(self._keyword_counter.most_common(), key=...)`` on every
    invocation. That's O(K log K) per call where K = unique keywords
    seen so far. The init-time bootstrap walk over .67's 393K-crystal
    federation room corpus took 14 minutes solo because the dominant
    formation's vocabulary K grew to ~5-10K and the per-crystal sort
    cost compounded. Past any reasonable maintenance window.

    Fix: ``Formation.keywords`` is now a lazy ``@property`` derived from
    ``_keyword_counter`` on access. ``update_with`` only bumps the
    counter (O(1) per keyword); the sort runs once per read, not per
    write.

    This test drives 5000 update_with calls with vocabulary growing to
    ~3000 unique keywords. Pre-fix: would take seconds-to-tens-of-seconds
    on a dev box. Post-fix: should complete in well under a second.
    Threshold of 3.0 seconds is a generous ceiling that still catches
    re-introduction of the per-call sort by an order of magnitude.
    """
    import time
    from linafish.formations import Formation
    from linafish.crystallizer_v3 import Crystal

    f = Formation(
        id=0, name="PERF", keywords=[], member_ids=[],
        centroid=[0.0] * 8, representative_text="",
        crystal_count=0, cognitive_centroid=[0.0] * 8,
    )

    n_calls = 5000
    vocab_size = 3000  # unique keywords across the run

    # Pre-build crystal stubs so we time only update_with, not Crystal init.
    crystals = []
    for i in range(n_calls):
        # Each crystal contributes 5 keywords; keyword indices spread
        # across vocab_size so the counter grows steadily, hitting the
        # K = ~3000 unique-vocabulary regime before the loop ends.
        kws = [f"kw_{(i * 5 + j) % vocab_size:04d}" for j in range(5)]
        c = Crystal(
            id=f"c{i}", ts="", text=f"text-{i}", source="",
            mi_vector=[1, 2, 3, 4, 5, 6, 7, 8],
            resonance=[1, 2, 3, 4, 5, 6, 7, 8],
            keywords=kws, ache=0.5,
            cognitive_vector=[1.0] + [0.5] * 7,
        )
        c.source_mind = "A"
        crystals.append(c)

    t0 = time.perf_counter()
    for c in crystals:
        f.update_with(c)
    elapsed = time.perf_counter() - t0

    assert elapsed < 0.5, (
        f"update_with × {n_calls} took {elapsed:.2f}s; expected well under "
        f"0.5s. Pre-fix code (O(K log K) per call at K=3000) takes 5-8s on "
        f"a dev laptop, so the 0.5s ceiling actually catches re-introduction "
        f"of the per-call sort while tolerating CI jitter (post-fix typical "
        f"is ~70 ms). Codex round-1 2026-05-02: prior 3.0s threshold let "
        f"reversion slip through on fast hardware. The fix is in "
        f"formations.py: update_with bumps _keyword_counter only, and "
        f"Formation.keywords is a @property derived on read."
    )

    # Sanity: the lazy property still produces a correct top-5.
    top = f.keywords
    assert len(top) == 5
    assert all(kw.startswith("kw_") for kw in top), top
    # And the counter saw all the calls (5 keywords × n_calls).
    assert sum(f._keyword_counter.values()) == n_calls * 5
