from pydantic import BaseModel

class ContextWindow(BaseModel):
    """Defines the context window schema.

    Attributes:
        max_input_tokens (int | None): The maximum number of input tokens. Defaults to None.
        max_output_tokens (int | None): The maximum number of output tokens. Defaults to None.
    """
    max_input_tokens: int | None
    max_output_tokens: int | None
