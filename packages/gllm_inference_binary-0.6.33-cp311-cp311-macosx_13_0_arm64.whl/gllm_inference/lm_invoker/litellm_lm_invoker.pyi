from gllm_core.retry import RetryConfig
from gllm_inference.lm_invoker.openai_chat_completions_lm_invoker import OpenAIChatCompletionsLMInvoker as OpenAIChatCompletionsLMInvoker
from gllm_inference.output_transformer import OutputTransformerChain as OutputTransformerChain
from gllm_inference.schema import AttachmentType as AttachmentType, InputTransformerType as InputTransformerType, LMOutput as LMOutput, LMTool as LMTool, ModelId as ModelId, ModelProvider as ModelProvider, OutputTransformerType as OutputTransformerType, ResponseSchema as ResponseSchema, ThinkingConfig as ThinkingConfig
from typing import Any

class LiteLLMLMInvoker(OpenAIChatCompletionsLMInvoker):
    '''A language model invoker to interact with language models using LiteLLM.

    Examples:
        ```python
        lm_invoker = LiteLLMLMInvoker(model_id="openai/gpt-5-nano")
        result = await lm_invoker.invoke("Hi there!")
        ```

    Initialization:
        The `LiteLLMLMInvoker` provides an interface to interact with multiple language model providers.
        In order to use this class:
        1. The `model_id` parameter must be in the format of `provider/model_name`. e.g. `openai/gpt-4o-mini`.
        2. The required credentials must be provided via the environment variables.

        Usage example:
        ```python
        os.environ["OPENAI_API_KEY"] = "your_openai_api_key"
        lm_invoker = LiteLLMLMInvoker(model_id="openai/gpt-4o-mini")
        ```

        For the complete list of supported providers and their required credentials, please refer to the
        LiteLLM documentation: https://docs.litellm.ai/docs/providers/

    Supported features:
        1. Basic invocation
        2. Streaming output
        3. Message roles
        4. Multimodal input
           a. Text
           b. Audio
           c. Image
        5. Structured output
        6. Tool calling
        7. Thinking
        8. Output analytics
        9. Retry and timeout
        10. Extra capabilities
           a. Input transformer
           b. Output transformer

        For full documentation and examples, please refer to the LM Invoker tutorial:
        https://gdplabs.gitbook.io/sdk/gen-ai-sdk/tutorials/inference/lm-invoker

    Attributes:
        model_id (str): The model ID of the language model.
        model_provider (str): The provider of the language model.
        model_name (str): The name of the language model.
        default_config (dict[str, Any]): Default config for invoking the model.
        tools (list[Tool]): The list of tools provided to the model to enable tool calling.
        response_schema (ResponseSchema | None): The schema of the response. If provided, the model will output a
            structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema dictionary.
        output_analytics (bool): Whether to output the invocation analytics.
        retry_config (RetryConfig | None): The retry configuration for the language model.
        thinking (ThinkingConfig): The thinking configuration for the language model.
        input_transformer (InputTransformerType): The type of input transformer to use.
        output_transformer (OutputTransformerType): The type of output transformer to use.
    '''
    def __init__(self, model_id: str, default_hyperparameters: dict[str, Any] | None = None, tools: list[LMTool] | None = None, response_schema: ResponseSchema | None = None, output_analytics: bool = False, retry_config: RetryConfig | None = None, thinking: bool | ThinkingConfig = False, input_transformer: InputTransformerType = ..., output_transformer: OutputTransformerType = ...) -> None:
        """Initializes a new instance of the LiteLLMLMInvoker class.

        Args:
            model_id (str): The ID of the model to use. Must be in the format of `provider/model_name`.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            tools (list[LMTool] | None, optional): Tools provided to the model to enable tool calling.
                Defaults to None.
            response_schema (ResponseSchema | None, optional): The schema of the response. If provided, the model will
                output a structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema
                dictionary. Defaults to None.
            output_analytics (bool, optional): Whether to output the invocation analytics. Defaults to False.
            retry_config (RetryConfig | None, optional): The retry configuration for the language model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            thinking (bool | ThinkingConfig, optional): A boolean or ThinkingConfig object to configure thinking.
                Defaults to False.
            input_transformer (InputTransformerType, optional): The type of input transformer to use.
                Defaults to InputTransformerType.IDENTITY, which returns the input without transformation.
            output_transformer (OutputTransformerType, optional): The type of output transformer to use.
                Defaults to OutputTransformerType.IDENTITY, which returns the output without transformation.
        """
