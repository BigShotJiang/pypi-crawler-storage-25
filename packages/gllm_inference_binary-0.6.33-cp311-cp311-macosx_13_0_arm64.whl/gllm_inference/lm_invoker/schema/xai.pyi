class Key:
    """Defines valid keys in xAI."""
    ARGUMENTS: str
    CHANNEL_OPTIONS: str
    CITATIONS: str
    COMPLETION_TOKENS: str
    CREATED_AT: str
    DELETED: str
    CONTENT: str
    FILE_ID: str
    FILENAME: str
    FINISH_REASON: str
    FUNCTION: str
    ID: str
    IMAGE_FORMAT: str
    NAME: str
    PROMPT_TOKENS: str
    REASONING_CONTENT: str
    RESPONSE_FORMAT: str
    SEARCH_PARAMETERS: str
    SIZE: str
    TEXT: str
    TIMEOUT: str
    TOOL_CALLS: str
    TOOLS: str
    TYPE: str
    URL: str
    URL_CITATION: str
    USAGE: str

class InputType:
    """Defines valid input types in xAI."""
    INPUT_FILE: str
