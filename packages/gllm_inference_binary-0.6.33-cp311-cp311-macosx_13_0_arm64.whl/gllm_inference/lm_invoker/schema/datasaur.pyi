from _typeshed import Incomplete
from pydantic import BaseModel, SecretStr
from typing import Any

JWE_ENCRYPTION_KEY_SIZES: Incomplete
JWE_KEY_WRAP_KEY_SIZES: Incomplete

class DatasaurJWEConfig(BaseModel):
    '''JWE authentication configuration for Datasaur invoker.

    Attributes:
        secret (SecretStr): The shared secret for JWE token generation.
        claims (dict[str, Any]): The additional claims for JWE token generation. Defaults to an empty dictionary.
        issuer (str): The issuer of the JWE token. Defaults to "agentkit".
        expires_in_seconds (int): The expiration time of the JWE token in seconds. Defaults to 3600.
        alg (str): The algorithm of the JWE token. Defaults to "dir".
        enc (str): The encryption algorithm of the JWE token. Defaults to "A256GCM".
        key_len (int): Read-only byte length of the symmetric key derived from `alg` and `enc`.
    '''
    secret: SecretStr
    claims: dict[str, Any]
    issuer: str
    expires_in_seconds: int
    alg: str
    enc: str
    @property
    def key_len(self) -> int:
        """Byte length of the symmetric key for the configured algorithms.

        Returns:
            int: The byte length of the symmetric key.
        """
    def infer_key_size(self) -> DatasaurJWEConfig:
        """Infers the key size based on the algorithm and encryption algorithm.

        Returns:
            DatasaurJWEConfig: The JWE configuration with the inferred key size.

        Raises:
            ValueError: If the JWE configuration is invalid.
        """

class Key:
    """Defines valid keys in Datasaur."""
    ALG: str
    API_KEY: str
    BASE_URL: str
    CONTEXTS: str
    ENC: str
    EXP: str
    IAT: str
    ISS: str
    MAX_RETRIES: str
    NAME: str
    TIMEOUT: str
    TYPE: str
    URL: str
    USAGE: str

class InputType:
    """Defines valid input types in Datasaur."""
    URL: str
