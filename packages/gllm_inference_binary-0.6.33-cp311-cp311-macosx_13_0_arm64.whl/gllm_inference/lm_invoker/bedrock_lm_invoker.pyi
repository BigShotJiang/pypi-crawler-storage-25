from _typeshed import Incomplete
from gllm_core.retry import RetryConfig
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker as BaseLMInvoker
from gllm_inference.lm_invoker.schema.bedrock import InputType as InputType, Key as Key, OutputType as OutputType
from gllm_inference.output_transformer import OutputTransformerChain as OutputTransformerChain
from gllm_inference.schema import Attachment as Attachment, AttachmentType as AttachmentType, InputTransformerType as InputTransformerType, LMOutput as LMOutput, LMTool as LMTool, Message as Message, ModelId as ModelId, ModelProvider as ModelProvider, NativeTool as NativeTool, OutputTransformerType as OutputTransformerType, ResponseEvent as ResponseEvent, ResponseSchema as ResponseSchema, StreamBuffer as StreamBuffer, TokenUsage as TokenUsage, ToolCall as ToolCall, ToolResult as ToolResult
from typing import Any

FILENAME_SANITIZATION_REGEX: Incomplete

class BedrockLMInvoker(BaseLMInvoker):
    '''A language model invoker to interact with AWS Bedrock language models.

    Examples:
        ```python
        lm_invoker = BedrockLMInvoker(
            model_name="us.anthropic.claude-sonnet-4-20250514-v1:0",
            aws_access_key_id="<your-aws-access-key-id>",
            aws_secret_access_key="<your-aws-secret-access-key>",
        )
        result = await lm_invoker.invoke("Hi there!")
        ```

    Supported features:
        1. Basic invocation
        2. Streaming output
        3. Message roles
        4. Multimodal input
           a. Text
           b. Document
           c. Image
           d. Video
        5. Structured output
        6. Tool calling
        7. Output analytics
        8. Retry and timeout
        9. Extra capabilities
           a. Input transformer
           b. Output transformer

        For full documentation and examples, please refer to the LM Invoker tutorial:
        https://gdplabs.gitbook.io/sdk/gen-ai-sdk/tutorials/inference/lm-invoker

    Attributes:
        model_id (str): The model ID of the language model.
        model_provider (str): The provider of the language model.
        model_name (str): The name of the language model.
        session (Session): The Bedrock client session.
        client_kwargs (dict[str, Any]): The Bedrock client kwargs.
        default_config (dict[str, Any]): Default config for invoking the model.
        tools (list[Tool]): Tools provided to the model to enable tool calling.
        response_schema (ResponseSchema | None): The schema of the response. If provided, the model will output a
            structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema dictionary.
        output_analytics (bool): Whether to output the invocation analytics.
        retry_config (RetryConfig): The retry configuration for the language model.
        input_transformer (InputTransformerType): The type of input transformer to use.
        output_transformer (OutputTransformerType): The type of output transformer to use.
    '''
    session: Incomplete
    client_kwargs: Incomplete
    def __init__(self, model_name: str, access_key_id: str | None = None, secret_access_key: str | None = None, region_name: str = 'us-east-1', model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, tools: list[LMTool] | None = None, response_schema: ResponseSchema | None = None, output_analytics: bool = False, retry_config: RetryConfig | None = None, input_transformer: InputTransformerType = ..., output_transformer: OutputTransformerType = ...) -> None:
        '''Initializes the BedrockLMInvoker instance.

        Args:
            model_name (str): The name of the Bedrock language model.
            access_key_id (str | None, optional): The AWS access key ID. Defaults to None, in which case
                the `AWS_ACCESS_KEY_ID` environment variable will be used.
            secret_access_key (str | None, optional): The AWS secret access key. Defaults to None, in which case
                the `AWS_SECRET_ACCESS_KEY` environment variable will be used.
            region_name (str, optional): The AWS region name. Defaults to "us-east-1".
            model_kwargs (dict[str, Any] | None, optional): Additional keyword arguments for the Bedrock client.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            tools (list[LMTool] | None, optional): Tools provided to the model to enable tool calling.
                Defaults to None, in which case an empty list is used.
            response_schema (ResponseSchema | None, optional): The schema of the response. If provided, the model will
                output a structured response as defined by the schema. Supports both Pydantic BaseModel and JSON schema
                dictionary. Defaults to None.
            output_analytics (bool, optional): Whether to output the invocation analytics. Defaults to False.
            retry_config (RetryConfig | None, optional): The retry configuration for the language model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            input_transformer (InputTransformerType, optional): The type of input transformer to use.
                Defaults to InputTransformerType.IDENTITY, which returns the input without transformation.
            output_transformer (OutputTransformerType, optional): The type of output transformer to use.
                Defaults to OutputTransformerType.IDENTITY, which returns the output without transformation.

        Raises:
            ValueError: If `access_key_id` or `secret_access_key` is neither provided nor set in the
                `AWS_ACCESS_KEY_ID` or `AWS_SECRET_ACCESS_KEY` environment variables, respectively.
        '''
