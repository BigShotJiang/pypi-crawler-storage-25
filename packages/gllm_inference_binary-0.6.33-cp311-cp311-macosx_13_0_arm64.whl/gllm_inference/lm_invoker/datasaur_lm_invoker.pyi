from _typeshed import Incomplete
from gllm_core.retry import RetryConfig
from gllm_inference.constants import INVOKER_PROPAGATED_MAX_RETRIES as INVOKER_PROPAGATED_MAX_RETRIES
from gllm_inference.exceptions.exceptions import ProviderAuthError as ProviderAuthError
from gllm_inference.lm_invoker.openai_chat_completions_lm_invoker import OpenAIChatCompletionsLMInvoker as OpenAIChatCompletionsLMInvoker
from gllm_inference.lm_invoker.schema.datasaur import DatasaurJWEConfig as DatasaurJWEConfig, InputType as InputType, Key as Key
from gllm_inference.output_transformer import OutputTransformerChain as OutputTransformerChain
from gllm_inference.schema import Attachment as Attachment, AttachmentType as AttachmentType, InputTransformerType as InputTransformerType, LMOutput as LMOutput, LMTool as LMTool, Message as Message, ModelId as ModelId, ModelProvider as ModelProvider, OutputTransformerType as OutputTransformerType, ResponseSchema as ResponseSchema, StreamBuffer as StreamBuffer, StreamBufferType as StreamBufferType, ToolCall as ToolCall, ToolResult as ToolResult
from typing import Any

TOOL_CALLING_NOT_SUPPORTED_MESSAGE: str

class DatasaurLMInvoker(OpenAIChatCompletionsLMInvoker):
    '''A language model invoker to interact with Datasaur LLM Projects Deployment API.

    Examples:
        ```python
        lm_invoker = DatasaurLMInvoker(base_url="https://deployment.datasaur.ai/api/deployment/teamId/deploymentId/")
        result = await lm_invoker.invoke("Hi there!")
        ```

    Authentication:
        The `DatasaurLMInvoker` can use either Deployment API or AgentKit API.

        Deployment API requires an API key for authentication:
        ```python
        lm_invoker = DatasaurLMInvoker(
            base_url="https://deployment.datasaur.ai/api/deployment/teamId/deploymentId/",
            api_key="your_api_key"
        )
        ```

        AgentKit API requires a JWE secret or configuration for authentication:
        ```python
        lm_invoker = DatasaurLMInvoker(
            base_url="https://my-agentkit-url/v1/",
            jwe_secret_or_config="your_jwe_secret"
        )
        ```

        If neither `api_key` nor `jwe_secret_or_config` is provided, Deployment API will be used by default.
        The `DATASAUR_API_KEY` environment variable will be used for Deployment API authentication.

    Supported features:
        1. Basic invocation
        2. Streaming output
        3. Message roles
        4. Multimodal input
           a. Text
           b. Audio
           c. Document
           d. Image
        5. Output analytics
        6. Retry and timeout
        7. Extra capabilities
           a. Input transformer
           b. Output transformer

        For full documentation and examples, please refer to the LM Invoker tutorial:
        https://gdplabs.gitbook.io/sdk/gen-ai-sdk/tutorials/inference/lm-invoker

    Citations:
        The `DatasaurLMInvoker` can be configured to output the citations used to generate the response.
        This feature can be enabled by setting the `citations` parameter to `True`.

        Citations outputs are stored in the `outputs` attribute of the `LMOutput` object and
        can be accessed via the `citations` property.

        ```python
        lm_invoker = DatasaurLMInvoker(..., citations=True)
        ```

    Attributes:
        model_id (str): The model ID of the language model.
        model_provider (str): The provider of the language model.
        model_name (str): The name of the language model.
        client_kwargs (dict[str, Any]): The keyword arguments for the OpenAI client.
        default_config (dict[str, Any]): Default config for invoking the model.
        tools (list[Any]): The list of tools provided to the model to enable tool calling. Currently not supported.
        response_schema (ResponseSchema | None): The schema of the response. Currently not supported.
        output_analytics (bool): Whether to output the invocation analytics.
        retry_config (RetryConfig | None): The retry configuration for the language model.
        citations (bool): Whether to output the citations.
        input_transformer (InputTransformerType): The type of input transformer to use.
        output_transformer (OutputTransformerType): The type of output transformer to use.
    '''
    client_kwargs: Incomplete
    jwe_config: Incomplete
    citations: Incomplete
    def __init__(self, base_url: str, api_key: str | None = None, jwe_secret_or_config: str | dict[str, Any] | DatasaurJWEConfig | None = None, model_kwargs: dict[str, Any] | None = None, default_hyperparameters: dict[str, Any] | None = None, output_analytics: bool = False, retry_config: RetryConfig | None = None, citations: bool = False, input_transformer: InputTransformerType = ..., output_transformer: OutputTransformerType = ...) -> None:
        """Initializes a new instance of the DatasaurLMInvoker class.

        Args:
            base_url (str): The base URL of the Datasaur LLM Projects Deployment API.
            api_key (str | None, optional): The API key for authenticating with Datasaur LLM Projects Deployment API.
                Defaults to None, in which case the `DATASAUR_API_KEY` environment variable will be used.
            jwe_secret_or_config (str | dict[str, Any] | DatasaurJWEConfig | None, optional): The shared secret for JWE
                token generation or the JWE configuration. Cannot be used together with `api_key`. Defaults to None.
            model_kwargs (dict[str, Any] | None, optional): Additional model parameters. Defaults to None.
            default_hyperparameters (dict[str, Any] | None, optional): Default hyperparameters for invoking the model.
                Defaults to None.
            output_analytics (bool, optional): Whether to output the invocation analytics. Defaults to False.
            retry_config (RetryConfig | None, optional): The retry configuration for the language model.
                Defaults to None, in which case a default config with no retry and 30.0 seconds timeout will be used.
            citations (bool, optional): Whether to output the citations. Defaults to False.
            input_transformer (InputTransformerType, optional): The type of input transformer to use.
                Defaults to InputTransformerType.IDENTITY, which returns the input without transformation.
            output_transformer (OutputTransformerType, optional): The type of output transformer to use.
                Defaults to OutputTransformerType.IDENTITY, which returns the output without transformation.
        """
    def set_tools(self, tools: list[LMTool]) -> None:
        """Sets the tools for the Datasaur LLM Projects Deployment API.

        This method is raises a `NotImplementedError` because the Datasaur LLM Projects Deployment API does not
        support tools.

        Args:
            tools (list[LMTool]): The list of tools to be used.

        Raises:
            NotImplementedError: This method is not supported for the Datasaur LLM Projects Deployment API.
        """
    def set_response_schema(self, response_schema: ResponseSchema | None) -> None:
        """Sets the response schema for the Datasaur LLM Projects Deployment API.

        This method is raises a `NotImplementedError` because the Datasaur LLM Projects Deployment API does not
        support response schema.

        Args:
            response_schema (ResponseSchema | None): The response schema to be used.

        Raises:
            NotImplementedError: This method is not supported for the Datasaur LLM Projects Deployment API.
        """
