from _typeshed import Incomplete
from gllm_inference.lm_invoker.anthropic_lm_invoker import AnthropicLMInvoker as AnthropicLMInvoker
from gllm_inference.lm_invoker.operations.file_operations.file_operations import FileOperations as FileOperations
from gllm_inference.lm_invoker.schema.anthropic import Key as Key
from gllm_inference.schema import Attachment as Attachment, ModelProvider as ModelProvider, UploadedAttachment as UploadedAttachment

FILE_KEYS: Incomplete

class AnthropicFileOperations(FileOperations):
    """Handles file operations for the AnthropicLMInvoker class."""
    def __init__(self, invoker: AnthropicLMInvoker) -> None:
        """Initializes the file operations.

        Args:
            invoker (AnthropicLMInvoker): The AnthropicLMInvoker to use for the file operations.
        """
    async def upload(self, file: Attachment) -> UploadedAttachment:
        """Uploads a file to the language model provider.

        Args:
            file (Attachment): The file to upload.

        Returns:
            UploadedAttachment: The uploaded attachment.
        """
    async def list(self) -> list[UploadedAttachment]:
        """Lists the files from the language model provider.

        Returns:
            list[UploadedAttachment]: The list of files.
        """
    async def delete(self, file: UploadedAttachment) -> None:
        """Deletes a file from the language model provider.

        Args:
            file (UploadedAttachment): The file to delete.
        """
