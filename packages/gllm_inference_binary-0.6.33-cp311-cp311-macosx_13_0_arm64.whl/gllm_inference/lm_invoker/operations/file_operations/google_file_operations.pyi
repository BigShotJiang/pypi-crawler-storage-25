from gllm_inference.constants import UPLOAD_FILE_STATUS_CHECK_INTERVAL as UPLOAD_FILE_STATUS_CHECK_INTERVAL
from gllm_inference.exceptions import FileOperationError as FileOperationError
from gllm_inference.lm_invoker.google_lm_invoker import GoogleLMInvoker as GoogleLMInvoker
from gllm_inference.lm_invoker.operations.file_operations.file_operations import FileOperations as FileOperations
from gllm_inference.lm_invoker.schema.google import Key as Key
from gllm_inference.schema import Attachment as Attachment, ModelProvider as ModelProvider, UploadedAttachment as UploadedAttachment

class GoogleFileOperations(FileOperations):
    """Handles file operations for the GoogleLMInvoker class."""
    def __init__(self, invoker: GoogleLMInvoker) -> None:
        """Initializes the file operations.

        Args:
            invoker (GoogleLMInvoker): The GoogleLMInvoker to use for the file operations.
        """
    async def upload(self, file: Attachment) -> UploadedAttachment:
        """Uploads a file to the language model provider.

        Args:
            file (Attachment): The file to upload.

        Returns:
            UploadedAttachment: The uploaded attachment.

        Raises:
            FileOperationError: If the file upload fails.
        """
    async def list(self) -> list[UploadedAttachment]:
        """Lists the files from the language model provider.

        Returns:
            list[UploadedAttachment]: The list of files.
        """
    async def delete(self, file: UploadedAttachment) -> None:
        """Deletes a file from the language model provider.

        Args:
            file (UploadedAttachment): The file to delete.
        """
