from gllm_core.event import EventEmitter
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker as BaseLMInvoker
from gllm_inference.prompt_builder import PromptBuilder as PromptBuilder
from gllm_inference.schema import LMOutput as LMOutput, Message as Message, MessageContent as MessageContent
from typing import Any

class PromptOperations:
    '''Handles prompt operations for an LM invoker.

    Examples:
        1. Configure prompt templates:
        ```python
        lm_invoker.prompt.build(system_template="You are helpful.", user_template="{query}")
        ```

        2. Invoke with the configured prompt builder:
        ```python
        result = await lm_invoker.prompt.invoke(query="Hello")
        ```

        3. Clear configured prompt builder:
        ```python
        lm_invoker.prompt.clear()
        ```
    '''
    prompt_builder: PromptBuilder | None
    def __init__(self, invoker: BaseLMInvoker) -> None:
        """Initializes the prompt operations.

        Args:
            invoker (BaseLMInvoker): The LM invoker to use for prompt operations.
        """
    def build(self, prompt_builder: PromptBuilder | None = None, *, system_template: str = '', user_template: str = '', prompt_builder_kwargs: dict[str, Any] | None = None) -> BaseLMInvoker:
        """Builds and stores a prompt builder.

        Args:
            prompt_builder (PromptBuilder | None, optional): A predefined prompt builder. Defaults to None.
            system_template (str, optional): The system prompt template. Defaults to an empty string.
            user_template (str, optional): The user prompt template. Defaults to an empty string.
            prompt_builder_kwargs (dict[str, Any] | None, optional): Additional keyword arguments for PromptBuilder.
                Defaults to None.

        Returns:
            BaseLMInvoker: The LM invoker for fluent chaining.

        Raises:
            ValueError:
            1. If both `prompt_builder` and template inputs are provided.
            2. If no prompt builder input is provided.
        """
    def clear(self) -> BaseLMInvoker:
        """Clears the configured prompt builder.

        Returns:
            BaseLMInvoker: The LM invoker for fluent chaining.
        """
    async def invoke(self, history: list[Message] | None = None, extra_contents: list[MessageContent] | None = None, hyperparameters: dict[str, Any] | None = None, event_emitter: EventEmitter | None = None, **prompt_kwargs: Any) -> LMOutput:
        """Invokes the language model using a configured prompt builder.

        Args:
            history (list[Message] | None, optional): Conversation history to include in the prompt.
                Defaults to None.
            extra_contents (list[MessageContent] | None, optional): Extra user contents for prompt formatting.
                Defaults to None.
            hyperparameters (dict[str, Any] | None, optional): Hyperparameters passed to the language model invocation.
                Defaults to None.
            event_emitter (EventEmitter | None, optional): Event emitter for streaming outputs. Defaults to None.
            **prompt_kwargs (Any): Prompt variables passed to `PromptBuilder.format`.

        Returns:
            LMOutput: The language model output from a single invocation.

        Raises:
            ValueError: If no prompt builder is configured.
        """
