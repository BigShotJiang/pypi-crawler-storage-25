from gllm_inference.lm_invoker.operations.prompt_operations.prompt_operations import PromptOperations as PromptOperations

__all__ = ['PromptOperations']
