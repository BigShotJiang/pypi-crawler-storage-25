from _typeshed import Incomplete
from abc import ABC
from gllm_core.retry import RetryConfig
from gllm_inference.constants import REALTIME_SESSION_DEFAULT_TIMEOUT as REALTIME_SESSION_DEFAULT_TIMEOUT
from gllm_inference.realtime_session.input_streamer import KeyboardInputStreamer as KeyboardInputStreamer
from gllm_inference.realtime_session.input_streamer.input_streamer import BaseInputStreamer as BaseInputStreamer
from gllm_inference.realtime_session.output_streamer import ConsoleOutputStreamer as ConsoleOutputStreamer
from gllm_inference.realtime_session.output_streamer.output_streamer import BaseOutputStreamer as BaseOutputStreamer
from gllm_inference.realtime_session.schema import RealtimeState as RealtimeState

class BaseRealtimeSession(ABC):
    """[BETA] A base class for realtime session modules.

    The `BaseRealtimeSession` class provides a framework for processing real-time conversation sessions.

    Attributes:
        retry_config (RetryConfig): The retry configuration for the realtime session.
    """
    retry_config: Incomplete
    def __init__(self, retry_config: RetryConfig | None = None) -> None:
        """Initializes a new instance of the BaseRealtimeSession class.

        Args:
            retry_config (RetryConfig | None, optional): The retry configuration for the realtime session.
                Defaults to None, in which case a default config with no retry and 60 minutes timeout will be used.
        """
    async def start(self, input_streamers: list[BaseInputStreamer] | None = None, output_streamers: list[BaseOutputStreamer] | None = None) -> None:
        """Starts the real-time conversation session using the provided input and output streamers.

        This method validates the input and output streamers, and then calls the _start method.

        Args:
            input_streamers (list[BaseInputStreamer] | None, optional): The input streamers to use.
                Defaults to None.
            output_streamers (list[BaseOutputStreamer] | None, optional): The output streamers to use.
                Defaults to None.

        Raises:
            ValueError: If the `input_streamers` or `output_streamers` is an empty list.
        """
