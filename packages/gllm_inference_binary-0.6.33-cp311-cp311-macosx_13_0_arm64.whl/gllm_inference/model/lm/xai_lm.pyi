class XAILM:
    '''Defines XAI language model names constants.

    Usage example:
    ```python
    from gllm_inference.model import XAILM
    from gllm_inference.lm_invoker import XAILMInvoker

    lm_invoker = XAILMInvoker(XAILM.GROK_4_1_FAST_NON_REASONING)
    response = await lm_invoker.invoke("Hello, world!")
    ```
    '''
    GROK_IMAGINE_IMAGE_PRO_IMAGE: str
    GROK_IMAGINE_IMAGE: str
    GROK_4_20_REASONING: str
    GROK_4_20_NON_REASONING: str
    GROK_4_20_MULTI_AGENT: str
    GROK_4_1_FAST_REASONING: str
    GROK_4_1_FAST_NON_REASONING: str
    GROK_4_FAST_REASONING: str
    GROK_4_FAST_NON_REASONING: str
    GROK_4_0709: str
