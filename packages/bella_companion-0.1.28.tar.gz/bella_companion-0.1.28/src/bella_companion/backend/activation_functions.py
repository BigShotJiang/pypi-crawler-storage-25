from abc import ABC, abstractmethod
from typing import Any

import numpy as np
from numpy.typing import ArrayLike

from bella_companion.backend.type_hints import Array


class ActivationFunction(ABC):
    @abstractmethod
    def __call__(self, x: ArrayLike) -> Array: ...


class Identity(ActivationFunction):
    def __call__(self, x: ArrayLike) -> Array:
        return np.asarray(x, dtype=np.float64)


class Sigmoid(ActivationFunction):
    def __init__(self, lower: float = 0.0, upper: float = 1.0, shape: float = 1.0):
        self._lower = lower
        self._upper = upper
        self._shape = shape

    def __call__(self, x: ArrayLike) -> Array:
        x = np.asarray(x, dtype=np.float64)
        return self._lower + (self._upper - self._lower) / (
            1 + np.exp(-self._shape * x)
        )


class ReLU(ActivationFunction):
    def __call__(self, x: ArrayLike) -> Array:
        return np.maximum(0, x)


class Softplus(ActivationFunction):
    def __call__(self, x: ArrayLike) -> Array:
        return np.log1p(np.exp(x))


class Tanh(ActivationFunction):
    def __call__(self, x: ArrayLike) -> Array:
        return np.tanh(x)


ACTIVATION_FUNCTIONS_REGISTRY = {
    class_.__name__.lower(): class_ for class_ in ActivationFunction.__subclasses__()
}
ActivationFunctionLike = str | ActivationFunction


def as_activation_function(
    activation: ActivationFunctionLike,
    **kwargs: Any,
) -> ActivationFunction:
    if isinstance(activation, str):
        return ACTIVATION_FUNCTIONS_REGISTRY[activation.lower()](**kwargs)
    return activation
