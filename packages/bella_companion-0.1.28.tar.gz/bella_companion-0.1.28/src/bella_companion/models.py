from dataclasses import dataclass
from enum import Enum
from typing import Sequence, Type

from bella_companion.backend import ActivationFunction


class WeightsPrior(str, Enum):
    NORMAL = "Normal"
    LAPLACE = "LaplaceDistribution"


@dataclass
class BELLASetting:
    weights_prior: WeightsPrior
    hidden_activation: Type[ActivationFunction]
    nodes: Sequence[int]
