MIGRATION_RATE_CHANGE_TIMES = {
    "flights_and_populations": [
        "2020-03-01",
        "2020-02-16",
        "2020-02-01",
        "2020-01-23",
        "2020-01-16",
        "2020-01-01",
    ],
    "flights_over_populations": [
        "2020-03-01",
        "2020-02-01",
        "2020-01-01",
    ],
}
