# This file was generated automatically. Do not edit it directly.
from typing import Literal, TypedDict, Unpack, cast

from fountain_life_service_clients._base_client import (
    AlphaConfig,
    AlphaResponse,
    BaseClient,
)


class CheckResultAnnotationRequest(TypedDict):
    patient: str
    project: str


class CheckResultAnnotationResponse(TypedDict):
    status: Literal["skipped", "queued", "ignored"]


class MedicalResultsServiceResultAnnotationClient(BaseClient):
    def __init__(self, **cfg: Unpack[AlphaConfig]):
        kwargs = {"target": "lambda://medical-results-service:deployed", **(cfg or {})}
        super().__init__(**kwargs)

    async def check_result_annotation(self, body: CheckResultAnnotationRequest):
        res = await self.client.request(
            path="/v1/medical-results/result-annotation",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[CheckResultAnnotationResponse], res)
