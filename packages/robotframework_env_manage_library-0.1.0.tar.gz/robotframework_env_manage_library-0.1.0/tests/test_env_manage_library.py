"""Unit tests for env_manage_library helper functions."""

import sys
import os
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from EnvManageLibrary.env_manage_library import (
    _load_dotenv,
    _build_nested_overrides,
    _apply_nested_overrides,
)


# ---------------------------------------------------------------------------
# _load_dotenv
# ---------------------------------------------------------------------------
class TestLoadDotenv:
    def test_basic_key_value(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("USER=admin\nPASS=secret\n")
        result = _load_dotenv(str(env_file))
        assert result == {"USER": "admin", "PASS": "secret"}

    def test_strips_quotes(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("A='single'\nB=\"double\"\n")
        result = _load_dotenv(str(env_file))
        assert result == {"A": "single", "B": "double"}

    def test_skips_comments_and_blanks(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("# comment\n\n  \nKEY=val\n")
        result = _load_dotenv(str(env_file))
        assert result == {"KEY": "val"}

    def test_skips_lines_without_equals(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("NOEQUALS\nKEY=val\n")
        result = _load_dotenv(str(env_file))
        assert result == {"KEY": "val"}

    def test_missing_file_returns_empty(self):
        result = _load_dotenv("nonexistent.env")
        assert result == {}

    def test_value_with_equals_sign(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("URL=https://example.com?a=1&b=2\n")
        result = _load_dotenv(str(env_file))
        assert result == {"URL": "https://example.com?a=1&b=2"}

    def test_strips_whitespace(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("  KEY  =  value  \n")
        result = _load_dotenv(str(env_file))
        assert result == {"KEY": "value"}


# ---------------------------------------------------------------------------
# _build_nested_overrides
# ---------------------------------------------------------------------------
class TestBuildNestedOverrides:
    def test_single_level_dot(self):
        env = {"AUTHEN_KEY.USER": "admin", "AUTHEN_KEY.PASS": "secret"}
        result = _build_nested_overrides(env)
        assert result == {"authen_key": {"user": "admin", "pass": "secret"}}

    def test_multi_level_dot(self):
        env = {"DB.CONN.HOST": "localhost", "DB.CONN.PORT": "5432"}
        result = _build_nested_overrides(env)
        assert result == {"db": {"conn": {"host": "localhost", "port": "5432"}}}

    def test_ignores_flat_keys(self):
        env = {"USER": "admin", "AUTHEN_KEY.USER": "nested"}
        result = _build_nested_overrides(env)
        assert "user" not in result
        assert result == {"authen_key": {"user": "nested"}}

    def test_empty_dict(self):
        assert _build_nested_overrides({}) == {}

    def test_case_insensitive_lowered(self):
        env = {"MyVar.SubKey": "val"}
        result = _build_nested_overrides(env)
        assert result == {"myvar": {"subkey": "val"}}


# ---------------------------------------------------------------------------
# _apply_nested_overrides
# ---------------------------------------------------------------------------
class TestApplyNestedOverrides:
    def test_overrides_matching_keys(self):
        data = {"user": "old", "pass": "old"}
        overrides = {"user": "new", "pass": "new"}
        changed = _apply_nested_overrides(data, overrides)
        assert changed is True
        assert data == {"user": "new", "pass": "new"}

    def test_no_match_returns_false(self):
        data = {"user": "old"}
        overrides = {"other": "val"}
        changed = _apply_nested_overrides(data, overrides)
        assert changed is False
        assert data == {"user": "old"}

    def test_nested_dict_override(self):
        data = {"conn": {"host": "old", "port": "old"}}
        overrides = {"conn": {"host": "new"}}
        changed = _apply_nested_overrides(data, overrides)
        assert changed is True
        assert data == {"conn": {"host": "new", "port": "old"}}

    def test_partial_override_keeps_others(self):
        data = {"user": "old", "email": "old"}
        overrides = {"user": "new"}
        _apply_nested_overrides(data, overrides)
        assert data == {"user": "new", "email": "old"}

    def test_empty_overrides(self):
        data = {"user": "old"}
        changed = _apply_nested_overrides(data, {})
        assert changed is False
