# EnvManageLibrary

Robot Framework keyword library that overrides test variables with values from `.env` files.

Variables loaded via Robot Framework's `Variables` directive (from YAML files) are automatically matched against `.env` entries and overridden at test-case scope.

## Installation

### Option 1: From PyPI

```bash
pip install robotframework-env-manage-library
```

### Option 2: From local .whl / .tar.gz file

```bash
pip install robotframework_env_manage_library-0.1.0-py3-none-any.whl
```

### Option 3: From local packages directory (offline)

```bash
pip install --no-index --find-links=./packages robotframework-env-manage-library
```

## .env Naming Convention

The dot (`.`) separator distinguishes nested dict keys from flat variable names containing underscores.

| .env Key | RF Variable | Type |
|---|---|---|
| `USER=value` | `${user}` | Flat |
| `DB_HOST=value` | `${db_host}` | Flat |
| `AUTHEN.USER=value` | `${authen}[user]` | Nested dict |
| `DB.CONN.HOST=value` | `${db}[conn][host]` | Deep nested dict |

## Usage

### YAML data files

```yaml
# data/credentials.yaml
user: testuser
pass: "default_pass"
```

```yaml
# data/config.yaml
db:
  host: localhost
  port: "5432"
```

### .env file

```env
# Flat overrides
USER=admin
PASS=S3cretK3y!

# Nested dict overrides (use dot separator)
DB.HOST=prod-db.example.com
DB.PORT=5433
```

### Robot Framework test

```robot
*** Settings ***
Library    EnvManageLibrary
Variables  ${CURDIR}/data/credentials.yaml
Variables  ${CURDIR}/data/config.yaml

*** Test Cases ***
Verify Credentials Override
    Override Variables From Env    path/to/.env
    Should Be Equal    ${user}    admin
    Should Be Equal    ${pass}    S3cretK3y!

Verify Config Override
    Override Variables From Env    path/to/.env
    Should Be Equal    ${db}[host]    prod-db.example.com
    Should Be Equal    ${db}[port]    5433

Values Reset Between Tests
    # No override called - original YAML values are intact
    Should Be Equal    ${user}    testuser
    Should Be Equal    ${db}[host]    localhost
```

## How It Works

1. Robot Framework loads YAML files via `Variables`, creating RF variables
2. `Override Variables From Env` parses the `.env` file
3. For each RF variable, it checks for a matching `.env` key:
   - Flat string variables: YAML key `user` matches env key `USER`
   - Dict variables: YAML key `db` with child `host` matches env key `DB.HOST`
4. Matched values are overridden using `Set Test Variable` (scoped to current test only)
5. Original YAML values remain intact for other test cases

## Key Behaviors

- Override scope is per test case - original values reset between tests
- If `.env` file doesn't exist, all variables keep their YAML values
- Case insensitive - YAML `user` matches env `USER`
- Flat keys with underscores (`DB_HOST`) only override flat RF variables (`${db_host}`), not nested dicts
- Dict values are deep-copied before override to prevent mutation

## Development

```bash
git clone https://github.com/Non-Spk/robotframework-env-manage-library.git
cd robotframework-env-manage-library
python -m venv venv

# Windows
venv\Scripts\pip install -e ".[dev]"
venv\Scripts\pytest -v

# macOS / Linux
source venv/bin/activate
pip install -e ".[dev]"
pytest -v
```

## Building

```bash
pip install build
python -m build
```

This produces `dist/robotframework_env_manage-0.1.0-py3-none-any.whl` and `dist/robotframework_env_manage-0.1.0.tar.gz`.

## License

MIT
