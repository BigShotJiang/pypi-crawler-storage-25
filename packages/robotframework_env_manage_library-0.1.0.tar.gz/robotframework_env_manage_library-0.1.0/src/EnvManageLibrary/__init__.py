"""EnvManageLibrary - Robot Framework library for .env variable overrides."""

from .env_manage_library import EnvManageLibrary

__all__ = ["EnvManageLibrary"]
__version__ = "0.1.0"
