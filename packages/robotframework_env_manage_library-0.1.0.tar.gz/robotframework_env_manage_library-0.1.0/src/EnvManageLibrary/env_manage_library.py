"""
EnvManageLibrary - Robot Framework keyword library.

Scans existing RF variables and overrides their values with matching
entries from a .env file, scoped to the current test case.

.env naming convention:
    - Flat variable ``${user}``            -> ``USER=value``
    - Flat variable ``${authen_key_user}`` -> ``AUTHEN_KEY_USER=value``
    - Nested dict ``${authen_key}[user]``  -> ``AUTHEN_KEY.USER=value``

The dot (``.``) separator distinguishes nested dict keys from flat
variable names that contain underscores.

Usage in Robot Framework:
    Library    EnvManageLibrary
    Variables  ${CURDIR}/data/authen.yaml

    EnvManageLibrary.Override Variables From Env    .env
"""

import copy
from pathlib import Path
from robot.api.deco import keyword
from robot.libraries.BuiltIn import BuiltIn

_SKIP_VARS = frozenset((
    "None", "True", "False", "null", "true", "false",
    "EMPTY", "SPACE", "\\n",
))


def _load_dotenv(env_path):
    """Parse a .env file into a dict."""
    env_vars = {}
    path = Path(env_path)
    if not path.is_file():
        return env_vars
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        env_vars[key.strip()] = value.strip().strip("'\"")
    return env_vars


def _build_nested_overrides(env_vars):
    """Build a lookup for nested dict overrides from dot-notation env keys.

    Returns a dict like: ``{"authen_key": {"user": "val", "pass": "val"}}``
    from env keys like ``AUTHEN_KEY.USER=val``, ``AUTHEN_KEY.PASS=val``.
    """
    nested = {}
    for env_key, env_value in env_vars.items():
        if "." not in env_key:
            continue
        parts = env_key.split(".")
        var_name = parts[0].lower()
        remaining = [p.lower() for p in parts[1:]]

        current = nested.setdefault(var_name, {})
        for part in remaining[:-1]:
            current = current.setdefault(part, {})
        current[remaining[-1]] = env_value
    return nested


def _apply_nested_overrides(data, overrides):
    """Apply nested overrides to a dict. Returns True if anything changed."""
    changed = False
    for key in data:
        if key not in overrides:
            continue
        override = overrides[key]
        if isinstance(data[key], dict) and isinstance(override, dict):
            if _apply_nested_overrides(data[key], override):
                changed = True
        else:
            data[key] = override
            changed = True
    return changed


class EnvManageLibrary:
    """Robot Framework library for overriding variables from .env files."""

    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    @keyword("Override Variables From Env")
    def override_variables_from_env(self, env_path=".env"):
        """Override current RF variables with values from a .env file.

        Naming convention in .env:
            - ``USER=value``            -> overrides flat ``${user}``
            - ``AUTHEN_KEY_USER=value`` -> overrides flat ``${authen_key_user}``
            - ``AUTHEN_KEY.USER=value`` -> overrides nested ``${authen_key}[user]``

        Overrides are scoped to the current test case (``Set Test Variable``).
        If .env file is missing, nothing changes.
        """
        builtin = BuiltIn()
        dot_env = _load_dotenv(env_path)

        if not dot_env:
            return

        flat_env = {k: v for k, v in dot_env.items() if "." not in k}
        nested_overrides = _build_nested_overrides(dot_env)

        rf_vars = builtin.get_variables()

        seen = set()
        for rf_name, rf_value in rf_vars.items():
            if len(rf_name) < 4 or rf_name[1] != "{" or not rf_name.endswith("}"):
                continue

            var_name = rf_name[2:-1]
            if var_name in seen:
                continue
            seen.add(var_name)

            if var_name.startswith((" ", "/", "{")):
                continue
            if var_name in _SKIP_VARS:
                continue
            if var_name.upper() == var_name and var_name not in flat_env:
                continue

            if isinstance(rf_value, dict):
                if var_name in nested_overrides:
                    new_value = copy.deepcopy(rf_value)
                    if _apply_nested_overrides(new_value, nested_overrides[var_name]):
                        builtin.set_test_variable(f"${{{var_name}}}", new_value)
            elif isinstance(rf_value, str):
                env_value = flat_env.get(var_name.upper())
                if env_value is not None:
                    builtin.set_test_variable(f"${{{var_name}}}", env_value)
