# LaraFastAPI

A framework for FastAPI similar to Laravel

## install

(1) install: `pip install LaraFastAPI`

(2) build application directories: `lara_post_install`

(3) run the app: `uvicorn main:app --reload`

## usage

### (1) command

① create controller : `python larafast make:controller User`

② create api-controller : `python larafast make:api User`

③ create restful-controller : `python larafast make:rest User`

④ create model : `python larafast make:model User`
