from setuptools import setup, find_packages

# Setup 配置
setup(
    name="LaraFastAPI",  # 项目名称
    version="0.1.4",  # 版本号
    author="LiuShilong",
    author_email="hbynlsl@hotmail.com",
    description="A framework for FastAPI similar to Laravel",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/hbynlsl/LaraFastAPI",
    packages=find_packages(),  # 自动检测子包
    include_package_data=True,  # 启用包含非 Python 文件的功能
    package_data={  # 直接列举需要的文件
        "LaraFastAPI": ["assets/*"],  # 包含 assets 文件夹中的所有文件
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[  # 安装依赖项
        "fastapi",
        "uvicorn",
        "jinja2",
        "python-dotenv",
        "masonite-orm",
        "pymysql"
    ],
    entry_points={
        'console_scripts': [
            'lara_post_install=LaraFastAPI.copy_assets:post_install_logic',
        ],
    },
)