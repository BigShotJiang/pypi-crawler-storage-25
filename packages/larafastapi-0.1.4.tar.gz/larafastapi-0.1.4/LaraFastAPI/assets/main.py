from LaraFastAPI.Application import Application

app = Application().app
