
routes = [
    # ('/路径', '标签', rest实例)
]