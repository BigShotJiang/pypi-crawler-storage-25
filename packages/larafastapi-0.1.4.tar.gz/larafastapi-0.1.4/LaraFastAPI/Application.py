from fastapi import FastAPI
from routes.controller import routes as controller_router
from routes.api import routes as api_router
from routes.rest import routes as rest_router
from routes.web import router as web_router
from LaraFastAPI.helpers import controller_router, resource_router

class Application:
    """创建FastAPI应用实例"""
    app = None
    def __init__(self, title: str = "FastAPI MVC Example"):
        # 创建FastAPI应用实例
        self.app = FastAPI(title=title)

        # 注册web路由
        self.app.include_router(web_router)
        # 注册controller路由
        for router in controller_router:
            self.app.include_router(controller_router(router[2], router[0], [router[1]]))
        # 注册api路由
        for router in api_router:
            self.app.include_router(resource_router(router[2], router[0], [router[1]]))
        # 注册rest路由
        for router in rest_router:
            self.app.include_router(resource_router(router[2], router[0], [router[1]]))
