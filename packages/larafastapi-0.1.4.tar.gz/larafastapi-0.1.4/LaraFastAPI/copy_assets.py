import os
import shutil
import importlib.resources as pkg_resources
import LaraFastAPI


def post_install_logic():
    """自定义安装后命令，用于在安装后执行额外操作（例如文件拷贝）"""
    # 自定义安装后逻辑：建立项目目录结构
    os.makedirs(os.path.join(os.getcwd(), 'config'), exist_ok=True)
    os.makedirs(os.path.join(os.getcwd(), 'routes'), exist_ok=True)
    os.makedirs(os.path.join(os.getcwd(), 'app'), exist_ok=True)
    os.makedirs(os.path.join(os.getcwd(), 'app', 'controllers'), exist_ok=True)
    os.makedirs(os.path.join(os.getcwd(), 'app', 'apis'), exist_ok=True)
    os.makedirs(os.path.join(os.getcwd(), 'app', 'rests'), exist_ok=True)
    os.makedirs(os.path.join(os.getcwd(), 'app', 'models'), exist_ok=True)
    os.makedirs(os.path.join(os.getcwd(), 'app', 'views'), exist_ok=True)

    # 自定义执行逻辑：复制assets目录下的文件到对应位置
    assets_dir = os.path.join(os.path.dirname(__file__), 'LaraFastAPI', 'assets')
    files = [
        ("controller.py", os.path.join(os.getcwd(), 'app', 'controllers', 'UserController.py')),
        ("model.py", os.path.join(os.getcwd(), 'app', 'models', 'User.py')),
        ("web.py", os.path.join(os.getcwd(), 'routes', 'web.py')),
        ("api.py", os.path.join(os.getcwd(), 'routes', 'api.py')),
        ("rest.py", os.path.join(os.getcwd(), 'routes', 'rest.py')),
        ("controller_routes.py", os.path.join(os.getcwd(), 'routes', 'controller.py')),
        ("larafast", os.path.join(os.getcwd(), 'larafast')),
        ("database.py", os.path.join(os.getcwd(), 'config', 'database.py')),
        ("main.py", os.path.join(os.getcwd(), 'main.py')),
    ]
    for filename, destination in files:
        source_file = pkg_resources.files(LaraFastAPI).joinpath(f'assets/{filename}')
        if os.path.isfile(source_file):
            print(f"Copying file {source_file} to {destination} ...")
            shutil.copy2(source_file, destination)