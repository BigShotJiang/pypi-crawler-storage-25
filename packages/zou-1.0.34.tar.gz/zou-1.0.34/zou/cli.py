#!/usr/bin/env python

import warnings

warnings.filterwarnings("ignore")
import os
import sys
import click


def _get_app():
    from zou.app import app

    return app


def _get_db_uri():
    from sqlalchemy.engine.url import URL

    return URL.create(
        drivername=os.getenv("DB_DRIVER", "postgresql+psycopg"),
        host=os.getenv("DB_HOST", "localhost"),
        port=os.getenv("DB_PORT", "5432"),
        username=os.getenv("DB_USERNAME", "postgres"),
        password=os.getenv("DB_PASSWORD", "mysecretpassword"),
        database=os.getenv("DB_DATABASE", "zoudb"),
    ).render_as_string(hide_password=False)


def _get_alembic_config():
    """Build an Alembic config that talks directly to the DB.

    Bypasses Flask/Flask-SQLAlchemy/Flask-Migrate entirely — only needs
    Alembic + the DB driver.  env.py detects the absence of a Flask app
    context and reads the URL from the Alembic config instead.
    """
    from alembic.config import Config

    cfg = Config(os.path.join(_get_migrations_path(), "alembic.ini"))
    cfg.set_main_option("script_location", _get_migrations_path())
    # Escape % for configparser, which Alembic uses internally and would
    # otherwise treat percent-encoded characters in the URI (e.g. a "=" in
    # the DB password rendered as "%3D") as interpolation tokens.
    cfg.set_main_option("sqlalchemy.url", _get_db_uri().replace("%", "%%"))
    return cfg


def _get_alembic_config_legacy():
    """Alembic config that includes both current and legacy migrations.

    Used as fallback when an instance is on a pre-squash revision.
    """
    from alembic.config import Config

    migrations_path = _get_migrations_path()
    versions_path = os.path.join(migrations_path, "versions")
    legacy_path = os.path.join(versions_path, "legacy")

    cfg = Config(os.path.join(migrations_path, "alembic.ini"))
    cfg.set_main_option("script_location", migrations_path)
    cfg.set_main_option("sqlalchemy.url", _get_db_uri().replace("%", "%%"))
    cfg.set_main_option("version_locations", f"{versions_path} {legacy_path}")
    return cfg


def _get_migrations_path():
    from zou import __file__ as root_path

    return os.path.join(os.path.dirname(root_path), "migrations")


@click.group()
def cli():
    pass


@cli.command()
def version():
    """
    Return current installation version.
    """
    from zou import __version__

    print(f"Zou version: {__version__}")


@cli.command()
@click.argument("shell", type=click.Choice(["bash", "zsh", "fish"]))
def shell_completion(shell):
    """
    Print shell completion script.

    To enable autocompletion, add the output to your shell config:

    \b
      zou shell-completion bash >> ~/.bashrc
      zou shell-completion zsh >> ~/.zshrc
      zou shell-completion fish > ~/.config/fish/completions/zou.fish
    """
    from click.shell_completion import get_completion_class

    comp_cls = get_completion_class(shell)
    comp = comp_cls(cli, {}, "zou", "_ZOU_COMPLETE")
    click.echo(comp.source())


@cli.command()
def init_db():
    "Create database table (database must be created through PG client)."
    from alembic import command

    print("Creating database and tables...")
    command.upgrade(_get_alembic_config(), "head")
    print("Database and tables created.")


@cli.command()
def is_db_ready():
    """
    Return a message telling whether the database is initialized or not.
    """
    from zou.app.utils import dbhelpers

    with _get_app().app_context():
        is_init = dbhelpers.is_init()
        if is_init:
            print("Database is initialized.")
        else:
            print(
                "Database is not initialized. "
                "Run 'zou init-db' and 'zou init-data'."
            )


@cli.command()
@click.option("--message", default="")
def migrate_db(message):
    """
    Generate migration files to describe a new revision of the database schema
    (for development only).
    """
    import flask_migrate

    with _get_app().app_context():
        flask_migrate.migrate(
            directory=_get_migrations_path(), message=message
        )


@cli.command()
@click.option("--revision", default="-1")
def downgrade_db(revision):
    """
    Downgrade db to previous revision of the database schema
    (for development only). For revision you can use an hash or a relative migration identifier.
    """
    from alembic import command

    command.downgrade(_get_alembic_config(), revision)


@cli.command()
def clear_db():
    "Drop all tables from database"

    import flask_migrate

    from zou.app.utils import dbhelpers

    with _get_app().app_context():
        print("Deleting database and tables...")
        dbhelpers.drop_all()
        print("Database and tables deleted.")
        flask_migrate.stamp(directory=_get_migrations_path(), revision="base")


@cli.command()
def reset_db():
    "Drop all tables, then recreate them."
    import flask_migrate

    from zou.app.utils import dbhelpers

    migrations_path = _get_migrations_path()
    with _get_app().app_context():
        print("Deleting database and tables...")
        dbhelpers.drop_all()
        print("Database and tables deleted.")
        flask_migrate.stamp(directory=migrations_path, revision="base")
        flask_migrate.upgrade(directory=migrations_path)
        print("Database and tables created.")


@cli.command()
@click.option("--no-telemetry", is_flag=True, default=False)
def upgrade_db(no_telemetry=False):
    """
    Upgrade database schema. Send anonymized statistics to our telemetry
    services (user and preview amounts). It allows us to size the Kitsu
    community.
    """
    import traceback

    from alembic import command
    from alembic.script import ScriptDirectory
    from sqlalchemy import create_engine, text, pool

    cfg = _get_alembic_config()

    # Detect if the instance is on a pre-squash revision and needs
    # the legacy migrations to catch up first.
    db_uri = cfg.get_main_option("sqlalchemy.url")
    engine = create_engine(db_uri, poolclass=pool.NullPool)
    with engine.connect() as conn:
        try:
            row = conn.execute(
                text("SELECT version_num FROM alembic_version")
            ).first()
            current_rev = row[0] if row else None
        except Exception:
            current_rev = None
    engine.dispose()

    if current_rev is not None:
        script = ScriptDirectory.from_config(cfg)
        known = {r.revision for r in script.walk_revisions()}
        if current_rev not in known:
            print(
                f"Revision {current_rev} not in current migrations, "
                "using legacy migrations to catch up..."
            )
            command.upgrade(_get_alembic_config_legacy(), "a1b2c3d4e5f6")

    command.upgrade(cfg, "head")

    is_self_hosted = os.getenv("IS_SELF_HOSTED", "true").lower() in (
        "y",
        "yes",
        "t",
        "true",
        "on",
        "1",
    )
    if not no_telemetry and is_self_hosted:
        with _get_app().app_context():
            from zou.app.services import telemetry_services

            try:
                telemetry_services.send_main_infos()
            except Exception:
                traceback.print_exc()


@cli.command()
@click.option("--revision", default=None)
def stamp_db(revision):
    "Set the database schema revision to current one."
    from alembic import command

    cfg = _get_alembic_config()
    command.stamp(cfg, revision if revision is not None else "head")


@cli.command()
def clear_memory_cache():
    "Clear Redis memory cache."
    from zou.app import cache

    with _get_app().app_context():
        cache.clear()


@cli.command()
def reset_migrations():
    "Set the database schema revision to first one."
    from alembic import command

    command.stamp(_get_alembic_config(), "base")


@cli.command()
@click.argument("email")
@click.option("--password", default=None)
def create_admin(email, password):
    """
    Create an admin user to allow usage of the API when database is empty.
    """
    from sqlalchemy.exc import IntegrityError

    from zou.app.utils import auth
    from zou.app.services import persons_service
    from zou.app.services.exception import (
        IsUserLimitReachedException,
        PersonNotFoundException,
    )

    with _get_app().app_context():
        try:
            person = persons_service.get_person_by_email(email)
            if person["role"] != "admin":
                persons_service.update_person(
                    person["id"],
                    {"role": "admin"},
                    bypass_protected_accounts=True,
                )
                print("Existing user's role has been upgraded to 'admin'.")
        except PersonNotFoundException:
            try:
                if password is None:
                    raise click.MissingParameter(
                        param_type="option", param_hint="--password"
                    )
                auth.validate_password(password)
                # Allow "admin@example.com" to be invalid.
                if email != "admin@example.com":
                    auth.validate_email(email)
                if persons_service.is_user_limit_reached():
                    raise IsUserLimitReachedException
                password = auth.encrypt_password(password)
                persons_service.create_person(
                    email, password, "Super", "Admin", role="admin"
                )
                print("Admin successfully created.")
            except IntegrityError:
                print("User already exists for this email.")
                sys.exit(1)
            except auth.PasswordTooShortException:
                print("Password is too short.")
                sys.exit(1)
            except auth.EmailNotValidException as e:
                print(f"Email is not valid: {e}")
                sys.exit(1)
            except IsUserLimitReachedException:
                print(
                    f"User limit reached (limit {persons_service.get_user_limit()})."
                )
                sys.exit(1)


@cli.command()
def clean_auth_tokens():
    "Remove revoked and expired tokens."
    from zou.app.utils import commands

    commands.clean_auth_tokens()


@cli.command()
def clear_all_auth_tokens():
    "Remove all authentication tokens."
    from zou.app.utils import commands

    commands.clear_all_auth_tokens()


@cli.command()
@click.option(
    "--domain",
    "-d",
    type=click.Choice(["2d", "3d", "vfx", "games"], case_sensitive=False),
    default="3d",
    help="Domain preset: 2d (2D production), 3d (3D animation), vfx (VFX), games (video games).",
)
def init_data(domain):
    "Generate minimal data set required to run Kitsu."
    from zou.app.utils import commands

    commands.init_data(domain=domain.lower())


@cli.command()
@click.argument("email-or-desktop-login")
def disable_two_factor_authentication(email_or_desktop_login):
    """
    Disable two factor authentication for given user.
    """
    from zou.app.services import persons_service, auth_service
    from zou.app.services.exception import (
        PersonNotFoundException,
        TwoFactorAuthenticationNotEnabledException,
    )

    with _get_app().app_context():
        try:
            person = persons_service.get_person_by_email_desktop_login(
                email_or_desktop_login
            )
            auth_service.disable_two_factor_authentication_for_person(
                person["id"]
            )
            print(
                f"Two factor authentication disabled for {email_or_desktop_login}."
            )
        except PersonNotFoundException:
            print(f"Email ({email_or_desktop_login}) not listed in database.")
            sys.exit(1)
        except TwoFactorAuthenticationNotEnabledException:
            print(
                f"Two factor authentication can't be disabled for {email_or_desktop_login} because it's not activated."
            )
            sys.exit(1)


@cli.command()
@click.argument("email")
@click.option("--password", required=True)
def change_password(email, password):
    """
    Change the password of given user.
    """
    from zou.app.utils import auth
    from zou.app.services import persons_service

    with _get_app().app_context():
        try:
            auth.validate_password(password)
            password = auth.encrypt_password(password)
            persons_service.update_password(email, password)
            print("Password changed for %s" % email)
        except auth.PasswordTooShortException:
            print("The password is too short.")
            sys.exit(1)


@cli.command()
@click.argument("email")
@click.option("--unactive", is_flag=True, default=False)
def set_person_as_active(email, unactive):
    """
    Set a person as active.
    """
    from zou.app.services import persons_service
    from zou.app.services.exception import (
        IsUserLimitReachedException,
        PersonNotFoundException,
    )

    with _get_app().app_context():
        try:
            if persons_service.is_user_limit_reached() and not unactive:
                raise IsUserLimitReachedException
            person = persons_service.get_person_by_email_raw(email)
            person.update({"active": not unactive})
            print(
                f'Person {email} is set as an {"active" if not unactive else "unactive"} user.'
            )
        except IsUserLimitReachedException:
            print(
                f"User limit reached (limit {persons_service.get_user_limit()})."
            )
            sys.exit(1)
        except PersonNotFoundException:
            print(f"Email ({email}) not listed in database.")
            sys.exit(1)


@cli.command()
def sync_with_ldap_server():
    """
    For each user account in your LDAP server, it creates a new user.
    """
    from zou.app.utils import commands
    from zou.app.services import persons_service

    with _get_app().app_context():
        if persons_service.is_user_limit_reached():
            print(
                f"User limit reached (limit {persons_service.get_user_limit()}). New users will not be added."
            )
            sys.exit(1)
        commands.sync_with_ldap_server()


@cli.command()
def reload_config():
    """
    Read USER_LIMIT, DEFAULT_TIMEZONE, DEFAULT_LOCALE,
    JOB_QUEUE_NOMAD_HOST, JOB_QUEUE_NOMAD_NORMALIZE_JOB, and
    JOB_QUEUE_NOMAD_PLAYLIST_JOB from environment variables and push
    them to Redis so that all workers pick up the new values
    immediately.
    """
    from zou.app.stores.config_store import sync_config

    with _get_app().app_context():
        values = sync_config()
        for key, value in values.items():
            print(f"  {key} = {value}")
        print("Config synced to Redis.")


if os.getenv("ADMIN_TOKEN"):

    @cli.command()
    @click.option(
        "--host",
        default="http://localhost:5000",
        help="Zou API host URL.",
    )
    def get_current_config(host):
        """
        Fetch the current config from the API and display env-cli,
        redis, and env-api values side by side.

        Checks that env-cli == redis for every key.  Exits with code 1
        if any mismatch is found.
        """
        import requests

        ENV_VAR_MAP = {
            "user_limit": "USER_LIMIT",
            "default_timezone": "DEFAULT_TIMEZONE",
            "default_locale": "DEFAULT_LOCALE",
            "nomad_host": "JOB_QUEUE_NOMAD_HOST",
            "nomad_normalize_job": "JOB_QUEUE_NOMAD_NORMALIZE_JOB",
            "nomad_playlist_job": "JOB_QUEUE_NOMAD_PLAYLIST_JOB",
        }

        token = os.getenv("ADMIN_TOKEN")
        url = f"{host}/admin/config/check"
        try:
            response = requests.get(
                url, headers={"Authorization": f"Bearer {token}"}
            )
            response.raise_for_status()
        except requests.ConnectionError:
            click.secho(f"Cannot connect to {host}", fg="red")
            sys.exit(1)
        except requests.HTTPError:
            click.secho(
                f"Error {response.status_code}: {response.text}",
                fg="red",
            )
            sys.exit(1)

        data = response.json()
        active_users = data.pop("active_users", None)

        click.secho("Config check", fg="cyan", bold=True)
        click.echo()

        col = 22
        name_width = max(len(k) for k in data)
        header = (
            f"  {'Key':<{name_width}}"
            f"  {'Env (CLI)':<{col}}"
            f"  {'Redis':<{col}}"
            f"  {'Env (API)':<{col}}"
            f"  Status"
        )
        click.secho(header, bold=True)
        click.echo(f"  {'─' * (name_width + 3 * col + 10)}")

        has_error = False
        for key, values in data.items():
            env_var = ENV_VAR_MAP.get(key, "")
            env_cli = os.getenv(env_var, "")
            redis_val = values.get("redis")
            redis_str = str(redis_val) if redis_val is not None else "∅"
            env_api = str(values.get("env", ""))

            match = env_cli == redis_str
            if not match:
                has_error = True
            symbol = "✓" if match else "✗"
            color = "green" if match else "red"

            click.echo(
                f"  {key:<{name_width}}"
                f"  {env_cli:<{col}}"
                f"  {redis_str:<{col}}"
                f"  {env_api:<{col}}  ",
                nl=False,
            )
            click.secho(symbol, fg=color)

        if active_users is not None:
            click.echo()
            click.secho(f"  Active users: {active_users}", fg="cyan")

        if has_error:
            click.echo()
            click.secho("  env-cli and redis are out of sync!", fg="red")
            sys.exit(1)


@cli.command()
@click.option("--source", default="http://localhost:5000")
@click.option("--project")
@click.option("--no-projects", is_flag=True)
@click.option("--with-events", is_flag=True)
@click.option("--only-projects", is_flag=True)
def sync_full(
    source,
    project=None,
    with_events=False,
    no_projects=False,
    only_projects=False,
):
    """
    Retrieve all data from source instance. It expects that credentials to
    connect to source instance are given through SYNC_LOGIN and SYNC_PASSWORD
    environment variables.
    """
    from zou.app.utils import commands

    print("Start syncing.")
    login = os.getenv("SYNC_LOGIN")
    password = os.getenv("SYNC_PASSWORD")
    commands.import_data_from_another_instance(
        source,
        login,
        password,
        project=project,
        with_events=with_events,
        no_projects=no_projects,
        only_projects=only_projects,
    )
    print("Syncing ended.")


@cli.command()
@click.option("--source", default="http://localhost:5000", show_default=True)
@click.option("--project", default=None, show_default=True)
@click.option(
    "--multithreaded", is_flag=True, show_default=True, default=False
)
@click.option("--number-workers", default=30, show_default=True, type=int)
@click.option("--number-attemps", default=3, show_default=True, type=int)
@click.option("--force-resync", is_flag=True, show_default=True, default=False)
def sync_full_files(
    source,
    project,
    multithreaded,
    number_workers,
    number_attemps,
    force_resync,
):
    """
    Retrieve all files from source instance. It expects that credentials to
    connect to source instance are given through SYNC_LOGIN and SYNC_PASSWORD
    environment variables.
    """
    from zou.app.utils import commands

    print("Start syncing.")
    login = os.getenv("SYNC_LOGIN")
    password = os.getenv("SYNC_PASSWORD")
    dict_errors = commands.import_files_from_another_instance(
        source,
        login,
        password,
        project=project,
        multithreaded=multithreaded,
        number_workers=number_workers,
        number_attemps=number_attemps,
        force_resync=force_resync,
    )
    print("Syncing ended.")
    if dict_errors:
        print("Errors summary:")
        for prefix, value in dict_errors.items():
            print(f"{prefix}:")
            for id, error in value.items():
                print(f"{id}:\n{error}")
            print()
        sys.exit(1)


@cli.command()
@click.option("--event-source", default="http://localhost:8080")
@click.option("--source", default="http://localhost:8080/api")
@click.option("--logs-directory", default=None)
def sync_changes(event_source, source, logs_directory):
    """
    Run a daemon that import data related to any change happening on source
    instance. It expects that credentials to connect to source instance are
    given through SYNC_LOGIN and SYNC_PASSWORD environment variables.
    """
    from zou.app.utils import commands

    login = os.getenv("SYNC_LOGIN")
    password = os.getenv("SYNC_PASSWORD")
    commands.run_sync_change_daemon(
        event_source, source, login, password, logs_directory
    )


@cli.command()
@click.option("--event-source", default="http://localhost:8080")
@click.option("--source", default="http://localhost:8080/api")
@click.option("--logs-directory", default=None)
def sync_file_changes(event_source, source, logs_directory):
    """
    Run a daemon that download files related to any change happening on source
    instance. It expects that credentials to connect to source instance are
    given through SYNC_LOGIN and SYNC_PASSWORD environment variables.
    """
    from zou.app.utils import commands

    login = os.getenv("SYNC_LOGIN")
    password = os.getenv("SYNC_PASSWORD")
    commands.run_sync_file_change_daemon(
        event_source, source, login, password, logs_directory
    )


@cli.command()
@click.option("--source", default="http://localhost:8080/api")
@click.option("--minutes", default=0)
@click.option("--page-size", default=300)
def sync_last_events(source, minutes, limit):
    """
    Retrieve last events that occured on source instance and import data related
    to them. It expects that credentials to connect to source instance are
    given through SYNC_LOGIN and SYNC_PASSWORD environment variables.
    """
    from zou.app.utils import commands

    login = os.getenv("SYNC_LOGIN")
    password = os.getenv("SYNC_PASSWORD")
    commands.import_last_changes_from_another_instance(
        source, login, password, minutes=minutes, limit=limit
    )


@cli.command()
@click.option("--source", default="http://localhost:8080/api")
@click.option("--minutes", default=20)
@click.option("--page-size", default=50)
def sync_last_files(source, minutes, limit):
    """
    Retrieve last preview files and thumbnails uploaded on source instance.
    It expects that credentials to connect to source instance are
    given through SYNC_LOGIN and SYNC_PASSWORD environment variables.
    """
    from zou.app.utils import commands

    login = os.getenv("SYNC_LOGIN")
    password = os.getenv("SYNC_PASSWORD")
    commands.import_last_file_changes_from_another_instance(
        source, login, password, minutes=minutes, limit=limit
    )


@cli.command()
def download_storage_files():
    """
    Download all files from a Swift object storage and store them in a local
    storage.
    """
    from zou.app.utils import commands

    commands.download_file_from_storage()


@cli.command()
@click.option("--store", is_flag=True)
def dump_database(store=False):
    """
    Dump database described in Zou environment variables and save it to
    configured object storage.
    """
    from zou.app.utils import commands

    commands.dump_database(store)


@cli.command()
@click.option("--days", default=None)
def upload_files_to_cloud_storage(days):
    """
    Upload all files related to previews to configured object storage.
    """
    from zou.app.utils import commands

    commands.upload_files_to_cloud_storage(days)


@cli.command()
@click.option("--project-id")
def clean_tasks_data(project_id):
    """
    Reset task models data (retake count, wip start date and end date)
    """
    if project_id is not None:
        from zou.app.utils import commands

        commands.reset_tasks_data(project_id)


@cli.command()
@click.option("--days", default=90)
def remove_old_data(days):
    """
    Remove old events, notifications and login logs older than 90 days
    (by default).
    """
    from zou.app.utils import commands

    commands.remove_old_data(days)


@cli.command()
def reset_search_index():
    """
    Reset search index.
    """
    from zou.app.utils import commands

    commands.reset_search_index()


@cli.command()
@click.option("--query", default="")
def search_asset(query):
    """ """
    from zou.app.utils import commands

    commands.search_asset(query)


@cli.command()
@click.option("--project", default=None, show_default=True)
@click.option("--entity-id", default=None, show_default=True)
@click.option("--episode", default=None, show_default=True, multiple=True)
@click.option("--only-shots", is_flag=True, default=False, show_default=True)
@click.option("--only-assets", is_flag=True, default=False, show_default=True)
@click.option("--with-tiles", is_flag=True, default=False, show_default=True)
@click.option(
    "--with-metadata", is_flag=True, default=False, show_default=True
)
@click.option(
    "--with-thumbnails", is_flag=True, default=False, show_default=True
)
@click.option(
    "--force-regenerate-tiles", is_flag=True, default=False, show_default=True
)
def generate_preview_extra(
    project,
    entity_id,
    episode,
    only_shots,
    only_assets,
    with_tiles,
    with_metadata,
    with_thumbnails,
    force_regenerate_tiles,
):
    """
    Generate tiles, thumbnails and metadata for all previews.
    """
    from zou.app.utils import commands

    commands.generate_preview_extra(
        project=project,
        entity_id=entity_id,
        episodes=episode,
        only_shots=only_shots,
        only_assets=only_assets,
        force_regenerate_tiles=force_regenerate_tiles,
        with_tiles=with_tiles,
        with_metadata=with_metadata,
        with_thumbnails=with_thumbnails,
    )


@cli.command()
def reset_movie_files_metadata():
    """
    Store height and width metadata for all movie previews in the database.
    """
    from zou.app.utils import commands

    commands.reset_movie_files_metadata()


@cli.command()
def reset_picture_files_metadata():
    """
    Store height and width metadata for all picture previews in the database.
    """
    from zou.app.utils import commands

    commands.reset_picture_files_metadata()


@cli.command()
def reset_breakdown_data():
    """
    Reset breakdown statistics for all open projects.
    """
    from zou.app.utils import commands

    commands.reset_breakdown_data()


@cli.command()
@click.option("--email", required=True)
@click.option("--name", required=True)
@click.option(
    "--expiration-date",
    required=False,
    default=None,
    show_default=True,
    help="Format: YYYY-MM-DD",
)
@click.option("--role", required=False, default="user", show_default=True)
def create_bot(
    email,
    name,
    expiration_date,
    role,
):
    """
    Create a bot.
    """
    from zou.app.utils import commands

    commands.create_bot(
        email,
        name,
        expiration_date,
        role,
    )


@cli.command()
@click.option(
    "--preview-file-id",
    required=False,
    default=None,
    show_default=True,
)
@click.option(
    "--project-id",
    required=False,
    default=None,
    show_default=True,
)
@click.option("--all-broken", is_flag=True, default=False, show_default=True)
@click.option(
    "--all-processing", is_flag=True, default=False, show_default=True
)
@click.option("--days", type=int, default=None, show_default=True)
@click.option("--hours", type=int, default=None, show_default=True)
@click.option("--minutes", type=int, default=None, show_default=True)
def renormalize_movie_preview_files(
    preview_file_id,
    project_id,
    all_broken,
    all_processing,
    days=None,
    hours=None,
    minutes=None,
):
    """
    Renormalize all preview files.
    """
    from zou.app.utils import commands

    commands.renormalize_movie_preview_files(
        preview_file_id,
        project_id,
        all_broken,
        all_processing,
        days=days,
        hours=hours,
        minutes=minutes,
    )


@cli.command()
@click.option(
    "--path",
    required=True,
    help="Plugin path: local directory, zip file, or git repository URL",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    show_default=True,
)
def install_plugin(path, force=False):
    """
    Install a plugin and apply the migrations.
    Supports local paths, zip files, and git repository URLs.
    """
    from zou.app.services import plugins_service

    with _get_app().app_context():
        result = plugins_service.install_plugin(path, force)
    print(
        f"✅ [Plugins] Plugin {result['plugin_id']} installed."
        f" Restart the server to apply changes."
    )


@cli.command()
@click.option(
    "--id",
    required=True,
)
def uninstall_plugin(id):
    """
    Uninstall a plugin.
    """
    from zou.app.services import plugins_service

    with _get_app().app_context():
        plugins_service.uninstall_plugin(id)
    print(
        f"✅ [Plugins] Plugin {id} uninstalled."
        f" Restart the server to apply changes."
    )


@cli.command()
@click.option(
    "--path",
    required=True,
)
@click.option(
    "--id",
    help="Plugin ID (must be unique).",
    required=True,
)
@click.option(
    "--name", help="Plugin name.", default="MyPlugin", show_default=True
)
@click.option(
    "--description",
    help="Plugin description.",
    default="My plugin description.",
    show_default=True,
)
@click.option(
    "--version", help="Plugin version.", default="0.1.0", show_default=True
)
@click.option(
    "--maintainer",
    help="Plugin maintainer.",
    default="Author <author@author.com>",
    show_default=True,
)
@click.option(
    "--website",
    help="Plugin website.",
    default="mywebsite.com",
    show_default=True,
)
@click.option(
    "--license",
    help="Plugin license.",
    default="GPL-3.0-only",
    show_default=True,
)
@click.option(
    "--icon",
    help="Plugin icon (lucide-vue icon name).",
    default=None,
    show_default=True,
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    show_default=True,
)
def create_plugin_skeleton(
    path,
    id,
    name,
    description,
    version,
    maintainer,
    website,
    license,
    icon,
    force=False,
):
    """
    Create a plugin template in the given path.
    """
    from zou.app.utils import plugins as plugin_utils

    plugin_path = plugin_utils.create_plugin_skeleton(
        path,
        id,
        name,
        description,
        version,
        maintainer,
        website,
        license,
        icon,
        force,
    )
    print(f"Plugin file tree skeleton created in '{plugin_path}'.")


@cli.command()
@click.option(
    "--path",
    required=True,
)
@click.option(
    "--output-path",
    required=True,
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    show_default=True,
)
def create_plugin_package(
    path,
    output_path,
    force=False,
):
    """
    Create a plugin package.
    """
    from zou.app.utils import plugins as plugin_utils

    plugin_path = plugin_utils.create_plugin_package(path, output_path, force)
    print(f"Plugin package created in '{plugin_path}'.")


@cli.command()
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"], case_sensitive=False),
    default="table",
    show_default=True,
    help="Output format: table or json.",
)
@click.option(
    "--verbose",
    is_flag=True,
    default=False,
    help="Show more plugin information.",
)
@click.option(
    "--filter-field",
    type=click.Choice(
        ["plugin_id", "name", "maintainer", "license"],
        case_sensitive=False,
    ),
    help="Field to filter by.",
)
@click.option("--filter-value", type=str, help="Value to search in the field.")
def list_plugins(output_format, verbose, filter_field, filter_value):
    """
    List installed plugins.
    """
    from zou.app.utils import commands

    commands.list_plugins(output_format, verbose, filter_field, filter_value)


@cli.command()
@click.option(
    "--path",
    required=True,
)
@click.option("--message", default="")
def migrate_plugin_db(path, message):
    """
    Migrate plugin database.
    """
    from zou.app.utils import plugins as plugin_utils

    with _get_app().app_context():
        plugin_utils.migrate_plugin_db(path, message)
    print(f"Plugin {path} database migrated.")


if __name__ == "__main__":
    cli()
