# Файл: clinic_lib/functions.py
from datetime import datetime

FILE_NAME = "Policlinika.txt"

def add_patient():
    """1) Записать пациента"""
    name = input("Введите ФИО пациента: ")
    vrach = input("Введите к какому врачу направлен: ")
    time = input("Введите время записи: ")
    current_time = datetime.now()
    time_zap = current_time.strftime("%d.%m.%Y %H:%M")
    
    with open(FILE_NAME, "a", encoding="utf-8") as textFile:
        textFile.write(f"ФИО записанного: {name} | Записан ко: {vrach} | Записан на: {time} | Записан в: {time_zap} |\n")
    print("✔ Пациент успешно записан!")

def search_patient():
    """2) Просмотреть (найти) пациента"""
    try:
        with open(FILE_NAME, "r", encoding="utf-8") as textFile:
            print("\nПоиск по любому параметру (можно заполнить только одно поле):")
            name = input("Введите ФИО для поиска (или Enter): ").strip().lower()
            vrach = input("Введите врача для поиска (или Enter): ").strip().lower()
            time = input("Введите время для поиска (или Enter): ").strip().lower()
            
            if not name and not vrach and not time:
                print("\n[!] Вы не ввели ни одного параметра для поиска.")
                return

            print("\n--- Результаты поиска ---")
            found = False
            for line in textFile:
                line_lower = line.lower()
                match_name = name and (name in line_lower)
                match_vrach = vrach and (vrach in line_lower)
                match_time = time and (time in line_lower)
                
                if match_name or match_vrach or match_time:
                    print(line.strip())
                    found = True
            
            if not found:
                print("Пациенты по вашему запросу не найдены.")
            print("-------------------------\n")
    except FileNotFoundError:
        print("\n[Ошибка] База данных еще пуста.\n")

def delete_patient():
    """3) Удалить пациента"""
    try:
        with open(FILE_NAME, "r", encoding="utf-8") as textFile:
            lines = textFile.readlines()
            
        if not lines:
            print("\n[!] В базе данных нет ни одной записи для удаления.\n")
            return
            
        print("\n--- Текущий список пациентов ---")
        for index, line in enumerate(lines, 1):
            print(f"{index}) {line.strip()}")
        print("--------------------------------")
        
        num_to_delete = int(input("Введите НОМЕР строки, которую хотите удалить: "))
        
        if 1 <= num_to_delete <= len(lines):
            deleted_line = lines.pop(num_to_delete - 1)
            with open(FILE_NAME, "w", encoding="utf-8") as textFile:
                textFile.writelines(lines)
            print(f"\n✔ Успешно удалено: {deleted_line.strip()}")
        else:
            print("\n[Ошибка] Неверный номер строки.\n")
    except FileNotFoundError:
        print("\n[Ошибка] База данных еще пуста.\n")

def edit_patient():
    """5) Изменить данные пациента"""
    try:
        with open(FILE_NAME, "r", encoding="utf-8") as textFile:
            lines = textFile.readlines()
            
        if not lines:
            print("\n[!] В базе данных нет ни одной записи для изменения.\n")
            return
            
        print("\n--- Текущий список пациентов ---")
        for index, line in enumerate(lines, 1):
            print(f"{index}) {line.strip()}")
        print("--------------------------------")
        
        num_to_edit = int(input("Введите НОМЕР строки, которую хотите изменить: "))
        
        if 1 <= num_to_edit <= len(lines):
            print(f"\nВы редактируете запись: {lines[num_to_edit - 1].strip()}")
            new_name = input("Введите новое ФИО (или оставьте старое): ")
            new_vrach = input("Введите нового врача (или оставьте старого): ")
            new_time = input("Введите новое время записи (или оставьте старое): ")
            
            old_data = [item.split(": ")[1].strip() for item in lines[num_to_edit - 1].split(" | ") if ":" in item]
            
            final_name = new_name if new_name else old_data[0]
            final_vrach = new_vrach if new_vrach else old_data[1]
            final_time = new_time if new_time else old_data[2]
            
            current_time = datetime.now()
            time_zap = current_time.strftime("%d.%m.%Y %H:%M")
            
            new_line = f"ФИО записанного: {final_name} | Записан ко: {final_vrach} | Записан на: {final_time} | Изменено в: {time_zap} |\n"
            lines[num_to_edit - 1] = new_line
            
            with open(FILE_NAME, "w", encoding="utf-8") as textFile:
                textFile.writelines(lines)
            print(f"\n✔ Запись №{num_to_edit} успешно обновлена!")
        else:
            print("\n[Ошибка] Неверный номер строки.\n")
    except FileNotFoundError:
        print("\n[Ошибка] База данных еще пуста.\n")
