from setuptools import setup, find_packages

setup(
    name="my_super_clinic_lib",      # Имя пакета на PyPI (должно быть уникальным)
    version="0.1.0",                 # Версия вашей библиотеки
    author="Ваше Имя",
    author_email="kiaa14@it-schools.org",
    description="Мини-библиотека для управления регистратурой клиники",
    packages=find_packages(),        # Автоматически найдет папку clinic_lib
    python_requires=">=3.6",
)
