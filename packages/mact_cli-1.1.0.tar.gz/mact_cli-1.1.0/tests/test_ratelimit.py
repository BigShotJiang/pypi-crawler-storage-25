"""Rate limiting: verify 429 after exceeding the limit."""

import pytest

httpx_mod = pytest.importorskip("httpx")


def test_room_creation_rate_limit(client):
    """POST /rooms should return 429 after exceeding the rate limit."""
    for i in range(10):
        resp = client.post(
            "/rooms",
            json={
                "room_id": f"rl-room-{i}",
                "developer_id": "alice",
                "upstream_url": "http://127.0.0.1:3000",
            },
        )
        assert resp.status_code == 200, f"request {i} failed unexpectedly"

    resp = client.post(
        "/rooms",
        json={
            "room_id": "rl-room-over",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    assert resp.status_code == 429
    assert "rate limit" in resp.json()["detail"].lower()


def test_heartbeat_has_higher_limit(client, room_tokens, auth):
    """Heartbeat allows 120 req/min — verify it does not 429 at moderate load."""
    for _ in range(30):
        resp = client.post(
            f"/rooms/{room_tokens['room_id']}/presence/heartbeat",
            json={"developer_id": room_tokens["developer_id"]},
            headers=auth(room_tokens["member_token"]),
        )
        assert resp.status_code == 200


def test_rate_limiter_unit():
    from mact.server.ratelimit import RateLimitConfig, RateLimiter

    rl = RateLimiter()
    cfg = RateLimitConfig(requests=3, window_seconds=10)

    for _ in range(3):
        rl.check("test-key", cfg)

    from fastapi import HTTPException

    with pytest.raises(HTTPException) as exc_info:
        rl.check("test-key", cfg)
    assert exc_info.value.status_code == 429
