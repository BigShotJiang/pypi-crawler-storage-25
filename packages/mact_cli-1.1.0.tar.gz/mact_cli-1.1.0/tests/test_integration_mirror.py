"""Integration tests: spin up a real HTTP server and verify mirror proxy end-to-end."""

from __future__ import annotations

import asyncio
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler

import pytest

httpx_mod = pytest.importorskip("httpx")


class _UpstreamHandler(BaseHTTPRequestHandler):
    """Tiny HTTP handler that returns predictable responses."""

    def do_GET(self):
        if self.path == "/health":
            self._respond(200, "text/plain", b"ok")
        elif self.path == "/page":
            self._respond(
                200,
                "text/html",
                b"<html><body><h1>Upstream Page</h1></body></html>",
            )
        elif self.path == "/api/data":
            self._respond(200, "application/json", b'{"items":[1,2,3]}')
        elif self.path.startswith("/echo-headers"):
            import json

            headers = {k: v for k, v in self.headers.items()}
            self._respond(200, "application/json", json.dumps(headers).encode())
        else:
            self._respond(404, "text/plain", b"not found")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        self._respond(200, "application/octet-stream", body)

    def _respond(self, code: int, content_type: str, body: bytes):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Custom-Upstream", "present")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        pass


@pytest.fixture(scope="module")
def upstream_server():
    """Start a real HTTP server in a background thread, yield its base URL."""
    server = HTTPServer(("127.0.0.1", 0), _UpstreamHandler)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


@pytest.fixture
def integration_client():
    """Fresh test client for integration tests (module-scoped upstream needs function-scoped app)."""
    try:
        from fastapi.testclient import TestClient
        from mact.server.main import app
    except Exception as exc:
        pytest.skip(f"test client unavailable: {exc}")

    with TestClient(app) as tc:
        yield tc


@pytest.fixture
def live_room(integration_client, upstream_server):
    """Create a room whose upstream_url points to the real ephemeral server."""
    resp = integration_client.post(
        "/rooms",
        json={
            "room_id": "integ-room",
            "developer_id": "tester",
            "upstream_url": upstream_server,
        },
    )
    assert resp.status_code == 200
    data = resp.json()
    integration_client.post(
        "/rooms/integ-room/commits",
        json={
            "developer_id": "tester",
            "commit_hash": "abc1234",
            "branch": "main",
            "message": "initial",
        },
        headers={"Authorization": f"Bearer {data['member_token']}"},
    )
    return {**data, "room_id": "integ-room", "upstream": upstream_server}


def test_mirror_proxies_get_to_real_upstream(integration_client, live_room):
    resp = integration_client.get("/r/integ-room/health")
    assert resp.status_code == 200
    assert resp.text == "ok"


def test_mirror_proxies_html_with_injection(integration_client, live_room):
    resp = integration_client.get("/r/integ-room/page")
    assert resp.status_code == 200
    assert "<h1>Upstream Page</h1>" in resp.text
    assert "MACT live-reload" in resp.text
    assert "location.reload()" in resp.text


def test_mirror_proxies_json_without_injection(integration_client, live_room):
    resp = integration_client.get("/r/integ-room/api/data")
    assert resp.status_code == 200
    assert resp.json() == {"items": [1, 2, 3]}
    assert "MACT live-reload" not in resp.text


def test_mirror_forwards_post_body(integration_client, live_room):
    resp = integration_client.post("/r/integ-room/echo", content=b"hello-body")
    assert resp.status_code == 200
    assert resp.content == b"hello-body"


def test_mirror_preserves_upstream_custom_headers(integration_client, live_room):
    resp = integration_client.get("/r/integ-room/health")
    assert resp.headers.get("x-custom-upstream") == "present"


def test_mirror_strips_hop_by_hop_and_adds_mact_headers(integration_client, live_room):
    resp = integration_client.get("/r/integ-room/health")
    assert resp.headers.get("x-mact-upstream") == live_room["upstream"]
    assert resp.headers.get("cache-control") == "no-store"


def test_mirror_returns_404_for_upstream_404(integration_client, live_room):
    resp = integration_client.get("/r/integ-room/nonexistent-path")
    assert resp.status_code == 404


def test_mirror_offline_when_no_room(integration_client):
    resp = integration_client.get("/r/no-such-room/anything")
    assert resp.status_code == 503
    assert "Room offline" in resp.text
