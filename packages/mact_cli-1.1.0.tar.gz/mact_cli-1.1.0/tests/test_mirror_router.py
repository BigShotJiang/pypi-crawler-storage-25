"""Mirror proxy tests: offline fallback, upstream proxy, 502 on error."""

import pytest
from starlette.websockets import WebSocketDisconnect

httpx = pytest.importorskip("httpx")


def test_mirror_offline_when_no_active_upstream(client, monkeypatch):
    from mact.db import repository as repo

    monkeypatch.setattr(repo, "resolve_active_upstream", lambda *a, **kw: None)

    response = client.get("/r/demo-room")
    assert response.status_code == 503
    assert "Room offline" in response.text


def test_mirror_websocket_offline_when_no_active_upstream(client, monkeypatch):
    from mact.db import repository as repo

    monkeypatch.setattr(repo, "resolve_active_upstream", lambda *a, **kw: None)

    with pytest.raises(WebSocketDisconnect):
        with client.websocket_connect("/r/demo-room"):
            pass


class _FakeMirrorClient:
    """Fake ``httpx.AsyncClient`` that delegates ``request()`` to a callback."""

    def __init__(self, request_fn):
        self._request_fn = request_fn

    async def request(self, **kwargs):
        return self._request_fn(**kwargs)

    async def aclose(self):
        pass


def _swap_mirror_client(client, fake_client):
    """Replace the shared mirror client on the running app."""
    from mact.server.main import fastapi_app
    fastapi_app.state.mirror_client = fake_client


def test_mirror_proxies_to_active_upstream(client, room_tokens):
    client.post(
        f"/rooms/{room_tokens['room_id']}/commits",
        json={
            "developer_id": room_tokens["developer_id"],
            "commit_hash": "a1b2c3d",
            "branch": "main",
            "message": "commit",
        },
        headers={"Authorization": f"Bearer {room_tokens['member_token']}"},
    )

    captured = {}

    def fake_request(method, url, content=None, headers=None, follow_redirects=False, **kw):
        captured["method"] = method
        captured["url"] = str(url)
        return httpx.Response(
            200,
            content=b"upstream-ok",
            headers={"content-type": "text/plain", "x-upstream": "yes"},
        )

    _swap_mirror_client(client, _FakeMirrorClient(fake_request))

    response = client.get(f"/r/{room_tokens['room_id']}/ping?x=1")

    assert response.status_code == 200
    assert response.text == "upstream-ok"
    assert response.headers["x-upstream"] == "yes"
    assert captured["method"] == "GET"
    assert captured["url"] == f"{room_tokens['upstream_url']}/ping?x=1"


def test_mirror_injects_reload_script_into_html(client, room_tokens):
    client.post(
        f"/rooms/{room_tokens['room_id']}/commits",
        json={
            "developer_id": room_tokens["developer_id"],
            "commit_hash": "c3c3c3c",
            "branch": "main",
            "message": "inject test",
        },
        headers={"Authorization": f"Bearer {room_tokens['member_token']}"},
    )

    def fake_request(method, url, content=None, headers=None, follow_redirects=False, **kw):
        return httpx.Response(
            200,
            content=b"<html><body><h1>Hello</h1></body></html>",
            headers={"content-type": "text/html"},
        )

    _swap_mirror_client(client, _FakeMirrorClient(fake_request))

    response = client.get(f"/r/{room_tokens['room_id']}/")
    assert response.status_code == 200
    assert "MACT live-reload" in response.text
    assert "location.reload()" in response.text
    assert "<h1>Hello</h1>" in response.text


def test_mirror_returns_502_on_upstream_error(client, room_tokens):
    client.post(
        f"/rooms/{room_tokens['room_id']}/commits",
        json={
            "developer_id": room_tokens["developer_id"],
            "commit_hash": "a1b2c3d",
            "branch": "main",
            "message": "commit",
        },
        headers={"Authorization": f"Bearer {room_tokens['member_token']}"},
    )

    def failing_request(method, url, **kw):
        raise httpx.ConnectError(
            "failed to connect", request=httpx.Request(method, url)
        )

    _swap_mirror_client(client, _FakeMirrorClient(failing_request))

    response = client.get(f"/r/{room_tokens['room_id']}/ping")
    assert response.status_code == 502
    payload = response.json()
    assert payload["detail"].startswith("upstream request failed:")
