"""Tests for shared validation patterns."""

from mact.validation import BRANCH_RE, DEV_RE, HASH_RE, ROOM_RE


def test_room_id_valid():
    assert ROOM_RE.fullmatch("demo")
    assert ROOM_RE.fullmatch("a")
    assert ROOM_RE.fullmatch("al-shifa")
    assert ROOM_RE.fullmatch("room_1")
    assert ROOM_RE.fullmatch("x" * 50)


def test_room_id_invalid():
    assert not ROOM_RE.fullmatch("")
    assert not ROOM_RE.fullmatch("-start")
    assert not ROOM_RE.fullmatch("end-")
    assert not ROOM_RE.fullmatch("UPPER")
    assert not ROOM_RE.fullmatch("x" * 51)


def test_developer_id():
    assert DEV_RE.fullmatch("alice")
    assert DEV_RE.fullmatch("Bob_123")
    assert DEV_RE.fullmatch("dev-1")
    assert not DEV_RE.fullmatch("")
    assert not DEV_RE.fullmatch("x" * 31)


def test_commit_hash():
    assert HASH_RE.fullmatch("a1b2c3d")
    assert HASH_RE.fullmatch("a" * 40)
    assert not HASH_RE.fullmatch("short")
    assert not HASH_RE.fullmatch("ABCDEF0")


def test_branch():
    assert BRANCH_RE.fullmatch("main")
    assert BRANCH_RE.fullmatch("feature/v1.0")
    assert BRANCH_RE.fullmatch("release/1.0.0")
    assert not BRANCH_RE.fullmatch("")
    assert not BRANCH_RE.fullmatch("x" * 81)
