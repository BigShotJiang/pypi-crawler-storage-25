"""Presence (heartbeat / disconnect) affects active-upstream resolution."""


def test_presence_disconnect_and_heartbeat_affect_active_upstream(client):
    # Create room and get tokens
    create_resp = client.post(
        "/rooms",
        json={
            "room_id": "presence-room",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    assert create_resp.status_code == 200
    tokens = create_resp.json()
    member_token = tokens["member_token"]
    auth = {"Authorization": f"Bearer {member_token}"}

    # Active upstream should be alice
    status_before = client.get("/rooms/presence-room/status")
    assert status_before.status_code == 200
    assert status_before.json()["active_upstream"] == "http://127.0.0.1:3000"

    # Disconnect alice
    disconnect_resp = client.post(
        "/rooms/presence-room/presence/disconnect",
        json={"developer_id": "alice"},
        headers=auth,
    )
    assert disconnect_resp.status_code == 200

    # No active upstream
    status_disc = client.get("/rooms/presence-room/status")
    assert status_disc.status_code == 200
    disc_payload = status_disc.json()
    assert disc_payload["active_upstream"] is None
    assert disc_payload["participants"][0]["connected"] is False

    # Heartbeat alice back
    hb_resp = client.post(
        "/rooms/presence-room/presence/heartbeat",
        json={"developer_id": "alice"},
        headers=auth,
    )
    assert hb_resp.status_code == 200

    # Active upstream restored
    status_after = client.get("/rooms/presence-room/status")
    assert status_after.status_code == 200
    after_payload = status_after.json()
    assert after_payload["active_upstream"] == "http://127.0.0.1:3000"
    assert after_payload["participants"][0]["connected"] is True


def test_heartbeat_updates_upstream_url(client):
    create_resp = client.post(
        "/rooms",
        json={
            "room_id": "upstream-update",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    tokens = create_resp.json()
    auth = {"Authorization": f"Bearer {tokens['member_token']}"}

    # Heartbeat with new upstream URL
    client.post(
        "/rooms/upstream-update/presence/heartbeat",
        json={
            "developer_id": "alice",
            "upstream_url": "http://tunnel.example.com",
        },
        headers=auth,
    )

    status = client.get("/rooms/upstream-update/status")
    payload = status.json()
    assert payload["active_upstream"] == "http://tunnel.example.com"
    assert payload["participants"][0]["upstream_url"] == "http://tunnel.example.com"


def test_presence_requires_auth(client):
    create_resp = client.post(
        "/rooms",
        json={
            "room_id": "auth-presence",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    assert create_resp.status_code == 200

    # Heartbeat without auth → 401
    resp = client.post(
        "/rooms/auth-presence/presence/heartbeat",
        json={"developer_id": "alice"},
    )
    assert resp.status_code == 401

    # Disconnect without auth → 401
    resp = client.post(
        "/rooms/auth-presence/presence/disconnect",
        json={"developer_id": "alice"},
    )
    assert resp.status_code == 401
