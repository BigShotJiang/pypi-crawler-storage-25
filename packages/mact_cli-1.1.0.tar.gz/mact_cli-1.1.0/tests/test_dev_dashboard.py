"""Dev-only path dashboard (MACT_DEV_DASHBOARD)."""


def test_path_dashboard_disabled_by_default(client):
    r = client.get("/rooms/test-room/dashboard")
    assert r.status_code == 404


def test_path_dashboard_when_enabled(client, monkeypatch):
    monkeypatch.setenv("MACT_DEV_DASHBOARD", "true")
    client.post(
        "/rooms",
        json={
            "room_id": "dash-room",
            "developer_id": "alice",
            "upstream_url": "http://127.0.0.1:3000",
        },
    )
    r = client.get("/rooms/dash-room/dashboard")
    assert r.status_code == 200
    assert "dash-room" in r.text
    assert "Room dash-room" in r.text or "dash-room" in r.text
