"""Initial rooms, members, commits schema.

Revision ID: 001_initial
Revises:
Create Date: 2026-04-05

"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "001_initial"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "rooms",
        sa.Column("room_id", sa.String(length=50), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("room_id"),
    )
    op.create_table(
        "room_members",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("room_id", sa.String(length=50), nullable=False),
        sa.Column("developer_id", sa.String(length=30), nullable=False),
        sa.Column("upstream_url", sa.String(length=2000), nullable=False),
        sa.Column("connected", sa.Boolean(), nullable=False),
        sa.Column("last_seen_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(
            ["room_id"],
            ["rooms.room_id"],
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("room_id", "developer_id", name="uq_room_member"),
    )
    op.create_table(
        "commits",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("room_id", sa.String(length=50), nullable=False),
        sa.Column("commit_hash", sa.String(length=64), nullable=False),
        sa.Column("branch", sa.String(length=80), nullable=False),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("developer_id", sa.String(length=30), nullable=False),
        sa.Column("server_received_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(
            ["room_id"],
            ["rooms.room_id"],
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("room_id", "commit_hash", name="uq_room_commit_hash"),
    )


def downgrade() -> None:
    op.drop_table("commits")
    op.drop_table("room_members")
    op.drop_table("rooms")
