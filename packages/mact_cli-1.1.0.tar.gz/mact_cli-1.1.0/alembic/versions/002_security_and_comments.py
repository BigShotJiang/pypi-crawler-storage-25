"""Add security columns and admin comments.

Revision ID: 002_security
Revises: 001_initial
Create Date: 2026-04-05

"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "002_security"
down_revision: Union[str, None] = "001_initial"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("rooms", sa.Column("join_secret_hash", sa.String(128), nullable=True))
    op.add_column("rooms", sa.Column("admin_token_hash", sa.String(128), nullable=True))
    op.add_column(
        "rooms", sa.Column("creator_developer_id", sa.String(30), nullable=True)
    )
    op.add_column(
        "room_members", sa.Column("member_token_hash", sa.String(128), nullable=True)
    )
    op.add_column("commits", sa.Column("admin_comment", sa.Text(), nullable=True))
    op.add_column(
        "commits",
        sa.Column("comment_updated_at", sa.DateTime(timezone=True), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("commits", "comment_updated_at")
    op.drop_column("commits", "admin_comment")
    op.drop_column("room_members", "member_token_hash")
    op.drop_column("rooms", "creator_developer_id")
    op.drop_column("rooms", "admin_token_hash")
    op.drop_column("rooms", "join_secret_hash")
