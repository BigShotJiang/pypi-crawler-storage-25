# MACT — Software Outline & Architecture Plan

**Document status:** planning  
**Domain / hosting:** `mact.live`, DigitalOcean droplet  
**Companion doc:** `REBUILD_SPECIFICATION.md` (legacy reference for problem domain only)

---

## 1. Product summary

**MACT** routes a **stable public URL per room** to the **localhost of the developer who made the latest Git commit** in that room, with **fallback** when that tunnel is down, and an **offline** experience when no participant is connected.

**Developer experience:** install a **Python package**, run `mact init`, create or **join with a secret code**, tunnel local app port, **post-commit hook** (or equivalent) reports commits to the server. **Dashboard** shows history, timestamps, messages, **per-commit admin comments** (nullable text), and **multidimensional contribution analytics**.

**Explicit non-goals for v1:** integrating with GitHub for routing; hosting the app source (teams use their own shared remote). Focus is **live preview sharing** and **room-local telemetry** derived from commits + presence.

---

## 2. High-level architecture

```mermaid
flowchart TB
  subgraph clients [Developers]
    CLI[mact Python CLI]
    FRPC[frpc tunnel]
    GIT[git post-commit]
    CLI --> FRPC
    GIT --> CLI
  end

  subgraph edge [Edge - droplet]
    TLS[Nginx / Caddy TLS]
    ROUTER[Room HTTP router + WS]
    TLS --> ROUTER
  end

  subgraph control [Control plane]
    API[REST API]
    DB[(PostgreSQL)]
    API --> DB
  end

  subgraph tunnel_srv [Tunnel server]
    FRPS[frps]
  end

  ROUTER --> API
  ROUTER --> FRPS
  FRPC --> FRPS
  CLI --> API
```

**Responsibility split:**

| Layer | Role |
|--------|------|
| **TLS / reverse proxy** | Terminate HTTPS, forward to app router by host/path; WebSocket upgrade. |
| **Room router** | Map `Host` (or path prefix) → `room_id`; serve **mirror** (proxy to active upstream), **dashboard** HTML, **offline** page; optional **SSE/WebSocket** for live dashboard updates. |
| **Control API** | Rooms, join secrets, participants, tunnel registration, commit ingestion, admin comment on commits, analytics reads/aggregates. |
| **PostgreSQL** | Durable rooms, members, commits, comments, events for analytics. |
| **frps** | Multiplex developer **frpc** HTTP tunnels to stable internal hostnames/ports the router uses. |

*Alternative:* merge “room router” and “API” into one **FastAPI** (or Starlette) app with clear internal modules if that reduces moving parts; still keep **frps** as separate process.

---

## 3. Core components (detailed)

### 3.1 Python CLI package (`mact`)

- **Distribution:** `pip install mact-cli` from PyPI (or private index); `pyproject.toml`, entry point `mact`; optional **`mact-cli[server]`** for the control plane.
- **Commands (v1):** `init` (developer id, optional GitHub profile URL), `create` (project label → server creates room + **join secret**), `join` (room id/slug + **secret** + local port), `leave`, `status`.
- **Side effects:** write `~/.mact_config.json`, `~/.mact_rooms.json`; generate **frpc** TOML; spawn/monitor **frpc**; install **post-commit** hook calling server `POST /commits/report` (or equivalent) with room id, developer id, hash, branch, message.
- **Heartbeat (recommended):** periodic `POST` or WebSocket so server knows **connected** state for fallback and analytics (“time connected”).

### 3.2 Control API

- **Auth models:**
  - **Join:** room identifier + **secret** (server stores **hash** of secret; constant-time compare).
  - **Admin:** room creator only — issue **admin token** at room creation (store hash server-side; CLI stores once in local config) or derive from signed server-side session; use for `PATCH` commit comment.
- **Endpoints (illustrative):**
  - `POST /rooms` — create room → returns `room_public_id`, `join_secret` (once), `admin_token` (once), suggested public URLs.
  - `POST /rooms/{id}/join` — body: join secret, developer id, tunnel metadata.
  - `POST /rooms/{id}/commits` — report commit (from hook; authenticated by **member** token or mTLS-lite via per-device key issued at join — *simplify v1:* HMAC or long-lived **member token** stored in `.mact` config).
  - `PATCH /rooms/{id}/commits/{hash}/comment` — admin only, body: `{ "comment": "..." | null }`.
  - `GET /rooms/{id}/dashboard` — JSON for SPA or server-rendered data: commits + comments + aggregates.
  - `GET /internal/rooms/{id}/active-upstream` — for router: resolved URL for mirror (not public if router is same process).

### 3.3 Room router (mirror + dashboard + offline)

- **Mirror:** HTTP(S) proxy to **active upstream URL** from control plane (FRP vhost URL for current active participant). Strip/add headers; WebSocket pass-through for live apps.
- **Fallback:** if active participant tunnel down → use **previous** active from ordered commit/participant history (spec’d behavior); if none available → **offline** static page.
- **Dashboard:** route e.g. `/dashboard` or `dashboard.{room}.mact.live` — table/chart of commits, timestamps, messages, admin comment column; charts from analytics API.
- **Live updates:** WebSocket or SSE from server to dashboard when commits or presence change.

### 3.4 Tunneling (frp)

- **frps** on droplet (control + vhost ports as in your network design).
- **frpc** launched by CLI with **unique subdomain per (room, developer)** so backend can map “participant → upstream base URL”.
- Pin **frp** version; document architecture (`linux-amd64` on server; CLI bundles or downloads frpc per OS optional).

### 3.5 Analytics (multidimensional, room-scoped)

Store **facts** then aggregate for UI:

| Dimension | Source |
|-----------|--------|
| Commits per developer | commit reports |
| Commits over time | timestamps |
| “Active” leadership | who was selected as active after each commit event |
| Connection / presence | heartbeats (optional but strongly useful) |
| Comment coverage | % commits with non-null admin comment (optional KPI) |

Implement as **SQL views** or **materialized rollups** + nightly/job refresh if volume grows. v1 can compute some charts on read with sane limits.

---

## 4. Data model (v1)

**rooms**

- `id` (UUID), `slug` or public id (for URL), `name`, `created_at`
- `join_secret_hash`, `join_secret_salt` (or single bcrypt/argon hash)
- `creator_developer_id` (string) — admin identity label
- `admin_token_hash` (if using bearer token model)

**room_members**

- `room_id`, `developer_id`, `github_url` nullable
- `member_token_hash` or API key for commit reporting
- `frp_subdomain` / upstream base URL template
- `connected`, `last_seen_at`

**commits**

- `room_id`, `commit_hash`, `branch`, `message`, `developer_id`, `committed_at`
- `admin_comment` TEXT NULL, `comment_updated_at` NULL

**analytics_events** (optional normalized)

- `room_id`, `type` (`commit`, `presence`, `active_change`), `payload` JSONB, `at`

Unique constraint: `(room_id, commit_hash)` if one row per commit per room.

---

## 5. Public URL strategy

Pick one for v1 (implement one, keep the other for later):

- **A — Subdomain:** `{room}.mact.live` (wildcard DNS + TLS).
- **B — Path:** `mact.live/r/{public_id}` (single cert, simpler DNS).

Dashboard: `{same origin}/dashboard` or dedicated subdomain. Document chosen pattern in deployment.

---

## 6. Deployment (DigitalOcean droplet)

- **OS:** Ubuntu LTS.
- **Stack:** Nginx or Caddy, **PostgreSQL**, Python app under **systemd**, **frps** under systemd.
- **Firewall:** 22, 80, 443; frp ports restricted or bound to localhost with router talking to internal only (prefer **not** exposing frp admin to the world).
- **Secrets:** env files in `/etc/mact/` — `DATABASE_URL`, `JWT_SECRET` or signing keys, pepper for join secrets.
- **CI/CD:** optional GitHub Actions → SSH deploy script.

---

## 7. Distributed systems, networking & reliability

MACT spans **developer laptops**, **long-lived TCP tunnels**, **HTTP proxies**, and a **central server + DB**. Misalignment is normal: the system should assume **partial failure**, **delay**, and **stale views**, and make behavior **predictable** and **observable**.

### 7.1 What can go wrong (non-exhaustive)

| Area | Risk |
|------|------|
| **Tunnels** | frpc/frps restart, NAT timeouts, laptop sleep → upstream disappears while DB still says “connected”. |
| **Commit reporting** | Hook runs but API is down → **lost** or **delayed** report; retry may **duplicate** the same commit. |
| **Ordering** | Commits arrive **out of order** vs true git history; two devs push “latest” from local view at different times. |
| **Clocks** | Client `committed_at` vs server time **skew** → misleading timelines unless normalized. |
| **Router vs control plane** | Router picks active URL from cached or stale state while membership or tunnels already changed. |
| **Proxy path** | Mirror returns 502/504 from upstream; WebSocket upgrade fails through nginx; body streaming timeouts. |
| **Split visibility** | “Latest commit” in DB says Alice, but only Bob’s tunnel is up → fallback must engage; **no** single global truth without heartbeats. |

### 7.2 Design principles (v1 and onward)

1. **Authoritative server time for ordering** — ingest commits with **server-received timestamp** for “what happened when on the platform”; optionally store **client-reported** time as metadata only. Use commit hash + room as **idempotency** key so duplicates do not double-count analytics.
2. **Explicit presence, not inference** — treat “tunnel works” as **heartbeats** or last successful **tunnel registration** + TTL. Do not infer liveness from commits alone.
3. **Eventually consistent mirror** — the public URL reflects **resolve(active)** on each request (or short TTL cache with **invalidation** on commit/presence events). Accept brief inconsistency; avoid long sticky routing to a dead upstream.
4. **Bounded proxy behavior** — configurable **connect/read timeouts** to upstream; clear **502** with body vs infinite hang; optional **retry** only for idempotent GET (not for POST mirror in general).
5. **Grace periods** — mark participant **disconnected** only after **N missed heartbeats** to avoid flapping UI and mirror thrash.
6. **Structured observability** — **correlation id** (e.g. `X-Request-ID`) from edge through API; log **room_id**, **resolved_upstream**, **fallback_step** on mirror decisions (no secrets). Health: `/health` **liveness** vs **readiness** (DB + optional frps check).

### 7.3 Consistency model (plain language)

- **Strong within the database** for room membership and commit rows (transactions).
- **Best-effort** alignment between **“who should be active”** (commit order policy) and **“who is actually reachable”** (tunnels). The product rule **fallback → offline** is a **reconciliation policy**, not magic consistency.

### 7.4 Testing & operations

- **Automated:** idempotency tests for duplicate commit POSTs; tests for **fallback order** when active tunnel is down; proxy tests with **mock upstream** that dies mid-request.
- **Manual / staging:** laptop sleep, frpc kill -9, nginx reload, API restart during active mirror.
- **Runbook (later):** “mirror shows wrong dev” → check heartbeat, frps, `active` resolution logs, nginx WS headers.

### 7.5 Phased delivery impact

Build **P0** with **timeouts + idempotent commits + server timestamps** from day one; add **heartbeats** early in **P1** before tuning analytics that depend on “connected” time.

---

## 8. Security notes (v1)

- Hash **join secrets** and **admin tokens**; never log plaintext.
- Rate-limit commit and join endpoints.
- Validate commit payload (hash format, message length, branch charset).
- Sanitize dashboard output (XSS) for commit messages and comments.
- TLS everywhere public.

---

## 9. Phased delivery

| Phase | Deliverable |
|-------|-------------|
| **P0** | Repo layout, `pyproject.toml`, DB migrations, core API (rooms, join, commits), minimal router (mirror + offline stub), CLI `init`/`create`/`join`, frpc integration, post-commit hook. |
| **P1** | Active/fallback logic, heartbeats, dashboard UI + per-commit comments (`PATCH`), analytics queries + charts. |
| **P2** | Hardening, systemd + Nginx + Postgres on DO, docs, PyPI publish. |
| **P3 (last)** | **mact.live** marketing homepage: what MACT is, install instructions, link to PyPI, support/docs. |

---

## 10. Repository layout (proposed)

```
mact/
├── pyproject.toml          # package: mact CLI + server deps (or split packages later)
├── README.md
├── ARCHITECTURE.md         # this file
├── src/
│   └── mact/
│       ├── cli/            # init, create, join, frpc, hook
│       ├── server/         # FastAPI/Starlette app: api + router + dashboard
│       ├── db/             # models, migrations (Alembic)
│       └── analytics/      # rollups, chart payloads
├── deployment/
│   ├── nginx/ / caddy/
│   ├── systemd/
│   └── scripts/
├── tests/
└── web/                    # P3: static landing site (or separate repo)
```

**Packaging (resolved):** PyPI **`mact-cli`** (minimal deps); self-host API with **`pip install mact-cli[server]`** and `uvicorn mact.server.main:app`. Same `src/mact/` tree ships in the sdist/wheel.

---

## 11. Open decisions (historical — several resolved in tree)

1. **Packaging:** **`mact-cli`** on PyPI; server deps optional extra (not a separate `mact-server` console script on PyPI).
2. **Member auth for commit hook:** long-lived token per member vs shared room secret (avoid shared secret for commits — prefer per-member token).
3. **Exact public URL pattern** (subdomain vs path).
4. **frpc distribution:** **download-on-first-run** to `~/.cache/mact/frp/` (PATH still overrides).

---

*Next step:* scaffold repo (P0), database migrations, and vertical slice “create room → join → report commit → see row in API” before mirror complexity — with **idempotent commit ingest** and **server-side ordering** assumed from the first merge.
