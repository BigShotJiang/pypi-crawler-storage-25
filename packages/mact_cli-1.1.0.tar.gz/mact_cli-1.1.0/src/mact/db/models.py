from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, ForeignKey, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class Room(Base):
    __tablename__ = "rooms"

    room_id: Mapped[str] = mapped_column(String(50), primary_key=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )
    join_secret_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    admin_token_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    creator_developer_id: Mapped[str | None] = mapped_column(String(30), nullable=True)

    members: Mapped[list["RoomMember"]] = relationship(back_populates="room")
    commits: Mapped[list["CommitRow"]] = relationship(back_populates="room")


class RoomMember(Base):
    __tablename__ = "room_members"
    __table_args__ = (
        UniqueConstraint("room_id", "developer_id", name="uq_room_member"),
    )

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    room_id: Mapped[str] = mapped_column(
        String(50), ForeignKey("rooms.room_id", ondelete="CASCADE")
    )
    developer_id: Mapped[str] = mapped_column(String(30))
    upstream_url: Mapped[str] = mapped_column(String(2000))
    connected: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    last_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )
    member_token_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)

    room: Mapped["Room"] = relationship(back_populates="members")


class CommitRow(Base):
    __tablename__ = "commits"
    __table_args__ = (
        UniqueConstraint("room_id", "commit_hash", name="uq_room_commit_hash"),
    )

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    room_id: Mapped[str] = mapped_column(
        String(50), ForeignKey("rooms.room_id", ondelete="CASCADE")
    )
    commit_hash: Mapped[str] = mapped_column(String(64))
    branch: Mapped[str] = mapped_column(String(80))
    message: Mapped[str] = mapped_column(Text)
    developer_id: Mapped[str] = mapped_column(String(30))
    server_received_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )
    admin_comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    comment_updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    room: Mapped["Room"] = relationship(back_populates="commits")
