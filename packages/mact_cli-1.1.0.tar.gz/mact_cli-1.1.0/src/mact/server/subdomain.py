from __future__ import annotations

from mact.validation import ROOM_RE

_EXCLUDED_PREFIXES = (
    "/dashboard",
    "/live",
    "/health",
    "/ready",
    "/docs",
    "/openapi.json",
    "/redoc",
    "/internal",
    "/rooms",
)


def parse_room_from_host(host: str, public_base_domain: str) -> str | None:
    """
    If host is ``{room}.mact.live`` (and not apex or www), return ``room_id``.
    ``host`` must be hostname only (no port).
    """
    host = host.strip().lower()
    base = public_base_domain.strip().lower()
    if not base or host == base or host == f"www.{base}":
        return None
    suffix = f".{base}"
    if not host.endswith(suffix):
        return None
    sub = host[: -len(suffix)]
    if not sub or sub == "www" or sub == "api":
        return None
    if not ROOM_RE.fullmatch(sub):
        return None
    return sub


def should_rewrite_subdomain_path(path: str) -> bool:
    for prefix in _EXCLUDED_PREFIXES:
        if path == prefix or path.startswith(prefix + "/"):
            return False
    return True
