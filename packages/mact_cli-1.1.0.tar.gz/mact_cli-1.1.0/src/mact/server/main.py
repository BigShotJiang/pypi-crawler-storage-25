from __future__ import annotations

import asyncio
import html
import json
import logging
import os
from contextlib import asynccontextmanager
from urllib.parse import urlparse, urlunparse

import httpx
import websockets
import uvicorn
from fastapi import Depends, FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from mact.db import repository as repo
from mact.db.models import Base
from mact.security import generate_token, hash_token
from mact.server.asgi_subdomain import SubdomainRewriteMiddleware
from mact.server.ratelimit import RATE_LIMITS, RateLimiter, rate_limit_key
from mact.server.realtime import RoomEventBroker, schedule_room_broadcast
from mact.server.settings import load_settings
from mact.validation import BRANCH_RE, DEV_RE, HASH_RE, ROOM_RE

HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
    "host",
}
STRIP_UPSTREAM_HEADERS = HOP_BY_HOP_HEADERS | {"server", "date"}
MIRROR_TIMEOUT = httpx.Timeout(connect=2.0, read=5.0, write=5.0, pool=5.0)
LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Pydantic request models
# ---------------------------------------------------------------------------

class RoomCreateRequest(BaseModel):
    room_id: str = Field(min_length=1, max_length=50)
    developer_id: str = Field(min_length=1, max_length=30)
    upstream_url: str = Field(min_length=1, max_length=2000)


class RoomJoinRequest(BaseModel):
    developer_id: str = Field(min_length=1, max_length=30)
    upstream_url: str = Field(min_length=1, max_length=2000)
    join_secret: str = Field(min_length=1)


class CommitReportRequest(BaseModel):
    developer_id: str = Field(min_length=1, max_length=30)
    commit_hash: str = Field(min_length=7, max_length=40)
    branch: str = Field(min_length=1, max_length=80)
    message: str = Field(min_length=1, max_length=250)


class MemberPresenceRequest(BaseModel):
    developer_id: str = Field(min_length=1, max_length=30)
    upstream_url: str | None = None


class CommitCommentRequest(BaseModel):
    comment: str | None = Field(default=None, max_length=2000)


# ---------------------------------------------------------------------------
# Validators
# ---------------------------------------------------------------------------

def _validate_room_id(room_id: str) -> None:
    if not ROOM_RE.fullmatch(room_id):
        raise HTTPException(status_code=400, detail="invalid room_id")


def _validate_developer_id(developer_id: str) -> None:
    if not DEV_RE.fullmatch(developer_id):
        raise HTTPException(status_code=400, detail="invalid developer_id")


def _validate_commit(commit_hash: str, branch: str) -> None:
    if not HASH_RE.fullmatch(commit_hash):
        raise HTTPException(status_code=400, detail="invalid commit_hash")
    if not BRANCH_RE.fullmatch(branch):
        raise HTTPException(status_code=400, detail="invalid branch")


def _require_bearer(request: Request) -> str:
    auth = request.headers.get("authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="missing authorization")
    return auth[7:]


def _rate_check(request: Request, bucket: str) -> None:
    cfg = RATE_LIMITS.get(bucket)
    if cfg:
        request.app.state.rate_limiter.check(rate_limit_key(request, bucket), cfg)


# ---------------------------------------------------------------------------
# App lifecycle
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = load_settings()
    connect_args: dict = {}
    if settings.database_url.startswith("sqlite"):
        connect_args["check_same_thread"] = False
    # In-memory SQLite uses a separate empty DB per connection unless we pin one pool.
    use_static_pool = (
        settings.database_url.startswith("sqlite") and ":memory:" in settings.database_url
    )
    engine_kw: dict = {"connect_args": connect_args, "pool_pre_ping": True}
    if use_static_pool:
        engine_kw["poolclass"] = StaticPool
        engine_kw["pool_pre_ping"] = False
    engine = create_engine(settings.database_url, **engine_kw)
    if settings.database_url.startswith("sqlite"):

        @event.listens_for(engine, "connect")
        def _sqlite_pragma(dbapi_conn, _connection_record) -> None:
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    if settings.auto_create_tables:
        Base.metadata.create_all(bind=engine)
    app.state.settings = settings
    app.state.SessionLocal = sessionmaker(
        autocommit=False, autoflush=False, bind=engine
    )
    app.state.main_loop = asyncio.get_running_loop()
    app.state.room_broker = RoomEventBroker()
    app.state.mirror_client = httpx.AsyncClient(timeout=MIRROR_TIMEOUT)
    app.state.rate_limiter = RateLimiter()
    yield
    await app.state.mirror_client.aclose()
    engine.dispose()


def get_db(request: Request):
    SessionLocal = request.app.state.SessionLocal
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


fastapi_app = FastAPI(title="MACT API", version="1.1.0", lifespan=lifespan)


# ---------------------------------------------------------------------------
# Health / readiness
# ---------------------------------------------------------------------------

@fastapi_app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@fastapi_app.get("/ready")
def ready(request: Request) -> dict[str, str]:
    SessionLocal = request.app.state.SessionLocal
    db = SessionLocal()
    try:
        repo.ping_db(db)
    except Exception as exc:
        raise HTTPException(
            status_code=503, detail="database not ready"
        ) from exc
    finally:
        db.close()
    return {"status": "ready"}


# ---------------------------------------------------------------------------
# Room management
# ---------------------------------------------------------------------------

@fastapi_app.post("/rooms")
def create_room(
    payload: RoomCreateRequest, request: Request, db: Session = Depends(get_db)
) -> dict:
    _rate_check(request, "/rooms")
    _validate_room_id(payload.room_id)
    _validate_developer_id(payload.developer_id)

    join_secret = generate_token()
    admin_token = generate_token()
    member_token = generate_token()

    try:
        repo.create_room(
            db,
            payload.room_id,
            payload.developer_id,
            payload.upstream_url,
            join_secret_hash=hash_token(join_secret),
            admin_token_hash=hash_token(admin_token),
            member_token_hash=hash_token(member_token),
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    schedule_room_broadcast(fastapi_app, payload.room_id)
    return {
        "room_id": payload.room_id,
        "join_secret": join_secret,
        "admin_token": admin_token,
        "member_token": member_token,
    }


@fastapi_app.post("/rooms/{room_id}/join")
def join_room(
    room_id: str,
    payload: RoomJoinRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict:
    _rate_check(request, "join")
    _validate_room_id(room_id)
    _validate_developer_id(payload.developer_id)

    if not repo.verify_join_secret(db, room_id, payload.join_secret):
        raise HTTPException(status_code=403, detail="invalid join secret")

    member_token = generate_token()
    try:
        repo.join_room(
            db,
            room_id,
            payload.developer_id,
            payload.upstream_url,
            member_token_hash=hash_token(member_token),
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    schedule_room_broadcast(fastapi_app, room_id)
    return {"status": "joined", "member_token": member_token}


# ---------------------------------------------------------------------------
# Commits
# ---------------------------------------------------------------------------

@fastapi_app.post("/rooms/{room_id}/commits")
def report_commit(
    room_id: str,
    payload: CommitReportRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict[str, bool]:
    _rate_check(request, "commits")
    _validate_room_id(room_id)
    _validate_developer_id(payload.developer_id)
    _validate_commit(payload.commit_hash, payload.branch)

    token = _require_bearer(request)
    if not repo.verify_member_token(db, room_id, payload.developer_id, token):
        raise HTTPException(status_code=403, detail="invalid member token")

    try:
        inserted = repo.add_commit(
            db,
            room_id=room_id,
            commit_hash=payload.commit_hash,
            branch=payload.branch,
            message=payload.message,
            developer_id=payload.developer_id,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    schedule_room_broadcast(fastapi_app, room_id)
    return {"inserted": inserted}


@fastapi_app.patch("/rooms/{room_id}/commits/{commit_hash}/comment")
def update_comment(
    room_id: str,
    commit_hash: str,
    payload: CommitCommentRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict[str, str]:
    _rate_check(request, "comment")
    _validate_room_id(room_id)

    token = _require_bearer(request)
    if not repo.verify_admin_token(db, room_id, token):
        raise HTTPException(status_code=403, detail="invalid admin token")

    if not repo.update_commit_comment(db, room_id, commit_hash, payload.comment):
        raise HTTPException(status_code=404, detail="commit not found")
    schedule_room_broadcast(fastapi_app, room_id)
    return {"status": "updated"}


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------

@fastapi_app.get("/rooms/{room_id}/status")
def room_status(
    room_id: str, request: Request, db: Session = Depends(get_db)
) -> dict:
    _validate_room_id(room_id)
    payload = repo.get_room_status(
        db,
        room_id,
        presence_ttl_seconds=request.app.state.settings.presence_ttl_seconds,
    )
    if payload is None:
        raise HTTPException(status_code=404, detail="room not found")
    return JSONResponse(
        content=payload,
        headers={
            "Cache-Control": "no-store, max-age=0",
            "Pragma": "no-cache",
        },
    )


@fastapi_app.get("/internal/rooms/{room_id}/active-upstream")
def active_upstream(
    room_id: str, request: Request, db: Session = Depends(get_db)
) -> dict[str, str | None]:
    _validate_room_id(room_id)
    return {
        "active_upstream": repo.resolve_active_upstream(
            db,
            room_id,
            presence_ttl_seconds=request.app.state.settings.presence_ttl_seconds,
        )
    }


# ---------------------------------------------------------------------------
# Presence
# ---------------------------------------------------------------------------

@fastapi_app.post("/rooms/{room_id}/presence/heartbeat")
def heartbeat(
    room_id: str,
    payload: MemberPresenceRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict[str, str]:
    _rate_check(request, "heartbeat")
    _validate_room_id(room_id)
    _validate_developer_id(payload.developer_id)

    token = _require_bearer(request)
    if not repo.verify_member_token(db, room_id, payload.developer_id, token):
        raise HTTPException(status_code=403, detail="invalid member token")

    try:
        repo.heartbeat_member(
            db, room_id, payload.developer_id, upstream_url=payload.upstream_url
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    schedule_room_broadcast(fastapi_app, room_id)
    return {"status": "ok"}


@fastapi_app.post("/rooms/{room_id}/presence/disconnect")
def disconnect(
    room_id: str,
    payload: MemberPresenceRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict[str, str]:
    _rate_check(request, "disconnect")
    _validate_room_id(room_id)
    _validate_developer_id(payload.developer_id)

    token = _require_bearer(request)
    if not repo.verify_member_token(db, room_id, payload.developer_id, token):
        raise HTTPException(status_code=403, detail="invalid member token")

    try:
        repo.disconnect_member(db, room_id, payload.developer_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    schedule_room_broadcast(fastapi_app, room_id)
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# Realtime (WebSocket)
# ---------------------------------------------------------------------------


@fastapi_app.websocket("/rooms/{room_id}/events")
async def room_events_ws(websocket: WebSocket, room_id: str) -> None:
    _validate_room_id(room_id)
    app = websocket.app
    SessionLocal = app.state.SessionLocal
    db = SessionLocal()
    try:
        payload = repo.get_room_status(
            db,
            room_id,
            presence_ttl_seconds=app.state.settings.presence_ttl_seconds,
        )
    finally:
        db.close()
    if payload is None:
        await websocket.close(code=1008)
        return

    await websocket.accept()
    broker: RoomEventBroker = app.state.room_broker
    await broker.connect(room_id, websocket)
    await websocket.send_json({"type": "room_status", "payload": payload})
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        await broker.disconnect(room_id, websocket)


# ---------------------------------------------------------------------------
# Mirror proxy
# ---------------------------------------------------------------------------

def _build_target_url(active_upstream: str, path: str, query: str) -> str:
    base = active_upstream.rstrip("/")
    suffix = f"/{path}" if path else ""
    if query:
        return f"{base}{suffix}?{query}"
    return f"{base}{suffix}"


def _http_url_to_ws(url: str) -> str:
    p = urlparse(url)
    scheme = "wss" if p.scheme == "https" else "ws"
    return urlunparse((scheme, p.netloc, p.path, "", p.query, ""))


async def _mirror_websocket_proxy(
    websocket: WebSocket, room_id: str, path: str
) -> None:
    _validate_room_id(room_id)
    SessionLocal = websocket.app.state.SessionLocal
    db = SessionLocal()
    try:
        active = repo.resolve_active_upstream(
            db,
            room_id,
            presence_ttl_seconds=websocket.app.state.settings.presence_ttl_seconds,
        )
    finally:
        db.close()

    if not active:
        await websocket.close(code=1008)
        return

    raw_q = websocket.scope.get("query_string", b"")
    q = raw_q.decode("latin-1") if raw_q else ""
    target_http = _build_target_url(active, path, q)
    ws_url = _http_url_to_ws(target_http)

    extra_headers: list[tuple[str, str]] = []
    for name in ("cookie", "authorization", "sec-websocket-protocol"):
        v = websocket.headers.get(name)
        if v:
            extra_headers.append((name, v))

    try:
        async with websockets.connect(
            ws_url,
            open_timeout=2.0,
            max_size=2**30,
            extra_headers=extra_headers or None,
        ) as upstream:
            await websocket.accept()

            async def client_to_upstream() -> None:
                try:
                    while True:
                        msg = await websocket.receive()
                        mtype = msg.get("type")
                        if mtype == "websocket.disconnect":
                            break
                        if mtype != "websocket.receive":
                            continue
                        if "text" in msg:
                            await upstream.send(msg["text"])
                        elif "bytes" in msg:
                            await upstream.send(msg["bytes"])
                except WebSocketDisconnect:
                    pass

            async def upstream_to_client() -> None:
                try:
                    async for message in upstream:
                        if isinstance(message, str):
                            await websocket.send_text(message)
                        else:
                            await websocket.send_bytes(message)
                except Exception:
                    LOGGER.warning(
                        "Upstream websocket relay failed for room_id=%s path=%s",
                        room_id,
                        path,
                        exc_info=True,
                    )

            _done, pending = await asyncio.wait(
                [
                    asyncio.create_task(client_to_upstream()),
                    asyncio.create_task(upstream_to_client()),
                ],
                return_when=asyncio.FIRST_COMPLETED,
            )
            for task in pending:
                task.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
    except Exception:
        LOGGER.warning(
            "Mirror websocket proxy failed for room_id=%s path=%s",
            room_id,
            path,
            exc_info=True,
        )
        try:
            await websocket.close(code=1011)
        except Exception:
            pass


@fastapi_app.websocket("/r/{room_id}")
async def mirror_room_websocket_root(websocket: WebSocket, room_id: str) -> None:
    await _mirror_websocket_proxy(websocket, room_id, "")


@fastapi_app.websocket("/r/{room_id}/{path:path}")
async def mirror_room_websocket_path(
    websocket: WebSocket, room_id: str, path: str
) -> None:
    await _mirror_websocket_proxy(websocket, room_id, path)


def _offline_page(room_id: str) -> str:
    safe = html.escape(room_id, quote=True)
    return (
        "<!doctype html>"
        "<html><head><title>MACT Offline</title></head>"
        "<body><h1>Room offline</h1>"
        f"<p>No active upstream for room <code>{safe}</code>.</p>"
        "</body></html>"
    )


def _dashboard_css() -> str:
    return """<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0f172a;--surface:#1e293b;--border:#334155;--text:#e2e8f0;
--muted:#94a3b8;--accent:#38bdf8;--green:#34d399;--red:#f87171;--yellow:#fbbf24}
body{font-family:system-ui,-apple-system,sans-serif;background:var(--bg);color:var(--text);
min-height:100vh;padding:2rem}
.container{max-width:960px;margin:0 auto}
h1{font-size:1.75rem;font-weight:700;margin-bottom:.25rem}
h2{font-size:1.1rem;font-weight:600;color:var(--muted);margin:1.5rem 0 .75rem;
text-transform:uppercase;letter-spacing:.05em;font-size:.85rem}
.room-title{color:var(--accent)}
.status-bar{display:flex;gap:1.5rem;flex-wrap:wrap;margin:1rem 0;padding:1rem;
background:var(--surface);border-radius:.5rem;border:1px solid var(--border)}
.status-item{display:flex;flex-direction:column;gap:.25rem}
.status-label{font-size:.75rem;color:var(--muted);text-transform:uppercase;letter-spacing:.04em}
.status-value{font-size:.95rem;font-weight:500}
.badge{display:inline-block;padding:.15rem .5rem;border-radius:9999px;font-size:.75rem;font-weight:600}
.badge-live{background:rgba(52,211,153,.15);color:var(--green)}
.badge-offline{background:rgba(248,113,113,.15);color:var(--red)}
table{width:100%;border-collapse:collapse;background:var(--surface);border-radius:.5rem;
overflow:hidden;border:1px solid var(--border)}
th{background:rgba(255,255,255,.03);text-align:left;padding:.6rem .75rem;
font-size:.75rem;color:var(--muted);text-transform:uppercase;letter-spacing:.04em;font-weight:600}
td{padding:.6rem .75rem;border-top:1px solid var(--border);font-size:.875rem}
tr:hover td{background:rgba(255,255,255,.02)}
.hash{font-family:'SF Mono',Consolas,monospace;color:var(--accent);font-size:.8rem}
.comment{color:var(--yellow);font-style:italic;font-size:.8rem}
.time{color:var(--muted);font-size:.8rem}
.empty{color:var(--muted);font-style:italic;padding:1rem}
</style>"""


def _dashboard_client_script(room_id: str) -> str:
    rj = json.dumps(room_id)
    return (
        "<script>\n"
        "(function(){\n"
        f"var ROOM_ID={rj};\n"
        "var statusUrl='/rooms/'+encodeURIComponent(ROOM_ID)+'/status';\n"
        "var wsProto=location.protocol==='https:'?'wss:':'ws:';\n"
        "var wsUrl=wsProto+'//'+location.host+'/rooms/'+encodeURIComponent(ROOM_ID)+'/events';\n"
        "function badge(live){return live"
        "?'<span class=\"badge badge-live\">LIVE</span>'"
        ":'<span class=\"badge badge-offline\">OFFLINE</span>';}\n"
        "function timeAgo(iso){\n"
        "  var d=new Date(iso),s=Math.floor((Date.now()-d)/1000);\n"
        "  if(s<60)return s+'s ago';if(s<3600)return Math.floor(s/60)+'m ago';\n"
        "  return Math.floor(s/3600)+'h ago';}\n"
        "function applyPayload(p){\n"
        "  if(!p)return;\n"
        "  var au=document.getElementById('mact-active-upstream');\n"
        "  if(au)au.textContent=p.active_upstream||'(none)';\n"
        "  var liveCount=(p.participants||[]).filter(function(x){return x.connected}).length;\n"
        "  var lc=document.getElementById('mact-live-count');\n"
        "  if(lc)lc.textContent=liveCount+'/'+p.participants.length;\n"
        "  var cc=document.getElementById('mact-commit-count');\n"
        "  if(cc)cc.textContent=(p.commits||[]).length;\n"
        "  var tb=document.getElementById('mact-participants-tbody');\n"
        "  if(tb){\n"
        "    tb.innerHTML='';\n"
        "    (p.participants||[]).forEach(function(m){\n"
        "      var tr=document.createElement('tr');\n"
        "      tr.innerHTML='<td>'+m.developer_id+'</td><td class=\"hash\">'+m.upstream_url"
        "+'</td><td>'+badge(m.connected)+'</td><td class=\"time\">'+timeAgo(m.last_seen_at)+'</td>';\n"
        "      tb.appendChild(tr);\n"
        "    });\n"
        "  }\n"
        "  var cb=document.getElementById('mact-commits-tbody');\n"
        "  if(cb){\n"
        "    cb.innerHTML='';\n"
        "    (p.commits||[]).forEach(function(c){\n"
        "      var tr=document.createElement('tr');\n"
        "      var cmt=c.admin_comment?'<span class=\"comment\">'+c.admin_comment+'</span>':'';\n"
        "      tr.innerHTML='<td class=\"hash\">'+c.commit_hash.substring(0,7)+'</td><td>'"
        "+c.developer_id+'</td><td>'+c.branch+'</td><td>'+c.message+'</td>'"
        "+'<td>'+cmt+'</td><td class=\"time\">'+timeAgo(c.server_received_at)+'</td>';\n"
        "      cb.appendChild(tr);\n"
        "    });\n"
        "    if(!p.commits||!p.commits.length){\n"
        "      var tr=document.createElement('tr');\n"
        "      tr.innerHTML='<td colspan=\"6\" class=\"empty\">(no commits yet)</td>';\n"
        "      cb.appendChild(tr);\n"
        "    }\n"
        "  }\n"
        "}\n"
        "function poll(){\n"
        "  fetch(statusUrl,{cache:'no-store',headers:{'Cache-Control':'no-cache'}})\n"
        "    .then(function(r){if(!r.ok)return null;return r.json();})\n"
        "    .then(function(d){if(d)applyPayload(d);})\n"
        "    .catch(function(){});\n"
        "}\n"
        "poll();setInterval(poll,2000);\n"
        "function connectWs(){\n"
        "  try{\n"
        "    var ws=new WebSocket(wsUrl);\n"
        "    ws.onmessage=function(ev){\n"
        "      try{var msg=JSON.parse(ev.data);\n"
        "      if(msg.type==='room_status')applyPayload(msg.payload);\n"
        "      }catch(e){}\n"
        "    };\n"
        "    ws.onclose=function(){setTimeout(connectWs,3000);};\n"
        "  }catch(e){setTimeout(connectWs,3000);}\n"
        "}\n"
        "connectWs();\n"
        "})();\n"
        "</script>"
    )


def _dashboard_html(room_id: str, payload: dict) -> str:
    esc = html.escape
    active = payload.get("active_upstream")
    active_str = esc(active) if active else "(none)"
    live_count = sum(1 for p in payload["participants"] if p["connected"])
    total = len(payload["participants"])
    commits = payload.get("commits", [])

    participant_rows = ""
    for p in payload["participants"]:
        badge = ('<span class="badge badge-live">LIVE</span>' if p["connected"]
                 else '<span class="badge badge-offline">OFFLINE</span>')
        participant_rows += (
            f"<tr><td>{esc(p['developer_id'])}</td>"
            f'<td class="hash">{esc(p["upstream_url"])}</td>'
            f"<td>{badge}</td>"
            f'<td class="time">{esc(p["last_seen_at"])}</td></tr>'
        )

    commit_rows = ""
    for c in commits:
        cmt = f'<span class="comment">{esc(c["admin_comment"])}</span>' if c.get("admin_comment") else ""
        commit_rows += (
            f'<tr><td class="hash">{esc(c["commit_hash"][:7])}</td>'
            f"<td>{esc(c['developer_id'])}</td>"
            f"<td>{esc(c['branch'])}</td>"
            f"<td>{esc(c['message'])}</td>"
            f"<td>{cmt}</td>"
            f'<td class="time">{esc(c["server_received_at"])}</td></tr>'
        )
    if not commit_rows:
        commit_rows = '<tr><td colspan="6" class="empty">(no commits yet)</td></tr>'

    return (
        "<!doctype html>"
        '<html lang="en"><head><meta charset="utf-8"/>'
        '<meta name="viewport" content="width=device-width,initial-scale=1"/>'
        f"<title>MACT — {esc(room_id)}</title>"
        f"{_dashboard_css()}"
        "</head><body>"
        '<div class="container">'
        f'<h1>Room <span class="room-title">{esc(room_id)}</span></h1>'
        '<div class="status-bar">'
        '<div class="status-item"><span class="status-label">Active Upstream</span>'
        f'<span class="status-value" id="mact-active-upstream">{active_str}</span></div>'
        '<div class="status-item"><span class="status-label">Members</span>'
        f'<span class="status-value" id="mact-live-count">{live_count}/{total}</span></div>'
        '<div class="status-item"><span class="status-label">Commits</span>'
        f'<span class="status-value" id="mact-commit-count">{len(commits)}</span></div>'
        "</div>"
        "<h2>Participants</h2>"
        "<table><thead><tr><th>Developer</th><th>Upstream</th><th>Status</th>"
        "<th>Last Seen</th></tr></thead>"
        f'<tbody id="mact-participants-tbody">{participant_rows}</tbody></table>'
        "<h2>Commit History</h2>"
        "<table><thead><tr><th>Hash</th><th>Author</th><th>Branch</th>"
        "<th>Message</th><th>Comment</th><th>Time</th></tr></thead>"
        f'<tbody id="mact-commits-tbody">{commit_rows}</tbody></table>'
        "</div>"
        f"{_dashboard_client_script(room_id)}"
        "</body></html>"
    )


def _mirror_live_html(room_id: str, iframe_src: str) -> str:
    esc = html.escape
    room_js = json.dumps(room_id)
    safe_src = esc(iframe_src, quote=True)
    return (
        "<!doctype html>"
        '<html lang="en"><head><meta charset="utf-8"/>'
        f"<title>MACT live — {esc(room_id)}</title>"
        "<style>html,body{height:100%;margin:0}"
        "#mact-mirror-frame{width:100%;height:100%;border:0}</style>"
        "</head><body>"
        f'<iframe id="mact-mirror-frame" src="{safe_src}" title="mirrored app"></iframe>'
        "<script>\n"
        "(function(){\n"
        f"var roomId = {room_js};\n"
        "var statusUrl = '/rooms/' + encodeURIComponent(roomId) + '/status';\n"
        "var iframe = document.getElementById('mact-mirror-frame');\n"
        "var lastUpstream = null;\n"
        "var wsProto = location.protocol === 'https:' ? 'wss:' : 'ws:';\n"
        "var wsUrl = wsProto + '//' + location.host + '/rooms/' + encodeURIComponent(roomId) + '/events';\n"
        "function reloadFrame() {\n"
        "  var base = iframe.src.split('?')[0];\n"
        "  iframe.src = base + '?mact_ts=' + Date.now();\n"
        "}\n"
        "function onStatus(p) {\n"
        "  if (!p) return;\n"
        "  var au = p.active_upstream;\n"
        "  if (au !== lastUpstream) {\n"
        "    if (lastUpstream !== null) reloadFrame();\n"
        "    lastUpstream = au;\n"
        "  }\n"
        "}\n"
        "function poll() {\n"
        "  fetch(statusUrl, { cache: 'no-store', headers: { 'Cache-Control': 'no-cache' } })\n"
        "    .then(function(r) { if (!r.ok) return null; return r.json(); })\n"
        "    .then(onStatus)\n"
        "    .catch(function() {});\n"
        "}\n"
        "poll();\n"
        "setInterval(poll, 2000);\n"
        "function connectWs() {\n"
        "  try {\n"
        "    var ws = new WebSocket(wsUrl);\n"
        "    ws.onmessage = function(ev) {\n"
        "      try {\n"
        "        var msg = JSON.parse(ev.data);\n"
        "        if (msg.type === 'room_status') onStatus(msg.payload);\n"
        "      } catch (e) {}\n"
        "    };\n"
        "    ws.onclose = function() { setTimeout(connectWs, 3000); };\n"
        "  } catch (e) { setTimeout(connectWs, 3000); }\n"
        "}\n"
        "connectWs();\n"
        "})();\n"
        "</script>"
        "</body></html>"
    )


def _room_dashboard_response(
    request: Request, db: Session, room_id: str
) -> HTMLResponse:
    _validate_room_id(room_id)
    payload = repo.get_room_status(
        db,
        room_id,
        presence_ttl_seconds=request.app.state.settings.presence_ttl_seconds,
    )
    if payload is None:
        return HTMLResponse(content=_offline_page(room_id), status_code=503)
    return HTMLResponse(content=_dashboard_html(room_id, payload))


@fastapi_app.get("/dashboard", response_class=HTMLResponse)
def room_dashboard(
    request: Request, db: Session = Depends(get_db)
) -> HTMLResponse:
    room_id = getattr(request.state, "mact_room_from_host", None)
    if not room_id:
        raise HTTPException(status_code=404, detail="Not found")
    return _room_dashboard_response(request, db, room_id)


def _path_dashboard_allowed() -> bool:
    return os.getenv("MACT_DEV_DASHBOARD", "").lower() in ("1", "true", "yes")


@fastapi_app.get("/rooms/{room_id}/dashboard", response_class=HTMLResponse)
def room_dashboard_by_path(
    room_id: str, request: Request, db: Session = Depends(get_db)
) -> HTMLResponse:
    """Browser-friendly dashboard when not using subdomains (local simulation).

    Same HTML as ``GET /dashboard`` on ``{room}.domain``. Requires
    ``MACT_DEV_DASHBOARD=true`` so it is off in production by default.
    """
    if not _path_dashboard_allowed():
        raise HTTPException(status_code=404, detail="Not found")
    return _room_dashboard_response(request, db, room_id)


@fastapi_app.get("/live", response_class=HTMLResponse)
def mirror_live_subdomain(request: Request) -> HTMLResponse:
    """Auto-updating mirror shell (iframe + WebSocket). Use on ``{room}.domain/live``."""
    room_id = getattr(request.state, "mact_room_from_host", None)
    if not room_id:
        raise HTTPException(status_code=404, detail="Not found")
    return HTMLResponse(content=_mirror_live_html(room_id, "/"))


@fastapi_app.get("/r/{room_id}/live", response_class=HTMLResponse)
def mirror_live_under_r(room_id: str) -> HTMLResponse:
    """Iframe + WebSocket: reloads mirrored content when the active upstream changes."""
    _validate_room_id(room_id)
    return HTMLResponse(content=_mirror_live_html(room_id, f"/r/{room_id}/"))


def _inject_mirror_reload_script(content: bytes, room_id: str) -> bytes:
    """Append a script to mirrored HTML that reloads the page when the active upstream changes."""
    rj = json.dumps(room_id)
    script = (
        "\n<!-- MACT live-reload -->\n"
        "<script>\n"
        "(function(){\n"
        f"var ROOM_ID={rj};\n"
        "var statusUrl='/rooms/'+encodeURIComponent(ROOM_ID)+'/status';\n"
        "var lastUpstream=null;\n"
        "function check(){\n"
        "  fetch(statusUrl,{cache:'no-store',headers:{'Cache-Control':'no-cache'}})\n"
        "    .then(function(r){if(!r.ok)return null;return r.json();})\n"
        "    .then(function(d){\n"
        "      if(!d)return;\n"
        "      var au=d.active_upstream;\n"
        "      if(lastUpstream===null){lastUpstream=au;return;}\n"
        "      if(au!==lastUpstream){location.reload();}\n"
        "    }).catch(function(){});\n"
        "}\n"
        "check();\n"
        "setInterval(check,2000);\n"
        "var wsProto=location.protocol==='https:'?'wss:':'ws:';\n"
        "var wsUrl=wsProto+'//'+location.host+'/rooms/'+encodeURIComponent(ROOM_ID)+'/events';\n"
        "function connectWs(){\n"
        "  try{\n"
        "    var ws=new WebSocket(wsUrl);\n"
        "    ws.onmessage=function(ev){\n"
        "      try{\n"
        "        var msg=JSON.parse(ev.data);\n"
        "        if(msg.type==='room_status'&&msg.payload){\n"
        "          var au=msg.payload.active_upstream;\n"
        "          if(lastUpstream===null){lastUpstream=au;return;}\n"
        "          if(au!==lastUpstream){location.reload();}\n"
        "        }\n"
        "      }catch(e){}\n"
        "    };\n"
        "    ws.onclose=function(){setTimeout(connectWs,3000);};\n"
        "  }catch(e){setTimeout(connectWs,3000);}\n"
        "}\n"
        "connectWs();\n"
        "})();\n"
        "</script>\n"
    ).encode()

    html_lower = content.lower()
    close_body = html_lower.rfind(b"</body>")
    if close_body != -1:
        return content[:close_body] + script + content[close_body:]
    close_html = html_lower.rfind(b"</html>")
    if close_html != -1:
        return content[:close_html] + script + content[close_html:]
    return content + script


@fastapi_app.api_route(
    "/r/{room_id}",
    methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
)
@fastapi_app.api_route(
    "/r/{room_id}/{path:path}",
    methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
)
async def mirror_room(
    room_id: str,
    request: Request,
    path: str = "",
    db: Session = Depends(get_db),
) -> Response:
    _validate_room_id(room_id)
    active = repo.resolve_active_upstream(
        db,
        room_id,
        presence_ttl_seconds=request.app.state.settings.presence_ttl_seconds,
    )
    if not active:
        LOGGER.info("mirror room_id=%s resolved=offline", room_id)
        return HTMLResponse(content=_offline_page(room_id), status_code=503)

    LOGGER.debug("mirror room_id=%s resolved_upstream=%s path=%s", room_id, active, path)
    target_url = _build_target_url(active, path, request.url.query)
    outbound_headers = {
        key: value
        for key, value in request.headers.items()
        if key.lower() not in HOP_BY_HOP_HEADERS
    }
    body = await request.body()

    try:
        mirror_client: httpx.AsyncClient = request.app.state.mirror_client
        upstream = await mirror_client.request(
            method=request.method,
            url=target_url,
            content=body if body else None,
            headers=outbound_headers,
            follow_redirects=True,
        )
    except httpx.RequestError as exc:
        raise HTTPException(
            status_code=502,
            detail=f"upstream request failed: {exc.__class__.__name__}",
        ) from exc

    response_headers = {
        key: value
        for key, value in upstream.headers.items()
        if key.lower() not in STRIP_UPSTREAM_HEADERS
    }
    response_headers["cache-control"] = "no-store"
    response_headers["x-mact-upstream"] = active

    content = upstream.content
    content_type = (upstream.headers.get("content-type") or "").lower()
    if "text/html" in content_type and upstream.status_code < 400:
        content = _inject_mirror_reload_script(content, room_id)
        response_headers.pop("content-length", None)

    return Response(
        content=content,
        status_code=upstream.status_code,
        headers=response_headers,
    )


app = SubdomainRewriteMiddleware(fastapi_app)


def run() -> None:
    uvicorn.run("mact.server.main:app", host="0.0.0.0", port=8000, reload=False)
