from __future__ import annotations

import json
from pathlib import Path

CONFIG_PATH = Path.home() / ".mact_config.json"
ROOMS_PATH = Path.home() / ".mact_rooms.json"


def _read_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def _write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


# -- developer identity --

def get_developer_id() -> str | None:
    data = _read_json(CONFIG_PATH)
    value = data.get("developer_id")
    return value if isinstance(value, str) else None


def set_developer_id(developer_id: str) -> None:
    data = _read_json(CONFIG_PATH)
    data["developer_id"] = developer_id
    _write_json(CONFIG_PATH, data)


# -- frp tunnel settings --

def get_frp_config() -> dict:
    data = _read_json(CONFIG_PATH)
    return data.get("frp", {})


def set_frp_config(
    server_addr: str,
    server_port: int,
    auth_token: str = "",
    vhost_domain: str = "tunnel.mact.live",
    vhost_http_port: int = 80,
) -> None:
    data = _read_json(CONFIG_PATH)
    data["frp"] = {
        "server_addr": server_addr,
        "server_port": server_port,
        "auth_token": auth_token,
        "vhost_domain": vhost_domain,
        "vhost_http_port": vhost_http_port,
    }
    _write_json(CONFIG_PATH, data)


# -- room metadata --

def save_room(room_id: str, room_data: dict) -> None:
    data = _read_json(ROOMS_PATH)
    data[room_id] = room_data
    _write_json(ROOMS_PATH, data)


def get_room(room_id: str) -> dict | None:
    data = _read_json(ROOMS_PATH)
    return data.get(room_id)


def get_rooms() -> dict:
    return _read_json(ROOMS_PATH)
