from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import threading
import time

import requests

from mact.cli.config import (
    get_developer_id,
    get_frp_config,
    get_room,
    get_rooms,
    save_room,
    set_developer_id,
    set_frp_config,
)


def _backend_url() -> str:
    return os.getenv("MACT_BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_init(args: argparse.Namespace) -> int:
    set_developer_id(args.developer)
    print(f"Initialized developer identity: {args.developer}")
    return 0


def cmd_configure_frp(args: argparse.Namespace) -> int:
    set_frp_config(
        server_addr=args.server_addr,
        server_port=args.server_port,
        auth_token=args.auth_token,
        vhost_domain=args.vhost_domain,
        vhost_http_port=args.vhost_http_port,
    )
    print(f"FRP config saved (server={args.server_addr}:{args.server_port})")
    return 0


def cmd_create(args: argparse.Namespace) -> int:
    developer_id = get_developer_id()
    if not developer_id:
        print("Run `mact init --developer <id>` first.", file=sys.stderr)
        return 1

    upstream_url = f"http://127.0.0.1:{args.port}"
    payload = {
        "room_id": args.room,
        "developer_id": developer_id,
        "upstream_url": upstream_url,
    }
    resp = requests.post(f"{_backend_url()}/rooms", json=payload, timeout=10)
    if resp.status_code >= 400:
        print(f"Create failed: {resp.status_code} {resp.text}", file=sys.stderr)
        return 1

    data = resp.json()
    save_room(
        args.room,
        {
            "developer_id": developer_id,
            "local_port": args.port,
            "upstream_url": upstream_url,
            "join_secret": data["join_secret"],
            "admin_token": data["admin_token"],
            "member_token": data["member_token"],
        },
    )
    print(f"Created room `{args.room}`")
    print(f"  Join secret : {data['join_secret']}")
    print(f"  Admin token : {data['admin_token']}")
    print(f"  Member token: {data['member_token']}")
    print("Share the join secret with collaborators.")
    return 0


def cmd_join(args: argparse.Namespace) -> int:
    developer_id = get_developer_id()
    if not developer_id:
        print("Run `mact init --developer <id>` first.", file=sys.stderr)
        return 1

    upstream_url = f"http://127.0.0.1:{args.port}"
    payload = {
        "developer_id": developer_id,
        "upstream_url": upstream_url,
        "join_secret": args.secret,
    }
    resp = requests.post(
        f"{_backend_url()}/rooms/{args.room}/join", json=payload, timeout=10
    )
    if resp.status_code >= 400:
        print(f"Join failed: {resp.status_code} {resp.text}", file=sys.stderr)
        return 1

    data = resp.json()
    save_room(
        args.room,
        {
            "developer_id": developer_id,
            "local_port": args.port,
            "upstream_url": upstream_url,
            "member_token": data["member_token"],
        },
    )
    print(f"Joined room `{args.room}` — member token stored locally.")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    resp = requests.get(
        f"{_backend_url()}/rooms/{args.room}/status", timeout=10
    )
    if resp.status_code >= 400:
        print(f"Status failed: {resp.status_code} {resp.text}", file=sys.stderr)
        return 1
    data = resp.json()
    print(f"Room: {data['room_id']}")
    print(f"Active upstream: {data['active_upstream']}")
    latest = data.get("latest_commit")
    if latest:
        print(
            f"Latest commit: {latest['commit_hash']} "
            f"({latest['developer_id']}) — {latest['message']}"
        )
    else:
        print("Latest commit: none")
    print(f"Participants: {len(data['participants'])}")
    for p in data["participants"]:
        live = "live" if p["connected"] else "offline"
        print(f"  {p['developer_id']}: {p['upstream_url']} [{live}]")
    return 0


def cmd_rooms(_args: argparse.Namespace) -> int:
    rooms = get_rooms()
    if not rooms:
        print("No local room metadata yet.")
        return 0
    for room_id, data in rooms.items():
        port = data.get("local_port", "?")
        print(f"  {room_id}  (port {port})")
    return 0


# ---------------------------------------------------------------------------
# `mact up` — long-running tunnel + heartbeat
# ---------------------------------------------------------------------------

def cmd_up(args: argparse.Namespace) -> int:
    room_data = get_room(args.room)
    if not room_data:
        print(f"Room `{args.room}` not found locally. Create or join first.", file=sys.stderr)
        return 1

    developer_id = room_data.get("developer_id") or get_developer_id()
    member_token = room_data.get("member_token")
    if not member_token:
        print("No member token stored for this room.", file=sys.stderr)
        return 1

    port = args.port or room_data.get("local_port")
    if not port:
        print("Specify --port or create/join with a port first.", file=sys.stderr)
        return 1

    tunnel = None
    upstream_url = f"http://127.0.0.1:{port}"

    frp_cfg = get_frp_config()
    if frp_cfg and not args.no_tunnel:
        try:
            from mact.tunnel.frpc import FrpcTunnel

            tunnel = FrpcTunnel(
                local_port=int(port),
                room_id=args.room,
                developer_id=developer_id,
                server_addr=frp_cfg.get("server_addr", "mact.live"),
                server_port=int(frp_cfg.get("server_port", 7000)),
                auth_token=frp_cfg.get("auth_token", ""),
                vhost_domain=frp_cfg.get("vhost_domain", "tunnel.mact.live"),
                vhost_http_port=int(frp_cfg.get("vhost_http_port", 80)),
            )
            tunnel.start()
            upstream_url = tunnel.public_url
            print(f"Tunnel started → {upstream_url}")
        except RuntimeError as exc:
            print(f"Tunnel failed: {exc}", file=sys.stderr)
            print("Falling back to local URL.", file=sys.stderr)
    else:
        if not args.no_tunnel:
            print("No FRP config — run `mact configure-frp` to enable tunneling.")
        print(f"Heartbeat-only mode (upstream={upstream_url})")

    backend = _backend_url()
    headers = {"Authorization": f"Bearer {member_token}"}
    stop_event = threading.Event()

    def _cleanup() -> None:
        stop_event.set()
        try:
            requests.post(
                f"{backend}/rooms/{args.room}/presence/disconnect",
                json={"developer_id": developer_id},
                headers=headers,
                timeout=5,
            )
        except Exception:
            pass
        if tunnel:
            tunnel.stop()

    signal.signal(signal.SIGTERM, lambda *_: stop_event.set())
    signal.signal(signal.SIGINT, lambda *_: stop_event.set())

    print(f"Room `{args.room}` is live. Press Ctrl+C to stop.")

    try:
        while not stop_event.is_set():
            try:
                requests.post(
                    f"{backend}/rooms/{args.room}/presence/heartbeat",
                    json={
                        "developer_id": developer_id,
                        "upstream_url": upstream_url,
                    },
                    headers=headers,
                    timeout=10,
                )
            except requests.RequestException as exc:
                print(f"Heartbeat failed: {exc}", file=sys.stderr)
            stop_event.wait(30)
    except KeyboardInterrupt:
        pass
    finally:
        _cleanup()
        print("\nDisconnected.")
    return 0


# ---------------------------------------------------------------------------
# `mact hook install` — git post-commit hook
# ---------------------------------------------------------------------------

_HOOK_SCRIPT_TEMPLATE = """\
#!/bin/sh
# MACT post-commit hook — reports commits to the server.
# Installed by: mact hook install --room {room_id}
HASH=$(git rev-parse HEAD)
BRANCH=$(git rev-parse --abbrev-ref HEAD)
MESSAGE=$(git log -1 --format=%s HEAD)
mact commit-report --room {room_id} --hash "$HASH" --branch "$BRANCH" --message "$MESSAGE"
"""


def cmd_hook_install(args: argparse.Namespace) -> int:
    git_dir = _find_git_dir()
    if git_dir is None:
        print("Not inside a git repository.", file=sys.stderr)
        return 1

    hook_path = git_dir / "hooks" / "post-commit"
    hook_path.parent.mkdir(parents=True, exist_ok=True)
    hook_path.write_text(
        _HOOK_SCRIPT_TEMPLATE.format(room_id=args.room), encoding="utf-8"
    )
    hook_path.chmod(0o755)
    print(f"Installed post-commit hook → {hook_path}")
    return 0


def _find_git_dir():
    from pathlib import Path

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True,
            text=True,
            check=True,
        )
        return Path(result.stdout.strip()).resolve()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


# ---------------------------------------------------------------------------
# `mact commit-report` — called from the post-commit hook
# ---------------------------------------------------------------------------

def cmd_commit_report(args: argparse.Namespace) -> int:
    room_data = get_room(args.room)
    if not room_data:
        print(f"Room `{args.room}` not found locally.", file=sys.stderr)
        return 1

    developer_id = room_data.get("developer_id") or get_developer_id()
    member_token = room_data.get("member_token")
    if not member_token or not developer_id:
        print("Missing credentials for this room.", file=sys.stderr)
        return 1

    commit_hash = args.hash
    branch = args.branch
    message = args.message

    if not commit_hash:
        try:
            commit_hash = subprocess.check_output(
                ["git", "rev-parse", "HEAD"], text=True
            ).strip()
        except Exception:
            print("Could not determine commit hash.", file=sys.stderr)
            return 1
    if not branch:
        try:
            branch = subprocess.check_output(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"], text=True
            ).strip()
        except Exception:
            branch = "unknown"
    if not message:
        try:
            message = subprocess.check_output(
                ["git", "log", "-1", "--format=%s", "HEAD"], text=True
            ).strip()
        except Exception:
            message = "(no message)"

    resp = requests.post(
        f"{_backend_url()}/rooms/{args.room}/commits",
        json={
            "developer_id": developer_id,
            "commit_hash": commit_hash[:40],
            "branch": branch[:80],
            "message": message[:250],
        },
        headers={"Authorization": f"Bearer {member_token}"},
        timeout=10,
    )
    if resp.status_code >= 400:
        print(
            f"Commit report failed: {resp.status_code} {resp.text}",
            file=sys.stderr,
        )
        return 1
    result = resp.json()
    if result.get("inserted"):
        print(f"Reported commit {commit_hash[:7]}")
    else:
        print(f"Commit {commit_hash[:7]} already reported (duplicate)")
    return 0


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="mact")
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", help="Set developer identity")
    p_init.add_argument("--developer", required=True)
    p_init.set_defaults(func=cmd_init)

    p_frp = sub.add_parser("configure-frp", help="Set FRP tunnel configuration")
    p_frp.add_argument("--server-addr", required=True)
    p_frp.add_argument("--server-port", type=int, default=7000)
    p_frp.add_argument("--auth-token", default="")
    p_frp.add_argument("--vhost-domain", default="tunnel.mact.live")
    p_frp.add_argument("--vhost-http-port", type=int, default=80,
                        help="frps vhostHTTPPort (default 80)")
    p_frp.set_defaults(func=cmd_configure_frp)

    p_create = sub.add_parser("create", help="Create room and register first member")
    p_create.add_argument("--room", required=True)
    p_create.add_argument("--port", required=True, type=int)
    p_create.set_defaults(func=cmd_create)

    p_join = sub.add_parser("join", help="Join existing room")
    p_join.add_argument("--room", required=True)
    p_join.add_argument("--port", required=True, type=int)
    p_join.add_argument("--secret", required=True, help="Join secret from room creator")
    p_join.set_defaults(func=cmd_join)

    p_up = sub.add_parser("up", help="Start tunnel + heartbeat (long-running)")
    p_up.add_argument("--room", required=True)
    p_up.add_argument("--port", type=int, default=None)
    p_up.add_argument(
        "--no-tunnel", action="store_true", help="Heartbeat only, no frpc tunnel"
    )
    p_up.set_defaults(func=cmd_up)

    p_status = sub.add_parser("status", help="Fetch room status")
    p_status.add_argument("--room", required=True)
    p_status.set_defaults(func=cmd_status)

    p_rooms = sub.add_parser("rooms", help="Show locally saved room metadata")
    p_rooms.set_defaults(func=cmd_rooms)

    p_hook = sub.add_parser("hook", help="Install git post-commit hook")
    p_hook_sub = p_hook.add_subparsers(dest="hook_command", required=True)
    p_hook_install = p_hook_sub.add_parser("install")
    p_hook_install.add_argument("--room", required=True)
    p_hook_install.set_defaults(func=cmd_hook_install)

    p_commit = sub.add_parser(
        "commit-report", help="Report a commit (used by git hook)"
    )
    p_commit.add_argument("--room", required=True)
    p_commit.add_argument("--hash", default=None)
    p_commit.add_argument("--branch", default=None)
    p_commit.add_argument("--message", default=None)
    p_commit.set_defaults(func=cmd_commit_report)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    rc = args.func(args)
    raise SystemExit(rc)
