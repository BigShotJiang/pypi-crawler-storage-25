from __future__ import annotations

import os
import signal
import subprocess
import tempfile
from pathlib import Path

from mact.tunnel.base import Tunnel
from mact.tunnel.frpc_download import ensure_frpc_executable


class FrpcTunnel(Tunnel):
    """Manages an frpc process that tunnels a local port via frps."""

    def __init__(
        self,
        local_port: int,
        room_id: str,
        developer_id: str,
        server_addr: str = "mact.live",
        server_port: int = 7000,
        auth_token: str = "",
        vhost_domain: str = "tunnel.mact.live",
        vhost_http_port: int = 80,
    ) -> None:
        self._local_port = local_port
        self._room_id = room_id
        self._developer_id = developer_id
        self._server_addr = server_addr
        self._server_port = server_port
        self._auth_token = auth_token
        self._vhost_domain = vhost_domain
        self._vhost_http_port = vhost_http_port
        self._process: subprocess.Popen | None = None
        self._config_path: Path | None = None

    @property
    def proxy_name(self) -> str:
        return f"mact-{self._developer_id}-{self._room_id}"

    @property
    def public_url(self) -> str:
        host = f"{self._developer_id}-{self._room_id}.{self._vhost_domain}"
        if self._vhost_http_port and self._vhost_http_port != 80:
            return f"http://{host}:{self._vhost_http_port}"
        return f"http://{host}"

    def generate_config(self) -> str:
        # Minimal TOML-safe escaping for quoted string values.
        def _toml_escape(value: str) -> str:
            return value.replace("\\", "\\\\").replace('"', '\\"')

        lines = [
            f'serverAddr = "{self._server_addr}"',
            f"serverPort = {self._server_port}",
        ]
        if self._auth_token:
            lines.append(f'auth.token = "{_toml_escape(self._auth_token)}"')
        lines.extend(
            [
                "",
                "[[proxies]]",
                f'name = "{self.proxy_name}"',
                'type = "http"',
                f"localPort = {self._local_port}",
                f'customDomains = ["{self._developer_id}-{self._room_id}.{self._vhost_domain}"]',
            ]
        )
        return "\n".join(lines) + "\n"

    def start(self) -> None:
        if self._process and self._process.poll() is None:
            return

        frpc = ensure_frpc_executable()

        config_content = self.generate_config()
        fd, path = tempfile.mkstemp(suffix=".toml", prefix="mact-frpc-")
        try:
            os.write(fd, config_content.encode())
        finally:
            os.close(fd)
        self._config_path = Path(path)

        self._process = subprocess.Popen(
            [frpc, "-c", str(self._config_path)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )

    def stop(self) -> None:
        if self._process and self._process.poll() is None:
            self._process.send_signal(signal.SIGTERM)
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
                self._process.wait()
        if self._config_path and self._config_path.exists():
            self._config_path.unlink(missing_ok=True)
        self._process = None

    def is_running(self) -> bool:
        return self._process is not None and self._process.poll() is None
