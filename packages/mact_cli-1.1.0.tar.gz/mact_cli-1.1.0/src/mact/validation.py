"""Shared validation patterns — single source of truth for slug/format regexes."""

from __future__ import annotations

import re

ROOM_RE = re.compile(r"^(?:[a-z0-9]|[a-z0-9][a-z0-9_-]{0,48}[a-z0-9])$")
DEV_RE = re.compile(r"^[a-zA-Z0-9_-]{1,30}$")
HASH_RE = re.compile(r"^[a-f0-9]{7,40}$")
BRANCH_RE = re.compile(r"^[a-zA-Z0-9/_.-]{1,80}$")
