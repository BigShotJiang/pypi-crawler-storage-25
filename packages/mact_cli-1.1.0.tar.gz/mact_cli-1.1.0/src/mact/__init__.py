"""MACT — Mirrored Active Collaborative Tunnel."""

__version__ = "1.1.0"
