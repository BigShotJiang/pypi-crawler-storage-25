"""Install/uninstall/status for the Kyber gateway and dashboard services.

Mirrors the service-setup block in the web installer (kyber.chat/install.sh)
so users who skipped service mode during onboarding can enable it later with
``kyber service install``. Also used for repair and removal.

Two platforms are supported:

* **macOS** — launchd user agents under ``~/Library/LaunchAgents/`` with
  labels ``chat.kyber.gateway`` and ``chat.kyber.dashboard``. Logs go to
  ``~/.kyber/logs/{gateway,dashboard}.{log,err.log}``.
* **Linux / WSL** — systemd user units at
  ``~/.config/systemd/user/kyber-{gateway,dashboard}.service``, with
  ``loginctl enable-linger`` so they survive logout.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path

GATEWAY_LABEL = "chat.kyber.gateway"
DASHBOARD_LABEL = "chat.kyber.dashboard"
GATEWAY_UNIT = "kyber-gateway.service"
DASHBOARD_UNIT = "kyber-dashboard.service"


class UnsupportedPlatformError(RuntimeError):
    """Raised when the current OS has no service backend we support."""


@dataclass
class UnitStatus:
    name: str  # user-facing service name, e.g. "gateway"
    installed: bool  # file on disk
    active: bool  # currently running
    identifier: str  # plist label or systemd unit name
    file_path: Path


@dataclass
class ServiceInfo:
    backend: str  # "launchd" | "systemd"
    gateway: UnitStatus
    dashboard: UnitStatus


def _detect_backend() -> str:
    system = platform.system()
    if system == "Darwin":
        return "launchd"
    if system == "Linux":
        if shutil.which("systemctl") is None:
            raise UnsupportedPlatformError(
                "systemctl is not available on this system. "
                "Kyber service mode on Linux requires systemd --user."
            )
        return "systemd"
    raise UnsupportedPlatformError(
        f"Kyber service mode is not supported on {system}. "
        "Run `kyber gateway` and `kyber dashboard` manually."
    )


def _resolve_kyber_bin() -> Path:
    """Return the absolute path to the ``kyber`` executable.

    Checks ``sys.argv[0]``, the current Python's scripts dir, and PATH.
    Falls back to ``~/.local/bin/kyber`` since that is where ``uv tool
    install kyber-chat`` drops it on both macOS and Linux.
    """
    candidates: list[Path] = []
    if sys.argv and sys.argv[0]:
        try:
            candidates.append(Path(sys.argv[0]).resolve())
        except OSError:
            pass
    from_path = shutil.which("kyber")
    if from_path:
        candidates.append(Path(from_path).resolve())
    candidates.append(Path.home() / ".local" / "bin" / "kyber")

    for c in candidates:
        try:
            if c.is_file() and os.access(c, os.X_OK) and c.name == "kyber":
                return c
        except OSError:
            continue
    # Last resort: trust the default path even if it doesn't exist yet.
    return Path.home() / ".local" / "bin" / "kyber"


# ── launchd (macOS) ────────────────────────────────────────────────────────


def _launchagent_dir() -> Path:
    return Path.home() / "Library" / "LaunchAgents"


def _launch_plist_path(label: str) -> Path:
    return _launchagent_dir() / f"{label}.plist"


def _render_plist(label: str, kyber_bin: Path, subcommand: str, log_dir: Path) -> str:
    env_path = f"{Path.home()}/.local/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin"
    return f"""<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">
<plist version=\"1.0\">
<dict>
  <key>Label</key>
  <string>{label}</string>
  <key>ProgramArguments</key>
  <array>
    <string>{kyber_bin}</string>
    <string>{subcommand}</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>{log_dir}/{subcommand}.log</string>
  <key>StandardErrorPath</key>
  <string>{log_dir}/{subcommand}.err.log</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>{env_path}</string>
  </dict>
</dict>
</plist>
"""


def _launchctl(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["launchctl", *args], capture_output=True, text=True, timeout=15
    )


def _launchd_is_loaded(label: str) -> bool:
    """Return True if the given label is currently loaded for this user.

    ``launchctl list <label>`` exits 0 when loaded, non-zero otherwise.
    """
    try:
        uid = os.getuid()
        result = subprocess.run(
            ["launchctl", "print", f"gui/{uid}/{label}"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _launchd_install(kyber_bin: Path) -> tuple[UnitStatus, UnitStatus]:
    launch_dir = _launchagent_dir()
    log_dir = Path.home() / ".kyber" / "logs"
    launch_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)

    results: list[UnitStatus] = []
    for name, label in (("gateway", GATEWAY_LABEL), ("dashboard", DASHBOARD_LABEL)):
        plist_path = _launch_plist_path(label)
        plist_path.write_text(
            _render_plist(label, kyber_bin, name, log_dir), encoding="utf-8"
        )

        # Unload first so updates to the plist take effect.
        _launchctl("unload", str(plist_path))
        load_result = _launchctl("load", str(plist_path))
        if load_result.returncode != 0:
            # Kickstart as a fallback so an orphan job doesn't block reload.
            uid = os.getuid()
            _launchctl("kickstart", "-k", f"gui/{uid}/{label}")

        # Give launchd a moment to flip the state before probing.
        time.sleep(0.3)
        active = _launchd_is_loaded(label)
        results.append(
            UnitStatus(
                name=name,
                installed=plist_path.is_file(),
                active=active,
                identifier=label,
                file_path=plist_path,
            )
        )
    return results[0], results[1]


def _launchd_uninstall() -> tuple[UnitStatus, UnitStatus]:
    results: list[UnitStatus] = []
    for name, label in (("gateway", GATEWAY_LABEL), ("dashboard", DASHBOARD_LABEL)):
        plist_path = _launch_plist_path(label)
        _launchctl("unload", str(plist_path))
        removed = False
        if plist_path.is_file():
            try:
                plist_path.unlink()
                removed = True
            except OSError:
                removed = False
        results.append(
            UnitStatus(
                name=name,
                installed=not removed and plist_path.is_file(),
                active=False,
                identifier=label,
                file_path=plist_path,
            )
        )
    return results[0], results[1]


def _launchd_restart() -> tuple[UnitStatus, UnitStatus]:
    results: list[UnitStatus] = []
    for name, label in (("gateway", GATEWAY_LABEL), ("dashboard", DASHBOARD_LABEL)):
        plist_path = _launch_plist_path(label)
        if plist_path.is_file():
            _launchctl("unload", str(plist_path))
            load_result = _launchctl("load", str(plist_path))
            if load_result.returncode != 0:
                uid = os.getuid()
                _launchctl("kickstart", "-k", f"gui/{uid}/{label}")
        time.sleep(0.3)
        results.append(
            UnitStatus(
                name=name,
                installed=plist_path.is_file(),
                active=_launchd_is_loaded(label),
                identifier=label,
                file_path=plist_path,
            )
        )
    return results[0], results[1]


def _launchd_status() -> tuple[UnitStatus, UnitStatus]:
    results: list[UnitStatus] = []
    for name, label in (("gateway", GATEWAY_LABEL), ("dashboard", DASHBOARD_LABEL)):
        plist_path = _launch_plist_path(label)
        results.append(
            UnitStatus(
                name=name,
                installed=plist_path.is_file(),
                active=_launchd_is_loaded(label),
                identifier=label,
                file_path=plist_path,
            )
        )
    return results[0], results[1]


# ── systemd (Linux) ────────────────────────────────────────────────────────


def _systemd_dir() -> Path:
    return Path.home() / ".config" / "systemd" / "user"


def _render_unit(description: str, kyber_bin: Path, subcommand: str) -> str:
    env_path = f"{Path.home()}/.local/bin:/usr/local/bin:/usr/bin:/bin"
    # systemd requires a fully-qualified path for ExecStart.
    return f"""[Unit]
Description={description}
{'Wants=network-online.target' if subcommand == 'gateway' else ''}
After={'network-online.target' if subcommand == 'gateway' else 'network.target'}

[Service]
Type=simple
ExecStart={kyber_bin} {subcommand}
WorkingDirectory={Path.home()}
Restart=always
RestartSec=5
Environment=PATH={env_path}

[Install]
WantedBy=default.target
"""


def _systemctl(*args: str, check: bool = False) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["systemctl", "--user", *args],
        capture_output=True,
        text=True,
        timeout=20,
        check=check,
    )


def _systemd_is_active(unit: str) -> bool:
    try:
        result = _systemctl("is-active", unit)
        return result.stdout.strip() == "active"
    except (OSError, subprocess.SubprocessError):
        return False


def _systemd_install(kyber_bin: Path) -> tuple[UnitStatus, UnitStatus]:
    unit_dir = _systemd_dir()
    unit_dir.mkdir(parents=True, exist_ok=True)

    results: list[UnitStatus] = []
    for name, unit, description in (
        ("gateway", GATEWAY_UNIT, "Kyber Gateway"),
        ("dashboard", DASHBOARD_UNIT, "Kyber Dashboard"),
    ):
        unit_path = unit_dir / unit
        unit_path.write_text(_render_unit(description, kyber_bin, name), encoding="utf-8")

    _systemctl("daemon-reload")
    _systemctl("enable", GATEWAY_UNIT)
    _systemctl("enable", DASHBOARD_UNIT)
    _systemctl("reset-failed", GATEWAY_UNIT, DASHBOARD_UNIT)

    for name, unit in (("gateway", GATEWAY_UNIT), ("dashboard", DASHBOARD_UNIT)):
        # Restart if already running, otherwise start.
        if _systemd_is_active(unit):
            _systemctl("restart", unit)
        else:
            _systemctl("start", unit)
        # Wait up to ~3s for the unit to reach "active".
        for _ in range(10):
            if _systemd_is_active(unit):
                break
            time.sleep(0.3)
        results.append(
            UnitStatus(
                name=name,
                installed=(unit_dir / unit).is_file(),
                active=_systemd_is_active(unit),
                identifier=unit,
                file_path=unit_dir / unit,
            )
        )

    # Keep user services running after logout on headless boxes.
    if shutil.which("loginctl") is not None:
        try:
            subprocess.run(
                ["loginctl", "enable-linger", os.environ.get("USER", "")],
                capture_output=True,
                timeout=10,
            )
        except (OSError, subprocess.SubprocessError):
            pass

    return results[0], results[1]


def _systemd_uninstall() -> tuple[UnitStatus, UnitStatus]:
    results: list[UnitStatus] = []
    for name, unit in (("gateway", GATEWAY_UNIT), ("dashboard", DASHBOARD_UNIT)):
        _systemctl("stop", unit)
        _systemctl("disable", unit)
        unit_path = _systemd_dir() / unit
        removed = False
        if unit_path.is_file():
            try:
                unit_path.unlink()
                removed = True
            except OSError:
                removed = False
        results.append(
            UnitStatus(
                name=name,
                installed=not removed and unit_path.is_file(),
                active=False,
                identifier=unit,
                file_path=unit_path,
            )
        )
    _systemctl("daemon-reload")
    return results[0], results[1]


def _systemd_restart() -> tuple[UnitStatus, UnitStatus]:
    results: list[UnitStatus] = []
    for name, unit in (("gateway", GATEWAY_UNIT), ("dashboard", DASHBOARD_UNIT)):
        unit_path = _systemd_dir() / unit
        if unit_path.is_file():
            _systemctl("restart", unit)
            for _ in range(10):
                if _systemd_is_active(unit):
                    break
                time.sleep(0.3)
        results.append(
            UnitStatus(
                name=name,
                installed=unit_path.is_file(),
                active=_systemd_is_active(unit),
                identifier=unit,
                file_path=unit_path,
            )
        )
    return results[0], results[1]


def _systemd_status() -> tuple[UnitStatus, UnitStatus]:
    results: list[UnitStatus] = []
    for name, unit in (("gateway", GATEWAY_UNIT), ("dashboard", DASHBOARD_UNIT)):
        unit_path = _systemd_dir() / unit
        results.append(
            UnitStatus(
                name=name,
                installed=unit_path.is_file(),
                active=_systemd_is_active(unit),
                identifier=unit,
                file_path=unit_path,
            )
        )
    return results[0], results[1]


# ── Public API ─────────────────────────────────────────────────────────────


def install_services() -> ServiceInfo:
    backend = _detect_backend()
    kyber_bin = _resolve_kyber_bin()
    if backend == "launchd":
        gw, dash = _launchd_install(kyber_bin)
    else:
        gw, dash = _systemd_install(kyber_bin)
    return ServiceInfo(backend=backend, gateway=gw, dashboard=dash)


def uninstall_services() -> ServiceInfo:
    backend = _detect_backend()
    if backend == "launchd":
        gw, dash = _launchd_uninstall()
    else:
        gw, dash = _systemd_uninstall()
    return ServiceInfo(backend=backend, gateway=gw, dashboard=dash)


def restart_services() -> ServiceInfo:
    backend = _detect_backend()
    if backend == "launchd":
        gw, dash = _launchd_restart()
    else:
        gw, dash = _systemd_restart()
    return ServiceInfo(backend=backend, gateway=gw, dashboard=dash)


def service_status() -> ServiceInfo:
    backend = _detect_backend()
    if backend == "launchd":
        gw, dash = _launchd_status()
    else:
        gw, dash = _systemd_status()
    return ServiceInfo(backend=backend, gateway=gw, dashboard=dash)
