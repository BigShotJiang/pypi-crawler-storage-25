from .base_client import BaseClient
from ..managers import ChannelManager, GuildManager
from ..structures import ClientUser, Channel
from ..types import ClientOptions
from ..events.handlers import (
    handle_private_message_create, handle_message_create,
    handle_member_joined, handle_member_left, handle_user_invite
)

class Client(BaseClient):
    def __init__(self, token: str, options: ClientOptions = None):
        super().__init__(token, options)

        self.channels = ChannelManager(self)
        self.guilds = GuildManager(self)
        self.user = ClientUser(self)

        self._setup_event_handlers()

    def _setup_event_handlers(self):
        self.get_ws().on('privateMessageCreate', lambda data: handle_private_message_create(self, data))
        self.get_ws().on('messageCreate', lambda data: handle_message_create(self, data))
        self.get_ws().on('memberJoined', lambda data: handle_member_joined(self, data))
        self.get_ws().on('memberLeft', lambda data: handle_member_left(self, data))
        self.get_ws().on('userInvite', lambda data: handle_user_invite(self, data))

    async def login(self):
        self.logger.info('Starting login flow')
        await self.get_ws().connect()
        
        response = self.get_rest().get('/data')
        data = response.json()
        
        self.user._patch(data['me'])

        for raw_channel in data['userList']['channels']:
            manager = self.channels if raw_channel['group_id'] else self.guilds
            manager._add(raw_channel)

        self.emit('ready', {
            'user': self.user,
            'channels': self.channels,
            'guilds': self.guilds,
        })

        self.logger.info({
            'channels': self.channels.size,
            'guilds': self.guilds.size,
            'userId': self.user.id,
        }, 'Client ready')

    def channel(self, id: str) -> Channel:
        return self.channels.get(id)

    async def join_guild(self, guild_id: str):
        response = self.get_rest().post(f'/channels/join/{guild_id}')
        return response.json()

    async def accept_invite(self, from_user: str):
        response = self.get_rest().post('/invite/accept', json={
            'from_user': from_user,
        })
        return response.json()