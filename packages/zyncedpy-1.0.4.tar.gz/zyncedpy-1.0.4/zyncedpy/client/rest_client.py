import requests
from typing import Optional, Dict, Any
from ..types import ClientLogger

class RestClient:
    def __init__(self, cookies: str, base_url: Optional[str] = None, logger: Optional[ClientLogger] = None):
        self.cookies = cookies
        self.base_url = base_url or 'https://zynced.app/api'
        self.logger = logger

        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'ZyncedPy/1.0',
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Cookie': self.cookies,
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        })

    def _log_request(self, method: str, url: str):
        if self.logger:
            self.logger.debug(f"REST request: {method} {url}")

    def _log_response(self, method: str, url: str, status: int):
        if self.logger:
            self.logger.debug(f"REST response: {method} {url} {status}")

    def _log_error(self, method: str, url: str, status: Optional[int], message: str):
        if self.logger:
            self.logger.error(f"REST request failed: {method} {url} {status} {message}")

    def get(self, endpoint: str, **kwargs):
        url = f"{self.base_url}{endpoint}"
        self._log_request('GET', url)
        try:
            response = self.session.get(url, **kwargs)
            self._log_response('GET', url, response.status_code)
            return response
        except Exception as e:
            self._log_error('GET', url, None, str(e))
            raise

    def post(self, endpoint: str, data=None, json=None, **kwargs):
        url = f"{self.base_url}{endpoint}"
        self._log_request('POST', url)
        try:
            response = self.session.post(url, data=data, json=json, **kwargs)
            self._log_response('POST', url, response.status_code)
            return response
        except Exception as e:
            self._log_error('POST', url, None, str(e))
            raise

    def put(self, endpoint: str, data=None, json=None, **kwargs):
        url = f"{self.base_url}{endpoint}"
        self._log_request('PUT', url)
        try:
            response = self.session.put(url, data=data, json=json, **kwargs)
            self._log_response('PUT', url, response.status_code)
            return response
        except Exception as e:
            self._log_error('PUT', url, None, str(e))
            raise

    def patch(self, endpoint: str, data=None, json=None, **kwargs):
        url = f"{self.base_url}{endpoint}"
        self._log_request('PATCH', url)
        try:
            response = self.session.patch(url, data=data, json=json, **kwargs)
            self._log_response('PATCH', url, response.status_code)
            return response
        except Exception as e:
            self._log_error('PATCH', url, None, str(e))
            raise

    def delete(self, endpoint: str, **kwargs):
        url = f"{self.base_url}{endpoint}"
        self._log_request('DELETE', url)
        try:
            response = self.session.delete(url, **kwargs)
            self._log_response('DELETE', url, response.status_code)
            return response
        except Exception as e:
            self._log_error('DELETE', url, None, str(e))
            raise