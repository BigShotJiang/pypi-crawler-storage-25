from typing import Dict, List, Callable, Any, Optional

class TypedEmitter:
    def __init__(self):
        self._listeners: Dict[str, List[Callable]] = {}

    def on(self, event: str, listener: Callable) -> 'TypedEmitter':
        if event not in self._listeners:
            self._listeners[event] = []
        self._listeners[event].append(listener)
        return self

    def once(self, event: str, listener: Callable) -> 'TypedEmitter':
        def wrapper(*args, **kwargs):
            self.off(event, wrapper)
            listener(*args, **kwargs)

        self.on(event, wrapper)
        return self

    def emit(self, event: str, *args, **kwargs) -> bool:
        if event in self._listeners:
            for listener in self._listeners[event]:
                try:
                    listener(*args, **kwargs)
                except Exception as e:
                    print(f"Error in event listener for {event}: {e}")
            return True
        return False

    def off(self, event: str, listener: Callable) -> 'TypedEmitter':
        if event in self._listeners:
            try:
                self._listeners[event].remove(listener)
            except ValueError:
                pass
        return self

    def remove_all_listeners(self, event: Optional[str] = None) -> 'TypedEmitter':
        if event:
            self._listeners.pop(event, None)
        else:
            self._listeners.clear()
        return self