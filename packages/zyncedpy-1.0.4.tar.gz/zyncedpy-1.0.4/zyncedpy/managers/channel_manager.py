from typing import Optional
from .base_manager import BaseManager
from ..structures import Channel, RawChannel

class ChannelManager(BaseManager[Channel]):
    def _add(self, data: RawChannel) -> Channel:
        if self.has(data.id):
            return self.cache[data.id]

        channel = Channel(self.client, data)
        self.cache[channel.id] = channel
        return channel

    def find_one_by_name(self, name: str) -> Optional[Channel]:
        return self.find(lambda channel: channel.name == name)

    def find_all_by_name(self, name: str) -> list[Channel]:
        return self.filter(lambda channel: channel.name == name)