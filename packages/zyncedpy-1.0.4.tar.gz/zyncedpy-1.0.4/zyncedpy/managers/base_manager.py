from typing import Dict, Iterator, List, Optional, TypeVar, Generic, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import Client

T = TypeVar('T')

class BaseManager(Generic[T]):
    def __init__(self, client: 'Client'):
        self.cache: Dict[str, T] = {}
        self.client = client

    def resolve(self, id: str) -> Optional[T]:
        return self.cache.get(id)

    def get(self, id: str) -> T:
        entity = self.resolve(id)
        if entity is None:
            raise ValueError(f"Entity {id} not in cache")
        return entity

    def has(self, id: str) -> bool:
        return id in self.cache

    @property
    def size(self) -> int:
        return len(self.cache)

    def values(self) -> Iterator[T]:
        return iter(self.cache.values())

    def find(self, fn) -> Optional[T]:
        for entity in self.cache.values():
            if fn(entity):
                return entity
        return None

    def filter(self, fn) -> List[T]:
        return [entity for entity in self.cache.values() if fn(entity)]

    def _add(self, data) -> T:
        raise NotImplementedError