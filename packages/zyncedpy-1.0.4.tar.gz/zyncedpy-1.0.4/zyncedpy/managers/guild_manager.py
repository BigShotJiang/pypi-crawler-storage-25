from .base_manager import BaseManager
from ..structures import Guild, RawChannel

class GuildManager(BaseManager[Guild]):
    def _add(self, data: RawChannel) -> Guild:
        if self.has(data.id):
            return self.cache[data.id]

        guild = Guild(self.client, data)
        self.cache[guild.id] = guild
        return guild