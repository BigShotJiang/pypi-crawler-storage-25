from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import Client

class PrivateMessage:
    def __init__(self, client: 'Client', data: dict):
        self._client = client

        self.chatmode = data['message']['chatmode']
        self.content = data['message']['text']
        self.author = data['from']
        self.date = datetime.fromisoformat(data['message']['timestamp'].replace('Z', '+00:00'))