from .base_channel import BaseChannel

class Guild(BaseChannel):
    async def leave(self, id: str):
        res = await self.client.get_rest().post(f'/channels/leave/{id}')
        return res.json()