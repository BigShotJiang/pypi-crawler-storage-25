from typing import Optional, TYPE_CHECKING
from dataclasses import dataclass
from .base import Base

if TYPE_CHECKING:
    from ..client import Client

@dataclass
class RawChannel:
    id: str
    name: str
    description: str
    group_id: Optional[str]
    category_id: Optional[str]
    position: Optional[int]
    relative_to_category: Optional[str]
    created_at: str
    blocked: bool
    avatar: str
    accept_joins: bool
    type: str  # 'text' | 'voice'
    owner: str
    user_joined_at: str
    lastMessageAt: int

class BaseChannel(Base):
    def __init__(self, client: 'Client', data: RawChannel):
        super().__init__(client)

        self.id = data.id
        self.name = data.name
        self.group_id = data.group_id
        self.description = data.description
        self.category_id = data.category_id
        self.position = data.position
        self.relative_to_category = data.relative_to_category
        self.created_at = data.created_at
        self.blocked = data.blocked
        self.avatar = data.avatar
        self.accept_joins = data.accept_joins
        self.type = data.type
        self.owner = data.owner
        self.user_joined_at = data.user_joined_at
        self.last_message_at = data.lastMessageAt