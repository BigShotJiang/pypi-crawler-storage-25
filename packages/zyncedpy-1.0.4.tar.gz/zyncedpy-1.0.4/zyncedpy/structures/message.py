from datetime import datetime
from typing import Optional, List, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import Client
    from ..types import MessageAttachment

class Message:
    def __init__(self, client: 'Client', data: dict):
        self._client = client

        channel = self._client.channel(data['channelId'])
        self.id = channel._add_message(self)
        self.guild_id = data.get('groupId')
        self.channel_id = data['channelId']
        self.content = data['message']['text']
        self.author = data['message']['from']
        self.date = datetime.fromisoformat(data['message']['date'].replace('Z', '+00:00'))
        self.is_reply = bool(data['message'].get('reply_to_index'))

    def reply(self, content: str, attachments: Optional[List] = None):
        if attachments is None:
            attachments = []
        channel = self._client.channel(self.channel_id)
        if channel:
            channel.reply(content, attachments, self.id, self.author, self.content)