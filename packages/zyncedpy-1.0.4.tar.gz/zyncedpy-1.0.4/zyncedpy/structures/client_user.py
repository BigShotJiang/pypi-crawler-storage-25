from typing import Optional, TYPE_CHECKING
from dataclasses import dataclass
from .base import Base

if TYPE_CHECKING:
    from ..client import Client

@dataclass
class RawClientUser:
    userId: str
    username: str
    avatar: str
    status: str
    bannerUrl: str
    onlineStatus: str
    isPremium: bool

class ClientUser(Base):
    def __init__(self, client: 'Client', data: Optional[RawClientUser] = None):
        super().__init__(client)
        self.id = data.userId if data else ''
        self.username = data.username if data else ''
        self.avatar = data.avatar if data else ''
        self.status = data.status if data else ''
        self.banner_url = data.bannerUrl if data else ''
        self.online_status = data.onlineStatus if data else ''
        self.is_premium = data.isPremium if data else False

    def _patch(self, data: dict):
        if 'userId' in data:
            self.id = data['userId']
        if 'username' in data:
            self.username = data['username']
        if 'avatar' in data:
            self.avatar = data['avatar']
        if 'status' in data:
            self.status = data['status']
        if 'bannerUrl' in data:
            self.banner_url = data['bannerUrl']
        if 'onlineStatus' in data:
            self.online_status = data['onlineStatus']
        if 'isPremium' in data:
            self.is_premium = data['isPremium']
        return self

    async def set_status(self, status: str):
        await self.client.get_ws().send('updateProfileStatus', {'status': status})
        self.status = status

    def __str__(self):
        return f"{self.username}#{self.id}"