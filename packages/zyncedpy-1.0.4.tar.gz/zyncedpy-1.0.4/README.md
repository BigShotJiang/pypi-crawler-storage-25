# ZyncedPy

ZyncedPy is a Python module that allows you to create bots for Zynced chat platform.

## Installation

```bash
pip install zyncedpy
```

## Usage

```python
from zyncedpy import Client

client = Client('cf_clearance=...;connect.sid=...;')

@client.on("ready")
def on_ready(data):
    print(f"Bot is ready! Logged in as {data['user'].username}")

@client.on("messageCreate")
def on_message(message):
    if message.content == "!ping":
        message.reply("Pong!")

client.login()
```

## Features

- WebSocket and REST API support
- Event-driven architecture
- Channel and guild management
- Message handling
- User management
- Invite system

## License

MIT