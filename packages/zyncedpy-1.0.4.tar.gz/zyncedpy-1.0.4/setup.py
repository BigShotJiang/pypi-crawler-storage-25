from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="zyncedpy",
    version="1.0.4",
    author="Emanuel Scura",
    description="ZyncedPy is a Python module that allows you to create bots for Zynced chat platform.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Emsa001/zyncedpy",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
        "python-socketio>=5.0.0",
        "python-engineio>=4.0.0",
        "dataclasses-json>=0.5.0",
    ],
    keywords=["sdk", "bot", "websocket", "api", "chat", "zynced"],
    license="MIT",
)