use std::io::Seek;
use std::sync::Arc;

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyDict;
use pyo3::IntoPyObjectExt;
use pyo3_arrow::PyRecordBatchReader;
use pyo3_arrow::PySchema;

use crate::error::{err_on_unwind, to_py};
use crate::util::{pyobject_to_bufreader, resolve_coord_system, resolve_fields, Reader};
use bigtools::bed::autosql::parse::parse_autosql;
use oxbow::bbi::model::base::field::FieldDef;
use oxbow::bbi::{BBIReader, BBIZoomScanner, BedSchema, BigBedScanner, BigWigScanner};
use oxbow::util::batches_to_ipc;
use oxbow::CoordSystem;

#[pyclass(eq, eq_int, from_py_object, module = "oxbow.oxbow")]
#[derive(Clone, PartialEq)]
pub enum PyBBIFileType {
    BigWig,
    BigBed,
}

/// A BigWig file scanner.
///
/// Parameters
/// ----------
/// src : str or file-like
///     The path to the BigWig file or a file-like object.
/// fields : list[str], optional
///     Names of the fields to include in the schema.
/// coords : Literal["01", "11"], optional [default: "01"]
///    Coordinate system for returning positions and interpreting query ranges.
///    "01" for 0-based half-open, "11" for 1-based closed.
#[pyclass(module = "oxbow.oxbow")]
pub struct PyBigWigScanner {
    _src: Py<PyAny>,
    reader: Reader,
    scanner: BigWigScanner,
}

#[pymethods]
impl PyBigWigScanner {
    #[new]
    #[pyo3(signature = (src, fields=None, coords=None))]
    fn new(
        py: Python,
        src: Py<PyAny>,
        fields: Option<Py<PyAny>>,
        coords: Option<String>,
    ) -> PyResult<Self> {
        let coord_system = resolve_coord_system(coords)?;
        let reader = pyobject_to_bufreader(py, src.clone_ref(py), false)?;
        let fmt_reader = bigtools::BigWigRead::open(reader).unwrap();
        let info = fmt_reader.info().clone();
        let reader = fmt_reader.into_inner();
        let scanner = BigWigScanner::new(
            info,
            resolve_fields(fields, py)?,
            coord_system.unwrap_or(CoordSystem::ZeroHalfOpen),
        )
        .map_err(to_py)?;
        Ok(Self {
            _src: src,
            reader,
            scanner,
        })
    }

    fn __getstate__(&self, py: Python) -> PyResult<Py<PyAny>> {
        Ok(py.None())
    }

    fn __getnewargs_ex__(&self, py: Python) -> PyResult<(Py<PyAny>, Py<PyAny>)> {
        let args = (self._src.clone_ref(py),);
        let kwargs = PyDict::new(py);
        kwargs.set_item("fields", self.scanner.model().field_names())?;
        kwargs.set_item("coords", self.scanner.model().coord_system().to_string())?;
        Ok((args.into_py_any(py)?, kwargs.into_py_any(py)?))
    }

    /// Return the names of the reference sequences.
    fn chrom_names(&self) -> Vec<String> {
        self.scanner.chrom_names()
    }

    /// Return the names of the reference sequences and their lengths in bp.
    fn chrom_sizes(&self) -> Vec<(String, u32)> {
        self.scanner.chrom_sizes()
    }

    /// Return the names of the fields.
    fn field_names(&self) -> Vec<String> {
        self.scanner.field_names()
    }

    /// Return the zoom/reduction level resolutions.
    fn zoom_levels(&self) -> Vec<u32> {
        self.scanner.zoom_levels()
    }

    /// Return a scanner for a specific zoom level.
    ///
    /// Parameters
    /// ---------
    /// zoom_level : int
    ///     The resolution (in bp) of the zoom level to scan.
    /// fields : list[str], optional
    ///     Names of the fields to include in the zoom schema.
    ///
    /// Returns
    /// -------
    /// PyBBIZoomScanner
    ///     A scanner for the specified zoom level.
    #[pyo3(signature = (zoom_level, fields=None))]
    fn get_zoom(
        &mut self,
        zoom_level: u32,
        fields: Option<Py<PyAny>>,
    ) -> PyResult<PyBBIZoomScanner> {
        Python::attach(|py| {
            PyBBIZoomScanner::new(
                py,
                self._src.clone_ref(py),
                PyBBIFileType::BigWig,
                zoom_level,
                fields,
                Some(self.scanner.model().coord_system().to_string()),
            )
        })
    }

    /// Return the Arrow schema.
    ///
    /// Returns
    /// -------
    /// arro3 Schema (pycapsule)
    fn schema(&self) -> PySchema {
        PySchema::new(Arc::new(self.scanner.schema().clone()))
    }

    /// Scan batches of records from the file.
    ///
    /// Parameters
    /// ----------
    /// columns : list[str], optional
    ///     Names of the columns to project.
    /// batch_size : int, optional [default: 1024]
    ///     The number of records to include in each batch.
    /// limit : int, optional
    ///     The maximum number of records to scan. If None, records are scanned
    ///     until EOF.
    ///
    /// Returns
    /// -------
    /// arro3 RecordBatchReader (pycapsule)
    ///     An iterator yielding Arrow record batches.
    #[pyo3(signature = (columns=None, batch_size=1024, limit=None))]
    fn scan(
        &mut self,
        columns: Option<Vec<String>>,
        batch_size: Option<usize>,
        limit: Option<usize>,
    ) -> PyResult<PyRecordBatchReader> {
        let reader = self.reader.clone();
        let info = self.scanner.info().clone();
        let fmt_reader = bigtools::BigWigRead::with_info(info, reader);
        let batch_reader = self
            .scanner
            .scan(fmt_reader, columns, batch_size, limit)
            .map_err(to_py)?;
        Ok(PyRecordBatchReader::new(err_on_unwind(batch_reader)))
    }

    /// Scan batches of records from a genomic range query.
    ///
    /// Parameters
    /// ----------
    /// region : str
    ///     Genomic range string in the format "chr:start-end",
    ///     "chr:[start,end]" or "chr:[start,end)".
    /// columns : list[str], optional
    ///     Names of the columns to project.
    /// batch_size : int, optional [default: 1024]
    ///     The number of records to include in each batch.
    /// limit : int, optional
    ///     The maximum number of records to scan. If None, all records
    ///     intersecting the query range are scanned.
    ///
    /// Returns
    /// -------
    /// arro3 RecordBatchReader (pycapsule)
    ///     An iterator yielding Arrow record batches.
    #[pyo3(signature = (region, columns=None, batch_size=1024, limit=None))]
    fn scan_query(
        &mut self,
        region: String,
        columns: Option<Vec<String>>,
        batch_size: Option<usize>,
        limit: Option<usize>,
    ) -> PyResult<PyRecordBatchReader> {
        let region =
            oxbow::Region::parse(&region, self.scanner.model().coord_system()).map_err(to_py)?;

        let reader = self.reader.clone();
        let info = self.scanner.info().clone();
        let fmt_reader = bigtools::BigWigRead::with_info(info, reader);
        let batch_reader = self
            .scanner
            .scan_query(fmt_reader, region, columns, batch_size, limit)
            .map_err(to_py)?;
        Ok(PyRecordBatchReader::new(err_on_unwind(batch_reader)))
    }
}

/// A BigBed file scanner.
///
/// Parameters
/// ----------
/// src : str or file-like
///     The path to the BigBed file or a file-like object.
/// schema : str, optional
///     The BED schema to use for parsing BigBed records. May be a
///     ``bed[m[+[n]]]`` string, ``"bedgraph"``, or ``"autosql"``. If not
///     specified, the BigBed is interpreted as BED3+, where all ancillary
///     fields are returned as a single lumped string field named "rest".
///     If "autosql", the file's AutoSql definition is used to parse the
///     records, if it exists.
/// fields : list[str], optional
///     Names of the fields to include in the schema.
/// coords : Literal["01", "11"], optional [default: "01"]
///    Coordinate system for returning positions and interpreting query ranges.
///    "01" for 0-based half-open, "11" for 1-based closed.
#[pyclass(module = "oxbow.oxbow")]
pub struct PyBigBedScanner {
    _src: Py<PyAny>,
    _schema: Option<String>,
    reader: Reader,
    scanner: BigBedScanner,
}

#[pymethods]
impl PyBigBedScanner {
    #[new]
    #[pyo3(signature = (src, schema=None, fields=None, coords=None))]
    fn new(
        py: Python,
        src: Py<PyAny>,
        schema: Option<Py<PyAny>>,
        fields: Option<Py<PyAny>>,
        coords: Option<String>,
    ) -> PyResult<Self> {
        let coord_system = resolve_coord_system(coords)?;
        let reader = pyobject_to_bufreader(py, src.clone_ref(py), false)?;
        let mut fmt_reader = bigtools::BigBedRead::open(reader).unwrap();
        let bed_schema = match &schema {
            Some(obj) => {
                // Check for "autosql" special string
                if let Ok(s) = obj.extract::<String>(py) {
                    if s == "autosql" {
                        let autosql_str = fmt_reader.autosql().unwrap().unwrap();
                        let mut declarations = parse_autosql(&autosql_str).unwrap();
                        if declarations.len() > 1 {
                            return Err(PyErr::new::<PyValueError, _>(
                                "Autosql schema must contain exactly one declaration.",
                            ));
                        }
                        let declaration = declarations.pop().unwrap();
                        let field_defs: Vec<_> = declaration
                            .fields
                            .iter()
                            .skip(3)
                            .map(FieldDef::try_from)
                            .collect::<Result<_, _>>()?;
                        BedSchema::new(3, Some(field_defs)).map_err(to_py)?
                    } else {
                        crate::bed::resolve_bed_schema(py, obj)?
                    }
                } else {
                    crate::bed::resolve_bed_schema(py, obj)?
                }
            }
            None => BedSchema::new_from_nm(3, None).map_err(to_py)?,
        };
        let info = fmt_reader.info().clone();
        let reader = fmt_reader.into_inner();
        let scanner = BigBedScanner::new(
            bed_schema,
            info,
            resolve_fields(fields, py)?,
            coord_system.unwrap_or(CoordSystem::ZeroHalfOpen),
        )
        .map_err(to_py)?;
        let _schema: Option<String> = schema.as_ref().and_then(|s| s.extract::<String>(py).ok());
        Ok(Self {
            _src: src,
            _schema,
            reader,
            scanner,
        })
    }

    fn __getstate__(&self, py: Python) -> PyResult<Py<PyAny>> {
        Ok(py.None())
    }

    fn __getnewargs_ex__(&self, py: Python) -> PyResult<(Py<PyAny>, Py<PyAny>)> {
        let args = (
            self._src.clone_ref(py),
            self._schema.clone().into_py_any(py)?,
        );
        let kwargs = PyDict::new(py);
        kwargs.set_item("fields", self.scanner.model().field_names())?;
        kwargs.set_item("coords", self.scanner.model().coord_system().to_string())?;
        Ok((args.into_py_any(py)?, kwargs.into_py_any(py)?))
    }

    /// Return the names of the reference sequences.
    fn chrom_names(&self) -> Vec<String> {
        self.scanner.chrom_names()
    }

    /// Return the names of the reference sequences and their lengths in bp.
    fn chrom_sizes(&self) -> Vec<(String, u32)> {
        self.scanner.chrom_sizes()
    }

    /// Return the names of the fields.
    fn field_names(&self) -> Vec<String> {
        self.scanner.field_names()
    }

    /// Return the raw autosql schema definition.
    ///
    /// Returns
    /// -------
    /// str
    fn read_autosql(&mut self) -> PyResult<String> {
        self.reader.seek(std::io::SeekFrom::Start(0)).unwrap();
        let reader = self.reader.clone();
        let mut fmt_reader = bigtools::BigBedRead::open(reader).unwrap();
        let autosql_str = fmt_reader.autosql().unwrap().unwrap();
        Ok(autosql_str)
    }

    /// Return the zoom/reduction level resolutions.
    fn zoom_levels(&self) -> Vec<u32> {
        self.scanner.zoom_levels()
    }

    /// Return a scanner for a specific zoom level.
    ///
    /// Parameters
    /// ---------
    /// zoom_level : int
    ///     The resolution (in bp) of the zoom level to scan.
    /// fields : list[str], optional
    ///     Names of the fields to include in the zoom schema.
    ///
    /// Returns
    /// -------
    /// PyBBIZoomScanner
    ///     A scanner for the specified zoom level.
    #[pyo3(signature = (zoom_level, fields=None))]
    fn get_zoom(
        &mut self,
        zoom_level: u32,
        fields: Option<Py<PyAny>>,
    ) -> PyResult<PyBBIZoomScanner> {
        Python::attach(|py| {
            PyBBIZoomScanner::new(
                py,
                self._src.clone_ref(py),
                PyBBIFileType::BigBed,
                zoom_level,
                fields,
                Some(self.scanner.model().coord_system().to_string()),
            )
        })
    }

    /// Return the Arrow schema.
    ///
    /// Returns
    /// -------
    /// arro3 Schema (pycapsule)
    fn schema(&self) -> PySchema {
        PySchema::new(Arc::new(self.scanner.schema().clone()))
    }

    /// Scan batches of records from the file's base-level records.
    ///
    /// Parameters
    /// ----------
    /// columns : list[str], optional
    ///     Names of the columns to project.
    /// batch_size : int, optional [default: 1024]
    ///     The number of records to include in each batch.
    /// limit : int, optional
    ///     The maximum number of records to scan. If None, records are scanned
    ///     until EOF.
    ///
    /// Returns
    /// -------
    /// arro3 RecordBatchReader (pycapsule)
    ///     An iterator yielding Arrow record batches.
    #[pyo3(signature = (columns=None, batch_size=1024, limit=None))]
    fn scan(
        &mut self,
        columns: Option<Vec<String>>,
        batch_size: Option<usize>,
        limit: Option<usize>,
    ) -> PyResult<PyRecordBatchReader> {
        let reader = self.reader.clone();
        let info = self.scanner.info().clone();
        let fmt_reader = bigtools::BigBedRead::with_info(info, reader);
        let batch_reader = self
            .scanner
            .scan(fmt_reader, columns, batch_size, limit)
            .map_err(to_py)?;
        Ok(PyRecordBatchReader::new(err_on_unwind(batch_reader)))
    }

    /// Scan batches of records from a genomic range query.
    ///
    /// Parameters
    /// ----------
    /// region : str
    ///     Genomic range string in the format "chr:start-end",
    ///     "chr:[start,end]" or "chr:[start,end)".
    /// columns : list[str], optional
    ///     Names of the columns to project.
    /// batch_size : int, optional [default: 1024]
    ///     The number of records to include in each batch.
    /// limit : int, optional
    ///     The maximum number of records to scan. If None, all records
    ///     intersecting the query range are scanned.
    ///
    /// Returns
    /// -------
    /// arro3 RecordBatchReader (pycapsule)
    ///     An iterator yielding Arrow record batches.
    #[pyo3(signature = (region, columns=None, batch_size=1024, limit=None))]
    fn scan_query(
        &mut self,
        region: String,
        columns: Option<Vec<String>>,
        batch_size: Option<usize>,
        limit: Option<usize>,
    ) -> PyResult<PyRecordBatchReader> {
        let region =
            oxbow::Region::parse(&region, self.scanner.model().coord_system()).map_err(to_py)?;

        let reader = self.reader.clone();
        let info = self.scanner.info().clone();
        let fmt_reader = bigtools::BigBedRead::with_info(info, reader);
        let batch_reader = self
            .scanner
            .scan_query(fmt_reader, region, columns, batch_size, limit)
            .map_err(to_py)?;
        Ok(PyRecordBatchReader::new(err_on_unwind(batch_reader)))
    }
}

/// A BBI file zoom level scanner.
///
/// Can only be initialized from a BigBed or BigWig scanner.
///
/// Parameters
/// ----------
/// src : str or file-like
///     The path to the BBI file or a file-like object.
/// bbi_type : PyBBIFileType
///     The type of BBI file (BigWig or BigBed).
/// zoom_level : int
///     The zoom level resolution in bp.
/// fields : list[str], optional
///     Names of the fields to include in the schema.
/// coords : Literal["01", "11"], optional [default: "01"]
///    Coordinate system for returning positions and interpreting query ranges.
///    "01" for 0-based half-open, "11" for 1-based closed.
#[pyclass(module = "oxbow.oxbow")]
pub struct PyBBIZoomScanner {
    src: Py<PyAny>,
    reader: Reader,
    bbi_type: PyBBIFileType,
    zoom_level: u32,
    scanner: BBIZoomScanner,
}

#[pymethods]
impl PyBBIZoomScanner {
    #[new]
    #[pyo3(signature = (src, bbi_type, zoom_level, fields=None, coords=None))]
    pub fn new(
        py: Python,
        src: Py<PyAny>,
        bbi_type: PyBBIFileType,
        zoom_level: u32,
        fields: Option<Py<PyAny>>,
        coords: Option<String>,
    ) -> PyResult<Self> {
        let coord_system = resolve_coord_system(coords)?;
        let reader = pyobject_to_bufreader(py, src.clone_ref(py), false)
            .expect("Failed to convert Py<PyAny> to BufReader");
        match bbi_type {
            PyBBIFileType::BigBed => {
                let fmt_reader = bigtools::BigBedRead::open(reader).unwrap();
                let ref_names = fmt_reader
                    .chroms()
                    .iter()
                    .map(|info| info.name.to_string())
                    .collect();
                let zoom_levels: Vec<u32> = fmt_reader
                    .info()
                    .zoom_headers
                    .iter()
                    .map(|header| header.reduction_level)
                    .collect();
                if !zoom_levels.contains(&zoom_level) {
                    return Err(PyErr::new::<PyValueError, _>(format!(
                        "Zoom resolution {} not found in BBI file. Available reduction levels: {:?}.",
                        zoom_level, zoom_levels
                    )));
                }
                let reader = fmt_reader.into_inner();
                let scanner = BBIZoomScanner::new(
                    ref_names,
                    zoom_level,
                    resolve_fields(fields, py)?,
                    coord_system.unwrap_or(CoordSystem::ZeroHalfOpen),
                )
                .map_err(to_py)?;
                Ok(Self {
                    src,
                    reader,
                    bbi_type,
                    zoom_level,
                    scanner,
                })
            }
            PyBBIFileType::BigWig => {
                let fmt_reader = bigtools::BigWigRead::open(reader).unwrap();
                let ref_names = fmt_reader
                    .chroms()
                    .iter()
                    .map(|info| info.name.to_string())
                    .collect();
                let zoom_levels: Vec<u32> = fmt_reader
                    .info()
                    .zoom_headers
                    .iter()
                    .map(|header| header.reduction_level)
                    .collect();
                if !zoom_levels.contains(&zoom_level) {
                    return Err(PyErr::new::<PyValueError, _>(format!(
                        "Zoom resolution {} not found in BBI file. Available reduction levels: {:?}.",
                        zoom_level, zoom_levels
                    )));
                }
                let reader = fmt_reader.into_inner();
                let scanner = BBIZoomScanner::new(
                    ref_names,
                    zoom_level,
                    resolve_fields(fields, py)?,
                    coord_system.unwrap_or(CoordSystem::ZeroHalfOpen),
                )
                .map_err(to_py)?;
                Ok(Self {
                    src,
                    reader,
                    bbi_type,
                    zoom_level,
                    scanner,
                })
            }
        }
    }

    fn __getstate__(&self, py: Python) -> PyResult<Py<PyAny>> {
        Ok(py.None())
    }

    fn __getnewargs_ex__(&self, py: Python) -> PyResult<(Py<PyAny>, Py<PyAny>)> {
        let args = (
            self.src.clone_ref(py),
            self.bbi_type.clone().into_py_any(py)?,
            self.zoom_level.into_py_any(py)?,
        );
        let kwargs = PyDict::new(py);
        kwargs.set_item("fields", self.scanner.field_names())?;
        kwargs.set_item("coords", self.scanner.model().coord_system().to_string())?;
        Ok((args.into_py_any(py)?, kwargs.into_py_any(py)?))
    }

    /// Return the names of the reference sequences.
    fn field_names(&self) -> Vec<String> {
        self.scanner.field_names()
    }

    /// Return the Arrow schema.
    ///
    /// Returns
    /// -------
    /// arro3 Schema (pycapsule)
    fn schema(&self) -> PySchema {
        PySchema::new(Arc::new(self.scanner.schema().clone()))
    }

    /// Scan batches of records from the zoom level.
    ///
    /// Parameters
    /// ----------
    /// columns : list[str], optional
    ///     Names of the columns to project.
    /// batch_size : int, optional [default: 1024]
    ///     The number of records to include in each batch.
    /// limit : int, optional
    ///     The maximum number of records to scan. If None, records are scanned
    ///     until EOF.
    ///
    /// Returns
    /// -------
    /// arro3 RecordBatchReader (pycapsule)
    ///     An iterator yielding Arrow record batches.
    #[pyo3(signature = (columns=None, batch_size=1024, limit=None))]
    fn scan(
        &mut self,
        columns: Option<Vec<String>>,
        batch_size: Option<usize>,
        limit: Option<usize>,
    ) -> PyResult<PyRecordBatchReader> {
        self.reader.seek(std::io::SeekFrom::Start(0)).unwrap();
        let reader = self.reader.clone();
        match self.bbi_type {
            PyBBIFileType::BigBed => {
                let fmt_reader = bigtools::BigBedRead::open(reader).unwrap();
                let reader = BBIReader::BigBed(fmt_reader);
                let batch_reader = self
                    .scanner
                    .scan(reader, columns, batch_size, limit)
                    .map_err(to_py)?;
                Ok(PyRecordBatchReader::new(err_on_unwind(batch_reader)))
            }
            PyBBIFileType::BigWig => {
                let fmt_reader = bigtools::BigWigRead::open(reader).unwrap();
                let reader = BBIReader::BigWig(fmt_reader);
                let batch_reader = self
                    .scanner
                    .scan(reader, columns, batch_size, limit)
                    .map_err(to_py)?;
                Ok(PyRecordBatchReader::new(err_on_unwind(batch_reader)))
            }
        }
    }

    /// Scan batches of records from a genomic range query.
    ///
    /// Parameters
    /// ----------
    /// region : str
    ///     Genomic range string in the format "chr:start-end",
    ///     "chr:[start,end]" or "chr:[start,end)".
    /// columns : list[str], optional
    ///     Names of the columns to project.
    /// batch_size : int, optional [default: 1024]
    ///     The number of records to include in each batch.
    /// limit : int, optional
    ///     The maximum number of records to scan. If None, all records
    ///     intersecting the query range are scanned.
    ///
    /// Returns
    /// -------
    /// arro3 RecordBatchReader (pycapsule)
    ///     An iterator yielding Arrow record batches.
    #[pyo3(signature = (region, columns=None, batch_size=1024, limit=None))]
    fn scan_query(
        &mut self,
        region: String,
        columns: Option<Vec<String>>,
        batch_size: Option<usize>,
        limit: Option<usize>,
    ) -> PyResult<PyRecordBatchReader> {
        let region =
            oxbow::Region::parse(&region, self.scanner.model().coord_system()).map_err(to_py)?;

        self.reader.seek(std::io::SeekFrom::Start(0)).unwrap();
        let reader = self.reader.clone();
        match self.bbi_type {
            PyBBIFileType::BigBed => {
                let fmt_reader = bigtools::BigBedRead::open(reader).unwrap();
                let reader = BBIReader::BigBed(fmt_reader);
                let batch_reader = self
                    .scanner
                    .scan_query(reader, region, columns, batch_size, limit)
                    .map_err(to_py)?;
                Ok(PyRecordBatchReader::new(err_on_unwind(batch_reader)))
            }
            PyBBIFileType::BigWig => {
                let fmt_reader = bigtools::BigWigRead::open(reader).unwrap();
                let reader = BBIReader::BigWig(fmt_reader);
                let batch_reader = self
                    .scanner
                    .scan_query(reader, region, columns, batch_size, limit)
                    .map_err(to_py)?;
                Ok(PyRecordBatchReader::new(err_on_unwind(batch_reader)))
            }
        }
    }
}

/// Return Arrow IPC format from a BigWig file.
///
/// Parameters
/// ----------
/// src : str or file-like
///     The path to the source file or a file-like object.
/// region : str
///     Genomic range string in the format "chr:start-end",
///     "chr:[start,end]" or "chr:[start,end)".
/// fields : list[str], optional
///     Names of the fixed fields to project.
///
/// Returns
/// -------
/// bytes
///     Arrow IPC
#[pyfunction]
#[pyo3(signature = (src, region=None, fields=None))]
pub fn read_bigwig(
    py: Python,
    src: Py<PyAny>,
    region: Option<String>,
    fields: Option<Py<PyAny>>,
) -> PyResult<Vec<u8>> {
    let reader = pyobject_to_bufreader(py, src.clone_ref(py), false)?;

    let ipc = if let Some(region) = region {
        let region =
            oxbow::Region::parse(&region, oxbow::CoordSystem::ZeroHalfOpen).map_err(to_py)?;

        let fmt_reader = bigtools::BigWigRead::open(reader)
            .map_err(|e| PyErr::new::<PyValueError, _>(e.to_string()))?;
        let info = fmt_reader.info().clone();
        let scanner =
            BigWigScanner::new(info, resolve_fields(fields, py)?, CoordSystem::ZeroHalfOpen)
                .map_err(to_py)?;
        let batches = scanner
            .scan_query(fmt_reader, region, None, None, None)
            .map_err(to_py)?;
        batches_to_ipc(batches)
    } else {
        let fmt_reader = bigtools::BigWigRead::open(reader)
            .map_err(|e| PyErr::new::<PyValueError, _>(e.to_string()))?;
        let info = fmt_reader.info().clone();
        let scanner =
            BigWigScanner::new(info, resolve_fields(fields, py)?, CoordSystem::ZeroHalfOpen)
                .map_err(to_py)?;
        let batches = scanner.scan(fmt_reader, None, None, None).map_err(to_py)?;
        batches_to_ipc(batches)
    };

    ipc.map_err(|e| PyErr::new::<PyValueError, _>(e.to_string()))
}

/// Return Arrow IPC format from a BigBed file.
///
/// Parameters
/// ----------
/// src : str or file-like
///     The path to the source file or a file-like object.
/// bed_schema : str
///     The BED schema to use for parsing BigBed records.
/// region : str
///     Genomic range string in the format "chr:start-end",
///     "chr:[start,end]" or "chr:[start,end)".
/// fields : list[str], optional
///     Names of the fixed fields to project.
///
/// Returns
/// -------
/// bytes
///     Arrow IPC
#[pyfunction]
#[pyo3(signature = (src, bed_schema="bed3+", region=None, fields=None))]
pub fn read_bigbed(
    py: Python,
    src: Py<PyAny>,
    bed_schema: &str,
    region: Option<String>,
    fields: Option<Py<PyAny>>,
) -> PyResult<Vec<u8>> {
    let bed_schema: BedSchema = bed_schema.parse().map_err(to_py)?;
    let reader = pyobject_to_bufreader(py, src.clone_ref(py), false)?;

    let ipc = if let Some(region) = region {
        let region =
            oxbow::Region::parse(&region, oxbow::CoordSystem::ZeroHalfOpen).map_err(to_py)?;

        let fmt_reader = bigtools::BigBedRead::open(reader)
            .map_err(|e| PyErr::new::<PyValueError, _>(e.to_string()))?;
        let info = fmt_reader.info().clone();
        let scanner = BigBedScanner::new(
            bed_schema,
            info,
            resolve_fields(fields, py)?,
            CoordSystem::ZeroHalfOpen,
        )
        .map_err(to_py)?;
        let batches = scanner
            .scan_query(fmt_reader, region, None, None, None)
            .map_err(to_py)?;
        batches_to_ipc(batches)
    } else {
        let fmt_reader = bigtools::BigBedRead::open(reader)
            .map_err(|e| PyErr::new::<PyValueError, _>(e.to_string()))?;
        let info = fmt_reader.info().clone();
        let scanner = BigBedScanner::new(
            bed_schema,
            info,
            resolve_fields(fields, py)?,
            CoordSystem::ZeroHalfOpen,
        )
        .map_err(to_py)?;
        let batches = scanner.scan(fmt_reader, None, None, None).map_err(to_py)?;
        batches_to_ipc(batches)
    };

    ipc.map_err(|e| PyErr::new::<PyValueError, _>(e.to_string()))
}
