"""
LangChain auto-instrumentation
===============================

Customer plugs `DobbyCallbackHandler` into LangChain's callback system and
every LLM call / tool invocation / chain step / agent action emits a Dobby
`SdkEvent` automatically — no `@track` decorators needed.

Usage::

    from dobby_collector import init
    from dobby_collector.integrations.langchain import DobbyCallbackHandler

    init(api_key="dsdk_...", connector_id="wc_...")
    handler = DobbyCallbackHandler()

    # Option A — per-invoke (recommended):
    result = agent.invoke({"input": "..."}, config={"callbacks": [handler]})

    # Option B — global (set once, applies to everything):
    from langchain_core.callbacks.manager import BaseCallbackManager
    # ... configure manager with [handler] ...

Each `invoke()` becomes one Dobby workload_run. The handler maps LangChain's
`run_id` (UUID per chain/tool/llm call) to Dobby's `event_id`, and uses
`parent_run_id` to thread `parent_event_id` for nested spans.

If the top-level chain has `parent_run_id is None` AND no SDK run is active,
the handler auto-`start_run()`s a Dobby run and `end_run()`s on completion —
the customer doesn't have to manage run boundaries explicitly.

Install::

    pip install dobby-collector[langchain]

Lazy import: this module imports `langchain_core` at module load. If
`langchain_core` isn't installed, `from dobby_collector.integrations.langchain
import DobbyCallbackHandler` raises ImportError with a remediation message.
The base SDK `pip install dobby-collector` does NOT pull langchain transitively.
"""

from __future__ import annotations

import logging
import threading
from collections import OrderedDict
from time import time
from typing import Any, Optional, Union
from uuid import UUID

try:
    from langchain_core.callbacks.base import BaseCallbackHandler
except ImportError as e:
    raise ImportError(
        "DobbyCallbackHandler requires langchain-core. Install with: "
        "`pip install dobby-collector[langchain]`"
    ) from e

from .._api import _emit, end_run, start_run
from .._config import get_collector
from .._events import (
    AGENT_STEP,
    CHAIN_END,
    CHAIN_START,
    LLM_COMPLETION,
    LLM_START,
    TOOL_END,
    TOOL_START,
    SdkEvent,
    iso_now,
    new_event_id,
)

logger = logging.getLogger("dobby_collector.integrations.langchain")

# Bounded LRU of (langchain_run_id → dobby_event_id) so long-running
# processes don't leak memory. LangChain's run_id is a UUID per call;
# parent_run_id may reference a parent that already completed.
_DEFAULT_RUN_MAP_SIZE = 4096

# Bounded LRU of (langchain_top_level_run_id → dobby_RunHandle) for the
# auto-start_run / end_run path. Distinct from the event-id map because
# the RunHandle is the SDK's lifecycle token, not a wire-protocol field.
_DEFAULT_AUTO_RUN_MAP_SIZE = 256


def _coerce_uuid(value: Union[UUID, str, None]) -> Optional[str]:
    """LangChain passes UUIDs; convert to plain str for our lookups."""
    if value is None:
        return None
    return str(value)


def _truncate(value: Any, max_chars: int = 4000) -> Any:
    """
    Coerce value to a JSON-serializable shape and truncate long strings.

    LangChain >= 1.0 surfaces message objects (HumanMessage / AIMessage /
    ToolMessage — Pydantic v2 models) in event data. The sender's JSON
    encoder rejects them and the batch is dropped silently — so any path
    that returns a non-(None/str/list/dict) value MUST coerce it first.

    Pydantic v2 models try `model_dump()` first; everything else falls back
    to `str(value)`. Mirror of `crewai.py:_truncate` fix from v0.4.2.
    """
    if value is None:
        return None
    if isinstance(value, str):
        return value if len(value) <= max_chars else value[:max_chars] + f"... [truncated {len(value) - max_chars} chars]"
    if isinstance(value, list):
        return [_truncate(v, max_chars) for v in value]
    if isinstance(value, dict):
        return {k: _truncate(v, max_chars) for k, v in value.items()}
    # Pydantic v2 model (HumanMessage / AIMessage / ToolMessage / etc.) —
    # serialise via .model_dump() then truncate.
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        try:
            return _truncate(model_dump(), max_chars)
        except Exception:  # noqa: BLE001 — fall through to repr below
            pass
    # Any other type — coerce to string (last-resort JSON safety net).
    s = str(value)
    return s if len(s) <= max_chars else s[:max_chars] + f"... [truncated {len(s) - max_chars} chars]"


class _BoundedDict(OrderedDict[str, Any]):
    """O(1) LRU with a hard cap. Evicts least-recently-used on overflow."""

    def __init__(self, max_size: int) -> None:
        super().__init__()
        self._max_size = max_size

    def __setitem__(self, key: str, value: Any) -> None:
        if key in self:
            self.move_to_end(key)
        super().__setitem__(key, value)
        if len(self) > self._max_size:
            self.popitem(last=False)

    def __getitem__(self, key: str) -> Any:
        value = super().__getitem__(key)
        self.move_to_end(key)
        return value

    def get_or_none(self, key: str) -> Any:
        if key in self:
            self.move_to_end(key)
            return self._dict_get(key)
        return None

    def _dict_get(self, key: str) -> Any:
        # Bypass __getitem__ to avoid double move_to_end work.
        return OrderedDict.__getitem__(self, key)


class DobbyCallbackHandler(BaseCallbackHandler):
    """
    LangChain callback handler that emits Dobby `SdkEvent`s for every
    callback LangChain fires.

    Thread-safe: LangChain may invoke callbacks from multiple threads when
    running parallel chains. All map mutations are guarded by an internal
    lock. Emission itself goes through the SDK's `_emit` which uses the
    buffer's internal lock.

    Construction is cheap — instantiate once per process and reuse, or pass
    a fresh instance to every `invoke()` if you prefer. Either works.

    Args:
        framework: Tag emitted on every event. Defaults to "langchain".
        auto_run: When True (default), auto-`start_run()` on the top-level
            chain.start (parent_run_id is None) and `end_run()` on its
            corresponding chain.end. Customers who manage runs themselves
            can set this to False.
        max_payload_chars: Per-field truncation cap for prompt / completion /
            tool args / tool outputs. Default 4000 — keeps a typical batch
            well under the 1MB webhook limit.
        run_map_size: Bounded LRU size for the LangChain-run-id → SDK-event-id
            mapping. Default 4096. Bump for very deep nesting / very long
            runs that span many concurrent sub-chains.
    """

    # Tell LangChain we want to receive all callbacks (default True, but
    # explicit is better — older LC versions check this attribute).
    raise_error: bool = False
    run_inline: bool = True
    ignore_llm: bool = False
    ignore_chain: bool = False
    ignore_agent: bool = False
    ignore_retriever: bool = True
    ignore_chat_model: bool = False
    ignore_custom_event: bool = True

    def __init__(
        self,
        *,
        framework: str = "langchain",
        auto_run: bool = True,
        max_payload_chars: int = 4000,
        run_map_size: int = _DEFAULT_RUN_MAP_SIZE,
        auto_run_map_size: int = _DEFAULT_AUTO_RUN_MAP_SIZE,
    ) -> None:
        super().__init__()
        self._framework = framework
        self._auto_run = auto_run
        self._max_payload_chars = max_payload_chars
        self._lock = threading.Lock()
        # LangChain run_id (UUID str) → Dobby event_id
        self._event_id_map: _BoundedDict = _BoundedDict(run_map_size)
        # LangChain top-level run_id → Dobby RunHandle (only when auto_run=True)
        self._auto_run_handles: _BoundedDict = _BoundedDict(auto_run_map_size)
        # Per-run-id start time (monotonic) so we can compute duration_ms on end.
        self._start_times: _BoundedDict = _BoundedDict(run_map_size)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _register_run(self, lc_run_id: str, event_id: str) -> None:
        with self._lock:
            self._event_id_map[lc_run_id] = event_id
            self._start_times[lc_run_id] = time()

    def _lookup_parent_event_id(self, lc_parent_run_id: Optional[str]) -> Optional[str]:
        if lc_parent_run_id is None:
            return None
        with self._lock:
            return self._event_id_map.get_or_none(lc_parent_run_id)

    def _resolve_run_id(self) -> str:
        """The active SDK run_id, or mint one if no run is active."""
        c = get_collector()
        if c is not None:
            rid = c.get_current_run()
            if rid is not None:
                return rid
        # Fallback: synthesize a run_id. The SDK's _emit handles the case
        # where no run is active gracefully.
        from .._events import new_run_id

        return new_run_id()

    def _duration_ms(self, lc_run_id: str) -> Optional[float]:
        with self._lock:
            started = self._start_times.get_or_none(lc_run_id)
        if started is None:
            return None
        return (time() - started) * 1000.0

    def _emit_event(
        self,
        *,
        event_type: str,
        lc_run_id: str,
        lc_parent_run_id: Optional[str],
        name: Optional[str] = None,
        status: Optional[str] = None,
        data: Optional[dict[str, Any]] = None,
        duration_ms: Optional[float] = None,
        is_end: bool = False,
    ) -> None:
        """
        Build + emit one SdkEvent. Translates LangChain run_id/parent_run_id
        into our event_id/parent_event_id, and records start times so paired
        end-events can compute duration.

        On `is_end=True`, the event reuses the START event's event_id as the
        parent_event_id (LangChain semantics: end shares run_id with start).
        That lets the server normalizer pair them.
        """
        # event_id is unique per event (start AND end each get one); but
        # the END event uses the START's id as parent_event_id, which is
        # how the server normalizer pairs (start, end) → ToolCallSummary /
        # LlmCallSummary etc.
        if is_end:
            parent_event_id = self._lookup_parent_event_id(lc_run_id)
            event_id = new_event_id()
        else:
            event_id = new_event_id()
            self._register_run(lc_run_id, event_id)
            parent_event_id = self._lookup_parent_event_id(lc_parent_run_id)

        event = SdkEvent(
            event_id=event_id,
            run_id=self._resolve_run_id(),
            timestamp=iso_now(),
            type=event_type,
            name=name,
            parent_event_id=parent_event_id,
            duration_ms=duration_ms,
            status=status,
            data=data,
            framework=self._framework,
        )
        try:
            _emit(event)
        except Exception:  # noqa: BLE001 — handler must NEVER raise
            logger.exception("DobbyCallbackHandler: _emit_event swallowed")

    def _maybe_auto_start_run(self, lc_run_id: str, name: str, inputs: Any) -> None:
        """If this is a top-level chain.start, optionally auto-`start_run()`."""
        if not self._auto_run:
            return
        c = get_collector()
        if c is None:
            return
        # If the customer already called start_run() manually, respect it.
        if c.get_current_run() is not None:
            return
        try:
            handle = start_run(
                name=name,
                inputs=_truncate(inputs, self._max_payload_chars),
            )
            with self._lock:
                self._auto_run_handles[lc_run_id] = handle
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler: auto start_run swallowed")

    def _maybe_auto_end_run(
        self,
        lc_run_id: str,
        outputs: Any,
        status: str = "success",
        error: Optional[str] = None,
    ) -> None:
        """If we auto-started a run for this top-level chain, close it now."""
        if not self._auto_run:
            return
        with self._lock:
            handle = self._auto_run_handles.get_or_none(lc_run_id)
            if handle is not None:
                # Remove FIRST so a second call (LangChain re-fires) is a no-op.
                del self._auto_run_handles[lc_run_id]
        if handle is None:
            return
        try:
            end_run(
                handle,
                outputs=_truncate(outputs, self._max_payload_chars),
                status=status,  # type: ignore[arg-type]
                error=error,
            )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler: auto end_run swallowed")

    # ------------------------------------------------------------------
    # LangChain callback overrides — all take **kwargs to forward-compat
    # ------------------------------------------------------------------

    # ----- Chain lifecycle -----

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            name = (serialized or {}).get("name") or (serialized or {}).get("id", [""])[-1] or "chain"

            # Top-level chain → auto-start a Dobby run if the customer hasn't.
            if lc_parent is None:
                self._maybe_auto_start_run(lc_run_id, name=name, inputs=inputs)

            self._emit_event(
                event_type=CHAIN_START,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                name=name,
                status="running",
                data={"inputs": _truncate(inputs, self._max_payload_chars)},
            )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_chain_start swallowed")

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            duration = self._duration_ms(lc_run_id)
            self._emit_event(
                event_type=CHAIN_END,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                status="success",
                duration_ms=duration,
                data={"outputs": _truncate(outputs, self._max_payload_chars)},
                is_end=True,
            )
            if lc_parent is None:
                self._maybe_auto_end_run(lc_run_id, outputs, status="success")
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_chain_end swallowed")

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            duration = self._duration_ms(lc_run_id)
            err_msg = f"{type(error).__name__}: {error}"
            self._emit_event(
                event_type=CHAIN_END,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                status="error",
                duration_ms=duration,
                data={"error": _truncate(err_msg, self._max_payload_chars)},
                is_end=True,
            )
            if lc_parent is None:
                self._maybe_auto_end_run(
                    lc_run_id, outputs=None, status="error", error=err_msg
                )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_chain_error swallowed")

    # ----- LLM lifecycle -----

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        invocation_params: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            ip = invocation_params or {}
            model = (
                ip.get("model")
                or ip.get("model_name")
                or (serialized or {}).get("name")
                or "llm"
            )
            self._emit_event(
                event_type=LLM_START,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                name=model,
                status="running",
                data={
                    "model": model,
                    "prompt": _truncate(prompts[0] if prompts else "", self._max_payload_chars),
                    "prompts": _truncate(prompts, self._max_payload_chars),
                    "params": {
                        k: v
                        for k, v in (invocation_params or {}).items()
                        if k in {"temperature", "max_tokens", "top_p", "stop"}
                    },
                },
            )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_llm_start swallowed")

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        invocation_params: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Chat models route through this instead of on_llm_start in LC 0.2+."""
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            ip = invocation_params or {}
            model = (
                ip.get("model")
                or ip.get("model_name")
                or (serialized or {}).get("name")
                or "chat_model"
            )
            # messages is list-of-list (one inner list per generation); stringify
            # the first generation's messages so the normalizer's prompt extract
            # has something to grab.
            prompt_str = ""
            if messages and messages[0]:
                prompt_str = "\n".join(str(m) for m in messages[0])
            self._emit_event(
                event_type=LLM_START,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                name=model,
                status="running",
                data={
                    "model": model,
                    "prompt": _truncate(prompt_str, self._max_payload_chars),
                    "params": {
                        k: v
                        for k, v in (invocation_params or {}).items()
                        if k in {"temperature", "max_tokens", "top_p", "stop"}
                    },
                },
            )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_chat_model_start swallowed")

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            duration = self._duration_ms(lc_run_id)

            # LLMResult.generations is list-of-list. Pull the first text.
            completion = ""
            prompt_tokens = 0
            completion_tokens = 0
            try:
                generations = getattr(response, "generations", None) or []
                if generations and generations[0]:
                    first = generations[0][0]
                    completion = getattr(first, "text", None) or str(first)
                # Token usage — best-effort across model providers
                llm_output = getattr(response, "llm_output", None) or {}
                usage = (
                    llm_output.get("token_usage")
                    or llm_output.get("usage")
                    or {}
                )
                prompt_tokens = int(usage.get("prompt_tokens", 0) or 0)
                completion_tokens = int(usage.get("completion_tokens", 0) or 0)
            except Exception:  # noqa: BLE001
                # Some custom LLM wrappers expose .content or other shapes — fall
                # back to stringifying the whole response.
                completion = str(response)[: self._max_payload_chars]

            self._emit_event(
                event_type=LLM_COMPLETION,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                status="success",
                duration_ms=duration,
                data={
                    "completion": _truncate(completion, self._max_payload_chars),
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens,
                    "latency_ms": duration,
                },
                is_end=True,
            )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_llm_end swallowed")

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            duration = self._duration_ms(lc_run_id)
            err_msg = f"{type(error).__name__}: {error}"
            self._emit_event(
                event_type=LLM_COMPLETION,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                status="error",
                duration_ms=duration,
                data={"error": _truncate(err_msg, self._max_payload_chars)},
                is_end=True,
            )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_llm_error swallowed")

    # ----- Tool lifecycle -----

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        inputs: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            name = (serialized or {}).get("name") or "tool"
            self._emit_event(
                event_type=TOOL_START,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                name=name,
                status="running",
                data={
                    "tool_name": name,
                    "args": _truncate(inputs or input_str, self._max_payload_chars),
                },
            )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_tool_start swallowed")

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            duration = self._duration_ms(lc_run_id)
            self._emit_event(
                event_type=TOOL_END,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                status="success",
                duration_ms=duration,
                data={"output": _truncate(output, self._max_payload_chars)},
                is_end=True,
            )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_tool_end swallowed")

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            duration = self._duration_ms(lc_run_id)
            err_msg = f"{type(error).__name__}: {error}"
            self._emit_event(
                event_type=TOOL_END,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                status="error",
                duration_ms=duration,
                data={"error": _truncate(err_msg, self._max_payload_chars)},
                is_end=True,
            )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_tool_error swallowed")

    # ----- Agent reasoning -----

    def on_agent_action(
        self,
        action: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """LangChain agent decided on a (thought, action, action_input) triple."""
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            tool = getattr(action, "tool", None)
            tool_input = getattr(action, "tool_input", None)
            log = getattr(action, "log", None)
            self._emit_event(
                event_type=AGENT_STEP,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                name=tool or "agent_step",
                data={
                    "thought": _truncate(log, self._max_payload_chars),
                    "action": tool,
                    "action_input": _truncate(tool_input, self._max_payload_chars),
                },
            )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_agent_action swallowed")

    def on_agent_finish(
        self,
        finish: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """LangChain agent reached its final answer. Emit one observation step."""
        try:
            lc_run_id = _coerce_uuid(run_id) or new_event_id()
            lc_parent = _coerce_uuid(parent_run_id)
            return_values = getattr(finish, "return_values", None) or {}
            log = getattr(finish, "log", None)
            self._emit_event(
                event_type=AGENT_STEP,
                lc_run_id=lc_run_id,
                lc_parent_run_id=lc_parent,
                name="agent_finish",
                status="success",
                data={
                    "thought": _truncate(log, self._max_payload_chars),
                    "observation": _truncate(return_values, self._max_payload_chars),
                },
            )
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCallbackHandler.on_agent_finish swallowed")
