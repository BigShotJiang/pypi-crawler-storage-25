# dobby-collector — Changelog

All notable changes to the `dobby-collector` Python SDK. Versions follow
[Semantic Versioning](https://semver.org/) — pre-1.0, `0.X.Y` bumps:
- `Y+1` = bug fix, wire-protocol unchanged, public API unchanged
- `X+1` = new feature (new event types, new framework adapter, new server contract)

Release process: see [PUBLISH.md](./PUBLISH.md).

## [Unreleased / v0.4.2 DRAFT] — pending publish

### Fixed
- **LangChain handler `_truncate()` now coerces Pydantic Message objects.**
  LangChain ≥ 1.0 surfaces `HumanMessage` / `AIMessage` / `ToolMessage`
  Pydantic v2 models in event data. Pre-fix, `_truncate` fell through to
  `return value`, sender's `json.dumps()` crashed, every batch was silently
  dropped → **0 `workload_runs` rows** for any LangChain ≥ 1.0 customer.
  Now: try `model_dump()` first, fall back to `str(value)`. Same recipe as
  the CrewAI fix in v0.4.1. Commit `56fae416`.
- Verified end-to-end against prod: pre-fix 0 rows, post-fix 1 row with
  `tool_calls=1` + `llm_calls=2` + `traceparent` populated.

### Known limitations (not fixed in v0.4.2)
- **LangChain ≥ 1.0 `create_agent` (langgraph) doesn't fire legacy
  `on_agent_action` / `on_agent_finish` callbacks** → `agent_steps` is
  always 0 for new LangChain runs. `tool_calls` + `llm_calls` capture the
  essential signal. LangChain 0.x `AgentExecutor` users unaffected.

## [0.4.1] — 2026-05-16

### Fixed
- **CrewAI handler `_truncate()` now coerces Pydantic `TaskOutput`.**
  CrewAI's `TaskCompletedEvent.output` is a Pydantic v2 model — pre-fix
  the sender's `json.dumps()` crashed on it → batches dropped silently.
  Added `model_dump()` path + `str()` fallback. Commit `a0a0954c`.
- **CrewAI handler `LLM_END` constant corrected to `"llm.completion"`**
  (was `"llm.end"`). The server normalizer pairs `llm.start` ↔
  `llm.completion`, so the mismatch caused `llm_calls=0` in BQ even on
  successful runs. Commit `a0a0954c`.

### Companion server-side change (deployed alongside v0.4.1)
- **`extractAgentSteps` server normalizer recognises CrewAI span:agent
  events** (commit `d7f63415`). Closes the `agent_steps=0` gap for
  CrewAI — no SDK upgrade required for this piece, takes effect on next
  prod deploy.

### Verified
- PyPI install path (`pip install dobby-collector[crewai]==0.4.1`) +
  fresh prod connector + real CrewAI 2-agent crew → 6/6 BQ verification
  fields populate including `agent_steps=2`. Memory:
  `crewai-oss-pypi-end-to-end-verified-2026-05-16`.

## [0.4.0] — 2026-05-16

### Added
- **W3C Trace Context auto-emission** on every outbound batch via fresh
  `traceparent: 00-{32hex}-{16hex}-01` header generated through
  `secrets.token_hex`. Per-batch (not per-process, not per-event) so each
  upload is a unique transaction. No customer code changes — `init(...)`
  picks up the behavior automatically.
- **Server-side strict W3C validation** + all-zero sentinel rejection
  before stamping onto `workload_runs.metadata_json.traceparent`.
  Malformed headers silently dropped; the batch is never rejected.

### Customer impact
- The Surrounding-mode `Tracing Enabled` governance control (weight = 4)
  flips from `not_applicable` → `configured` for an org within one
  hourly governance-rescore cron tick after their first batch lands.
- Public docs page: `/docs/sdk/python-collector/tracing`.

## [0.3.0] — 2026-05-XX

### Added
- **`DobbyAssistantsHandler`** — auto-instrumentation for OpenAI
  Assistants API. Install via `pip install dobby-collector[openai_assistants]`.
- **`DobbyAutoGenLogHandler`** — auto-instrumentation for AutoGen ≥ 0.4.
  Install via `pip install dobby-collector[autogen]`.

## [0.2.0] — 2026-05-XX

### Added
- **`DobbyCrewAIHandler`** — auto-instrumentation for CrewAI ≥ 1.0 via
  the `CrewAIEventsBus` + `BaseEventListener` pattern. Install via
  `pip install dobby-collector[crewai]`. Runnable example +
  `examples/crewai_real_agent.py`.

## [0.1.x] — 2026-05-13/14

### Added
- **v0.1.0** Phase 1 publish — manual `@track` / `span` / `start_run` /
  `end_run` / `shutdown` API. In-memory ring buffer + background sender
  + HTTP retries. SQLite DLQ for crash-survival. First PyPI publish.
- **Phase 2b** — `DobbyCallbackHandler` for LangChain via
  `BaseCallbackHandler`. PII redaction + field exclusion. Backpressure
  synthetic event.

## Cross-references

- Release runbook: [PUBLISH.md](./PUBLISH.md)
- Server-side adapter: `web/shared/lib/connectors/dobby-sdk/normalize.ts`
  + `web/app/api/v1/webhooks/workloads/[connectorId]/route.ts`
- Verification scripts: [scripts/debug/smoke-crewai-oss.py](../../scripts/debug/smoke-crewai-oss.py) ·
  [scripts/debug/smoke-langchain-oss.py](../../scripts/debug/smoke-langchain-oss.py) ·
  [scripts/debug/smoke-dobby-sdk.py](../../scripts/debug/smoke-dobby-sdk.py)
- Customer quickstart pages: `/docs/sdk/python-collector/crewai` ·
  `/docs/sdk/python-collector/tracing`
