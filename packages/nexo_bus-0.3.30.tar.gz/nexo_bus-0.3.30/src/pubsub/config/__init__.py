from typing import Annotated, Self

from pydantic import BaseModel, Field

from ..._config import (
    IdentifierConfigMixin,
    OptSubscriptionsConfig,
    PublisherConfigMixin,
    SubscriptionsConfigMixin,
)
from .publisher import TopicsConfig


class SubscriberManagerConfig(IdentifierConfigMixin):
    @classmethod
    def from_config(cls, config: "PubSubConfig") -> Self:
        return cls(identifier=config.identifier)


class PubSubConfig[P: TopicsConfig, S: OptSubscriptionsConfig](
    SubscriptionsConfigMixin[S],
    PublisherConfigMixin[P],
    IdentifierConfigMixin,
):
    @property
    def subscriber_manager_config(self) -> SubscriberManagerConfig:
        return SubscriberManagerConfig(identifier=self.identifier)


OptPubSubConfig = PubSubConfig | None


class PubSubConfigs(BaseModel):
    pass


OptPubSubConfigs = PubSubConfigs | None


class PubSubConfigsMixin[T: OptPubSubConfigs](BaseModel):
    pubsub: Annotated[T, Field(..., description="PubSub's Configs")]
