from typing import Annotated

from pydantic import BaseModel, Field


class TopicConfig(BaseModel):
    id: str = Field(..., description="Topic's Id")


DEFAULT_HEARTBEAT_TOPIC_CONFIG = TopicConfig(id="heartbeat")
DEFAULT_OPERATION_TOPIC_CONFIG = TopicConfig(id="operation")
DEFAULT_RESOURCE_MEASUREMENT_TOPIC_CONFIG = TopicConfig(id="resource-measurement")


class InfraTopicsConfig(BaseModel):
    heartbeat: Annotated[
        TopicConfig,
        Field(
            DEFAULT_HEARTBEAT_TOPIC_CONFIG,
            description="Heartbeat topic config",
        ),
    ] = DEFAULT_HEARTBEAT_TOPIC_CONFIG
    resource_measurement: Annotated[
        TopicConfig,
        Field(
            DEFAULT_RESOURCE_MEASUREMENT_TOPIC_CONFIG,
            description="Resource measurement topic config",
        ),
    ] = DEFAULT_RESOURCE_MEASUREMENT_TOPIC_CONFIG


class TopicsConfig(BaseModel):
    infra: Annotated[
        InfraTopicsConfig,
        Field(InfraTopicsConfig(), description="Infra topics config"),
    ] = InfraTopicsConfig()
    operation: Annotated[
        TopicConfig,
        Field(
            DEFAULT_OPERATION_TOPIC_CONFIG,
            description="Operation topic config",
        ),
    ] = DEFAULT_OPERATION_TOPIC_CONFIG
