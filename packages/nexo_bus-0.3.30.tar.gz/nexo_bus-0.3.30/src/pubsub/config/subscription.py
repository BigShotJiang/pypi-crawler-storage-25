from typing import Annotated

from pydantic import Field

from ..._config import SubscriptionConfig as BaseSubscriptionConfig


class SubscriptionConfig(BaseSubscriptionConfig):
    max_messages: Annotated[
        int, Field(10, description="Subscription's Max messages")
    ] = 10
    ack_deadline: Annotated[
        int, Field(10, description="Subscription's ACK deadline")
    ] = 10
