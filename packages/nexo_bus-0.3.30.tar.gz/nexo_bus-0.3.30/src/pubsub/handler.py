from ..handler import SubscriptionHandler as BaseSubscriptionHandler
from .config.subscription import SubscriptionConfig


class SubscriptionHandler(BaseSubscriptionHandler[SubscriptionConfig]):
    pass
