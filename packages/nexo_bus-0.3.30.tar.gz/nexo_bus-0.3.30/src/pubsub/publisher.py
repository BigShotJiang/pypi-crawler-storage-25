from google.cloud.pubsub_v1 import PublisherClient
from google.oauth2.service_account import Credentials
from nexo.schemas.bus import PubSubPublisher
from nexo.types.misc import OptPathOrStr
from nexo.utils.loaders.google import load, validate

from .config.publisher import TopicsConfig


class GooglePublisherManager[T: TopicsConfig]:
    def __init__(
        self,
        config: T,
        *,
        credentials: Credentials | None = None,
        credentials_path: OptPathOrStr = None,
    ) -> None:
        self.config = config

        if (credentials is None and credentials_path is None) or (
            credentials is not None and credentials_path is not None
        ):
            raise ValueError(
                "Only either 'credentials' and 'credentials_path' must be given"
            )

        if credentials is not None:
            self._credentials = credentials
        else:
            self._credentials = load(credentials_path)

        validate(self._credentials)

        self.client = PublisherClient(credentials=self._credentials)

    @property
    def project_id(self) -> str:
        project_id = self._credentials.project_id
        if not isinstance(project_id, str):
            raise ValueError("Project ID did not exist")
        return project_id

    def topic_path(self, topic) -> str:
        return self.client.topic_path(self.project_id, topic)

    @property
    def heartbeat_publisher(self) -> PubSubPublisher:
        return PubSubPublisher(
            client=self.client,
            project_id=self.project_id,
            topic_id=self.config.infra.heartbeat.id,
        )

    @property
    def operation_publisher(self) -> PubSubPublisher:
        return PubSubPublisher(
            client=self.client,
            project_id=self.project_id,
            topic_id=self.config.operation.id,
        )

    @property
    def resource_measurement_publisher(self) -> PubSubPublisher:
        return PubSubPublisher(
            client=self.client,
            project_id=self.project_id,
            topic_id=self.config.infra.resource_measurement.id,
        )
