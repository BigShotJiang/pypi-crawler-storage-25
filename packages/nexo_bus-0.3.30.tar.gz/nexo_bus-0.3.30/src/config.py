from typing import Annotated

from pydantic import BaseModel, Field

from .pubsub.config import OptPubSubConfigs, PubSubConfigsMixin
from .rabbitmq.config import OptRabbitMQConfigs, RabbitMQConfigsMixin


class BusConfig[P: OptPubSubConfigs, R: OptRabbitMQConfigs](
    RabbitMQConfigsMixin[R], PubSubConfigsMixin[P]
):
    pass


class BusConfigMixin[T: BusConfig](BaseModel):
    bus: Annotated[T, Field(..., description="Bus config")]
