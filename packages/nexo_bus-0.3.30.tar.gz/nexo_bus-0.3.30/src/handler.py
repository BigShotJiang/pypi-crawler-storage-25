from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field

from ._config import SubscriptionConfig
from .types import MessageController


class SubscriptionHandler[T: SubscriptionConfig](BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    config: Annotated[T, Field(..., description="Subscription config")]
    controller: Annotated[MessageController, Field(..., description="Controller")]
