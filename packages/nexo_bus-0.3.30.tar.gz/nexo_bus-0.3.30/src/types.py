from collections.abc import Awaitable, Callable
from typing import Concatenate, ParamSpec, TypeVar

from aio_pika.abc import AbstractIncomingMessage
from google.cloud.pubsub_v1.subscriber.message import Message

M = TypeVar("M", AbstractIncomingMessage, Message)
P = ParamSpec("P")
R = TypeVar("R", bool, Awaitable[bool])
MessageController = Callable[Concatenate[str, M, P], R]
