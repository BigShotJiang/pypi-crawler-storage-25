from typing import Annotated

from nexo.enums.environment import Environment
from nexo.types.dict import OptStrToStrDict
from nexo.types.string import OptStr
from pydantic import BaseModel, Field


class IdentifierConfig(BaseModel):
    enabled: Annotated[bool, Field(True, description="Whether bus is enabled")] = True
    environment: Annotated[Environment, Field(..., description="Bus's environment")]
    name: Annotated[str, Field(..., description="Bus's name")]
    description: Annotated[OptStr, Field(None, description="Bus's description")] = None
    tags: Annotated[OptStrToStrDict, Field(None, description="Bus's tags")] = None


class IdentifierConfigMixin(BaseModel):
    identifier: Annotated[IdentifierConfig, Field(..., description="Identifier")]


class PublisherConfigMixin[T](BaseModel):
    publisher: Annotated[T, Field(..., description="Publisher config")]


class SubscriptionConfig(BaseModel):
    id: Annotated[str, Field(..., description="Subscription's Identifier")]
    enabled: Annotated[
        bool, Field(True, description="Whether to enable subscription")
    ] = True
    consume: Annotated[bool, Field(True, description="Whether to consume message")] = (
        True
    )


class SubscriptionsConfig(BaseModel):
    pass


OptSubscriptionsConfig = SubscriptionsConfig | None


class SubscriptionsConfigMixin[T: OptSubscriptionsConfig](BaseModel):
    subscriptions: Annotated[T, Field(..., description="Subscriptions config")]
