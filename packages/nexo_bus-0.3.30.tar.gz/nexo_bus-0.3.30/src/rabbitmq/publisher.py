from nexo.schemas.bus import RabbitMQPublisher
from pika import BlockingConnection, URLParameters

from .config.connection import ConnectionConfig
from .config.publisher import ExchangeConfig, ExchangesConfig


class RabbitMQPublisherManager[T: ExchangesConfig]:
    def __init__(self, connection: ConnectionConfig, config: T) -> None:
        self.connection = connection
        self.config = config

        self.connect()

    def connect(self) -> None:
        params = URLParameters(self.connection.url)
        self._connection = BlockingConnection(params)
        self._channel = self._connection.channel()

    def disconnect(self) -> None:
        if self._connection and not self._connection.is_closed:
            self._connection.close()

    def build_handler(self, exchange_config: ExchangeConfig) -> RabbitMQPublisher:
        return RabbitMQPublisher(
            channel=self._channel,
            exchange_name=exchange_config.name,
            routing_key=exchange_config.routing_key,
        )

    @property
    def heartbeat_publisher(self) -> RabbitMQPublisher:
        return self.build_handler(self.config.infra.heartbeat)

    @property
    def operation_publisher(self) -> RabbitMQPublisher:
        return self.build_handler(self.config.operation)

    @property
    def resource_measurement_publisher(self) -> RabbitMQPublisher:
        return self.build_handler(self.config.infra.resource_measurement)
