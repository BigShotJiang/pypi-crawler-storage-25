from typing import Annotated, Self

from pydantic import BaseModel, Field

from ..._config import (
    IdentifierConfigMixin,
    OptSubscriptionsConfig,
    PublisherConfigMixin,
    SubscriptionsConfigMixin,
)
from .connection import ConnectionConfigMixin
from .publisher import ExchangesConfig


class SubscriberManagerConfig(ConnectionConfigMixin, IdentifierConfigMixin):
    @classmethod
    def from_config(cls, config: "RabbitMQConfig") -> Self:
        return cls(
            identifier=config.identifier,
            connection=config.connection,
        )


class RabbitMQConfig[P: ExchangesConfig, S: OptSubscriptionsConfig](
    SubscriptionsConfigMixin[S],
    PublisherConfigMixin[P],
    ConnectionConfigMixin,
    IdentifierConfigMixin,
):
    @property
    def subscriber_manager_config(self) -> SubscriberManagerConfig:
        return SubscriberManagerConfig(
            identifier=self.identifier,
            connection=self.connection,
        )


OptRabbitMQConfig = RabbitMQConfig | None


class RabbitMQConfigs(BaseModel):
    pass


OptRabbitMQConfigs = RabbitMQConfigs | None


class RabbitMQConfigsMixin[T: OptRabbitMQConfigs](BaseModel):
    rabbitmq: Annotated[T, Field(..., description="RabbitMQ's Configs")]
