from typing import Annotated

from pydantic import Field

from ..._config import SubscriptionConfig as BaseSubscriptionConfig


class SubscriptionConfig(BaseSubscriptionConfig):
    prefetch_count: Annotated[
        int, Field(10, description="Max unacked messages at a time")
    ] = 10
    durable: Annotated[bool, Field(True, description="Whether queue is durable")] = True
