from typing import Annotated

from pydantic import BaseModel, Field


class ExchangeConfig(BaseModel):
    name: Annotated[str, Field(..., description="Exchange name to publish to")]
    routing_key: Annotated[str, Field(..., description="Routing key / queue name")]
    durable: Annotated[bool, Field(True, description="Whether is durable")] = True


DEFAULT_HEARTBEAT_EXCHANGE_CONFIG = ExchangeConfig(
    name="heartbeat.events",
    routing_key="checked",
)
DEFAULT_OPERATION_EXCHANGE_CONFIG = ExchangeConfig(
    name="operation.events",
    routing_key="completed",
)
DEFAULT_RESOURCE_MEASUREMENT_EXCHANGE_CONFIG = ExchangeConfig(
    name="resource-measurement.events",
    routing_key="measured",
)


class InfraExchangesConfig(BaseModel):
    heartbeat: Annotated[
        ExchangeConfig,
        Field(
            DEFAULT_HEARTBEAT_EXCHANGE_CONFIG,
            description="Heartbeat exchange config",
        ),
    ] = DEFAULT_HEARTBEAT_EXCHANGE_CONFIG
    resource_measurement: Annotated[
        ExchangeConfig,
        Field(
            DEFAULT_RESOURCE_MEASUREMENT_EXCHANGE_CONFIG,
            description="Resource measurement exchange config",
        ),
    ] = DEFAULT_RESOURCE_MEASUREMENT_EXCHANGE_CONFIG


class ExchangesConfig(BaseModel):
    infra: Annotated[
        InfraExchangesConfig,
        Field(InfraExchangesConfig(), description="Infra's exchanges config"),
    ] = InfraExchangesConfig()
    operation: Annotated[
        ExchangeConfig,
        Field(
            DEFAULT_OPERATION_EXCHANGE_CONFIG,
            description="Operation exchange config",
        ),
    ] = DEFAULT_OPERATION_EXCHANGE_CONFIG
