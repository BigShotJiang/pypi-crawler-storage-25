from typing import Annotated

from pydantic import BaseModel, Field, computed_field


class ConnectionConfig(BaseModel):
    username: Annotated[str, Field("guest", description="Username")] = "guest"
    password: Annotated[str, Field("guest", description="Password")] = "guest"
    host: Annotated[str, Field("127.0.0.1", description="Host")] = "127.0.0.1"
    port: Annotated[int, Field(5672, description="Port")] = 5672
    vhost: Annotated[str, Field("/", description="Virtual Host")] = "/"

    @computed_field
    @property
    def url(self) -> str:
        return f"amqp://{self.username}:{self.password}@{self.host}:{self.port}/{self.vhost.lstrip('/')}"


class ConnectionConfigMixin(BaseModel):
    connection: Annotated[ConnectionConfig, Field(..., description="Connection config")]
