import asyncio
import inspect
from collections.abc import Sequence

import aio_pika
from aio_pika.abc import AbstractIncomingMessage
from nexo.logging.config import LogConfig
from nexo.logging.logger import Bus
from nexo.schemas.application import ApplicationContext, OptApplicationContext
from nexo.schemas.extractor import extract_details

from ..types import MessageController
from .config import SubscriberManagerConfig
from .handler import SubscriptionHandler


class RabbitMQSubscriberManager:
    def __init__(
        self,
        config: SubscriberManagerConfig,
        log_config: LogConfig,
        handlers: Sequence[SubscriptionHandler],
        *,
        application_context: OptApplicationContext = None,
    ) -> None:
        self.config = config

        self._application_context = (
            application_context
            if application_context is not None
            else ApplicationContext.new()
        )

        self._logger = Bus(
            log_config,
            environment=self._application_context.environment,
            service_key=self._application_context.service_key,
            identifier=(
                "rabbitmq|"
                f"{self.config.identifier.environment.value}|"
                f"{self.config.identifier.name}"
            ),
        )

        self.handlers = handlers

        self._event_loop = None
        self._active_listeners: dict[str, asyncio.Task] = {}

    async def connect(self):
        """Establish connection and channel"""
        self._connection = await aio_pika.connect_robust(self.config.connection.url)
        self._channel = await self._connection.channel()

    async def disconnect(self):
        """Close connection"""
        if self._connection and not self._connection.is_closed:
            await self._connection.close()

    def set_event_loop(self, loop: asyncio.AbstractEventLoop):
        """Set the event loop to use for async operations"""
        self._event_loop = loop

    async def message_callback(
        self,
        subscription_id: str,
        message: AbstractIncomingMessage,
        *,
        consume: bool,
        controller: MessageController,
    ):
        """Main callback — delegates to controller, acks/nacks based on result"""
        prefix = f"Subscription {subscription_id} - Message {message.message_id}"
        log_extra = {
            "json_fields": {
                "message_details": {
                    "headers": dict(message.headers),
                    "content_type": message.content_type,
                }
            },
        }

        if not consume:
            await message.ack()
            self._logger.info(
                f"{prefix} - Successfully processed message", extra=log_extra
            )
            return

        # Check if the controller function is async
        if inspect.iscoroutinefunction(controller):
            # Handle async controller function
            success = await controller(subscription_id, message)
        else:
            success = controller(subscription_id, message)

        # Acknowledge or nack based on controller result
        if success:
            await message.ack()
            self._logger.info(
                f"{prefix} - Successfully processed message", extra=log_extra
            )
        else:
            await message.nack(requeue=True)
            self._logger.warning(
                f"{prefix} - Failed processing message", extra=log_extra
            )

    async def start_listening(self, *, handler: SubscriptionHandler):
        """Start listening to a specific queue"""
        try:
            await self._channel.set_qos(prefetch_count=handler.config.prefetch_count)

            queue = await self._channel.declare_queue(
                handler.config.id,
                durable=handler.config.durable,
            )

            async def _on_message(message: AbstractIncomingMessage):
                await self.message_callback(
                    handler.config.id,
                    message,
                    consume=handler.config.consume,
                    controller=handler.controller,
                )

            await queue.consume(_on_message)
            self._logger.info(f"Started listener for queue {handler.config.id}")

        except Exception as e:
            self._logger.error(
                f"Exception occured while starting listener "
                f"for queue {handler.config.id}",
                exc_info=True,
                extra={"json_fields": {"exc_details": extract_details(e)}},
            )

    async def start_all_listeners(self):
        """Start listening to all enabled subscriptions"""
        tasks = []
        for handler in self.handlers:
            if handler.config.enabled:
                task = asyncio.create_task(self.start_listening(handler=handler))
                tasks.append(task)

        await asyncio.sleep(1)
        self._logger.info(f"Started {len(tasks)} subscription listeners")
        return tasks

    async def stop_all_listeners(self):
        """Stop all active listener"""
        for _, task in self._active_listeners.items():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        self._active_listeners.clear()
        self._logger.info(f"Stopped {len(self.handlers)} subscription listeners")
