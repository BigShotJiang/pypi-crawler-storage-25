# Converter Benchmark

This benchmark compares the performance of pure C++ converters versus Python converters, measuring the conversion overhead between Python and C++.

## Building

### Option 1: Build from benchmark directory

From the project root:

```bash
cd benchmark
mkdir -p build
cd build
cmake ..
make
```

The executable will be at `benchmark/build/converter_benchmark`.

### Option 2: Build from project root

If COLA-Py is already built:

```bash
mkdir -p build
cd build
cmake ..
cmake --build . --target converter_benchmark
```

## Running

From the build directory:

```bash
./converter_benchmark [num_events] [num_particles]
```

Default values:
- `num_events`: 1000
- `num_particles`: 100

Examples:
```bash
# Default run
./converter_benchmark

# Custom parameters
./converter_benchmark 5000 200

# Large scale test
./converter_benchmark 10000 1000
```

**Note**: Make sure `test_converter.py` is in the same directory as the executable, or in the Python path.

## What it measures

The benchmark compares:

1. **C++ Converter (pass-through)**: Pure C++ converter with minimal overhead - baseline
2. **C++ Converter (with work)**: C++ converter that accesses and modifies particles - shows C++ processing time
3. **Python Converter (pass-through)**: Python converter that just passes through data - measures pure conversion overhead
4. **Python Converter (with work)**: Python converter that accesses and modifies particles - measures conversion + processing overhead
5. **Python Converter (modify & return)**: Python converter that creates a new event - measures full conversion cycle

The benchmark calculates the conversion overhead by comparing Python converters to their C++ equivalents.

## Output

The benchmark outputs:
- Individual timing for each converter type
- Conversion overhead analysis comparing C++ vs Python pass-through converters
- All times in microseconds per event

Example output:
```
========================================
Converter Benchmark
========================================
Events per test: 1000
Particles per event: 100

  C++ Converter (pass-through) (100 particles): 2.5 μs per event
  C++ Converter (with work) (100 particles): 15.3 μs per event
  Python Converter (pass-through) (100 particles): 45.2 μs per event
  Python Converter (with work) (100 particles): 180.5 μs per event
  Python Converter (modify & return) (100 particles): 250.8 μs per event

========================================
Conversion Overhead Analysis
========================================
C++ pass-through:     2.5 μs
Python pass-through:  45.2 μs
Conversion overhead:  42.7 μs (1708.0%)
```

## Requirements

- COLA library (installed or available via CMAKE_PREFIX_PATH)
- COLA-Py library (built from source or installed)
- Python 3 with `colapy` package installed or available in source
- pybind11 (found via CMake)

## Troubleshooting

### COLA-Py not found
If you get "COLA-Py not found", make sure:
1. COLA-Py is installed, OR
2. You're building from the project root (so it can find `src/COLA-Py`)

### Python import errors
If you get Python import errors:
1. Make sure `colapy` is installed: `pip install -e .`
2. Or ensure the source directory is in Python path
3. Make sure `test_converter.py` is in the benchmark directory

### Library linking errors
If you get linking errors:
1. Make sure COLA is installed or available
2. Check that COLA-Py library was built successfully
3. Verify CMAKE_PREFIX_PATH includes COLA installation directory

