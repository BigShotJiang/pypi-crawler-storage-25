"""PQS tools for LangChain agents."""

from __future__ import annotations

import os
from typing import Optional, Type

import requests
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

PQS_CA_URL = os.environ.get("PQS_CA_URL", "http://localhost:4025")


class VerifyInput(BaseModel):
    """Input for PQSVerifyTool."""

    endpoint: str = Field(description="The API endpoint URL to verify against PQS CA")


class ListProvidersInput(BaseModel):
    """Input for PQSListProvidersTool."""

    filter: Optional[str] = Field(
        default=None,
        description="Optional keyword to filter providers by endpoint URL or capabilities",
    )


class PQSVerifyTool(BaseTool):
    """Check whether an API endpoint is PQS-verified.

    Queries the PQS Certificate Authority to determine if a given endpoint
    holds a valid verification certificate, and returns its trust score,
    tier, capabilities, and EAS attestation UID.
    """

    name: str = "pqs_verify"
    description: str = (
        "Verify if an API endpoint is PQS-certified. "
        "Returns verification status, PQS score, tier, capabilities, "
        "certificate expiry, and EAS attestation UID. "
        "Use this before calling any untrusted AI agent endpoint."
    )
    args_schema: Type[BaseModel] = VerifyInput

    pqs_ca_url: str = PQS_CA_URL

    def _run(self, endpoint: str) -> str:
        try:
            resp = requests.get(
                f"{self.pqs_ca_url}/verify",
                params={"endpoint": endpoint},
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            return f"Error contacting PQS CA: {e}"

        if not data.get("valid"):
            return f"Endpoint {endpoint} is NOT verified by PQS."

        cert = data.get("cert", {})
        subject = cert.get("subject", {})
        lines = [
            f"Endpoint: {endpoint}",
            f"Verified: YES",
            f"Signature valid: {data.get('signature_valid', 'N/A')}",
            f"PQS Score: {data.get('pqs_score', 'N/A')}",
            f"PQS Tier: {data.get('pqs_tier', 'N/A')}",
            f"EAS UID: {data.get('eas_uid', 'N/A')}",
        ]

        if cert:
            lines.append(f"Capabilities: {', '.join(cert.get('capabilities', []))}")
            lines.append(f"Issuer: {cert.get('issuer', 'N/A')}")
            lines.append(f"Issued: {cert.get('issued_at', 'N/A')}")
            lines.append(f"Expires: {cert.get('expires_at', 'N/A')}")
            lines.append(f"Wallet: {subject.get('wallet', 'N/A')}")
            lines.append(f"ERC-8004 ID: {subject.get('erc8004_id', 'N/A')}")

        return "\n".join(lines)


class PQSListProvidersTool(BaseTool):
    """List all PQS-verified API providers.

    Queries the PQS Certificate Authority for the full registry of
    verified endpoints and their certificates.
    """

    name: str = "pqs_list_providers"
    description: str = (
        "List all PQS-verified API providers with their scores and capabilities. "
        "Optionally filter by keyword. Use this to discover trusted AI agent endpoints."
    )
    args_schema: Type[BaseModel] = ListProvidersInput

    pqs_ca_url: str = PQS_CA_URL

    def _run(self, filter: Optional[str] = None) -> str:
        try:
            resp = requests.get(f"{self.pqs_ca_url}/certs", timeout=10)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            return f"Error contacting PQS CA: {e}"

        certs = data.get("certs", [])
        total = data.get("total", len(certs))

        if filter:
            keyword = filter.lower()
            certs = [
                c
                for c in certs
                if keyword in c.get("endpoint", "").lower()
                or keyword
                in ", ".join(c.get("capabilities", [])).lower()
            ]

        if not certs:
            msg = "No verified providers found"
            if filter:
                msg += f" matching '{filter}'"
            return f"{msg}."

        lines = [f"PQS Verified Providers ({len(certs)}/{total} total):"]
        lines.append("")

        for i, cert in enumerate(certs, 1):
            lines.append(f"{i}. {cert.get('endpoint', 'unknown')}")
            lines.append(f"   Wallet: {cert.get('wallet', 'N/A')}")
            lines.append(f"   Capabilities: {', '.join(cert.get('capabilities', []))}")
            lines.append(f"   Status: {cert.get('status', 'N/A')}")
            lines.append(f"   Issued: {cert.get('issued_at', 'N/A')} | Expires: {cert.get('expires_at', 'N/A')}")
            lines.append(f"   EAS UID: {cert.get('eas_uid', 'N/A')}")
            lines.append("")

        return "\n".join(lines)
