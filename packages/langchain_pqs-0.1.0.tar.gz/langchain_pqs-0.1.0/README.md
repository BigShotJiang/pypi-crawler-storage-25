# langchain-pqs

LangChain integration for **PQS (Protocol Quality Standard)** — the Certificate Authority for AI agent economy.

Gives LangChain agents the ability to verify whether an API endpoint is PQS-certified before calling it, and to discover trusted providers from the PQS registry.

## Installation

```bash
pip install langchain-pqs
```

## Configuration

Set the PQS CA server URL (defaults to `http://localhost:4025`):

```bash
export PQS_CA_URL=http://localhost:4025
```

Or pass it directly:

```python
from langchain_pqs import PQSVerifyTool

tool = PQSVerifyTool(pqs_ca_url="https://pqs.smartflowproai.com")
```

## Tools

### PQSVerifyTool

Check if an API endpoint is PQS-verified:

```python
from langchain_pqs import PQSVerifyTool

verify = PQSVerifyTool()
result = verify.invoke({"endpoint": "https://api.example.com/v1/signals"})
print(result)
```

Output:
```
Endpoint: https://api.example.com/v1/signals
Verified: YES
PQS Score: 87
PQS Tier: gold
EAS UID: 0xabc123...
Capabilities: market-signals, risk-scoring
Registered: 2026-04-01T00:00:00Z
Verified at: 2026-04-02T12:00:00Z
Expires: 2027-04-02T12:00:00Z
Owner: ExampleCorp
```

### PQSListProvidersTool

List all verified providers (with optional keyword filter):

```python
from langchain_pqs import PQSListProvidersTool

providers = PQSListProvidersTool()
result = providers.invoke({"filter": "signals"})
print(result)
```

## Usage with LangChain Agent

```python
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate
from langchain_pqs import PQSVerifyTool, PQSListProvidersTool

llm = ChatOpenAI(model="gpt-4o")
tools = [PQSVerifyTool(), PQSListProvidersTool()]

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are an AI agent that only calls PQS-verified endpoints. "
               "Always verify an endpoint before using it."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])

agent = create_tool_calling_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools)

result = executor.invoke({
    "input": "Is https://api.example.com/v1/signals a trusted endpoint?"
})
```

## License

MIT
