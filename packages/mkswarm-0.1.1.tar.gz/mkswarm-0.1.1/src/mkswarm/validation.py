"""Validation module for mkswarm.

This module provides IPv4 address validation and file parsing utilities.
"""

import ipaddress
import logging
import sys

log = logging.getLogger("mkswarm")

DOCKER_API_PORT = 2375


def parse_ipv4(raw: str) -> str:
    """Validate and normalize an IPv4 address string.

    Args:
        raw: String to validate as IPv4 address.

    Returns:
        Validated IPv4 address as string.

    Raises:
        ValueError: If input is not a valid IPv4 address.

    Example:
        >>> parse_ipv4("192.168.1.1")
        '192.168.1.1'
        >>> parse_ipv4("192.168.1.1 ")  # whitespace is trimmed
        '192.168.1.1'
    """
    try:
        addr = ipaddress.ip_address(raw)
        if not isinstance(addr, ipaddress.IPv4Address):
            raise ValueError("not IPv4")
        return str(addr)
    except ValueError:
        raise ValueError(f"invalid IPv4 address: {raw!r}")


def load_ips(path: str) -> list[str]:
    """Load and validate IPv4 addresses from a file.

    Reads a file containing one IPv4 address per line. Lines starting with
    '#' are treated as comments and empty lines are ignored.

    Args:
        path: Path to file containing IPv4 addresses.

    Returns:
        List of validated IPv4 address strings.

    Raises:
        SystemExit: If any line contains an invalid IPv4 address.

    Example:
        >>> # Example contents of ips.txt:
        >>> # Manager node
        >>> 192.168.1.1
        >>> 192.168.1.2
        >>> 192.168.1.3
        >>> ips = load_ips("ips.txt")
    """
    ips: list[str] = []
    errors: list[str] = []
    with open(path) as f:
        for lineno, line in enumerate(f, 1):
            raw = line.strip()
            if not raw or raw.startswith("#"):
                continue
            try:
                ips.append(parse_ipv4(raw))
            except ValueError as e:
                errors.append(f"  line {lineno}: {e}")
    if errors:
        log.error("IP file has invalid entries:\n%s", "\n".join(errors))
        sys.exit(1)
    return ips
