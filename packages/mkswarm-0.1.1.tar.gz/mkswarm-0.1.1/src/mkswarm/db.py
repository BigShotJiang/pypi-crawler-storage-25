"""Database module for mkswarm.

This module provides the SwarmDB class for managing Docker Swarm state
in a SQLite database.
"""

import logging
import os
import sqlite3
from datetime import UTC, datetime
from typing import Any

log = logging.getLogger("mkswarm")

DOCKER_PORT = 2377
DEFAULT_DB = "swarm.db"
KEY_ENV = "MKSWARM_KEY"

DDL = """
CREATE TABLE IF NOT EXISTS swarms (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    manager_ip     TEXT    NOT NULL,
    swarm_id       TEXT,
    worker_token   TEXT    NOT NULL,
    manager_token  TEXT    NOT NULL,
    manager_rate   REAL    NOT NULL,
    advertise_addr TEXT    NOT NULL,
    output_script  TEXT    NOT NULL,
    proxy          TEXT,
    encrypted      INTEGER NOT NULL DEFAULT 0,
    created_at     TEXT    NOT NULL,
    status         TEXT    NOT NULL DEFAULT 'initializing'
        CHECK(status IN ('initializing','ready','failed','destroyed'))
);

CREATE TABLE IF NOT EXISTS nodes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    swarm_id    INTEGER NOT NULL REFERENCES swarms(id) ON DELETE CASCADE,
    ip          TEXT    NOT NULL,
    role        TEXT    NOT NULL CHECK(role IN ('manager','worker')),
    status      TEXT    NOT NULL DEFAULT 'pending'
        CHECK(status IN ('pending','joined','failed','skipped','left')),
    error       TEXT,
    joined_at   TEXT,
    updated_at  TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_nodes_swarm  ON nodes(swarm_id);
CREATE INDEX IF NOT EXISTS idx_nodes_ip     ON nodes(ip);
CREATE INDEX IF NOT EXISTS idx_nodes_status ON nodes(status);
"""


def utcnow() -> str:
    """Return current UTC time as ISO format string.

    Returns:
        ISO format timestamp string.
    """
    return datetime.now(UTC).isoformat()


class SwarmDB:
    """SQLite database wrapper for Docker Swarm state management.

    This class provides methods to create, read, update, and delete
    swarm and node records in a SQLite database.

    Attributes:
        conn: SQLite connection object.

    Example:
        >>> db = SwarmDB("swarm.db")
        >>> swarm_id = db.create_swarm("192.168.1.1", "worker_token", "manager_token", 0.2, "192.168.1.1:2377", "join.sh")
        >>> db.close()
    """

    def __init__(self, path: str = DEFAULT_DB) -> None:
        """Initialize database connection and create tables.

        Args:
            path: Path to SQLite database file.
        """
        self.conn = sqlite3.connect(path)
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.executescript(DDL)
        self.conn.commit()
        log.debug("db: %s", os.path.abspath(path))

    def find_ready_swarm(self, manager_ip: str) -> int | None:
        """Find a ready swarm for the given manager IP.

        Args:
            manager_ip: Manager node IP address.

        Returns:
            Swarm ID if found, None otherwise.
        """
        cur = self.conn.execute(
            "SELECT id FROM swarms WHERE manager_ip=? AND status='ready' LIMIT 1",
            (manager_ip,),
        )
        row = cur.fetchone()
        return row[0] if row else None

    def create_swarm(
        self,
        manager_ip: str,
        worker_token: str,
        manager_token: str,
        manager_rate: float,
        advertise_addr: str,
        output_script: str,
        swarm_id: str | None = None,
        proxy: str | None = None,
        encrypted: bool = False,
    ) -> int:
        """Create a new swarm record.

        Args:
            manager_ip: Manager node IP address.
            worker_token: Worker join token.
            manager_token: Manager join token.
            manager_rate: Fraction of peers to promote to managers.
            advertise_addr: Swarm advertise address.
            output_script: Path to join script.
            swarm_id: Docker Swarm ID (optional).
            proxy: Proxy URL (optional).
            encrypted: Whether tokens are encrypted.

        Returns:
            Row ID of inserted swarm (always valid after insert).
        """
        cur = self.conn.execute(
            """INSERT INTO swarms
               (manager_ip, swarm_id, worker_token, manager_token, manager_rate,
                advertise_addr, output_script, proxy, encrypted, created_at, status)
               VALUES (?,?,?,?,?,?,?,?,?,?,'initializing')""",
            (
                manager_ip,
                swarm_id,
                worker_token,
                manager_token,
                manager_rate,
                advertise_addr,
                output_script,
                proxy,
                int(encrypted),
                utcnow(),
            ),
        )
        self.conn.commit()
        result = cur.lastrowid
        if result is None:
            raise RuntimeError("Failed to insert swarm record")
        return result

    def set_swarm_status(self, rowid: int, status: str) -> None:
        """Update swarm status.

        Args:
            rowid: Swarm row ID.
            status: New status (initializing, ready, failed, destroyed).
        """
        self.conn.execute("UPDATE swarms SET status=? WHERE id=?", (status, rowid))
        self.conn.commit()

    def set_swarm_id(self, rowid: int, swarm_id: str) -> None:
        """Update swarm ID.

        Args:
            rowid: Swarm row ID.
            swarm_id: Docker Swarm ID.
        """
        self.conn.execute("UPDATE swarms SET swarm_id=? WHERE id=?", (swarm_id, rowid))
        self.conn.commit()

    def add_node(self, swarm_rowid: int, ip: str, role: str) -> int:
        """Add a node to a swarm.

        Args:
            swarm_rowid: Swarm row ID.
            ip: Node IP address.
            role: Node role (manager or worker).

        Returns:
            Row ID of inserted node.
        """
        cur = self.conn.execute(
            "INSERT INTO nodes (swarm_id,ip,role,status,updated_at) VALUES (?,?,?,'pending',?)",
            (swarm_rowid, ip, role, utcnow()),
        )
        self.conn.commit()
        result = cur.lastrowid
        if result is None:
            raise RuntimeError("Failed to insert swarm record")
        return result

    def set_node_status(
        self, rowid: int, status: str, error: str | None = None
    ) -> None:
        """Update node status.

        Args:
            rowid: Node row ID.
            status: New status (pending, joined, failed, skipped, left).
            error: Error message if status is failed.
        """
        joined_at = utcnow() if status == "joined" else None
        self.conn.execute(
            "UPDATE nodes SET status=?,error=?,joined_at=?,updated_at=? WHERE id=?",
            (status, error, joined_at, utcnow(), rowid),
        )
        self.conn.commit()

    def get_swarm(self, rowid: int) -> dict[str, Any]:
        """Get swarm by ID.

        Args:
            rowid: Swarm row ID.

        Returns:
            Dictionary with swarm data, empty dict if not found.
        """
        cur = self.conn.execute("SELECT * FROM swarms WHERE id=?", (rowid,))
        row = cur.fetchone()
        return dict(zip([d[0] for d in cur.description], row)) if row else {}

    def get_all_swarms(self) -> list[dict[str, Any]]:
        """Get all swarms ordered by ID.

        Returns:
            List of swarm dictionaries.
        """
        cur = self.conn.execute("SELECT * FROM swarms ORDER BY id")
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, row)) for row in cur.fetchall()]

    def get_nodes(self, swarm_rowid: int) -> list[dict[str, Any]]:
        """Get all nodes for a swarm.

        Args:
            swarm_rowid: Swarm row ID.

        Returns:
            List of node dictionaries.
        """
        cur = self.conn.execute(
            "SELECT * FROM nodes WHERE swarm_id=? ORDER BY id", (swarm_rowid,)
        )
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, row)) for row in cur.fetchall()]

    def get_pending_nodes(self, swarm_rowid: int) -> list[dict[str, Any]]:
        """Get pending nodes for a swarm.

        Args:
            swarm_rowid: Swarm row ID.

        Returns:
            List of pending node dictionaries.
        """
        cur = self.conn.execute(
            "SELECT * FROM nodes WHERE swarm_id=? AND status='pending' ORDER BY id",
            (swarm_rowid,),
        )
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, row)) for row in cur.fetchall()]

    def summary(self, swarm_rowid: int) -> None:
        """Print swarm state summary to stdout.

        Args:
            swarm_rowid: Swarm row ID.
        """
        swarm = self.get_swarm(swarm_rowid)
        nodes = self.get_nodes(swarm_rowid)
        enc = " (encrypted)" if swarm.get("encrypted") else ""
        print("\n── Swarm state ──────────────────────────────────────")
        print(f"  id            : {swarm['id']}")
        print(f"  swarm_id      : {swarm['swarm_id']}")
        print(f"  manager_ip    : {swarm['manager_ip']}")
        print(f"  advertise_addr: {swarm['advertise_addr']}")
        print(f"  proxy         : {swarm['proxy'] or '(none)'}")
        print(f"  tokens        : {'set' + enc}")
        print(f"  status        : {swarm['status']}")
        print(f"  created_at    : {swarm['created_at']}")
        print(f"  output_script : {swarm['output_script']}")
        print(f"\n  {'IP':<18} {'role':<10} {'status':<10} joined_at")
        print(f"  {'-' * 18} {'-' * 10} {'-' * 10} {'-' * 26}")
        for n in nodes:
            err = f"  ERR: {n['error']}" if n["error"] else ""
            print(
                f"  {n['ip']:<18} {n['role']:<10} {n['status']:<10}"
                f" {n['joined_at'] or '-'}{err}"
            )
        counts = {
            s: sum(1 for n in nodes if n["status"] == s)
            for s in ("pending", "joined", "failed", "skipped", "left")
        }
        print(f"\n  totals: {counts}")
        print("─────────────────────────────────────────────────────\n")

    def close(self) -> None:
        """Close database connection."""
        if self.conn is not None:
            self.conn.close()
        self.conn: Connection | None = None
