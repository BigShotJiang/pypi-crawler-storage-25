"""Cryptography module for mkswarm.

This module provides token encryption and decryption using Fernet.
"""

from __future__ import annotations

import logging
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cryptography.fernet import Fernet

log = logging.getLogger("mkswarm")


def _fernet(key: str) -> Fernet:
    """Create Fernet cipher from key.

    Args:
        key: Encryption key (base64-encoded string or bytes).

    Returns:
        Fernet cipher instance.
    """
    from cryptography.fernet import Fernet

    raw = key.encode() if isinstance(key, str) else key
    return Fernet(raw)


def encrypt_token(token: str, key: str | None) -> str:
    """Encrypt a Docker Swarm join token.

    Args:
        token: Plaintext token to encrypt.
        key: Fernet encryption key. If None, returns token unchanged.

    Returns:
        Encrypted token (base64) if key provided, otherwise original token.
    """
    if not key:
        return token
    return _fernet(key).encrypt(token.encode()).decode()


def decrypt_token(token: str, key: str | None) -> str:
    """Decrypt a Docker Swarm join token.

    Args:
        token: Token to decrypt (base64 if encrypted).
        key: Fernet decryption key. If None, returns token unchanged.

    Returns:
        Decrypted token if key provided, otherwise original token.

    Raises:
        SystemExit: If decryption fails due to wrong key.
    """
    if not key:
        return token
    try:
        return _fernet(key).decrypt(token.encode()).decode()
    except Exception as e:
        log.error("Token decryption failed — wrong key? (%s)", e)
        sys.exit(1)


def generate_key() -> str:
    """Generate a new Fernet encryption key.

    Returns:
        Base64-encoded Fernet key string.

    Example:
        >>> key = generate_key()
        >>> encrypted = encrypt_token("my_token", key)
        >>> decrypted = decrypt_token(encrypted, key)
        >>> assert decrypted == "my_token"
    """
    from cryptography.fernet import Fernet

    return Fernet.generate_key().decode()
