"""Backup and restore module for mkswarm.

This module provides database backup and restore functionality.
"""

import logging
import os
import shutil
import sqlite3
from datetime import datetime

from .db import DEFAULT_DB

log = logging.getLogger("mkswarm")

BUFFER_SIZE = 65536


def get_default_backup_path() -> str:
    """Get default backup filename with timestamp."""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"mkswarm_backup_{ts}.db"


def validate_backup(backup_path: str) -> bool:
    """Validate a backup file has correct schema.

    Args:
        backup_path: Path to backup file.

    Returns:
        True if valid, False otherwise.
    """
    try:
        conn = sqlite3.connect(backup_path)
        cursor = conn.cursor()

        # Check tables exist
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        )
        tables = [row[0] for row in cursor.fetchall()]

        required_tables = {"swarms", "nodes"}
        if not required_tables.issubset(set(tables)):
            log.error("Missing required tables in backup")
            conn.close()
            return False

        # Check schema matches
        cursor.execute("PRAGMA table_info(swarms)")
        swarm_cols = {row[1] for row in cursor.fetchall()}
        expected_swarm_cols = {
            "id",
            "manager_ip",
            "swarm_id",
            "worker_token",
            "manager_token",
            "manager_rate",
            "advertise_addr",
            "output_script",
            "proxy",
            "encrypted",
            "created_at",
            "status",
        }
        if not expected_swarm_cols.issubset(swarm_cols):
            log.error("Schema mismatch in swarms table")
            conn.close()
            return False

        cursor.execute("PRAGMA table_info(nodes)")
        node_cols = {row[1] for row in cursor.fetchall()}
        expected_node_cols = {
            "id",
            "swarm_id",
            "ip",
            "role",
            "status",
            "error",
            "joined_at",
            "updated_at",
        }
        if not expected_node_cols.issubset(node_cols):
            log.error("Schema mismatch in nodes table")
            conn.close()
            return False

        conn.close()
        log.info("Backup validation passed: %s", backup_path)
        return True

    except Exception as e:
        log.error("Backup validation failed: %s", e)
        return False


def backup_db(
    db_path: str | None = None,
    backup_path: str | None = None,
) -> str:
    """Create a backup of the database.

    Args:
        db_path: Source database path (default: DEFAULT_DB).
        backup_path: Destination backup path (auto-generated if None).

    Returns:
        Path to created backup file.
    """
    if db_path is None:
        db_path = DEFAULT_DB

    if backup_path is None:
        backup_path = get_default_backup_path()

    # Ensure source exists
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"Database not found: {db_path}")

    # Validate backup doesn't overwrite
    if os.path.exists(backup_path):
        raise FileExistsError(f"Backup already exists: {backup_path}")

    log.info("Creating backup: %s -> %s", db_path, backup_path)

    # Copy with large buffer for speed
    with open(db_path, "rb") as src, open(backup_path, "wb") as dst:
        while chunk := src.read(BUFFER_SIZE):
            dst.write(chunk)

    log.info("Backup complete: %s", backup_path)
    return backup_path


def restore_db(backup_path: str, db_path: str | None = None) -> None:
    """Restore database from backup.

    Args:
        backup_path: Path to backup file.
        db_path: Destination database path (default: DEFAULT_DB).
    """
    if db_path is None:
        db_path = DEFAULT_DB

    # Validate backup file
    if not os.path.exists(backup_path):
        raise FileNotFoundError(f"Backup not found: {backup_path}")

    if not validate_backup(backup_path):
        raise ValueError(f"Invalid or corrupted backup: {backup_path}")

    # Warn about existing DB
    if os.path.exists(db_path):
        bak_path = db_path + ".pre_restore"
        log.warning("Existing DB found, backing up to: %s", bak_path)
        shutil.copy2(db_path, bak_path)

    log.info("Restoring: %s -> %s", backup_path, db_path)

    # Copy backup to new location
    with open(backup_path, "rb") as src, open(db_path, "wb") as dst:
        while chunk := src.read(BUFFER_SIZE):
            dst.write(chunk)

    log.info("Restore complete: %s", db_path)


def check_db_integrity(db_path: str | None = None) -> bool:
    """Check database integrity.

    Args:
        db_path: Path to database (default: DEFAULT_DB).

    Returns:
        True if OK, False if issues found.
    """
    if db_path is None:
        db_path = DEFAULT_DB

    if not os.path.exists(db_path):
        log.error("Database not found: %s", db_path)
        return False

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Run integrity check
        cursor.execute("PRAGMA integrity_check")
        result = cursor.fetchone()[0]

        if result != "ok":
            log.error("Integrity check failed: %s", result)
            conn.close()
            return False

        # Check foreign keys
        cursor.execute("PRAGMA foreign_key_check")
        fk_violations = cursor.fetchall()
        if fk_violations:
            log.error("Foreign key violations: %s", fk_violations)
            conn.close()
            return False

        conn.close()
        log.info("Database integrity OK")
        return True

    except Exception as e:
        log.error("Integrity check error: %s", e)
        return False
