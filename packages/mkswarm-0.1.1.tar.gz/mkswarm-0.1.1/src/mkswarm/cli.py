"""CLI module for mkswarm.

This module provides the command-line interface for mkswarm.
"""

import argparse
import logging
import math
import os
import sys
from typing import Any

from docker.errors import APIError, DockerException

from .backup import backup_db, check_db_integrity, restore_db, validate_backup
from .crypto import decrypt_token, encrypt_token
from .db import DEFAULT_DB, KEY_ENV, SwarmDB
from .docker_client import DOCKER_PORT, check_reachable, configure_proxy, make_client
from .health import (
    continuous_health_check,
    health_check_swarm,
)
from .scripts import render_join_script
from .validation import load_ips

log = logging.getLogger("mkswarm")


def add_tls_args(p: argparse.ArgumentParser) -> None:
    """Add TLS arguments to an argument parser.

    Args:
        p: ArgumentParser or argument group to add arguments to.
    """
    g = p.add_argument_group("TLS")
    g.add_argument("--tls-cert", metavar="FILE", help="Client TLS certificate")
    g.add_argument("--tls-key", metavar="FILE", help="Client TLS key")
    g.add_argument(
        "--tls-ca", metavar="FILE", help="CA certificate for server verification"
    )


def add_proxy_key_args(p: argparse.ArgumentParser) -> None:
    """Add proxy and key arguments to an argument parser.

    Args:
        p: ArgumentParser to add arguments to.
    """
    p.add_argument(
        "-p",
        "--proxy",
        default=None,
        metavar="URL",
        help="Proxy URL (socks5://host:port, socks4://..., http://...)",
    )
    p.add_argument(
        "-k",
        "--key",
        default=os.environ.get(KEY_ENV),
        metavar="KEY",
        help=f"Fernet key for token encryption (or ${KEY_ENV} env var). "
        f'Generate one with: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"',
    )


def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser for mkswarm CLI.

    Returns:
        Configured ArgumentParser.
    """
    root = argparse.ArgumentParser(
        prog="mkswarm",
        description="Bootstrap and manage a Docker Swarm cluster.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    root.add_argument(
        "-d", "--db", default=DEFAULT_DB, metavar="FILE", help="SQLite3 database path"
    )
    root.add_argument("-v", "--verbose", action="store_true")
    root.add_argument("-q", "--quiet", action="store_true")
    root.add_argument("--log-file", metavar="FILE", help="Append logs to file")
    root.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview actions without contacting Docker or writing files",
    )

    sub = root.add_subparsers(dest="cmd", required=True)

    # init
    p_init = sub.add_parser("init", help="Bootstrap a new swarm")
    p_init.add_argument("-i", "--ips", required=True, metavar="FILE")
    p_init.add_argument("-m", "--manager", required=True, metavar="IP")
    p_init.add_argument(
        "-r",
        "--rate",
        required=True,
        type=float,
        metavar="FLOAT",
        help="Fraction of peer nodes to promote to managers [0.0-1.0]",
    )
    p_init.add_argument(
        "-o",
        "--output",
        required=True,
        metavar="FILE",
        help="Path for generated bash join-script",
    )
    p_init.add_argument(
        "-a",
        "--advertise-addr",
        default=None,
        metavar="IP:PORT",
        help=f"Advertise address for the swarm (default: <manager>:{DOCKER_PORT})",
    )
    add_proxy_key_args(p_init)
    add_tls_args(p_init)

    # run
    p_run = sub.add_parser("run", help="Join pending nodes via Docker SDK")
    p_run.add_argument("swarm_id", type=int, metavar="SWARM_ID")
    p_run.add_argument(
        "--parallel", type=int, default=1, metavar="N", help="Number of parallel joins"
    )
    p_run.add_argument("--progress", action="store_true", help="Show progress bars")
    add_proxy_key_args(p_run)
    add_tls_args(p_run)

    # status
    p_status = sub.add_parser("status", help="Show swarm state")
    p_status.add_argument("swarm_id", type=int, metavar="SWARM_ID")

    # list
    sub.add_parser("list", help="List all swarms")

    # reemit
    p_reemit = sub.add_parser("reemit", help="Regenerate join script from DB")
    p_reemit.add_argument("swarm_id", type=int, metavar="SWARM_ID")
    p_reemit.add_argument(
        "-o",
        "--output",
        default=None,
        metavar="FILE",
        help="Output path (default: original path from DB)",
    )
    add_proxy_key_args(p_reemit)

    # destroy
    p_destroy = sub.add_parser("destroy", help="Force-leave all nodes")
    p_destroy.add_argument("swarm_id", type=int, metavar="SWARM_ID")
    add_proxy_key_args(p_destroy)
    add_tls_args(p_destroy)

    # health
    p_health = sub.add_parser("health", help="Check health of swarm nodes")
    p_health.add_argument("swarm_id", type=int, metavar="SWARM_ID")
    p_health.add_argument(
        "--watch", action="store_true", help="Continuous health monitoring"
    )
    p_health.add_argument(
        "--interval", type=int, default=30, metavar="SECONDS", help="Check interval"
    )
    add_tls_args(p_health)

    # backup
    p_backup = sub.add_parser("backup", help="Backup database to a file")
    p_backup.add_argument("output", metavar="FILE", help="Output backup file path")

    # restore
    p_restore = sub.add_parser("restore", help="Restore database from backup")
    p_restore.add_argument("input", metavar="FILE", help="Input backup file path")

    return root


def setup_logging(args: argparse.Namespace) -> None:
    """Configure logging based on command-line arguments.

    Args:
        args: Parsed command-line arguments.
    """
    level = (
        logging.WARNING
        if args.quiet
        else (logging.DEBUG if args.verbose else logging.INFO)
    )
    fmt = "%(asctime)s %(levelname)s %(message)s"
    handlers: list[logging.Handler] = [logging.StreamHandler()]
    if args.log_file:
        handlers.append(logging.FileHandler(args.log_file))
    logging.basicConfig(level=level, format=fmt, handlers=handlers)


def cmd_init(args: argparse.Namespace, db: SwarmDB) -> None:
    """Initialize a new Docker Swarm.

    Args:
        args: Parsed command-line arguments.
        db: SwarmDB instance.
    """
    ips = load_ips(args.ips)
    if not ips:
        log.error("No IPs found in %r", args.ips)
        sys.exit(1)

    manager = args.manager
    advertise_addr = args.advertise_addr or f"{manager}:{DOCKER_PORT}"

    # Idempotency guard
    existing = db.find_ready_swarm(manager)
    if existing is not None:
        log.error(
            "A ready swarm for manager %s already exists (id=%d). "
            "Run 'destroy' first or use a different DB.",
            manager,
            existing,
        )
        sys.exit(1)

    peers = [ip for ip in ips if ip != manager]
    if not peers:
        log.error("No peer nodes after excluding manager IP")
        sys.exit(1)

    n_managers = math.ceil(len(peers) * args.rate)
    peer_roles = [
        (ip, "manager" if i < n_managers else "worker") for i, ip in enumerate(peers)
    ]

    if args.dry_run:
        log.info(
            "[dry-run] would init swarm on %s, %d peers (%d managers, %d workers)",
            manager,
            len(peers),
            n_managers,
            len(peers) - n_managers,
        )
        script = render_join_script(
            peer_roles, manager, "WTK", "MTK", advertise_addr, args.proxy
        )
        print(script)
        return

    check_reachable(manager)

    client = make_client(manager, args.tls_cert, args.tls_key, args.tls_ca)
    log.info("swarm leave --force on %s", manager)
    try:
        client.swarm.leave(force=True)
    except APIError as e:
        log.debug("swarm leave failed (ignored): %s", e)

    log.info("swarm init on %s", manager)
    client.swarm.init(
        advertise_addr=advertise_addr, listen_addr=f"0.0.0.0:{DOCKER_PORT}"
    )

    attrs = client.swarm.attrs
    swarm_id = attrs.get("ID", "")
    worker_token = attrs["JoinTokens"]["Worker"]
    manager_token = attrs["JoinTokens"]["Manager"]
    client.close()

    key = args.key
    swarm_rowid = db.create_swarm(
        manager_ip=manager,
        worker_token=encrypt_token(worker_token, key),
        manager_token=encrypt_token(manager_token, key),
        manager_rate=args.rate,
        advertise_addr=advertise_addr,
        output_script=os.path.abspath(args.output),
        swarm_id=swarm_id,
        proxy=args.proxy,
        encrypted=bool(key),
    )

    mgr_rowid = db.add_node(swarm_rowid, manager, "manager")
    db.set_node_status(mgr_rowid, "skipped")
    for ip, role in peer_roles:
        db.add_node(swarm_rowid, ip, role)

    script = render_join_script(
        peer_roles, manager, worker_token, manager_token, advertise_addr, args.proxy
    )
    with open(args.output, "w") as f:
        f.write(script)
    os.chmod(args.output, 0o755)
    log.info("wrote %s (%d nodes)", args.output, len(peer_roles))

    db.set_swarm_status(swarm_rowid, "ready")
    db.summary(swarm_rowid)


def cmd_run(args: argparse.Namespace, db: SwarmDB) -> None:
    """Execute pending node joins via Docker SDK.

    Args:
        args: Parsed command-line arguments.
        db: SwarmDB instance.
    """
    swarm = db.get_swarm(args.swarm_id)
    if not swarm:
        log.error("Swarm id=%d not found", args.swarm_id)
        sys.exit(1)
    if swarm["status"] != "ready":
        log.error(
            "Swarm id=%d is not in 'ready' state (status=%s)",
            args.swarm_id,
            swarm["status"],
        )
        sys.exit(1)

    key = args.key
    worker_token = decrypt_token(
        swarm["worker_token"], key if swarm["encrypted"] else None
    )
    manager_token = decrypt_token(
        swarm["manager_token"], key if swarm["encrypted"] else None
    )
    advertise_addr = swarm["advertise_addr"]

    pending = db.get_pending_nodes(args.swarm_id)
    if not pending:
        log.info("No pending nodes for swarm id=%d", args.swarm_id)
        db.summary(args.swarm_id)
        return

    log.info("%d pending node(s) to join", len(pending))

    for node in pending:
        ip = node["ip"]
        role = node["role"]
        token = manager_token if role == "manager" else worker_token

        if args.dry_run:
            log.info("[dry-run] would join %s as %s", ip, role)
            continue

        check_reachable(ip)
        log.info("joining %s as %s", ip, role)
        try:
            client = make_client(ip, args.tls_cert, args.tls_key, args.tls_ca)
            client.swarm.join(
                remote_addrs=[advertise_addr], join_token=token, advertise_addr=ip
            )
            client.close()
            db.set_node_status(node["id"], "joined")
            log.info("  %s joined OK", ip)
        except (DockerException, APIError) as e:
            db.set_node_status(node["id"], "failed", error=str(e))
            log.warning("  %s failed: %s", ip, e)

    db.summary(args.swarm_id)


def cmd_status(args: argparse.Namespace, db: SwarmDB) -> None:
    """Show swarm state from the database.

    Args:
        args: Parsed command-line arguments.
        db: SwarmDB instance.
    """
    swarm = db.get_swarm(args.swarm_id)
    if not swarm:
        log.error("Swarm id=%d not found", args.swarm_id)
        sys.exit(1)
    db.summary(args.swarm_id)


def cmd_list(_args: argparse.Namespace, db: SwarmDB) -> None:
    """List all swarms in the database.

    Args:
        args: Parsed command-line arguments.
        db: SwarmDB instance.
    """
    swarms = db.get_all_swarms()
    if not swarms:
        print("No swarms recorded.")
        return
    print(
        f"\n  {'id':<5} {'manager_ip':<18} {'swarm_id':<28} {'status':<12} created_at"
    )
    print(f"  {'-' * 5} {'-' * 18} {'-' * 28} {'-' * 12} {'-' * 26}")
    for s in swarms:
        sid = (s["swarm_id"] or "")[:26]
        print(
            f"  {s['id']:<5} {s['manager_ip']:<18} {sid:<28} {s['status']:<12} {s['created_at']}"
        )
    print()


def cmd_reemit(args: argparse.Namespace, db: SwarmDB) -> None:
    """Regenerate join script from database without touching Docker.

    Args:
        args: Parsed command-line arguments.
        db: SwarmDB instance.
    """
    swarm = db.get_swarm(args.swarm_id)
    if not swarm:
        log.error("Swarm id=%d not found", args.swarm_id)
        sys.exit(1)

    key = args.key
    worker_token = decrypt_token(
        swarm["worker_token"], key if swarm["encrypted"] else None
    )
    manager_token = decrypt_token(
        swarm["manager_token"], key if swarm["encrypted"] else None
    )

    nodes = [n for n in db.get_nodes(args.swarm_id) if n["status"] != "skipped"]
    peers = [(n["ip"], n["role"]) for n in nodes]

    script = render_join_script(
        peers,
        swarm["manager_ip"],
        worker_token,
        manager_token,
        swarm["advertise_addr"],
        swarm["proxy"],
    )

    out = args.output or swarm["output_script"]
    if args.dry_run:
        print(script)
        return

    with open(out, "w") as f:
        f.write(script)
    os.chmod(out, 0o755)
    log.info("reemitted %s (%d nodes)", out, len(peers))


def cmd_destroy(args: argparse.Namespace, db: SwarmDB) -> None:
    """Force-leave all nodes and mark swarm as destroyed.

    Args:
        args: Parsed command-line arguments.
        db: SwarmDB instance.
    """
    swarm = db.get_swarm(args.swarm_id)
    if not swarm:
        log.error("Swarm id=%d not found", args.swarm_id)
        sys.exit(1)

    nodes = [
        n for n in db.get_nodes(args.swarm_id) if n["status"] in ("joined", "pending")
    ]

    log.info("leaving %d node(s)", len(nodes))
    for node in nodes:
        ip = node["ip"]
        if args.dry_run:
            log.info("[dry-run] would leave %s", ip)
            continue
        try:
            check_reachable(ip)
            client = make_client(ip, args.tls_cert, args.tls_key, args.tls_ca)
            client.swarm.leave(force=True)
            client.close()
            db.set_node_status(node["id"], "left")
            log.info("  %s left", ip)
        except (DockerException, APIError, SystemExit) as e:
            log.warning("  %s failed to leave: %s", ip, e)
            db.set_node_status(node["id"], "failed", error=str(e))

    if not args.dry_run:
        db.set_swarm_status(args.swarm_id, "destroyed")
    db.summary(args.swarm_id)


def cmd_health(args: argparse.Namespace, db: SwarmDB) -> None:
    """Check health of swarm nodes.

    Args:
        args: Parsed command-line arguments.
        db: SwarmDB instance.
    """
    swarm = db.get_swarm(args.swarm_id)
    if not swarm:
        log.error("Swarm id=%d not found", args.swarm_id)
        sys.exit(1)

    if args.watch:
        continuous_health_check(args.swarm_id, interval=args.interval)
    else:
        results = health_check_swarm(args.swarm_id, db=db)
        if not results:
            log.error("No nodes for swarm id=%d", args.swarm_id)
            sys.exit(1)
        for node in results:
            status = "healthy" if node.status == "healthy" else "unhealthy"
            name = node.ip
            print(f"  {name} ({node.role}): {status}")
            if node.error:
                print(f"    error: {node.error}")
        healthy_count = sum(1 for n in results if n.status == "healthy")
        print(f"\n{healthy_count}/{len(results)} nodes healthy")


def cmd_backup(args: argparse.Namespace, db: SwarmDB) -> None:
    """Backup database to a file.

    Args:
        args: Parsed command-line arguments.
        db: SwarmDB instance.
    """
    backup_path = backup_db(args.db, args.output)
    integrity = check_db_integrity(backup_path)
    print(f"Backed up database to {backup_path}")
    if integrity:
        print("Backup integrity: OK")
    else:
        log.error("Backup integrity check failed!")
        sys.exit(1)


def cmd_restore(args: argparse.Namespace, db: SwarmDB) -> None:
    """Restore database from backup.

    Args:
        args: Parsed command-line arguments.
        db: SwarmDB instance.
    """
    if not validate_backup(args.input):
        log.error("Invalid backup file!")
        sys.exit(1)
    restore_db(args.input, args.db)
    print(f"Restored database from {args.input}")


def main() -> None:
    """Main entry point for mkswarm CLI."""
    parser = build_parser()
    args = parser.parse_args()
    setup_logging(args)

    if args.cmd == "init":
        if not (0.0 <= args.rate <= 1.0):
            log.error("--rate must be in [0.0, 1.0]")
            sys.exit(1)
        if getattr(args, "proxy", None):
            configure_proxy(args.proxy)

    if args.cmd in ("run", "destroy") and getattr(args, "proxy", None):
        configure_proxy(args.proxy)

    db = SwarmDB(args.db)
    try:
        dispatch: dict[str, Any] = {
            "init": cmd_init,
            "run": cmd_run,
            "status": cmd_status,
            "list": cmd_list,
            "reemit": cmd_reemit,
            "destroy": cmd_destroy,
            "health": cmd_health,
            "backup": cmd_backup,
            "restore": cmd_restore,
        }
        dispatch[args.cmd](args, db)
    except (DockerException, ValueError) as e:
        log.error("%s", e)
        sys.exit(1)
    finally:
        db.close()
