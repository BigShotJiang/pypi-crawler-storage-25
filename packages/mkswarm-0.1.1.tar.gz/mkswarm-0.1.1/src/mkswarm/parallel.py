"""Parallel execution module for mkswarm.

This module provides parallel node joining and progress bar functionality.
"""

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Any

from .crypto import decrypt_token
from .db import SwarmDB
from .docker_client import check_reachable, make_client

log = logging.getLogger("mkswarm")


@dataclass
class JoinResult:
    """Result of a node join operation."""

    node_id: int
    ip: str
    role: str
    success: bool
    error: str | None = None


def join_node(
    node: dict[str, Any],
    worker_token: str,
    manager_token: str,
    advertise_addr: str,
    tls_cert: str | None = None,
    tls_key: str | None = None,
    tls_ca: str | None = None,
) -> JoinResult:
    """Join a single node to the swarm.

    Args:
        node: Node dict with id, ip, role.
        worker_token: Worker join token.
        manager_token: Manager join token.
        advertise_addr: Swarm advertise address.
        tls_cert: TLS certificate path.
        tls_key: TLS key path.
        tls_ca: TLS CA path.

    Returns:
        JoinResult with success status.
    """
    ip = node["ip"]
    role = node["role"]
    node_id = node["id"]

    token = manager_token if role == "manager" else worker_token

    try:
        check_reachable(ip)
        log.debug("joining %s as %s", ip, role)

        client = make_client(ip, tls_cert, tls_key, tls_ca)
        client.swarm.join(
            remote_addrs=[advertise_addr],
            join_token=token,
            advertise_addr=ip,
        )
        client.close()

        return JoinResult(node_id=node_id, ip=ip, role=role, success=True)

    except Exception as e:
        return JoinResult(
            node_id=node_id,
            ip=ip,
            role=role,
            success=False,
            error=str(e),
        )


def parallel_join_nodes(
    nodes: list[dict[str, Any]],
    worker_token: str,
    manager_token: str,
    advertise_addr: str,
    workers: int = 4,
    tls_cert: str | None = None,
    tls_key: str | None = None,
    tls_ca: str | None = None,
    progress_callback: Any = None,
) -> list[JoinResult]:
    """Join multiple nodes in parallel.

    Args:
        nodes: List of node dicts.
        worker_token: Worker join token.
        manager_token: Manager join token.
        advertise_addr: Swarm advertise address.
        workers: Number of parallel workers.
        tls_cert: TLS certificate path.
        tls_key: TLS key path.
        tls_ca: TLS CA path.
        progress_callback: Optional callback(completed, total).

    Returns:
        List of JoinResult for each node.
    """
    results: list[JoinResult] = []
    completed = 0

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {
            executor.submit(
                join_node,
                node,
                worker_token,
                manager_token,
                advertise_addr,
                tls_cert,
                tls_key,
                tls_ca,
            ): node
            for node in nodes
        }

        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            completed += 1

            if progress_callback:
                progress_callback(completed, len(nodes))

    return results


def parallel_join_with_progress(
    nodes: list[dict[str, Any]],
    worker_token: str,
    manager_token: str,
    advertise_addr: str,
    workers: int = 4,
    tls_cert: str | None = None,
    tls_key: str | None = None,
    tls_ca: str | None = None,
    show_progress: bool = True,
) -> list[JoinResult]:
    """Join nodes in parallel with progress bar.

    Args:
        nodes: List of node dicts.
        worker_token: Worker join token.
        manager_token: Manager join token.
        advertise_addr: Swarm advertise address.
        workers: Number of parallel workers.
        tls_cert: TLS certificate path.
        tls_key: TLS key path.
        tls_ca: TLS CA path.
        show_progress: Show progress bar.

    Returns:
        List of JoinResult for each node.
    """
    if not show_progress or len(nodes) < 3:
        return parallel_join_nodes(
            nodes,
            worker_token,
            manager_token,
            advertise_addr,
            workers,
            tls_cert,
            tls_key,
            tls_ca,
        )

    try:
        from tqdm import tqdm

        pbar = tqdm(total=len(nodes), desc="Joining nodes", unit="node")

        def update_progress(completed: int, total: int) -> None:
            pbar.n = completed
            pbar.refresh()

        return parallel_join_nodes(
            nodes,
            worker_token,
            manager_token,
            advertise_addr,
            workers,
            tls_cert,
            tls_key,
            tls_ca,
            progress_callback=update_progress,
        )
    except ImportError:
        return parallel_join_nodes(
            nodes,
            worker_token,
            manager_token,
            advertise_addr,
            workers,
            tls_cert,
            tls_key,
            tls_ca,
        )


def run_parallel(
    args: Any,
    db: SwarmDB,
) -> None:
    """Execute parallel node joins.

    Args:
        args: Parsed command-line arguments.
        db: SwarmDB instance.
    """
    swarm = db.get_swarm(args.swarm_id)
    if not swarm:
        log.error("Swarm id=%d not found", args.swarm_id)
        return

    if swarm["status"] != "ready":
        log.error("Swarm id=%d is not in 'ready' state", args.swarm_id)
        return

    key = args.key
    worker_token = decrypt_token(
        swarm["worker_token"], key if swarm["encrypted"] else None
    )
    manager_token = decrypt_token(
        swarm["manager_token"], key if swarm["encrypted"] else None
    )
    advertise_addr = swarm["advertise_addr"]

    pending = db.get_pending_nodes(args.swarm_id)
    if not pending:
        log.info("No pending nodes for swarm id=%d", args.swarm_id)
        db.summary(args.swarm_id)
        return

    workers = getattr(args, "parallel", 4)
    if workers < 1:
        workers = 1
    if workers > 16:
        log.warning("Capping workers to 16 (was %d)", workers)
        workers = 16

    log.info("%d pending node(s) to join (workers=%d)", len(pending), workers)

    results = parallel_join_with_progress(
        pending,
        worker_token,
        manager_token,
        advertise_addr,
        workers=workers,
        tls_cert=args.tls_cert,
        tls_key=args.tls_key,
        tls_ca=args.tls_ca,
        show_progress=getattr(args, "progress", False),
    )

    for r in results:
        if r.success:
            db.set_node_status(r.node_id, "joined")
            log.info("  %s joined OK", r.ip)
        else:
            db.set_node_status(r.node_id, "failed", error=r.error)
            log.warning("  %s failed: %s", r.ip, r.error)

    db.summary(args.swarm_id)
