"""Main entry point for mkswarm CLI."""


from mkswarm import cli


def main() -> int:
    """Main entry point.

    Returns:
        Exit code.
    """
    cli.main()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
