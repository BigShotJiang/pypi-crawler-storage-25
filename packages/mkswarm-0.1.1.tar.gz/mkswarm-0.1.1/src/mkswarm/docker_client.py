"""Docker client module for mkswarm.

This module provides Docker client creation, proxy configuration,
and connectivity checking utilities.
"""

import logging
import socket
import sys
from urllib.parse import urlparse

import docker

log = logging.getLogger("mkswarm")

DOCKER_PORT = 2377
DOCKER_API_PORT = 2375


def check_reachable(host: str, port: int = DOCKER_API_PORT, timeout: int = 5) -> None:
    """Check if a host is reachable on the given port.

    Args:
        host: Hostname or IP address.
        port: Port number (default: 2375 for Docker API).
        timeout: Connection timeout in seconds.

    Raises:
        SystemExit: If host is unreachable.
    """
    log.debug("pre-check %s:%d", host, port)
    try:
        with socket.create_connection((host, port), timeout=timeout):
            pass
    except OSError as e:
        log.error("Manager %s:%d is unreachable: %s", host, port, e)
        sys.exit(1)
    log.debug("pre-check OK")


def configure_proxy(proxy_url: str) -> None:
    """Configure SOCKS or HTTP proxy for socket connections.

    Args:
        proxy_url: Proxy URL (socks4://, socks5://, or http://).

    Raises:
        SystemExit: If PySocks is not installed or proxy URL is invalid.
    """
    try:
        import socks
    except ImportError:
        log.error("PySocks not installed. Run: pip install PySocks")
        sys.exit(1)

    parsed = urlparse(proxy_url)
    scheme = parsed.scheme.lower()
    host, port = parsed.hostname, parsed.port
    user, passwd = parsed.username or None, parsed.password or None

    type_map = {"socks4": socks.SOCKS4, "socks5": socks.SOCKS5, "http": socks.HTTP}
    if scheme not in type_map:
        log.error(
            "Unsupported proxy scheme %r. Use socks4://, socks5://, or http://", scheme
        )
        sys.exit(1)
    if not host or not port:
        log.error("Cannot parse host/port from proxy URL %r", proxy_url)
        sys.exit(1)

    socks.set_default_proxy(
        type_map[scheme], host, port, rdns=True, username=user, password=passwd
    )
    socks.wrapmodule(socket)
    log.info("proxy: %s://%s:%d", scheme, host, port)


def make_client(
    host: str,
    tls_cert: str | None = None,
    tls_key: str | None = None,
    tls_ca: str | None = None,
) -> docker.DockerClient:
    """Create a Docker client for the given host.

    Args:
        host: Docker host IP address or hostname.
        tls_cert: Path to client TLS certificate.
        tls_key: Path to client TLS key.
        tls_ca: Path to CA certificate for server verification.

    Returns:
        Configured Docker client.

    Raises:
        DockerException: If client creation fails.

    Example:
        >>> client = make_client("192.168.1.1")
        >>> info = client.info()
        >>> client.close()
    """
    if tls_cert and tls_key:
        tls_config = docker.tls.TLSConfig(
            client_cert=(tls_cert, tls_key),
            ca_cert=tls_ca,
            verify=bool(tls_ca),
        )
        return docker.DockerClient(
            base_url=f"tcp://{host}:{DOCKER_API_PORT}", tls=tls_config, timeout=30
        )
    return docker.DockerClient(base_url=f"tcp://{host}:{DOCKER_API_PORT}", timeout=30)
