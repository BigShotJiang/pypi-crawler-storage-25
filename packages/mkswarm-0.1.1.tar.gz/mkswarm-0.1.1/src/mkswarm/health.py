"""Health check module for mkswarm.

This module provides health checking functionality for Docker Swarm nodes.
"""

import logging
import socket
from dataclasses import dataclass
from typing import Any

from .db import SwarmDB
from .docker_client import make_client

log = logging.getLogger("mkswarm")


@dataclass
class NodeHealth:
    """Health status for a single node."""

    ip: str
    role: str
    status: str
    docker_reachable: bool
    swarm_joined: bool
    manager_reachable: bool
    error: str | None = None


def health_check_node(host: str, timeout: int = 5) -> NodeHealth:
    """Check health of a single node.

    Args:
        host: Node IP address.
        timeout: Connection timeout in seconds.

    Returns:
        NodeHealth with status information.
    """
    result = NodeHealth(
        ip=host,
        role="unknown",
        status="unknown",
        docker_reachable=False,
        swarm_joined=False,
        manager_reachable=False,
        error=None,
    )

    # Check Docker API reachability
    try:
        with socket.create_connection((host, 2375), timeout=timeout):
            result.docker_reachable = True
    except OSError as e:
        result.error = f"unreachable: {e}"
        return result

    # Check if node can reach manager and is in swarm
    try:
        client = make_client(host)
        info = client.info()
        client.close()

        result.manager_reachable = True
        if info.get("Swarm", {}).get("NodeID"):
            result.swarm_joined = True
            result.status = "healthy"
    except Exception as e:
        result.error = f"swarm check failed: {e}"
        result.status = "unhealthy"

    return result


def health_check_swarm(
    swarm_id: int,
    db: SwarmDB | None = None,
    timeout: int = 5,
) -> list[NodeHealth]:
    """Check health of all nodes in a swarm.

    Args:
        swarm_id: Swarm ID to check.
        db: SwarmDB instance (will create if None).
        timeout: Connection timeout in seconds.

    Returns:
        List of NodeHealth results for all nodes.
    """
    if db is None:
        db = SwarmDB()

    try:
        swarm = db.get_swarm(swarm_id)
        if not swarm:
            log.error("Swarm id=%d not found", swarm_id)
            return []

        nodes = db.get_nodes(swarm_id)
        results: list[NodeHealth] = []

        for node in nodes:
            health = health_check_node(node["ip"], timeout=timeout)
            health.role = node["role"]
            results.append(health)

        return results
    finally:
        db.close()


def continuous_health_check(
    swarm_id: int,
    interval: int = 30,
    timeout: int = 5,
    stop_event: Any = None,
) -> None:
    """Run continuous health checks until stopped.

    Args:
        swarm_id: Swarm ID to monitor.
        interval: Seconds between checks.
        timeout: Connection timeout.
        stop_event: Threading event to signal stop.
    """
    import threading

    if stop_event is None:
        stop_event = threading.Event()

    db = SwarmDB()
    try:
        while not stop_event.is_set():
            results = health_check_swarm(swarm_id, db=db, timeout=timeout)

            healthy = sum(1 for r in results if r.status == "healthy")
            unhealthy = len(results) - healthy

            log.info(
                "health check: %d/%d nodes healthy (unreachable: %d)",
                healthy,
                len(results),
                unhealthy,
            )

            for r in results:
                if r.status != "healthy":
                    log.warning(
                        "node %s (%s): %s", r.ip, r.role, r.error or "unhealthy"
                    )

            stop_event.wait(interval)
    finally:
        db.close()


def monitor_swarm(
    swarm_id: int,
    interval: int = 30,
    timeout: int = 5,
    once: bool = False,
) -> None:
    """Monitor a swarm's health.

    Args:
        swarm_id: Swarm ID to monitor.
        interval: Seconds between checks.
        timeout: Connection timeout.
        once: Run only once if True.
    """
    db = SwarmDB()
    try:
        if once:
            results = health_check_swarm(swarm_id, db=db, timeout=timeout)
            _print_health_results(results)
        else:
            continuous_health_check(swarm_id, interval=interval, timeout=timeout)
    finally:
        db.close()


def _print_health_results(results: list[NodeHealth]) -> None:
    """Print health check results."""
    from rich.console import Console
    from rich.table import Table

    console = Console()

    table = Table(title="Swarm Health Check Results")
    table.add_column("IP")
    table.add_column("Role")
    table.add_column("Docker API")
    table.add_column("Swarm Joined")
    table.add_column("Status")
    table.add_column("Error")

    for r in results:
        table.add_row(
            r.ip,
            r.role,
            "✓" if r.docker_reachable else "✗",
            "✓" if r.swarm_joined else "✗",
            r.status,
            r.error or "-",
        )

    console.print(table)
