# src/context_engine/cli.py
"""CLI entry point for claude-context-engine."""
import asyncio
import json
import socket
import sys
from pathlib import Path

import click

from context_engine.config import load_config, PROJECT_CONFIG_NAME


def _configure_mcp(project_dir: Path) -> bool:
    """Write MCP server config to .mcp.json in the project directory.

    Returns True if the entry was added. Uses an atomic write so a crash or
    partial write can't destroy pre-existing MCP server entries in the file.
    """
    import os
    import tempfile

    mcp_path = project_dir / ".mcp.json"
    cce_bin = Path(sys.executable).parent / "cce"
    command = str(cce_bin) if cce_bin.exists() else "cce"

    entry = {"command": command, "args": ["serve", "--project-dir", str(project_dir)]}

    if mcp_path.exists():
        try:
            data = json.loads(mcp_path.read_text())
        except (json.JSONDecodeError, OSError):
            data = {}
    else:
        data = {}

    servers = data.setdefault("mcpServers", {})
    if "context-engine" in servers:
        return False  # already configured

    servers["context-engine"] = entry

    # Atomic write: serialise to a tempfile in the same dir, then rename.
    fd, tmp_name = tempfile.mkstemp(
        prefix=".mcp.json.", suffix=".tmp", dir=str(project_dir)
    )
    try:
        with os.fdopen(fd, "w") as f:
            f.write(json.dumps(data, indent=2) + "\n")
        os.replace(tmp_name, mcp_path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise
    return True


_CCE_CLAUDE_MD_MARKER = "## Context Engine (CCE)"

_CCE_CLAUDE_MD_BLOCK = """\
## Context Engine (CCE)

This project uses Claude Context Engine for intelligent code retrieval.

**IMPORTANT: You MUST use `context_search` instead of reading files directly**
when exploring the codebase, answering questions about code, or understanding
how things work. This is a hard requirement, not a suggestion. The `context_search`
MCP tool routes queries through the semantic search engine, which:
- Returns only the most relevant code chunks (not entire files)
- Tracks token savings automatically
- Provides confidence scores for each result

**When to use `context_search`:**
- Answering questions about the codebase ("how does X work?", "where is Y?")
- Exploring code structure or architecture
- Finding related code, functions, or patterns
- Any time you would otherwise read a file to understand it

**When to use `Read` instead:**
- You need to edit a specific file (read before editing)
- You need the exact, complete content of a known file path

Other useful MCP tools:
- `expand_chunk` — get full source for a compressed result
- `related_context` — find what calls/imports a function
- `session_recall` — retrieve decisions from past sessions
- `record_decision` — persist an important decision for future sessions

## Output Style

Be concise. Lead with the answer or action, not reasoning. Skip filler words,
preamble, and phrases like "I'll help you with that" or "Certainly!". Prefer
fragments over full sentences in explanations. No trailing summaries of what
you just did. One sentence if it fits.

Code blocks, file paths, commands, and error messages are always written in full.
"""


def _resolve_cce_cmd() -> str:
    """Find the globally installed cce binary path."""
    import shutil
    for candidate in [
        Path.home() / ".local" / "bin" / "cce",
        Path("/usr/local/bin/cce"),
    ]:
        if candidate.exists():
            return str(candidate)
    return shutil.which("cce") or "cce"


def _has_cce_hook(hook_list: list, marker: str) -> bool:
    """Check if a CCE hook already exists in a hooks list."""
    for entry in hook_list:
        for h in entry.get("hooks", []):
            if marker in h.get("command", ""):
                return True
    return False


def _ensure_session_hook(project_dir: Path) -> None:
    """Add Claude Code hooks so CCE status shows on startup."""
    settings_dir = project_dir / ".claude"
    settings_dir.mkdir(exist_ok=True)
    settings_path = settings_dir / "settings.local.json"

    if settings_path.exists():
        try:
            data = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, OSError):
            data = {}
    else:
        data = {}

    hooks = data.setdefault("hooks", {})
    cce_cmd = _resolve_cce_cmd()
    changed = False

    # SessionStart hook — show CCE status
    session_hooks = hooks.setdefault("SessionStart", [])
    if not _has_cce_hook(session_hooks, "cce status"):
        session_hooks.append({
            "matcher": "",
            "hooks": [{"type": "command", "command": f"{cce_cmd} status --oneline"}],
        })
        changed = True

    if changed:
        settings_path.write_text(json.dumps(data, indent=2) + "\n")
        click.echo("SessionStart hook installed for CCE status.")


def _ensure_claude_md(project_dir: Path) -> None:
    """Add CCE instructions to CLAUDE.md if not already present."""
    claude_md = project_dir / "CLAUDE.md"
    if claude_md.exists():
        existing = claude_md.read_text()
        if _CCE_CLAUDE_MD_MARKER in existing:
            return  # already has CCE block
        # Append to existing file
        new_content = existing.rstrip() + "\n\n" + _CCE_CLAUDE_MD_BLOCK
        claude_md.write_text(new_content)
        click.echo("CCE instructions appended to existing CLAUDE.md.")
    else:
        claude_md.write_text(_CCE_CLAUDE_MD_BLOCK)
        click.echo("CLAUDE.md created with CCE instructions.")


@click.group()
@click.version_option(package_name="claude-context-engine")
@click.option("--verbose", "-v", is_flag=True, help="Enable detailed logging output")
@click.pass_context
def main(ctx: click.Context, verbose: bool) -> None:
    """claude-context-engine — Local context engine for Claude Code."""
    ctx.ensure_object(dict)
    project_path = Path.cwd() / PROJECT_CONFIG_NAME
    ctx.obj["config"] = load_config(project_path=project_path if project_path.exists() else None)
    ctx.obj["verbose"] = verbose


@main.command()
@click.pass_context
def init(ctx: click.Context) -> None:
    """Initialize context engine and connect it to Claude Code."""
    from context_engine.indexer.git_hooks import install_hooks
    config = ctx.obj["config"]
    project_dir = Path.cwd()

    installed = install_hooks(str(project_dir))
    if installed:
        click.echo(f"Git hooks installed: {len(installed)} hooks")

    project_name = project_dir.name
    storage_dir = Path(config.storage_path) / project_name
    storage_dir.mkdir(parents=True, exist_ok=True)
    click.echo(f"Storage directory: {storage_dir}")

    # Persist the source path so `cce prune` can detect deleted projects.
    meta_path = storage_dir / "meta.json"
    meta_path.write_text(json.dumps({"project_dir": str(project_dir.resolve())}))

    configured = _configure_mcp(project_dir)
    if configured:
        click.echo("MCP server registered in .mcp.json — restart Claude Code to activate.")
    else:
        click.echo("MCP server already in .mcp.json.")

    _ensure_claude_md(project_dir)
    _ensure_session_hook(project_dir)

    # Add .cce/ to .gitignore
    from context_engine.project_commands import ensure_gitignore
    ensure_gitignore(str(project_dir))

    is_git_repo = (project_dir / ".git").exists()
    if not is_git_repo:
        click.echo(
            "Note: not a git repository — git history will not be indexed.\n"
            "To enable git indexing, run: git init && git add . && git commit -m 'init'"
        )

    click.echo("Running initial index...")
    asyncio.run(_run_index(config, str(project_dir), full=True))
    click.echo("Done. Restart Claude Code if this is your first time running init.")


@main.command()
@click.option("--full", is_flag=True, help="Force full re-index")
@click.option("--path", type=str, default=None, help="Index specific file/directory")
@click.option("--changed-only", is_flag=True, help="Only index changed files")
@click.pass_context
def index(ctx: click.Context, full: bool, path: str | None, changed_only: bool) -> None:
    """Index or re-index project files."""
    config = ctx.obj["config"]
    verbose = ctx.obj["verbose"]
    project_dir = path or str(Path.cwd())
    asyncio.run(_run_index(config, project_dir, full=full, verbose=verbose))
    click.echo("Indexing complete.")


@main.command()
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.option("--oneline", is_flag=True, help="Single-line status for hooks")
@click.pass_context
def status(ctx: click.Context, output_json: bool, oneline: bool) -> None:
    """Show index status and config."""
    import json as _json
    from importlib.metadata import version as pkg_version
    config = ctx.obj["config"]
    verbose = ctx.obj["verbose"]

    if oneline:
        try:
            ver = pkg_version("claude-context-engine")
        except Exception:
            ver = "?"
        project_name = Path.cwd().name
        storage = Path(config.storage_path) / project_name
        stats_path = storage / "stats.json"
        chunks = 0
        savings = ""
        try:
            from context_engine.storage.vector_store import VectorStore
            vs = VectorStore(db_path=str(storage / "vectors"))
            chunks = vs.count()
        except Exception:
            pass
        if stats_path.exists():
            try:
                stats = _json.loads(stats_path.read_text())
                q = stats.get("queries", 0)
                full = stats.get("full_file_tokens", 0)
                served = stats.get("served_tokens", 0)
                if q > 0 and full > 0:
                    pct = int((full - served) / full * 100)
                    savings = f" · {pct}% saved over {q} queries"
            except Exception:
                pass
        click.echo(
            f"CCE v{ver} · {project_name} · {chunks} chunks indexed{savings}\n"
            f"USE context_search MCP tool for all code questions. Do NOT use Read/Grep to explore code."
        )
        return

    if output_json:
        out = {
            "storage_path": config.storage_path,
            "compression_level": config.compression_level,
            "resource_profile": config.detect_resource_profile(),
        }
        click.echo(_json.dumps(out, indent=2))
        return

    click.echo(f"Storage path: {config.storage_path}")
    click.echo(f"Compression level: {config.compression_level}")
    click.echo(f"Resource profile: {config.detect_resource_profile()}")

    # Token savings
    project_name = Path.cwd().name
    stats_path = Path(config.storage_path) / project_name / "stats.json"
    if stats_path.exists():
        try:
            stats = _json.loads(stats_path.read_text())
            raw = stats.get("raw_tokens", 0)
            served = stats.get("served_tokens", 0)
            queries = stats.get("queries", 0)
            saved = raw - served
            pct = int(saved / raw * 100) if raw > 0 else 0
            click.echo(f"\nToken savings ({queries} queries):")
            click.echo(f"  Raw tokens:    {raw:,}")
            click.echo(f"  Served tokens: {served:,}")
            click.echo(f"  Saved:         {saved:,} ({pct}%)")
        except (KeyError, _json.JSONDecodeError):
            pass
    else:
        click.echo("\nToken savings: no usage recorded yet (run context_search via MCP)")

    if verbose:
        storage_path = Path(config.storage_path)
        if storage_path.exists():
            projects = [d for d in storage_path.iterdir() if d.is_dir()]
            click.echo(f"\nProjects indexed: {len(projects)}")
            for project in projects:
                chunks = list(project.glob("**/*.json"))
                click.echo(f"  {project.name}: {len(chunks)} stored files")
        else:
            click.echo("Storage directory does not exist yet.")


@main.group()
def commands():
    """Manage project-specific commands (before_push, before_commit, etc.)."""


@commands.command("add")
@click.argument("hook", type=click.Choice(["before_push", "before_commit", "on_start"]))
@click.argument("command")
def commands_add(hook: str, command: str) -> None:
    """Add a command to a hook. Example: cce commands add before_push 'composer test'"""
    from context_engine.project_commands import load_project_only, add_command
    existing = load_project_only(str(Path.cwd())).get(hook, [])
    if command in existing:
        click.echo(f"Already exists in {hook}: {command}")
        return
    add_command(str(Path.cwd()), hook, command)
    click.echo(f"Added to {hook}: {command}")


@commands.command("add-custom")
@click.argument("name")
@click.argument("command")
def commands_add_custom(name: str, command: str) -> None:
    """Add a named custom command. Example: cce commands add-custom deploy 'kubectl apply -f k8s/'"""
    from context_engine.project_commands import add_custom_command
    add_custom_command(str(Path.cwd()), name, command)
    click.echo(f"Added custom command '{name}': {command}")


@commands.command("remove")
@click.argument("hook")
@click.argument("command")
def commands_remove(hook: str, command: str) -> None:
    """Remove a command from a hook."""
    from context_engine.project_commands import remove_command
    if remove_command(str(Path.cwd()), hook, command):
        click.echo(f"Removed from {hook}: {command}")
    else:
        click.echo(f"Command not found in {hook}: {command}")


@commands.command("add-rule")
@click.argument("rule")
def commands_add_rule(rule: str) -> None:
    """Add a project rule. Example: cce commands add-rule 'Never use down() in migrations'"""
    from context_engine.project_commands import load_project_only, add_rule
    existing = load_project_only(str(Path.cwd())).get("rules", [])
    if rule in existing:
        click.echo(f"Rule already exists: {rule}")
        return
    add_rule(str(Path.cwd()), rule)
    click.echo(f"Rule added: {rule}")


@commands.command("remove-rule")
@click.argument("rule")
def commands_remove_rule(rule: str) -> None:
    """Remove a project rule."""
    from context_engine.project_commands import remove_rule
    if remove_rule(str(Path.cwd()), rule):
        click.echo(f"Rule removed: {rule}")
    else:
        click.echo(f"Rule not found: {rule}")


@commands.command("set-pref")
@click.argument("key")
@click.argument("value")
def commands_set_pref(key: str, value: str) -> None:
    """Set a preference. Example: cce commands set-pref database PostgreSQL"""
    from context_engine.project_commands import set_preference
    set_preference(str(Path.cwd()), key, value)
    click.echo(f"Preference set: {key} = {value}")


@commands.command("remove-pref")
@click.argument("key")
def commands_remove_pref(key: str) -> None:
    """Remove a preference."""
    from context_engine.project_commands import remove_preference
    if remove_preference(str(Path.cwd()), key):
        click.echo(f"Preference removed: {key}")
    else:
        click.echo(f"Preference not found: {key}")


@commands.command("list")
def commands_list() -> None:
    """Show all project commands, rules, and preferences (merged with workspace)."""
    from context_engine.project_commands import load_commands
    cmds = load_commands(str(Path.cwd()))
    if not cmds:
        click.echo("No project configuration found.")
        click.echo("  cce commands add-rule 'Never use down() in migrations'")
        click.echo("  cce commands set-pref database PostgreSQL")
        click.echo("  cce commands add before_push 'composer test'")
        return
    import yaml
    click.echo(yaml.dump(cmds, default_flow_style=False, sort_keys=False).rstrip())


@main.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("--all", "all_projects", is_flag=True, help="Show savings for all indexed projects")
@click.pass_context
def savings(ctx: click.Context, as_json: bool, all_projects: bool) -> None:
    """Show token savings report — how much CCE is saving you."""
    config = ctx.obj["config"]
    _run_savings_report(config, as_json=as_json, all_projects=all_projects)


def _run_savings_report(config, *, as_json: bool = False, all_projects: bool = False) -> None:
    """Shared implementation for savings report (used by subcommand and shortcut)."""
    import json as _json

    storage_root = Path(config.storage_path)

    def _load_stats(project_dir: Path) -> dict | None:
        stats_path = project_dir / "stats.json"
        if not stats_path.exists():
            return None
        try:
            return _json.loads(stats_path.read_text())
        except (KeyError, _json.JSONDecodeError):
            return None

    _USED = "⛁"
    _FREE = "⛶"
    _COLS = 10

    def _fmt_k(n: int) -> str:
        return f"{n / 1000:.1f}k" if n >= 1000 else str(n)

    def _grid_rows(used_pct: float, rows: int) -> list[str]:
        total = _COLS * rows
        filled = max(0, min(total, round(used_pct * total)))
        result = []
        for r in range(rows):
            cells = [
                _USED if r * _COLS + c < filled else _FREE
                for c in range(_COLS)
            ]
            result.append("     " + " ".join(cells))
        return result

    def _print_project(name: str, stats: dict) -> None:
        full_file = stats.get("full_file_tokens", 0)
        served = stats.get("served_tokens", 0)
        queries = stats.get("queries", 0)
        raw = stats.get("raw_tokens", 0)
        baseline = max(full_file, raw) if full_file > 0 else raw
        saved = max(0, baseline - served)
        used_pct = served / baseline if baseline > 0 else 0
        saved_pct = int((1 - used_pct) * 100) if baseline > 0 else 0
        used_pct_int = int(used_pct * 100)

        labels: list[str] = [
            f"  {name} · {queries:,} queries",
            f"  {_fmt_k(served)}/{_fmt_k(baseline)} tokens used ({used_pct_int}%)",
            "",
            "  Token savings",
            f"  {_USED} With CCE:    {served:>10,} tokens  ({used_pct_int}%)",
            f"  {_FREE} Tokens saved:{saved:>10,} tokens  ({saved_pct}%)",
        ]

        grid = _grid_rows(used_pct, rows=len(labels))
        click.echo()
        for g, l in zip(grid, labels):
            click.echo(f"{g}   {l}")

    def _json_entry(name: str, stats: dict) -> dict:
        full_file = stats.get("full_file_tokens", 0)
        raw = stats.get("raw_tokens", 0)
        served = stats.get("served_tokens", 0)
        baseline = max(full_file, raw) if full_file > 0 else raw
        saved = baseline - served
        return {
            "project": name,
            "queries": stats.get("queries", 0),
            "full_file_tokens": full_file,
            "served_tokens": served,
            "tokens_saved": saved,
            "savings_pct": int(saved / baseline * 100) if baseline > 0 else 0,
        }

    # Collect projects
    if all_projects:
        if not storage_root.exists():
            if as_json:
                click.echo(_json.dumps({"projects": []}))
            else:
                click.echo("No indexed projects found.")
            return
        project_dirs = sorted(
            (d for d in storage_root.iterdir() if d.is_dir()),
            key=lambda d: d.name,
        )
    else:
        project_name = Path.cwd().name
        project_dirs = [storage_root / project_name]

    reports: list[tuple[str, dict]] = []
    for pd in project_dirs:
        stats = _load_stats(pd)
        if stats is not None:
            reports.append((pd.name, stats))

    if not reports:
        if as_json:
            if all_projects:
                click.echo(_json.dumps({"projects": []}))
            else:
                click.echo(_json.dumps(_json_entry(Path.cwd().name, {
                    "raw_tokens": 0, "served_tokens": 0, "queries": 0,
                })))
        else:
            click.echo("No usage recorded yet.")
            click.echo("Run context_search queries via MCP to start tracking savings.")
        return

    if as_json:
        if all_projects:
            click.echo(_json.dumps(
                {"projects": [_json_entry(n, s) for n, s in reports]}, indent=2,
            ))
        else:
            click.echo(_json.dumps(_json_entry(*reports[0]), indent=2))
        return

    # Text output
    for name, stats in reports:
        _print_project(name, stats)
        if len(reports) > 1:
            click.echo()
            click.echo("  " + "─" * 52)

    if len(reports) > 1:
        total_raw = sum(s.get("raw_tokens", 0) for _, s in reports)
        total_served = sum(s.get("served_tokens", 0) for _, s in reports)
        total_queries = sum(s.get("queries", 0) for _, s in reports)
        total_saved = total_raw - total_served
        total_pct = int(total_saved / total_raw * 100) if total_raw > 0 else 0
        click.echo()
        click.echo(f"  Total across {len(reports)} projects · {total_queries:,} queries")
        click.echo(f"  {_FREE} Saved: {total_saved:,} tokens ({total_pct}%)")

    click.echo()


@main.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def clear(ctx: click.Context, yes: bool) -> None:
    """Clear all index data for the current project (vectors, FTS, graph, manifest)."""
    from context_engine.storage.local_backend import LocalBackend

    config = ctx.obj["config"]
    project_name = Path.cwd().name
    storage_dir = Path(config.storage_path) / project_name

    if not storage_dir.exists():
        click.echo(f"No index data found for '{project_name}'.")
        return

    if not yes:
        click.confirm(f"Clear all index data for '{project_name}'? This cannot be undone.", abort=True)

    backend = LocalBackend(base_path=str(storage_dir))
    asyncio.run(backend.clear())

    # Reset manifest so next index starts fresh
    manifest_path = storage_dir / "manifest.json"
    if manifest_path.exists():
        manifest_path.write_text(json.dumps({"__schema_version": 2, "files": {}}))

    # Reset stats
    stats_path = storage_dir / "stats.json"
    stats_path.write_text(json.dumps({"queries": 0, "raw_tokens": 0, "served_tokens": 0, "full_file_tokens": 0}))

    click.echo(f"Cleared index data for '{project_name}'. Run 'cce index' to re-index.")


@main.command()
@click.option("--dry-run", is_flag=True, help="Show what would be removed without deleting")
@click.pass_context
def prune(ctx: click.Context, dry_run: bool) -> None:
    """Remove index data for projects whose directories no longer exist."""
    import shutil
    config = ctx.obj["config"]
    storage_root = Path(config.storage_path)
    if not storage_root.exists():
        click.echo("No indexed projects found.")
        return

    removed = []
    kept = []
    for project_dir in sorted(storage_root.iterdir()):
        if not project_dir.is_dir():
            continue
        meta_path = project_dir / "meta.json"
        if not meta_path.exists():
            kept.append((project_dir.name, "(no meta.json — skipping)"))
            continue
        try:
            meta = json.loads(meta_path.read_text())
            source_path = Path(meta.get("project_dir", ""))
        except (json.JSONDecodeError, OSError):
            kept.append((project_dir.name, "(unreadable meta.json — skipping)"))
            continue

        if source_path and source_path.exists():
            kept.append((project_dir.name, str(source_path)))
        else:
            removed.append((project_dir.name, str(source_path), project_dir))

    if not removed:
        click.echo("Nothing to prune — all indexed projects still exist.")
        for name, path in kept:
            click.echo(f"  ✓ {name}  ({path})")
        return

    for name, path, storage_dir in removed:
        label = f"  {'[dry-run] would remove' if dry_run else '✗ removed'}  {name}  (source: {path})"
        if not dry_run:
            shutil.rmtree(storage_dir)
        click.echo(label)

    for name, path in kept:
        click.echo(f"  ✓ kept  {name}  ({path})")


def savings_shortcut() -> None:
    """Entry point for the `cce-savings` shortcut command."""
    import sys as _sys

    @click.command()
    @click.option("--json", "as_json", is_flag=True, help="Output as JSON")
    @click.option("--all", "all_projects", is_flag=True, help="Show all projects")
    def _cmd(as_json: bool, all_projects: bool) -> None:
        """Show CCE token savings — how much context compression is saving you."""
        project_path = Path.cwd() / PROJECT_CONFIG_NAME
        config = load_config(project_path=project_path if project_path.exists() else None)
        _run_savings_report(config, as_json=as_json, all_projects=all_projects)

    _cmd()


def _find_free_port() -> int:
    """Return an available TCP port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@main.command()
@click.option("--http", "as_http", is_flag=True, help="Start HTTP REST server instead of stdio MCP")
@click.option("--host", default="127.0.0.1", show_default=True, help="HTTP bind host (requires CCE_API_TOKEN for non-loopback)")
@click.option("--port", default=8765, show_default=True, help="HTTP port")
@click.option("--project-dir", default=None, help="Project directory (defaults to cwd)")
@click.pass_context
def serve(ctx: click.Context, as_http: bool, host: str, port: int, project_dir: str | None) -> None:
    """Start the MCP server (used by Claude Code).

    With --http, starts a REST server exposing the storage backend for remote
    backend clients. Binds loopback by default; exposing on other interfaces
    requires CCE_API_TOKEN to be set.
    """
    if project_dir:
        import os
        os.chdir(project_dir)
    if as_http:
        from context_engine.serve_http import run_http_server
        run_http_server(ctx.obj["config"], host=host, port=port)
        return
    from importlib.metadata import version as pkg_version
    try:
        ver = pkg_version("claude-context-engine")
    except Exception:
        ver = "unknown"
    click.echo(f"CCE v{ver} · Starting context engine MCP server...", err=True)
    asyncio.run(_run_serve(ctx.obj["config"]))


@main.command()
@click.option("--port", default=0, type=int, help="Port to listen on (0 = random free port)")
@click.option("--no-browser", is_flag=True, help="Don't open browser automatically")
@click.pass_context
def dashboard(ctx: click.Context, port: int, no_browser: bool) -> None:
    """Start the web dashboard for index inspection."""
    import webbrowser
    import uvicorn
    from context_engine.dashboard.server import create_app

    config = ctx.obj["config"]
    project_dir = Path.cwd()

    if port == 0:
        port = _find_free_port()

    url = f"http://localhost:{port}"
    click.echo(f"CCE Dashboard at {url}")
    click.echo("Press Ctrl+C to stop.")

    if not no_browser:
        webbrowser.open(url)

    app = create_app(config, project_dir)
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="error")


# ── services command group ────────────────────────────────────────────────────

@main.group(invoke_without_command=True)
@click.pass_context
def services(ctx: click.Context) -> None:
    """Show status of CCE services (Ollama, Dashboard)."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(services_status)


@services.command(name="status")
def services_status() -> None:
    """Show status of all CCE services."""
    from context_engine.services import get_ollama_status, get_dashboard_status, get_mcp_status

    rows = [
        get_ollama_status(),
        get_dashboard_status(),
        get_mcp_status(),
    ]

    click.echo(f"{'SERVICE':<12}{'STATUS':<10}DETAIL")
    click.echo("-" * 48)

    for row in rows:
        running = row["running"]
        status_text = "running" if running else "stopped"
        status_col = click.style(f"{status_text:<10}", fg="green" if running else "red")
        detail = row.get("detail", "")
        click.echo(f"{row['name']:<12}{status_col}  {detail}")


@services.command(name="start")
@click.argument("service", required=False, type=click.Choice(["ollama", "dashboard", "all"]), default="all")
@click.option("--port", default=8080, show_default=True, help="Dashboard port (only used when starting dashboard)")
def services_start(service: str, port: int) -> None:
    """Start CCE services. SERVICE: ollama | dashboard | all (default)."""
    from context_engine.services import start_ollama, start_dashboard

    targets = ["ollama", "dashboard"] if service == "all" else [service]

    for target in targets:
        if target == "ollama":
            ok, msg = start_ollama()
        else:
            ok, msg = start_dashboard(port=port)
        prefix = click.style("✓", fg="green") if ok else click.style("·", fg="yellow")
        click.echo(f"  {prefix} {msg}")


@services.command(name="stop")
@click.argument("service", required=False, type=click.Choice(["ollama", "dashboard", "all"]), default="all")
def services_stop(service: str) -> None:
    """Stop CCE services. SERVICE: ollama | dashboard | all (default)."""
    from context_engine.services import stop_ollama, stop_dashboard

    targets = ["ollama", "dashboard"] if service == "all" else [service]

    for target in targets:
        if target == "ollama":
            ok, msg = stop_ollama()
        else:
            ok, msg = stop_dashboard()
        prefix = click.style("✓", fg="green") if ok else click.style("·", fg="yellow")
        click.echo(f"  {prefix} {msg}")


async def _run_index(config, project_dir: str, full: bool = False, verbose: bool = False) -> None:
    """Run indexing pipeline (thin wrapper over `indexer.pipeline.run_indexing`)."""
    from context_engine.indexer.pipeline import run_indexing

    log_fn = (lambda msg: click.echo(msg)) if verbose else None
    result = await run_indexing(config, project_dir, full=full, log_fn=log_fn)
    for err in result.errors:
        click.echo(f"Error: {err}", err=True)
    click.echo(
        f"Indexed {result.total_chunks} chunks from {len(result.indexed_files)} files"
        + (f", pruned {len(result.deleted_files)} deleted" if result.deleted_files else "")
        + (f", skipped {len(result.skipped_files)} non-text" if result.skipped_files else "")
    )


async def _run_serve(config) -> None:
    """Start MCP server."""
    from context_engine.storage.local_backend import LocalBackend
    from context_engine.indexer.embedder import Embedder
    from context_engine.retrieval.retriever import HybridRetriever
    from context_engine.compression.compressor import Compressor
    from context_engine.integration.mcp_server import ContextEngineMCP

    project_name = Path.cwd().name
    storage_base = Path(config.storage_path) / project_name
    backend = LocalBackend(base_path=str(storage_base))
    embedder = Embedder(model_name=config.embedding_model)
    retriever = HybridRetriever(backend=backend, embedder=embedder)
    compressor = Compressor(model=config.compression_model)
    mcp = ContextEngineMCP(
        retriever=retriever, backend=backend, compressor=compressor,
        embedder=embedder, config=config,
    )
    chunk_count = backend._vector_store.count()
    import sys
    print(f"CCE ready · {project_name} · {chunk_count} chunks indexed", file=sys.stderr)
    await mcp.run_stdio()
