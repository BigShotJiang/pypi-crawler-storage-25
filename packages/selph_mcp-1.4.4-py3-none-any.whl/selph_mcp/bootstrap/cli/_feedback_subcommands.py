"""Feedback and retry-reports CLI subcommands for selph-mcp-bootstrap (Phase 1 + 2, §8.2).

Subcommands:
- ``feedback "<text>"`` — record user feedback to the local flush spool
  and trigger an immediate flush to the server.
- ``retry-reports`` — Phase 2 stub. In v1 the bridge-CLI retry store is
  empty (``register`` is carved out per §6; it is the only bridge write).
  Remote-MCP retries happen in the active conversation, not via CLI.
  This subcommand prints a friendly message and exits 0.
"""
from __future__ import annotations

import argparse
import logging

from selph_mcp._log import get_logger, log_event
from ._envelope import err_envelope, ok_envelope

_log = get_logger("selph_mcp.bootstrap.cli.feedback")


def _cmd_feedback(args: argparse.Namespace) -> int:
    """feedback "<text>"

    Appends a feedback record to the local flush spool
    (``~/.config/selph-mcp/reports.jsonl``) and attempts an immediate
    flush to ``POST /apps/mcp/failure_reports``.

    The flush is best-effort: if the server is unreachable the record
    stays on disk and will be flushed on the next adapter activation.
    """
    note: str = (getattr(args, "note", None) or "").strip()
    if not note:
        return err_envelope(
            error_type="MissingArgument",
            message="feedback requires a non-empty text argument.",
        )

    log_event(_log, logging.INFO, "cli.feedback.entry", note_len=len(note))

    try:
        from selph_mcp.skill.runtime._failure_log import record_feedback, flush
        record_feedback(note)
        log_event(_log, logging.INFO, "cli.feedback.recorded")
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "cli.feedback.record_failed",
            error_type=type(exc).__name__,
            error=str(exc)[:200],
        )
        return err_envelope(exc)

    # Best-effort flush — load credentials and attempt a sync POST.
    flushed = False
    try:
        import httpx
        from selph_mcp.bootstrap.credentials import load_credentials
        from selph_mcp.skill.runtime._failure_log import flush

        creds = load_credentials()
        if creds and creds.get("api_url") and creds.get("bearer_token") and creds.get("consumer_id"):
            api_url: str = creds["api_url"].rstrip("/")
            with httpx.Client(
                base_url=api_url,
                headers={
                    "Authorization": f"Bearer {creds['bearer_token']}",
                    "X-Consumer-Id": creds["consumer_id"],
                    "Content-Type": "application/json",
                },
                timeout=15.0,
            ) as client:
                flush(client)
            flushed = True
            log_event(_log, logging.INFO, "cli.feedback.flushed")
    except Exception as exc:  # noqa: BLE001 — best-effort
        log_event(
            _log, logging.WARNING, "cli.feedback.flush_failed",
            error_type=type(exc).__name__,
            error=str(exc)[:200],
        )

    ok_envelope({"recorded": True, "flushed": flushed, "note_len": len(note)})
    log_event(_log, logging.INFO, "cli.feedback.complete", flushed=flushed)
    return 0


def _cmd_retry_reports(args: argparse.Namespace) -> int:
    """retry-reports

    Surfaces any bridge-CLI retryable entries from the local retry store
    and drives the user-confirmed replay flow.

    In v1, the bridge-CLI retry store is always empty: ``register`` (the
    only current bridge write) is explicitly carved out of retry scope per
    §6 of the failure-feedback strategy brief. Remote-MCP retries happen
    in the active conversation when the assistant re-issues the tool call
    with ``retry_for_event_id`` set — not via CLI.

    This subcommand is a no-op stub for v1. It prints a friendly envelope
    so callers always get a well-formed ``{"ok": true, ...}`` response.
    """
    log_event(_log, logging.INFO, "mcp.bootstrap.retry_reports.entry")

    message = (
        "No bridge-CLI retryables pending. "
        "Remote-MCP retries happen in conversation — the assistant re-issues "
        "the relevant action with your confirmation."
    )

    ok_envelope({"retryables": 0, "message": message})
    log_event(_log, logging.INFO, "mcp.bootstrap.retry_reports.complete", retryables=0)
    return 0


__all__ = ["_cmd_feedback", "_cmd_retry_reports"]
