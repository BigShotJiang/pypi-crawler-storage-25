"""Console script entry point for ``selph-mcp-hook`` (Phase G ambient capture).

Reads stdin JSON, branches by hook event (UserPromptSubmit | Stop | SessionEnd),
and dispatches to the local session spool.

Design invariants:
- Always exits 0. The hook MUST NOT crash Claude Code sessions.
- Wraps the entire dispatch in try/except BaseException.
- Every allocation names its closer (httpx client uses ``with`` block).
- HTTP-boundary parsing: direct dict-key access, KeyError on drift.
- No imports from ingestion_api / selph_core / selph_db / selph_graph.

Import constraints: stdlib + selph_mcp.skill.* + httpx.
"""

from __future__ import annotations

import os
import subprocess
import sys
import traceback
from pathlib import Path
from typing import Optional

# ── helpers (split for line-count) ────────────────────────────────────────────
from ._hook_helpers import (
    derive_session_id,
    find_selph_workspace,
    parse_last_tool_calls,
    perform_http_flush,
    read_stdin_json,
    read_workspace_credentials,
    setup_hook_logger,
)


def main() -> int:
    """Console-script entry point — always exits 0."""
    log = setup_hook_logger()
    try:
        rc = _dispatch(log)
        return rc
    except BaseException as exc:  # noqa: BLE001
        try:
            log.error(
                "hook_dispatch.unhandled_exception",
                extra={
                    "event": "hook_dispatch.unhandled_exception",
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:300],
                    "traceback": traceback.format_exc()[:2000],
                },
            )
        except Exception:
            sys.stderr.write(f"[selph-mcp-hook] fatal: {exc}\n")
    return 0


def _dispatch(log) -> int:
    """Inner dispatch — may raise; caller catches BaseException."""
    import argparse

    parser = argparse.ArgumentParser(
        prog="selph-mcp-hook",
        description="Selph ambient capture hook dispatcher.",
        add_help=False,
    )
    parser.add_argument(
        "event_name",
        choices=["UserPromptSubmit", "Stop", "SessionEnd"],
    )
    try:
        args = parser.parse_args()
    except SystemExit:
        return 0

    event_name: str = args.event_name

    log.info(
        "hook_dispatch.entry",
        extra={"event": "hook_dispatch.entry", "hook_event": event_name},
    )

    # ── Read stdin JSON (non-blocking) ────────────────────────────────────────
    stdin_data = read_stdin_json(timeout=0.5)

    # ── Resolve workspace ─────────────────────────────────────────────────────
    cwd_str = (
        (stdin_data or {}).get("cwd")
        or os.environ.get("CLAUDE_PROJECT_DIR")
        or os.getcwd()
    )
    cwd = Path(cwd_str).resolve()

    workspace = _resolve_workspace(cwd, log)
    if workspace is None:
        log.debug(
            "hook_dispatch.no_workspace",
            extra={"event": "hook_dispatch.no_workspace", "cwd": str(cwd)},
        )
        return 0

    # ── Read credentials ──────────────────────────────────────────────────────
    creds = read_workspace_credentials(workspace)
    if not creds:
        log.debug(
            "hook_dispatch.no_credentials",
            extra={
                "event": "hook_dispatch.no_credentials",
                "workspace": str(workspace),
            },
        )
        return 0

    user_id: Optional[str] = creds.get("user_id")
    if not user_id:
        log.debug(
            "hook_dispatch.no_user_id",
            extra={
                "event": "hook_dispatch.no_user_id",
                "workspace": str(workspace),
            },
        )
        return 0

    session_id = derive_session_id(workspace, stdin_data)

    # ── Branch by event ───────────────────────────────────────────────────────
    if event_name == "UserPromptSubmit":
        return _handle_user_prompt_submit(
            workspace, session_id, user_id, stdin_data, cwd, log
        )
    elif event_name == "Stop":
        return _handle_stop(workspace, session_id, stdin_data, log)
    elif event_name == "SessionEnd":
        return _handle_session_end(workspace, session_id, user_id, creds, log)

    return 0


# ── Workspace resolver (primary + ancestor walk) ──────────────────────────────

def _resolve_workspace(cwd: Path, log) -> Optional[Path]:
    """Try resolve_workspace_root first; then ancestor walk."""
    try:
        from selph_mcp.skill.bootstrap import resolve_workspace_root
        ws = resolve_workspace_root(start=cwd)
        if (ws / ".selph" / "state" / "onboarding.json").exists():
            return ws
    except Exception as exc:  # noqa: BLE001
        log.debug(
            "hook_dispatch.resolve_workspace_failed",
            extra={
                "event": "hook_dispatch.resolve_workspace_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )

    # Ancestor walk fallback
    return find_selph_workspace(cwd, max_levels=10)


# ── UserPromptSubmit ──────────────────────────────────────────────────────────

def _handle_user_prompt_submit(workspace, session_id, user_id, stdin_data, cwd, log) -> int:
    prompt = (stdin_data or {}).get("prompt") or ""

    try:
        from selph_mcp.skill.runtime import append_turn_auto_idx, evaluate_trigger
        metadata = {"hook_event": "UserPromptSubmit", "cwd": str(cwd)}
        assigned_idx = append_turn_auto_idx(
            workspace=workspace,
            session_id=session_id,
            role="user",
            content=prompt,
            metadata=metadata,
        )
        log.info(
            "hook_dispatch.user_turn_appended",
            extra={
                "event": "hook_dispatch.user_turn_appended",
                "session_id": session_id,
                "turn_idx": assigned_idx,
            },
        )
    except Exception as exc:  # noqa: BLE001
        log.warning(
            "hook_dispatch.user_turn_append_failed",
            extra={
                "event": "hook_dispatch.user_turn_append_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return 0

    # Evaluate whether to trigger a background flush
    try:
        should, reason = evaluate_trigger(
            workspace, session_id, is_session_start=False, last_flushed_turn_idx=-1
        )
        if should:
            # async-safety §2: parent process exits within <50ms; child has bounded
            # work (httpx 30s timeout); start_new_session=True detaches from parent
            # process group; OS init reaps the orphan after it completes. No closer
            # required because no resource (fd, asyncio task, DB conn) is retained
            # in the parent.
            subprocess.Popen(
                [
                    sys.executable, "-m", "selph_mcp.bootstrap.cli",
                    "session-do-flush",
                    "--workspace", str(workspace),
                    "--session-id", session_id,
                    "--user-id", user_id,
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
                close_fds=True,
            )
            log.info(
                "hook_dispatch.flush_triggered",
                extra={
                    "event": "hook_dispatch.flush_triggered",
                    "session_id": session_id,
                    "reason": reason,
                },
            )
    except Exception as exc:  # noqa: BLE001
        log.warning(
            "hook_dispatch.flush_trigger_failed",
            extra={
                "event": "hook_dispatch.flush_trigger_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )

    return 0


# ── Stop ──────────────────────────────────────────────────────────────────────

def _handle_stop(workspace, session_id, stdin_data, log) -> int:
    last_msg = (stdin_data or {}).get("last_assistant_message") or ""
    transcript_path = (stdin_data or {}).get("transcript_path")

    metadata = parse_last_tool_calls(transcript_path, log)

    try:
        from selph_mcp.skill.runtime import append_turn_auto_idx
        assigned_idx = append_turn_auto_idx(
            workspace=workspace,
            session_id=session_id,
            role="assistant",
            content=last_msg,
            metadata=metadata,
        )
        log.info(
            "hook_dispatch.assistant_turn_appended",
            extra={
                "event": "hook_dispatch.assistant_turn_appended",
                "session_id": session_id,
                "turn_idx": assigned_idx,
            },
        )
    except Exception as exc:  # noqa: BLE001
        log.warning(
            "hook_dispatch.assistant_turn_append_failed",
            extra={
                "event": "hook_dispatch.assistant_turn_append_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )

    # Do NOT trigger flush on Stop (latency-sensitive path)
    return 0


# ── SessionEnd ────────────────────────────────────────────────────────────────

def _handle_session_end(workspace, session_id, user_id, creds, log) -> int:
    """Flush spool to server on SessionEnd.

    Delegates HTTP logic to perform_http_flush (in _hook_helpers.py) which
    carries the correct 409-envelope parsing and URL construction.
    """
    return perform_http_flush(workspace, session_id, user_id, log)


# flush_attempt_count helpers live in _hook_helpers.py (perform_http_flush).
