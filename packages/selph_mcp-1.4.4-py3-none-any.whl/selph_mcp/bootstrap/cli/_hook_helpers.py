"""Helper utilities for hook_dispatch.py (Phase G).

Split from hook_dispatch to keep both files within the 300-line cap.
Import constraints: stdlib only + selph_mcp.skill.* + httpx.
No imports from ingestion_api / selph_core / selph_db / selph_graph.
"""

from __future__ import annotations

import json
import logging
import os
import select
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── logger setup ─────────────────────────────────────────────────────────────

_LOG_MAX_BYTES = 1_000_000
_LOG_BACKUP_COUNT = 3


def setup_hook_logger(name: str = "selph_mcp.hook_dispatch") -> logging.Logger:
    """Set up a RotatingFileHandler on ~/.selph-hook.log; fall back to /dev/null."""
    log = logging.getLogger(name)
    if log.handlers:
        return log
    log.setLevel(logging.DEBUG)

    log_path = Path.home() / ".selph-hook.log"
    try:
        handler: logging.Handler = RotatingFileHandler(
            str(log_path),
            maxBytes=_LOG_MAX_BYTES,
            backupCount=_LOG_BACKUP_COUNT,
        )
    except OSError as exc:
        handler = logging.FileHandler(os.devnull)
        # Can't log the error to itself; write to stderr as last resort
        sys.stderr.write(
            f"[selph-mcp-hook] could not open {log_path}: {exc}\n"
        )
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    handler.setFormatter(fmt)
    log.addHandler(handler)
    return log


# ── stdin JSON reader ─────────────────────────────────────────────────────────

def read_stdin_json(timeout: float = 0.5) -> Optional[Dict[str, Any]]:
    """Non-blocking read of stdin JSON; returns None on empty or parse error."""
    try:
        rlist, _, _ = select.select([sys.stdin], [], [], timeout)
        if not rlist:
            return None
        raw = sys.stdin.read()
        if not raw.strip():
            return None
        return json.loads(raw)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        logging.getLogger("selph_mcp.hook_dispatch").warning(
            "hook_dispatch.read_stdin_json_failed",
            extra={
                "event": "hook_dispatch.read_stdin_json_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return None


# ── workspace anchor detection ────────────────────────────────────────────────

def find_selph_workspace(cwd: Path, max_levels: int = 10) -> Optional[Path]:
    """Walk up from cwd looking for the first ancestor with .selph/state/onboarding.json.

    Returns the Path if found within max_levels, else None.
    """
    current = cwd.resolve()
    for _ in range(max_levels + 1):
        if (current / ".selph" / "state" / "onboarding.json").exists():
            return current
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


# ── credentials reader ────────────────────────────────────────────────────────

def read_workspace_credentials(workspace: Path) -> Optional[Dict[str, Any]]:
    """Read .selph/state/credentials.json; return dict or None."""
    creds_path = workspace / ".selph" / "state" / "credentials.json"
    if not creds_path.exists():
        return None
    try:
        return json.loads(creds_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logging.getLogger("selph_mcp.hook_dispatch").warning(
            "hook_dispatch.read_credentials_failed",
            extra={
                "event": "hook_dispatch.read_credentials_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return None


# ── session_id derivation ─────────────────────────────────────────────────────

def derive_session_id(workspace: Path, stdin_data: Optional[Dict[str, Any]]) -> str:
    """Derive a stable session_id for this workspace.

    Uses stdin['session_id'] when present; otherwise hashes the workspace
    path to produce a stable per-workspace default. This is not a real
    session UUID but is sufficient for single-workspace ambient capture.
    """
    if stdin_data and stdin_data.get("session_id"):
        return str(stdin_data["session_id"])
    import hashlib
    return "ws-" + hashlib.sha1(str(workspace).encode()).hexdigest()[:16]


# ── transcript tool-call parser ───────────────────────────────────────────────

def parse_last_tool_calls(
    transcript_path: Optional[str],
    log: logging.Logger,
) -> Dict[str, Any]:
    """Best-effort parse of last assistant tool_use blocks from JSONL transcript.

    Returns dict with either:
      {"hook_event": "Stop", "tool_calls": [...]}   on success
      {"hook_event": "Stop", "tool_calls_parse_error": "<msg>"}  on failure
    """
    if not transcript_path:
        return {"hook_event": "Stop", "tool_calls_parse_error": "no_transcript_path"}

    try:
        tp = Path(transcript_path)
        if not tp.exists():
            return {"hook_event": "Stop", "tool_calls_parse_error": "transcript_not_found"}

        # Read last 100 lines of JSONL to find last assistant entry
        lines: List[str] = []
        with tp.open("r", encoding="utf-8", errors="replace") as fh:
            # Efficient tail read
            for line in fh:
                lines.append(line)
                if len(lines) > 100:
                    lines.pop(0)

        last_assistant: Optional[Dict[str, Any]] = None
        for line in reversed(lines):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(obj, dict) and obj.get("role") == "assistant":
                last_assistant = obj
                break

        if last_assistant is None:
            return {"hook_event": "Stop", "tool_calls_parse_error": "no_assistant_entry_found"}

        content = last_assistant.get("content", [])
        tool_use_blocks = [
            block for block in content
            if isinstance(block, dict) and block.get("type") == "tool_use"
        ]
        return {"hook_event": "Stop", "tool_calls": tool_use_blocks}

    except Exception as exc:
        log.warning(
            "hook_dispatch.parse_tool_calls_failed",
            extra={
                "event": "hook_dispatch.parse_tool_calls_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return {"hook_event": "Stop", "tool_calls_parse_error": str(exc)[:200]}


# ── HTTP flush logic ──────────────────────────────────────────────────────────

def perform_http_flush(
    workspace: Path,
    session_id: str,
    user_id: str,
    log: logging.Logger,
) -> int:
    """POST pending spool turns to the server session-ingest endpoint.

    This is the single authoritative HTTP flush implementation shared by:
      - ``hook_dispatch._handle_session_end`` (SessionEnd hook, sync path)
      - ``_state_subcommands._cmd_session_do_flush`` (background spawn path)

    HTTP-boundary contract (rules/async-safety.md §6):
      200 response: direct key access ``resp_json["acked_through_turn_idx"]``
      409 response: FastAPI wraps the detail model under ``resp_json["detail"]``,
                    so the acked index lives at ``resp_json["detail"]["acked_through_turn_idx"]``

    Always returns 0 — the hook must never crash Claude Code sessions.
    """
    from selph_mcp.skill.runtime import (
        force_flush_payload,
        on_flush_success,
        on_flush_failure,
        on_flush_409,
    )
    from selph_mcp.skill.runtime._session_spool import _spool_db_path

    creds = read_workspace_credentials(workspace)
    if not creds:
        log.warning(
            "hook_dispatch.perform_http_flush.no_credentials",
            extra={
                "event": "hook_dispatch.perform_http_flush.no_credentials",
                "workspace": str(workspace),
            },
        )
        return 0

    api_url: Optional[str] = (
        creds.get("api_url")
        or creds.get("engine_base_url")
        or creds.get("mcp_endpoint")
    )
    bearer_token: Optional[str] = creds.get("bearer_token")
    consumer_id: Optional[str] = creds.get("consumer_id")

    if not api_url or not bearer_token:
        log.warning(
            "hook_dispatch.perform_http_flush.missing_creds",
            extra={
                "event": "hook_dispatch.perform_http_flush.missing_creds",
                "has_url": bool(api_url),
                "has_token": bool(bearer_token),
                "has_consumer_id": bool(consumer_id),
            },
        )
        return 0

    if not consumer_id:
        log.warning(
            "hook_dispatch.perform_http_flush.missing_consumer_id",
            extra={
                "event": "hook_dispatch.perform_http_flush.missing_consumer_id",
                "workspace": str(workspace),
            },
        )
        return 0

    payload = force_flush_payload(workspace, session_id, user_id)
    if payload is None:
        log.info(
            "hook_dispatch.perform_http_flush.no_pending",
            extra={
                "event": "hook_dispatch.perform_http_flush.no_pending",
                "session_id": session_id,
            },
        )
        return 0

    db_path = _spool_db_path(workspace)
    attempt_id: str = payload["attempt_id"]
    ingest_url = api_url.rstrip("/") + "/core/observe/ingest/selph/session"

    # Read current flush_attempt_count from spool_meta
    flush_attempt_count = _read_flush_attempt_count_helper(db_path, log)

    try:
        import httpx
        # async-safety §2: httpx.Client closed via the with-block closer
        with httpx.Client(timeout=30.0) as client:
            response = client.post(
                ingest_url,
                json=payload,
                headers={
                    "Authorization": f"Bearer {bearer_token}",
                    "X-Consumer-Id": consumer_id,
                    "Content-Type": "application/json",
                },
            )

        if response.status_code == 200:
            resp_json = response.json()
            # 200: acked_through_turn_idx is at the top level (not wrapped)
            server_acked = resp_json["acked_through_turn_idx"]  # KeyError on drift
            on_flush_success(db_path, session_id, attempt_id, server_acked)
            _reset_flush_attempt_count_helper(db_path, log)
            log.info(
                "hook_dispatch.perform_http_flush.ok",
                extra={
                    "event": "hook_dispatch.perform_http_flush.ok",
                    "session_id": session_id,
                    "acked_through": server_acked,
                    "ranker_kept_user_turn_idxs": resp_json.get("ranker_kept_user_turn_idxs", []),
                    "ranker_dropped_count": resp_json.get("ranker_dropped_count", 0),
                    "ingest_request_ids": resp_json.get("ingest_request_ids", []),
                },
            )

        elif response.status_code == 409:
            resp_json = response.json()
            # 409: FastAPI wraps the SessionIngestConflict model under "detail"
            detail_obj = resp_json["detail"]  # KeyError on drift
            server_acked = detail_obj["acked_through_turn_idx"]  # KeyError on drift
            on_flush_409(db_path, session_id, server_acked)
            log.info(
                "hook_dispatch.perform_http_flush.409",
                extra={
                    "event": "hook_dispatch.perform_http_flush.409",
                    "session_id": session_id,
                    "server_acked": server_acked,
                },
            )
            # One retry after trimming to the server's acked position
            retry_payload = force_flush_payload(workspace, session_id, user_id)
            if retry_payload is not None:
                with httpx.Client(timeout=30.0) as retry_client:
                    retry_response = retry_client.post(
                        ingest_url,
                        json=retry_payload,
                        headers={
                            "Authorization": f"Bearer {bearer_token}",
                            "X-Consumer-Id": consumer_id,
                            "Content-Type": "application/json",
                        },
                    )
                if retry_response.status_code == 200:
                    retry_json = retry_response.json()
                    retry_acked = retry_json["acked_through_turn_idx"]  # KeyError on drift
                    on_flush_success(
                        db_path, session_id, retry_payload["attempt_id"], retry_acked
                    )
                    _reset_flush_attempt_count_helper(db_path, log)
                    log.info(
                        "hook_dispatch.perform_http_flush.retry_ok",
                        extra={
                            "event": "hook_dispatch.perform_http_flush.retry_ok",
                            "session_id": session_id,
                            "acked_through": retry_acked,
                            "ranker_kept_user_turn_idxs": retry_json.get("ranker_kept_user_turn_idxs", []),
                            "ranker_dropped_count": retry_json.get("ranker_dropped_count", 0),
                            "ingest_request_ids": retry_json.get("ingest_request_ids", []),
                        },
                    )
                else:
                    on_flush_failure(
                        db_path, retry_payload["attempt_id"],
                        error=f"http_{retry_response.status_code}",
                        backoff_attempt=flush_attempt_count + 1,
                    )
                    _increment_flush_attempt_count_helper(db_path, log)
                    log.warning(
                        "hook_dispatch.perform_http_flush.retry_failed",
                        extra={
                            "event": "hook_dispatch.perform_http_flush.retry_failed",
                            "session_id": session_id,
                            "status_code": retry_response.status_code,
                        },
                    )

        else:
            on_flush_failure(
                db_path, attempt_id,
                error=f"http_{response.status_code}",
                backoff_attempt=flush_attempt_count + 1,
            )
            _increment_flush_attempt_count_helper(db_path, log)
            log.warning(
                "hook_dispatch.perform_http_flush.error",
                extra={
                    "event": "hook_dispatch.perform_http_flush.error",
                    "session_id": session_id,
                    "status_code": response.status_code,
                    "backoff_attempt": flush_attempt_count + 1,
                },
            )

    except Exception as exc:  # noqa: BLE001
        log.error(
            "hook_dispatch.perform_http_flush.exception",
            extra={
                "event": "hook_dispatch.perform_http_flush.exception",
                "session_id": session_id,
                "error_type": type(exc).__name__,
                "error": str(exc)[:300],
            },
        )
        on_flush_failure(
            db_path, attempt_id,
            error=f"{type(exc).__name__}: {str(exc)[:200]}",
            backoff_attempt=flush_attempt_count + 1,
        )
        _increment_flush_attempt_count_helper(db_path, log)

    return 0


# ── flush_attempt_count helpers (shared, no side-effects besides sqlite) ──────

def _read_flush_attempt_count_helper(db_path: Path, log: logging.Logger) -> int:
    try:
        import sqlite3
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout = 2000")
        try:
            row = conn.execute(
                "SELECT flush_attempt_count FROM spool_meta WHERE id = 1"
            ).fetchone()
            return int(row["flush_attempt_count"]) if row else 0
        finally:
            conn.close()
    except Exception as exc:
        log.warning(
            "hook_dispatch.read_flush_attempt_count_failed",
            extra={
                "event": "hook_dispatch.read_flush_attempt_count_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return 0


def _reset_flush_attempt_count_helper(db_path: Path, log: logging.Logger) -> None:
    try:
        import sqlite3
        conn = sqlite3.connect(str(db_path), isolation_level=None)
        conn.execute("PRAGMA busy_timeout = 2000")
        try:
            conn.execute(
                "UPDATE spool_meta SET flush_attempt_count = 0 WHERE id = 1"
            )
        finally:
            conn.close()
    except Exception as exc:
        log.warning(
            "hook_dispatch.reset_flush_attempt_count_failed",
            extra={
                "event": "hook_dispatch.reset_flush_attempt_count_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )


def _increment_flush_attempt_count_helper(db_path: Path, log: logging.Logger) -> None:
    try:
        import sqlite3
        conn = sqlite3.connect(str(db_path), isolation_level=None)
        conn.execute("PRAGMA busy_timeout = 2000")
        try:
            conn.execute(
                "UPDATE spool_meta "
                "SET flush_attempt_count = COALESCE(flush_attempt_count, 0) + 1 "
                "WHERE id = 1"
            )
        finally:
            conn.close()
    except Exception as exc:
        log.warning(
            "hook_dispatch.increment_flush_attempt_count_failed",
            extra={
                "event": "hook_dispatch.increment_flush_attempt_count_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
