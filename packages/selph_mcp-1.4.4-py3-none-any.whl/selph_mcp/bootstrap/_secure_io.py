"""Atomic secure file-write helper for the selph-mcp wheel (Phase 1, §6).

Extracts the atomic-write + symlink-refusal pattern that was previously
inlined in :func:`selph_mcp.bootstrap.credentials.save_credentials` so
that both the credentials writer and the new failure-log writer can share
the same hardened implementation without duplication.

Public surface
--------------
:func:`atomic_secure_write` — the single callable.

Both callers must still invoke
:func:`selph_mcp.bootstrap.credentials._refuse_symlinks_under` **before**
calling this function — the symlink refusal lives in the credentials module
and is reused by reference, not re-implemented here.
"""
from __future__ import annotations

import os
import stat
import tempfile
from pathlib import Path


def atomic_secure_write(
    path: Path,
    body_bytes: bytes,
    mode: int = 0o600,
) -> None:
    """Atomically write ``body_bytes`` to ``path`` with ``mode`` permissions.

    Write-pattern:
    1. Create a sibling ``.tmp`` file via :func:`tempfile.mkstemp` in the
       same directory as ``path`` (so the final ``os.replace`` is atomic
       on POSIX — same filesystem, no cross-device move).
    2. ``os.fsync`` the file descriptor before closing.
    3. ``os.chmod`` the temp file to ``mode`` BEFORE the replace so the
       public path never exists with looser permissions during the window
       between replace and chmod.
    4. ``os.replace`` (atomic rename) into the final ``path``.

    On any failure the temp file is unlinked (best-effort) and the
    exception is re-raised — the caller is responsible for handling it.

    Args:
        path: Absolute path of the destination file.  The parent directory
            must already exist; this function does NOT call ``mkdir``.
        body_bytes: Raw bytes to write.
        mode: File permission bits (default ``0o600`` — owner read/write
            only). The ``os.chmod`` call is a no-op on Windows but
            harmless.

    Raises:
        OSError: If the write, fsync, chmod, or replace fails.
    """
    parent = str(path.parent)
    fd, tmp_path = tempfile.mkstemp(
        prefix=f".{path.name}-",
        suffix=".tmp",
        dir=parent,
    )
    try:
        try:
            os.write(fd, body_bytes)
            os.fsync(fd)
        finally:
            # Always close the fd — even if write or fsync raised.
            try:
                os.close(fd)
            except OSError:
                pass
        # chmod BEFORE replace so the public path never briefly exists at
        # the default mkstemp mode (0o600 on POSIX; no-op on Windows).
        try:
            os.chmod(tmp_path, mode)
        except OSError:
            pass  # Windows / unsupported filesystem — harmless
        os.replace(tmp_path, str(path))
    except Exception:
        # Best-effort cleanup of the tempfile so we don't leak .tmp files.
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


__all__ = ["atomic_secure_write"]
