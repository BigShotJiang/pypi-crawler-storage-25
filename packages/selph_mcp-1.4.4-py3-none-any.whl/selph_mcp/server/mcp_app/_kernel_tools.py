"""Register the four kernel tools (observe, query, project, revise) onto a FastMCP server."""
from __future__ import annotations

import logging
import time as _time
from datetime import datetime, timezone
from typing import Any, Dict, Optional
from uuid import UUID

from fastapi import HTTPException, status
from mcp.server.fastmcp import Context, FastMCP

from selph_mcp.contracts.correction import CorrectionPayload
from selph_mcp.contracts.writeback import SessionObservation
from selph_mcp.kernel import observe as kernel_observe
from selph_mcp.kernel import project as kernel_project
from selph_mcp.kernel import query as kernel_query
from selph_mcp.kernel import revise as kernel_revise
from selph_mcp._event_id import get_event_id, set_event_id

from ._helpers import (
    _consumer_from_ctx,
    _lifespan_attr,
    _log,
    _mounted_request_credentials,
    log_event,
)


# ─────────────────────────────────────────────────────────────────────────────
# Tool registration
# ─────────────────────────────────────────────────────────────────────────────

def _register_tools(server: FastMCP) -> None:
    """Wire the four kernel tools onto ``server``.

    Each tool:
      1. Calls :func:`_consumer_from_ctx` for auth (raises on failure).
      2. Adapts the tool params into the kernel adapter signature.
      3. Logs entry / complete / error per the mandatory coverage rule.
    """

    @server.tool(
        name="observe",
        description=(
            "Persist a harness session observation. Always runs the full "
            "extraction pipeline. `observation_provenance` declares the "
            "evidence kind and is stamped on every produced memory. "
            "`apply_session_ranker` is forwarded but currently informational on "
            "this route — conversational ranking runs on the dedicated session "
            "ingest path. `idempotency_key` lets retries attach to an in-flight "
            "operation instead of starting a new ingest. Returns "
            "{status, raw_evidence_id, ingest_status, operation_id, duration_ms}."
        ),
    )
    async def observe_tool(  # noqa: D401 — MCP tool docstring is the description
        consumer_id: str,
        harness_id: str,
        session_id: str,
        captured_at: str,
        speaker: str,
        text: str,
        observation_provenance: Optional[str] = None,
        apply_session_ranker: bool = True,
        idempotency_key: Optional[str] = None,
        retry_for_event_id: Optional[str] = None,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        import asyncio as _asyncio
        import uuid as _uuid

        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"

        # Server-side event_id for Remote MCP path (§9.3).
        existing_event_id = get_event_id()
        _tok = None
        if not existing_event_id:
            _server_event_id = str(_uuid.uuid4())
            _tok = set_event_id(_server_event_id)
        else:
            _server_event_id = existing_event_id

        log_event(
            _log, logging.INFO, "mcp.tool.observe.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="observe",
            session_id=session_id,
            observation_provenance=observation_provenance,
            apply_session_ranker=apply_session_ranker,
            has_idempotency_key=(idempotency_key is not None),
            text_len=len(text or ""),
            mcp_transport=_mcp_transport,
            retry_for_event_id=retry_for_event_id,
            event_id=_server_event_id,
        )
        try:
            try:
                # ── Anti-bypass binding (§3.5.1) ────────────────────────────
                # Reject caller-supplied consumer_id / harness_id when they
                # disagree with the authenticated consumer row. A consumer
                # authenticated as ``cns-A`` must not be able to write
                # provenance metadata claiming ``cns-B`` (or some other
                # harness they don't own). Empty-string args are treated as
                # "not supplied" and silently filled from the consumer row.
                bound_consumer_id = consumer.consumer_id
                bound_harness_id = consumer.harness_id
                supplied_consumer = (consumer_id or "").strip()
                supplied_harness = (harness_id or "").strip()
                if supplied_consumer and supplied_consumer != bound_consumer_id:
                    log_event(
                        _log, logging.WARNING,
                        "mcp.tool.observe.consumer_binding_violation",
                        consumer_id=bound_consumer_id,
                        user_id=consumer.user_id,
                        payload_consumer_id=supplied_consumer,
                    )
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail=(
                            "Payload consumer_id does not match the authenticated consumer."
                        ),
                    )
                if supplied_harness and supplied_harness != bound_harness_id:
                    log_event(
                        _log, logging.WARNING,
                        "mcp.tool.observe.harness_binding_violation",
                        consumer_id=bound_consumer_id,
                        user_id=consumer.user_id,
                        bound_harness_id=bound_harness_id,
                        payload_harness_id=supplied_harness,
                    )
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail=(
                            "Payload harness_id does not match the authenticated consumer."
                        ),
                    )

                observation = SessionObservation(
                    consumer_id=bound_consumer_id,
                    harness_id=bound_harness_id,
                    session_id=session_id,
                    captured_at=captured_at,  # pydantic parses ISO-8601
                    speaker=speaker,
                    text=text,
                    provenance_role=observation_provenance,  # type: ignore[arg-type]
                )
                async with _mounted_request_credentials(ctx):
                    result = await kernel_observe.observe_session(
                        consumer=consumer,
                        observation=observation,
                        graph=_lifespan_attr(ctx, "neo4j"),
                        engine=_lifespan_attr(ctx, "engine"),
                        mcp_transport=_mcp_transport,
                        apply_session_ranker=apply_session_ranker,
                        idempotency_key=idempotency_key,
                    )
            except HTTPException:
                raise
            except Exception as _exc:
                # Server-observed failure capture (§9.3). Best-effort — never raise.
                try:
                    from selph_db import mcp_failure_report_manager as _report_mgr
                    from selph_mcp._redaction import redact_payload as _redact
                    _loop = _asyncio.get_running_loop()
                    _ev = _uuid.UUID(_server_event_id)
                    _redacted = _redact({
                        "session_id": session_id,
                        "speaker": speaker,
                        "text": text,
                        "observation_provenance": observation_provenance,
                    })
                    _parent_uuid = UUID(retry_for_event_id) if retry_for_event_id else None
                    await _loop.run_in_executor(
                        None,
                        lambda: _report_mgr.insert_or_merge(
                            event_id=_ev,
                            consumer_id=consumer.consumer_id,
                            user_id=consumer.user_id,
                            kind="failure",
                            observed_at=datetime.now(timezone.utc),
                            tool_name="observe",
                            request_payload_redacted=_redacted,
                            error_source="server_5xx",
                            error_code=type(_exc).__name__,
                            error_message=str(_exc)[:2048],
                            parent_event_id=_parent_uuid,
                        ),
                    )
                    # If this was a retry, also update the parent row's status.
                    if retry_for_event_id:
                        _parent_ev = _uuid.UUID(retry_for_event_id)
                        await _loop.run_in_executor(
                            None,
                            lambda: _report_mgr.update_status(
                                _parent_ev,
                                status="failed_again",
                                retry_outcome={
                                    "new_event_id": str(_ev),
                                    "error_type": type(_exc).__name__,
                                    "error": str(_exc)[:300],
                                },
                                expected_consumer_id=consumer.consumer_id,
                                expected_user_id=consumer.user_id,
                                expected_current_statuses={"retryable"},
                            ),
                        )
                except Exception:  # noqa: BLE001 — never surface capture errors
                    pass
                raise

            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            # On success: if this was a retry, update the parent row.
            if retry_for_event_id:
                try:
                    from selph_db import mcp_failure_report_manager as _report_mgr_ok
                    _loop = _asyncio.get_running_loop()
                    _parent_ev = _uuid.UUID(retry_for_event_id)
                    await _loop.run_in_executor(
                        None,
                        lambda: _report_mgr_ok.update_status(
                            _parent_ev,
                            status="retried",
                            retry_outcome={
                                "event_id": _server_event_id,
                                "result": "ok",
                            },
                            expected_consumer_id=consumer.consumer_id,
                            expected_user_id=consumer.user_id,
                            expected_current_statuses={"retryable"},
                        ),
                    )
                except Exception:  # noqa: BLE001
                    pass

            log_event(
                _log, logging.INFO, "mcp.tool.observe.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="observe",
                duration_ms=duration_ms,
                raw_evidence_id=result.get("raw_evidence_id"),
                ingest_status=result.get("ingest_status"),
                operation_id=result.get("operation_id"),
                mcp_transport=_mcp_transport,
            )
            return result
        except HTTPException:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.WARNING, "mcp.tool.observe.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="observe",
                duration_ms=duration_ms,
                error_type="HTTPException",
                mcp_transport=_mcp_transport,
            )
            raise
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.observe.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="observe",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise
        finally:
            if _tok is not None:
                try:
                    _tok.var.reset(_tok)
                finally:
                    pass

    @server.tool(
        name="query",
        description=(
            "Run a natural-language query against the persona KG. "
            "Returns {status, data, timing_ms, duration_ms}."
        ),
    )
    async def query_tool(
        query_text: str,
        tz: str = "America/Chicago",
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.query.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="query",
            query_len=len(query_text or ""),
            tz=tz,
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                result = await kernel_query.query(
                    consumer=consumer,
                    query_text=query_text,
                    graph=_lifespan_attr(ctx, "neo4j"),
                    chroma=_lifespan_attr(ctx, "chroma"),
                    tz=tz,
                    engine=_lifespan_attr(ctx, "engine"),
                    mcp_transport=_mcp_transport,
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.query.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="query",
                duration_ms=duration_ms,
                status=result.get("status"),
                mcp_transport=_mcp_transport,
            )
            return result
        except HTTPException:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.WARNING, "mcp.tool.query.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="query",
                duration_ms=duration_ms,
                error_type="HTTPException",
                mcp_transport=_mcp_transport,
            )
            raise
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.query.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="query",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="project",
        description=(
            "Read the latest hub payload for (user_id, hub_type). "
            "Sync read — never triggers a rebuild. Returns "
            "{status, user_id, hub_type, payload, duration_ms}. "
            "Optional: pass domain_hint as a natural language phrase to scope "
            "this request to a specific preference domain "
            "(e.g. 'food preferences', 'dietary requirements', 'entertainment')."
        ),
    )
    async def project_tool(
        hub_type: str,
        domain_hint: Optional[str] = None,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"
        log_event(
            _log, logging.INFO, "mcp.tool.project.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="project",
            hub_type=hub_type,
            has_domain_hint=(domain_hint is not None),
            mcp_transport=_mcp_transport,
        )
        try:
            async with _mounted_request_credentials(ctx):
                result = await kernel_project.project(
                    consumer=consumer,
                    hub_type=hub_type,
                    domain_hint=domain_hint,
                    engine=_lifespan_attr(ctx, "engine"),
                    mcp_transport=_mcp_transport,
                )
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.INFO, "mcp.tool.project.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="project",
                hub_type=hub_type,
                has_domain_hint=(domain_hint is not None),
                duration_ms=duration_ms,
                status=result.get("status"),
                mcp_transport=_mcp_transport,
            )
            return result
        except HTTPException:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.WARNING, "mcp.tool.project.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="project",
                duration_ms=duration_ms,
                error_type="HTTPException",
                mcp_transport=_mcp_transport,
            )
            raise
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.project.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="project",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise

    @server.tool(
        name="revise",
        description=(
            "Apply a structured persona correction. Dispatches per the "
            "§3.4 compile table — all 12 cells are live ops (Phase 3 "
            "wired supersede for memory/identity_claim + "
            "reject_recommendation). Returns the underlying "
            "manager_result; unmapped (action, target_type) pairs return "
            "HTTP 400."
        ),
    )
    async def revise_tool(
        payload: Dict[str, Any],
        retry_for_event_id: Optional[str] = None,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        import asyncio as _asyncio
        import uuid as _uuid

        t0 = _time.perf_counter()
        consumer = await _consumer_from_ctx(ctx)
        _mcp_transport: str = _lifespan_attr(ctx, "transport") or "stdio"

        # Server-side event_id for Remote MCP path (§9.3).
        existing_event_id = get_event_id()
        _tok = None
        if not existing_event_id:
            _server_event_id = str(_uuid.uuid4())
            _tok = set_event_id(_server_event_id)
        else:
            _server_event_id = existing_event_id

        log_event(
            _log, logging.INFO, "mcp.tool.revise.entry",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            tool_name="revise",
            action=(payload or {}).get("action"),
            target_type=(payload or {}).get("target_type"),
            mcp_transport=_mcp_transport,
            retry_for_event_id=retry_for_event_id,
            event_id=_server_event_id,
        )
        try:
            try:
                structured = CorrectionPayload(**payload)
                async with _mounted_request_credentials(ctx):
                    result = await kernel_revise.revise(
                        consumer=consumer,
                        payload=structured,
                        engine=_lifespan_attr(ctx, "engine"),
                        mcp_transport=_mcp_transport,
                    )
            except HTTPException:
                raise
            except Exception as _exc:
                # Server-observed failure capture (§9.3). Best-effort — never raise.
                try:
                    from selph_db import mcp_failure_report_manager as _report_mgr
                    from selph_mcp._redaction import redact_payload as _redact
                    _loop = _asyncio.get_running_loop()
                    _ev = _uuid.UUID(_server_event_id)
                    _redacted = _redact(payload or {})
                    _parent_uuid = UUID(retry_for_event_id) if retry_for_event_id else None
                    await _loop.run_in_executor(
                        None,
                        lambda: _report_mgr.insert_or_merge(
                            event_id=_ev,
                            consumer_id=consumer.consumer_id,
                            user_id=consumer.user_id,
                            kind="failure",
                            observed_at=datetime.now(timezone.utc),
                            tool_name="revise",
                            request_payload_redacted=_redacted,
                            error_source="server_5xx",
                            error_code=type(_exc).__name__,
                            error_message=str(_exc)[:2048],
                            parent_event_id=_parent_uuid,
                        ),
                    )
                    if retry_for_event_id:
                        _parent_ev = _uuid.UUID(retry_for_event_id)
                        await _loop.run_in_executor(
                            None,
                            lambda: _report_mgr.update_status(
                                _parent_ev,
                                status="failed_again",
                                retry_outcome={
                                    "new_event_id": str(_ev),
                                    "error_type": type(_exc).__name__,
                                    "error": str(_exc)[:300],
                                },
                                expected_consumer_id=consumer.consumer_id,
                                expected_user_id=consumer.user_id,
                                expected_current_statuses={"retryable"},
                            ),
                        )
                except Exception:  # noqa: BLE001
                    pass
                raise

            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            # On success: if this was a retry, update the parent row.
            if retry_for_event_id:
                try:
                    from selph_db import mcp_failure_report_manager as _report_mgr_ok
                    _loop = _asyncio.get_running_loop()
                    _parent_ev = _uuid.UUID(retry_for_event_id)
                    await _loop.run_in_executor(
                        None,
                        lambda: _report_mgr_ok.update_status(
                            _parent_ev,
                            status="retried",
                            retry_outcome={
                                "event_id": _server_event_id,
                                "result": "ok",
                            },
                            expected_consumer_id=consumer.consumer_id,
                            expected_user_id=consumer.user_id,
                            expected_current_statuses={"retryable"},
                        ),
                    )
                except Exception:  # noqa: BLE001
                    pass

            log_event(
                _log, logging.INFO, "mcp.tool.revise.complete",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="revise",
                action=structured.action.value,
                target_type=structured.target_type.value,
                duration_ms=duration_ms,
                status=(result or {}).get("status"),
                mcp_transport=_mcp_transport,
            )
            return result
        except HTTPException:
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.WARNING, "mcp.tool.revise.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="revise",
                duration_ms=duration_ms,
                error_type="HTTPException",
                mcp_transport=_mcp_transport,
            )
            raise
        except Exception as exc:  # noqa: BLE001
            duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
            log_event(
                _log, logging.ERROR, "mcp.tool.revise.error",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                tool_name="revise",
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
                mcp_transport=_mcp_transport,
            )
            raise
        finally:
            if _tok is not None:
                try:
                    _tok.var.reset(_tok)
                finally:
                    pass
