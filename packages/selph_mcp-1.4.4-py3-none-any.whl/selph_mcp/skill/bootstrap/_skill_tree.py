"""Modular skill-tree install/repair helpers for the using-selph bootstrap.

Maintains the canonical sub-tree under
``~/.claude/commands/using-selph/{flows,reference}/*.md`` so the slim
SKILL.md controller can route to detail-heavy sub-files without bloating
its own context window.

Idempotency contract:

- Missing files are restored from the wheel-bundled fallback (or from the
  server when ``api_url`` is provided).
- Files that already match canonical content are left untouched.
- Files that have been edited by the user are PRESERVED — never silently
  overwritten. Pass ``force=True`` to refresh them from canonical.
"""

from __future__ import annotations

import urllib.error
import urllib.request
from importlib.resources import files as _resource_files
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import urlparse

from ._file_locking import _atomic_write_text
from ._shared import logger

__all__: list[str] = [
    "SKILL_TREE_MANIFEST",
    "install_skill_tree",
    "skill_tree_root",
]


# Canonical manifest of sub-files. Keep in sync with the
# ``selph_mcp/skill/install/using-selph/`` tree shipped in the wheel.
SKILL_TREE_MANIFEST: tuple[str, ...] = (
    "flows/first-run.md",
    "flows/returning.md",
    "flows/workflow-audit.md",
    "reference/voice-and-evidence.md",
    "reference/troubleshooting.md",
    "reference/memory-boundary.md",
)


def skill_tree_root() -> Path:
    """Resolve the user-facing modular skill tree root.

    Sub-files are written under ``~/.claude/commands/using-selph/`` as
    siblings of the slash-command file ``~/.claude/commands/using-selph.md``.
    """
    return Path.home() / ".claude" / "commands" / "using-selph"


def _require_https_url(api_url: str) -> tuple[bool, str]:
    """Mirrors the helper in ``_slash_command``: HTTPS everywhere, HTTP loopback only."""
    parsed = urlparse(api_url)
    if parsed.scheme == "https":
        if not parsed.netloc:
            return False, "api_url must include a host"
        return True, ""
    if parsed.scheme == "http":
        if parsed.hostname in {"localhost", "127.0.0.1", "0.0.0.0"}:
            return True, ""
        return False, (
            f"api_url must use https:// scheme for non-loopback hosts; got {parsed.scheme!r}"
        )
    return False, f"api_url must use https:// scheme; got {parsed.scheme!r}"


def _read_wheel_bundle(rel_path: str) -> str:
    """Read a sub-file from the wheel-bundled ``using-selph/`` tree.

    Uses ``importlib.resources`` so the helper works whether the package is
    installed as a wheel or imported from a source checkout.
    """
    base = _resource_files("selph_mcp.skill.install").joinpath("using-selph")
    resource = base
    for part in rel_path.split("/"):
        resource = resource.joinpath(part)
    return resource.read_text(encoding="utf-8")


class _FetchError(Exception):
    """Raised by :func:`_fetch_server_copy` on non-success so the caller can
    record the failure before falling back to the wheel bundle.

    Attributes:
        event_id: The UUID minted for this request (set as ``X-Selph-Event-Id``
            header) so the caller can record the same id locally.
        error_source: One of ``client_network``, ``server_4xx``, ``server_5xx``,
            ``schema_validation`` — matches the DB CHECK constraint.
    """

    def __init__(
        self,
        message: str,
        *,
        event_id: str,
        error_source: str,
        cause: Optional[Exception] = None,
    ) -> None:
        super().__init__(message)
        self.event_id = event_id
        self.error_source = error_source
        self.cause = cause


def _fetch_server_copy(
    api_url: str, rel_path: str, *, timeout: float = 10.0
) -> Optional[str]:
    """Fetch a sub-file from ``<api_url>/apps/install/using-selph/<rel_path>``.

    Returns text on HTTP 200 with non-empty body.

    Raises:
        :class:`_FetchError`: on any network, HTTP, or decode failure.
            The ``event_id`` attribute carries the UUID sent as
            ``X-Selph-Event-Id`` so the caller can pass it to
            :func:`record_failure` for correct event correlation.
    """
    import uuid as _uuid
    event_id = str(_uuid.uuid4())

    base = api_url.rstrip("/")
    url = f"{base}/apps/install/using-selph/{rel_path}"
    try:
        req = urllib.request.Request(
            url,
            headers={"X-Selph-Event-Id": event_id},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                logger.debug(
                    "skill_tree.fetch_server_copy: bad status",
                    extra={
                        "event": "bootstrap.skill_tree.fetch.bad_status",
                        "rel_path": rel_path,
                        "status": resp.status,
                    },
                )
                _source = "server_5xx" if resp.status >= 500 else "server_4xx"
                raise _FetchError(
                    f"HTTP {resp.status}",
                    event_id=event_id,
                    error_source=_source,
                )
            raw = resp.read()
    except _FetchError:
        raise
    except urllib.error.HTTPError as exc:
        _source = "server_5xx" if exc.code >= 500 else "server_4xx"
        logger.debug(
            "skill_tree.fetch_server_copy: HTTP error",
            extra={
                "event": "bootstrap.skill_tree.fetch.http_error",
                "rel_path": rel_path,
                "status": exc.code,
                "error": str(exc)[:200],
            },
        )
        raise _FetchError(
            f"HTTP {exc.code}: {exc}",
            event_id=event_id,
            error_source=_source,
            cause=exc,
        ) from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        logger.debug(
            "skill_tree.fetch_server_copy: fetch failed",
            extra={
                "event": "bootstrap.skill_tree.fetch.failed",
                "rel_path": rel_path,
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        raise _FetchError(
            str(exc),
            event_id=event_id,
            error_source="client_network",
            cause=exc,
        ) from exc
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        logger.warning(
            "skill_tree.fetch_server_copy: decode failed",
            extra={
                "event": "bootstrap.skill_tree.fetch.decode_failed",
                "rel_path": rel_path,
                "error": str(exc)[:200],
            },
        )
        raise _FetchError(
            f"UnicodeDecodeError: {exc}",
            event_id=event_id,
            error_source="schema_validation",
            cause=exc,
        ) from exc
    if not text.strip():
        raise _FetchError(
            "empty response body",
            event_id=event_id,
            error_source="schema_validation",
        )
    return text


def install_skill_tree(
    *,
    api_url: Optional[str] = None,
    force: bool = False,
    failure_recorder: Optional[Callable] = None,
) -> dict:
    """Idempotently restore the modular sub-tree under ``~/.claude/commands/using-selph/``.

    Args:
        api_url: When provided, prefer the server-hosted copy at
            ``<api_url>/apps/install/using-selph/<rel>`` over the
            wheel-bundled fallback. Network failures fall back to the
            wheel bundle — but the failure is recorded via
            ``failure_recorder`` before the fallback so the operator
            knows the server copy was unavailable.
        force: When ``True``, overwrite existing files that differ from
            canonical content. Default ``False`` preserves user edits.
        failure_recorder: Optional callable with the signature
            ``(event_id, tool_name, payload, exc, *, redactor, error_source)``
            (matches :func:`selph_mcp.skill.runtime._failure_log.record_failure`).
            Called on each per-file remote-fetch failure when ``api_url``
            is set.  Callers inject this so the function does not import
            the failure-log module itself (import-boundary safety).

    Returns:
        A summary dict with ``repaired`` (newly written), ``refreshed``
        (overwritten via ``force``), ``preserved`` (left untouched), and
        ``failed`` (per-file write/read errors) lists. Always ``ok``
        envelope-shaped — callers wrap it in their own envelope.

    Raises:
        ValueError: when ``api_url`` is provided but uses a non-loopback
            HTTP scheme (server fetch is rejected).
    """
    if api_url is not None:
        ok, reason = _require_https_url(api_url)
        if not ok:
            raise ValueError(reason)

    target_root = skill_tree_root()
    target_root.mkdir(parents=True, exist_ok=True)

    repaired: list[str] = []
    refreshed: list[str] = []
    preserved: list[str] = []
    failed: list[dict[str, str]] = []

    for rel in SKILL_TREE_MANIFEST:
        target = target_root / rel
        try:
            canonical, source_label = _resolve_canonical(
                rel, api_url, failure_recorder=failure_recorder
            )
        except Exception as exc:  # noqa: BLE001 — record per-file failure
            logger.error(
                "skill_tree.canonical_unavailable",
                extra={
                    "event": "bootstrap.skill_tree.canonical_unavailable",
                    "rel_path": rel,
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:200],
                },
            )
            failed.append({
                "path": rel,
                "reason": f"{type(exc).__name__}: {exc}"[:200],
            })
            continue

        existing = _read_existing(target)

        if existing is None:
            _try_write(
                target, canonical, rel, source_label,
                outcome_list=repaired, failed_list=failed,
                event_kind="repaired",
            )
            continue

        if existing == canonical:
            preserved.append(rel)
            continue

        if force:
            _try_write(
                target, canonical, rel, source_label,
                outcome_list=refreshed, failed_list=failed,
                event_kind="refreshed",
            )
            continue

        # User-edited file; do not overwrite.
        preserved.append(rel)
        logger.debug(
            "skill_tree.preserved_user_edit",
            extra={
                "event": "bootstrap.skill_tree.preserved_user_edit",
                "rel_path": rel,
            },
        )

    return {
        "target_root": str(target_root),
        "repaired": repaired,
        "refreshed": refreshed,
        "preserved": preserved,
        "failed": failed,
        "manifest": list(SKILL_TREE_MANIFEST),
    }


def _resolve_canonical(
    rel: str,
    api_url: Optional[str],
    *,
    failure_recorder: Optional[Callable] = None,
) -> tuple[str, str]:
    """Return ``(content, source_label)`` for one manifest entry.

    Server fetch is preferred when ``api_url`` is set; falls back to the
    wheel-bundled copy on any fetch failure.  When ``failure_recorder`` is
    provided, it is called with the fetch exception BEFORE the fallback so
    the operator has a record that the server copy was unavailable.
    """
    if api_url:
        try:
            server_copy = _fetch_server_copy(api_url, rel)
            return server_copy, "server"
        except _FetchError as exc:
            # Record the failure (best-effort) then fall back to the wheel bundle.
            if failure_recorder is not None:
                try:
                    failure_recorder(
                        exc.event_id,
                        "install_skill_tree",
                        {"api_url": api_url, "rel_path": rel},
                        exc,
                        error_source=exc.error_source,
                    )
                except Exception:  # noqa: BLE001 — recorder must not block install
                    pass
            logger.debug(
                "skill_tree._resolve_canonical: server fetch failed; using wheel bundle",
                extra={
                    "event": "bootstrap.skill_tree.fallback_to_wheel",
                    "rel_path": rel,
                    "event_id": exc.event_id,
                    "error_source": exc.error_source,
                    "error": str(exc)[:200],
                },
            )
    return _read_wheel_bundle(rel), "wheel"


def _dir_ancestors_under(root: Path, target: Path) -> list[Path]:
    """Yield directory ancestors of ``target`` that live strictly under ``root``.

    Used by the symlink-defense in :func:`_try_write` to walk every
    directory between the tree root and the file's parent. The root
    itself is checked separately by the caller.
    """
    ancestors: list[Path] = []
    parent = target.parent
    while parent != root and parent != parent.parent:
        ancestors.append(parent)
        parent = parent.parent
    ancestors.reverse()
    return ancestors


def _read_existing(target: Path) -> Optional[str]:
    if not target.is_file():
        return None
    try:
        return target.read_text(encoding="utf-8")
    except OSError as exc:
        logger.warning(
            "skill_tree.read_existing_failed",
            extra={
                "event": "bootstrap.skill_tree.read_existing_failed",
                "path": str(target),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return None


def _try_write(
    target: Path,
    content: str,
    rel: str,
    source_label: str,
    *,
    outcome_list: list[str],
    failed_list: list[dict[str, str]],
    event_kind: str,
) -> None:
    # Guard against symlinks redirecting the install target. The canonical
    # tree must live under ~/.claude/commands/using-selph/ — if any
    # component along the way (the using-selph dir itself, flows/,
    # reference/, or the file itself) is a symlink that escapes
    # ~/.claude/commands/, refuse the write. Even a same-tree symlink is
    # rejected for the directory components: this is a system-installed
    # tree, not a user re-mount point.
    commands_root = Path.home() / ".claude" / "commands"
    tree_root = skill_tree_root()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        # 1. The skill-tree root and every directory ancestor of `target`
        #    inside it must not be a symlink — symlinked dirs subvert the
        #    canonical install location even if they point somewhere safe.
        for ancestor in (tree_root, *_dir_ancestors_under(tree_root, target)):
            if ancestor.is_symlink():
                raise OSError(f"refusing symlinked path component: {ancestor}")
        # 2. The target file itself, if it already exists, must not be a
        #    symlink — atomic_write_text would follow it to write outside.
        if target.exists() and target.is_symlink():
            raise OSError(f"refusing symlinked target file: {target}")
        # 3. Belt-and-braces: the resolved parent must still live under
        #    ~/.claude/commands/ even after every symlink in the path is
        #    chased. Catches edge cases the per-component check might miss
        #    (e.g. ~/.claude itself being a symlink the user set up).
        resolved_parent = target.parent.resolve(strict=False)
        resolved_commands = commands_root.resolve(strict=False)
        resolved_parent.relative_to(resolved_commands)
    except (OSError, ValueError) as exc:
        logger.error(
            "skill_tree.path_escape_blocked",
            extra={
                "event": "bootstrap.skill_tree.path_escape_blocked",
                "rel_path": rel,
                "target": str(target),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        failed_list.append({
            "path": rel,
            "reason": (
                f"refused to write outside skill-tree root: "
                f"{type(exc).__name__}: {exc}"
            )[:200],
        })
        return
    try:
        _atomic_write_text(target, content)
    except OSError as exc:
        logger.error(
            "skill_tree.write_failed",
            extra={
                "event": "bootstrap.skill_tree.write_failed",
                "path": str(target),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        failed_list.append({
            "path": rel,
            "reason": f"{type(exc).__name__}: {exc}"[:200],
        })
        return
    outcome_list.append(rel)
    logger.info(
        f"skill_tree.{event_kind}",
        extra={
            "event": f"bootstrap.skill_tree.{event_kind}",
            "rel_path": rel,
            "source": source_label,
            "bytes": len(content),
        },
    )
