"""Slash-command self-update helpers for the using-selph bootstrap."""

from __future__ import annotations

import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from ._shared import logger
from ._file_locking import _atomic_write_text


def _require_https_url(api_url: str) -> tuple[bool, str]:
    """Return (True, "") if api_url is safe; (False, reason) otherwise.

    Mirrors the helper in selph_mcp.bootstrap.cli._install_subcommands so
    direct callers of refresh_slash_command() also get the scheme check.
    Allows https:// everywhere and http:// on loopback only (dev convenience).
    """
    parsed = urlparse(api_url)
    if parsed.scheme == "https":
        if not parsed.netloc:
            return False, "api_url must include a host"
        return True, ""
    if parsed.scheme == "http":
        if parsed.hostname in {"localhost", "127.0.0.1", "0.0.0.0"}:
            return True, ""
        return False, (
            f"api_url must use https:// scheme for non-loopback hosts; got {parsed.scheme!r}"
        )
    return False, f"api_url must use https:// scheme; got {parsed.scheme!r}"

__all__: list[str] = ["_slash_command_path", "refresh_slash_command"]


def _slash_command_path() -> Path:
    """Resolve the user's installed `/using-selph` slash-command file.

    The slash-command file lives in the user's Claude Code config directory
    at ``~/.claude/commands/using-selph.md``. This is the file Claude Code
    actually reads when the user types ``/using-selph`` — distinct from the
    SKILL.md spec in the repo (which is the source of truth shipped by the
    server).
    """
    return Path.home() / ".claude" / "commands" / "using-selph.md"


def refresh_slash_command(api_url: str, *, timeout: float = 10.0) -> bool:
    """Fetch the latest using-selph slash-command spec from the server and
    write it to ``~/.claude/commands/using-selph.md``.

    Uses ``urllib.request`` only — keeps the bootstrap dependency-free so
    it can run in any Python environment (no httpx / requests).

    Returns:
        - ``True`` if the file was created or updated
        - ``False`` if the on-disk content already matched (no write)

    Raises:
        Any exception whose ``event_id`` (UUID) and ``error_source`` (one
        of ``client_network``, ``server_4xx``, ``server_5xx``,
        ``schema_validation``) attributes are set to the values used for the
        ``X-Selph-Event-Id`` request header.  Callers that want best-effort
        behaviour should wrap in ``try/except Exception``.

    The endpoint is unauthenticated by design — the slash-command spec
    carries no secrets and must be fetchable before any auth handshake.
    """
    ok, reason = _require_https_url(api_url)
    if not ok:
        logger.warning(
            "refresh_slash_command: insecure URL rejected",
            extra={
                "event": "bootstrap.refresh_slash_command.insecure_url",
                "api_url": api_url,
                "reason": reason,
            },
        )
        return None

    import uuid as _uuid
    _event_id = str(_uuid.uuid4())

    base = api_url.rstrip("/")
    url = f"{base}/apps/install/using-selph"

    try:
        req = urllib.request.Request(
            url,
            headers={"X-Selph-Event-Id": _event_id},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = resp.status
            raw = resp.read()
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        logger.info(
            "refresh_slash_command: fetch failed",
            extra={
                "event": "bootstrap.refresh_slash_command.fetch_failed",
                "api_url": api_url,
                "event_id": _event_id,
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        # Attach event_id as attribute so the caller can record with the same id.
        exc_with_id = exc  # type: ignore[assignment]
        exc_with_id.event_id = _event_id  # type: ignore[attr-defined]
        exc_with_id.error_source = "client_network"  # type: ignore[attr-defined]
        raise exc_with_id from exc

    if status != 200:
        logger.warning(
            "refresh_slash_command: bad status",
            extra={
                "event": "bootstrap.refresh_slash_command.bad_status",
                "api_url": api_url,
                "event_id": _event_id,
                "status": status,
            },
        )
        _source = "server_5xx" if status >= 500 else "server_4xx"
        _err: Exception = OSError(f"HTTP {status}")
        _err.event_id = _event_id  # type: ignore[attr-defined]
        _err.error_source = _source  # type: ignore[attr-defined]
        raise _err

    try:
        new_content = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        logger.warning(
            "refresh_slash_command: decode failed",
            extra={
                "event": "bootstrap.refresh_slash_command.decode_failed",
                "api_url": api_url,
                "event_id": _event_id,
                "error": str(exc)[:200],
            },
        )
        exc.event_id = _event_id  # type: ignore[attr-defined]
        exc.error_source = "schema_validation"  # type: ignore[attr-defined]
        raise

    if not new_content.strip():
        logger.warning(
            "refresh_slash_command: empty body",
            extra={
                "event": "bootstrap.refresh_slash_command.empty_body",
                "api_url": api_url,
                "event_id": _event_id,
            },
        )
        _empty_err: Exception = ValueError("empty response body")
        _empty_err.event_id = _event_id  # type: ignore[attr-defined]
        _empty_err.error_source = "schema_validation"  # type: ignore[attr-defined]
        raise _empty_err

    target = _slash_command_path()
    try:
        existing = target.read_text(encoding="utf-8") if target.is_file() else None
    except OSError as exc:
        logger.warning(
            "refresh_slash_command: read existing failed",
            extra={
                "event": "bootstrap.refresh_slash_command.read_existing_failed",
                "path": str(target),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        existing = None

    if existing == new_content:
        logger.debug(
            "refresh_slash_command: unchanged",
            extra={
                "event": "bootstrap.refresh_slash_command.unchanged",
                "path": str(target),
                "bytes": len(new_content),
            },
        )
        return False

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_text(target, new_content)
    except OSError as exc:
        logger.error(
            "refresh_slash_command: write failed",
            extra={
                "event": "bootstrap.refresh_slash_command.write_failed",
                "path": str(target),
                "event_id": _event_id,
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        exc.event_id = _event_id  # type: ignore[attr-defined]
        exc.error_source = "client_network"  # type: ignore[attr-defined]
        raise

    logger.info(
        "refresh_slash_command: updated",
        extra={
            "event": "bootstrap.refresh_slash_command.updated",
            "path": str(target),
            "bytes": len(new_content),
            "was_present": existing is not None,
        },
    )
    return True
