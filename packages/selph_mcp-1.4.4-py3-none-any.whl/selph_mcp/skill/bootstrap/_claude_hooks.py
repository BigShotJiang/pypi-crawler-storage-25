"""Hook installer for Claude Code ambient session capture (Phase G).

Manages entries in ``<workspace>/.claude/settings.local.json`` for the three
Claude Code hook events: UserPromptSubmit, Stop, SessionEnd.

Import constraints (per ``.importlinter`` ``adapters-surface-only``):
  ALLOWED: stdlib, this package.
  FORBIDDEN: selph_core, selph_db, selph_graph, ingestion_api, selph_apps.
"""

from __future__ import annotations

import json
import shlex
from pathlib import Path
from typing import Any, Dict, List, Optional

from ._file_locking import _file_lock
from ._shared import logger

__all__: list[str] = [
    "install_hooks",
    "uninstall_hooks",
    "uninstall_all",
    "verify_hooks",
]

# ── Constants ──────────────────────────────────────────────────────────────────

_HOOK_OWNER_PREFIX = "SELPH_HOOK_OWNER=selph-mcp@"
_HOOK_OWNER_TAG = "SELPH_HOOK_OWNER=selph-mcp@1"
_HOOK_BINARY = "selph-mcp-hook"
_HOOK_EVENTS = ("UserPromptSubmit", "Stop", "SessionEnd")

# SessionEnd gets a 60s timeout; the others use the Claude default.
_SESSION_END_TIMEOUT = 60


def _settings_local_path(workspace: Path) -> Path:
    return workspace / ".claude" / "settings.local.json"


def _build_hook_command(event_name: str) -> str:
    """Build hook command — shlex-quoted log path; command -v guard + || true."""
    log_path = shlex.quote(str(Path.home() / ".selph-hook.log"))
    return (
        f"/bin/sh -c 'command -v {_HOOK_BINARY} >/dev/null 2>&1 && "
        f"{_HOOK_OWNER_TAG} {_HOOK_BINARY} {event_name} 2>>{log_path} || true'"
    )


def _is_selph_owned(entry: Any) -> bool:
    """True iff entry is a dict with both Selph marker substrings."""
    if not isinstance(entry, dict):
        return False
    cmd = entry.get("command", "")
    return _HOOK_OWNER_PREFIX in cmd and _HOOK_BINARY in cmd


def _load_settings(path: Path) -> Dict[str, Any]:
    if path.exists():
        try:
            text = path.read_text(encoding="utf-8")
            return json.loads(text) if text.strip() else {}
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning(
                "hooks: failed to load settings.local.json; treating as empty",
                extra={
                    "event": "bootstrap.hooks.load_failed",
                    "path": str(path),
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:200],
                },
            )
    return {}


def _save_settings(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def install_hooks(workspace: Path) -> None:
    """Install ambient capture hooks into settings.local.json (idempotent)."""
    logger.info(
        "hooks.install.entry",
        extra={"event": "bootstrap.hooks.install.entry", "workspace": str(workspace)},
    )
    path = _settings_local_path(workspace)

    def _do_install() -> None:
        settings = _load_settings(path)
        hooks_root: Dict[str, Any] = settings.setdefault("hooks", {})

        for event in _HOOK_EVENTS:
            cmd = _build_hook_command(event)
            new_entry: Dict[str, Any] = {"type": "command", "command": cmd}
            if event == "SessionEnd":
                new_entry["timeout"] = _SESSION_END_TIMEOUT

            # Each event key is a list of matcher-groups
            event_list: List[Dict[str, Any]] = hooks_root.setdefault(event, [])

            # Find the first matcher group that has the ``"*"`` wildcard
            # AND a Selph-owned entry — replace it. Otherwise append.
            placed = False
            for group in event_list:
                if not isinstance(group, dict):
                    continue
                if group.get("matcher") != "*":
                    continue
                inner: List[Any] = group.setdefault("hooks", [])
                # Remove existing Selph-owned entries from this group
                inner[:] = [e for e in inner if not _is_selph_owned(e)]
                inner.append(new_entry)
                placed = True
                break

            if not placed:
                event_list.append({"matcher": "*", "hooks": [new_entry]})

        settings["hooks"] = hooks_root
        _save_settings(path, settings)

    with _file_lock(path):
        _do_install()

    logger.info(
        "hooks.install.complete",
        extra={
            "event": "bootstrap.hooks.install.complete",
            "workspace": str(workspace),
            "path": str(path),
        },
    )


def uninstall_hooks(workspace: Path) -> int:
    """Remove Selph-owned hook entries; return count removed."""
    logger.info(
        "hooks.uninstall.entry",
        extra={"event": "bootstrap.hooks.uninstall.entry", "workspace": str(workspace)},
    )
    path = _settings_local_path(workspace)
    removed = 0

    def _do_uninstall() -> None:
        nonlocal removed
        if not path.exists():
            return
        settings = _load_settings(path)
        hooks_root: Dict[str, Any] = settings.get("hooks", {})
        if not hooks_root:
            return

        new_hooks: Dict[str, Any] = {}
        for event, event_list in hooks_root.items():
            if not isinstance(event_list, list):
                new_hooks[event] = event_list
                continue
            new_event_list = []
            for group in event_list:
                if not isinstance(group, dict):
                    new_event_list.append(group)
                    continue
                inner: List[Any] = group.get("hooks", [])
                kept = [e for e in inner if not _is_selph_owned(e)]
                removed += len(inner) - len(kept)
                if kept:
                    new_group = dict(group)
                    new_group["hooks"] = kept
                    new_event_list.append(new_group)
                # else: drop the now-empty matcher group
            if new_event_list:
                new_hooks[event] = new_event_list
            # else: drop the now-empty event key

        if new_hooks:
            settings["hooks"] = new_hooks
        else:
            settings.pop("hooks", None)

        _save_settings(path, settings)

    with _file_lock(path):
        _do_uninstall()

    logger.info(
        "hooks.uninstall.complete",
        extra={
            "event": "bootstrap.hooks.uninstall.complete",
            "workspace": str(workspace),
            "removed": removed,
        },
    )
    return removed


def _try_delete(path: Path, label: str) -> bool:
    """Attempt to delete a file; log warning on failure; return success."""
    if not path.exists():
        return False
    try:
        path.unlink()
        return True
    except OSError as exc:
        logger.warning(
            f"hooks.uninstall_all: could not delete {label}",
            extra={
                "event": f"bootstrap.hooks.uninstall_all.{label}_delete_failed",
                "path": str(path),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return False


def uninstall_all(
    workspace: Path,
    *,
    purge_credentials: bool = False,
) -> Dict[str, Any]:
    """Remove hooks, slash command, and onboarding state; preserve credentials unless purge_credentials=True."""
    logger.info(
        "hooks.uninstall_all.entry",
        extra={
            "event": "bootstrap.hooks.uninstall_all.entry",
            "workspace": str(workspace),
            "purge_credentials": purge_credentials,
        },
    )
    hooks_removed = uninstall_hooks(workspace)
    slash_deleted = _try_delete(
        Path.home() / ".claude" / "commands" / "using-selph.md", "slash_command"
    )
    onboarding_deleted = _try_delete(
        workspace / ".selph" / "state" / "onboarding.json", "onboarding"
    )
    credentials_deleted = (
        _try_delete(workspace / ".selph" / "state" / "credentials.json", "credentials")
        if purge_credentials else False
    )
    result = {
        "hooks_removed": hooks_removed,
        "slash_command_deleted": slash_deleted,
        "onboarding_deleted": onboarding_deleted,
        "credentials_deleted": credentials_deleted,
    }
    logger.info(
        "hooks.uninstall_all.complete",
        extra={"event": "bootstrap.hooks.uninstall_all.complete", **result},
    )
    return result


def verify_hooks(workspace: Path) -> bool:
    """True iff all three events have a Selph-owned entry in settings.local.json."""
    path = _settings_local_path(workspace)
    if not path.exists():
        logger.debug(
            "hooks.verify: settings.local.json absent",
            extra={"event": "bootstrap.hooks.verify.absent", "workspace": str(workspace)},
        )
        return False

    settings = _load_settings(path)
    hooks_root: Dict[str, Any] = settings.get("hooks", {})

    for event in _HOOK_EVENTS:
        event_list = hooks_root.get(event, [])
        found = False
        for group in event_list:
            if not isinstance(group, dict):
                continue
            for entry in group.get("hooks", []):
                cmd = entry.get("command", "") if isinstance(entry, dict) else ""
                if _HOOK_OWNER_TAG in cmd and _HOOK_BINARY in cmd:
                    found = True
                    break
            if found:
                break
        if not found:
            logger.debug(
                "hooks.verify: event missing Selph-owned entry",
                extra={
                    "event": "bootstrap.hooks.verify.missing",
                    "hook_event": event,
                    "workspace": str(workspace),
                },
            )
            return False

    logger.debug(
        "hooks.verify: all events present",
        extra={"event": "bootstrap.hooks.verify.ok", "workspace": str(workspace)},
    )
    return True
