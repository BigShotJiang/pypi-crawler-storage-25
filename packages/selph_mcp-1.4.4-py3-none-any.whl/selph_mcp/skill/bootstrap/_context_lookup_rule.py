"""Install/update the skill-author-facing Selph context-lookup rule file.

Writes ``<workspace>/.claude/rules/selph-context-lookup.md`` from the
``templates/selph_context_lookup_rule.md`` template. Idempotent — if the
file is already at the current template content, no-op. If the file exists
but its content between the v1 markers diverged, the marker region is
rewritten in place (user prose outside the markers is preserved).
"""

from __future__ import annotations

from pathlib import Path

from ._shared import _read_template, logger
from ._file_locking import _atomic_write_text, _locked_write

__all__ = ["install_context_lookup_rule"]

_RULE_FILENAME = "selph-context-lookup.md"
_RULE_TEMPLATE = "selph_context_lookup_rule.md"
_MARKER_START = "<!-- selph:context-lookup-rule:v1 START -->"
_MARKER_END = "<!-- selph:context-lookup-rule:v1 END -->"


def _rules_dir(workspace: Path) -> Path:
    return workspace / ".claude" / "rules"


def install_context_lookup_rule(workspace: Path) -> bool:
    """Install the Selph context-lookup rule file under .claude/rules/.

    Returns True if the file was created or its marker region was updated.

    The template is wrapped in HTML-comment markers; this function only
    rewrites the region between them so user-authored prose appended below
    survives a re-install.
    """
    rules_dir = _rules_dir(workspace)
    rules_dir.mkdir(parents=True, exist_ok=True)
    target = rules_dir / _RULE_FILENAME

    template_text = _read_template(_RULE_TEMPLATE)
    s = template_text.find(_MARKER_START)
    e = template_text.find(_MARKER_END)
    if s == -1 or e == -1:
        logger.warning(
            "context-lookup rule markers not found in template; skipping",
            extra={"event": "bootstrap.install_context_lookup_rule.no_markers"},
        )
        return False
    rule_block = template_text[s : e + len(_MARKER_END)]

    changed = {"value": False}

    def _do_write() -> None:
        existing = target.read_text(encoding="utf-8") if target.exists() else ""
        es = existing.find(_MARKER_START)
        ee = existing.find(_MARKER_END)

        if es != -1 and ee != -1 and ee > es:
            current_block = existing[es : ee + len(_MARKER_END)]
            if current_block == rule_block:
                logger.debug(
                    "context-lookup rule already up to date",
                    extra={
                        "event": "bootstrap.install_context_lookup_rule",
                        "changed": False,
                    },
                )
                return
            new_content = (
                existing[:es]
                + rule_block
                + existing[ee + len(_MARKER_END):]
            )
        else:
            sep = ""
            if existing:
                sep = "" if existing.endswith("\n\n") else (
                    "\n" if existing.endswith("\n") else "\n\n"
                )
            new_content = existing + sep + rule_block
            if not new_content.endswith("\n"):
                new_content += "\n"

        _atomic_write_text(target, new_content)
        changed["value"] = True
        logger.info(
            "context-lookup rule installed",
            extra={
                "event": "bootstrap.install_context_lookup_rule",
                "changed": True,
                "path": str(target),
            },
        )

    _locked_write(target, _do_write)
    return changed["value"]
