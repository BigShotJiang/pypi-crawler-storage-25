"""Cache management helpers for the using-selph bootstrap."""

from __future__ import annotations

import json
import os
import shutil
import stat
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from ._shared import logger
from ._paths import _cache_dir

__all__: list[str] = [
    "ensure_cache_dir",
    "purge_cache",
    "handshake_and_purge_if_revoked",
    "fetch_whoami",
    "WhoamiAuthError",
    "WhoamiHTTPError",
    "WhoamiNetworkError",
    "WhoamiValidationError",
]


def ensure_cache_dir(workspace: Path) -> Path:
    """Create ``<workspace>/.selph/cache/`` with mode 0700. Idempotent.

    Returning users hit the cache before any tool result lands, so the dir
    must exist by the time ``record_onboarding_complete`` returns. Mode 0700
    matches the state dir treatment so Posix MAC bits are uniform under
    ``.selph/``.
    """
    cache_dir = _cache_dir(workspace)
    cache_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(cache_dir, 0o700)
    except OSError as exc:
        logger.warning(
            "failed to chmod cache dir to 0700",
            extra={
                "event": "bootstrap.ensure_cache_dir.chmod_failed",
                "path": str(cache_dir),
                "error_type": type(exc).__name__,
            },
        )
    logger.debug(
        "cache dir ensured",
        extra={"event": "bootstrap.ensure_cache_dir", "path": str(cache_dir)},
    )
    return cache_dir


def purge_cache(workspace: Path) -> Path:
    """Destroy and recreate ``<workspace>/.selph/cache/`` with mode 0700.

    Called by :func:`handshake_and_purge_if_revoked` when a revocation
    tombstone is detected.  Also safe to call independently for manual
    cache invalidation.

    The directory is removed with :func:`shutil.rmtree` then recreated
    via :func:`ensure_cache_dir`.  Idempotent: if the cache dir does not
    exist, :func:`ensure_cache_dir` simply creates it.

    Security:
        Before removing anything the resolved target path is verified to
        be a genuine subdirectory of the resolved workspace root (symlink-
        safe ``Path.resolve()`` + ``is_relative_to`` check, same pattern
        as ``install_workflow``).  If any segment on the path to
        ``<workspace>/.selph/cache/`` is a symlink we WARN-log and skip
        the purge to avoid redirected destruction outside the workspace.

    Returns:
        The path to the (re)created cache directory.
    """
    cache_dir = _cache_dir(workspace)

    # ── Containment check (always runs, not just when cache_dir exists) ────
    # A symlinked `.selph` or parent segment can redirect both the rmtree
    # AND the ensure_cache_dir mkdir/chmod outside the workspace, even when
    # the final `cache/` path does not yet exist.  Resolve the parent chain
    # and the workspace with strict=False so this works on cold start, then
    # refuse any side effects if containment fails.
    resolved_workspace = workspace.resolve()
    try:
        resolved_cache = cache_dir.resolve()
    except OSError as exc:
        logger.warning(
            "cache dir path resolution failed; skipping purge",
            extra={
                "event": "bootstrap.purge_cache.resolve_failed",
                "path": str(cache_dir),
                "error_type": type(exc).__name__,
                "error": str(exc),
            },
        )
        return cache_dir

    if not resolved_cache.is_relative_to(resolved_workspace):
        logger.warning(
            "cache dir is outside workspace root; skipping purge (containment check failed)",
            extra={
                "event": "bootstrap.purge_cache.containment_failed",
                "cache_dir": str(cache_dir),
                "resolved_cache": str(resolved_cache),
                "resolved_workspace": str(resolved_workspace),
            },
        )
        return cache_dir

    # Refuse to operate on symlinks at any ancestor below `workspace`.
    # `Path.resolve()` follows symlinks so a symlink pointing inside the
    # workspace passes containment but is still suspicious in a developer-
    # controlled context where no symlinks should exist under `.selph/`.
    probe = cache_dir
    while probe != workspace and probe.parent != probe:
        try:
            lstat_result = probe.lstat()
        except OSError:
            probe = probe.parent
            continue
        if stat.S_ISLNK(lstat_result.st_mode):
            logger.warning(
                "symlink detected under workspace/.selph/; skipping purge (symlink refused)",
                extra={
                    "event": "bootstrap.purge_cache.symlink_refused",
                    "path": str(probe),
                    "cache_dir": str(cache_dir),
                },
            )
            return cache_dir
        probe = probe.parent

    if cache_dir.exists():
        try:
            shutil.rmtree(cache_dir)
            logger.info(
                "cache dir purged",
                extra={
                    "event": "bootstrap.purge_cache.rmtree",
                    "path": str(cache_dir),
                },
            )
        except OSError as exc:
            logger.warning(
                "failed to rmtree cache dir during purge",
                extra={
                    "event": "bootstrap.purge_cache.rmtree_failed",
                    "path": str(cache_dir),
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                },
            )
    return ensure_cache_dir(workspace)


def handshake_and_purge_if_revoked(
    workspace: Path,
    server_url: str,
    api_key: str,
    consumer_id: str,
    since_cursor: int,
    *,
    timeout_secs: float = 5.0,
) -> Tuple[int, bool]:
    """Hit the invalidations endpoint and purge the cache if revoked.

    This is the Phase 6 kill-switch handshake.  It is best-effort:
    network errors are WARNING-logged and swallowed.  The caller should
    treat a network failure as a non-revocation (i.e. continue normally)
    — the kill-switch only fires when the server explicitly returns a
    revocation signal.

    Constraints:
      - MUST NOT import ``selph_db``, ``selph_core``, ``selph_graph``, or
        ``ingestion_api`` (import-linter ``adapters-surface-only``).
      - MUST respect existing Phase 4 hardening (no new file writes that
        bypass ``_atomic_write_text`` / ``_file_lock``).
      - Uses only stdlib HTTP (``urllib.request``) — no ``httpx`` / ``requests``
        dependency at import time.

    Args:
        workspace: The workspace root (same as every other bootstrap call).
        server_url: Base URL of the Selph API server, without trailing
            slash (e.g. ``"https://api.selph.ai"``).
        api_key: The ``X-API-Key`` value for authenticating the request.
        consumer_id: The consumer ID to query.
        since_cursor: The last-seen invalidation seq from the stored
            :class:`OnboardingState`. Pass 0 on first reconnect.
        timeout_secs: Request timeout in seconds.  Defaults to 5.0 —
            kept short so a slow server does not stall the harness cold-start.

    Returns:
        ``(latest_seq, revoked)`` where ``latest_seq`` is the highest
        seq returned by the server (falls back to ``since_cursor`` on
        network error) and ``revoked`` is ``True`` when the server's
        per-consumer ``revoked`` boolean field is ``True``.  On network
        error both return values reflect the pre-call state
        (``since_cursor``, ``False``).

    Side effects:
        Calls :func:`purge_cache` when ``revoked`` is ``True``.
    """
    logger.info(
        "revocation handshake starting",
        extra={
            "event": "bootstrap.handshake.entry",
            "consumer_id": consumer_id,
            "since_cursor": since_cursor,
            "server_url": server_url,
        },
    )

    url = (
        f"{server_url.rstrip('/')}/apps/mcp/consumers"
        f"/{consumer_id}/invalidations?since_cursor={since_cursor}"
    )
    req = urllib.request.Request(
        url,
        headers={
            "X-API-Key": api_key,
            "Accept": "application/json",
        },
        method="GET",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout_secs) as resp:
            body = resp.read()
            data: Dict[str, Any] = json.loads(body.decode("utf-8", errors="replace"))
    except Exception as exc:  # noqa: BLE001 — best-effort, swallow all errors
        logger.warning(
            "revocation handshake request failed; skipping purge",
            extra={
                "event": "bootstrap.handshake.request_failed",
                "consumer_id": consumer_id,
                "since_cursor": since_cursor,
                "error_type": type(exc).__name__,
                "error": str(exc)[:300],
            },
        )
        return since_cursor, False

    latest_seq: int = int(data.get("latest_seq") or since_cursor)
    # Use ONLY the route's top-level ``revoked`` boolean for the
    # self-revocation decision.  The route derives this from
    # ``mcp_consumers.revoked_at IS NOT NULL``, which is per-consumer.
    # Scanning ``kind_prefix == "revoked:*"`` across ALL returned rows
    # is dangerous: GET /invalidations returns rows for the bound user_id,
    # which includes tombstones for OTHER consumers under the same user.
    # Revoking consumer B would previously cause consumer A's cache to be
    # purged (false positive). The top-level boolean is authoritative and
    # correctly scoped to this specific consumer.
    revoked: bool = bool(data.get("revoked", False))

    if revoked:
        logger.warning(
            "consumer revocation detected; purging cache",
            extra={
                "event": "bootstrap.handshake.revoked",
                "consumer_id": consumer_id,
                "server_revoked": revoked,
                "latest_seq": latest_seq,
            },
        )
        purge_cache(workspace)
    else:
        logger.info(
            "revocation handshake complete; consumer is active",
            extra={
                "event": "bootstrap.handshake.active",
                "consumer_id": consumer_id,
                "latest_seq": latest_seq,
                "row_count": len(data.get("invalidations") or []),
            },
        )

    return latest_seq, revoked


# ─────────────────────────────────────────────────────────────────────────────
# Structured exception types for fetch_whoami (Phase 1 §8.3)
# Replaces silent None collapses so callers can record_failure.
# ─────────────────────────────────────────────────────────────────────────────


class WhoamiAuthError(Exception):
    """HTTP 401 or 403 from the Whoami endpoint — auth failed."""
    def __init__(self, status_code: int, body: str = "", *, event_id: str = "") -> None:
        self.status_code = status_code
        self.body = body
        self.event_id = event_id
        super().__init__(f"Whoami auth failed (HTTP {status_code}): {body[:200]}")


class WhoamiHTTPError(Exception):
    """Non-2xx/non-auth HTTP response from the Whoami endpoint."""
    def __init__(self, status_code: int, body: str = "", *, event_id: str = "") -> None:
        self.status_code = status_code
        self.body = body
        self.event_id = event_id
        super().__init__(f"Whoami HTTP error (HTTP {status_code}): {body[:200]}")


class WhoamiNetworkError(Exception):
    """Network-level failure — no HTTP response received."""
    def __init__(self, message: str = "", *, event_id: str = "") -> None:
        self.event_id = event_id
        super().__init__(message)


class WhoamiValidationError(Exception):
    """Response body received but failed Pydantic model validation."""
    def __init__(self, message: str = "", *, event_id: str = "") -> None:
        self.event_id = event_id
        super().__init__(message)


def fetch_whoami(
    server_url: str,
    bearer: str,
    consumer_id: str,
    *,
    timeout_secs: float = 5.0,
) -> Optional[Any]:
    """Call ``GET /apps/mcp/whoami`` and return a validated :class:`Whoami`.

    Sends ``Authorization: Bearer <token>``, ``X-Consumer-Id: <consumer_id>``,
    and a fresh ``X-Selph-Event-Id: <uuid4>`` header per call.  The event_id
    is stamped on every raised exception so callers can pass the same id to
    :func:`record_failure` and achieve correct client ↔ server correlation.

    Returns:
        :class:`Whoami` on HTTP 200 with a valid body.

    Raises:
        :class:`WhoamiAuthError`: HTTP 401 or 403.
        :class:`WhoamiHTTPError`: Other non-2xx HTTP response (e.g. 5xx).
        :class:`WhoamiNetworkError`: Network/timeout failure.
        :class:`WhoamiValidationError`: Response body failed Pydantic validation.

    All raised exceptions carry a ``event_id`` attribute (the UUID that was
    sent as ``X-Selph-Event-Id``).

    Constraints:
    - Uses only stdlib HTTP (``urllib.request``) — no ``httpx`` dependency.
    - Import-linter ``adapters-surface-only``: ``Whoami`` from
      ``selph_mcp.contracts.whoami`` is the only Selph internal import.
    - Validates the response with ``Whoami.model_validate`` per async-safety rule 6
      so contract drift surfaces as ``ValidationError``, not a silent fallback.
    """
    import uuid as _uuid
    from selph_mcp.contracts.whoami import Whoami

    # Mint event_id once per call so the header and any exception carry the same id.
    event_id = str(_uuid.uuid4())

    url = f"{server_url.rstrip('/')}/apps/mcp/whoami"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {bearer}",
            "X-Consumer-Id": consumer_id,
            "X-Selph-Event-Id": event_id,
            "Accept": "application/json",
        },
        method="GET",
    )
    logger.info(
        "whoami fetch starting",
        extra={
            "event": "mcp.using_selph.whoami.entry",
            "consumer_id": consumer_id,
            "server_url": server_url,
            "event_id": event_id,
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout_secs) as resp:
            status = resp.status
            body = resp.read()
    except urllib.error.HTTPError as exc:
        status = exc.code
        body_text = ""
        try:
            body_text = exc.read().decode("utf-8", errors="replace")[:300]
        except Exception:  # noqa: BLE001
            pass
        if status in (401, 403):
            logger.warning(
                "whoami auth failed",
                extra={
                    "event": "mcp.using_selph.whoami.auth_failed",
                    "consumer_id": consumer_id,
                    "http_status": status,
                    "event_id": event_id,
                    "error": str(exc)[:300],
                },
            )
            raise WhoamiAuthError(status, body_text, event_id=event_id)
        logger.warning(
            "whoami endpoint unreachable",
            extra={
                "event": "mcp.using_selph.whoami.unreachable",
                "consumer_id": consumer_id,
                "http_status": status,
                "event_id": event_id,
                "error": str(exc)[:300],
            },
        )
        raise WhoamiHTTPError(status, body_text, event_id=event_id)
    except urllib.error.URLError as exc:
        logger.warning(
            "whoami request failed (network/timeout)",
            extra={
                "event": "mcp.using_selph.whoami.unreachable",
                "consumer_id": consumer_id,
                "event_id": event_id,
                "error_type": type(exc).__name__,
                "error": str(exc)[:300],
            },
        )
        raise WhoamiNetworkError(str(exc), event_id=event_id) from exc
    except Exception as exc:  # noqa: BLE001 — other network/timeout errors
        logger.warning(
            "whoami request failed (unexpected)",
            extra={
                "event": "mcp.using_selph.whoami.unreachable",
                "consumer_id": consumer_id,
                "event_id": event_id,
                "error_type": type(exc).__name__,
                "error": str(exc)[:300],
            },
        )
        raise WhoamiNetworkError(str(exc), event_id=event_id) from exc

    if status >= 500:
        logger.warning(
            "whoami endpoint returned server error",
            extra={
                "event": "mcp.using_selph.whoami.unreachable",
                "consumer_id": consumer_id,
                "http_status": status,
                "event_id": event_id,
            },
        )
        raise WhoamiHTTPError(status, "server error", event_id=event_id)

    if status in (401, 403):
        logger.warning(
            "whoami auth failed",
            extra={
                "event": "mcp.using_selph.whoami.auth_failed",
                "consumer_id": consumer_id,
                "http_status": status,
                "event_id": event_id,
            },
        )
        raise WhoamiAuthError(status, "", event_id=event_id)

    try:
        data = json.loads((body or b"").decode("utf-8", errors="replace"))
        whoami = Whoami.model_validate(data)
    except Exception as exc:
        logger.warning(
            "whoami response failed validation",
            extra={
                "event": "mcp.using_selph.whoami.validation_failed",
                "consumer_id": consumer_id,
                "event_id": event_id,
                "error_type": type(exc).__name__,
                "error": str(exc)[:300],
            },
        )
        raise WhoamiValidationError(str(exc), event_id=event_id) from exc

    logger.info(
        "whoami fetch complete",
        extra={
            "event": "mcp.using_selph.whoami.complete",
            "consumer_id": whoami.consumer_id,
            "user_id": whoami.user_id,
            "event_id": event_id,
        },
    )
    return whoami
