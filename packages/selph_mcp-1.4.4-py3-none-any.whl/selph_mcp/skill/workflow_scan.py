"""Workflow scan — personalization proposal generator (§4.7 / Phase C3).

Scans the workspace for installed workflows, classifies them (Selph-managed
vs unmanaged pre-existing), parses ``<!-- selph:skill-meta:v1 ... -->`` lines,
applies the exclusion list from §4.7, and emits :class:`WorkflowProposal`
entries.

Pure-ish: the only I/O is reading SKILL.md files from disk.

Layer/import constraints (per ``.importlinter`` rule ``adapters-surface-only``):
- ALLOWED: ``selph_mcp.contracts``, ``selph_utils``, stdlib, this package.
- FORBIDDEN: ``selph_core``, ``selph_db``, ``selph_graph``, ``ingestion_api``,
  ``selph_apps``.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

from selph_mcp._log import get_logger

from .state_schema import (
    MEMORY_BOUNDARY_POLICY_VERSION,
    OnboardingState,
    PersonalizationMode,
    WorkflowProposal,
    WorkflowScanCandidate,
    WorkflowScanReport,
)

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Marker constants (re-declared here for module independence; canonical values
# live in bootstrap._WORKFLOW_SKILL_MARKER_START etc.)
# ---------------------------------------------------------------------------
_WORKFLOW_SKILL_MARKER_START = "<!-- selph:workflow-skill:v1 START -->"
_SKILL_META_MARKER_PREFIX = "<!-- selph:skill-meta:v1"

# ---------------------------------------------------------------------------
# §4.7 exclusion list — workflow_id prefixes/keywords to skip for proposals.
# Case-insensitive substring match against the workflow_id.
# ---------------------------------------------------------------------------
_EXCLUSION_KEYWORDS = frozenset(
    [
        "coding",
        "debug",
        "debugging",
        "repository",
        "repo-maintenance",
        "repo_maintenance",
        "infrastructure",
        "deploy",
        "deployment",
        "infra",
        "ci",
        "cd",
        "linting",
        "formatting",
        "refactor",
    ]
)


def _is_excluded(workflow_id: str) -> bool:
    """Return True when ``workflow_id`` matches an exclusion class."""
    lower = workflow_id.lower()
    return any(kw in lower for kw in _EXCLUSION_KEYWORDS)


_SELPH_TOOL_PREFIX = "mcp__selph-remote__"


def _has_selph_tool_in_allowed_tools(text: str) -> bool:
    """Return True when the SKILL.md frontmatter `allowed-tools` lists
    at least one ``mcp__selph-remote__*`` entry.

    Recognises both block form::

        allowed-tools:
          - mcp__selph-remote__ask_selph

    and flow form::

        allowed-tools: [mcp__selph-remote__ask_selph, Read]

    Scan is bounded to the leading YAML frontmatter delimited by ``---``
    lines. Skills without frontmatter return False (the rule treats
    absence of frontmatter as absence of allowlisted Selph tools).
    """
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return _SELPH_TOOL_PREFIX in text and _is_in_yaml_allowed_tools_loose(text)

    # Bound the scan to the frontmatter region.
    end_idx: Optional[int] = None
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            end_idx = idx
            break
    if end_idx is None:
        return False
    fm = "\n".join(lines[1:end_idx])

    # Find an ``allowed-tools:`` key.
    in_block = False
    for raw in fm.splitlines():
        stripped = raw.strip()
        if not in_block:
            if stripped.startswith("allowed-tools:") or stripped.startswith(
                "allowed_tools:"
            ):
                tail = stripped.split(":", 1)[1].strip()
                if tail.startswith("[") and tail.endswith("]"):
                    # Flow form on one line.
                    return _SELPH_TOOL_PREFIX in tail
                if tail and tail != "":
                    # Single inline value: ``allowed-tools: mcp__selph-...``
                    return _SELPH_TOOL_PREFIX in tail
                in_block = True
                continue
        else:
            if not raw.startswith((" ", "\t", "-")) and stripped:
                # End of block — next top-level key.
                return False
            if _SELPH_TOOL_PREFIX in raw:
                return True
    return False


def _is_in_yaml_allowed_tools_loose(text: str) -> bool:
    """Fallback for files with no leading ``---`` fence — still allow
    the heuristic to succeed when the SKILL.md contains an
    ``allowed-tools:`` section anywhere in the file.
    """
    seen_key = False
    for raw in text.splitlines():
        stripped = raw.strip()
        if stripped.startswith("allowed-tools:") or stripped.startswith(
            "allowed_tools:"
        ):
            seen_key = True
            tail = stripped.split(":", 1)[1].strip()
            if tail.startswith("[") and tail.endswith("]"):
                return _SELPH_TOOL_PREFIX in tail
            if tail:
                return _SELPH_TOOL_PREFIX in tail
            continue
        if seen_key and _SELPH_TOOL_PREFIX in raw:
            return True
        if seen_key and stripped and not raw.startswith((" ", "\t", "-")):
            return False
    return False


def _parse_skill_meta(text: str) -> tuple[PersonalizationMode, Optional[int]]:
    """Parse ``<!-- selph:skill-meta:v1 ... -->`` from SKILL.md text.

    Returns ``(personalization_mode, policy_version_last_applied)``.
    Falls back to ``(UNKNOWN, None)`` when no meta tag is present.
    """
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped.startswith(_SKILL_META_MARKER_PREFIX):
            continue
        # personalization_mode=eligible
        mode_match = re.search(r"personalization_mode=(\S+)", stripped)
        # policy_version_last_applied=1
        pv_match = re.search(r"policy_version_last_applied=(\d+|null)", stripped)

        raw_mode = mode_match.group(1) if mode_match else None
        try:
            mode = PersonalizationMode(raw_mode) if raw_mode else PersonalizationMode.UNKNOWN
        except ValueError:
            mode = PersonalizationMode.UNKNOWN

        policy_version: Optional[int] = None
        if pv_match:
            pv_str = pv_match.group(1)
            if pv_str != "null":
                try:
                    policy_version = int(pv_str)
                except ValueError:
                    policy_version = None

        return mode, policy_version

    return PersonalizationMode.UNKNOWN, None


def scan_workspace_workflows(
    workspace: Path,
    state: OnboardingState,
) -> WorkflowScanReport:
    """Scan the workspace for workflows and generate personalization proposals.

    Args:
        workspace: The workspace root (same value as everywhere else in bootstrap).
        state: The current :class:`OnboardingState` (provides ``installed_workflows``).
            Must be an ``OnboardingState`` instance, NOT the ``State`` discriminated
            union returned by ``detect_state``. On a ``Returning`` result, pass
            ``returning_result.state`` (the nested ``OnboardingState``).

    Returns:
        :class:`WorkflowScanReport` with ``candidates`` and ``proposals``.

    Pure-ish: reads SKILL.md files from disk; never writes.

    Raises:
        TypeError: if ``state`` is not an ``OnboardingState`` instance, so that
            callers that pass the raw ``State`` union fail loudly rather than
            silently producing empty results.
    """
    if not isinstance(state, OnboardingState):
        raise TypeError(
            f"scan_workspace_workflows expects OnboardingState, got "
            f"{type(state).__name__}. "
            "If you have a Returning result from detect_state(), pass "
            "returning_result.state — not the Returning object itself."
        )
    logger.info(
        "scan_workspace_workflows: starting",
        extra={
            "event": "bootstrap.scan_workspace_workflows.entry",
            "workspace": str(workspace),
            "installed_count": len(state.installed_workflows),
        },
    )

    skills_root = workspace / ".claude" / "skills"
    installed_set = set(state.installed_workflows)

    # --- Collect on-disk workflow ids ----------------------------------------
    on_disk: dict[str, Path] = {}  # workflow_id -> SKILL.md path
    if skills_root.exists():
        for skill_md in skills_root.glob("*/SKILL.md"):
            workflow_id = skill_md.parent.name
            on_disk[workflow_id] = skill_md

    # --- Detect installed-but-missing workflows (emit advisory drift) --------
    missing_from_disk: list[str] = []
    for wf_id in installed_set:
        if wf_id not in on_disk:
            missing_from_disk.append(wf_id)
            logger.warning(
                "installed workflow missing on disk",
                extra={
                    "event": "bootstrap.scan_workspace_workflows.missing_on_disk",
                    "workflow_id": wf_id,
                },
            )

    # --- Build candidates ----------------------------------------------------
    candidates: list[WorkflowScanCandidate] = []
    for wf_id, skill_path in on_disk.items():
        classification: str = (
            "selph_managed" if wf_id in installed_set else "unmanaged_preexisting"
        )

        try:
            skill_text = skill_path.read_text(encoding="utf-8")
        except OSError as exc:
            logger.warning(
                "scan_workspace_workflows: cannot read SKILL.md",
                extra={
                    "event": "bootstrap.scan_workspace_workflows.read_failed",
                    "workflow_id": wf_id,
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:200],
                },
            )
            skill_text = ""

        mode, last_pv = _parse_skill_meta(skill_text)
        has_selph_tool = _has_selph_tool_in_allowed_tools(skill_text)

        candidates.append(
            WorkflowScanCandidate(
                workflow_id=wf_id,
                skill_md_path=str(skill_path),
                classification=classification,  # type: ignore[arg-type]
                personalization_mode=mode,
                last_policy_version_applied=last_pv,
                has_selph_tool_allowlisted=has_selph_tool,
            )
        )

    # --- Generate proposals --------------------------------------------------
    proposals: list[WorkflowProposal] = []

    # Advisory proposals for missing-from-disk installed workflows
    for wf_id in missing_from_disk:
        if _is_excluded(wf_id):
            continue
        proposals.append(
            WorkflowProposal(
                workflow_id=wf_id,
                proposal_kind="upgrade_in_place",
                drift_reasons=["installed_workflow_missing_on_disk"],
                suggested_action=(
                    f"Workflow '{wf_id}' is tracked as installed but its "
                    "SKILL.md is missing. Re-install to restore it."
                ),
            )
        )

    for candidate in candidates:
        wf_id = candidate.workflow_id

        if _is_excluded(wf_id):
            logger.debug(
                "scan_workspace_workflows: workflow in exclusion list; skipping",
                extra={
                    "event": "bootstrap.scan_workspace_workflows.excluded",
                    "workflow_id": wf_id,
                },
            )
            continue

        # Selph context-lookup advisory — flag any skill whose frontmatter
        # is missing every ``mcp__selph-remote__*`` entry. The scanner
        # cannot prove the skill needs Selph at runtime; it only surfaces
        # the absence of capability. Skip when personalization is
        # explicitly declared not-applicable.
        if (
            not candidate.has_selph_tool_allowlisted
            and candidate.personalization_mode != PersonalizationMode.NOT_APPLICABLE
        ):
            proposals.append(
                WorkflowProposal(
                    workflow_id=wf_id,
                    proposal_kind="advisory_only",
                    drift_reasons=["no_selph_tool_allowlisted"],
                    suggested_action=(
                        f"'{wf_id}' has no `mcp__selph-remote__*` tool in its "
                        "allowed-tools frontmatter. If this skill ever "
                        "operates on input naming people, projects, or "
                        "events, it cannot honour the context-lookup rule "
                        "(.claude/rules/selph-context-lookup.md). Add at "
                        "least `mcp__selph-remote__ask_selph` and "
                        "`mcp__selph-remote__get_context`, or declare the "
                        "skill personalization_mode=not_applicable in its "
                        "skill-meta tag."
                    ),
                )
            )

        if candidate.classification == "selph_managed":
            pv = candidate.last_policy_version_applied
            if pv is None or pv < MEMORY_BOUNDARY_POLICY_VERSION:
                proposals.append(
                    WorkflowProposal(
                        workflow_id=wf_id,
                        proposal_kind="upgrade_in_place",
                        drift_reasons=["memory_boundary_policy_version"],
                        suggested_action=(
                            f"Update '{wf_id}' to the current memory-boundary "
                            f"policy (v{MEMORY_BOUNDARY_POLICY_VERSION})."
                        ),
                    )
                )
            else:
                proposals.append(
                    WorkflowProposal(
                        workflow_id=wf_id,
                        proposal_kind="noop",
                        drift_reasons=[],
                        suggested_action="Already at current policy version.",
                    )
                )

        else:
            # unmanaged_preexisting
            if candidate.personalization_mode == PersonalizationMode.UNKNOWN:
                proposals.append(
                    WorkflowProposal(
                        workflow_id=wf_id,
                        proposal_kind="advisory_only",
                        drift_reasons=[],
                        suggested_action=(
                            f"Review whether Selph personalization would help "
                            f"'{wf_id}'; Selph cannot upgrade this workflow "
                            "automatically (unmanaged)."
                        ),
                    )
                )
            elif candidate.personalization_mode == PersonalizationMode.ELIGIBLE:
                pv = candidate.last_policy_version_applied
                if pv is None or pv < MEMORY_BOUNDARY_POLICY_VERSION:
                    proposals.append(
                        WorkflowProposal(
                            workflow_id=wf_id,
                            proposal_kind="advisory_only",
                            drift_reasons=["memory_boundary_policy_version"],
                            suggested_action=(
                                f"'{wf_id}' is marked personalization-eligible "
                                "but is unmanaged. Review whether Selph should "
                                "take ownership and apply the current policy."
                            ),
                        )
                    )
            # NOT_APPLICABLE: skip (no proposal)

    logger.info(
        "scan_workspace_workflows: complete",
        extra={
            "event": "bootstrap.scan_workspace_workflows.complete",
            "candidate_count": len(candidates),
            "proposal_count": len(proposals),
            "missing_from_disk_count": len(missing_from_disk),
        },
    )

    return WorkflowScanReport(candidates=candidates, proposals=proposals)


__all__ = ["scan_workspace_workflows"]
