<!-- selph:context-lookup-rule:v1 START -->
# Selph context-lookup rule (for skill authors)

This rule applies to every skill, agent, slash command, hook, or controller
in this workspace that operates on user input. It is installed by the
`using-selph` adapter and is the authoring counterpart to the runtime
retrieval policy in `CLAUDE.md`.

## The rule

When your skill's operation encounters a **named person, project, event,
relationship, place, or pursuit** in its input, you must resolve it
through Selph before reasoning about it, drafting on top of it, or
acting on it. Do not assume the name is unfamiliar. Do not fabricate
context. Do not silently skip the lookup.

The skill's source file usually contains no names — names arrive at
runtime via the task it is asked to do. The lookup decision happens
inside the skill's operation, not in its description.

Concretely:

1. **Check local first.** Read what's already in the active session
   transcript and the workspace cache (`<workspace>/.selph/cache/`).
   If the context is there, use it. A cache miss is fine.
2. **If not local, call Selph.** Use the appropriate persona tool:
   - `mcp__selph-remote__ask_selph(question=…)` — for a specific
     question ("Who is Thomas?", "What's the status of the API
     migration?").
   - `mcp__selph-remote__get_context(subject=…, intent=…)` — for a
     briefing or operating-manual block on the user, a person, a
     project, or a topic.
   - `mcp__selph-remote__get_entity_card(entity_id=…)` — when you
     already have a resolved entity ID and need its card.
   - `mcp__selph-remote__find_evidence(ref_id=…)` — to surface the
     specific evidence behind a claim.
3. **Honour the sparse-graph posture.** When `meta.confidence < 0.3`
   or `meta.evidence_count == 0`, lead with *"I don't know you well
   enough yet."* — never substitute a softer phrase. Then explain
   plainly what Selph has and what would help.
4. **Cite.** Surface the citation chips Selph returns. Don't repackage
   them as your own reasoning.

## When the rule does NOT apply

- Pure code, infrastructure, lint, build, deploy, or refactor skills
  that never touch user-personal input.
- Skills whose input is bounded to source files the user has open in
  this repo.
- Skills that explicitly declare `personalization_mode=not_applicable`
  in their skill-meta tag and document why.

If you are unsure, lean toward calling Selph. A wasted call is cheap;
a fabricated "I already know who Thomas is" is the failure mode this
rule exists to prevent.

## Required `allowed-tools` entries

If a skill can operate on user-personal input at runtime, its
frontmatter `allowed-tools` must include at least:

```yaml
allowed-tools:
  - mcp__selph-remote__ask_selph
  - mcp__selph-remote__get_context
```

Add others (`get_entity_card`, `find_evidence`, `what_changed`) as the
skill's responsibilities require. Without these in `allowed-tools`,
the rule above is unenforceable — the harness will not be able to call
Selph when the skill's operation says it should.

## Authoring scaffold

Copy `templates/workflow_skill_author.md.tmpl` (shipped by the
`using-selph` wheel) as the starting point for any new skill. The
scaffold pre-wires the `allowed-tools` entries above and includes the
Phase 0 named-entity decision step.

## How this is enforced

- `selph-mcp-bootstrap scan-workflows` flags any on-disk skill whose
  frontmatter is missing all `mcp__selph-remote__*` entries with
  `drift_reasons=["no_selph_tool_allowlisted"]`. The first-run and
  returning-user flows surface those proposals to the user during
  `/using-selph`.
- The scanner cannot prove a skill *needs* Selph at runtime — that's a
  behavioural property. It can only surface the absence of capability.
  The judgement call ("does this skill ever touch named entities?")
  belongs to the skill's author.

This rule supersedes any earlier informal expectation. If you are
patching an existing skill to comply, update both its `allowed-tools`
frontmatter and its operation body in the same change.
<!-- selph:context-lookup-rule:v1 END -->
