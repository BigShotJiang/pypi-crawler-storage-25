# Uninstall flow

Read this file when the user asks to uninstall, remove, or disable Selph
from their workspace.

There are two levels of removal. Explain both clearly, then ask the user
which they want.

---

## Option 1 — Remove ambient capture only

```bash
selph-mcp-bootstrap uninstall-hooks --workspace "<cwd>"
```

This removes the three hook entries Selph added to
`<workspace>/.claude/settings.local.json`. Selph will stop quietly
observing conversation turns in this workspace.

**What is removed:**
- Hook entries for UserPromptSubmit, Stop, and SessionEnd in
  `.claude/settings.local.json`

**What stays in place:**
- Your slash command file (`~/.claude/commands/using-selph.md`)
- Your workspace credentials (`.selph/state/credentials.json`)
- Your onboarding state (`.selph/state/onboarding.json`)
- Any existing spool data (`.selph/state/session_spool.db`)
- Any installed workflow SKILL.md files

---

## Option 2 — Remove everything Selph added to this workspace

```bash
selph-mcp-bootstrap uninstall-all --workspace "<cwd>"
```

**What is removed:**
- Hook entries in `.claude/settings.local.json` (same as Option 1)
- The slash command file at `~/.claude/commands/using-selph.md`
- Onboarding state at `.selph/state/onboarding.json`

**What stays in place:**
- Your workspace credentials (`.selph/state/credentials.json`) —
  kept so you can re-onboard without re-registering

---

## Option 2b — Remove everything including credentials

```bash
selph-mcp-bootstrap uninstall-all --workspace "<cwd>" --purge
```

**What is removed (in addition to Option 2):**
- `.selph/state/credentials.json`

Use `--purge` only if you want to fully reset your workspace's connection to
Selph. After this, you will need to run `/using-selph` again to re-onboard.

---

## After uninstalling

- If you removed hooks only (Option 1): Selph still knows this workspace but
  will no longer observe turns. You can re-install at any time with
  `selph-mcp-bootstrap install-hooks --workspace "<cwd>"`.
- If you ran `uninstall-all`: the slash command is gone. To restore it, run
  `selph-mcp-bootstrap install-slash-command`.
- If you ran `uninstall-all --purge`: you will need to re-register and
  re-onboard via `/using-selph`.

---

## Presenting the choice

Ask the user which option they want before running any command:

> I can remove Selph's ambient capture from this workspace (keeps the slash
> command and your connection intact), or I can remove everything Selph
> added here.
>
> Which would you prefer?
>   [1] Remove ambient capture hooks only
>   [2] Remove everything (hooks + slash command + workspace state)
>   [3] Remove everything including credentials (full reset)
>   [4] Never mind — leave it as-is

On `[4]`, do nothing and close with "No changes made."
