# Memory boundary — durable vs operational

Read this file when you are building, evaluating, or operating any
feature that has *memory of any kind*: tasks, reminders, drafts, prep
work, journals, queues, inboxes, run logs, scratchpads, planning
surfaces, agent state, reading history — anything stateful that lives
alongside the user's durable context in Selph.

The slim controller does not need to load this file during normal
onboarding. The CLAUDE.md block installed in the user's workspace
carries the one-screen summary of the rule; this file is the long-form
contract and example bank for cases where the summary isn't enough.

The persistent-assistant / task-manager case is the lead worked example
because it is where the boundary bites first and hardest. The rule is
not specific to it.

---

## The boundary in one sentence

> Selph remembers that something is *true*, *happened*, or *was
> decided*. The adapter manages whether it is still open, due, in
> progress, blocked, or already done.

That is the entire product split. Everything below is the same rule
applied to specific shapes of state.

---

## Two stores, two kinds of memory

### Durable memory — lives in Selph

Retrieved with `get_context`, `ask_selph`, `get_entity_card`,
`find_evidence`, `what_changed`. Written through `observe_session` when
something durable actually changes; corrected through `correct`.

What belongs here:

- projects you are working on
- goals and pursuits you are moving toward
- relationships and client status
- preferences
- recurring constraints
- major decisions
- stable operating context
- durable evidence that something happened
- patterns across time and conversations

When the user says *"what was I supposed to talk to Sam about?"* — the
*who is Sam*, *what is the project*, *what's our last decision* all
live in Selph. The follow-up reminder itself does not.

### Operational memory — lives locally

Lives under `.selph/state/<feature>/` (durable across sessions but
adapter-owned), `.selph/cache/` (rebuildable performance cache), or
plain workspace files / app state. The adapter is free to design
whatever store fits the feature. The only rule is: **don't push
operational state through Selph**.

What belongs here:

- inbox items
- tasks and subtasks, reminders, due dates, follow-ups, waiting-ons
- prep artifacts (drafts, scratch notes, working summaries)
- execution queues, run history
- status transitions (`todo`, `doing`, `blocked`, `done`, `deferred`)
- local summaries that are only useful for the current execution
- in-flight planning artefacts (a meeting agenda being assembled, a
  reply being drafted, a feature spec being written)
- per-feature counters, cursors, last-seen timestamps

This is normal adapter behaviour. It is not an implementation accident
to clean up later — it is the architecture.

### Naming convention

When a feature needs durable adapter-local state, prefer
`.selph/state/<feature>/<kind>.json` (or similar) so a new repo touching
the same feature finds the same shape. Examples:

- `.selph/state/tasks/inbox.json`
- `.selph/state/journal/drafts/`
- `.selph/state/agent-runs/history.jsonl`

This keeps the operational store discoverable, clearly local, and
clearly not Selph-managed.

---

## Memory shape vs state shape (worked example: tasks)

The user says: *"Remind me Friday to send Julian the revised SOW. He's
been waiting since Tuesday and we said end of week."*

Two different things are present in that one sentence:

- **State shape** — what the operational system needs:
  `due=Friday`, `for=Julian`, `artifact=revised SOW`,
  `status=waiting on me`, `prior_commitment=end of week`. This is
  ephemeral. It changes the moment the SOW is sent. Keep it local.

- **Memory shape** — what Selph needs (only if durable):
  Julian is currently an active counterparty on this engagement; the
  SOW track was committed to end-of-week. That part is durable context
  about a relationship and a commitment. It may already be in Selph;
  if it is genuinely new, it belongs there.

If the SOW gets sent tomorrow, the state shape evaporates. Selph still
remembers that there is/was a Julian engagement with a SOW track. That
asymmetry is the whole point — and it generalizes:

- Drafting feature: *draft body* is state; *the user has a writing
  voice they ask for help with* is memory.
- Reading-history feature: *which articles are unread* is state; *this
  user reads about distributed-systems papers* is memory.
- Agent-runs feature: *run #482 is in progress* is state; *the user
  delegates research-and-summarize tasks to AI* is memory.

---

## The decision test (use this on every feature event)

For every utterance, file change, queue entry, or feature event, ask
three questions:

1. **Is there durable context here?** A new project, a stated goal, a
   relationship update, a preference, a recurring constraint, a major
   decision, a correction to prior understanding.
2. **Is there operational state here?** A due date, a status change,
   a piece of prep work, a draft, a queue entry, a reminder.
3. **Is the durable part already in Selph?** If yes, no writeback
   needed unless this is a *change* to it (correction, supersede,
   expire).

Then:

| Pattern | Local state | Selph writeback |
|---|---|---|
| Operational only | yes | no — or one optional evidence writeback if the *pattern* is durable |
| Durable only | only if it cancels/reprioritizes existing operational state | yes — `observe_session` the durable change |
| Both | yes | yes — write the durable side; operational state follows |
| Neither (chat scaffolding, venting, brainstorming) | maybe (scratch) | no |

---

## The default retrieval-and-plan pattern

This pattern applies to any feature that combines "what's happening
now" with "who and what is involved": meeting prep, outreach prep,
project planning, follow-up planning, weekly review, daily
prioritization, drafting a reply, building an agenda, queueing a batch,
summarizing a session.

1. **Keep the operational state local.** Do not load it from Selph; do
   not write it to Selph.
2. **Retrieve Selph context** for the linked people, projects, goals,
   pursuits, constraints. The right tools:
   - `get_context(intent="briefing", subject=...)` — quick orientation
   - `ask_selph(question=...)` — specific durable question
   - `get_entity_card(entity_id=...)` — one person/project/etc.
   - `what_changed(since_cursor=...)` — drift since last session
3. **Build the operational artefact locally.** Plan, draft, queue,
   summary — all combine the local state with the retrieved durable
   context. The artefact stays local.
4. **Only write back what crossed the durable threshold.** A real
   change in projects, goals, relationships, constraints, or patterns
   — not the artefact itself, not the local state.

Decision check: would Selph still need to know this six months from
now, even if every operational artefact in the workspace were deleted?
If yes, write it. If no, keep it local.

---

## Worked examples (task-manager case)

This is the case the rule was first written for. The patterns here are
the canonical illustrations of the general rule.

### Reminders / follow-ups

> "Remind me to follow up with Julian tomorrow."

- Local: yes — schedule the reminder.
- Selph: no by default. Optional one-shot evidence writeback only if
  the pattern of asking-the-assistant-to-track-this-relationship is
  itself durable context worth recording.

### Prep work / drafting

> "Draft research for my meeting with Candace."

- Local: yes — keep the draft, the deadline, the meeting reference.
- Selph: no for the draft. If the meeting is on a project Selph
  already knows about, retrieve from Selph for context (do not push
  prep into it). A single delegation-evidence writeback is acceptable
  to capture *that* the user delegates research; never push the draft
  itself.

### Due dates

> "This is due Friday."

- Local: yes.
- Selph: no. Due dates are ephemeral.

### Project reprioritization

> "Selph platform is my top priority this quarter."

- Local: yes — re-rank the active queue.
- Selph: yes — `observe_session` the priority statement. Quarter-level
  priority is durable goal/project context.

### Relationship / status change

> "Julian is now an active client."

- Local: maybe — the existing operational items may now matter more.
- Selph: yes — `observe_session` the status change. Client status is
  durable.

### Cancellations / pursuit changes

> "I'm no longer pursuing Black AI Builders."

- Local: yes — cancel any dependent operational items.
- Selph: yes — `observe_session` as a correction or expiration of the
  pursuit. Use `correct(...)` if there is an existing record to
  invalidate.

### Pure venting or brainstorming

> "I'm so behind on everything, I just need to power through."

- Local: maybe — surface as a wellbeing signal in the operational layer.
- Selph: no. Venting and rough planning clutter are not evidence.

---

## Other features the same rule covers

The shape of the boundary is identical regardless of feature.

### A journaling feature

- Local: the entry text in progress, the calendar of past entries, any
  draft you're editing.
- Selph: a stated insight ("I realized I avoid hard conversations"),
  a stated goal ("I want to write three times a week"), a recurring
  pattern that has corroboration.

### A reading-history feature

- Local: which items are unread, last-read position, sync cursor.
- Selph: stated interests, durable preferences ("I prefer long-form
  to listicles"), patterns observed across many items.

### An agent-runs / queue feature

- Local: queue contents, current run status, last N run logs, retry
  state.
- Selph: stated delegation patterns, recurring problem types the user
  brings, durable preferences about how the user wants assistance to
  behave.

### A spec / planning workspace

- Local: the spec being drafted, comment threads, decision-in-progress
  notes.
- Selph: the *finished* decisions, the project itself, who is involved,
  what constraints apply.

The same decision test applies: durable context → Selph; operational
state → local.

---

## Anti-patterns to avoid in any feature

1. **Selph as the live operational store.** Querying Selph at the
   start of every session to find out what is in progress. The
   in-progress list is local.
2. **One Selph memory per operational instance.** Don't write a Selph
   memory for every "remind me", "queue this", "draft that". The
   *pattern* may be durable; each instance is not.
3. **Round-tripping operational state.** Reading from local storage,
   posting to Selph, reading back from Selph. Wrong store.
4. **Writeback on every utterance.** Most conversation is scaffolding.
   Write back when something has actually crossed into durable
   territory, not on every turn.
5. **Asking Selph to evaluate operational progress.** Selph has no
   opinion on whether you finished a task, sent a draft, or finished a
   run. The adapter knows; Selph doesn't.
6. **Inventing a graph layer for operational state.** No fifth KG
   layer. Operational state is not a Selph concern; it has no place in
   the persona graph or any future "operational layer" inside it.

---

## When the boundary is genuinely ambiguous

Default to **local**. Selph can always be told later — corroboration,
recurrence, explicit endorsement all turn a candidate into evidence.
Pulling a hasty memory back out (`correct(...)`, hub rebuilds, L3
invalidation) is more expensive than waiting for the durable shape to
surface.

When the user later confirms ("yeah, I do that every week" / "this
really is a long-term thing"), then write it. Endorsement turns a
candidate into evidence.

---

## Cross-references

- [`../flows/returning.md`](../flows/returning.md) — how the slim
  controller routes returning-user sessions.
- [`./voice-and-evidence.md`](./voice-and-evidence.md) — sparse-graph
  posture and evidence-chip contract; both still apply when echoing
  durable context back into any operational artefact.
- The CLAUDE.md block installed in the user's workspace carries the
  one-screen summary of this contract. This file is the long-form
  version for cases the summary doesn't cover.
