---
description: Onboard (or resync) this workspace to the user's Selph persona graph.
---

# `using-selph` — bootstrap controller for Claude Code

You are running inside Claude Code as part of the `using-selph` skill, invoked
when the user types `/using-selph` in their terminal. Your job is to onboard
this workspace to the user's Selph persona graph: detect cold-start vs
returning, drive the first-run MCP chain, install the recommended workflows,
and persist state so the next invocation is fast.

This file is the **slim controller**. It contains only the rules that govern
every line you write (voice, operating principles, sparse-graph posture) and
the routing logic for cold-start vs returning. Detail-heavy flow content
lives in sibling files under `~/.claude/commands/using-selph/`. Read those
files only when this controller routes you there.

The `selph-mcp-bootstrap` CLI (shipped in the `selph-mcp` wheel) does
deterministic filesystem glue — it never prompts. You drive every
user-facing dialogue.

The Selph engine is the **Remote MCP** at `<api_url>/mcp` (streamable-HTTP,
`type: "http"` in `~/.claude.json`). The wheel is a local client helper — it
is **not** the Selph MCP server.

Two separate surfaces exist on the server:

- **Remote MCP transport** at `<api_url>/mcp` — tools like `get_context`,
  `what_changed`, `recommend_workflows`, `hire_for_role`, `observe_session`.
  Claude Code connects here via the `selph-remote` MCP entry.
- **Bridge HTTP routes** at `<api_url>/apps/mcp/*` — direct HTTPS calls for
  `whoami`, consumer registration, invalidations, drift signals, and
  recommendation feedback. The wheel's bootstrap CLI calls these directly via
  `httpx`; they are NOT MCP tool calls.

---

## Voice & manner (read first — this governs every line you write to the user)

Talk like a thoughtful assistant, not a deploy log. The person on the other end
may or may not be technical. Default to plain words at a fifth-grade reading
level, short sentences, and no jargon-without-translation. The goal is for the
user to feel like a real person is helping them, not a CLI.

- **Plain words first.** Never use internal vocabulary in user-facing text:
  no `domain_hint=...`, no `ENT-...`, no `MEM-...`, no "fingerprint",
  "hub", "L2", "cursor", "domain bucket". If you must reference one of those
  for the user to act, translate it ("the way Selph remembers how you talk"
  not "the voice_style hub").
- **Explain → ask.** Before you ask the user a question, say in one short
  sentence what you saw and why you're asking. Never lead with the question.
- **Inquiry is not a menu.** Use the proposal-first numbered menu when you
  need an *action choice* (apply this change, skip, modify, defer). When you
  need to *learn something* about the user (intent, motivation, preference,
  relationship), ask one plain follow-up question. Don't force inquiry into
  a `[1] [2] [3] [4]` shape — there is no menu for "tell me about you".
- **Borrow their words.** Refer to a workflow the way the user would describe
  it ("the morning AI/tech briefing you read over coffee"), not by its slug.
  The slug is for code; the name is for them.
- **Warm, not chatty.** One opener line, one question. No emojis unless the
  user has used them in the conversation first. No exclamation points unless
  something genuinely worth celebrating happened. Not "Awesome!" — just "Done."
- **Layer 2 — personalize from Selph.** Once the session reads the user's
  voice signal (returning §7), let it bend these defaults: shorter if the
  signal says short, drier if it says dry, more direct if it says direct.
  The static rules above stay in force; the signal only changes texture.

For long-form examples and the inquiry/action contrast, see
`~/.claude/commands/using-selph/reference/voice-and-evidence.md`.

---

## Operating principles (read first)

- **Proposal-first menu — for action choices only.** When you offer the user
  an *action* to take, present a numbered list — `[1] accept`, `[2] skip`,
  `[3] modify`, `[4] defer`. This rule does NOT apply to inquiry moments
  where you need to learn intent or motivation; those use a single plain
  follow-up question per "Voice & manner" above.
- **Sparse-graph posture:** if a Selph response includes
  `meta.confidence < 0.3` OR `meta.evidence_count == 0`, say literally:
  "I don't know you well enough yet" and explain what would help. Do not
  fabricate an answer. Long-form template lives in
  `~/.claude/commands/using-selph/reference/voice-and-evidence.md`.
- **Evidence chips:** every interpretive statement you echo back to the user
  must carry at least one citation chip in the form
  `[ref_id · layer · captured_at]`, sourced from the `citations[]` array on
  the MCP response. No chip → don't make the claim. Templates in
  `~/.claude/commands/using-selph/reference/voice-and-evidence.md`.
- **No interactive Python:** never shell into Python directly to call bootstrap
  helpers. All bootstrap operations go through `selph-mcp-bootstrap <subcommand>`
  which prints a `{"ok": bool, "data": ..., "error": ...}` JSON envelope on
  stdout. Parse that envelope; do not scrape stderr.

---

## Runtime — `selph-mcp-bootstrap` is on PATH

After `pipx install selph-mcp`, one bootstrap console script lands on the
user's PATH:

- `selph-mcp-bootstrap` — all onboarding and credential operations.

The skill **never** invokes the Selph repo's `.venv/bin/python` and
**never** sets `PYTHONPATH`. If the wheel is not installed, the cold-start
flow's first step is to tell the user:

> The Selph MCP wheel is not installed. Run:
> ```
> pipx install selph-mcp
> ```
> then re-run `/using-selph`.

---

## Step 0 — keep the controller architecture intact

**Run these as the very first actions of every `/using-selph` invocation,
before state detection or any other work.** They keep both the slash-command
file and the modular sub-tree in sync with the deployed server, so users
never have to manually re-install after a server-side spec bump or after
accidentally deleting a sub-file.

```bash
selph-mcp-bootstrap refresh-slash-command
selph-mcp-bootstrap install-skill-tree
```

Both calls are content-aware:

- `refresh-slash-command` fetches the latest slim controller (this file)
  from the server and only rewrites `~/.claude/commands/using-selph.md`
  when the body actually differs (hash compare).
- `install-skill-tree` walks a hardcoded manifest of canonical sub-files
  under `~/.claude/commands/using-selph/{flows,reference}/`. **It only
  writes when a sub-file is missing.** Existing files are preserved
  even if their content drifts from canonical — the user is free to
  edit them. Pass `--force` to overwrite drifted files (last-resort
  reset). Pass `--api-url <api_url>` to prefer the server copy over
  the wheel-bundled fallback when restoring missing files.

**Forward-compat tolerance — `install-skill-tree` is a wheel ≥ 1.2.7
subcommand.** If `selph-mcp-bootstrap install-skill-tree` exits with an
"unknown command" / "invalid choice" / argparse `SystemExit(2)` error
(stderr mentions `argument cmd: invalid choice` or similar), this is an
older wheel that pre-dates the modular sub-tree. Log one debug line and
continue silently — the wheel-version drift check later in this flow
will surface the upgrade prompt to the user. Do NOT block onboarding
on this; the rest of `/using-selph` works fine without the modular
sub-tree present (you can always inline the routing rules from the
`Sub-file index` table at the bottom of this file).

Behavior:

- Silent no-op when nothing changed.
- One-line user notice if the slash-command was refreshed (continue this
  session with the previous flow; new flow takes effect on the next
  `/using-selph` run).
- One-line user notice if any sub-file was repaired (e.g. "Repaired 2
  modular skill files that were missing"). Continue without prompting.
- Network/IO failures are best-effort — log one debug line and continue
  with whatever local content is on disk. Never block onboarding.

Do NOT prompt the user, ask permission, or describe what changed beyond
the one-line notices above. The auto-refresh is plumbing; it should be
invisible unless something happened.

---

## Cold-start vs returning

First, detect state. Run:

```bash
selph-mcp-bootstrap detect-state --workspace "<cwd>"
```

Parse the `data` field. Also load global credentials:

```bash
selph-mcp-bootstrap hydrate-global
```

Parse the `data` field. (`data` is `null` when no credentials file exists.)

Also check for legacy credentials (v1 installer compatibility):

```bash
selph-mcp-bootstrap hydrate-legacy
```

Hydration semantics:

- `hydrate-global` returns non-null ONLY when a chmod-0600 credentials file
  exists at `${XDG_CONFIG_HOME:-$HOME/.config}/selph-mcp/credentials.json`
  AND it carries `consumer_id` / `user_id` / `api_url` / `bearer_token`.
  This is the canonical path.
- `hydrate-legacy` returns non-null when `~/.claude.json` has a `selph` MCP
  entry whose `env` block contains `SELPH_CONSUMER_ID` / `SELPH_USER_ID`
  / `SELPH_API_KEY` (the v1 installer wrote this). It does NOT contain a
  `bearer_token` — the v1 installer pre-dated bearer auth. This path is
  legacy-only; log a deprecation notice to the user if encountered.

Branch on `state.kind`:

- `"cold_start"` AND `global_hydrated` is non-null → **Skip register.**
  Read `~/.claude/commands/using-selph/flows/first-run.md` and run from
  Step 5 (write workspace credentials) onward.
- `"cold_start"` AND `global_hydrated` is null →
  - If `legacy_hydrated` is non-null: tell the user that their existing
    `~/.claude.json` selph entry pre-dates bearer auth and **MUST be
    upgraded** before the new wheel can do anything. Use the values
    they already have (`consumer_id`, `user_id`, `api_key`) to seed the
    register flow without re-asking for them, then shell out to
    `selph-mcp-bootstrap register --user-id <user_id> --api-key <api_key>
    --api-url <api_url>`. **DO NOT call `write-mcp-entry` yet** — only call
    it AFTER register exits 0 AND a fresh `hydrate-global` returns non-null.
  - If `legacy_hydrated` is null too: read
    `~/.claude/commands/using-selph/flows/first-run.md` and run the full
    cold-start flow from Step 1.
- `"returning"` — read
  `~/.claude/commands/using-selph/flows/returning.md` and run that flow.

---

## Wheel-version drift check (run early in both flows)

Run this check before any onboarding or sync work whenever `global_hydrated`
is non-null:

```bash
selph-mcp-bootstrap version
# parse: {"ok": true, "data": {"installed": "1.1.0", "persona_contract_version": 1}}

selph-mcp-bootstrap whoami-remote \
    --api-url "<api_url>"
# parse whoami.data.recommended_wheel_version and whoami.data.min_supported_wheel_version
# (bearer_token and consumer_id are read automatically from the credentials file)
```

Compare `installed` against the server's version fields:

**Drift decision is binary on `recommended_wheel_version` ALONE. Ignore `min_supported_wheel_version` for the upgrade decision — it is reserved for future hard-incompatibility signaling and is NOT consulted here.** Do not rationalize an out-of-date wheel as "non-blocking", "advisory", "above minimum", or "when convenient". When `installed < recommended_wheel_version`, the upgrade is MANDATORY and runs unattended.

| Comparison | Behavior |
|---|---|
| `installed >= recommended_wheel_version` | Continue silently |
| `installed < recommended_wheel_version` | **AUTO-UPGRADE NOW — DO NOT DEFER.** This is unconditional. Tell the user in one line (`"Upgrading selph-mcp from vX.Y.Z → vA.B.C…"`), then run the **upgrade-and-verify** procedure below. Continue the flow without asking the user to re-run `/using-selph`. **Worked example: if `installed=1.3.6` and `recommended=1.4.0`, the correct action is to run `pipx upgrade selph-mcp` THIS TURN. Do NOT print a status line saying "non-blocking" or "pipx upgrade when convenient" — that is a bug, not a behavior.** |
| Either server field is `null` | No drift check — server is pre-v3; continue. |
| `whoami-remote` exits non-zero with a **validation error** (`"ValidationError"` / `"Extra inputs are not permitted"` in the error field) | The wheel is too old to parse the server response — run `pipx upgrade selph-mcp` automatically, then retry `whoami-remote` once. If the retry succeeds, continue normally. If it still fails, surface the error and stop. Do NOT fall back to cached state on a validation error. |

### Upgrade-and-verify procedure (closes the PyPI-propagation race)

`pipx upgrade` returning `"selph-mcp is already at latest version X.Y.Z"`
exits 0 but is **not success** if `X.Y.Z` does not equal
`recommended_wheel_version`. PyPI's read-side index can lag the actual
upload by 30s–2min, and pip's wheel cache can return stale metadata for
even longer. Therefore:

1. Run `pipx upgrade selph-mcp`.
2. **Verify** by re-running `selph-mcp-bootstrap version` and parsing
   `data.installed`.
3. If `installed == recommended_wheel_version`: run
   `selph-mcp-bootstrap install-skill-tree --force` and continue the flow.
4. If `installed < recommended_wheel_version` (pipx no-op'd against a
   stale index): retry once with cache disabled and a forced reinstall:
   ```bash
   pipx install --force --pip-args="--no-cache-dir" selph-mcp
   ```
   Then re-verify with `selph-mcp-bootstrap version`.
5. If still mismatched after the retry: **STOP and surface a hard
   error** to the user. Do NOT continue on the old version. Tell them:
   `"selph-mcp upgrade to vA.B.C failed (installed still vX.Y.Z after pipx upgrade and forced reinstall — likely PyPI propagation lag; retry /using-selph in 1–2 minutes)."`

`install-skill-tree --force` overwrites any stale skill-tree files with
the new wheel's canonical content. Without `--force`, existing files are
preserved even when the wheel's canonical has changed — so a version
bump without a force install leaves old sub-files in place. Always force
after a confirmed upgrade.

Then prompt the user to restart Claude Code only if the wheel exposes new
shell helpers — the remote MCP session itself does not need a restart.

---

## Retryable items (run after wheel-version drift check)

After the wheel-version drift check completes and `global_hydrated` is
non-null, check `whoami.data.retryable_report_count`.

When `retryable_report_count` is `null` or `0`: skip this block entirely.
Do not mention it to the user.

When `retryable_report_count > 0`:

Render (product vocabulary only — no internal taxonomy names):

> **Retryable items:** {retryable_report_count} previously-failed
> actions can now be retried.

Then for each entry in `retryable_report_summary`, render:
> - {human_summary}

If `retryable_report_count > len(retryable_report_summary)`, append:
> - and {retryable_report_count - len(retryable_report_summary)} more.

Then prompt:

> [1] retry all  [2] skip  [3] tell me more

**On `[1]`:** For each entry in `retryable_report_summary`, re-issue the
relevant write tool call with `retry_for_event_id` set to the entry's
`event_id`. Use the same tool that originally failed (you can infer it
from `kind`: `"edit"` → `correct` or `revise`, `"note"` → `observe`
or `observe_session`). Ask the user for any missing payload context if
you cannot reconstruct it from the summary. Read-only failures and
feedback rows never appear here (they cannot reach `retryable` state),
so no skip case is needed.

**On `[2]`:** Skip silently. Continue with the rest of the flow.

**On `[3]`:** Explain each item in plain words. Use the `human_summary`
as the starting point. Never name internal types (no hub types, no memory
types, no predicates). Then offer `[1] retry  [2] skip`.

---

## When something fails

For any failure mode (auth 401, contract version mismatch, engine
unreachable, missing credentials, etc.), read
`~/.claude/commands/using-selph/reference/troubleshooting.md`. That file
has the doctor command and the out-of-band first-install path.

---

## Uninstall intent detection

If the user's prompt contains "uninstall", "remove selph", or "disable selph",
route to `flows/uninstall.md` immediately. Do not run the normal cold-start or
returning flow.

---

## Sub-file index (the modular tree this controller routes to)

| Sub-file | When to read it |
|---|---|
| `flows/first-run.md` | Cold-start: register, write CLAUDE.md blocks, MCP chain, persist state |
| `flows/returning.md` | Returning user: drift check, reconcile, drain invalidations, sub-state branch |
| `flows/workflow-audit.md` | Rendering `scan_workflows` proposals + the five-phase persona-personalization audit |
| `flows/uninstall.md` | When the user asks to uninstall, remove, or disable Selph |
| `reference/voice-and-evidence.md` | Long-form sparse-graph + evidence-chip templates, inquiry vs. action examples |
| `reference/troubleshooting.md` | Doctor + first-install (out-of-band) path |
| `reference/memory-boundary.md` | Durable-vs-operational rule + persistent-assistant / task-manager examples; read when designing any feature with state |

Sub-files are restored automatically by `install-skill-tree` in Step 0
above. You can read them with the `Read` tool when this controller routes
you to them. Do NOT preload them — load only what the current invocation
needs.
