"""Local failure/feedback log for the using-selph wheel (Phase 1, §8.1).

Owns two on-disk stores in ``${XDG_CONFIG_HOME:-~/.config}/selph-mcp/``:

- **Flush spool** — ``reports.jsonl``: redacted failure records + feedback
  records, one JSON line per record.  Compacted after server ack.
- **Retry store** — ``retry_payloads.d/``: directory reserved for
  Phase 2 (full unredacted write payloads).  Created at 0o700 in Phase 1
  but no files are written there (no bridge-CLI writes exist yet).

All operations are sync (no asyncio) so the bootstrap CLI can call them
without an event loop.  All I/O is best-effort — exceptions are
WARNING-logged and never raised to the caller.

Writes use :func:`selph_mcp.bootstrap._secure_io.atomic_secure_write`
and :func:`selph_mcp.bootstrap.credentials._refuse_symlinks_under` for
the same hardened write pattern as ``credentials.json``.

Public surface
--------------
:func:`record_failure`   — append a redacted failure record to the flush spool.
:func:`record_feedback`  — append a feedback record to the flush spool.
:func:`flush`            — POST the spool to ``/apps/mcp/failure_reports``,
                           delete acked entries. Best-effort.
"""
from __future__ import annotations

import json
import logging
import os
import stat
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

# ─────────────────────────────────────────────────────────────────────────────
# Logging — reuse the wheel-vendored logger so no selph_utils dep is needed.
# ─────────────────────────────────────────────────────────────────────────────
from selph_mcp._log import get_logger

_log = get_logger("selph_mcp.skill.runtime.failure_log")


# ─────────────────────────────────────────────────────────────────────────────
# Path helpers
# ─────────────────────────────────────────────────────────────────────────────


def _config_dir() -> Path:
    """Resolve ``${XDG_CONFIG_HOME:-~/.config}/selph-mcp/``."""
    xdg = os.environ.get("XDG_CONFIG_HOME", "").strip()
    base = Path(xdg) if xdg else Path(os.path.expanduser("~")) / ".config"
    return base / "selph-mcp"


def _spool_path() -> Path:
    return _config_dir() / "reports.jsonl"


def _retry_dir() -> Path:
    return _config_dir() / "retry_payloads.d"


# ─────────────────────────────────────────────────────────────────────────────
# Directory bootstrap
# ─────────────────────────────────────────────────────────────────────────────


def _ensure_dirs() -> None:
    """Create the config dir (0o700) and retry_payloads.d (0o700) if absent."""
    config_d = _config_dir()
    try:
        config_d.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(config_d, stat.S_IRWXU)
        except OSError:
            pass
    except OSError as exc:
        _log.warning(
            "failure_log: failed to create config dir",
            extra={
                "event": "failure_log.ensure_dirs.config_dir_failed",
                "path": str(config_d),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return

    retry_d = _retry_dir()
    try:
        retry_d.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(retry_d, stat.S_IRWXU)
        except OSError:
            pass
    except OSError as exc:
        _log.warning(
            "failure_log: failed to create retry_payloads.d",
            extra={
                "event": "failure_log.ensure_dirs.retry_dir_failed",
                "path": str(retry_d),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )


# Hard cap on flush-spool size (bytes). When exceeded, the oldest
# newline-delimited records are dropped from the front. Set high enough that
# a normal weekly cadence never trips it; low enough that a long offline
# window cannot fill the user's disk. Override via SELPH_FAILURE_SPOOL_MAX_BYTES.
_MAX_SPOOL_BYTES = int(os.environ.get("SELPH_FAILURE_SPOOL_MAX_BYTES", "2097152"))  # 2 MiB


def _trim_spool(content: bytes, max_bytes: int) -> bytes:
    """Drop oldest newline-delimited records from the front until under max_bytes."""
    if len(content) <= max_bytes:
        return content
    lines = content.split(b"\n")
    if lines and lines[-1] == b"":
        lines = lines[:-1]
    while lines and sum(len(line) + 1 for line in lines) > max_bytes:
        lines = lines[1:]
    if not lines:
        return b""
    return b"\n".join(lines) + b"\n"


# ─────────────────────────────────────────────────────────────────────────────
# Atomic append to the flush spool
# ─────────────────────────────────────────────────────────────────────────────


def _append_to_spool(record: Dict[str, Any]) -> None:
    """Atomically append one JSON line to the flush spool.

    Uses :func:`selph_mcp.bootstrap._secure_io.atomic_secure_write` to
    rewrite the entire spool + the new record atomically (append via
    read-then-rewrite). This is safe for the low-frequency write rates
    expected here (seconds to minutes between failures).

    Refuses to write if any ancestor segment of the spool path is a
    symbolic link (symlink-refusal guard).
    """
    from selph_mcp.bootstrap._secure_io import atomic_secure_write
    from selph_mcp.bootstrap.credentials import _refuse_symlinks_under

    spool = _spool_path()
    try:
        _refuse_symlinks_under(spool)
    except PermissionError as exc:
        _log.warning(
            "failure_log: symlink detected; refusing write",
            extra={
                "event": "failure_log.append.symlink_refused",
                "path": str(spool),
                "error": str(exc)[:200],
            },
        )
        return

    line = json.dumps(record, ensure_ascii=False, default=str) + "\n"
    try:
        # Read existing content (if any).
        existing = b""
        if spool.exists():
            try:
                existing = spool.read_bytes()
            except OSError as exc:
                _log.warning(
                    "failure_log: could not read spool for append",
                    extra={
                        "event": "failure_log.append.read_failed",
                        "path": str(spool),
                        "error_type": type(exc).__name__,
                        "error": str(exc)[:200],
                    },
                )
                # Continue with empty existing — we still write the new record.
        new_content = existing + line.encode("utf-8")
        # Hard cap on spool size — prevent unbounded growth on long-offline
        # adapters and keep read-then-rewrite cost amortized. Drop oldest
        # newline-delimited records until under the cap.
        if len(new_content) > _MAX_SPOOL_BYTES:
            new_content = _trim_spool(new_content, _MAX_SPOOL_BYTES)
        atomic_secure_write(spool, new_content, mode=stat.S_IRUSR | stat.S_IWUSR)
    except OSError as exc:
        _log.warning(
            "failure_log: append to spool failed",
            extra={
                "event": "failure_log.append.write_failed",
                "path": str(spool),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────


def record_failure(
    event_id: str,
    tool_name: str,
    full_payload: Any,
    error: Exception,
    *,
    redactor: Callable[[Any], Any],
    error_source: str = "client_network",
) -> None:
    """Append a redacted failure record to the flush spool.

    The ``full_payload`` is passed through ``redactor`` before storage —
    the spool never contains unredacted free-text content.

    The retry store entry (full unredacted payload) is NOT written in
    Phase 1 because no bridge-CLI writes exist yet — ``retry_payloads.d/``
    is created but empty.

    Args:
        event_id: UUID string generated by the caller per call.
        tool_name: Name of the MCP tool or bridge CLI subcommand.
        full_payload: Raw request payload; passed through ``redactor``.
        error: The caught exception.
        redactor: Callable that accepts a payload dict and returns a
            redacted dict (e.g. :func:`selph_mcp._redaction.redact_payload`).
        error_source: One of ``client_network`` (default), ``server_4xx``,
            ``server_5xx``, ``schema_validation``.  Callers should pass the
            right value instead of relying on the default so the DB CHECK
            constraint carries meaningful triage data.

    Best-effort — any exception is WARNING-logged and never raised.
    """
    try:
        _ensure_dirs()
        redacted = redactor(full_payload) if full_payload is not None else None
        record: Dict[str, Any] = {
            "schema": "failure_report_v1",
            "event_id": event_id,
            "kind": "failure",
            "tool_name": tool_name,
            "observed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "error_source": error_source,
            "error_code": type(error).__name__,
            "error_message": str(error)[:2048],
            # Field name matches FailureReportItem.request_payload (the route model
            # is the contract owner; the adapter must use the same key so Pydantic
            # does not silently drop the value on batch ingest).
            "request_payload": redacted,
        }
        _append_to_spool(record)
        _log.info(
            "failure_log: recorded failure",
            extra={
                "event": "failure_log.record_failure.complete",
                "event_id": event_id,
                "tool_name": tool_name,
                "error_type": type(error).__name__,
            },
        )
    except Exception as exc:  # noqa: BLE001 — best-effort
        _log.warning(
            "failure_log.record_failure: unexpected error; swallowing",
            extra={
                "event": "failure_log.record_failure.unexpected",
                "event_id": event_id,
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )


def record_feedback(user_note: str) -> None:
    """Append a feedback record to the flush spool.

    Feedback is always adapter-originated; never retry-eligible (§4 CHECK
    constraint). No retry store entry is created.

    Best-effort — exceptions are WARNING-logged, never raised.
    """
    try:
        _ensure_dirs()
        record: Dict[str, Any] = {
            "schema": "failure_report_v1",
            "event_id": str(uuid.uuid4()),
            "kind": "feedback",
            "observed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "user_note": user_note[:4096] if user_note else "",
        }
        _append_to_spool(record)
        _log.info(
            "failure_log: recorded feedback",
            extra={"event": "failure_log.record_feedback.complete"},
        )
    except Exception as exc:  # noqa: BLE001 — best-effort
        _log.warning(
            "failure_log.record_feedback: unexpected error; swallowing",
            extra={
                "event": "failure_log.record_feedback.unexpected",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )


def flush(http_client: Any) -> None:
    """POST the flush spool to ``/apps/mcp/failure_reports`` and compact acked entries.

    ``http_client`` is expected to expose a ``post(path, *, json)`` interface
    that raises on non-2xx (e.g. :class:`selph_mcp._client.EngineClient`).
    For the bootstrap CLI context (sync), callers pass an ``httpx.Client``
    instance directly.

    Compaction: after a successful POST the spool is rewritten with
    only the records that the server did NOT ack (``skipped`` or ``errors``
    from the response).  In Phase 1 the server acks everything that
    parses, so compaction empties the spool on success.

    Best-effort throughout — failures are WARNING-logged and the spool is
    left on disk for the next activation.
    """
    spool = _spool_path()
    if not spool.exists():
        return

    try:
        raw = spool.read_bytes()
    except OSError as exc:
        _log.warning(
            "failure_log.flush: could not read spool",
            extra={
                "event": "failure_log.flush.read_failed",
                "path": str(spool),
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return

    lines = [ln for ln in raw.splitlines() if ln.strip()]
    if not lines:
        return

    records: List[Dict[str, Any]] = []
    malformed: List[bytes] = []
    for ln in lines:
        try:
            records.append(json.loads(ln.decode("utf-8")))
        except (json.JSONDecodeError, UnicodeDecodeError):
            malformed.append(ln)

    if not records:
        return

    _log.info(
        "failure_log.flush: posting batch",
        extra={
            "event": "failure_log.flush.start",
            "record_count": len(records),
            "malformed_count": len(malformed),
        },
    )

    try:
        response = http_client.post(
            "/apps/mcp/failure_reports",
            json={"records": records},
        )
        # For httpx.Client, response is an httpx.Response — check status.
        if hasattr(response, "raise_for_status"):
            response.raise_for_status()
        resp_data: Dict[str, Any] = (
            response.json() if hasattr(response, "json") else (response or {})
        )
    except Exception as exc:
        _log.warning(
            "failure_log.flush: POST failed; leaving spool on disk",
            extra={
                "event": "failure_log.flush.post_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:300],
            },
        )
        return

    # Async-safety rule §6: KeyError-on-drift surfaces in the wrapping
    # except below; do not use .get(...) fallbacks on internal HTTP boundaries.
    try:
        ingested: int = resp_data["ingested"]
        skipped_count: int = resp_data["skipped"]
        errors_list: List[Dict[str, str]] = resp_data["errors"]
    except (KeyError, TypeError) as exc:
        _log.warning(
            "failure_log.flush: response shape drift; leaving spool on disk",
            extra={
                "event": "failure_log.flush.response_drift",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return
    error_ids: set[str] = {e["event_id"] for e in errors_list if "event_id" in e}

    # Compact: keep records that the server errored on + malformed lines.
    remaining_records = [r for r in records if r.get("event_id") in error_ids]
    remaining_bytes = b""
    for r in remaining_records:
        remaining_bytes += (json.dumps(r, ensure_ascii=False, default=str) + "\n").encode("utf-8")
    for ln in malformed:
        remaining_bytes += ln + b"\n"

    try:
        from selph_mcp.bootstrap._secure_io import atomic_secure_write
        if remaining_bytes:
            atomic_secure_write(spool, remaining_bytes, mode=stat.S_IRUSR | stat.S_IWUSR)
        else:
            # All acked — remove the spool file.
            try:
                spool.unlink()
            except OSError:
                atomic_secure_write(spool, b"", mode=stat.S_IRUSR | stat.S_IWUSR)
    except OSError as exc:
        _log.warning(
            "failure_log.flush: compaction write failed",
            extra={
                "event": "failure_log.flush.compact_failed",
                "error_type": type(exc).__name__,
                "error": str(exc)[:200],
            },
        )
        return

    _log.info(
        "failure_log.flush: complete",
        extra={
            "event": "failure_log.flush.complete",
            "ingested": ingested,
            "skipped": skipped_count,
            "remaining": len(remaining_records),
        },
    )


__all__ = [
    "record_failure",
    "record_feedback",
    "flush",
]
