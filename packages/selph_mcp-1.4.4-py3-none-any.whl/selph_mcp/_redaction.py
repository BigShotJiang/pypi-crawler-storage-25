"""Shared payload redactor for MCP failure-report capture (Phase 1, §6).

Applies the brief's §6 redaction table to any dict-shaped payload:

- Free-text content fields (``text``, ``message``, ``note``, ``query``,
  ``question``, ``user_note``, ``content``, ``body``, ``summary``,
  ``description``, ``detail``, ``reason``, ``answer``) are replaced with
  ``{"redacted": true, "len": <chars>, "lang": "<stub>"}``.  The ``lang``
  field is a no-op stub for Phase 1 — always ``"unknown"``.
- Identifiers (``user_id``, ``entity_id``, ``memory_id``, ``hub_id``,
  ``consumer_id``, ``event_id``, ``session_id``) are kept unchanged.
- Tool names, action enums, target_type values, timestamps, cursor ints,
  and confidence floats are kept unchanged.
- Header / auth fields (``Authorization``, ``X-API-Key``, ``bearer_token``,
  ``api_key``, ``secret``, ``token``, ``password``) are stripped entirely.

The redactor is intentionally simple and non-exhaustive — it strips
known-sensitive fields by name and preserves everything else. Unknown
fields are preserved (schema-hiding rule: the surface is forgiving).

Public surface
--------------
:func:`redact_payload` — the single callable. Accepts any dict/list/scalar
and returns a redacted copy. Safe to call on nested structures.
"""
from __future__ import annotations

from typing import Any, Optional

# ─────────────────────────────────────────────────────────────────────────────
# Field classification sets
# ─────────────────────────────────────────────────────────────────────────────

# Free-text content fields — replace with redaction envelope.
_FREE_TEXT_FIELDS: frozenset[str] = frozenset({
    "text",
    "message",
    "note",
    "query",
    "question",
    "user_note",
    "content",
    "body",
    "summary",
    "description",
    "detail",
    "details",
    "reason",
    "answer",
    "response",
    "prompt",
    "input",
    "output",
})

# Auth / credential fields — strip entirely (value replaced with None/omitted).
_STRIP_FIELDS: frozenset[str] = frozenset({
    "Authorization",
    "authorization",
    "X-API-Key",
    "x-api-key",
    "bearer_token",
    "api_key",
    "secret",
    "token",
    "password",
    "credential",
    "credentials",
    "X-Consumer-Id",
    "x-consumer-id",
})


def _redact_value(key: str, value: Any) -> Any:
    """Return redacted representation for a single key-value pair.

    Rules (applied in order):
    1. Strip auth/header fields.
    2. Redact free-text content fields.
    3. Recurse into nested dicts / lists.
    4. Pass scalars through unchanged.
    """
    if key in _STRIP_FIELDS:
        return None  # stripped

    if key in _FREE_TEXT_FIELDS:
        if isinstance(value, str):
            return {"redacted": True, "len": len(value), "lang": "unknown"}
        if value is None:
            return value
        # Non-string free-text field — redact as opaque.
        return {"redacted": True, "len": None, "lang": "unknown"}

    # Recurse into nested structures.
    if isinstance(value, dict):
        return redact_payload(value)
    if isinstance(value, list):
        return [_redact_value("", item) if not isinstance(item, dict) else redact_payload(item)
                for item in value]

    # Scalars (int, float, bool, None) — pass through.
    return value


def redact_payload(
    obj: Any,
    *,
    fields_strategy: Optional[Any] = None,  # reserved for future per-field overrides; unused in P1
) -> Any:
    """Return a redacted copy of ``obj``.

    Accepts:
    - A ``dict`` — keys are classified and values are redacted recursively.
    - A ``list`` — each element is processed by :func:`redact_payload`.
    - Any scalar — returned unchanged.

    The ``fields_strategy`` parameter is accepted but unused in Phase 1.
    It is reserved for future per-field override injection (e.g. a caller
    that knows certain field names are safe to keep verbatim).

    This function is pure and side-effect-free — the input ``obj`` is
    never mutated.
    """
    if isinstance(obj, dict):
        out: dict[str, Any] = {}
        for k, v in obj.items():
            redacted_v = _redact_value(k, v)
            if k in _STRIP_FIELDS:
                # Omit stripped fields entirely (don't emit key with None value).
                # This prevents downstream consumers from seeing
                # ``{"Authorization": null}`` and inferring the field was present.
                continue
            out[k] = redacted_v
        return out

    if isinstance(obj, list):
        return [redact_payload(item) for item in obj]

    # Scalar — pass through.
    return obj


__all__ = ["redact_payload"]
