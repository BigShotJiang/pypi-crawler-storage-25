"""In-process observe implementation for InProcessEngineAdapter.

Extracted from ``selph_mcp/adapters/engine.py`` to keep that file
under the 700-line orchestrator hard cap (rules/code-structure.md).

Called exclusively by ``InProcessEngineAdapter._observe``.

Import-linter compliance: imports only from ``selph_core.*``, ``selph_db.*``,
and ``selph_graph.*`` — never from ``ingestion_api``.

Rules/code-structure.md target: adapter ≤ 400 lines.
Layer assignment: Surface adapter — delegates to Core.
"""
from __future__ import annotations

import hashlib as _hashlib
import logging
import os as _os
from typing import Any, Dict, Optional

from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.adapters._observe_impl")

# Piecewise-linear estimate buckets (mirrors ingestion_api/_observe_estimator.py;
# duplicated here to avoid importing ingestion_api — not a shared Core constant
# because the estimator is a Surface heuristic, not a Core invariant).
_BUCKETS: tuple[tuple[int, int], ...] = (
    (200,   80_000),
    (800,  170_000),
    (2000, 290_000),
    (5000, 180_000),
)
_ESTIMATE_FALLBACK_MS: int = 300_000


def _estimate_duration_ms(message: str) -> int:
    char_len = len(message)
    for max_len, est_ms in _BUCKETS:
        if char_len < max_len:
            return est_ms
    return _ESTIMATE_FALLBACK_MS


def _get_sync_budget_ms() -> int:
    try:
        raw = _os.environ.get("SELPH_OBSERVE_SYNC_BUDGET_MS")
        if raw:
            return int(float(raw))
        raw_secs = _os.environ.get("SELPH_OBSERVE_SYNC_BUDGET_SECS")
        if raw_secs:
            return int(float(raw_secs) * 1000)
    except (ValueError, TypeError):
        pass
    return 180_000


async def run_inprocess_observe(
    payload: Dict[str, Any],
    neo4j: Any,
) -> Dict[str, Any]:
    """Execute an observe operation in-process using Core entry points.

    Mirrors ``ingestion_api/routes.py::ingest``:
      1. User validation
      2. Idempotency gate (claim_or_attach)
      3. L1 write (insert_raw_evidence)
      4. dispatch_observe — sync or async receipt path based on estimate

    Args:
        payload:  Dict of observe payload fields (from the kernel tool JSON).
        neo4j:    App-level Neo4jConnection from host_app.state.

    Returns:
        Dict matching ``IngestResponse`` field names (rules/async-safety.md §6 —
        direct field access by the caller; no .get() fallback chains).
    """
    import asyncio as _asyncio

    from selph_core.observe.operation_service import dispatch_observe
    from selph_core.observe.request import IngestRequest
    from selph_db.idempotency_manager import claim_or_attach, mark_failed
    from selph_db.raw_evidence_manager import insert_raw_evidence
    from selph_db.user_management import get_user

    user_id: str = payload.get("user_id", "")
    message: str = payload.get("message", "")

    log_event(_log, logging.DEBUG, "observe_impl.start",
              user_id=user_id, msg_len=len(message))

    # ── 1. User validation ───────────────────────────────────────────────
    user = await _asyncio.to_thread(get_user, user_id)
    if user is None:
        log_event(_log, logging.WARNING, "observe_impl.unknown_user", user_id=user_id)
        return {
            "status": "error",
            "error_message": f"Unknown user_id: {user_id!r}. Create the user first.",
            "ingest_status": "failed",
            "raw_evidence_id": None,
            "operation_id": None,
        }

    # ── 2. Idempotency gate ──────────────────────────────────────────────
    _idem_key: Optional[str] = payload.get("idempotency_key")
    _source_type: str = payload.get("source") or "harness_session"
    _fingerprint: bytes = _hashlib.sha256(message.strip().encode("utf-8")).digest()

    claim = await claim_or_attach(
        user_id=user_id,
        source_type=_source_type,
        key_value=_idem_key,
        content_fingerprint=_fingerprint,
    )
    _operation_id = claim.operation_id

    if claim.status == "in_flight":
        log_event(_log, logging.INFO, "observe_impl.in_flight",
                  user_id=user_id, operation_id=str(_operation_id))
        return {
            "status": "ok",
            "info_message": "ingest already running for this fingerprint",
            "operation_id": str(_operation_id),
            "ingest_status": "accepted",
            "raw_evidence_id": None,
        }

    if claim.status == "completed":
        log_event(_log, logging.INFO, "observe_impl.completed",
                  user_id=user_id, operation_id=str(_operation_id))
        return {
            "status": "ok",
            "info_message": "ingest already completed for this fingerprint",
            "raw_evidence_id": str(claim.raw_evidence_id) if claim.raw_evidence_id else None,
            "operation_id": str(_operation_id),
            "ingest_status": "completed",
        }

    # claim.status == 'new' — proceed.

    # ── 3. L1 write ──────────────────────────────────────────────────────
    raw_evidence_id: Optional[str] = None
    if message.strip():
        _l1_metadata: Dict[str, Any] = {
            "input_context": payload.get("input_context") or "user_message",
            "source": _source_type,
        }
        _l1_metadata = {k: v for k, v in _l1_metadata.items() if v is not None}
        try:
            raw_evidence_id = await _asyncio.to_thread(
                insert_raw_evidence,
                user_id=user_id,
                source_type="generic_message",
                content_text=message,
                source_channel=payload.get("source") or "mcp",
                external_source_id=_idem_key,
                metadata=_l1_metadata,
            )
        except Exception as _l1_exc:
            log_event(_log, logging.WARNING, "observe_impl.l1_failed",
                      user_id=user_id, operation_id=str(_operation_id),
                      error_type=type(_l1_exc).__name__, error=str(_l1_exc)[:300])
            try:
                await mark_failed(_operation_id, f"L1 write failed: {_l1_exc!s}"[:500])
            except Exception:
                pass
            return {
                "status": "error",
                "error_message": "Evidence write failed; ingest aborted.",
                "ingest_status": "failed",
                "operation_id": str(_operation_id),
                "raw_evidence_id": None,
            }

    # ── 4. Build IngestRequest and dispatch ──────────────────────────────
    # Forward all kernel-supplied fields that exist on IngestRequest so that
    # observation_provenance, apply_session_ranker, metadata, external_source_id,
    # consumer_id, harness_id, input_context, etc. are not silently dropped.
    # Use model_fields as the canonical field list — any payload key whose name
    # matches an IngestRequest field is forwarded; unknown keys are ignored.
    _ingest_kwargs: Dict[str, Any] = {
        k: payload[k]
        for k in IngestRequest.model_fields
        if k in payload and payload[k] is not None
    }
    # Always override with the values we own in this scope (L1-derived fields
    # and the resolved source default must not be clobbered by payload).
    _ingest_kwargs["user_id"] = user_id
    _ingest_kwargs["message"] = message
    _ingest_kwargs["source"] = payload.get("source") or "harness_session"
    _ingest_kwargs["raw_evidence_id"] = raw_evidence_id
    _ingest_kwargs["idempotency_key"] = _idem_key
    ingest_request = IngestRequest(**_ingest_kwargs)

    estimated_duration_ms = _estimate_duration_ms(message)
    sync_budget_ms = _get_sync_budget_ms()

    try:
        result = await dispatch_observe(
            user_id=user_id,
            operation_id=str(_operation_id),
            raw_evidence_id=raw_evidence_id or "",
            ingest_request=ingest_request,
            graph=neo4j,
            estimated_duration_ms=estimated_duration_ms,
            sync_budget_ms=sync_budget_ms,
        )
    except Exception as exc:
        log_event(_log, logging.ERROR, "observe_impl.dispatch_error",
                  user_id=user_id, operation_id=str(_operation_id),
                  error_type=type(exc).__name__, error=str(exc)[:300])
        try:
            await mark_failed(_operation_id, str(exc)[:500])
        except Exception:
            pass
        return {
            "status": "error",
            "error_message": f"Dispatch error: {exc}",
            "ingest_status": "failed",
            "operation_id": str(_operation_id),
            "raw_evidence_id": None,
        }

    log_event(_log, logging.DEBUG, "observe_impl.complete",
              user_id=user_id, ingest_status=result.get("ingest_status"))
    return result


__all__ = ["run_inprocess_observe"]
