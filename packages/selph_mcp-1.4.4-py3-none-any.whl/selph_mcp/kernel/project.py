"""Kernel ``project`` adapter (Phase 1b §1).

Sync hub-payload read backed by
:func:`selph_db.selph_hub_store.get_hub_payload`. Read-only — never
triggers a rebuild on the request critical path. Hub rebuilds remain
asynchronous (the ``selph_core.project.hub_builder`` rebuild worker
fires at memory thresholds; this adapter only reads what is already
materialized).

Same consumer-to-user binding (§3.5.1 anti-bypass) as the other
kernel adapters.
"""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict, Optional

from fastapi import HTTPException, status

from selph_mcp._client import EngineUpstreamError, get_client
from selph_mcp.adapters.engine import EngineAdapter, HttpEngineAdapter
from selph_mcp.contracts.consumer import Consumer
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.kernel.project")


def _resolve_user_id(
    *,
    consumer: Consumer,
    payload_user_id: Optional[str],
) -> str:
    """Apply the §3.5.1 consumer-to-user binding."""
    if not payload_user_id:
        return consumer.user_id
    if payload_user_id != consumer.user_id:
        log_event(
            _log, logging.WARNING, "mcp.kernel.project.user_binding_violation",
            consumer_id=consumer.consumer_id,
            consumer_user_id=consumer.user_id,
            payload_user_id=payload_user_id,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "Payload user_id does not match the consumer-bound user_id."
            ),
        )
    return payload_user_id


async def project(
    *,
    consumer: Consumer,
    hub_type: str,
    user_id: Optional[str] = None,
    domain_hint: Optional[str] = None,
    engine: Optional[EngineAdapter] = None,
    mcp_transport: str = "stdio",
) -> Dict[str, Any]:
    """Return the latest hub payload for ``(user_id, hub_type)``.

    ``selph_db.selph_hub_store.get_hub_payload`` is sync (Postgres I/O)
    — wrapped in :func:`loop.run_in_executor` so the event loop stays
    free.

    Args:
        consumer: Authenticated consumer row (binding source).
        hub_type: Hub-type label (e.g. ``"current_identity"``,
            ``"relationship_priority"``).
        user_id: Optional caller-supplied user_id; must match
            ``consumer.user_id`` when present.
        domain_hint: Optional natural language hint to scope this request
            to a specific preference domain (e.g. 'food preferences',
            'dietary requirements', 'entertainment'). Only meaningful for
            multi-instance hub types. Unknown hints fall through gracefully.

    Returns:
        ``{"status": "ok"|"miss"|"error",
           "user_id": str, "hub_type": str,
           "payload": dict|None, "duration_ms": float}``

    Raises:
        HTTPException(400): missing ``hub_type``.
        HTTPException(401): consumer/user binding violation.
        HTTPException(404): unknown user_id.
    """
    t0 = _time.perf_counter()
    resolved_user_id = _resolve_user_id(consumer=consumer, payload_user_id=user_id)

    log_event(
        _log, logging.INFO, "mcp.kernel.project.entry",
        consumer_id=consumer.consumer_id,
        user_id=resolved_user_id,
        hub_type=hub_type,
        has_domain_hint=(domain_hint is not None),
        mcp_transport=mcp_transport,
    )

    if not hub_type or not hub_type.strip():
        log_event(
            _log, logging.WARNING, "mcp.kernel.project.bad_request",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            reason="empty_hub_type",
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="`hub_type` is required and must be non-empty.",
        )

    # Use the injected engine adapter when present; fall back to HttpEngineAdapter.
    _engine: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())

    params: Dict[str, Any] = {}
    if domain_hint is not None:
        params["domain_hint"] = domain_hint

    try:
        data = await _engine.get(
            f"/core/project/hubs/{resolved_user_id}/{hub_type}",
            params=params if params else None,
        )
        payload = data.get("payload")
    except EngineUpstreamError as exc:
        if exc.status_code == 404:
            log_event(
                _log, logging.WARNING, "mcp.kernel.project.unknown_user",
                consumer_id=consumer.consumer_id,
                user_id=resolved_user_id,
                hub_type=hub_type,
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Unknown user_id or hub not found: {resolved_user_id!r}/{hub_type!r}.",
            ) from exc
        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.ERROR, "mcp.kernel.project.error",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            hub_type=hub_type,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
            duration_ms=duration_ms,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Hub payload read failed: {exc}",
        ) from exc
    except Exception as exc:  # noqa: BLE001
        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.ERROR, "mcp.kernel.project.error",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            hub_type=hub_type,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
            duration_ms=duration_ms,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Hub payload read failed: {exc}",
        ) from exc

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    status_value = "ok" if payload is not None else "miss"

    log_event(
        _log, logging.INFO, "mcp.kernel.project.complete",
        consumer_id=consumer.consumer_id,
        user_id=resolved_user_id,
        hub_type=hub_type,
        has_domain_hint=(domain_hint is not None),
        status=status_value,
        has_payload=payload is not None,
        duration_ms=duration_ms,
        mcp_transport=mcp_transport,
    )

    return {
        "status": status_value,
        "user_id": resolved_user_id,
        "hub_type": hub_type,
        "payload": payload,
        "duration_ms": duration_ms,
    }


__all__ = ["project"]
