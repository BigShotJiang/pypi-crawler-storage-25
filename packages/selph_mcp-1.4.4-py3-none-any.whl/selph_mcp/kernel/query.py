"""Kernel ``query`` adapter (Phase 1b §1, Phase 2 §4).

Typed in-process adapter over the existing KG-query path. Mirrors
the FastAPI ``POST /core/observe/kg/query`` route but without the HTTP
layer — calls
:func:`selph_core.query.query_to_answer_v2` directly using the
Neo4j and Chroma handles owned by the MCP lifespan.

Same consumer-to-user binding (§3.5.1 anti-bypass) as
:mod:`selph_mcp.kernel.observe`.

Imports only ``selph_core`` / ``selph_db`` / ``selph_shared`` to stay
inside the ``mcp-surface-boundary`` import-linter contract — never
``ingestion_api`` or ``selph_apps``.

Mode branch (Phase 2)
---------------------
``query(..., mode="targeted")`` is the default and unchanged — it
returns the raw evidence bundles from ``query_to_answer_v2``. When
``mode="insight"`` the adapter additionally invokes a synthesizer
callable (injected by the host lifespan) to produce a synthesized
natural-language answer. The synthesizer lives in
``selph_apps.answering.synthesis`` which ``selph_mcp`` **cannot
import** per the ``mcp-surface-boundary`` import-linter contract —
so the host (e.g. the FastAPI ``ingestion_api/main.py`` lifespan that
hosts the MCP app in-process, or a future standalone MCP bootstrap
that is allowed to reach into App code) is responsible for:

  1. Importing ``selph_apps.answering.synthesize_evidence`` at
     lifespan init time, and
  2. Storing a thin callable on the lifespan context under
     ``.insight_synthesizer`` with the signature
     ``async def (question: str, bundles: list[dict], *, user_id:
     Optional[str], self_entity_id: Optional[str]) -> dict``.

If no synthesizer is installed on the lifespan, ``mode="insight"``
degrades to ``mode="targeted"`` with an ``insight_disabled`` warning
rather than hard-failing — the persona surface still gets a
structurally-valid envelope.
"""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Awaitable, Callable, Dict, List, Literal, Optional

from fastapi import HTTPException, status

from selph_mcp._client import EngineUpstreamError, get_client
from selph_mcp.adapters.engine import EngineAdapter, HttpEngineAdapter
from selph_mcp.contracts.consumer import Consumer
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.kernel.query")

#: Callable shape the host lifespan is expected to install on the
#: lifespan context under ``.insight_synthesizer``. The kernel invokes
#: it only when the persona surface requests ``mode="insight"``.
InsightSynthesizer = Callable[..., Awaitable[Dict[str, Any]]]


def _resolve_user_id(
    *,
    consumer: Consumer,
    payload_user_id: Optional[str],
) -> str:
    """Apply the §3.5.1 consumer-to-user binding (see kernel/observe.py)."""
    if not payload_user_id:
        return consumer.user_id
    if payload_user_id != consumer.user_id:
        log_event(
            _log, logging.WARNING, "mcp.kernel.query.user_binding_violation",
            consumer_id=consumer.consumer_id,
            consumer_user_id=consumer.user_id,
            payload_user_id=payload_user_id,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "Payload user_id does not match the consumer-bound user_id."
            ),
        )
    return payload_user_id


async def query(
    *,
    consumer: Consumer,
    query_text: str,
    graph: Any,
    chroma: Any,
    user_id: Optional[str] = None,
    tz: str = "America/Chicago",
    mode: Literal["targeted", "insight"] = "targeted",
    synthesizer: Optional[InsightSynthesizer] = None,
    self_entity_id: Optional[str] = None,
    engine: Optional[EngineAdapter] = None,
    mcp_transport: str = "stdio",
    extra_evidence: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Run an end-to-end KG query under MCP auth.

    Args:
        consumer: Authenticated consumer row.
        query_text: Natural-language query string. Required.
        graph: ``selph_graph.graph_upserter.Neo4jConnection`` handle.
        chroma: Chroma client handle.
        user_id: Optional caller-supplied user_id; must match
            ``consumer.user_id`` when present (anti-bypass).
        tz: IANA timezone for temporal-window resolution. Defaults to
            ``America/Chicago`` matching the FastAPI route.
        mode: ``"targeted"`` (default — raw evidence bundles) or
            ``"insight"`` (run the evidence through a host-supplied
            synthesizer). Phase 2 addition.
        synthesizer: Optional async callable injected by the host
            lifespan. Only consulted when ``mode == "insight"``. When
            absent the call degrades to ``targeted`` with an
            ``insight_disabled`` warning on the result. See the module
            docstring for the expected signature.
        self_entity_id: Optional self-entity id passed through to the
            synthesizer when ``mode == "insight"``. Ignored for
            targeted queries.
        extra_evidence: Optional list of additional record dicts the
            persona layer wants the synthesizer to see alongside the
            engine's KNN evidence. Prepended to the synthesizer's
            ``bundles`` argument. Used by ``_dispatch_insight`` to
            inject the subject-mapped hub payload so meta-questions
            (e.g. "who do I talk to a lot") have structured context
            even when KNN returns nothing. Also returned to the caller
            via the ``data`` field so envelope assembly sees the same
            evidence the synthesizer used.

    Returns:
        ``{"status": "ok"|"error", "data": list[dict]|None,
           "timing_ms": dict, "duration_ms": float,
           "error_message": str|None, "mode": str,
           "insight": dict|None}``

        ``mode`` echoes the mode actually executed (may differ from the
        requested mode when the synthesizer is absent — see
        ``insight`` key for a ``disabled`` marker). ``insight`` is
        ``None`` when the targeted path ran, otherwise the synthesized
        answer payload produced by the injected callable.

    Raises:
        HTTPException(401): consumer/user binding violation.
        HTTPException(404): unknown user_id.
        HTTPException(500): missing graph/chroma handles.
    """
    t0 = _time.perf_counter()
    resolved_user_id = _resolve_user_id(consumer=consumer, payload_user_id=user_id)

    log_event(
        _log, logging.INFO, "mcp.kernel.query.entry",
        consumer_id=consumer.consumer_id,
        user_id=resolved_user_id,
        query_len=len(query_text or ""),
        tz=tz,
        mcp_transport=mcp_transport,
    )

    if not query_text or not query_text.strip():
        log_event(
            _log, logging.WARNING, "mcp.kernel.query.bad_request",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            reason="empty_query",
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="`query_text` is required and must be non-empty.",
        )

    timing: Dict[str, float] = {}
    answer: Optional[List[Dict[str, Any]]] = None
    error_message: Optional[str] = None
    status_value = "ok"

    # Use the injected engine adapter when present; fall back to HttpEngineAdapter
    # wrapping get_client() so persona tools that don't pass engine= keep working.
    _engine: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())

    pipe_t0 = _time.perf_counter()
    try:
        engine_result = await _engine.post(
            "/apps/answer/kg/answer",
            json={
                "user_id": resolved_user_id,
                "query": query_text,
                "tz": tz,
            },
        )
        # KGAnswerResponse (ingestion_api/answer_routes.py:43-49) uses the
        # field name ``evidence`` (not ``data`` or ``results``).
        # ``answer`` (str) is the synthesized text — not an evidence list;
        # we surface it separately via the insight path, not as ``data``.
        answer = engine_result.get("evidence") or []
        if isinstance(answer, dict):
            answer = [answer]
        timing["pipeline_ms"] = round((_time.perf_counter() - pipe_t0) * 1000, 2)
    except EngineUpstreamError as exc:
        timing["pipeline_ms"] = round((_time.perf_counter() - pipe_t0) * 1000, 2)
        if exc.status_code == 404:
            log_event(
                _log, logging.WARNING, "mcp.kernel.query.unknown_user",
                consumer_id=consumer.consumer_id,
                user_id=resolved_user_id,
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Unknown user_id: {resolved_user_id!r}.",
            ) from exc
        status_value = "error"
        error_message = str(exc)
        log_event(
            _log, logging.ERROR, "mcp.kernel.query.error",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            error_type=type(exc).__name__,
            error=error_message[:300],
            timing_ms=timing,
        )
    except Exception as exc:  # noqa: BLE001
        timing["pipeline_ms"] = round((_time.perf_counter() - pipe_t0) * 1000, 2)
        status_value = "error"
        error_message = str(exc)
        log_event(
            _log, logging.ERROR, "mcp.kernel.query.error",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            error_type=type(exc).__name__,
            error=error_message[:300],
            timing_ms=timing,
        )

    # ── Optional insight synthesis (Phase 2 branch) ────────────────────
    # Runs only when (a) the caller asked for ``mode="insight"``, (b)
    # the targeted path produced results, and (c) the host lifespan
    # injected a synthesizer callable. When the synthesizer is absent we
    # silently degrade to targeted with an ``insight_disabled`` marker
    # so the persona surface still gets a valid envelope (per
    # rules/naming-and-constraints.md — never fail silently).
    insight_payload: Optional[Dict[str, Any]] = None
    executed_mode: str = "targeted"
    # Fix C1: Surface an explicit degrade reason when insight was
    # requested but could not actually run. The persona layer reads this
    # to populate ``meta.degraded_from`` + emit a WARNING log rather
    # than silently reporting ``mode_used=insight`` when targeted ran.
    insight_degraded_reason: Optional[str] = None

    if mode == "insight":
        if synthesizer is None:
            log_event(
                _log, logging.WARNING, "mcp.kernel.query.insight_disabled",
                consumer_id=consumer.consumer_id,
                user_id=resolved_user_id,
                reason="no_synthesizer_on_lifespan",
            )
            insight_payload = {
                "status": "disabled",
                "reason": (
                    "No insight synthesizer was installed on the MCP "
                    "lifespan context. Host must import "
                    "selph_apps.answering.synthesize_evidence at "
                    "lifespan init and expose it as "
                    "lifespan_context.insight_synthesizer."
                ),
            }
            executed_mode = "targeted"
            insight_degraded_reason = "synthesizer_not_wired"
        elif status_value != "ok":
            # Targeted path failed — surface the underlying error and
            # skip synthesis rather than feed empty bundles to the LLM.
            log_event(
                _log, logging.WARNING, "mcp.kernel.query.insight_skipped",
                consumer_id=consumer.consumer_id,
                user_id=resolved_user_id,
                reason="targeted_failed",
            )
            insight_payload = {
                "status": "skipped",
                "reason": "targeted_path_failed",
                "error": error_message,
            }
            executed_mode = "targeted"
            insight_degraded_reason = "targeted_path_failed"
        else:
            # Prepend persona-supplied hub bundles (e.g. subject's primary
            # hub from _dispatch_insight) so the synthesizer always has
            # structured persona context even when KNN returned nothing.
            # Vague meta-questions like "who do I talk to a lot" produce
            # zero KNN anchors but the hub already holds the answer.
            syn_bundles: List[Dict[str, Any]] = list(answer or [])
            if extra_evidence:
                syn_bundles = list(extra_evidence) + syn_bundles
            syn_t0 = _time.perf_counter()
            try:
                insight_payload = await synthesizer(
                    question=query_text,
                    bundles=syn_bundles,
                    user_id=resolved_user_id,
                    self_entity_id=self_entity_id,
                )
                timing["insight_ms"] = round(
                    (_time.perf_counter() - syn_t0) * 1000, 2
                )
                executed_mode = "insight"
            except Exception as exc:  # noqa: BLE001
                timing["insight_ms"] = round(
                    (_time.perf_counter() - syn_t0) * 1000, 2
                )
                log_event(
                    _log, logging.ERROR, "mcp.kernel.query.insight_failed",
                    consumer_id=consumer.consumer_id,
                    user_id=resolved_user_id,
                    error_type=type(exc).__name__,
                    error=str(exc)[:300],
                )
                insight_payload = {
                    "status": "error",
                    "reason": "synthesizer_raised",
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:300],
                }
                executed_mode = "targeted"
                insight_degraded_reason = "synthesizer_raised"

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    timing["total_ms"] = duration_ms

    log_event(
        _log, logging.INFO, "mcp.kernel.query.complete",
        consumer_id=consumer.consumer_id,
        user_id=resolved_user_id,
        status=status_value,
        result_count=(len(answer) if answer else 0),
        duration_ms=duration_ms,
        mode_requested=mode,
        mode_executed=executed_mode,
        mcp_transport=mcp_transport,
    )

    data_out: List[Dict[str, Any]] = list(answer or [])
    if extra_evidence:
        data_out = list(extra_evidence) + data_out

    return {
        "status": status_value,
        "data": data_out,
        "timing_ms": timing,
        "duration_ms": duration_ms,
        "error_message": error_message,
        "mode": executed_mode,
        # Fix C1: ``mode_executed`` is a stable alias of ``mode`` —
        # persona envelope assembly reads this key explicitly rather
        # than the ambiguous ``mode`` so callers can distinguish
        # "requested insight, got insight" from "requested insight,
        # silently degraded to targeted".
        "mode_executed": executed_mode,
        "mode_requested": mode,
        "insight_degraded_reason": insight_degraded_reason,
        "insight": insight_payload,
    }


__all__ = ["query", "InsightSynthesizer"]
