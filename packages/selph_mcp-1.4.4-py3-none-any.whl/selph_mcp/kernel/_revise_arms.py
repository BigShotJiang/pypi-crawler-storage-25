"""Dispatcher arms for :mod:`selph_mcp.kernel.revise` — one per
compile-table cell.

The §3.4 compile table itself, the routing policy, the public
:func:`selph_mcp.kernel.revise.revise` entry point, and the import-time
cell-coverage guard all live in :mod:`selph_mcp.kernel.revise`. This
module exists purely to keep the orchestrator file under its
500-line soft target now that all 12 cells are live.

Every arm is an ``async`` coroutine with the same parameter contract:

    arm(*, user_id, payload, consumer, engine=None) -> dict

The optional ``engine=`` keyword is only present on arms that POST to
``/core/revise/``; manager-direct arms call :func:`get_client` directly
to preserve the ``ENABLE_CORRECTION_LAYER`` gate enforced by
``CompositeEngineAdapter._HTTP_ONLY_PREFIXES``. The dispatcher in
``revise.py`` inspects the signature at runtime to decide whether to
pass ``engine``.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import HTTPException

from selph_core.revise import RevisionAction, RevisionRequest, RevisionTarget
from selph_mcp._client import EngineUpstreamError, get_client
from selph_mcp.adapters.engine import EngineAdapter, HttpEngineAdapter
from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.correction import CorrectionPayload


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _initiated_by(consumer: Consumer) -> str:
    """Stable consumer attribution for ``RevisionRequest.initiated_by``."""
    return f"consumer:{consumer.consumer_id}"


# ─────────────────────────────────────────────────────────────────────────────
# /core/revise/ arms (8 cells) — typed RevisionRequest + .model_dump(mode="json")
# ─────────────────────────────────────────────────────────────────────────────

async def _entity_field_replace(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    if payload.new_state is None or "value" not in payload.new_state:
        raise HTTPException(
            status_code=400,
            detail="`new_state.value` is required for replace × entity_field_observation.",
        )
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    req = RevisionRequest(
        user_id=user_id,
        target_type=RevisionTarget.ENTITY_FIELD,
        target_id=payload.target_id,
        action=RevisionAction.CORRECT,
        new_value={"value": payload.new_state["value"]},
        reason=payload.reason,
        evidence_ids=[],
        initiated_by=_initiated_by(consumer),
    )
    return await _eng.post("/core/revise/", json=req.model_dump(mode="json"))


async def _entity_field_retract(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    req = RevisionRequest(
        user_id=user_id,
        target_type=RevisionTarget.ENTITY_FIELD,
        target_id=payload.target_id,
        action=RevisionAction.RETRACT,
        new_value=None,
        reason=payload.reason,
        evidence_ids=[],
        initiated_by=_initiated_by(consumer),
    )
    return await _eng.post("/core/revise/", json=req.model_dump(mode="json"))


async def _memory_replace(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    if (
        payload.new_state is None
        or "field_path" not in payload.new_state
        or "value" not in payload.new_state
    ):
        raise HTTPException(
            status_code=400,
            detail="replace × memory requires `new_state.field_path` and `new_state.value`.",
        )
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    req = RevisionRequest(
        user_id=user_id,
        target_type=RevisionTarget.MEMORY,
        target_id=payload.target_id,
        action=RevisionAction.CORRECT,
        new_value={
            "field_path": payload.new_state["field_path"],
            "value": payload.new_state["value"],
        },
        reason=payload.reason,
        evidence_ids=[],
        initiated_by=_initiated_by(consumer),
    )
    return await _eng.post("/core/revise/", json=req.model_dump(mode="json"))


async def _memory_retract(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    req = RevisionRequest(
        user_id=user_id,
        target_type=RevisionTarget.MEMORY,
        target_id=payload.target_id,
        action=RevisionAction.RETRACT,
        new_value=None,
        reason=payload.reason,
        evidence_ids=[],
        initiated_by=_initiated_by(consumer),
    )
    return await _eng.post("/core/revise/", json=req.model_dump(mode="json"))


async def _memory_expire(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    req = RevisionRequest(
        user_id=user_id,
        target_type=RevisionTarget.MEMORY,
        target_id=payload.target_id,
        action=RevisionAction.REJECT,
        new_value=None,
        reason=payload.reason,
        evidence_ids=[],
        initiated_by=_initiated_by(consumer),
    )
    return await _eng.post("/core/revise/", json=req.model_dump(mode="json"))


async def _memory_reinstate(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    req = RevisionRequest(
        user_id=user_id,
        target_type=RevisionTarget.MEMORY,
        target_id=payload.target_id,
        action=RevisionAction.ACCEPT,
        new_value=None,
        reason=payload.reason,
        evidence_ids=[],
        initiated_by=_initiated_by(consumer),
    )
    return await _eng.post("/core/revise/", json=req.model_dump(mode="json"))


async def _memory_supersede(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    if (
        payload.new_state is None
        or "field_path" not in payload.new_state
        or "value" not in payload.new_state
    ):
        raise HTTPException(
            status_code=400,
            detail="supersede × memory requires `new_state.field_path` and `new_state.value`.",
        )
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    req = RevisionRequest(
        user_id=user_id,
        target_type=RevisionTarget.MEMORY,
        target_id=payload.target_id,
        action=RevisionAction.SUPERSEDE,
        new_value={
            "field_path": payload.new_state["field_path"],
            "value": payload.new_state["value"],
        },
        reason=payload.reason,
        evidence_ids=[],
        initiated_by=_initiated_by(consumer),
    )
    return await _eng.post("/core/revise/", json=req.model_dump(mode="json"))


async def _identity_claim_supersede(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    ns = payload.new_state or {}
    claim_text = ns.get("claim_text")
    claim_structured = ns.get("claim_structured")
    if not claim_text or not str(claim_text).strip():
        raise HTTPException(
            status_code=400,
            detail="supersede × identity_claim requires a non-empty `new_state.claim_text`.",
        )
    if not claim_structured or (
        isinstance(claim_structured, (list, dict, str)) and not claim_structured
    ):
        raise HTTPException(
            status_code=400,
            detail="supersede × identity_claim requires a non-empty `new_state.claim_structured` payload.",
        )
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    req = RevisionRequest(
        user_id=user_id,
        target_type=RevisionTarget.IDENTITY_CLAIM,
        target_id=payload.target_id,
        action=RevisionAction.SUPERSEDE,
        new_value=dict(ns),
        reason=payload.reason,
        evidence_ids=[],
        initiated_by=_initiated_by(consumer),
    )
    return await _eng.post("/core/revise/", json=req.model_dump(mode="json"))


# ─────────────────────────────────────────────────────────────────────────────
# Manager-direct arms (4 cells) — bypass /core/revise/, route through
# /apps/correction/* or /apps/mcp/* via get_client() directly.
# ─────────────────────────────────────────────────────────────────────────────

async def _entity_field_expire(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
) -> Dict[str, Any]:
    try:
        observation_id = int(payload.target_id)
    except (TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=400,
            detail=(
                "expire × entity_field_observation requires a numeric "
                "observation_id in target_id."
            ),
        ) from exc
    return await get_client().post(
        "/apps/correction/corrections/entity-field",
        params={"user_id": user_id},
        json={
            "operation": "expire",
            "target_observation_id": observation_id,
            "reason": payload.reason,
            "actor_id": _initiated_by(consumer),
        },
    )


async def _entity_field_reattribute(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
) -> Dict[str, Any]:
    if not payload.new_state or not payload.new_state.get("destination_entity_id"):
        raise HTTPException(
            status_code=400,
            detail=(
                "reattribute × entity_field_observation requires "
                "`new_state.destination_entity_id`."
            ),
        )
    try:
        observation_id = int(payload.target_id)
    except (TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=400,
            detail=(
                "reattribute × entity_field_observation requires a numeric "
                "observation_id in target_id."
            ),
        ) from exc
    return await get_client().post(
        "/apps/correction/corrections/entity-field",
        params={"user_id": user_id},
        json={
            "operation": "reattribute",
            "target_observation_id": observation_id,
            "destination_entity_id": payload.new_state["destination_entity_id"],
            "reason": payload.reason,
            "actor_id": _initiated_by(consumer),
        },
    )


async def _memory_reattribute(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
) -> Dict[str, Any]:
    if (
        not payload.new_state
        or "old_entity_id" not in payload.new_state
        or "new_entity_id" not in payload.new_state
    ):
        raise HTTPException(
            status_code=400,
            detail=(
                "reattribute × memory requires `new_state.old_entity_id` "
                "and `new_state.new_entity_id`."
            ),
        )
    return await get_client().post(
        "/apps/correction/corrections/memory",
        params={"user_id": user_id},
        json={
            "operation": "reattribute_entity",
            "memory_id": payload.target_id,
            "old_entity_id": payload.new_state["old_entity_id"],
            "new_entity_id": payload.new_state["new_entity_id"],
            "reason": payload.reason,
            "actor_id": _initiated_by(consumer),
        },
    )


async def _recommendation_reject(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
) -> Dict[str, Any]:
    target_id = (payload.target_id or "").strip()
    if not target_id:
        raise HTTPException(
            status_code=400,
            detail=(
                "reject_recommendation × recommendation requires a "
                "non-empty `feedback_event_key` in target_id."
            ),
        )
    try:
        return await get_client().post(
            "/apps/mcp/recommendation-feedback",
            json={
                "feedback_event_key": target_id,
                "outcome": "rejected",
                "notes": payload.reason,
            },
        )
    except EngineUpstreamError as exc:
        if exc.status_code == 400:
            raise HTTPException(status_code=400, detail=exc.body[:300]) from exc
        raise


__all__ = [
    "_initiated_by",
    "_entity_field_replace",
    "_entity_field_retract",
    "_entity_field_expire",
    "_entity_field_reattribute",
    "_memory_replace",
    "_memory_retract",
    "_memory_expire",
    "_memory_reinstate",
    "_memory_reattribute",
    "_memory_supersede",
    "_identity_claim_supersede",
    "_recommendation_reject",
]
