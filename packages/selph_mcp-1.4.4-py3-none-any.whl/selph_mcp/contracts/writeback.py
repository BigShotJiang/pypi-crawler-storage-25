"""Writeback event contracts (`writeback_event_v2`).

Implements §3.3 / §3.3.1 of the implementation plan and §4.2 of the
conversational memory-boundary strategy. Three event families:

- `SessionObservation` — Layer 1 capture of harness session text. The
  full ingest pipeline (Phases 0–7) always runs. `store_raw_only` has
  been removed from the contract (Track A, 2026-05-01) — observe always
  means "persist Layer 1 evidence then run the selected ingest path".

  **v2 additions (Phase A, §4.2):** four optional boundary-metadata fields
  (`provenance_role`, `memory_boundary_class`, `stability_hint`,
  `write_intent`) are declared here and forwarded onto
  `raw_evidence.metadata_json` (via `insert_raw_evidence(metadata=...)`)
  by the kernel observe path. No extraction behavior changes in Phase A.

- `RecommendationFeedback` — accept / skip / modify / defer outcomes for
  a previously surfaced recommendation, keyed by `feedback_event_key`.
- `DriftSignal` — harness flags that its local cache disagrees with Selph
  (logged for offline investigation; no live mutation).
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Session observation (§3.3.1)
# ---------------------------------------------------------------------------


class Speaker(str, Enum):
    """Who produced the observed utterance."""

    user = "user"
    assistant = "assistant"
    system = "system"


class SignalKind(str, Enum):
    """Layer-2 candidate signals the harness flags inside the raw text.

    These are *candidates* only — never promoted directly. Any Layer 2
    derivative still has to flow through Phases 0–7.
    """

    decision = "decision"
    preference = "preference"
    correction = "correction"
    edit = "edit"
    drift = "drift"


class IngestMode(str, Enum):
    """Controls how a session observation is processed.

    ``store_raw_only`` has been hard-removed (Track A, 2026-05-01).
    Observe always runs the full extraction pipeline. This enum is retained
    so callers that already import ``IngestMode.deep_ingest`` continue to
    compile; surface-agent and pipeline-agent will remove the remaining
    ``IngestMode.store_raw_only`` call sites listed at the bottom of this
    module's Track A surface audit.
    """

    # Run the full extraction pipeline.
    deep_ingest = "deep_ingest"


class SpanRef(BaseModel):
    """Character span pointer into the raw `text` payload."""

    model_config = ConfigDict(extra="forbid")

    start: int = Field(..., ge=0)
    end: int = Field(..., ge=0)


class StructuredSignal(BaseModel):
    """A Layer-2 candidate flag attached to a span of raw text."""

    model_config = ConfigDict(extra="forbid")

    kind: SignalKind
    span_ref: SpanRef
    note: str
    confidence: float = Field(..., ge=0.0, le=1.0)


class LinkContext(BaseModel):
    """Optional back-references that tie this observation to prior reads."""

    model_config = ConfigDict(extra="forbid")

    etag: Optional[str] = Field(
        default=None,
        description="The Selph etag the harness was operating on when this observation was produced.",
    )
    recommendation_key: Optional[str] = Field(
        default=None,
        description="`feedback_event_key` of a recommendation this observation relates to.",
    )


class SessionObservation(BaseModel):
    """Layer-1 raw evidence captured from a harness session.

    Per §3.3.1: this is an extension of the existing
    `/ingest/selph/message` data source (`source = "harness_session"`),
    not a new evidence family. `text` is always stored verbatim as
    Layer 1; `structured_signals` are Layer 2 candidates only.
    """

    model_config = ConfigDict(extra="forbid")

    consumer_id: str
    harness_id: str
    session_id: str
    captured_at: datetime
    speaker: Speaker
    text: str = Field(
        ...,
        description="Layer 1 raw — always stored verbatim in `selph_utterances`.",
    )
    structured_signals: List[StructuredSignal] = Field(
        default_factory=list,
        description="Layer 2 candidates. Never promoted directly — must flow through Phases 0–7.",
    )
    link_context: Optional[LinkContext] = None
    mode: IngestMode = Field(
        default=IngestMode.deep_ingest,
        description="Observation processing mode. Only `deep_ingest` is supported; "
                    "`store_raw_only` has been removed from this contract.",
    )

    # ------------------------------------------------------------------
    # v2: memory-boundary metadata (§4.2, Phase A)
    #
    # All four fields are optional so existing clients that omit them
    # remain valid against this schema (additive under extra="forbid").
    # The kernel observe path forwards these onto raw_evidence.source_metadata
    # (via insert_raw_evidence(metadata=...)) without any extraction
    # behavior change in Phase A.
    # ------------------------------------------------------------------

    provenance_role: Optional[
        Literal["user_stated", "user_endorsed_summary", "correction", "assistant_generated"]
    ] = Field(
        default=None,
        description=(
            "Who authored the content. `assistant_generated` content must never "
            "promote on its own — only admissible when explicitly endorsed by the user."
        ),
    )
    memory_boundary_class: Optional[
        Literal[
            "task", "problem", "frustration", "preference", "goal",
            "self_claim", "observation", "constraint", "other",
        ]
    ] = Field(
        default=None,
        description="Semantic category of the conversational span being written back.",
    )
    stability_hint: Optional[
        Literal["ephemeral", "candidate", "salient", "recurrent", "explicit"]
    ] = Field(
        default=None,
        description=(
            "Harness-assessed durability of this observation. "
            "`ephemeral` — discard-eligible; `candidate` — provisional; "
            "`salient` — recall-worthy; `recurrent` — seen across sessions; "
            "`explicit` — user-stated with clear intent."
        ),
    )
    write_intent: Optional[
        Literal["raw_only", "allow_l2_candidate", "promotion_signal"]
    ] = Field(
        default=None,
        description=(
            "Desired downstream treatment. `raw_only` — Layer 1 only (default posture); "
            "`allow_l2_candidate` — eligible for Phase 0–7 extraction on next batch; "
            "`promotion_signal` — strong endorsement / corroboration event."
        ),
    )


# ---------------------------------------------------------------------------
# Recommendation feedback
# ---------------------------------------------------------------------------


class FeedbackOutcome(str, Enum):
    """Outcome enum for `RecommendationFeedback` per §3.3.

    Phase 3 extension (non-breaking, additive): ``rejected`` is emitted by
    the Phase 3 ``recommendation_feedback(outcome="rejected")`` tool AND
    by ``correct(action=reject_recommendation)``. Both paths write to
    ``selph_recommendation_feedback`` via the same manager. See migration
    026 for the matching CHECK-constraint extension.
    """

    accepted = "accepted"
    skipped = "skipped"
    modified = "modified"
    deferred = "deferred"
    rejected = "rejected"


class RecommendationFeedback(BaseModel):
    """Outcome of a previously surfaced recommendation.

    References `feedback_event_key` from the recommendation envelope
    (§6.4 of the strategy doc). Used by the heuristic ranker (Phase 5).
    """

    model_config = ConfigDict(extra="forbid")

    feedback_event_key: str
    outcome: FeedbackOutcome
    notes: Optional[str] = None
    consumer_id: str
    harness_id: str
    session_id: str
    occurred_at: datetime


# ---------------------------------------------------------------------------
# Drift signal
# ---------------------------------------------------------------------------


class DriftSignal(BaseModel):
    """Harness flags that its local cache disagrees with Selph.

    Logged to `mcp_drift_signals` for offline investigation; no live
    mutation. Used to surface staleness bugs that the etag invalidation
    pipeline missed.
    """

    model_config = ConfigDict(extra="forbid")

    consumer_id: str
    harness_id: str
    session_id: str
    etag: str = Field(..., description="Etag the harness was operating on.")
    observed_local_state: Dict[str, Any] = Field(
        ...,
        description=(
            "Structured description of the disagreement the harness detected. "
            "Persisted to `mcp_drift_signals.observed_local_state` (JSONB) and "
            "validated as a dict by `mcp_drift_signal_manager`."
        ),
    )
    observed_at: datetime


__all__ = [
    "Speaker",
    "SignalKind",
    "IngestMode",
    "SpanRef",
    "StructuredSignal",
    "LinkContext",
    "SessionObservation",
    "FeedbackOutcome",
    "RecommendationFeedback",
    "DriftSignal",
]
