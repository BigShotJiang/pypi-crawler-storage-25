"""Whoami contract — secret-free consumer identity returned by GET /whoami.

This model mirrors :class:`~selph_mcp.contracts.consumer.Consumer` but:
- omits ``secret_hash`` (never returned over the wire);
- uses ``extra="forbid"`` so downstream validators fail loudly on schema drift.

Adapters import this from ``selph_mcp.contracts.whoami`` (allowed by the
``adapters-surface-only`` import-linter contract:
``adapters.** -> selph_mcp.contracts.**``).

v2 addition (Phase A): ``memory_boundary_policy_version`` is part of the
``writeback_event_version`` 1→2 contract bump. ``Optional[int]`` lets a
**newer** client validate an older server's response (where the field is
absent). It does NOT protect older clients that pin a pre-v2 ``Whoami``
model with ``extra="forbid"`` — those will hard-fail validation when the
new server returns this field. This is the accepted breaking-change
boundary documented in §4.2 of the memory-boundary brief; the gate is
``selph-mcp`` wheel re-release before Phase C ships. Harness bootstrap
uses this value to detect policy drift and fire upgrade proposals (§4.6).

v3 addition (Phase F — remote decoupling strategy): ``recommended_wheel_version``
and ``min_supported_wheel_version`` enable server-driven wheel drift detection.
SKILL.md's returning flow runs ``selph-mcp-bootstrap version --json``, compares
against these fields, and offers a numbered upgrade menu when the installed wheel
falls behind. Both are ``Optional[str]`` so a v3 client can talk to a pre-v3
server without validation failure (``None`` from old server = no drift check).
Source on the server side: env vars ``SELPH_RECOMMENDED_WHEEL_VERSION`` and
``SELPH_MIN_SUPPORTED_WHEEL_VERSION`` (set via ``cloud.sh sync env``).

v4 addition (Phase 2 — persona adapter failure/feedback retry surfacing):
``retryable_report_count`` and ``retryable_report_summary`` carry a server-
computed snapshot of rows in ``mcp_failure_reports`` with ``status='retryable'``
for this consumer/user. Both are ``Optional`` (default ``None``) so a newer
client can read a pre-v4 server's response without validation failure. As with
prior bumps, the breaking-change boundary is in the OTHER direction: an
older client pinned to a pre-v4 ``Whoami`` model with ``extra="forbid"``
hard-fails when this server emits the new fields. The accepted gate is the
wheel re-release plus ``SELPH_MIN_SUPPORTED_WHEEL_VERSION`` raised before
emit is enabled — the server-side opt-in is gated by env var
``SELPH_RETRYABLE_REPORTS_EMIT`` (default off) so the v4 response can ship
ahead of the wheel rollout without breaking older adapters in production.
"""

from __future__ import annotations

from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from selph_mcp.contracts.consumer import BudgetTier, Scope, SensitivityCeiling


class RetryableReportSummary(BaseModel):
    """One short, product-vocabulary entry describing a retryable failure.

    Server-rendered for the Whoami v4 ``retryable_report_summary`` list.
    Adapter consumers display ``human_summary`` directly; ``event_id`` is
    the join key the adapter passes back via the ``retry_for_event_id``
    persona-tool argument when the user confirms a retry.

    Schema-hiding rule (``.claude/rules/api-surface.md``): the ``kind``
    enum uses product vocabulary (``"edit"``, ``"ask"``, ``"note"``,
    ``"feedback"``) rather than internal MCP tool names so the contract
    does not leak Selph's internal taxonomy.
    """

    model_config = ConfigDict(extra="forbid")

    event_id: str = Field(
        ...,
        description=(
            "UUID string identifying the original failure record. "
            "Adapter passes this back as ``retry_for_event_id`` on the "
            "subsequent persona-tool call."
        ),
    )
    kind: Literal["edit", "note"] = Field(
        ...,
        description=(
            "Public-vocabulary classification of what was attempted. "
            "Used for sort/group ordering on the adapter side; does not "
            "name internal tool/memory/hub identifiers. The enum is "
            "intentionally tighter than the brief draft: read-only "
            "failures (e.g. ``ask_selph``) flow to ``status='fixed'`` "
            "per §10 and never appear in this summary, and feedback "
            "rows cannot reach ``status='retryable'`` per the DB CHECK "
            "constraint — so neither ``ask`` nor ``feedback`` are "
            "reachable kinds for retryables."
        ),
    )
    human_summary: str = Field(
        ...,
        max_length=80,
        description=(
            "Short server-rendered description in product vocabulary "
            "(≤ 80 chars). Adapter slim controllers display this verbatim."
        ),
    )
    observed_at: datetime = Field(
        ...,
        description="When the original failure was first observed.",
    )


class Whoami(BaseModel):
    """Secret-free consumer identity payload for ``GET /apps/mcp/whoami``.

    The server builds this from the authenticated :class:`~selph_mcp.contracts.consumer.Consumer`
    object resolved by ``verify_consumer_bearer`` — no second DB round-trip.

    Adapters use :meth:`Whoami.model_validate` to parse the response body so
    any contract drift surfaces as a ``ValidationError`` rather than a silent
    ``KeyError``-on-missing-field fallback (async-safety rule 6).
    """

    model_config = ConfigDict(extra="forbid")

    consumer_id: str = Field(
        ...,
        description="Stable consumer identifier (e.g. ``cns-<8hex>``).",
    )
    user_id: str = Field(
        ...,
        description="Selph user_id bound to this consumer (e.g. ``U001``).",
    )
    harness_id: str = Field(
        ...,
        description="Harness identifier (e.g. ``claude-code``).",
    )
    display_name: str = Field(
        ...,
        description="Human-readable label for this consumer.",
    )
    allowed_scopes: List[Scope] = Field(
        default_factory=list,
        description="Projection scopes this consumer may request.",
    )
    sensitivity_ceiling: SensitivityCeiling = Field(
        default=SensitivityCeiling.normal,
        description="Maximum sensitivity tier this consumer may receive.",
    )
    budget_tier: BudgetTier = Field(
        default=BudgetTier.standard,
        description="Daily persona-credit budget tier.",
    )
    revoked_at: Optional[datetime] = Field(
        default=None,
        description="Non-null when the consumer has been revoked.",
    )
    etag_cursor: int = Field(
        default=0,
        ge=0,
        description=(
            "Monotonic invalidation log cursor. Sent by adapters on the "
            "returning-user handshake so the server can return the purge "
            "set since this point."
        ),
    )
    memory_boundary_policy_version: Optional[int] = Field(
        default=None,
        ge=1,
        description=(
            "Active memory-boundary policy version on the server "
            "(``MEMORY_BOUNDARY_POLICY_VERSION`` from "
            "``selph_mcp.contracts.versions``). ``None`` from a newer client "
            "talking to a pre-v2 server. Harness bootstrap compares this "
            "against its locally-installed policy version to detect drift "
            "and fire upgrade proposals per §4.6 of the memory-boundary "
            "strategy."
        ),
    )

    # v3 fields — Phase F (remote decoupling strategy)
    recommended_wheel_version: Optional[str] = Field(
        default=None,
        description=(
            "Server-recommended wheel version string (e.g. ``'1.2.0'``). "
            "``None`` from a pre-v3 server. When set, SKILL.md compares "
            "against the locally installed wheel version and offers a numbered "
            "upgrade menu when the installed version lags behind."
        ),
    )
    min_supported_wheel_version: Optional[str] = Field(
        default=None,
        description=(
            "Minimum wheel version the server will support (e.g. ``'1.1.0'``). "
            "``None`` from a pre-v3 server. When the installed wheel is older "
            "than this version, SKILL.md must refuse to continue and print the "
            "upgrade command before proceeding."
        ),
    )

    # v4 fields — Phase 2 (persona adapter failure/feedback retry surfacing)
    retryable_report_count: Optional[int] = Field(
        default=None,
        ge=0,
        description=(
            "Total number of ``mcp_failure_reports`` rows in status "
            "``retryable`` for this consumer/user. ``None`` from a pre-v4 "
            "server, or when the server has ``SELPH_RETRYABLE_REPORTS_EMIT`` "
            "disabled. Adapter slim controllers treat ``None`` and ``0`` "
            "identically (skip the retry-prompt block)."
        ),
    )
    retryable_report_summary: Optional[List[RetryableReportSummary]] = Field(
        default=None,
        description=(
            "Up to 5 server-rendered summaries of the most recent retryable "
            "rows, ordered by ``observed_at`` descending. Adapter renders "
            "each ``human_summary`` verbatim. The ``count`` field carries "
            "the true total — when ``count > len(summary)``, slim "
            "controllers append ``and N more``."
        ),
    )


__all__ = ["Whoami", "RetryableReportSummary"]
