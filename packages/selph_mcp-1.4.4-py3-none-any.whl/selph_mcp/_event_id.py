"""X-Selph-Event-Id contextvar for MCP failure-report correlation (Phase 1, §2.1).

The ``event_id`` contextvar is set by:

- FastAPI middleware in ``ingestion_api/main.py`` when a request carries
  an ``X-Selph-Event-Id`` header (bridge-CLI path: adapter generated the
  id and forwarded it).
- Persona-tool entry points for the Remote MCP path (server generates
  the id via ``uuid4()``).

``selph_mcp/_client.py:_headers()`` reads the contextvar via
:func:`get_event_id` and emits the ``X-Selph-Event-Id`` header on
loopback HTTP calls so inner bridge routes know an outer persona-tool
already owns the row (anti-double-log rule, §9.3).

Public surface
--------------
:data:`_event_id_ctx`     — the raw ``ContextVar``
:func:`get_event_id`      — returns the current value or ``None``
:func:`set_event_id`      — sets and returns a reset token
"""
from __future__ import annotations

from contextvars import ContextVar, Token
from typing import Optional

_event_id_ctx: ContextVar[Optional[str]] = ContextVar(
    "_event_id_ctx", default=None
)


def get_event_id() -> Optional[str]:
    """Return the current event_id, or ``None`` when unset."""
    return _event_id_ctx.get()


def set_event_id(event_id: Optional[str]) -> Token[Optional[str]]:
    """Set the event_id contextvar; returns a reset token.

    Callers must call ``token.var.reset(token)`` in the ``finally``
    block that wraps the request scope — per async-safety rule §3.
    """
    return _event_id_ctx.set(event_id)


__all__ = ["_event_id_ctx", "get_event_id", "set_event_id"]
