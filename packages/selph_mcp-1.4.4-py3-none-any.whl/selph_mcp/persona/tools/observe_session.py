"""Persona ``observe_session`` tool (Track A, 2026-05-01).

Thin wrapper around :func:`selph_mcp.kernel.observe.observe_session`.
``store_raw_only`` / ``mode`` have been removed from the contract.
Observe always runs the full extraction pipeline. Returns an envelope
with a citation pointing at the newly minted ``raw_evidence_id``.

Zero budget cost — writes are free.

New parameters (Track A):
    ``observation_provenance`` — who authored this observation (domain-neutral
        product vocabulary per rules/api-surface.md).
    ``apply_session_ranker`` — when True the session ranker decides which USER
        turns are evidence-worthy. Defaults to True for session paths.
    ``idempotency_key`` — caller-supplied opaque key; server combines with
        authenticated user_id to prevent cross-tenant collisions.

Channel vs ``mode_used`` (deferred contract note):
    :class:`ModeUsed` is a Phase 1a-frozen read-side enum (``brief``,
    ``targeted``, ``insight``, ``evidence``, ``none``) — there is no
    ``"writeback"`` value. To stay contract-clean we report
    ``mode_used=ModeUsed.brief`` (the smallest read-shape) and surface
    the real channel via ``data["channel"] = "writeback"``. Harnesses
    that need to distinguish writeback from a read must branch on
    ``data["channel"]``, not ``mode_used``. Adding a first-class
    writeback ``mode_used`` value is a future contract bump — deferred
    beyond Phase 2.
"""
from __future__ import annotations

import logging
import time as _time
from datetime import datetime, timezone
from typing import Any, Optional

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import (
    Citation,
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
    RefType,
)
from selph_mcp.contracts.writeback import SessionObservation
from selph_mcp.kernel import observe as kernel_observe
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import compute_fingerprint
from selph_mcp._log import get_logger, log_event
from selph_mcp._event_id import get_event_id, set_event_id

_log = get_logger("selph_mcp.persona.tools.observe_session")


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    if consumer.allowed_scopes:
        try:
            return ConsumerScope(consumer.allowed_scopes[0].value)
        except ValueError:
            pass
    return ConsumerScope.personal


async def observe_session(
    *,
    consumer: Consumer,
    observation: SessionObservation,
    graph: Any = None,
    retry_for_event_id: Optional[str] = None,
    apply_session_ranker: Optional[bool] = None,
    idempotency_key: Optional[str] = None,
) -> PersonaResponse:
    """Persist a session observation as Layer 1 raw_evidence.

    The kernel adapter handles the consumer/user binding anti-bypass,
    L1 write, and extraction pipeline (Phases 0–7). This wrapper shapes
    the response envelope. ``store_raw_only`` / ``mode`` have been removed
    (Track A, 2026-05-01).

    Phase 2 addition: accepts ``retry_for_event_id`` (optional) to
    correlate this call with a previously-failed ``mcp_failure_reports``
    row. On success the parent row is updated to ``status='retried'``;
    on failure a new chained row is inserted with
    ``parent_event_id=retry_for_event_id``.
    """
    import asyncio as _asyncio
    import uuid as _uuid

    t0 = _time.perf_counter()

    # Server-side event_id for Remote MCP path (§9.3).
    existing_event_id = get_event_id()
    _tok = None
    if not existing_event_id:
        _server_event_id = str(_uuid.uuid4())
        _tok = set_event_id(_server_event_id)
    else:
        _server_event_id = existing_event_id

    log_event(
        _log, logging.INFO, "mcp.persona.observe_session.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        session_id=observation.session_id,
        text_len=len(observation.text or ""),
        observation_provenance=observation.provenance_role,
        event_id=_server_event_id,
        retry_for_event_id=retry_for_event_id,
    )

    scope = _primary_scope(consumer)
    ceiling = consumer.sensitivity_ceiling.value

    # Phase 1 §1.3: fingerprint BEFORE retrieval.  Writeback ack →
    # empty dependency_keys (spec: writebacks do not carry dep keys).
    _fp = compute_fingerprint(
        tool="observe_session",
        params={
            "session_id": observation.session_id,
            "observation_provenance": observation.provenance_role,
        },
        consumer=consumer,
    )

    try:
        try:
            result = await kernel_observe.observe_session(
                consumer=consumer,
                observation=observation,
                graph=graph,
                apply_session_ranker=apply_session_ranker,
                idempotency_key=idempotency_key,
            )
        except Exception as _exc:
            # Server-observed failure capture (§9.3). Best-effort — never raise.
            try:
                from selph_db import mcp_failure_report_manager as _report_mgr
                from selph_mcp._redaction import redact_payload as _redact
                _loop = _asyncio.get_running_loop()
                _ev = _uuid.UUID(_server_event_id)
                _redacted = _redact({
                    "session_id": observation.session_id,
                    "observation_provenance": observation.provenance_role,
                })
                _parent_uuid = _uuid.UUID(retry_for_event_id) if retry_for_event_id else None
                await _loop.run_in_executor(
                    None,
                    lambda: _report_mgr.insert_or_merge(
                        event_id=_ev,
                        consumer_id=consumer.consumer_id,
                        user_id=consumer.user_id,
                        kind="failure",
                        observed_at=datetime.now(timezone.utc),
                        tool_name="observe_session",
                        request_payload_redacted=_redacted,
                        error_source="server_5xx",
                        error_code=type(_exc).__name__,
                        error_message=str(_exc)[:2048],
                        parent_event_id=_parent_uuid,
                    ),
                )
                if retry_for_event_id:
                    _parent_ev = _uuid.UUID(retry_for_event_id)
                    await _loop.run_in_executor(
                        None,
                        lambda: _report_mgr.update_status(
                            _parent_ev,
                            status="failed_again",
                            retry_outcome={
                                "new_event_id": str(_ev),
                                "error_type": type(_exc).__name__,
                                "error": str(_exc)[:300],
                            },
                            expected_consumer_id=consumer.consumer_id,
                            expected_user_id=consumer.user_id,
                            expected_current_statuses={"retryable"},
                        ),
                    )
            except Exception:  # noqa: BLE001 — never surface capture errors
                pass
            raise

        # On success: if this was a retry, update the parent row. Best-effort.
        if retry_for_event_id:
            try:
                from selph_db import mcp_failure_report_manager as _report_mgr_ok
                _loop = _asyncio.get_running_loop()
                _parent_ev = _uuid.UUID(retry_for_event_id)
                await _loop.run_in_executor(
                    None,
                    lambda: _report_mgr_ok.update_status(
                        _parent_ev,
                        status="retried",
                        retry_outcome={
                            "event_id": _server_event_id,
                            "result": "ok",
                        },
                        expected_consumer_id=consumer.consumer_id,
                        expected_user_id=consumer.user_id,
                        expected_current_statuses={"retryable"},
                    ),
                )
            except Exception:  # noqa: BLE001
                pass

        raw_evidence_id = result.get("raw_evidence_id")
        citations = []
        if raw_evidence_id:
            try:
                citations.append(
                    Citation(
                        ref_type=RefType.observation,
                        ref_id=str(raw_evidence_id),
                        layer=1,
                        captured_at=observation.captured_at,
                    )
                )
            except Exception:  # noqa: BLE001
                pass

        captured = observation.captured_at
        source_cutoff_at = (
            captured.isoformat() if hasattr(captured, "isoformat") else str(captured)
        )
        etag = _etag.generate_etag(
            kind="writeback",
            subject="self",
            intent="briefing",
            user_id=consumer.user_id,
            consumer_scope=scope,
            sensitivity_class=ceiling,
            constraints={
                "session_id": observation.session_id,
                "observation_provenance": observation.provenance_role,
            },
            content_cutoff_at=source_cutoff_at,
        )

        # ``mode_used`` must be a :class:`ModeUsed` value — there is no
        # "writeback" enum in Phase 1a (ModeUsed is read-side). We report
        # ``brief`` (smallest footprint) and surface the real channel in
        # ``data.channel`` so harnesses can differentiate. This keeps the
        # Phase 1a envelope contract frozen.
        envelope = build_envelope(
            mode_used=ModeUsed.brief,
            ok=bool(result.get("status") == "ok"),
            data={
                "channel": "writeback",
                "raw_evidence_id": raw_evidence_id,
                "ingest_status": result.get("ingest_status"),
                "operation_id": result.get("operation_id"),
            },
            citations=citations,
            meta_inputs={
                "source_cutoff_at": source_cutoff_at,
                "staleness_status": "fresh",
                "confidence": 1.0,
                "etag": etag,
                "budget_tier": consumer.budget_tier.value,
                "consumer_scope": scope,
                "sensitivity_class": ceiling,
            },
            query_fingerprint=_fp,
            dependency_keys=[],
        )

        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.INFO, "mcp.persona.observe_session.complete",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            session_id=observation.session_id,
            raw_evidence_id=raw_evidence_id,
            ingest_status=result.get("ingest_status"),
            operation_id=result.get("operation_id"),
            duration_ms=duration_ms,
        )
        return envelope
    finally:
        # Unconditional contextvar cleanup (async-safety rule §3).
        if _tok is not None:
            try:
                _tok.var.reset(_tok)
            finally:
                pass


__all__ = ["observe_session"]
