"""Per-mode kernel dispatch helpers.

Each dispatcher produces a uniform result dict::

    {
        "data":             <mode-specific payload>,
        "citations":        list[Citation],
        "source_cutoff_at": str,             # derived from record timestamps
        "confidence":       float,
        "mode_executed":    Optional[str],   # only on query-backed modes
        "mode_requested":   Optional[str],
        "insight_degraded_reason": Optional[str],
    }

The orchestrator in :mod:`_entry` does not care which kernel adapter
produced the result — only the surface shape above is contract.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.envelope import Citation
from selph_mcp.contracts.read import GetContextRequest
from selph_mcp.kernel import project as kernel_project
from selph_mcp.kernel import query as kernel_query
from selph_mcp.persona import etag as _etag
from selph_mcp.persona._hub_classifier import classify_question_to_hub
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.tools.get_context.dispatch")

from selph_mcp.persona.tools.get_context._citations import (
    _citations_from_hub_payload,
    _citations_from_kernel_records,
)
from selph_mcp.persona.tools.get_context._helpers import (
    _SUBJECT_TO_HUB_MAP,
    _compose_query_text,
    _safe_float,
)


async def _dispatch_brief(
    request: GetContextRequest,
    consumer: Consumer,
    graph: Any,
) -> Dict[str, Any]:
    """Brief mode: single hub payload read keyed on subject.

    We map ``Subject`` → hub_type via :data:`_SUBJECT_TO_HUB_MAP`.
    Subjects that have no direct hub (e.g. ``topic``) fall back to
    ``current_identity`` so the caller still gets a response envelope
    rather than a 400. The mapping is intentionally not a 1:1 contract
    — it's a brief-mode heuristic documented in-line.
    """
    hub_type = _SUBJECT_TO_HUB_MAP.get(request.subject.value, "current_identity")
    result = await kernel_project.project(
        consumer=consumer,
        hub_type=hub_type,
        user_id=consumer.user_id,
    )
    payload = result.get("payload")
    citations = _citations_from_hub_payload(hub_type, payload)
    return {
        "data": payload or {},
        "citations": citations,
        "hub_type": hub_type,
        # Fix D: source_cutoff_at is derived from the hub payload's own
        # timestamps (source_cutoff_at / generated_at) rather than
        # wall-clock ``now()``. Empty payload falls back to the Unix
        # epoch via :func:`_etag.derive_content_cutoff` so an empty
        # result still has a deterministic etag.
        "source_cutoff_at": _etag.derive_content_cutoff(
            [payload] if payload else None
        ),
        "confidence": _safe_float(
            (payload or {}).get("confidence_score")
        ) or 0.7,
    }


async def _dispatch_targeted(
    request: GetContextRequest,
    consumer: Consumer,
    graph: Any,
    chroma: Any,
    question_override: Optional[str] = None,
    domain_hint_prefix: Optional[str] = None,
) -> Dict[str, Any]:
    query_text = _compose_query_text(request, question_override, domain_hint_prefix=domain_hint_prefix)
    result = await kernel_query.query(
        consumer=consumer,
        query_text=query_text,
        graph=graph,
        chroma=chroma,
        user_id=consumer.user_id,
        mode="targeted",
    )
    records = result.get("data") or []
    citations = _citations_from_kernel_records(records)
    return {
        "data": {"records": records, "timing_ms": result.get("timing_ms")},
        "citations": citations,
        # Fix D: cutoff derived from the records' own timestamps, not
        # wall clock. Empty result → epoch fallback (deterministic).
        "source_cutoff_at": _etag.derive_content_cutoff(records),
        "confidence": 0.6,
        # Fix C2: surface the kernel's actually-executed mode so the
        # caller can detect insight → targeted silent degrades. The
        # kernel returns ``mode_executed`` as a stable alias of ``mode``.
        "mode_executed": result.get("mode_executed") or result.get("mode"),
        "mode_requested": result.get("mode_requested"),
        "insight_degraded_reason": result.get("insight_degraded_reason"),
        # Propagate kernel-level failure so the entry orchestrator can
        # surface ok=False instead of an empty success envelope.
        "kernel_status": result.get("status"),
        "kernel_error_message": result.get("error_message"),
    }


async def _dispatch_insight(
    request: GetContextRequest,
    consumer: Consumer,
    graph: Any,
    chroma: Any,
    synthesizer: Any,
    self_entity_id: Optional[str],
    question_override: Optional[str] = None,
    domain_hint_prefix: Optional[str] = None,
) -> Dict[str, Any]:
    query_text = _compose_query_text(request, question_override, domain_hint_prefix=domain_hint_prefix)

    # Read the subject's primary hub and pass it to the synthesizer as
    # extra evidence. Without this, vague meta-questions (e.g. "who do I
    # talk to a lot") produce zero KNN anchors against actual memory
    # content and the synthesizer responds "not enough information"
    # despite a fully-built persona — see _SUBJECT_TO_HUB_MAP for the
    # subject → hub_type mapping the brief mode already uses.
    subject_hub_type = _SUBJECT_TO_HUB_MAP.get(
        request.subject.value, "current_identity"
    )
    # Topical hub: ask gpt-4.1-mini which hub_type best fits the
    # question. The subject hub (e.g. current_identity for
    # subject="self") is generic; the topical hub answers questions
    # like "name people I communicate with" → relationship_priority
    # whose payload actually names people. When both differ we merge
    # both into evidence; when they match we only load once.
    #
    # We classify against ``query_text`` (which includes any
    # domain_hint_prefix prepended by _compose_query_text) so an
    # explicit domain hint also steers topical-hub selection.
    #
    # The LLM classifier replaces the prior keyword-based domain
    # classifier — keyword matching misroutes phrasings like "who do
    # I talk to a lot" (matches "talk" → voice rather than the user's
    # actual relationship intent). Soft-fail to None on any error;
    # the subject hub is still loaded.
    topical_hub_type: Optional[str] = await classify_question_to_hub(query_text)
    if topical_hub_type and topical_hub_type == subject_hub_type:
        topical_hub_type = None

    hubs_to_load: List[tuple] = [(subject_hub_type, "subject_primary_hub")]
    if topical_hub_type:
        hubs_to_load.append((topical_hub_type, "topical_hub"))

    hub_records: List[Dict[str, Any]] = []
    hub_citations: List[Citation] = []
    hub_payloads: List[Dict[str, Any]] = []
    for _hub_type, _source in hubs_to_load:
        try:
            hub_result = await kernel_project.project(
                consumer=consumer,
                hub_type=_hub_type,
                user_id=consumer.user_id,
            )
            # kernel_project.project returns {status, user_id, hub_type,
            # payload, duration_ms} — hub_id / confidence_score live
            # inside the payload (when the hub builder wrote them
            # there), not at the top level. Pull citation metadata
            # from the payload via _citations_from_hub_payload to stay
            # consistent with brief mode.
            payload = hub_result.get("payload")
            if payload:
                hub_records.append({
                    "hub_type": _hub_type,
                    "payload": payload,
                    "source": _source,
                })
                hub_citations.extend(
                    _citations_from_hub_payload(_hub_type, payload)
                )
                hub_payloads.append(payload)
        except Exception as exc:  # noqa: BLE001 — hub merge is best-effort
            # Per rules/naming-and-constraints.md: every except block
            # must log. This is a soft-fail (the insight call still
            # proceeds with whatever hubs did load), but a hub-read
            # regression must be visible — silently swallowing makes
            # it look like ordinary "no evidence" cases.
            log_event(
                _log,
                logging.WARNING,
                "mcp.persona.dispatch.hub_load_failed",
                consumer_id=consumer.consumer_id,
                user_id=consumer.user_id,
                hub_type=_hub_type,
                source=_source,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )
            continue

    result = await kernel_query.query(
        consumer=consumer,
        query_text=query_text,
        graph=graph,
        chroma=chroma,
        user_id=consumer.user_id,
        mode="insight",
        synthesizer=synthesizer,
        self_entity_id=self_entity_id,
        extra_evidence=hub_records or None,
    )
    records = result.get("data") or []
    # _citations_from_kernel_records filters by anchor_type so hub
    # records (which carry no anchor_type) are skipped naturally —
    # no manual dedup needed.
    citations = list(hub_citations) + _citations_from_kernel_records(records)
    insight = result.get("insight") or {}
    # Codex finding (etag staleness): when KNN is empty the records list
    # has no timestamps, but each hub payload may carry generated_at /
    # source_cutoff_at — feeding the payloads into derive_content_cutoff
    # alongside records lets the etag track hub rebuilds even on
    # hub-only/meta queries. Same shape brief mode uses.
    cutoff_inputs: List[Any] = list(hub_payloads) + list(records)
    return {
        "data": {
            "records": records,
            "insight": insight,
            "executed_mode": result.get("mode"),
            "timing_ms": result.get("timing_ms"),
        },
        "citations": citations,
        "source_cutoff_at": _etag.derive_content_cutoff(cutoff_inputs or None),
        "confidence": 0.7,
        "mode_executed": result.get("mode_executed") or result.get("mode"),
        "mode_requested": result.get("mode_requested"),
        "insight_degraded_reason": result.get("insight_degraded_reason"),
        # Propagate kernel-level failure so the entry orchestrator can
        # surface ok=False instead of an empty success envelope.
        "kernel_status": result.get("status"),
        "kernel_error_message": result.get("error_message"),
    }
