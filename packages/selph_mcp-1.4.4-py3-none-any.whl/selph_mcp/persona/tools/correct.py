"""Persona ``correct`` tool (Phase 2 task 14).

Thin wrapper around :func:`selph_mcp.kernel.revise.revise` — dispatches
a :class:`CorrectionPayload` through the §3.4 compile table and wraps
the kernel response in a :class:`PersonaResponse` envelope.

Zero budget cost — corrections are free.

Channel vs ``mode_used`` (deferred contract note):
    :class:`ModeUsed` is a Phase 1a-frozen read-side enum — there is
    no ``"correction"`` value. To stay contract-clean we report
    ``mode_used=ModeUsed.brief`` and surface the real channel via
    ``data["channel"] = "correction"``. Harnesses that need to
    distinguish a correction from a read must branch on
    ``data["channel"]``. Adding a first-class correction
    ``mode_used`` value is a future contract bump — deferred beyond
    Phase 2.
"""
from __future__ import annotations

import logging
import time as _time
from datetime import datetime, timezone
from typing import Any, Optional

from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.correction import CorrectionPayload
from selph_mcp.contracts.envelope import (
    ConsumerScope,
    ModeUsed,
    PersonaResponse,
)
from selph_mcp.kernel import revise as kernel_revise
from selph_mcp.persona import etag as _etag
from selph_mcp.persona.envelope_builder import build_envelope
from selph_mcp.persona.fingerprint import compute_fingerprint
from selph_mcp._log import get_logger, log_event
from selph_mcp._event_id import get_event_id, set_event_id

_log = get_logger("selph_mcp.persona.tools.correct")


def _primary_scope(consumer: Consumer) -> ConsumerScope:
    if consumer.allowed_scopes:
        try:
            return ConsumerScope(consumer.allowed_scopes[0].value)
        except ValueError:
            pass
    return ConsumerScope.personal


async def correct(
    *,
    consumer: Consumer,
    payload: CorrectionPayload,
    retry_for_event_id: Optional[str] = None,
) -> PersonaResponse:
    """Apply a structured correction via the kernel revise dispatcher."""
    import uuid as _uuid
    from datetime import datetime, timezone

    t0 = _time.perf_counter()

    # Server-side event_id for Remote MCP path (§9.3):
    # set contextvar so loopback HTTP calls from this tool carry the id forward.
    existing_event_id = get_event_id()
    _tok = None
    if not existing_event_id:
        _server_event_id = str(_uuid.uuid4())
        _tok = set_event_id(_server_event_id)
    else:
        _server_event_id = existing_event_id

    log_event(
        _log, logging.INFO, "mcp.persona.correct.entry",
        consumer_id=consumer.consumer_id,
        user_id=consumer.user_id,
        action=payload.action.value,
        target_type=payload.target_type.value,
        target_id=payload.target_id,
        event_id=_server_event_id,
        retry_for_event_id=retry_for_event_id,
    )

    scope = _primary_scope(consumer)
    ceiling = consumer.sensitivity_ceiling.value

    # Phase 1 §1.3: fingerprint BEFORE retrieval.  Correction ack →
    # empty dependency_keys.
    _fp = compute_fingerprint(
        tool="correct",
        params={
            "action": payload.action.value,
            "target_type": payload.target_type.value,
            "target_id": payload.target_id,
        },
        consumer=consumer,
    )

    try:
        try:
            result = await kernel_revise.revise(consumer=consumer, payload=payload)
        except Exception as _exc:
            # Server-observed failure capture (§9.3). Best-effort — never raise.
            try:
                import asyncio as _asyncio
                from selph_db import mcp_failure_report_manager as _report_mgr
                from selph_mcp._redaction import redact_payload as _redact_payload
                _loop = _asyncio.get_running_loop()
                import uuid as _uuid2
                _ev = _uuid2.UUID(_server_event_id)
                _redacted = _redact_payload(payload.model_dump())
                _parent_uuid = _uuid2.UUID(retry_for_event_id) if retry_for_event_id else None
                await _loop.run_in_executor(
                    None,
                    lambda: _report_mgr.insert_or_merge(
                        event_id=_ev,
                        consumer_id=consumer.consumer_id,
                        user_id=consumer.user_id,
                        kind="failure",
                        observed_at=datetime.now(timezone.utc),
                        tool_name="correct",
                        request_payload_redacted=_redacted,
                        error_source="server_5xx",
                        error_code=type(_exc).__name__,
                        error_message=str(_exc)[:2048],
                        parent_event_id=_parent_uuid,
                    ),
                )
                if retry_for_event_id:
                    _parent_ev = _uuid2.UUID(retry_for_event_id)
                    await _loop.run_in_executor(
                        None,
                        lambda: _report_mgr.update_status(
                            _parent_ev,
                            status="failed_again",
                            retry_outcome={
                                "new_event_id": str(_ev),
                                "error_type": type(_exc).__name__,
                                "error": str(_exc)[:300],
                            },
                            expected_consumer_id=consumer.consumer_id,
                            expected_user_id=consumer.user_id,
                            expected_current_statuses={"retryable"},
                        ),
                    )
            except Exception:  # noqa: BLE001 — never surface capture errors
                pass
            raise

        # On success: if this was a retry, update the parent row. Best-effort.
        if retry_for_event_id:
            try:
                import asyncio as _asyncio2
                import uuid as _uuid3
                from selph_db import mcp_failure_report_manager as _report_mgr2
                _loop2 = _asyncio2.get_running_loop()
                _parent_ev2 = _uuid3.UUID(retry_for_event_id)
                await _loop2.run_in_executor(
                    None,
                    lambda: _report_mgr2.update_status(
                        _parent_ev2,
                        status="retried",
                        retry_outcome={
                            "event_id": _server_event_id,
                            "result": "ok",
                        },
                        expected_consumer_id=consumer.consumer_id,
                        expected_user_id=consumer.user_id,
                        expected_current_statuses={"retryable"},
                    ),
                )
            except Exception:  # noqa: BLE001
                pass

        effective = payload.effective_at
        if effective is not None:
            source_cutoff_at = (
                effective.isoformat() if hasattr(effective, "isoformat") else str(effective)
            )
        else:
            source_cutoff_at = "1970-01-01T00:00:00Z"
        etag = _etag.generate_etag(
            kind="correction",
            subject="self",
            intent="briefing",
            user_id=consumer.user_id,
            consumer_scope=scope,
            sensitivity_class=ceiling,
            constraints={
                "action": payload.action.value,
                "target_type": payload.target_type.value,
                "target_id": payload.target_id,
            },
            content_cutoff_at=source_cutoff_at,
        )

        # ``mode_used`` is frozen to :class:`ModeUsed` in Phase 1a; correction
        # is a writeback-family event so we report ``brief`` as the smallest
        # read-shape and surface the real channel via ``data.channel``.
        envelope = build_envelope(
            mode_used=ModeUsed.brief,
            ok=(result or {}).get("status") != "error",
            data={
                "channel": "correction",
                "kernel_result": result,
            },
            citations=[],
            meta_inputs={
                "source_cutoff_at": source_cutoff_at,
                "staleness_status": "fresh",
                "confidence": 1.0,
                "etag": etag,
                "budget_tier": consumer.budget_tier.value,
                "consumer_scope": scope,
                "sensitivity_class": ceiling,
            },
            query_fingerprint=_fp,
            dependency_keys=[],
        )

        duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
        log_event(
            _log, logging.INFO, "mcp.persona.correct.complete",
            consumer_id=consumer.consumer_id,
            user_id=consumer.user_id,
            action=payload.action.value,
            target_type=payload.target_type.value,
            target_id=payload.target_id,
            kernel_status=(result or {}).get("status"),
            duration_ms=duration_ms,
        )
        return envelope
    finally:
        # Unconditional contextvar cleanup (async-safety rule §3).
        if _tok is not None:
            _tok.var.reset(_tok)


__all__ = ["correct"]
