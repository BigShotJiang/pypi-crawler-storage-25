"""Workflow library loader and manifest renderer for Phase 5.

Provides three public callables:

- :func:`load_workflow_spec` — load and validate a ``WorkflowSpec`` from
  ``adapters/workflows/<workflow_id>/workflow.yaml`` (repo-only, build-time
  path) or, when running from the wheel, from the precompiled JSON manifest
  at ``selph_mcp/persona/workflow_manifests/<workflow_id>.json`` loaded via
  ``importlib.resources``.
- :func:`list_official_workflow_ids` — return the three v1 official workflow IDs.
- :func:`build_manifest` — adapt a ``WorkflowSpec`` into a ``WorkflowManifest``
  suitable for installation into ``.claude/skills/<workflow_id>/SKILL.md``.

Loading strategy (Phase B precompile fix)
-----------------------------------------
At wheel-install time the ``adapters/workflows/`` directory is excluded from
the package (``pyproject.toml:exclude``) and ``PyYAML`` is not in the wheel
``dependencies`` list.  To support pipx-only users:

1. ``scripts/build_workflow_manifests.py`` runs at build time, loads the YAML
   specs, and writes precompiled JSON to
   ``selph_mcp/persona/workflow_manifests/<id>.json``.
2. At runtime ``load_workflow_spec`` first tries the precompiled JSON manifest
   via ``importlib.resources``.  Only if that lookup fails (i.e. we are running
   from the repo source tree without precompiled manifests) does it fall back to
   the YAML file.  The YAML fallback imports ``yaml`` lazily so the wheel build
   is not blocked when ``PyYAML`` is absent.

Import-linter note
------------------
``selph_mcp.persona.workflows`` imports from ``selph_mcp.contracts.*`` only.
``WorkflowManifest`` now lives in ``selph_mcp.contracts.workflow_manifest`` so
no ``selph_mcp -> adapters`` edge is created.  The ``adapters-surface-only``
``.importlinter`` contract allows ``adapters.** -> selph_mcp.contracts.**``, and
``adapters/claude_code/using_selph/state_schema.py`` imports from there.
"""

from __future__ import annotations

import importlib.resources
import json
import re
from pathlib import Path
from typing import List

from selph_mcp.contracts.workflow_manifest import WorkflowManifest
from selph_mcp.contracts.workflow_spec import WorkflowSpec

# ---------------------------------------------------------------------------
# Workflow ID validation (duplicated regex — state_schema cannot be imported
# here due to the selph_mcp -> adapters import boundary; the canonical
# definition lives in selph_mcp.contracts.workflow_manifest and is also
# available via adapters.claude_code.using_selph.state_schema.validate_workflow_id)
# ---------------------------------------------------------------------------

_WORKFLOW_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,62}$")


def _validate_workflow_id(workflow_id: str) -> str:
    """Validate *workflow_id* against the path-safe regex.

    Same constraints as ``validate_workflow_id`` in
    ``selph_mcp.contracts.workflow_manifest``. Duplicated here because
    ``selph_mcp.persona.workflows`` cannot import from ``adapters.*``
    (import boundary), and importing ``_validate_workflow_id_str`` from
    ``selph_mcp.contracts.workflow_manifest`` is the clean path — but we
    use that function directly in :func:`load_workflow_spec` below.

    Args:
        workflow_id: Candidate workflow ID string.

    Returns:
        The validated workflow_id unchanged.

    Raises:
        ValueError: if the ID does not match the allowlist regex.
    """
    from selph_mcp.contracts.workflow_manifest import (
        _validate_workflow_id_str,
    )
    return _validate_workflow_id_str(workflow_id)


# ---------------------------------------------------------------------------
# Repo-root resolution (used only for the YAML fallback path)
# ---------------------------------------------------------------------------

def _repo_root() -> Path:
    """Return the repository root by walking up from this file.

    Path: ``selph_mcp/persona/workflows.py``
          → ``selph_mcp/persona/``  (parent)
          → ``selph_mcp/``          (parent.parent)
          → repo root               (parent.parent.parent)
    """
    return Path(__file__).resolve().parent.parent.parent


def load_workflow_manifest(workflow_id: str) -> WorkflowManifest:
    """Load a precompiled :class:`WorkflowManifest` from the JSON package data.

    This is the **wheel-safe path**: it uses ``importlib.resources`` to load
    the precompiled JSON written by ``scripts/build_workflow_manifests.py`` at
    build time, avoiding any dependency on ``PyYAML`` or the ``adapters/``
    directory tree (which is excluded from the wheel).

    Use this function when you need the rendered manifest for installation
    (i.e. writing to ``.claude/skills/<id>/SKILL.md``).  Use
    :func:`load_workflow_spec` only when you need the full :class:`WorkflowSpec`
    with all structured fields (e.g. for testing or re-rendering).

    Args:
        workflow_id: Stable kebab-case identifier validated against the
            allowlist regex before any filesystem access.

    Returns:
        A validated :class:`WorkflowManifest` loaded from the precompiled JSON.

    Raises:
        ValueError: if *workflow_id* does not match the allowlist regex.
        FileNotFoundError: if no precompiled JSON exists for *workflow_id*
            (run ``python scripts/build_workflow_manifests.py`` to generate).
        ValueError: if the JSON fails :class:`WorkflowManifest` validation.
    """
    _validate_workflow_id(workflow_id)

    try:
        pkg = importlib.resources.files("selph_mcp.persona.workflow_manifests")
        json_file = pkg.joinpath(f"{workflow_id}.json")
        with importlib.resources.as_file(json_file) as p:
            if not p.exists():
                raise FileNotFoundError(str(p))
            raw = p.read_text(encoding="utf-8")
    except FileNotFoundError:
        raise FileNotFoundError(
            f"No precompiled JSON manifest for workflow_id={workflow_id!r}. "
            "Run `python scripts/build_workflow_manifests.py` to generate."
        )

    data = json.loads(raw)
    try:
        return WorkflowManifest.model_validate(data)
    except Exception as exc:
        raise ValueError(
            f"WorkflowManifest validation failed for workflow_id={workflow_id!r}: {exc}"
        ) from exc


# ---------------------------------------------------------------------------
# Official workflow ID registry (v1 hardcoded — no filesystem enumeration)
# ---------------------------------------------------------------------------

_OFFICIAL_WORKFLOW_IDS: List[str] = [
    "morning-operator-brief",
    "vip-reply-drafting",
    "weekly-strategy-memo",
]


def list_official_workflow_ids() -> List[str]:
    """Return the list of v1 official workflow IDs.

    Hardcoded for v1 — filesystem enumeration is deferred to a future version
    once the workflow library grows beyond the three initial entries.

    Returns:
        Ordered list of workflow ID strings.
    """
    return list(_OFFICIAL_WORKFLOW_IDS)


# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------

def load_workflow_spec(workflow_id: str) -> WorkflowSpec:
    """Load and validate a :class:`WorkflowSpec` from its YAML manifest.

    Resolves the path as::

        <repo_root>/adapters/workflows/<workflow_id>/workflow.yaml

    This is the **source-tree path** — it requires PyYAML and the
    ``adapters/workflows/`` directory.  For wheel-installed usage, callers
    should prefer :func:`load_workflow_manifest` which loads from precompiled
    JSON and has no PyYAML dependency.

    Args:
        workflow_id: Stable kebab-case identifier, e.g.
            ``"morning-operator-brief"``.  Validated against the same
            ``^[a-z0-9][a-z0-9_-]{0,62}$`` regex used by the bootstrap
            install path — invalid IDs raise :exc:`ValueError` before any
            filesystem access.

    Returns:
        A validated :class:`WorkflowSpec` instance.

    Raises:
        ValueError: if *workflow_id* does not match the allowlist regex.
        FileNotFoundError: if no ``workflow.yaml`` exists at the resolved
            path.
        ValueError: if the YAML content fails ``WorkflowSpec.model_validate``
            (``extra="forbid"`` is enforced — unknown fields are an error).
        ImportError: if ``PyYAML`` is not installed (not in wheel deps — use
            :func:`load_workflow_manifest` instead in wheel context).
    """
    # Validate ID first — prevents path traversal before any filesystem call.
    _validate_workflow_id(workflow_id)

    yaml_path = _repo_root() / "adapters" / "workflows" / workflow_id / "workflow.yaml"

    if not yaml_path.exists():
        raise FileNotFoundError(
            f"No workflow.yaml found for workflow_id={workflow_id!r}. "
            f"Expected path: {yaml_path}"
        )

    # Lazy import — PyYAML is not in wheel deps; this path is repo-only.
    try:
        import yaml  # type: ignore[import]
    except ImportError as exc:
        raise ImportError(
            "PyYAML is required to load YAML workflow specs but is not "
            "installed. In a wheel context, use load_workflow_manifest() "
            "instead (loads precompiled JSON)."
        ) from exc

    raw_text = yaml_path.read_text(encoding="utf-8")
    data = yaml.safe_load(raw_text)

    if not isinstance(data, dict):
        raise ValueError(
            f"workflow.yaml for {workflow_id!r} must be a YAML mapping; "
            f"got {type(data).__name__}"
        )

    try:
        spec = WorkflowSpec.model_validate(data)
    except Exception as exc:
        raise ValueError(
            f"WorkflowSpec validation failed for workflow_id={workflow_id!r}: {exc}"
        ) from exc

    # §2.3 — enforce late-bound frontmatter invariants at load time.
    from selph_mcp.contracts.late_bound import validate_late_bound
    try:
        validate_late_bound(spec)
    except ValueError as exc:
        raise ValueError(
            f"Late-bound validation failed for workflow_id={workflow_id!r}: {exc}"
        ) from exc

    return spec


# ---------------------------------------------------------------------------
# Manifest builder
# ---------------------------------------------------------------------------

def build_manifest(spec: WorkflowSpec) -> WorkflowManifest:
    """Adapt a :class:`WorkflowSpec` into a :class:`WorkflowManifest`.

    Produces a concise markdown body suitable for writing to
    ``.claude/skills/<workflow_id>/SKILL.md`` during bootstrap installation.
    The rendered content covers purpose, approval model, retrieval policy,
    write permissions, expected outputs, and minimum graph requirements —
    enough for the harness to understand the workflow contract without
    needing to re-fetch the full YAML.

    No LLM is involved — template rendering only.

    Args:
        spec: A validated :class:`WorkflowSpec` to render.

    Returns:
        A :class:`WorkflowManifest` with ``workflow_id``, ``version="1.0.0"``,
        and a rendered ``body_md``.
    """
    lines: List[str] = []

    # ── Header ───────────────────────────────────────────────────────────────
    lines.append(f"# Workflow: {spec.workflow_id}")
    lines.append("")
    lines.append(f"**Purpose:** {spec.purpose}")
    lines.append("")

    if spec.description:
        lines.append("## Description")
        lines.append("")
        lines.append(spec.description.strip())
        lines.append("")

    # ── Governance ───────────────────────────────────────────────────────────
    lines.append("## Governance")
    lines.append("")
    lines.append(f"- **Trust tier:** `{spec.trust_tier.value}`")
    lines.append(f"- **Approval model:** `{spec.approval_model.value}`")
    if spec.allowed_harnesses:
        lines.append(
            f"- **Allowed harnesses:** {', '.join(f'`{h}`' for h in spec.allowed_harnesses)}"
        )
    if spec.required_connectors:
        lines.append(
            f"- **Required connectors:** {', '.join(f'`{c}`' for c in spec.required_connectors)}"
        )
    else:
        lines.append("- **Required connectors:** none (Selph-only)")
    lines.append("")

    # ── Retrieval policy ─────────────────────────────────────────────────────
    policy = spec.selph_retrieval_policy
    lines.append("## Retrieval Policy")
    lines.append("")
    lines.append(f"- **Default depth:** `{policy.default_depth.value}`")
    if policy.preferred_subjects:
        lines.append(
            f"- **Preferred subjects:** {', '.join(f'`{s.value}`' for s in policy.preferred_subjects)}"
        )
    if policy.preferred_intents:
        lines.append(
            f"- **Preferred intents:** {', '.join(f'`{i.value}`' for i in policy.preferred_intents)}"
        )
    lines.append(
        f"- **Evidence mode:** {'enabled' if policy.use_evidence_mode else 'disabled'}"
    )
    if policy.notes:
        lines.append("")
        lines.append(policy.notes.strip())
    lines.append("")

    # ── Write permissions ─────────────────────────────────────────────────────
    wp = spec.write_permissions
    lines.append("## Write Permissions")
    lines.append("")
    lines.append(f"- **Scope:** `{wp.scope.value}`")
    if wp.correction_targets:
        lines.append(
            f"- **Correction targets:** {', '.join(f'`{t.value}`' for t in wp.correction_targets)}"
        )
    lines.append("")

    # ── Minimum graph requirements ────────────────────────────────────────────
    if spec.minimum_graph_requirements:
        lines.append("## Minimum Graph Requirements")
        lines.append("")
        for req in spec.minimum_graph_requirements:
            desc = f" — {req.description}" if req.description else ""
            lines.append(
                f"- `{req.signal}` (min count: {req.minimum_count}){desc}"
            )
        lines.append("")

    # ── Expected outputs ─────────────────────────────────────────────────────
    if spec.expected_outputs:
        lines.append("## Expected Outputs")
        lines.append("")
        for out in spec.expected_outputs:
            sample = f" (sample: `{out.sample_path}`)" if out.sample_path else ""
            lines.append(f"- **{out.name}**: {out.description}{sample}")
        lines.append("")

    # ── Cache policy ─────────────────────────────────────────────────────────
    cp = spec.cache_policy
    lines.append("## Cache Policy")
    lines.append("")
    lines.append(f"- **TTL:** `{cp.ttl.value}`")
    lines.append(
        f"- **Revalidate on etag change:** {'yes' if cp.revalidate_on_etag_change else 'no'}"
    )
    lines.append(
        f"- **Purge on revocation:** {'yes' if cp.purge_on_revocation else 'no'}"
    )
    if cp.notes:
        lines.append("")
        lines.append(cp.notes.strip())
    lines.append("")

    body_md = "\n".join(lines)

    return WorkflowManifest(
        workflow_id=spec.workflow_id,
        version="1.0.0",
        body_md=body_md,
    )


__all__ = [
    "load_workflow_spec",
    "load_workflow_manifest",
    "list_official_workflow_ids",
    "build_manifest",
]
