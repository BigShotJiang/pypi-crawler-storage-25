"""LLM-based topical hub classifier for persona insight reads.

The deterministic keyword classifier in
:func:`selph_core.query.service._classify_query_domains` misroutes
common phrases — e.g. "who do I talk to a lot" matches ``talk`` → voice
domain, but the user's intent is a relationship question. This module
runs a single ``gpt-4.1-mini`` structured call to pick a topical
hub_type from the question text directly, mirroring the
``_route_query`` pattern already used for QUICK/MEDIUM/DEEP routing.

The result is best-effort: a misroute is recoverable because
:func:`selph_mcp.persona.tools.get_context._dispatch._dispatch_insight`
also loads the subject's primary hub. A None return falls through to
the subject hub alone — same behavior as before topical hubs existed.
"""

from __future__ import annotations

import logging
from typing import Literal, Optional

from pydantic import BaseModel

from selph_shared.llm.client import get_llm_client, run_agent_logged
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.persona.hub_classifier")


# Hub types the classifier may pick. Mirrors the active hub set per
# rules/hubs.md plus ``none`` for "no clear topical fit." Internal-only —
# never exposed on a caller-facing surface (rules/api-surface.md).
HubChoice = Literal[
    "current_identity",
    "relationship_priority",
    "voice_style",
    "narrative_identity",
    "temporal",
    "recent_change",
    "pursuit",
    "project",
    "social",
    "emotional",
    "spiritual",
    "tension",
    "learning_dynamics",
    "assistance",
    "capability",
    "preference_domain",
    "identity",
    "relationship",
    "domain",
    "none",
]


class _HubClassifierOutput(BaseModel):
    hub: HubChoice
    reason: str


_HUB_CLASSIFIER_SYSTEM_PROMPT = """\
You are a topical-hub classifier for a personal knowledge graph. Given a
user's natural-language question, pick ONE hub type that's most likely to
contain the answer. Pick "none" only when no single hub is a clear fit
(e.g. the question is too vague or spans many hubs).

Hub types and what they answer:

- current_identity   — generic "who am I" overview: roles, traits, goals,
  high-level priorities. Use for personality / self-description questions.
- relationship_priority — WHO matters: people the user talks to, friends,
  family, partner, contacts, social circle. Use this for "who do I talk
  to / message / communicate with" — these are relationship questions
  even though they mention "talk".
- voice_style        — HOW the user talks/writes/phrases things — TONE,
  word choice, style. Not WHO. "How do I write" / "what's my tone."
- narrative_identity — recurring patterns, internal stories, scripts,
  "why do I always…" / "what's my pattern around…"
- temporal           — time-bounded changes, "lately", "recently",
  "this year", "over time", "compared to last year."
- recent_change      — very recent identity / relationship / role shifts.
- pursuit            — open-ended directional efforts, "what am I moving
  toward", goals without clear finish lines.
- project            — concrete time-bounded work, "what am I building",
  active projects with milestones.
- social             — broader social engagement: creators followed,
  communities, content patterns. Not 1:1 relationship priority.
- emotional          — emotional state and triggers.
- spiritual          — values, beliefs, meaning, faith, philosophy. Pick
  this (NOT current_identity) for explicit value / belief / meaning
  questions like "what do I believe" / "what are my values".
- tension            — internal contradictions, recurring conflicts.
- learning_dynamics  — how the user learns, growth edges, friction.
- assistance         — what the user delegates to AI, assistance patterns.
- capability         — skills, tools the user can execute with.
- preference_domain  — explicit likes/dislikes/requirements (food, media,
  environment, communication, activity).
- domain             — focused topical interest area (e.g. a hobby, a
  field of work) when the question is scoped to a single domain.
- identity / relationship — broader fallbacks for "who am I" / "how do
  my relationships look" when the more specific hubs above don't fit.

Examples:
- "who do I talk to a lot" → relationship_priority
- "name people I communicate with" → relationship_priority
- "how do I write" → voice_style
- "describe my personality" → current_identity
- "what do I believe" → spiritual
- "what are my values" → spiritual
- "what am I working on" → project
- "what am I trying to become" → pursuit
- "what's my pattern around conflict" → narrative_identity
- "what's changed recently" → recent_change
- "what's my expertise in cooking" → domain

Return ``hub`` (one type) and a one-sentence ``reason``.
"""


async def classify_question_to_hub(question: str) -> Optional[str]:
    """Pick a topical hub_type for ``question`` via gpt-4.1-mini.

    Args:
        question: Raw user question text. Empty / blank → ``None``.

    Returns:
        The hub_type string (e.g. ``"relationship_priority"``) or
        ``None`` when the LLM picks ``"none"`` or the call fails.
        Callers fall back to the subject hub alone in that case.
    """
    if not question or not question.strip():
        return None

    llm = get_llm_client()
    agent = llm.agent(
        _HubClassifierOutput,
        name="persona_hub_classifier",
        system_prompt=_HUB_CLASSIFIER_SYSTEM_PROMPT,
        override_model="gpt-4.1-mini",
        max_output_tokens=80,
    )
    try:
        result = await run_agent_logged(
            agent, question.strip(), logger=_log
        )
    except Exception as exc:  # noqa: BLE001 — soft-fail to keyword-free path
        log_event(
            _log,
            logging.WARNING,
            "mcp.persona.hub_classifier.failed",
            question_len=len(question),
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        return None

    choice = result.output.hub
    if choice == "none":
        log_event(
            _log,
            logging.INFO,
            "mcp.persona.hub_classifier.no_topical_fit",
            question_len=len(question),
            reason=str(result.output.reason)[:200],
        )
        return None

    log_event(
        _log,
        logging.INFO,
        "mcp.persona.hub_classifier.routed",
        question_len=len(question),
        hub=choice,
        reason=str(result.output.reason)[:200],
    )
    return choice


__all__ = ["classify_question_to_hub", "HubChoice"]
