import sys
from pathlib import Path
from .extract import get_css, export_all, find_notebooks, export_one
from .lint import lint_project, find_root, lint_file
from .output import print_summary, write_log
from .types import Report
from .minify import minify

USAGE = '      css — extract and lint CSS from marimo notebooks\n \n      usage: css <command> [options]\n \n      commands:\n        extract   extract CSS from notebooks into .css files\n        lint      lint standalone .css files\n        check     extract → lint → cleanup (single pipeline)\n \n      run css <command> --help for command-specific options\n    '
HELP_EXTRACT = '      css extract [target] [out_dir] [flags]\n \n      Extract CSS from notebooks into .css files.\n \n      positional arguments:\n        target      a single .py notebook or a directory of them  (default: ./notebooks)\n        out_dir     where to write .css files                     (default: same as input)\n \n      flags:\n        --min       minify output (strip comments & whitespace)\n        --brotli    also emit .css.br brotli-compressed files\n \n      examples:\n        css extract\n        css extract app.py\n        css extract app.py ./static\n        css extract ./notebooks ./static --min --brotli\n    '
HELP_LINT = '      css lint [file.css]\n \n      Lint CSS files for common issues.\n \n      positional arguments:\n        file.css    lint a single .css file\n                    if omitted, lints every .css file under the project root\n                    (project root is detected by walking up to pyproject.toml)\n \n      output:\n        writes css_lint.log and prints a summary to stdout\n        exits 1 if any errors are found\n \n      examples:\n        css lint\n        css lint src/styles/theme.css\n    '
HELP_CHECK = '      css check [directory]\n \n      All-in-one: extract CSS from notebooks, lint it, then clean up temp files.\n \n      positional arguments:\n        directory   folder containing notebooks  (default: ./notebooks)\n \n      output:\n        writes css_lint.log and prints a summary to stdout\n        exits 1 if any errors are found\n \n      examples:\n        css check\n        css check ./src/notebooks\n    '
COMMAND_HELP = {'extract': HELP_EXTRACT, 'lint': HELP_LINT, 'check': HELP_CHECK}

def lint_notebook(notebook_path: str) -> Report:
    """Extract CSS from a marimo notebook and lint it."""
    css = get_css(notebook_path)
    # write to temp file so lint_file can reference it
    tmp = Path(notebook_path).with_suffix(".css")
    tmp.write_text(css)
    report = Report()
    lint_file(tmp, report, tmp.parent)
    tmp.unlink()
    return report

def cmd_extract(args: list[str]):
    flags = {"--min", "--brotli"}
    do_min = "--min" in args
    do_brotli = "--brotli" in args
    rest = [a for a in args if a not in flags]
 
    target = rest[0] if rest else "./notebooks"
    out_dir = rest[1] if len(rest) > 1 else None
    _out = Path(out_dir) if out_dir else None
 
    if Path(target).is_file():
        paths = [export_one(Path(target), _out)]
    else:
        paths = export_all(target, out_dir)
 
    if do_min:
        from .minify import minify
        for p in paths:
            p.write_text(minify(p.read_text()))
 
    br_paths = []
    if do_brotli:
        from .minify import compress_brotli
        br_paths = [compress_brotli(p) for p in paths]
 
    for p in paths:
        sz = f"{p.stat().st_size / 1024:.1f}kB"
        print(f"  {p} ({sz})")
    for p in br_paths:
        sz = f"{p.stat().st_size / 1024:.1f}kB"
        print(f"  {p} ({sz})")
 
    suffixes = []
    if do_min: suffixes.append("minified")
    if do_brotli: suffixes.append("brotli")
    tag = f" ({', '.join(suffixes)})" if suffixes else ""
    total = len(paths) + len(br_paths)
    print(f"\n  {total} file{'s' * (total != 1)} extracted{tag}")

def cmd_lint(args: list[str]):
    if args and args[0].endswith(".css"):
        report = Report()
        p = Path(args[0])
        lint_file(p, report, p.parent)
    else:
        root = find_root()
        report = lint_project(root)
 
    log_path = Path("css_lint.log")
    write_log(report, log_path)
    print_summary(report, log_path)
    sys.exit(1 if report.errors else 0)

def cmd_check(args: list[str]):
    directory = args[0] if args else "./notebooks"
    notebooks = find_notebooks(directory)
 
    if not notebooks:
        print(f"  no notebooks found in {directory}")
        sys.exit(1)
 
    report = Report()
    tmp_files = []
 
    for nb in notebooks:
        css = get_css(str(nb))
        tmp = Path(f".tmp_{nb.stem}.css")
        tmp.write_text(css)
        tmp_files.append(tmp)
        lint_file(tmp, report, tmp.parent)
 
    for tmp in tmp_files:
        tmp.unlink()
 
    log_path = Path("css_lint.log")
    write_log(report, log_path)
    print_summary(report, log_path)
    sys.exit(1 if report.errors else 0)

def main():
    from . import __version__
 
    args = sys.argv[1:]
 
    if not args or args[0] in ("-h", "--help"):
        print(USAGE)
        sys.exit(0)
 
    if args[0] in ("-v", "--version"):
        print(f"  css {__version__}")
        sys.exit(0)
 
    cmd, rest = args[0], args[1:]
 
    commands = {
        "extract": cmd_extract,
        "lint": cmd_lint,
        "check": cmd_check,
    }
 
    if cmd not in commands:
        print(f"  unknown command: {cmd}")
        print(f"  available: {', '.join(commands)}\n")
        print(USAGE)
        sys.exit(1)
 
    if rest and rest[0] in ("-h", "--help"):
        print(COMMAND_HELP[cmd])
        sys.exit(0)
 
    commands[cmd](rest)
