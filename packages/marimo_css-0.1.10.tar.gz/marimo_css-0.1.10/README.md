# marimo-css
![PyPI version](https://img.shields.io/pypi/v/marimo-css)


> [!WARNING]
> This side-project is under active development and is not an official marimo tool - May 2026  

```bash
# Write CSS in Marimo  
css extract app.py              # single notebook
css extract app.py ./static     # single notebook → specific output dir
css extract ./notebooks         # whole directory
css extract [dir,file] [out]    # notebooks → .css   (default: ./notebooks)
# options
css extract --min               # minified
css extract --min --brotli      # minified + .css.br

# below not recomended to use (not general)
css lint                       # lint all .css in project
css lint style.css             # lint one file

css check [dir]                # extract → lint → cleanup
```