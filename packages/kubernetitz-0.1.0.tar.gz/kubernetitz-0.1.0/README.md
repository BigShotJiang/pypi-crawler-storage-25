# kubernetitz

Mock Kubernetes orchestration with Linear issue tracking integration.

Simulate clusters, deployments, and pod failures — and automatically route cluster events to Linear issues.

## Installation

```bash
pip install kubernetitz
```

## Quick Start

```python
from kubernetitz import Cluster, Deployment, LinearBridge

# Create a cluster
cluster = Cluster("production")
cluster.create_namespace("backend")

# Attach Linear integration (mock mode)
bridge = LinearBridge(team="ENG", mock=True)
cluster.attach(bridge)

# Deploy something
dep = Deployment("api", image="myapp:v2", replicas=3)
for event in cluster.deploy("backend", dep):
    print(event)

# Simulate a pod failure — automatically creates a Linear issue
for event in cluster.simulate_failure("backend", "api"):
    print(event)

print(bridge.list_issues())
```
