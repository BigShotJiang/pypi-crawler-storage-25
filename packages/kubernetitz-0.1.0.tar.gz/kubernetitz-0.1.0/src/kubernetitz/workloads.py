"""
Workload primitives: Pod, Deployment.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
import random


class PodStatus(Enum):
    PENDING = "Pending"
    RUNNING = "Running"
    FAILED = "Failed"
    SUCCEEDED = "Succeeded"
    CRASHLOOP = "CrashLoopBackOff"
    UNKNOWN = "Unknown"


class DeploymentStatus(Enum):
    PROGRESSING = "Progressing"
    AVAILABLE = "Available"
    DEGRADED = "Degraded"
    FAILED = "Failed"


@dataclass
class Pod:
    name: str
    image: str
    namespace: str = "default"
    status: PodStatus = PodStatus.PENDING
    restarts: int = 0
    _logs: list[str] = field(default_factory=list)

    def start(self) -> str:
        self.status = PodStatus.RUNNING
        self._logs.append(f"[{self.name}] Started container {self.image}")
        return f"pod/{self.name} started"

    def fail(self, reason: str = "OOMKilled") -> str:
        self.status = PodStatus.FAILED
        self.restarts += 1
        self._logs.append(f"[{self.name}] Container failed: {reason}")
        if self.restarts >= 3:
            self.status = PodStatus.CRASHLOOP
        return f"pod/{self.name} failed ({reason}) — restarts: {self.restarts}"

    def logs(self) -> str:
        return "\n".join(self._logs) if self._logs else f"[{self.name}] No logs."

    def describe(self) -> str:
        lines = [
            f"Name:      {self.name}",
            f"Namespace: {self.namespace}",
            f"Image:     {self.image}",
            f"Status:    {self.status.value}",
            f"Restarts:  {self.restarts}",
        ]
        return "\n".join(lines)

    def is_healthy(self) -> bool:
        return self.status == PodStatus.RUNNING


@dataclass
class Deployment:
    name: str
    image: str
    namespace: str = "default"
    replicas: int = 1
    status: DeploymentStatus = DeploymentStatus.PROGRESSING
    pods: list[Pod] = field(default_factory=list)

    def roll_out(self) -> list[str]:
        """Spin up pods to match desired replica count."""
        events = []
        while len(self.pods) < self.replicas:
            idx = len(self.pods) + 1
            pod = Pod(
                name=f"{self.name}-{idx}",
                image=self.image,
                namespace=self.namespace,
            )
            self.pods.append(pod)
            events.append(pod.start())

        self.status = DeploymentStatus.AVAILABLE
        events.append(
            f"deployment/{self.name} available — {self.replicas}/{self.replicas} replicas ready"
        )
        return events

    def scale(self, replicas: int) -> list[str]:
        """Scale up or down."""
        events = []
        prev = self.replicas
        self.replicas = replicas

        if replicas > len(self.pods):
            events += self.roll_out()
        elif replicas < len(self.pods):
            removed = self.pods[replicas:]
            self.pods = self.pods[:replicas]
            for p in removed:
                p.status = PodStatus.SUCCEEDED
                events.append(f"pod/{p.name} terminated")

        events.append(f"deployment/{self.name} scaled {prev} → {replicas}")
        return events

    def simulate_failure(self, reason: str = "OOMKilled") -> list[str]:
        """Randomly fail one running pod."""
        running = [p for p in self.pods if p.is_healthy()]
        if not running:
            return [f"deployment/{self.name} — no running pods to fail"]
        pod = random.choice(running)
        events = [pod.fail(reason)]
        healthy = sum(1 for p in self.pods if p.is_healthy())
        if healthy < self.replicas:
            self.status = DeploymentStatus.DEGRADED
            events.append(
                f"deployment/{self.name} degraded — {healthy}/{self.replicas} replicas ready"
            )
        return events

    def healthy_pods(self) -> int:
        return sum(1 for p in self.pods if p.is_healthy())

    def describe(self) -> str:
        lines = [
            f"Name:       {self.name}",
            f"Namespace:  {self.namespace}",
            f"Image:      {self.image}",
            f"Replicas:   {self.healthy_pods()}/{self.replicas} ready",
            f"Status:     {self.status.value}",
        ]
        return "\n".join(lines)
