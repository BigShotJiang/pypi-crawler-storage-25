"""
Kubernetitz — mock Kubernetes orchestration with Linear integration.

Simulate clusters, deployments, and pod failures.
Route cluster events to Linear issues automatically.
"""

__version__ = "0.1.0"

from .workloads import Pod, Deployment, PodStatus, DeploymentStatus
from .cluster import Cluster, Namespace, Event
from .linear_bridge import LinearBridge, MockIssue
