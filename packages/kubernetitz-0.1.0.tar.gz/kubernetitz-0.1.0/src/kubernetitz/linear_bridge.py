"""
LinearBridge — connects cluster events to Linear issues.

Can run in mock mode (default) or live mode using the Linear API.

Mock mode logs all actions locally.
Live mode requires a Linear API key and team ID.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from .workloads import Pod, Deployment


@dataclass
class MockIssue:
    id: str
    title: str
    description: str
    priority: str   # "urgent" | "high" | "medium" | "low"
    status: str = "Todo"
    comments: list[str] = field(default_factory=list)

    def __str__(self) -> str:
        return f"[{self.id}] [{self.priority.upper()}] {self.title} — {self.status}"


class LinearBridge:
    """
    Listens to Cluster events and creates/updates Linear issues.

    In mock mode (default), issues are stored in memory and printed.
    In live mode, issues are created via the Linear API.

    Example:
        bridge = LinearBridge(team="ENG", mock=True)
        cluster.attach(bridge)

        # Now any pod failure or deployment event creates a Linear issue.
        cluster.simulate_failure("backend", "api")
        bridge.list_issues()
    """

    def __init__(self, team: str, api_key: str | None = None, mock: bool = True):
        self.team = team
        self.api_key = api_key
        self.mock = mock or api_key is None
        self._issues: list[MockIssue] = []
        self._counter = 1

    # --- Event handlers (called by Cluster) ---

    def on_pod_failure(self, pod: Pod, reason: str) -> MockIssue | dict:
        title = f"Pod {pod.name} failed: {reason}"
        description = (
            f"**Pod:** `{pod.name}`\n"
            f"**Namespace:** `{pod.namespace}`\n"
            f"**Image:** `{pod.image}`\n"
            f"**Reason:** {reason}\n"
            f"**Restarts:** {pod.restarts}\n\n"
            f"**Logs:**\n```\n{pod.logs()}\n```"
        )
        priority = "urgent" if pod.restarts >= 3 else "high"
        return self._create_issue(title, description, priority)

    def on_deploy(self, deployment: Deployment) -> MockIssue | dict:
        title = f"Deployment {deployment.name} rolled out"
        description = (
            f"**Deployment:** `{deployment.name}`\n"
            f"**Namespace:** `{deployment.namespace}`\n"
            f"**Image:** `{deployment.image}`\n"
            f"**Replicas:** {deployment.replicas}\n"
            f"**Status:** {deployment.status.value}"
        )
        return self._create_issue(title, description, priority="low", status="Done")

    def on_scale(self, deployment: Deployment, replicas: int) -> MockIssue | dict:
        title = f"Deployment {deployment.name} scaled to {replicas}"
        description = (
            f"**Deployment:** `{deployment.name}`\n"
            f"**New replica count:** {replicas}\n"
            f"**Status:** {deployment.status.value}"
        )
        return self._create_issue(title, description, priority="medium")

    def add_comment(self, issue_id: str, comment: str) -> str:
        issue = next((i for i in self._issues if i.id == issue_id), None)
        if not issue:
            return f"Issue {issue_id} not found"
        issue.comments.append(comment)
        if self.mock:
            print(f"  [Linear mock] Comment on {issue_id}: {comment}")
        return f"Comment added to {issue_id}"

    def resolve(self, issue_id: str) -> str:
        issue = next((i for i in self._issues if i.id == issue_id), None)
        if not issue:
            return f"Issue {issue_id} not found"
        issue.status = "Done"
        if self.mock:
            print(f"  [Linear mock] Resolved {issue_id}: {issue.title}")
        return f"{issue_id} resolved"

    def list_issues(self) -> str:
        if not self._issues:
            return "No issues. Ship is running smoothly."
        return "\n".join(str(i) for i in self._issues)

    def open_issues(self) -> list[MockIssue]:
        return [i for i in self._issues if i.status != "Done"]

    # --- Internal ---

    def _create_issue(
        self, title: str, description: str, priority: str, status: str = "Todo"
    ) -> MockIssue | dict:
        if self.mock:
            return self._mock_create(title, description, priority, status)
        return self._live_create(title, description, priority, status)

    def _mock_create(
        self, title: str, description: str, priority: str, status: str
    ) -> MockIssue:
        issue_id = f"{self.team}-{self._counter}"
        self._counter += 1
        issue = MockIssue(
            id=issue_id,
            title=title,
            description=description,
            priority=priority,
            status=status,
        )
        self._issues.append(issue)
        print(f"  [Linear mock] Created {issue}")
        return issue

    def _live_create(
        self, title: str, description: str, priority: str, status: str
    ) -> dict:
        """
        Create a real Linear issue via the API.
        Requires `pip install requests` and a valid api_key.
        """
        try:
            import requests
        except ImportError:
            raise RuntimeError("Install 'requests' to use live Linear integration.")

        priority_map = {"urgent": 1, "high": 2, "medium": 3, "low": 4}
        mutation = """
        mutation CreateIssue($title: String!, $description: String!, $teamId: String!, $priority: Int!) {
            issueCreate(input: {
                title: $title,
                description: $description,
                teamId: $teamId,
                priority: $priority
            }) {
                success
                issue { id identifier title url }
            }
        }
        """
        resp = requests.post(
            "https://api.linear.app/graphql",
            headers={
                "Authorization": self.api_key,
                "Content-Type": "application/json",
            },
            json={
                "query": mutation,
                "variables": {
                    "title": title,
                    "description": description,
                    "teamId": self.team,
                    "priority": priority_map.get(priority, 3),
                },
            },
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()
        issue = data["data"]["issueCreate"]["issue"]
        print(f"  [Linear live] Created {issue['identifier']}: {issue['url']}")
        return issue
