"""
Cluster and Namespace — top-level orchestration primitives.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from .workloads import Deployment, Pod


@dataclass
class Event:
    kind: str       # "Warning" | "Normal"
    reason: str
    message: str
    source: str

    def __str__(self) -> str:
        return f"[{self.kind}] {self.source} — {self.reason}: {self.message}"


@dataclass
class Namespace:
    name: str
    deployments: list[Deployment] = field(default_factory=list)

    def add_deployment(self, deployment: Deployment) -> str:
        deployment.namespace = self.name
        self.deployments.append(deployment)
        return f"deployment/{deployment.name} created in namespace/{self.name}"

    def get_deployment(self, name: str) -> Deployment | None:
        return next((d for d in self.deployments if d.name == name), None)

    def all_pods(self) -> list[Pod]:
        return [p for d in self.deployments for p in d.pods]

    def get_pod(self, name: str) -> Pod | None:
        return next((p for p in self.all_pods() if p.name == name), None)

    def status(self) -> str:
        total_pods = len(self.all_pods())
        healthy = sum(1 for p in self.all_pods() if p.is_healthy())
        return f"namespace/{self.name} — {len(self.deployments)} deployments, {healthy}/{total_pods} pods running"


class Cluster:
    """
    A mock Kubernetes cluster.

    Manages namespaces, deployments, and emits events that can be
    forwarded to Linear via LinearBridge.

    Example:
        cluster = Cluster("production")
        cluster.create_namespace("backend")
        cluster.deploy("backend", Deployment("api", image="api:v2", replicas=3))
    """

    def __init__(self, name: str):
        self.name = name
        self.namespaces: dict[str, Namespace] = {
            "default": Namespace("default")
        }
        self.events: list[Event] = []
        self._listeners: list = []   # LinearBridge hooks

    def create_namespace(self, name: str) -> str:
        if name in self.namespaces:
            return f"namespace/{name} already exists"
        self.namespaces[name] = Namespace(name)
        return f"namespace/{name} created"

    def deploy(self, namespace: str, deployment: Deployment) -> list[str]:
        ns = self.namespaces.get(namespace)
        if not ns:
            return [f"Error: namespace/{namespace} not found"]
        msg = ns.add_deployment(deployment)
        roll_events = deployment.roll_out()
        all_events = [msg] + roll_events
        self._emit(Event("Normal", "Scheduled", msg, f"deployment/{deployment.name}"))
        for listener in self._listeners:
            listener.on_deploy(deployment)
        return all_events

    def scale(self, namespace: str, deployment_name: str, replicas: int) -> list[str]:
        dep = self._get_deployment(namespace, deployment_name)
        if not dep:
            return [f"Error: deployment/{deployment_name} not found in namespace/{namespace}"]
        events = dep.scale(replicas)
        self._emit(Event("Normal", "Scaled", f"{deployment_name} scaled to {replicas}", f"deployment/{deployment_name}"))
        for listener in self._listeners:
            listener.on_scale(dep, replicas)
        return events

    def simulate_failure(self, namespace: str, deployment_name: str, reason: str = "OOMKilled") -> list[str]:
        dep = self._get_deployment(namespace, deployment_name)
        if not dep:
            return [f"Error: deployment/{deployment_name} not found"]
        events = dep.simulate_failure(reason)
        failed_pods = [p for p in dep.pods if not p.is_healthy()]
        for pod in failed_pods:
            self._emit(Event("Warning", "BackOff", f"{pod.name} failed: {reason}", f"pod/{pod.name}"))
            for listener in self._listeners:
                listener.on_pod_failure(pod, reason)
        return events

    def get_events(self, kind: str | None = None) -> list[Event]:
        if kind:
            return [e for e in self.events if e.kind == kind]
        return self.events

    def attach(self, bridge) -> None:
        """Attach a LinearBridge to receive cluster events."""
        self._listeners.append(bridge)

    def status(self) -> str:
        lines = [f"=== Cluster: {self.name} ==="]
        for ns in self.namespaces.values():
            lines.append(f"  {ns.status()}")
            for dep in ns.deployments:
                lines.append(f"    deployment/{dep.name} — {dep.status.value} ({dep.healthy_pods()}/{dep.replicas})")
        return "\n".join(lines)

    def _get_deployment(self, namespace: str, name: str) -> Deployment | None:
        ns = self.namespaces.get(namespace)
        return ns.get_deployment(name) if ns else None

    def _emit(self, event: Event) -> None:
        self.events.append(event)
