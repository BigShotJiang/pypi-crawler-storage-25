# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_dms_enterprise20181101 import models as main_models
from darabonba.model import DaraModel

class GetAuthorityTemplateResponseBody(DaraModel):
    def __init__(
        self,
        authority_template_view: main_models.GetAuthorityTemplateResponseBodyAuthorityTemplateView = None,
        error_code: str = None,
        error_message: str = None,
        request_id: str = None,
        success: bool = None,
        tid: int = None,
    ):
        # The details of the permission template.
        self.authority_template_view = authority_template_view
        # The error code returned if the request failed.
        self.error_code = error_code
        # The error message returned if the request failed.
        self.error_message = error_message
        # The ID of the request.
        self.request_id = request_id
        # Indicates whether the request was successful. Valid values:
        # 
        # *   **true**: The request was successful.
        # *   **false**: The request failed.
        self.success = success
        # The ID of the tenant.
        self.tid = tid

    def validate(self):
        if self.authority_template_view:
            self.authority_template_view.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.authority_template_view is not None:
            result['AuthorityTemplateView'] = self.authority_template_view.to_map()

        if self.error_code is not None:
            result['ErrorCode'] = self.error_code

        if self.error_message is not None:
            result['ErrorMessage'] = self.error_message

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        if self.success is not None:
            result['Success'] = self.success

        if self.tid is not None:
            result['Tid'] = self.tid

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AuthorityTemplateView') is not None:
            temp_model = main_models.GetAuthorityTemplateResponseBodyAuthorityTemplateView()
            self.authority_template_view = temp_model.from_map(m.get('AuthorityTemplateView'))

        if m.get('ErrorCode') is not None:
            self.error_code = m.get('ErrorCode')

        if m.get('ErrorMessage') is not None:
            self.error_message = m.get('ErrorMessage')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        if m.get('Success') is not None:
            self.success = m.get('Success')

        if m.get('Tid') is not None:
            self.tid = m.get('Tid')

        return self

class GetAuthorityTemplateResponseBodyAuthorityTemplateView(DaraModel):
    def __init__(
        self,
        authority_template_item_list: main_models.GetAuthorityTemplateResponseBodyAuthorityTemplateViewAuthorityTemplateItemList = None,
        create_time: str = None,
        creator_id: int = None,
        description: str = None,
        name: str = None,
        template_id: int = None,
    ):
        self.authority_template_item_list = authority_template_item_list
        # The time when the permission template was created. The time is in the yyyy-MM-DD HH:mm:ss format.
        self.create_time = create_time
        # The ID of the user who created the permission template.
        self.creator_id = creator_id
        # The description of the permission template.
        self.description = description
        # The name of the permission template.
        self.name = name
        # The ID of the permission template.
        self.template_id = template_id

    def validate(self):
        if self.authority_template_item_list:
            self.authority_template_item_list.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.authority_template_item_list is not None:
            result['AuthorityTemplateItemList'] = self.authority_template_item_list.to_map()

        if self.create_time is not None:
            result['CreateTime'] = self.create_time

        if self.creator_id is not None:
            result['CreatorId'] = self.creator_id

        if self.description is not None:
            result['Description'] = self.description

        if self.name is not None:
            result['Name'] = self.name

        if self.template_id is not None:
            result['TemplateId'] = self.template_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AuthorityTemplateItemList') is not None:
            temp_model = main_models.GetAuthorityTemplateResponseBodyAuthorityTemplateViewAuthorityTemplateItemList()
            self.authority_template_item_list = temp_model.from_map(m.get('AuthorityTemplateItemList'))

        if m.get('CreateTime') is not None:
            self.create_time = m.get('CreateTime')

        if m.get('CreatorId') is not None:
            self.creator_id = m.get('CreatorId')

        if m.get('Description') is not None:
            self.description = m.get('Description')

        if m.get('Name') is not None:
            self.name = m.get('Name')

        if m.get('TemplateId') is not None:
            self.template_id = m.get('TemplateId')

        return self

class GetAuthorityTemplateResponseBodyAuthorityTemplateViewAuthorityTemplateItemList(DaraModel):
    def __init__(
        self,
        authority_template_item: List[main_models.GetAuthorityTemplateResponseBodyAuthorityTemplateViewAuthorityTemplateItemListAuthorityTemplateItem] = None,
    ):
        self.authority_template_item = authority_template_item

    def validate(self):
        if self.authority_template_item:
            for v1 in self.authority_template_item:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['AuthorityTemplateItem'] = []
        if self.authority_template_item is not None:
            for k1 in self.authority_template_item:
                result['AuthorityTemplateItem'].append(k1.to_map() if k1 else None)

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.authority_template_item = []
        if m.get('AuthorityTemplateItem') is not None:
            for k1 in m.get('AuthorityTemplateItem'):
                temp_model = main_models.GetAuthorityTemplateResponseBodyAuthorityTemplateViewAuthorityTemplateItemListAuthorityTemplateItem()
                self.authority_template_item.append(temp_model.from_map(k1))

        return self

class GetAuthorityTemplateResponseBodyAuthorityTemplateViewAuthorityTemplateItemListAuthorityTemplateItem(DaraModel):
    def __init__(
        self,
        attribute: str = None,
        db_id: int = None,
        instance_id: int = None,
        item_id: int = None,
        modifier_id: int = None,
        resource_type: str = None,
        table_name: str = None,
        template_id: int = None,
    ):
        self.attribute = attribute
        self.db_id = db_id
        self.instance_id = instance_id
        self.item_id = item_id
        self.modifier_id = modifier_id
        self.resource_type = resource_type
        self.table_name = table_name
        self.template_id = template_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.attribute is not None:
            result['Attribute'] = self.attribute

        if self.db_id is not None:
            result['DbId'] = self.db_id

        if self.instance_id is not None:
            result['InstanceId'] = self.instance_id

        if self.item_id is not None:
            result['ItemId'] = self.item_id

        if self.modifier_id is not None:
            result['ModifierId'] = self.modifier_id

        if self.resource_type is not None:
            result['ResourceType'] = self.resource_type

        if self.table_name is not None:
            result['TableName'] = self.table_name

        if self.template_id is not None:
            result['TemplateId'] = self.template_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Attribute') is not None:
            self.attribute = m.get('Attribute')

        if m.get('DbId') is not None:
            self.db_id = m.get('DbId')

        if m.get('InstanceId') is not None:
            self.instance_id = m.get('InstanceId')

        if m.get('ItemId') is not None:
            self.item_id = m.get('ItemId')

        if m.get('ModifierId') is not None:
            self.modifier_id = m.get('ModifierId')

        if m.get('ResourceType') is not None:
            self.resource_type = m.get('ResourceType')

        if m.get('TableName') is not None:
            self.table_name = m.get('TableName')

        if m.get('TemplateId') is not None:
            self.template_id = m.get('TemplateId')

        return self

