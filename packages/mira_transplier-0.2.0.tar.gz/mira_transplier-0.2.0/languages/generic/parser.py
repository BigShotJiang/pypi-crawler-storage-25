import os

from languages.base import BaseParser


GENERIC_CHUNK_LINE_COUNT = 100


class GenericParser(BaseParser):
    def parse(self, file_path):
        with open(file_path, "r", encoding="utf-8", errors="replace") as handle:
            source_lines = handle.readlines()

        sections = []
        total_lines = len(source_lines)
        chunk_number = 1
        for start_line in range(1, total_lines + 1, GENERIC_CHUNK_LINE_COUNT):
            end_line = min(total_lines, start_line + GENERIC_CHUNK_LINE_COUNT - 1)
            sections.append(
                {
                    "label": f"CHUNK {chunk_number}",
                    "start": start_line,
                    "end": end_line,
                    "members": [],
                }
            )
            chunk_number += 1

        extension = os.path.splitext(file_path)[1].lower().lstrip(".") or "generic"
        stat = os.stat(file_path)
        return {
            "language": extension,
            "file_kind": "generic",
            "storage_mode": "mirrored",
            "global_variables": {},
            "imports": [],
            "classes": {},
            "functions": {},
            "symbols": [],
            "sections": sections,
            "source_signature": {
                "size": stat.st_size,
                "mtime_ns": getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)),
            },
            "origin": "manual_or_external",
        }