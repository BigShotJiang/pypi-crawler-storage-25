import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
MIRA_SCRIPT = REPO_ROOT / "mira.py"


class MiraCliRegressionTests(unittest.TestCase):
    maxDiff = None

    def make_workspace(self):
        tempdir = tempfile.TemporaryDirectory()
        self.addCleanup(tempdir.cleanup)
        return Path(tempdir.name)

    def write_file(self, workspace, relative_path, content):
        path = workspace / relative_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def run_mira(self, workspace, *args, input_text=None):
        return subprocess.run(
            [sys.executable, str(MIRA_SCRIPT), *args],
            cwd=workspace,
            input=input_text,
            text=True,
            capture_output=True,
            check=False,
        )

    def assert_ok(self, result):
        self.assertEqual(result.returncode, 0, self.format_result(result))

    def assert_failed(self, result, expected_text=None):
        self.assertNotEqual(result.returncode, 0, self.format_result(result))
        if expected_text is not None:
            self.assertIn(expected_text, result.stdout + result.stderr, self.format_result(result))

    def build_workspace(self, workspace):
        result = self.run_mira(workspace, ".")
        self.assert_ok(result)
        return result

    def read_text(self, workspace, relative_path):
        return (workspace / relative_path).read_text(encoding="utf-8")

    def read_json(self, workspace, relative_path):
        return json.loads(self.read_text(workspace, relative_path))

    def indexed_paths(self, workspace):
        global_index = self.read_json(workspace, ".mira/global_index.json")
        return {entry["path"] for entry in global_index["files"].values()}

    def file_id_for_path(self, workspace, relative_path):
        global_index = self.read_json(workspace, ".mira/global_index.json")
        for file_id, entry in global_index["files"].items():
            if entry["path"] == relative_path:
                return int(file_id)
        self.fail(f"Missing indexed path: {relative_path}")

    def format_result(self, result):
        return f"exit={result.returncode}\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"

    def test_ai_surface_hides_admin_index_commands_and_builds_generic_and_document_files(self):
        workspace = self.make_workspace()
        self.write_file(workspace, "main.py", "print('ok')\n")
        self.write_file(workspace, "src/app.py", "def app():\n    return 'app'\n")
        self.write_file(workspace, "src/nested/deep.py", "def deep():\n    return 'deep'\n")
        self.write_file(workspace, ".gitignore", "build/\n")
        self.write_file(workspace, ".env", "SECRET=1\n")
        self.write_file(workspace, "artifact.egg-info/PKG-INFO", "Name: artifact\n")
        self.write_file(workspace, "notes.txt", "alpha\nbeta\n")
        self.write_file(workspace, "data.json", '{"name": "mira", "enabled": true}\n')
        self.write_file(workspace, "rows.jsonl", '{"id": 1, "name": "alpha"}\n{"id": 2, "name": "beta"}\n')
        java_lines = "\n".join(f"System.out.println({line_number});" for line_number in range(1, 206)) + "\n"
        self.write_file(workspace, "Example.java", java_lines)

        self.build_workspace(workspace)

        project_manifest = self.read_text(workspace, ".mira/project.mira")
        guide_text = self.read_text(workspace, ".mira/GUIDE.txt")
        list_result = self.run_mira(workspace, "!list")
        self.assert_ok(list_result)

        self.assertNotIn("ENVIRONMENT:", project_manifest)
        self.assertNotIn("!index", project_manifest)
        self.assertIn("!index", guide_text)
        self.assertIn("!index add <path>", guide_text)
        self.assertIn("!index remove <path>", guide_text)
        self.assertIn("!environment [path|clear|create <name>]", guide_text)
        self.assertIn("!add_comment <chunk_id>", project_manifest)
        self.assertIn("!edit_comment <chunk_id>", project_manifest)
        self.assertIn("!delete_comment <chunk_id>", project_manifest)
        self.assertNotIn("!environment", project_manifest)
        self.assertNotIn("!environment", list_result.stdout)
        self.assertNotIn("!index", list_result.stdout)
        self.assertNotIn("--stdin", project_manifest)
        self.assertNotIn("--stdin", guide_text)
        self.assertNotIn("--stdin", list_result.stdout)

        indexed_paths = self.indexed_paths(workspace)
        self.assertIn(".gitignore", indexed_paths)
        self.assertNotIn(".env", indexed_paths)
        self.assertNotIn("artifact.egg-info/PKG-INFO", indexed_paths)
        self.assertIn("notes.txt", indexed_paths)
        self.assertIn("data.json", indexed_paths)
        self.assertIn("rows.jsonl", indexed_paths)
        self.assertIn("Example.java", indexed_paths)

        global_index = self.read_json(workspace, ".mira/global_index.json")
        entries_by_path = {entry["path"]: entry for entry in global_index["files"].values()}
        self.assertEqual(entries_by_path["notes.txt"]["storage_mode"], "metadata-only")
        self.assertEqual(entries_by_path["data.json"]["storage_mode"], "metadata-only")
        self.assertEqual(entries_by_path["rows.jsonl"]["storage_mode"], "metadata-only")
        self.assertEqual(entries_by_path["Example.java"]["file_kind"], "generic")

        java_file_id = self.file_id_for_path(workspace, "Example.java")
        java_meta = self.read_json(workspace, f".mira/files/{java_file_id}/meta.json")
        self.assertEqual(len(java_meta["chunks"]), 3)

    def test_index_remove_and_nested_readd_follow_folder_boundaries(self):
        workspace = self.make_workspace()
        self.write_file(workspace, "src/app.py", "def app():\n    return 'app'\n")
        self.write_file(workspace, "src/nested/deep.py", "def deep():\n    return 'deep'\n")
        self.write_file(workspace, "src/.env", "TOKEN=abc\n")

        self.build_workspace(workspace)

        result = self.run_mira(workspace, "!index", "remove", "src")
        self.assert_ok(result)
        indexed_paths = self.indexed_paths(workspace)
        self.assertNotIn("src/app.py", indexed_paths)
        self.assertNotIn("src/nested/deep.py", indexed_paths)
        self.assertNotIn("src/.env", indexed_paths)

        result = self.run_mira(workspace, "!index", "add", "src/nested")
        self.assert_ok(result)
        indexed_paths = self.indexed_paths(workspace)
        self.assertNotIn("src/app.py", indexed_paths)
        self.assertIn("src/nested/deep.py", indexed_paths)

        result = self.run_mira(workspace, "!index", "add", "src/app.py")
        self.assert_failed(result, "Index the folder instead: src")

        result = self.run_mira(workspace, "!index", "add", "src/.env")
        self.assert_ok(result)
        indexed_paths = self.indexed_paths(workspace)
        self.assertIn("src/.env", indexed_paths)
        self.assertIn("src/nested/deep.py", indexed_paths)
        self.assertNotIn("src/app.py", indexed_paths)

    def test_nested_create_auto_indexes_and_delete_cleans_state(self):
        workspace = self.make_workspace()
        self.write_file(workspace, "main.py", "print('base')\n")

        self.build_workspace(workspace)

        self.assert_ok(self.run_mira(workspace, "!create", "/runtime/another"))
        self.assert_ok(self.run_mira(workspace, "!create", str(workspace / "runtime" / "script.py")))
        self.assert_ok(self.run_mira(workspace, "!create", str(workspace / "runtime" / "another" / "deep.java")))
        self.assert_ok(self.run_mira(workspace, "!create", "/trash/lone.py"))

        indexed_paths = self.indexed_paths(workspace)
        self.assertIn("runtime/script.py", indexed_paths)
        self.assertIn("runtime/another/deep.java", indexed_paths)
        self.assertIn("trash/lone.py", indexed_paths)

        index_state = self.read_json(workspace, ".mira/ADMIN/index.json")
        self.assertIn("runtime", index_state["entries"])
        self.assertIn("runtime/another", index_state["entries"])
        self.assertTrue(index_state["entries"]["runtime"]["included"])
        self.assertTrue(index_state["entries"]["runtime/another"]["included"])

        script_file_id = self.file_id_for_path(workspace, "runtime/script.py")
        result = self.run_mira(workspace, "!delete", str(script_file_id), input_text="y\n")
        self.assert_ok(result)
        indexed_paths = self.indexed_paths(workspace)
        self.assertNotIn("runtime/script.py", indexed_paths)
        self.assertIn("runtime/another/deep.java", indexed_paths)

        lone_file_id = self.file_id_for_path(workspace, "trash/lone.py")
        result = self.run_mira(workspace, "!delete", str(lone_file_id), input_text="y\ny\n")
        self.assert_ok(result)
        indexed_paths = self.indexed_paths(workspace)
        self.assertNotIn("trash/lone.py", indexed_paths)
        self.assertFalse((workspace / "trash").exists())

        result = self.run_mira(workspace, "!delete", str(workspace / "runtime" / "another"), input_text="y\n")
        self.assert_ok(result)
        indexed_paths = self.indexed_paths(workspace)
        self.assertNotIn("runtime/another/deep.java", indexed_paths)

        index_state = self.read_json(workspace, ".mira/ADMIN/index.json")
        self.assertNotIn("runtime/another", index_state["entries"])
        self.assertNotIn("trash", index_state["entries"])

    def test_environment_admin_command_lists_and_configures_manifest_environment(self):
        workspace = self.make_workspace()
        self.write_file(workspace, "main.py", "print('base')\n")
        self.write_file(workspace, ".venv/Scripts/activate", "")
        self.write_file(workspace, "global/randomFolder/env/Scripts/Activate.ps1", "")

        self.build_workspace(workspace)

        result = self.run_mira(workspace, "!environment")
        self.assert_ok(result)
        self.assertIn("Configured environment: none", result.stdout)
        self.assertIn(".venv", result.stdout)
        self.assertIn("global/randomFolder/env", result.stdout)

        bad_env = workspace / "bad-env"
        bad_env.mkdir(parents=True, exist_ok=True)
        result = self.run_mira(workspace, "!environment", str(bad_env))
        self.assert_failed(result, "Folder doesn't have /Scripts")

        result = self.run_mira(workspace, "!environment", "create", "project-env")
        self.assert_ok(result)
        self.build_workspace(workspace)

        project_manifest = self.read_text(workspace, ".mira/project.mira")
        self.assertIn(f"ENVIRONMENT: project-env ({(workspace / 'project-env').resolve()})", project_manifest)
        self.assertTrue((workspace / "project-env" / "Scripts").exists())

        result = self.run_mira(workspace, "!environment", "clear")
        self.assert_ok(result)
        project_manifest = self.read_text(workspace, ".mira/project.mira")
        self.assertNotIn("ENVIRONMENT:", project_manifest)

    def test_chunk_comments_follow_unchanged_chunks_and_update_skeleton(self):
        workspace = self.make_workspace()
        self.write_file(
            workspace,
            "app.py",
            "def alpha():\n    return 1\n\n\ndef beta():\n    return 2\n",
        )

        self.build_workspace(workspace)

        file_id = self.file_id_for_path(workspace, "app.py")
        meta = self.read_json(workspace, f".mira/files/{file_id}/meta.json")
        beta_chunk_id = next(
            chunk_id for chunk_id, chunk_meta in meta["chunks"].items() if any(name.endswith("beta") for name in chunk_meta["functions"])
        )

        result = self.run_mira(workspace, "!add_comment", beta_chunk_id, "Beta chunk")
        self.assert_ok(result)

        skeleton = self.read_text(workspace, f".mira/files/{file_id}/skeleton.txt")
        self.assertIn("# FORMAT: item | lines | id | comment", skeleton)
        self.assertIn("#Beta chunk", skeleton)

        result = self.run_mira(
            workspace,
            "!edit",
            str(file_id),
            input_text="def beta():\n    return 2\n\n\ndef alpha():\n    return 1\n",
        )
        self.assert_ok(result)

        meta = self.read_json(workspace, f".mira/files/{file_id}/meta.json")
        updated_beta_chunk_id = next(
            chunk_id for chunk_id, chunk_meta in meta["chunks"].items() if any(name.endswith("beta") for name in chunk_meta["functions"])
        )
        self.assertNotEqual(beta_chunk_id, updated_beta_chunk_id)
        self.assertEqual(meta["chunks"][updated_beta_chunk_id]["comment"], "Beta chunk")

        result = self.run_mira(workspace, "!edit_comment", updated_beta_chunk_id, "Beta updated")
        self.assert_ok(result)
        meta = self.read_json(workspace, f".mira/files/{file_id}/meta.json")
        self.assertEqual(meta["chunks"][updated_beta_chunk_id]["comment"], "Beta updated")

        result = self.run_mira(workspace, "!delete_comment", updated_beta_chunk_id)
        self.assert_ok(result)
        meta = self.read_json(workspace, f".mira/files/{file_id}/meta.json")
        self.assertNotIn("comment", meta["chunks"][updated_beta_chunk_id])

    def test_cpp_files_keep_structured_chunks(self):
        workspace = self.make_workspace()
        cpp_source = (
            "#include <string>\n\n"
            "namespace demo {\n"
            "class Engine {\n"
            "public:\n"
            "    int value() const;\n"
            "};\n\n"
            "int Engine::value() const {\n"
            "    return 7;\n"
            "}\n\n"
            "std::string greet() {\n"
            "    return \"hi\";\n"
            "}\n"
            "}\n"
        )
        self.write_file(workspace, "engine.cpp", cpp_source)

        self.build_workspace(workspace)

        file_id = self.file_id_for_path(workspace, "engine.cpp")
        global_index = self.read_json(workspace, ".mira/global_index.json")
        cpp_entry = global_index["files"][str(file_id)]
        self.assertEqual(cpp_entry["language"], "cpp")
        self.assertEqual(cpp_entry["file_kind"], "code")

        cpp_meta = self.read_json(workspace, f".mira/files/{file_id}/meta.json")
        self.assertGreaterEqual(len(cpp_meta["chunks"]), 3)

    def test_edit_surface_supports_auto_stdin_and_generic_chunk_operations(self):
        workspace = self.make_workspace()
        java_lines = "\n".join(f"System.out.println({line_number});" for line_number in range(1, 206)) + "\n"
        self.write_file(workspace, "Example.java", java_lines)

        self.build_workspace(workspace)

        file_id = self.file_id_for_path(workspace, "Example.java")
        replacement_text = "\n".join(f"System.out.println({line_number * 10});" for line_number in range(1, 206)) + "\n"

        result = self.run_mira(workspace, "!edit", str(file_id), input_text=replacement_text)
        self.assert_ok(result)

        result = self.run_mira(workspace, "!edit", f"{file_id}_1+", "System.out.println(999);", input_text="n\n")
        self.assert_ok(result)
        result = self.run_mira(workspace, "!edit", f"{file_id}_1-", "System.out.println(111);", input_text="n\n")
        self.assert_ok(result)
        result = self.run_mira(workspace, "!edit", f"-{file_id}_3")
        self.assert_ok(result)

        source_lines = self.read_text(workspace, "Example.java").splitlines()
        self.assertEqual(source_lines[0], "System.out.println(111);")
        self.assertIn("System.out.println(999);", source_lines)
        self.assertEqual(len(source_lines), 200)

        java_meta = self.read_json(workspace, f".mira/files/{file_id}/meta.json")
        self.assertEqual(len(java_meta["chunks"]), 2)


if __name__ == "__main__":
    unittest.main()