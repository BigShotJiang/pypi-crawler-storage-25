from litestar import Router, get


@get("/")
def hello():
    return "hi"


router = Router(path="/test", route_handlers=[hello])

print(f"Attributes: {dir(router)}")
print(f"Route handlers: {getattr(router, 'route_handlers', 'MISSING')}")
print(f"Registered IDs: {getattr(router, 'registered_route_handler_ids', 'MISSING')}")
