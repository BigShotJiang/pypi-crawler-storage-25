## framework-m-standard v0.11.0

### Features

- add landing and defaults adapters with deterministic naming (f21b60c)
- implement platform-level navigation adapters (c0ba170)
- implement child-table backed workflow state persistence (01e6083)
- add database introspection adapter and migrate-verify command (3bc51b6)
- implement generic worker and CLI entry point (4d137d6)
- add metadata discovery routes to web adapter (84074d7)
- implement agnostic hybrid overflow and references (161ba4a)

### Bug Fixes

- correct metadata discovery and harden core adapters (6325397)
- get_permitted_filters to check user's role access (79809d9)
- clarify use aiosqlite for db url in test (ea6d152)
- clarify use aiosqlite for db url in test (e42da44)
- align adapters and tests with stabilized metadata schema (d091724)

## framework-m-standard v0.10.0

### Features

- wire DatabaseAuditAdapter to RepositoryProtocol (08a066e)

### Bug Fixes

- mypy and typecheck errors (10d010d)
- mypy and typecheck errors (17ba489)

## framework-m-standard v0.9.0

### Features

- generalize discovery api and restore socket publish bridge (adfb65e)

## framework-m-standard v0.8.0

### Features

- support client_secret_post for custom OIDC providers (be83ac1)

## framework-m-standard v0.7.0

### Features

- refactor auth strategy names (1e66f0e)
- implement OIDC federated auth strategy (274e8cf)
- refactor auth strategy names (5e7147c)

## framework-m-standard v0.6.5

### Bug Fixes

- implement bulk dependency upgrades and fix typecheck stubs (bf01d94)
- install pnpm and coreutils in release phase (ed335f8)
- enforce tool availability and install pnpm in CI (b8f9465)
- enforce lockfile sync, stage templates, and fix types (a41aad0)
- enhance local dry-run and silence check-ignore spam (29f9ef6)
- modernize gitops auth and api integration (7f15453)
- secure staging logic and resolve test regressions (e31d701)
- implement pnpm/uv lockfile sync and config cleanup (8302956)
- lint cleanup for cli.py (40b3a78)
- support GITLAB_TOKEN and harden auth check (c08b25c)
- implement atomic direct push for CI/CD stability (2947270)
- modularize release package and resolve test regressions (fe8c676)

## framework-m-standard v0.6.4

### Bug Fixes

- install pnpm and coreutils in release phase (ed335f8)
- enforce tool availability and install pnpm in CI (b8f9465)
- enforce lockfile sync, stage templates, and fix types (a41aad0)
- enhance local dry-run and silence check-ignore spam (29f9ef6)
- modernize gitops auth and api integration (7f15453)
- secure staging logic and resolve test regressions (e31d701)
- implement pnpm/uv lockfile sync and config cleanup (8302956)
- lint cleanup for cli.py (40b3a78)
- support GITLAB_TOKEN and harden auth check (c08b25c)
- implement atomic direct push for CI/CD stability (2947270)
- modularize release package and resolve test regressions (fe8c676)

# Changelog

## framework-m-standard v0.6.3

### Bug Fixes

- fix uv-build output and sync python packages (d9c994a)


## framework-m-standard v0.6.2

### Bug Fixes

- refine dependency sync to respect explicit targets (187938c)
- support commit body tags for synchronized releases (b83d42a)


## framework-m-standard v0.6.1

### Bug Fixes

- simplify docs and add license (7c68b3a)


## framework-m-standard v0.6.0

### Features

- implement pluggable Auth Strategy Registry and Citadel IAM integration (e226752)
- add cli info and enhance locale resolution (6edc077)
- add observability middleware and real health checks (256396a)
- implement zero-downtime migration check and harden web security (8e4636e)
- harden security and implement secrets adapter (cc70608)

### Bug Fixes

- hardcoded tmp path in test_migrate.py (3733980)
- mypy error (381b071)
- mypy error (2d92019)
- Native social login support using authlib (ec44d46)
- resolve test warnings and make rate-limit config configurable (ebf1f0d)


## framework-m-standard v0.5.0

### Features

- implement backend MFE discovery and serving (b5de8bf)


## framework-m-standard v0.4.2

### Bug Fixes

- update package description in readme (73dd3ea)


## framework-m-standard v0.4.1

### Bug Fixes

- resolve duplicate filenames in wheel (cb44656)


## framework-m-standard v0.4.0

### Features

- add oauth runtime wiring and create-user CLI (0f6c295)
- add oauth runtime wiring and create-user CLI (25f10bb)
- implement decentralized modular migration system (fe91cc1)

### Bug Fixes

- ruff format checks (91c3e40)
- centralize doctype discovery and improve static fallback (ecad32c)


## framework-m-standard v0.3.2

### Bug Fixes

- server ips to 0.0.0.0 and changes are runtime fixes (Desk asset URL rewrite + preferred dist resolution) (69e4f99)


## framework-m-standard v0.3.1

### Bug Fixes

- migration layout and default permissions (603496e)


## framework-m-standard v0.3.0

### Features

- optional nginx support (6f361cc)


## framework-m-standard v0.2.17

### Bug Fixes

- mypy error (64b8bd2)
- static file issue and auth doc (aef4523)


## framework-m-standard v0.2.16

### Bug Fixes

- serve_desk_spa in app.py and add auth documentation (c7f3a96)


## framework-m-standard v0.2.15

### Bug Fixes

- respect DATABASE_URL in migrate init and avoid hardcoded engine (fc0259e)


## framework-m-standard v0.2.14

### Bug Fixes

- use last tag version as base for release bump (bfefd3f)
- support version bumping for package.json in release script (2b6a7c3)
- fix build crash and ensure static assets are packaged (bdc18b7)
- force include gitignored static assets in packages (4fd49a5)


## framework-m-standard v0.2.13

### Bug Fixes

- trigger doc builds on studio changes (d1a2a7b)
- synchronize pages rules with build-docs (3b2d9b7)
- aggressive filtering and dependency decoupling (6b8dbf0)
- global dummy assets and artifact integrity (f6d39f2)
- dual-track artifacts and tag optimization (6b9cdfb)
- optimize tag pipeline and kill duplication (d9154ae)
- use hatch artifacts to resolve duplicate filenames (e499457)


## framework-m-standard v0.2.12

### Bug Fixes

- robustly detect existing tags in auto_tag_release (8aeef39)


## framework-m-standard v0.2.11

### Bug Fixes

- bulletproof tagging and gitlab pypi upload idempotency (530466b)
- make auto_tag_release script idempotent (c211ab5)


## framework-m-standard v0.2.10

### Bug Fixes

- remove unsupported --skip-existing from gitlab twine upload (a1b6a96)


## framework-m-standard v0.2.9

### Bug Fixes

- make test-workspace needs optional (96450fc)
- restore gitlint general section header (7131edc)
- adjust gitlint limits and script for long release titles (1a1371e)
- resolve duplicate filenames in wheel and improve CI robustness (e24c0ef)


## framework-m-standard v0.2.8

### Bug Fixes

- add ruff code style badge to README (3bd7674)


## framework-m-standard v0.2.7

### Bug Fixes

- add pipeline status badge to README (c2dc70f)


## framework-m-standard v0.2.6

### Bug Fixes

- enforce timezone-aware datetimes and fix test (b68332a)

