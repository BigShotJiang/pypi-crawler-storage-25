# Framework M Standard

[![PyPI version](https://badge.fury.io/py/framework-m-standard.svg)](https://badge.fury.io/py/framework-m-standard)
[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![GitLab Pipeline Status](https://gitlab.com/castlecraft/framework-m/badges/main/pipeline.svg)](https://gitlab.com/castlecraft/framework-m/-/pipelines)
[![Code style: ruff](https://img.shields.io/badge/code%20style-ruff-000000.svg)](https://github.com/astral-sh/ruff)

Default adapters and Desk UI serving for Framework M.

## Installation

```bash
pip install framework-m-standard
```

Or with `uv`:

```bash
uv add framework-m-standard
```

Default adapters and infrastructure implementations for Framework M.

## Overview

Framework M Standard provides a set of batteries-included adapters for the core protocols:

- **Database**: SQLAlchemy-based repositories and automatic schema mapping.
- **Web**: Litestar integration with auth guards and Desk UI serving.
- **Async I/O**: Redis-backed caching and event bus implementations.
- **Background Jobs**: Taskiq integration for reliable job processing.

These adapters are designed to work together seamlessly but can be swapped individually as needed.

## Usage

This package is typically used as a dependency of `framework-m`.
For most applications, install the full `framework-m` package instead.

```python
from framework_m_standard.adapters.db import GenericRepository
from framework_m_standard.adapters.cache import RedisCacheAdapter
from framework_m_standard.adapters.web.app import create_app
```

## License

Apache 2.0 License - see [LICENSE](https://gitlab.com/castlecraft/framework-m/blob/main/LICENSE) for details.
