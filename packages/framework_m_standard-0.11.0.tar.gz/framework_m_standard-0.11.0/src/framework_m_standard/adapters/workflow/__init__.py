"""Workflow adapters for Framework M.

This package contains concrete implementations of WorkflowProtocol:
- InternalWorkflowAdapter: Database-backed workflow using DocTypes
- TemporalWorkflowAdapter: Integration with Temporal.io (optional)
"""

from framework_m_standard.adapters.workflow.internal_workflow import (
    InternalWorkflowAdapter,
)
from framework_m_standard.adapters.workflow.temporal_adapter import (
    TemporalWorkflowAdapter,
)
from framework_m_standard.adapters.workflow.temporal_worker import (
    TemporalWorkerAdapter,
)

__all__ = [
    "InternalWorkflowAdapter",
    "TemporalWorkflowAdapter",
    "TemporalWorkerAdapter",
]
