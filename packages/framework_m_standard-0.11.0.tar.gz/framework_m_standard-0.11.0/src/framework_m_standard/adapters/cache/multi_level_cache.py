"""Multi-Level Cache Adapter - Combines L1 and L2 caching.

This module provides the MultiLevelCacheAdapter that orchestrates multiple
caching layers (e.g., L1 MemoryCache, L2 RedisCache) to optimize performance
and persistence.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from framework_m_core.interfaces.cache import CacheProtocol

logger = logging.getLogger(__name__)


class MultiLevelCacheAdapter:
    """Multi-level cache that delegates to L1 and L2 layers.

    Typically used with:
    - L1: MemoryCacheAdapter (Per-process/Per-request, Very fast)
    - L2: RedisCacheAdapter (Shared/Distributed, Persistent)

    Operations follow the write-through/read-through pattern.
    """

    def __init__(self, l1: CacheProtocol, l2: CacheProtocol) -> None:
        """Initialize with L1 and L2 caches.

        Args:
            l1: First level cache (e.g., Memory)
            l2: Second level cache (e.g., Redis)
        """
        self.l1 = l1
        self.l2 = l2

    async def get(self, key: str) -> Any | None:
        """Get a value from cache layers (L1 then L2)."""
        # 1. Try L1
        val = await self.l1.get(key)
        if val is not None:
            return val

        # 2. Try L2
        val = await self.l2.get(key)
        if val is not None:
            # Backfill L1
            ttl = await self.l2.ttl(key)
            await self.l1.set(key, val, ttl)
            return val

        return None

    async def set(
        self,
        key: str,
        value: Any,
        ttl: int | None = None,
    ) -> None:
        """Set a value in all cache levels."""
        await self.l1.set(key, value, ttl)
        await self.l2.set(key, value, ttl)

    async def delete(self, key: str) -> None:
        """Delete a key from all levels."""
        await self.l1.delete(key)
        await self.l2.delete(key)

    async def exists(self, key: str) -> bool:
        """Check if a key exists in any level."""
        if await self.l1.exists(key):
            return True
        return await self.l2.exists(key)

    async def get_many(self, keys: list[str]) -> dict[str, Any]:
        """Get multiple values from cache layers."""
        # 1. Get as much as possible from L1
        results = await self.l1.get_many(keys)

        missing_keys = [k for k in keys if k not in results]
        if not missing_keys:
            return results

        # 2. Get remainder from L2
        l2_results = await self.l2.get_many(missing_keys)
        if l2_results:
            # Backfill L1 for each found in L2
            # Note: We don't fetch TTL for each key in batch for performance reasons,
            # we just set them in L1 without TTL or with a default if desired.
            # But the protocol allows us to call set_many.
            await self.l1.set_many(l2_results)
            results.update(l2_results)

        return results

    async def set_many(
        self,
        items: dict[str, Any],
        ttl: int | None = None,
    ) -> None:
        """Set multiple values in all cache levels."""
        await self.l1.set_many(items, ttl)
        await self.l2.set_many(items, ttl)

    async def delete_pattern(self, pattern: str) -> int:
        """Delete all keys matching a pattern in all levels."""
        c1 = await self.l1.delete_pattern(pattern)
        c2 = await self.l2.delete_pattern(pattern)
        return max(c1, c2)

    async def ttl(self, key: str) -> int | None:
        """Get remaining TTL from L1 or L2."""
        t1 = await self.l1.ttl(key)
        if t1 is not None:
            return t1
        return await self.l2.ttl(key)

    async def clear(self) -> None:
        """Clear all levels."""
        await self.l1.clear()
        await self.l2.clear()

    async def acquire_lock(self, key: str, ttl: int) -> bool:
        """Acquire a lock (Delegate to L2 ONLY).

        Multi-level caching should only use the shared layer for locking
        to maintain distributed consistency.
        """
        return await self.l2.acquire_lock(key, ttl)

    async def release_lock(self, key: str) -> bool:
        """Release a lock (Delegate to L2 ONLY)."""
        return await self.l2.release_lock(key)


# Ensure it matches Protocol

if TYPE_CHECKING:
    _m: CacheProtocol = MultiLevelCacheAdapter(None, None)  # type: ignore[arg-type]

__all__ = ["MultiLevelCacheAdapter"]
