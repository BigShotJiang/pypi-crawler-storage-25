"""Cache Adapters - Port implementations for CacheProtocol."""

from __future__ import annotations

from framework_m_standard.adapters.cache.memory_cache import MemoryCacheAdapter
from framework_m_standard.adapters.cache.multi_level_cache import MultiLevelCacheAdapter
from framework_m_standard.adapters.cache.redis_cache import RedisCacheAdapter

# For backward compatibility
InMemoryCacheAdapter = MemoryCacheAdapter

__all__ = [
    "InMemoryCacheAdapter",
    "MemoryCacheAdapter",
    "MultiLevelCacheAdapter",
    "RedisCacheAdapter",
]
