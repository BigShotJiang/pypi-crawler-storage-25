"""Memory Cache Adapter - In-memory caching for L1 or development.

This module provides the MemoryCacheAdapter that implements CacheProtocol
using a simple dictionary with TTL support.
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any

from framework_m_core.interfaces.cache import CacheProtocol

logger = logging.getLogger(__name__)


class _CacheEntry:
    """Internal entry in memory cache with TTL."""

    def __init__(self, value: Any, expires_at: float | None = None) -> None:
        self.value = value
        self.expires_at = expires_at

    def is_expired(self) -> bool:
        """Check if entry has expired."""
        if self.expires_at is None:
            return False
        return time.time() > self.expires_at


class MemoryCacheAdapter:
    """Simple in-memory cache for per-request or per-process caching.

    Implements CacheProtocol using a dictionary. Not suitable for
    multi-process shared caching, but ideal as an L1 cache or for
    development/testing.
    """

    def __init__(self) -> None:
        """Initialize the memory cache adapter."""
        self._data: dict[str, _CacheEntry] = {}

    async def get(self, key: str) -> Any | None:
        """Get a value from cache."""
        entry = self._data.get(key)
        if not entry:
            return None

        if entry.is_expired():
            del self._data[key]
            return None

        return entry.value

    async def set(
        self,
        key: str,
        value: Any,
        ttl: int | None = None,
    ) -> None:
        """Set a value in cache with optional TTL."""
        expires_at = time.time() + ttl if ttl is not None else None
        self._data[key] = _CacheEntry(value, expires_at)

    async def delete(self, key: str) -> None:
        """Delete a key from cache."""
        if key in self._data:
            del self._data[key]

    async def exists(self, key: str) -> bool:
        """Check if a key exists."""
        entry = self._data.get(key)
        if not entry:
            return False

        if entry.is_expired():
            del self._data[key]
            return False

        return True

    async def get_many(self, keys: list[str]) -> dict[str, Any]:
        """Get multiple values from cache."""
        results = {}
        for key in keys:
            val = await self.get(key)
            if val is not None:
                results[key] = val
        return results

    async def set_many(
        self,
        items: dict[str, Any],
        ttl: int | None = None,
    ) -> None:
        """Set multiple values in cache."""
        for key, value in items.items():
            await self.set(key, value, ttl)

    async def delete_pattern(self, pattern: str) -> int:
        """Delete all keys matching a glob-style pattern.

        Note: Memory implementation is simple and supports basic * suffix pattern.
        """
        import fnmatch

        count = 0
        keys_to_delete = [key for key in self._data if fnmatch.fnmatch(key, pattern)]
        for key in keys_to_delete:
            del self._data[key]
            count += 1
        return count

    async def ttl(self, key: str) -> int | None:
        """Get remaining TTL for a key."""
        entry = self._data.get(key)
        if not entry:
            return None

        if entry.expires_at is None:
            return None

        remaining = int(entry.expires_at - time.time())
        return max(0, remaining)

    async def clear(self) -> None:
        """Clear all keys from cache."""
        self._data.clear()

    async def acquire_lock(self, key: str, ttl: int) -> bool:
        """Acquire a local lock.

        Note: This only provides locking within the current process/process-local.
        For distributed locking, use RedisCacheAdapter.
        """
        lock_key = f"lock:{key}"
        if await self.exists(lock_key):
            return False

        await self.set(lock_key, True, ttl)
        return True

    async def release_lock(self, key: str) -> bool:
        """Release a local lock."""
        await self.delete(f"lock:{key}")
        return True


# Ensure it matches Protocol

if TYPE_CHECKING:
    _p: CacheProtocol = MemoryCacheAdapter()

__all__ = ["MemoryCacheAdapter"]
