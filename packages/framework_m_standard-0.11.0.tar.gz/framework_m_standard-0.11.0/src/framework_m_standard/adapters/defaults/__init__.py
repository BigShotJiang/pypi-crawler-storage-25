"""Defaults Adapters.

Contains concrete implementations of the DefaultsProtocol.
"""

from framework_m_standard.adapters.defaults.toml_defaults import TomlDefaultsAdapter

__all__ = [
    "TomlDefaultsAdapter",
]
