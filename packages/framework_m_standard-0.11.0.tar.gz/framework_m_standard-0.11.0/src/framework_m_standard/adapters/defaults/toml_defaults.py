"""TOML Defaults Adapter.

Reads system default configurations from a TOML file.
"""

import tomllib
from pathlib import Path
from typing import Any

from framework_m_core.interfaces.defaults import DefaultsProtocol


class TomlDefaultsAdapter(DefaultsProtocol):
    """Adapter for reading system defaults from a TOML file."""

    def __init__(self, file_path: str | Path) -> None:
        """Initialize the adapter with a path to a TOML file.

        Args:
            file_path: The path to the TOML configuration file.
        """
        self.file_path = Path(file_path)
        self._data: dict[str, Any] | None = None

    def _load_data(self) -> dict[str, Any]:
        """Lazily load and cache the TOML file contents."""
        if self._data is not None:
            return self._data

        if not self.file_path.exists():
            self._data = {}
            return self._data

        try:
            with open(self.file_path, "rb") as f:
                self._data = tomllib.load(f)
        except Exception:
            self._data = {}

        return self._data

    async def get(self, key: str, default: Any = None) -> Any:
        """Retrieve a specific default value, supporting dot notation."""
        current = self._load_data()
        for part in key.split("."):
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return default
        return current

    async def get_all(self) -> dict[str, Any]:
        """Retrieve all currently configured defaults."""
        return self._load_data()
