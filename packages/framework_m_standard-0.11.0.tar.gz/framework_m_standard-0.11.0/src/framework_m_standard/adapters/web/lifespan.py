"""Application Lifespan Management.

This module handles the startup and shutdown lifecycle events for the Litestar
application, including dependency injection setup, database connections, and
background worker initialization.
"""

from __future__ import annotations

import logging
import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager, suppress
from typing import Any

from framework_m_core.config import load_config
from framework_m_core.container import Container
from framework_m_core.doctypes.webhook import Webhook
from framework_m_core.interfaces.audit import AuditLogProtocol, InMemoryAuditAdapter
from framework_m_core.interfaces.repository import FilterOperator, FilterSpec
from framework_m_core.registry import MetaRegistry
from framework_m_core.services.user_manager import UserManager
from litestar import Litestar

from framework_m_standard.adapters.audit import (
    DatabaseAuditAdapter,
    ElasticAuditAdapter,
    FileAuditAdapter,
)
from framework_m_standard.adapters.auth.local_identity import LocalIdentityAdapter
from framework_m_standard.adapters.auth.oauth_service import OAuthService
from framework_m_standard.adapters.auth.repository_adapters import (
    LocalUserRepositoryAdapter,
    SessionRepositoryAdapter,
    SocialAccountRepositoryAdapter,
)
from framework_m_standard.adapters.auth.session_store import (
    DatabaseSessionAdapter,
    RedisSessionAdapter,
)
from framework_m_standard.adapters.auth.strategies import SessionCookieAuth
from framework_m_standard.adapters.db.connection import ConnectionFactory
from framework_m_standard.adapters.db.repository_factory import RepositoryFactory
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from framework_m_standard.adapters.db.session import SessionFactory
from framework_m_standard.adapters.web.auth_routes import (
    configure_auth_routes,
    configure_session_store,
)
from framework_m_standard.adapters.web.oauth_routes import configure_oauth_routes
from framework_m_standard.adapters.webhooks.delivery import HttpWebhookDeliverer
from framework_m_standard.adapters.webhooks.listener import WebhookListener

logger = logging.getLogger(__name__)


class _RepositoryWebhookLoader:
    """Repository-backed webhook loader for runtime delivery."""

    def __init__(
        self, repo_factory: RepositoryFactory, session_factory: SessionFactory
    ) -> None:
        self._repo_factory = repo_factory
        self._session_factory = session_factory

    async def load_active_webhooks(self) -> list[Webhook]:
        repo = self._repo_factory.get_repository(Webhook)
        if repo is None:
            return []

        async with self._session_factory.get_session() as session:
            result = await repo.list_entities(
                session=session,
                filters=[
                    FilterSpec(
                        field="enabled",
                        operator=FilterOperator.EQ,
                        value=True,
                    )
                ],
                limit=1000,
                offset=0,
            )
            return [item for item in result.items if isinstance(item, Webhook)]


def _create_runtime_audit_adapter(config: dict[str, Any]) -> AuditLogProtocol:
    """Create runtime audit adapter from env/config, defaulting to database mode."""
    audit_cfg = config.get("audit", {})
    adapter_name = os.environ.get(
        "FRAMEWORK_M_AUDIT_ADAPTER",
        str(audit_cfg.get("adapter", "database")),
    ).lower()

    if adapter_name == "elastic":
        elastic_url = os.environ.get(
            "FRAMEWORK_M_ELASTICSEARCH_URL",
            str(audit_cfg.get("elasticsearch_url", "http://localhost:9200")),
        )
        index_prefix = str(audit_cfg.get("index_prefix", "framework-m-audit"))
        return ElasticAuditAdapter(hosts=[elastic_url], index_prefix=index_prefix)

    if adapter_name == "file":
        file_path = os.environ.get(
            "FRAMEWORK_M_AUDIT_FILE_PATH",
            str(audit_cfg.get("file_path", "./audit.log")),
        )
        return FileAuditAdapter(file_path=file_path)

    if adapter_name == "database":
        return DatabaseAuditAdapter()

    logger.warning(
        "Unknown FRAMEWORK_M_AUDIT_ADAPTER=%s, using in-memory", adapter_name
    )
    return InMemoryAuditAdapter()


@asynccontextmanager
async def app_lifespan(app: Litestar) -> AsyncGenerator[None, None]:
    """Application lifespan context manager."""
    container = Container()
    connection_factory = ConnectionFactory()
    session_factory = SessionFactory()

    config = load_config()
    database_url = os.environ.get("DATABASE_URL") or config.get("database", {}).get(
        "url", "sqlite+aiosqlite:///./dev.db"
    )

    connection_factory.configure({"default": database_url})
    session_factory.configure(connection_factory)
    audit_adapter = _create_runtime_audit_adapter(config)
    app.state.audit_adapter = audit_adapter

    from sqlalchemy import MetaData

    registry = MetaRegistry.get_instance()
    metadata = MetaData()
    schema_mapper = SchemaMapper()

    _AUTH_DOCTYPES = [
        "framework_m_core.doctypes.user",
        "framework_m_core.doctypes.social_account",
        "framework_m_core.doctypes.session",
    ]
    for _auth_module_path in _AUTH_DOCTYPES:
        try:
            import importlib as _importlib
            import inspect as _inspect

            from framework_m_core.domain.base_doctype import BaseDocType as _BaseDocType

            _mod = _importlib.import_module(_auth_module_path)
            for _, _cls in _inspect.getmembers(_mod, _inspect.isclass):
                if issubclass(_cls, _BaseDocType) and _cls is not _BaseDocType:
                    with suppress(Exception):
                        schema_mapper.create_tables(_cls, metadata)
        except Exception as _e:
            import sys as _sys

            print(
                f"[Auth] Warning: Failed to map auth schema {_auth_module_path}: {_e}",
                file=_sys.stderr,
            )

    for doctype_name in registry.list_doctypes():
        try:
            doctype_class = registry.get_doctype(doctype_name)
            if doctype_class is not None and doctype_class.get_api_resource():
                schema_mapper.create_tables(doctype_class, metadata)
        except Exception:
            pass

    engine = connection_factory.get_engine("default")
    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)

    repo_factory = RepositoryFactory(metadata, session_factory)
    app.state.repository_factory = repo_factory
    app.state.engine = engine

    user_repo_adapter = LocalUserRepositoryAdapter(repo_factory, session_factory)
    local_identity = LocalIdentityAdapter(
        user_repository=user_repo_adapter,
        jwt_secret=app.state.jwt_secret,
    )
    user_manager = UserManager(
        identity_provider=local_identity,
        user_repository=user_repo_adapter,
    )
    configure_auth_routes(user_manager)

    if app.state.redis_url:
        runtime_session_store: Any = RedisSessionAdapter(redis_url=app.state.redis_url)
    else:
        session_repo_adapter = SessionRepositoryAdapter(repo_factory, session_factory)
        runtime_session_store = DatabaseSessionAdapter(
            session_repository=session_repo_adapter
        )

    configure_session_store(runtime_session_store)

    social_repo_adapter = SocialAccountRepositoryAdapter(repo_factory, session_factory)
    oauth_service = OAuthService(
        social_account_repo=social_repo_adapter,
        user_repo=user_repo_adapter,
    )
    configure_oauth_routes(runtime_session_store, oauth_service)

    auth_chain = app.state.auth_chain
    existing = [
        strategy
        for strategy in auth_chain._strategies
        if not isinstance(strategy, SessionCookieAuth)
    ]
    auth_chain._strategies = [
        SessionCookieAuth(
            session_store=runtime_session_store,
            user_lookup=user_manager.get,
        ),
        *existing,
    ]

    app.state.container = container

    webhook_listener: WebhookListener | None = None
    event_bus: Any | None = None
    try:
        event_bus = container.event_bus()
        if hasattr(event_bus, "connect"):
            await event_bus.connect()

        webhook_loader = _RepositoryWebhookLoader(repo_factory, session_factory)
        webhook_deliverer = HttpWebhookDeliverer(audit_log=audit_adapter)
        webhook_listener = WebhookListener(
            event_bus=event_bus,
            webhook_loader=webhook_loader,
            deliverer=webhook_deliverer,
        )
        await webhook_listener.start()

        app.state.event_bus = event_bus
        app.state.webhook_listener = webhook_listener
    except Exception as exc:
        logger.warning("Webhook listener startup skipped: %s", exc)

    yield

    webhook_listener = getattr(app.state, "webhook_listener", None)
    if webhook_listener is not None:
        with suppress(Exception):
            await webhook_listener.stop()

    event_bus = getattr(app.state, "event_bus", None)
    if event_bus is not None and hasattr(event_bus, "disconnect"):
        with suppress(Exception):
            await event_bus.disconnect()

    await connection_factory.dispose_all()
