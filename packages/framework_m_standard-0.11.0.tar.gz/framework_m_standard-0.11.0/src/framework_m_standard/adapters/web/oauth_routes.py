"""OAuth Routes - OAuth2/OIDC authentication endpoints.

This module provides REST endpoints for OAuth2 social login:
- GET /api/v1/auth/oauth/{provider}/start - Redirect to OAuth provider
- GET /api/v1/auth/oauth/{provider}/callback - Handle OAuth callback

Strategy A (BFF Cookie Mode):
- /start redirects to provider, stores CSRF state in session store (10-min TTL)
- /callback exchanges code, fetches userinfo, calls OAuthService.auto_link_user(),
  creates a server-side session, and redirects to /desk/ with Set-Cookie

Configuration in framework_config.toml:
    [auth.oauth]
    enabled = true
    providers = ["google", "github"]
    # Optional: override default post-login redirect (/desk/)
    # post_login_redirect = "https://your-frontend-host/desk/"

    [auth.oauth.google]
    client_id = "${GOOGLE_CLIENT_ID}"
    client_secret = "${GOOGLE_CLIENT_SECRET}"
    redirect_uri = "https://yourdomain.com/api/v1/auth/oauth/google/callback"

Example:
    from litestar import Litestar
    from framework_m_standard.adapters.web.oauth_routes import oauth_routes_router

    app = Litestar(route_handlers=[oauth_routes_router])
"""

from __future__ import annotations

import logging
import secrets
from typing import Any
from urllib.parse import urlencode

from litestar import Router, get
from litestar.connection import Request
from litestar.exceptions import NotAuthorizedException, NotFoundException
from litestar.response import Redirect

from framework_m_standard.adapters.web.oauth_client import OAuthHTTPClient
from framework_m_standard.adapters.web.oauth_provider import (
    _DEFAULT_OIDC_SCOPE,
    PROVIDER_CONFIGS,
    extract_email,
    extract_provider_user_id,
    get_oauth_config,
    get_post_login_redirect,
    get_provider_config,
    is_email_verified,
    resolve_provider_endpoints,
)
from framework_m_standard.adapters.web.oauth_state_manager import OAuthStateManager

logger = logging.getLogger(__name__)

# =============================================================================
# Module-level singletons (set via configure_* at startup)
# =============================================================================
_session_store: Any | None = None
_oauth_service: Any | None = None


def configure_oauth_routes(
    session_store: Any, oauth_service: Any | None = None
) -> None:
    """Configure OAuth routes with session store and optional OAuth service.

    Call this during app startup. Session store is used for CSRF state storage.

    Args:
        session_store: Session store for OAuth state (short-lived 10-min sessions)
        oauth_service: OAuthService instance for auto_link_user(). Optional;
                       if None, OAuth callback will return an error.
    """
    global _session_store, _oauth_service
    _session_store = session_store
    _oauth_service = oauth_service


# =============================================================================
# Route Handlers
# =============================================================================


@get("/{provider:str}/start")
async def oauth_start(provider: str, request: Request[Any, Any, Any]) -> Redirect:
    """Start OAuth2 flow - redirect to provider.

    Generates a CSRF state parameter and redirects to the provider's auth page.
    Stores the state in the session store (10-min TTL) for later validation.

    Args:
        provider: OAuth provider name (google, github, microsoft, or custom)

    Returns:
        Redirect response to provider's auth URL

    Raises:
        NotFoundException: If provider not configured or not supported
    """
    provider_cfg = get_provider_config(provider)
    if provider_cfg is None:
        logger.warning(
            "oauth_start_provider_not_configured",
            extra={"provider": provider},
        )
        raise NotFoundException(detail=f"OAuth provider '{provider}' not configured")

    resolved = await resolve_provider_endpoints(provider, provider_cfg)

    # Generate CSRF state
    state = secrets.token_urlsafe(32)
    await OAuthStateManager.store_state(_session_store, state, request)

    # Build authorization URL
    client_id = provider_cfg.get("client_id", "")
    redirect_uri = provider_cfg.get(
        "redirect_uri", f"/api/v1/auth/oauth/{provider}/callback"
    )
    scope = resolved["scope"]
    response_type = str(provider_cfg.get("response_type", "code"))

    auth_query: dict[str, str] = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": response_type,
        "scope": scope,
        "state": state,
    }
    response_mode = provider_cfg.get("response_mode")
    if isinstance(response_mode, str) and response_mode.strip():
        auth_query["response_mode"] = response_mode.strip()

    response_type_tokens = {token.strip() for token in response_type.split() if token}
    if "id_token" in response_type_tokens:
        auth_query["nonce"] = secrets.token_urlsafe(24)

    query = urlencode(auth_query)
    auth_url = f"{resolved['authorization_url']}?{query}"

    return Redirect(path=auth_url)


@get("/providers")
async def oauth_providers() -> dict[str, Any]:
    """Return configured OAuth provider names for frontend runtime rendering."""
    oauth_config = get_oauth_config()
    providers_raw = oauth_config.get("providers", [])

    providers: list[str] = []
    if isinstance(providers_raw, list):
        providers = [p for p in providers_raw if isinstance(p, str)]
    elif isinstance(providers_raw, dict):
        providers = [str(k) for k in providers_raw]

    return {
        "enabled": bool(oauth_config.get("enabled", False)),
        "providers": providers,
    }


@get("/{provider:str}/callback")
async def oauth_callback(
    provider: str,
    request: Request[Any, Any, Any],
    code: str | None = None,
    oauth_state: str | None = None,
    error: str | None = None,
) -> Redirect:
    """Handle OAuth2 callback from provider.

    Full implementation of OAuth2 code exchange flow:
    1. Validate state against session store (CSRF protection)
    2. Exchange code for access_token via httpx call to provider's token_url
    3. Fetch userinfo from provider's userinfo_url
    4. Call OAuthService.auto_link_user() to find or create LocalUser
    5. Create server-side session
    6. Redirect to /desk/ with Set-Cookie: session_id=...

    Args:
        provider: OAuth provider name
        code: Authorization code from provider
        oauth_state: CSRF state parameter for validation (renamed from 'state' to
                     avoid Litestar's internal 'state' parameter conflict)
        error: Error from provider if authorization failed

    Returns:
        Redirect to /desk/ with session cookie set

    Raises:
        NotAuthorizedException: If OAuth flow fails (bad state, bad code, etc.)
    """
    if error:
        logger.warning(
            "oauth_callback_provider_error",
            extra={"provider": provider, "oauth_error": error},
        )
        raise NotAuthorizedException(detail=f"OAuth error: {error}")

    if code is None:
        logger.warning(
            "oauth_callback_missing_code",
            extra={"provider": provider},
        )
        raise NotAuthorizedException(detail="No authorization code received")

    provider_cfg = get_provider_config(provider)
    if provider_cfg is None:
        logger.warning(
            "oauth_callback_provider_not_configured",
            extra={"provider": provider},
        )
        raise NotFoundException(detail=f"OAuth provider '{provider}' not configured")

    resolved = await resolve_provider_endpoints(provider, provider_cfg)

    callback_state = oauth_state or request.query_params.get("state")

    # Step 1: State validation (CSRF protection)
    if callback_state is None:
        logger.warning(
            "oauth_callback_missing_state",
            extra={"provider": provider},
        )
        raise NotAuthorizedException(detail="Missing state parameter (CSRF protection)")

    state_redirect = await OAuthStateManager.validate_and_consume(
        _session_store, callback_state
    )

    # Step 2: Exchange code for tokens
    token_data = await OAuthHTTPClient.exchange_code_for_tokens(
        code=code,
        token_url=resolved["token_url"],
        provider_cfg=provider_cfg,
        default_scope=_DEFAULT_OIDC_SCOPE,
    )

    access_token: str | None = token_data.get("access_token")
    if not access_token:
        raise NotAuthorizedException(detail="Failed to get access token from provider")

    # Step 3: Fetch userinfo from provider
    userinfo = await OAuthHTTPClient.fetch_userinfo(
        provider=provider,
        access_token=access_token,
        userinfo_url=resolved.get("userinfo_url", ""),
        emails_url=resolved.get("emails_url"),
    )

    provider_user_id = extract_provider_user_id(provider, userinfo)
    if not provider_user_id:
        raise NotAuthorizedException(
            detail="Could not determine user identity from provider"
        )

    email: str | None = extract_email(provider, userinfo)
    email_verified = is_email_verified(provider, userinfo)
    display_name: str = (
        userinfo.get("name")
        or userinfo.get("login")  # GitHub
        or userinfo.get("preferred_username")
        or email
        or provider_user_id
    )

    # Step 4: Find or create local user
    if _oauth_service is None:
        raise NotAuthorizedException(
            detail="OAuth service not configured. Run 'm create-admin' to set up."
        )

    user = await _oauth_service.auto_link_user(
        provider=provider,
        provider_user_id=provider_user_id,
        email=email,
        email_verified=email_verified,
        display_name=display_name,
    )

    # Step 5: Create server-side session
    if _session_store is None:
        raise NotAuthorizedException(detail="Session store not configured")

    session_data = await _session_store.create(
        user_id=str(user.id),
        ip_address=None,
        user_agent=None,
    )
    session_id = session_data.session_id

    # Step 6: Redirect to /desk/ with Set-Cookie
    # NOTE: Litestar Redirect doesn't support setting headers directly.
    # The cookie is included in the redirect response by using a Response object.
    # We return a Redirect and rely on after-response middleware to set the cookie,
    # OR we set a custom response with both redirect + cookie.
    # For simplicity, we use a Response with 302 status and Set-Cookie header.
    from litestar.response import Response

    cookie_value = f"{session_id}; HttpOnly; SameSite=Lax; Path=/; Max-Age=1209600"
    redirect_target = get_post_login_redirect(state_redirect)
    return Response(  # type: ignore[return-value]
        content=b"",
        status_code=302,
        headers={
            "location": redirect_target,
            "set-cookie": f"session_id={cookie_value}",
        },
    )


def _is_admin_request(request: Request[Any, Any, Any]) -> bool:
    """Check whether request is admin-authorized for diagnostics routes."""
    user = getattr(request.state, "user", None)
    roles = getattr(user, "roles", None)
    if isinstance(roles, list) and any(str(role).lower() == "admin" for role in roles):
        return True

    header_roles = request.headers.get("x-roles", "") if request.headers else ""
    return any(role.strip().lower() == "admin" for role in header_roles.split(","))


@get("/{provider:str}/diagnostics")
async def provider_diagnostics(
    provider: str,
    request: Request[Any, Any, Any],
) -> dict[str, Any]:
    """Admin-only diagnostics for OAuth provider endpoint resolution."""
    if not _is_admin_request(request):
        logger.warning(
            "oauth_diagnostics_forbidden",
            extra={"provider": provider},
        )
        raise NotAuthorizedException(detail="Admin role required")

    provider_cfg = get_provider_config(provider)
    if provider_cfg is None and provider not in PROVIDER_CONFIGS:
        return {
            "provider": provider,
            "configured": False,
            "resolution": "unconfigured",
        }

    effective_provider_cfg = provider_cfg or {}
    resolved = await resolve_provider_endpoints(provider, effective_provider_cfg)

    resolution = "explicit"
    if provider in PROVIDER_CONFIGS:
        resolution = "built-in"
    elif effective_provider_cfg.get("discovery_url"):
        resolution = "discovery"

    return {
        "provider": provider,
        "configured": True,
        "resolution": resolution,
        "authorization_url": resolved.get("authorization_url"),
        "token_url": resolved.get("token_url"),
        "userinfo_url": resolved.get("userinfo_url"),
        "scope": resolved.get("scope"),
    }


# =============================================================================
# Router
# =============================================================================


oauth_routes_router = Router(
    path="/api/v1/auth/oauth",
    route_handlers=[oauth_start, oauth_providers, oauth_callback, provider_diagnostics],
    tags=["auth"],
)


__all__ = [
    "configure_oauth_routes",
    "get_oauth_config",
    "get_provider_config",
    "oauth_callback",
    "provider_diagnostics",
    "oauth_routes_router",
    "oauth_start",
]
