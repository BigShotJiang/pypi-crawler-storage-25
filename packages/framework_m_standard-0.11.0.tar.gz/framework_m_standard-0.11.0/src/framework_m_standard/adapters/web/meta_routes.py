"""Metadata Routes - DocType metadata API.

This module provides the metadata API endpoint for retrieving DocType
schema, layout, and permissions information.

Endpoint:
    GET /api/meta/{doctype}

Returns DocType metadata including:
- JSON Schema (from Pydantic model_json_schema())
- UI configuration (from Meta.ui_meta)
- Permissions (from Meta.permissions)
- Additional metadata (requires_auth, apply_rls, etc.)

Example:
    GET /api/meta/Invoice
    {
        "doctype": "Invoice",
        "schema": {...},
        "permissions": {...},
        "metadata": {
            "requires_auth": true,
            "apply_rls": true,
            "rls_field": "owner",
            "api_resource": true
        }
    }
"""

from __future__ import annotations

from typing import Any

from framework_m_core.registry import (
    MetaRegistry,
    UIContextRegistry,
)
from litestar import Request, Router, get
from litestar.di import Provide
from litestar.exceptions import NotFoundException
from sqlalchemy.ext.asyncio import AsyncSession

from framework_m_standard.adapters.web.middleware.locale import provide_locale


@get("/roles")
async def list_roles(
    search: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> dict[str, Any]:
    """List active roles across all registered DocTypes.

    Supports in-memory pagination and search, safely iterating over
    the cached singleton registry.
    """
    registry = MetaRegistry.get_instance()
    roles = registry.list_active_roles()

    if search:
        search_lower = search.lower()
        roles = [r for r in roles if search_lower in r.lower()]

    total = len(roles)
    return {
        "items": roles[offset : offset + limit],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


@get("/{doctype:str}")
async def get_doctype_metadata(
    doctype: str,
    request: Request[Any, Any, Any],
    locale: str,
    ui_context: str | None = None,
) -> dict[str, Any]:
    """Get DocType metadata including schema, layout, and permissions.

    Automatically translates field labels based on the resolved locale
    from Accept-Language header, user preference, tenant default, or system default.
    Results are cached to improve performance.

    Args:
        doctype: The DocType name (e.g., "Invoice")
        request: Litestar request object (for accessing state/session)
        locale: Resolved locale from middleware (injected)

    Returns:
        Dict containing schema, layout, permissions, and metadata
        with translated field labels if available
    """
    from framework_m_standard.adapters.factory import get_cache

    # Get tenant ID for cache partitioning
    tenant_ctx = getattr(request.state, "tenant", None)
    tenant_id: str | None = tenant_ctx.tenant_id if tenant_ctx else None

    # Try cache first
    cache = get_cache()
    context_suffix = ui_context.lower() if isinstance(ui_context, str) else "default"
    cache_key = f"meta:{doctype}:{locale}:{tenant_id or 'default'}:{context_suffix}"
    cached_metadata = await cache.get(cache_key)
    if cached_metadata:
        return cached_metadata  # type: ignore[no-any-return]

    registry = MetaRegistry.get_instance()

    # Get DocType class from registry
    try:
        doctype_class = registry.get_doctype(doctype)
    except KeyError:
        raise NotFoundException(
            detail=f"DocType '{doctype}' not found"
        ) from None  # pragma: no cover

    # Generate JSON Schema from Pydantic model
    schema = doctype_class.model_json_schema()

    # Apply decorators
    from framework_m_core.metadata_decorator import MetadataDecoratorRegistry
    from framework_m_core.schema_enrichment import enrich_schema

    schema = MetadataDecoratorRegistry.get_instance().apply(doctype, schema)

    # Post-process schema for frontend: resolve $refs, inline enum options,
    # consolidate validation constraints into ui_meta.
    schema = enrich_schema(schema)

    # Translate field labels if i18n adapter is available
    try:
        from framework_m_core.doctypes.tenant_translation import TenantTranslation
        from framework_m_core.doctypes.translation import Translation

        from framework_m_standard.adapters.db.generic_repository import (
            GenericRepository,
        )
        from framework_m_standard.adapters.i18n import DefaultI18nAdapter

        # Get session from request state if available
        session: AsyncSession | None = getattr(request.state, "db_session", None)

        if session and "properties" in schema:
            # Create i18n adapter with tenant translation support
            from framework_m_standard.adapters.db.table_registry import TableRegistry

            table_registry = TableRegistry()
            translation_table = table_registry.get_table("Translation")
            tenant_translation_table = table_registry.get_table("TenantTranslation")

            translation_repo = GenericRepository(Translation, translation_table)
            tenant_translation_repo = GenericRepository(
                TenantTranslation, tenant_translation_table
            )
            i18n_adapter = DefaultI18nAdapter(
                translation_repo=translation_repo,  # type: ignore[arg-type]
                tenant_translation_repo=tenant_translation_repo,  # type: ignore[arg-type]
                default_locale="en",
            )

            # Translate field descriptions (labels)
            for _field_name, field_schema in schema["properties"].items():
                if "description" in field_schema:
                    original_desc = field_schema["description"]
                    translated_desc = await i18n_adapter.translate(
                        original_desc,
                        locale=locale,
                        session=session,
                        translation_context="field_label",
                        tenant_id=tenant_id,
                    )
                    if translated_desc != original_desc:
                        field_schema["description"] = translated_desc

                if "title" in field_schema:
                    original_title = field_schema["title"]
                    translated_title = await i18n_adapter.translate(
                        original_title,
                        locale=locale,
                        session=session,
                        translation_context="field_label",
                        tenant_id=tenant_id,
                    )
                    if translated_title != original_title:
                        field_schema["title"] = translated_title

    except (ImportError, AttributeError):  # pragma: no cover
        pass  # pragma: no cover

    # Get permissions
    permissions = doctype_class.get_permissions()

    # Get additional metadata
    metadata_flags = {
        "requires_auth": doctype_class.get_requires_auth(),
        "apply_rls": doctype_class.get_apply_rls(),
        "rls_field": doctype_class.get_rls_field(),
        "api_resource": doctype_class.get_api_resource(),
    }

    meta_class = getattr(doctype_class, "Meta", None)
    base_ui_meta = getattr(meta_class, "ui_meta", None)
    ui_registry = UIContextRegistry.get_instance()
    resolved_ui_meta = ui_registry.resolve_ui_meta(
        doctype_name=doctype,
        base_ui_meta=base_ui_meta if isinstance(base_ui_meta, dict) else None,
        context=ui_context,
    )

    if doctype_class.get_is_aggregate_root():
        additional_views = resolved_ui_meta.setdefault("additional_views", {})
        if isinstance(additional_views, dict):
            additional_views.setdefault(
                "aggregate_root",
                {
                    "children": [
                        {"resource": child}
                        for child in doctype_class.get_aggregate_children()
                    ]
                },
            )

    # Collect custom plugin meta namespaces (e.g. wms_meta, mobile_meta)
    custom_namespaces = doctype_class.get_custom_meta_namespaces()

    result = {
        "doctype": doctype,
        "schema": schema,
        "permissions": permissions,
        "ui_meta": resolved_ui_meta,
        "metadata": metadata_flags,
        "locale": locale,
        "ui_context": ui_context,
        **custom_namespaces,
    }

    # Cache the result (expire in 1 hour by default)
    await cache.set(cache_key, result, ttl=3600)

    return result


# Create router
meta_routes_router = Router(
    path="/api/meta",
    route_handlers=[list_roles, get_doctype_metadata],
    tags=["Metadata"],
    dependencies={"locale": Provide(provide_locale, sync_to_thread=False)},
)


__all__ = ["get_doctype_metadata", "list_roles", "meta_routes_router"]
