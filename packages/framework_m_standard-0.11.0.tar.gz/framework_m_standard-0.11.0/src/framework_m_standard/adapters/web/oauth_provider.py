"""OAuth provider configuration and identity extraction utilities."""

from typing import Any

from framework_m_core.config import load_config
from litestar.exceptions import NotFoundException

from framework_m_standard.adapters.web.oauth_client import OAuthHTTPClient

_DEFAULT_OIDC_SCOPE = "openid email profile"

# Well-known OAuth2 provider configurations
PROVIDER_CONFIGS: dict[str, dict[str, str]] = {
    "google": {
        "authorization_url": "https://accounts.google.com/o/oauth2/v2/auth",
        "token_url": "https://oauth2.googleapis.com/token",
        "userinfo_url": "https://www.googleapis.com/oauth2/v3/userinfo",
        "scope": _DEFAULT_OIDC_SCOPE,
    },
    "github": {
        "authorization_url": "https://github.com/login/oauth/authorize",
        "token_url": "https://github.com/login/oauth/access_token",
        "userinfo_url": "https://api.github.com/user",
        "emails_url": "https://api.github.com/user/emails",
        "scope": "read:user user:email",
    },
    "microsoft": {
        "authorization_url": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
        "token_url": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        "userinfo_url": "https://graph.microsoft.com/v1.0/me",
        "scope": _DEFAULT_OIDC_SCOPE,
    },
}


def get_oauth_config() -> dict[str, Any]:
    """Get OAuth configuration from framework_config.toml."""
    config = load_config()
    auth_config = config.get("auth", {})
    oauth_config = auth_config.get("oauth", {})

    return {
        "enabled": oauth_config.get("enabled", False),
        "providers": oauth_config.get("providers", []),
        **{k: v for k, v in oauth_config.items() if k not in ("enabled", "providers")},
    }


def get_provider_config(provider: str) -> dict[str, Any] | None:
    """Get configuration for a specific OAuth provider."""
    oauth_config = get_oauth_config()
    providers = oauth_config.get("providers", [])

    if isinstance(providers, dict):
        provider_cfg = providers.get(provider)
        return provider_cfg if isinstance(provider_cfg, dict) else None

    if provider not in providers:
        return None

    result: dict[str, Any] | None = oauth_config.get(provider, {})
    return result if result else None


def get_post_login_redirect(state_redirect: str | None = None) -> str:
    """Get post-login redirect URL for OAuth callback success."""
    oauth_config = get_oauth_config()
    redirect_target = oauth_config.get("post_login_redirect")
    if isinstance(redirect_target, str) and redirect_target.strip():
        return redirect_target.strip()

    if state_redirect:
        return state_redirect

    return "/desk"


def get_oidc_well_known(provider_cfg: dict[str, Any]) -> dict[str, str] | None:
    """Get OIDC well-known config for generic OIDC provider."""
    if "authorization_url" in provider_cfg and "token_url" in provider_cfg:
        return {
            "authorization_url": str(provider_cfg["authorization_url"]),
            "token_url": str(provider_cfg["token_url"]),
            "userinfo_url": str(provider_cfg.get("userinfo_url", "")),
            "scope": str(provider_cfg.get("scope", _DEFAULT_OIDC_SCOPE)),
        }
    return None


def is_generic_oidc_provider(provider: str) -> bool:
    """Check if provider is a generic OIDC provider (not in well-known list)."""
    return provider not in PROVIDER_CONFIGS


async def resolve_provider_endpoints(
    provider: str,
    provider_cfg: dict[str, Any],
) -> dict[str, str]:
    """Resolve provider endpoints in priority order."""
    built_in = PROVIDER_CONFIGS.get(provider)
    if built_in is not None:
        resolved = dict(built_in)
        if provider_cfg.get("scope"):
            resolved["scope"] = str(provider_cfg["scope"])
        return resolved

    discovery_url = provider_cfg.get("discovery_url")
    if isinstance(discovery_url, str) and discovery_url:
        discovered = await OAuthHTTPClient.fetch_discovery_metadata(discovery_url)
        discovered["scope"] = str(provider_cfg.get("scope", _DEFAULT_OIDC_SCOPE))
        if provider_cfg.get("emails_url"):
            discovered["emails_url"] = str(provider_cfg["emails_url"])
        return discovered

    explicit = get_oidc_well_known(provider_cfg)
    if explicit is not None:
        return explicit

    raise NotFoundException(
        detail=(
            f"OAuth provider '{provider}' requires discovery_url or "
            "authorization_url and token_url"
        )
    )


def extract_email(provider: str, userinfo: dict[str, Any]) -> str | None:
    """Extract email from provider userinfo dict."""
    email = userinfo.get("email")
    if email:
        return str(email)

    if provider == "microsoft":
        mail = userinfo.get("mail") or userinfo.get("userPrincipalName")
        if mail:
            return str(mail)

    return None


def extract_provider_user_id(provider: str, userinfo: dict[str, Any]) -> str:
    """Extract canonical provider user id from userinfo payload."""
    if provider == "github":
        github_id = userinfo.get("id") or userinfo.get("node_id") or userinfo.get("sub")
        return str(github_id or "")

    oidc_id = userinfo.get("sub") or userinfo.get("id")
    return str(oidc_id or "")


def is_email_verified(provider: str, userinfo: dict[str, Any]) -> bool:
    """Determine whether provider email is verified and trusted for auto-link."""
    email_verified = userinfo.get("email_verified")
    if isinstance(email_verified, bool):
        return email_verified

    if isinstance(email_verified, str):
        return email_verified.lower() == "true"

    if provider == "github" and userinfo.get("email"):
        return bool(userinfo.get("email_verified", False))

    return False
