"""
Discovery services for frontend micro-frontends (MFE) and shells.

This module provides functions to discover installed frontend plugins and determine
the active UI shell at runtime, based on Python entry points and environment variables.
"""

import base64
import importlib.metadata
import importlib.resources
import json
import os
from importlib.resources.abc import Traversable


def discover_mfe_remotes() -> dict[str, str]:
    """
    Discover MFE remotes from installed packages and configuration.

    1. Scans for packages that register a `framework_m.frontend` entry point and
       verifies that they have a pre-built `static/mfe/remoteEntry.js`.
    2. Loads extra remotes from `FRAMEWORK_M_MFE_REMOTES` (JSON or Base64 JSON).
    3. Loads extra remotes from `FRAMEWORK_M_MFE_REMOTES_FILE` (Path to JSON).

    Returns:
        A dictionary mapping the MFE name to its remote entry URL.
        Example: `{"wms_app": "/mfe/wms_app/1.2.3/remoteEntry.js"}`

    Environment Variables:
        FRAMEWORK_M_STATIC_BASE_URL: Base URL for absolute CDN/MFE paths.
        FRAMEWORK_M_MFE_REMOTES: JSON string or Base64-encoded JSON string of extra remotes.
        FRAMEWORK_M_MFE_REMOTES_FILE: path to a JSON file containing extra remotes.
    """
    base_url = os.getenv("FRAMEWORK_M_STATIC_BASE_URL", "").rstrip("/")
    remotes: dict[str, str] = {}

    # 1. Discover from entry points
    try:
        eps = list(importlib.metadata.entry_points(group="framework_m.frontend"))
    except Exception:
        eps = []

    for ep in eps:
        package_name = ep.module.split(".")[0]
        try:
            # Check for the existence of the MFE entry file
            mfe_entry_path = (
                importlib.resources.files(package_name)
                / "static"
                / "mfe"
                / "remoteEntry.js"
            )
            if not mfe_entry_path.is_file():
                continue

            version = importlib.metadata.version(package_name)
            url = f"{base_url}/mfe/{ep.name}/{version}/remoteEntry.js"
            remotes[ep.name] = url
        except (ModuleNotFoundError, importlib.metadata.PackageNotFoundError):
            continue

    # 2. Add extra remotes from environment (JSON or Base64)
    extra_env = os.getenv("FRAMEWORK_M_MFE_REMOTES")
    if extra_env:
        try:
            # Try to decode as Base64 first
            try:
                decoded = base64.b64decode(extra_env, validate=True).decode("utf-8")
                extra_data = json.loads(decoded)
            except (ValueError, Exception):
                # Fallback to plain JSON
                extra_data = json.loads(extra_env)

            if isinstance(extra_data, dict):
                remotes.update(extra_data)
        except (json.JSONDecodeError, Exception):
            pass

    # 3. Add extra remotes from file
    extra_file_path = os.getenv("FRAMEWORK_M_MFE_REMOTES_FILE")
    if extra_file_path and os.path.exists(extra_file_path):
        try:
            with open(extra_file_path) as f:
                extra_data = json.load(f)
                if isinstance(extra_data, dict):
                    remotes.update(extra_data)
        except (json.JSONDecodeError, Exception):
            pass

    return remotes


def discover_active_shell() -> Traversable:
    """
    Discover the active UI shell application.

    The shell is determined by the `framework_m.shell` entry point.
    - If no entry point is found, it defaults to the bundled `framework-m-standard` shell.
    - If one is found, it uses that application's shell.
    - If multiple are found, it raises a ValueError unless disambiguated by the
      `FRAMEWORK_M_ACTIVE_SHELL` environment variable.

    Returns:
        A path-like object (Traversable) to the static directory of the active shell.
    """
    try:
        shell_eps = list(importlib.metadata.entry_points(group="framework_m.shell"))
    except Exception:
        shell_eps = []

    if not shell_eps:
        return importlib.resources.files("framework_m_standard") / "static"

    if len(shell_eps) > 1:
        active_shell_name = os.getenv("FRAMEWORK_M_ACTIVE_SHELL")
        if not active_shell_name:
            raise ValueError(
                "Multiple 'framework_m.shell' entry points found. Set FRAMEWORK_M_ACTIVE_SHELL to resolve."
            )

        selected_eps = [ep for ep in shell_eps if ep.name == active_shell_name]
        if not selected_eps:
            raise ValueError(
                f"FRAMEWORK_M_ACTIVE_SHELL is set to '{active_shell_name}', but no matching entry point was found."
            )
        shell_eps = selected_eps

    selected_ep = shell_eps[0]
    package_name = selected_ep.module.split(".")[0]
    return importlib.resources.files(package_name) / "static"
