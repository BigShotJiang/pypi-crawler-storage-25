"""Pure HTTP client for OAuth2/OIDC operations."""

from typing import Any

from litestar.exceptions import NotAuthorizedException

from framework_m_standard.adapters.auth.oauth import OAuthAdapter


class OAuthHTTPClient:
    """Stateless client for fetching OIDC metadata and exchanging tokens."""

    @staticmethod
    async def fetch_discovery_metadata(discovery_url: str) -> dict[str, str]:
        """Fetch and normalize OIDC discovery metadata endpoints."""
        try:
            import httpx
        except ImportError as e:  # pragma: no cover
            raise NotAuthorizedException(
                detail="httpx is required for OIDC discovery"
            ) from e

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(discovery_url, timeout=10.0)
                if response.status_code != 200:
                    raise NotAuthorizedException(
                        detail=f"OIDC discovery failed: {response.status_code}"
                    )
                payload = response.json()
        except httpx.HTTPError as e:
            raise NotAuthorizedException(
                detail=f"OIDC discovery network error: {e}"
            ) from e

        authorization_url = payload.get("authorization_endpoint")
        token_url = payload.get("token_endpoint")
        userinfo_url = payload.get("userinfo_endpoint", "")

        if not authorization_url or not token_url:
            raise NotAuthorizedException(
                detail="OIDC discovery payload missing required endpoints"
            )

        return {
            "authorization_url": str(authorization_url),
            "token_url": str(token_url),
            "userinfo_url": str(userinfo_url),
        }

    @staticmethod
    async def fetch_userinfo(
        provider: str,
        access_token: str,
        userinfo_url: str,
        emails_url: str | None = None,
    ) -> dict[str, Any]:
        """Fetch user info from provider's userinfo endpoint."""
        try:
            import httpx
        except ImportError as e:  # pragma: no cover
            raise NotAuthorizedException(
                detail="httpx is required for OAuth userinfo fetch"
            ) from e

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
        }

        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(userinfo_url, headers=headers, timeout=10.0)
                if resp.status_code != 200:
                    raise NotAuthorizedException(
                        detail=f"Failed to fetch userinfo: {resp.status_code}"
                    )

                userinfo: dict[str, Any] = resp.json()

                # GitHub doesn't always include email in /user — fetch from /user/emails
                if provider == "github" and not userinfo.get("email") and emails_url:
                    emails_resp = await client.get(
                        emails_url, headers=headers, timeout=10.0
                    )
                    if emails_resp.status_code == 200:
                        emails = emails_resp.json()
                        primary = next(
                            (
                                e
                                for e in emails
                                if e.get("primary") and e.get("verified")
                            ),
                            None,
                        )
                        if primary:
                            userinfo["email"] = primary["email"]
                            userinfo["email_verified"] = True

                return userinfo
        except httpx.HTTPError as e:
            raise NotAuthorizedException(
                detail=f"Network error fetching userinfo: {e}"
            ) from e

    @staticmethod
    async def exchange_code_for_tokens(
        code: str, token_url: str, provider_cfg: dict[str, Any], default_scope: str
    ) -> dict[str, Any]:
        """Exchange OAuth2 authorization code for tokens."""
        try:
            adapter = OAuthAdapter(
                provider_name=str(provider_cfg.get("provider", "oidc")),
                client_id=str(provider_cfg.get("client_id", "")),
                client_secret=str(provider_cfg.get("client_secret", "")),
                authorization_url=str(provider_cfg.get("authorization_url", "")),
                token_url=token_url,
                userinfo_url=str(provider_cfg.get("userinfo_url", "")),
                scope=str(provider_cfg.get("scope", default_scope)),
                token_endpoint_auth_method=str(
                    provider_cfg.get(
                        "token_endpoint_auth_method", "client_secret_basic"
                    )
                ),
            )
            token = await adapter.exchange_code(
                code=code, redirect_uri=str(provider_cfg.get("redirect_uri", ""))
            )
        except Exception as e:
            raise NotAuthorizedException(detail=f"Token exchange failed: {e}") from e

        return {
            "access_token": token.access_token,
            "token_type": token.token_type,
            "expires_in": token.expires_in,
            "refresh_token": token.refresh_token,
            "scope": token.scope,
        }
