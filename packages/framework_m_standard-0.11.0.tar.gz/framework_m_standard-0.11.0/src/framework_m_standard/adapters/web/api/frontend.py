"""API endpoints for frontend configuration and discovery."""

from framework_m_standard.adapters.web.frontend_discovery import discover_mfe_remotes
from litestar import Controller, Router, get


class FrontendController(Controller):
    """Controller for frontend-related API endpoints."""

    path = "/api/v1/frontend"

    @get("/remotes")
    async def get_remotes(self) -> dict[str, str]:
        """Discover and return all registered Micro-Frontend (MFE) remotes."""
        return discover_mfe_remotes()


frontend_router = Router(path="", route_handlers=[FrontendController])
