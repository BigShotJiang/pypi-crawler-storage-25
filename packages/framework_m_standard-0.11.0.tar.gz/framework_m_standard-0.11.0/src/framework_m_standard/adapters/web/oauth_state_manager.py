"""OAuth state management and CSRF protection."""

from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.parse import urlparse

from litestar.connection import Request
from litestar.exceptions import NotAuthorizedException

_OAUTH_STATE_TTL_SECONDS = 600
_STATE_REDIRECT_PREFIX = "post_login_redirect:"


class OAuthStateManager:
    """Stateless manager for OAuth CSRF state and redirect inference."""

    @staticmethod
    async def store_state(
        session_store: Any | None, state: str, request: Request[Any, Any, Any]
    ) -> None:
        """Store the generated OAuth state in the session store."""
        if session_store is None:
            return

        inferred_redirect = OAuthStateManager.infer_state_post_login_redirect(request)
        user_agent = (
            f"{_STATE_REDIRECT_PREFIX}{inferred_redirect}"
            if inferred_redirect
            else None
        )

        await session_store.create(
            user_id=f"oauth_state:{state}",
            ip_address=None,
            user_agent=user_agent,
        )

    @staticmethod
    async def validate_and_consume(
        session_store: Any | None, oauth_state: str
    ) -> str | None:
        """Validate persisted OAuth state and invalidate it after verification."""
        if session_store is None:
            raise NotAuthorizedException(detail="Session store not configured")

        state_user_id = f"oauth_state:{oauth_state}"
        state_sessions = await session_store.list_for_user(state_user_id)
        if not state_sessions:
            raise NotAuthorizedException(detail="Invalid or expired OAuth state")

        now = datetime.now(UTC)
        is_valid = False
        state_redirect: str | None = None

        for state_session in state_sessions:
            if state_redirect is None:
                state_redirect = OAuthStateManager.extract_state_redirect(
                    getattr(state_session, "user_agent", None)
                )

            created_at = getattr(state_session, "created_at", None)
            if created_at is None:
                is_valid = True
                continue

            if (
                created_at.tzinfo is None
                or created_at.tzinfo.utcoffset(created_at) is None
            ):
                created_at = created_at.replace(tzinfo=UTC)

            if now - created_at <= timedelta(seconds=_OAUTH_STATE_TTL_SECONDS):
                is_valid = True

        # Consume/delete the state so it can't be reused
        for state_session in state_sessions:
            state_session_id = getattr(state_session, "session_id", None)
            if state_session_id:
                await session_store.delete(state_session_id)

        if not is_valid:
            raise NotAuthorizedException(detail="Invalid or expired OAuth state")

        return state_redirect

    @staticmethod
    def extract_state_redirect(value: Any) -> str | None:
        """Extract validated post-login redirect marker from state session metadata."""
        if not isinstance(value, str) or not value.startswith(_STATE_REDIRECT_PREFIX):
            return None
        candidate = value[len(_STATE_REDIRECT_PREFIX) :].strip()
        return (
            candidate
            if OAuthStateManager.is_allowed_state_redirect(candidate)
            else None
        )

    @staticmethod
    def is_allowed_state_redirect(value: str) -> bool:
        """Allow only local frontend dev redirect targets for state-derived redirects."""
        parsed = urlparse(value)
        if parsed.scheme not in {"http", "https"}:
            return False
        return parsed.netloc in {
            "localhost:5173",
            "127.0.0.1:5173",
        } and parsed.path in {"/desk", "/desk/"}

    @staticmethod
    def infer_state_post_login_redirect(request: Request[Any, Any, Any]) -> str | None:
        """Infer frontend dev redirect from request origin/referrer when applicable."""
        headers = getattr(request, "headers", None)
        if headers is None:
            return None

        for key in ("origin", "referer"):
            val = headers.get(key)
            if isinstance(val, str) and val:
                parsed = urlparse(val)
                if parsed.scheme and parsed.netloc:
                    origin = f"{parsed.scheme}://{parsed.netloc}"
                    if OAuthStateManager.is_allowed_state_redirect(f"{origin}/desk"):
                        return f"{origin}/desk"
        return None
