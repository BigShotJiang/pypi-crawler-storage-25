"""OpenTelemetry Tracing Integration.

Provides setup functions to instrument the application, database,
and cache layers for distributed tracing.
"""

import logging

from litestar import Litestar

logger = logging.getLogger(__name__)

try:
    from opentelemetry.instrumentation.litestar import (  # type: ignore[import-not-found]
        LitestarInstrumentor,
    )
    from opentelemetry.instrumentation.redis import (  # type: ignore[import-not-found,unused-ignore]
        RedisInstrumentor,
    )
    from opentelemetry.instrumentation.sqlalchemy import (  # type: ignore[import-not-found,unused-ignore]
        SQLAlchemyInstrumentor,
    )

    OPENTELEMETRY_AVAILABLE = True
except ImportError:
    OPENTELEMETRY_AVAILABLE = False


def setup_tracing(app: Litestar) -> None:
    """Initialize OpenTelemetry instrumentation.

    Instruments the Litestar ASGI application, SQLAlchemy engines,
    and Redis clients if the OpenTelemetry packages are installed.

    Args:
        app: The Litestar application instance.
    """
    if not OPENTELEMETRY_AVAILABLE:
        logger.debug("OpenTelemetry tracing dependencies not installed. Skipping.")
        return

    # Instrument Litestar HTTP routes
    try:
        LitestarInstrumentor().instrument_app(app)
    except Exception as e:
        logger.warning("Failed to instrument Litestar: %s", e)

    # Instrument SQLAlchemy (hooks into engine creation globally)
    try:
        SQLAlchemyInstrumentor().instrument()
    except Exception as e:
        logger.warning("Failed to instrument SQLAlchemy: %s", e)

    # Instrument Redis (hooks into redis client globally)
    try:
        RedisInstrumentor().instrument()
    except Exception as e:
        logger.warning("Failed to instrument Redis: %s", e)
