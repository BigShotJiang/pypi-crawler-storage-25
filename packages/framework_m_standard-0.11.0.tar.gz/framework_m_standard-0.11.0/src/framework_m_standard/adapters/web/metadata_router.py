"""Metadata API Routes.

This module provides metadata discovery endpoints:
- GET /api/meta/doctypes - List all registered DocTypes
- GET /api/meta/{doctype} - Get DocType schema (in meta_router.py)

These endpoints enable the frontend to dynamically discover
available DocTypes and build UI from schema.

Per ARCHITECTURE.md:
- Code-first Pydantic models
- MetaRegistry singleton holds all DocTypes
"""

import re
from typing import Any, TypedDict, cast

from framework_m_core.registry import MetaRegistry
from litestar import Request, Router, get
from pydantic import BaseModel, ConfigDict


def _to_title_case(text: str) -> str:
    """Convert PascalCase or camelCase to Title Case."""
    if not text:
        return text
    # Add space before capital letters and trim
    return re.sub(r"([A-Z])", r" \1", text).strip()


def _normalize_nullable_property(property_schema: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(property_schema)

    type_value = normalized.get("type")
    if isinstance(type_value, list):
        non_null_types = [t for t in type_value if isinstance(t, str) and t != "null"]
        if len(non_null_types) == 1:
            normalized["type"] = non_null_types[0]

    any_of = normalized.get("anyOf")
    if isinstance(any_of, list):
        non_null = [
            item
            for item in any_of
            if isinstance(item, dict) and item.get("type") != "null"
        ]
        if len(non_null) == 1:
            merged = {**non_null[0], **normalized}
            merged["type"] = non_null[0].get("type", normalized.get("type"))
            merged.pop("anyOf", None)
            return merged

    return normalized


def _merge_ui_meta_to_property(
    prop: dict[str, Any], field_meta: dict[str, Any]
) -> dict[str, Any]:
    """Merge UI-specific metadata into a schema property."""
    if not field_meta:
        return prop
    # Merge field_meta into prop, giving priority to field_meta for UI-specific keys
    return {**prop, **field_meta}


def _normalize_schema(
    schema: dict[str, Any], ui_meta: dict[str, Any] | None = None
) -> dict[str, Any]:
    normalized = dict(schema)
    properties = normalized.get("properties")
    if not isinstance(properties, dict):
        return normalized

    ui_fields = ui_meta.get("fields", {}) if ui_meta else {}

    normalized["properties"] = {
        key: _merge_ui_meta_to_property(
            _normalize_nullable_property(value) if isinstance(value, dict) else value,
            ui_fields.get(key, {}),
        )
        for key, value in properties.items()
    }
    return normalized


class DocTypeInfo(BaseModel):
    """Brief DocType info for listing."""

    name: str
    module: str | None = None
    label: str | None = None
    show_in_desk: bool = True
    is_child_table: bool = False
    is_singleton: bool = False
    metadata: dict[str, bool | str | int | float] = {}

    # Allow extra fields for custom metadata
    model_config = ConfigDict(extra="allow")


class DocTypeListResponse(BaseModel):
    """Response structure for listing DocTypes."""

    doctypes: list[DocTypeInfo]
    count: int


@get("/doctypes", tags=["Metadata"])
async def list_doctypes(request: Request[Any, Any, Any]) -> DocTypeListResponse:
    """List registered DocTypes with metadata discovery.

    Returns summary info for each DocType and its whitelisted
    metadata flags. Supports dynamic filtering via query parameters.

    Example:
        GET /api/meta/doctypes?show_in_desk=true

    Returns:
        List of whitelisted DocType info objects
    """
    registry = MetaRegistry.get_instance()
    whitelisted_keys = registry.get_whitelisted_meta_keys()
    doctype_names = registry.list_doctypes()

    # Extract all whitelisted filters from query params
    # and implement strict boolean casting
    filters: dict[str, Any] = {}
    for key, value in request.query_params.items():
        if key in whitelisted_keys:
            if value.lower() == "true":
                filters[key] = True
            elif value.lower() == "false":
                filters[key] = False
            else:
                filters[key] = value

    doctypes_info: list[DocTypeInfo] = []
    for name in doctype_names:
        try:
            doctype_class = registry.get_doctype(name)
            meta_flags = doctype_class.get_meta_flags()

            # Filter DocTypes based on whitelisted query params
            match = True
            for f_key, f_val in filters.items():
                if meta_flags.get(f_key) != f_val:
                    match = False
                    break

            if not match:
                continue

            # Only return whitelisted metadata flags
            response_metadata = {
                k: v for k, v in meta_flags.items() if k in whitelisted_keys
            }

            # Finalize metadata labeling - use Title Case fallback for name
            raw_label = response_metadata.get("label")
            label = str(raw_label) if raw_label else _to_title_case(name)

            doctypes_info.append(
                DocTypeInfo(
                    name=name,
                    module=str(getattr(doctype_class, "__module__", "")),
                    label=label,
                    show_in_desk=cast(bool, meta_flags.get("show_in_desk", False)),
                    is_child_table=cast(bool, meta_flags.get("is_child_table", False)),
                    is_singleton=cast(bool, meta_flags.get("is_singleton", False)),
                    metadata={
                        k: v for k, v in meta_flags.items() if k in whitelisted_keys
                    },
                )
            )
        except (KeyError, AttributeError):
            continue

    return DocTypeListResponse(
        doctypes=doctypes_info,
        count=len(doctypes_info),
    )


class DocTypeMetadata(BaseModel):
    """Core metadata flags for frontend consumption."""

    label: str
    is_child_table: bool
    is_singleton: bool = False
    api_resource: bool
    requires_auth: bool
    apply_rls: bool

    # Allow extra flags from plugins
    model_config = ConfigDict(extra="allow")


class DocTypeSchemaResponse(TypedDict, total=False):
    """Response structure for a specific DocType's full schema."""

    doctype: str
    module: str | None
    schema: dict[str, Any]
    ui_meta: dict[str, Any] | None
    layout: dict[str, Any] | None
    permissions: dict[str, Any]
    metadata: DocTypeMetadata


@get("/{doctype_name:str}", tags=["Metadata"])
async def get_doctype_schema(doctype_name: str) -> DocTypeSchemaResponse:
    """Get schema for a specific DocType.

    Returns the full JSON Schema, layout, and permissions for the DocType.

    Args:
        doctype_name: Name of the DocType

    Returns:
        DocType schema including fields, layout, permissions

    Raises:
        NotFoundException: If DocType is not registered
    """
    from litestar.exceptions import NotFoundException

    registry = MetaRegistry.get_instance()

    try:
        doctype_class = registry.get_doctype(doctype_name)
    except KeyError as e:
        raise NotFoundException(f"DocType '{doctype_name}' not found") from e

    # Generate JSON Schema from Pydantic model and apply decorators
    raw_schema = doctype_class.model_json_schema()
    from framework_m_core.metadata_decorator import MetadataDecoratorRegistry

    decorated_schema = MetadataDecoratorRegistry.get_instance().apply(
        doctype_name, raw_schema
    )
    ui_meta = doctype_class.get_ui_meta()
    schema = _normalize_schema(decorated_schema, ui_meta)

    # Extract metadata from Meta class
    meta = getattr(doctype_class, "Meta", None)

    response = DocTypeSchemaResponse(
        doctype=doctype_name,
        module=getattr(doctype_class, "__module__", None),
        schema=schema,
        ui_meta=ui_meta,
        layout=getattr(meta, "layout", None) if meta else None,
        permissions=doctype_class.get_permissions(),
        metadata=DocTypeMetadata(
            label=getattr(meta, "label", _to_title_case(doctype_name))
            if meta
            else _to_title_case(doctype_name),
            is_child_table=doctype_class.get_is_child_table(),
            is_singleton=doctype_class.get_is_singleton(),
            api_resource=doctype_class.get_api_resource(),
            requires_auth=doctype_class.get_requires_auth(),
            apply_rls=doctype_class.get_apply_rls(),
        ),
    )

    # Include all custom metadata namespaces (e.g., wms_meta, mobile_meta)
    custom_meta = doctype_class.get_custom_meta_namespaces()
    response.update(custom_meta)  # type: ignore

    return response


# Create router with /api/meta prefix
metadata_router = Router(
    path="/api/meta",
    route_handlers=[list_doctypes, get_doctype_schema],
    tags=["Metadata"],
)


__all__ = ["get_doctype_schema", "list_doctypes", "metadata_router"]
