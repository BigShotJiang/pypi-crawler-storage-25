"""Correction API routes (RFC-0008 UI Step UI-1.1/UI-1.2 scaffolding).

This module exposes correction endpoints that are intentionally injectable for TDD:
- POST /api/v1/{doctype}/{id}/amend
- POST /api/v1/{doctype}/{id}/restore
- POST /api/v1/{doctype}/{id}/in_place_edit
- GET  /api/v1/ActivityLog

Runtime wiring can inject callables/services via app.state:
- correction_document_loader(doctype: str, doc_id: str) -> BaseDocType | None
- correction_snapshot_loader(doctype: str, doc_id: str, version_no: int) -> dict | None
- correction_service with amend/restore/in_place_edit methods
- correction_versioning_enabled: bool (optional, defaults to True)
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from datetime import datetime
from typing import Any, Protocol, cast

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.audit import AuditEntry
from framework_m_core.interfaces.auth_context import UserContext
from litestar import Request, Router, get, post
from litestar.exceptions import (
    ClientException,
    NotAuthorizedException,
    NotFoundException,
)
from pydantic import BaseModel, Field


class _CorrectionServiceLike(Protocol):
    """Protocol for correction service implementations used by the router."""

    async def amend(
        self,
        doc: BaseDocType,
        reason: str,
        user: UserContext,
    ) -> BaseDocType: ...

    async def restore(
        self,
        doc: BaseDocType,
        snapshot_data: dict[str, Any],
        reason: str,
        user: UserContext,
    ) -> BaseDocType: ...

    async def in_place_edit(
        self,
        doc: BaseDocType,
        reason: str,
        user: UserContext,
    ) -> BaseDocType: ...


class CorrectionRequest(BaseModel):
    """Request payload for amend/in_place_edit."""

    reason: str = Field(..., min_length=1)


class RestoreRequest(CorrectionRequest):
    """Request payload for restore."""

    version_no: int = Field(..., ge=1)


class ActivityLogItem(BaseModel):
    """ActivityLog API response item."""

    id: str
    timestamp: datetime
    user_id: str
    action: str
    doctype_name: str
    document_id: str
    diff: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None


class ActivityLogListResponse(BaseModel):
    """Paginated ActivityLog list response."""

    items: list[ActivityLogItem]
    total: int
    limit: int
    offset: int


def _resolve_user(request: Request[Any, Any, Any]) -> UserContext | None:
    """Resolve authenticated user from request state or legacy headers."""
    user = getattr(request.state, "user", None)
    if isinstance(user, UserContext):
        return user

    user_id = request.headers.get("x-user-id")
    if not user_id:
        return None

    roles_header = request.headers.get("x-roles", "")
    tenants_header = request.headers.get("x-tenants", "")
    roles = [role.strip() for role in roles_header.split(",") if role.strip()]
    tenants = [tenant.strip() for tenant in tenants_header.split(",") if tenant.strip()]

    return UserContext(
        id=user_id,
        email=request.headers.get("x-user-email", ""),
        roles=roles,
        tenants=tenants,
    )


def _require_user(request: Request[Any, Any, Any]) -> UserContext:
    """Raise 401 when no authenticated user context is available."""
    user = _resolve_user(request)
    if user is None:
        raise NotAuthorizedException("Authentication required")
    return user


def _get_document_loader(
    request: Request[Any, Any, Any],
) -> Callable[[str, str], Awaitable[BaseDocType | None]]:
    loader = getattr(request.app.state, "correction_document_loader", None)
    if callable(loader):
        return cast(Callable[[str, str], Awaitable[BaseDocType | None]], loader)
    raise ClientException(
        status_code=503,
        detail="Correction document loader is not configured",
    )


def _get_snapshot_loader(
    request: Request[Any, Any, Any],
) -> Callable[[str, str, int], Awaitable[dict[str, Any] | None]]:
    loader = getattr(request.app.state, "correction_snapshot_loader", None)
    if callable(loader):
        return cast(Callable[[str, str, int], Awaitable[dict[str, Any] | None]], loader)
    raise ClientException(
        status_code=503,
        detail="Correction snapshot loader is not configured",
    )


def _get_correction_service(
    request: Request[Any, Any, Any],
) -> _CorrectionServiceLike:
    service = getattr(request.app.state, "correction_service", None)
    if service is None:
        raise ClientException(
            status_code=503,
            detail="Correction service is not configured",
        )
    return cast(_CorrectionServiceLike, service)


def _is_versioning_enabled(request: Request[Any, Any, Any]) -> bool:
    """Check if versioning is enabled for restore operations."""
    override = getattr(request.app.state, "correction_versioning_enabled", None)
    if isinstance(override, bool):
        return override
    return True


@post("/{doctype:str}/{doc_id:str}/amend", status_code=200)
async def amend_document(
    doctype: str,
    doc_id: str,
    data: CorrectionRequest,
    request: Request[Any, Any, Any],
) -> dict[str, Any]:
    """Amend a submitted document and return the newly created draft."""
    user = _require_user(request)
    loader = _get_document_loader(request)
    service = _get_correction_service(request)

    doc = await loader(doctype, doc_id)
    if doc is None:
        raise NotFoundException(detail=f"{doctype} with id '{doc_id}' not found")

    try:
        corrected = await service.amend(doc=doc, reason=data.reason, user=user)
    except ValueError as exc:
        raise ClientException(status_code=422, detail=str(exc)) from exc

    return dict(corrected.model_dump())


@post("/{doctype:str}/{doc_id:str}/restore", status_code=200)
async def restore_document(
    doctype: str,
    doc_id: str,
    data: RestoreRequest,
    request: Request[Any, Any, Any],
) -> dict[str, Any]:
    """Restore a document using a historical snapshot version."""
    user = _require_user(request)
    loader = _get_document_loader(request)
    snapshot_loader = _get_snapshot_loader(request)
    service = _get_correction_service(request)

    if not _is_versioning_enabled(request):
        raise ClientException(
            status_code=400,
            detail="Versioning must be enabled for restore",
        )

    doc = await loader(doctype, doc_id)
    if doc is None:
        raise NotFoundException(detail=f"{doctype} with id '{doc_id}' not found")

    snapshot_data = await snapshot_loader(doctype, doc_id, data.version_no)
    if snapshot_data is None:
        raise ClientException(
            status_code=400,
            detail=f"Snapshot version {data.version_no} not found",
        )

    try:
        restored = await service.restore(
            doc=doc,
            snapshot_data=snapshot_data,
            reason=data.reason,
            user=user,
        )
    except ValueError as exc:
        raise ClientException(status_code=422, detail=str(exc)) from exc

    return dict(restored.model_dump())


@post("/{doctype:str}/{doc_id:str}/in_place_edit", status_code=200)
async def in_place_edit_document(
    doctype: str,
    doc_id: str,
    data: CorrectionRequest,
    request: Request[Any, Any, Any],
) -> dict[str, Any]:
    """Reset a submitted document to draft in-place after snapshotting."""
    user = _require_user(request)
    loader = _get_document_loader(request)
    service = _get_correction_service(request)

    doc = await loader(doctype, doc_id)
    if doc is None:
        raise NotFoundException(detail=f"{doctype} with id '{doc_id}' not found")

    try:
        corrected = await service.in_place_edit(doc=doc, reason=data.reason, user=user)
    except ValueError as exc:
        message = str(exc)
        status_code = 400 if "VersionedMixin" in message else 422
        raise ClientException(status_code=status_code, detail=message) from exc

    return dict(corrected.model_dump())


@get("/ActivityLog")
async def list_activity_logs(
    request: Request[Any, Any, Any],
    document_id: str | None = None,
    doctype_name: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> ActivityLogListResponse:
    """List activity log entries with document and doctype filters.

    This endpoint is intentionally explicit for UI use-cases where the frontend
    queries `/api/v1/ActivityLog?document_id=...&doctype_name=...`.
    """
    audit_adapter = getattr(request.app.state, "audit_adapter", None)
    if audit_adapter is None or not hasattr(audit_adapter, "query"):
        raise ClientException(status_code=503, detail="Audit adapter is not configured")

    filters: dict[str, Any] = {}
    if document_id:
        filters["document_id"] = document_id
    if doctype_name:
        # Audit adapter expects protocol field name `doctype`.
        filters["doctype"] = doctype_name

    entries: list[AuditEntry] = await audit_adapter.query(
        filters=filters or None,
        limit=max(1, limit),
        offset=max(0, offset),
    )

    sorted_entries = sorted(entries, key=lambda entry: entry.timestamp, reverse=True)

    items = [
        ActivityLogItem(
            id=entry.id,
            timestamp=entry.timestamp,
            user_id=entry.user_id,
            action=entry.action,
            doctype_name=entry.doctype,
            document_id=entry.document_id,
            diff=entry.changes,
            metadata=entry.metadata,
        )
        for entry in sorted_entries
    ]

    return ActivityLogListResponse(
        items=items,
        total=len(items),
        limit=max(1, limit),
        offset=max(0, offset),
    )


correction_router = Router(
    path="/api/v1",
    route_handlers=[
        amend_document,
        restore_document,
        in_place_edit_document,
        list_activity_logs,
    ],
    tags=["Corrections", "ActivityLog"],
)


__all__ = [
    "ActivityLogItem",
    "ActivityLogListResponse",
    "CorrectionRequest",
    "RestoreRequest",
    "amend_document",
    "correction_router",
    "in_place_edit_document",
    "list_activity_logs",
    "restore_document",
]
