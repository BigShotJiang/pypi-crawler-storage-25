"""Structured Logging Middleware.

Provides JSON formatted logging and injects request context
like request_id and user_id into log records.
"""

import contextvars
import datetime
import logging
import uuid
from typing import Any

from litestar import Request
from litestar.types import ASGIApp, Receive, Scope, Send
from pythonjsonlogger.jsonlogger import JsonFormatter  # type: ignore[attr-defined]

_request_ctx_var: contextvars.ContextVar[Request[Any, Any, Any]] = (
    contextvars.ContextVar("request")
)


class RequestContextFilter(logging.Filter):
    """Filter that injects request context data into log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            request = _request_ctx_var.get()
        except LookupError:
            return True

        if hasattr(request.state, "request_id"):
            record.request_id = request.state.request_id

        user = getattr(request.state, "user", None)
        if user and hasattr(user, "id"):
            record.user_id = user.id

        return True


class CustomJsonFormatter(JsonFormatter):
    """Custom JSON formatter for structured logging."""

    def add_fields(
        self,
        log_record: dict[str, Any],
        record: logging.LogRecord,
        message_dict: dict[str, Any],
    ) -> None:
        super().add_fields(log_record, record, message_dict)
        if not log_record.get("timestamp"):
            now = datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
            log_record["timestamp"] = now

        if hasattr(record, "request_id"):
            log_record["request_id"] = record.request_id
        if hasattr(record, "user_id"):
            log_record["user_id"] = record.user_id


class LoggingMiddleware:
    """Middleware to inject request context for structured logging."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        request = Request[Any, Any, Any](scope)

        # Extract or generate request ID
        request_id = request.headers.get("x-request-id")
        if not request_id:
            request_id = str(uuid.uuid4())

        request.state.request_id = request_id

        token = _request_ctx_var.set(request)
        try:
            await self.app(scope, receive, send)
        finally:
            _request_ctx_var.reset(token)
