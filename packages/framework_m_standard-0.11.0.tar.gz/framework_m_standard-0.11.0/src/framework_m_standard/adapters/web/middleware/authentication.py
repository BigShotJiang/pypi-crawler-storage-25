"""Authentication Middleware for Framework M (BFF Cookie Mode).

This middleware authenticates requests using an AuthChain strategy:
1. SessionCookieAuth — HttpOnly session cookie (primary, for browser clients)
2. BearerTokenAuth — JWT in Authorization header (for API/mobile clients)
3. HeaderAuth — Gateway headers (for federated/enterprise deployments)

Excluded paths bypass authentication entirely:
- /health, /schema
- /api/v1/auth/login, /api/v1/auth/logout (login endpoints themselves)
- /api/v1/auth/oauth/ (OAuth2 redirect flows)
- /desk (frontend static assets)

Example:
    from framework_m_standard.adapters.web.auth_middleware import create_auth_middleware

    app = Litestar(
        middleware=[create_auth_middleware(auth_chain=chain, require_auth=True)],
    )
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from framework_m_core.interfaces.auth_context import UserContext
from litestar.middleware.base import DefineMiddleware

if TYPE_CHECKING:
    from litestar.types import ASGIApp, Receive, Scope, Send

    from framework_m_standard.adapters.auth.strategies import AuthChain


# Default paths that bypass authentication completely (chain not run)
DEFAULT_EXCLUDED_PATHS: list[str] = [
    "/health",
    "/schema",
    "/api/v1/auth/login",
    "/api/v1/auth/logout",
    "/api/v1/auth/oauth/",
    "/desk",
]

# Paths where auth chain runs (to inject user context) but 401 is NOT enforced.
# Useful for /me — always accessible but reports auth state when logged in.
DEFAULT_NON_ENFORCED_PATHS: list[str] = [
    "/api/v1/auth/me",
]

# Anonymous access is allowed for safe/read-only methods.
# Mutating methods still require authentication.
SAFE_METHODS: set[str] = {"GET", "HEAD", "OPTIONS"}


class AuthMiddleware:
    """Middleware that authenticates requests via an AuthChain.

    Delegates authentication to a chain of strategies. On success, stores
    the resolved UserContext in request.state.user. On failure, either
    returns 401 (if require_auth=True) or continues with user=None.

    Authentication strategies tried in order:
    1. SessionCookieAuth (cookie header)
    2. BearerTokenAuth (Authorization header)
    3. HeaderAuth (gateway x-user-id headers, federated mode)

    Attributes:
        app: The wrapped ASGI application
        auth_chain: Chain of authentication strategies to try
        require_auth: If True, returns 401 when no strategy authenticates
        excluded_paths: List of path prefixes that bypass auth check
    """

    def __init__(
        self,
        app: ASGIApp,
        auth_chain: AuthChain | None = None,
        require_auth: bool = True,
        excluded_paths: list[str] | None = None,
        non_enforced_paths: list[str] | None = None,
    ) -> None:
        """Initialize the authentication middleware.

        Args:
            app: The ASGI application
            auth_chain: AuthChain with ordered strategies. Falls back to
                        legacy header-only mode if None (for backwards compat).
            require_auth: Whether to return 401 if no strategy authenticates
            excluded_paths: Paths that completely bypass auth (chain not run)
            non_enforced_paths: Paths where chain runs to inject context,
                                but 401 is NOT returned if unauthenticated.
                                Use for endpoints like /me that are always
                                accessible but show auth state when logged in.
        """
        self.app = app
        self.auth_chain = auth_chain
        self.require_auth = require_auth
        self.excluded_paths = excluded_paths or DEFAULT_EXCLUDED_PATHS
        self.non_enforced_paths = non_enforced_paths or DEFAULT_NON_ENFORCED_PATHS

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Process the request and resolve user context via AuthChain.

        Args:
            scope: ASGI scope
            receive: ASGI receive callable
            send: ASGI send callable
        """
        scope_type = scope["type"]
        if scope_type != "http":  # type: ignore[comparison-overlap]
            await self.app(scope, receive, send)
            return

        # Check if path is excluded from auth
        path: str = scope.get("path", "")
        if self._is_excluded_path(path):
            await self.app(scope, receive, send)
            return

        # For non-enforced paths: run chain to inject context, but no 401
        is_non_enforced = self._is_non_enforced_path(path)
        method = str(scope.get("method", "GET")).upper()

        # Build a lowercase-keyed headers dict for strategy consumption
        raw_headers: list[tuple[bytes, bytes]] = list(scope.get("headers", []))
        headers: dict[str, str] = {
            k.decode("latin-1").lower(): v.decode("latin-1") for k, v in raw_headers
        }

        # Authenticate via chain
        user: UserContext | None = None
        if self.auth_chain is not None:
            user = await self.auth_chain.authenticate(headers)
        else:
            # Legacy fallback: hydrate from gateway headers directly
            user_id = headers.get("x-user-id")
            if user_id:
                roles_str = headers.get("x-roles", "")
                tenants_str = headers.get("x-tenants", "")
                roles = [r.strip() for r in roles_str.split(",") if r.strip()]
                tenants = [t.strip() for t in tenants_str.split(",") if t.strip()]
                user = UserContext(
                    id=user_id,
                    email=headers.get("x-user-email", ""),
                    roles=roles,
                    tenants=tenants,
                )

        # Require auth check (skip for non-enforced paths)
        if (
            self.require_auth
            and user is None
            and not is_non_enforced
            and method not in SAFE_METHODS
        ):
            await self._send_401_response(send)
            return

        # Store user context in ASGI scope state
        if "state" not in scope:
            scope["state"] = {}
        scope["state"]["user"] = user

        await self.app(scope, receive, send)

    async def _send_401_response(self, send: Send) -> None:
        """Send a 401 Unauthorized ASGI response.

        Args:
            send: ASGI send callable
        """
        import json

        body = json.dumps(
            {
                "status_code": 401,
                "detail": "Authentication required. Please log in.",
            }
        ).encode("utf-8")

        from litestar.types import HTTPResponseBodyEvent, HTTPResponseStartEvent

        start_event: HTTPResponseStartEvent = {
            "type": "http.response.start",
            "status": 401,
            "headers": [
                (b"content-type", b"application/json"),
                (b"content-length", str(len(body)).encode("utf-8")),
            ],
        }
        await send(start_event)

        body_event: HTTPResponseBodyEvent = {
            "type": "http.response.body",
            "body": body,
            "more_body": False,
        }
        await send(body_event)

    def _is_excluded_path(self, path: str) -> bool:
        """Check if path should completely bypass authentication."""
        for excluded in self.excluded_paths:
            if excluded == "/":
                if path == "/":
                    return True
                continue
            if path.startswith(excluded):
                return True
        return False

    def _is_non_enforced_path(self, path: str) -> bool:
        """Check if path runs auth chain but doesn't enforce 401."""
        return any(path.startswith(p) for p in self.non_enforced_paths)

    def _get_header(self, headers: dict[bytes, bytes], name: bytes) -> str | None:
        """Get a header value as string (legacy helper).

        Args:
            headers: Dict of header name -> value (both bytes)
            name: Header name to look up

        Returns:
            Header value as string, or None if not found
        """
        value = headers.get(name)
        if value is None:
            return None
        return value.decode("utf-8")

    def _parse_comma_separated(self, value: str | None) -> list[str]:
        """Parse a comma-separated string into a list.

        Args:
            value: Comma-separated string or None

        Returns:
            List of trimmed values, empty list if input is None or empty
        """
        if not value:
            return []
        return [item.strip() for item in value.split(",") if item.strip()]


def create_auth_middleware(
    auth_chain: Any | None = None,
    require_auth: bool = True,
    excluded_paths: list[str] | None = None,
    non_enforced_paths: list[str] | None = None,
) -> DefineMiddleware:
    """Create an authentication middleware configuration.

    Args:
        auth_chain: AuthChain instance. If None, falls back to legacy header mode.
        require_auth: If True, returns 401 when no strategy authenticates.
        excluded_paths: Paths that bypass auth completely (chain not run).
                       Defaults to DEFAULT_EXCLUDED_PATHS.
        non_enforced_paths: Paths where chain runs but 401 is not enforced.
                            Defaults to DEFAULT_NON_ENFORCED_PATHS.

    Returns:
        DefineMiddleware instance for use in Litestar
    """
    return DefineMiddleware(
        AuthMiddleware,
        auth_chain=auth_chain,
        require_auth=require_auth,
        excluded_paths=excluded_paths,
        non_enforced_paths=non_enforced_paths,
    )


__all__ = ["AuthMiddleware", "DEFAULT_EXCLUDED_PATHS", "create_auth_middleware"]
