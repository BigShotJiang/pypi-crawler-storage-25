"""Prometheus Metrics Middleware.

Collects HTTP request metrics (count, duration) and exposes them
via a /metrics endpoint.
"""

import time
from typing import Any

from litestar import get
from litestar.response import Response
from litestar.types import ASGIApp, Message, Receive, Scope, Send
from prometheus_client import (
    CONTENT_TYPE_LATEST,
    REGISTRY,
    Counter,
    Histogram,
    generate_latest,
)

# Define Prometheus metrics
HTTP_REQUESTS_TOTAL = Counter(
    "http_requests_total",
    "Total HTTP requests",
    ["method", "path", "status"],
)

HTTP_REQUEST_DURATION_SECONDS = Histogram(
    "http_request_duration_seconds",
    "HTTP request duration in seconds",
    ["method", "path", "status"],
)


@get("/metrics", sync_to_thread=False)
def metrics_endpoint() -> Response[bytes]:
    """Expose Prometheus metrics."""
    return Response(
        content=generate_latest(REGISTRY),
        media_type=CONTENT_TYPE_LATEST,
    )


class MetricsMiddleware:
    """Middleware to collect Prometheus metrics for HTTP requests."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":  # type: ignore[comparison-overlap]
            await self.app(scope, receive, send)
            return

        method = str(scope.get("method", "GET"))
        path = str(scope.get("path", ""))

        # Skip metrics collection for the metrics endpoint itself
        if path == "/metrics":
            await self.app(scope, receive, send)
            return

        start_time = time.perf_counter()
        status_code = 500

        async def send_wrapper(message: Message) -> None:
            nonlocal status_code
            if message["type"] == "http.response.start":
                status_code = int(message.get("status", 500))
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            duration = time.perf_counter() - start_time

            # Try to get the parameterized path to avoid high cardinality
            route_handler: Any = scope.get("route_handler")
            if (
                route_handler
                and hasattr(route_handler, "paths")
                and route_handler.paths
            ):
                paths = list(route_handler.paths)
                if paths:
                    path = str(paths[0])

            HTTP_REQUESTS_TOTAL.labels(
                method=method, path=path, status=str(status_code)
            ).inc()

            HTTP_REQUEST_DURATION_SECONDS.labels(
                method=method, path=path, status=str(status_code)
            ).observe(duration)
