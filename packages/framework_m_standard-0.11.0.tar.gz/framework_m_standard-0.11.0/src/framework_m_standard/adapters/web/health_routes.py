"""Health and Readiness Probes.

Provides endpoints for application monitoring and load balancing:
- GET /health: Basic health check (DB and Redis connectivity)
- GET /ready: Readiness check (DB migrations up to date)
"""

import inspect
from typing import Any

from litestar import Request, get
from litestar.response import Response

from framework_m_standard.adapters.db.migration_check import MigrationStatusUtility


@get("/health")
async def health_check(request: Request[Any, Any, Any]) -> Response[dict[str, str]]:
    """Health check endpoint.

    Returns basic health status for load balancers and monitoring.

    Returns:
        JSON response with status information.
    """
    engine = getattr(request.app.state, "engine", None)
    if engine is not None:
        try:
            async with engine.connect():
                pass
        except Exception:
            return Response(
                content={"status": "unhealthy", "database": "down"},
                status_code=503,
            )

    redis_url = getattr(request.app.state, "redis_url", None)
    if redis_url:
        try:
            import redis.asyncio as redis_async

            client = redis_async.from_url(redis_url)  # type: ignore[no-untyped-call,unused-ignore]
            ping_result = client.ping()
            if inspect.isawaitable(ping_result):
                await ping_result
            await client.aclose()
        except Exception:
            return Response(
                content={"status": "unhealthy", "redis": "down"},
                status_code=503,
            )

    return Response(content={"status": "healthy"}, status_code=200)


@get("/ready")
async def readiness_check(request: Request[Any, Any, Any]) -> Response[dict[str, str]]:
    """Readiness check endpoint.

    Checks if the application is ready to serve traffic,
    specifically verifying database migration status.

    Returns:
        JSON response with readiness status.
    """
    engine = getattr(request.app.state, "engine", None)
    if engine is None:
        return Response(
            content={"status": "not_ready", "detail": "Starting up"},
            status_code=503,
        )

    try:
        utility = MigrationStatusUtility(engine)
        if await utility.is_up_to_date():
            return Response(content={"status": "ready"}, status_code=200)
        return Response(
            content={"status": "not_ready", "detail": "Pending migrations"},
            status_code=503,
        )
    except Exception:
        return Response(
            content={"status": "not_ready", "detail": "Database error"},
            status_code=503,
        )


__all__ = ["health_check", "readiness_check"]
