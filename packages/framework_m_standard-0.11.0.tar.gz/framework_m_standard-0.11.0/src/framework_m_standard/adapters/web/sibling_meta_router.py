"""Sibling metadata API routes for Desk sibling overlay discovery."""

from __future__ import annotations

from framework_m_core.registry import MetaRegistry
from litestar import Router, get
from pydantic import BaseModel


class SiblingDocTypeInfo(BaseModel):
    """Sibling DocType metadata exposed to the frontend."""

    doctype: str
    label: str
    extends: str
    is_metadata_overlay: bool = False


class SiblingDocTypeListResponse(BaseModel):
    """Response payload for sibling metadata lookup."""

    siblings: list[SiblingDocTypeInfo]


@get("/{doctype:str}/siblings", tags=["Metadata"])
async def list_sibling_doctypes(doctype: str) -> SiblingDocTypeListResponse:
    """List sibling DocTypes where Meta.extends equals the parent doctype."""
    registry = MetaRegistry.get_instance()
    sibling_items: list[SiblingDocTypeInfo] = []

    for doctype_name in registry.list_doctypes():
        try:
            doctype_class = registry.get_doctype(doctype_name)
        except KeyError:
            continue

        meta = getattr(doctype_class, "Meta", None)
        extends = getattr(meta, "extends", None) if meta else None
        if extends != doctype:
            continue

        sibling_items.append(
            SiblingDocTypeInfo(
                doctype=doctype_name,
                label=getattr(meta, "label", doctype_name) if meta else doctype_name,
                extends=extends,
                is_metadata_overlay=(
                    bool(getattr(meta, "is_metadata_overlay", False)) if meta else False
                ),
            )
        )

    return SiblingDocTypeListResponse(siblings=sibling_items)


sibling_meta_router = Router(
    path="/api/v1/meta",
    route_handlers=[list_sibling_doctypes],
    tags=["Metadata"],
)


__all__ = [
    "SiblingDocTypeInfo",
    "SiblingDocTypeListResponse",
    "list_sibling_doctypes",
    "sibling_meta_router",
]
