"""Exception Handlers for the Litestar application.

Provides standard formatting for domain exceptions and maps them
to appropriate HTTP status codes.
"""

from typing import Any

from framework_m_core.exceptions import (
    DocTypeNotFoundError,
    DuplicateNameError,
    EntityNotFoundError,
    FrameworkError,
    PermissionDeniedError,
    ValidationError,
)
from litestar import Response
from litestar.exceptions import NotFoundException


def validation_error_handler(
    request: Any, exc: ValidationError
) -> Response[dict[str, Any]]:
    """Handle validation errors with 400 Bad Request.

    Args:
        request: The incoming request
        exc: The validation exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "ValidationError",
            "message": str(exc),
            "details": getattr(exc, "details", None),
        },
        status_code=400,
    )


def permission_denied_handler(
    request: Any, exc: PermissionDeniedError
) -> Response[dict[str, str]]:
    """Handle permission denied errors with 403 Forbidden.

    Args:
        request: The incoming request
        exc: The permission exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "PermissionDenied",
            "message": str(exc),
        },
        status_code=403,
    )


def not_found_handler(
    request: Any, exc: DocTypeNotFoundError | EntityNotFoundError
) -> Response[dict[str, str]]:
    """Handle not found errors with 404 Not Found.

    Args:
        request: The incoming request
        exc: The not found exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "NotFound",
            "message": str(exc),
        },
        status_code=404,
    )


def duplicate_name_handler(
    request: Any, exc: DuplicateNameError
) -> Response[dict[str, str]]:
    """Handle duplicate name errors with 409 Conflict.

    Args:
        request: The incoming request
        exc: The duplicate name exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "Conflict",
            "message": str(exc),
            "doctype": exc.doctype_name,
            "name": exc.name,
        },
        status_code=409,
    )


def framework_error_handler(
    request: Any, exc: FrameworkError
) -> Response[dict[str, str]]:
    """Handle generic framework errors with 500 Internal Server Error.

    Args:
        request: The incoming request
        exc: The framework exception

    Returns:
        JSON response with error details
    """
    return Response(
        content={
            "error": "InternalError",
            "message": str(exc),
        },
        status_code=500,
    )


def litestar_not_found_handler(
    request: Any, exc: NotFoundException
) -> Response[dict[str, Any]]:
    """Handle framework-level 404 errors without noisy uncaught tracebacks.

    This is used for unmatched routes (e.g. `/desk/` in API-only dev mode).
    """
    detail = getattr(exc, "detail", None) or "Not Found"
    return Response(
        content={
            "status_code": 404,
            "detail": str(detail),
        },
        status_code=404,
    )
