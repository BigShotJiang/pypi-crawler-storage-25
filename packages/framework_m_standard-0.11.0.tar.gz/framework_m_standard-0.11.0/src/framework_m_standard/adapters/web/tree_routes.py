"""Tree Routes — Hierarchical DocType data API.

Provides endpoints for:
- GET /api/tree/{doctype}        - Fetch full tree (or subtree)
- PATCH /api/tree/{doctype}/{id} - Reparent a node (drag-and-drop)
- POST /api/tree/{doctype}/add-child - Add a child node inline

These endpoints work for any DocType that has a `parent_field`
declared in its Meta class (e.g., ``parent_doctype`` or ``parent``).

Example DocType with tree support::

    class Territory(BaseDocType):
        class Meta:
            parent_field = "parent_territory"
            label_field = "name"
            order_field = "lft"

Example tree response::

    [
        {
            "id": "All Territories",
            "label": "All Territories",
            "children": [
                {"id": "North America", "label": "North America", "children": []},
                {"id": "Europe", "label": "Europe", "children": []}
            ]
        }
    ]
"""

from __future__ import annotations

from typing import Any

from framework_m_core.registry import MetaRegistry
from litestar import Router, get, patch, post
from litestar.exceptions import NotFoundException, ValidationException

try:
    from sqlalchemy import select
    from sqlalchemy.ext.asyncio import AsyncSession

    HAS_SQLALCHEMY = True
except ImportError:
    HAS_SQLALCHEMY = False


def _get_parent_field(doctype: str) -> tuple[str, str]:
    """Return (parent_field, label_field) from DocType Meta or defaults."""
    registry = MetaRegistry.get_instance()
    try:
        doctype_class = registry.get_doctype(doctype)
    except KeyError:
        raise NotFoundException(detail=f"DocType '{doctype}' not found") from None

    meta = getattr(doctype_class, "Meta", None)
    parent_field: str = getattr(meta, "parent_field", "parent")
    label_field: str = getattr(meta, "label_field", "name")
    return parent_field, label_field


def _build_tree(
    rows: list[dict[str, Any]],
    parent_field: str,
    label_field: str,
    parent_value: Any = None,
) -> list[dict[str, Any]]:
    """Recursively build a tree structure from flat rows."""
    nodes = []
    for row in rows:
        row_parent = row.get(parent_field)
        # Treat empty string and None as both meaning "root"
        is_root = (row_parent is None or row_parent == "") and (
            parent_value is None or parent_value == ""
        )
        is_child = str(row_parent) == str(parent_value) if not is_root else False

        if is_root or is_child:
            node: dict[str, Any] = {
                "id": row.get("id") or row.get("name"),
                "label": row.get(label_field) or row.get("name"),
                "data": {
                    k: v for k, v in row.items() if k not in ("id", "name", label_field)
                },
                "children": _build_tree(
                    rows,
                    parent_field,
                    label_field,
                    parent_value=row.get("id") or row.get("name"),
                ),
            }
            nodes.append(node)
    return nodes


@get("/{doctype:str}")
async def get_tree(
    doctype: str,
    request: Any,
    parent: str | None = None,
) -> dict[str, Any]:
    """Fetch hierarchical tree data for a DocType.

    Args:
        doctype: The DocType name (e.g., "Territory").
        request: Litestar request (provides db_session from state).
        parent: Optional root node ID for subtree fetch.

    Returns:
        ``{"doctype": ..., "parent_field": ..., "tree": [...]}``
    """
    parent_field, label_field = _get_parent_field(doctype)

    session: AsyncSession | None = getattr(request.state, "db_session", None)
    if session is None or not HAS_SQLALCHEMY:
        # Fallback: empty tree if DB unavailable
        return {"doctype": doctype, "parent_field": parent_field, "tree": []}

    # Use the generic document table
    from framework_m_standard.adapters.db.table_registry import TableRegistry

    table_registry = TableRegistry()
    try:
        table = table_registry.get_table(doctype)
    except Exception:
        return {"doctype": doctype, "parent_field": parent_field, "tree": []}

    stmt = select(table)
    result = await session.execute(stmt)
    rows = [dict(row._mapping) for row in result]

    tree = _build_tree(rows, parent_field, label_field, parent_value=parent or None)
    return {"doctype": doctype, "parent_field": parent_field, "tree": tree}


@patch("/{doctype:str}/{node_id:str}")
async def reparent_node(
    doctype: str,
    node_id: str,
    data: dict[str, Any],
    request: Any,
) -> dict[str, Any]:
    """Update a tree node (re-parent and/or rename).

    Args:
        doctype: The DocType name.
        node_id: ID of the node to move.
        data: Body with ``{"parent": "<new_parent_id>", "label": "<new_label>"}``
        request: Litestar request.

    Returns:
        ``{"ok": true, "id": node_id, "parent": new_parent, "label": ...}``
    """
    parent_field, label_field = _get_parent_field(doctype)

    has_parent = "parent" in data
    has_label = "label" in data
    if not has_parent and not has_label:
        raise ValidationException(detail="Body must contain 'parent' and/or 'label'")

    new_parent = data.get("parent") if has_parent else None
    new_label = data.get("label") if has_label else None

    session: AsyncSession | None = getattr(request.state, "db_session", None)
    if session is None or not HAS_SQLALCHEMY:
        return {"ok": True, "id": node_id, "parent": new_parent}

    from framework_m_standard.adapters.db.table_registry import TableRegistry

    table_registry = TableRegistry()
    try:
        table = table_registry.get_table(doctype)
    except Exception:
        raise NotFoundException(detail=f"Table for '{doctype}' not found") from None

    update_values: dict[str, Any] = {}
    if has_parent:
        update_values[parent_field] = new_parent or None
    if has_label:
        update_values[label_field] = new_label

    stmt = table.update().where(table.c.id == node_id).values(update_values)
    await session.execute(stmt)
    await session.commit()

    response: dict[str, Any] = {"ok": True, "id": node_id}
    if has_parent:
        response["parent"] = new_parent
    if has_label:
        response["label"] = new_label
    return response


@post("/{doctype:str}/add-child")
async def add_child_node(
    doctype: str,
    data: dict[str, Any],
    request: Any,
) -> dict[str, Any]:
    """Add a new child node inline.

    Args:
        doctype: The DocType name.
        data: Body with at minimum ``{"parent": "<parent_id>", "label": "<name>"}``
        request: Litestar request.

    Returns:
        Created node dict with ``id``.
    """
    parent_id: str | None = data.get("parent")
    label: str = data.get("label", "New Item")

    parent_field, label_field = _get_parent_field(doctype)

    session: AsyncSession | None = getattr(request.state, "db_session", None)
    if session is None or not HAS_SQLALCHEMY:
        # Return stub — real insert requires session
        return {"ok": True, "id": "temp", label_field: label, parent_field: parent_id}

    import uuid

    from framework_m_standard.adapters.db.table_registry import TableRegistry

    table_registry = TableRegistry()
    try:
        table = table_registry.get_table(doctype)
    except Exception:
        raise NotFoundException(detail=f"Table for '{doctype}' not found") from None

    new_id = str(uuid.uuid4())
    row_values: dict[str, Any] = {
        "id": new_id,
        label_field: label,
        parent_field: parent_id or None,
        **{k: v for k, v in data.items() if k not in ("parent", "label")},
    }
    stmt = table.insert().values(row_values)
    await session.execute(stmt)
    await session.commit()

    return {"ok": True, **row_values}


# Router — mounted at /api/tree
tree_routes_router = Router(
    path="/api/tree",
    route_handlers=[get_tree, reparent_node, add_child_node],
    tags=["Tree"],
)

__all__ = [
    "get_tree",
    "reparent_node",
    "add_child_node",
    "tree_routes_router",
]
