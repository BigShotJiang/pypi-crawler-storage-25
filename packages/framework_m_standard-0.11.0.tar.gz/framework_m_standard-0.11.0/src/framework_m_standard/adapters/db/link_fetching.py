"""Link Fetching Service - Auto-populates fields based on fetch_from metadata."""

from __future__ import annotations

from uuid import UUID

from framework_m_core.domain.base_doctype import BaseDocType
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from framework_m_standard.adapters.db.table_registry import TableRegistry


class LinkFetchingService[T: BaseDocType]:
    """Service for fetching values from linked documents.

    Processes fields with json_schema_extra={"fetch_from": "link.field"}
    and auto-populates them from the linked document.
    """

    def __init__(self, model: type[T]) -> None:
        """Initialize the link fetching service.

        Args:
            model: The DocType model class
        """
        self._model = model

    async def fetch_link_values(self, session: AsyncSession, entity: T) -> None:
        """Fetch values from linked documents based on fetch_from metadata.

        Example:
            customer: UUID | None = Field(json_schema_extra={"link": "Customer"})
            customer_name: str | None = Field(
                json_schema_extra={"fetch_from": "customer.customer_name"}
            )

        Args:
            session: SQLAlchemy async session
            entity: The entity to populate fetch fields for
        """
        # Track which link fields we need to check for manual overrides
        # Key: fetch_field_name, Value: (link_field_name, link_value)
        fetch_fields_to_check: dict[str, tuple[str, UUID | None]] = {}

        # First pass: identify all fetch fields and their link sources
        for field_name, field_info in self._model.model_fields.items():
            if not field_info.json_schema_extra or not isinstance(
                field_info.json_schema_extra, dict
            ):
                continue

            fetch_from = field_info.json_schema_extra.get("fetch_from")
            if not fetch_from or not isinstance(fetch_from, str):
                continue

            # Parse fetch_from: "link_field.target_field"
            parts = fetch_from.split(".", 1)
            if len(parts) != 2:
                continue

            link_field_name, _target_field_name = parts

            # Check if entity has the link field
            if not hasattr(entity, link_field_name):
                continue

            # Get link value
            link_value = getattr(entity, link_field_name, None)
            fetch_fields_to_check[field_name] = (link_field_name, link_value)

        if not fetch_fields_to_check:
            return

        table_registry = TableRegistry()

        # Second pass: fetch values
        for field_name, (link_field_name, link_value) in fetch_fields_to_check.items():
            if link_value is None:
                # No link set, set fetch field to None
                setattr(entity, field_name, None)
                continue

            # Re-fetch the target field name from metadata to avoid storing another mapping
            field_info = self._model.model_fields[field_name]
            fetch_from = field_info.json_schema_extra["fetch_from"]  # type: ignore[index]
            _, target_field_name = fetch_from.split(".", 1)  # type: ignore[union-attr]

            # Get link metadata to find target DocType
            link_field_info = self._model.model_fields.get(link_field_name)
            if not link_field_info or not link_field_info.json_schema_extra:
                continue

            target_doctype = link_field_info.json_schema_extra.get("link")  # type: ignore[union-attr]
            if not target_doctype or not isinstance(target_doctype, str):
                continue

            # Get target table from registry
            try:
                target_table = table_registry.get_table(target_doctype)
            except KeyError:
                # Target table not registered, skip
                continue

            # Query target document
            stmt = select(target_table).where(target_table.c.id == link_value)
            result = await session.execute(stmt)
            target_row = result.first()

            if target_row is None:
                # Linked document not found, set to None
                setattr(entity, field_name, None)
                continue

            # Only update if the target field actually exists
            if hasattr(target_table.c, target_field_name):
                fetched_value = getattr(target_row, target_field_name, None)
                setattr(entity, field_name, fetched_value)
