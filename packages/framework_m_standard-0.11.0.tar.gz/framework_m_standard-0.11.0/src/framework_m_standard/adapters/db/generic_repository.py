"""Generic Repository - SQLAlchemy implementation of RepositoryProtocol.

This module provides the GenericRepository class that implements standard
CRUD operations for DocTypes using SQLAlchemy async sessions.

Features:
- Automatic soft delete (deleted_at)
- Controller lifecycle hooks
- Optimistic Concurrency Control (OCC) support
- Name auto-generation
"""

from __future__ import annotations

import logging
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.exceptions import (
    DatabaseError,
    DuplicateNameError,
    IntegrityError,
    RepositoryError,
)
from framework_m_core.interfaces.repository import (
    FilterSpec,
    OrderSpec,
    PaginatedResult,
)
from sqlalchemy import Table, func, select, update
from sqlalchemy import delete as sql_delete
from sqlalchemy.exc import IntegrityError as SAIntegrityError
from sqlalchemy.exc import OperationalError, SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from framework_m_standard.adapters.db.cache_manager import RepoCacheManager
from framework_m_standard.adapters.db.child_table import ChildTableManager
from framework_m_standard.adapters.db.entity_mapper import EntityRowMapper
from framework_m_standard.adapters.db.event_publisher import RepositoryEventPublisher
from framework_m_standard.adapters.db.history_manager import HistoryManager
from framework_m_standard.adapters.db.link_fetching import LinkFetchingService
from framework_m_standard.adapters.db.naming import DocumentNamingService
from framework_m_standard.adapters.db.query_builder import QueryBuilder
from framework_m_standard.adapters.db.rls_manager import RLSManager
from framework_m_standard.adapters.db.singles_manager import SinglesManager

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from framework_m_core.domain.base_controller import BaseController
    from framework_m_core.interfaces.auth_context import UserContext
    from framework_m_core.interfaces.cache import CacheProtocol
    from framework_m_core.interfaces.event_bus import EventBusProtocol


class VersionConflictError(Exception):
    """Raised when optimistic concurrency control detects a conflict."""

    def __init__(self, entity_id: UUID, expected_version: int) -> None:
        """Initialize with conflict details.

        Args:
            entity_id: The ID of the entity with version conflict
            expected_version: The version that was expected
        """
        self.entity_id = entity_id
        self.expected_version = expected_version
        super().__init__(
            f"Version conflict for entity {entity_id}. "
            f"Expected version {expected_version}."
        )


class GenericRepository[T: BaseDocType]:
    """Generic SQLAlchemy repository implementing RepositoryProtocol.

    Provides standard CRUD operations for DocTypes using async SQLAlchemy.
    Supports controller lifecycle hooks and optimistic concurrency control.

    Note:
        This repository does NOT store sessions. All CRUD methods accept
        session as the first parameter. The caller owns the session via
        UnitOfWork context manager.

    Example:
        >>> repo = GenericRepository(
        ...     model=Todo,
        ...     table=todo_table,
        ...     controller_class=TodoController,
        ...     event_bus=InMemoryEventBus(),
        ... )
        >>> async with uow_factory() as uow:
        ...     todo = await repo.save(uow.session, entity)
    """

    def __init__(
        self,
        model: type[T],
        table: Table,
        controller_class: type[BaseController[T]] | None = None,
        event_bus: EventBusProtocol | None = None,
        cache: CacheProtocol | None = None,
        defaults_service: Any | None = None,
    ) -> None:
        """Initialize the repository.

        Args:
            model: The DocType model class
            table: SQLAlchemy Table object
            controller_class: Optional controller for lifecycle hooks
            event_bus: Optional event bus for publishing domain events
            defaults_service: Optional service for virtual singletons
            cache: Optional cache for query result caching
        """
        self._model = model
        self._table = table
        self._controller_class = controller_class
        self._event_bus = event_bus
        self._cache_manager = RepoCacheManager(cache, model)
        self._naming_service = DocumentNamingService(model, table)
        self._child_table_manager = ChildTableManager(model)
        self._mapper = EntityRowMapper(model, table, self._child_table_manager)
        self._event_publisher = RepositoryEventPublisher(model, event_bus)
        self._link_fetching_service = LinkFetchingService(model)
        self._rls_manager = RLSManager(self)
        self._history_manager = HistoryManager(self)
        self._singles_manager = SinglesManager(self, defaults_service)

    @property
    def model(self) -> type[T]:
        """Get the DocType model class."""
        return self._model

    @property
    def table(self) -> Table:
        """Get the SQLAlchemy table."""
        return self._table

    @property
    def controller_class(self) -> type[BaseController[T]] | None:
        """Get the controller class if set."""
        return self._controller_class

    @property
    def event_bus(self) -> EventBusProtocol | None:
        """Get the event bus if set."""
        return self._event_bus

    @property
    def cache(self) -> CacheProtocol | None:
        """Get the cache if set."""
        return self._cache_manager._cache

    async def get(
        self,
        session: AsyncSession,
        id: UUID,
        include_deleted: bool = False,
        as_of: datetime | None = None,
    ) -> T | None:
        """Retrieve an entity by its unique identifier.

        Args:
            session: SQLAlchemy async session
            id: The UUID of the entity
            include_deleted: If True, include soft-deleted entities

        Returns:
            The entity if found, None otherwise
        """
        if as_of is not None:
            return await self._history_manager.get_as_of(
                session, id, include_deleted, as_of
            )

        # Check cache first (only for non-deleted queries)
        if self._cache_manager.is_enabled and not include_deleted:
            cached = await self._cache_manager.get_by_id(id)
            if cached:
                logger.debug("CACHE HIT %s[%s]", self._model.__name__, id)
                return self._model.model_validate(cached)

        stmt = select(self._table).where(self._table.c.id == id)

        # Filter soft-deleted by default
        if not include_deleted and hasattr(self._table.c, "deleted_at"):
            stmt = stmt.where(self._table.c.deleted_at.is_(None))

        logger.debug(
            "GET %s[%s] (include_deleted=%s)",
            self._model.__name__,
            id,
            include_deleted,
        )

        result = await session.execute(stmt)
        row = result.first()

        if row is None:
            return None

        entity = self._mapper.row_to_entity(row)

        # Load child tables
        child_fields = self._child_table_manager.get_child_table_fields()
        if child_fields and entity:
            await self._child_table_manager.load_child_tables(
                session, entity, child_fields
            )

        # Resolve references for Zero-Overhead resolution
        if entity:
            import os

            from framework_m_standard.adapters.db.reference_resolver import (
                ReferenceResolver,
            )

            m_mode = os.environ.get("M_MODE", "indie").lower()
            if m_mode == "indie":
                await ReferenceResolver.resolve_indie(session, entity, self._model)
            elif m_mode == "enterprise":
                await ReferenceResolver.resolve_enterprise(
                    entity, self._model, self._event_bus
                )

        # Cache the result
        if self._cache_manager.is_enabled and entity and not include_deleted:
            await self._cache_manager.set_by_id(id, entity.model_dump(mode="json"))
            logger.debug("CACHE SET %s[%s]", self._model.__name__, id)

        return entity

    async def get_singleton(self, session: AsyncSession) -> T | None:
        """Retrieve the single instance of this DocType.

        Args:
            session: SQLAlchemy async session

        Returns:
            The entity if found, None otherwise
        """
        singleton_id = await self._singles_manager.get_singleton_id(session)
        if not singleton_id:
            return await self._singles_manager.get_virtual_singleton()
        return await self.get(session, singleton_id)

    async def get_by_name(
        self, session: AsyncSession, name: str, include_deleted: bool = False
    ) -> T | None:
        """Retrieve an entity by its human-readable name.

        Args:
            session: SQLAlchemy async session
            name: The name of the entity
            include_deleted: If True, include soft-deleted entities

        Returns:
            The entity if found, None otherwise
        """
        # Check cache first (only for non-deleted queries)
        if self._cache_manager.is_enabled and not include_deleted:
            cached = await self._cache_manager.get_by_name(name)
            if cached:
                logger.debug("CACHE HIT %s[name=%s]", self._model.__name__, name)
                return self._model.model_validate(cached)

        stmt = select(self._table).where(self._table.c.name == name)

        if not include_deleted and hasattr(self._table.c, "deleted_at"):
            stmt = stmt.where(self._table.c.deleted_at.is_(None))

        result = await session.execute(stmt)
        row = result.first()

        if row is None:
            return None

        entity = self._mapper.row_to_entity(row)

        # Cache result
        if self._cache_manager.is_enabled and entity and not include_deleted:
            entity_dump = entity.model_dump(mode="json")
            await self._cache_manager.set_by_name(name, entity_dump, ttl=300)
            if entity.id:
                await self._cache_manager.set_by_id(entity.id, entity_dump, ttl=300)

        return entity

    async def save(
        self, session: AsyncSession, entity: T, version: int | None = None
    ) -> T:
        """Persist an entity (insert or update).

        Args:
            session: SQLAlchemy async session
            entity: The entity to save
            version: Expected version for OCC (optional)

        Returns:
            The saved entity with updated fields

        Raises:
            VersionConflictError: If version doesn't match (OCC)
            DuplicateNameError: If name collision persists after retries
        """
        # For Singletons, ensure we update the existing record if it exists
        if self._model.get_is_singleton():
            await self._singles_manager.ensure_singleton_identity(session, entity)

        # Track if we auto-generated the name (for retry logic)
        auto_generated_name = entity.name is None

        # Generate name if not set
        if auto_generated_name:
            entity.name = await self._naming_service.generate_name(session, entity)

        # Apply deterministic ID strategy if configured
        meta = getattr(self._model, "Meta", None)
        if getattr(meta, "id_strategy", "random") == "deterministic" and entity.name:
            from framework_m_core.services.document_id import DocumentIdService

            id_service = DocumentIdService()
            entity.id = id_service.generate_deterministic_id(
                self._model.get_doctype_name(), entity.name
            )

        # Check if entity exists
        is_new = not await self._entity_exists(session, entity)

        # Get controller instance if available
        controller = self._get_controller(entity)

        if is_new:
            saved_entity = await self._insert_with_retry(
                session, entity, controller, auto_generated_name
            )
            await self._call_hook(controller, "after_naming")
            return saved_entity
        else:
            return await self._update(session, entity, controller, version)

    async def delete(self, session: AsyncSession, id: UUID, hard: bool = False) -> None:
        """Delete an entity by its unique identifier.

        By default performs soft-delete (sets deleted_at). Use hard=True
        for physical deletion.

        Args:
            session: SQLAlchemy async session
            id: The UUID of the entity to delete
            hard: If True, physically delete; otherwise soft-delete
        """
        # Get entity for lifecycle hooks and event emission
        entity = await self.get(session, id)
        controller = None
        if entity and self._controller_class is not None:
            controller = self._get_controller(entity)

        # Lifecycle: before_delete
        if controller:
            await controller.before_delete()

        # Delete child tables first (cascade)
        child_fields = self._child_table_manager.get_child_table_fields()
        if child_fields:
            await self._child_table_manager.delete_child_tables(
                session, id, child_fields
            )

        try:
            if hard:
                # Physical delete
                delete_stmt = sql_delete(self._table).where(self._table.c.id == id)
                await session.execute(delete_stmt)
            else:
                # Soft delete
                update_stmt = (
                    update(self._table)
                    .where(self._table.c.id == id)
                    .values(deleted_at=datetime.now(UTC))
                )
                await session.execute(update_stmt)
        except SAIntegrityError as e:
            error_msg = str(e.orig) if e.orig else str(e)
            logger.error("Delete failed for %s: %s", self._model.__name__, error_msg)
            raise IntegrityError(error_msg) from e
        except OperationalError as e:
            logger.error(
                "Database operation failed for %s: %s", self._model.__name__, str(e)
            )
            raise DatabaseError("delete", str(e)) from e
        except SQLAlchemyError as e:
            logger.error(
                "Unexpected database error for %s: %s", self._model.__name__, str(e)
            )
            raise RepositoryError(f"Delete failed: {e}") from e

        # Lifecycle: after_delete
        if controller:
            await controller.after_delete()

        # Emit delete event
        if entity:
            await self._event_publisher.emit_event("delete", entity)

        # Invalidate cache
        await self._cache_manager.invalidate(entity, id_to_invalidate=id)
        logger.debug("CACHE INVALIDATE %s[%s]", self._model.__name__, id)

    async def exists(self, session: AsyncSession, id: UUID) -> bool:
        """Check if an entity exists by its identifier.

        Args:
            session: SQLAlchemy async session
            id: The UUID to check

        Returns:
            True if entity exists and is not soft-deleted
        """
        stmt = (
            select(func.count()).select_from(self._table).where(self._table.c.id == id)
        )
        if hasattr(self._table.c, "deleted_at"):
            stmt = stmt.where(self._table.c.deleted_at.is_(None))

        result = await session.execute(stmt)
        count = result.scalar()
        return count is not None and count > 0

    async def count(
        self, session: AsyncSession, filters: list[FilterSpec] | None = None
    ) -> int:
        """Count entities matching the given filters.

        Args:
            session: SQLAlchemy async session
            filters: Optional list of filter conditions

        Returns:
            Total count of matching entities
        """
        stmt = select(func.count()).select_from(self._table)

        # Exclude soft-deleted
        if hasattr(self._table.c, "deleted_at"):
            stmt = stmt.where(self._table.c.deleted_at.is_(None))

        if filters:
            stmt = QueryBuilder.apply_filters(stmt, self._model, self._table, filters)

        result = await session.execute(stmt)
        return result.scalar() or 0

    async def list_entities(
        self,
        session: AsyncSession,
        filters: list[FilterSpec] | None = None,
        order_by: list[OrderSpec] | None = None,
        limit: int = 20,
        offset: int = 0,
        as_of: datetime | None = None,
    ) -> PaginatedResult[T]:
        """List entities with filtering, sorting, and pagination.

        Args:
            session: SQLAlchemy async session
            filters: Filter conditions
            order_by: Sort specifications
            limit: Maximum number of items (default 20, max 1000)
            offset: Number of items to skip

        Returns:
            PaginatedResult containing items and metadata
        """
        if as_of is not None:
            return await self._history_manager.list_entities_as_of(
                session=session,
                as_of=as_of,
                filters=filters,
                order_by=order_by,
                limit=limit,
                offset=offset,
            )

        # Enforce max limit
        effective_limit = min(limit, 1000)

        # Build base query
        stmt = select(self._table)

        # Exclude soft-deleted
        if hasattr(self._table.c, "deleted_at"):
            stmt = stmt.where(self._table.c.deleted_at.is_(None))

        if filters is not None:
            stmt = QueryBuilder.apply_filters(stmt, self._model, self._table, filters)

        # Get total count
        total = await self.count(session, filters)

        # Apply ordering
        if order_by is not None:
            stmt = QueryBuilder.apply_ordering(stmt, self._model, self._table, order_by)

        # Apply pagination
        stmt = stmt.limit(effective_limit).offset(offset)

        logger.debug(
            "LIST %s (filters=%d, order_by=%d, limit=%d, offset=%d)",
            self._model.__name__,
            len(filters) if filters else 0,
            len(order_by) if order_by else 0,
            effective_limit,
            offset,
        )

        result = await session.execute(stmt)
        rows = result.fetchall()

        items = [self._mapper.row_to_entity(row) for row in rows]

        # Load child tables efficiently (select_in_loading)
        if items:
            child_fields = self._child_table_manager.get_child_table_fields()
            if child_fields:
                parent_ids = [item.id for item in items]
                for field_name, child_model in child_fields.items():
                    from framework_m_standard.adapters.db.table_registry import (
                        TableRegistry,
                    )

                    table_registry = TableRegistry()
                    child_table = table_registry.get_table(child_model.__name__)
                    if child_table is not None:
                        children_by_parent = (
                            await self._child_table_manager.load_children_for_parents(
                                session,
                                parent_ids,
                                child_table,
                                child_model,
                            )
                        )
                        for item in items:
                            item_id_str = str(item.id)
                            setattr(
                                item,
                                field_name,
                                children_by_parent.get(item_id_str, []),
                            )

        return PaginatedResult(
            items=items,
            total=total,
            limit=effective_limit,
            offset=offset,
        )

    async def list_for_user(
        self,
        session: AsyncSession,
        user: UserContext | None,
        filters: list[FilterSpec] | None = None,
        order_by: list[OrderSpec] | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> PaginatedResult[T]:
        """List entities with RLS filtering applied.

        This method automatically applies Row-Level Security filters
        based on the user's permissions and the DocType's RLS settings.

        Args:
            session: SQLAlchemy async session
            user: Current user context (None for public access)
            filters: Additional filter conditions
            order_by: Sort specifications
            limit: Maximum number of items (default 20, max 1000)
            offset: Number of items to skip

        Returns:
            PaginatedResult containing only items the user can access
        """
        return await self._rls_manager.list_for_user(
            session=session,
            user=user,
            filters=filters,
            order_by=order_by,
            limit=limit,
            offset=offset,
        )

    async def get_for_user(
        self,
        session: AsyncSession,
        user: UserContext,
        id: UUID,
        action: str = "read",
        include_deleted: bool = False,
    ) -> T:
        """Retrieve an entity with permission checking.

        Loads the entity and verifies the user has permission to access it.
        Raises PermissionDeniedError if access is denied.

        Args:
            session: SQLAlchemy async session
            user: Current user context
            id: The UUID of the entity
            action: The action to check (default: "read")
            include_deleted: If True, include soft-deleted entities

        Returns:
            The entity if found and accessible

        Raises:
            EntityNotFoundError: If entity does not exist
            PermissionDeniedError: If user lacks permission
        """
        return await self._rls_manager.get_for_user(
            session=session,
            user=user,
            id=id,
            action=action,
            include_deleted=include_deleted,
        )

    async def bulk_save(self, session: AsyncSession, entities: list[T]) -> list[T]:
        """Save multiple entities in a single operation.

        Uses SQLAlchemy bulk insert for new entities for better performance.
        For updates, falls back to individual saves due to version handling.

        Args:
            session: SQLAlchemy async session
            entities: List of entities to save

        Returns:
            List of saved entities with updated fields
        """
        if not entities:
            return []

        # Separate new and existing entities
        new_entities: list[T] = []
        existing_entities: list[T] = []

        for entity in entities:
            if await self._entity_exists(session, entity):
                existing_entities.append(entity)
            else:
                new_entities.append(entity)

        results: list[T] = []

        # Bulk insert new entities
        if new_entities:
            inserted = await self._bulk_insert(session, new_entities)
            results.extend(inserted)

        # Update existing entities individually (for version handling)
        for entity in existing_entities:
            saved = await self.save(session, entity)
            results.append(saved)

        return results

    async def _bulk_insert(self, session: AsyncSession, entities: list[T]) -> list[T]:
        """Bulk insert multiple new entities.

        Uses SQLAlchemy's bulk insert for better performance.

        Args:
            session: SQLAlchemy async session
            entities: List of new entities to insert

        Returns:
            List of inserted entities
        """
        if not entities:
            return []

        exclude_fields = self._mapper.get_excluded_fields()

        # Prepare all entity data
        values_list = []
        for entity in entities:
            # Generate name if not set
            if entity.name is None:
                entity.name = await self._naming_service.generate_name(session, entity)

            data = self._mapper.entity_to_db_payload(entity, exclude_fields)
            data["modified"] = datetime.now(UTC)
            values_list.append(data)

        # Execute bulk insert with error handling
        try:
            stmt = self._table.insert().values(values_list)
            await session.execute(stmt)
            logger.debug(
                "Bulk inserted %d %s entities",
                len(entities),
                self._model.__name__,
            )
        except SAIntegrityError as e:
            error_msg = str(e.orig) if e.orig else str(e)
            logger.error(
                "Bulk insert failed for %s: %s",
                self._model.__name__,
                error_msg,
                extra={"doctype": self._model.__name__, "count": len(entities)},
            )
            if "UNIQUE constraint" in error_msg or "duplicate key" in error_msg.lower():
                raise DuplicateNameError(self._model.__name__, "bulk") from e
            raise IntegrityError(error_msg) from e
        except SQLAlchemyError as e:
            logger.error(
                "Bulk insert database error for %s: %s",
                self._model.__name__,
                str(e),
                extra={"doctype": self._model.__name__, "operation": "bulk_insert"},
            )
            raise RepositoryError(f"Bulk insert failed: {e}") from e

        return entities

    # =========================================================================
    # Private Methods
    # =========================================================================

    async def _entity_exists(self, session: AsyncSession, entity: T) -> bool:
        """Check if an entity already exists in the database.

        Args:
            session: SQLAlchemy async session
            entity: The entity to check

        Returns:
            True if entity exists
        """
        entity_id = getattr(entity, "id", None)

        if entity_id is not None:
            stmt = (
                select(func.count())
                .select_from(self._table)
                .where(self._table.c.id == entity_id)
            )
            result = await session.execute(stmt)
            count = result.scalar()
            return count is not None and count > 0

        if entity.name is None:
            return False

        stmt = (
            select(func.count())
            .select_from(self._table)
            .where(self._table.c.name == entity.name)
        )
        result = await session.execute(stmt)
        count = result.scalar()
        return count is not None and count > 0

    def _get_controller(self, entity: T) -> BaseController[T] | None:
        """Get a controller instance for the entity.

        Args:
            entity: The entity

        Returns:
            Controller instance or None
        """
        if self._controller_class is None:
            return None
        return self._controller_class(entity)

    async def _call_hook(
        self,
        controller: BaseController[T] | None,
        hook_name: str,
        context: object = None,
    ) -> None:
        """Call a lifecycle hook on the controller if it exists.

        This helper method checks if the controller exists, if the hook method
        exists on the controller, and calls it with optional context.

        Args:
            controller: Optional controller instance
            hook_name: Name of the hook method to call (e.g., 'validate', 'before_save')
            context: Optional context to pass to the hook

        Raises:
            Any exception raised by the hook method is propagated to the caller
        """
        if controller is None:
            return

        hook_method = getattr(controller, hook_name, None)
        if hook_method is None:
            return

        if callable(hook_method):
            await hook_method(context)

    async def _insert_with_retry(
        self,
        session: AsyncSession,
        entity: T,
        controller: BaseController[T] | None,
        auto_generated_name: bool,
        max_retries: int = 3,
    ) -> T:
        """Insert a new entity with retry on name collision.

        For auto-generated names, retries with a new name if DuplicateNameError
        occurs (e.g., from concurrent inserts with same counter value).
        For manually provided names, does not retry.

        Args:
            session: SQLAlchemy async session
            entity: The entity to insert
            controller: Optional controller for lifecycle hooks
            auto_generated_name: Whether name was auto-generated (enables retry)
            max_retries: Maximum number of retry attempts (default 3)

        Returns:
            The inserted entity

        Raises:
            DuplicateNameError: If collision persists after max retries (or manual name)
        """
        for attempt in range(max_retries + 1):
            try:
                return await self._insert(session, entity, controller)
            except DuplicateNameError:
                if not auto_generated_name or attempt >= max_retries:
                    # Manual name or max retries exceeded - propagate error
                    raise
                # Retry with new generated name
                logger.debug(
                    "Name collision on %s attempt %d, regenerating",
                    entity.name,
                    attempt + 1,
                )
                entity.name = await self._naming_service.generate_name(session, entity)

        # Should not reach here, but satisfy type checker
        return await self._insert(session, entity, controller)  # pragma: no cover

    async def _insert(
        self, session: AsyncSession, entity: T, controller: BaseController[T] | None
    ) -> T:
        """Insert a new entity.

        Args:
            session: SQLAlchemy async session
            entity: The entity to insert
            controller: Optional controller for lifecycle hooks

        Returns:
            The inserted entity
        """
        # Fetch values from linked documents
        await self._link_fetching_service.fetch_link_values(session, entity)

        # Lifecycle hooks: validate, before_insert, before_save
        await self._call_hook(controller, "validate")
        await self._call_hook(controller, "before_insert")
        await self._call_hook(controller, "before_save")

        # Prepare data (exclude child/computed fields, include DB columns)
        exclude_fields = self._mapper.get_excluded_fields()
        data = self._mapper.entity_to_db_payload(entity, exclude_fields)
        modified_at = datetime.now(UTC)
        data["modified"] = modified_at

        # Execute insert with error handling
        try:
            stmt = self._table.insert().values(**data)
            await session.execute(stmt)
            await session.flush()  # Ensure INSERT is written to DB
            await self._history_manager.write_history_snapshot_on_save(
                session=session,
                entity=entity,
                valid_from=modified_at,
            )
        except SAIntegrityError as e:
            error_msg = str(e.orig) if e.orig else str(e)
            logger.error(
                "Insert failed for %s: %s",
                self._model.__name__,
                error_msg,
                extra={"doctype": self._model.__name__, "entity_name": entity.name},
            )
            # Check for duplicate name error
            if "UNIQUE constraint" in error_msg or "duplicate key" in error_msg.lower():
                raise DuplicateNameError(self._model.__name__, entity.name or "") from e
            raise IntegrityError(error_msg) from e
        except OperationalError as e:
            logger.error(
                "Database operation failed for %s: %s",
                self._model.__name__,
                str(e),
                extra={"doctype": self._model.__name__, "operation": "insert"},
            )
            raise DatabaseError("insert", str(e)) from e
        except SQLAlchemyError as e:
            logger.error(
                "Unexpected database error for %s: %s",
                self._model.__name__,
                str(e),
                extra={"doctype": self._model.__name__, "operation": "insert"},
            )
            raise RepositoryError(f"Insert failed: {e}") from e

        # Lifecycle hooks: after_save, after_insert
        await self._call_hook(controller, "after_save")
        await self._call_hook(controller, "after_insert")

        # Save child tables
        child_fields = self._child_table_manager.get_child_table_fields()
        if child_fields:
            await self._child_table_manager.save_child_tables(
                session, entity, child_fields
            )

        # Emit create event
        await self._event_publisher.emit_event("create", entity)

        return entity

    async def _update(
        self,
        session: AsyncSession,
        entity: T,
        controller: BaseController[T] | None,
        version: int | None = None,
    ) -> T:
        """Update an existing entity.

        Args:
            session: SQLAlchemy async session
            entity: The entity to update
            controller: Optional controller for lifecycle hooks
            version: Expected version for OCC

        Returns:
            The updated entity

        Raises:
            VersionConflictError: If version doesn't match
        """
        existing_entity: T | None = None
        previous_docstatus: object | None = None
        requires_docstatus_checks = hasattr(entity, "docstatus")
        requires_audit_snapshot = (
            controller is not None
            and getattr(controller, "_audit_adapter", None) is not None
        )
        should_load_existing = controller is not None and (
            requires_docstatus_checks or requires_audit_snapshot
        )

        if should_load_existing:
            entity_id = getattr(entity, "id", None)
            if entity_id is not None:
                existing_stmt = select(self._table).where(self._table.c.id == entity_id)
            else:
                existing_stmt = select(self._table).where(
                    self._table.c.name == entity.name
                )

            existing_result = await session.execute(existing_stmt)
            existing_row = existing_result.first()
            if existing_row is not None:
                row_mapping = getattr(existing_row, "_mapping", None)
                if isinstance(row_mapping, Mapping):
                    try:
                        existing_entity = self._mapper.row_to_entity(existing_row)
                    except Exception:  # pragma: no cover
                        # Non-standard row payloads (common in unit-test mocks) should
                        # not block normal update semantics.
                        existing_entity = None

        if existing_entity is not None:
            previous_docstatus = getattr(existing_entity, "docstatus", None)

            if (
                controller is not None
                and getattr(controller, "_pre_save_snapshot", None) is None
            ):
                controller._pre_save_snapshot = existing_entity.model_dump()

            if controller is not None and requires_docstatus_checks:
                await controller._validate_submitted_changes(entity, existing_entity)

        # Fetch values from linked documents
        await self._link_fetching_service.fetch_link_values(session, entity)

        # Lifecycle hooks: validate, before_save
        await self._call_hook(controller, "validate")
        await self._call_hook(controller, "before_save")

        # Prepare data (exclude child/computed fields, include DB columns)
        exclude_fields = self._mapper.get_excluded_fields()
        data = self._mapper.entity_to_db_payload(entity, exclude_fields)
        modified_at = datetime.now(UTC)
        data["modified"] = modified_at

        # Build update statement
        entity_id = getattr(entity, "id", None)
        if entity_id is not None:
            stmt = update(self._table).where(self._table.c.id == entity_id)
        else:
            stmt = update(self._table).where(self._table.c.name == entity.name)

        # OCC: Add version check if provided
        if version is not None:
            stmt = stmt.where(self._table.c._version == version)
            data["_version"] = version + 1

        stmt = stmt.values(**data)

        try:
            result = await session.execute(stmt)
            # OCC: Check if update succeeded
            # Access rowcount via getattr for type safety with async results
            rowcount: int = getattr(result, "rowcount", 0)
            if version is not None and rowcount == 0:
                raise VersionConflictError(
                    entity_id=entity.name if entity.name else "unknown",  # type: ignore[arg-type]
                    expected_version=version,
                )
            await session.flush()
        except SAIntegrityError as e:
            error_msg = str(e.orig) if e.orig else str(e)
            logger.error("Update failed for %s: %s", self._model.__name__, error_msg)
            if "UNIQUE constraint" in error_msg or "duplicate key" in error_msg.lower():
                raise DuplicateNameError(self._model.__name__, entity.name or "") from e
            raise IntegrityError(error_msg) from e
        except OperationalError as e:
            logger.error(
                "Database operation failed for %s: %s", self._model.__name__, str(e)
            )
            raise DatabaseError("update", str(e)) from e
        except SQLAlchemyError as e:
            logger.error(
                "Unexpected database error for %s: %s", self._model.__name__, str(e)
            )
            raise RepositoryError(f"Update failed: {e}") from e

        await self._history_manager.write_history_snapshot_on_save(
            session=session,
            entity=entity,
            valid_from=modified_at,
        )

        # Invalidate cache
        await self._cache_manager.invalidate(entity)

        # Lifecycle hook: after_save
        await self._call_hook(controller, "after_save")

        # Lifecycle hooks: on_submit / on_cancel for docstatus transitions
        if controller is not None and previous_docstatus is not None:
            from framework_m_core.domain.mixins import DocStatus

            current_docstatus = getattr(entity, "docstatus", None)
            if (
                previous_docstatus != DocStatus.SUBMITTED
                and current_docstatus == DocStatus.SUBMITTED
            ):
                await self._call_hook(controller, "on_submit")
            elif (
                previous_docstatus != DocStatus.CANCELLED
                and current_docstatus == DocStatus.CANCELLED
            ):
                await self._call_hook(controller, "on_cancel")

        # Update child tables (delete old, insert new)
        child_fields = self._child_table_manager.get_child_table_fields()
        if child_fields and entity.id:
            # Delete old children
            await self._child_table_manager.delete_child_tables(
                session, entity.id, child_fields
            )
            # Save new children
            await self._child_table_manager.save_child_tables(
                session, entity, child_fields
            )

        # Emit update event
        await self._event_publisher.emit_event("update", entity)

        # Invalidate cache after update
        await self._cache_manager.invalidate(entity)
        if entity.id:
            logger.debug("CACHE INVALIDATE %s[%s]", self._model.__name__, entity.id)

        return entity

    # ==========================================
    # Bulk Operations with RLS
    # ==========================================

    async def delete_many_for_user(
        self,
        session: AsyncSession,
        user: UserContext | None,
        filters: list[FilterSpec] | None = None,
        hard: bool = False,
    ) -> int:
        """Delete multiple entities with RLS filtering.

        IMPORTANT: RLS is applied so users can only delete their own documents.
        Admin/System users bypass RLS and can delete all matching documents.
        If user is None, no RLS is applied (for public DocTypes).

        Args:
            session: SQLAlchemy async session
            user: Current user context (None bypasses RLS for public access)
            filters: Additional filter conditions
            hard: If True, physically delete; otherwise soft-delete

        Returns:
            Number of documents deleted
        """
        return await self._rls_manager.delete_many_for_user(
            session=session, user=user, filters=filters, hard=hard
        )

    async def update_many_for_user(
        self,
        session: AsyncSession,
        user: UserContext | None,
        filters: list[FilterSpec] | None = None,
        data: dict[str, Any] | None = None,
    ) -> int:
        """Update multiple entities with RLS filtering.

        IMPORTANT: RLS is applied so users can only update their own documents.
        Admin/System users bypass RLS and can update all matching documents.
        If user is None, no RLS is applied (for public DocTypes).

        Args:
            session: SQLAlchemy async session
            user: Current user context (None bypasses RLS for public access)
            filters: Additional filter conditions
            data: Fields to update

        Returns:
            Number of documents updated
        """
        return await self._rls_manager.update_many_for_user(
            session=session, user=user, filters=filters, data=data
        )


__all__ = ["GenericRepository", "VersionConflictError"]
