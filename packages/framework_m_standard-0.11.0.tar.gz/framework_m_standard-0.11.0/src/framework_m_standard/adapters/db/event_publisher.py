"""Repository Event Publisher - Handles domain event dispatching."""

from __future__ import annotations

import logging
from uuid import uuid4

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.event_bus import EventBusProtocol

logger = logging.getLogger(__name__)


class RepositoryEventPublisher[T: BaseDocType]:
    """Handles publishing repository lifecycle events to the event bus."""

    def __init__(self, model: type[T], event_bus: EventBusProtocol | None) -> None:
        self._model = model
        self._event_bus = event_bus

    async def emit_event(
        self, event_type: str, entity: T, changed_fields: list[str] | None = None
    ) -> None:
        """Emit a domain event if event_bus is configured."""
        if self._event_bus is None:
            return

        from framework_m_core.events import DocCreated, DocDeleted, DocUpdated
        from framework_m_core.interfaces.event_bus import Event

        doctype_name = self._model.__name__
        doc_name = str(entity.name) if entity.name else str(entity.id)

        event: Event
        if event_type == "create":
            event = DocCreated(doctype=doctype_name, doc_name=doc_name)
        elif event_type == "update":
            event = DocUpdated(
                doctype=doctype_name,
                doc_name=doc_name,
                changed_fields=changed_fields or [],
            )
        elif event_type == "delete":
            event = DocDeleted(doctype=doctype_name, doc_name=doc_name)
        else:
            event = Event(
                id=str(uuid4()),
                type=f"{doctype_name}.{event_type}",
                source="framework_m",
                subject=f"{doctype_name}:{doc_name}",
                data={
                    "id": str(entity.id),
                    "name": entity.name,
                    "doctype": doctype_name,
                },
            )

        try:
            topic = f"doc.{event_type}"
            await self._event_bus.publish(topic, event)
        except Exception as e:
            logger.warning(
                "Failed to emit event %s: %s",
                event.type,
                str(e),
                extra={"doctype": doctype_name, "event_type": event_type},
            )
