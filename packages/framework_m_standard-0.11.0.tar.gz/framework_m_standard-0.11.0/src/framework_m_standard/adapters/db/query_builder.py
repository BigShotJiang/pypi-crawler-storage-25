"""Query Builder - Stateless SQL query construction."""

from __future__ import annotations

import logging
from typing import Any

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.repository import (
    FilterOperator,
    FilterSpec,
    OrderDirection,
    OrderSpec,
)
from sqlalchemy import Table

logger = logging.getLogger(__name__)


class QueryBuilder:
    """Stateless utility for applying filters and ordering to SQLAlchemy statements."""

    @staticmethod
    def apply_filters(
        stmt: Any,
        model: type[BaseDocType],
        table: Table,
        filters: list[FilterSpec],
    ) -> Any:
        """Apply filter conditions to a SQLAlchemy query."""
        json_fields = set()
        for field_name, field_info in model.model_fields.items():
            extra = field_info.json_schema_extra
            if isinstance(extra, dict) and extra.get("persistence") == "json":
                json_fields.add(field_name)

        for f in filters:
            val: Any
            if f.field in json_fields:
                column = table.c.custom_fields[f.field].as_string()
                if f.value is not None and not isinstance(f.value, (list, tuple)):
                    val = str(f.value)
                elif isinstance(f.value, (list, tuple)):
                    val = [str(v) for v in f.value]
                else:
                    val = f.value
            elif hasattr(table.c, f.field):
                column = getattr(table.c, f.field)
                val = f.value
            else:
                continue

            if f.operator == FilterOperator.EQ:
                stmt = stmt.where(column == val)
            elif f.operator == FilterOperator.NE:
                stmt = stmt.where(column != val)
            elif f.operator == FilterOperator.LT:
                stmt = stmt.where(column < val)
            elif f.operator == FilterOperator.LTE:
                stmt = stmt.where(column <= val)
            elif f.operator == FilterOperator.GT:
                stmt = stmt.where(column > val)
            elif f.operator == FilterOperator.GTE:
                stmt = stmt.where(column >= val)
            elif f.operator == FilterOperator.IN:
                stmt = stmt.where(column.in_(val))
            elif f.operator == FilterOperator.NOT_IN:
                stmt = stmt.where(~column.in_(val))
            elif f.operator == FilterOperator.LIKE:
                stmt = stmt.where(column.like(val))
            elif f.operator == FilterOperator.IS_NULL:
                stmt = (
                    stmt.where(column.is_(None))
                    if val
                    else stmt.where(column.is_not(None))
                )

        return stmt

    @staticmethod
    def apply_ordering(
        stmt: Any, model: type[BaseDocType], table: Table, order_by: list[OrderSpec]
    ) -> Any:
        """Apply ordering to a SQLAlchemy query."""
        json_fields = {
            name
            for name, info in model.model_fields.items()
            if isinstance(info.json_schema_extra, dict)
            and info.json_schema_extra.get("persistence") == "json"
        }

        for spec in order_by:
            if spec.field in json_fields:
                column = table.c.custom_fields[spec.field].as_string()
            elif hasattr(table.c, spec.field):
                column = getattr(table.c, spec.field)
            else:
                logger.warning(
                    "Invalid sort field '%s' for model %s (ignored)",
                    spec.field,
                    model.__name__,
                )
                continue

            if spec.direction == OrderDirection.DESC:
                stmt = stmt.order_by(column.desc())
            else:
                stmt = stmt.order_by(column.asc())

        return stmt
