"""Cache Manager - Handles entity caching and invalidation."""

import asyncio
import logging
from typing import Any
from uuid import UUID

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.cache import CacheProtocol

logger = logging.getLogger(__name__)


class RepoCacheManager[T: BaseDocType]:
    """Manages caching and cache invalidation for a repository.

    Handles both entity-level caching and global pattern invalidation
    triggered by specific domain entities.
    """

    def __init__(self, cache: CacheProtocol | None, model: type[T]) -> None:
        self._cache = cache
        self._model = model
        self._model_name = model.__name__

    @property
    def is_enabled(self) -> bool:
        """Return True if caching is enabled."""
        return self._cache is not None

    def _cache_key(self, id: UUID) -> str:
        return f"{self._model_name}:id:{id}"

    def _cache_key_by_name(self, name: str) -> str:
        return f"{self._model_name}:name:{name}"

    async def get_by_id(self, id: UUID) -> dict[str, Any] | None:
        if not self._cache:
            return None
        return await self._cache.get(self._cache_key(id))

    async def set_by_id(self, id: UUID, data: dict[str, Any], ttl: int = 300) -> None:
        if not self._cache:
            return
        await self._cache.set(self._cache_key(id), data, ttl=ttl)

    async def get_by_name(self, name: str) -> dict[str, Any] | None:
        if not self._cache:
            return None
        return await self._cache.get(self._cache_key_by_name(name))

    async def set_by_name(
        self, name: str, data: dict[str, Any], ttl: int = 300
    ) -> None:
        if not self._cache:
            return
        await self._cache.set(self._cache_key_by_name(name), data, ttl=ttl)

    async def invalidate(
        self, entity: T | None, id_to_invalidate: UUID | None = None
    ) -> None:
        """Invalidate cache entries for an entity and trigger global invalidations."""
        if not self._cache:
            return

        tasks = []
        if id_to_invalidate:
            tasks.append(self._cache.delete(self._cache_key(id_to_invalidate)))
        elif entity and entity.id:
            tasks.append(self._cache.delete(self._cache_key(entity.id)))

        name = getattr(entity, "name", None) if entity else None
        if isinstance(name, str):
            tasks.append(self._cache.delete(self._cache_key_by_name(name)))

        if tasks:
            await asyncio.gather(*tasks)

        # Global Invalidation Triggers
        global_tasks = []
        if self._model_name in ("User", "LocalUser"):
            user_id = entity.id if entity else id_to_invalidate
            if user_id:
                global_tasks.append(self._cache.delete_pattern(f"perm:{user_id}:*"))
        elif self._model_name == "CustomPermission":
            global_tasks.append(self._cache.delete_pattern("perm:*"))
        elif self._model_name in ("Translation", "TenantTranslation"):
            global_tasks.append(self._cache.delete_pattern("meta:*"))

        if global_tasks:
            await asyncio.gather(*global_tasks)
