"""SQLAlchemy Introspection Adapter.

Implements the IntrospectionProtocol to read database schemas using
SQLAlchemy's reflection capabilities.
"""

from framework_m_core.interfaces.introspection import (
    ColumnMeta,
    IndexMeta,
    TableMeta,
)
from sqlalchemy import Connection, inspect
from sqlalchemy.engine.reflection import Inspector
from sqlalchemy.ext.asyncio import AsyncEngine


class SQLAlchemyIntrospectionAdapter:
    """Adapter for introspecting database schemas via SQLAlchemy."""

    def __init__(self, engine: AsyncEngine) -> None:
        """Initialize the adapter with an async SQLAlchemy engine.

        Args:
            engine: The SQLAlchemy AsyncEngine to use for introspection.
        """
        self._engine = engine

    async def introspect_table(self, table_name: str) -> TableMeta | None:
        """Introspect a single table and return its metadata if it exists."""
        async with self._engine.connect() as conn:
            return await conn.run_sync(self._introspect_table_sync, table_name)

    async def introspect_database(self) -> list[TableMeta]:
        """Introspect all tables in the current database."""
        async with self._engine.connect() as conn:
            return await conn.run_sync(self._introspect_database_sync)

    def _introspect_table_sync(
        self, conn: Connection, table_name: str
    ) -> TableMeta | None:
        """Synchronous helper to run SQLAlchemy inspector for a single table."""
        inspector: Inspector = inspect(conn)

        if not inspector.has_table(table_name):
            return None

        pk_constraint = inspector.get_pk_constraint(table_name)
        pk_columns = pk_constraint.get("constrained_columns", [])

        # 1. Map Columns
        columns_meta: list[ColumnMeta] = []
        for col in inspector.get_columns(table_name):
            col_type = col["type"]

            # Extract standard generic type name (e.g., VARCHAR, INTEGER)
            type_name = getattr(col_type, "__visit_name__", str(col_type)).upper()
            if type_name == "STRING":
                type_name = "VARCHAR"

            max_length = getattr(col_type, "length", None)

            columns_meta.append(
                ColumnMeta(
                    name=col["name"],
                    type=type_name,
                    nullable=col.get("nullable", True),
                    primary_key=col["name"] in pk_columns,
                    default=col.get("default"),
                    max_length=max_length,
                )
            )

        # 2. Map Indexes and Unique Constraints
        indexes_meta: list[IndexMeta] = []

        for idx in inspector.get_indexes(table_name):
            idx_cols = [c for c in idx["column_names"] if c is not None]
            idx_name = idx["name"] or f"idx_{table_name}_{'_'.join(idx_cols)}"
            indexes_meta.append(
                IndexMeta(
                    name=idx_name,
                    columns=idx_cols,
                    unique=bool(idx.get("unique", False)),
                )
            )

        for uq in inspector.get_unique_constraints(table_name):
            uq_cols = [c for c in uq["column_names"] if c is not None]
            uq_name = uq.get("name") or f"uq_{table_name}_{'_'.join(uq_cols)}"
            indexes_meta.append(IndexMeta(name=uq_name, columns=uq_cols, unique=True))

        return TableMeta(name=table_name, columns=columns_meta, indexes=indexes_meta)

    def _introspect_database_sync(self, conn: Connection) -> list[TableMeta]:
        """Synchronous helper to run SQLAlchemy inspector for all tables."""
        inspector: Inspector = inspect(conn)
        tables: list[TableMeta] = []
        for t in inspector.get_table_names():
            meta = self._introspect_table_sync(conn, t)
            if meta is not None:
                tables.append(meta)
        return tables
