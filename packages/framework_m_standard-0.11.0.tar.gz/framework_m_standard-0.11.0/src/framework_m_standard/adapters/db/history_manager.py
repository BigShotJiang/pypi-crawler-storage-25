"""History Manager - Handles temporal queries and version snapshots.

This module extracts the versioning and temporal "as_of" query logic
from the GenericRepository, adhering to the Single Responsibility Principle.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.exceptions import DatabaseError, TemporalQueryNotSupportedError
from framework_m_core.interfaces.repository import (
    FilterSpec,
    OrderSpec,
    PaginatedResult,
)
from sqlalchemy import Table, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from framework_m_standard.adapters.db.query_builder import QueryBuilder
from framework_m_standard.adapters.db.versioning_config import is_versioning_enabled

if TYPE_CHECKING:
    from framework_m_standard.adapters.db.generic_repository import GenericRepository

logger = logging.getLogger(__name__)


class HistoryManager[T: BaseDocType]:
    """Manager for temporal queries and versioning history.

    Handles fetching documents "as of" a specific point in time,
    and writing snapshot rows to history tables on save.
    """

    def __init__(self, repository: GenericRepository[T]) -> None:
        """Initialize the history manager.

        Args:
            repository: The parent repository instance
        """
        self._repo = repository
        self._model = repository.model
        self._table = repository.table

    def _get_history_table(self) -> Table:
        """Return the configured history table for this repository's model."""
        history_table_name = f"{self._table.name}_history"
        history_table = self._table.metadata.tables.get(history_table_name)
        if history_table is None:
            raise DatabaseError(
                "temporal_query",
                f"History table '{history_table_name}' not found",
            )
        return history_table

    def _ensure_temporal_query_supported(self) -> None:
        """Ensure temporal as_of query is valid for model/config."""
        if not getattr(self._model, "_versioning_enabled", False):
            raise TemporalQueryNotSupportedError(self._model.__name__)

        if not is_versioning_enabled():
            raise TemporalQueryNotSupportedError(self._model.__name__)

    async def get_as_of(
        self,
        session: AsyncSession,
        id: UUID,
        include_deleted: bool,
        as_of: datetime,
    ) -> T | None:
        """Retrieve historical state from history table at a specific point in time."""
        self._ensure_temporal_query_supported()
        history_table = self._get_history_table()

        stmt = (
            select(history_table)
            .where(history_table.c.id == id)
            .where(history_table.c.modified <= as_of)
            .order_by(history_table.c._version_no.desc())
            .limit(1)
        )

        if not include_deleted and hasattr(history_table.c, "deleted_at"):
            stmt = stmt.where(history_table.c.deleted_at.is_(None))

        result = await session.execute(stmt)
        row = result.first()

        if row is None:
            return None

        entity = self._repo._mapper.row_to_entity(row)

        # Load child tables using current child-table mechanism
        child_fields = self._repo._child_table_manager.get_child_table_fields()
        if child_fields and entity:
            await self._repo._child_table_manager.load_child_tables(
                session, entity, child_fields
            )

        return entity

    async def list_entities_as_of(
        self,
        session: AsyncSession,
        as_of: datetime,
        filters: list[FilterSpec] | None = None,
        order_by: list[OrderSpec] | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> PaginatedResult[T]:
        """List historical states from history table at a point in time."""
        self._ensure_temporal_query_supported()
        history_table = self._get_history_table()

        effective_limit = min(limit, 1000)

        latest_versions = (
            select(
                history_table.c.id.label("entity_id"),
                func.max(history_table.c._version_no).label("max_version"),
            )
            .where(history_table.c.modified <= as_of)
            .group_by(history_table.c.id)
            .subquery()
        )

        stmt = select(history_table).join(
            latest_versions,
            (history_table.c.id == latest_versions.c.entity_id)
            & (history_table.c._version_no == latest_versions.c.max_version),
        )

        if hasattr(history_table.c, "deleted_at"):
            stmt = stmt.where(history_table.c.deleted_at.is_(None))

        if filters is not None:
            stmt = QueryBuilder.apply_filters(
                stmt, self._repo.model, history_table, filters
            )

        total_stmt = select(func.count()).select_from(stmt.subquery())
        total_result = await session.execute(total_stmt)
        total = total_result.scalar() or 0

        if order_by is not None:
            stmt = QueryBuilder.apply_ordering(
                stmt, self._repo.model, history_table, order_by
            )

        stmt = stmt.limit(effective_limit).offset(offset)
        result = await session.execute(stmt)
        rows = result.fetchall()
        items = [self._repo._mapper.row_to_entity(row) for row in rows]

        # Load child tables efficiently
        if items:
            child_fields = self._repo._child_table_manager.get_child_table_fields()
            if child_fields:
                parent_ids = [item.id for item in items]
                for field_name, child_model in child_fields.items():
                    from framework_m_standard.adapters.db.table_registry import (
                        TableRegistry,
                    )

                    table_registry = TableRegistry()
                    child_table = table_registry.get_table(child_model.__name__)
                    if child_table is not None:
                        children_by_parent = await self._repo._child_table_manager.load_children_for_parents(
                            session,
                            parent_ids,
                            child_table,
                            child_model,
                        )
                        for item in items:
                            item_id_str = str(item.id)
                            setattr(
                                item,
                                field_name,
                                children_by_parent.get(item_id_str, []),
                            )

        return PaginatedResult(
            items=items,
            total=total,
            limit=effective_limit,
            offset=offset,
        )

    async def write_history_snapshot_on_save(
        self,
        session: AsyncSession,
        entity: T,
        valid_from: datetime,
    ) -> None:
        """Write a version snapshot row after successful insert/update."""
        if not getattr(self._model, "_versioning_enabled", False):
            return

        if not is_versioning_enabled():
            return

        history_table_name = f"{self._table.name}_history"
        history_table = self._table.metadata.tables.get(history_table_name)
        if history_table is None:
            logger.debug(
                "Skipping history write for %s because table '%s' is not provisioned",
                self._model.__name__,
                history_table_name,
            )
            return

        row_data = await self._get_persisted_row_data(session, entity)
        entity_id = row_data.get("id")

        if entity_id is None:
            raise DatabaseError(
                "versioning",
                f"Cannot write history snapshot for {self._model.__name__}: missing id",
            )

        audit_db_url = history_table.info.get("audit_db_url")
        current_db_url = self._get_session_db_url(session)

        if (
            isinstance(audit_db_url, str)
            and audit_db_url
            and current_db_url != audit_db_url
        ):
            audit_engine = create_async_engine(audit_db_url, pool_pre_ping=True)
            try:
                async with audit_engine.begin() as conn:
                    await self._write_history_row(
                        execute=conn.execute,
                        history_table=history_table,
                        row_data=row_data,
                        entity_id=entity_id,
                        valid_from=valid_from,
                    )
            finally:
                await audit_engine.dispose()
            return

        await self._write_history_row(
            execute=session.execute,
            history_table=history_table,
            row_data=row_data,
            entity_id=entity_id,
            valid_from=valid_from,
        )

    async def _get_persisted_row_data(
        self,
        session: AsyncSession,
        entity: T,
    ) -> dict[str, Any]:
        """Read the latest persisted main-table row for the entity."""
        entity_id = getattr(entity, "id", None)

        if entity_id is not None:
            stmt = select(self._table).where(self._table.c.id == entity_id)
        else:
            stmt = select(self._table).where(self._table.c.name == entity.name)

        result = await session.execute(stmt)
        row = result.first()
        if row is None:
            raise DatabaseError(
                "versioning",
                f"Cannot fetch persisted row for {self._model.__name__}",
            )

        return dict(row._mapping)

    def _get_session_db_url(self, session: AsyncSession) -> str | None:
        """Return DB URL string for the current session bind."""
        bind = session.get_bind()
        bind_url = getattr(bind, "url", None)
        return str(bind_url) if bind_url is not None else None

    async def _write_history_row(
        self,
        execute: Any,
        history_table: Table,
        row_data: dict[str, Any],
        entity_id: Any,
        valid_from: datetime,
    ) -> None:
        """Insert a history snapshot and close prior valid window."""
        max_version_result = await execute(
            select(func.max(history_table.c._version_no)).where(
                history_table.c.id == entity_id
            )
        )
        max_version = max_version_result.scalar()
        next_version = (int(max_version) if max_version is not None else 0) + 1

        await execute(
            update(history_table)
            .where(history_table.c.id == entity_id)
            .where(history_table.c._valid_to.is_(None))
            .values(_valid_to=valid_from)
        )

        history_payload = dict(row_data)
        history_payload["_version_no"] = next_version
        history_payload["_valid_from"] = valid_from
        history_payload["_valid_to"] = None

        await execute(history_table.insert().values(**history_payload))
