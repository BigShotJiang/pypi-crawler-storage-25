"""Singles Manager - Handles persistence for Singleton DocTypes."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, TypeVar
from uuid import UUID

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.services.defaults_service import DefaultsService
from sqlalchemy import select

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

    from framework_m_standard.adapters.db.generic_repository import GenericRepository

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseDocType)


class SinglesManager[T: BaseDocType]:
    """Manager for handling Singleton DocType persistence.

    Ensures that only one record exists for DocTypes with is_singleton=True.
    """

    def __init__(
        self,
        repository: GenericRepository[T],
        defaults_service: DefaultsService | None = None,
    ) -> None:
        """Initialize the singles manager.

        Args:
            repository: The generic repository instance
            defaults_service: Optional service for virtual singletons
        """
        self._repository = repository
        self._model = repository.model
        self._table = repository.table
        self._defaults_service = defaults_service

    async def get_virtual_singleton(self) -> T | None:
        """Return a virtual singleton instance if defaults service is configured."""
        if not self._defaults_service:
            return None
        return await self._defaults_service.build_virtual_singleton(self._model)

    async def get_singleton_id(self, session: AsyncSession) -> UUID | None:
        """Get the ID of the single record for this DocType.

        Args:
            session: SQLAlchemy async session

        Returns:
            The UUID of the single record if it exists, None otherwise
        """
        # Look for the first record that is not soft-deleted
        stmt = select(self._table.c.id).limit(1)
        if hasattr(self._table.c, "deleted_at"):
            stmt = stmt.where(self._table.c.deleted_at.is_(None))

        result = await session.execute(stmt)
        return result.scalar()

    async def ensure_singleton_identity(self, session: AsyncSession, entity: T) -> None:
        """Ensure the entity has the correct identity for a singleton.

        If the record already exists in the database, attaches its ID to the entity.
        This forces GenericRepository to perform an UPDATE instead of an INSERT.

        Args:
            session: SQLAlchemy async session
            entity: The entity instance being saved
        """
        existing_id = await self.get_singleton_id(session)
        if existing_id:
            # If we found an existing record, we MUST use its ID
            # This ensures we update the single record instead of creating a new one
            entity.id = existing_id
            logger.debug(
                "Attached existing singleton ID %s to %s",
                existing_id,
                self._model.__name__,
            )
        else:
            # If no record exists, we can let it be inserted as new
            # We ensure the name is set correctly for reference
            if entity.name is None:
                entity.name = self._model.get_doctype_name()
            logger.debug(
                "No existing singleton found for %s, will insert new",
                self._model.__name__,
            )
