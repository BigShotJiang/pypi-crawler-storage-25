"""Versioning configuration gate utilities."""

from __future__ import annotations

import os
from typing import Any

from framework_m_core.config import load_config

_VERSIONING_ENV_VAR = "FRAMEWORK_M_STRONGSYNC_VERSIONING"


def _parse_env_override(value: str | None) -> bool | None:
    """Parse environment override for versioning config.

    Returns True/False for explicit values and None when not set/invalid.
    """
    if value is None:
        return None

    normalized = value.strip().lower()
    if normalized == "true":
        return True
    if normalized == "false":
        return False

    return None


def is_versioning_enabled(config: dict[str, Any] | None = None) -> bool:
    """Return whether shadow-table versioning is enabled.

    Precedence order:
    1. Environment variable FRAMEWORK_M_STRONGSYNC_VERSIONING (true/false)
    2. Config value compliance.versioning_enabled
    3. Default False
    """
    env_override = _parse_env_override(os.environ.get(_VERSIONING_ENV_VAR))
    if env_override is not None:
        return env_override

    effective_config = load_config() if config is None else config
    compliance_config = effective_config.get("compliance")
    if not isinstance(compliance_config, dict):
        return False

    return bool(compliance_config.get("versioning_enabled", False))


__all__ = ["is_versioning_enabled"]
