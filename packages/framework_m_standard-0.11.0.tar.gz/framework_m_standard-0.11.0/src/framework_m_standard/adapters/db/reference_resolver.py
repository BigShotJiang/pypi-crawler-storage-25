"""Reference Resolver - Handles Zero-Overhead RPC Reference Resolution."""

import logging
from typing import Any
from uuid import UUID

from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.event_bus import EventBusProtocol
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)


class ReferenceResolver:
    """Stateless utility for resolving reference_to links on entities."""

    @staticmethod
    async def resolve_indie(
        session: AsyncSession,
        entity: BaseDocType,
        model: type[BaseDocType],
    ) -> None:
        """Resolve reference_to links locally in Indie mode."""
        from framework_m_core.registry import MetaRegistry

        from framework_m_standard.adapters.db.generic_repository import (
            GenericRepository,
        )
        from framework_m_standard.adapters.db.table_registry import TableRegistry

        table_registry = TableRegistry()
        meta_registry = MetaRegistry.get_instance()

        for field_name, field_info in model.model_fields.items():
            extra = field_info.json_schema_extra
            if not isinstance(extra, dict):
                continue

            target_doctype = extra.get("link")
            if not target_doctype or not isinstance(target_doctype, str):
                continue

            link_value = getattr(entity, field_name, None)
            if not link_value:
                continue

            try:
                target_table = table_registry.get_table(target_doctype)
                target_model = meta_registry.get_doctype(target_doctype)
            except Exception:
                continue

            try:
                link_uuid = UUID(str(link_value))
            except ValueError:
                continue

            stmt = select(target_table).where(target_table.c.id == link_uuid)
            result = await session.execute(stmt)
            target_row = result.first()

            if target_row:
                # Use a temporary repository to reuse robust _row_to_entity parsing
                target_repo = GenericRepository(target_model, target_table)
                target_entity = target_repo._mapper.row_to_entity(target_row)

                prop_name = (
                    field_name[:-3]
                    if field_name.endswith("_id")
                    else f"{field_name}_doc"
                )

                try:
                    setattr(entity, prop_name, target_entity)
                except Exception:
                    # Fallback if Pydantic model rejects extra attributes
                    entity.__dict__[prop_name] = target_entity

    @staticmethod
    async def resolve_enterprise(
        entity: BaseDocType,
        model: type[BaseDocType],
        event_bus: EventBusProtocol | None,
    ) -> None:
        """Resolve reference_to links via EventBus in Enterprise mode."""
        if not event_bus:
            return

        from framework_m_core.registry import MetaRegistry

        meta_registry = MetaRegistry.get_instance()

        for field_name, field_info in model.model_fields.items():
            extra = field_info.json_schema_extra
            if not isinstance(extra, dict):
                continue

            target_doctype = extra.get("link")
            if not target_doctype or not isinstance(target_doctype, str):
                continue

            link_value = getattr(entity, field_name, None)
            if not link_value:
                continue

            try:
                response = await event_bus.request(
                    f"rpc.{target_doctype}.get", {"id": str(link_value)}
                )

                if not response or not isinstance(response, dict):
                    continue

                target_entity: Any
                try:
                    target_model = meta_registry.get_doctype(target_doctype)
                    target_entity = target_model.model_validate(response)
                except Exception:

                    class DynamicRecord:
                        def __init__(self, **kwargs: Any) -> None:
                            self.__dict__.update(kwargs)

                    target_entity = DynamicRecord(**response)

                prop_name = (
                    field_name[:-3]
                    if field_name.endswith("_id")
                    else f"{field_name}_doc"
                )

                try:
                    setattr(entity, prop_name, target_entity)
                except Exception:
                    entity.__dict__[prop_name] = target_entity

            except Exception as e:
                logger.debug(
                    "Enterprise reference resolution failed for %s: %s",
                    target_doctype,
                    str(e),
                )
