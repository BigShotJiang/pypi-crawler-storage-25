"""Citadel IAM Authentication Strategy.

This module provides the CitadelAuth strategy, which implements both
TRUST_PROXY (gateway-extracted) and ZERO_TRUST (token-enrichment)
authentication patterns for Citadel IAM.
"""

from __future__ import annotations

import base64
import json
import logging
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, cast

import httpx
from framework_m_core.interfaces.auth_context import UserContext

if TYPE_CHECKING:
    from framework_m_core.interfaces.cache import CacheProtocol

logger = logging.getLogger(__name__)

AuthStrategy = Literal["TRUST_PROXY", "ZERO_TRUST"]


class CitadelAuth:
    """Authentication strategy for Citadel IAM.

    Supports two modes:
    - TRUST_PROXY: Legacy/Internal mode. Identity headers are trusted from upstream.
    - ZERO_TRUST: Cloud-native mode. Bearer tokens are validated/enriched via IAM API.
    """

    def __init__(
        self,
        strategy: AuthStrategy = "TRUST_PROXY",
        iam_url: str | None = None,
        s2s_client: Any | None = None,
    ) -> None:
        """Initialize CitadelAuth.

        Args:
            strategy: 'TRUST_PROXY' or 'ZERO_TRUST'
            iam_url: Base URL for Citadel IAM service
            s2s_client: Optional S2S client for ZERO_TRUST token enrichment
        """
        self.strategy = strategy
        self.iam_url = iam_url.rstrip("/") if iam_url else None
        self.s2s_client = s2s_client

    def supports(self, headers: Mapping[str, str]) -> bool:
        """Check if request has Citadel-specific headers or Bearer token."""
        if self.strategy == "TRUST_PROXY":
            return "x-user-id" in headers or "x-service-id" in headers

        auth_header = headers.get("authorization", "")
        return auth_header.lower().startswith("bearer ")

    async def authenticate(self, headers: Mapping[str, str]) -> UserContext | None:
        """Authenticate request via Citadel IAM logic."""
        if self.strategy == "TRUST_PROXY":
            return self._authenticate_proxy(headers)

        return await self._authenticate_zero_trust(headers)

    def _authenticate_proxy(self, headers: Mapping[str, str]) -> UserContext | None:
        """Extract user context from trusted headers.

        Header priority:
        1. x-user-id (User identity)
        2. x-service-id (Service identity)
        """
        user_id = headers.get("x-user-id")
        email = headers.get("x-email", "")
        is_service = False

        if not user_id:
            user_id = headers.get("x-service-id")
            is_service = True

        if not user_id:
            return None

        # Parse roles and scopes
        roles = [
            r.strip() for r in headers.get("x-user-roles", "").split(",") if r.strip()
        ]
        scopes = [
            s.strip() for s in headers.get("x-scopes", "").split(",") if s.strip()
        ]

        # Parse Verified Tenants
        tenants: list[str] = []
        tenant_id = headers.get("x-tenant-id")
        if tenant_id:
            tenants.extend([t.strip() for t in tenant_id.split(",") if t.strip()])

        # Parse and merge attributes
        attributes: dict[str, Any] = {}

        # User selector (not yet verified by adapter, but passed in core and used as hint)
        active_tenant = headers.get("x-active-tenant-id")
        if active_tenant:
            attributes["active_tenant_id"] = active_tenant
            if not tenants:
                # Fallback if enrichment didn't set x-tenant-id but did provide active_tenant
                tenants.append(active_tenant)

        # User attributes
        user_attrs_b64 = headers.get("x-user-attributes")
        if user_attrs_b64:
            try:
                user_attrs = json.loads(
                    base64.b64decode(user_attrs_b64).decode("utf-8")
                )
                attributes.update(user_attrs)
            except Exception as e:
                logger.warning(f"Failed to decode x-user-attributes: {e}")

        # Tenant attributes (merged or namespaced)
        tenant_attrs_b64 = headers.get("x-tenant-attributes")
        if tenant_attrs_b64:
            try:
                tenant_attrs = json.loads(
                    base64.b64decode(tenant_attrs_b64).decode("utf-8")
                )
                # We put them in a dedicated key to avoid collisions with user attributes
                attributes["tenant_attributes"] = tenant_attrs
            except Exception as e:
                logger.warning(f"Failed to decode x-tenant-attributes: {e}")

        # Add service metadata if applicable
        if is_service:
            attributes["service_id"] = user_id
            attributes["is_service"] = True

        if scopes:
            attributes["scopes"] = scopes

        # Display name
        name = headers.get("x-tenant-name") or headers.get("x-full-name")
        if not name and "full_name" in attributes:
            name = attributes["full_name"]
        elif not name and "name" in attributes:
            name = attributes["name"]

        return UserContext(
            id=user_id,
            email=email,
            name=name,
            roles=roles,
            tenants=tenants,
            attributes=attributes,
        )

    async def _authenticate_zero_trust(
        self, headers: Mapping[str, str]
    ) -> UserContext | None:
        """Enrich Bearer token via Citadel IAM service."""
        auth_header = headers.get("authorization", "")
        if not auth_header.lower().startswith("bearer ") or not self.iam_url:
            return None

        user_token = auth_header[7:]

        # S2S enrichment
        try:
            # Fetch S2S token if client is provided
            s2s_token = None
            if self.s2s_client is not None:
                s2s_token = await self.s2s_client.get_admin_token()

            enrich_url = f"{self.iam_url}/api/iam/v1/system/enrich-token"
            req_headers = {"Authorization": f"Bearer {user_token}"}
            if s2s_token:
                req_headers["X-S2s-Token"] = s2s_token

            async with httpx.AsyncClient(timeout=2.0) as client:
                response = await client.get(enrich_url, headers=req_headers)
                response.raise_for_status()

                # The response headers contain the enriched identity
                return self._authenticate_proxy(response.headers)
        except Exception as e:
            logger.error(f"Citadel Zero-Trust enrichment failed: {e}")
            return None


class S2sClient:
    """Service-to-Service client for Citadel token management."""

    def __init__(
        self,
        token_endpoint: str,
        client_id: str,
        client_secret: str,
        scope: str = "self_service",
        cache_service: CacheProtocol | None = None,
    ) -> None:
        self.token_endpoint = token_endpoint
        self.client_id = client_id
        self.client_secret = client_secret
        self.scope = scope
        self.cache_service = cache_service
        self._local_token: str | None = None

    async def get_admin_token(self) -> str:
        """Fetch and cache admin token."""
        if self._local_token:
            return self._local_token

        async with httpx.AsyncClient() as client:
            auth_str = f"{self.client_id}:{self.client_secret}"
            auth_b64 = base64.b64encode(auth_str.encode()).decode("utf-8")

            response = await client.post(
                self.token_endpoint,
                data={"grant_type": "client_credentials", "scope": self.scope},
                headers={"Authorization": f"Basic {auth_b64}"},
            )
            response.raise_for_status()
            token = cast(str, response.json()["access_token"])
            self._local_token = token
            return token
