"""Auth Strategy Registry - Stores and retrieves authentication strategies.

This module provides the AuthStrategyRegistry class that manages the mapping
between configuration names and their corresponding strategy factories.
"""

from __future__ import annotations

import importlib
import logging
from collections.abc import Callable
from typing import ClassVar, cast

from framework_m_core.interfaces.authentication import AuthenticationProtocol

logger = logging.getLogger(__name__)

# Strategy Factory signature: (config: dict[str, Any], **deps: Any) -> AuthenticationProtocol | None
StrategyFactory = Callable[..., AuthenticationProtocol | None]


class AuthStrategyRegistry:
    """Registry for authentication strategy factories.

    Provides a centralized location to register and retrieve strategies
    based on their configuration name.

    Example:
        >>> registry = AuthStrategyRegistry()
        >>> registry.register("bearer", bearer_factory)
        >>> factory = registry.get_factory("bearer")
    """

    _instance: ClassVar[AuthStrategyRegistry | None] = None
    _factories: dict[str, StrategyFactory]

    def __new__(cls) -> AuthStrategyRegistry:
        """Implement singleton pattern.

        Returns:
            The single AuthStrategyRegistry instance
        """
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._factories = {}
        return cls._instance

    def register(self, name: str, factory: StrategyFactory) -> None:
        """Register a strategy factory.

        Args:
            name: Config name (e.g. "bearer", "my_custom")
            factory: Function that creates the strategy instance
        """
        if name in self._factories:
            logger.debug("Overwriting auth strategy factory for '%s'", name)
        self._factories[name] = factory

    def get_factory(self, name: str) -> StrategyFactory | None:
        """Get factory by name.

        Args:
            name: Config name or module path

        Returns:
            The strategy factory or None if not found
        """
        # 1. Check direct registry first
        if name in self._factories:
            return self._factories[name]

        # 2. Try dynamic loading if it looks like a path
        if "." in name:
            return self._load_from_path(name)

        return None

    def list_strategies(self) -> list[str]:
        """List all registered strategy names.

        Returns:
            List of registered strategy names
        """
        return list(self._factories.keys())

    def _load_from_path(self, path: str) -> StrategyFactory | None:
        """Dynamically load a factory or class from a module path.

        Args:
            path: Full python path (e.g. "myapp.auth.CustomStrategy")

        Returns:
            The loaded class or function, or None if failed
        """
        try:
            module_path, attr_name = path.rsplit(".", 1)
            module = importlib.import_module(module_path)
            attr = getattr(module, attr_name)
            if callable(attr):
                return cast(StrategyFactory, attr)
            return None
        except (ImportError, AttributeError, ValueError) as e:
            logger.error("Failed to load auth strategy from path '%s': %s", path, e)
            return None

    def reset(self) -> None:
        """Clear all registered factories (useful for tests)."""
        self._factories.clear()


__all__ = ["AuthStrategyRegistry", "StrategyFactory"]
