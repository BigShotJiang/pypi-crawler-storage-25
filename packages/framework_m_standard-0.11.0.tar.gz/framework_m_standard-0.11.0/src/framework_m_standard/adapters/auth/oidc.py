"""OIDC Federated Authentication Strategy.

Implements an authentication strategy for validating OIDC-compliant JWTs
from external identity providers.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, cast

import httpx
import jwt
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey
from framework_m_core.interfaces.auth_context import UserContext

from .singleflight import AsyncSingleflight

if TYPE_CHECKING:
    from framework_m_core.interfaces.cache import CacheProtocol

logger = logging.getLogger(__name__)

# Global singleflight group for fetching public keys to prevent thundering herd
_key_fetch_group: AsyncSingleflight[RSAPublicKey | None] = AsyncSingleflight()


class OidcFederatedAuth:
    """
    Authentication strategy for OIDC JWT Bearer tokens from external IdPs.

    Args:
        cache: A cache adapter implementing CacheProtocol for JWKS caching.
        providers: A dictionary of configured OIDC providers from config.
    """

    def __init__(
        self,
        cache: CacheProtocol,
        providers: dict[str, Any],
    ) -> None:
        self._cache = cache
        self._providers = providers

    def supports(self, headers: Mapping[str, str]) -> bool:
        """Check if the request has a Bearer token."""
        auth_header = headers.get("authorization", "")
        return auth_header.lower().startswith("bearer ")

    async def authenticate(self, headers: Mapping[str, str]) -> UserContext | None:
        """
        Authenticate using an OIDC JWT Bearer token.

        1. Decodes the token header to find the issuer (`iss`) and key ID (`kid`).
        2. Fetches the public key from the provider's JWKS endpoint (with caching).
        3. Verifies the token's signature and claims.
        4. Maps the claims to a UserContext.

        Args:
            headers: Request headers.

        Returns:
            UserContext if the token is valid, otherwise None.
        """
        auth_header = headers.get("authorization", "")
        if not self.supports(headers):
            return None

        token = auth_header[7:]

        try:
            claims = await self._decode_and_verify(token, headers)
            if not claims or not claims.get("sub"):
                return None

            # Map claims to UserContext
            return UserContext(
                id=str(claims.get("sub")),
                email=claims.get("email", ""),
                name=claims.get("name"),
                roles=claims.get("roles", []),
                tenants=claims.get("tenants", []),
                teams=claims.get("teams", []),
                attributes=claims,  # Pass all claims as attributes
            )
        except Exception as e:
            logger.debug("OIDC token validation failed: %s", e)
            return None

    async def _decode_and_verify(
        self, token: str, headers: Mapping[str, str] | None = None
    ) -> dict[str, Any] | None:
        """Determines token type (JWT vs opaque), selects provider, and verifies."""
        headers = headers or {}
        is_jwt = False
        unverified_claims = {}

        try:
            unverified_claims = jwt.decode(token, options={"verify_signature": False})
            is_jwt = True
        except jwt.PyJWTError:
            is_jwt = False

        if is_jwt:
            issuer = unverified_claims.get("iss")
            provider_config = self._get_provider_by_issuer(issuer)
            if not provider_config:
                return None

            if (
                provider_config.get("discovery_url")
                and not provider_config.get("jwks_uri")
                and not provider_config.get("jwks_endpoint")
            ):
                discovery_data = await self._fetch_oidc_discovery(
                    cast(str, provider_config["discovery_url"])
                )
                if discovery_data:
                    provider_config.update(discovery_data)

            return await self._decode_and_verify_jwt(token, provider_config)

        # Opaque Token Path
        provider_name = headers.get("x-auth-provider")
        if provider_name:
            provider_config = self._providers.get(provider_name)
        else:
            provider_config = self._get_default_provider()

        if not provider_config:
            return None

        return await self._introspect_opaque_token(token, provider_config)

    async def _decode_and_verify_jwt(
        self, token: str, provider_config: dict[str, Any]
    ) -> dict[str, Any] | None:
        """Verifies JWT signature using the selected provider configuration."""
        try:
            unverified_header = jwt.get_unverified_header(token)
            unverified_claims = jwt.decode(token, options={"verify_signature": False})
        except jwt.PyJWTError as e:
            logger.warning("Failed to decode OIDC token header/claims: %s", e)
            return None

        issuer = unverified_claims.get("iss")
        kid = unverified_header.get("kid")

        if not issuer or not kid:
            return None

        public_key = await self._get_public_key(cast(str, issuer), cast(str, kid))
        if not public_key:
            return None

        try:
            # Decode the token, this time verifying the signature
            decoded = jwt.decode(
                token,
                public_key,
                algorithms=["RS256", "ES256"],
                audience=provider_config.get("audience"),
            )
            if isinstance(decoded, dict):
                return decoded
            return None
        except jwt.PyJWTError as e:
            logger.warning("OIDC token signature or claim validation failed: %s", e)
            return None

    def _get_provider_by_issuer(self, issuer: str | None) -> dict[str, Any] | None:
        if not issuer:
            return None
        for config in self._providers.values():
            if config.get("issuer") == issuer:
                return cast(dict[str, Any], config)
        return None

    def _get_default_provider(self) -> dict[str, Any] | None:
        for config in self._providers.values():
            if config.get("default") is True:
                return cast(dict[str, Any], config)
        return None

    async def _fetch_oidc_discovery(self, discovery_url: str) -> dict[str, Any] | None:
        """Fetches OpenID Connect metadata from the discovery URL."""
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(discovery_url)
                response.raise_for_status()
                return cast(dict[str, Any], response.json())
        except Exception as e:
            logger.error("Failed to fetch OIDC discovery from %s: %s", discovery_url, e)
            return None

    async def _introspect_opaque_token(
        self, token: str, provider_config: dict[str, Any]
    ) -> dict[str, Any] | None:
        """Introspect an opaque token, falling back to userinfo endpoint."""
        userinfo_url = provider_config.get("userinfo_url")

        if not userinfo_url and provider_config.get("discovery_url"):
            discovery_data = await self._fetch_oidc_discovery(
                cast(str, provider_config["discovery_url"])
            )
            if discovery_data:
                provider_config.update(discovery_data)
                userinfo_url = provider_config.get("userinfo_url")

        if userinfo_url:
            try:
                async with httpx.AsyncClient(timeout=5.0) as client:
                    response = await client.get(
                        cast(str, userinfo_url),
                        headers={"Authorization": f"Bearer {token}"},
                    )
                    if response.status_code == 200:
                        return cast(dict[str, Any], response.json())
            except Exception as e:
                logger.warning("UserInfo fetch failed: %s", e)

        return None

    def _get_audience_for_issuer(self, issuer: str) -> str | None:
        """Finds the configured audience for a given issuer."""
        for provider_config in self._providers.values():
            if provider_config.get("issuer") == issuer:
                return cast(str | None, provider_config.get("audience"))
        return None

    async def _get_public_key(self, issuer: str, kid: str) -> RSAPublicKey | None:
        """Retrieve the public key for a given issuer and key ID (kid)."""
        cache_key = f"oidc:jwks:{issuer}:{kid}"
        cached_key_data = await self._cache.get(cache_key)
        if cached_key_data:
            try:
                return cast(
                    RSAPublicKey,
                    jwt.algorithms.RSAAlgorithm.from_jwk(json.loads(cached_key_data)),
                )
            except Exception:
                pass

        return await _key_fetch_group.do(
            cache_key, lambda: self._fetch_and_cache_public_key(issuer, kid, cache_key)
        )

    async def _fetch_and_cache_public_key(
        self, issuer: str, kid: str, cache_key: str
    ) -> RSAPublicKey | None:
        """Fetch JWKS, find the matching key, cache it, and return it."""
        jwks_uri = self._get_jwks_uri_for_issuer(issuer)
        if not jwks_uri:
            return None

        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(jwks_uri)
                response.raise_for_status()
                jwks = response.json()

            for key_data in jwks.get("keys", []):
                if key_data.get("kid") == kid:
                    await self._cache.set(cache_key, json.dumps(key_data), ttl=86400)
                    return cast(
                        RSAPublicKey, jwt.algorithms.RSAAlgorithm.from_jwk(key_data)
                    )
        except (httpx.HTTPError, json.JSONDecodeError, KeyError) as e:
            logger.error("Failed to fetch or parse JWKS from %s: %s", jwks_uri, e)

        return None

    def _get_jwks_uri_for_issuer(self, issuer: str) -> str | None:
        """Finds the configured JWKS URI for a given issuer."""
        for provider_config in self._providers.values():
            if provider_config.get("issuer") == issuer:
                # This could be from OIDC discovery or explicit config
                return cast(
                    str | None,
                    provider_config.get("jwks_uri")
                    or provider_config.get("jwks_endpoint"),
                )
        return None
