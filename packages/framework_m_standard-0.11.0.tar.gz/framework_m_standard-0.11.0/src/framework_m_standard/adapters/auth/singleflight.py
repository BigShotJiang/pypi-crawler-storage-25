"""AsyncSingleflight - Request Coalescing Utility.

Provides a mechanism to prevent the "thundering herd" problem by ensuring
that for a given key, only one async function is executed at a time, while
other concurrent callers for the same key await the same result.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable


class AsyncSingleflight[T]:
    """
    A request coalescer to prevent thundering herd.

    For a given key, ensures that only one async function is executed.
    Concurrent calls for the same key will wait for the first call to complete
    and receive its result.

    Example:
        group = AsyncSingleflight()

        async def fetch_data(key: str) -> str:
            # Simulate a slow network call
            await asyncio.sleep(1)
            return f"data for {key}"

        # Multiple concurrent calls
        results = await asyncio.gather(
            group.do("my-key", lambda: fetch_data("my-key")),
            group.do("my-key", lambda: fetch_data("my-key")),
            group.do("my-key", lambda: fetch_data("my-key")),
        )
        # fetch_data("my-key") is only called ONCE.
        # All results will be "data for my-key".
    """

    def __init__(self) -> None:
        self._calls: dict[str, asyncio.Future[T]] = {}

    async def do(self, key: str, func: Callable[[], Awaitable[T]]) -> T:
        """
        Execute and return the value for a given key, coalescing concurrent calls.
        """
        if key in self._calls:
            return await self._calls[key]

        future: asyncio.Future[T] = asyncio.Future()
        self._calls[key] = future

        try:
            result = await func()
            future.set_result(result)
            return result
        except Exception as e:
            future.set_exception(e)
            raise
        finally:
            del self._calls[key]
