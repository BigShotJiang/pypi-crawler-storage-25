"""OAuthService — Auto-link OAuth2/OIDC provider users to local accounts.

This service implements the "auto_link_user" logic for RFC-0006 Strategy A:
given OAuth userinfo, find or create a local user + SocialAccount.

Priority chain:
1. Existing SocialAccount(provider, provider_user_id) → return linked user
2. email_verified + LocalUser.email match → create SocialAccount link → return
3. No match → create LocalUser (random password) + SocialAccount → return

Security:
- Email linkage ONLY when email_verified=True (prevents account takeover)
- No provider tokens are persisted (only identity linking info)
- Random password for social-only users (can't log in via password)
"""

from __future__ import annotations

import secrets
from datetime import UTC, datetime
from typing import Any


class OAuthService:
    """Service for linking OAuth2 provider identities to local users.

    Args:
        social_account_repo: Repository for SocialAccount CRUD
        user_repo: Repository for LocalUser CRUD

    Example:
        service = OAuthService(
            social_account_repo=social_repo,
            user_repo=user_repo,
        )
        user = await service.auto_link_user(
            provider="google",
            provider_user_id="1234567890",
            email="user@gmail.com",
            email_verified=True,
            display_name="John Doe",
        )
    """

    def __init__(
        self,
        social_account_repo: Any,
        user_repo: Any,
    ) -> None:
        """Initialize the service.

        Args:
            social_account_repo: Repository for SocialAccount operations
                                 (find_by_provider, create, update)
            user_repo: Repository for LocalUser operations
                       (get, find_by_email, create)
        """
        self._social_repo = social_account_repo
        self._user_repo = user_repo

    async def auto_link_user(
        self,
        provider: str,
        provider_user_id: str,
        email: str | None,
        email_verified: bool,
        display_name: str,
    ) -> Any:
        """Find or create a local user from OAuth provider info.

        This is the core "social login" logic. Implements the 3-step priority chain:
        1. Look up existing SocialAccount → return linked LocalUser
        2. If email_verified + email match → create SocialAccount link → return
        3. No match → create LocalUser + SocialAccount → return

        Args:
            provider: OAuth provider name (google, github, microsoft, oidc)
            provider_user_id: Unique user ID from the provider
            email: Email from provider (may be None for private email accounts)
            email_verified: Whether the provider confirmed email ownership.
                            CRITICAL: Only link by email when True.
            display_name: Display name from provider (for UI)

        Returns:
            LocalUser instance (existing or newly created)
        """
        # Attempt 1: Find existing SocialAccount
        social_account = await self._social_repo.find_by_provider(
            provider=provider,
            provider_user_id=provider_user_id,
        )

        if social_account is not None:
            # Get linked user
            user = await self._user_repo.get(social_account.user_id)
            if user is not None:
                # Update last login timestamp
                await self._social_repo.update(
                    social_account,
                    last_login_at=datetime.now(UTC),
                )
                return user

        # Attempt 2: Link by verified email
        if email_verified and email:
            existing_user = await self._user_repo.find_by_email(email)
            if existing_user is not None:
                # Create a new SocialAccount linking provider to existing user
                await self._social_repo.create(
                    provider=provider,
                    provider_user_id=provider_user_id,
                    user_id=str(existing_user.id),
                    display_name=display_name,
                    email=email,
                    last_login_at=datetime.now(UTC),
                )
                return existing_user

        # Attempt 3: Create new LocalUser + SocialAccount
        new_user = await self._create_user_from_provider(
            email=email,
            display_name=display_name,
        )

        await self._social_repo.create(
            provider=provider,
            provider_user_id=provider_user_id,
            user_id=str(new_user.id),
            display_name=display_name,
            email=email,
            last_login_at=datetime.now(UTC),
        )

        return new_user

    async def _create_user_from_provider(
        self,
        email: str | None,
        display_name: str,
    ) -> Any:
        """Create a new LocalUser from provider info.

        Creates a user with a random secure password (can't login via password).
        The user can only log in via social providers.

        Args:
            email: Email address (may be None)
            display_name: Display name for the new user

        Returns:
            Newly created LocalUser
        """
        # Generate a random secure password for social-only accounts
        # This makes password-based login impossible for these users
        random_password = secrets.token_urlsafe(32)

        # Construct a placeholder email if provider didn't share one
        placeholder_email = (
            email or f"social-{secrets.token_hex(8)}@placeholder.invalid"
        )

        return await self._user_repo.create(
            email=placeholder_email,
            password=random_password,
            full_name=display_name,
            roles=["User"],
        )


__all__ = ["OAuthService"]
