"""Navigation Policy Engine.

Filters navigation manifests based on SaaS entitlements and user context.
"""

from framework_m_core.domain.navigation import NavigationManifest, NavigationNode
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.feature_entitlement import FeatureEntitlementProtocol


class NavigationPolicyEngine:
    """Resolves and filters navigation structures."""

    def __init__(self, entitlement_protocol: FeatureEntitlementProtocol):
        self.entitlement_protocol = entitlement_protocol

    async def resolve_navigation(
        self, manifests: list[NavigationManifest], user: UserContext
    ) -> list[NavigationManifest]:
        """Filter a list of manifests based on user roles and tenant entitlements."""
        # Assuming single-tenant context for the active session
        tenant_id = user.tenants[0] if user.tenants else "default"
        resolved_manifests = []

        for manifest in manifests:
            filtered_resources = []
            for node in manifest.resources:
                filtered_node = await self._filter_node(node, user, tenant_id)
                if filtered_node:
                    filtered_resources.append(filtered_node)

            if filtered_resources:
                resolved_manifests.append(
                    manifest.model_copy(update={"resources": filtered_resources})
                )

        return resolved_manifests

    async def _filter_node(
        self, node: NavigationNode, user: UserContext, tenant_id: str
    ) -> NavigationNode | None:
        """Evaluate a single node and its children recursively."""
        # 1. SaaS Entitlement Check
        if node.feature_id and not await self.entitlement_protocol.is_feature_enabled(
            tenant_id, node.feature_id
        ):
            return None

        # 2. RBAC Visibility Check
        if node.visibility_policy and node.visibility_policy.roles:
            has_role = any(role in user.roles for role in node.visibility_policy.roles)
            if not has_role:
                return None

        # 3. Recursive Child Filtering
        if node.children:
            filtered_children = []
            for child in node.children:
                filtered_child = await self._filter_node(child, user, tenant_id)
                if filtered_child:
                    filtered_children.append(filtered_child)

            return node.model_copy(update={"children": filtered_children})

        return node
