"""Permission-Aware Landing Adapter.

This adapter iterates through a list of potential landing candidates
and delegates to the PermissionProtocol to ensure the user has the
required access before resolving the landing route.
"""

from collections.abc import Sequence

from framework_m_core.domain.landing import LandingDescriptor
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.landing import LandingProtocol
from framework_m_core.interfaces.permission import (
    PermissionProtocol,
    PolicyEvaluateRequest,
)
from pydantic import BaseModel, Field


class LandingCandidate(BaseModel):
    """Configuration for a potential landing page target."""

    route: str = Field(description="The target frontend route.")
    required_doctype: str | None = Field(
        default=None, description="DocType the user must have permission to access."
    )
    required_action: str | None = Field(
        default=None,
        description="Action (e.g., 'read') the user must be permitted to perform.",
    )


class PermissionAwareLandingAdapter(LandingProtocol):
    """Resolves landing pages by checking user permissions against candidates."""

    def __init__(
        self,
        permission_service: PermissionProtocol,
        candidates: Sequence[LandingCandidate],
    ) -> None:
        """Initialize the adapter.

        Args:
            permission_service: The service to delegate authorization checks to.
            candidates: Ordered sequence of landing candidates to evaluate.
        """
        self.permission_service = permission_service
        self.candidates = candidates

    async def resolve(self, context: UserContext) -> LandingDescriptor | None:
        """Resolve the first candidate the user is permitted to access."""
        for candidate in self.candidates:
            # If candidate requires specific permissions, check them
            if candidate.required_doctype and candidate.required_action:
                request = PolicyEvaluateRequest(
                    principal=context.id,
                    action=candidate.required_action,
                    resource=candidate.required_doctype,
                    principal_attributes={
                        "roles": context.roles,
                        "tenants": context.tenants,
                        "teams": context.teams,
                        "is_system_user": context.is_system_user,
                    },
                )
                result = await self.permission_service.evaluate(request)
                if not result.authorized:
                    continue  # Try the next candidate

            # If we reach here, either permissions passed or weren't required
            return LandingDescriptor(route=candidate.route)

        return None
