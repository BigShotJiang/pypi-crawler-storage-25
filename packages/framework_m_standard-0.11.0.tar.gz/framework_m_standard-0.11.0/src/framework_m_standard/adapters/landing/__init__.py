"""Landing Adapters.

This package contains concrete implementations of the LandingProtocol
for resolving user landing pages.
"""

from framework_m_standard.adapters.landing.composite_adapter import (
    CompositeLandingAdapter,
)
from framework_m_standard.adapters.landing.permission_aware_adapter import (
    LandingCandidate,
    PermissionAwareLandingAdapter,
)

__all__ = [
    "CompositeLandingAdapter",
    "LandingCandidate",
    "PermissionAwareLandingAdapter",
]
