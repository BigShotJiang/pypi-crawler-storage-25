"""Composite Landing Adapter.

Implements the Composite pattern to group multiple LandingProtocol
adapters together and try them in sequence.
"""

from collections.abc import Sequence

from framework_m_core.domain.landing import LandingDescriptor
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.landing import LandingProtocol


class CompositeLandingAdapter(LandingProtocol):
    """Composite adapter that tries multiple landing resolvers in sequence."""

    def __init__(self, adapters: Sequence[LandingProtocol]) -> None:
        """Initialize with a list of adapters to try in order.

        Args:
            adapters: The ordered sequence of adapters to try.
        """
        self.adapters = adapters

    async def resolve(self, context: UserContext) -> LandingDescriptor | None:
        """Resolve the landing page by trying sub-adapters in sequence."""
        for adapter in self.adapters:
            descriptor = await adapter.resolve(context)
            if descriptor is not None:
                return descriptor
        return None
