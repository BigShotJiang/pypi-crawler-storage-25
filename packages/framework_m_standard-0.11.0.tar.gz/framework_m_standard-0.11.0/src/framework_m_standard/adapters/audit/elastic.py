"""Elasticsearch Audit Adapter - Async audit logging for enterprise workloads.

This adapter writes audit entries into Elasticsearch indexes and supports
filtered query access for reporting and analytics use cases.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from framework_m_core.interfaces.audit import AuditEntry, AuditLogProtocol


class ElasticAuditAdapter(AuditLogProtocol):
    """Elasticsearch-backed audit adapter.

    Index naming strategy uses monthly rotation by default:
    ``{index_prefix}-YYYY-MM``.
    """

    def __init__(
        self,
        *,
        client: Any | None = None,
        hosts: list[str] | None = None,
        index_prefix: str = "framework-m-audit",
    ) -> None:
        """Initialize adapter.

        Args:
            client: Existing async Elasticsearch client (preferred for DI/tests)
            hosts: Elasticsearch hosts used when ``client`` is not provided
            index_prefix: Prefix used for monthly index names
        """
        self._index_prefix = index_prefix
        if client is not None:
            self._client = client
            return

        try:
            from elasticsearch import AsyncElasticsearch
        except ImportError as exc:  # pragma: no cover - runtime dependency guard
            raise RuntimeError(
                "elasticsearch package is required when no client is provided"
            ) from exc

        self._client = AsyncElasticsearch(hosts=hosts or ["http://localhost:9200"])

    def _index_name(self, timestamp: datetime) -> str:
        """Return index name for a timestamp using monthly rotation."""
        ts = timestamp.astimezone(UTC)
        return f"{self._index_prefix}-{ts.year:04d}-{ts.month:02d}"

    async def log(
        self,
        user_id: str,
        action: str,
        doctype: str,
        document_id: str,
        changes: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Log an audit entry into Elasticsearch."""
        entry = AuditEntry(
            user_id=user_id,
            action=action,
            doctype=doctype,
            document_id=document_id,
            changes=changes,
            metadata=metadata,
        )

        document = entry.model_dump(mode="json")
        await self._client.index(
            index=self._index_name(entry.timestamp),
            id=entry.id,
            document=document,
            refresh=False,
        )
        return entry.id

    async def query(
        self,
        filters: dict[str, Any] | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[AuditEntry]:
        """Query audit entries from Elasticsearch."""
        must_filters: list[dict[str, Any]] = []
        if filters:
            for key in ("user_id", "action", "doctype", "document_id"):
                if key in filters:
                    must_filters.append({"term": {key: filters[key]}})

        query: dict[str, Any]
        if must_filters:
            query = {"bool": {"filter": must_filters}}
        else:
            query = {"match_all": {}}

        response = await self._client.search(
            index=f"{self._index_prefix}-*",
            query=query,
            sort=[{"timestamp": {"order": "desc"}}],
            from_=offset,
            size=limit,
        )

        hits = response.get("hits", {}).get("hits", [])
        return [
            AuditEntry.model_validate(hit.get("_source", {}))
            for hit in hits
            if hit.get("_source")
        ]


__all__ = ["ElasticAuditAdapter"]
