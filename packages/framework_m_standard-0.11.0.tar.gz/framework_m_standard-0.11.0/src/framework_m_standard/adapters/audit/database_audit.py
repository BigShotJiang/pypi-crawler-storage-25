"""Database Audit Adapter - Database-backed audit logging for Indie mode.

This module provides DatabaseAuditAdapter for writing audit logs to the
ActivityLog table in the database. Ideal for Indie mode deployments where
logs can be queried via the Admin UI.

Features:
- Stores audit entries as ActivityLog DocType records
- Easy querying via SQL and Admin UI
- No external dependencies (Elasticsearch, file shipping)

Trade-offs vs FileAuditAdapter:
- Pro: Easy to query, view in Admin UI
- Con: Database bloat for high-volume applications

Configuration in framework_config.toml:
    [audit]
    adapter = "database"

Example:
    adapter = DatabaseAuditAdapter(repository=activity_log_repo)
    await adapter.log("user-001", "create", "Invoice", "INV-001")
"""

from __future__ import annotations

from typing import Any, cast

from framework_m_core.doctypes.activity_log import ActivityLog, ActivityLogAction
from framework_m_core.exceptions import PermissionDeniedError
from framework_m_core.interfaces.audit import (
    AuditEntry,
    AuditLogProtocol,
    InMemoryAuditAdapter,
)
from framework_m_core.interfaces.repository import (
    FilterOperator,
    FilterSpec,
    RepositoryProtocol,
)


class DatabaseAuditAdapter(AuditLogProtocol):
    """Database-backed audit adapter using ActivityLog DocType.

    Writes audit entries to the ActivityLog table in the database.
    Suitable for Indie mode where audit logs are queried via UI.

    Attributes:
        _repository: Repository for ActivityLog persistence

    Example:
        adapter = DatabaseAuditAdapter()
        await adapter.log("user-001", "create", "Todo", "TODO-001")

    Note:
        In production, this adapter would use a repository to persist
        ActivityLog records to the database. The current implementation
        uses in-memory storage for testing purposes.
    """

    def __init__(
        self,
        repository: RepositoryProtocol[ActivityLog] | None = None,
    ) -> None:
        """Initialize the database audit adapter.

        Args:
            repository: Repository for persisting ActivityLog entries.
                If omitted, falls back to in-memory storage for compatibility
                in lightweight/test app setups.
        """
        self._repository = repository
        self._fallback = InMemoryAuditAdapter() if repository is None else None

    async def log(
        self,
        user_id: str,
        action: str,
        doctype: str,
        document_id: str,
        changes: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Log an audit entry to the database.

        Creates an ActivityLog record in the database.

        Args:
            user_id: ID of the user performing the action
            action: Type of action ("create", "read", "update", "delete")
            doctype: Name of the DocType
            document_id: ID of the document
            changes: Optional field changes for updates
            metadata: Optional context (request_id, ip, etc.)

        Returns:
            ID of the created audit entry
        """
        if self._repository is None:
            return await self._fallback.log(  # type: ignore[union-attr]
                user_id=user_id,
                action=action,
                doctype=doctype,
                document_id=document_id,
                changes=changes,
                metadata=metadata,
            )

        entry = ActivityLog(
            user_id=user_id,
            action=cast(ActivityLogAction, action),
            doctype_name=doctype,
            document_id=document_id,
            diff=changes,
            metadata=metadata,
        )

        existing = await self._repository.get(entry.id)
        if isinstance(existing, ActivityLog):
            raise PermissionDeniedError(
                "ActivityLog is immutable; update-style writes are not allowed"
            )

        await self._repository.save(entry)

        return str(entry.id)

    async def query(
        self,
        filters: dict[str, Any] | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[AuditEntry]:
        """Query audit entries from the database.

        Retrieves ActivityLog records matching the given criteria.

        Args:
            filters: Optional filter criteria
            limit: Maximum entries to return
            offset: Number of entries to skip

        Returns:
            List of matching AuditEntry objects
        """
        if self._repository is None:
            return await self._fallback.query(  # type: ignore[union-attr]
                filters=filters,
                limit=limit,
                offset=offset,
            )

        repo_filters: list[FilterSpec] = []

        # Apply filters
        if filters:
            for key, value in filters.items():
                if key == "doctype":
                    repo_filters.append(
                        FilterSpec(
                            field="doctype_name",
                            operator=FilterOperator.EQ,
                            value=value,
                        )
                    )
                elif key == "from_timestamp":
                    repo_filters.append(
                        FilterSpec(
                            field="timestamp", operator=FilterOperator.GTE, value=value
                        )
                    )
                elif key == "to_timestamp":
                    repo_filters.append(
                        FilterSpec(
                            field="timestamp", operator=FilterOperator.LTE, value=value
                        )
                    )
                else:
                    repo_filters.append(
                        FilterSpec(field=key, operator=FilterOperator.EQ, value=value)
                    )

        result = await self._repository.list(
            filters=repo_filters,
            limit=limit,
            offset=offset,
        )

        # Convert ActivityLog to AuditEntry
        return [
            AuditEntry(
                id=str(r.id),
                timestamp=r.timestamp,
                user_id=r.user_id,
                action=r.action,
                doctype=r.doctype_name,
                document_id=r.document_id,
                changes=r.diff,
                metadata=r.metadata,
            )
            for r in result.items
        ]


__all__ = ["DatabaseAuditAdapter"]
