"""Environment Secret Adapter.

Implements SecretProtocol using environment variables (os.environ).
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


class EnvSecretAdapter:
    """Secret adapter that reads from environment variables.

    This is the default provider for Framework M, supporting the
    'Everything in Env Var' philosophy.
    """

    def get_secret(self, key: str, default: str | None = None) -> str | None:
        """Retrieve a secret from os.environ.

        Args:
            key: Environment variable name.
            default: Value to return if env var is missing.

        Returns:
            The env var value or default.
        """
        return os.environ.get(key, default)

    def list_required_secrets(self) -> list[str]:
        """Return list of keys currently in environment.

        Returns:
            List of environment variable names.
        """
        return list(os.environ.keys())


__all__ = ["EnvSecretAdapter"]
