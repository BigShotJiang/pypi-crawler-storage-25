"""BakeAugmentedModels - Bake dynamically registered metadata properties.

This bootstrap step runs the model baking process via MetaRegistry.
It ensures any properties added via the MetadataDecoratorRegistry are
compiled into new Pydantic models before the schema is synced to the database.
"""

from typing import Any

from framework_m_core.interfaces.bootstrap import BootstrapProtocol


class BakeAugmentedModels:
    """
    Bake augmented properties into all registered DocTypes.

    This locks the MetadataDecoratorRegistry and generates the final
    Python subclasses containing the dynamically appended fields.

    Order: 25 (after registries, before sync_schema)
    """

    name = "bake_augmented_models"
    order = 25

    async def run(self, container: Any) -> None:
        """
        Bake dynamic properties into DocTypes.

        Args:
            container: DI container with framework context
        """
        from framework_m_core.registry import MetaRegistry

        registry = MetaRegistry.get_instance()
        registry.bake_augmented_models()


assert isinstance(BakeAugmentedModels(), BootstrapProtocol)
