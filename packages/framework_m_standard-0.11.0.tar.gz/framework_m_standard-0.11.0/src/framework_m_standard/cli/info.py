"""CLI Info Plugin for framework-m-standard."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from rich.table import Table


def standard_info_plugin(table: Table) -> None:
    """Detect and add standard services information to 'm info'."""

    # Database
    db_url = os.environ.get("DATABASE_URL")
    if db_url:
        db_type = db_url.split(":", 1)[0]
        table.add_row("Database", f"Configured ({db_type})")
    else:
        table.add_row("Database", "In-Memory (Mock)")

    # Cache
    cache_url = os.environ.get("REDIS_URL") or os.environ.get("CACHE_URL")
    if cache_url:
        cache_type = "Redis" if "redis" in cache_url else "Configured"
        table.add_row("Cache", f"Configured ({cache_type})")
    else:
        table.add_row("Cache", "NA")

    # Events
    events_url = os.environ.get("NATS_URL") or os.environ.get("EVENT_BUS_URL")
    if events_url:
        events_type = "NATS" if "nats" in events_url else "Configured"
        table.add_row("Events", f"Configured ({events_type})")
    else:
        table.add_row("Events", "In-Memory (Mock)")

    # Storage
    storage_backend = os.environ.get("STORAGE_BACKEND")
    s3_bucket = os.environ.get("S3_BUCKET")
    if storage_backend == "s3" or s3_bucket:
        table.add_row("Storage", f"S3 ({s3_bucket or 'unknown bucket'})")
    elif storage_backend == "local":
        table.add_row(
            "Storage", f"Local ({os.environ.get('STORAGE_PATH', './storage')})"
        )
    else:
        table.add_row("Storage", "NA")

    # Jobs
    jobs_url = os.environ.get("NATS_URL")
    if jobs_url:
        table.add_row("Jobs", "Configured (NATS)")
    else:
        table.add_row("Jobs", "In-Memory (Mock)")
