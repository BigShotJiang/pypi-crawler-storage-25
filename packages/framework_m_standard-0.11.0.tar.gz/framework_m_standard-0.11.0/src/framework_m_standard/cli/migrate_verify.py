"""Migration Verification CLI Logic.

Provides logic for verifying blueprints against the current database
state using the Schema Introspection Protocol.
"""

import asyncio
import importlib.metadata
import os
import sys
from pathlib import Path
from typing import Annotated, Any

import cyclopts
from framework_m_core.domain.migration_engine import (
    MigrationEngine,
    RiskLevel,
    SchemaDiff,
)
from framework_m_core.interfaces.introspection import ColumnMeta, TableMeta


def get_introspection_adapter(engine_name: str) -> Any:
    """Resolve the introspection adapter based on the engine flag."""
    eps = importlib.metadata.entry_points(group="framework_m.adapters.introspection")
    for ep in eps:
        if ep.name == engine_name:
            adapter_class = ep.load()
            return adapter_class

    print(f"Error: Introspection engine '{engine_name}' not found.")
    sys.exit(1)  # pragma: no cover


async def run_verification(
    adapter_class: Any, database_url: str | None = None, apps: str | None = None
) -> list[SchemaDiff]:
    """Run the actual schema verification workflow against Blueprints."""
    from framework_m_core.config import load_config
    from framework_m_core.registry import MetaRegistry

    from framework_m_standard.adapters.db.connection import ConnectionFactory

    if apps:
        os.environ["INSTALLED_APPS"] = apps
        apps_list = [a.strip() for a in apps.split(",") if a.strip()]
        MetaRegistry.get_instance().load_apps(apps_list)

    config = load_config()
    db_url = database_url or os.environ.get(
        "DATABASE_URL",
        config.get("database", {}).get("url", "sqlite+aiosqlite:///./dev.db"),
    )

    connection_factory = ConnectionFactory()
    connection_factory.configure({"default": db_url})
    db_engine = connection_factory.get_engine("default")

    adapter = adapter_class(db_engine)
    current_tables = await adapter.introspect_database()
    current_table_map = {t.name: t for t in current_tables}

    registry = MetaRegistry.get_instance()
    diffs: list[SchemaDiff] = []

    for doctype_name in registry.list_doctypes():
        doctype_class = registry.get_doctype(doctype_name)
        table_name = doctype_name.lower()

        desired_columns = []
        for field_name, field_info in doctype_class.model_fields.items():
            field_type = str(field_info.annotation).upper()
            col_type = "VARCHAR"
            if "INT" in field_type:
                col_type = "INTEGER"
            elif "BOOL" in field_type:
                col_type = "BOOLEAN"

            max_length = next(
                (
                    meta.max_length
                    for meta in field_info.metadata
                    if hasattr(meta, "max_length")
                ),
                None,
            )

            desired_columns.append(
                ColumnMeta(
                    name=field_name,
                    type=col_type,
                    nullable=not field_info.is_required(),
                    primary_key=field_name == "id",
                    max_length=max_length,
                )
            )

        desired_meta = TableMeta(name=table_name, columns=desired_columns, indexes=[])
        current_meta = current_table_map.get(table_name)
        if not current_meta:
            current_meta = TableMeta(name=table_name, columns=[], indexes=[])

        engine_diff = MigrationEngine(current=current_meta, desired=desired_meta)
        diffs.extend(engine_diff.compare())

    await connection_factory.dispose_all()
    return diffs


def verify_migration_command(
    path: Annotated[
        Path,
        cyclopts.Parameter(name="--path", help="Path to the application directory"),
    ] = Path(),
    database_url: Annotated[
        str | None,
        cyclopts.Parameter(
            name=["--database-url", "-d"],
            env_var="DATABASE_URL",
            help="Database connection URL",
        ),
    ] = None,
    apps: Annotated[
        str | None,
        cyclopts.Parameter(
            name="--apps", help="Comma-separated list of apps to include"
        ),
    ] = None,
    engine: Annotated[
        str,
        cyclopts.Parameter(
            name="--engine", help="Introspection engine to use (default: sqlalchemy)"
        ),
    ] = "sqlalchemy",
) -> None:
    """Verify the desired blueprint schema against the current database.

    Performs a read-only introspection of the target database and compares
    it against the local Blueprints, outputting a risk-categorized report.
    """
    adapter_class = get_introspection_adapter(engine)

    diffs = asyncio.run(run_verification(adapter_class, database_url, apps))

    if not diffs:
        print("Schema is in sync. No changes detected.")
        return

    has_breaking = False

    for diff in diffs:
        if diff.risk == RiskLevel.BREAKING:
            print(f"[BREAKING] {diff.message}")
            has_breaking = True
        elif diff.risk == RiskLevel.WARNING:
            print(f"[WARNING] {diff.message}")
        elif diff.risk == RiskLevel.SAFE:
            print(f"[SAFE] {diff.message}")

    if has_breaking:
        sys.exit(1)  # pragma: no cover


__all__ = ["get_introspection_adapter", "run_verification", "verify_migration_command"]
