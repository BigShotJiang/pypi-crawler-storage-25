"""Framework M Standard - Default Adapters."""

import importlib.metadata

try:
    __version__ = importlib.metadata.version("framework-m-standard")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = ["__version__"]
