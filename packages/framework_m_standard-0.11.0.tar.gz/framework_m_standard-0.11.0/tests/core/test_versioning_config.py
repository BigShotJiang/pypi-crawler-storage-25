"""Tests for versioning configuration gate."""

from __future__ import annotations

from framework_m_standard.adapters.db.versioning_config import is_versioning_enabled
from pytest import MonkeyPatch


def test_returns_true_from_config_flag() -> None:
    """Versioning should be enabled when compliance flag is true."""
    config = {"compliance": {"versioning_enabled": True}}

    assert is_versioning_enabled(config) is True


def test_returns_false_when_config_missing() -> None:
    """Versioning should default to disabled when config keys are absent."""
    assert is_versioning_enabled({}) is False


def test_returns_false_from_config_flag() -> None:
    """Versioning should be disabled when compliance flag is false."""
    config = {"compliance": {"versioning_enabled": False}}

    assert is_versioning_enabled(config) is False


def test_env_true_overrides_config_false(monkeypatch: MonkeyPatch) -> None:
    """Environment variable should force-enable versioning regardless of config."""
    monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")
    config = {"compliance": {"versioning_enabled": False}}

    assert is_versioning_enabled(config) is True


def test_env_false_overrides_config_true(monkeypatch: MonkeyPatch) -> None:
    """Environment variable should force-disable versioning regardless of config."""
    monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "false")
    config = {"compliance": {"versioning_enabled": True}}

    assert is_versioning_enabled(config) is False


def test_loads_config_when_not_provided(monkeypatch: MonkeyPatch) -> None:
    """Function should call load_config() when config argument is omitted."""

    monkeypatch.setattr(
        "framework_m_standard.adapters.db.versioning_config.load_config",
        lambda: {"compliance": {"versioning_enabled": True}},
    )

    assert is_versioning_enabled() is True
