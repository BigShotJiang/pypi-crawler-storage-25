"""Targeted coverage restoration tests for Web Adapters.

This file hits specific uncovered logic branches identified in the coverage report
for meta_router.py and metadata_router.py.
"""

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.web.meta_router import (
    create_crud_routes,
    create_meta_router,
)
from framework_m_standard.adapters.web.metadata_router import (
    _merge_ui_meta_to_property,
    _normalize_nullable_property,
    _normalize_schema,
    _to_title_case,
    metadata_router,
)
from litestar import Litestar
from litestar.testing import TestClient

# =============================================================================
# Test Data
# =============================================================================


class CoverageDoc(BaseDocType):
    """DocType for coverage testing."""

    name: str = Field(default="Test")

    class Meta:
        api_resource = True


class SingletonDoc(BaseDocType):
    """Singleton DocType for coverage testing."""

    settings: str = Field(default="Default")

    class Meta:
        api_resource = True
        is_singleton = True


# =============================================================================
# Tests
# =============================================================================


class TestMetaRouterCoverage:
    """Targeted tests for uncovered branches in meta_router.py."""

    @pytest.fixture(autouse=True)
    def setup_registry(self):
        registry = MetaRegistry.get_instance()
        registry.clear()
        registry.register_doctype(CoverageDoc)
        registry.register_doctype(SingletonDoc)
        yield
        registry.clear()

    def test_meta_router_fallback_no_factory(self) -> None:
        """Test fallback behavior when repository factory is missing from app state."""
        app = Litestar(route_handlers=[create_crud_routes(CoverageDoc)])
        # Mock permission checks to focus on repository fallback logic
        with (
            patch(
                "framework_m_standard.adapters.web.meta_router._check_permission",
                return_value=None,
            ),
            TestClient(app) as client,
        ):
            response = client.post("/CoverageDoc/", json={"name": "New"})
            assert response.status_code == 201
            assert response.json()["name"] == "New"

    def test_get_entity_fallback_no_factory(self) -> None:
        """Test fallback behavior when repository factory is missing for GET operations."""
        app = Litestar(route_handlers=[create_crud_routes(CoverageDoc)])
        with (
            patch(
                "framework_m_standard.adapters.web.meta_router._check_permission",
                return_value=None,
            ),
            TestClient(app) as client,
        ):
            uid = uuid4()
            response = client.get(f"/CoverageDoc/{uid}")
            assert response.status_code == 200
            assert response.json()["doctype"] == "CoverageDoc"

    def test_singleton_get_and_put_logic(self) -> None:
        """Exercise singleton GET and PUT logic, including auto-initialization when record is missing."""
        # Setup mocks for repository and session
        mock_repo = MagicMock()
        mock_repo.get_singleton = AsyncMock(
            return_value=None
        )  # Simulate missing record
        mock_repo.save = AsyncMock(
            side_effect=lambda s, e: e
        )  # Return the saved entity

        mock_factory = MagicMock()
        mock_factory.get_repository.return_value = mock_repo
        # session_factory.get_session() returns an async context manager
        mock_session_manager = MagicMock()
        mock_session_manager.__aenter__ = AsyncMock(return_value=MagicMock())
        mock_session_manager.__aexit__ = AsyncMock(return_value=None)
        mock_factory.session_factory.get_session.return_value = mock_session_manager

        app = Litestar(route_handlers=[create_crud_routes(SingletonDoc)])
        app.state.repository_factory = mock_factory

        with (
            patch(
                "framework_m_standard.adapters.web.meta_router._check_permission",
                return_value=None,
            ),
            TestClient(app) as client,
        ):
            # GET singleton (exercises auto-creation logic)
            with patch.object(
                mock_repo, "get_singleton", new_callable=AsyncMock
            ) as mocked_get:
                mocked_get.return_value = None
                response = client.get("/SingletonDoc/singleton")
                assert response.status_code == 200
                assert response.json().get("is_new") is True

            # PUT singleton (exercises save logic)
            with patch.object(
                mock_repo, "get_singleton", new_callable=AsyncMock
            ) as mocked_get:
                mocked_get.return_value = None
                response = client.put(
                    "/SingletonDoc/singleton", json={"settings": "Updated"}
                )
                assert response.status_code == 200
                assert response.json()["settings"] == "Updated"

    def test_meta_router_discovery_skip_missing_doctype(self) -> None:
        """Verify that the discovery loop skips DocTypes that are registered but unreachable."""
        registry = MetaRegistry.get_instance()
        with (
            patch.object(registry, "list_doctypes", return_value=["GhostDoc"]),
            patch.object(registry, "get_doctype", return_value=None),
        ):
            router = create_meta_router()
            # Check that no routes were added to the router by checking the registered IDs
            assert len(router.registered_route_handler_ids) == 0


class TestMetadataRouterCoverage:
    """Targeted tests for uncovered branches in metadata_router.py."""

    def test_title_case_edge_cases(self) -> None:
        """Test title case normalization with empty or None inputs."""
        assert _to_title_case("") == ""
        assert _to_title_case(None) is None  # type: ignore

    def test_nullable_property_normalization_with_union_types(self) -> None:
        """Verify normalization of properties using JSON Schema union types (list style)."""
        prop = {"type": ["string", "null"]}
        normalized = _normalize_nullable_property(prop)
        assert normalized["type"] == "string"

        # Test multiple non-null types (should remain unchanged)
        prop2 = {"type": ["string", "integer", "null"]}
        assert _normalize_nullable_property(prop2)["type"] == [
            "string",
            "integer",
            "null",
        ]

    def test_schema_normalization_safety(self) -> None:
        """Test schema normalization when properties are malformed or missing."""
        schema = {"properties": "invalid"}
        assert _normalize_schema(schema)["properties"] == "invalid"

    def test_ui_meta_merge_with_empty_data(self) -> None:
        """Verify UI meta merging handles empty dictionaries gracefully."""
        prop = {"type": "string"}
        assert _merge_ui_meta_to_property(prop, {}) == prop

    def test_doctype_listing_error_handling(self) -> None:
        """Exercise error handling during DocType discovery when DocTypes encounter attribute errors."""
        registry = MetaRegistry.get_instance()
        registry.clear()
        with (
            patch.object(registry, "list_doctypes", return_value=["Broken"]),
            # object() lacks get_api_resource, triggering attribute error during discovery
            patch.object(registry, "get_doctype", return_value=object()),
        ):
            app = Litestar(route_handlers=[metadata_router])
            with TestClient(app) as client:
                response = client.get("/api/meta/doctypes")
                assert response.status_code == 200
                assert response.json()["doctypes"] == []
