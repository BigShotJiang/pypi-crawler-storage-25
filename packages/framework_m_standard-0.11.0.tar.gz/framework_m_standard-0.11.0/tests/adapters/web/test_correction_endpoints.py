"""Tests for correction REST endpoints and ActivityLog list API (RFC-0008 UI)."""

from __future__ import annotations

from datetime import UTC, datetime
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock

import pytest
from framework_m_core.interfaces.audit import AuditEntry
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_standard.adapters.web.correction_router import correction_router
from litestar import Litestar
from litestar.testing import TestClient
from litestar.types import ASGIApp, Receive, Scope, Send


class _SavedDoc:
    """Small response model stub used by correction endpoint tests."""

    def __init__(self, payload: dict[str, Any]) -> None:
        self._payload = payload

    def model_dump(self) -> dict[str, Any]:
        return dict(self._payload)


class _FakeAuditAdapter:
    """Query-only adapter used for ActivityLog endpoint tests."""

    def __init__(self, entries: list[AuditEntry]) -> None:
        self._entries = entries
        self.last_filters: dict[str, Any] | None = None

    async def query(
        self,
        filters: dict[str, Any] | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[AuditEntry]:
        self.last_filters = filters
        return self._entries[offset : offset + limit]


def _auth_middleware(app: ASGIApp) -> ASGIApp:
    async def middleware(scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http":
            if "state" not in scope:
                scope["state"] = {}
            # Inject UserContext if a special header is set
            if any(k == b"x-use-middleware" for k, _ in scope.get("headers", [])):
                scope["state"]["user"] = UserContext(
                    id="user-mid", email="m@m.m", roles=[]
                )
        await app(scope, receive, send)

    return middleware


@pytest.fixture
def app() -> Litestar:
    return Litestar(route_handlers=[correction_router], middleware=[_auth_middleware])


@pytest.fixture
def client(app: Litestar) -> TestClient[Litestar]:
    return TestClient(app)


def test_all_correction_endpoints_require_auth(client: TestClient[Litestar]) -> None:
    """POST correction endpoints should return 401 when user context is absent."""
    r1 = client.post("/api/v1/Invoice/abc/amend", json={"reason": "Typo fix"})
    r2 = client.post(
        "/api/v1/Invoice/abc/restore",
        json={"reason": "Restore", "version_no": 1},
    )
    r3 = client.post(
        "/api/v1/Invoice/abc/in_place_edit",
        json={"reason": "Ops fix"},
    )

    assert r1.status_code == 401
    assert r2.status_code == 401
    assert r3.status_code == 401


def test_amend_with_user_context_in_state(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    """Should use UserContext if it's already set in request.state.user."""
    app.state.correction_document_loader = AsyncMock(
        return_value=SimpleNamespace(id="abc")
    )
    service = AsyncMock()
    service.amend.return_value = _SavedDoc(
        {"id": "new", "name": "INV-001-1", "docstatus": 0}
    )
    app.state.correction_service = service

    response = client.post(
        "/api/v1/Invoice/abc/amend",
        headers={
            "x-use-middleware": "1"
        },  # triggers middleware to set request.state.user
        json={"reason": "Typo fix"},
    )

    assert response.status_code == 200


def test_amend_happy_path_returns_new_doc(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    loader = AsyncMock(return_value=SimpleNamespace(id="abc", name="INV-001"))
    service = AsyncMock()
    service.amend.return_value = _SavedDoc(
        {
            "id": "new-id",
            "name": "INV-001-1",
            "docstatus": 0,
        }
    )

    app.state.correction_document_loader = loader
    app.state.correction_service = service

    response = client.post(
        "/api/v1/Invoice/abc/amend",
        headers={"x-user-id": "user-001"},
        json={"reason": "Typo fix"},
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["id"] == "new-id"
    assert payload["name"] == "INV-001-1"
    assert payload["docstatus"] == 0


def test_amend_returns_404_for_missing_doc(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(return_value=None)
    app.state.correction_service = AsyncMock()

    response = client.post(
        "/api/v1/Invoice/missing/amend",
        headers={"x-user-id": "user-001"},
        json={"reason": "Typo fix"},
    )

    assert response.status_code == 404


def test_amend_returns_422_when_doc_not_submitted(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(
        return_value=SimpleNamespace(id="abc", name="INV-001")
    )
    service = AsyncMock()
    service.amend.side_effect = ValueError("Only submitted documents can be corrected")
    app.state.correction_service = service

    response = client.post(
        "/api/v1/Invoice/abc/amend",
        headers={"x-user-id": "user-001"},
        json={"reason": "Typo fix"},
    )

    assert response.status_code == 422


def test_amend_returns_503_for_missing_document_loader(
    client: TestClient[Litestar],
) -> None:
    response = client.post(
        "/api/v1/Invoice/abc/amend",
        headers={"x-user-id": "user-001"},
        json={"reason": "Typo fix"},
    )
    assert response.status_code == 503
    assert "Correction document loader" in response.text


def test_restore_returns_503_for_missing_snapshot_loader(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(
        return_value=SimpleNamespace(id="abc")
    )
    response = client.post(
        "/api/v1/Invoice/abc/restore",
        headers={"x-user-id": "user-001"},
        json={"reason": "Restore", "version_no": 1},
    )
    assert response.status_code == 503
    assert "Correction snapshot loader" in response.text


def test_amend_returns_503_for_missing_correction_service(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(
        return_value=SimpleNamespace(id="abc")
    )
    response = client.post(
        "/api/v1/Invoice/abc/amend",
        headers={"x-user-id": "user-001"},
        json={"reason": "Typo fix"},
    )
    assert response.status_code == 503
    assert "Correction service" in response.text


def test_restore_returns_404_for_missing_doc(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(return_value=None)
    app.state.correction_snapshot_loader = AsyncMock()
    app.state.correction_service = AsyncMock()
    response = client.post(
        "/api/v1/Invoice/missing/restore",
        headers={"x-user-id": "user-001"},
        json={"reason": "Restore", "version_no": 1},
    )
    assert response.status_code == 404


def test_restore_returns_400_when_version_not_found(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(
        return_value=SimpleNamespace(id="abc", name="INV-001")
    )
    app.state.correction_snapshot_loader = AsyncMock(return_value=None)
    app.state.correction_service = AsyncMock()

    response = client.post(
        "/api/v1/Invoice/abc/restore",
        headers={"x-user-id": "user-001"},
        json={"reason": "restore", "version_no": 1},
    )

    assert response.status_code == 400


def test_restore_returns_400_when_versioning_disabled(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(
        return_value=SimpleNamespace(id="abc", name="INV-001")
    )
    app.state.correction_snapshot_loader = AsyncMock(return_value={"name": "INV-001"})
    app.state.correction_service = AsyncMock()
    app.state.correction_versioning_enabled = False

    response = client.post(
        "/api/v1/Invoice/abc/restore",
        headers={"x-user-id": "user-001"},
        json={"reason": "restore", "version_no": 1},
    )

    assert response.status_code == 400


def test_restore_happy_path_returns_restored_doc(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(
        return_value=SimpleNamespace(id="abc")
    )
    app.state.correction_snapshot_loader = AsyncMock(return_value={"id": "abc"})
    service = AsyncMock()
    service.restore.return_value = _SavedDoc({"id": "abc", "name": "RESTORED"})
    app.state.correction_service = service

    response = client.post(
        "/api/v1/Invoice/abc/restore",
        headers={"x-user-id": "user-001"},
        json={"reason": "Restore", "version_no": 1},
    )
    assert response.status_code == 200
    assert response.json()["name"] == "RESTORED"


def test_restore_returns_422_on_value_error(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(
        return_value=SimpleNamespace(id="abc")
    )
    app.state.correction_snapshot_loader = AsyncMock(return_value={"id": "abc"})
    service = AsyncMock()
    service.restore.side_effect = ValueError("Cannot restore")
    app.state.correction_service = service

    response = client.post(
        "/api/v1/Invoice/abc/restore",
        headers={"x-user-id": "user-001"},
        json={"reason": "Restore", "version_no": 1},
    )
    assert response.status_code == 422
    assert "Cannot restore" in response.text


def test_in_place_edit_returns_404_for_missing_doc(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(return_value=None)
    app.state.correction_service = AsyncMock()
    response = client.post(
        "/api/v1/Invoice/missing/in_place_edit",
        headers={"x-user-id": "user-001"},
        json={"reason": "Ops fix"},
    )
    assert response.status_code == 404


def test_in_place_edit_returns_400_for_non_versioned_doctype(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(
        return_value=SimpleNamespace(id="abc", name="INV-001")
    )
    service = AsyncMock()
    service.in_place_edit.side_effect = ValueError(
        "in_place_edit requires VersionedMixin"
    )
    app.state.correction_service = service

    response = client.post(
        "/api/v1/Invoice/abc/in_place_edit",
        headers={"x-user-id": "user-001"},
        json={"reason": "Ops fix"},
    )

    assert response.status_code == 400


def test_in_place_edit_happy_path_returns_doc(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    app.state.correction_document_loader = AsyncMock(
        return_value=SimpleNamespace(id="abc")
    )
    service = AsyncMock()
    service.in_place_edit.return_value = _SavedDoc({"id": "abc", "name": "EDITED"})
    app.state.correction_service = service

    response = client.post(
        "/api/v1/Invoice/abc/in_place_edit",
        headers={"x-user-id": "user-001"},
        json={"reason": "Ops fix"},
    )
    assert response.status_code == 200
    assert response.json()["name"] == "EDITED"


def test_activity_log_list_filters_and_returns_desc_order(
    client: TestClient[Litestar],
    app: Litestar,
) -> None:
    older = AuditEntry(
        id="1",
        timestamp=datetime(2026, 1, 1, 10, 0, tzinfo=UTC),
        user_id="user-001",
        action="update",
        doctype="Invoice",
        document_id="INV-001",
        changes={"amount": {"old": 100, "new": 110}},
        metadata={"reason": "adjust"},
    )
    newer = AuditEntry(
        id="2",
        timestamp=datetime(2026, 1, 1, 11, 0, tzinfo=UTC),
        user_id="user-001",
        action="submit",
        doctype="Invoice",
        document_id="INV-001",
        changes=None,
        metadata=None,
    )
    fake_audit = _FakeAuditAdapter(entries=[older, newer])
    app.state.audit_adapter = fake_audit

    response = client.get(
        "/api/v1/ActivityLog?document_id=INV-001&doctype_name=Invoice"
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["total"] == 2
    assert payload["items"][0]["id"] == "2"
    assert payload["items"][1]["id"] == "1"
    assert payload["items"][1]["diff"]["amount"]["old"] == 100
    assert fake_audit.last_filters == {
        "document_id": "INV-001",
        "doctype": "Invoice",
    }


def test_activity_log_list_missing_audit_adapter(client: TestClient[Litestar]) -> None:
    response = client.get("/api/v1/ActivityLog")
    assert response.status_code == 503
    assert "Audit adapter is not configured" in response.text
