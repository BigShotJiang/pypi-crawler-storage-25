from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from framework_m_standard.adapters.web.middleware.locale import (
    LocaleResolutionMiddleware,
    parse_accept_language,
    provide_locale,
)


@pytest.mark.asyncio
async def test_locale_resolution_middleware():
    app = AsyncMock()
    middleware = LocaleResolutionMiddleware(app)

    # 1. Test from Accept-Language header
    scope = {
        "type": "http",
        "headers": [(b"accept-language", b"es-ES,es;q=0.9,en;q=0.8")],
        "state": {},
    }
    receive = AsyncMock()
    send = AsyncMock()

    await middleware(scope, receive, send)
    assert scope["state"]["locale"] == "es"

    # 2. Test from query parameter
    scope = {"type": "http", "headers": [], "query_string": b"lang=fr", "state": {}}
    await middleware(scope, receive, send)
    assert scope["state"]["locale"] == "fr"

    # 3. Test from cookie
    scope = {"type": "http", "headers": [(b"cookie", b"locale=de")], "state": {}}
    await middleware(scope, receive, send)
    assert scope["state"]["locale"] == "de"

    # 4. Test priority: Query > Cookie > Header
    scope = {
        "type": "http",
        "headers": [(b"cookie", b"locale=de"), (b"accept-language", b"en")],
        "query_string": b"lang=fr",
        "state": {},
    }
    await middleware(scope, receive, send)
    assert scope["state"]["locale"] == "fr"

    # 5. Test default fallback
    scope = {"type": "http", "headers": [], "state": {}}
    await middleware(scope, receive, send)
    assert scope["state"]["locale"] == "en"  # assuming "en" is default in core/config


def test_parse_accept_language_without_q() -> None:
    """Should parse locale even if no quality value is given."""
    assert parse_accept_language("fr-FR, fr") == "fr"


@pytest.mark.asyncio
async def test_locale_resolution_middleware_non_http() -> None:
    """Should bypass completely for non-http/websocket scopes."""
    app = AsyncMock()
    middleware = LocaleResolutionMiddleware(app)
    scope = {"type": "lifespan"}
    receive = AsyncMock()
    send = AsyncMock()
    await middleware(scope, receive, send)
    app.assert_awaited_once_with(scope, receive, send)


@pytest.mark.asyncio
async def test_locale_from_user_preference() -> None:
    """Should read locale from authenticated user context."""
    app = AsyncMock()
    middleware = LocaleResolutionMiddleware(app)
    mock_auth = MagicMock()
    mock_auth.user.locale = "it"
    scope = {
        "type": "http",
        "headers": [],
        "query_string": b"",
        "state": {"auth": mock_auth},
    }
    await middleware(scope, AsyncMock(), AsyncMock())
    assert scope["state"]["locale"] == "it"


@pytest.mark.asyncio
async def test_locale_from_tenant_preference() -> None:
    """Should read locale from tenant context."""
    app = AsyncMock()
    middleware = LocaleResolutionMiddleware(app)
    mock_tenant = MagicMock()
    mock_tenant.attributes = {"default_locale": "pt"}
    scope = {
        "type": "http",
        "headers": [],
        "query_string": b"",
        "state": {"tenant": mock_tenant},
    }
    await middleware(scope, AsyncMock(), AsyncMock())
    assert scope["state"]["locale"] == "pt"


def test_provide_locale() -> None:
    """Dependency should return resolved locale from request state."""
    request = MagicMock()
    request.state.locale = "es"
    assert provide_locale(request) == "es"

    # Fallback to default if not set
    request2 = MagicMock()
    del request2.state.locale
    assert provide_locale(request2) == "en"
