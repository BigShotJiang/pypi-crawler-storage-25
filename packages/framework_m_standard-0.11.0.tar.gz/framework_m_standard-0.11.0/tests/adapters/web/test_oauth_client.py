"""Tests for the pure OAuthHTTPClient."""

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from framework_m_standard.adapters.web.oauth_client import OAuthHTTPClient
from litestar.exceptions import NotAuthorizedException


@pytest.mark.asyncio
async def test_fetch_discovery_metadata_success() -> None:
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "authorization_endpoint": "https://auth",
        "token_endpoint": "https://token",
        "userinfo_endpoint": "https://user",
    }

    mock_client = MagicMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.get = AsyncMock(return_value=mock_resp)

    with patch("httpx.AsyncClient", return_value=mock_client):
        res = await OAuthHTTPClient.fetch_discovery_metadata("https://test")
        assert res["authorization_url"] == "https://auth"
        assert res["token_url"] == "https://token"


@pytest.mark.asyncio
async def test_fetch_discovery_metadata_http_error() -> None:
    mock_client = MagicMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.get = AsyncMock(side_effect=httpx.HTTPError("Network failed"))

    with (
        patch("httpx.AsyncClient", return_value=mock_client),
        pytest.raises(NotAuthorizedException, match="network error"),
    ):
        await OAuthHTTPClient.fetch_discovery_metadata("https://test")


@pytest.mark.asyncio
async def test_fetch_discovery_metadata_not_200() -> None:
    mock_resp = MagicMock()
    mock_resp.status_code = 500

    mock_client = MagicMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.get = AsyncMock(return_value=mock_resp)

    with (
        patch("httpx.AsyncClient", return_value=mock_client),
        pytest.raises(NotAuthorizedException, match="OIDC discovery failed"),
    ):
        await OAuthHTTPClient.fetch_discovery_metadata("https://test")


@pytest.mark.asyncio
async def test_fetch_discovery_metadata_missing_endpoints() -> None:
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    # Missing token_endpoint
    mock_resp.json.return_value = {"authorization_endpoint": "https://auth"}

    mock_client = MagicMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.get = AsyncMock(return_value=mock_resp)

    with (
        patch("httpx.AsyncClient", return_value=mock_client),
        pytest.raises(NotAuthorizedException, match="missing required endpoints"),
    ):
        await OAuthHTTPClient.fetch_discovery_metadata("https://test")


@pytest.mark.asyncio
async def test_fetch_userinfo_success() -> None:
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {"sub": "123", "email": "test@test.com"}

    mock_client = MagicMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.get = AsyncMock(return_value=mock_resp)

    with patch("httpx.AsyncClient", return_value=mock_client):
        res = await OAuthHTTPClient.fetch_userinfo("google", "token", "https://user")
        assert res["email"] == "test@test.com"


@pytest.mark.asyncio
async def test_fetch_userinfo_not_200() -> None:
    mock_resp = MagicMock()
    mock_resp.status_code = 401

    mock_client = MagicMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.get = AsyncMock(return_value=mock_resp)

    with (
        patch("httpx.AsyncClient", return_value=mock_client),
        pytest.raises(NotAuthorizedException, match="Failed to fetch userinfo"),
    ):
        await OAuthHTTPClient.fetch_userinfo("google", "token", "https://user")


@pytest.mark.asyncio
async def test_fetch_userinfo_github_fallback() -> None:
    user_resp = MagicMock(status_code=200)
    user_resp.json.return_value = {"login": "octocat", "id": 1}

    emails_resp = MagicMock(status_code=200)
    emails_resp.json.return_value = [
        {"email": "octo@github.com", "primary": True, "verified": True}
    ]

    mock_client = MagicMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.get = AsyncMock(side_effect=[user_resp, emails_resp])

    with patch("httpx.AsyncClient", return_value=mock_client):
        userinfo = await OAuthHTTPClient.fetch_userinfo(
            "github", "token", "url", "emails_url"
        )
        assert userinfo["email"] == "octo@github.com"
        assert userinfo["email_verified"] is True


@pytest.mark.asyncio
async def test_fetch_userinfo_network_error() -> None:
    mock_client = MagicMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.get = AsyncMock(side_effect=httpx.HTTPError("Network down"))

    with (
        patch("httpx.AsyncClient", return_value=mock_client),
        pytest.raises(NotAuthorizedException, match="Network error fetching userinfo"),
    ):
        await OAuthHTTPClient.fetch_userinfo("google", "token", "https://user")


@pytest.mark.asyncio
async def test_exchange_code_for_tokens_success() -> None:
    mock_token = MagicMock()
    mock_token.access_token = "access"
    mock_token.token_type = "bearer"
    mock_token.expires_in = 3600
    mock_token.refresh_token = "refresh"
    mock_token.scope = "openid email"

    mock_adapter = MagicMock()
    mock_adapter.exchange_code = AsyncMock(return_value=mock_token)

    with patch(
        "framework_m_standard.adapters.web.oauth_client.OAuthAdapter",
        return_value=mock_adapter,
    ):
        res = await OAuthHTTPClient.exchange_code_for_tokens(
            "code", "https://token", {}, "openid"
        )
        assert res["access_token"] == "access"
        assert res["refresh_token"] == "refresh"


@pytest.mark.asyncio
async def test_exchange_code_for_tokens_error() -> None:
    with (
        patch(
            "framework_m_standard.adapters.web.oauth_client.OAuthAdapter",
            side_effect=Exception("Crash"),
        ),
        pytest.raises(NotAuthorizedException, match="Token exchange failed"),
    ):
        await OAuthHTTPClient.exchange_code_for_tokens(
            "code", "https://token", {}, "openid"
        )
