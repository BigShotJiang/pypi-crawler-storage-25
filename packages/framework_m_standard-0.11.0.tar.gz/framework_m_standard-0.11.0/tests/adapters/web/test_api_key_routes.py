"""Tests for API Key Management Routes.

TDD: This test file is created BEFORE the implementation.

Tests cover:
- POST /api/v1/auth/api-keys - Create new API key
- DELETE /api/v1/auth/api-keys/{id} - Revoke API key
- GET /api/v1/auth/api-keys - List user's API keys
"""

import pytest

# =============================================================================
# Test: API Key Routes Import
# =============================================================================


class TestApiKeyRoutesImport:
    """Tests for API Key routes import."""

    def test_import_api_key_routes_router(self) -> None:
        """api_key_routes_router should be importable."""
        from framework_m_standard.adapters.web.api_key_routes import (
            api_key_routes_router,
        )

        assert api_key_routes_router is not None


class TestApiKeyRoutesConfig:
    """Tests for API Key routes configuration."""

    def test_router_has_correct_path(self) -> None:
        """API Key router should be mounted at /api/v1/auth/api-keys."""
        from framework_m_standard.adapters.web.api_key_routes import (
            api_key_routes_router,
        )

        assert api_key_routes_router.path == "/api/v1/auth/api-keys"

    def test_router_has_auth_tag(self) -> None:
        """API Key router should have 'auth' tag."""
        from framework_m_standard.adapters.web.api_key_routes import (
            api_key_routes_router,
        )

        assert "auth" in api_key_routes_router.tags


# =============================================================================
# Test: Create API Key
# =============================================================================


class TestCreateApiKeyImport:
    """Tests for create_api_key handler import."""

    def test_import_create_api_key(self) -> None:
        """create_api_key handler should be importable."""
        from framework_m_standard.adapters.web.api_key_routes import create_api_key

        assert create_api_key is not None


class TestCreateApiKeyRequest:
    """Tests for CreateApiKeyRequest model."""

    def test_import_create_api_key_request(self) -> None:
        """CreateApiKeyRequest should be importable."""
        from framework_m_standard.adapters.web.api_key_routes import CreateApiKeyRequest

        assert CreateApiKeyRequest is not None

    def test_create_request_with_name(self) -> None:
        """CreateApiKeyRequest should accept name."""
        from framework_m_standard.adapters.web.api_key_routes import CreateApiKeyRequest

        request = CreateApiKeyRequest(name="My API Key")
        assert request.name == "My API Key"

    def test_create_request_with_scopes(self) -> None:
        """CreateApiKeyRequest should accept optional scopes."""
        from framework_m_standard.adapters.web.api_key_routes import CreateApiKeyRequest

        request = CreateApiKeyRequest(name="Key", scopes=["read", "write"])
        assert request.scopes == ["read", "write"]

    def test_create_request_with_expires_in_days(self) -> None:
        """CreateApiKeyRequest should accept optional expires_in_days."""
        from framework_m_standard.adapters.web.api_key_routes import CreateApiKeyRequest

        request = CreateApiKeyRequest(name="Key", expires_in_days=30)
        assert request.expires_in_days == 30


class TestCreateApiKeyHandler:
    """Tests for create_api_key handler execution."""

    @pytest.mark.asyncio
    async def test_create_api_key_without_expiry(self) -> None:
        from framework_m_standard.adapters.web.api_key_routes import (
            CreateApiKeyRequest,
            create_api_key,
        )

        req = CreateApiKeyRequest(name="Test Key")
        resp = await create_api_key.fn(data=req)

        assert resp.name == "Test Key"
        assert resp.expires_at is None
        assert resp.key.startswith("fm_")

    @pytest.mark.asyncio
    async def test_create_api_key_with_expiry(self) -> None:
        from framework_m_standard.adapters.web.api_key_routes import (
            CreateApiKeyRequest,
            create_api_key,
        )

        req = CreateApiKeyRequest(name="Test Key", expires_in_days=30)
        resp = await create_api_key.fn(data=req)

        assert resp.name == "Test Key"
        assert resp.expires_at is not None
        assert resp.key.startswith("fm_")


class TestListApiKeysHandler:
    """Tests for list_api_keys handler execution."""

    @pytest.mark.asyncio
    async def test_list_api_keys(self) -> None:
        from framework_m_standard.adapters.web.api_key_routes import list_api_keys

        resp = await list_api_keys.fn()
        assert resp == []


# =============================================================================
# Test: Revoke API Key
# =============================================================================


class TestRevokeApiKeyImport:
    """Tests for revoke_api_key handler import."""

    def test_import_revoke_api_key(self) -> None:
        """revoke_api_key handler should be importable."""
        from framework_m_standard.adapters.web.api_key_routes import revoke_api_key

        assert revoke_api_key is not None

    @pytest.mark.asyncio
    async def test_revoke_api_key_handler(self) -> None:
        """revoke_api_key handler should execute."""
        from framework_m_standard.adapters.web.api_key_routes import revoke_api_key

        resp = await revoke_api_key.fn(key_id="test_id")
        assert resp["message"] == "API key revoked"
        assert resp["id"] == "test_id"
