"""Tests for OAuthStateManager."""

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock

import pytest
from framework_m_standard.adapters.web.oauth_state_manager import OAuthStateManager
from litestar.exceptions import NotAuthorizedException


@pytest.mark.asyncio
async def test_store_state_no_store() -> None:
    """Should safely return if session store is None."""
    await OAuthStateManager.store_state(None, "state123", MagicMock())


@pytest.mark.asyncio
async def test_store_state_with_store() -> None:
    """Should create state session with inferred redirect user-agent."""
    mock_store = AsyncMock()
    request = MagicMock()
    request.headers = {"origin": "http://localhost:5173"}

    await OAuthStateManager.store_state(mock_store, "state123", request)

    mock_store.create.assert_called_once()
    kwargs = mock_store.create.call_args.kwargs
    assert kwargs["user_id"] == "oauth_state:state123"
    assert kwargs["user_agent"] == "post_login_redirect:http://localhost:5173/desk"


@pytest.mark.asyncio
async def test_validate_and_consume_no_store() -> None:
    """Should raise error if store missing during validation."""
    with pytest.raises(NotAuthorizedException, match="not configured"):
        await OAuthStateManager.validate_and_consume(None, "state123")


@pytest.mark.asyncio
async def test_validate_and_consume_missing_state() -> None:
    """Should raise error if state is not found."""
    mock_store = AsyncMock()
    mock_store.list_for_user.return_value = []

    with pytest.raises(NotAuthorizedException, match="Invalid or expired"):
        await OAuthStateManager.validate_and_consume(mock_store, "state123")


@pytest.mark.asyncio
async def test_validate_and_consume_valid_state() -> None:
    """Should validate state, delete it, and extract redirect."""
    mock_store = AsyncMock()
    session = MagicMock()
    session.created_at = datetime.now(UTC)
    session.user_agent = "post_login_redirect:http://localhost:5173/desk"
    session.session_id = "sess_123"
    mock_store.list_for_user.return_value = [session]

    redirect = await OAuthStateManager.validate_and_consume(mock_store, "state123")

    assert redirect == "http://localhost:5173/desk"
    mock_store.delete.assert_called_once_with("sess_123")


@pytest.mark.asyncio
async def test_validate_and_consume_expired_state() -> None:
    """Should reject state older than TTL."""
    mock_store = AsyncMock()
    session = MagicMock()
    session.created_at = datetime.now(UTC) - timedelta(minutes=20)
    session.session_id = "sess_123"
    mock_store.list_for_user.return_value = [session]

    with pytest.raises(NotAuthorizedException, match="Invalid or expired"):
        await OAuthStateManager.validate_and_consume(mock_store, "state123")


def test_is_allowed_state_redirect() -> None:
    """Should only allow local dev origins and specific paths."""
    assert (
        OAuthStateManager.is_allowed_state_redirect("http://localhost:5173/desk")
        is True
    )
    assert (
        OAuthStateManager.is_allowed_state_redirect("https://127.0.0.1:5173/desk/")
        is True
    )

    assert (
        OAuthStateManager.is_allowed_state_redirect("http://malicious.com/desk")
        is False
    )
    assert (
        OAuthStateManager.is_allowed_state_redirect("http://localhost:5173/other")
        is False
    )
    assert (
        OAuthStateManager.is_allowed_state_redirect("ftp://localhost:5173/desk")
        is False
    )


def test_extract_state_redirect() -> None:
    """Should correctly parse user_agent string into redirect."""
    assert (
        OAuthStateManager.extract_state_redirect(
            "post_login_redirect:http://localhost:5173/desk"
        )
        == "http://localhost:5173/desk"
    )
    assert (
        OAuthStateManager.extract_state_redirect("post_login_redirect:http://bad.com")
        is None
    )
    assert OAuthStateManager.extract_state_redirect("Mozilla/5.0") is None
    assert OAuthStateManager.extract_state_redirect(None) is None


def test_infer_state_post_login_redirect() -> None:
    """Should check headers to infer origin redirect."""
    req1 = MagicMock(headers={"origin": "http://localhost:5173"})
    assert (
        OAuthStateManager.infer_state_post_login_redirect(req1)
        == "http://localhost:5173/desk"
    )

    req2 = MagicMock(headers={"referer": "http://127.0.0.1:5173/docs"})
    assert (
        OAuthStateManager.infer_state_post_login_redirect(req2)
        == "http://127.0.0.1:5173/desk"
    )

    req3 = MagicMock(headers={"origin": "http://prod.com"})
    assert OAuthStateManager.infer_state_post_login_redirect(req3) is None

    assert (
        OAuthStateManager.infer_state_post_login_redirect(MagicMock(headers=None))
        is None
    )
