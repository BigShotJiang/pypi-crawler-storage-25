"""End-to-End Authentication Integration Tests (RFC-0006 Strategy A: BFF Cookie Mode).

These tests exercise the FULL HTTP-level auth flow using the real Litestar app
(create_app() + TestClient) with mocked UserManager and SessionStore.

The key challenge: create_app() calls configure_auth_routes(real_user_manager)
during app lifespan startup. We override it AFTER the TestClient context manager
starts (i.e., after lifespan has run), so our mocks win.

Tests cover (as specified in task.md):
1. Full login → Set-Cookie response
2. Authenticated session → /me returns user, protected API returns correct status
3. Logout → cookie cleared, subsequent /me returns guest
"""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.identity import Token
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.web.app import create_app
from litestar.testing import TestClient

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture(autouse=True)
def reset_registry():
    """Clear MetaRegistry before and after each test to avoid DuplicateDocTypeError."""
    MetaRegistry.get_instance()._doctypes.clear()
    yield
    MetaRegistry.get_instance()._doctypes.clear()


@pytest.fixture
def mock_user() -> UserContext:
    """Standard test user."""
    return UserContext(
        id="user-e2e-001",
        email="e2e@example.com",
        name="E2E Test User",
        roles=["User"],
        tenants=[],
    )


@pytest.fixture
def mock_session_id() -> str:
    return "sess_e2e_test_abc123xyz"


def _make_user_manager_mock(mock_user: UserContext, side_effect=None):
    """Build a mock UserManager that authenticates and returns mock_user."""
    mm = AsyncMock()
    if side_effect:
        mm.authenticate = AsyncMock(side_effect=side_effect)
    else:
        mm.authenticate = AsyncMock(
            return_value=Token(
                access_token="internal-jwt",
                token_type="bearer",
                expires_in=86400,
            )
        )
    mm.get_by_email = AsyncMock(return_value=mock_user)
    return mm


def _make_session_store_mock(mock_session_id: str, mock_user: UserContext):
    """Build a mock SessionStore."""
    mock_session = MagicMock()
    mock_session.session_id = mock_session_id

    ss = AsyncMock()
    ss.create = AsyncMock(return_value=mock_session)
    ss.delete = AsyncMock(return_value=True)
    ss.get = AsyncMock(return_value=mock_user)
    return ss


@contextmanager
def _override_auth_singletons(user_manager, session_store) -> Generator:
    """
    Context manager: override auth_routes module-level singletons.

    Use this INSIDE the TestClient context (after lifespan has fired) so our
    mocks are the last thing set before the HTTP request executes.
    """
    import framework_m_standard.adapters.web.auth_routes as auth_mod
    from framework_m_standard.adapters.web.auth_routes import (
        configure_auth_routes,
        configure_session_store,
    )

    original_um = getattr(auth_mod, "_user_manager", None)
    original_ss = getattr(auth_mod, "_session_store", None)
    try:
        configure_auth_routes(user_manager)
        configure_session_store(session_store)
        yield
    finally:
        auth_mod._user_manager = original_um
        auth_mod._session_store = original_ss


# =============================================================================
# Test 1: Full Login Flow → Set-Cookie
# =============================================================================


class TestLoginFlow:
    """E2E: POST /api/v1/auth/login sets HttpOnly session cookie."""

    def test_login_returns_set_cookie_header(
        self, mock_user: UserContext, mock_session_id: str
    ) -> None:
        """
        POST /api/v1/auth/login with valid credentials should:
        - Return HTTP 200
        - Body contains user info (NOT access_token — BFF Cookie Mode)
        - Set-Cookie header: session_id=<id>; HttpOnly; SameSite=Lax
        """
        um = _make_user_manager_mock(mock_user)
        ss = _make_session_store_mock(mock_session_id, mock_user)

        app = create_app(serve_static=False)
        with TestClient(app) as client, _override_auth_singletons(um, ss):
            response = client.post(
                "/api/v1/auth/login",
                json={"email": "e2e@example.com", "password": "correct_password"},
            )

        assert response.status_code in (
            200,
            201,
        ), f"Expected 200/201, got {response.status_code}: {response.text}"

        body = response.json()
        # BFF Cookie Mode: NO access_token in body
        assert "access_token" not in body, "Cookie mode must NOT return access_token"
        # Should return user info or session confirmation
        assert "user" in body or "session_cookie_set" in body

        # Set-Cookie MUST be present
        set_cookie = response.headers.get("set-cookie", "")
        assert "session_id=" in set_cookie, (
            f"Missing session cookie — got: {set_cookie!r}"
        )
        assert "HttpOnly" in set_cookie, "Cookie must be HttpOnly"
        assert "SameSite" in set_cookie, "Cookie must have SameSite attribute"

    def test_login_with_wrong_password_returns_401(
        self, mock_user: UserContext, mock_session_id: str
    ) -> None:
        """POST /login with bad credentials should return HTTP 401."""
        from framework_m_core.exceptions import AuthenticationError

        um = _make_user_manager_mock(
            mock_user,
            side_effect=AuthenticationError("Invalid credentials"),
        )
        ss = _make_session_store_mock(mock_session_id, mock_user)

        app = create_app(serve_static=False)
        with TestClient(app) as client, _override_auth_singletons(um, ss):
            response = client.post(
                "/api/v1/auth/login",
                json={"email": "e2e@example.com", "password": "WRONG"},
            )

        assert response.status_code == 401
        assert "detail" in response.json()


# =============================================================================
# Test 2: Authenticated Session → /me + Protected API
# =============================================================================


class TestAuthenticatedSession:
    """E2E: Valid session cookie authorises /me and enforced endpoints."""

    def test_me_returns_authenticated_user_when_auth_chain_resolves(
        self, mock_user: UserContext, mock_session_id: str
    ) -> None:
        """
        GET /me returns {authenticated: true, id, email, roles} when the auth
        chain resolves a user.

        Patches AuthChain.authenticate() to return mock_user, bypassing the
        need for a real session DB or Redis. This directly tests that the
        middleware injects user into request.state.user and that the /me
        route handler reads it correctly.
        """
        from framework_m_standard.adapters.auth.strategies import AuthChain

        app = create_app(serve_static=False)
        with (
            TestClient(app) as client,
            patch.object(
                AuthChain,
                "authenticate",
                return_value=mock_user,
            ),
        ):
            response = client.get("/api/v1/auth/me")

        assert response.status_code == 200
        body = response.json()
        assert body["authenticated"] is True
        assert body["id"] == mock_user.id
        assert body["email"] == mock_user.email
        assert "User" in body["roles"]

    def test_me_returns_guest_without_cookie(self) -> None:
        """
        GET /me with NO cookie returns HTTP 200 with authenticated=false.
        (/me is a non-enforced path — guests can call it without 401.)
        """
        app = create_app(serve_static=False)
        with TestClient(app) as client:
            response = client.get("/api/v1/auth/me")

        assert response.status_code == 200
        body = response.json()
        assert body["authenticated"] is False
        assert body["id"] == "guest"

    def test_public_endpoint_is_accessible_without_cookie(self) -> None:
        """Global middleware should not block guests for public endpoints."""
        app = create_app(serve_static=False)
        with TestClient(app) as client:
            response = client.get("/api/meta/doctypes")

        assert response.status_code == 200


# =============================================================================
# Test 3: Logout → Cookie Cleared → Guest
# =============================================================================


class TestLogoutFlow:
    """E2E: POST /logout clears cookie and session, subsequent /me returns guest."""

    def test_logout_clears_session_cookie(
        self, mock_user: UserContext, mock_session_id: str
    ) -> None:
        """
        POST /logout with a valid session cookie:
        - Returns HTTP 200
        - Set-Cookie: session_id=; Max-Age=0 (clears browser cookie)
        - Calls session store delete()
        """
        um = _make_user_manager_mock(mock_user)
        ss = _make_session_store_mock(mock_session_id, mock_user)

        app = create_app(serve_static=False)
        with TestClient(app) as client, _override_auth_singletons(um, ss):
            response = client.post(
                "/api/v1/auth/logout",
                cookies={"session_id": mock_session_id},
            )
            # Verify session store received the delete call
            ss.delete.assert_called_once_with(mock_session_id)

        assert response.status_code in (
            200,
            201,
        ), f"Expected 200/201 for logout, got {response.status_code}: {response.text}"
        set_cookie = response.headers.get("set-cookie", "")
        assert "session_id=" in set_cookie, (
            f"Logout must clear session cookie: {set_cookie!r}"
        )
        # Cookie is cleared by Max-Age=0 or empty/expired value
        assert (
            "Max-Age=0" in set_cookie
            or "session_id=;" in set_cookie
            or 'session_id=""' in set_cookie
        ), f"Logout cookie should have Max-Age=0 to expire it, got: {set_cookie!r}"

    def test_full_login_authenticated_logout_guest_round_trip(
        self, mock_user: UserContext, mock_session_id: str
    ) -> None:
        """
        Full BFF Cookie Mode round-trip:
          1. POST /login → 200 + Set-Cookie: session_id=...
          2. GET /me with cookie → {authenticated: true, email: ...}
          3. POST /logout → 200 + Set-Cookie: session_id=; Max-Age=0
          4. GET /me without cookie → {authenticated: false, id: 'guest'}
        """
        um = _make_user_manager_mock(mock_user)
        ss = _make_session_store_mock(mock_session_id, mock_user)

        app = create_app(serve_static=False)
        with TestClient(app) as client:
            with _override_auth_singletons(um, ss):
                # --- Step 1: Login ---
                login_resp = client.post(
                    "/api/v1/auth/login",
                    json={"email": "e2e@example.com", "password": "correct_password"},
                )
                assert login_resp.status_code in (
                    200,
                    201,
                ), f"Login failed: {login_resp.text}"
                assert "session_id=" in login_resp.headers.get("set-cookie", "")

                # --- Step 2: GET /me authenticated (patch AuthChain) ---
                from unittest.mock import patch as _patch

                from framework_m_standard.adapters.auth.strategies import (
                    AuthChain as _AuthChain,
                )

                with _patch.object(_AuthChain, "authenticate", return_value=mock_user):
                    me_resp = client.get("/api/v1/auth/me")
                assert me_resp.status_code == 200
                assert me_resp.json()["authenticated"] is True
                assert me_resp.json()["email"] == mock_user.email

                # --- Step 3: Logout ---
                logout_resp = client.post(
                    "/api/v1/auth/logout",
                    cookies={"session_id": mock_session_id},
                )
                assert logout_resp.status_code in (200, 201)

            # --- Step 4: GET /me without cookie → guest (outside auth override) ---
            guest_resp = client.get("/api/v1/auth/me")
            assert guest_resp.status_code == 200
            assert guest_resp.json()["authenticated"] is False
            assert guest_resp.json()["id"] == "guest"
