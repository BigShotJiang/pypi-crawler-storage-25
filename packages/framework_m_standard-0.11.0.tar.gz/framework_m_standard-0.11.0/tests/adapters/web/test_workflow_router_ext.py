"""Extended Tests for Workflow Router.

Covers missing branches when workflow_service is wired in app state.
"""

from unittest.mock import AsyncMock, MagicMock

import pytest
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.workflow import TransitionResult
from framework_m_standard.adapters.web.workflow_router import workflow_router
from litestar import Litestar
from litestar.testing import TestClient
from litestar.types import ASGIApp, Receive, Scope, Send


def create_test_app(
    workflow_service: AsyncMock | None = None, user: UserContext | None = None
) -> Litestar:
    """Helper to create a test app with mocked state."""

    def middleware_factory(app: ASGIApp) -> ASGIApp:
        async def middleware(scope: Scope, receive: Receive, send: Send) -> None:
            if "state" not in scope:
                scope["state"] = {}
            scope["state"]["user"] = user
            await app(scope, receive, send)

        return middleware

    app = Litestar(route_handlers=[workflow_router], middleware=[middleware_factory])
    app.state.workflow_service = workflow_service
    return app


@pytest.mark.asyncio
async def test_get_workflow_state_found() -> None:
    """Should return state from workflow service."""
    mock_service = AsyncMock()
    mock_state = MagicMock()
    mock_state.doctype = "Invoice"
    mock_state.document_id = "123"
    mock_state.workflow_name = "test_wf"
    mock_state.current_state = "Approved"
    mock_state.updated_at.isoformat.return_value = "2024-01-01T00:00:00+00:00"
    mock_state.updated_by = "user-1"
    mock_service.get_workflow_state.return_value = mock_state

    app = create_test_app(workflow_service=mock_service)

    with TestClient(app=app) as client:
        res = client.get("/api/v1/workflow/Invoice/123/state")
        assert res.status_code == 200
        data = res.json()
        assert data["current_state"] == "Approved"


@pytest.mark.asyncio
async def test_get_workflow_state_not_found() -> None:
    """Should return 404 if state not found in service."""
    mock_service = AsyncMock()
    mock_service.get_workflow_state.return_value = None

    app = create_test_app(workflow_service=mock_service)

    with TestClient(app=app) as client:
        res = client.get("/api/v1/workflow/Invoice/123/state")
        assert res.status_code == 404


@pytest.mark.asyncio
async def test_get_available_actions_with_user() -> None:
    """Should return actions from service when user is present."""
    mock_service = AsyncMock()
    mock_state = MagicMock()
    mock_state.current_state = "Pending"
    mock_service.get_workflow_state.return_value = mock_state
    mock_service.get_available_actions.return_value = ["Approve", "Reject"]

    mock_user = UserContext(id="user-123", email="user@test.com", roles=["Admin"])

    app = create_test_app(workflow_service=mock_service, user=mock_user)

    with TestClient(app=app) as client:
        res = client.get("/api/v1/workflow/Invoice/123/actions")
        assert res.status_code == 200
        data = res.json()
        assert data["actions"] == ["Approve", "Reject"]
        assert data["current_state"] == "Pending"


@pytest.mark.asyncio
async def test_get_available_actions_without_user() -> None:
    """Should return empty actions when user is None but service exists."""
    mock_service = AsyncMock()
    mock_state = MagicMock()
    mock_state.current_state = "Pending"
    mock_service.get_workflow_state.return_value = mock_state

    app = create_test_app(workflow_service=mock_service, user=None)

    with TestClient(app=app) as client:
        res = client.get("/api/v1/workflow/Invoice/123/actions")
        assert res.status_code == 200
        assert res.json()["actions"] == []


@pytest.mark.asyncio
async def test_execute_transition_success() -> None:
    """Should execute transition via service and return result."""
    mock_service = AsyncMock()
    mock_result = TransitionResult(
        success=True,
        old_state="Pending",
        new_state="Approved",
        action="Approve",
        message="Success",
    )
    mock_service.transition.return_value = mock_result

    mock_user = UserContext(id="user-123", email="user@test.com", roles=["Admin"])
    app = create_test_app(workflow_service=mock_service, user=mock_user)

    with TestClient(app=app) as client:
        res = client.post(
            "/api/v1/workflow/Invoice/123/transition",
            json={"action": "Approve", "comment": "Looks good"},
        )
        assert res.status_code == 201
        assert res.json()["success"] is True
