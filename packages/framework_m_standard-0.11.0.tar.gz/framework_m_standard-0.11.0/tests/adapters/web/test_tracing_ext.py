"""Extended Tests for Tracing.

Covers lines checking OPENTELEMETRY_AVAILABLE and instrumentation calls.
"""

import logging
from unittest.mock import MagicMock, patch

import pytest
from framework_m_standard.adapters.web.tracing import setup_tracing


def test_setup_tracing_not_available(caplog: pytest.LogCaptureFixture) -> None:
    """Should log debug message and return if opentelemetry is not available."""
    with (
        caplog.at_level(logging.DEBUG),
        patch(
            "framework_m_standard.adapters.web.tracing.OPENTELEMETRY_AVAILABLE", False
        ),
    ):
        app = MagicMock()
        setup_tracing(app)

    assert "OpenTelemetry tracing dependencies not installed" in caplog.text


def test_setup_tracing_success_and_exceptions(caplog: pytest.LogCaptureFixture) -> None:
    """Should instrument app when available and catch/log exceptions gracefully."""
    with (
        caplog.at_level(logging.WARNING),
        patch(
            "framework_m_standard.adapters.web.tracing.OPENTELEMETRY_AVAILABLE", True
        ),
        patch(
            "framework_m_standard.adapters.web.tracing.LitestarInstrumentor",
            create=True,
        ) as mock_litestar,
        patch(
            "framework_m_standard.adapters.web.tracing.SQLAlchemyInstrumentor",
            create=True,
        ) as mock_sqla,
        patch(
            "framework_m_standard.adapters.web.tracing.RedisInstrumentor",
            create=True,
        ) as mock_redis,
    ):
        # Simulate exceptions to hit the warning branches
        mock_litestar.return_value.instrument_app.side_effect = Exception(
            "Litestar fail"
        )
        mock_sqla.return_value.instrument.side_effect = Exception("SQLAlchemy fail")
        mock_redis.return_value.instrument.side_effect = Exception("Redis fail")

        setup_tracing(MagicMock())

    assert "Failed to instrument Litestar: Litestar fail" in caplog.text
    assert "Failed to instrument SQLAlchemy: SQLAlchemy fail" in caplog.text
    assert "Failed to instrument Redis: Redis fail" in caplog.text
