"""Tests for Prometheus Metrics Middleware.

TDD tests for HTTP request metrics collection and exposure.
Tests written FIRST per CONTRIBUTING.md guidelines.
"""

# These imports will fail initially in TDD workflow until implemented
from framework_m_standard.adapters.web.middleware.metrics import (
    MetricsMiddleware,
    metrics_endpoint,
)
from litestar import Litestar, get
from litestar.testing import TestClient


@get("/test-endpoint")
async def sample_endpoint() -> dict[str, str]:
    """Sample endpoint to generate metrics."""
    return {"status": "ok"}


class TestMetricsMiddleware:
    """Tests for Prometheus metrics collection and exposure."""

    def test_metrics_endpoint_exposes_prometheus_data(self) -> None:
        """The /metrics endpoint should return valid Prometheus text format."""
        app = Litestar(
            route_handlers=[sample_endpoint, metrics_endpoint],
            middleware=[MetricsMiddleware],
        )

        with TestClient(app) as client:
            # Generate some traffic
            client.get("/test-endpoint")
            client.get("/test-endpoint")

            # Force a 404 to check status code labeling
            client.get("/non-existent")

            # Fetch metrics
            metrics_response = client.get("/metrics")
            assert metrics_response.status_code == 200
            assert "text/plain" in metrics_response.headers.get("content-type", "")

            metrics_text = metrics_response.text

            # Assert expected metrics and labels are present in the output
            assert "http_requests_total" in metrics_text
            assert "http_request_duration_seconds" in metrics_text
            assert 'method="GET",path="/test-endpoint",status="200"' in metrics_text
