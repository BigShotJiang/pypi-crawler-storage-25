"""Coverage tests for OAuth validation failures."""

from unittest.mock import patch

import pytest
from framework_m_standard.adapters.web.oauth_routes import oauth_routes_router
from litestar import Litestar
from litestar.testing import TestClient


@pytest.fixture
def client() -> TestClient:
    app = Litestar(route_handlers=[oauth_routes_router])
    return TestClient(app=app)


def test_oauth_callback_explicit_error(client: TestClient) -> None:
    """Should reject if provider redirects back with an error."""
    response = client.get("/api/v1/auth/oauth/google/callback?error=access_denied")
    assert response.status_code == 401
    assert "access_denied" in response.text


def test_oauth_callback_missing_code(client: TestClient) -> None:
    """Should reject if code is missing."""
    response = client.get("/api/v1/auth/oauth/google/callback")
    assert response.status_code == 401
    assert "No authorization code" in response.text


def test_oauth_callback_provider_not_configured(client: TestClient) -> None:
    """Should reject if provider config cannot be loaded."""
    with patch(
        "framework_m_standard.adapters.web.oauth_routes.get_provider_config",
        return_value=None,
    ):
        response = client.get("/api/v1/auth/oauth/google/callback?code=123")
        assert response.status_code == 404
        assert "not configured" in response.text


def test_oauth_callback_missing_state(client: TestClient) -> None:
    """Should reject if state is missing."""
    with (
        patch(
            "framework_m_standard.adapters.web.oauth_routes.get_provider_config",
            return_value={"client_id": "test"},
        ),
        patch(
            "framework_m_standard.adapters.web.oauth_routes.resolve_provider_endpoints",
            return_value={},
        ),
    ):
        response = client.get("/api/v1/auth/oauth/google/callback?code=123")
        assert response.status_code == 401
        assert "Missing state parameter" in response.text


def test_oauth_diagnostics_unauthorized(client: TestClient) -> None:
    """Should reject diagnostics if not admin."""
    response = client.get("/api/v1/auth/oauth/google/diagnostics")
    assert response.status_code == 401
    assert "Admin role required" in response.text


def test_oauth_start_unconfigured(client: TestClient) -> None:
    """Should 404 if starting flow for unconfigured provider."""
    response = client.get("/api/v1/auth/oauth/unknown/start")
    assert response.status_code == 404
