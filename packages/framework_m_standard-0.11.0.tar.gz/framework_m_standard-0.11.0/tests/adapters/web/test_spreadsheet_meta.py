"""Tests for Spreadsheet UX (ListField) Metadata.

Verifies that ui_meta from DocType and MetadataDecoratorRegistry is correctly
merged into the discovery API output.
"""

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.domain.meta import UIFieldMeta
from framework_m_core.metadata_decorator import MetadataDecoratorRegistry
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.web.metadata_router import metadata_router
from litestar import Litestar
from litestar.testing import TestClient

# =============================================================================
# Test Models
# =============================================================================


class ChildItem(BaseDocType):
    """Child DocType for grid testing."""

    item_name: str = Field(description="Item name")
    qty: float = Field(default=0.0, description="Quantity")
    rate: float = Field(default=0.0, description="Rate")

    class Meta:
        is_child_table = True


class ParentDocType(BaseDocType):
    """Parent DocType with a child list."""

    title: str = Field(description="Title")
    items: list[ChildItem] = Field(default_factory=list, description="Items list")

    class Meta:
        api_resource = True
        ui_meta = {
            "fields": {
                "items": {
                    "ui_widget": "grid",
                    "grid_columns": ["item_name", "qty", "rate"],
                }
            }
        }


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture(autouse=True)
def clean_registry():
    """Clear registries before each test."""
    MetaRegistry.get_instance().clear()
    MetadataDecoratorRegistry.get_instance().clear()
    yield
    MetaRegistry.get_instance().clear()
    MetadataDecoratorRegistry.get_instance().clear()


# =============================================================================
# Tests
# =============================================================================


def test_ui_meta_merged_into_schema() -> None:
    """Should merge Meta.ui_meta into the properties schema."""
    registry = MetaRegistry.get_instance()
    registry.register_doctype(ParentDocType)

    # Note: We must call bake if we want decorated properties,
    # but for static ui_meta it should work via get_ui_meta() call in router.
    registry.bake_augmented_models()

    app = Litestar(route_handlers=[metadata_router])
    with TestClient(app) as client:
        response = client.get("/api/meta/ParentDocType")
        assert response.status_code == 200
        data = response.json()

        # Check that ui_meta is present in the response
        assert "ui_meta" in data
        assert data["ui_meta"]["fields"]["items"]["ui_widget"] == "grid"

        # Check that it's merged into the schema properties
        props = data["schema"]["properties"]
        assert props["items"]["ui_widget"] == "grid"
        assert props["items"]["grid_columns"] == ["item_name", "qty", "rate"]


def test_decorated_property_grid_meta() -> None:
    """Should support grid meta for decorated/appended fields."""
    registry = MetaRegistry.get_instance()
    registry.register_doctype(ParentDocType)

    # Decorate with an extra grid property
    decorator_reg = MetadataDecoratorRegistry.get_instance()
    decorator_reg.register_property(
        "ParentDocType",
        "extra_items",
        list[ChildItem],
        ui_widget="grid",
        grid_columns=["item_name", "qty"],
    )

    # Bake models to apply decoration
    registry.bake_augmented_models()

    app = Litestar(route_handlers=[metadata_router])
    with TestClient(app) as client:
        response = client.get("/api/meta/ParentDocType")
        assert response.status_code == 200
        data = response.json()

        props = data["schema"]["properties"]
        assert "extra_items" in props
        assert props["extra_items"]["ui_widget"] == "grid"
        assert props["extra_items"]["grid_columns"] == ["item_name", "qty"]


def test_ui_meta_overrides_scalar_properties() -> None:
    """Should priority ui_meta field overrides over field defaults."""
    registry = MetaRegistry.get_instance()
    registry.register_doctype(ParentDocType)

    # Update _meta_config directly since Pydantic parses Meta once at class creation
    ParentDocType._meta_config.ui_meta.fields["title"] = UIFieldMeta(
        label="Custom Title Label"
    )

    registry.bake_augmented_models()

    app = Litestar(route_handlers=[metadata_router])
    with TestClient(app) as client:
        response = client.get("/api/meta/ParentDocType")
        assert response.status_code == 200
        data = response.json()

        props = data["schema"]["properties"]
        assert props["title"]["label"] == "Custom Title Label"
