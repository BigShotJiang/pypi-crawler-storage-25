"""Tests for tree routes API."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_standard.adapters.web.tree_routes import (
    _build_tree,
    _get_parent_field,
    tree_routes_router,
)
from litestar import Litestar, Request
from litestar.testing import TestClient


class MockRow:
    """Mock SQLAlchemy Row-like object for testing."""

    def __init__(self, mapping: dict[str, Any]) -> None:
        self._mapping = mapping


def _inject_mock_session(session_mock: AsyncMock | None) -> Any:
    """Create a Litestar before_request hook to inject a mock DB session."""

    def before_request(request: Request[Any, Any, Any]) -> None:
        request.state.db_session = session_mock

    return before_request


def test_build_tree() -> None:
    """Test recursive tree building from flat rows."""
    rows = [
        {"id": "1", "name": "Node1", "parent_f": None, "extra": "A"},
        {"id": "2", "name": "Node2", "parent_f": "", "extra": "B"},
        {"id": "3", "label_f": "Node3", "parent_f": "1"},  # uses label_f
        {"name": "4", "parent_f": "1"},  # uses name for both id and label
        {"id": "5", "name": "Orphan", "parent_f": "missing"},  # should be excluded
    ]

    tree = _build_tree(rows, "parent_f", "label_f")

    assert len(tree) == 2

    # Check first root
    assert tree[0]["id"] == "1"
    assert tree[0]["label"] == "Node1"
    assert tree[0]["data"] == {"extra": "A", "parent_f": None}
    assert len(tree[0]["children"]) == 2

    # Check second root
    assert tree[1]["id"] == "2"

    # Check children of first root
    assert tree[0]["children"][0]["id"] == "3"
    assert tree[0]["children"][0]["label"] == "Node3"

    assert tree[0]["children"][1]["id"] == "4"
    assert tree[0]["children"][1]["label"] == "4"


@patch("framework_m_standard.adapters.web.tree_routes.MetaRegistry")
def test_get_parent_field_defaults(mock_meta: MagicMock) -> None:
    """Test _get_parent_field falls back to defaults when Meta is missing."""
    mock_doctype = MagicMock()
    del mock_doctype.Meta
    mock_meta.get_instance.return_value.get_doctype.return_value = mock_doctype

    parent_f, label_f = _get_parent_field("NoMetaDoc")
    assert parent_f == "parent"
    assert label_f == "name"


@patch("framework_m_standard.adapters.web.tree_routes.MetaRegistry")
def test_get_parent_field_not_found(mock_meta: MagicMock) -> None:
    """Test _get_parent_field raises NotFoundException for unknown doctypes."""
    mock_meta.get_instance.return_value.get_doctype.side_effect = KeyError("Not found")
    from litestar.exceptions import NotFoundException

    with pytest.raises(NotFoundException):
        _get_parent_field("UnknownDoc")


@patch("framework_m_standard.adapters.web.tree_routes.MetaRegistry")
def test_get_tree_no_session(mock_meta: MagicMock) -> None:
    """Test get_tree with no DB session returns empty tree."""
    mock_doctype = MagicMock()
    mock_doctype.Meta.parent_field = "parent"
    mock_doctype.Meta.label_field = "name"
    mock_meta.get_instance.return_value.get_doctype.return_value = mock_doctype

    app = Litestar(
        route_handlers=[tree_routes_router],
        before_request=_inject_mock_session(None),
    )
    with TestClient(app=app) as client:
        res = client.get("/api/tree/TestDoc")
        assert res.status_code == 200
        assert res.json() == {
            "doctype": "TestDoc",
            "parent_field": "parent",
            "tree": [],
        }


@patch("framework_m_standard.adapters.db.table_registry.TableRegistry")
@patch("framework_m_standard.adapters.web.tree_routes.MetaRegistry")
def test_get_tree_table_error(
    mock_meta: MagicMock, mock_table_registry: MagicMock
) -> None:
    """Test get_tree handles missing database tables safely."""
    mock_doctype = MagicMock()
    mock_doctype.Meta.parent_field = "parent"
    mock_doctype.Meta.label_field = "name"
    mock_meta.get_instance.return_value.get_doctype.return_value = mock_doctype
    mock_table_registry.return_value.get_table.side_effect = Exception("No table")

    app = Litestar(
        route_handlers=[tree_routes_router],
        before_request=_inject_mock_session(AsyncMock()),
    )
    with TestClient(app=app) as client:
        res = client.get("/api/tree/TestDoc")
        assert res.status_code == 200
        assert res.json()["tree"] == []


@patch("framework_m_standard.adapters.web.tree_routes.select")
@patch("framework_m_standard.adapters.db.table_registry.TableRegistry")
@patch("framework_m_standard.adapters.web.tree_routes.MetaRegistry")
def test_get_tree_success(
    mock_meta: MagicMock, mock_table_registry: MagicMock, mock_select: MagicMock
) -> None:
    """Test get_tree builds a valid hierarchy from DB records."""
    mock_doctype = MagicMock()
    mock_doctype.Meta.parent_field = "parent"
    mock_doctype.Meta.label_field = "name"
    mock_meta.get_instance.return_value.get_doctype.return_value = mock_doctype
    mock_table_registry.return_value.get_table.return_value = MagicMock()

    mock_session = AsyncMock()
    mock_result = MagicMock()
    mock_result.__iter__.return_value = [
        MockRow({"id": "1", "name": "Root", "parent": None}),
    ]
    mock_session.execute.return_value = mock_result

    app = Litestar(
        route_handlers=[tree_routes_router],
        before_request=_inject_mock_session(mock_session),
    )
    with TestClient(app=app) as client:
        res = client.get("/api/tree/TestDoc")
        assert res.status_code == 200
        assert len(res.json()["tree"]) == 1
        assert res.json()["tree"][0]["id"] == "1"


@patch("framework_m_standard.adapters.web.tree_routes.MetaRegistry")
def test_reparent_node_validation(mock_meta: MagicMock) -> None:
    """Test reparent_node enforces valid body parameters."""
    app = Litestar(route_handlers=[tree_routes_router])
    with TestClient(app=app) as client:
        res = client.patch("/api/tree/TestDoc/node1", json={})
        assert res.status_code == 400
        assert "Body must contain 'parent' and/or 'label'" in res.text


@patch("framework_m_standard.adapters.web.tree_routes.MetaRegistry")
def test_reparent_node_no_session(mock_meta: MagicMock) -> None:
    """Test reparent_node fallback when DB session is missing."""
    mock_doctype = MagicMock()
    mock_doctype.Meta.parent_field = "parent"
    mock_doctype.Meta.label_field = "name"
    mock_meta.get_instance.return_value.get_doctype.return_value = mock_doctype
    app = Litestar(
        route_handlers=[tree_routes_router],
        before_request=_inject_mock_session(None),
    )
    with TestClient(app=app) as client:
        res = client.patch("/api/tree/TestDoc/node1", json={"parent": "new_parent"})
        assert res.status_code == 200
        assert res.json() == {"ok": True, "id": "node1", "parent": "new_parent"}


@patch("framework_m_standard.adapters.db.table_registry.TableRegistry")
@patch("framework_m_standard.adapters.web.tree_routes.MetaRegistry")
def test_reparent_node_success(
    mock_meta: MagicMock, mock_table_registry: MagicMock
) -> None:
    """Test reparent_node successfully updates database fields."""
    mock_doctype = MagicMock()
    mock_doctype.Meta.parent_field = "parent"
    mock_doctype.Meta.label_field = "name"
    mock_meta.get_instance.return_value.get_doctype.return_value = mock_doctype
    mock_table = MagicMock()
    mock_table_registry.return_value.get_table.return_value = mock_table

    mock_session = AsyncMock()
    app = Litestar(
        route_handlers=[tree_routes_router],
        before_request=_inject_mock_session(mock_session),
    )
    with TestClient(app=app) as client:
        res = client.patch(
            "/api/tree/TestDoc/node1",
            json={"parent": "new_parent", "label": "new_label"},
        )
        assert res.status_code == 200
        data = res.json()
        assert data["ok"] is True
        assert data["parent"] == "new_parent"
        assert data["label"] == "new_label"

        mock_session.execute.assert_called_once()
        mock_session.commit.assert_called_once()


@patch("framework_m_standard.adapters.db.table_registry.TableRegistry")
@patch("framework_m_standard.adapters.web.tree_routes.MetaRegistry")
def test_add_child_node_success(
    mock_meta: MagicMock, mock_table_registry: MagicMock
) -> None:
    """Test add_child_node successfully inserts a new child node to the DB."""
    mock_doctype = MagicMock()
    mock_doctype.Meta.parent_field = "parent"
    mock_doctype.Meta.label_field = "name"
    mock_meta.get_instance.return_value.get_doctype.return_value = mock_doctype
    mock_table_registry.return_value.get_table.return_value = MagicMock()

    mock_session = AsyncMock()
    app = Litestar(
        route_handlers=[tree_routes_router],
        before_request=_inject_mock_session(mock_session),
    )
    with TestClient(app=app) as client:
        res = client.post(
            "/api/tree/TestDoc/add-child",
            json={"parent": "root_id", "label": "New Child", "custom": "value"},
        )
        assert res.status_code == 201
        data = res.json()

        assert data["ok"] is True
        assert "id" in data
        assert data["name"] == "New Child"
        assert data["parent"] == "root_id"
        assert data["custom"] == "value"

        mock_session.execute.assert_called_once()
        mock_session.commit.assert_called_once()
