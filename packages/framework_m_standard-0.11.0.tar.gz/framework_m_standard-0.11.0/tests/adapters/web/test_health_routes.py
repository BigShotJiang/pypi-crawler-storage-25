"""Tests for Health & Readiness Probes."""

import pytest
from framework_m_standard.adapters.web.app import create_app
from litestar.testing import TestClient


class TestHealthEndpoint:
    """Test the health check endpoint."""

    def test_health_endpoint_returns_200(self) -> None:
        """Health endpoint should return 200 OK."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/health")
            assert response.status_code == 200

    def test_health_endpoint_returns_status(self) -> None:
        """Health endpoint should return status information."""
        app = create_app()
        with TestClient(app) as client:
            response = client.get("/health")
            data = response.json()
            assert "status" in data
            assert data["status"] == "healthy"

    def test_health_endpoint_db_failure_returns_503(self) -> None:
        """Health endpoint should return 503 when DB is down."""
        from unittest.mock import patch

        app = create_app()
        # Patch engine.connect only during the health check to avoid breaking lifespan
        with (
            TestClient(app) as client,
            patch("sqlalchemy.ext.asyncio.AsyncEngine.connect") as mock_connect,
        ):
            mock_connect.side_effect = Exception("DB Connection Failed")
            response = client.get("/health")

            assert response.status_code == 503
            data = response.json()
            assert data["status"] == "unhealthy"
            assert data["database"] == "down"

    def test_health_endpoint_redis_failure_returns_503(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Health endpoint should return 503 when Redis is down."""
        from unittest.mock import AsyncMock, patch

        monkeypatch.setenv("REDIS_URL", "redis://localhost:6379/0")

        with patch("redis.asyncio.from_url") as mock_from_url:
            mock_redis = AsyncMock()
            mock_from_url.return_value = mock_redis

            app = create_app()
            with TestClient(app) as client:
                # Simulate Redis failure
                mock_redis.ping.side_effect = Exception("Redis Connection Failed")
                response = client.get("/health")

                assert response.status_code == 503
                data = response.json()
                assert data["status"] == "unhealthy"
                assert data["redis"] == "down"


class TestReadinessEndpoint:
    """Test the readiness check endpoint."""

    def test_readiness_endpoint_200(self) -> None:
        """Readiness endpoint should return 200 when migrations are up to date."""
        from unittest.mock import AsyncMock, patch

        with patch(
            "framework_m_standard.adapters.db.migration_check.MigrationStatusUtility.is_up_to_date",
            new_callable=AsyncMock,
        ) as mock_check:
            mock_check.return_value = True
            app = create_app()
            with TestClient(app) as client:
                response = client.get("/ready")
                assert response.status_code == 200
                assert response.json() == {"status": "ready"}

    def test_readiness_endpoint_503(self) -> None:
        """Readiness endpoint should return 503 when migrations are pending."""
        from unittest.mock import AsyncMock, patch

        with patch(
            "framework_m_standard.adapters.db.migration_check.MigrationStatusUtility.is_up_to_date",
            new_callable=AsyncMock,
        ) as mock_check:
            mock_check.return_value = False
            app = create_app()
            with TestClient(app) as client:
                response = client.get("/ready")
                assert response.status_code == 503
                assert response.json() == {
                    "status": "not_ready",
                    "detail": "Pending migrations",
                }

    def test_readiness_endpoint_503_on_db_error(self) -> None:
        """Readiness endpoint should return 503 when DB connection fails."""
        from unittest.mock import AsyncMock, patch

        with patch(
            "framework_m_standard.adapters.db.migration_check.MigrationStatusUtility.is_up_to_date",
            new_callable=AsyncMock,
        ) as mock_check:
            mock_check.side_effect = Exception("Database connection refused")
            app = create_app()
            with TestClient(app) as client:
                response = client.get("/ready")
                assert response.status_code == 503
                assert response.json() == {
                    "status": "not_ready",
                    "detail": "Database error",
                }
