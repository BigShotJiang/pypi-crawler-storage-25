"""Tests for Authentication Middleware."""

from unittest.mock import AsyncMock

import pytest
from framework_m_standard.adapters.web.middleware.authentication import AuthMiddleware


@pytest.mark.asyncio
async def test_auth_middleware_non_http_scope() -> None:
    """Should completely bypass the middleware for non-HTTP scopes (like lifespan)."""
    mock_app = AsyncMock()
    middleware = AuthMiddleware(app=mock_app)

    scope = {"type": "lifespan"}
    receive = AsyncMock()
    send = AsyncMock()

    await middleware(scope, receive, send)
    mock_app.assert_awaited_once_with(scope, receive, send)


@pytest.mark.asyncio
async def test_auth_middleware_missing_state_in_scope() -> None:
    """Should initialize scope['state'] if it is missing from the ASGI scope."""
    mock_app = AsyncMock()
    middleware = AuthMiddleware(app=mock_app, require_auth=False)

    scope = {
        "type": "http",
        "path": "/api/test",
        "method": "GET",
        "headers": [],
        # "state" is intentionally omitted
    }

    await middleware(scope, AsyncMock(), AsyncMock())
    mock_app.assert_awaited_once()
    assert "state" in scope
    assert "user" in scope["state"]


def test_legacy_helpers() -> None:
    """Should correctly parse headers and comma-separated strings."""
    middleware = AuthMiddleware(app=AsyncMock())

    assert middleware._get_header({b"x-test": b"value"}, b"x-test") == "value"
    assert middleware._get_header({b"x-test": b"value"}, b"missing") is None

    assert middleware._parse_comma_separated(None) == []
    assert middleware._parse_comma_separated("") == []
    assert middleware._parse_comma_separated("a, b , c ") == ["a", "b", "c"]
    assert middleware._parse_comma_separated("a,,b") == ["a", "b"]
