"""Tests for Exception Handlers."""

from unittest.mock import MagicMock

from framework_m_core.exceptions import (
    DocTypeNotFoundError,
    DuplicateNameError,
    EntityNotFoundError,
    FrameworkError,
    PermissionDeniedError,
    ValidationError,
)
from framework_m_standard.adapters.web.exception_handlers import (
    duplicate_name_handler,
    framework_error_handler,
    litestar_not_found_handler,
    not_found_handler,
    permission_denied_handler,
    validation_error_handler,
)
from litestar.exceptions import NotFoundException


def test_validation_error_handler() -> None:
    """Test validation error handler."""
    request = MagicMock()
    exc = ValidationError("Invalid data")
    setattr(exc, "details", {"field": "required"})  # noqa: B010

    response = validation_error_handler(request, exc)

    assert response.status_code == 400
    assert response.content["error"] == "ValidationError"
    assert response.content["message"] == "Invalid data"
    assert response.content["details"] == {"field": "required"}


def test_permission_denied_handler() -> None:
    """Test permission denied handler."""
    request = MagicMock()
    exc = PermissionDeniedError("Not allowed")

    response = permission_denied_handler(request, exc)

    assert response.status_code == 403
    assert response.content["error"] == "PermissionDenied"
    assert response.content["message"] == "Not allowed"


def test_not_found_handler_doctype() -> None:
    """Test not found handler for DocTypeNotFoundError."""
    request = MagicMock()
    exc = DocTypeNotFoundError("User")

    response = not_found_handler(request, exc)

    assert response.status_code == 404
    assert response.content["error"] == "NotFound"
    assert "User" in response.content["message"]


def test_not_found_handler_entity() -> None:
    """Test not found handler for EntityNotFoundError."""
    request = MagicMock()
    exc = EntityNotFoundError("User", "123")

    response = not_found_handler(request, exc)

    assert response.status_code == 404
    assert response.content["error"] == "NotFound"
    assert "User" in response.content["message"]


def test_duplicate_name_handler() -> None:
    """Test duplicate name handler."""
    request = MagicMock()

    # Use MagicMock to prevent init signature mismatch errors
    exc = MagicMock(spec=DuplicateNameError)
    exc.__str__.return_value = "Conflict"
    exc.doctype_name = "User"
    exc.name = "john@example.com"

    response = duplicate_name_handler(request, exc)

    assert response.status_code == 409
    assert response.content["error"] == "Conflict"
    assert response.content["message"] == "Conflict"
    assert response.content["doctype"] == "User"
    assert response.content["name"] == "john@example.com"


def test_framework_error_handler() -> None:
    """Test framework error handler."""
    request = MagicMock()
    exc = FrameworkError("Something went wrong")

    response = framework_error_handler(request, exc)

    assert response.status_code == 500
    assert response.content["error"] == "InternalError"
    assert response.content["message"] == "Something went wrong"


def test_litestar_not_found_handler() -> None:
    """Test Litestar not found handler."""
    request = MagicMock()
    exc = NotFoundException(detail="Custom not found")

    response = litestar_not_found_handler(request, exc)

    assert response.status_code == 404
    assert response.content["status_code"] == 404
    assert response.content["detail"] == "Custom not found"
