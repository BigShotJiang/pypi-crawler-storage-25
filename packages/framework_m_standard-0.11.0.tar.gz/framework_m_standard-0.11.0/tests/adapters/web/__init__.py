"""Tests for web adapters."""
