"""Tests for Metadata API.

TDD tests for GET /api/meta/{doctype} endpoint that returns
DocType metadata including JSON schema, layout, and permissions.
"""

from typing import ClassVar

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.registry import (
    MetaRegistry,
    UIContextRegistry,
)
from litestar import Litestar
from litestar.testing import TestClient

# =============================================================================
# Test DocTypes
# =============================================================================


class MetaTestInvoice(BaseDocType):
    """Test DocType with full metadata for metadata API tests."""

    customer: str = Field(title="Customer Name", description="Name of the customer")
    total: float = Field(default=0.0, title="Total Amount", description="Invoice total")
    status: str = Field(default="draft", title="Status", description="Invoice status")

    class Meta:
        requires_auth: ClassVar[bool] = True
        apply_rls: ClassVar[bool] = True
        rls_field: ClassVar[str] = "owner"
        api_resource: ClassVar[bool] = True
        is_aggregate_root: ClassVar[bool] = True
        aggregate_children: ClassVar[list[str]] = ["MetaTestInvoiceItem"]
        permissions: ClassVar[dict[str, list[str]]] = {
            "read": ["Employee", "Manager"],
            "write": ["Manager"],
            "create": ["Manager"],
            "delete": ["Admin"],
        }
        ui_meta: ClassVar[dict[str, object]] = {
            "doctype": "MetaTestInvoice",
            "form": {
                "sections": [
                    {"label": "Default", "fields": ["customer", "total"]},
                ]
            },
            "list": {
                "columns": [
                    {"field": "customer", "label": "Customer"},
                    {"field": "total", "label": "Total"},
                ]
            },
        }


class MetaTestRoleDocA(BaseDocType):
    """Mock DocType for role testing."""

    class Meta:
        roles: ClassVar[dict[str, list[str]]] = {"read": ["Role A", "Common Role"]}


class MetaTestRoleDocB(BaseDocType):
    """Another mock DocType for role testing."""

    class Meta:
        roles: ClassVar[dict[str, list[str]]] = {
            "write": ["Role B", "Common Role"],
        }


class MetaTestPublicConfig(BaseDocType):
    """Test DocType with minimal metadata (public, no layout)."""

    key: str = Field(title="Config Key", description="Configuration key")
    value: str = Field(
        default="", title="Config Value", description="Configuration value"
    )

    class Meta:
        requires_auth: ClassVar[bool] = False
        apply_rls: ClassVar[bool] = False


# =============================================================================
# Tests for Metadata Endpoint
# =============================================================================


class TestMetadataEndpoint:
    """Tests for GET /api/meta/{doctype} endpoint."""

    @pytest.fixture(autouse=True)
    def register_doctypes(self) -> None:
        """Register test DocTypes in MetaRegistry."""
        registry = MetaRegistry.get_instance()
        UIContextRegistry.get_instance().clear()
        try:
            registry.get_doctype("MetaTestInvoice")
        except KeyError:
            registry.register_doctype(MetaTestInvoice)
        try:
            registry.get_doctype("MetaTestPublicConfig")
        except KeyError:
            registry.register_doctype(MetaTestPublicConfig)

        UIContextRegistry.get_instance().register_context_override(
            "MetaTestInvoice",
            "pos",
            {
                "form": {
                    "sections": [
                        {"label": "POS", "fields": ["customer", "status"]},
                    ]
                }
            },
        )

    @pytest.fixture
    def app(self) -> Litestar:
        """Create test app with metadata routes."""
        from framework_m_standard.adapters.web.meta_routes import meta_routes_router

        return Litestar(route_handlers=[meta_routes_router])

    @pytest.fixture
    def client(self, app: Litestar) -> TestClient[Litestar]:
        """Create test client."""
        return TestClient(app)

    def test_meta_routes_router_is_importable(self) -> None:
        """meta_routes_router should be importable."""
        from framework_m_standard.adapters.web.meta_routes import meta_routes_router

        assert meta_routes_router is not None

    def test_get_doctype_metadata_returns_schema(
        self, client: TestClient[Litestar]
    ) -> None:
        """Should return JSON schema for DocType."""
        response = client.get("/api/meta/MetaTestInvoice")

        assert response.status_code == 200
        data = response.json()
        assert "schema" in data
        assert "properties" in data["schema"]
        # Should have our custom fields in schema
        assert "customer" in data["schema"]["properties"]
        assert "total" in data["schema"]["properties"]

    def test_get_doctype_metadata_returns_permissions(
        self, client: TestClient[Litestar]
    ) -> None:
        """Should return permissions configuration."""
        response = client.get("/api/meta/MetaTestInvoice")

        assert response.status_code == 200
        data = response.json()
        assert "permissions" in data
        assert "read" in data["permissions"]
        assert "Manager" in data["permissions"]["read"]

    def test_get_doctype_metadata_returns_metadata(
        self, client: TestClient[Litestar]
    ) -> None:
        """Should return additional metadata (requires_auth, apply_rls, etc.)."""
        response = client.get("/api/meta/MetaTestInvoice")

        assert response.status_code == 200
        data = response.json()
        assert "metadata" in data
        assert data["metadata"]["requires_auth"] is True
        assert data["metadata"]["apply_rls"] is True
        assert data["metadata"]["rls_field"] == "owner"
        assert data["metadata"]["api_resource"] is True

    def test_get_doctype_metadata_returns_field_titles(
        self, client: TestClient[Litestar]
    ) -> None:
        """Schema should include field titles from Field(title=...)."""
        response = client.get("/api/meta/MetaTestInvoice")

        assert response.status_code == 200
        data = response.json()
        customer_field = data["schema"]["properties"]["customer"]
        assert customer_field.get("title") == "Customer Name"

    def test_get_doctype_metadata_returns_field_descriptions(
        self, client: TestClient[Litestar]
    ) -> None:
        """Schema should include field descriptions from Field(description=...)."""
        response = client.get("/api/meta/MetaTestInvoice")

        assert response.status_code == 200
        data = response.json()
        customer_field = data["schema"]["properties"]["customer"]
        assert customer_field.get("description") == "Name of the customer"

    def test_get_doctype_metadata_404_for_unknown(
        self, client: TestClient[Litestar]
    ) -> None:
        """Should return 404 for unknown DocType."""
        response = client.get("/api/meta/UnknownDocType")

        assert response.status_code == 404

    def test_get_doctype_metadata_public_config(
        self, client: TestClient[Litestar]
    ) -> None:
        """Should return metadata for public DocType."""
        response = client.get("/api/meta/MetaTestPublicConfig")

        assert response.status_code == 200
        data = response.json()
        assert data["metadata"]["requires_auth"] is False
        assert data["metadata"]["apply_rls"] is False
        # Empty permissions should be empty dict
        assert data["permissions"] == {}

    def test_get_doctype_metadata_returns_ui_meta(
        self, client: TestClient[Litestar]
    ) -> None:
        """Should return base ui_meta in metadata response."""
        response = client.get("/api/meta/MetaTestInvoice")

        assert response.status_code == 200
        data = response.json()
        assert "ui_meta" in data
        assert data["ui_meta"]["doctype"] == "MetaTestInvoice"
        assert data["ui_meta"]["list"]["columns"][0]["field"] == "customer"

    def test_get_doctype_metadata_applies_ui_context_override(
        self, client: TestClient[Litestar]
    ) -> None:
        """Should apply context-specific ui_meta override when requested."""
        response = client.get("/api/meta/MetaTestInvoice?ui_context=pos")

        assert response.status_code == 200
        data = response.json()
        assert data["ui_context"] == "pos"
        assert data["ui_meta"]["form"]["sections"][0]["label"] == "POS"

    def test_get_doctype_metadata_includes_aggregate_root_view_config(
        self, client: TestClient[Litestar]
    ) -> None:
        """Should include aggregate root view metadata for registered DocTypes."""
        response = client.get("/api/meta/MetaTestInvoice")

        assert response.status_code == 200
        data = response.json()
        aggregate_root = data["ui_meta"]["additional_views"]["aggregate_root"]
        assert aggregate_root["children"][0]["resource"] == "MetaTestInvoiceItem"


class TestRolesEndpoint:
    """Tests for GET /api/meta/roles endpoint."""

    @pytest.fixture(autouse=True)
    def register_doctypes(self) -> None:
        """Register test DocTypes in MetaRegistry."""
        registry = MetaRegistry.get_instance()
        registry.clear()
        try:
            registry.get_doctype("MetaTestRoleDocA")
        except KeyError:
            registry.register_doctype(MetaTestRoleDocA)
        try:
            registry.get_doctype("MetaTestRoleDocB")
        except KeyError:
            registry.register_doctype(MetaTestRoleDocB)

        # Also inject a role
        registry.inject_role("Injected Role")

    @pytest.fixture
    def app(self) -> Litestar:
        """Create test app with metadata routes."""
        from framework_m_standard.adapters.web.meta_routes import meta_routes_router

        return Litestar(route_handlers=[meta_routes_router])

    @pytest.fixture
    def client(self, app: Litestar) -> TestClient[Litestar]:
        """Create test client."""
        return TestClient(app)

    def test_list_roles_returns_all_unique_roles(
        self, client: TestClient[Litestar]
    ) -> None:
        """Should return a deduplicated list of all roles from DocTypes and injected roles."""
        response = client.get("/api/meta/roles")
        assert response.status_code == 200
        data = response.json()

        assert "items" in data
        roles = data["items"]

        # The list is sorted by the implementation
        assert roles == ["Common Role", "Injected Role", "Role A", "Role B"]
        assert data["total"] == 4

    def test_list_roles_with_search(self, client: TestClient[Litestar]) -> None:
        """Should filter roles based on the search query parameter."""
        response = client.get("/api/meta/roles?search=Common")
        assert response.status_code == 200
        data = response.json()

        assert set(data["items"]) == {"Common Role"}
        assert data["total"] == 1

    def test_list_roles_with_pagination(self, client: TestClient[Litestar]) -> None:
        """Should support limit and offset for pagination."""
        response = client.get("/api/meta/roles?limit=2&offset=1")
        assert response.status_code == 200
        data = response.json()
        assert data["items"] == ["Injected Role", "Role A"]
        assert data["total"] == 4


# =============================================================================
# Tests for I18n and Edge Cases
# =============================================================================


class TestDocTypeMetadataI18nAndOverrides:
    """Tests for i18n translation and edge cases in DocType metadata."""

    def test_get_doctype_metadata_translates_labels(self) -> None:
        from unittest.mock import AsyncMock, MagicMock, patch

        from framework_m_core.domain.base_doctype import BaseDocType, Field
        from framework_m_core.registry import MetaRegistry
        from litestar import Litestar, Request
        from litestar.testing import TestClient

        class I18nTestDoc(BaseDocType):
            f_both: str = Field(title="T1", description="D1")
            f_title: str = Field(title="T2")
            f_desc: str = Field(description="D2")
            f_none: str = Field()

        MetaRegistry.get_instance().register_doctype(I18nTestDoc)

        async def mock_translate(text, *args, **kwargs):
            if text in ("T1", "T2", "D1", "D2"):
                return text + "_translated"
            # Return original text if not matched to trigger the "==" branch
            return text

        with (
            patch("framework_m_standard.adapters.db.table_registry.TableRegistry"),
            patch(
                "framework_m_standard.adapters.db.generic_repository.GenericRepository"
            ),
            patch(
                "framework_m_standard.adapters.i18n.DefaultI18nAdapter"
            ) as mock_i18n_cls,
            patch("framework_m_standard.adapters.factory.get_cache") as mock_cache,
        ):
            mock_adapter = MagicMock()
            mock_adapter.translate = AsyncMock(side_effect=mock_translate)
            mock_i18n_cls.return_value = mock_adapter

            mock_cache_inst = AsyncMock()
            mock_cache_inst.get.return_value = None
            mock_cache.return_value = mock_cache_inst

            def inject_session(request: Request) -> None:
                request.state.db_session = AsyncMock()
                request.state.tenant = MagicMock(tenant_id="tenant-123")

            from framework_m_standard.adapters.web.meta_routes import meta_routes_router

            app = Litestar(
                route_handlers=[meta_routes_router], before_request=inject_session
            )

            with TestClient(app) as client:
                response = client.get(
                    "/api/meta/I18nTestDoc", headers={"Accept-Language": "fr"}
                )
                assert response.status_code == 200

                props = response.json()["schema"]["properties"]
                assert props["f_both"]["title"] == "T1_translated"
                assert props["f_both"]["description"] == "D1_translated"
                assert props["f_title"]["title"] == "T2_translated"
                assert props["f_desc"]["description"] == "D2_translated"
                assert props["f_none"]["title"] == "F None"

    def test_get_doctype_metadata_invalid_additional_views(self) -> None:
        """Should handle gracefully when additional_views is not a dict."""
        from unittest.mock import AsyncMock, patch

        from framework_m_core.registry import MetaRegistry, UIContextRegistry
        from framework_m_standard.adapters.web.meta_routes import meta_routes_router
        from litestar import Litestar
        from litestar.testing import TestClient

        MetaRegistry.get_instance().register_doctype(MetaTestInvoice)

        UIContextRegistry.get_instance().register_context_override(
            "MetaTestInvoice",
            "bad_views",
            {"additional_views": ["this", "is", "a", "list"]},
        )

        app = Litestar(route_handlers=[meta_routes_router])
        with (
            TestClient(app) as client,
            patch("framework_m_standard.adapters.factory.get_cache") as mock_cache,
        ):
            mock_cache_inst = AsyncMock()
            mock_cache_inst.get.return_value = None
            mock_cache.return_value = mock_cache_inst

            response = client.get("/api/meta/MetaTestInvoice?ui_context=bad_views")
            assert response.status_code == 200
            data = response.json()
            assert isinstance(data["ui_meta"]["additional_views"], list)
