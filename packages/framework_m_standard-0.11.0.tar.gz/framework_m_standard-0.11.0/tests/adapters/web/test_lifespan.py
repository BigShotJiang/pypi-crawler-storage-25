"""Tests for Application Lifespan.

TDD tests for the application lifecycle hooks extracted from app.py.
"""

import importlib
import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_core.doctypes.webhook import Webhook
from framework_m_core.interfaces.audit import InMemoryAuditAdapter
from framework_m_standard.adapters.audit import ElasticAuditAdapter, FileAuditAdapter
from framework_m_standard.adapters.web.app import create_app
from framework_m_standard.adapters.web.lifespan import (
    _create_runtime_audit_adapter,
    _RepositoryWebhookLoader,
)
from litestar.testing import TestClient


class TestAppLifecycle:
    """Test application lifecycle hooks."""

    @pytest.mark.asyncio
    async def test_lifespan_context_manager(self) -> None:
        """App should properly handle startup and shutdown."""
        # Use in-memory SQLite to isolate the web lifespan test from the filesystem/real database
        with patch.dict(os.environ, {"DATABASE_URL": "sqlite+aiosqlite:///:memory:"}):
            app = create_app()
            assert app is not None

            # Entering the TestClient context manager triggers the ASGI lifespan startup,
            # and exiting triggers the ASGI lifespan shutdown.
            with TestClient(app) as client:
                assert client.app is app

    @pytest.mark.asyncio
    async def test_lifespan_auth_schema_warning(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should catch and print warning if auth schema mapping fails."""
        original_import = importlib.import_module

        def mock_import_module(name, *args, **kwargs):
            if name == "framework_m_core.doctypes.user":
                raise Exception("mock error")
            return original_import(name, *args, **kwargs)

        with patch.dict(os.environ, {"DATABASE_URL": "sqlite+aiosqlite:///:memory:"}):
            app = create_app()
            # Apply the patch ONLY during the lifespan execution
            with (
                patch("importlib.import_module", side_effect=mock_import_module),
                TestClient(app),
            ):
                pass
        captured = capsys.readouterr()
        assert "[Auth] Warning: Failed to map auth schema" in captured.err

    @pytest.mark.asyncio
    async def test_lifespan_webhook_listener_startup_error(self) -> None:
        """Should catch and log warning if webhook listener fails to start."""
        mock_container = MagicMock()
        mock_container.event_bus.return_value = AsyncMock()

        with patch.dict(os.environ, {"DATABASE_URL": "sqlite+aiosqlite:///:memory:"}):
            app = create_app()
            with (
                patch(
                    "framework_m_standard.adapters.web.lifespan.Container",
                    return_value=mock_container,
                ),
                patch(
                    "framework_m_standard.adapters.web.lifespan.WebhookListener"
                ) as mock_listener,
                patch(
                    "framework_m_standard.adapters.web.lifespan.logger"
                ) as mock_logger,
            ):
                mock_listener.return_value.start = AsyncMock(
                    side_effect=Exception("bus error")
                )
                with TestClient(app):
                    pass

                mock_logger.warning.assert_called_once()
                assert (
                    "Webhook listener startup skipped"
                    in mock_logger.warning.call_args[0][0]
                )

    @pytest.mark.asyncio
    async def test_lifespan_disconnects_event_bus(self) -> None:
        """Should call disconnect on event_bus if available."""
        mock_bus = AsyncMock()
        mock_bus.connect = AsyncMock()
        mock_bus.disconnect = AsyncMock()

        mock_container = MagicMock()
        mock_container.event_bus.return_value = mock_bus

        with patch.dict(os.environ, {"DATABASE_URL": "sqlite+aiosqlite:///:memory:"}):
            app = create_app()
            with (
                patch(
                    "framework_m_standard.adapters.web.lifespan.Container",
                    return_value=mock_container,
                ),
                patch(
                    "framework_m_standard.adapters.web.lifespan.WebhookListener"
                ) as mock_listener,
            ):
                mock_listener.return_value.start = AsyncMock()
                with TestClient(app):
                    pass

        mock_bus.disconnect.assert_called_once()


class TestRepositoryWebhookLoader:
    """Tests for _RepositoryWebhookLoader."""

    @pytest.mark.asyncio
    async def test_load_active_webhooks_repo_none(self) -> None:
        mock_repo_factory = MagicMock()
        mock_repo_factory.get_repository.return_value = None
        loader = _RepositoryWebhookLoader(mock_repo_factory, MagicMock())
        assert await loader.load_active_webhooks() == []

    @pytest.mark.asyncio
    async def test_load_active_webhooks_success(self) -> None:
        mock_repo = AsyncMock()
        mock_result = MagicMock()
        webhook = Webhook(name="test_webhook", url="http://test", event="test")
        mock_result.items = [webhook, "not-a-webhook"]
        mock_repo.list_entities.return_value = mock_result

        mock_repo_factory = MagicMock()
        mock_repo_factory.get_repository.return_value = mock_repo

        mock_session_factory = MagicMock()
        mock_session = AsyncMock()
        mock_session_factory.get_session.return_value.__aenter__.return_value = (
            mock_session
        )

        loader = _RepositoryWebhookLoader(mock_repo_factory, mock_session_factory)
        hooks = await loader.load_active_webhooks()

        assert len(hooks) == 1
        assert hooks[0] is webhook
        mock_repo.list_entities.assert_called_once()


class TestCreateRuntimeAuditAdapter:
    """Tests for _create_runtime_audit_adapter."""

    def test_elastic_adapter(self) -> None:
        with patch.dict(
            os.environ,
            {
                "FRAMEWORK_M_AUDIT_ADAPTER": "elastic",
                "FRAMEWORK_M_ELASTICSEARCH_URL": "http://es:9200",
            },
        ):
            adapter = _create_runtime_audit_adapter({})
            assert isinstance(adapter, ElasticAuditAdapter)

    def test_file_adapter(self) -> None:
        with patch.dict(
            os.environ,
            {
                "FRAMEWORK_M_AUDIT_ADAPTER": "file",
                "FRAMEWORK_M_AUDIT_FILE_PATH": "/tmp/a.log",
            },
        ):
            adapter = _create_runtime_audit_adapter({})
            assert isinstance(adapter, FileAuditAdapter)

    def test_fallback_adapter(self) -> None:
        with patch.dict(os.environ, {"FRAMEWORK_M_AUDIT_ADAPTER": "unknown"}):
            adapter = _create_runtime_audit_adapter({})
            assert isinstance(adapter, InMemoryAuditAdapter)
