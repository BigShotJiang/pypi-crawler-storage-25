"""Tests for Auth API routes.

TDD: This test file is created BEFORE the implementation.

Tests cover:
- GET /api/v1/auth/me - returns current user context
- POST /api/v1/auth/login - authenticates and returns token
- POST /api/v1/auth/logout - clears session
"""

from unittest.mock import AsyncMock

import pytest

# =============================================================================
# Test: Auth Routes Import
# =============================================================================


class TestAuthRoutesImport:
    """Tests for auth_routes module import."""

    def test_import_auth_routes_router(self) -> None:
        """auth_routes_router should be importable."""
        from framework_m_standard.adapters.web.auth_routes import auth_routes_router

        assert auth_routes_router is not None

    def test_import_create_auth_router(self) -> None:
        """create_auth_router should be importable."""
        from framework_m_standard.adapters.web.auth_routes import create_auth_router

        assert create_auth_router is not None

    def test_create_auth_router_returns_router(self) -> None:
        """create_auth_router should return the auth_routes_router."""
        from framework_m_standard.adapters.web.auth_routes import (
            auth_routes_router,
            create_auth_router,
        )

        assert create_auth_router() is auth_routes_router


# =============================================================================
# Test: GET /api/v1/auth/me
# =============================================================================


class TestGetCurrentUser:
    """Tests for GET /api/v1/auth/me endpoint."""

    def test_import_get_current_user(self) -> None:
        """get_current_user handler should be importable."""
        from framework_m_standard.adapters.web.auth_routes import get_current_user

        assert get_current_user is not None

    @pytest.mark.asyncio
    async def test_get_current_user_returns_user_context(self) -> None:
        """get_current_user should return user context dict."""
        from unittest.mock import MagicMock

        from framework_m_core.interfaces.auth_context import UserContext
        from framework_m_standard.adapters.web.auth_routes import get_current_user

        user = UserContext(
            id="user-123",
            email="test@example.com",
            name="Test User",
            roles=["Employee"],
            tenants=["tenant-001"],
        )

        # Create mock request with user in state
        mock_request = MagicMock()
        mock_request.state.user = user

        # Access underlying function via .fn for Litestar route handlers
        result = await get_current_user.fn(request=mock_request)

        assert result["id"] == "user-123"
        assert result["email"] == "test@example.com"
        assert result["name"] == "Test User"
        assert result["roles"] == ["Employee"]
        assert result["tenants"] == ["tenant-001"]


# =============================================================================
# Test: POST /api/v1/auth/login
# =============================================================================


class TestLogin:
    """Tests for POST /api/v1/auth/login endpoint."""

    def test_import_login(self) -> None:
        """login handler should be importable."""
        from framework_m_standard.adapters.web.auth_routes import login

        assert login is not None

    def test_import_login_request_dto(self) -> None:
        """LoginRequest DTO should be importable."""
        from framework_m_standard.adapters.web.auth_routes import LoginRequest

        assert LoginRequest is not None

    def test_login_request_validation(self) -> None:
        """LoginRequest should validate username and password."""
        from framework_m_standard.adapters.web.auth_routes import LoginRequest

        request = LoginRequest(username="user@example.com", password="secret123")
        assert request.username == "user@example.com"
        assert request.password == "secret123"

    @pytest.mark.asyncio
    async def test_login_raises_401_when_user_manager_not_configured(self) -> None:
        """login raises 401 when UserManager is not configured."""
        import sys

        from framework_m_standard.adapters.web.auth_routes import LoginRequest, login
        from litestar.exceptions import NotAuthorizedException

        auth_module = sys.modules["framework_m_standard.adapters.web.auth_routes"]

        original_um = auth_module._user_manager
        try:
            # Ensure user manager is not configured
            auth_module._user_manager = None
            request = LoginRequest(username="user@example.com", password="secret")
            mock_request = AsyncMock()
            mock_request.headers = {}
            mock_request.client = None
            with pytest.raises(NotAuthorizedException):
                await login.fn(data=request, request=mock_request)
        finally:
            auth_module._user_manager = original_um

    @pytest.mark.asyncio
    async def test_login_with_mocked_user_manager_raises_for_invalid_credentials(
        self,
    ) -> None:
        """login should raise 401 when UserManager returns AuthenticationError."""
        import sys

        auth_module = sys.modules["framework_m_standard.adapters.web.auth_routes"]
        from framework_m_core.exceptions import AuthenticationError
        from framework_m_standard.adapters.web.auth_routes import LoginRequest, login
        from litestar.exceptions import NotAuthorizedException

        # Temporarily set a mock UserManager
        mock_user_manager = AsyncMock()
        mock_user_manager.authenticate.side_effect = AuthenticationError("Invalid")

        original_user_manager = auth_module._user_manager
        auth_module._user_manager = mock_user_manager

        try:
            request = LoginRequest(username="user@example.com", password="wrong")
            mock_request = AsyncMock()
            mock_request.headers = {}
            mock_request.client = None
            with pytest.raises(NotAuthorizedException):
                await login.fn(data=request, request=mock_request)
        finally:
            auth_module._user_manager = original_user_manager

    @pytest.mark.asyncio
    async def test_login_raises_401_on_attribute_error(self) -> None:
        """login should raise 401 when authenticate raises AttributeError (backend uninitialized)."""
        import sys
        from unittest.mock import AsyncMock

        auth_module = sys.modules["framework_m_standard.adapters.web.auth_routes"]
        from framework_m_standard.adapters.web.auth_routes import LoginRequest, login
        from litestar.exceptions import NotAuthorizedException

        mock_user_manager = AsyncMock()
        mock_user_manager.authenticate.side_effect = AttributeError("No backend")

        original_user_manager = auth_module._user_manager
        auth_module._user_manager = mock_user_manager

        try:
            request = LoginRequest(username="user@example.com", password="pwd")
            mock_request = AsyncMock()
            mock_request.headers = {}
            mock_request.client = None
            with pytest.raises(
                NotAuthorizedException,
                match="Authentication backend is not initialized",
            ):
                await login.fn(data=request, request=mock_request)
        finally:
            auth_module._user_manager = original_user_manager

    @pytest.mark.asyncio
    async def test_login_fallback_when_user_context_is_none(self) -> None:
        """login should construct minimal context from token claims if get_by_email returns None."""
        import sys
        from unittest.mock import AsyncMock, MagicMock

        auth_module = sys.modules["framework_m_standard.adapters.web.auth_routes"]
        from framework_m_standard.adapters.web.auth_routes import LoginRequest, login

        mock_user_manager = AsyncMock()
        mock_token = MagicMock()
        mock_token.access_token = "test"
        mock_token.token_type = "bearer"
        mock_token.expires_in = 100
        mock_token.user_id = "fallback-user-id"
        mock_user_manager.authenticate.return_value = mock_token
        mock_user_manager.get_by_email.return_value = None

        mock_session_store = AsyncMock()
        mock_session_store.create.return_value = MagicMock(session_id="sess_fallback")

        original_user_manager = auth_module._user_manager
        original_session_store = auth_module._session_store

        auth_module._user_manager = mock_user_manager
        auth_module._session_store = mock_session_store

        try:
            request = LoginRequest(username="fallback@example.com", password="pwd")
            mock_request = AsyncMock()
            mock_request.headers = {}
            mock_request.client = None

            response = await login.fn(data=request, request=mock_request)
            assert response.status_code == 200
            assert response.content["user"]["id"] == "fallback-user-id"
            assert response.content["user"]["name"] == "Fallback"
        finally:
            auth_module._user_manager = original_user_manager
            auth_module._session_store = original_session_store


# =============================================================================
# Test: POST /api/v1/auth/logout
# =============================================================================


class TestLogout:
    """Tests for POST /api/v1/auth/logout endpoint."""

    def test_import_logout(self) -> None:
        """logout handler should be importable."""
        from framework_m_standard.adapters.web.auth_routes import logout

        assert logout is not None

    @pytest.mark.asyncio
    async def test_logout_returns_success(self) -> None:
        """logout should return success message."""
        from unittest.mock import MagicMock

        from framework_m_standard.adapters.web.auth_routes import logout

        # Access underlying function via .fn — pass a mock request
        mock_request = MagicMock()
        mock_request.cookies = {}
        result = await logout.fn(request=mock_request)

        assert result.status_code == 200
        assert result.content["message"] == "Logged out successfully"


# =============================================================================
# Test: Router Configuration
# =============================================================================


class TestAuthRouterConfig:
    """Tests for auth router configuration."""

    def test_router_has_correct_path(self) -> None:
        """Auth router should be mounted at /api/v1/auth."""
        from framework_m_standard.adapters.web.auth_routes import auth_routes_router

        assert auth_routes_router.path == "/api/v1/auth"

    def test_router_has_auth_tag(self) -> None:
        """Auth router should have 'auth' tag."""
        from framework_m_standard.adapters.web.auth_routes import auth_routes_router

        assert "auth" in auth_routes_router.tags


# =============================================================================
# Test: Helpers
# =============================================================================


class TestAuthHelpers:
    """Tests for auth module helper functions."""

    def test_get_user_manager_raises_when_none(self) -> None:
        import sys

        auth_module = sys.modules.get("framework_m_standard.adapters.web.auth_routes")
        if auth_module is None:
            import framework_m_standard.adapters.web.auth_routes as auth_module  # type: ignore[no-redef]

        original_um = auth_module._user_manager
        auth_module._user_manager = None
        try:
            with pytest.raises(RuntimeError, match="UserManager not configured"):
                auth_module.get_user_manager()
        finally:
            auth_module._user_manager = original_um

    def test_get_user_manager_returns_instance(self) -> None:
        import sys
        from unittest.mock import MagicMock

        auth_module = sys.modules.get("framework_m_standard.adapters.web.auth_routes")

        mock_um = MagicMock()
        original_um = auth_module._user_manager
        auth_module._user_manager = mock_um
        try:
            assert auth_module.get_user_manager() == mock_um
        finally:
            auth_module._user_manager = original_um

    def test_cookie_settings_invalid_samesite_fallback(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from framework_m_standard.adapters.web.auth_routes import (
            _COOKIE_SAMESITE,
            _get_cookie_settings,
        )

        monkeypatch.setenv("FRAMEWORK_M_COOKIE_SAMESITE", "invalid")
        settings = _get_cookie_settings()
        assert settings["samesite"] == _COOKIE_SAMESITE
