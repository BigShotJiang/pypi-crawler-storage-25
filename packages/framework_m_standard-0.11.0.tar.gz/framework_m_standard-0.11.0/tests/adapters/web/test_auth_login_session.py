"""Tests for Session Cookie Auth flow (RFC-0006 Strategy A: BFF Cookie Mode).

TDD: Tests written BEFORE implementation.

Tests cover:
- POST /api/v1/auth/login → Set-Cookie: session_id=...; HttpOnly; SameSite=Lax
- POST /api/v1/auth/logout → Set-Cookie: session_id=; Max-Age=0
- GET /api/v1/auth/me → returns authenticated user when cookie is valid
- GET /api/v1/auth/me → returns 401 when no cookie
- configure_session_store() wires session store into auth routes
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

# =============================================================================
# Test: configure_session_store()
# =============================================================================


class TestConfigureSessionStore:
    """Tests for configure_session_store() wiring function."""

    def test_configure_session_store_is_importable(self) -> None:
        """configure_session_store should be importable from auth_routes."""
        from framework_m_standard.adapters.web.auth_routes import (
            configure_session_store,
        )

        assert configure_session_store is not None

    def test_configure_session_store_sets_module_level_store(self) -> None:
        """configure_session_store should set the module-level _session_store."""
        import sys

        auth_module = sys.modules.get("framework_m_standard.adapters.web.auth_routes")
        if auth_module is None:
            import framework_m_standard.adapters.web.auth_routes as auth_module  # type: ignore[no-redef]

        from framework_m_standard.adapters.web.auth_routes import (
            configure_session_store,
        )

        mock_store = MagicMock()
        original = getattr(auth_module, "_session_store", None)

        try:
            configure_session_store(mock_store)
            assert auth_module._session_store is mock_store
        finally:
            auth_module._session_store = original


# =============================================================================
# Test: POST /api/v1/auth/login → Set-Cookie
# =============================================================================


class TestLoginSetsCookie:
    """Tests that /login sets an HttpOnly session cookie (not raw JWT)."""

    @pytest.mark.asyncio
    async def test_login_sets_session_cookie_header(self) -> None:
        """Successful login should set a Set-Cookie header with session_id."""
        import sys

        auth_module = sys.modules.get("framework_m_standard.adapters.web.auth_routes")
        if auth_module is None:
            import framework_m_standard.adapters.web.auth_routes as auth_module  # type: ignore[no-redef]

        from framework_m_core.interfaces.auth_context import UserContext
        from framework_m_core.interfaces.identity import Token
        from framework_m_standard.adapters.web.auth_routes import (
            LoginRequest,
            configure_auth_routes,
            configure_session_store,
            login,
        )

        # Set up mock UserManager
        mock_user_manager = AsyncMock()
        mock_user_manager.authenticate.return_value = Token(
            access_token="jwt-token",
            token_type="bearer",
            expires_in=86400,
        )
        mock_user_manager.get_by_email = AsyncMock(
            return_value=UserContext(
                id="user-001",
                email="user@example.com",
                name="Test User",
                roles=["User"],
            )
        )

        # Set up mock session store
        mock_session = MagicMock()
        mock_session.session_id = "sess_abc123"
        mock_store = AsyncMock()
        mock_store.create = AsyncMock(return_value=mock_session)

        original_um = auth_module._user_manager
        original_ss = getattr(auth_module, "_session_store", None)

        try:
            configure_auth_routes(mock_user_manager)
            configure_session_store(mock_store)

            # Create mock request (needed for cookie/IP extraction)
            mock_request = MagicMock()
            mock_request.headers = {}
            mock_request.client = MagicMock()
            mock_request.client.host = "127.0.0.1"

            request_data = LoginRequest(email="user@example.com", password="secret123")
            result = await login.fn(data=request_data, request=mock_request)

            assert result.status_code == 200
            # Should NOT have access_token in body (cookie mode)
            assert "access_token" not in result.content
            # Should return user info
            assert "user" in result.content
            assert result.cookies
            assert any(cookie.key == "session_id" for cookie in result.cookies)
            # Session store should have been called
            mock_store.create.assert_called_once()

        finally:
            auth_module._user_manager = original_um
            auth_module._session_store = original_ss

    @pytest.mark.asyncio
    async def test_login_invalid_credentials_raises_401(self) -> None:
        """Login with wrong credentials should raise 401 NotAuthorizedException."""
        import sys

        auth_module = sys.modules.get("framework_m_standard.adapters.web.auth_routes")
        if auth_module is None:
            import framework_m_standard.adapters.web.auth_routes as auth_module  # type: ignore[no-redef]

        from framework_m_core.exceptions import AuthenticationError
        from framework_m_standard.adapters.web.auth_routes import (
            LoginRequest,
            configure_auth_routes,
            login,
        )
        from litestar.exceptions import NotAuthorizedException

        mock_user_manager = AsyncMock()
        mock_user_manager.authenticate.side_effect = AuthenticationError(
            "Invalid credentials"
        )

        original_um = auth_module._user_manager
        try:
            configure_auth_routes(mock_user_manager)

            mock_request = MagicMock()
            mock_request.headers = {}
            mock_request.client = None

            request_data = LoginRequest(
                email="user@example.com", password="wrong_password"
            )
            with pytest.raises(NotAuthorizedException):
                await login.fn(data=request_data, request=mock_request)
        finally:
            auth_module._user_manager = original_um


# =============================================================================
# Test: POST /api/v1/auth/logout → Clear Cookie
# =============================================================================


class TestLogoutClearsCookie:
    """Tests that /logout returns a cookie-clearing Set-Cookie header."""

    @pytest.mark.asyncio
    async def test_logout_deletes_session(self) -> None:
        """Logout should delete the session from the store."""
        import sys

        auth_module = sys.modules.get("framework_m_standard.adapters.web.auth_routes")
        if auth_module is None:
            import framework_m_standard.adapters.web.auth_routes as auth_module  # type: ignore[no-redef]

        from framework_m_standard.adapters.web.auth_routes import (
            configure_session_store,
            logout,
        )

        mock_store = AsyncMock()
        mock_store.delete = AsyncMock(return_value=True)

        original_ss = getattr(auth_module, "_session_store", None)
        try:
            configure_session_store(mock_store)

            # Mock request with session cookie
            mock_request = MagicMock()
            mock_request.cookies = {"session_id": "sess_abc123"}

            result = await logout.fn(request=mock_request)

            # Session should be deleted
            mock_store.delete.assert_called_once_with("sess_abc123")
            assert result.status_code == 200
            assert result.content["message"] == "Logged out successfully"
            assert result.cookies
            assert any(cookie.key == "session_id" for cookie in result.cookies)

        finally:
            auth_module._session_store = original_ss

    @pytest.mark.asyncio
    async def test_logout_no_cookie_returns_success(self) -> None:
        """Logout with no cookie should succeed without error."""
        from framework_m_standard.adapters.web.auth_routes import logout

        mock_request = MagicMock()
        mock_request.cookies = {}

        result = await logout.fn(request=mock_request)
        assert result.status_code == 200
        assert result.content["message"] == "Logged out successfully"


# =============================================================================
# Test: GET /api/v1/auth/me → authenticated user
# =============================================================================


class TestMeEndpoint:
    """Tests for GET /api/v1/auth/me with session context."""

    @pytest.mark.asyncio
    async def test_me_returns_authenticated_user(self) -> None:
        """GET /me with user in request.state should return full user info."""
        from framework_m_core.interfaces.auth_context import UserContext
        from framework_m_standard.adapters.web.auth_routes import get_current_user

        user = UserContext(
            id="user-001",
            email="admin@example.com",
            name="Admin User",
            roles=["Admin"],
            tenants=["tenant-001"],
        )

        mock_request = MagicMock()
        mock_request.state.user = user

        result = await get_current_user.fn(request=mock_request)

        assert result["authenticated"] is True
        assert result["id"] == "user-001"
        assert result["email"] == "admin@example.com"
        assert result["roles"] == ["Admin"]

    @pytest.mark.asyncio
    async def test_me_returns_unauthenticated_without_user(self) -> None:
        """GET /me with no user in state should return authenticated=False."""
        from framework_m_standard.adapters.web.auth_routes import get_current_user

        mock_request = MagicMock()
        mock_request.state.user = None

        result = await get_current_user.fn(request=mock_request)

        assert result["authenticated"] is False
        assert result["id"] == "guest"


# =============================================================================
# Test: Cookie Security Flags (Phase D)
# =============================================================================


class TestCookieSecurityFlags:
    """Tests for environment-configurable cookie security flags."""

    def test_cookie_settings_default_values(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Default cookie settings should remain safe baseline values."""
        from framework_m_standard.adapters.web.auth_routes import _get_cookie_settings

        monkeypatch.delenv("FRAMEWORK_M_COOKIE_SECURE", raising=False)
        monkeypatch.delenv("FRAMEWORK_M_COOKIE_SAMESITE", raising=False)
        monkeypatch.delenv("FRAMEWORK_M_COOKIE_DOMAIN", raising=False)

        settings = _get_cookie_settings()

        assert settings["secure"] is True
        assert settings["samesite"] == "lax"
        assert settings["domain"] is None

    def test_cookie_settings_can_be_overridden_from_env(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Cookie settings should be configurable via environment variables."""
        from framework_m_standard.adapters.web.auth_routes import _get_cookie_settings

        monkeypatch.setenv("FRAMEWORK_M_COOKIE_SECURE", "true")
        monkeypatch.setenv("FRAMEWORK_M_COOKIE_SAMESITE", "strict")
        monkeypatch.setenv("FRAMEWORK_M_COOKIE_DOMAIN", "example.com")

        settings = _get_cookie_settings()

        assert settings["secure"] is True
        assert settings["samesite"] == "strict"
        assert settings["domain"] == "example.com"
