"""Tests for Structured Logging Middleware.

TDD tests for structured JSON logging, request correlation, and user tracking.
Tests written FIRST per CONTRIBUTING.md guidelines.
"""

import json
import logging
from typing import Any

import pytest

# These imports will fail initially in TDD workflow until implemented
from framework_m_standard.adapters.web.middleware.logging import (
    CustomJsonFormatter,
    LoggingMiddleware,
    RequestContextFilter,
    _request_ctx_var,
)
from litestar import Litestar, Request, get
from litestar.testing import TestClient

# =============================================================================
# Test Helpers
# =============================================================================


class LogCaptureHandler(logging.Handler):
    """Custom handler to capture log records for test assertions."""

    def __init__(self) -> None:
        super().__init__()
        self.records: list[logging.LogRecord] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.records.append(record)


@get("/test-log")
async def log_endpoint(request: Request[Any, Any, Any]) -> dict[str, str]:
    """Test endpoint that emits a log."""
    logger = logging.getLogger("test_logger")
    logger.info("Test log message")
    return {"status": "ok"}


@get("/auth-log")
async def auth_log_endpoint(request: Request[Any, Any, Any]) -> dict[str, str]:
    """Test endpoint that sets a mock user and emits a log."""

    # Mock user context setting (normally done by AuthMiddleware earlier in the chain)
    class MockUser:
        id = "user-999"

    request.state.user = MockUser()
    logger = logging.getLogger("test_logger")
    logger.info("Authenticated log message")
    return {"status": "ok"}


@pytest.fixture
def capture_handler() -> LogCaptureHandler:
    """Provide a fresh capture handler for each test."""
    return LogCaptureHandler()


@pytest.fixture
def test_logger(capture_handler: LogCaptureHandler) -> logging.Logger:
    """Create a test logger with the RequestContextFilter."""
    logger = logging.getLogger("test_logger")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    logger.addHandler(capture_handler)
    logger.addFilter(RequestContextFilter())
    return logger


# =============================================================================
# Tests
# =============================================================================


class TestLoggingMiddleware:
    """Tests for the LoggingMiddleware and Context Filter."""

    def test_middleware_injects_request_id(
        self, test_logger: logging.Logger, capture_handler: LogCaptureHandler
    ) -> None:
        """Middleware should extract 'x-request-id' and inject into log records."""
        app = Litestar(
            route_handlers=[log_endpoint],
            middleware=[LoggingMiddleware],
        )

        with TestClient(app) as client:
            response = client.get("/test-log", headers={"x-request-id": "req-123"})
            assert response.status_code == 200

        assert len(capture_handler.records) > 0
        record = capture_handler.records[0]

        assert hasattr(record, "request_id")
        assert record.request_id == "req-123"

    def test_middleware_generates_request_id_if_missing(
        self, test_logger: logging.Logger, capture_handler: LogCaptureHandler
    ) -> None:
        """Middleware should generate a UUID request_id if none is provided."""
        app = Litestar(
            route_handlers=[log_endpoint],
            middleware=[LoggingMiddleware],
        )

        with TestClient(app) as client:
            response = client.get("/test-log")
            assert response.status_code == 200

        assert len(capture_handler.records) > 0
        record = capture_handler.records[0]

        assert hasattr(record, "request_id")
        assert record.request_id is not None
        assert isinstance(record.request_id, str)
        assert len(record.request_id) > 0

    def test_middleware_injects_user_id(
        self, test_logger: logging.Logger, capture_handler: LogCaptureHandler
    ) -> None:
        """Middleware should extract user ID from request state if available."""
        app = Litestar(
            route_handlers=[auth_log_endpoint],
            middleware=[LoggingMiddleware],
        )

        with TestClient(app) as client:
            response = client.get("/auth-log")
            assert response.status_code == 200

        assert len(capture_handler.records) > 0
        record = capture_handler.records[0]

        assert hasattr(record, "user_id")
        assert record.user_id == "user-999"

    def test_filter_without_request_context(self) -> None:
        """Filter should not crash if called outside request context."""
        filter_instance = RequestContextFilter()
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="test",
            args=(),
            exc_info=None,
        )
        assert filter_instance.filter(record) is True
        assert not hasattr(record, "request_id")

    @pytest.mark.asyncio
    async def test_middleware_skips_non_http_websocket(self) -> None:
        """Middleware should pass through for lifespan scopes."""
        from unittest.mock import AsyncMock

        mock_app = AsyncMock()
        middleware = LoggingMiddleware(mock_app)
        scope = {"type": "lifespan"}
        receive = AsyncMock()
        send = AsyncMock()
        await middleware(scope, receive, send)
        mock_app.assert_awaited_once_with(scope, receive, send)

    def test_filter_without_request_id_in_state(self) -> None:
        """Filter should handle state without request_id or user gracefully."""
        from unittest.mock import MagicMock

        filter_instance = RequestContextFilter()
        mock_request = MagicMock()
        del mock_request.state.request_id
        del mock_request.state.user

        token = _request_ctx_var.set(mock_request)
        try:
            record = logging.LogRecord(
                name="test",
                level=logging.INFO,
                pathname="",
                lineno=0,
                msg="test",
                args=(),
                exc_info=None,
            )
            assert filter_instance.filter(record) is True
            assert not hasattr(record, "request_id")
            assert not hasattr(record, "user_id")
        finally:
            _request_ctx_var.reset(token)


class TestStructuredJsonFormatter:
    """Tests for the Custom JSON Formatter."""

    def test_json_formatter_outputs_valid_json_with_context(self) -> None:
        """Formatter should output valid JSON including injected context fields."""
        formatter = CustomJsonFormatter("%(timestamp)s %(level)s %(name)s %(message)s")

        record = logging.LogRecord(
            name="test.logger",
            level=logging.INFO,
            pathname="test_logging.py",
            lineno=10,
            msg="Structured log test",
            args=(),
            exc_info=None,
        )

        # Simulate the filter attaching context
        record.request_id = "req-abc-123"
        record.user_id = "user-001"

        formatted_str = formatter.format(record)

        # Verify it parses as JSON
        parsed = json.loads(formatted_str)

        assert parsed["message"] == "Structured log test"
        assert parsed["request_id"] == "req-abc-123"
        assert parsed["user_id"] == "user-001"
        assert "timestamp" in parsed

    def test_json_formatter_existing_timestamp_and_no_context(self) -> None:
        """Formatter should not overwrite timestamp and should handle missing context."""
        formatter = CustomJsonFormatter("%(message)s")
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="test",
            args=(),
            exc_info=None,
        )

        # Pass a log_record that already has a timestamp
        log_record = {"timestamp": "2026-01-01T00:00:00.000Z"}
        formatter.add_fields(log_record, record, {})

        assert log_record["timestamp"] == "2026-01-01T00:00:00.000Z"
        assert "request_id" not in log_record
        assert "user_id" not in log_record
