"""Tests for OAuth Provider Configuration and Identity Extraction.

Isolates tests for provider configuration and utility functions,
keeping route tests focused on HTTP behaviors.
"""

from unittest.mock import AsyncMock, patch

import pytest
from framework_m_standard.adapters.web.oauth_provider import (
    extract_email,
    extract_provider_user_id,
    get_provider_config,
    is_email_verified,
    resolve_provider_endpoints,
)
from litestar.exceptions import NotFoundException


def test_extract_email() -> None:
    """Should properly extract emails including Microsoft fallbacks."""
    # Standard OIDC
    assert extract_email("google", {"email": "test@google.com"}) == "test@google.com"

    # Microsoft fallbacks
    assert extract_email("microsoft", {"mail": "mail@ms.com"}) == "mail@ms.com"
    assert (
        extract_email("microsoft", {"userPrincipalName": "upn@ms.com"}) == "upn@ms.com"
    )
    assert extract_email("microsoft", {}) is None

    # Missing
    assert extract_email("google", {}) is None


def test_extract_provider_user_id() -> None:
    """Should properly extract user IDs including GitHub fallbacks."""
    # GitHub fallbacks
    assert extract_provider_user_id("github", {"id": 123}) == "123"
    assert extract_provider_user_id("github", {"node_id": "node123"}) == "node123"
    assert extract_provider_user_id("github", {"sub": "sub123"}) == "sub123"
    assert extract_provider_user_id("github", {}) == ""

    # Standard OIDC fallbacks
    assert extract_provider_user_id("google", {"sub": "sub123"}) == "sub123"
    assert extract_provider_user_id("google", {"id": "id123"}) == "id123"
    assert extract_provider_user_id("google", {}) == ""


def test_is_email_verified() -> None:
    """Should handle various email verification payload types."""
    # Boolean
    assert is_email_verified("google", {"email_verified": True}) is True
    assert is_email_verified("google", {"email_verified": False}) is False

    # String
    assert is_email_verified("google", {"email_verified": "true"}) is True
    assert is_email_verified("google", {"email_verified": "False"}) is False

    # GitHub fallback
    assert (
        is_email_verified("github", {"email": "test@git.com", "email_verified": True})
        is True
    )
    assert is_email_verified("github", {"email": "test@git.com"}) is False

    # Default
    assert is_email_verified("google", {}) is False


@pytest.mark.asyncio
async def test_resolve_provider_endpoints_built_in() -> None:
    """Should resolve built-in providers and apply scope overrides."""
    cfg = {"scope": "custom scope"}
    res = await resolve_provider_endpoints("google", cfg)
    assert res["scope"] == "custom scope"
    assert res["authorization_url"] == "https://accounts.google.com/o/oauth2/v2/auth"


@pytest.mark.asyncio
async def test_resolve_provider_endpoints_discovery() -> None:
    """Should resolve discovery URLs and apply email URLs."""
    cfg = {
        "discovery_url": "https://auth.com/.well-known",
        "emails_url": "https://auth.com/emails",
    }

    with patch(
        "framework_m_standard.adapters.web.oauth_client.OAuthHTTPClient.fetch_discovery_metadata",
        new=AsyncMock(return_value={"authorization_url": "https://auth.com/auth"}),
    ):
        res = await resolve_provider_endpoints("custom", cfg)
        assert res["authorization_url"] == "https://auth.com/auth"
        assert res["emails_url"] == "https://auth.com/emails"


@pytest.mark.asyncio
async def test_resolve_provider_endpoints_explicit() -> None:
    """Should fallback to explicit well-known OIDC parameters."""
    cfg = {"authorization_url": "https://auth", "token_url": "https://token"}
    res = await resolve_provider_endpoints("custom", cfg)
    assert res["authorization_url"] == "https://auth"


@pytest.mark.asyncio
async def test_resolve_provider_endpoints_failure() -> None:
    """Should raise NotFoundException if provider lacks discovery and explicit URLs."""
    cfg = {}
    with pytest.raises(NotFoundException):
        await resolve_provider_endpoints("custom", cfg)


def test_get_provider_config_dict_fallback() -> None:
    """Should return None if a provider config entry is mysteriously not a dict."""
    config = {"auth": {"oauth": {"providers": {"custom": "not_a_dict"}}}}
    with patch(
        "framework_m_standard.adapters.web.oauth_provider.load_config",
        return_value=config,
    ):
        assert get_provider_config("custom") is None
