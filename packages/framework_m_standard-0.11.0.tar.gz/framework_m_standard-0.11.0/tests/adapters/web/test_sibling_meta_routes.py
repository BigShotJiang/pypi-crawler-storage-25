"""Tests for sibling metadata discovery endpoint used by Desk UI."""

from __future__ import annotations

from typing import ClassVar

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.web.sibling_meta_router import sibling_meta_router
from litestar import Litestar
from litestar.testing import TestClient


class ParentInvoice(BaseDocType):
    """Parent DocType for sibling route tests."""

    customer: str = Field(default="")


class InvoiceOverlay(BaseDocType):
    """Metadata overlay sibling for ParentInvoice."""

    note: str = Field(default="")

    class Meta:
        label: ClassVar[str] = "Invoice Overlay"
        extends: ClassVar[str] = "ParentInvoice"
        is_metadata_overlay: ClassVar[bool] = True


class InvoiceFooterExtra(BaseDocType):
    """Non-overlay sibling for ParentInvoice."""

    comment: str = Field(default="")

    class Meta:
        label: ClassVar[str] = "Invoice Extra"
        extends: ClassVar[str] = "ParentInvoice"
        is_metadata_overlay: ClassVar[bool] = False


class UnrelatedSibling(BaseDocType):
    """Sibling of another parent should not be listed."""

    text: str = Field(default="")

    class Meta:
        label: ClassVar[str] = "Other Parent Child"
        extends: ClassVar[str] = "OtherParent"


@pytest.fixture(autouse=True)
def register_doctypes() -> None:
    registry = MetaRegistry.get_instance()

    for doctype in [
        ParentInvoice,
        InvoiceOverlay,
        InvoiceFooterExtra,
        UnrelatedSibling,
    ]:
        try:
            registry.get_doctype(doctype.__name__)
        except KeyError:
            registry.register_doctype(doctype)


@pytest.fixture
def app() -> Litestar:
    return Litestar(route_handlers=[sibling_meta_router])


@pytest.fixture
def client(app: Litestar) -> TestClient[Litestar]:
    return TestClient(app)


def test_lists_registered_siblings_for_parent_doctype(
    client: TestClient[Litestar],
) -> None:
    response = client.get("/api/v1/meta/ParentInvoice/siblings")

    assert response.status_code == 200
    payload = response.json()

    assert len(payload["siblings"]) == 2

    by_doctype = {item["doctype"]: item for item in payload["siblings"]}
    assert by_doctype["InvoiceOverlay"]["extends"] == "ParentInvoice"
    assert by_doctype["InvoiceOverlay"]["label"] == "Invoice Overlay"
    assert by_doctype["InvoiceOverlay"]["is_metadata_overlay"] is True

    assert by_doctype["InvoiceFooterExtra"]["extends"] == "ParentInvoice"
    assert by_doctype["InvoiceFooterExtra"]["label"] == "Invoice Extra"
    assert by_doctype["InvoiceFooterExtra"]["is_metadata_overlay"] is False


def test_returns_empty_siblings_when_parent_has_no_registered_companions(
    client: TestClient[Litestar],
) -> None:
    response = client.get("/api/v1/meta/UnknownParent/siblings")

    assert response.status_code == 200
    payload = response.json()
    assert payload["siblings"] == []
