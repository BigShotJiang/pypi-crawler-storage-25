"""Coverage tests for file_routes edge cases and endpoints."""

from unittest.mock import patch

import pytest
from framework_m_standard.adapters.web.file_routes import (
    _parse_size,
    file_router,
    get_content_type,
)
from litestar import Litestar
from litestar.testing import TestClient


def test_parse_size_invalid_fallback() -> None:
    """Should fall back to 10MB when an invalid size string is provided."""
    assert _parse_size("invalid_format") == 10 * 1024 * 1024


def test_get_content_type_unknown() -> None:
    """Should fall back to octet-stream for unknown extensions."""
    assert get_content_type("unknown_file_without_ext") == "application/octet-stream"


@pytest.fixture
def client() -> TestClient:
    app = Litestar(route_handlers=[file_router])
    return TestClient(app=app)


def test_upload_file_success(client: TestClient) -> None:
    """Should successfully handle multipart file uploads."""
    with patch(
        "framework_m_standard.adapters.web.file_routes.get_file_config"
    ) as mock_config:
        mock_config.return_value = {
            "max_upload_size": 10 * 1024 * 1024,
            "allowed_extensions": ["txt"],
            "storage_backend": "local",
            "storage_path": "./uploads",
        }

        response = client.post(
            "/api/v1/file/upload", files={"data": ("test.txt", b"dummy content")}
        )

        assert response.status_code == 201
        data = response.json()
        assert data["file_name"] == "test.txt"
        assert data["file_size"] == 13
        assert data["content_type"] == "text/plain"


@pytest.mark.parametrize(
    "endpoint",
    [
        ("GET", "/api/v1/file/fake-id"),
        ("GET", "/api/v1/file/fake-id/info"),
        ("DELETE", "/api/v1/file/fake-id"),
    ],
)
def test_file_endpoints_placeholders_raise_not_found(
    client: TestClient, endpoint: tuple[str, str]
) -> None:
    """Should raise NotFoundException for unimplemented placeholder endpoints."""
    method, url = endpoint
    response = client.request(method, url)
    assert response.status_code == 404
    assert "not found" in response.text.lower()
