"""Tests for OpenTelemetry Tracing.

TDD tests for distributed tracing collection.
Tests written FIRST per CONTRIBUTING.md guidelines.
"""

import pytest

# These imports will fail initially in TDD workflow until implemented/installed
from framework_m_standard.adapters.web.tracing import setup_tracing
from litestar import Litestar, get
from litestar.testing import TestClient
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
    InMemorySpanExporter,
)


@get("/trace-test")
async def sample_endpoint() -> dict[str, str]:
    """Sample endpoint to generate a span."""
    # Manually create a sub-span to ensure context propagation works
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span("internal_work"):
        pass
    return {"status": "ok"}


@pytest.fixture
def span_exporter() -> "InMemorySpanExporter":
    """Provide an in-memory exporter for testing."""
    return InMemorySpanExporter()


@pytest.fixture
def tracer_provider(span_exporter: "InMemorySpanExporter") -> "TracerProvider":
    """Provide a test tracer provider."""
    provider = TracerProvider()
    processor = SimpleSpanProcessor(span_exporter)
    provider.add_span_processor(processor)
    trace.set_tracer_provider(provider)
    return provider


class TestTracingIntegration:
    """Tests for OpenTelemetry tracing integration."""

    def test_http_request_generates_spans(
        self, span_exporter: "InMemorySpanExporter", tracer_provider: "TracerProvider"
    ) -> None:
        """An HTTP request should generate an OTel span."""
        app = Litestar(route_handlers=[sample_endpoint])
        setup_tracing(app)

        with TestClient(app) as client:
            response = client.get("/trace-test")
            assert response.status_code == 200

        spans = span_exporter.get_finished_spans()

        assert len(spans) > 0, "No spans were exported"
