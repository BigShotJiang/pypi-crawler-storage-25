"""Tests for Elasticsearch audit adapter."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from framework_m_standard.adapters.audit.elastic import ElasticAuditAdapter


class TestElasticAuditAdapter:
    """Behavior tests for ElasticAuditAdapter."""

    @pytest.mark.asyncio
    async def test_log_translates_audit_entry_to_document(self) -> None:
        """log() should write an audit entry as an Elasticsearch document."""
        client = AsyncMock()
        adapter = ElasticAuditAdapter(client=client, index_prefix="audit-test")

        entry_id = await adapter.log(
            user_id="user-1",
            action="create",
            doctype="Invoice",
            document_id="INV-001",
            metadata={"request_id": "req-123"},
        )

        client.index.assert_awaited_once()
        call_kwargs = client.index.await_args.kwargs
        assert call_kwargs["id"] == entry_id
        assert call_kwargs["index"].startswith("audit-test-")
        assert call_kwargs["document"]["user_id"] == "user-1"
        assert call_kwargs["document"]["doctype"] == "Invoice"
        assert call_kwargs["document"]["metadata"]["request_id"] == "req-123"

    @pytest.mark.asyncio
    async def test_query_translates_filters_and_parses_hits(self) -> None:
        """query() should pass filters to Elasticsearch and parse results."""
        client = AsyncMock()
        client.search.return_value = {
            "hits": {
                "hits": [
                    {
                        "_source": {
                            "id": "entry-1",
                            "timestamp": "2025-01-01T00:00:00Z",
                            "user_id": "user-1",
                            "action": "update",
                            "doctype": "Invoice",
                            "document_id": "INV-001",
                            "changes": {"status": {"old": "draft", "new": "paid"}},
                            "metadata": {"request_id": "req-999"},
                        }
                    }
                ]
            }
        }
        adapter = ElasticAuditAdapter(client=client, index_prefix="audit-test")

        result = await adapter.query(filters={"user_id": "user-1"}, limit=10, offset=5)

        client.search.assert_awaited_once()
        call_kwargs = client.search.await_args.kwargs
        assert call_kwargs["index"] == "audit-test-*"
        assert call_kwargs["from_"] == 5
        assert call_kwargs["size"] == 10
        assert call_kwargs["query"]["bool"]["filter"] == [
            {"term": {"user_id": "user-1"}}
        ]
        assert len(result) == 1
        assert result[0].id == "entry-1"
        assert result[0].action == "update"
