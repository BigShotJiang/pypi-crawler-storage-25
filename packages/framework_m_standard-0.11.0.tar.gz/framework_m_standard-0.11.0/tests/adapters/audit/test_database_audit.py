"""Tests for Database Audit Adapter.

Tests cover:
- DatabaseAuditAdapter initialization
- Log and query operations
- ActivityLog integration
"""

from unittest.mock import AsyncMock

import pytest
from framework_m_core.doctypes.activity_log import ActivityLog
from framework_m_core.interfaces.audit import AuditEntry
from framework_m_core.interfaces.repository import (
    FilterOperator,
    PaginatedResult,
    RepositoryProtocol,
)
from framework_m_standard.adapters.audit.database_audit import DatabaseAuditAdapter

# =============================================================================
# Test: Import
# =============================================================================


class TestDatabaseAuditImport:
    """Tests for DatabaseAuditAdapter import."""

    def test_import_database_audit_adapter(self) -> None:
        """DatabaseAuditAdapter should be importable."""
        from framework_m_standard.adapters.audit import DatabaseAuditAdapter

        assert DatabaseAuditAdapter is not None


class TestDatabaseAuditInit:
    """Tests for initialization."""

    def test_init_requires_repository(self) -> None:
        """Should accept repository in constructor."""
        mock_repo = AsyncMock(spec=RepositoryProtocol)
        adapter = DatabaseAuditAdapter(repository=mock_repo)
        assert adapter._repository is mock_repo


# =============================================================================
# Test: Log
# =============================================================================


class TestDatabaseAuditLog:
    """Tests for log operation."""

    @pytest.mark.asyncio
    async def test_log_returns_id(self) -> None:
        """log() should return entry ID."""
        mock_repo = AsyncMock(spec=RepositoryProtocol)

        def save_side_effect(entity, version=None):
            entity.id = "12345678-1234-5678-1234-567812345678"
            return entity

        mock_repo.save.side_effect = save_side_effect
        adapter = DatabaseAuditAdapter(repository=mock_repo)

        entry_id = await adapter.log(
            user_id="user-001",
            action="create",
            doctype="Todo",
            document_id="TODO-001",
        )

        assert entry_id == "12345678-1234-5678-1234-567812345678"
        assert isinstance(entry_id, str)

    @pytest.mark.asyncio
    async def test_log_calls_repository_save(self) -> None:
        """log() should call repository.save with correctly mapped ActivityLog."""
        mock_repo = AsyncMock(spec=RepositoryProtocol)
        adapter = DatabaseAuditAdapter(repository=mock_repo)

        await adapter.log(
            user_id="user-001",
            action="update",
            doctype="Invoice",
            document_id="TODO-001",
            changes={"status": {"old": "open", "new": "closed"}},
            metadata={"ip": "127.0.0.1"},
        )

        mock_repo.save.assert_called_once()
        saved_entry = mock_repo.save.call_args[0][0]

        assert isinstance(saved_entry, ActivityLog)
        assert saved_entry.user_id == "user-001"
        assert saved_entry.action == "update"
        # Verify field mapping (doctype -> doctype_name, changes -> diff)
        assert saved_entry.doctype_name == "Invoice"
        assert saved_entry.document_id == "TODO-001"
        assert saved_entry.diff == {"status": {"old": "open", "new": "closed"}}
        assert saved_entry.metadata == {"ip": "127.0.0.1"}

    @pytest.mark.asyncio
    async def test_log_propagates_repository_error(self) -> None:
        """Database errors should propagate."""
        mock_repo = AsyncMock(spec=RepositoryProtocol)
        mock_repo.save.side_effect = Exception("DB Error")
        adapter = DatabaseAuditAdapter(repository=mock_repo)

        with pytest.raises(Exception, match="DB Error"):
            await adapter.log(
                user_id="user-001",
                action="create",
                doctype="Todo",
                document_id="TODO-001",
            )

    @pytest.mark.asyncio
    async def test_log_creates_new_instance(self) -> None:
        """log() should always create new ActivityLog (never update)."""
        # This implies we are not passing an ID to save() for existing records
        # covered by test_log_calls_repository_save implicitly
        pass


# =============================================================================
# Test: Query
# =============================================================================


class TestDatabaseAuditQuery:
    """Tests for query operation."""

    @pytest.mark.asyncio
    async def test_query_calls_repository_list(self) -> None:
        """query() should call repository.list with filters and map results."""
        mock_repo = AsyncMock(spec=RepositoryProtocol)

        # Mock return from repo
        mock_log = ActivityLog(
            user_id="user-1",
            action="create",
            doctype_name="Invoice",
            document_id="inv-1",
            id="12345678-1234-5678-1234-567812345678",
        )
        mock_repo.list.return_value = PaginatedResult(
            items=[mock_log], total=1, limit=10, offset=5
        )

        adapter = DatabaseAuditAdapter(repository=mock_repo)

        results = await adapter.query(
            filters={"doctype": "Invoice"}, limit=10, offset=5
        )

        # Check Repository Call
        mock_repo.list.assert_called_once()
        call_kwargs = mock_repo.list.call_args.kwargs

        assert call_kwargs["limit"] == 10
        assert call_kwargs["offset"] == 5

        # Check Filters
        filters = call_kwargs["filters"]
        assert len(filters) == 1
        assert filters[0].field == "doctype_name"  # Mapped
        assert filters[0].operator == FilterOperator.EQ
        assert filters[0].value == "Invoice"

        # Check Result Mapping
        assert len(results) == 1
        assert isinstance(results[0], AuditEntry)
        assert results[0].doctype == "Invoice"  # Mapped back
        assert results[0].user_id == "user-1"

    @pytest.mark.asyncio
    async def test_query_time_filters(self) -> None:
        """query() should map from/to timestamp to GTE/LTE filters."""
        mock_repo = AsyncMock(spec=RepositoryProtocol)
        mock_repo.list.return_value = PaginatedResult(
            items=[], total=0, limit=50, offset=0
        )
        adapter = DatabaseAuditAdapter(repository=mock_repo)

        from datetime import datetime

        dt = datetime(2024, 1, 1)
        await adapter.query(filters={"from_timestamp": dt, "to_timestamp": dt})

        filters = mock_repo.list.call_args.kwargs["filters"]

        f_gte = next(f for f in filters if f.operator == FilterOperator.GTE)
        assert f_gte.field == "timestamp"
        assert f_gte.value == dt

        f_lte = next(f for f in filters if f.operator == FilterOperator.LTE)
        assert f_lte.field == "timestamp"
        assert f_lte.value == dt

    @pytest.mark.asyncio
    async def test_query_standard_filters(self) -> None:
        """query() should map standard filters."""
        mock_repo = AsyncMock(spec=RepositoryProtocol)
        mock_repo.list.return_value = PaginatedResult(
            items=[], total=0, limit=50, offset=0
        )
        adapter = DatabaseAuditAdapter(repository=mock_repo)

        await adapter.query(
            filters={
                "user_id": "user-1",
                "action": "create",
                "document_id": "doc-1",
            }
        )

        filters = mock_repo.list.call_args.kwargs["filters"]
        assert len(filters) == 3
        fields = {f.field for f in filters}
        assert "user_id" in fields
        assert "action" in fields
        assert "document_id" in fields
