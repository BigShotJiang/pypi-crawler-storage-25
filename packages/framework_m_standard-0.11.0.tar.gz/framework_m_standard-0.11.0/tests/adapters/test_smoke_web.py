from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from framework_m_standard.adapters.web.app import create_app
from framework_m_standard.adapters.web.auth_routes import login, logout


@pytest.mark.asyncio
async def test_web_app_smoke():
    # Smoke test for create_app factory
    with patch("litestar.Litestar"):
        app = create_app()
        assert app is not None


@pytest.mark.asyncio
async def test_auth_routes_smoke():
    # Smoke test for auth routes
    # These are unit tests for the route handlers
    request = MagicMock()
    request.state = MagicMock()

    # Just check if they can be called/imported
    assert login is not None
    assert logout is not None


def test_oauth_routes_import():
    from framework_m_standard.adapters.web import oauth_routes

    assert oauth_routes is not None
