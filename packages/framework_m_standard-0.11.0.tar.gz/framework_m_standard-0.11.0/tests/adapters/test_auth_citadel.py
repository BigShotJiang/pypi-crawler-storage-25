"""Tests for Citadel IAM Authentication Strategy."""

import base64
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_standard.adapters.auth.citadel_auth import CitadelAuth, S2sClient


@pytest.mark.asyncio
async def test_citadel_auth_supports():
    """Verify supports() detects headers based on strategy."""
    # TRUST_PROXY
    auth = CitadelAuth(strategy="TRUST_PROXY")
    assert auth.supports({"x-user-id": "123"}) is True
    assert auth.supports({"x-service-id": "456"}) is True
    assert auth.supports({"authorization": "Bearer token"}) is False

    # ZERO_TRUST
    auth = CitadelAuth(strategy="ZERO_TRUST", iam_url="http://iam")
    assert auth.supports({"authorization": "Bearer token"}) is True
    assert auth.supports({"x-user-id": "123"}) is False


@pytest.mark.asyncio
async def test_citadel_auth_trust_proxy_extraction():
    """Verify header extraction in TRUST_PROXY mode."""
    auth = CitadelAuth(strategy="TRUST_PROXY")

    # Mock user attributes (base64)
    user_attrs = {"full_name": "Antigravity AI", "dept": "Core"}
    user_attrs_b64 = base64.b64encode(json.dumps(user_attrs).encode()).decode()

    # Mock tenant attributes (base64)
    tenant_attrs = {"plan": "enterprise", "region": "us-east-1"}
    tenant_attrs_b64 = base64.b64encode(json.dumps(tenant_attrs).encode()).decode()

    headers = {
        "x-user-id": "user-123",
        "x-email": "ai@example.com",
        "x-user-roles": "User, Admin",
        "x-tenant-id": "tenant-verified",
        "x-active-tenant-id": "tenant-selector",
        "x-user-attributes": user_attrs_b64,
        "x-tenant-attributes": tenant_attrs_b64,
    }

    user = await auth.authenticate(headers)
    assert user is not None
    assert user.id == "user-123"
    assert user.email == "ai@example.com"
    assert user.name == "Antigravity AI"
    assert "Admin" in user.roles
    assert "tenant-verified" in user.tenants
    assert user.attributes["active_tenant_id"] == "tenant-selector"

    # Verify attribute merging
    assert user.attributes["dept"] == "Core"
    assert user.attributes["tenant_attributes"]["plan"] == "enterprise"


@pytest.mark.asyncio
async def test_citadel_auth_service_identity():
    """Verify service identity extraction."""
    auth = CitadelAuth(strategy="TRUST_PROXY")

    headers = {
        "x-service-id": "service-abc",
        "x-scopes": "read, write",
    }

    user = await auth.authenticate(headers)
    assert user is not None
    assert user.id == "service-abc"
    assert user.attributes["is_service"] is True
    assert "read" in user.attributes["scopes"]


@pytest.mark.asyncio
async def test_citadel_auth_zero_trust_enrichment():
    """Verify token enrichment in ZERO_TRUST mode."""
    iam_url = "http://citadel-iam"
    s2s_client = MagicMock(spec=S2sClient)
    s2s_client.get_admin_token = AsyncMock(return_value="admin-token-456")

    auth = CitadelAuth(strategy="ZERO_TRUST", iam_url=iam_url, s2s_client=s2s_client)

    headers = {"authorization": "Bearer user-token-123"}

    # Mock response from IAM service
    mock_resp = MagicMock()
    mock_resp.headers = {
        "x-user-id": "user-789",
        "x-email": "enriched@example.com",
        "x-user-roles": "Superuser",
    }
    mock_resp.status_code = 200
    mock_resp.raise_for_status = MagicMock()

    with patch("httpx.AsyncClient") as mock_client_class:
        mock_client = mock_client_class.return_value.__aenter__.return_value
        mock_client.get = AsyncMock(return_value=mock_resp)

        user = await auth.authenticate(headers)

        assert user is not None
        assert user.id == "user-789"
        assert user.email == "enriched@example.com"
        assert "Superuser" in user.roles

        # Verify call parameters
        mock_client.get.assert_called_once()
        args, kwargs = mock_client.get.call_args
        assert args[0] == f"{iam_url}/api/iam/v1/system/enrich-token"
        assert kwargs["headers"]["X-S2s-Token"] == "admin-token-456"


@pytest.mark.asyncio
async def test_s2s_client_token_fetching():
    """Verify S2S client fetches and caches tokens."""
    token_url = "http://iam/oauth/token"
    client = S2sClient(token_url, "cid", "csec")

    mock_resp = MagicMock()
    mock_resp.json.return_value = {"access_token": "new-token-999"}
    mock_resp.status_code = 200
    mock_resp.raise_for_status = MagicMock()

    with patch("httpx.AsyncClient") as mock_client_class:
        mock_client = mock_client_class.return_value.__aenter__.return_value
        mock_client.post = AsyncMock(return_value=mock_resp)

        token = await client.get_admin_token()
        assert token == "new-token-999"

        # Second call should use cache
        token2 = await client.get_admin_token()
        assert token2 == "new-token-999"
        assert mock_client.post.call_count == 1


@pytest.mark.asyncio
async def test_auth_chain_citadel_integration():
    """Verify CitadelAuth works within an AuthChain."""
    from framework_m_standard.adapters.auth.strategies import AuthChain

    citadel = CitadelAuth(strategy="TRUST_PROXY")
    chain = AuthChain(strategies=[citadel])

    headers = {"x-user-id": "citadel-user"}
    assert chain.supports(headers) is True

    user = await chain.authenticate(headers)
    assert user is not None
    assert user.id == "citadel-user"


@pytest.mark.asyncio
async def test_auth_factory_creates_citadel_strategy():
    """Verify create_auth_chain_from_config handles 'citadel'."""
    from framework_m_standard.adapters.auth.strategies import (
        create_auth_chain_from_config,
    )

    with patch(
        "framework_m_standard.adapters.auth.strategies.load_config"
    ) as mock_load:
        mock_load.return_value = {
            "auth": {
                "strategies": ["citadel"],
                "citadel": {"strategy": "ZERO_TRUST", "iam_url": "http://iam-factory"},
            }
        }

        chain = create_auth_chain_from_config(jwt_secret="secret")
        assert len(chain._strategies) == 1
        # Use __class__.__name__ comparison to avoid import issues in some environments
        assert chain._strategies[0].__class__.__name__ == "CitadelAuth"
        assert chain._strategies[0].strategy == "ZERO_TRUST"
        assert chain._strategies[0].iam_url == "http://iam-factory"
