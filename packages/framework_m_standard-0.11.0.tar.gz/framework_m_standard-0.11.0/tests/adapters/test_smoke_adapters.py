from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from framework_m_standard.adapters.i18n import InMemoryI18nAdapter
from framework_m_standard.adapters.web.middleware.locale import (
    LocaleResolutionMiddleware,
)


def test_i18n_adapter_behavior():
    # Smoke test for InMemoryI18nAdapter
    adapter = InMemoryI18nAdapter()
    # Basic verification of attributes/existence
    assert hasattr(adapter, "translate")


@pytest.mark.asyncio
async def test_locale_middleware_behavior():
    # Smoke test for LocaleResolutionMiddleware (ASGI)
    app = AsyncMock()
    middleware = LocaleResolutionMiddleware(app)

    # Mock ASGI scope, receive, send
    scope = {
        "type": "http",
        "headers": [(b"accept-language", b"en-US,en;q=0.9")],
        "state": MagicMock(),
    }
    receive = AsyncMock()
    send = AsyncMock()

    await middleware(scope, receive, send)
    assert app.called
