"""Tests for NatsEventBusAdapter."""

import asyncio
from datetime import UTC, datetime
from unittest.mock import AsyncMock, Mock, patch

import pytest
from framework_m_core.interfaces.event_bus import Event

# =============================================================================
# Test: NatsEventBusAdapter Import and Instantiation
# =============================================================================


class TestNatsEventBusImport:
    """Tests for NatsEventBusAdapter module import."""

    def test_import_nats_event_bus(self) -> None:
        """NatsEventBusAdapter should be importable."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        assert NatsEventBusAdapter is not None

    def test_nats_event_bus_instantiation(self) -> None:
        """NatsEventBusAdapter should be instantiable."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter(nats_url="nats://localhost:4222")
        assert bus is not None

    def test_nats_event_bus_default_url_from_env(self) -> None:
        """NatsEventBusAdapter should use NATS_URL env var."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        with patch.dict("os.environ", {"NATS_URL": "nats://test:4222"}):
            bus = NatsEventBusAdapter()
            assert bus._nats_url == "nats://test:4222"


# =============================================================================
# Test: Connection Lifecycle
# =============================================================================


class TestNatsEventBusConnection:
    """Tests for NatsEventBusAdapter connection lifecycle."""

    def test_is_connected_initially_false(self) -> None:
        """Bus should not be connected initially."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter(nats_url="nats://localhost:4222")
        assert bus.is_connected() is False

    @pytest.mark.asyncio
    async def test_connect_handles_add_stream_exception(self) -> None:
        """connect() should suppress stream creation exceptions (like stream already exists)."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter()
        mock_js = Mock()
        mock_js.add_stream = AsyncMock(side_effect=Exception("Stream exists"))
        mock_nc = Mock()
        mock_nc.jetstream = Mock(return_value=mock_js)

        with patch("nats.connect", new_callable=AsyncMock, return_value=mock_nc):
            await bus.connect()
            assert bus.is_connected() is True

    @pytest.mark.asyncio
    async def test_connect_sets_connected(self) -> None:
        """connect() should establish connection."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter(nats_url="nats://localhost:4222")

        mock_js = Mock()
        mock_js.add_stream = AsyncMock()

        mock_nc = Mock()
        mock_nc.jetstream = Mock(return_value=mock_js)
        mock_nc.close = AsyncMock()

        with patch("nats.connect", new_callable=AsyncMock, return_value=mock_nc):
            await bus.connect()
            assert bus.is_connected() is True

    @pytest.mark.asyncio
    async def test_disconnect_closes_connection(self) -> None:
        """disconnect() should close connection."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter(nats_url="nats://localhost:4222")

        mock_js = Mock()
        mock_js.add_stream = AsyncMock()

        mock_nc = Mock()
        mock_nc.jetstream = Mock(return_value=mock_js)
        mock_nc.close = AsyncMock()

        with patch("nats.connect", new_callable=AsyncMock, return_value=mock_nc):
            await bus.connect()
            await bus.disconnect()

            mock_nc.close.assert_called_once()
            assert bus.is_connected() is False


# =============================================================================
# Test: Publish
# =============================================================================


class TestNatsEventBusPublish:
    """Tests for NatsEventBusAdapter publish functionality."""

    @pytest.mark.asyncio
    async def test_publish_not_connected(self) -> None:
        """publish() should return early if not connected."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter()
        event = Event(id="1", type="test", source="test", timestamp=datetime.now(UTC))
        # Should return silently without raising
        await bus.publish("test", event)

    @pytest.mark.asyncio
    async def test_publish_serializes_event(self) -> None:
        """publish() should serialize event to JSON."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter(nats_url="nats://localhost:4222")

        mock_js = Mock()
        mock_js.add_stream = AsyncMock()
        mock_js.publish = AsyncMock()

        mock_nc = Mock()
        mock_nc.jetstream = Mock(return_value=mock_js)
        mock_nc.close = AsyncMock()

        with patch("nats.connect", new_callable=AsyncMock, return_value=mock_nc):
            await bus.connect()

            event = Event(
                id="evt-001",
                type="doc.created",
                source="test",
                timestamp=datetime.now(UTC),
            )

            await bus.publish("doc.created", event)

            # Should call js.publish with serialized data
            mock_js.publish.assert_called_once()
            call_args = mock_js.publish.call_args
            assert "events.doc.created" in call_args[0][0]


# =============================================================================
# Test: Subscribe
# =============================================================================


class TestNatsEventBusSubscribe:
    """Tests for NatsEventBusAdapter subscribe functionality."""

    @pytest.mark.asyncio
    async def test_subscribe_not_connected_raises(self) -> None:
        """subscribe() should raise RuntimeError if not connected."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter()

        async def handler(e: Event) -> None:
            pass

        with pytest.raises(RuntimeError, match="Not connected to NATS"):
            await bus.subscribe("test", handler)

    @pytest.mark.asyncio
    async def test_subscribe_pattern_not_connected_raises(self) -> None:
        """subscribe_pattern() should raise RuntimeError if not connected."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter()

        async def handler(e: Event) -> None:
            pass

        with pytest.raises(RuntimeError, match="Not connected to NATS"):
            await bus.subscribe_pattern("test.*", handler)

    @pytest.mark.asyncio
    async def test_subscribe_returns_subscription_id(self) -> None:
        """subscribe() should return subscription ID."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter(nats_url="nats://localhost:4222")

        mock_sub = Mock()
        mock_js = Mock()
        mock_js.add_stream = AsyncMock()
        mock_js.subscribe = AsyncMock(return_value=mock_sub)

        mock_nc = Mock()
        mock_nc.jetstream = Mock(return_value=mock_js)
        mock_nc.close = AsyncMock()

        with patch("nats.connect", new_callable=AsyncMock, return_value=mock_nc):
            await bus.connect()

            async def handler(event: Event) -> None:
                pass

            sub_id = await bus.subscribe("doc.created", handler)

            assert sub_id is not None
            assert isinstance(sub_id, str)

            await bus.disconnect()

    @pytest.mark.asyncio
    async def test_subscribe_pattern_success(self) -> None:
        """subscribe_pattern() should setup pattern subscription."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter(nats_url="nats://localhost:4222")

        mock_sub = Mock()
        mock_js = Mock()
        mock_js.add_stream = AsyncMock()
        mock_js.subscribe = AsyncMock(return_value=mock_sub)

        mock_nc = Mock()
        mock_nc.jetstream = Mock(return_value=mock_js)
        mock_nc.close = AsyncMock()

        with patch("nats.connect", new_callable=AsyncMock, return_value=mock_nc):
            await bus.connect()

            async def handler(event: Event) -> None:
                pass

            sub_id = await bus.subscribe_pattern("doc.*", handler)

            assert sub_id is not None
            assert sub_id in bus._consumer_tasks
            mock_js.subscribe.assert_called_with("events.doc.*")

            await bus.disconnect()

    @pytest.mark.asyncio
    async def test_unsubscribe_removes_subscription(self) -> None:
        """unsubscribe() should remove subscription."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter(nats_url="nats://localhost:4222")

        mock_sub = Mock()
        mock_sub.unsubscribe = AsyncMock()
        mock_js = Mock()
        mock_js.add_stream = AsyncMock()
        mock_js.subscribe = AsyncMock(return_value=mock_sub)

        mock_nc = Mock()
        mock_nc.jetstream = Mock(return_value=mock_js)
        mock_nc.close = AsyncMock()

        with patch("nats.connect", new_callable=AsyncMock, return_value=mock_nc):
            await bus.connect()

            async def handler(event: Event) -> None:
                pass

            sub_id = await bus.subscribe("doc.created", handler)
            await bus.unsubscribe(sub_id)

            mock_sub.unsubscribe.assert_called_once()


# =============================================================================
# Test: Consume Loop
# =============================================================================


class TestNatsEventBusConsume:
    """Tests for message consumption and error handling."""

    @pytest.mark.asyncio
    async def test_consume_success_and_errors(self) -> None:
        """_consume() should handle valid messages, bad JSON, and handler errors gracefully."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter()

        class MockMessages:
            def __init__(self, msgs: list[Mock]):
                self.msgs = msgs
                self.idx = 0

            def __aiter__(self):
                return self

            async def __anext__(self):
                if self.idx < len(self.msgs):
                    val = self.msgs[self.idx]
                    self.idx += 1
                    return val
                raise StopAsyncIteration

        msg1 = Mock()
        msg1.data = b'{"id":"1","type":"test","source":"test"}'
        msg1.ack = AsyncMock()

        msg2 = Mock()
        msg2.data = b"invalid json"

        msg3 = Mock()
        msg3.data = b'{"id":"3","type":"test","source":"test"}'
        msg3.ack = AsyncMock()

        mock_sub = Mock()
        mock_sub.messages = MockMessages([msg1, msg2, msg3])

        handler_calls = []

        async def handler(e: Event) -> None:
            handler_calls.append(e)
            if e.id == "3":
                raise ValueError("Handler error")

        await bus._consume(mock_sub, handler)

        assert len(handler_calls) == 2
        msg1.ack.assert_called_once()
        # msg3 hit an exception in the handler, so ack should not be called
        msg3.ack.assert_not_called()

    @pytest.mark.asyncio
    async def test_consume_cancelled(self) -> None:
        """_consume() should exit cleanly on asyncio.CancelledError."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter()

        class MockMessages:
            def __aiter__(self):
                return self

            async def __anext__(self):
                raise asyncio.CancelledError()

        mock_sub = Mock()
        mock_sub.messages = MockMessages()

        async def handler(e: Event) -> None:
            pass

        # Should not raise exception
        await bus._consume(mock_sub, handler)


# =============================================================================
# Test: Request (RPC)
# =============================================================================


class TestNatsEventBusRequest:
    """Tests for NatsEventBusAdapter request functionality."""

    @pytest.mark.asyncio
    async def test_request_not_connected_raises(self) -> None:
        """request() should raise RuntimeError if not connected."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter()

        with pytest.raises(RuntimeError, match="Not connected to NATS"):
            await bus.request("rpc.test", {"id": "123"})

    @pytest.mark.asyncio
    async def test_request_success_dict_payload(self) -> None:
        """request() should serialize dict, call NATS request, and return response dict."""
        import json

        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter()
        mock_nc = AsyncMock()
        mock_msg = Mock()
        mock_msg.data = json.dumps({"status": "ok", "name": "Test"}).encode()
        mock_nc.request.return_value = mock_msg
        bus._nc = mock_nc

        response = await bus.request("rpc.test", {"req": "value"})

        mock_nc.request.assert_called_once()
        args, kwargs = mock_nc.request.call_args
        assert args[0] == "rpc.test"
        assert json.loads(args[1].decode()) == {"req": "value"}
        assert response == {"status": "ok", "name": "Test"}

    @pytest.mark.asyncio
    async def test_request_success_pydantic_payload(self) -> None:
        """request() should serialize BaseModel properly."""
        import json

        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )
        from pydantic import BaseModel

        class DummyPayload(BaseModel):
            key: str

        bus = NatsEventBusAdapter()
        mock_nc = AsyncMock()
        mock_msg = Mock()
        mock_msg.data = b'{"status": "ok"}'
        mock_nc.request.return_value = mock_msg
        bus._nc = mock_nc

        response = await bus.request("rpc.test", DummyPayload(key="val"))

        args, _ = mock_nc.request.call_args
        assert json.loads(args[1].decode()) == {"key": "val"}
        assert response == {"status": "ok"}

    @pytest.mark.asyncio
    async def test_request_exception_wraps_in_runtime_error(self) -> None:
        """request() should wrap NATS exceptions in RuntimeError."""
        from framework_m_standard.adapters.events.nats_event_bus import (
            NatsEventBusAdapter,
        )

        bus = NatsEventBusAdapter()
        mock_nc = AsyncMock()
        mock_nc.request.side_effect = Exception("Timeout waiting for response")
        bus._nc = mock_nc

        with pytest.raises(RuntimeError, match="NATS request failed: Timeout waiting"):
            await bus.request("rpc.test", {"id": "123"})
