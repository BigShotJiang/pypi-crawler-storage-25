"""Tests for Authorization Security Hardening (Step 2.3)."""

from typing import ClassVar
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.exceptions import PermissionDeniedError
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_standard.adapters.web.exception_handlers import (
    permission_denied_handler,
)
from litestar import Litestar
from litestar.status_codes import HTTP_200_OK, HTTP_403_FORBIDDEN
from litestar.testing import TestClient

# =============================================================================
# Test DocType
# =============================================================================


class ProtectedDoc(BaseDocType):
    """DocType with RLS and specific permissions."""

    title: str = ""

    class Meta:
        api_resource: ClassVar[bool] = True
        requires_auth: ClassVar[bool] = True
        apply_rls: ClassVar[bool] = True
        permissions: ClassVar[dict[str, list[str]]] = {
            "read": ["User", "Manager"],
            "write": ["Manager"],
            "create": ["User", "Manager"],
            "delete": ["Admin"],
        }


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def app() -> Litestar:
    """Create a test application with meta router for ProtectedDoc."""
    from framework_m_core.registry import MetaRegistry
    from framework_m_standard.adapters.web.meta_router import create_crud_routes

    registry = MetaRegistry.get_instance()
    try:
        registry.get_doctype("ProtectedDoc")
    except KeyError:
        registry.register_doctype(ProtectedDoc)

    router = create_crud_routes(ProtectedDoc)
    return Litestar(
        route_handlers=[router],
        exception_handlers={PermissionDeniedError: permission_denied_handler},
    )


# =============================================================================
# Tests: RBAC Enforcement
# =============================================================================


def test_list_enforces_read_permission(app: Litestar):
    """Verify that list_entities checks for READ permission."""
    # User with 'Guest' role (not in 'read' permissions)
    user = UserContext(id="user-1", email="guest@example.com", roles=["Guest"])

    with (
        TestClient(app=app) as client,
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_from_request",
            return_value=user,
        ),
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_context",
            return_value=(user.id, user.roles, []),
        ),
        patch(
            "framework_m_standard.adapters.web.meta_router.apply_rls_filters",
            return_value=[],
        ),
    ):
        response = client.get("/ProtectedDoc")
        assert response.status_code == HTTP_403_FORBIDDEN


def test_list_allows_authorized_user(app: Litestar):
    """Verify that list_entities allows user with READ permission."""
    user = UserContext(id="user-1", email="user@example.com", roles=["User"])

    mock_repo = MagicMock()
    mock_result = MagicMock()
    mock_result.items = []
    mock_result.total = 0
    mock_repo.list_entities = AsyncMock(return_value=mock_result)
    mock_repo.count = AsyncMock(return_value=0)

    # Inject mock factory into app state
    mock_factory = MagicMock()
    mock_factory.get_repository.return_value = mock_repo
    app.state.repository_factory = mock_factory

    with (
        TestClient(app=app) as client,
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_from_request",
            return_value=user,
        ),
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_context",
            return_value=(user.id, user.roles, []),
        ),
        patch(
            "framework_m_standard.adapters.web.meta_router.apply_rls_filters",
            return_value=[],
        ),
    ):
        response = client.get("/ProtectedDoc")
        assert response.status_code == HTTP_200_OK


# =============================================================================
# Tests: RLS Enforcement (Object-Level)
# =============================================================================


def test_get_enforces_rls_ownership(app: Litestar):
    """Verify that get_entity enforces RLS (cannot read others' docs)."""
    user = UserContext(id="user-1", email="user@example.com", roles=["User"])
    doc_id = uuid4()

    # Mock doc owned by someone else
    other_doc = ProtectedDoc(id=doc_id, owner="user-2", title="Secret")

    mock_repo = MagicMock()
    mock_repo.get = AsyncMock(return_value=other_doc)

    mock_factory = MagicMock()
    mock_factory.get_repository.return_value = mock_repo
    app.state.repository_factory = mock_factory

    with (
        TestClient(app=app) as client,
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_from_request",
            return_value=user,
        ),
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_context",
            return_value=(user.id, user.roles, []),
        ),
    ):
        response = client.get(f"/ProtectedDoc/{doc_id}")
        assert response.status_code == HTTP_403_FORBIDDEN


def test_update_enforces_rls_ownership(app: Litestar):
    """Verify that update_entity enforces RLS (cannot update others' docs)."""
    user = UserContext(id="user-1", email="user@example.com", roles=["Manager"])
    doc_id = uuid4()

    other_doc = ProtectedDoc(id=doc_id, owner="user-2", title="Secret")

    mock_repo = MagicMock()
    mock_repo.get = AsyncMock(return_value=other_doc)

    mock_factory = MagicMock()
    mock_factory.get_repository.return_value = mock_repo
    app.state.repository_factory = mock_factory

    with (
        TestClient(app=app) as client,
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_from_request",
            return_value=user,
        ),
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_context",
            return_value=(user.id, user.roles, []),
        ),
    ):
        response = client.put(f"/ProtectedDoc/{doc_id}", json={"title": "Hacked"})
        assert response.status_code == HTTP_403_FORBIDDEN


def test_delete_enforces_rls_ownership(app: Litestar):
    """Verify that delete_entity enforces RLS (cannot delete others' docs)."""
    from framework_m_core.registry import MetaRegistry
    from framework_m_standard.adapters.web.meta_router import create_crud_routes

    class DeleteableDoc(BaseDocType):
        class Meta:
            api_resource = True
            apply_rls = True
            permissions = {"delete": ["User"], "read": ["User"]}

    try:
        MetaRegistry.get_instance().get_doctype("DeleteableDoc")
    except KeyError:
        MetaRegistry.get_instance().register_doctype(DeleteableDoc)

    router = create_crud_routes(DeleteableDoc)
    app_del = Litestar(
        route_handlers=[router],
        exception_handlers={PermissionDeniedError: permission_denied_handler},
    )

    user = UserContext(id="user-1", email="user@example.com", roles=["User"])
    doc_id = uuid4()
    other_doc = DeleteableDoc(id=doc_id, owner="user-2")

    mock_repo = MagicMock()
    mock_repo.get = AsyncMock(return_value=other_doc)

    mock_factory = MagicMock()
    mock_factory.get_repository.return_value = mock_repo
    app_del.state.repository_factory = mock_factory

    with (
        TestClient(app=app_del) as client,
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_from_request",
            return_value=user,
        ),
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_context",
            return_value=(user.id, user.roles, []),
        ),
    ):
        response = client.delete(f"/DeleteableDoc/{doc_id}")
        assert response.status_code == HTTP_403_FORBIDDEN


def test_admin_bypass_rls(app: Litestar):
    """Verify that Admin role bypasses RLS and can read others' docs."""
    admin = UserContext(id="admin-1", email="admin@b.com", roles=["Admin"])
    doc_id = uuid4()

    other_doc = ProtectedDoc(id=doc_id, owner="user-2", title="Secret")

    mock_repo = MagicMock()
    mock_repo.get = AsyncMock(return_value=other_doc)

    mock_factory = MagicMock()
    mock_factory.get_repository.return_value = mock_repo
    app.state.repository_factory = mock_factory

    with (
        TestClient(app=app) as client,
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_from_request",
            return_value=admin,
        ),
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_context",
            return_value=(admin.id, admin.roles, []),
        ),
    ):
        response = client.get(f"/ProtectedDoc/{doc_id}")
        assert response.status_code == HTTP_200_OK


# =============================================================================
# Tests: Logging
# =============================================================================


def test_permission_denial_is_logged(app: Litestar, caplog: pytest.LogCaptureFixture):
    """Verify that permission denials are logged for auditing."""
    user = UserContext(id="evildoer", email="bad@example.com", roles=["Guest"])

    with (
        TestClient(app=app) as client,
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_from_request",
            return_value=user,
        ),
        patch(
            "framework_m_standard.adapters.web.meta_router._get_user_context",
            return_value=(user.id, user.roles, []),
        ),
    ):
        response = client.get("/ProtectedDoc")
        assert response.status_code == HTTP_403_FORBIDDEN

        # Check log
        assert "PERMISSION DENIED" in caplog.text
        assert "User 'evildoer'" in caplog.text
        assert "ProtectedDoc" in caplog.text
