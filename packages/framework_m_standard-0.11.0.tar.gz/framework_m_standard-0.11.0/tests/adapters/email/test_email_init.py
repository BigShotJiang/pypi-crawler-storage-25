"""Tests for email package initialization."""

import framework_m_standard.adapters.email as email_module
from framework_m_standard.adapters.email import (
    DatabaseEmailQueueAdapter,
    get_email_queue_adapter,
)


def test_get_email_queue_adapter_default() -> None:
    """Should default to DatabaseEmailQueueAdapter if none configured."""
    email_module._email_queue_adapter = None
    adapter = get_email_queue_adapter()
    assert isinstance(adapter, DatabaseEmailQueueAdapter)
