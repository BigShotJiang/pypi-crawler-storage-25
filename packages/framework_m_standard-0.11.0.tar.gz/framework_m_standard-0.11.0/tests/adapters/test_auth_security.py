"""Tests for Authentication Security Hardening (Step 2.2)."""

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_core.interfaces.identity import Token
from litestar import Litestar
from litestar.status_codes import (
    HTTP_200_OK,
    HTTP_401_UNAUTHORIZED,
    HTTP_429_TOO_MANY_REQUESTS,
)
from litestar.testing import TestClient


@pytest.fixture
def app() -> Litestar:
    """Create a test application with auth routes."""
    # Force dev mode to false for testing entropy check and secure cookies
    with patch.dict(
        os.environ,
        {
            "M_DEV_MODE": "false",
            "FRAMEWORK_M_JWT_SECRET": "a-very-long-and-secure-secret-key-12345",
        },
    ):
        from framework_m_standard.adapters.web.app import create_app

        return create_app(serve_static=False)


def test_login_rate_limiting(app: Litestar):
    """Verify that login endpoint is rate limited."""
    with (
        TestClient(app=app) as client,
        patch(
            "framework_m_standard.adapters.web.auth_routes._user_manager"
        ) as mock_manager,
    ):
        from framework_m_core.exceptions import AuthenticationError

        mock_manager.authenticate.side_effect = AuthenticationError("Invalid login")

        # 1. First 5 requests should get 401 Unauthorized (not rate limited)
        for _ in range(5):
            response = client.post(
                "/api/v1/auth/login",
                json={"email": "test@example.com", "password": "wrong"},
            )
            assert response.status_code == HTTP_401_UNAUTHORIZED

        # 2. 6th request should be rate limited (429 Too Many Requests)
        response = client.post(
            "/api/v1/auth/login",
            json={"email": "test@example.com", "password": "wrong"},
        )
        assert response.status_code == HTTP_429_TOO_MANY_REQUESTS


def test_login_secure_cookies(app: Litestar):
    """Verify that login response includes secure, httponly cookies."""
    with (
        TestClient(app=app) as client,
        patch(
            "framework_m_standard.adapters.web.auth_routes._user_manager"
        ) as mock_manager,
        patch(
            "framework_m_standard.adapters.web.auth_routes._session_store"
        ) as mock_store,
    ):
        # Mock successful authentication
        mock_user = MagicMock()
        mock_user.id = "user-1"
        mock_user.email = "test@example.com"
        mock_user.name = "Test User"
        mock_user.roles = ["User"]

        mock_manager.authenticate = AsyncMock(
            return_value=Token(access_token="fake-jwt", token_type="Bearer")
        )
        mock_manager.get_by_email = AsyncMock(return_value=mock_user)

        # Mock session creation
        mock_session = MagicMock()
        mock_session.session_id = "sess_12345"
        mock_store.create = AsyncMock(return_value=mock_session)

        response = client.post(
            "/api/v1/auth/login",
            json={"email": "test@example.com", "password": "right"},
        )
        assert response.status_code == HTTP_200_OK

        # Check cookies
        cookies = response.cookies
        assert "session_id" in cookies

        # In Litestar/TestClient, we can't easily inspect all flags on the cookie object directly from the response.cookies dict
        # But we can check the 'Set-Cookie' header
        set_cookie = response.headers.get("set-cookie", "").lower()
        assert "httponly" in set_cookie
        assert "secure" in set_cookie
        assert "samesite=lax" in set_cookie


def test_jwt_claims_hardening():
    """Verify that LocalIdentityAdapter generates tokens with nbf and jti."""
    import jwt
    from framework_m_standard.adapters.auth.local_identity import LocalIdentityAdapter

    secret = "a-very-long-and-secure-secret-key-12345"
    adapter = LocalIdentityAdapter(user_repository=MagicMock(), jwt_secret=secret)

    mock_user = MagicMock()
    mock_user.id = "user-1"
    mock_user.email = "test@example.com"
    mock_user.roles = ["User"]

    token = adapter._generate_token(mock_user)
    payload = jwt.decode(token.access_token, secret, algorithms=["HS256"])

    assert "nbf" in payload
    assert "jti" in payload
    assert len(payload["jti"]) > 10
