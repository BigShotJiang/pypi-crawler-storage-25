"""Tests for Webhook Listener."""

from unittest.mock import AsyncMock, Mock

import pytest
from framework_m_core.events import DocCreated

# =============================================================================
# Test: WebhookListener Import
# =============================================================================


class TestWebhookListenerImport:
    """Tests for WebhookListener import."""

    def test_import_webhook_listener(self) -> None:
        """WebhookListener should be importable."""
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        assert WebhookListener is not None

    def test_webhook_listener_instantiation(self) -> None:
        """WebhookListener should be instantiable."""
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        mock_event_bus = Mock()
        listener = WebhookListener(event_bus=mock_event_bus)
        assert listener is not None


# =============================================================================
# Test: WebhookListener Start/Stop
# =============================================================================


class TestWebhookListenerLifecycle:
    """Tests for WebhookListener lifecycle."""

    @pytest.mark.asyncio
    async def test_start_subscribes_to_events(self) -> None:
        """start() should subscribe to doc events."""
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        mock_event_bus = AsyncMock()
        mock_event_bus.subscribe_pattern = AsyncMock(return_value="sub-123")

        listener = WebhookListener(event_bus=mock_event_bus)
        await listener.start()

        mock_event_bus.subscribe_pattern.assert_called()

    @pytest.mark.asyncio
    async def test_stop_unsubscribes(self) -> None:
        """stop() should unsubscribe from events."""
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        mock_event_bus = AsyncMock()
        mock_event_bus.subscribe_pattern = AsyncMock(return_value="sub-123")
        mock_event_bus.unsubscribe = AsyncMock()

        listener = WebhookListener(event_bus=mock_event_bus)
        await listener.start()
        await listener.stop()

        mock_event_bus.unsubscribe.assert_called_with("sub-123")

    @pytest.mark.asyncio
    async def test_stop_without_start(self) -> None:
        """stop() should do nothing if there is no subscription."""
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        mock_event_bus = AsyncMock()
        listener = WebhookListener(event_bus=mock_event_bus)
        await listener.stop()
        mock_event_bus.unsubscribe.assert_not_called()


# =============================================================================
# Test: Event Handling
# =============================================================================


class TestWebhookEventHandling:
    """Tests for WebhookListener event handling."""

    @pytest.mark.asyncio
    async def test_handle_event_matches_webhooks(self) -> None:
        """handle_event should match event to webhooks."""
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        mock_event_bus = AsyncMock()
        mock_webhook_loader = AsyncMock()
        mock_webhook_loader.load_active_webhooks = AsyncMock(return_value=[])

        listener = WebhookListener(
            event_bus=mock_event_bus,
            webhook_loader=mock_webhook_loader,
        )

        event = DocCreated(doctype="Invoice", doc_name="INV-001")
        await listener.handle_event(event)

        mock_webhook_loader.load_active_webhooks.assert_called_once()

    @pytest.mark.asyncio
    async def test_handle_event_filters_by_event_type(self) -> None:
        """handle_event should filter webhooks by event type."""
        from framework_m_core.doctypes.webhook import Webhook
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        mock_event_bus = AsyncMock()

        # Webhook for doc.created events only
        webhook = Webhook(
            name="test_hook",
            event="doc.created",
            url="https://example.com/webhook",
        )

        mock_webhook_loader = AsyncMock()
        mock_webhook_loader.load_active_webhooks = AsyncMock(return_value=[webhook])

        mock_deliverer = AsyncMock()

        listener = WebhookListener(
            event_bus=mock_event_bus,
            webhook_loader=mock_webhook_loader,
            deliverer=mock_deliverer,
        )

        event = DocCreated(doctype="Invoice", doc_name="INV-001")
        await listener.handle_event(event)

        # Should trigger delivery
        mock_deliverer.deliver.assert_called_once()

    @pytest.mark.asyncio
    async def test_handle_event_filters_by_doctype(self) -> None:
        """handle_event should filter webhooks by doctype_filter."""
        from framework_m_core.doctypes.webhook import Webhook
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        mock_event_bus = AsyncMock()

        # Webhook for Invoice only
        webhook = Webhook(
            name="invoice_hook",
            event="doc.created",
            url="https://example.com/webhook",
            doctype_filter="Invoice",
        )

        mock_webhook_loader = AsyncMock()
        mock_webhook_loader.load_active_webhooks = AsyncMock(return_value=[webhook])

        mock_deliverer = AsyncMock()

        listener = WebhookListener(
            event_bus=mock_event_bus,
            webhook_loader=mock_webhook_loader,
            deliverer=mock_deliverer,
        )

        # Event for Order - should NOT trigger
        event = DocCreated(doctype="Order", doc_name="ORD-001")
        await listener.handle_event(event)

        mock_deliverer.deliver.assert_not_called()

    @pytest.mark.asyncio
    async def test_handle_event_matches_doctype_filter(self) -> None:
        """handle_event should match when doctype matches filter."""
        from framework_m_core.doctypes.webhook import Webhook
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        mock_event_bus = AsyncMock()

        webhook = Webhook(
            name="invoice_hook",
            event="doc.created",
            url="https://example.com/webhook",
            doctype_filter="Invoice",
        )

        mock_webhook_loader = AsyncMock()
        mock_webhook_loader.load_active_webhooks = AsyncMock(return_value=[webhook])

        mock_deliverer = AsyncMock()

        listener = WebhookListener(
            event_bus=mock_event_bus,
            webhook_loader=mock_webhook_loader,
            deliverer=mock_deliverer,
        )

        # Event for Invoice - should trigger
        event = DocCreated(doctype="Invoice", doc_name="INV-001")
        await listener.handle_event(event)

        mock_deliverer.deliver.assert_called_once()

    @pytest.mark.asyncio
    async def test_handle_event_exception_caught(self) -> None:
        """handle_event should catch and log exceptions during delivery."""
        from framework_m_core.doctypes.webhook import Webhook
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        mock_event_bus = AsyncMock()
        webhook = Webhook(name="test", event="doc.created", url="http://t")
        mock_webhook_loader = AsyncMock()
        mock_webhook_loader.load_active_webhooks = AsyncMock(return_value=[webhook])

        mock_deliverer = AsyncMock()
        mock_deliverer.deliver.side_effect = Exception("Delivery failed")

        listener = WebhookListener(
            event_bus=mock_event_bus,
            webhook_loader=mock_webhook_loader,
            deliverer=mock_deliverer,
        )

        event = DocCreated(doctype="Invoice", doc_name="INV-001")
        # Should not raise exception
        await listener.handle_event(event)
        mock_deliverer.deliver.assert_called()

    @pytest.mark.asyncio
    async def test_handle_event_with_job_queue(self) -> None:
        """handle_event should enqueue job if use_job_queue is True."""
        from framework_m_core.doctypes.webhook import Webhook
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        mock_event_bus = AsyncMock()
        webhook = Webhook(name="test", event="doc.created", url="http://t")
        mock_webhook_loader = AsyncMock()
        mock_webhook_loader.load_active_webhooks = AsyncMock(return_value=[webhook])

        mock_job_queue = AsyncMock()

        listener = WebhookListener(
            event_bus=mock_event_bus,
            webhook_loader=mock_webhook_loader,
            job_queue=mock_job_queue,
            use_job_queue=True,
        )

        event = DocCreated(doctype="Invoice", doc_name="INV-001")
        await listener.handle_event(event)

        mock_job_queue.enqueue.assert_called_once()
        assert mock_job_queue.enqueue.call_args[0][0] == "fire_webhook"

    @pytest.mark.asyncio
    async def test_queue_webhook_job_fallback(self) -> None:
        """_queue_webhook_job should fallback to direct delivery if queue is None."""
        from framework_m_core.doctypes.webhook import Webhook
        from framework_m_standard.adapters.webhooks.listener import WebhookListener

        mock_event_bus = AsyncMock()
        webhook = Webhook(name="test", event="doc.created", url="http://t")
        mock_webhook_loader = AsyncMock()
        mock_webhook_loader.load_active_webhooks = AsyncMock(return_value=[webhook])

        mock_deliverer = AsyncMock()

        # use_job_queue = True but job_queue is None
        listener = WebhookListener(
            event_bus=mock_event_bus,
            webhook_loader=mock_webhook_loader,
            deliverer=mock_deliverer,
            use_job_queue=True,
        )

        event = DocCreated(doctype="Invoice", doc_name="INV-001")
        await listener.handle_event(event)

        # Should fallback to direct delivery
        mock_deliverer.deliver.assert_called_once()


# =============================================================================
# Test: Default Components
# =============================================================================


class TestDefaultWebhookComponents:
    """Tests for the default loader and deliverer."""

    @pytest.mark.asyncio
    async def test_in_memory_loader(self) -> None:
        from framework_m_core.doctypes.webhook import Webhook
        from framework_m_standard.adapters.webhooks.listener import (
            InMemoryWebhookLoader,
        )

        loader = InMemoryWebhookLoader()
        w1 = Webhook(name="w1", event="test", url="http://t", enabled=True)
        w2 = Webhook(name="w2", event="test", url="http://t", enabled=False)

        loader.add_webhook(w1)
        loader.add_webhook(w2)

        active = await loader.load_active_webhooks()
        assert len(active) == 1
        assert active[0].name == "w1"

    @pytest.mark.asyncio
    async def test_logging_deliverer(self) -> None:
        from framework_m_core.doctypes.webhook import Webhook
        from framework_m_core.events import DocCreated
        from framework_m_standard.adapters.webhooks.listener import (
            LoggingWebhookDeliverer,
        )

        deliverer = LoggingWebhookDeliverer()
        webhook = Webhook(name="w1", event="doc.created", url="http://t")
        event = DocCreated(doctype="Test", doc_name="1")

        # Should not raise any exceptions
        await deliverer.deliver(webhook, event)
