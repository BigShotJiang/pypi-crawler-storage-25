from __future__ import annotations

from unittest.mock import MagicMock

from framework_m_standard.adapters.db.connection import ConnectionFactory
from framework_m_standard.adapters.db.repository_factory import RepositoryFactory
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from framework_m_standard.adapters.db.session import SessionFactory
from framework_m_standard.adapters.db.table_registry import TableRegistry


def test_db_adapters_smoke():
    # ConnectionFactory
    cf = ConnectionFactory()
    assert cf is not None

    # SessionFactory
    sf = SessionFactory()
    assert sf is not None

    # RepositoryFactory
    metadata = MagicMock()
    rf = RepositoryFactory(metadata, sf)
    assert rf is not None

    # SchemaMapper
    sm = SchemaMapper()
    assert sm is not None

    # TableRegistry
    tr = TableRegistry()
    assert tr is not None
