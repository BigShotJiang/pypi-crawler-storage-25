"""Tests for adapters package."""
