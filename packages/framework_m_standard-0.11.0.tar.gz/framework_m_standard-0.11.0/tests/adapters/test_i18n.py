from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from framework_m_standard.adapters.i18n import DefaultI18nAdapter, InMemoryI18nAdapter


@pytest.mark.asyncio
async def test_in_memory_i18n_adapter():
    adapter = InMemoryI18nAdapter(default_locale="en")
    adapter.add_translation("es", "Hello", "Hola")
    adapter.add_translation("es", "Hello {name}", "Hola {name}")

    # Basic translation
    assert await adapter.translate("Hello", locale="es") == "Hola"
    # Interpolation
    assert (
        await adapter.translate("Hello {name}", locale="es", context={"name": "World"})
        == "Hola World"
    )
    # Default fallback
    assert await adapter.translate("Unknown", locale="es") == "Unknown"
    assert (
        await adapter.translate("Unknown", locale="es", default="Missing") == "Missing"
    )
    # Current locale
    await adapter.set_locale("es")
    assert await adapter.get_locale() == "es"
    assert await adapter.translate("Hello") == "Hola"
    # Available locales
    assert "es" in await adapter.get_available_locales()
    assert "en" in await adapter.get_available_locales()

    # Test set_locale with new locale
    await adapter.set_locale("de")
    assert "de" in await adapter.get_available_locales()

    # Test target locale not in translations (fallback to default)
    res = await adapter.translate("Missing", locale="fr")
    assert res == "Missing"

    # Context substitution where key is not present in translation string
    adapter.add_translation("es", "Plain", "Plano")
    res = await adapter.translate("Plain", locale="es", context={"ignored": "val"})
    assert res == "Plano"

    # Test adding translation when locale is in available but not translations dict
    # This hits the 'if locale not in self._available_locales:' branch in add_translation
    adapter._translations.pop(
        "de", None
    )  # remove from translations to trigger the branch
    adapter.add_translation("de", "Yes", "Ja")
    assert await adapter.translate("Yes", locale="de") == "Ja"

    # Test translation fallback to default parameter
    res_default = await adapter.translate(
        "UnknownText", locale="fr", default="FallbackValue"
    )
    assert res_default == "FallbackValue"


@pytest.mark.asyncio
async def test_default_i18n_adapter():
    mock_repo = MagicMock()
    mock_tenant_repo = MagicMock()
    adapter = DefaultI18nAdapter(
        translation_repo=mock_repo,
        tenant_translation_repo=mock_tenant_repo,
        default_locale="en",
    )

    session = AsyncMock()

    # Mock system translations
    mock_item = MagicMock()
    mock_item.source_text = "Hello"
    mock_item.context = None
    mock_item.translated_text = "Hola"

    mock_item_ctx = MagicMock()
    mock_item_ctx.source_text = "Hello"
    mock_item_ctx.context = "formal"
    mock_item_ctx.translated_text = "Buenos días"

    mock_repo.list = AsyncMock(return_value=MagicMock(items=[mock_item, mock_item_ctx]))

    # Mock tenant translations
    mock_tenant_item = MagicMock()
    mock_tenant_item.source_text = "Hello"
    mock_tenant_item.context = None
    mock_tenant_item.translated_text = "Hola Amigo"
    mock_tenant_repo.list = AsyncMock(return_value=MagicMock(items=[mock_tenant_item]))

    # Test fallback to base locale if context missing
    res = await adapter.translate(
        "Hello", locale="es", session=session, translation_context="unknown"
    )
    assert res == "Hola"  # Falls back to no-context translation

    # Test system-wide translation (no tenant)
    res = await adapter.translate("Hello", locale="es", session=session, tenant_id=None)
    assert res == "Hola"

    # Test cache hit (should not call repo)
    mock_repo.list.reset_mock()
    res = await adapter.translate("Hello", locale="es", session=session)
    assert res == "Hola"
    mock_repo.list.assert_not_called()

    # Test interpolation without context
    assert (
        await adapter.translate("Hello {name}", locale="es", session=session)
        == "Hello {name}"
    )

    # Test available locales (from cache keys)
    assert "es" in await adapter.get_available_locales()


class FakeTranslation:
    def __init__(self, source_text: str, context: str | None, translated_text: str):
        self.source_text = source_text
        self.context = context
        self.translated_text = translated_text


class FakeRepo:
    def __init__(self, items: list[FakeTranslation]):
        self._items = items
        self.call_count = 0

    async def list(self, session: Any, filters: Any, limit: int) -> Any:
        self.call_count += 1

        class Result:
            items = self._items

        return Result()


@pytest.mark.asyncio
async def test_default_i18n_adapter_comprehensive_coverage():
    """Comprehensive test to cover all branches in DefaultI18nAdapter."""

    sys_repo = FakeRepo(
        [
            FakeTranslation("Welcome", None, "Bienvenue"),
            FakeTranslation("Welcome", "formal", "Bienvenue Monsieur"),
            FakeTranslation("FallbackOnly", "ctx", "Fallback System Ctx"),
            FakeTranslation("FallbackOnly", None, "Fallback System"),
        ]
    )

    tenant_repo = FakeRepo(
        [
            FakeTranslation("Welcome", None, "Bienvenue au locataire"),
            FakeTranslation("Welcome", "formal", "Salutations"),
        ]
    )

    adapter = DefaultI18nAdapter(
        translation_repo=sys_repo,
        tenant_translation_repo=tenant_repo,
        default_locale="en",
    )
    session = AsyncMock()

    # 1. Tenant + Context hit
    res1 = await adapter.translate(
        "Welcome",
        locale="fr",
        session=session,
        tenant_id="t1",
        translation_context="formal",
    )
    assert res1 == "Salutations"

    # 2. Tenant + No Context match (fallback to None context in tenant)
    res_casual = await adapter.translate(
        "Welcome",
        locale="fr",
        session=session,
        tenant_id="t1",
        translation_context="casual",
    )
    assert res_casual == "Bienvenue au locataire"

    # 3. Tenant + Explicitly No Context
    res2 = await adapter.translate(
        "Welcome", locale="fr", session=session, tenant_id="t1"
    )
    assert res2 == "Bienvenue au locataire"

    # 4. Cache hit for tenant (ensures early return in _load_tenant_locale)
    initial_calls = tenant_repo.call_count
    res_cache = await adapter.translate(
        "Welcome", locale="fr", session=session, tenant_id="t1"
    )
    assert res_cache == "Bienvenue au locataire"
    assert tenant_repo.call_count == initial_calls

    # 5. System cache fallback with context
    res_sys_ctx = await adapter.translate(
        "FallbackOnly",
        locale="fr",
        session=session,
        tenant_id="t1",
        translation_context="ctx",
    )
    assert res_sys_ctx == "Fallback System Ctx"

    # 6. System cache fallback without matching context (fallback to None)
    res_sys_none = await adapter.translate(
        "FallbackOnly",
        locale="fr",
        session=session,
        tenant_id="t1",
        translation_context="unknown",
    )
    assert res_sys_none == "Fallback System"

    # 7. Fallback to default_locale (when target_locale not in cache for the string)
    # Here, "en" is default. We request "es" but it's not in DB, so it should fallback to "en"
    # We'll set the sys_repo to return English fallbacks
    sys_repo._items = [
        FakeTranslation("MissingES", "ctx", "Found in EN ctx"),
        FakeTranslation("MissingES", None, "Found in EN"),
    ]
    res_def_ctx = await adapter.translate(
        "MissingES", locale="es", session=session, translation_context="ctx"
    )
    assert res_def_ctx == "Found in EN ctx"

    res_def_none = await adapter.translate(
        "MissingES", locale="es", session=session, translation_context="unknown"
    )
    assert res_def_none == "Found in EN"

    # 8. Context interpolation logic
    res_interp = await adapter.translate(
        "Hello {name}", locale="fr", session=session, context={"name": "Alice"}
    )
    assert res_interp == "Hello Alice"

    # 9. Test set_locale and get_locale and get_available_locales
    await adapter.set_locale("de")
    assert await adapter.get_locale() == "de"

    locales = await adapter.get_available_locales()
    assert "fr" in locales


@pytest.mark.asyncio
async def test_default_i18n_adapter_no_tenant_repo():
    """Test behavior when tenant_repo is not provided."""
    mock_repo = MagicMock()
    mock_repo.list = AsyncMock(return_value=MagicMock(items=[]))
    adapter = DefaultI18nAdapter(translation_repo=mock_repo)

    session = AsyncMock()

    # Should not break if tenant_id is provided but no tenant repo exists
    res = await adapter.translate("Hi", locale="es", session=session, tenant_id="t1")
    assert res == "Hi"

    # Check set_locale
    await adapter.set_locale("es")
    assert await adapter.get_locale() == "es"
    locales = await adapter.get_available_locales()
    assert "es" in locales
