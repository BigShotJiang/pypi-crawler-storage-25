"""Tests for the Navigation Policy Engine adapter.

Validates that the policy engine correctly prunes the navigation manifest
based on SaaS Feature Entitlements and User Role Visibility Policies.
"""

import pytest
from framework_m_core.domain.navigation import (
    NavigationManifest,
    NavigationNode,
    VisibilityPolicy,
)
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.feature_entitlement import FeatureEntitlementProtocol
from framework_m_standard.adapters.navigation.policy_engine import (
    NavigationPolicyEngine,
)


class MockEntitlement(FeatureEntitlementProtocol):
    """Mock entitlement adapter for testing feature toggles."""

    def __init__(self, allowed_features: set[str]):
        self.allowed_features = allowed_features

    async def is_feature_enabled(self, tenant_id: str, feature_id: str) -> bool:
        return feature_id in self.allowed_features


@pytest.fixture
def mock_manifest() -> NavigationManifest:
    return NavigationManifest(
        app_id="test_app",
        label="Test App",
        icon="box",
        resources=[
            NavigationNode(name="public", label="Public", route="/public"),
            NavigationNode(
                name="admin_only",
                label="Admin",
                route="/admin",
                visibility_policy=VisibilityPolicy(roles=["Admin"]),
            ),
            NavigationNode(
                name="premium_feature",
                label="Premium",
                route="/premium",
                feature_id="premium_pack",
            ),
            NavigationNode(
                name="parent",
                label="Parent",
                route="/parent",
                children=[
                    NavigationNode(
                        name="nested_premium",
                        label="Nested Premium",
                        route="/parent/premium",
                        feature_id="premium_pack",
                    )
                ],
            ),
        ],
    )


@pytest.mark.asyncio
async def test_policy_engine_filters_by_role(mock_manifest: NavigationManifest) -> None:
    """It should prune nodes where the user lacks the required role."""
    user = UserContext(
        id="u1",
        email="test@test.com",
        roles=["StandardUser"],
        tenants=["t1"],
        attributes={},
    )
    entitlements = MockEntitlement(allowed_features={"premium_pack"})
    engine = NavigationPolicyEngine(entitlement_protocol=entitlements)

    resolved = await engine.resolve_navigation([mock_manifest], user)
    resources = resolved[0].resources
    node_names = [n.name for n in resources]

    assert "admin_only" not in node_names
    assert "public" in node_names


@pytest.mark.asyncio
async def test_policy_engine_filters_by_entitlement(
    mock_manifest: NavigationManifest,
) -> None:
    """It should completely prune nodes that the tenant is not entitled to (e.g. Bronze vs Gold plan)."""
    user = UserContext(
        id="u1", email="admin@test.com", roles=["Admin"], tenants=["t1"], attributes={}
    )
    entitlements = MockEntitlement(
        allowed_features=set()
    )  # Tenant has no premium features
    engine = NavigationPolicyEngine(entitlement_protocol=entitlements)

    resolved = await engine.resolve_navigation([mock_manifest], user)
    resources = resolved[0].resources

    # Top-level feature node pruned
    node_names = [n.name for n in resources]
    assert "premium_feature" not in node_names

    # Nested feature node pruned
    parent_node = next(n for n in resources if n.name == "parent")
    assert len(parent_node.children) == 0
