"""Tests for Input Validation and Sanitization (Step 2.1)."""

from unittest.mock import MagicMock, patch

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.web.meta_router import (
    _parse_filters,
    _sanitize_data,
    create_crud_routes,
)
from litestar import Request
from litestar.exceptions import ValidationException


class ValidatedDoc(BaseDocType):
    title: str = Field(description="Title")
    secret_internal: str | None = None

    class Meta:
        api_resource = True


@pytest.fixture(autouse=True)
def setup_registry():
    registry = MetaRegistry.get_instance()
    if "ValidatedDoc" not in registry.list_doctypes():
        registry.register_doctype(ValidatedDoc)


def test_sanitize_data():
    """Verify that _sanitize_data escapes HTML."""
    data = {
        "title": "<script>alert('xss')</script>",
        "nested": ["<b>bold</b>", 123],
        "safe": "Hello World",
    }
    sanitized = _sanitize_data(data)
    # html.escape by default escapes single quotes to &#x27;
    assert sanitized["title"] == "&lt;script&gt;alert(&#x27;xss&#x27;)&lt;/script&gt;"
    assert sanitized["nested"][0] == "&lt;b&gt;bold&lt;/b&gt;"
    assert sanitized["nested"][1] == 123
    assert sanitized["safe"] == "Hello World"


def test_parse_filters_validation():
    """Verify that _parse_filters validates fields."""
    # Valid field
    filters = '[{"field": "title", "operator": "eq", "value": "test"}]'
    specs = _parse_filters(filters, ValidatedDoc)
    assert len(specs) == 1
    assert specs[0].field == "title"

    # Invalid field
    filters_invalid = '[{"field": "non_existent", "operator": "eq", "value": "test"}]'
    with pytest.raises(
        ValidationException, match="Invalid fields in Filter: non_existent"
    ):
        _parse_filters(filters_invalid, ValidatedDoc)


@pytest.mark.asyncio
async def test_list_entities_validation():
    """Verify that list_entities validates sort and field selection."""
    router = create_crud_routes(ValidatedDoc)

    # Exhaustively find list_entities handler (GET)
    list_handler = None
    for route in router.routes:
        for handler in route.route_handlers:
            if "GET" in getattr(handler, "http_methods", []):
                list_handler = handler
                break
        if list_handler:
            break

    assert list_handler is not None

    mock_request = MagicMock(spec=Request)
    mock_request.state = MagicMock()
    mock_request.app.state.repository_factory = None  # Prevent DB calls

    # 1. Invalid order_by
    with (
        patch(
            "framework_m_standard.adapters.web.meta_router.RbacPermissionAdapter.evaluate"
        ) as mock_eval,
        pytest.raises(ValidationException, match="Invalid fields in Order by: boom"),
    ):
        mock_eval.return_value = MagicMock(authorized=True)
        await list_handler.fn(request=mock_request, order_by="title, -boom")

    # 2. Invalid fields selection
    with (
        patch(
            "framework_m_standard.adapters.web.meta_router.RbacPermissionAdapter.evaluate"
        ) as mock_eval,
        pytest.raises(
            ValidationException, match="Invalid fields in Fields selection: hidden"
        ),
    ):
        mock_eval.return_value = MagicMock(authorized=True)
        await list_handler.fn(request=mock_request, fields="title,hidden")


@pytest.mark.asyncio
async def test_create_sanitization():
    """Verify that create_entity sanitizes data."""
    router = create_crud_routes(ValidatedDoc)

    # Exhaustively find create_entity handler (POST)
    create_handler = None
    for route in router.routes:
        for handler in route.route_handlers:
            if "POST" in getattr(handler, "http_methods", []):
                create_handler = handler
                break
        if create_handler:
            break

    assert create_handler is not None

    mock_request = MagicMock(spec=Request)
    mock_request.state = MagicMock()
    mock_request.state.user = MagicMock(id="user-1")
    mock_request.app.state.repository_factory = None

    data = {"title": "<b>XSS</b>"}

    # Since repository_factory is None, it returns a mock response
    with patch("framework_m_standard.adapters.web.meta_router._check_permission"):
        result = await create_handler.fn(request=mock_request, data=data)
        assert result["title"] == "&lt;b&gt;XSS&lt;/b&gt;"
