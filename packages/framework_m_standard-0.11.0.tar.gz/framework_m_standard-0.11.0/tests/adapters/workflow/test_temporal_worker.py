"""Tests for Temporal Worker Adapter."""

import asyncio
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_core.interfaces.worker import (
    ActivityRegistry,
    WorkerProtocol,
    worker_activity,
)
from framework_m_standard.adapters.workflow.temporal_worker import TemporalWorkerAdapter


def test_temporal_worker_implements_protocol() -> None:
    """Ensure the Temporal worker conforms to WorkerProtocol."""
    adapter = TemporalWorkerAdapter()
    assert isinstance(adapter, WorkerProtocol)


@pytest.mark.asyncio
async def test_temporal_worker_lifecycle() -> None:
    """Test that the worker starts, registers activities, and stops cleanly."""
    # 1. Register a mock activity
    ActivityRegistry.get_instance().clear()

    @worker_activity(name="send_welcome_email")
    async def mock_activity(email: str) -> bool:
        return True

    # 2. Mock the temporalio SDK so we don't need a real server
    mock_temporalio = MagicMock()
    mock_client_cls = MagicMock()
    mock_client_cls.connect = AsyncMock()
    mock_worker_cls = MagicMock()
    mock_worker_instance = MagicMock()

    async def blocking_run(*args: Any, **kwargs: Any) -> None:
        # Simulate a long-running worker loop until cancelled
        await asyncio.sleep(3600)

    mock_worker_instance.run = AsyncMock(side_effect=blocking_run)
    mock_worker_cls.return_value = mock_worker_instance

    mock_temporalio.client.Client = mock_client_cls
    mock_temporalio.worker.Worker = mock_worker_cls

    with patch.dict(
        "sys.modules",
        {
            "temporalio": mock_temporalio,
            "temporalio.client": mock_temporalio.client,
            "temporalio.worker": mock_temporalio.worker,
        },
    ):
        adapter = TemporalWorkerAdapter(host="localhost:7233", task_queue="test-queue")

        # 3. Start the worker
        await adapter.start()

        # Yield to event loop to allow background task to run
        await asyncio.sleep(0)

        mock_client_cls.connect.assert_called_once_with(
            "localhost:7233",
            namespace="default",
            tls=False,
            rpc_metadata={},
        )
        mock_worker_cls.assert_called_once()
        mock_worker_instance.run.assert_called_once()

        # 4. Stop the worker
        await adapter.stop()
        assert adapter._worker_task is None or adapter._worker_task.cancelled()


@pytest.mark.asyncio
async def test_temporal_worker_import_error() -> None:
    """Temporal worker should raise ImportError if SDK is not installed."""
    adapter = TemporalWorkerAdapter()
    with (
        patch.dict(
            "sys.modules", {"temporalio.client": None, "temporalio.worker": None}
        ),
        pytest.raises(ImportError, match="Temporal SDK not installed"),
    ):
        await adapter.start()


@pytest.mark.asyncio
async def test_temporal_worker_with_mtls_and_api_key() -> None:
    """Test worker correctly configures TLS and API key."""
    ActivityRegistry.get_instance().clear()

    mock_temporalio = MagicMock()
    mock_client_cls = MagicMock()
    mock_client_cls.connect = AsyncMock()
    mock_worker_cls = MagicMock()
    mock_worker_instance = MagicMock()
    mock_worker_instance.run = AsyncMock()
    mock_worker_cls.return_value = mock_worker_instance

    mock_temporalio.client.Client = mock_client_cls
    mock_temporalio.worker.Worker = mock_worker_cls
    mock_temporalio.client.TLSConfig = MagicMock()

    with (
        patch.dict(
            "sys.modules",
            {
                "temporalio": mock_temporalio,
                "temporalio.client": mock_temporalio.client,
                "temporalio.worker": mock_temporalio.worker,
            },
        ),
        patch.dict(
            "os.environ",
            {
                "TEMPORAL_API_KEY": "test-key",
                "TEMPORAL_CLIENT_CERT": "-----BEGIN CERTIFICATE-----",
                "TEMPORAL_CLIENT_KEY": "-----BEGIN PRIVATE KEY-----",
            },
        ),
    ):
        adapter = TemporalWorkerAdapter(host="localhost:7233", task_queue="test-queue")
        await adapter.start()

        # Ensure TLSConfig was instantiated
        mock_temporalio.client.TLSConfig.assert_called_once()

        # Verify connect was called with TLS and RPC metadata
        connect_kwargs = mock_client_cls.connect.call_args.kwargs
        assert connect_kwargs["tls"] is not False
        assert connect_kwargs["rpc_metadata"] == {"Authorization": "Bearer test-key"}

        await adapter.stop()


@pytest.mark.asyncio
async def test_temporal_worker_stop_without_start() -> None:
    """Stopping a worker that hasn't started should be a no-op."""
    adapter = TemporalWorkerAdapter()
    await adapter.stop()
    assert adapter._worker_task is None
