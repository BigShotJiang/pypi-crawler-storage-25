from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_standard.adapters.workflow.temporal_adapter import (
    TemporalWorkflowAdapter,
)


@pytest.mark.asyncio
async def test_temporal_adapter_tls_connection():
    """Test connect() logic with TLS enabled and disabled."""
    # Localize sys.modules patching to avoid global side-effects
    with patch.dict(
        "sys.modules", {"temporalio": MagicMock(), "temporalio.client": MagicMock()}
    ):
        # Test TLS branch
        with patch.dict(
            "os.environ",
            {
                "TEMPORAL_HOST": "localhost:7233",
                "TEMPORAL_CLIENT_CERT": "-----BEGIN CERT",
                "TEMPORAL_CLIENT_KEY": "-----BEGIN KEY",
            },
        ):
            adapter_tls = TemporalWorkflowAdapter()
            with patch(
                "temporalio.client.Client.connect", new_callable=AsyncMock
            ) as mock_connect:
                await adapter_tls.connect()
                assert mock_connect.called

        # Test no TLS branch
        adapter_no_tls = TemporalWorkflowAdapter(host="localhost:7233")
        with patch(
            "temporalio.client.Client.connect", new_callable=AsyncMock
        ) as mock_connect:
            await adapter_no_tls.connect()
            assert mock_connect.called


@pytest.mark.asyncio
async def test_temporal_adapter_disconnected_safety():
    """Test that operations raise ConnectionError when not connected."""
    adapter = TemporalWorkflowAdapter(host="localhost:7233")

    # Mocking UserContext
    mock_user = MagicMock()
    mock_user.id = "user1"

    # All these should hit the 'if not self.is_connected()' branch
    with pytest.raises(ConnectionError, match="Not connected to Temporal"):
        await adapter.start_workflow("wf_doc", "id1", "wf_name", mock_user)

    with pytest.raises(ConnectionError, match="Not connected to Temporal"):
        await adapter.get_workflow_state("wf_doc", "id1")

    # mock transition request
    mock_req = MagicMock()
    with pytest.raises(ConnectionError, match="Not connected to Temporal"):
        await adapter.transition(mock_req)

    with pytest.raises(ConnectionError, match="Not connected to Temporal"):
        await adapter.get_available_actions("wf_doc", "id1", mock_user)


@pytest.mark.asyncio
async def test_temporal_adapter_connection_error_handling():
    """Test that connection errors are propagated correctly."""
    adapter = TemporalWorkflowAdapter(host="localhost:7233")

    # Localize sys.modules patching
    with (
        patch.dict(
            "sys.modules", {"temporalio": MagicMock(), "temporalio.client": MagicMock()}
        ),
        patch(
            "temporalio.client.Client.connect",
            side_effect=Exception("Connection Failed"),
        ),
        pytest.raises(ConnectionError, match="Connection Failed"),
    ):
        await adapter.connect()
