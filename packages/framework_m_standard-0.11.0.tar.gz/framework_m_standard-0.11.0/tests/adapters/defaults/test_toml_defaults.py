"""Tests for TomlDefaultsAdapter."""

from pathlib import Path

import pytest
from framework_m_standard.adapters.defaults.toml_defaults import TomlDefaultsAdapter


@pytest.fixture
def toml_file(tmp_path: Path) -> Path:
    """Create a temporary TOML file with nested test data."""
    file_path = tmp_path / "defaults.toml"
    file_path.write_text(
        'app_name = "Framework M"\n[theme]\nprimary_color = "blue"\ndark_mode = true'
    )
    return file_path


@pytest.mark.asyncio
async def test_get_existing_key(toml_file: Path) -> None:
    """It should retrieve a top-level key."""
    adapter = TomlDefaultsAdapter(file_path=toml_file)
    assert await adapter.get("app_name") == "Framework M"


@pytest.mark.asyncio
async def test_get_nested_key(toml_file: Path) -> None:
    """It should retrieve nested keys using dot notation."""
    adapter = TomlDefaultsAdapter(file_path=toml_file)
    assert await adapter.get("theme.primary_color") == "blue"
    assert await adapter.get("theme.dark_mode") is True


@pytest.mark.asyncio
async def test_get_missing_key_returns_default(toml_file: Path) -> None:
    """It should return the fallback value if the key does not exist."""
    adapter = TomlDefaultsAdapter(file_path=toml_file)
    assert await adapter.get("missing_key", "fallback") == "fallback"
    assert await adapter.get("theme.missing", "fallback") == "fallback"


@pytest.mark.asyncio
async def test_missing_file_handles_gracefully() -> None:
    """It should return defaults/empty dict if the file does not exist."""
    adapter = TomlDefaultsAdapter(file_path="nonexistent.toml")
    assert await adapter.get("anything", "default") == "default"
    assert await adapter.get_all() == {}
