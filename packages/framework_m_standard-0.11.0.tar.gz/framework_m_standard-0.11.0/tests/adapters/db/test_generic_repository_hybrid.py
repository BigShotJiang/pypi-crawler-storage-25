"""Tests for GenericRepository Hybrid JSON Overflow (Phase 4.2)."""

from typing import Any
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.interfaces.repository import FilterOperator, FilterSpec
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from sqlalchemy import MetaData, select
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine


class HybridUser(BaseDocType):
    name_field: str = Field(description="Standard column")
    regional_tax_id: str | None = Field(
        default=None, json_schema_extra={"persistence": "json"}
    )


@pytest.fixture
async def hybrid_setup() -> tuple[Any, Any, Any, GenericRepository[HybridUser]]:
    """Fixture to set up an in-memory DB with hybrid schema."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False)
    metadata = MetaData()
    mapper = SchemaMapper()
    table = mapper.create_table(HybridUser, metadata)

    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)

    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    repo = GenericRepository(HybridUser, table)

    return engine, session_factory, table, repo


@pytest.mark.asyncio
async def test_save_packs_and_get_unpacks(
    hybrid_setup: tuple[Any, Any, Any, GenericRepository[HybridUser]],
) -> None:
    """Repository should transparently pack/unpack JSON persistence fields."""
    engine, session_factory, table, repo = hybrid_setup

    doc_id = uuid4()
    user = HybridUser(id=doc_id, name_field="Alice", regional_tax_id="GST123")

    async with session_factory() as session:
        await repo.save(session, user)

        # Check raw DB row to ensure it went to custom_fields
        result = await session.execute(select(table).where(table.c.id == doc_id))
        row = result.first()
        assert "regional_tax_id" not in row._mapping
        assert row._mapping["custom_fields"] == {"regional_tax_id": "GST123"}

        # Check repo.get unpacks it transparently into the Pydantic model
        fetched = await repo.get(session, doc_id)
        assert fetched.name_field == "Alice"
        assert fetched.regional_tax_id == "GST123"


@pytest.mark.asyncio
async def test_list_filters_by_json_path(
    hybrid_setup: tuple[Any, Any, Any, GenericRepository[HybridUser]],
) -> None:
    """Repository should convert JSON-persisted field filters into SQLAlchemy JSON paths."""
    engine, session_factory, table, repo = hybrid_setup

    async with session_factory() as session:
        await repo.save(
            session, HybridUser(name_field="Alice", regional_tax_id="GST123")
        )
        await repo.save(session, HybridUser(name_field="Bob", regional_tax_id="VAT456"))

        filters = [
            FilterSpec(
                field="regional_tax_id", operator=FilterOperator.EQ, value="VAT456"
            )
        ]
        result = await repo.list_entities(session, filters=filters)

        assert result.total == 1
        assert result.items[0].name_field == "Bob"
