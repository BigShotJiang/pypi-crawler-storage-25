"""Tests for DocumentNamingService.

TDD tests for extracting Name Generation logic out of the GenericRepository.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import ClassVar
from unittest.mock import AsyncMock, MagicMock

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_standard.adapters.db.naming import DocumentNamingService
from sqlalchemy import Column, MetaData, String, Table

# =============================================================================
# Test Models
# =============================================================================


class DefaultDoc(BaseDocType):
    """Test DocType with no naming pattern."""

    title: str = Field(default="Test")


class PatternDoc(BaseDocType):
    """Test DocType with complex naming pattern."""

    category: str = Field(default="DEV")

    class Meta:
        name_pattern: ClassVar[str] = "DOC-.YYYY.MM.-.{category}.-.####"


class SequenceDoc(BaseDocType):
    """Test DocType with sequence pattern."""

    title: str = Field(default="Test")

    class Meta:
        name_pattern: ClassVar[str] = "sequence:test_sequence"


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def metadata() -> MetaData:
    return MetaData()


@pytest.fixture
def test_table(metadata: MetaData) -> Table:
    return Table(
        "test_table",
        metadata,
        Column("id", String, primary_key=True),
        Column("name", String, unique=True),
    )


@pytest.fixture
def mock_session() -> AsyncMock:
    return AsyncMock()


# =============================================================================
# Tests
# =============================================================================


class TestDocumentNamingService:
    """Tests for DocumentNamingService."""

    @pytest.mark.asyncio
    async def test_generate_default_uuid_name(
        self, test_table: Table, mock_session: AsyncMock
    ) -> None:
        """Should generate UUID-based name when no pattern is defined."""
        service = DocumentNamingService(model=DefaultDoc, table=test_table)
        doc = DefaultDoc()

        name = await service.generate_name(mock_session, doc)

        assert name.startswith("DEFA-")
        assert len(name) > 5

    @pytest.mark.asyncio
    async def test_generate_pattern_name(
        self, test_table: Table, mock_session: AsyncMock
    ) -> None:
        """Should format date, fields, and counter correctly."""
        service = DocumentNamingService(model=PatternDoc, table=test_table)
        doc = PatternDoc(category="OPS")

        # Mock counter query to return nothing (meaning next is 1)
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_session.execute.return_value = mock_result

        name = await service.generate_name(mock_session, doc)

        now = datetime.now(UTC)
        expected_prefix = f"DOC-{now.year}{now.month:02d}-OPS-"

        assert name == f"{expected_prefix}0001"

    @pytest.mark.asyncio
    async def test_get_next_counter_existing_records(
        self, test_table: Table, mock_session: AsyncMock
    ) -> None:
        """Should increment counter based on existing names."""
        service = DocumentNamingService(model=PatternDoc, table=test_table)
        doc = PatternDoc(category="OPS")

        now = datetime.now(UTC)
        prefix = f"DOC-{now.year}{now.month:02d}-OPS-"

        # Mock counter query to return an existing record with counter 42
        mock_result = MagicMock()
        mock_result.fetchall.return_value = [(f"{prefix}0042",)]
        mock_session.execute.return_value = mock_result

        name = await service.generate_name(mock_session, doc)

        assert name == f"{prefix}0043"

    @pytest.mark.asyncio
    async def test_generate_sequence_postgres(
        self, test_table: Table, mock_session: AsyncMock
    ) -> None:
        """Should use nextval for postgres sequences."""
        service = DocumentNamingService(model=SequenceDoc, table=test_table)
        doc = SequenceDoc()

        # Mock postgres sequence response
        mock_result = MagicMock()
        mock_result.scalar.return_value = 123
        mock_session.execute.return_value = mock_result

        name = await service.generate_name(mock_session, doc)

        assert name == "SEQU-00000123"

    @pytest.mark.asyncio
    async def test_generate_sequence_fallback(
        self, test_table: Table, mock_session: AsyncMock
    ) -> None:
        """Should fallback to prefix counter if nextval fails (e.g. SQLite)."""
        service = DocumentNamingService(model=SequenceDoc, table=test_table)
        doc = SequenceDoc()

        # First query (nextval) fails, second query (counter) returns nothing
        def mock_execute_side_effect(stmt):
            mock_res = MagicMock()
            if "nextval" in str(stmt):
                raise Exception("Not PostgreSQL")
            mock_res.fetchall.return_value = []
            return mock_res

        mock_session.execute.side_effect = mock_execute_side_effect

        name = await service.generate_name(mock_session, doc)

        assert name == "SEQU-00000001"
