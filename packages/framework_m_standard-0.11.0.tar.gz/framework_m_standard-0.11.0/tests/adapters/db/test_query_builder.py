"""Tests for QueryBuilder."""

from __future__ import annotations

import logging

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.interfaces.repository import (
    FilterOperator,
    FilterSpec,
    OrderDirection,
    OrderSpec,
)
from framework_m_standard.adapters.db.query_builder import QueryBuilder
from pydantic import Field
from sqlalchemy import Column, Integer, MetaData, String, Table, select
from sqlalchemy.types import JSON


class DummyModel(BaseDocType):
    name: str = Field(default="")
    age: int = Field(default=0)
    config: dict = Field(
        default_factory=dict, json_schema_extra={"persistence": "json"}
    )


metadata = MetaData()
dummy_table = Table(
    "dummy",
    metadata,
    Column("name", String),
    Column("age", Integer),
    Column("custom_fields", JSON),
)


@pytest.mark.parametrize(
    "operator",
    [
        FilterOperator.EQ,
        FilterOperator.NE,
        FilterOperator.LT,
        FilterOperator.LTE,
        FilterOperator.GT,
        FilterOperator.GTE,
        FilterOperator.IN,
        FilterOperator.NOT_IN,
        FilterOperator.LIKE,
    ],
)
def test_apply_filters_operators(operator: FilterOperator) -> None:
    stmt = select(dummy_table)
    val = ["test"] if operator in (FilterOperator.IN, FilterOperator.NOT_IN) else "test"
    filters = [FilterSpec(field="name", operator=operator, value=val)]
    stmt = QueryBuilder.apply_filters(stmt, DummyModel, dummy_table, filters)
    compiled = str(stmt.compile())
    assert "dummy.name" in compiled


def test_apply_filters_is_null() -> None:
    stmt = select(dummy_table)
    filters = [FilterSpec(field="name", operator=FilterOperator.IS_NULL, value=True)]
    stmt = QueryBuilder.apply_filters(stmt, DummyModel, dummy_table, filters)
    compiled = str(stmt.compile())
    assert "IS NULL" in compiled


def test_apply_filters_is_not_null() -> None:
    stmt = select(dummy_table)
    filters = [FilterSpec(field="name", operator=FilterOperator.IS_NULL, value=False)]
    stmt = QueryBuilder.apply_filters(stmt, DummyModel, dummy_table, filters)
    compiled = str(stmt.compile())
    assert "IS NOT NULL" in compiled


def test_apply_filters_json_field() -> None:
    stmt = select(dummy_table)
    filters = [FilterSpec(field="config", operator=FilterOperator.EQ, value="val")]
    stmt = QueryBuilder.apply_filters(stmt, DummyModel, dummy_table, filters)
    compiled = str(stmt.compile())
    assert "custom_fields" in compiled


def test_apply_filters_json_field_list() -> None:
    stmt = select(dummy_table)
    filters = [
        FilterSpec(field="config", operator=FilterOperator.IN, value=["v1", "v2"])
    ]
    stmt = QueryBuilder.apply_filters(stmt, DummyModel, dummy_table, filters)
    compiled = str(stmt.compile())
    assert "custom_fields" in compiled


def test_apply_filters_unknown_field() -> None:
    stmt = select(dummy_table)
    filters = [FilterSpec(field="unknown", operator=FilterOperator.EQ, value="val")]
    result = QueryBuilder.apply_filters(stmt, DummyModel, dummy_table, filters)
    assert str(result.compile()) == str(stmt.compile())


def test_apply_ordering_desc() -> None:
    stmt = select(dummy_table)
    order = [OrderSpec(field="name", direction=OrderDirection.DESC)]
    stmt = QueryBuilder.apply_ordering(stmt, DummyModel, dummy_table, order)
    compiled = str(stmt.compile())
    assert "ORDER BY dummy.name DESC" in compiled


def test_apply_ordering_unknown_field(caplog: pytest.LogCaptureFixture) -> None:
    # Re-enable logger in case a previous test's logging config disabled it
    qb_logger = logging.getLogger("framework_m_standard.adapters.db.query_builder")
    qb_logger.disabled = False
    caplog.set_level(
        logging.WARNING, logger="framework_m_standard.adapters.db.query_builder"
    )

    stmt = select(dummy_table)
    order = [OrderSpec(field="unknown", direction=OrderDirection.ASC)]
    result = QueryBuilder.apply_ordering(stmt, DummyModel, dummy_table, order)
    assert str(result.compile()) == str(stmt.compile())
    assert "Invalid sort field 'unknown' for model DummyModel" in caplog.text
