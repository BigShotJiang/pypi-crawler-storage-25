"""Tests for SchemaMapper versioning extensions (RFC-0008 Step 3.1)."""

from __future__ import annotations

from framework_m import DocType
from framework_m_core.domain.mixins import VersionedMixin
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from sqlalchemy import Integer, MetaData


class AuditedInvoice(DocType, VersionedMixin):
    """Versioned DocType used for history-table provisioning tests."""

    customer_name: str
    amount: float


class PlainInvoice(DocType):
    """Non-versioned DocType used for gate checks."""

    customer_name: str


class TestSchemaMapperVersioning:
    """Tests for create_versioned_tables and history DDL generation."""

    def setup_method(self) -> None:
        self.mapper = SchemaMapper()
        self.metadata = MetaData()

    def test_create_versioned_tables_returns_main_and_history_when_enabled(
        self,
    ) -> None:
        config = {"compliance": {"versioning_enabled": True}}

        tables = self.mapper.create_versioned_tables(
            AuditedInvoice,
            self.metadata,
            config,
        )

        assert len(tables) == 2
        assert tables[0].name == "auditedinvoice"
        assert tables[1].name == "auditedinvoice_history"

    def test_history_table_has_main_columns_plus_version_columns(self) -> None:
        config = {"compliance": {"versioning_enabled": True}}

        tables = self.mapper.create_versioned_tables(
            AuditedInvoice, self.metadata, config
        )
        main_table = tables[0]
        history_table = tables[1]

        for column in main_table.columns:
            assert column.name in history_table.columns

        assert "_version_no" in history_table.columns
        assert isinstance(history_table.columns["_version_no"].type, Integer)
        assert history_table.columns["_version_no"].nullable is False
        assert "_valid_from" in history_table.columns
        assert "_valid_to" in history_table.columns

    def test_history_table_name_column_is_not_unique(self) -> None:
        config = {"compliance": {"versioning_enabled": True}}

        tables = self.mapper.create_versioned_tables(
            AuditedInvoice, self.metadata, config
        )
        history_table = tables[1]

        assert history_table.columns["name"].unique is not True

    def test_history_table_has_valid_from_index(self) -> None:
        config = {"compliance": {"versioning_enabled": True}}

        tables = self.mapper.create_versioned_tables(
            AuditedInvoice, self.metadata, config
        )
        history_table = tables[1]
        index_names = [idx.name for idx in history_table.indexes]

        assert f"ix_{history_table.name}_valid_from" in index_names

    def test_returns_only_main_table_when_versioning_disabled(self) -> None:
        config = {"compliance": {"versioning_enabled": False}}

        tables = self.mapper.create_versioned_tables(
            AuditedInvoice, self.metadata, config
        )

        assert len(tables) == 1
        assert tables[0].name == "auditedinvoice"

    def test_returns_only_main_table_for_non_versioned_doctype(self) -> None:
        config = {"compliance": {"versioning_enabled": True}}

        tables = self.mapper.create_versioned_tables(
            PlainInvoice, self.metadata, config
        )

        assert len(tables) == 1
        assert tables[0].name == "plaininvoice"

    def test_create_table_remains_unchanged_without_history(self) -> None:
        table = self.mapper.create_table(AuditedInvoice, self.metadata)

        assert table.name == "auditedinvoice"
        assert "auditedinvoice_history" not in self.metadata.tables

    def test_create_history_alteration_ddl_generates_add_column_statements(
        self,
    ) -> None:
        added_columns = {
            "compliance_note": {"sa_type": "TEXT", "nullable": True},
            "risk_score": {"sa_type": "INTEGER", "nullable": False},
        }

        ddls = self.mapper.create_history_alteration_ddl(
            "auditedinvoice_history",
            added_columns,
        )
        ddl_texts = [getattr(ddl, "text", str(ddl)) for ddl in ddls]

        assert len(ddls) == 2
        assert any(
            "ALTER TABLE auditedinvoice_history ADD COLUMN compliance_note TEXT"
            in ddl_text
            for ddl_text in ddl_texts
        )
        assert any(
            "ALTER TABLE auditedinvoice_history ADD COLUMN risk_score INTEGER NOT NULL"
            in ddl_text
            for ddl_text in ddl_texts
        )

    def test_history_table_info_contains_audit_db_url_when_configured(self) -> None:
        config = {
            "compliance": {
                "versioning_enabled": True,
                "audit_db_url": "postgresql://audit-db/framework_m_audit",
            }
        }

        tables = self.mapper.create_versioned_tables(
            AuditedInvoice, self.metadata, config
        )
        history_table = tables[1]

        assert (
            history_table.info.get("audit_db_url")
            == config["compliance"]["audit_db_url"]
        )
