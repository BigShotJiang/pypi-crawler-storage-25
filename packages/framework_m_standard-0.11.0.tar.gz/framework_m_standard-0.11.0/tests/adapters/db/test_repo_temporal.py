"""Tests for temporal query support in GenericRepository (RFC-0008 Step 5.2)."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID, uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.domain.mixins import VersionedMixin
from framework_m_core.exceptions import TemporalQueryNotSupportedError
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from sqlalchemy import MetaData
from sqlalchemy import insert as sql_insert
from sqlalchemy.ext.asyncio import AsyncSession


class VersionedItem(BaseDocType, VersionedMixin):
    """Versioned DocType for temporal query tests."""

    title: str = Field(description="Title")


class PlainItem(BaseDocType):
    """Non-versioned DocType for temporal query guard tests."""

    title: str = Field(description="Title")


@pytest.fixture
async def versioned_repo_with_history(
    db_session: AsyncSession,
    clean_tables: MetaData,
) -> tuple[GenericRepository[VersionedItem], Any, Any]:
    """Create versioned main + history tables and repository."""
    mapper = SchemaMapper()
    tables = mapper.create_versioned_tables(
        VersionedItem,
        clean_tables,
        {"compliance": {"versioning_enabled": True}},
    )
    main_table, history_table = tables[0], tables[1]

    conn = await db_session.connection()
    await conn.run_sync(clean_tables.create_all)

    return GenericRepository(VersionedItem, main_table), main_table, history_table


@pytest.fixture
async def versioned_repo_main_only(
    db_session: AsyncSession,
    clean_tables: MetaData,
) -> tuple[GenericRepository[VersionedItem], Any]:
    """Create only the main table for a versioned DocType."""
    mapper = SchemaMapper()
    main_table = mapper.create_table(VersionedItem, clean_tables)

    conn = await db_session.connection()
    await conn.run_sync(clean_tables.create_all)

    return GenericRepository(VersionedItem, main_table), main_table


@pytest.fixture
async def plain_repo(
    db_session: AsyncSession,
    clean_tables: MetaData,
) -> GenericRepository[PlainItem]:
    """Create repository for non-versioned DocType."""
    mapper = SchemaMapper()
    main_table = mapper.create_table(PlainItem, clean_tables)

    conn = await db_session.connection()
    await conn.run_sync(clean_tables.create_all)

    return GenericRepository(PlainItem, main_table)


async def _insert_history_version(
    session: AsyncSession,
    history_table: Any,
    *,
    doc_id: UUID,
    name: str,
    title: str,
    modified: datetime,
    version_no: int,
    valid_from: datetime,
    valid_to: datetime | None,
) -> None:
    """Insert a single historical version row."""
    await session.execute(
        sql_insert(history_table).values(
            id=doc_id,
            name=name,
            creation=modified,
            modified=modified,
            modified_by="tester@example.com",
            owner="tester@example.com",
            deleted_at=None,
            title=title,
            _version_no=version_no,
            _valid_from=valid_from,
            _valid_to=valid_to,
            custom_fields={},
        )
    )


class TestRepositoryTemporalQueries:
    """Temporal as_of behavior for get/list operations."""

    @pytest.mark.asyncio
    async def test_get_returns_historical_state_for_as_of_between_versions(
        self,
        versioned_repo_with_history: tuple[GenericRepository[VersionedItem], Any, Any],
        db_session: AsyncSession,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        repo, _main_table, history_table = versioned_repo_with_history
        doc_id = uuid4()
        name = "ITEM-001"

        t1 = datetime.now(UTC) - timedelta(minutes=3)
        t2 = datetime.now(UTC) - timedelta(minutes=1)

        await _insert_history_version(
            db_session,
            history_table,
            doc_id=doc_id,
            name=name,
            title="first version",
            modified=t1,
            version_no=1,
            valid_from=t1,
            valid_to=t2,
        )
        await _insert_history_version(
            db_session,
            history_table,
            doc_id=doc_id,
            name=name,
            title="second version",
            modified=t2,
            version_no=2,
            valid_from=t2,
            valid_to=None,
        )

        between = t1 + (t2 - t1) / 2

        historical = await repo.get(db_session, doc_id, as_of=between)
        assert historical is not None
        assert historical.title == "first version"

        latest = await repo.get(db_session, doc_id, as_of=datetime.now(UTC))
        assert latest is not None
        assert latest.title == "second version"

    @pytest.mark.asyncio
    async def test_get_returns_none_when_as_of_before_first_version(
        self,
        versioned_repo_with_history: tuple[GenericRepository[VersionedItem], Any, Any],
        db_session: AsyncSession,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        repo, _main_table, history_table = versioned_repo_with_history
        doc_id = uuid4()
        t1 = datetime.now(UTC) - timedelta(minutes=2)

        await _insert_history_version(
            db_session,
            history_table,
            doc_id=doc_id,
            name="ITEM-002",
            title="only version",
            modified=t1,
            version_no=1,
            valid_from=t1,
            valid_to=None,
        )

        result = await repo.get(db_session, doc_id, as_of=t1 - timedelta(seconds=1))
        assert result is None

    @pytest.mark.asyncio
    async def test_list_returns_historical_versions_for_as_of(
        self,
        versioned_repo_with_history: tuple[GenericRepository[VersionedItem], Any, Any],
        db_session: AsyncSession,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        repo, _main_table, history_table = versioned_repo_with_history

        doc1 = uuid4()
        doc2 = uuid4()
        t1 = datetime.now(UTC) - timedelta(minutes=4)
        t2 = datetime.now(UTC) - timedelta(minutes=2)

        await _insert_history_version(
            db_session,
            history_table,
            doc_id=doc1,
            name="ITEM-003",
            title="doc1-v1",
            modified=t1,
            version_no=1,
            valid_from=t1,
            valid_to=t2,
        )
        await _insert_history_version(
            db_session,
            history_table,
            doc_id=doc1,
            name="ITEM-003",
            title="doc1-v2",
            modified=t2,
            version_no=2,
            valid_from=t2,
            valid_to=None,
        )
        await _insert_history_version(
            db_session,
            history_table,
            doc_id=doc2,
            name="ITEM-004",
            title="doc2-v1",
            modified=t1,
            version_no=1,
            valid_from=t1,
            valid_to=None,
        )

        between = t1 + (t2 - t1) / 2
        result = await repo.list_entities(db_session, as_of=between, limit=10, offset=0)

        by_name = {item.name: item.title for item in result.items}
        assert result.total == 2
        assert by_name["ITEM-003"] == "doc1-v1"
        assert by_name["ITEM-004"] == "doc2-v1"

    @pytest.mark.asyncio
    async def test_as_of_none_uses_main_table_without_history(
        self,
        versioned_repo_main_only: tuple[GenericRepository[VersionedItem], Any],
        db_session: AsyncSession,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        repo, _main_table = versioned_repo_main_only
        entity = VersionedItem(title="current")

        await repo.save(db_session, entity)
        result = await repo.list_entities(db_session, as_of=None)

        assert result.total == 1
        assert result.items[0].title == "current"

    @pytest.mark.asyncio
    async def test_as_of_raises_when_versioning_disabled(
        self,
        versioned_repo_with_history: tuple[GenericRepository[VersionedItem], Any, Any],
        db_session: AsyncSession,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "false")

        repo, _main_table, _history_table = versioned_repo_with_history

        with pytest.raises(TemporalQueryNotSupportedError):
            await repo.get(db_session, uuid4(), as_of=datetime.now(UTC))

        with pytest.raises(TemporalQueryNotSupportedError):
            await repo.list_entities(db_session, as_of=datetime.now(UTC))

    @pytest.mark.asyncio
    async def test_as_of_raises_for_non_versioned_doctype(
        self,
        plain_repo: GenericRepository[PlainItem],
        db_session: AsyncSession,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

        with pytest.raises(TemporalQueryNotSupportedError):
            await plain_repo.get(db_session, uuid4(), as_of=datetime.now(UTC))
