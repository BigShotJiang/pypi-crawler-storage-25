"""Tests for ReferenceResolver."""

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_standard.adapters.db.reference_resolver import ReferenceResolver
from pydantic import Field
from sqlalchemy import Column, MetaData, Table
from sqlalchemy.types import UUID as SA_UUID


class MockTarget(BaseDocType):
    name: str = "Target"


class MockSource(BaseDocType):
    target_id: str | None = Field(
        default=None, json_schema_extra={"link": "MockTarget"}
    )
    normal_link: str | None = Field(
        default=None, json_schema_extra={"link": "MockTarget"}
    )
    no_extra: str | None = Field(default=None)
    bad_extra: str | None = Field(default=None, json_schema_extra="string")
    no_link_key: str | None = Field(default=None, json_schema_extra={"foo": "bar"})
    empty_val: str | None = Field(
        default=None, json_schema_extra={"link": "MockTarget"}
    )


@pytest.fixture
def mock_meta_registry():
    with patch("framework_m_core.registry.MetaRegistry.get_instance") as mock:
        instance = MagicMock()
        instance.get_doctype.return_value = MockTarget
        mock.return_value = instance
        yield instance


@pytest.fixture
def mock_table_registry():
    with patch("framework_m_standard.adapters.db.table_registry.TableRegistry") as mock:
        instance = MagicMock()
        metadata = MetaData()
        mock_table = Table(
            "mock_table", metadata, Column("id", SA_UUID, primary_key=True)
        )
        instance.get_table.return_value = mock_table
        mock.return_value = instance
        yield instance


@pytest.mark.asyncio
async def test_resolve_indie_success(mock_meta_registry, mock_table_registry):
    session = AsyncMock()
    mock_row = MagicMock()
    mock_row._mapping = {"id": str(uuid4()), "name": "Target"}
    session.execute.return_value.first.return_value = mock_row

    entity = MockSource(target_id=str(uuid4()), normal_link=str(uuid4()))

    with patch(
        "framework_m_standard.adapters.db.generic_repository.GenericRepository"
    ) as mock_repo:
        mock_repo_instance = MagicMock()
        mock_repo_instance._mapper = MagicMock()
        mock_repo_instance._mapper.row_to_entity.return_value = MockTarget()
        mock_repo.return_value = mock_repo_instance

        await ReferenceResolver.resolve_indie(session, entity, MockSource)

    assert hasattr(entity, "target")
    assert hasattr(entity, "normal_link_doc")


@pytest.mark.asyncio
async def test_resolve_indie_exceptions(mock_meta_registry, mock_table_registry):
    session = AsyncMock()
    entity = MockSource(
        target_id="invalid-uuid"
    )  # Will silently skip due to ValueError

    mock_table_registry.get_table.side_effect = Exception("Not found")
    entity2 = MockSource(target_id=str(uuid4()))

    await ReferenceResolver.resolve_indie(session, entity, MockSource)
    await ReferenceResolver.resolve_indie(session, entity2, MockSource)
    # Should not raise any exceptions


@pytest.mark.asyncio
async def test_resolve_indie_setattr_fallback(mock_meta_registry, mock_table_registry):
    class BlockedSource(MockSource):
        @property
        def target(self):
            return None

    session = AsyncMock()
    mock_row = MagicMock()
    session.execute.return_value.first.return_value = mock_row

    entity = BlockedSource(target_id=str(uuid4()))

    with patch(
        "framework_m_standard.adapters.db.generic_repository.GenericRepository"
    ) as mock_repo:
        mock_repo.return_value._mapper = MagicMock()
        mock_repo.return_value._mapper.row_to_entity.return_value = MockTarget()

        await ReferenceResolver.resolve_indie(session, entity, MockSource)

    assert "target" in entity.__dict__


@pytest.mark.asyncio
async def test_resolve_enterprise_success(mock_meta_registry):
    event_bus = AsyncMock()
    event_bus.request.return_value = {"id": str(uuid4()), "name": "Enterprise Target"}
    entity = MockSource(target_id=str(uuid4()))

    await ReferenceResolver.resolve_enterprise(entity, MockSource, event_bus)
    assert entity.target.name == "Enterprise Target"


@pytest.mark.asyncio
async def test_resolve_enterprise_no_bus():
    entity = MockSource(target_id=str(uuid4()))
    await ReferenceResolver.resolve_enterprise(entity, MockSource, None)
    assert not hasattr(entity, "target")


@pytest.mark.asyncio
async def test_resolve_enterprise_dynamic_fallback(mock_meta_registry):
    event_bus = AsyncMock()
    event_bus.request.return_value = {"id": str(uuid4()), "name": "Dynamic"}
    mock_meta_registry.get_doctype.side_effect = Exception("Not in registry")

    entity = MockSource(target_id=str(uuid4()))
    await ReferenceResolver.resolve_enterprise(entity, MockSource, event_bus)

    # Should trigger the DynamicRecord fallback
    assert entity.target.name == "Dynamic"


@pytest.mark.asyncio
async def test_resolve_enterprise_bad_response():
    event_bus = AsyncMock()
    event_bus.request.return_value = None  # Bad response
    entity = MockSource(target_id=str(uuid4()))
    await ReferenceResolver.resolve_enterprise(entity, MockSource, event_bus)
    assert not hasattr(entity, "target")

    event_bus.request.side_effect = Exception("Network down")
    await ReferenceResolver.resolve_enterprise(
        entity, MockSource, event_bus
    )  # Should not raise
