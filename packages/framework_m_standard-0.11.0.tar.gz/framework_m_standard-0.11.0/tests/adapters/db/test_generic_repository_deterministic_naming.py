"""Tests for GenericRepository deterministic naming orchestration (Phase 4.5)."""

from typing import Any, ClassVar

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.services.document_id import DocumentIdService
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from sqlalchemy import MetaData, func, select
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine


class DeterministicDoc(BaseDocType):
    """DocType using deterministic ID strategy."""

    title: str = Field(description="Title")

    class Meta:
        id_strategy: ClassVar[str] = "deterministic"


class RandomDoc(BaseDocType):
    """DocType using default random ID strategy."""

    title: str = Field(description="Title")

    class Meta:
        id_strategy: ClassVar[str] = "random"


@pytest.fixture
async def deterministic_setup() -> tuple[Any, GenericRepository[DeterministicDoc]]:
    """Fixture to set up database with DeterministicDoc schema."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False)
    metadata = MetaData()
    mapper = SchemaMapper()
    table = mapper.create_table(DeterministicDoc, metadata)

    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)

    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    repo = GenericRepository(DeterministicDoc, table)
    return session_factory, repo


@pytest.fixture
async def random_setup() -> tuple[Any, GenericRepository[RandomDoc]]:
    """Fixture to set up database with RandomDoc schema."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False)
    metadata = MetaData()
    mapper = SchemaMapper()
    table = mapper.create_table(RandomDoc, metadata)

    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)

    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    repo = GenericRepository(RandomDoc, table)
    return session_factory, repo


@pytest.mark.asyncio
async def test_save_generates_deterministic_id(
    deterministic_setup: tuple[Any, GenericRepository[DeterministicDoc]],
) -> None:
    """It should overwrite the random Pydantic UUID with a deterministic UUID5."""
    session_factory, repo = deterministic_setup

    # Instantiate with a standard UUID4 from Pydantic defaults
    doc = DeterministicDoc(title="Test", name="DET-001")
    original_random_id = doc.id

    async with session_factory() as session:
        saved_doc = await repo.save(session, doc)
        await session.commit()

        # The generic repository should have intercepted and overwritten the ID
        assert saved_doc.id != original_random_id

        expected_id = DocumentIdService().generate_deterministic_id(
            "DeterministicDoc", "DET-001"
        )
        assert saved_doc.id == expected_id


@pytest.mark.asyncio
async def test_save_idempotent_with_deterministic_id(
    deterministic_setup: tuple[Any, GenericRepository[DeterministicDoc]],
) -> None:
    """It should update the existing record instead of throwing DuplicateNameError if re-imported."""
    session_factory, repo = deterministic_setup

    async with session_factory() as session:
        # Simulate a CI/CD pipeline running for the first time
        doc1 = DeterministicDoc(title="Version 1", name="DET-IDEM")
        await repo.save(session, doc1)
        await session.commit()

    async with session_factory() as session:
        # Simulate the CI/CD pipeline running again next week
        # We instantiate a new Pydantic object (meaning it gets a new random UUID4!)
        doc2 = DeterministicDoc(title="Version 2", name="DET-IDEM")
        assert doc1.id != doc2.id  # They start off as different UUIDs

        # Because id_strategy="deterministic", GenericRepository will hash the name,
        # realize the ID already exists in the DB, and route this to `_update`!
        await repo.save(session, doc2)
        await session.commit()

        # Prove it didn't insert a second row
        count = await session.scalar(select(func.count()).select_from(repo.table))
        assert count == 1

        # Prove it successfully updated the title using the exact same deterministic ID
        fetched = await repo.get_by_name(session, "DET-IDEM")
        assert fetched is not None
        assert fetched.title == "Version 2"
        assert fetched.id == doc1.id


@pytest.mark.asyncio
async def test_save_keeps_random_id(
    random_setup: tuple[Any, GenericRepository[RandomDoc]],
) -> None:
    """It should leave the Pydantic UUID untouched if strategy is random."""
    session_factory, repo = random_setup

    doc = RandomDoc(title="Test", name="RND-001")
    original_random_id = doc.id

    async with session_factory() as session:
        saved_doc = await repo.save(session, doc)
        await session.commit()

        # ID should remain completely unchanged
        assert saved_doc.id == original_random_id
