"""Tests for HistoryManager."""

from datetime import UTC, datetime
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.exceptions import DatabaseError
from framework_m_core.interfaces.repository import (
    FilterOperator,
    FilterSpec,
    OrderDirection,
    OrderSpec,
)
from framework_m_standard.adapters.db.history_manager import HistoryManager
from sqlalchemy import Column, Integer, MetaData, String, Table


class DummyHistoryDoc(BaseDocType):
    name: str | None = None
    items: list[Any] = []
    _versioning_enabled = True


@pytest.fixture
def mock_repo():
    repo = MagicMock()
    repo.model = DummyHistoryDoc

    metadata = MetaData()
    table = Table(
        "dummy",
        metadata,
        Column("id", String, primary_key=True),
        Column("name", String),
    )
    history_table = Table(
        "dummy_history",
        metadata,
        Column("id", String, primary_key=True),
        Column("modified", String),
        Column("_version_no", Integer),
        Column("_valid_from", String),
        Column("_valid_to", String),
        Column("deleted_at", String),
    )
    history_table.info = {}

    repo.table = table
    repo._row_to_entity.return_value = DummyHistoryDoc(id=uuid4())
    repo._child_table_manager.get_child_table_fields.return_value = {}
    return repo


@pytest.fixture
def manager(mock_repo):
    with patch(
        "framework_m_standard.adapters.db.history_manager.is_versioning_enabled",
        return_value=True,
    ):
        yield HistoryManager(mock_repo)


@pytest.mark.asyncio
async def test_get_history_table_missing():
    repo = MagicMock()
    repo.table = Table(
        "dummy_no_hist", MetaData(), Column("id", String, primary_key=True)
    )
    manager = HistoryManager(repo)
    with pytest.raises(
        DatabaseError, match="History table 'dummy_no_hist_history' not found"
    ):
        manager._get_history_table()


@pytest.mark.asyncio
async def test_get_as_of_with_child_tables(manager):
    session = AsyncMock()
    mock_result = MagicMock()
    mock_result.first.return_value = MagicMock()
    session.execute.return_value = mock_result

    child_fields = {"items": MagicMock()}
    manager._repo._child_table_manager.get_child_table_fields.return_value = (
        child_fields
    )
    manager._repo._child_table_manager.load_child_tables = AsyncMock()

    entity = await manager.get_as_of(session, uuid4(), False, datetime.now(UTC))

    assert entity is not None
    manager._repo._child_table_manager.load_child_tables.assert_called_once()


@pytest.mark.asyncio
async def test_list_entities_as_of_with_filters_and_order_and_children(manager):
    session = AsyncMock()

    mock_count_result = MagicMock()
    mock_count_result.scalar.return_value = 1

    mock_rows_result = MagicMock()
    mock_row = MagicMock()
    mock_row.id = uuid4()
    mock_rows_result.fetchall.return_value = [mock_row]

    session.execute.side_effect = [mock_count_result, mock_rows_result]

    child_fields = {"items": MagicMock(__name__="ChildItem")}
    manager._repo._child_table_manager.get_child_table_fields.return_value = (
        child_fields
    )
    manager._repo._child_table_manager.load_children_for_parents = AsyncMock(
        return_value={}
    )

    with patch(
        "framework_m_standard.adapters.db.table_registry.TableRegistry"
    ) as MockTR:
        mock_tr = MockTR.return_value
        mock_tr.get_table.return_value = MagicMock()

        result = await manager.list_entities_as_of(
            session,
            as_of=datetime.now(UTC),
            filters=[
                FilterSpec(field="name", operator=FilterOperator.EQ, value="test")
            ],
            order_by=[OrderSpec(field="name", direction=OrderDirection.ASC)],
        )

        assert result.total == 1
        assert len(result.items) == 1
        manager._repo._child_table_manager.load_children_for_parents.assert_called_once()


@pytest.mark.asyncio
async def test_write_history_snapshot_on_save_missing_id(manager):
    session = AsyncMock()
    entity = DummyHistoryDoc()

    with (
        patch.object(manager, "_get_persisted_row_data", return_value={"name": "test"}),
        pytest.raises(DatabaseError, match="missing id"),
    ):
        await manager.write_history_snapshot_on_save(session, entity, datetime.now(UTC))


@pytest.mark.asyncio
async def test_get_persisted_row_data_by_name(manager):
    session = AsyncMock()
    entity = DummyHistoryDoc(name="test_name")

    mock_result = MagicMock()
    mock_row = MagicMock()
    mock_row._mapping = {"id": uuid4(), "name": "test_name"}
    mock_result.first.return_value = mock_row
    session.execute.return_value = mock_result

    data = await manager._get_persisted_row_data(session, entity)
    assert data["name"] == "test_name"


@pytest.mark.asyncio
async def test_get_persisted_row_data_not_found(manager):
    session = AsyncMock()
    entity = DummyHistoryDoc(id=uuid4())
    session.execute.return_value = MagicMock(first=MagicMock(return_value=None))

    with pytest.raises(DatabaseError, match="Cannot fetch persisted row"):
        await manager._get_persisted_row_data(session, entity)


@pytest.mark.asyncio
async def test_write_history_snapshot_with_audit_db_url(manager):
    session = AsyncMock()
    mock_bind = MagicMock()
    mock_bind.url = "sqlite:///main.db"
    session.get_bind = MagicMock(return_value=mock_bind)

    history_table = manager._get_history_table()
    history_table.info["audit_db_url"] = "sqlite:///audit.db"

    entity = DummyHistoryDoc(id=uuid4())

    with (
        patch.object(
            manager, "_get_persisted_row_data", return_value={"id": entity.id}
        ),
        patch(
            "framework_m_standard.adapters.db.history_manager.create_async_engine"
        ) as mock_create_engine,
    ):
        mock_engine = MagicMock()
        mock_conn = AsyncMock()
        mock_context = AsyncMock()
        mock_context.__aenter__.return_value = mock_conn
        mock_context.__aexit__.return_value = None
        mock_engine.begin.return_value = mock_context
        mock_engine.dispose = AsyncMock()
        mock_create_engine.return_value = mock_engine

        with patch.object(manager, "_write_history_row") as mock_write:
            await manager.write_history_snapshot_on_save(
                session, entity, datetime.now(UTC)
            )
            mock_create_engine.assert_called_once_with(
                "sqlite:///audit.db", pool_pre_ping=True
            )
            mock_write.assert_called_once()
            mock_engine.dispose.assert_called_once()


@pytest.mark.asyncio
async def test_write_history_row(manager):
    execute = AsyncMock()
    mock_max_version = MagicMock()
    mock_max_version.scalar.return_value = 5
    execute.return_value = mock_max_version

    history_table = manager._get_history_table()
    row_data = {"id": uuid4(), "name": "test"}

    await manager._write_history_row(
        execute, history_table, row_data, row_data["id"], datetime.now(UTC)
    )

    assert execute.call_count == 3
