"""Tests for the SQLAlchemy Introspection Adapter."""

import pytest
import pytest_asyncio
from framework_m_core.interfaces.introspection import TableMeta
from framework_m_standard.adapters.db.introspection import (
    SQLAlchemyIntrospectionAdapter,
)
from sqlalchemy import Boolean, Column, Integer, MetaData, String, Table
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine


@pytest_asyncio.fixture
async def sqlite_engine() -> AsyncEngine:
    """Provide an in-memory SQLite engine populated with test tables."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False)
    metadata = MetaData()

    # Define a test table with various column types and constraints
    Table(
        "test_users",
        metadata,
        Column("id", Integer, primary_key=True),
        Column("username", String(50), nullable=False, unique=True),
        Column("is_active", Boolean, default=True),
    )

    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)

    yield engine

    async with engine.begin() as conn:
        await conn.run_sync(metadata.drop_all)
    await engine.dispose()


@pytest.mark.asyncio
class TestSQLAlchemyIntrospectionAdapter:
    """Test suite for SQLAlchemy-based database schema introspection."""

    async def test_introspect_table_returns_correct_meta(
        self, sqlite_engine: AsyncEngine
    ) -> None:
        """Adapter should correctly introspect a single table's columns and indexes."""
        adapter = SQLAlchemyIntrospectionAdapter(sqlite_engine)

        table_meta = await adapter.introspect_table("test_users")

        assert table_meta is not None
        assert isinstance(table_meta, TableMeta)
        assert table_meta.name == "test_users"
        assert len(table_meta.columns) == 3

        # Verify Primary Key (id)
        id_col = next((c for c in table_meta.columns if c.name == "id"), None)
        assert id_col is not None
        assert id_col.primary_key is True
        assert id_col.type == "INTEGER"

        # Verify constraints and sizes (username)
        username_col = next(
            (c for c in table_meta.columns if c.name == "username"), None
        )
        assert username_col is not None
        assert username_col.nullable is False
        assert username_col.max_length == 50
        assert username_col.type == "VARCHAR"

        # Verify indexes/unique constraints
        assert len(table_meta.indexes) >= 1
        username_idx = next(
            (idx for idx in table_meta.indexes if "username" in idx.columns), None
        )
        assert username_idx is not None
        assert username_idx.unique is True

    async def test_introspect_database_returns_all_tables(
        self, sqlite_engine: AsyncEngine
    ) -> None:
        """Adapter should introspect all tables in the connected database."""
        adapter = SQLAlchemyIntrospectionAdapter(sqlite_engine)
        tables = await adapter.introspect_database()

        assert any(t.name == "test_users" for t in tables)
