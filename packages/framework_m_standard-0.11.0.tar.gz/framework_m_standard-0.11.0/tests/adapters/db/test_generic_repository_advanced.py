"""Advanced tests for GenericRepository.

Covers edge cases, error handling branches, and bulk operations.
"""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.exceptions import (
    DatabaseError,
    DuplicateNameError,
    IntegrityError,
    RepositoryError,
)
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from sqlalchemy import Column, Integer, MetaData, String, Table
from sqlalchemy.exc import IntegrityError as SAIntegrityError
from sqlalchemy.exc import OperationalError, SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession


class AdvancedTodo(BaseDocType):
    """Test DocType for advanced repository tests."""

    title: str = Field(description="Task title")


@pytest.fixture
def advanced_table() -> Table:
    """Create AdvancedTodo table for testing."""
    metadata = MetaData()
    return Table(
        "tab_advanced_todo",
        metadata,
        Column("id", String, primary_key=True),
        Column("name", String, unique=True),
        Column("title", String),
        Column("owner", String),
        Column("modified_by", String),
        Column("deleted_at", String, nullable=True),
        Column("_version", String, nullable=True),
    )


@pytest.fixture
def repo(advanced_table: Table) -> GenericRepository[AdvancedTodo]:
    """Create repository instance."""
    return GenericRepository(model=AdvancedTodo, table=advanced_table)


@pytest.fixture
def mock_session() -> AsyncMock:
    """Create a mock AsyncSession."""
    session = AsyncMock(spec=AsyncSession)
    session.execute = AsyncMock()
    session.flush = AsyncMock()
    return session


class TestBulkOperations:
    """Tests for bulk_save and _bulk_insert."""

    @pytest.mark.asyncio
    async def test_bulk_save_empty(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """bulk_save should return empty list when given empty list."""
        assert await repo.bulk_save(mock_session, []) == []

    @pytest.mark.asyncio
    async def test_bulk_save_mixed_entities(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """bulk_save should separate new and existing entities."""
        new_doc = AdvancedTodo(title="New")
        existing_doc = AdvancedTodo(title="Existing", name="EX-1")

        # Mock _entity_exists: first returns False (new), second returns True (existing)
        with (
            patch.object(repo, "_entity_exists", side_effect=[False, True]),
            patch.object(
                repo, "_bulk_insert", new_callable=AsyncMock
            ) as mock_bulk_insert,
            patch.object(repo, "save", new_callable=AsyncMock) as mock_save,
        ):
            mock_bulk_insert.return_value = [new_doc]
            mock_save.return_value = existing_doc

            result = await repo.bulk_save(mock_session, [new_doc, existing_doc])

            assert len(result) == 2
            mock_bulk_insert.assert_called_once_with(mock_session, [new_doc])
            mock_save.assert_called_once_with(mock_session, existing_doc)

    @pytest.mark.asyncio
    async def test_bulk_save_all_new(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """bulk_save should only call _bulk_insert if all entities are new."""
        doc1 = AdvancedTodo(title="New 1")
        doc2 = AdvancedTodo(title="New 2")
        with (
            patch.object(repo, "_entity_exists", return_value=False),
            patch.object(
                repo, "_bulk_insert", new_callable=AsyncMock
            ) as mock_bulk_insert,
        ):
            mock_bulk_insert.return_value = [doc1, doc2]

            res = await repo.bulk_save(mock_session, [doc1, doc2])
            assert len(res) == 2
            mock_bulk_insert.assert_called_once_with(mock_session, [doc1, doc2])

    @pytest.mark.asyncio
    async def test_bulk_insert_empty(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """_bulk_insert should return empty list when given empty list."""
        assert await repo._bulk_insert(mock_session, []) == []

    @pytest.mark.asyncio
    async def test_bulk_save_success_real_insert(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """bulk_save should execute bulk insert successfully and return entities."""
        doc1 = AdvancedTodo.model_construct(title="New 1", name=None)
        doc2 = AdvancedTodo(title="New 2", name="DOC-2")

        with (
            patch.object(repo, "_entity_exists", return_value=False),
            patch.object(repo._naming_service, "generate_name", return_value="GEN-1"),
        ):
            res = await repo.bulk_save(mock_session, [doc1, doc2])

            assert len(res) == 2
            assert res[0].name == "GEN-1"
            assert res[1].name == "DOC-2"
            mock_session.execute.assert_called_once()


class TestInsertErrorHandling:
    """Tests for exception translation during _insert."""

    @pytest.mark.asyncio
    async def test_insert_integrity_error_other(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate non-unique SAIntegrityError to domain IntegrityError."""
        doc = AdvancedTodo(title="Test")
        mock_session.execute.side_effect = [
            MagicMock(scalar=MagicMock(return_value=False)),  # exists check
            SAIntegrityError(
                "INSERT", {}, Exception("Foreign key violation")
            ),  # insert
        ]
        with pytest.raises(IntegrityError):
            await repo.save(mock_session, doc)

    @pytest.mark.asyncio
    async def test_insert_operational_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate OperationalError to DatabaseError."""
        doc = AdvancedTodo(title="Test")
        mock_session.execute.side_effect = [
            MagicMock(scalar=MagicMock(return_value=False)),
            OperationalError("INSERT", {}, Exception("DB Down")),
        ]
        with pytest.raises(DatabaseError):
            await repo.save(mock_session, doc)

    @pytest.mark.asyncio
    async def test_insert_sqlalchemy_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate generic SQLAlchemyError to RepositoryError."""
        doc = AdvancedTodo(title="Test")
        mock_session.execute.side_effect = [
            MagicMock(scalar=MagicMock(return_value=False)),
            SQLAlchemyError("Unknown DB error"),
        ]
        with pytest.raises(RepositoryError):
            await repo.save(mock_session, doc)


class TestBulkInsertErrorHandling:
    """Tests for exception translation during _bulk_insert."""

    @pytest.mark.asyncio
    async def test_bulk_insert_duplicate_name(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate UNIQUE constraint error to DuplicateNameError."""
        docs = [AdvancedTodo(title="Test 1", name="DOC-1")]
        mock_session.execute.side_effect = SAIntegrityError(
            "INSERT", {}, Exception("UNIQUE constraint failed")
        )
        with pytest.raises(DuplicateNameError):
            await repo._bulk_insert(mock_session, docs)

    @pytest.mark.asyncio
    async def test_bulk_insert_integrity_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate other integrity errors to domain IntegrityError."""
        docs = [AdvancedTodo(title="Test 1", name="DOC-1")]
        mock_session.execute.side_effect = SAIntegrityError(
            "INSERT", {}, Exception("FK violation")
        )
        with pytest.raises(IntegrityError):
            await repo._bulk_insert(mock_session, docs)

    @pytest.mark.asyncio
    async def test_bulk_insert_sqlalchemy_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate generic SQLAlchemyError to RepositoryError."""
        docs = [AdvancedTodo(title="Test 1", name="DOC-1")]
        mock_session.execute.side_effect = SQLAlchemyError("DB error")
        with pytest.raises(RepositoryError):
            await repo._bulk_insert(mock_session, docs)


class TestUpdateErrorHandling:
    """Tests for exception translation during _update."""

    @pytest.mark.asyncio
    async def test_update_duplicate_name(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate UNIQUE constraint error to DuplicateNameError."""
        doc = AdvancedTodo(title="Test", name="DOC-1")
        mock_session.execute.side_effect = [
            MagicMock(scalar=MagicMock(return_value=True)),  # exists check
            SAIntegrityError(
                "UPDATE", {}, Exception("UNIQUE constraint failed")
            ),  # update
        ]
        with pytest.raises(DuplicateNameError):
            await repo.save(mock_session, doc)

    @pytest.mark.asyncio
    async def test_update_integrity_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate other integrity errors to domain IntegrityError."""
        doc = AdvancedTodo(title="Test", name="DOC-1")
        mock_session.execute.side_effect = [
            MagicMock(scalar=MagicMock(return_value=True)),  # exists check
            SAIntegrityError("UPDATE", {}, Exception("FK violation")),  # update
        ]
        with pytest.raises(IntegrityError):
            await repo.save(mock_session, doc)

    @pytest.mark.asyncio
    async def test_update_operational_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate OperationalError to DatabaseError."""
        doc = AdvancedTodo(title="Test", name="DOC-1")
        mock_session.execute.side_effect = [
            MagicMock(scalar=MagicMock(return_value=True)),  # exists check
            OperationalError("UPDATE", {}, Exception("DB Down")),  # update
        ]
        with pytest.raises(DatabaseError):
            await repo.save(mock_session, doc)

    @pytest.mark.asyncio
    async def test_update_sqlalchemy_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate generic SQLAlchemyError to RepositoryError."""
        doc = AdvancedTodo(title="Test", name="DOC-1")
        mock_session.execute.side_effect = [
            MagicMock(scalar=MagicMock(return_value=True)),  # exists check
            SQLAlchemyError("DB error"),  # update
        ]
        with pytest.raises(RepositoryError):
            await repo.save(mock_session, doc)


class TestEmitEventFallbacks:
    """Tests for _emit_event fallback logic and exception swallowing."""

    @pytest.mark.asyncio
    async def test_emit_event_custom_type(
        self, repo: GenericRepository[AdvancedTodo]
    ) -> None:
        """Should emit a generic Event for unrecognized event types."""
        doc = AdvancedTodo(title="Test", name="DOC-1")
        mock_bus = AsyncMock()
        repo._event_publisher._event_bus = mock_bus

        await repo._event_publisher.emit_event("custom_action", doc)

        mock_bus.publish.assert_called_once()
        args, _ = mock_bus.publish.call_args
        topic, event = args
        assert topic == "doc.custom_action"
        assert event.type == "AdvancedTodo.custom_action"

    @pytest.mark.asyncio
    async def test_emit_event_swallows_exception(
        self, repo: GenericRepository[AdvancedTodo]
    ) -> None:
        """Should log warning and not raise if event bus publish fails."""
        doc = AdvancedTodo(title="Test", name="DOC-1")
        mock_bus = AsyncMock()
        mock_bus.publish.side_effect = Exception("Message bus down")
        repo._event_publisher._event_bus = mock_bus

        # Should safely complete without raising
        await repo._event_publisher.emit_event("create", doc)
        mock_bus.publish.assert_called_once()


class TestInsertRetry:
    """Tests for _insert_with_retry logic."""

    @pytest.mark.asyncio
    async def test_insert_with_retry_success_after_failure(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should retry insert when name is auto-generated and DuplicateNameError occurs."""
        doc = AdvancedTodo(title="Test")

        repo._naming_service.generate_name = AsyncMock(return_value="RETRY-NAME")
        repo._insert = AsyncMock(
            side_effect=[DuplicateNameError("AdvancedTodo", "DOC-1"), doc]
        )

        await repo._insert_with_retry(
            mock_session, doc, controller=None, auto_generated_name=True
        )

        assert repo._insert.call_count == 2
        repo._naming_service.generate_name.assert_called_once()
        assert doc.name == "RETRY-NAME"

    @pytest.mark.asyncio
    async def test_insert_with_retry_fails_if_manual_name(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should NOT retry if the name was manually provided."""
        doc = AdvancedTodo(title="Test", name="MANUAL-NAME")

        repo._insert = AsyncMock(
            side_effect=DuplicateNameError("AdvancedTodo", "MANUAL-NAME")
        )
        repo._naming_service.generate_name = AsyncMock()

        with pytest.raises(DuplicateNameError):
            await repo._insert_with_retry(
                mock_session, doc, controller=None, auto_generated_name=False
            )

        assert repo._insert.call_count == 1
        repo._naming_service.generate_name.assert_not_called()

    @pytest.mark.asyncio
    async def test_insert_with_retry_exceeds_max_retries(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should propagate DuplicateNameError if max retries are exceeded."""
        doc = AdvancedTodo(title="Test")

        repo._insert = AsyncMock(
            side_effect=DuplicateNameError("AdvancedTodo", "DOC-X")
        )
        repo._naming_service.generate_name = AsyncMock(return_value="RETRY-NAME")

        with pytest.raises(DuplicateNameError):
            await repo._insert_with_retry(
                mock_session,
                doc,
                controller=None,
                auto_generated_name=True,
                max_retries=2,
            )

        assert repo._insert.call_count == 3  # 1 initial + 2 retries


class TestDeleteErrorHandling:
    """Tests for exception translation during delete."""

    @pytest.mark.asyncio
    async def test_delete_integrity_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate SAIntegrityError to domain IntegrityError."""
        mock_session.execute.side_effect = [
            MagicMock(
                first=MagicMock(
                    return_value=MagicMock(
                        _mapping={"id": str(uuid4()), "title": "test"}
                    )
                )
            ),
            SAIntegrityError("DELETE", {}, Exception("FK violation")),
        ]
        with pytest.raises(IntegrityError):
            await repo.delete(mock_session, uuid4(), hard=True)

    @pytest.mark.asyncio
    async def test_delete_operational_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate OperationalError to DatabaseError."""
        mock_session.execute.side_effect = [
            MagicMock(
                first=MagicMock(
                    return_value=MagicMock(
                        _mapping={"id": str(uuid4()), "title": "test"}
                    )
                )
            ),
            OperationalError("DELETE", {}, Exception("DB Down")),
        ]
        with pytest.raises(DatabaseError):
            await repo.delete(mock_session, uuid4(), hard=True)

    @pytest.mark.asyncio
    async def test_delete_sqlalchemy_error(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should translate generic SQLAlchemyError to RepositoryError."""
        mock_session.execute.side_effect = [
            MagicMock(
                first=MagicMock(
                    return_value=MagicMock(
                        _mapping={"id": str(uuid4()), "title": "test"}
                    )
                )
            ),
            SQLAlchemyError("Unknown DB error"),
        ]
        with pytest.raises(RepositoryError):
            await repo.delete(mock_session, uuid4(), hard=True)


class TestCacheGlobalInvalidation:
    """Tests for global cache invalidation triggers in _cache_manager.invalidate."""

    @pytest.mark.asyncio
    async def test_invalidate_cache_global_triggers(
        self, advanced_table: Table
    ) -> None:
        """Should trigger global pattern deletions for specific models."""

        class CustomPermission(BaseDocType):
            name: str = Field(default="test")

        class Translation(BaseDocType):
            name: str = Field(default="test")

        class LocalUser(BaseDocType):
            name: str = Field(default="test")

        mock_cache = AsyncMock()

        repo_perm = GenericRepository(
            CustomPermission, advanced_table, cache=mock_cache
        )
        await repo_perm._cache_manager.invalidate(CustomPermission(name="test"))
        mock_cache.delete_pattern.assert_called_with("perm:*")

        mock_cache.reset_mock()

        repo_trans = GenericRepository(Translation, advanced_table, cache=mock_cache)
        await repo_trans._cache_manager.invalidate(Translation(name="test"))
        mock_cache.delete_pattern.assert_called_with("meta:*")

        mock_cache.reset_mock()

        repo_user = GenericRepository(LocalUser, advanced_table, cache=mock_cache)
        doc = LocalUser(name="test")
        doc.id = uuid4()
        await repo_user._cache_manager.invalidate(doc)
        mock_cache.delete_pattern.assert_called_with(f"perm:{doc.id}:*")


class TestSubmittableUpdate:
    """Tests for docstatus transitions and hooks."""

    @pytest.mark.asyncio
    async def test_update_docstatus_triggers_hooks(
        self, mock_session: AsyncMock
    ) -> None:
        from framework_m_core.domain.base_controller import BaseController
        from framework_m_core.domain.mixins import DocStatus

        class SubDoc(BaseDocType):
            title: str
            docstatus: DocStatus = DocStatus.DRAFT

        class SubController(BaseController[SubDoc]):
            def __init__(self, doc):
                super().__init__(doc)
                self.submit_called = False
                self.cancel_called = False

            async def on_submit(self, context=None):
                self.submit_called = True

            async def on_cancel(self, context=None):
                self.cancel_called = True

            async def _validate_submitted_changes(self, new_doc, old_doc):
                pass

        metadata = MetaData()
        table = Table(
            "sub_doc",
            metadata,
            Column("id", String, primary_key=True),
            Column("name", String),
            Column("title", String),
            Column("docstatus", String),
        )
        repo = GenericRepository(SubDoc, table, controller_class=SubController)

        doc_id = uuid4()
        old_doc = SubDoc(
            id=doc_id, title="Test", docstatus=DocStatus.DRAFT, name="TEST-1"
        )
        new_doc = SubDoc(
            id=doc_id, title="Test", docstatus=DocStatus.SUBMITTED, name="TEST-1"
        )

        mock_row = MagicMock()
        mock_row._mapping = {
            "id": str(doc_id),
            "name": "TEST-1",
            "title": "Test",
            "docstatus": 0,
        }
        mock_result = MagicMock()
        mock_result.first.return_value = mock_row
        mock_session.execute.return_value = mock_result

        controller = SubController(new_doc)
        await repo._update(mock_session, new_doc, controller)
        assert controller.submit_called is True

        # Test Cancel transition
        old_doc.docstatus = DocStatus.SUBMITTED
        mock_row._mapping["docstatus"] = 1
        cancel_doc = SubDoc(
            id=doc_id, title="Test", docstatus=DocStatus.CANCELLED, name="TEST-1"
        )

        cancel_controller = SubController(cancel_doc)
        await repo._update(mock_session, cancel_doc, cancel_controller)
        assert cancel_controller.cancel_called is True


class TestTemporalQueries:
    """Tests for as_of parameter routing."""

    @pytest.mark.asyncio
    async def test_get_as_of_routes_to_history_manager(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """get() with as_of should route directly to _history_manager."""
        repo._history_manager.get_as_of = AsyncMock(return_value="historical_doc")
        dt = datetime.now(UTC)

        result = await repo.get(mock_session, uuid4(), as_of=dt)
        assert result == "historical_doc"
        repo._history_manager.get_as_of.assert_called_once()

    @pytest.mark.asyncio
    async def test_list_entities_as_of_routes_to_history_manager(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """list_entities() with as_of should route directly to _history_manager."""
        repo._history_manager.list_entities_as_of = AsyncMock(
            return_value="historical_list"
        )
        dt = datetime.now(UTC)

        result = await repo.list_entities(mock_session, as_of=dt)
        assert result == "historical_list"
        repo._history_manager.list_entities_as_of.assert_called_once()


class TestIncludeDeleted:
    """Tests for include_deleted branching."""

    @pytest.mark.asyncio
    async def test_get_include_deleted(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """get() should bypass soft-delete filtering when include_deleted=True."""
        mock_session.execute.return_value = MagicMock(
            first=MagicMock(return_value=None)
        )
        await repo.get(mock_session, uuid4(), include_deleted=True)
        stmt = mock_session.execute.call_args[0][0]
        assert "IS NULL" not in str(stmt)

    @pytest.mark.asyncio
    async def test_get_by_name_include_deleted(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """get_by_name() should bypass soft-delete filtering when include_deleted=True."""
        mock_session.execute.return_value = MagicMock(
            first=MagicMock(return_value=None)
        )
        await repo.get_by_name(mock_session, "DOC-1", include_deleted=True)
        stmt = mock_session.execute.call_args[0][0]
        assert "IS NULL" not in str(stmt)


class TestEntityExistsEdgeCases:
    """Tests for _entity_exists fallbacks."""

    @pytest.mark.asyncio
    async def test_entity_exists_by_name(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should check existence by name if id is missing."""
        mock_session.execute.return_value = MagicMock(scalar=MagicMock(return_value=1))
        # Bypass validation to test the edge case where id is missing
        doc = AdvancedTodo.model_construct(id=None, name="JustName", title="Test")

        exists = await repo._entity_exists(mock_session, doc)
        assert exists is True
        stmt = mock_session.execute.call_args[0][0]
        assert "tab_advanced_todo.name =" in str(stmt)

    @pytest.mark.asyncio
    async def test_entity_exists_no_id_no_name(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should return False instantly if both id and name are missing."""
        # Bypass validation to test the edge case where both id and name are missing
        doc = AdvancedTodo.model_construct(id=None, name=None, title="Test")
        exists = await repo._entity_exists(mock_session, doc)
        assert exists is False
        mock_session.execute.assert_not_called()


class TestEnterpriseResolution:
    """Tests for reference resolution enterprise branching."""

    @pytest.mark.asyncio
    async def test_get_resolves_enterprise_references(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """Should call resolve_enterprise when M_MODE is enterprise."""
        mock_row = MagicMock()
        mock_row._mapping = {"id": str(uuid4()), "name": "DOC-1", "title": "Test"}
        mock_session.execute.return_value = MagicMock(
            first=MagicMock(return_value=mock_row)
        )
        repo._mapper.row_to_entity = MagicMock(return_value=AdvancedTodo(title="Test"))

        with (
            patch.dict("os.environ", {"M_MODE": "enterprise"}),
            patch(
                "framework_m_standard.adapters.db.reference_resolver.ReferenceResolver.resolve_enterprise"
            ) as mock_resolve,
        ):
            mock_resolve.return_value = None
            await repo.get(mock_session, uuid4())
            mock_resolve.assert_called_once()


class TestUpdateEdgeCases:
    """Tests for edge cases during _update."""

    @pytest.mark.asyncio
    async def test_update_many_empty_data(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """update_many_for_user should short-circuit if data is empty."""
        res = await repo.update_many_for_user(mock_session, None, data={})
        assert res == 0
        mock_session.execute.assert_not_called()

    @pytest.mark.asyncio
    async def test_update_existing_entity_by_name(
        self, repo: GenericRepository[AdvancedTodo], mock_session: AsyncMock
    ) -> None:
        """_update should load existing entity by name if id is missing."""
        from framework_m_core.domain.base_controller import BaseController

        class AdvancedTodoController(BaseController[AdvancedTodo]):
            def __init__(self, doc):
                super().__init__(doc)
                self._audit_adapter = True

        repo_with_ctrl = GenericRepository(
            AdvancedTodo, repo.table, controller_class=AdvancedTodoController
        )

        # Bypass validation since id is missing
        doc = AdvancedTodo.model_construct(id=None, title="Updated", name="DOC-NAME")

        mock_exists_result = MagicMock()
        mock_exists_result.scalar.return_value = True

        mock_existing_row = MagicMock()
        mock_existing_row._mapping = {
            "id": str(uuid4()),
            "name": "DOC-NAME",
            "title": "Old",
        }
        mock_existing_result = MagicMock()
        mock_existing_result.first.return_value = mock_existing_row

        mock_update_result = MagicMock()
        mock_update_result.rowcount = 1

        mock_session.execute.side_effect = [
            mock_exists_result,  # _entity_exists
            mock_existing_result,  # fetch existing by name
            mock_update_result,  # actual update
        ]

        await repo_with_ctrl.save(mock_session, doc)

        assert mock_session.execute.call_count == 3
        stmt_str = str(mock_session.execute.call_args_list[1][0][0])
        assert "tab_advanced_todo.name =" in stmt_str


class TestListWithChildren:
    """Tests for list_entities child table resolution."""

    @pytest.mark.asyncio
    async def test_list_entities_loads_children(self, mock_session: AsyncMock) -> None:
        class ChildModel(BaseDocType):
            content: str

            class Meta:
                is_child = True

        class ParentModel(BaseDocType):
            title: str
            children: list[ChildModel] = Field(default_factory=list)

        metadata = MetaData()
        table = Table(
            "parent_doc",
            metadata,
            Column("id", String, primary_key=True),
            Column("name", String),
            Column("title", String),
        )
        child_table = Table(
            "child_doc",
            metadata,
            Column("id", String, primary_key=True),
            Column("parent", String),
            Column("content", String),
            Column("idx", Integer),
        )

        repo = GenericRepository(ParentModel, table)

        doc_id = uuid4()
        mock_row = MagicMock()
        mock_row._mapping = {"id": str(doc_id), "name": "P-1", "title": "Parent"}

        mock_result = MagicMock()
        mock_result.fetchall.return_value = [mock_row]

        mock_count = MagicMock()
        mock_count.scalar.return_value = 1

        mock_session.execute.side_effect = [mock_count, mock_result]

        with (
            patch(
                "framework_m_standard.adapters.db.table_registry.TableRegistry.get_table",
                return_value=child_table,
            ),
            patch.object(
                repo._child_table_manager,
                "load_children_for_parents",
                new_callable=AsyncMock,
            ) as mock_load,
        ):
            mock_load.return_value = {str(doc_id): [ChildModel(content="Child 1")]}

            res = await repo.list_entities(mock_session)

            assert len(res.items) == 1
            assert res.items[0].children[0].content == "Child 1"
