"""Tests for MigrationManager config and decentralized version locations."""

from unittest.mock import MagicMock, patch

from framework_m_standard.adapters.db.migration import MigrationManager


class TestMigrationConfig:
    """Tests for MigrationManager._create_config."""

    def test_create_config_merges_version_locations(self, tmp_path):
        """_create_config should merge version locations from INSTALLED_APPS."""
        # 1. Setup base alembic directory
        base_alembic = tmp_path / "alembic"
        base_alembic.mkdir()
        (base_alembic / "versions").mkdir()

        manager = MigrationManager(tmp_path)

        # 2. Setup mock app with its own alembic/versions
        app_path = tmp_path / "my_app"
        app_path.mkdir()
        app_versions = app_path / "alembic" / "versions"
        app_versions.mkdir(parents=True)

        # Mock importlib.util.find_spec to return our mock app
        mock_spec = MagicMock()
        mock_spec.origin = str(app_path / "__init__.py")
        (app_path / "__init__.py").touch()

        with (
            patch("os.environ.get", return_value="my_app"),
            patch("importlib.util.find_spec", return_value=mock_spec),
        ):
            config = manager._create_config()

            locations = config.get_main_option("version_locations")
            assert str(base_alembic / "versions") in locations
            assert str(app_versions) in locations

    def test_create_config_handles_missing_app_spec(self, tmp_path):
        """_create_config should ignore apps that cannot be found."""
        manager = MigrationManager(tmp_path)
        manager.init()

        with (
            patch("os.environ.get", return_value="nonexistent_app"),
            patch("importlib.util.find_spec", return_value=None),
        ):
            config = manager._create_config()
            locations = config.get_main_option("version_locations")
            assert "nonexistent_app" not in locations

    def test_create_config_sets_default_sqlite(self, tmp_path):
        """_create_config should fallback to sqlite if no URL or ini exists."""
        manager = MigrationManager(tmp_path, database_url=None)
        # Ensure alembic.ini DOES NOT exist in tmp_path

        config = manager._create_config()
        assert "sqlite" in config.get_main_option("sqlalchemy.url")

    def test_revision_with_version_path(self, tmp_path):
        """revision() should pass version_path to alembic."""
        manager = MigrationManager(tmp_path)
        manager.init()

        custom_path = tmp_path / "custom_versions"
        custom_path.mkdir()

        with patch("alembic.command.revision") as mock_revision:
            manager.revision(message="test", version_path=custom_path)

            mock_revision.assert_called_once()
            # Verify version_locations was set in the config used by the command
            assert manager.config.get_main_option("version_locations") == str(
                custom_path
            )
