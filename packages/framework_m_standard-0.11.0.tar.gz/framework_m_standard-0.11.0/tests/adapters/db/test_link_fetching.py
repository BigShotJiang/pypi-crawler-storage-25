"""Tests for LinkFetchingService.

TDD tests for extracting Link Field Fetching logic out of the GenericRepository.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID, uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_standard.adapters.db.link_fetching import LinkFetchingService
from sqlalchemy import Column, MetaData, String, Table
from sqlalchemy.types import UUID as SA_UUID

# =============================================================================
# Test Models
# =============================================================================


class MockCustomer(BaseDocType):
    """Target DocType for link."""

    customer_name: str


class MockOrder(BaseDocType):
    """DocType with link and fetch_from fields."""

    customer_id: UUID | None = Field(
        default=None, json_schema_extra={"link": "MockCustomer"}
    )
    customer_name: str | None = Field(
        default=None, json_schema_extra={"fetch_from": "customer_id.customer_name"}
    )
    unrelated_field: str | None = Field(default=None)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def target_table() -> Table:
    metadata = MetaData()
    return Table(
        "mockcustomer",
        metadata,
        Column("id", SA_UUID, primary_key=True),
        Column("customer_name", String),
    )


@pytest.fixture
def mock_session() -> AsyncMock:
    return AsyncMock()


# =============================================================================
# Tests
# =============================================================================


class TestLinkFetchingService:
    """Tests for LinkFetchingService."""

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_fetch_values_success(
        self, mock_get_table: MagicMock, target_table: Table, mock_session: AsyncMock
    ) -> None:
        """Should correctly fetch target_field and set it on the entity."""
        mock_get_table.return_value = target_table
        customer_uuid = uuid4()
        order = MockOrder(customer_id=customer_uuid)

        # Mock DB returning the target customer
        mock_row = MagicMock()
        mock_row.customer_name = "Acme Corp"
        mock_result = MagicMock()
        mock_result.first.return_value = mock_row
        mock_session.execute.return_value = mock_result

        service = LinkFetchingService(MockOrder)
        await service.fetch_link_values(mock_session, order)

        assert order.customer_name == "Acme Corp"
        mock_get_table.assert_called_once_with("MockCustomer")
        mock_session.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_fetch_values_empty_link(self, mock_session: AsyncMock) -> None:
        """Should set fetched field to None if link is not set."""
        order = MockOrder(customer_id=None, customer_name="Old Value")

        service = LinkFetchingService(MockOrder)
        await service.fetch_link_values(mock_session, order)

        # Should clear the fetch field because the link is empty
        assert order.customer_name is None
        mock_session.execute.assert_not_called()

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_fetch_values_target_not_found(
        self, mock_get_table: MagicMock, target_table: Table, mock_session: AsyncMock
    ) -> None:
        """Should set fetched field to None if target record is deleted/missing."""
        mock_get_table.return_value = target_table
        order = MockOrder(customer_id=uuid4(), customer_name="Stale Name")

        # Mock DB returning nothing (target record deleted/missing)
        mock_result = MagicMock()
        mock_result.first.return_value = None
        mock_session.execute.return_value = mock_result

        service = LinkFetchingService(MockOrder)
        await service.fetch_link_values(mock_session, order)

        assert order.customer_name is None

    @pytest.mark.asyncio
    @patch("framework_m_standard.adapters.db.table_registry.TableRegistry.get_table")
    async def test_fetch_values_unregistered_table(
        self, mock_get_table: MagicMock, mock_session: AsyncMock
    ) -> None:
        """Should silently skip if the target table is not registered."""
        mock_get_table.side_effect = KeyError("MockCustomer not found")
        order = MockOrder(customer_id=uuid4())

        service = LinkFetchingService(MockOrder)
        await service.fetch_link_values(mock_session, order)

        mock_session.execute.assert_not_called()
