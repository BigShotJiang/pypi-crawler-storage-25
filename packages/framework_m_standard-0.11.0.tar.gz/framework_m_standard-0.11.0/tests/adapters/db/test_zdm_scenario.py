"""Tests for Zero Downtime Migration (ZDM) scenarios.

TDD tests for Step 1.3: Verifying the application can handle
forward-compatible schema changes without downtime.
"""

from pathlib import Path
from typing import ClassVar

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.db.migration import MigrationManager
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from sqlalchemy import MetaData, create_engine
from sqlalchemy.ext.asyncio import create_async_engine


class ZDMUserV1(BaseDocType):
    """Old version of the DocType."""

    username: str = Field(description="User's login name")
    email: str = Field(description="User's email")

    class Meta:
        table_name: ClassVar[str] = "zdm_user"


class ZDMUserV2(BaseDocType):
    """New version of the DocType (adds a nullable column)."""

    username: str = Field(description="User's login name")
    email: str = Field(description="User's email")
    age: int | None = Field(default=None, description="Optional age field")

    class Meta:
        table_name: ClassVar[str] = "zdm_user"


@pytest.fixture
def clean_registry():
    """Clear registry before and after tests."""
    registry = MetaRegistry.get_instance()
    registry.clear()
    yield registry
    registry.clear()


@pytest.mark.asyncio
async def test_zdm_forward_compatible_migration(
    tmp_path: Path, clean_registry: MetaRegistry
) -> None:
    """Test that adding a nullable column allows V1 code to continue operating."""
    db_path = tmp_path / "zdm_test.db"
    db_url = f"sqlite:///{db_path}"
    async_db_url = f"sqlite+aiosqlite:///{db_path}"

    # Setup Phase 1: Deploy V1 Schema
    clean_registry.register_doctype(ZDMUserV1)

    sync_engine = create_engine(db_url)
    async_engine = create_async_engine(async_db_url)

    manager = MigrationManager(tmp_path, database_url=db_url)
    manager.init()

    # Generate V1 schema
    v1_metadata = MetaData()
    mapper = SchemaMapper()
    v1_table = mapper.create_table(ZDMUserV1, v1_metadata)

    # Auto-migrate to V1 (creates table in DB via dev_mode=True directly bridging DDL)
    manager.auto_migrate(target_metadata=v1_metadata, dev_mode=True, engine=sync_engine)

    # Insert data using V1 model
    repo_v1 = GenericRepository(ZDMUserV1, v1_table)

    from framework_m_standard.adapters.db.connection import ConnectionFactory
    from framework_m_standard.adapters.db.session import SessionFactory

    conn_factory = ConnectionFactory()
    conn_factory.configure({"default": async_db_url})
    session_factory = SessionFactory()
    session_factory.configure(conn_factory)

    async with session_factory.get_session() as session:
        user1 = ZDMUserV1(username="alice", email="alice@example.com")
        await repo_v1.save(session, user1)
        await session.commit()

    # Setup Phase 2: Deploy V2 Schema (Migration applied, but code is still V1)
    clean_registry.clear()
    clean_registry.register_doctype(ZDMUserV2)

    v2_metadata = MetaData()
    mapper.create_table(ZDMUserV2, v2_metadata)

    # Apply V2 migration (adds 'age' column)
    manager.auto_migrate(target_metadata=v2_metadata, dev_mode=True, engine=sync_engine)

    # Assertion: V1 Code can still perform CRUD even though the db has V2
    async with session_factory.get_session() as session:
        # Update
        retrieved = await repo_v1.get(session, user1.id)
        assert retrieved is not None
        retrieved.email = "alice.new@example.com"
        await repo_v1.save(session, retrieved)

        # Create new record using V1 code against V2 schema (forward compat test)
        user2 = ZDMUserV1(username="bob", email="bob@example.com")
        await repo_v1.save(session, user2)
        await session.commit()

    # Verify new record was successfully read
    async with session_factory.get_session() as session:
        retrieved_bob = await repo_v1.get(session, user2.id)
        assert retrieved_bob is not None
        assert retrieved_bob.username == "bob"

    # Teardown
    await async_engine.dispose()
    await conn_factory.dispose_all()


@pytest.mark.asyncio
async def test_zdm_readiness_during_backfill(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, clean_registry: MetaRegistry
) -> None:
    """Test /ready endpoint behavior during a simulated backfill."""
    from unittest.mock import patch

    from framework_m_standard.adapters.web.app import create_app
    from litestar.testing import TestClient

    db_path = tmp_path / "zdm_test_2.db"
    async_db_url = f"sqlite+aiosqlite:///{db_path}"

    monkeypatch.setenv("DATABASE_URL", async_db_url)
    monkeypatch.setenv(
        "CHECK_DECLARATIVE_SYNC", "False"
    )  # ZDM Mode Ignore Pending Decl Changes

    app = create_app(serve_static=False)

    with (
        patch(
            "framework_m_standard.adapters.db.migration_check.MigrationStatusUtility._is_alembic_up_to_date",
            return_value=True,
        ),
        patch(
            "framework_m_standard.adapters.db.migration_check.MigrationStatusUtility._has_breaking_declarative_changes",
            return_value=True,
        ),
        TestClient(app) as client,
    ):
        response = client.get("/ready")
        assert response.status_code == 200
        assert response.json() == {"status": "ready"}
