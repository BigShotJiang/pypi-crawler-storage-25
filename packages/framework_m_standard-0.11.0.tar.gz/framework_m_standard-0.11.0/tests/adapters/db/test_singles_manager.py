"""Tests for SinglesManager and Singleton Persistence."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from framework_m import DocType
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from sqlalchemy import Column, MetaData, String, Table
from sqlalchemy.ext.asyncio import AsyncSession

# =============================================================================
# Test Singleton DocType
# =============================================================================


class SystemSettings(DocType):
    """Test singleton DocType."""

    app_name: str = "Framework M"

    class Meta:
        is_singleton = True
        table_name = "system_settings"


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def metadata() -> MetaData:
    return MetaData()


@pytest.fixture
def settings_table(metadata: MetaData) -> Table:
    return Table(
        "tab_system_settings",
        metadata,
        Column("id", String, primary_key=True),
        Column("name", String, unique=True),
        Column("app_name", String),
        Column("owner", String),
        Column("modified", String),
        Column("deleted_at", String, nullable=True),
        Column("_version", String, nullable=True),
    )


@pytest.fixture
def repository(settings_table: Table) -> GenericRepository[SystemSettings]:
    return GenericRepository(
        model=SystemSettings,
        table=settings_table,
    )


@pytest.fixture
def mock_session() -> AsyncMock:
    session = AsyncMock(spec=AsyncSession)
    session.execute = AsyncMock()
    return session


# =============================================================================
# Tests
# =============================================================================


class TestSingletonPersistence:
    """Tests for singleton persistence logic."""

    @pytest.mark.asyncio
    async def test_save_singleton_first_time(
        self, repository: GenericRepository[SystemSettings], mock_session: AsyncMock
    ) -> None:
        """First save should insert the record."""
        settings = SystemSettings(app_name="New App")

        # Mock exists check (returns False/0)
        mock_exists_result = MagicMock()
        mock_exists_result.scalar.return_value = 0

        # Mock get_singleton_id (returns None)
        mock_id_result = MagicMock()
        mock_id_result.scalar.return_value = None

        # execution order: get_singleton_id, exists_check, insert
        mock_session.execute.side_effect = [
            mock_id_result,
            mock_exists_result,
            MagicMock(),
        ]

        result = await repository.save(mock_session, settings)

        assert result.app_name == "New App"
        assert result.name == "SystemSettings"  # Default name for singleton

    @pytest.mark.asyncio
    async def test_save_singleton_updates_existing(
        self, repository: GenericRepository[SystemSettings], mock_session: AsyncMock
    ) -> None:
        """Subsequent saves should update the existing record regardless of provided ID."""
        existing_id = uuid4()
        settings = SystemSettings(app_name="Updated App")

        # Mock get_singleton_id (returns existing_id)
        mock_id_result = MagicMock()
        mock_id_result.scalar.return_value = existing_id

        # Mock exists check (returns True)
        mock_exists_result = MagicMock()
        mock_exists_result.scalar.return_value = 1

        mock_session.execute.side_effect = [
            mock_id_result,
            mock_exists_result,
            MagicMock(),
        ]

        result = await repository.save(mock_session, settings)

        assert str(result.id) == str(existing_id)
        assert result.app_name == "Updated App"

    @pytest.mark.asyncio
    async def test_get_singleton(
        self, repository: GenericRepository[SystemSettings], mock_session: AsyncMock
    ) -> None:
        """get_singleton() should find the single record."""
        singleton_id = uuid4()

        # Mock get_singleton_id in SinglesManager
        mock_id_result = MagicMock()
        mock_id_result.scalar.return_value = singleton_id

        # Mock get() call in GenericRepository
        mock_row = MagicMock()
        mock_row._mapping = {
            "id": str(singleton_id),
            "name": "SystemSettings",
            "app_name": "Test App",
            "deleted_at": None,
        }
        mock_get_result = MagicMock()
        mock_get_result.first.return_value = mock_row

        mock_session.execute.side_effect = [mock_id_result, mock_get_result]

        result = await repository.get_singleton(mock_session)

        assert result is not None
        assert str(result.id) == str(singleton_id)
        assert result.app_name == "Test App"

    @pytest.mark.asyncio
    async def test_get_singleton_missing_deleted_at_column(
        self,
        mock_session: AsyncMock,
        metadata: MetaData,
        repository: GenericRepository[SystemSettings],
    ) -> None:
        """Test get_singleton handles tables without a deleted_at column."""
        from framework_m_standard.adapters.db.generic_repository import (
            GenericRepository,
        )
        from framework_m_standard.adapters.db.singles_manager import SinglesManager

        # Create a table WITHOUT deleted_at
        simple_table = Table(
            "tab_simple",
            metadata,
            Column("id", String, primary_key=True),
            Column("name", String, unique=True),
            Column("value", String),
        )

        mock_id_result = MagicMock()
        mock_id_result.scalar.return_value = "id1"
        mock_session.execute.return_value = mock_id_result

        # Must associate the table with the manager via a repo
        temp_repo = GenericRepository(model=SystemSettings, table=simple_table)
        manager = SinglesManager(repository=temp_repo)
        # This triggers the branch: if "deleted_at" in (col.name for col in table.columns):
        result = await manager.get_singleton_id(mock_session)
        assert result == "id1"
        assert mock_session.execute.called

    @pytest.mark.asyncio
    async def test_set_singleton_identity_preservation(
        self,
        mock_session: AsyncMock,
        metadata: MetaData,
        repository: GenericRepository[SystemSettings],
    ) -> None:
        """Test set_singleton preserves name/identity column."""
        from framework_m_standard.adapters.db.generic_repository import (
            GenericRepository,
        )
        from framework_m_standard.adapters.db.singles_manager import SinglesManager

        table = Table(
            "tab_identity",
            metadata,
            Column("id", String, primary_key=True),
            Column("name", String, unique=True),
            Column("val", String),
        )

        # Mock existing row to trigger update
        mock_row = MagicMock()
        mock_row.name = "my_identity"
        mock_result = MagicMock()
        mock_result.all.return_value = [mock_row]
        mock_session.execute.return_value = mock_result

        temp_repo = GenericRepository(model=SystemSettings, table=table)
        manager = SinglesManager(repository=temp_repo)
        # mock entity
        mock_entity = MagicMock()
        mock_entity.name = None
        await manager.ensure_singleton_identity(mock_session, mock_entity)

        # Verify it called execute (for SELECT)
        assert mock_session.execute.called
