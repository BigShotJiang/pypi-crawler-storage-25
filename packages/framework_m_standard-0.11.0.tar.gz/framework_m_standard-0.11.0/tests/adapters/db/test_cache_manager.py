"""Tests for RepoCacheManager."""

from unittest.mock import AsyncMock
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_standard.adapters.db.cache_manager import RepoCacheManager


class DummyDoc(BaseDocType):
    name: str | None = None


class User(BaseDocType):
    name: str | None = None


class CustomPermission(BaseDocType):
    name: str | None = None


class Translation(BaseDocType):
    name: str | None = None


@pytest.fixture
def mock_cache():
    return AsyncMock()


def test_cache_keys():
    manager = RepoCacheManager(None, DummyDoc)
    uid = uuid4()
    assert manager._cache_key(uid) == f"DummyDoc:id:{uid}"
    assert manager._cache_key_by_name("test") == "DummyDoc:name:test"
    assert manager.is_enabled is False


@pytest.mark.asyncio
async def test_get_set_by_id(mock_cache):
    manager = RepoCacheManager(mock_cache, DummyDoc)
    uid = uuid4()

    mock_cache.get.return_value = {"id": str(uid)}
    res = await manager.get_by_id(uid)
    assert res == {"id": str(uid)}
    mock_cache.get.assert_called_once_with(f"DummyDoc:id:{uid}")

    await manager.set_by_id(uid, {"id": str(uid)})
    mock_cache.set.assert_called_once_with(
        f"DummyDoc:id:{uid}", {"id": str(uid)}, ttl=300
    )


@pytest.mark.asyncio
async def test_get_set_by_name(mock_cache):
    manager = RepoCacheManager(mock_cache, DummyDoc)

    mock_cache.get.return_value = {"name": "test"}
    res = await manager.get_by_name("test")
    assert res == {"name": "test"}
    mock_cache.get.assert_called_once_with("DummyDoc:name:test")

    await manager.set_by_name("test", {"name": "test"})
    mock_cache.set.assert_called_once_with(
        "DummyDoc:name:test", {"name": "test"}, ttl=300
    )


@pytest.mark.asyncio
async def test_no_cache_returns_none():
    manager = RepoCacheManager(None, DummyDoc)
    uid = uuid4()
    assert await manager.get_by_id(uid) is None
    assert await manager.get_by_name("test") is None
    await manager.set_by_id(uid, {})
    await manager.set_by_name("test", {})
    await manager.invalidate(None)


@pytest.mark.asyncio
async def test_invalidate_basic(mock_cache):
    manager = RepoCacheManager(mock_cache, DummyDoc)
    uid = uuid4()
    doc = DummyDoc(id=uid, name="testdoc")

    await manager.invalidate(doc)
    mock_cache.delete.assert_any_call(f"DummyDoc:id:{uid}")
    mock_cache.delete.assert_any_call("DummyDoc:name:testdoc")


@pytest.mark.asyncio
async def test_invalidate_global_triggers(mock_cache):
    uid = uuid4()

    await RepoCacheManager(mock_cache, User).invalidate(None, id_to_invalidate=uid)
    mock_cache.delete_pattern.assert_any_call(f"perm:{uid}:*")

    await RepoCacheManager(mock_cache, CustomPermission).invalidate(
        CustomPermission(id=uid)
    )
    mock_cache.delete_pattern.assert_any_call("perm:*")

    await RepoCacheManager(mock_cache, Translation).invalidate(Translation(id=uid))
    mock_cache.delete_pattern.assert_any_call("meta:*")
