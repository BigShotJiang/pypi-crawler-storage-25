"""Tests for Agnostic Hybrid Overflow (Phase 4.2)."""

from typing import Any
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.interfaces.repository import FilterOperator, FilterSpec
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from sqlalchemy import MetaData, select
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine


class RegionalCompany(BaseDocType):
    name_field: str
    # High performance column
    india_gstin: str | None = Field(
        default=None, json_schema_extra={"persistence": "column"}
    )
    # JSON overflow
    eu_vat_id: str | None = Field(
        default=None, json_schema_extra={"persistence": "json"}
    )


@pytest.fixture
async def hybrid_setup() -> tuple[Any, Any, type[RegionalCompany]]:
    """Fixture to set up database with hybrid schema."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False)
    metadata = MetaData()
    mapper = SchemaMapper()

    table = mapper.create_table(RegionalCompany, metadata)

    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)

    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    return session_factory, table, RegionalCompany


@pytest.mark.asyncio
async def test_hybrid_pack_unpack(
    hybrid_setup: tuple[Any, Any, type[RegionalCompany]],
) -> None:
    """Verify physical column vs JSON overflow pack/unpack behavior."""
    session_factory, table, model = hybrid_setup
    repo = GenericRepository(model, table)

    doc_id = uuid4()

    async with session_factory() as session:
        doc = model(
            id=doc_id,
            name="COMP-01",
            name_field="Acme",
            india_gstin="22AAAAA0000A1Z5",
            eu_vat_id="FR123456789",
        )
        await repo.save(session, doc)

        # 1. Verify raw DB state to ensure strict separation
        result = await session.execute(select(table).where(table.c.id == doc_id))
        row = result.first()

        assert row is not None
        assert hasattr(row, "india_gstin")
        assert row.india_gstin == "22AAAAA0000A1Z5"
        assert not hasattr(row, "eu_vat_id")  # Should not be a physical column
        assert "eu_vat_id" in row.custom_fields
        assert row.custom_fields["eu_vat_id"] == "FR123456789"

        # 2. Verify repository transparently unpacks both
        retrieved = await repo.get(session, doc_id)
        assert retrieved is not None
        assert retrieved.india_gstin == "22AAAAA0000A1Z5"
        assert retrieved.eu_vat_id == "FR123456789"


@pytest.mark.asyncio
async def test_hybrid_smart_filtering(
    hybrid_setup: tuple[Any, Any, type[RegionalCompany]],
) -> None:
    """Verify smart filtering routes to column vs JSON paths seamlessly."""
    session_factory, table, model = hybrid_setup
    repo = GenericRepository(model, table)

    async with session_factory() as session:
        doc1 = model(
            id=uuid4(),
            name="C1",
            name_field="C1",
            india_gstin="GSTIN1",
            eu_vat_id="VAT1",
        )
        doc2 = model(
            id=uuid4(),
            name="C2",
            name_field="C2",
            india_gstin="GSTIN2",
            eu_vat_id="VAT2",
        )
        await repo.save(session, doc1)
        await repo.save(session, doc2)

        # 1. Query by high-performance column field
        res1 = await repo.list_entities(
            session,
            filters=[
                FilterSpec(
                    field="india_gstin", operator=FilterOperator.EQ, value="GSTIN1"
                )
            ],
        )
        assert res1.total == 1
        assert res1.items[0].name == "C1"

        # 2. Query by JSON overflow field (smart path extraction)
        res2 = await repo.list_entities(
            session,
            filters=[
                FilterSpec(field="eu_vat_id", operator=FilterOperator.EQ, value="VAT2")
            ],
        )
        assert res2.total == 1
        assert res2.items[0].name == "C2"
