"""Tests for Zero-Overhead Reference Resolution (Phase 4.2)."""

from typing import Any
from unittest.mock import AsyncMock
from uuid import uuid4

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.metadata_decorator import MetadataDecoratorRegistry
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from framework_m_standard.adapters.db.table_registry import TableRegistry
from sqlalchemy import MetaData
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine


class Supplier(BaseDocType):
    name_field: str = Field(description="Supplier Name")


class StockEntry(BaseDocType):
    item_code: str = Field(description="Item Code")
    supplier_id: str = Field(description="Supplier Reference")


@pytest.fixture
async def reference_setup(
    monkeypatch: pytest.MonkeyPatch,
) -> tuple[Any, Any, Any, Any, type[BaseDocType]]:
    """Fixture to set up database and baked models for reference resolution."""
    registry = MetadataDecoratorRegistry()
    registry.clear()

    # Register the No-Cliff reference
    registry.register_property("StockEntry", "supplier_id", str, link="Supplier")

    BakedStockEntry = registry.bake(StockEntry)

    meta_registry = MetaRegistry.get_instance()
    meta_registry.clear()
    meta_registry.register_doctype(Supplier)
    meta_registry.register_doctype(BakedStockEntry)

    engine = create_async_engine("sqlite+aiosqlite:///:memory:", echo=False)
    metadata = MetaData()
    mapper = SchemaMapper()

    supplier_table = mapper.create_table(Supplier, metadata)
    stock_table = mapper.create_table(BakedStockEntry, metadata)

    TableRegistry().reset()
    TableRegistry().register_table("Supplier", supplier_table)
    TableRegistry().register_table("StockEntry", stock_table)

    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)

    session_factory = async_sessionmaker(engine, expire_on_commit=False)

    return session_factory, supplier_table, stock_table, BakedStockEntry, Supplier


@pytest.mark.asyncio
async def test_indie_mode_reference_resolution(
    reference_setup: tuple[Any, Any, Any, Any, type[BaseDocType]],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Indie mode should fetch linked documents directly from the local database."""
    monkeypatch.setenv("M_MODE", "indie")
    session_factory, supplier_table, stock_table, BakedStockEntry, SupplierModel = (
        reference_setup
    )

    supplier_repo = GenericRepository(SupplierModel, supplier_table)
    stock_repo = GenericRepository(BakedStockEntry, stock_table)

    supplier_id = uuid4()
    stock_id = uuid4()

    async with session_factory() as session:
        await supplier_repo.save(
            session,
            SupplierModel(id=supplier_id, name="SUP-01", name_field="Acme Corp"),
        )
        await stock_repo.save(
            session,
            BakedStockEntry(
                id=stock_id, item_code="ITEM-A", supplier_id=str(supplier_id)
            ),
        )

        # Fetch stock entry - should auto-resolve supplier in Indie mode
        doc = await stock_repo.get(session, stock_id)

        assert doc is not None
        # The referenced document should be attached as a hydrated property
        assert hasattr(doc, "supplier")
        assert doc.supplier is not None
        assert doc.supplier.name_field == "Acme Corp"


@pytest.mark.asyncio
async def test_enterprise_mode_reference_resolution(
    reference_setup: tuple[Any, Any, Any, Any, type[BaseDocType]],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Enterprise mode should fetch linked documents via NATS event bus."""
    monkeypatch.setenv("M_MODE", "enterprise")
    session_factory, supplier_table, stock_table, BakedStockEntry, SupplierModel = (
        reference_setup
    )

    supplier_id = uuid4()
    stock_id = uuid4()

    # Mock EventBus to simulate NATS Request/Reply cross-service call
    mock_event_bus = AsyncMock()
    mock_event_bus.request.return_value = {
        "id": str(supplier_id),
        "name": "SUP-02",
        "name_field": "Enterprise Supplier Inc",
    }

    stock_repo = GenericRepository(
        BakedStockEntry, stock_table, event_bus=mock_event_bus
    )

    async with session_factory() as session:
        # We don't even need to save the supplier locally in enterprise mode!
        await stock_repo.save(
            session,
            BakedStockEntry(
                id=stock_id, item_code="ITEM-ENT", supplier_id=str(supplier_id)
            ),
        )

        doc = await stock_repo.get(session, stock_id)

        assert doc is not None
        assert hasattr(doc, "supplier")
        assert doc.supplier.name_field == "Enterprise Supplier Inc"

        mock_event_bus.request.assert_called_once_with(
            "rpc.Supplier.get", {"id": str(supplier_id)}
        )
