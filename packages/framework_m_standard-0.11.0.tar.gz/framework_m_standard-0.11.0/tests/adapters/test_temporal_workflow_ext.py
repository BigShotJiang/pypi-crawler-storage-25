"""Extended tests for Temporal Workflow Adapter to cover mTLS, API keys, and error handling."""

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.workflow import TransitionRequest
from framework_m_standard.adapters.workflow.temporal_adapter import (
    TemporalWorkflowAdapter,
)


@pytest.mark.asyncio
async def test_temporal_adapter_mtls_and_api_key() -> None:
    """Test connect with mTLS and API key."""
    mock_temporalio = MagicMock()
    mock_client_cls = MagicMock()
    mock_client_cls.connect = AsyncMock()
    mock_temporalio.client.Client = mock_client_cls
    mock_temporalio.client.TLSConfig = MagicMock()

    with (
        patch.dict(
            "sys.modules",
            {
                "temporalio": mock_temporalio,
                "temporalio.client": mock_temporalio.client,
            },
        ),
        patch.dict(
            "os.environ",
            {
                "TEMPORAL_API_KEY": "test-key",
                "TEMPORAL_CLIENT_CERT": "-----BEGIN CERTIFICATE-----",
                "TEMPORAL_CLIENT_KEY": "-----BEGIN PRIVATE KEY-----",
            },
        ),
    ):
        adapter = TemporalWorkflowAdapter()
        await adapter.connect()

        mock_temporalio.client.TLSConfig.assert_called_once()
        kwargs = mock_client_cls.connect.call_args.kwargs
        assert kwargs["tls"] is not False
        assert kwargs["rpc_metadata"] == {"Authorization": "Bearer test-key"}

        await adapter.disconnect()
        assert adapter._client is None


@pytest.mark.asyncio
async def test_temporal_adapter_mtls_file_paths(tmp_path: Path) -> None:
    """Test connect with mTLS using file paths."""
    cert_file = tmp_path / "cert.pem"
    key_file = tmp_path / "key.pem"
    cert_file.write_text("cert-content")
    key_file.write_text("key-content")

    mock_temporalio = MagicMock()
    mock_client_cls = MagicMock()
    mock_client_cls.connect = AsyncMock()
    mock_temporalio.client.Client = mock_client_cls
    mock_temporalio.client.TLSConfig = MagicMock()

    with (
        patch.dict(
            "sys.modules",
            {
                "temporalio": mock_temporalio,
                "temporalio.client": mock_temporalio.client,
            },
        ),
        patch.dict(
            "os.environ",
            {
                "TEMPORAL_CLIENT_CERT": str(cert_file),
                "TEMPORAL_CLIENT_KEY": str(key_file),
            },
        ),
    ):
        adapter = TemporalWorkflowAdapter()
        await adapter.connect()

        mock_temporalio.client.TLSConfig.assert_called_once_with(
            client_cert=b"cert-content", client_private_key=b"key-content"
        )


@pytest.mark.asyncio
async def test_temporal_adapter_import_error() -> None:
    """Test Temporal adapter raises ImportError when SDK is missing."""
    adapter = TemporalWorkflowAdapter()
    with (
        patch.dict("sys.modules", {"temporalio.client": None}),
        pytest.raises(ImportError, match="Temporal SDK not installed"),
    ):
        await adapter.connect()


@pytest.mark.asyncio
async def test_temporal_adapter_start_workflow_error() -> None:
    """Test start_workflow handles underlying errors."""
    adapter = TemporalWorkflowAdapter()
    adapter._client = MagicMock()
    adapter._client.start_workflow = AsyncMock(side_effect=Exception("mock error"))

    user = MagicMock(spec=UserContext)
    with pytest.raises(ValueError, match="Failed to start workflow"):
        await adapter.start_workflow("Doc", "123", "wf", user)


@pytest.mark.asyncio
async def test_temporal_adapter_get_workflow_state_error() -> None:
    """Test get_workflow_state handles missing workflow."""
    adapter = TemporalWorkflowAdapter()
    adapter._client = MagicMock()
    adapter._client.get_workflow_handle.side_effect = Exception("not found")

    result = await adapter.get_workflow_state("Doc", "123")
    assert result is None


@pytest.mark.asyncio
async def test_temporal_adapter_transition_error() -> None:
    """Test transition handles workflow errors gracefully."""
    adapter = TemporalWorkflowAdapter()
    adapter._client = MagicMock()
    adapter._client.get_workflow_handle.side_effect = Exception("failed")

    user = MagicMock(spec=UserContext)
    req = TransitionRequest(
        doctype="Doc", doc_id="123", action="approve", user=user, comment=""
    )
    result = await adapter.transition(req)
    assert result.success is False
    assert "Transition failed" in result.message


@pytest.mark.asyncio
async def test_temporal_adapter_get_available_actions_error() -> None:
    adapter = TemporalWorkflowAdapter()
    adapter._client = MagicMock()
    adapter._client.get_workflow_handle.side_effect = Exception("failed")

    user = MagicMock(spec=UserContext)
    result = await adapter.get_available_actions("Doc", "123", user)
    assert result == []
