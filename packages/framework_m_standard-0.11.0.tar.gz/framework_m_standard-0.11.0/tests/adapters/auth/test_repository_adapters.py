"""Tests for Auth Repository Adapters.

TDD tests for extracting the auth-specific repository adapters out of app.py.
"""

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import UUID

import pytest
from framework_m_core.doctypes.session import Session
from framework_m_core.doctypes.social_account import SocialAccount
from framework_m_core.doctypes.user import LocalUser
from framework_m_core.interfaces.repository import PaginatedResult
from framework_m_standard.adapters.auth.repository_adapters import (
    LocalUserRepositoryAdapter,
    SessionRepositoryAdapter,
    SocialAccountRepositoryAdapter,
)


class TestAuthRepositoryAdapters:
    """Tests for internal repository adapters in app.py."""

    @pytest.fixture
    def mock_repo_factory(self):
        return MagicMock()

    @pytest.fixture
    def mock_session_factory(self):
        factory = MagicMock()
        session = AsyncMock()
        factory.get_session.return_value.__aenter__.return_value = session
        return factory

    @pytest.mark.asyncio
    async def test_local_user_adapter(self, mock_repo_factory, mock_session_factory):
        repo = AsyncMock()
        mock_repo_factory.get_repository.return_value = repo
        adapter = LocalUserRepositoryAdapter(mock_repo_factory, mock_session_factory)

        user_id = UUID("550e8400-e29b-41d4-a716-446655440000")
        user = LocalUser(email="test@example.com", password_hash="hash")
        repo.get.return_value = user

        # get
        assert await adapter.get(str(user_id)) == user
        assert await adapter.get("invalid") is None

        # get_by_email
        repo.list_entities.return_value = PaginatedResult(
            items=[user], total=1, limit=1, offset=0
        )
        assert await adapter.get_by_email("test@example.com") == user

        # save & create
        repo.save.return_value = user
        assert await adapter.save(user) == user
        with patch("framework_m_core.security.hash_password", return_value="hashed"):
            assert await adapter.create("new@test.com", "pass") == user

    @pytest.mark.asyncio
    async def test_social_account_adapter(
        self, mock_repo_factory, mock_session_factory
    ):
        repo = AsyncMock()
        mock_repo_factory.get_repository.return_value = repo
        adapter = SocialAccountRepositoryAdapter(
            mock_repo_factory, mock_session_factory
        )

        account = SocialAccount(
            provider="google",
            provider_user_id="123",
            user_id=str(UUID(int=1)),
            display_name="T",
        )
        repo.list_entities.return_value = PaginatedResult(
            items=[account], total=1, limit=1, offset=0
        )

        assert await adapter.find_by_provider("g", "1") == account
        repo.save.return_value = account
        assert await adapter.create("g", "1", UUID(int=1), "T", "e", None) == account
        assert await adapter.update(account, display_name="N") == account

    @pytest.mark.asyncio
    async def test_session_adapter(self, mock_repo_factory, mock_session_factory):
        repo = AsyncMock()
        mock_repo_factory.get_repository.return_value = repo
        adapter = SessionRepositoryAdapter(mock_repo_factory, mock_session_factory)

        session_model = Session(
            session_id="s1",
            user_id=str(UUID(int=1)),
            expires_at=datetime.now(UTC) + timedelta(days=1),
        )
        repo.save.return_value = session_model

        assert await adapter.save(session_model) == session_model
        repo.list_entities.return_value = PaginatedResult(
            items=[session_model], total=1, limit=1, offset=0
        )
        assert await adapter.get_by_id("s1") == session_model
        assert await adapter.delete("s1") is True
        assert await adapter.find_by(user_id="u1") == [session_model]
