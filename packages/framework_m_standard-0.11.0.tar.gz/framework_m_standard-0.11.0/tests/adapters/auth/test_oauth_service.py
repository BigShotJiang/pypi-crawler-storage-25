"""Tests for OAuthService — auto-link OAuth users to local accounts.

TDD: Tests written BEFORE the implementation.

Tests cover:
- auto_link_user() finds existing SocialAccount by provider+provider_user_id
- auto_link_user() links to existing LocalUser by verified email match
- auto_link_user() creates new LocalUser + SocialAccount on first login
- auto_link_user() handles missing email gracefully (creates user without email match)
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest


class TestOAuthServiceImport:
    """Verify OAuthService is importable."""

    def test_oauth_service_is_importable(self) -> None:
        """OAuthService should be importable from oauth_service module."""
        from framework_m_standard.adapters.auth.oauth_service import OAuthService

        assert OAuthService is not None

    def test_auto_link_user_is_a_method(self) -> None:
        """OAuthService should have an async auto_link_user() method."""
        from framework_m_standard.adapters.auth.oauth_service import OAuthService

        assert hasattr(OAuthService, "auto_link_user")


class TestAutoLinkUserExistingSocialAccount:
    """Tests for auto_link_user() with existing SocialAccount."""

    @pytest.mark.asyncio
    async def test_returns_existing_user_via_social_account(self) -> None:
        """If SocialAccount exists: return linked LocalUser without creating anything."""
        from framework_m_standard.adapters.auth.oauth_service import OAuthService

        # Mock repositories
        mock_social_repo = AsyncMock()
        mock_user_repo = AsyncMock()

        # Existing social account
        existing_social = MagicMock()
        existing_social.user_id = "user-existing-001"
        mock_social_repo.find_by_provider = AsyncMock(return_value=existing_social)

        existing_user = MagicMock()
        existing_user.id = "user-existing-001"
        existing_user.email = "john@gmail.com"
        mock_user_repo.get = AsyncMock(return_value=existing_user)

        service = OAuthService(
            social_account_repo=mock_social_repo,
            user_repo=mock_user_repo,
        )

        user = await service.auto_link_user(
            provider="google",
            provider_user_id="google-123",
            email="john@gmail.com",
            email_verified=True,
            display_name="John Doe",
        )

        # Should return existing user without creating new records
        assert user.id == "user-existing-001"
        mock_social_repo.find_by_provider.assert_called_once_with(
            provider="google", provider_user_id="google-123"
        )
        # Should NOT create a new user
        mock_user_repo.create.assert_not_called()

    @pytest.mark.asyncio
    async def test_updates_last_login_timestamp(self) -> None:
        """auto_link_user should update SocialAccount.last_login_at on each login."""
        from framework_m_standard.adapters.auth.oauth_service import OAuthService

        mock_social_repo = AsyncMock()
        mock_user_repo = AsyncMock()

        existing_social = MagicMock()
        existing_social.user_id = "user-001"
        mock_social_repo.find_by_provider = AsyncMock(return_value=existing_social)

        existing_user = MagicMock()
        existing_user.id = "user-001"
        mock_user_repo.get = AsyncMock(return_value=existing_user)

        service = OAuthService(
            social_account_repo=mock_social_repo,
            user_repo=mock_user_repo,
        )

        await service.auto_link_user(
            provider="github",
            provider_user_id="gh-456",
            email="jane@example.com",
            email_verified=True,
            display_name="Jane Smith",
        )

        # Should update last login
        mock_social_repo.update.assert_called_once()


class TestAutoLinkUserByEmail:
    """Tests for auto_link_user() linking via verified email match."""

    @pytest.mark.asyncio
    async def test_links_to_existing_user_by_verified_email(self) -> None:
        """If no SocialAccount but verified email matches LocalUser: link and return."""
        from framework_m_standard.adapters.auth.oauth_service import OAuthService

        mock_social_repo = AsyncMock()
        mock_user_repo = AsyncMock()

        # No existing social account
        mock_social_repo.find_by_provider = AsyncMock(return_value=None)

        # Existing user with same email
        existing_user = MagicMock()
        existing_user.id = "user-existing-002"
        existing_user.email = "alice@example.com"
        mock_user_repo.find_by_email = AsyncMock(return_value=existing_user)

        # CreateSocialAccount mock
        mock_social_repo.create = AsyncMock()

        service = OAuthService(
            social_account_repo=mock_social_repo,
            user_repo=mock_user_repo,
        )

        user = await service.auto_link_user(
            provider="google",
            provider_user_id="google-999",
            email="alice@example.com",
            email_verified=True,
            display_name="Alice",
        )

        assert user.id == "user-existing-002"
        # Should create a new SocialAccount linking provider to existing user
        mock_social_repo.create.assert_called_once()
        # Should NOT create a new user
        mock_user_repo.create.assert_not_called()

    @pytest.mark.asyncio
    async def test_does_not_link_by_unverified_email(self) -> None:
        """If email is not verified: should NOT link by email (create new user instead)."""
        from framework_m_standard.adapters.auth.oauth_service import OAuthService

        mock_social_repo = AsyncMock()
        mock_user_repo = AsyncMock()

        mock_social_repo.find_by_provider = AsyncMock(return_value=None)
        mock_user_repo.find_by_email = AsyncMock(return_value=None)  # Won't be called
        new_user = MagicMock()
        new_user.id = "user-new-001"
        mock_user_repo.create = AsyncMock(return_value=new_user)
        mock_social_repo.create = AsyncMock()

        service = OAuthService(
            social_account_repo=mock_social_repo,
            user_repo=mock_user_repo,
        )

        user = await service.auto_link_user(
            provider="github",
            provider_user_id="gh-777",
            email="bob@example.com",
            email_verified=False,  # Not verified
            display_name="Bob",
        )

        assert user is not None
        # Should not try to link by email when email_verified=False
        mock_user_repo.find_by_email.assert_not_called()

    @pytest.mark.asyncio
    async def test_links_verified_email_with_string_user_id(self) -> None:
        """SocialAccount link should receive user_id as string even if LocalUser id is UUID."""
        from framework_m_standard.adapters.auth.oauth_service import OAuthService

        mock_social_repo = AsyncMock()
        mock_user_repo = AsyncMock()

        mock_social_repo.find_by_provider = AsyncMock(return_value=None)

        existing_user = MagicMock()
        existing_user.id = uuid4()
        existing_user.email = "alice@example.com"
        mock_user_repo.find_by_email = AsyncMock(return_value=existing_user)
        mock_social_repo.create = AsyncMock()

        service = OAuthService(
            social_account_repo=mock_social_repo,
            user_repo=mock_user_repo,
        )

        await service.auto_link_user(
            provider="google",
            provider_user_id="google-uuid-id",
            email="alice@example.com",
            email_verified=True,
            display_name="Alice",
        )

        assert mock_social_repo.create.call_args.kwargs["user_id"] == str(
            existing_user.id
        )


class TestAutoLinkUserCreateNew:
    """Tests for auto_link_user() creating new user on first social login."""

    @pytest.mark.asyncio
    async def test_creates_new_user_and_social_account(self) -> None:
        """First-ever social login: creates LocalUser + SocialAccount."""
        from framework_m_standard.adapters.auth.oauth_service import OAuthService

        mock_social_repo = AsyncMock()
        mock_user_repo = AsyncMock()

        # No existing social account, no email match
        mock_social_repo.find_by_provider = AsyncMock(return_value=None)
        mock_user_repo.find_by_email = AsyncMock(return_value=None)

        new_user = MagicMock()
        new_user.id = "user-brand-new-001"
        new_user.email = "newuser@example.com"
        mock_user_repo.create = AsyncMock(return_value=new_user)
        mock_social_repo.create = AsyncMock()

        service = OAuthService(
            social_account_repo=mock_social_repo,
            user_repo=mock_user_repo,
        )

        user = await service.auto_link_user(
            provider="google",
            provider_user_id="google-new-555",
            email="newuser@example.com",
            email_verified=True,
            display_name="New User",
        )

        assert user.id == "user-brand-new-001"
        # Should create both a LocalUser and a SocialAccount
        mock_user_repo.create.assert_called_once()
        mock_social_repo.create.assert_called_once()

    @pytest.mark.asyncio
    async def test_creates_user_without_email(self) -> None:
        """Should handle missing email (some providers don't share email)."""
        from framework_m_standard.adapters.auth.oauth_service import OAuthService

        mock_social_repo = AsyncMock()
        mock_user_repo = AsyncMock()

        mock_social_repo.find_by_provider = AsyncMock(return_value=None)

        new_user = MagicMock()
        new_user.id = "user-noemail-001"
        mock_user_repo.create = AsyncMock(return_value=new_user)
        mock_social_repo.create = AsyncMock()

        service = OAuthService(
            social_account_repo=mock_social_repo,
            user_repo=mock_user_repo,
        )

        user = await service.auto_link_user(
            provider="github",
            provider_user_id="gh-private-email",
            email=None,  # No email
            email_verified=False,
            display_name="Private User",
        )

        assert user is not None
        mock_user_repo.create.assert_called_once()

    @pytest.mark.asyncio
    async def test_creates_social_link_with_string_user_id(self) -> None:
        """New-user social link should receive user_id as string even if LocalUser id is UUID."""
        from framework_m_standard.adapters.auth.oauth_service import OAuthService

        mock_social_repo = AsyncMock()
        mock_user_repo = AsyncMock()

        mock_social_repo.find_by_provider = AsyncMock(return_value=None)
        mock_user_repo.find_by_email = AsyncMock(return_value=None)

        new_user = MagicMock()
        new_user.id = uuid4()
        mock_user_repo.create = AsyncMock(return_value=new_user)
        mock_social_repo.create = AsyncMock()

        service = OAuthService(
            social_account_repo=mock_social_repo,
            user_repo=mock_user_repo,
        )

        await service.auto_link_user(
            provider="github",
            provider_user_id="gh-uuid-id",
            email="new@example.com",
            email_verified=True,
            display_name="New",
        )

        assert mock_social_repo.create.call_args.kwargs["user_id"] == str(new_user.id)
