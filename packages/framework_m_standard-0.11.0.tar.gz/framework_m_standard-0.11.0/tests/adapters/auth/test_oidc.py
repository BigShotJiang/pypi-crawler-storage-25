"""Tests for OIDC Federated Authentication Strategy.

TDD: This test file is created BEFORE the implementation.
"""

from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_core.interfaces.auth_context import UserContext

if TYPE_CHECKING:
    from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth


class TestOidcFederatedAuthImport:
    """Tests for OidcFederatedAuth strategy import."""

    def test_import_oidc_auth(self) -> None:
        """OidcFederatedAuth should be importable."""
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        assert OidcFederatedAuth is not None


class TestOidcFederatedAuthSupports:
    """Tests for OidcFederatedAuth.supports method."""

    def test_oidc_strategy_supports_bearer_header(self) -> None:
        """supports() should return True for Authorization: Bearer header."""
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        # Mock cache protocol
        mock_cache = AsyncMock()
        strategy = OidcFederatedAuth(cache=mock_cache, providers={})

        mock_headers = {
            "authorization": "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjEyMyJ9..."
        }
        assert strategy.supports(mock_headers) is True

    def test_not_supports_missing_header(self) -> None:
        """supports() should return False when no Authorization header."""
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        mock_cache = AsyncMock()
        strategy = OidcFederatedAuth(cache=mock_cache, providers={})

        mock_headers: dict[str, str] = {}
        assert strategy.supports(mock_headers) is False


class TestOidcFederatedAuthAuthenticate:
    """Tests for OidcFederatedAuth.authenticate method."""

    @pytest.fixture
    def mock_cache(self) -> AsyncMock:
        """Provide a mock cache."""
        cache = AsyncMock()
        cache.get.return_value = None
        return cache

    @pytest.fixture
    def oidc_providers_config(self) -> dict:
        """Provide a mock provider config."""
        return {
            "test-idp": {
                "issuer": "https://idp.example.com",
                "jwks_uri": "https://idp.example.com/.well-known/jwks.json",
            }
        }

    @pytest.mark.asyncio
    async def test_oidc_strategy_validates_signature(
        self, mock_cache: AsyncMock, oidc_providers_config: dict
    ) -> None:
        """authenticate() should validate RS256 signature using JWKS."""
        from datetime import UTC, datetime, timedelta

        import jwt
        from cryptography.hazmat.primitives.asymmetric import rsa
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        # Generate a temporary RSA key pair for testing
        private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        public_key = private_key.public_key()

        # Create a valid token signed with the private key
        payload = {
            "iss": "https://idp.example.com",
            "sub": "ext-user-123",
            "exp": datetime.now(UTC) + timedelta(hours=1),
        }
        headers = {"kid": "key-1"}
        token = jwt.encode(payload, private_key, algorithm="RS256", headers=headers)  # type: ignore

        strategy = OidcFederatedAuth(cache=mock_cache, providers=oidc_providers_config)

        # We patch the internal JWKS fetcher to return our public key
        with patch.object(
            strategy, "_get_public_key", new_callable=AsyncMock
        ) as mock_get_key:
            mock_get_key.return_value = public_key

            mock_http_headers = {"authorization": f"Bearer {token}"}
            result = await strategy.authenticate(mock_http_headers)

            assert result is not None
            assert result.id == "ext-user-123"
            mock_get_key.assert_called_once_with("https://idp.example.com", "key-1")

    @pytest.mark.asyncio
    async def test_oidc_strategy_enriches_user_context(
        self, mock_cache: AsyncMock, oidc_providers_config: dict
    ) -> None:
        """authenticate() should correctly map JWT claims to UserContext."""
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        strategy = OidcFederatedAuth(cache=mock_cache, providers=oidc_providers_config)

        # Patch the internal decode method to bypass signature verification for this test
        # and just return the mapped claims
        with patch.object(
            strategy, "_decode_and_verify", new_callable=AsyncMock
        ) as mock_decode:
            mock_decode.return_value = {
                "sub": "user-456",
                "email": "test@company.com",
                "name": "Jane Doe",
            }

            result = await strategy.authenticate(
                {"authorization": "Bearer dummy-token"}
            )
            assert isinstance(result, UserContext)
            assert result.id == "user-456"
            assert result.email == "test@company.com"

    @pytest.mark.asyncio
    async def test_authenticate_exception_handling(
        self, mock_cache: AsyncMock, oidc_providers_config: dict
    ) -> None:
        """authenticate() should gracefully return None if an unexpected error occurs."""
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        strategy = OidcFederatedAuth(cache=mock_cache, providers=oidc_providers_config)

        with patch.object(
            strategy, "_decode_and_verify", side_effect=Exception("Unexpected crash")
        ):
            result = await strategy.authenticate({"authorization": "Bearer token"})
            assert result is None


class TestOidcFederatedAuthInternals:
    """Tests for internal validation, fetching, and caching methods."""

    @pytest.fixture
    def strategy(self) -> "OidcFederatedAuth":
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        return OidcFederatedAuth(
            cache=AsyncMock(),
            providers={
                "test-idp": {
                    "issuer": "https://test.com",
                    "audience": "my-aud",
                    "jwks_uri": "https://test.com/jwks",
                },
                "other-idp": {
                    "issuer": "https://other.com",
                    "jwks_endpoint": "https://other.com/keys",
                },
            },
        )

    def test_get_audience_for_issuer(self, strategy: "OidcFederatedAuth") -> None:
        """Should correctly find the configured audience."""
        assert strategy._get_audience_for_issuer("https://test.com") == "my-aud"
        assert strategy._get_audience_for_issuer("https://other.com") is None
        assert strategy._get_audience_for_issuer("https://unknown.com") is None

    def test_get_jwks_uri_for_issuer(self, strategy: "OidcFederatedAuth") -> None:
        """Should correctly find the configured JWKS URI."""
        assert (
            strategy._get_jwks_uri_for_issuer("https://test.com")
            == "https://test.com/jwks"
        )
        assert (
            strategy._get_jwks_uri_for_issuer("https://other.com")
            == "https://other.com/keys"
        )
        assert strategy._get_jwks_uri_for_issuer("https://unknown.com") is None

    @pytest.mark.asyncio
    async def test_fetch_and_cache_public_key_success(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should fetch JWKS via HTTP, cache it, and return the key."""
        import json

        jwk = {"kty": "RSA", "kid": "key-1", "n": "abc", "e": "AQAB"}
        mock_response = MagicMock()
        mock_response.json.return_value = {"keys": [jwk]}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response
        mock_client.__aenter__.return_value = mock_client

        with (
            patch(
                "framework_m_standard.adapters.auth.oidc.httpx.AsyncClient",
                return_value=mock_client,
            ),
            patch(
                "framework_m_standard.adapters.auth.oidc.jwt.algorithms.RSAAlgorithm.from_jwk",
                return_value="mocked-pub-key",
            ),
        ):
            key = await strategy._fetch_and_cache_public_key(
                "https://test.com", "key-1", "cache_key"
            )

            assert key == "mocked-pub-key"
            strategy._cache.set.assert_called_once_with(
                "cache_key", json.dumps(jwk), ttl=86400
            )

    @pytest.mark.asyncio
    async def test_fetch_and_cache_public_key_http_error(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should return None if the HTTP fetch fails."""
        import httpx

        mock_client = AsyncMock()
        mock_client.get.side_effect = httpx.HTTPError("Network failed")
        mock_client.__aenter__.return_value = mock_client

        with patch(
            "framework_m_standard.adapters.auth.oidc.httpx.AsyncClient",
            return_value=mock_client,
        ):
            key = await strategy._fetch_and_cache_public_key(
                "https://test.com", "key-1", "cache_key"
            )
            assert key is None

    @pytest.mark.asyncio
    async def test_decode_and_verify_invalid_token(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should gracefully return None on invalid JWT format."""
        assert await strategy._decode_and_verify("not-a-valid-jwt") is None


class TestOidcFactory:
    """Tests for the oidc_factory in strategies.py."""

    def test_oidc_factory_disabled(self) -> None:
        from framework_m_standard.adapters.auth.strategies import oidc_factory

        config = {"oauth": {"enabled": False}}
        assert oidc_factory(config) is None

    def test_oidc_factory_enabled(self) -> None:
        from framework_m_standard.adapters.auth.strategies import oidc_factory

        config = {
            "oauth": {
                "enabled": True,
                "providers": ["test-idp"],
                "test-idp": {"issuer": "https://test.com"},
            }
        }
        with patch("framework_m_standard.adapters.factory.get_cache"):
            strategy = oidc_factory(config)
            assert strategy is not None
            assert strategy._providers == {"test-idp": {"issuer": "https://test.com"}}


class TestOidcProviderSelection:
    """Tests for the provider selection logic (Phase 3)."""

    @pytest.fixture
    def multi_provider_config(self) -> dict:
        """Provide a multi-provider config for selection tests."""
        return {
            "google": {
                "issuer": "https://accounts.google.com",
                "jwks_uri": "https://www.googleapis.com/oauth2/v3/certs",
            },
            "azure": {
                "issuer": "https://login.microsoftonline.com/tenant-id/v2.0",
                "discovery_url": "https://login.microsoftonline.com/tenant-id/v2.0/.well-known/openid-configuration",
            },
            "keycloak": {
                "issuer": "https://keycloak.example.com/realms/master",
                "introspection_url": "https://keycloak.example.com/realms/master/protocol/openid-connect/token/introspect",
                "default": True,  # This is the default for opaque tokens
            },
        }

    @pytest.mark.asyncio
    async def test_selects_provider_by_jwt_iss_claim(
        self, multi_provider_config: dict
    ) -> None:
        """Should select the correct provider based on the JWT 'iss' claim."""
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        strategy = OidcFederatedAuth(cache=AsyncMock(), providers=multi_provider_config)

        # This token has "iss": "https://accounts.google.com"
        google_jwt = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJzdWIiOiIxMjMifQ.sig"

        with patch.object(
            strategy, "_decode_and_verify_jwt", new_callable=AsyncMock
        ) as mock_verify_jwt:
            mock_verify_jwt.return_value = {"sub": "user-123"}
            await strategy.authenticate({"authorization": f"Bearer {google_jwt}"})

            # Verify that the JWT verification was called with the 'google' provider config
            mock_verify_jwt.assert_called_once()
            call_args = mock_verify_jwt.call_args[0]
            assert call_args[0] == google_jwt
            assert call_args[1]["issuer"] == "https://accounts.google.com"

    @pytest.mark.asyncio
    async def test_selects_provider_by_header_for_opaque_token(
        self, multi_provider_config: dict
    ) -> None:
        """Should select provider from 'X-Auth-Provider' header for opaque tokens."""
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        strategy = OidcFederatedAuth(cache=AsyncMock(), providers=multi_provider_config)
        opaque_token = "a_very_opaque_token_string"

        with patch.object(
            strategy, "_introspect_opaque_token", new_callable=AsyncMock
        ) as mock_introspect:
            mock_introspect.return_value = {"sub": "user-456"}
            headers = {
                "authorization": f"Bearer {opaque_token}",
                "x-auth-provider": "keycloak",  # Explicitly select keycloak
            }
            await strategy.authenticate(headers)

            # Verify introspection was called with the 'keycloak' provider config
            mock_introspect.assert_called_once()
            call_args = mock_introspect.call_args[0]
            assert call_args[0] == opaque_token
            assert (
                call_args[1]["introspection_url"]
                == "https://keycloak.example.com/realms/master/protocol/openid-connect/token/introspect"
            )

    @pytest.mark.asyncio
    async def test_selects_default_provider_for_opaque_token_with_no_header(
        self, multi_provider_config: dict
    ) -> None:
        """Should fall back to the 'default' provider for an opaque token."""
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        strategy = OidcFederatedAuth(cache=AsyncMock(), providers=multi_provider_config)
        opaque_token = "another_opaque_token"

        with patch.object(
            strategy, "_introspect_opaque_token", new_callable=AsyncMock
        ) as mock_introspect:
            mock_introspect.return_value = {"sub": "user-789"}
            headers = {"authorization": f"Bearer {opaque_token}"}  # No provider header
            await strategy.authenticate(headers)

            # Verify introspection was called with the 'keycloak' (default) provider config
            mock_introspect.assert_called_once()
            call_args = mock_introspect.call_args[0]
            assert call_args[1]["default"] is True

    @pytest.mark.asyncio
    async def test_dynamic_discovery_is_triggered(
        self, multi_provider_config: dict
    ) -> None:
        """Should trigger OIDC discovery if 'discovery_url' is present."""
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        strategy = OidcFederatedAuth(cache=AsyncMock(), providers=multi_provider_config)
        azure_jwt = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vdGVuYW50LWlkL3YyLjAifQ.sig"

        with (
            patch.object(
                strategy, "_fetch_oidc_discovery", new_callable=AsyncMock
            ) as mock_discovery,
            patch.object(
                strategy, "_decode_and_verify_jwt", new_callable=AsyncMock
            ) as mock_verify_jwt,
        ):
            mock_discovery.return_value = {"jwks_uri": "http://discovered-jwks"}
            mock_verify_jwt.return_value = {"sub": "user-123"}
            await strategy.authenticate({"authorization": f"Bearer {azure_jwt}"})
            mock_discovery.assert_called_once_with(
                "https://login.microsoftonline.com/tenant-id/v2.0/.well-known/openid-configuration"
            )


class TestOidcFederatedAuthDeepInternals:
    """Tests for deep internal logic to hit missing lines."""

    @pytest.fixture
    def strategy(self) -> "OidcFederatedAuth":
        from framework_m_standard.adapters.auth.oidc import OidcFederatedAuth

        return OidcFederatedAuth(
            cache=AsyncMock(),
            providers={
                "test-idp": {
                    "issuer": "https://test.com",
                    "audience": "my-aud",
                    "jwks_uri": "https://test.com/jwks",
                },
            },
        )

    @pytest.mark.asyncio
    async def test_authenticate_unsupported_header(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should return None if supports() fails inside authenticate()."""
        assert await strategy.authenticate({"authorization": "Basic abc"}) is None

    @pytest.mark.asyncio
    async def test_authenticate_invalid_claims(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should return None if claims are missing 'sub'."""
        with patch.object(
            strategy, "_decode_and_verify", new_callable=AsyncMock
        ) as mock_decode:
            mock_decode.return_value = {"email": "no-sub@test.com"}
            assert (
                await strategy.authenticate({"authorization": "Bearer token"}) is None
            )

    @pytest.mark.asyncio
    async def test_decode_verify_unknown_issuer(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should return None if issuer is not configured."""
        jwt_token = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJodHRwczovL3Vua25vd24uY29tIn0.sig"
        assert await strategy._decode_and_verify(jwt_token) is None

    @pytest.mark.asyncio
    async def test_decode_verify_jwt_header_error(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should handle errors in jwt.get_unverified_header."""
        import jwt as pyjwt

        with patch(
            "framework_m_standard.adapters.auth.oidc.jwt.get_unverified_header",
            side_effect=pyjwt.PyJWTError,
        ):
            result = await strategy._decode_and_verify_jwt("token", {})
            assert result is None

    @pytest.mark.asyncio
    async def test_decode_verify_jwt_missing_kid(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should return None if 'kid' is missing from header."""
        with (
            patch(
                "framework_m_standard.adapters.auth.oidc.jwt.get_unverified_header",
                return_value={"alg": "RS256"},
            ),
            patch(
                "framework_m_standard.adapters.auth.oidc.jwt.decode",
                return_value={"iss": "https://test.com"},
            ),
        ):
            result = await strategy._decode_and_verify_jwt("token", {})
            assert result is None

    @pytest.mark.asyncio
    async def test_decode_verify_jwt_pubkey_none(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should return None if _get_public_key returns None."""
        with (
            patch(
                "framework_m_standard.adapters.auth.oidc.jwt.get_unverified_header",
                return_value={"kid": "k1"},
            ),
            patch(
                "framework_m_standard.adapters.auth.oidc.jwt.decode",
                return_value={"iss": "https://test.com"},
            ),
            patch.object(strategy, "_get_public_key", return_value=None),
        ):
            result = await strategy._decode_and_verify_jwt("token", {})
            assert result is None

    @pytest.mark.asyncio
    async def test_get_public_key_cache_hit(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should return key from cache if available."""
        import json

        jwk = {"kty": "RSA", "kid": "k1", "n": "abc", "e": "AQAB"}
        strategy._cache.get.return_value = json.dumps(jwk)

        with patch(
            "framework_m_standard.adapters.auth.oidc.jwt.algorithms.RSAAlgorithm.from_jwk",
            return_value="pubkey",
        ):
            key = await strategy._get_public_key("https://test.com", "k1")
            assert key == "pubkey"
            strategy._cache.get.assert_called_once()

    @pytest.mark.asyncio
    async def test_fetch_public_key_not_in_jwks(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should return None if requested kid is not in retrieved JWKS."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"keys": [{"kid": "other-kid"}]}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response
        mock_client.__aenter__.return_value = mock_client

        with patch(
            "framework_m_standard.adapters.auth.oidc.httpx.AsyncClient",
            return_value=mock_client,
        ):
            key = await strategy._fetch_and_cache_public_key(
                "https://test.com", "key-1", "ck"
            )
            assert key is None

    @pytest.mark.asyncio
    async def test_introspect_opaque_token_full(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should perform OIDC discovery and userinfo fetch."""
        mock_client = AsyncMock()
        mock_client.__aenter__.return_value = mock_client

        # 1st call: Discovery, 2nd call: UserInfo
        mock_discovery = MagicMock()
        mock_discovery.status_code = 200
        mock_discovery.json.return_value = {"userinfo_url": "https://test.com/userinfo"}

        mock_userinfo = MagicMock()
        mock_userinfo.status_code = 200
        mock_userinfo.json.return_value = {"sub": "opaque-123"}

        mock_client.get.side_effect = [mock_discovery, mock_userinfo]

        with patch(
            "framework_m_standard.adapters.auth.oidc.httpx.AsyncClient",
            return_value=mock_client,
        ):
            config = {"discovery_url": "https://test.com/.well-known"}
            result = await strategy._introspect_opaque_token("token", config)
            assert result == {"sub": "opaque-123"}
            assert config["userinfo_url"] == "https://test.com/userinfo"

    @pytest.mark.asyncio
    async def test_fetch_oidc_discovery_failure(
        self, strategy: "OidcFederatedAuth"
    ) -> None:
        """Should return None if discovery fetch fails."""
        mock_client = AsyncMock()
        mock_client.__aenter__.return_value = mock_client
        mock_client.get.side_effect = Exception("Failed")

        with patch(
            "framework_m_standard.adapters.auth.oidc.httpx.AsyncClient",
            return_value=mock_client,
        ):
            assert await strategy._fetch_oidc_discovery("http://bad-url") is None
