"""Tests for AsyncSingleflight request coalescing utility."""

import asyncio

import pytest
from framework_m_standard.adapters.auth.singleflight import AsyncSingleflight


class TestAsyncSingleflight:
    """Tests for AsyncSingleflight."""

    @pytest.mark.asyncio
    async def test_coalesces_concurrent_calls(self) -> None:
        """Should execute the function only once for concurrent calls to the same key."""
        group = AsyncSingleflight[str]()
        call_count = 0

        async def slow_fetch() -> str:
            nonlocal call_count
            call_count += 1
            await asyncio.sleep(0.05)
            return "success"

        # Run 3 concurrent requests for the same key
        results = await asyncio.gather(
            group.do("key1", slow_fetch),
            group.do("key1", slow_fetch),
            group.do("key1", slow_fetch),
        )

        assert results == ["success", "success", "success"]
        assert call_count == 1  # Verified: only called once

    @pytest.mark.asyncio
    async def test_propagates_exceptions(self) -> None:
        """Should propagate exceptions to all waiting concurrent callers."""
        group = AsyncSingleflight[str]()

        async def failing_fetch() -> str:
            await asyncio.sleep(0.01)
            raise ValueError("fetch failed")

        results = await asyncio.gather(
            group.do("key2", failing_fetch),
            group.do("key2", failing_fetch),
            return_exceptions=True,
        )

        assert isinstance(results[0], ValueError)
        assert isinstance(results[1], ValueError)
        assert str(results[0]) == "fetch failed"

    @pytest.mark.asyncio
    async def test_sequential_calls_execute_multiple_times(self) -> None:
        """Should execute again if the previous call for the key has completed."""
        group = AsyncSingleflight[str]()
        call_count = 0

        async def fast_fetch() -> str:
            nonlocal call_count
            call_count += 1
            return "ok"

        res1 = await group.do("key3", fast_fetch)
        res2 = await group.do("key3", fast_fetch)

        assert res1 == "ok"
        assert res2 == "ok"
        assert call_count == 2  # Not coalesced because they are sequential
