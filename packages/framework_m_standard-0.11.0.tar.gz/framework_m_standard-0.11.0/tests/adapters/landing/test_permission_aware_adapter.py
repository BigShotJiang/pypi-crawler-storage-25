"""Tests for PermissionAwareLandingAdapter.

This adapter checks a list of landing candidates and uses the
PermissionProtocol to return the first route the user is authorized to view.
"""

from unittest.mock import AsyncMock

import pytest
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.permission import (
    PermissionProtocol,
    PolicyEvaluateRequest,
    PolicyEvaluateResult,
)
from framework_m_standard.adapters.landing.permission_aware_adapter import (
    LandingCandidate,
    PermissionAwareLandingAdapter,
)


@pytest.fixture
def mock_context() -> UserContext:
    """Provide a basic user context."""
    return UserContext(id="user-1", email="test@example.com")


@pytest.fixture
def mock_permission() -> AsyncMock:
    """Provide a mock PermissionProtocol."""
    mock = AsyncMock(spec=PermissionProtocol)
    mock.evaluate.return_value = PolicyEvaluateResult(authorized=True)
    return mock


@pytest.mark.asyncio
async def test_resolves_first_permitted_candidate(
    mock_context: UserContext, mock_permission: AsyncMock
) -> None:
    """It should return the first candidate the user has permission for."""
    candidates = [
        LandingCandidate(
            route="/app/admin",
            required_doctype="SystemSettings",
            required_action="read",
        ),
        LandingCandidate(
            route="/app/dashboard", required_doctype="Workspace", required_action="read"
        ),
    ]

    # User lacks permission for SystemSettings, but has it for Workspace
    async def mock_evaluate(request: PolicyEvaluateRequest) -> PolicyEvaluateResult:
        return PolicyEvaluateResult(authorized=(request.resource == "Workspace"))

    mock_permission.evaluate.side_effect = mock_evaluate

    adapter = PermissionAwareLandingAdapter(
        permission_service=mock_permission,
        candidates=candidates,
    )

    result = await adapter.resolve(mock_context)

    assert result is not None
    assert result.route == "/app/dashboard"
    assert mock_permission.evaluate.call_count == 2


@pytest.mark.asyncio
async def test_returns_none_if_no_permissions(
    mock_context: UserContext, mock_permission: AsyncMock
) -> None:
    """It should return None if the user lacks permission for all candidates."""
    candidates = [
        LandingCandidate(
            route="/app/admin",
            required_doctype="SystemSettings",
            required_action="read",
        ),
    ]
    mock_permission.evaluate.return_value = PolicyEvaluateResult(authorized=False)

    adapter = PermissionAwareLandingAdapter(
        permission_service=mock_permission, candidates=candidates
    )
    result = await adapter.resolve(mock_context)

    assert result is None


@pytest.mark.asyncio
async def test_resolves_candidate_without_permission_requirement(
    mock_context: UserContext, mock_permission: AsyncMock
) -> None:
    """It should immediately resolve a candidate that doesn't require specific permissions."""
    candidates = [LandingCandidate(route="/app/home")]

    adapter = PermissionAwareLandingAdapter(
        permission_service=mock_permission, candidates=candidates
    )
    result = await adapter.resolve(mock_context)

    assert result is not None
    assert result.route == "/app/home"
    mock_permission.evaluate.assert_not_called()
