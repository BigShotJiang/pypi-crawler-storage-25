"""Tests for CompositeLandingAdapter.

This adapter implements the Composite pattern, allowing multiple
LandingProtocol adapters to be grouped and tried in sequence.
"""

from unittest.mock import AsyncMock

import pytest
from framework_m_core.domain.landing import LandingDescriptor
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.landing import LandingProtocol
from framework_m_standard.adapters.landing.composite_adapter import (
    CompositeLandingAdapter,
)


@pytest.fixture
def mock_context() -> UserContext:
    return UserContext(id="user-1", email="test@example.com")


@pytest.mark.asyncio
async def test_composite_adapter_resolves_first_match(
    mock_context: UserContext,
) -> None:
    """It should return the descriptor from the first sub-adapter that resolves."""
    adapter1 = AsyncMock(spec=LandingProtocol)
    adapter1.resolve.return_value = LandingDescriptor(route="/app/first")

    adapter2 = AsyncMock(spec=LandingProtocol)
    adapter2.resolve.return_value = LandingDescriptor(route="/app/second")

    composite = CompositeLandingAdapter(adapters=[adapter1, adapter2])
    result = await composite.resolve(mock_context)

    assert result is not None
    assert result.route == "/app/first"
    adapter1.resolve.assert_called_once_with(mock_context)
    adapter2.resolve.assert_not_called()


@pytest.mark.asyncio
async def test_composite_adapter_falls_through(mock_context: UserContext) -> None:
    """It should try the next sub-adapter if the first returns None."""
    adapter1 = AsyncMock(spec=LandingProtocol)
    adapter1.resolve.return_value = None

    adapter2 = AsyncMock(spec=LandingProtocol)
    adapter2.resolve.return_value = LandingDescriptor(route="/app/second")

    composite = CompositeLandingAdapter(adapters=[adapter1, adapter2])
    result = await composite.resolve(mock_context)

    assert result is not None
    assert result.route == "/app/second"
    adapter1.resolve.assert_called_once_with(mock_context)
    adapter2.resolve.assert_called_once_with(mock_context)


@pytest.mark.asyncio
async def test_composite_adapter_returns_none_if_no_match(
    mock_context: UserContext,
) -> None:
    """It should return None if no sub-adapters resolve."""
    adapter1 = AsyncMock(spec=LandingProtocol)
    adapter1.resolve.return_value = None

    composite = CompositeLandingAdapter(adapters=[adapter1])
    result = await composite.resolve(mock_context)

    assert result is None
    adapter1.resolve.assert_called_once_with(mock_context)


@pytest.mark.asyncio
async def test_composite_adapter_empty(mock_context: UserContext) -> None:
    """It should return None if initialized with no adapters."""
    composite = CompositeLandingAdapter(adapters=[])
    result = await composite.resolve(mock_context)
    assert result is None
