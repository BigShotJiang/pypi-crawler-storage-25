"""Tests for Auth Strategy Registry and dynamic loading."""

from unittest.mock import Mock, patch

import pytest
from framework_m_standard.adapters.auth.registry import AuthStrategyRegistry
from framework_m_standard.adapters.auth.strategies import (
    JwtAuth,
    create_auth_chain_from_config,
    register_builtins,
)


class TestAuthStrategyRegistry:
    """Tests for AuthStrategyRegistry singleton."""

    @pytest.fixture(autouse=True)
    def reset_registry(self):
        """Reset registry before each test."""
        AuthStrategyRegistry().reset()
        yield
        AuthStrategyRegistry().reset()

    def test_singleton_pattern(self):
        """Registry should be a singleton."""
        reg1 = AuthStrategyRegistry()
        reg2 = AuthStrategyRegistry()
        assert reg1 is reg2

    def test_register_and_get_factory(self):
        """Should register and retrieve a factory."""
        registry = AuthStrategyRegistry()
        mock_factory = Mock()

        registry.register("custom", mock_factory)

        assert registry.get_factory("custom") == mock_factory
        assert "custom" in registry.list_strategies()

    def test_get_nonexistent_factory(self):
        """Should return None for unknown strategy."""
        registry = AuthStrategyRegistry()
        assert registry.get_factory("unknown") is None

    def test_load_from_path(self):
        """Should dynamically load a factory from a string path."""
        registry = AuthStrategyRegistry()

        # Test loading a built-in class by its full path
        path = "framework_m_standard.adapters.auth.strategies.JwtAuth"
        factory = registry.get_factory(path)

        assert factory is JwtAuth

    def test_load_from_invalid_path(self):
        """Should return None for invalid paths."""
        registry = AuthStrategyRegistry()

        assert registry.get_factory("invalid.path.NotExists") is None
        assert registry.get_factory("nonexistent_module.Strategy") is None


class TestCreateAuthChainWithRegistry:
    """Tests for create_auth_chain_from_config using the registry."""

    @pytest.mark.asyncio
    async def test_create_chain_with_builtin_strategies(self):
        """Should create chain using registered built-in strategies."""
        # Restore built-ins since they might have been reset by previous tests
        register_builtins()

        from framework_m_standard.adapters.auth.strategies import AuthStrategyRegistry

        registry = AuthStrategyRegistry()
        assert "jwt" in registry.list_strategies()
        assert "api_key" in registry.list_strategies()

        with patch(
            "framework_m_standard.adapters.auth.strategies.load_config"
        ) as mock_load_config:
            mock_load_config.return_value = {"auth": {"strategies": ["jwt"]}}

            chain = create_auth_chain_from_config(jwt_secret="test-secret")

            assert len(chain._strategies) == 1
            assert isinstance(chain._strategies[0], JwtAuth)

    @pytest.mark.asyncio
    async def test_create_chain_with_custom_registered_strategy(self):
        """Should support custom strategies registered at runtime."""
        registry = AuthStrategyRegistry()
        mock_strategy = Mock()
        mock_factory = Mock(return_value=mock_strategy)

        registry.register("my-custom", mock_factory)

        with patch(
            "framework_m_standard.adapters.auth.strategies.load_config"
        ) as mock_load_config:
            mock_load_config.return_value = {"auth": {"strategies": ["my-custom"]}}

            chain = create_auth_chain_from_config(jwt_secret="test-secret")

            assert len(chain._strategies) == 1
            assert chain._strategies[0] == mock_strategy
            mock_factory.assert_called_once()
