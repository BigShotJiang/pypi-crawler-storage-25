"""Tests for MemoryCacheAdapter - Comprehensive coverage tests."""

import time

import pytest
from framework_m_standard.adapters.cache.memory_cache import _CacheEntry

# =============================================================================
# Test: MemoryCacheAdapter Import
# =============================================================================


class TestInMemoryCacheImport:
    """Tests for MemoryCacheAdapter import."""

    def test_import_inmemory_data_adapter(self) -> None:
        """MemoryCacheAdapter should be importable."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        assert MemoryCacheAdapter is not None


# =============================================================================
# Test: MemoryCacheAdapter Instantiation
# =============================================================================


class TestInMemoryCacheInstantiation:
    """Tests for MemoryCacheAdapter instantiation."""

    def test_init_creates_empty_data(self) -> None:
        """__init__ should create empty cache dict."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()

        assert cache._data == {}

    def test_init_is_isolated(self) -> None:
        """Each instance should have its own cache."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache1 = MemoryCacheAdapter()
        cache2 = MemoryCacheAdapter()

        assert cache1._data is not cache2._data


# =============================================================================
# Test: MemoryCacheAdapter - Get
# =============================================================================


class TestInMemoryCacheGet:
    """Tests for get method."""

    @pytest.mark.asyncio
    async def test_get_returns_none_for_missing_key(self) -> None:
        """get should return None for missing key."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()

        result = await cache.get("missing")

        assert result is None

    @pytest.mark.asyncio
    async def test_get_returns_datad_value(self) -> None:
        """get should return cached value."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        cache._data["key"] = _CacheEntry({"data": "value"}, None)

        result = await cache.get("key")

        assert result == {"data": "value"}

    @pytest.mark.asyncio
    async def test_get_removes_expired_key(self) -> None:
        """get should remove and return None for expired key."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        # Set to already expired
        cache._data["expired"] = _CacheEntry("old_value", time.time() - 10)

        result = await cache.get("expired")

        assert result is None
        assert "expired" not in cache._data

    @pytest.mark.asyncio
    async def test_get_returns_value_before_expiry(self) -> None:
        """get should return value if not expired."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        # Set to expire in future
        cache._data["fresh"] = _CacheEntry("value", time.time() + 1000)

        result = await cache.get("fresh")

        assert result == "value"


# =============================================================================
# Test: MemoryCacheAdapter - Set
# =============================================================================


class TestInMemoryCacheSet:
    """Tests for set method."""

    @pytest.mark.asyncio
    async def test_set_stores_value(self) -> None:
        """set should store value in cache."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()

        await cache.set("key", {"data": "value"})

        assert "key" in cache._data
        entry = cache._data["key"]
        assert entry.value == {"data": "value"}

    @pytest.mark.asyncio
    async def test_set_without_ttl(self) -> None:
        """set without TTL should have no expiry."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()

        await cache.set("key", "value")

        entry = cache._data["key"]
        assert entry.expires_at is None

    @pytest.mark.asyncio
    async def test_set_with_ttl(self) -> None:
        """set with TTL should set expiry time."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        before = time.time()

        await cache.set("key", "value", ttl=60)

        entry = cache._data["key"]
        assert entry.expires_at is not None
        assert entry.expires_at >= before + 60

    @pytest.mark.asyncio
    async def test_set_overwrites_existing(self) -> None:
        """set should overwrite existing value."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        await cache.set("key", "old")
        await cache.set("key", "new")

        entry = cache._data["key"]
        assert entry.value == "new"


# =============================================================================
# Test: MemoryCacheAdapter - Delete
# =============================================================================


class TestInMemoryCacheDelete:
    """Tests for delete method."""

    @pytest.mark.asyncio
    async def test_delete_removes_key(self) -> None:
        """delete should remove key from cache."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        cache._data["key"] = _CacheEntry("value", None)

        await cache.delete("key")

        assert "key" not in cache._data

    @pytest.mark.asyncio
    async def test_delete_nonexistent_key(self) -> None:
        """delete should not error for nonexistent key."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()

        # Should not raise
        await cache.delete("nonexistent")


# =============================================================================
# Test: MemoryCacheAdapter - Exists
# =============================================================================


class TestInMemoryCacheExists:
    """Tests for exists method."""

    @pytest.mark.asyncio
    async def test_exists_returns_true(self) -> None:
        """exists should return True for existing key."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        cache._data["key"] = _CacheEntry("value", None)

        result = await cache.exists("key")

        assert result is True

    @pytest.mark.asyncio
    async def test_exists_returns_false(self) -> None:
        """exists should return False for missing key."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()

        result = await cache.exists("missing")

        assert result is False

    @pytest.mark.asyncio
    async def test_exists_returns_false_for_expired(self) -> None:
        """exists should return False for expired key."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        cache._data["expired"] = _CacheEntry("value", time.time() - 10)

        result = await cache.exists("expired")

        assert result is False


# =============================================================================
# Test: MemoryCacheAdapter - Get Many
# =============================================================================


class TestInMemoryCacheGetMany:
    """Tests for get_many method."""

    @pytest.mark.asyncio
    async def test_get_many_returns_existing(self) -> None:
        """get_many should return existing values."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        cache._data["key1"] = _CacheEntry("value1", None)
        cache._data["key2"] = _CacheEntry("value2", None)

        result = await cache.get_many(["key1", "key2", "key3"])

        assert result == {"key1": "value1", "key2": "value2"}

    @pytest.mark.asyncio
    async def test_get_many_empty_keys(self) -> None:
        """get_many should return empty dict for empty keys."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()

        result = await cache.get_many([])

        assert result == {}

    @pytest.mark.asyncio
    async def test_get_many_all_missing(self) -> None:
        """get_many should return empty dict if all missing."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()

        result = await cache.get_many(["a", "b", "c"])

        assert result == {}


# =============================================================================
# Test: MemoryCacheAdapter - Set Many
# =============================================================================


class TestInMemoryCacheSetMany:
    """Tests for set_many method."""

    @pytest.mark.asyncio
    async def test_set_many_stores_all(self) -> None:
        """set_many should store all items."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()

        await cache.set_many({"key1": "value1", "key2": "value2"})

        assert "key1" in cache._data
        assert "key2" in cache._data

    @pytest.mark.asyncio
    async def test_set_many_with_ttl(self) -> None:
        """set_many should apply TTL to all items."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()

        await cache.set_many({"k1": "v1", "k2": "v2"}, ttl=60)

        entry1 = cache._data["k1"]
        entry2 = cache._data["k2"]
        assert entry1.expires_at is not None
        assert entry2.expires_at is not None


# =============================================================================
# Test: MemoryCacheAdapter - Delete Pattern
# =============================================================================


class TestInMemoryCacheDeletePattern:
    """Tests for delete_pattern method."""

    @pytest.mark.asyncio
    async def test_delete_pattern_removes_matching(self) -> None:
        """delete_pattern should remove matching keys."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        cache._data["user:1"] = _CacheEntry("data1", None)
        cache._data["user:2"] = _CacheEntry("data2", None)
        cache._data["order:1"] = _CacheEntry("data3", None)

        count = await cache.delete_pattern("user:*")

        assert count == 2
        assert "user:1" not in cache._data
        assert "user:2" not in cache._data
        assert "order:1" in cache._data

    @pytest.mark.asyncio
    async def test_delete_pattern_no_matches(self) -> None:
        """delete_pattern should return 0 for no matches."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        cache._data["key"] = _CacheEntry("value", None)

        count = await cache.delete_pattern("nomatch:*")

        assert count == 0


# =============================================================================
# Test: MemoryCacheAdapter - TTL
# =============================================================================


class TestInMemoryCacheTTL:
    """Tests for ttl method."""

    @pytest.mark.asyncio
    async def test_ttl_returns_none_for_missing(self) -> None:
        """ttl should return None for missing key."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()

        result = await cache.ttl("missing")

        assert result is None

    @pytest.mark.asyncio
    async def test_ttl_returns_none_for_no_expiry(self) -> None:
        """ttl should return None for key without expiry."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        cache._data["key"] = _CacheEntry("value", None)

        result = await cache.ttl("key")

        assert result is None

    @pytest.mark.asyncio
    async def test_ttl_returns_remaining_time(self) -> None:
        """ttl should return remaining seconds."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        cache._data["key"] = _CacheEntry("value", time.time() + 100)

        result = await cache.ttl("key")

        assert result is not None
        assert result >= 99  # Allow for small timing difference

    @pytest.mark.asyncio
    async def test_ttl_returns_zero_for_expired(self) -> None:
        """ttl should return 0 for expired key."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        cache._data["expired"] = _CacheEntry("value", time.time() - 10)

        result = await cache.ttl("expired")

        assert result == 0


# =============================================================================
# Test: MemoryCacheAdapter - Clear
# =============================================================================


class TestInMemoryCacheClear:
    """Tests for clear method."""

    @pytest.mark.asyncio
    async def test_clear_removes_all_keys(self) -> None:
        """clear should remove all keys."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        cache._data["key1"] = _CacheEntry("v1", None)
        cache._data["key2"] = _CacheEntry("v2", None)

        await cache.clear()

        assert cache._data == {}


# =============================================================================
# Test: MemoryCacheAdapter - Locks
# =============================================================================


class TestInMemoryCacheLocks:
    """Tests for lock methods."""

    @pytest.mark.asyncio
    async def test_acquire_lock_success(self) -> None:
        """acquire_lock should return True and store lock."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        result = await cache.acquire_lock("my_lock", ttl=60)

        assert result is True
        assert "lock:my_lock" in cache._data

    @pytest.mark.asyncio
    async def test_acquire_lock_fails_if_held(self) -> None:
        """acquire_lock should return False if already locked."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        await cache.acquire_lock("my_lock", ttl=60)

        # Second attempt should fail
        result = await cache.acquire_lock("my_lock", ttl=60)
        assert result is False

    @pytest.mark.asyncio
    async def test_release_lock_success(self) -> None:
        """release_lock should clear the lock."""
        from framework_m_standard.adapters.cache import MemoryCacheAdapter

        cache = MemoryCacheAdapter()
        await cache.acquire_lock("my_lock", ttl=60)

        result = await cache.release_lock("my_lock")
        assert result is True
        assert "lock:my_lock" not in cache._data
