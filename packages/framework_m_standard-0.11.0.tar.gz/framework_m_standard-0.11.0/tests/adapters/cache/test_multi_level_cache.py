"""Tests for MultiLevelCacheAdapter."""

from unittest.mock import AsyncMock

import pytest
from framework_m_standard.adapters.cache.memory_cache import MemoryCacheAdapter
from framework_m_standard.adapters.cache.multi_level_cache import MultiLevelCacheAdapter


@pytest.fixture
def l1_cache() -> MemoryCacheAdapter:
    """L1 Memory cache."""
    return MemoryCacheAdapter()


@pytest.fixture
def l2_cache() -> AsyncMock:
    """Mock L2 Redis cache."""
    mock = AsyncMock()
    mock.get = AsyncMock(return_value=None)
    mock.set = AsyncMock()
    mock.delete = AsyncMock()
    mock.ttl = AsyncMock(return_value=None)
    mock.exists = AsyncMock(return_value=False)
    mock.get_many = AsyncMock(return_value={})
    mock.set_many = AsyncMock()
    mock.delete_pattern = AsyncMock(return_value=0)
    mock.clear = AsyncMock()
    mock.acquire_lock = AsyncMock(return_value=True)
    mock.release_lock = AsyncMock(return_value=True)
    return mock


@pytest.mark.asyncio
async def test_multi_level_cache_read_through(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test read-through: L1 miss -> L2 hit -> backfill L1."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)

    # Setup L2 hit
    l2_cache.get.return_value = "l2_value"
    l2_cache.ttl.return_value = 3600

    # 1. First get (L1 miss, L2 hit)
    result = await cache.get("key1")
    assert result == "l2_value"
    l2_cache.get.assert_called_once_with("key1")

    # 2. Second get (L1 hit)
    result = await cache.get("key1")
    assert result == "l2_value"
    # L2.get should NOT be called again
    assert l2_cache.get.call_count == 1


@pytest.mark.asyncio
async def test_multi_level_cache_write_through(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test write-through: Write to both levels."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)

    await cache.set("key1", "value1", ttl=600)

    # Check L1
    assert await l1_cache.get("key1") == "value1"
    # Check L2 call
    l2_cache.set.assert_called_once_with("key1", "value1", 600)


@pytest.mark.asyncio
async def test_multi_level_cache_delete_all(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test delete: Invalidate all levels."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)

    await l1_cache.set("key1", "value1")
    await cache.delete("key1")

    assert await l1_cache.get("key1") is None
    l2_cache.delete.assert_called_once_with("key1")


@pytest.mark.asyncio
async def test_multi_level_cache_locking_delegates_to_l2(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test locking: MUST delegate to L2 for distributed safety."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)

    # L1 should be ignored for locking
    await cache.acquire_lock("lock1", ttl=10)
    l2_cache.acquire_lock.assert_called_once_with("lock1", 10)

    await cache.release_lock("lock1")
    l2_cache.release_lock.assert_called_once_with("lock1")


@pytest.mark.asyncio
async def test_multi_level_cache_exists(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test exists checks L1 then L2."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)

    # Test L1 hit
    await l1_cache.set("key_exist", "val")
    assert await cache.exists("key_exist") is True

    # Test L2 hit
    l2_cache.exists.return_value = True
    assert await cache.exists("key_l2") is True
    l2_cache.exists.assert_called_once_with("key_l2")


@pytest.mark.asyncio
async def test_multi_level_cache_get_many(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test get_many fetches from L1, falls back to L2, and backfills L1."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)

    await l1_cache.set("k1", "v1")
    l2_cache.get_many.return_value = {"k2": "v2"}
    l2_cache.ttl.return_value = 100

    result = await cache.get_many(["k1", "k2"])

    assert result == {"k1": "v1", "k2": "v2"}
    l2_cache.get_many.assert_called_once_with(["k2"])
    assert await l1_cache.get("k2") == "v2"


@pytest.mark.asyncio
async def test_multi_level_cache_ttl(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test ttl delegates to L2 since L1 is local/ephemeral."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)
    l2_cache.ttl.return_value = 300
    assert await cache.ttl("key1") == 300
    l2_cache.ttl.assert_called_once_with("key1")


@pytest.mark.asyncio
async def test_multi_level_cache_get_miss_all(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test get returns None if both L1 and L2 miss."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)
    l2_cache.get.return_value = None

    assert await cache.get("missing") is None
    l2_cache.get.assert_called_once_with("missing")


@pytest.mark.asyncio
async def test_multi_level_cache_get_many_all_l1_hits(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test get_many returns early if all keys are found in L1."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)
    await l1_cache.set("k1", "v1")
    await l1_cache.set("k2", "v2")

    result = await cache.get_many(["k1", "k2"])
    assert result == {"k1": "v1", "k2": "v2"}
    l2_cache.get_many.assert_not_called()


@pytest.mark.asyncio
async def test_multi_level_cache_get_many_l2_miss(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test get_many correctly handles when L2 returns nothing."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)
    l2_cache.get_many.return_value = {}

    result = await cache.get_many(["missing"])
    assert result == {}
    l2_cache.get_many.assert_called_once_with(["missing"])


@pytest.mark.asyncio
async def test_multi_level_cache_delete_pattern(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test delete_pattern combines counts from L1 and L2."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)
    await l1_cache.set("test:1", "val")
    l2_cache.delete_pattern.return_value = 5

    count = await cache.delete_pattern("test:*")
    assert count == 5  # max(1, 5)
    l2_cache.delete_pattern.assert_called_once_with("test:*")
    assert await l1_cache.get("test:1") is None


@pytest.mark.asyncio
async def test_multi_level_cache_clear(
    l1_cache: MemoryCacheAdapter, l2_cache: AsyncMock
) -> None:
    """Test clear delegates to both layers."""
    cache = MultiLevelCacheAdapter(l1_cache, l2_cache)
    await cache.clear()
    l2_cache.clear.assert_called_once()
