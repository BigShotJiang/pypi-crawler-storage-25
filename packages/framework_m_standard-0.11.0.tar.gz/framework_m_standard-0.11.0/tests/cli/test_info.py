"""Tests for standard_info_plugin."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

from framework_m_standard.cli.info import standard_info_plugin
from rich.table import Table


def test_standard_info_plugin_no_env() -> None:
    """Test standard_info_plugin with no environment variables set."""
    table = Table()
    table.add_column = MagicMock()
    table.add_row = MagicMock()

    with patch.dict(os.environ, {}, clear=True):
        standard_info_plugin(table)

    # Check for default "In-Memory" or "NA" rows
    calls = [call.args[0] for call in table.add_row.call_args_list]
    assert "Database" in calls
    assert "In-Memory (Mock)" in [
        call.args[1]
        for call in table.add_row.call_args_list
        if call.args[0] == "Database"
    ]
    assert "Cache" in calls
    assert "NA" in [
        call.args[1] for call in table.add_row.call_args_list if call.args[0] == "Cache"
    ]
    assert "Events" in calls
    assert "In-Memory (Mock)" in [
        call.args[1]
        for call in table.add_row.call_args_list
        if call.args[0] == "Events"
    ]
    assert "Storage" in calls
    assert "NA" in [
        call.args[1]
        for call in table.add_row.call_args_list
        if call.args[0] == "Storage"
    ]
    assert "Jobs" in calls
    assert "In-Memory (Mock)" in [
        call.args[1] for call in table.add_row.call_args_list if call.args[0] == "Jobs"
    ]


def test_standard_info_plugin_with_env() -> None:
    """Test standard_info_plugin with environment variables set."""
    table = Table()
    table.add_column = MagicMock()
    table.add_row = MagicMock()

    env = {
        "DATABASE_URL": "postgresql://user:pass@localhost/db",
        "REDIS_URL": "redis://localhost:6379",
        "NATS_URL": "nats://localhost:4222",
        "STORAGE_BACKEND": "s3",
        "S3_BUCKET": "my-test-bucket",
    }

    with patch.dict(os.environ, env, clear=True):
        standard_info_plugin(table)

    # Check for configured rows
    rows = {call.args[0]: call.args[1] for call in table.add_row.call_args_list}
    assert rows["Database"] == "Configured (postgresql)"
    assert rows["Cache"] == "Configured (Redis)"
    assert rows["Events"] == "Configured (NATS)"
    assert rows["Storage"] == "S3 (my-test-bucket)"
    assert rows["Jobs"] == "Configured (NATS)"


def test_standard_info_plugin_local_storage() -> None:
    """Test standard_info_plugin with local storage backend."""
    table = Table()
    table.add_row = MagicMock()

    env = {
        "STORAGE_BACKEND": "local",
        "STORAGE_PATH": "/tmp/m_storage",  # nosec B108
    }

    with patch.dict(os.environ, env, clear=True):
        standard_info_plugin(table)

    rows = {call.args[0]: call.args[1] for call in table.add_row.call_args_list}
    assert rows["Storage"] == "Local (/tmp/m_storage)"
