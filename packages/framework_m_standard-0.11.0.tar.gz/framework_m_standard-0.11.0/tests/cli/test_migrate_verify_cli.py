"""Tests for the Migrate Verify CLI Integration."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_core.domain.migration_engine import ChangeType, RiskLevel, SchemaDiff
from framework_m_core.interfaces.introspection import ColumnMeta, TableMeta
from framework_m_standard.cli.migrate_verify import (
    get_introspection_adapter,
    run_verification,
    verify_migration_command,
)
from pydantic import BaseModel, Field


class MockUserDocType(BaseModel):
    """Mock DocType for testing schema generation."""

    id: int
    username: str = Field(max_length=50)
    is_active: bool


class TestVerifyMigrationCLI:
    """Test suite for the migrate verify CLI command."""

    @patch("framework_m_standard.cli.migrate_verify.run_verification")
    def test_verify_migration_safe(
        self, mock_run_verification: AsyncMock, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should print safe messages and exit 0 for safe changes."""
        # Mock the workflow to return a SAFE schema difference
        mock_run_verification.return_value = [
            SchemaDiff(
                change_type=ChangeType.ADD_COLUMN,
                risk=RiskLevel.SAFE,
                column_name="new_field",
                message="Adding new column 'new_field'. This is a safe operation.",
            )
        ]

        verify_migration_command(engine="sqlalchemy")

        captured = capsys.readouterr()
        assert "SAFE" in captured.out
        assert "Adding new column 'new_field'" in captured.out

    @patch("framework_m_standard.cli.migrate_verify.run_verification")
    def test_verify_migration_breaking(
        self, mock_run_verification: AsyncMock, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Should print actionable advice for breaking changes and exit with 1."""
        # Mock the workflow to return a BREAKING schema difference
        mock_run_verification.return_value = [
            SchemaDiff(
                change_type=ChangeType.DROP_COLUMN,
                risk=RiskLevel.BREAKING,
                column_name="old_field",
                message="Dropping column 'old_field'. This is a breaking change requiring ZDM backfill patterns.",
            )
        ]

        with pytest.raises(SystemExit) as exc:
            verify_migration_command(engine="sqlalchemy")

        # Breaking changes should fail the CI pipeline
        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "BREAKING" in captured.out
        assert "ZDM backfill patterns" in captured.out

    @patch("framework_m_standard.cli.migrate_verify.get_introspection_adapter")
    @patch("framework_m_standard.cli.migrate_verify.run_verification")
    def test_verify_migration_respects_engine_flag(
        self, mock_run_verification: AsyncMock, mock_get_adapter: AsyncMock
    ) -> None:
        """Should resolve the correct introspection adapter based on the --engine flag."""
        mock_run_verification.return_value = []

        # Mock the adapter factory to return a dummy adapter
        mock_adapter = AsyncMock()
        mock_get_adapter.return_value = mock_adapter

        # Test with default engine (sqlalchemy)
        verify_migration_command(engine="sqlalchemy")
        mock_get_adapter.assert_called_with("sqlalchemy")

        # Test with specific engine override (e.g., motor)
        verify_migration_command(engine="motor")
        mock_get_adapter.assert_called_with("motor")

    @patch("framework_m_standard.cli.migrate_verify.importlib.metadata.entry_points")
    def test_get_introspection_adapter_success(self, mock_eps: MagicMock) -> None:
        """Should correctly find and load the adapter from entry points."""
        mock_ep = MagicMock()
        mock_ep.name = "sqlalchemy"
        mock_ep.load.return_value = "MockSQLAlchemyAdapterClass"
        mock_eps.return_value = [mock_ep]

        adapter = get_introspection_adapter("sqlalchemy")
        assert adapter == "MockSQLAlchemyAdapterClass"
        mock_ep.load.assert_called_once()


class TestRunVerification:
    """Test suite for the run_verification logic."""

    @pytest.mark.asyncio
    @patch("framework_m_core.config.load_config")
    @patch("framework_m_core.registry.MetaRegistry")
    @patch("framework_m_standard.adapters.db.connection.ConnectionFactory")
    async def test_run_verification_empty_db(
        self,
        mock_conn_factory_cls: MagicMock,
        mock_meta_registry_cls: MagicMock,
        mock_load_config: MagicMock,
    ) -> None:
        """Test verification when database has no tables."""
        mock_load_config.return_value = {}

        mock_registry = MagicMock()
        mock_meta_registry_cls.get_instance.return_value = mock_registry
        mock_registry.list_doctypes.return_value = ["User"]
        mock_registry.get_doctype.return_value = MockUserDocType

        mock_conn_factory = MagicMock()
        mock_conn_factory_cls.return_value = mock_conn_factory
        mock_conn_factory.dispose_all = AsyncMock()

        mock_adapter = AsyncMock()
        mock_adapter.introspect_database.return_value = []
        mock_adapter_class = MagicMock(return_value=mock_adapter)

        diffs = await run_verification(mock_adapter_class, apps="auth, users")

        assert len(diffs) > 0
        # Since table is empty, all columns should be ADD_COLUMN
        assert any(
            d.column_name == "id" and d.change_type == ChangeType.ADD_COLUMN
            for d in diffs
        )
        assert any(
            d.column_name == "username" and d.change_type == ChangeType.ADD_COLUMN
            for d in diffs
        )
        assert any(
            d.column_name == "is_active" and d.change_type == ChangeType.ADD_COLUMN
            for d in diffs
        )

        mock_registry.load_apps.assert_called_with(["auth", "users"])
        mock_conn_factory.dispose_all.assert_called_once()

    @pytest.mark.asyncio
    @patch("framework_m_core.config.load_config")
    @patch("framework_m_core.registry.MetaRegistry")
    @patch("framework_m_standard.adapters.db.connection.ConnectionFactory")
    async def test_run_verification_existing_db(
        self,
        mock_conn_factory_cls: MagicMock,
        mock_meta_registry_cls: MagicMock,
        mock_load_config: MagicMock,
    ) -> None:
        """Test verification when database has existing tables and handles type mapping."""
        mock_load_config.return_value = {
            "database": {"url": "sqlite+aiosqlite:///custom.db"}
        }

        mock_registry = MagicMock()
        mock_meta_registry_cls.get_instance.return_value = mock_registry
        mock_registry.list_doctypes.return_value = ["User"]
        mock_registry.get_doctype.return_value = MockUserDocType

        mock_conn_factory = MagicMock()
        mock_conn_factory_cls.return_value = mock_conn_factory
        mock_conn_factory.dispose_all = AsyncMock()

        mock_adapter = AsyncMock()
        mock_adapter.introspect_database.return_value = [
            TableMeta(
                name="user",
                columns=[
                    ColumnMeta(name="id", type="INTEGER", primary_key=True),
                    ColumnMeta(name="username", type="VARCHAR", max_length=255),
                    ColumnMeta(name="is_active", type="BOOLEAN"),
                ],
                indexes=[],
            )
        ]
        mock_adapter_class = MagicMock(return_value=mock_adapter)

        # Passing no apps and specific database_url to trigger those branches
        diffs = await run_verification(
            mock_adapter_class, database_url="sqlite:///override.db"
        )

        # We should have a diff because username max_length shrunk from 255 to 50
        assert len(diffs) == 1
        assert diffs[0].column_name == "username"
        assert diffs[0].change_type == ChangeType.ALTER_COLUMN
        assert diffs[0].risk == RiskLevel.WARNING

        mock_registry.load_apps.assert_not_called()
