"""Tests for migration environment validator."""

import os
from pathlib import Path
from unittest.mock import patch

from framework_m_standard.cli.migration_validator import validate_environment


def test_validate_environment_success_alembic_exists(tmp_path: Path) -> None:
    (tmp_path / "alembic").mkdir()
    errors = validate_environment(tmp_path, "sqlite+aiosqlite:///test.db")
    assert not errors


def test_validate_environment_success_skip_alembic(tmp_path: Path) -> None:
    errors = validate_environment(
        tmp_path, "sqlite+aiosqlite:///test.db", skip_alembic_check=True
    )
    assert not errors


def test_validate_environment_missing_alembic(tmp_path: Path) -> None:
    errors = validate_environment(tmp_path, "sqlite+aiosqlite:///test.db")
    assert len(errors) == 1
    assert "Alembic not initialized" in errors[0]


def test_validate_environment_invalid_sqlite_url(tmp_path: Path) -> None:
    (tmp_path / "alembic").mkdir()
    errors = validate_environment(tmp_path, "sqlite:///test.db")
    assert len(errors) == 1
    assert "Invalid database URL for async operation" in errors[0]


def test_validate_environment_invalid_url_from_env(tmp_path: Path) -> None:
    (tmp_path / "alembic").mkdir()
    with patch.dict(os.environ, {"DATABASE_URL": "sqlite:///env.db"}):
        errors = validate_environment(tmp_path)
        assert len(errors) == 1
        assert "Got: sqlite:///env.db" in errors[0]
