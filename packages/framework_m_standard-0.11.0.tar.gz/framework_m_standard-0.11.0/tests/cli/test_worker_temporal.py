"""Tests for Temporal Worker CLI integration."""

import asyncio
from unittest.mock import AsyncMock, patch

import pytest
from framework_m_standard.cli.worker import _run_temporal_worker_async


@pytest.mark.asyncio
async def test_run_temporal_worker_async() -> None:
    """_run_temporal_worker_async should start and stop the adapter cleanly."""

    with patch(
        "framework_m_standard.adapters.workflow.temporal_worker.TemporalWorkerAdapter"
    ) as mock_adapter_cls:
        mock_adapter = mock_adapter_cls.return_value
        mock_adapter.start = AsyncMock()
        mock_adapter.stop = AsyncMock()
        mock_adapter._host = "localhost:7233"
        mock_adapter._task_queue = "framework-m-workflows"

        # Simulate the user hitting Ctrl+C by making Event.wait raise CancelledError
        with patch("asyncio.Event.wait", new_callable=AsyncMock) as mock_wait:
            mock_wait.side_effect = asyncio.CancelledError()

            await _run_temporal_worker_async()

            mock_adapter.start.assert_called_once()
            mock_wait.assert_called_once()
            mock_adapter.stop.assert_called_once()
