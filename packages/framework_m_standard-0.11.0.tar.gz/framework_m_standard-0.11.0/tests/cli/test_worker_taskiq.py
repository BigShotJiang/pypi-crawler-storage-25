"""Tests for Taskiq/NATS worker implementations."""

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


class TestGetNatsUrl:
    """Tests for get_nats_url function."""

    def test_returns_default_when_no_env(self) -> None:
        """get_nats_url should return default when NATS_URL not set."""
        from framework_m_standard.cli.worker import DEFAULT_NATS_URL, get_nats_url

        with patch.dict(os.environ, {}, clear=True):
            env_backup = os.environ.pop("NATS_URL", None)
            try:
                result = get_nats_url()
                assert result == DEFAULT_NATS_URL
            finally:
                if env_backup:
                    os.environ["NATS_URL"] = env_backup

    def test_returns_env_value(self) -> None:
        """get_nats_url should return NATS_URL env value."""
        from framework_m_standard.cli.worker import get_nats_url

        with patch.dict(os.environ, {"NATS_URL": "nats://custom:1234"}):
            result = get_nats_url()
            assert result == "nats://custom:1234"


class TestGetBroker:
    """Tests for get_broker function."""

    def test_get_broker_calls_create_taskiq_broker(self) -> None:
        """get_broker should call create_taskiq_broker."""
        from framework_m_standard.cli.worker import get_broker

        with patch(
            "framework_m_standard.adapters.jobs.taskiq_adapter.create_taskiq_broker"
        ) as mock_create:
            mock_broker = MagicMock()
            mock_create.return_value = mock_broker
            result = get_broker()
            mock_create.assert_called_once()
            assert result is mock_broker

    def test_get_broker_passes_nats_url(self) -> None:
        """get_broker should pass nats_url to create_taskiq_broker."""
        from framework_m_standard.cli.worker import get_broker

        with (
            patch.dict(os.environ, {"NATS_URL": "nats://test:4222"}),
            patch(
                "framework_m_standard.adapters.jobs.taskiq_adapter.create_taskiq_broker"
            ) as mock_create,
        ):
            mock_create.return_value = MagicMock()
            get_broker()
            mock_create.assert_called_once_with(nats_url="nats://test:4222")


class TestDiscoverJobs:
    """Tests for discover_jobs function."""

    def test_discover_jobs_returns_list(self) -> None:
        """discover_jobs should return list of job names."""
        from framework_m_standard.cli.worker import discover_jobs

        with patch(
            "framework_m_standard.adapters.jobs.taskiq_adapter.get_global_registry"
        ) as mock_get:
            mock_registry = MagicMock()
            mock_registry.list.return_value = ["job1", "job2"]
            mock_get.return_value = mock_registry

            result = discover_jobs()
            assert result == ["job1", "job2"]

    def test_discover_jobs_empty(self) -> None:
        """discover_jobs should return empty list when no jobs."""
        from framework_m_standard.cli.worker import discover_jobs

        with patch(
            "framework_m_standard.adapters.jobs.taskiq_adapter.get_global_registry"
        ) as mock_get:
            mock_registry = MagicMock()
            mock_registry.list.return_value = []
            mock_get.return_value = mock_registry

            result = discover_jobs()
            assert result == []


class TestRunWorkerAsync:
    """Tests for _run_worker_async function."""

    @pytest.mark.asyncio
    async def test_run_worker_async_with_jobs(self) -> None:
        """_run_worker_async should print discovered jobs."""
        from framework_m_standard.cli.worker import _run_worker_async

        mock_broker = MagicMock()
        mock_broker.startup = AsyncMock()
        mock_broker.shutdown = AsyncMock()

        with (
            patch("framework_m_standard.cli.worker.discover_jobs") as mock_discover,
            patch("builtins.print") as mock_print,
            patch("taskiq.receiver.Receiver") as mock_receiver_cls,
        ):
            mock_discover.return_value = ["job1", "job2"]
            mock_receiver = MagicMock()
            mock_receiver.listen = AsyncMock(side_effect=KeyboardInterrupt)
            mock_receiver_cls.return_value = mock_receiver

            await _run_worker_async(mock_broker, concurrency=2)
            mock_print.assert_any_call("Discovered 2 jobs: job1, job2")

    @pytest.mark.asyncio
    async def test_run_worker_async_no_jobs(self) -> None:
        """_run_worker_async should print message when no jobs."""
        from framework_m_standard.cli.worker import _run_worker_async

        mock_broker = MagicMock()
        mock_broker.startup = AsyncMock()
        mock_broker.shutdown = AsyncMock()

        with (
            patch("framework_m_standard.cli.worker.discover_jobs") as mock_discover,
            patch("builtins.print") as mock_print,
            patch("taskiq.receiver.Receiver") as mock_receiver_cls,
        ):
            mock_discover.return_value = []
            mock_receiver = MagicMock()
            mock_receiver.listen = AsyncMock(side_effect=KeyboardInterrupt)
            mock_receiver_cls.return_value = mock_receiver

            await _run_worker_async(mock_broker)
            mock_print.assert_any_call(
                "No jobs discovered. Register jobs with @job decorator."
            )

    @pytest.mark.asyncio
    async def test_run_worker_async_creates_receiver(self) -> None:
        """_run_worker_async should create Receiver with correct params."""
        from framework_m_standard.cli.worker import _run_worker_async

        mock_broker = MagicMock()
        mock_broker.startup = AsyncMock()
        mock_broker.shutdown = AsyncMock()

        with (
            patch("framework_m_standard.cli.worker.discover_jobs", return_value=[]),
            patch("builtins.print"),
            patch("taskiq.receiver.Receiver") as mock_receiver_cls,
        ):
            mock_receiver = MagicMock()
            mock_receiver.listen = AsyncMock(side_effect=KeyboardInterrupt)
            mock_receiver_cls.return_value = mock_receiver

            await _run_worker_async(mock_broker, concurrency=8)
            mock_receiver_cls.assert_called_once_with(
                mock_broker, max_async_tasks=8, run_startup=False
            )

    @pytest.mark.asyncio
    async def test_run_worker_async_starts_and_shuts_down_broker(self) -> None:
        """_run_worker_async should start and shutdown broker."""
        from framework_m_standard.cli.worker import _run_worker_async

        mock_broker = MagicMock()
        mock_broker.startup = AsyncMock()
        mock_broker.shutdown = AsyncMock()

        with (
            patch("framework_m_standard.cli.worker.discover_jobs", return_value=[]),
            patch("builtins.print"),
            patch("taskiq.receiver.Receiver") as mock_receiver_cls,
        ):
            mock_receiver = MagicMock()
            mock_receiver.listen = AsyncMock(side_effect=KeyboardInterrupt)
            mock_receiver_cls.return_value = mock_receiver

            await _run_worker_async(mock_broker)
            mock_broker.startup.assert_called_once()
            mock_broker.shutdown.assert_called_once()


class TestRunWorker:
    """Tests for run_worker sync wrapper."""

    def test_run_worker_calls_asyncio_run(self) -> None:
        """run_worker should call asyncio.run on the taskiq runner."""
        from framework_m_standard.cli.worker import run_worker

        with patch("framework_m_standard.cli.worker.asyncio.run") as mock_run:
            run_worker(concurrency=4)
            mock_run.assert_called_once()


class TestTaskiqWorkerWrapper:
    """Tests for _run_taskiq_worker_wrapper."""

    @pytest.mark.asyncio
    async def test_wrapper_calls_broker_and_async_run(self) -> None:
        """_run_taskiq_worker_wrapper should initialize broker and start async runner."""
        from framework_m_standard.cli.worker import _run_taskiq_worker_wrapper

        with (
            patch("framework_m_standard.cli.worker.get_broker") as mock_get_broker,
            patch(
                "framework_m_standard.cli.worker._run_worker_async"
            ) as mock_run_async,
        ):
            mock_broker = MagicMock()
            mock_get_broker.return_value = mock_broker
            await _run_taskiq_worker_wrapper(concurrency=6)
            mock_get_broker.assert_called_once()
            mock_run_async.assert_called_once_with(mock_broker, 6)
