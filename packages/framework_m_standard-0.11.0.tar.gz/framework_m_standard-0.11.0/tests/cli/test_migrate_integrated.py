"""Integrated tests for Migration CLI and Hooks."""

import os
from unittest.mock import MagicMock, patch

import pytest
from framework_m_core.registry import MetaRegistry
from framework_m_standard.cli.migrate import all_command, sync_command


@pytest.fixture
def registry():
    reg = MetaRegistry.get_instance()
    reg.clear()
    return reg


class TestMigrateIntegrated:
    """Integrated tests for migrate CLI."""

    def test_sync_command_executes_hooks(self, tmp_path, registry):
        """sync_command should discover and execute app hooks."""
        # 1. Setup mock app with hooks
        app_name = "test_app_hooks"
        mock_hooks = MagicMock()

        # Mock the module for discovery
        mock_module = MagicMock()
        mock_module.before_sync = mock_hooks.before
        mock_module.after_sync = mock_hooks.after

        (tmp_path / "alembic").mkdir()
        with (
            patch("importlib.import_module", return_value=mock_module),
            patch("sqlalchemy.create_engine"),
            patch("framework_m_standard.cli.migrate.get_manager") as mock_get_manager,
        ):
            manager = mock_get_manager.return_value
            manager.auto_migrate.return_value = []

            sync_command(
                path=tmp_path,
                apps=app_name,
                database_url="sqlite+aiosqlite:///test.db",
            )

            # Verify hooks were called
            mock_hooks.before.assert_called_once()
            mock_hooks.after.assert_called_once()

    def test_all_command_flow(self, tmp_path):
        """all_command should sequence migrate and sync."""
        with (
            patch("framework_m_standard.cli.migrate.migrate") as mock_migrate,
            patch("framework_m_standard.cli.migrate.sync_command") as mock_sync,
        ):
            all_command(
                path=tmp_path, apps="app1,app2", database_url="sqlite:///test.db"
            )

            assert os.environ["INSTALLED_APPS"] == "app1,app2"
            mock_migrate.assert_called_once()
            mock_sync.assert_called_once()

    def test_sync_command_handles_import_error(self, tmp_path):
        """sync_command should skip apps with missing migrations module."""
        import importlib

        original_import = importlib.import_module
        (tmp_path / "alembic").mkdir()

        def side_effect(name, *args, **kwargs):
            if name == "missing_app.migrations":
                raise ImportError(f"Mocked ImportError for {name}")
            return original_import(name, *args, **kwargs)

        with (
            patch("importlib.import_module", side_effect=side_effect),
            patch("sqlalchemy.create_engine"),
            patch("framework_m_standard.cli.migrate.get_manager"),
        ):
            # Should not raise exception
            sync_command(
                path=tmp_path,
                apps="missing_app",
                database_url="sqlite+aiosqlite:///test.db",
            )

    def test_sync_command_dry_run_skips_after_hooks(self, tmp_path):
        """sync_command --dry-run should not execute after_sync hooks."""
        app_name = "test_app_dry"
        mock_hooks = MagicMock()
        mock_module = MagicMock()
        mock_module.after_sync = mock_hooks.after

        (tmp_path / "alembic").mkdir()
        with (
            patch("importlib.import_module", return_value=mock_module),
            patch("sqlalchemy.create_engine"),
            patch("framework_m_standard.cli.migrate.get_manager"),
        ):
            sync_command(
                path=tmp_path,
                apps=app_name,
                dry_run=True,
                database_url="sqlite+aiosqlite:///test.db",
            )

            # after_sync should NOT be called
            mock_hooks.after.assert_not_called()

    def test_all_command_failure(self, tmp_path):
        """all_command should raise if migrate fails."""
        with patch(
            "framework_m_standard.cli.migrate.migrate", side_effect=SystemExit(1)
        ):
            with pytest.raises(SystemExit) as exc:
                all_command(path=tmp_path, database_url="sqlite:///test.db")
            assert exc.value.code == 1

    def test_all_command_success_exit(self, tmp_path):
        """all_command should continue if migrate exits with 0."""
        with (
            patch(
                "framework_m_standard.cli.migrate.migrate", side_effect=SystemExit(0)
            ),
            patch("framework_m_standard.cli.migrate.sync_command") as mock_sync,
        ):
            all_command(path=tmp_path, database_url="sqlite:///test.db")
            assert mock_sync.called
