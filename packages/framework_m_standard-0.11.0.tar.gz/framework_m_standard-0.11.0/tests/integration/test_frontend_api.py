from unittest.mock import patch

import pytest

# This import will fail until the file is created, which is the TDD way.
from framework_m_standard.adapters.web.api.frontend import frontend_router
from litestar import Litestar
from litestar.testing import AsyncTestClient


@pytest.mark.asyncio
async def test_get_remotes_endpoint():
    """
    Test GET /api/v1/frontend/remotes endpoint.

    It should call the discovery service and return its results as JSON.
    """
    mock_remotes = {
        "wms_app": "/mfe/wms_app/1.2.3/remoteEntry.js",
        "crm_app": "/mfe/crm_app/2.0.0/remoteEntry.js",
    }

    # Patch the discovery function where it will be looked up.
    with patch(
        "framework_m_standard.adapters.web.api.frontend.discover_mfe_remotes",
        return_value=mock_remotes,
    ) as mock_discover:
        app = Litestar(route_handlers=[frontend_router])
        async with AsyncTestClient(app=app) as client:
            response = await client.get("/api/v1/frontend/remotes")
            assert response.status_code == 200
            assert response.json() == mock_remotes
            mock_discover.assert_called_once()
