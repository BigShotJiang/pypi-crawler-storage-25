import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_standard.adapters.web.app import create_app
from httpx import ASGITransport, AsyncClient
from litestar.status_codes import HTTP_200_OK, HTTP_502_BAD_GATEWAY


@pytest.fixture(autouse=True)
def proxy_env():
    """Enable proxying for all tests in this module."""
    os.environ["FRAMEWORK_M_MFE_PROXY_ENABLED"] = "true"
    yield
    # Use pop to avoid lint errors with del
    os.environ.pop("FRAMEWORK_M_MFE_PROXY_ENABLED", None)
    os.environ.pop("FRAMEWORK_M_MFE_REMOTES", None)


@pytest.mark.asyncio
async def test_mfe_proxy_success():
    """Test that the shell host correctly proxies MFE assets from a remote service."""
    remote_app_name = "remote_app"
    remote_origin = "http://remote-service:9000"
    mfe_path = "assets/remoteEntry.js"
    version = "1.0.0"

    # Mock remotes to return a remote URL
    remotes = {
        remote_app_name: f"{remote_origin}/mfe/{remote_app_name}/{version}/remoteEntry.js"
    }

    with patch(
        "framework_m_standard.adapters.web.desk_routes.discover_mfe_remotes",
        return_value=remotes,
    ):
        app = create_app(serve_static=True)

        # Mock ONLY the httpx.AsyncClient used inside desk_routes
        mock_response = AsyncMock()
        mock_response.content = b"remote-js-content"
        mock_response.status_code = HTTP_200_OK
        mock_response.headers = {"Content-Type": "application/javascript"}

        # Use a context manager mock for the client
        mock_client = AsyncMock()
        mock_client.get.return_value = mock_response
        mock_client.__aenter__.return_value = mock_client

        with patch(
            "framework_m_standard.adapters.web.desk_routes.httpx.AsyncClient",
            return_value=mock_client,
        ):
            async with AsyncClient(
                transport=ASGITransport(app=app), base_url="http://test"
            ) as client:
                response = await client.get(
                    f"/mfe/{remote_app_name}/{version}/{mfe_path}"
                )

                assert response.status_code == HTTP_200_OK
                assert response.content == b"remote-js-content"
                assert response.headers["Content-Type"] == "application/javascript"

                # Verify the upstream URL was constructed correctly
                expected_upstream_url = (
                    f"{remote_origin}/mfe/{remote_app_name}/{version}/{mfe_path}"
                )
                mock_client.get.assert_called_once_with(
                    expected_upstream_url, follow_redirects=True
                )


@pytest.mark.asyncio
async def test_mfe_proxy_error_fallback():
    """Test that proxy errors (e.g. connection refused) return 502."""
    remote_app_name = "broken_app"
    remote_origin = "http://broken-service:9999"

    remotes = {
        remote_app_name: f"{remote_origin}/mfe/{remote_app_name}/1.0.0/remoteEntry.js"
    }

    with patch(
        "framework_m_standard.adapters.web.desk_routes.discover_mfe_remotes",
        return_value=remotes,
    ):
        app = create_app(serve_static=True)

        # Mock httpx failure
        mock_client = AsyncMock()
        mock_client.get.side_effect = Exception("Connection refused")
        mock_client.__aenter__.return_value = mock_client

        with patch(
            "framework_m_standard.adapters.web.desk_routes.httpx.AsyncClient",
            return_value=mock_client,
        ):
            async with AsyncClient(
                transport=ASGITransport(app=app), base_url="http://test"
            ) as client:
                response = await client.get(
                    f"/mfe/{remote_app_name}/1.0.0/remoteEntry.js"
                )

                assert response.status_code == HTTP_502_BAD_GATEWAY
                assert b"Proxy Error" in response.content


@pytest.mark.asyncio
async def test_mfe_proxy_disabled():
    """Test that proxying is skipped if FRAMEWORK_M_MFE_PROXY_ENABLED is false."""
    os.environ["FRAMEWORK_M_MFE_PROXY_ENABLED"] = "false"

    remote_app_name = "remote_app"
    remotes = {
        remote_app_name: "http://remote-service/mfe/remote_app/1.0.0/remoteEntry.js"
    }

    with patch(
        "framework_m_standard.adapters.web.desk_routes.discover_mfe_remotes",
        return_value=remotes,
    ):
        app = create_app(serve_static=True)

        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.get(f"/mfe/{remote_app_name}/1.0.0/remoteEntry.js")

            # Should return 404 because it won't try to proxy
            assert response.status_code == 404
            assert b"Proxy disabled" in response.content


@pytest.mark.asyncio
async def test_mfe_no_remote_404():
    """Test that requesting a non-existent MFE returns 404."""
    with patch(
        "framework_m_standard.adapters.web.desk_routes.discover_mfe_remotes",
        return_value={},
    ):
        app = create_app(serve_static=True)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.get("/mfe/non_existent/1.0.0/file.js")
            assert response.status_code == 404


@pytest.mark.asyncio
async def test_mfe_local_fallback():
    """Test that local MFE remotes (relative URLs) fall back to local discovery."""
    remotes = {"local_app": "/mfe/local_app/1.0.0/remoteEntry.js"}

    with patch(
        "framework_m_standard.adapters.web.desk_routes.discover_mfe_remotes",
        return_value=remotes,
    ):
        app = create_app(serve_static=True)

        # Mock entry points to find the local app
        mock_ep = MagicMock()
        mock_ep.name = "local_app"
        mock_ep.module = "business_m.frontend"

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            # Mock the file system to "find" the file
            mock_path = MagicMock()
            mock_path.__truediv__.return_value = mock_path
            mock_path.is_file.return_value = True
            mock_path.read_bytes.return_value = b"local-content"

            with patch("importlib.resources.files", return_value=mock_path):
                async with AsyncClient(
                    transport=ASGITransport(app=app), base_url="http://test"
                ) as client:
                    response = await client.get("/mfe/local_app/1.0.0/remoteEntry.js")
                    assert response.status_code == 200
                    assert response.content == b"local-content"


@pytest.mark.asyncio
async def test_mfe_security_check():
    """Test that suspicious paths (..) are blocked."""
    remotes = {"local_app": "/mfe/local_app/1.0.0/remoteEntry.js"}

    with patch(
        "framework_m_standard.adapters.web.desk_routes.discover_mfe_remotes",
        return_value=remotes,
    ):
        app = create_app(serve_static=True)
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.get("/mfe/local_app/1.0.0/../../etc/passwd")
            assert response.status_code == 404
