"""Integration tests for Metadata API filtering."""

from __future__ import annotations

from typing import ClassVar

import pytest
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.registry import MetaRegistry
from framework_m_standard.adapters.web.metadata_router import metadata_router
from litestar.status_codes import HTTP_200_OK
from litestar.testing import TestClient


class VisibleDoc(BaseDocType):
    """DocType that should show in desk."""

    __doctype_name__: ClassVar[str] = "VisibleDoc"

    class Meta:
        show_in_desk = True


class HiddenDoc(BaseDocType):
    """DocType that should NOT show in desk."""

    __doctype_name__: ClassVar[str] = "HiddenDoc"

    class Meta:
        show_in_desk = False


@pytest.fixture(autouse=True)
def register_test_doctypes():
    """Register and unregister test DocTypes for each test."""
    registry = MetaRegistry.get_instance()
    # Clear registry to avoid DuplicateDocTypeError from previous tests
    registry.clear()

    # Use correct method from registry
    registry.register_doctype(VisibleDoc)
    registry.register_doctype(HiddenDoc)
    # Ensure discoverable key
    registry.register_meta_key("show_in_desk")
    yield


def test_list_doctypes_no_filter() -> None:
    """End-to-end test for listing all DocTypes without filter."""
    from litestar import Litestar

    app = Litestar(route_handlers=[metadata_router])
    with TestClient(app=app) as client:
        response = client.get("/api/meta/doctypes")
        assert response.status_code == HTTP_200_OK

        data = response.json()
        doc_info = next(d for d in data["doctypes"] if d["name"] == "VisibleDoc")

        # Verify metadata is now in the 'metadata' dict
        assert "metadata" in doc_info
        assert doc_info["metadata"]["show_in_desk"] is True


def test_list_doctypes_filter_show_in_desk() -> None:
    """End-to-end test for whitelisted, strict boolean filtering."""
    from litestar import Litestar

    app = Litestar(route_handlers=[metadata_router])
    with TestClient(app=app) as client:
        # 1. Filter for show_in_desk="true"
        response = client.get("/api/meta/doctypes", params={"show_in_desk": "true"})
        assert response.status_code == HTTP_200_OK

        data = response.json()
        names = [d["name"] for d in data["doctypes"]]
        assert "VisibleDoc" in names
        assert "HiddenDoc" not in names

        # 2. Filter for show_in_desk="false"
        response = client.get("/api/meta/doctypes", params={"show_in_desk": "false"})
        assert response.status_code == HTTP_200_OK

        data = response.json()
        names = [d["name"] for d in data["doctypes"]]
        # In HiddenDoc, show_in_desk is False
        assert "HiddenDoc" in names
        assert "VisibleDoc" not in names


def test_custom_metadata_discovery() -> None:
    """Verification for app-level metadata extensibility/discovery."""
    registry = MetaRegistry.get_instance()

    class CustomDoc(BaseDocType):
        __doctype_name__: ClassVar[str] = "CustomDoc"

        class Meta:
            wms_enabled = True

    registry.register_doctype(CustomDoc)

    from litestar import Litestar

    app = Litestar(route_handlers=[metadata_router])
    with TestClient(app=app) as client:
        # Before registration, wms_enabled should NOT be in the API metadata
        response = client.get("/api/meta/doctypes")
        data = response.json()
        custom_info = next(d for d in data["doctypes"] if d["name"] == "CustomDoc")
        assert "wms_enabled" not in custom_info["metadata"]

        # Register the key to the discovery whitelist
        registry.register_meta_key("wms_enabled")

        # After registration, it should appear and be filterable
        response = client.get("/api/meta/doctypes", params={"wms_enabled": "true"})
        data = response.json()
        names = [d["name"] for d in data["doctypes"]]
        assert "CustomDoc" in names

        custom_info = next(d for d in data["doctypes"] if d["name"] == "CustomDoc")
        assert custom_info["metadata"]["wms_enabled"] is True
