from unittest.mock import MagicMock, NonCallableMagicMock, patch

import pytest

# The app factory is the system under test
from framework_m_standard.adapters.web.app import create_app
from litestar.testing import AsyncTestClient


# Helper for mocking entry points
class MockEntryPoint:
    def __init__(self, name, module):
        self.name = name
        self.module = module

    def load(self):
        # For this test, we don't need to actually load anything, just prevent the error
        return MagicMock()


@pytest.mark.asyncio
@patch("framework_m_standard.adapters.web.desk_routes.discover_active_shell")
async def test_serve_shell_index(mock_discover_shell):
    """Test that GET /desk/ serves the index.html from the active shell."""
    # The app factory does some rewriting, so we need to provide content that
    # includes the markers it looks for.
    mock_shell_content = (
        b"<html><body><script>__FRAMEWORK_CONFIG__</script></body></html>"
    )
    # Use NonCallableMagicMock for path objects to prevent MagicMock from
    # auto-generating AsyncMock children (which trigger RuntimeWarning in GC).
    mock_index_html = NonCallableMagicMock()
    mock_index_html.exists.return_value = True
    mock_index_html.is_file.return_value = True
    mock_index_html.read_bytes.return_value = mock_shell_content

    mock_shell_path = NonCallableMagicMock()
    mock_shell_path.__truediv__ = MagicMock(return_value=mock_index_html)
    mock_discover_shell.return_value = mock_shell_path

    app = create_app(serve_static=True)

    async with AsyncTestClient(app=app) as client:
        response = await client.get("/desk/")
        assert response.status_code == 200
        # Check that the OAuth provider injection happened
        assert b"globalThis.__FRAMEWORK_OAUTH_PROVIDERS__" in response.content
        mock_discover_shell.assert_called()


@pytest.mark.asyncio
async def test_serve_mfe_remote_success():
    """Test GET /mfe/{app}/{version}/remoteEntry.js serves file successfully."""
    mock_remote_content = b"// Mock remoteEntry.js"

    # Patch discovery to simulate an installed MFE app
    remotes = {"test_mfe": "/mfe/test_mfe/1.0.0/remoteEntry.js"}
    with (
        patch(
            "framework_m_standard.adapters.web.desk_routes.discover_mfe_remotes",
            return_value=remotes,
        ),
        patch(
            "framework_m_standard.adapters.web.desk_routes.importlib.metadata.entry_points",
            return_value=[
                MockEntryPoint(name="test_mfe", module="test_mfe_pkg.frontend")
            ],
        ),
        patch(
            "framework_m_standard.adapters.web.desk_routes.importlib.resources.files"
        ) as mock_files,
    ):
        mock_package_root = MagicMock()
        mock_file_path = MagicMock()
        mock_file_path.is_file.return_value = True
        mock_file_path.read_bytes.return_value = mock_remote_content
        mock_package_root.joinpath.return_value = mock_file_path
        # Handle path traversal via / operator: root / "static" / "mfe" / "remoteEntry.js"
        mock_package_root.__truediv__.return_value.__truediv__.return_value.__truediv__.return_value = mock_file_path
        mock_files.return_value = mock_package_root

        app = create_app(serve_static=True)

        async with AsyncTestClient(app=app) as client:
            response = await client.get("/mfe/test_mfe/1.0.0/remoteEntry.js")

            assert response.status_code == 200
            assert response.content == mock_remote_content
            assert "text/javascript" in response.headers["content-type"]
            mock_files.assert_called_once_with("test_mfe_pkg")


@pytest.mark.asyncio
async def test_serve_mfe_remote_not_found():
    """Test GET /mfe/{app}/{version}/remoteEntry.js returns 404 for unknown app."""
    # No entry points mocked, so no MFEs should be found
    with patch(
        "framework_m_standard.adapters.web.desk_routes.importlib.metadata.entry_points",
        return_value=[],
    ):
        app = create_app(serve_static=True)
        async with AsyncTestClient(app=app) as client:
            response = await client.get("/mfe/unknown_mfe/1.0.0/remoteEntry.js")
            assert response.status_code == 404
