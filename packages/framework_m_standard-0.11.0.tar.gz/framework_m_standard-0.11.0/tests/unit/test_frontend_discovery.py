import json
import os
from unittest.mock import MagicMock, patch

import pytest

# These imports will fail until the file is created, which is the TDD way.
from framework_m_standard.adapters.web.frontend_discovery import (
    discover_active_shell,
    discover_mfe_remotes,
)


# Mock EntryPoint class for typing and structure
class MockEntryPoint:
    def __init__(self, name, module):
        self.name = name
        self.module = module


@pytest.fixture(autouse=True)
def clear_env_vars():
    """Ensure a clean environment for each test."""
    original_env = os.environ.copy()
    for key in ["FRAMEWORK_M_STATIC_BASE_URL", "FRAMEWORK_M_ACTIVE_SHELL"]:
        if key in os.environ:
            del os.environ[key]
    yield
    os.environ.clear()
    os.environ.update(original_env)


def test_discover_mfe_remotes_empty():
    """Test that an empty dictionary is returned when no entry points are found."""
    with patch("importlib.metadata.entry_points", return_value=[]) as mock_eps:
        remotes = discover_mfe_remotes()
        assert remotes == {}
        mock_eps.assert_called_once_with(group="framework_m.frontend")


@patch("importlib.metadata.version")
@patch("importlib.resources.files")
@patch("importlib.metadata.entry_points")
def test_discover_mfe_remotes_local(mock_eps, mock_files, mock_version):
    """Test discovery of MFE remotes with relative URLs (local serving)."""
    mock_eps.return_value = [
        MockEntryPoint(name="wms_app", module="wms_app.frontend:plugin"),
        MockEntryPoint(name="crm_app", module="crm_app.frontend:plugin"),
    ]
    mock_version.side_effect = lambda pkg: {"wms_app": "1.2.3", "crm_app": "2.0.0"}.get(
        pkg
    )

    mock_mfe_dir = MagicMock()
    mock_remote_entry = MagicMock()
    mock_remote_entry.is_file.return_value = True
    mock_mfe_dir.__truediv__.return_value = mock_remote_entry
    mock_files.return_value = mock_mfe_dir

    remotes = discover_mfe_remotes()

    assert "FRAMEWORK_M_STATIC_BASE_URL" not in os.environ
    assert remotes == {
        "wms_app": "/mfe/wms_app/1.2.3/remoteEntry.js",
        "crm_app": "/mfe/crm_app/2.0.0/remoteEntry.js",
    }
    mock_eps.assert_called_once_with(group="framework_m.frontend")
    assert mock_version.call_count == 2
    mock_version.assert_any_call("wms_app")
    mock_version.assert_any_call("crm_app")


@patch("importlib.metadata.version")
@patch("importlib.resources.files")
@patch("importlib.metadata.entry_points")
def test_discover_mfe_remotes_cdn(mock_eps, mock_files, mock_version):
    """Test discovery of MFE remotes with an absolute CDN URL."""
    cdn_url = "https://cdn.example.com"
    os.environ["FRAMEWORK_M_STATIC_BASE_URL"] = cdn_url

    mock_eps.return_value = [
        MockEntryPoint(name="wms_app", module="wms_app.frontend:plugin")
    ]
    mock_version.return_value = "1.2.3"

    mock_mfe_dir = MagicMock()
    mock_remote_entry = MagicMock()
    mock_remote_entry.is_file.return_value = True
    mock_mfe_dir.__truediv__.return_value = mock_remote_entry
    mock_files.return_value = mock_mfe_dir

    remotes = discover_mfe_remotes()

    assert remotes == {
        "wms_app": f"{cdn_url}/mfe/wms_app/1.2.3/remoteEntry.js",
    }
    mock_version.assert_called_once_with("wms_app")


@patch("importlib.resources.files")
@patch("importlib.metadata.entry_points")
def test_discover_mfe_remotes_skips_if_file_missing(mock_eps, mock_files):
    """Test that a plugin is skipped if its remoteEntry.js is not found."""
    mock_eps.return_value = [
        MockEntryPoint(name="wms_app", module="wms_app.frontend:plugin")
    ]

    mock_mfe_dir = MagicMock()
    mock_remote_entry = MagicMock()
    mock_remote_entry.is_file.return_value = False  # Key part of this test
    mock_mfe_dir.__truediv__.return_value = mock_remote_entry
    mock_files.return_value = mock_mfe_dir

    remotes = discover_mfe_remotes()

    assert remotes == {}


@patch("importlib.metadata.entry_points")
def test_discover_shell_default(mock_eps):
    """Test that the bundled desk shell is returned by default."""
    mock_eps.side_effect = lambda group: (
        [] if group == "framework_m.shell" else [MockEntryPoint("a", "b")]
    )

    with patch("importlib.resources.files") as mock_files:
        mock_path = MagicMock()
        mock_path.is_dir.return_value = True
        mock_files.return_value = mock_path

        shell_path = discover_active_shell()

        mock_files.assert_called_once_with("framework_m_standard")
        assert shell_path == mock_path / "static"


@patch("importlib.metadata.entry_points")
def test_discover_shell_custom(mock_eps):
    """Test that a custom shell is returned when an entry point is registered."""
    shell_ep = MockEntryPoint(name="my_erp", module="my_erp.frontend:shell")
    mock_eps.return_value = [shell_ep]

    with patch("importlib.resources.files") as mock_files:
        mock_path = MagicMock()
        mock_path.is_dir.return_value = True
        mock_files.return_value = mock_path

        shell_path = discover_active_shell()

        mock_eps.assert_called_once_with(group="framework_m.shell")
        mock_files.assert_called_once_with("my_erp")
        assert shell_path == mock_path / "static"


@patch("importlib.metadata.entry_points")
def test_discover_shell_conflict_raises_error(mock_eps):
    """Test that a ValueError is raised if multiple shells are registered."""
    mock_eps.return_value = [
        MockEntryPoint(name="my_erp", module="my_erp.frontend:shell"),
        MockEntryPoint(name="business_m", module="business_m.frontend:shell"),
    ]

    with pytest.raises(
        ValueError, match="Multiple 'framework_m.shell' entry points found"
    ):
        discover_active_shell()


@patch("importlib.metadata.entry_points")
def test_discover_shell_conflict_resolved_by_env_var(mock_eps):
    """Test that an environment variable can resolve a multi-shell conflict."""
    os.environ["FRAMEWORK_M_ACTIVE_SHELL"] = "business_m"
    mock_eps.return_value = [
        MockEntryPoint(name="my_erp", module="my_erp.frontend:shell"),
        MockEntryPoint(name="business_m", module="business_m.frontend:shell"),
    ]

    with patch("importlib.resources.files") as mock_files:
        mock_path = MagicMock()
        mock_path.is_dir.return_value = True
        mock_files.return_value = mock_path

        shell_path = discover_active_shell()

        mock_files.assert_called_once_with("business_m")
        assert shell_path == mock_path / "static"


def test_discover_mfe_remotes_from_env_json():
    """Test that remotes are loaded from FRAMEWORK_M_MFE_REMOTES environment variable."""
    extra_remotes = {
        "external_app": "http://external-service:8000/mfe/external_app/1.0.0/remoteEntry.js"
    }
    os.environ["FRAMEWORK_M_MFE_REMOTES"] = json.dumps(extra_remotes)

    with patch("importlib.metadata.entry_points", return_value=[]):
        remotes = discover_mfe_remotes()
        assert remotes["external_app"] == extra_remotes["external_app"]


def test_discover_mfe_remotes_from_env_base64():
    """Test that remotes are loaded from Base64-encoded FRAMEWORK_M_MFE_REMOTES."""
    import base64

    extra_remotes = {"b64_app": "http://b64-service:8000/remoteEntry.js"}
    b64_data = base64.b64encode(json.dumps(extra_remotes).encode()).decode()
    os.environ["FRAMEWORK_M_MFE_REMOTES"] = b64_data

    with patch("importlib.metadata.entry_points", return_value=[]):
        remotes = discover_mfe_remotes()
        assert remotes["b64_app"] == extra_remotes["b64_app"]


def test_discover_mfe_remotes_from_file(tmp_path):
    """Test that remotes are loaded from a JSON file."""
    extra_remotes = {"file_app": "http://file-service:8000/remoteEntry.js"}
    config_file = tmp_path / "remotes.json"
    config_file.write_text(json.dumps(extra_remotes))
    os.environ["FRAMEWORK_M_MFE_REMOTES_FILE"] = str(config_file)

    with patch("importlib.metadata.entry_points", return_value=[]):
        remotes = discover_mfe_remotes()
        assert remotes["file_app"] == extra_remotes["file_app"]


def test_discover_mfe_remotes_invalid_config():
    """Test that invalid config in environment variables is gracefully ignored."""
    os.environ["FRAMEWORK_M_MFE_REMOTES"] = "invalid-json"
    remotes = discover_mfe_remotes()
    assert isinstance(remotes, dict)

    os.environ["FRAMEWORK_M_MFE_REMOTES"] = "eyI"  # Invalid Base64
    remotes = discover_mfe_remotes()
    assert isinstance(remotes, dict)


def test_discover_mfe_remotes_missing_mfe_file():
    """Test that entry points without a remoteEntry.js are skipped."""
    mock_ep = MagicMock()
    mock_ep.name = "missing_entry"
    mock_ep.module = "some_package.frontend"

    with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
        # Mocking importlib.resources.files to return a path that IS NOT a file
        mock_path = MagicMock()
        mock_path.__truediv__.return_value.__truediv__.return_value.__truediv__.return_value.is_file.return_value = False

        with patch("importlib.resources.files", return_value=mock_path):
            remotes = discover_mfe_remotes()
            assert "missing_entry" not in remotes
