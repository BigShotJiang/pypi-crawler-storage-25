"""Tests for BakeAugmentedModels bootstrap step."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from framework_m_core.interfaces.bootstrap import BootstrapProtocol
from framework_m_standard.bootstrap.bake_augmented_models import BakeAugmentedModels


class TestBakeAugmentedModels:
    """Test BakeAugmentedModels bootstrap step."""

    def test_name(self) -> None:
        """BakeAugmentedModels should have name 'bake_augmented_models'."""
        step = BakeAugmentedModels()
        assert step.name == "bake_augmented_models"

    def test_order(self) -> None:
        """BakeAugmentedModels should have order 25."""
        step = BakeAugmentedModels()
        assert step.order == 25

    def test_protocol_compliance(self) -> None:
        """BakeAugmentedModels should comply with BootstrapProtocol."""
        step = BakeAugmentedModels()
        assert isinstance(step, BootstrapProtocol)

    @pytest.mark.asyncio
    async def test_run_bakes_models(self) -> None:
        """run() should get MetaRegistry instance and call bake_augmented_models."""
        step = BakeAugmentedModels()
        mock_container = MagicMock()

        with patch("framework_m_core.registry.MetaRegistry") as MockMetaRegistry:
            mock_instance = MagicMock()
            MockMetaRegistry.get_instance.return_value = mock_instance
            await step.run(mock_container)
            MockMetaRegistry.get_instance.assert_called_once()
            mock_instance.bake_augmented_models.assert_called_once()
