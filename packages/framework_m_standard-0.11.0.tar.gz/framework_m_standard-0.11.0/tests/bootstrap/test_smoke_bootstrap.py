from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from framework_m_standard.bootstrap.sync_schema import SyncSchema


@pytest.mark.asyncio
async def test_sync_schema_task_smoke():
    task = SyncSchema()
    assert task.name == "sync_schema"

    # Mock dependencies
    with (
        patch("framework_m_core.registry.MetaRegistry") as mock_registry,
        patch("framework_m_standard.adapters.db.connection.ConnectionFactory"),
        patch("framework_m_standard.adapters.db.schema_mapper.SchemaMapper"),
    ):
        mock_registry.instance.get_doctypes.return_value = []

        # Mock container
        mock_container = MagicMock()
        mock_container.config.get.return_value = True

        # Should run without error
        await task.run(mock_container)


@pytest.mark.asyncio
async def test_sync_schema_skipped():
    from framework_m_standard.bootstrap.sync_schema import SyncSchema

    task = SyncSchema()

    mock_container = MagicMock()
    mock_container.config.get.return_value = False  # auto_sync_schema=False

    # Should return early
    await task.run(mock_container)


@pytest.mark.asyncio
async def test_sync_schema_no_engine():
    from framework_m_standard.bootstrap.sync_schema import SyncSchema

    task = SyncSchema()

    # Container has engine=None
    mock_container = MagicMock()
    mock_container.config.get.return_value = True
    mock_container.engine.return_value = None

    # Should return early with warning
    await task.run(mock_container)


@pytest.mark.asyncio
async def test_sync_schema_no_doctypes():
    from framework_m_standard.bootstrap.sync_schema import SyncSchema

    task = SyncSchema()

    mock_container = MagicMock()
    mock_container.config.get.return_value = True

    with patch("framework_m_core.registry.MetaRegistry.get_instance") as mock_reg_inst:
        mock_reg_inst.return_value.list_doctypes.return_value = []
        await task.run(mock_container)


@pytest.mark.asyncio
async def test_sync_schema_error_in_loop():
    from framework_m_standard.bootstrap.sync_schema import SyncSchema

    task = SyncSchema()

    mock_container = MagicMock()
    mock_container.config.get.return_value = True

    with (
        patch("framework_m_core.registry.MetaRegistry.get_instance") as mock_reg_inst,
        patch(
            "framework_m_standard.adapters.db.schema_mapper.SchemaMapper"
        ) as mock_mapper,
    ):
        mock_reg_inst.return_value.list_doctypes.return_value = ["Test"]
        mock_mapper.return_value.create_table.side_effect = Exception("Mapping failed")

        await task.run(mock_container)
