from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from framework_m_standard.bootstrap.init_adapters import InitAdapters


@pytest.mark.asyncio
async def test_init_adapters_run():
    task = InitAdapters()
    container = MagicMock()

    # 1. Test basic binding
    await task.run(container)

    assert container.repository.override.called
    assert container.session_factory.override.called
    assert container.schema_mapper.override.called


@pytest.mark.asyncio
async def test_init_adapters_overrides():
    task = InitAdapters()
    container = MagicMock()
    # Need to ensure container has these attributes so the code enters the override logic

    # Mock entry points for overrides
    mock_ep = MagicMock()
    mock_ep.name = "mongo"
    # Create a mock adapter class that has a __name__ attribute
    mock_adapter = type("MockAdapter", (), {"__name__": "MongoAdapter"})
    mock_ep.load.return_value = mock_adapter

    with patch("importlib.metadata.entry_points") as mock_eps:
        # Mock group search
        def get_eps(group=None, **kwargs):
            if group in (
                "framework_m.adapters.repository",
                "framework_m.adapters.unit_of_work",
                "framework_m.adapters.schema_mapper",
            ):
                return [mock_ep]
            return []

        mock_eps.side_effect = get_eps

        await task.run(container)

        # Verify overrides called
        assert container.repository.override.called
        assert container.unit_of_work.override.called
        assert container.schema_mapper.override.called


@pytest.mark.asyncio
async def test_init_adapters_exception_handling(capsys):
    task = InitAdapters()
    container = MagicMock()

    with patch("importlib.metadata.entry_points", side_effect=Exception("EP Error")):
        await task.run(container)

    captured = capsys.readouterr()
    assert "Warning: Failed to check entry point overrides" in captured.out


@pytest.mark.asyncio
async def test_init_adapters_no_attributes():
    task = InitAdapters()
    # container that lacks the attributes (to cover False branches of hasattr)
    container = object()
    await task.run(container)
    # Should not raise AttributeError
