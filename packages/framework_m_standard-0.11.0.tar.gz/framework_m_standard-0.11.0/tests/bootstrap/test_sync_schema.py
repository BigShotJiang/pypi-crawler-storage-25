"""Tests for SyncSchema bootstrap step."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from framework_m_standard.bootstrap.sync_schema import SyncSchema


@pytest.fixture
def sync_schema() -> SyncSchema:
    """Provide a SyncSchema instance."""
    return SyncSchema()


@pytest.mark.asyncio
async def test_skip_auto_sync(sync_schema: SyncSchema) -> None:
    """Should skip if auto_sync_schema is False."""
    container = MagicMock()
    container.config.get.return_value = False

    with patch("builtins.print") as mock_print:
        await sync_schema.run(container)

    mock_print.assert_called_with("[SyncSchema] Skipped (auto_sync_schema=False)")


@pytest.mark.asyncio
async def test_no_engine(sync_schema: SyncSchema) -> None:
    """Should skip with warning if no engine is available."""
    container = MagicMock()
    container.config.get.return_value = True
    del container.engine
    del container.config.engine

    with patch("builtins.print") as mock_print:
        await sync_schema.run(container)

    mock_print.assert_called_with(
        "[SyncSchema] Warning: No engine available, skipping schema sync"
    )


@pytest.mark.asyncio
async def test_engine_from_config(sync_schema: SyncSchema) -> None:
    """Should fallback to config.engine() if container.engine is missing."""
    container = MagicMock()
    container.config.get.return_value = True
    del container.engine  # Force fallback branch

    mock_engine = AsyncMock()
    container.config.engine.return_value = mock_engine

    with patch("framework_m_core.registry.MetaRegistry") as mock_meta_reg:
        mock_meta_reg.get_instance.return_value.list_doctypes.return_value = []

        with patch("builtins.print") as mock_print:
            await sync_schema.run(container)

    mock_print.assert_any_call(
        "[SyncSchema] No DocTypes registered, skipping schema sync"
    )


@pytest.mark.asyncio
async def test_sync_success_and_exception(sync_schema: SyncSchema) -> None:
    """Should create and register tables, handling individual failures gracefully."""
    container = MagicMock()
    container.config.get.return_value = True

    mock_engine = MagicMock()
    mock_conn = AsyncMock()
    mock_engine.begin.return_value.__aenter__.return_value = mock_conn
    mock_engine.begin.return_value.__aexit__.return_value = None
    container.engine.return_value = mock_engine

    with (
        patch("framework_m_core.registry.MetaRegistry") as mock_meta_reg,
        patch(
            "framework_m_standard.adapters.db.table_registry.TableRegistry"
        ) as mock_table_reg,
        patch(
            "framework_m_standard.adapters.db.schema_mapper.SchemaMapper"
        ) as mock_mapper_cls,
    ):
        mock_meta_inst = mock_meta_reg.get_instance.return_value
        mock_meta_inst.list_doctypes.return_value = ["GoodDoc", "BadDoc"]
        mock_meta_inst.get_doctype.side_effect = lambda n: n  # Just return the name

        mock_table_inst = mock_table_reg.return_value
        mock_mapper_inst = mock_mapper_cls.return_value

        mock_table = MagicMock()
        mock_table.name = "tab_good"

        def mock_create_table(doctype_class, metadata):
            if doctype_class == "BadDoc":
                raise ValueError("Simulated creation error")
            return mock_table

        mock_mapper_inst.create_table.side_effect = mock_create_table

        with patch("builtins.print") as mock_print:
            await sync_schema.run(container)

        # Verify successful registration
        mock_table_inst.register_table.assert_called_once_with("GoodDoc", mock_table)

        # Verify printed output
        mock_print.assert_any_call("[SyncSchema] Creating tables for 2 DocTypes...")
        mock_print.assert_any_call("[SyncSchema]   ✓ GoodDoc -> tab_good")
        mock_print.assert_any_call(
            "[SyncSchema]   ✗ BadDoc - Error: Simulated creation error"
        )
        mock_print.assert_any_call("[SyncSchema] Schema sync complete (2 DocTypes)")

        # Verify engine sync execution
        mock_engine.begin.assert_called_once()
        mock_conn.run_sync.assert_called_once()
