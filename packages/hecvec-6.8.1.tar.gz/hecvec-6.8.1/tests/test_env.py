"""Tests for hecvec.env (no chroma/openai)."""
import os

import pytest

from hecvec.env import load_dotenv_if_available, load_openai_key


def test_load_openai_key_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """OPENAI_API_KEY is read from os.environ."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-key")
    assert load_openai_key() == "sk-test-key"


def test_load_openai_key_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    """Missing key returns None."""
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    assert load_openai_key() is None


def test_load_dotenv_if_available_no_error() -> None:
    """load_dotenv_if_available never raises (no-op if no dotenv)."""
    load_dotenv_if_available()
    load_dotenv_if_available("/nonexistent/.env")
