#!/usr/bin/env python3
"""Run slice pipeline. Usage: uv run python scripts/test_slice.py [path]"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

def main():

    from hecvec import Slicer
    path = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) >= 2 else (ROOT / "lotr.txt")
    
    slicer = Slicer(server="chroma_cloud", 
                    embedding_model = 'text-embedding-3-large')
                    #host="localhost", 
                    #port=8000)


    print("hecvec slicer config:", {"db": slicer.db, "host": slicer.host, "port": slicer.port})
    
    test = slicer.slice(path=path, 
                        collection_name="lotr_test2", 
                        chunking_method="text",
                        chunk_size=200, 
                        )
    print(test)

    collections = slicer.collections(server="chroma_cloud")
    for name, count in collections:
        print(f"{name}: {count} chunks")
    return 0

if __name__ == "__main__":
    sys.exit(main())
