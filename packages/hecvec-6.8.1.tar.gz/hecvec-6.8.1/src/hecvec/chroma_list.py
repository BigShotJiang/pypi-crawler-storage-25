"""
List Chroma collections. One module = one responsibility: inspect collections on a Chroma server.
Requires: pip install hecvec[chroma] (chromadb).
"""
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import chromadb

from hecvec.chroma_client import get_client, get_cloud_client
from hecvec.env import (
    load_chroma_cloud_database,
    load_chroma_cloud_key,
    load_chroma_cloud_tenant,
)

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8000


def list_collections(
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
    *,
    user: str | None = None,
    password: str | None = None,
    server: str | None = None,
    db: str | None = None,  # backward-compatible alias; default "chroma" when both omitted
    cloud_api_key: str | None = None,
    cloud_tenant: str | None = None,
    cloud_database: str | None = None,
    dotenv_path: str | Path | None = None,
) -> list[tuple[str, int]]:
    """
    List all collection names and their document counts.

    - Self-hosted: ``server="chroma"`` (default) — uses host:port (optional user/password).
    - Cloud: ``server="chroma_cloud"`` — API key and optional tenant/database; host/port are ignored.

    ``db=`` is an alias for ``server=`` (same resolution as ``Slicer``).
    """
    backend = db or server or "chroma"
    if backend == "chroma_cloud":
        key = cloud_api_key or load_chroma_cloud_key(dotenv_path)
        tenant = cloud_tenant or load_chroma_cloud_tenant(dotenv_path)
        database = cloud_database or load_chroma_cloud_database(dotenv_path)
        client = get_cloud_client(api_key=key, tenant=tenant, database=database)
        return list_collections_from_client(client)
    if backend != "chroma":
        raise ValueError(f"Unsupported server/db={backend!r}. Use 'chroma' or 'chroma_cloud'.")
    client = get_client(host=host, port=port, user=user, password=password)
    return list_collections_from_client(client)


def list_collections_from_client(client: "chromadb.api.client.Client") -> list[tuple[str, int]]:
    """
    List all collection names and their document counts from any Chroma client
    Returns [(name, count), ...].
    """
    return [(c.name, c.count()) for c in client.list_collections()]
