# Changelog


## v0.1.6 - (TBD)

### Features

- **Preflight Snowflake permission check for experiment tracking**: Added a preflight check in `Trainer` that verifies the Native App has the required Snowflake permissions before training starts. Attempts an authoritative grant-level check via `SHOW GRANTS ON DATABASE/SCHEMA`; if the current role lacks privilege, delegates to the Native App which uses a transient `CREATE EXPERIMENT` + `DROP` test. Returns a structured diagnostic result with six fields (`db_exists`, `schema_exists`, `usage_on_db`, `usage_on_schema`, `create_experiment`, `create_model`) and raises actionable errors with the exact `GRANT` statements needed to fix missing permissions.

- **Task-aware receptive-field check vs metadata graph diameter**: `Trainer` now computes the diameter `D` of the dataset's metadata (FK) graph and validates the configured `fanouts` depth against it. Repeated link prediction raises `ValueError` when `len(fanouts) < D - 1`; non-repeated link prediction warns below `ceil(D / 2)`; node tasks warn below `D`. The metadata graph is cached on `Dataset` after FK validation and reused for connectivity and diameter checks.

## v0.1.5 - (04-17-2026)

### Features

- **Unified engine job management**: Migrated internal SDK calls from the `experimental` to the `api` schema in the Native App (`cancel_job` and related operations), aligning with the stable engine API.

### Bug Fixes

- **Secure views always created for Native App inference**: Fixed a regression introduced in v0.1.4 where making `output_config` optional caused secure views to be skipped during Native App inference. Views are now always created when running inference via a Native App, since the SDK reads results through `source_views`.

---

## v0.1.4 - (04-15-2026)

### Features

- **GTable custom column types**: Added `column_dtypes` parameter to `GNNTable` to allow explicit dtype overrides for columns whose types cannot be inferred automatically. Accepts a mapping of column name to `ColumnDType` or string.

- **`output_config` optional in Trainer**: Made `output_config` an optional parameter in `Trainer`, simplifying instantiation when output configuration is not needed.

- **Token-expiry resilience for experiment tracking**: Added automatic retry logic when experiment tracking tokens expire during long-running training jobs.

### Bug Fixes

- **Reduced memory footprint during graph construction**: DataFrames are now released eagerly after use during graph construction, reducing peak memory consumption for large graphs.

- **Object type detection for catalog-integration tables**: Fixed incorrect object type detection for Snowflake catalog-integration tables that caused schema mismatches.

---

## v0.1.3 - (04-01-2026)

### Features

- **Overwrite results option for Snowflake table materialization**: Added `overwrite_results` parameter to `Trainer` to control whether existing Snowflake result tables are overwritten when materializing prediction outputs.

- **Training start logging and SQL diagnostics**: Training start events are now logged and Snowflake SQL library (sqlib) debug logs are captured, improving observability during training runs.

- **Model removal cleanup**: Improved model lifecycle management so all associated artifacts are fully cleaned up when a model version is deleted.

### Bug Fixes

- **Engine readiness detection**: Fixed an issue where the engine was incorrectly detected as not ready, causing training jobs to fail prematurely.

- **Grace drain and queue cleanup for job monitoring**: Job monitoring now performs a graceful drain and queue cleanup on shutdown, preventing resource leaks when stopping long-running jobs.

---

## v0.1.2 - (03-11-2026)

### Features

- **Diagnostics framework for job error handling**: Added a new `diagnostics` module with `PermissionDiagnostic` and `LogPatternDiagnostic` classes that detect known error patterns during job monitoring (log streaming and status checks) and provide enhanced, actionable error messages.

- **Database/Schema permission error detection**: Automatically detect Snowflake database and schema permission errors and raise `PermissionError` with detailed SQL grant instructions including the configured database/schema names.

- **Out-of-memory error detection**: Detect OOM errors (process exit code -9) during training and raise `MemoryError` with a recommendation to use a larger instance.

---

## v0.1.1 - (02-23-2026)

### Features

- **Skip table reference validation for non-Snowflake connectors**: Allow Snowflake connectors that read CSVs and not only tables by skipping table reference validation for non-Snowflake connector types.

---

## v0.1.0 - (02-11-2026)

### Features

- **Simplified model operations**: Removed `experiment_name` parameter from `delete_model()`, `register_model()`, and `predict()`. Experiment name is now automatically resolved from `model_run_id`.

- **Schema and dtype validation**: Added validation in `predict()` to ensure inference datasets match training dataset structure. New `align_dtypes` parameter automatically aligns data types when set to `True`.

- **Enhanced prediction logic**: Improved `predict()` method with better validation and support for three inference scenarios: using training dataset, custom test table, or new dataset.

- **Foreign key sorting**: Added automatic sorting of foreign keys in `TableSchema` for consistent schema ordering.

- **File locking**: Implemented thread-safe file locking for model registry and mapping file operations to prevent race conditions.

### Documentation

- Updated directory structure documentation in `config.py` for better clarity.

---

## v0.0.4 - (01-26-2026)

---

## v0.0.3 - (01-21-2026)

---

## v0.0.1 - (01-13-2026)

- First release of `GNN SDK`
