import re
from typing import Any, Dict, List, Optional

from relationalai_gnns.common.dataset_model import TaskMeta, TaskType


class CustomAttributeError(Exception):
    """Custom error for setting read-only properties."""

    pass


def extract_error_message(error_text):
    """
    Extract the core error message between 'Bad Request - error creating job:'
    and 'the request is not valid'
    """
    pattern = r"Bad Request - error creating job:?\s*(.*?)(?:the request is not valid|$)"
    match = re.search(pattern, error_text, re.DOTALL | re.IGNORECASE)

    if match:
        return match.group(1).strip()[:-1]
    else:
        return error_text


def wrap_user(payload: dict) -> dict:
    """Wraps a dictionary payload in a user / reference structure."""
    return {"user": payload, "system": {"references": []}}


def extract_all_table_paths(dataset_dict: dict) -> list[str]:
    """Extract all table source paths from tables and task sources."""
    # Extract table sources
    table_paths = [table["source"] for table in dataset_dict.get("tables", []) if "source" in table]

    # Extract and filter task sources (remove None values)
    task_sources = dataset_dict.get("task", {}).get("source", {})
    task_paths = [path for path in task_sources.values() if path is not None]
    # concatanate and remove duplicates and return
    # removing duplicates is needed since VALIDATE_AND_UPSERT_REFERENCES stored procedure
    # can not handle duplicate references
    return list(dict.fromkeys(table_paths + task_paths))


def build_view_name(table_path: str, job_id: str, app_name: str) -> str:
    """Convert table path to corresponding view name by inserting job_id."""
    _, _, table = table_path.split(".")
    job_suffix = job_id.replace("-", "_")
    return f"{app_name}.RESULTS.job_{job_suffix}_{table}"


def get_results_views(job_status: dict, app_name: str) -> dict:
    """Extract view names for predictions and embeddings from completed job."""
    if job_status["status"] != "COMPLETED":
        return None

    job_id = job_status["job_id"]
    export_paths = job_status.get("export_paths")
    if not export_paths:
        return None

    results_views = {}

    if "predictions" in export_paths:
        results_views["predictions"] = {build_view_name(export_paths["predictions"], job_id, app_name)}

    if "embeddings" in export_paths:
        results_views["embeddings"] = {
            node_id: build_view_name(path, job_id, app_name) for node_id, path in export_paths["embeddings"].items()
        }

    return results_views


########################################################
# Helper functions for comparing metadata schemas
########################################################


def _compare_tables(source_data: Dict, target_data: Dict) -> Dict[str, Any]:
    """Compare tables, columns, dtypes, candidate keys, and foreign keys."""
    source_tables = {t["name"]: t for t in source_data.get("tables", [])}
    target_tables = {t["name"]: t for t in target_data.get("tables", [])}

    tables_only_in_source = sorted(set(source_tables) - set(target_tables))
    tables_only_in_target = sorted(set(target_tables) - set(source_tables))
    common_tables = sorted(set(source_tables) & set(target_tables))

    columns_only_in_source: Dict[str, List[str]] = {}
    columns_only_in_target: Dict[str, List[str]] = {}
    table_type_mismatches: List[Dict[str, Any]] = []
    candidate_keys_only_in_source: Dict[str, List[str]] = {}
    candidate_keys_only_in_target: Dict[str, List[str]] = {}
    candidate_key_mismatches: List[Dict[str, Any]] = []
    foreign_keys_only_in_source: Dict[str, List[str]] = {}
    foreign_keys_only_in_target: Dict[str, List[str]] = {}
    foreign_key_mismatches: List[Dict[str, Any]] = []
    time_column_mismatches: List[Dict[str, Any]] = []

    for table_name in common_tables:
        src_table = source_tables[table_name]
        tgt_table = target_tables[table_name]

        # Compare table type
        if src_table.get("type") != tgt_table.get("type"):
            table_type_mismatches.append(
                {"table": table_name, "source_type": src_table.get("type"), "target_type": tgt_table.get("type")}
            )

        # Compare time_column
        if src_table.get("time_column") != tgt_table.get("time_column"):
            time_column_mismatches.append(
                {
                    "table": table_name,
                    "source_time_column": src_table.get("time_column"),
                    "target_time_column": tgt_table.get("time_column"),
                }
            )

        # Compare columns
        src_cols = {c["name"] for c in src_table.get("columns", [])}
        tgt_cols = {c["name"] for c in tgt_table.get("columns", [])}

        missing_in_target = sorted(src_cols - tgt_cols)
        missing_in_source = sorted(tgt_cols - src_cols)
        if missing_in_target:
            columns_only_in_source[table_name] = missing_in_target
        if missing_in_source:
            columns_only_in_target[table_name] = missing_in_source

        # Compare candidate_keys
        src_ckeys = {ck["name"]: ck.get("is_feature", False) for ck in src_table.get("candidate_keys", [])}
        tgt_ckeys = {ck["name"]: ck.get("is_feature", False) for ck in tgt_table.get("candidate_keys", [])}

        missing_ck_in_target = sorted(set(src_ckeys) - set(tgt_ckeys))
        missing_ck_in_source = sorted(set(tgt_ckeys) - set(src_ckeys))
        if missing_ck_in_target:
            candidate_keys_only_in_source[table_name] = missing_ck_in_target
        if missing_ck_in_source:
            candidate_keys_only_in_target[table_name] = missing_ck_in_source

        for ck_name in sorted(set(src_ckeys) & set(tgt_ckeys)):
            if src_ckeys[ck_name] != tgt_ckeys[ck_name]:
                candidate_key_mismatches.append(
                    {
                        "table": table_name,
                        "candidate_key": ck_name,
                        "source_is_feature": src_ckeys[ck_name],
                        "target_is_feature": tgt_ckeys[ck_name],
                    }
                )

        # Compare foreign_keys
        src_fkeys = {
            fk["name"]: (fk.get("is_feature", False), fk.get("link_to")) for fk in src_table.get("foreign_keys", [])
        }
        tgt_fkeys = {
            fk["name"]: (fk.get("is_feature", False), fk.get("link_to")) for fk in tgt_table.get("foreign_keys", [])
        }

        missing_fk_in_target = sorted(set(src_fkeys) - set(tgt_fkeys))
        missing_fk_in_source = sorted(set(tgt_fkeys) - set(src_fkeys))
        if missing_fk_in_target:
            foreign_keys_only_in_source[table_name] = missing_fk_in_target
        if missing_fk_in_source:
            foreign_keys_only_in_target[table_name] = missing_fk_in_source

        for fk_name in sorted(set(src_fkeys) & set(tgt_fkeys)):
            if src_fkeys[fk_name] != tgt_fkeys[fk_name]:
                foreign_key_mismatches.append(
                    {
                        "table": table_name,
                        "foreign_key": fk_name,
                        "source_is_feature": src_fkeys[fk_name][0],
                        "source_link_to": src_fkeys[fk_name][1],
                        "target_is_feature": tgt_fkeys[fk_name][0],
                        "target_link_to": tgt_fkeys[fk_name][1],
                    }
                )

    result: Dict[str, Any] = {}
    if tables_only_in_source:
        result["tables_only_in_source"] = tables_only_in_source
    if tables_only_in_target:
        result["tables_only_in_target"] = tables_only_in_target
    if columns_only_in_source:
        result["columns_only_in_source"] = columns_only_in_source
    if columns_only_in_target:
        result["columns_only_in_target"] = columns_only_in_target
    if table_type_mismatches:
        result["table_type_mismatches"] = table_type_mismatches
    if candidate_keys_only_in_source:
        result["candidate_keys_only_in_source"] = candidate_keys_only_in_source
    if candidate_keys_only_in_target:
        result["candidate_keys_only_in_target"] = candidate_keys_only_in_target
    if candidate_key_mismatches:
        result["candidate_key_mismatches"] = candidate_key_mismatches
    if foreign_keys_only_in_source:
        result["foreign_keys_only_in_source"] = foreign_keys_only_in_source
    if foreign_keys_only_in_target:
        result["foreign_keys_only_in_target"] = foreign_keys_only_in_target
    if foreign_key_mismatches:
        result["foreign_key_mismatches"] = foreign_key_mismatches
    if time_column_mismatches:
        result["time_column_mismatches"] = time_column_mismatches

    return result


def _compare_tasks(source_data: Dict, target_data: Dict) -> Dict[str, Any]:
    """
    Compare two task metadata dictionaries for inference-time compatibility, returning a dict describing any detected
    mismatches.

    The following are intentionally NOT checked, as they are irrelevant for
    inference:
        - Extra/unknown fields beyond the defined schema
        - Evaluation metric configuration
        - Label column (node tasks) or target entity column (link tasks),
          since these are only used for training labels

    The following fields ARE checked:
        - ``time_column``: must match by name; if mismatched, the column names
          are added to ``columns_only_in_source`` / ``columns_only_in_target``
        - ``current_time``: must match
        - ``task_type``: must match

        For link tasks (``LINK_PREDICTION``, ``REPEATED_LINK_PREDICTION``):
            - ``source_entity_column``: must match by name; if mismatched, the
              column names are tracked in the columns-only sets;
            - ``source_link_to``: must match

        For node tasks (all other task types):
            - ``target_entity_column``: must match by name; if mismatched, the
              column names are tracked in the columns-only sets;
            - ``target_link_to``: must match

    Args:
        source_data (Dict): Raw dictionary representation of the source task
            metadata, validated against ``TaskMeta``.
        target_data (Dict): Raw dictionary representation of the target task
            metadata, validated against ``TaskMeta``.

    Returns:
        Dict[str, Any]: An empty dict if the tasks are compatible, or a dict
        with one or more of the following keys if mismatches are found:

            - ``"field_mismatches"`` (List[Dict[str, Any]]): Field-level
              mismatches, each entry containing:
                - ``"field"`` (str): The name of the mismatched field
                - ``"source"``: The value in the source metadata
                - ``"target"``: The value in the target metadata
            - ``"columns_only_in_source"`` (Set[str]): Column names present in
              the source task metadata but not the target, derived from
              mismatched ``time_column`` or entity column names.
            - ``"columns_only_in_target"`` (Set[str]): Column names present in
              the target task metadata but not the source.
    """
    source_meta = TaskMeta.model_validate(source_data["task"])
    target_meta = TaskMeta.model_validate(target_data["task"])

    # data column mismatches
    columns_only_in_source = set()
    columns_only_in_target = set()

    field_mismatches = []
    if source_meta.time_column != target_meta.time_column:
        field_mismatches.append(
            {
                "field": "time_column",
                "source": source_meta.time_column,
                "target": target_meta.time_column,
            }
        )
        # since they are different we can add them to column differences if they exist
        if source_meta.time_column is not None:
            columns_only_in_source.add(source_meta.time_column)
        if target_meta.time_column is not None:
            columns_only_in_target.add(target_meta.time_column)

    if source_meta.current_time != target_meta.current_time:
        field_mismatches.append(
            {
                "field": "current_time",
                "source": source_meta.current_time,
                "target": target_meta.current_time,
            }
        )
    if source_meta.task_type != target_meta.task_type:
        field_mismatches.append(
            {
                "field": "task_type",
                "source": source_meta.task_type,
                "target": target_meta.task_type,
            }
        )

    # if we are dealing with link tasks then source entities must match
    if source_meta.task_type in [
        TaskType.LINK_PREDICTION,
        TaskType.REPEATED_LINK_PREDICTION,
    ]:
        if source_meta.source_entity_column != target_meta.source_entity_column:
            field_mismatches.append(
                {
                    "field": "source_entity_column",
                    "source": source_meta.source_entity_column,
                    "target": target_meta.source_entity_column,
                }
            )
            if source_meta.source_entity_column is not None:
                columns_only_in_source.add(source_meta.source_entity_column)
            if target_meta.source_entity_column is not None:
                columns_only_in_target.add(target_meta.source_entity_column)

        if source_meta.source_link_to != target_meta.source_link_to:
            field_mismatches.append(
                {
                    "field": "source_link_to",
                    "source": source_meta.source_link_to,
                    "target": target_meta.source_link_to,
                }
            )

    # else for node tasks target entities must match
    else:
        if source_meta.target_entity_column != target_meta.target_entity_column:
            field_mismatches.append(
                {
                    "field": "target_entity_column",
                    "source": source_meta.target_entity_column,
                    "target": target_meta.target_entity_column,
                }
            )
            if source_meta.target_entity_column is not None:
                columns_only_in_source.add(source_meta.target_entity_column)
            if target_meta.target_entity_column is not None:
                columns_only_in_target.add(target_meta.target_entity_column)

        if source_meta.target_link_to != target_meta.target_link_to:
            field_mismatches.append(
                {
                    "field": "target_link_to",
                    "source": source_meta.target_link_to,
                    "target": target_meta.target_link_to,
                }
            )
    result: Dict[str, Any] = {}
    if columns_only_in_source:
        result["columns_only_in_source"] = sorted(columns_only_in_source)
    if columns_only_in_target:
        result["columns_only_in_target"] = sorted(columns_only_in_target)
    if field_mismatches:
        result["field_mismatches"] = field_mismatches

    return result


def diff_metadata_schema(source_data: Dict, target_data: Dict) -> Dict[str, Any]:
    """
    Return schema differences between two metadata dicts: tables, columns, task.
    """
    table_diff = _compare_tables(source_data, target_data)
    task_diff = _compare_tasks(source_data, target_data)

    result = {**table_diff, **task_diff}
    return result


########################################################
# Helper functions for validating test table schemas
########################################################


def find_missing_test_table_required_columns(
    column_names: list,
    target_entity_column: Optional[str] = None,
    source_entity_column: Optional[str] = None,
    time_column: Optional[str] = None,
) -> list[str]:
    """Find and return list of missing required columns from test table."""
    missing_columns = []

    if target_entity_column is not None and target_entity_column not in column_names:
        missing_columns.append(target_entity_column)

    if source_entity_column is not None and source_entity_column not in column_names:
        missing_columns.append(source_entity_column)

    if time_column and time_column not in column_names:
        missing_columns.append(time_column)

    return missing_columns


########################################################
# Helper functions for comparing metadata dtypes
########################################################


def diff_metadata_dtypes(source_data: Dict, target_data: Dict) -> Dict[str, Any]:
    """Compare dtypes for tables and task columns between source and target metadata."""
    table_dtype_mismatches: List[Dict[str, str]] = []
    task_dtype_mismatches: List[Dict[str, str]] = []

    # Compare table column dtypes
    source_tables = {t["name"]: t for t in source_data.get("tables", [])}
    target_tables = {t["name"]: t for t in target_data.get("tables", [])}
    common_tables = sorted(set(source_tables) & set(target_tables))

    for table_name in common_tables:
        src_table = source_tables[table_name]
        tgt_table = target_tables[table_name]

        src_cols = {c["name"]: c["dtype"] for c in src_table.get("columns", [])}
        tgt_cols = {c["name"]: c["dtype"] for c in tgt_table.get("columns", [])}

        for col_name in sorted(set(src_cols) & set(tgt_cols)):
            if src_cols[col_name] != tgt_cols[col_name]:
                table_dtype_mismatches.append(
                    {
                        "table": table_name,
                        "column": col_name,
                        "source_dtype": src_cols[col_name],
                        "target_dtype": tgt_cols[col_name],
                    }
                )

    # Compare task column dtypes
    src_task = source_data.get("task") or {}
    tgt_task = target_data.get("task") or {}

    src_task_cols = {c["name"]: c["dtype"] for c in src_task.get("columns", [])}
    tgt_task_cols = {c["name"]: c["dtype"] for c in tgt_task.get("columns", [])}

    for col in sorted(set(src_task_cols) & set(tgt_task_cols)):
        if src_task_cols[col] != tgt_task_cols[col]:
            task_dtype_mismatches.append(
                {"column": col, "source_dtype": src_task_cols[col], "target_dtype": tgt_task_cols[col]}
            )

    result: Dict[str, Any] = {}
    if table_dtype_mismatches:
        result["table_dtype_mismatches"] = table_dtype_mismatches
    if task_dtype_mismatches:
        result["task_dtype_mismatches"] = task_dtype_mismatches

    return result


########################################################
# Helper functions for mapping dtypes
########################################################


def _create_dtype_map(source_data: Dict) -> Dict[str, Dict[str, str]]:
    """Create a mapping of table_name -> column_name -> dtype."""
    dtype_map = {}

    for table in source_data.get("tables", []):
        table_name = table["name"]
        dtype_map[table_name] = {}

        for column in table.get("columns", []):
            dtype_map[table_name][column["name"]] = column["dtype"]

    # Map task columns
    dtype_map["__task__"] = {}
    for column in source_data["task"]["columns"]:
        dtype_map["__task__"][column["name"]] = column["dtype"]

    return dtype_map


def _apply_dtype_map(target_data: Dict, dtype_map: Dict[str, Dict[str, str]]) -> None:
    """Apply dtype mapping to target data, updating column dtypes to match source."""
    # Update table columns
    for table in target_data.get("tables", []):
        table_name = table["name"]

        if table_name in dtype_map:
            for column in table.get("columns", []):
                col_name = column["name"]
                if col_name in dtype_map[table_name]:
                    old_dtype = column["dtype"]
                    new_dtype = dtype_map[table_name][col_name]
                    if old_dtype != new_dtype:
                        print(f"Aligning column '{table_name}.{col_name}' dtype: {old_dtype} → {new_dtype}")
                        column["dtype"] = new_dtype

    # Update task columns
    for column in target_data["task"]["columns"]:
        col_name = column["name"]
        if col_name in dtype_map["__task__"]:
            old_dtype = column["dtype"]
            new_dtype = dtype_map["__task__"][col_name]
            if old_dtype != new_dtype:
                print(f"  task.{col_name}: {old_dtype} -> {new_dtype}")
                column["dtype"] = new_dtype


def map_dtypes(source_data: Dict, target_data: Dict) -> None:
    """Map dtypes from source_data to target_data."""
    # Create dtype mapping from source
    dtype_map = _create_dtype_map(source_data)
    # Apply mapping to target
    _apply_dtype_map(target_data, dtype_map)
