import re
from typing import Optional

from relationalai_gnns.common.exceptions import ModelManagerError
from relationalai_gnns.common.job_models import PayloadTypes

from .api_request_handler import APIRequestHandler
from .config_trainer import ExperimentConfig
from .connector import BaseConnector


class ModelManager:
    """Manager for registering and handling models via the connector."""

    def __init__(self, connector: BaseConnector):
        """
        Initialize the ModelManager.

        Args:
            connector (BaseConnector): Connector to communicate with the backend service.
        """
        self.connector = connector
        self.api_handler = APIRequestHandler(connector)

    def list_models(self):
        """Get dataset metadata from MLflow artifacts."""

        payload = {
            "payload_type": PayloadTypes.REQUEST_LIST_MODELS,
        }
        return self.api_handler.make_request(payload)

    def delete_model(
        self,
        model_run_id: str,
        experiment_config: Optional[ExperimentConfig] = None,
        delete_experiment_run: bool = True,
    ):
        """
        Delete a model and its associated training artifacts.

        Args:
            model_run_id: Unique identifier of the model run to delete.
            experiment_config: Database and schema where the experiment is tracked.
                Required when ``delete_experiment_run=True``.
            delete_experiment_run: If ``True`` (default), the Snowflake experiment
                tracking run is also deleted.  Set to ``False`` to keep the run so
                that historical metrics, hyperparameters, etc. remain accessible.
                When ``False``, ``experiment_config`` may be omitted.
        """
        if delete_experiment_run and experiment_config is None:
            raise ModelManagerError("'experiment_config' is required when delete_experiment_run=True.")

        payload = {
            "payload_type": PayloadTypes.DELETE_MODEL,
            "model_run_id": model_run_id,
            "delete_experiment_run": delete_experiment_run,
            "experiment_database": experiment_config.database if experiment_config else None,
            "experiment_schema": experiment_config.schema if experiment_config else None,
        }
        try:
            result = self.api_handler.make_request(payload)
        except Exception as e:
            raise ModelManagerError(f"Failed to delete model '{model_run_id}': {e}") from e
        if isinstance(result, dict) and result.get("warnings"):
            for warning in result["warnings"]:
                print(f"Warning: {warning}")
        return result

    def delete_registered_model(
        self,
        model_name: str,
        version_name: str,
        experiment_config: ExperimentConfig,
    ):
        """
        Remove a registered model pointer without deleting the underlying training artifacts.

        Only the registry entry (models.json + Snowflake model version) is removed.
        The model directory and training artifacts are left intact.

        Args:
            model_name (str): Name of the registered model.
            version_name (str): Version name to remove.
            experiment_config (ExperimentConfig): Database and schema where the model is registered.
        """
        payload = {
            "payload_type": PayloadTypes.DELETE_REGISTERED_MODEL,
            "model_name": model_name,
            "version_name": version_name,
            "database_name": experiment_config.database,
            "schema_name": experiment_config.schema,
        }
        try:
            result = self.api_handler.make_request(payload)
        except Exception as e:
            raise ModelManagerError(
                f"Failed to delete registered model '{model_name}' version '{version_name}': {e}"
            ) from e
        if isinstance(result, dict) and result.get("warnings"):
            for warning in result["warnings"]:
                print(f"Warning: {warning}")
        return result

    def register_model(
        self,
        model_run_id: str,
        model_name: str,
        version_name: str,
        database_name: str,
        schema_name: str,
        comment: Optional[str] = None,
    ):
        """
        Register a trained model in the Model Registry.

        The model is registered under the specified name and version.
        Registration is only allowed if a valid `model_run_id` exists.
        Duplicate version names for a model are not allowed.

        Args:
            model_run_id (str): Unique identifier of the trained model run.
            model_name (str): Name to assign to the registered model.
            version_name (str): Version name for the model.
            database_name (str): Database where the model is registered.
            schema_name (str): Schema in the database.
            comment (Optional[str]): Optional comment for registration.

        Raises:
            ValueError: If the registration fails due to a request error or other exceptions.
        """
        payload = {
            "payload_type": PayloadTypes.REGISTER_MODEL,
            "model_name": model_name,
            "version_name": version_name,
            "database_name": database_name,
            "schema_name": schema_name,
            "model_run_id": model_run_id,
            "comment": comment,
        }

        try:
            registered_model = self.api_handler.make_request(payload)
            print(
                f"✅ Successfully registered model "
                f"'{registered_model['database_name']}.{registered_model['schema_name']}."
                f"{registered_model['model_name']}.{registered_model['version_name']}'"
            )
        except Exception as e:
            error_msg = re.sub(r"To auto-generate `version_name`, skip that argument\.", "", str(e)).strip()
            raise ModelManagerError(f"❌ Error during model registration: {error_msg}")
