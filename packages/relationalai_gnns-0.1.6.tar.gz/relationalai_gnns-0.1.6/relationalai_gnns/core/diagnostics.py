import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Optional, Type

from .config_trainer import ExperimentConfig


@dataclass(frozen=True)
class ErrorAction:
    """
    Defines the response to a specific log pattern.

    Frozen makes it immutable (hashable and safer).
    """

    message: str
    exception: Type[Exception]


class LogDiagnostic(ABC):
    """Abstract base class for detecting and handling specific categories of log errors."""

    @abstractmethod
    def detect_error(self, log_msg: str) -> bool:
        """
        Verifies if the specific error type exists in the log.

        Returns the subtype string (e.g., 'Database', 'OOM') if found, None otherwise.
        """
        pass

    @abstractmethod
    def enhance_error_message(self, log_msg: str) -> str:
        """
        Returns an enhanced message with instructions if the error is detected.

        Otherwise, returns the original log_msg.
        """
        pass

    @abstractmethod
    def check_and_raise(self, log_msg: str) -> None:
        """Checks if the error exists and raises the appropriate Exception with instructions."""
        pass


class PermissionDiagnostic(LogDiagnostic):
    """Handles Snowflake Database and Schema permission errors."""

    def __init__(self, experiment_config: Optional[ExperimentConfig] = None):
        self.experiment_config = experiment_config

    def detect_error(self, log_msg: str) -> bool:
        return self._detect_permission_error_type(log_msg) is not None

    def enhance_error_message(self, log_msg: str) -> str:
        """Enhance database or schema permission error messages with helpful instructions."""
        missing_type = self._detect_permission_error_type(log_msg)

        if missing_type:
            verification = self._generate_config_verification_message(missing_type)
            return (
                f"{missing_type} does not exist or the GNN RelationalAI Native App lacks permissions. "
                f"{verification} "
                f"If correct, grant the necessary permissions (USAGE on {missing_type.upper()}, "
                f"CREATE EXPERIMENT, and CREATE MODEL on SCHEMA) to the GNN RelationalAI Native App."
            )
        return log_msg

    def check_and_raise(self, log_msg: str) -> None:
        """
        Check if log message indicates a database or schema permission error and raise detailed instructions.

        :param log: The log message to check.
        :type log: str
        :raises PermissionError: If the log contains a database or schema "does not exist" error, with detailed
            instructions on how to grant the necessary permissions.
        """
        missing_type = self._detect_permission_error_type(log_msg)

        if missing_type:
            error_message = self._generate_permission_instructions(missing_type)
            raise PermissionError(error_message)

    def _detect_permission_error_type(self, log_msg: str) -> Optional[str]:
        """
        Detects if the log message indicates a database or schema permission error.

        :param log_msg: The log message to check.
        :type log_msg: str
        :returns: 'Database' if a database permission error is detected, 'Schema' if a schema permission error is
            detected, None otherwise.
        :rtype: Optional[str]
        """
        if re.search(r"Database\s+\S+\s+does not exist", log_msg, re.IGNORECASE):
            return "Database"
        if re.search(r"Schema\s+\S+\s+does not exist", log_msg, re.IGNORECASE):
            return "Schema"
        return None

    def _generate_config_verification_message(self, missing_type: str) -> str:
        """Generate verification message with config details if available."""
        experiment_location = ""
        if self.experiment_config:
            db_name = getattr(self.experiment_config, "database", None)
            schema_name = getattr(self.experiment_config, "schema", None)
            if db_name and schema_name:
                experiment_location = (
                    f" The experiment is configured to use database '{db_name}' and schema '{schema_name}'."
                )

        return f"{experiment_location} Verify that the {missing_type.lower()} name in your configuration is correct."

    def _generate_permission_instructions(self, missing_type: str) -> str:
        """Modular function to generate the SQL instruction block."""
        # Defaults
        app_placeholder = "<GNN_RAI_APP_NAME>"
        db_name = "<YOUR_DATABASE>"
        schema_name = "<YOUR_SCHEMA>"

        if self.experiment_config:
            if hasattr(self.experiment_config, "database"):
                db_name = self.experiment_config.database
            if hasattr(self.experiment_config, "schema"):
                schema_name = self.experiment_config.schema

        commands = []
        if missing_type == "Database":
            commands.append(f"GRANT USAGE ON DATABASE {db_name} TO APPLICATION {app_placeholder};")

        commands.extend(
            [
                f"GRANT USAGE ON SCHEMA {db_name}.{schema_name} TO APPLICATION {app_placeholder};",
                f"GRANT CREATE EXPERIMENT ON SCHEMA {db_name}.{schema_name} TO APPLICATION {app_placeholder};",
                f"GRANT CREATE MODEL ON SCHEMA {db_name}.{schema_name} TO APPLICATION {app_placeholder};",
            ]
        )

        header = (
            f"Experiment tracking failed because the target Snowflake {missing_type} does not exist or the "
            "GNN RelationalAI Native App lacks permissions."
        )

        verification = self._generate_config_verification_message(missing_type)

        intro = "To grant the necessary permissions, run the following commands in Snowflake:"

        cmd_block = "\n".join(f"  {cmd}" for cmd in commands)

        if self.experiment_config:
            footer = f"Replace {app_placeholder} with your actual application name."
        else:
            footer = f"Replace {app_placeholder} and placeholders with your actual values."

        return f"{header}\n\n{verification}\n\n{intro}\n\n{cmd_block}\n\n{footer}"


class LogPatternDiagnostic(LogDiagnostic):
    """A generic diagnostic that scans logs for specific text patterns defined in a dictionary and maps them to specific
    exceptions and human-readable messages."""

    # Dictionary mapping 'substring' -> ErrorAction Object
    # Keys = substrings to find (automatically normalized to lowercase)
    # Values = The action to take (message translation + specific exception raising)
    DEFAULT_PATTERNS: Dict[str, ErrorAction] = {
        "process exited with code -9": ErrorAction(
            message=(
                "The process ran out of memory (OOM) and was terminated by the system "
                "(Process exited with code -9). \n"
                "Recommendation: The current compute resources are insufficient for this dataset. "
                "If you selected a smaller machine type, please try switching to an instance with "
                "higher memory capacity."
            ),
            exception=MemoryError,
        ),
    }

    def __init__(self, patterns: Optional[Dict[str, ErrorAction]] = None):
        """
        Initializes the diagnostic with an optional pattern map.

        :param patterns: A dictionary mapping log substrings to ErrorAction objects. Patterns will be normalized to
            lowercase for case-insensitive matching. If None, the class defaults (DEFAULT_PATTERNS) are used.
        """
        # Use provided patterns or fallback to the class defaults
        source_patterns = patterns if patterns is not None else self.DEFAULT_PATTERNS
        # Normalize all pattern keys to lowercase for case-insensitive matching
        self.patterns = {pattern.lower(): action for pattern, action in source_patterns.items()}

    def _get_matching_action(self, log_msg: str) -> Optional[ErrorAction]:
        """
        Internal helper to find the ErrorAction for a given log message.

        :param log_msg: The raw log string to analyze.
        :return: The matching ErrorAction object if found, otherwise None.
        """
        log_lower = log_msg.lower()
        for pattern, action in self.patterns.items():
            if pattern in log_lower:
                return action
        return None

    def detect_error(self, log_msg: str) -> bool:
        """
        Verifies if any of the configured error patterns exist in the log.

        :param log_msg: The raw log string to analyze.
        :return: True if a known error pattern is found, False otherwise.
        """
        return self._get_matching_action(log_msg) is not None

    def enhance_error_message(self, log_msg: str) -> str:
        """
        Translates cryptic log messages into user-friendly explanations based on the configured patterns.

        :param log_msg: The raw log string to analyze.
        :return: The enhanced user-friendly message if a match is found; otherwise, returns the original log_msg.
        """
        action = self._get_matching_action(log_msg)
        if action:
            return action.message
        return log_msg

    def check_and_raise(self, log_msg: str) -> None:
        """
        Checks for known error patterns and raises the specific Exception type associated with that pattern.

        :param log_msg: The raw log string to analyze.
        :raises Exception: Raises the specific exception defined in the ErrorAction (e.g., MemoryError, ConnectionError)
            if a match is found.
        """
        action = self._get_matching_action(log_msg)
        if action:
            # Dynamically raise the specific exception type stored in the dataclass
            raise action.exception(action.message)
