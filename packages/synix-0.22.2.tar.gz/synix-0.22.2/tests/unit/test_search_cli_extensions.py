"""Unit tests for search CLI extensions: --step, --trace, --customer."""

from __future__ import annotations

import json

import pytest
from click.testing import CliRunner

from synix.cli import main
from synix.core.models import Artifact
from synix.search.indexer import SearchIndex
from tests.helpers.snapshot_factory import create_test_snapshot


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def populated_build_dir(tmp_path):
    """Build dir with a search index, artifacts, and provenance for testing."""
    build_dir = tmp_path / "build"
    build_dir.mkdir()

    # Transcript artifact
    t1 = Artifact(
        label="t-conv001",
        artifact_type="transcript",
        content="user: Tell me about machine learning\nassistant: Machine learning is a subset of AI",
        metadata={
            "source": "chatgpt",
            "source_conversation_id": "conv001",
            "title": "ML discussion",
            "date": "2024-03-15",
            "layer_name": "transcripts",
            "customer_id": "acme-corp",
        },
    )

    # Episode artifact
    ep1 = Artifact(
        label="ep-conv001",
        artifact_type="episode",
        content="In this conversation about machine learning, the user discussed fundamentals of AI",
        metadata={
            "source_conversation_id": "conv001",
            "date": "2024-03-15",
            "layer_name": "episodes",
            "customer_id": "acme-corp",
        },
    )

    # Another episode with different customer
    ep2 = Artifact(
        label="ep-conv002",
        artifact_type="episode",
        content="Discussion about machine learning applications in healthcare and diagnostics",
        metadata={
            "source_conversation_id": "conv002",
            "date": "2024-03-16",
            "layer_name": "episodes",
            "customer_id": "beta-inc",
        },
    )

    # Monthly rollup artifact
    m1 = Artifact(
        label="monthly-2024-03",
        artifact_type="rollup",
        content="In March 2024 the main themes were machine learning and AI development",
        metadata={
            "date_range": "2024-03",
            "layer_name": "monthly",
            "customer_id": "acme-corp",
        },
    )

    # Create snapshot with provenance
    create_test_snapshot(
        tmp_path,
        {
            "transcripts": [t1],
            "episodes": [ep1, ep2],
            "monthly": [m1],
        },
        parent_labels_map={
            "ep-conv001": ["t-conv001"],
            "monthly-2024-03": ["ep-conv001", "ep-conv002"],
        },
    )

    # Build search index
    db_path = build_dir / "search.db"
    index = SearchIndex(db_path)
    index.create()
    index.insert(ep1, "episodes", 1)
    index.insert(ep2, "episodes", 1)
    index.insert(m1, "monthly", 2)
    index.close()

    return build_dir


# --- Flag existence tests ---


def test_step_flag_exists(runner):
    """CLI accepts --step flag."""
    result = runner.invoke(main, ["search", "--help"])
    assert result.exit_code == 0
    assert "--step" in result.output


def test_trace_flag_exists(runner):
    """CLI accepts --trace flag."""
    result = runner.invoke(main, ["search", "--help"])
    assert result.exit_code == 0
    assert "--trace" in result.output


def test_customer_flag_exists(runner):
    """CLI accepts --customer flag."""
    result = runner.invoke(main, ["search", "--help"])
    assert result.exit_code == 0
    assert "--customer" in result.output


def test_projection_flag_exists(runner):
    """CLI accepts --projection flag."""
    result = runner.invoke(main, ["search", "--help"])
    assert result.exit_code == 0
    assert "--projection" in result.output


def test_projection_help_mentions_multiple_outputs(runner):
    """CLI help documents projection disambiguation for multiple outputs."""
    result = runner.invoke(main, ["search", "--help"])
    assert result.exit_code == 0
    assert "multiple local outputs" in result.output


# --- Functional tests ---


def test_step_filters_results(runner, populated_build_dir):
    """--step filters results to the specified layer."""
    result = runner.invoke(
        main,
        [
            "search",
            "machine learning",
            "--build-dir",
            str(populated_build_dir),
            "--step",
            "episodes",
        ],
    )
    assert result.exit_code == 0
    # Should have episode results but not monthly
    assert "episodes" in result.output
    assert "monthly" not in result.output or "monthly-2024-03" not in result.output


def test_step_and_layers_combine(runner, populated_build_dir):
    """--step and --layers combine their filter sets."""
    result = runner.invoke(
        main,
        [
            "search",
            "machine learning",
            "--build-dir",
            str(populated_build_dir),
            "--layers",
            "episodes",
            "--step",
            "monthly",
        ],
    )
    assert result.exit_code == 0
    # Should include both episode and monthly results
    assert "episodes" in result.output or "monthly" in result.output


def test_trace_shows_provenance(runner, populated_build_dir):
    """With --trace, output contains provenance tree."""
    result = runner.invoke(
        main,
        [
            "search",
            "machine learning",
            "--build-dir",
            str(populated_build_dir),
            "--trace",
        ],
    )
    assert result.exit_code == 0
    assert "Provenance" in result.output


def test_trace_shows_tree_characters(runner, populated_build_dir):
    """With --trace, output contains tree-drawing characters."""
    result = runner.invoke(
        main,
        [
            "search",
            "machine learning",
            "--build-dir",
            str(populated_build_dir),
            "--trace",
        ],
    )
    assert result.exit_code == 0
    # Rich Tree uses box-drawing characters; look for any parent artifact IDs
    # that would appear in the provenance tree
    assert "t-conv001" in result.output or "ep-conv001" in result.output


def test_customer_filters_results(runner, populated_build_dir):
    """--customer filters results by customer_id metadata."""
    result = runner.invoke(
        main,
        [
            "search",
            "machine learning",
            "--build-dir",
            str(populated_build_dir),
            "--customer",
            "acme-corp",
        ],
    )
    assert result.exit_code == 0
    # Should have results for acme-corp
    assert "ep-conv001" in result.output or "monthly-2024-03" in result.output
    # beta-inc's episode (ep-conv002) should NOT appear as a search result panel.
    # It may still appear in provenance trees since the monthly rollup depends on it.
    # Check that ep-conv002 does not appear as a result title/artifact line.
    # The result panels show "Artifact: <id>" — ep-conv002 should not be listed there.
    lines = result.output.split("\n")
    artifact_lines = [l for l in lines if "Artifact:" in l and "ep-conv002" in l]
    assert len(artifact_lines) == 0, "ep-conv002 should not appear as a search result"


def test_customer_no_match(runner, populated_build_dir):
    """--customer with no matching results shows appropriate message."""
    result = runner.invoke(
        main,
        [
            "search",
            "machine learning",
            "--build-dir",
            str(populated_build_dir),
            "--customer",
            "nonexistent-customer",
        ],
    )
    assert result.exit_code == 0
    assert "No results for customer" in result.output


def test_step_no_match(runner, populated_build_dir):
    """--step with a layer that has no matches returns no results."""
    result = runner.invoke(
        main,
        [
            "search",
            "machine learning",
            "--build-dir",
            str(populated_build_dir),
            "--step",
            "core",
        ],
    )
    assert result.exit_code == 0
    assert "No results for" in result.output


def test_customer_and_step_combined(runner, populated_build_dir):
    """--customer and --step can be combined."""
    result = runner.invoke(
        main,
        [
            "search",
            "machine learning",
            "--build-dir",
            str(populated_build_dir),
            "--step",
            "episodes",
            "--customer",
            "acme-corp",
        ],
    )
    assert result.exit_code == 0
    # Only acme-corp episodes should show
    assert "ep-conv002" not in result.output


def test_trace_without_provenance_data(runner, tmp_path):
    """--trace works gracefully when no provenance data exists for a result."""
    build_dir = tmp_path / "build"
    build_dir.mkdir()

    # Create a search index with an artifact that has no provenance
    artifact = Artifact(
        label="orphan-001",
        artifact_type="episode",
        content="An orphaned artifact about machine learning with no provenance",
        metadata={"layer_name": "episodes"},
    )
    db_path = build_dir / "search.db"
    index = SearchIndex(db_path)
    index.create()
    index.insert(artifact, "episodes", 1)
    index.close()

    result = runner.invoke(
        main,
        [
            "search",
            "machine learning",
            "--build-dir",
            str(build_dir),
            "--trace",
        ],
    )
    assert result.exit_code == 0
    # Should still show results, just without provenance tree
    assert "orphan-001" in result.output


def test_search_uses_custom_synix_output_path(runner, tmp_path):
    """Search resolves a custom SynixSearch DB path from projection metadata."""
    build_dir = tmp_path / "build"
    build_dir.mkdir()
    custom_db = build_dir / "outputs" / "memory.db"
    custom_db.parent.mkdir()

    artifact = Artifact(
        label="custom-001",
        artifact_type="episode",
        content="Custom Synix output contains machine learning notes",
        metadata={"layer_name": "episodes"},
    )
    index = SearchIndex(custom_db)
    index.create()
    index.insert(artifact, "episodes", 1)
    index.close()

    (build_dir / ".projection_cache.json").write_text(
        json.dumps(
            {
                "custom-search": {
                    "projection_type": "synix_search",
                    "db_path": "outputs/memory.db",
                }
            }
        )
    )

    result = runner.invoke(main, ["search", "machine learning", "--build-dir", str(build_dir)])
    assert result.exit_code == 0
    assert "custom-001" in result.output


def test_search_requires_projection_when_multiple_outputs_exist(runner, tmp_path):
    """Search asks for --projection when multiple local search outputs are present."""
    build_dir = tmp_path / "build"
    build_dir.mkdir()

    for rel_path, label in (("outputs/a.db", "alpha-001"), ("outputs/b.db", "beta-001")):
        db_path = build_dir / rel_path
        db_path.parent.mkdir(parents=True, exist_ok=True)
        artifact = Artifact(
            label=label,
            artifact_type="episode",
            content=f"{label} discusses machine learning",
            metadata={"layer_name": "episodes"},
        )
        index = SearchIndex(db_path)
        index.create()
        index.insert(artifact, "episodes", 1)
        index.close()

    (build_dir / ".projection_cache.json").write_text(
        json.dumps(
            {
                "alpha": {"projection_type": "synix_search", "db_path": "outputs/a.db"},
                "beta": {"projection_type": "synix_search", "db_path": "outputs/b.db"},
            }
        )
    )

    result = runner.invoke(main, ["search", "machine learning", "--build-dir", str(build_dir)])
    assert result.exit_code != 0
    assert "--projection" in result.output


def test_search_prefers_named_search_output_when_multiple_outputs_exist(runner, tmp_path):
    """Search defaults to the output named 'search' when several outputs exist."""
    build_dir = tmp_path / "build"
    build_dir.mkdir()

    archive_db = build_dir / "outputs" / "archive.db"
    archive_db.parent.mkdir(parents=True, exist_ok=True)
    archive_artifact = Artifact(
        label="archive-001",
        artifact_type="episode",
        content="Historical archive data",
        metadata={"layer_name": "episodes"},
    )
    archive_index = SearchIndex(archive_db)
    archive_index.create()
    archive_index.insert(archive_artifact, "episodes", 1)
    archive_index.close()

    preferred_db = build_dir / "outputs" / "search.db"
    preferred_artifact = Artifact(
        label="preferred-001",
        artifact_type="episode",
        content="Preferred search output contains machine learning notes",
        metadata={"layer_name": "episodes"},
    )
    preferred_index = SearchIndex(preferred_db)
    preferred_index.create()
    preferred_index.insert(preferred_artifact, "episodes", 1)
    preferred_index.close()

    (build_dir / ".projection_cache.json").write_text(
        json.dumps(
            {
                "archive": {"projection_type": "search_index", "db_path": "outputs/archive.db"},
                "search": {"projection_type": "synix_search", "db_path": "outputs/search.db"},
            }
        )
    )

    result = runner.invoke(main, ["search", "machine learning", "--build-dir", str(build_dir)])
    assert result.exit_code == 0
    assert "preferred-001" in result.output
    assert "archive-001" not in result.output
