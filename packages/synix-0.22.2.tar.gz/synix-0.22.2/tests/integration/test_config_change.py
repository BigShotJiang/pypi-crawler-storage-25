"""Integration tests — config change (monthly → topical rollups)."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from synix import FlatFile, Pipeline, SearchIndex, SearchSurface, Source
from synix.build.runner import run
from synix.ext import CoreSynthesis, EpisodeSummary, MonthlyRollup, TopicalRollup
from synix.search.index import SearchIndex as SearchIdx

FIXTURES_DIR = Path(__file__).parent.parent / "synix" / "fixtures"


@pytest.fixture
def source_dir(tmp_path):
    """Source directory with both export fixtures."""
    src = tmp_path / "exports"
    src.mkdir()
    shutil.copy(FIXTURES_DIR / "chatgpt_export.json", src / "chatgpt_export.json")
    shutil.copy(FIXTURES_DIR / "claude_export.json", src / "claude_export.json")
    return src


@pytest.fixture
def build_dir(tmp_path):
    return tmp_path / "build"


def _monthly_pipeline(build_dir: Path) -> Pipeline:
    """Pipeline with monthly rollups."""
    p = Pipeline("monthly-pipeline")
    p.build_dir = str(build_dir)
    p.llm_config = {"model": "claude-sonnet-4-20250514", "temperature": 0.3, "max_tokens": 1024}

    transcripts = Source("transcripts")
    episodes = EpisodeSummary("episodes", depends_on=[transcripts])
    monthly = MonthlyRollup("monthly", depends_on=[episodes])
    core = CoreSynthesis("core", depends_on=[monthly], context_budget=10000)

    p.add(transcripts, episodes, monthly, core)
    p.add(SearchIndex("memory-index", sources=[episodes, monthly, core], search=["fulltext"]))
    p.add(FlatFile("context-doc", sources=[core], output_path=str(build_dir / "context.md")))
    return p


def _topical_pipeline(build_dir: Path) -> Pipeline:
    """Pipeline with topical rollups instead of monthly."""
    p = Pipeline("topical-pipeline")
    p.build_dir = str(build_dir)
    p.llm_config = {"model": "claude-sonnet-4-20250514", "temperature": 0.3, "max_tokens": 1024}

    transcripts = Source("transcripts")
    episodes = EpisodeSummary("episodes", depends_on=[transcripts])
    topics = TopicalRollup("topics", depends_on=[episodes], config={"topics": ["programming", "machine-learning"]})
    core = CoreSynthesis("core", depends_on=[topics], context_budget=10000)

    p.add(transcripts, episodes, topics, core)
    p.add(SearchIndex("memory-index", sources=[episodes, topics, core], search=["fulltext"]))
    p.add(FlatFile("context-doc", sources=[core], output_path=str(build_dir / "context.md")))
    return p


def _surface_topical_pipeline(build_dir: Path) -> Pipeline:
    """Pipeline with a named search surface consumed by topical rollups."""
    p = Pipeline("surface-topical-pipeline")
    p.build_dir = str(build_dir)
    p.llm_config = {"model": "claude-sonnet-4-20250514", "temperature": 0.3, "max_tokens": 1024}

    transcripts = Source("transcripts")
    episodes = EpisodeSummary("episodes", depends_on=[transcripts])
    episode_search = SearchSurface("episode-search", sources=[episodes], modes=["fulltext"])
    topics = TopicalRollup(
        "topics",
        depends_on=[episodes],
        uses=[episode_search],
        config={"topics": ["programming", "machine-learning"]},
    )
    core = CoreSynthesis("core", depends_on=[topics], context_budget=10000)

    p.add(transcripts, episodes, episode_search, topics, core)
    p.add(FlatFile("context-doc", sources=[core], output_path=str(build_dir / "context.md")))
    return p


class TestConfigChange:
    def test_swap_monthly_to_topical(self, source_dir, build_dir, mock_llm):
        """Run monthly then topical — transcripts+episodes cached, topics+core rebuilt."""
        monthly = _monthly_pipeline(build_dir)
        result1 = run(monthly, source_dir=str(source_dir))
        assert result1.built > 0

        topical = _topical_pipeline(build_dir)
        result2 = run(topical, source_dir=str(source_dir))

        # Transcripts: Source layers always re-parse (built > 0)
        t_stats = next(s for s in result2.layer_stats if s.name == "transcripts")
        assert t_stats.built > 0

        # Episodes: all cached (same transcript content → same artifact IDs)
        e_stats = next(s for s in result2.layer_stats if s.name == "episodes")
        assert e_stats.built == 0
        assert e_stats.cached > 0

        # Topics: all built (new layer)
        topic_stats = next(s for s in result2.layer_stats if s.name == "topics")
        assert topic_stats.built > 0

        # Core: rebuilt (dependency changed)
        core_stats = next(s for s in result2.layer_stats if s.name == "core")
        assert core_stats.built > 0

    def test_search_results_differ(self, source_dir, build_dir, mock_llm):
        """Same query returns different results after config change."""
        from synix.build.refs import synix_dir_for_build_dir
        from synix.build.release_engine import execute_release

        synix_dir = synix_dir_for_build_dir(build_dir)
        release_dir = synix_dir / "releases" / "local"

        monthly = _monthly_pipeline(build_dir)
        run(monthly, source_dir=str(source_dir))
        execute_release(synix_dir, release_name="local")

        index1 = SearchIdx(release_dir / "search.db")
        results1 = index1.query("programming")
        ids1 = {r.label for r in results1}
        index1.close()

        topical = _topical_pipeline(build_dir)
        run(topical, source_dir=str(source_dir))
        execute_release(synix_dir, release_name="local")

        index2 = SearchIdx(release_dir / "search.db")
        results2 = index2.query("programming")
        ids2 = {r.label for r in results2}
        index2.close()

        # The rollup artifact IDs should differ (monthly-* vs topic-*)
        rollup_ids1 = {i for i in ids1 if i.startswith("monthly-")}
        rollup_ids2 = {i for i in ids2 if i.startswith("topic-")}
        assert rollup_ids1 != rollup_ids2

    def test_context_doc_differs(self, source_dir, build_dir, mock_llm):
        """context.md content changes after config change."""
        from synix.build.refs import synix_dir_for_build_dir
        from synix.build.release_engine import execute_release

        synix_dir = synix_dir_for_build_dir(build_dir)
        release_dir = synix_dir / "releases" / "local"

        monthly = _monthly_pipeline(build_dir)
        run(monthly, source_dir=str(source_dir))
        execute_release(synix_dir, release_name="local")
        content1 = (release_dir / "context.md").read_text()

        topical = _topical_pipeline(build_dir)
        run(topical, source_dir=str(source_dir))
        execute_release(synix_dir, release_name="local")
        content2 = (release_dir / "context.md").read_text()

        # The core memory is rebuilt with different inputs, so content
        # is the same mock text. What matters is both exist and the file is rewritten.
        assert len(content1) > 0
        assert len(content2) > 0

    def test_topical_rollup_uses_named_search_surface(self, source_dir, build_dir, mock_llm):
        """Named search surfaces materialize to .synix/work/surfaces/."""
        from synix.build.refs import synix_dir_for_build_dir

        pipeline = _surface_topical_pipeline(build_dir)
        run(pipeline, source_dir=str(source_dir))

        synix_dir = synix_dir_for_build_dir(build_dir)
        surface_db = synix_dir / "work" / "surfaces" / "episode-search.db"
        assert surface_db.exists()
        assert not (build_dir / "search.db").exists()

        index = SearchIdx(surface_db)
        results = index.query("programming", layers=["episodes"])
        index.close()

        assert len(results) > 0
        assert all(result.layer_name == "episodes" for result in results)
