"""Allow ``python -m Snowforge.FabricIntegration`` to launch the Fabric CLI."""

from .FabricCLI import main

main()
