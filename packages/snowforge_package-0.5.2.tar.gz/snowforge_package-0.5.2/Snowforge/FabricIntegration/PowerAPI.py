# Ansvarlig utvikler: Andreas Heggelund
# Spørsmål: fagområdedata@norsk-tipping.no

"""
Low-level HTTP client and URL builder for the Power BI / Fabric REST API.

This is the transport layer — it knows about endpoints and HTTP verbs,
but has no business logic.  ``FabricIntegration`` inherits from it and
adds the domain operations (pipelines, semantic models, report export).
"""

from __future__ import annotations

import requests
from ..AWSIntegration import AWSIntegration
from ..Logging import Debug


class PowerAPI:
    """Thin wrapper around the Power BI / Fabric REST API."""

    def __init__(self) -> None:
        self.URL_TEMPLATES: dict[str, str] = {
            "export": "https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/reports/{report_id}/ExportTo",
            "export_status": "https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/reports/{report_id}/exports/{export_id}",
            "export_file": "https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/reports/{report_id}/exports/{export_id}/file",
            "execute_query": "https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}",
            "get_report": "https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/reports/{report_id}",
            "get_reports": "https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/reports",
            "get_datasets": "https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/datasets",
            "get_pages": "https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/reports/{report_id}/pages",
            "get_workspaces": "https://api.powerbi.com/v1.0/myorg/groups",
            "get_parameters": "https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/reports/{report_id}/parameters",
            "update_pipeline": "https://api.fabric.microsoft.com/v1/workspaces/{workspaceId}/items/{itemId}/jobs/instances?jobType=Pipeline",
            "semantic_model_reload": "https://api.powerbi.com/v1.0/myorg/groups/{workspace_id}/datasets/{item_id}/refreshes",
            "get_semantic_models": "https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}/semanticModels",
        }

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    @staticmethod
    def get_secret_from_AWS(
        secret_name: str = "powerbi_refresh_token_secret",
        aws_profile: str = "default",
    ) -> str:
        """Retrieve an API token from AWS Secrets Manager."""
        AWSIntegration.initialize(profile=aws_profile)
        return AWSIntegration.get_secret(secret_name)

    # ------------------------------------------------------------------
    # URL builder
    # ------------------------------------------------------------------

    def get_url_for(
        self,
        operation: str,
        workspace_id: str = "",
        report_id: str = "",
        export_id: str = "",
        item_id: str = "",
    ) -> str:
        operation = operation.strip().lower()

        if operation not in self.URL_TEMPLATES:
            Debug.log(f"Unsupported operation: {operation}", level="ERROR")
            return ""

        template = self.URL_TEMPLATES[operation]

        # --- workspace-only ---
        if operation in ("get_workspaces",):
            return template

        if operation in ("get_reports", "get_datasets", "get_semantic_models"):
            if not workspace_id:
                Debug.log("workspace_id required for this operation", level="ERROR")
                return ""
            return template.format(workspace_id=workspace_id)

        # --- workspace + report ---
        if operation in ("get_report", "get_pages", "get_parameters", "export"):
            if not workspace_id or not report_id:
                Debug.log("workspace_id and report_id required", level="ERROR")
                return ""
            return template.format(workspace_id=workspace_id, report_id=report_id)

        # --- workspace + report + export ---
        if operation in ("export_status", "export_file"):
            if not workspace_id or not report_id or not export_id:
                Debug.log("workspace_id, report_id and export_id required", level="ERROR")
                return ""
            return template.format(
                workspace_id=workspace_id,
                report_id=report_id,
                export_id=export_id,
            )

        # --- pipeline ---
        if operation == "update_pipeline":
            if not workspace_id or not item_id:
                Debug.log("workspace_id and item_id required for update_pipeline", level="ERROR")
                return ""
            return template.format(workspaceId=workspace_id, itemId=item_id)

        # --- semantic model ---
        if operation == "semantic_model_reload":
            if not workspace_id or not item_id:
                Debug.log("workspace_id and item_id required for semantic_model_reload", level="ERROR")
                return ""
            return template.format(workspace_id=workspace_id, item_id=item_id)

        # --- fallback ---
        return template.format(
            workspace_id=workspace_id or "",
            report_id=report_id or "",
            export_id=export_id or "",
            item_id=item_id or "",
        )

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    def get_request(
        self, url: str, headers: dict, payload: dict | None = None, verify: bool = True
    ) -> requests.Response | None:
        try:
            if payload:
                r = requests.get(url, headers=headers, json=payload, verify=verify)
            else:
                r = requests.get(url, headers=headers, verify=verify)
            r.raise_for_status()
            return r
        except requests.exceptions.HTTPError as e:
            Debug.log(f"GET {url} failed: {e} (status {e.response.status_code})", level="ERROR")
            return None
        except Exception as e:
            Debug.log(f"GET {url} failed: {e}", level="ERROR")
            return None

    def post_request(
        self, url: str, headers: dict, payload: dict | None = None, verify: bool = True
    ) -> requests.Response | None:
        try:
            if payload:
                r = requests.post(url, headers=headers, json=payload, verify=verify)
            else:
                r = requests.post(url, headers=headers, verify=verify)
            r.raise_for_status()
            return r
        except requests.exceptions.HTTPError as e:
            Debug.log(f"POST {url} failed: {e} (status {e.response.status_code})", level="ERROR")
            return None
        except Exception as e:
            Debug.log(f"POST {url} failed: {e}", level="ERROR")
            return None