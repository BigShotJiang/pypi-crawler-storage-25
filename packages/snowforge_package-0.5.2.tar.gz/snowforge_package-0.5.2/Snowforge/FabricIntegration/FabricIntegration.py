"""
FabricIntegration — business logic for Fabric/Power BI operations.

Handles pipelines, semantic models, and paginated report exports.
Inherits the HTTP transport from ``PowerAPI``.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from .PowerAPI import PowerAPI
from ..Broadcaster.TemplateRenderer import TemplateRenderer
from ..Logging import Debug

_TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"


class FabricIntegration(PowerAPI):
    """
    Middle layer that encapsulates business logic for
    Fabric pipeline, semantic model, and report operations.

    Parameters
    ----------
    aws_secret_name : str
        Name of the secret in AWS Secrets Manager holding the
        Power BI / Fabric bearer token.
    aws_profile : str
        AWS profile from ``snowforge_config.toml`` to use when
        fetching the secret.
    template_dir : str | Path
        Directory containing Jinja2 templates for API request bodies.
    """

    DEBUG_MODE = False

    def __init__(
        self,
        aws_secret_name: str = "powerbi_refresh_token_secret",
        aws_profile: str = "default",
        template_dir: str | Path | None = None,
    ) -> None:
        super().__init__()

        self.access_token: str = self.get_secret_from_AWS(
            secret_name=aws_secret_name,
            aws_profile=aws_profile,
        )

        self.headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json",
        }

        tpl_dir = Path(template_dir) if template_dir else _TEMPLATE_DIR
        self.template_renderer = TemplateRenderer(tpl_dir)

    # -----------------------------------------------------------------
    # PIPELINE MANAGEMENT
    # -----------------------------------------------------------------

    def start_pipeline(self, workspace_id: str, item_id: str) -> str:
        """Start a Fabric pipeline and return execution ID."""
        run_id, status = self.check_pipeline_last_status(workspace_id, item_id)
        if status in ("InProgress", "NotStarted"):
            Debug.log("Pipeline already running.", "WARNING")
            return "Error"

        url = self.get_url_for("update_pipeline", workspace_id=workspace_id, item_id=item_id)
        response = self.post_request(url, self.headers)

        if not (response and response.status_code == 202):
            Debug.log("Failed to initiate pipeline update.", "ERROR")
            return "Error"

        Debug.log("Pipeline update initiated successfully.", "SUCCESS")
        time.sleep(2)

        run_id, status = self.check_pipeline_last_status(workspace_id, item_id)
        if status in ("InProgress", "NotStarted"):
            return run_id

        Debug.log("Failed to get execution ID.", "ERROR")
        return "Error"

    def check_pipeline_last_status(self, workspace_id: str, item_id: str) -> tuple[str, str]:
        """Fetch the latest pipeline run ID and status."""
        url = self.get_url_for("update_pipeline", workspace_id=workspace_id, item_id=item_id)
        Debug.log(f"Checking pipeline status: {url}", "DEBUG", self.DEBUG_MODE)

        response = self.get_request(url, self.headers)
        Debug.log(
            f"Pipeline status response: {response.text if response else 'No Response'}",
            "DEBUG", self.DEBUG_MODE,
        )

        if not response or response.status_code != 200:
            Debug.log("Failed to get pipeline status.", "ERROR")
            return "Error", "Error"

        data = response.json().get("value", [])
        if not data:
            Debug.log("No recent runs found.", "WARNING")
            return "None", "None"

        latest = data[0]
        status = latest.get("status", "")
        if status in ("Unknown", "NotStarted"):
            return latest.get("id", ""), "InProgress"

        run_id = latest.get("id", "")
        Debug.log(f"Latest pipeline run: {run_id}, status: {status}", "DEBUG", self.DEBUG_MODE)
        return run_id, status

    # -----------------------------------------------------------------
    # SEMANTIC MODEL MANAGEMENT
    # -----------------------------------------------------------------

    def get_semantic_models(self, workspace_id: str) -> list[dict]:
        """Retrieve semantic models in a workspace."""
        url = self.get_url_for("get_semantic_models", workspace_id=workspace_id)
        response = self.get_request(url, self.headers)

        if not response or response.status_code != 200:
            Debug.log("Failed to get semantic models.", "ERROR")
            return []

        data = response.json().get("value", [])
        Debug.log(f"Retrieved {len(data)} semantic models.", "INFO")
        return data

    def semantic_model_reload(self, workspace_id: str, item_id: str) -> str:
        """Trigger semantic model refresh."""
        url = self.get_url_for("semantic_model_reload", workspace_id=workspace_id, item_id=item_id)
        response = self.post_request(url, self.headers)

        if not response or response.status_code not in (200, 202):
            Debug.log("Failed to initiate semantic model refresh.", "ERROR")
            return "Error"

        Debug.log("Semantic model refresh initiated successfully.", "SUCCESS")
        return "Completed"

    def check_semantic_model_status(self, workspace_id: str, item_id: str) -> str:
        """Check the last semantic model refresh status."""
        url = self.get_url_for("semantic_model_reload", workspace_id=workspace_id, item_id=item_id)
        response = self.get_request(url, self.headers)

        if not response or response.status_code != 200:
            Debug.log("Failed to get semantic model status.", "ERROR")
            return "Failed"

        entries = response.json().get("value", [])
        if not entries:
            Debug.log("No refresh history found.", "WARNING")
            return "None"

        status = entries[0].get("status", "")
        if status == "Unknown":
            status = "InProgress"

        Debug.log(f"Last semantic model refresh status: {status}", "INFO")
        return status

    # -----------------------------------------------------------------
    # PAGINATED REPORT EXPORT
    # -----------------------------------------------------------------

    def export_paginated_report(
        self,
        access_token: str,
        workspace_id: str,
        report_id: str,
        input_data: dict[str, Any] | None = None,
        file_format: str = "PDF",
    ) -> Any:
        """
        Kick off an async export of a paginated Power BI report.

        Parameters
        ----------
        access_token : str
            Bearer token (kept as an explicit arg for backward compat).
        workspace_id, report_id : str
            Identifies the report to export.
        input_data : dict, optional
            Report parameter key/value pairs.  Rendered through the
            Jinja2 template ``powerbi_body_template_json.j2``.
        file_format : str
            Target format (``PDF``, ``XLSX``, etc.).

        Returns
        -------
        requests.Response
            The raw HTTP response from the export endpoint.
        """
        url = self.get_url_for("export", workspace_id=workspace_id, report_id=report_id)
        header = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {access_token}",
        }

        body: dict | None = None
        if input_data:
            body = self.template_renderer.render_json(
                "powerbi_body_template_json.j2", input_data
            )
            Debug.log(f"Rendered export body: {body}", "DEBUG", self.DEBUG_MODE)
        else:
            body = {"format": file_format}
            Debug.log(f"No parameters — using minimal export body: {body}", "DEBUG", self.DEBUG_MODE)

        response = self.post_request(url, header, body, verify=True)
        return response

    def check_report_status(
        self, workspace_id: str, report_id: str, export_id: str
    ) -> int:
        """
        Poll the export status endpoint.

        Returns
        -------
        int
            HTTP status code: 200 = completed, 202 = still running,
            anything else = failure.
        """
        url = self.get_url_for(
            "export_status",
            workspace_id=workspace_id,
            report_id=report_id,
            export_id=export_id,
        )
        response = self.get_request(url, self.headers)

        if response is None:
            return 500

        status_code = response.status_code

        if status_code == 200:
            # 200 means the export metadata is ready — check inner status
            data = response.json()
            percent = data.get("percentComplete", 0)
            inner_status = data.get("status", "")

            if inner_status == "Succeeded" or percent == 100:
                Debug.log(f"Export {export_id} completed.", "SUCCESS")
                return 200

            Debug.log(
                f"Export {export_id}: {percent}% ({inner_status})",
                "DEBUG", self.DEBUG_MODE,
            )
            return 202  # still running

        return status_code

    def download_report(
        self, workspace_id: str, report_id: str, export_id: str
    ) -> tuple[bytes, str]:
        """
        Download the exported report file.

        Returns
        -------
        tuple[bytes, str]
            ``(file_content, filename)``
        """
        url = self.get_url_for(
            "export_file",
            workspace_id=workspace_id,
            report_id=report_id,
            export_id=export_id,
        )
        response = self.get_request(url, self.headers)

        if response is None:
            raise RuntimeError(
                f"Failed to download export {export_id} — the API returned "
                f"an error (likely 403 Forbidden). Check that your bearer token "
                f"has Report.Read.All permission and hasn't expired."
            )

        # Extract filename from Content-Disposition header
        cd = response.headers.get("Content-Disposition", "")
        filename = "report.pdf"
        if "filename=" in cd:
            filename = cd.split("filename=")[-1].strip().strip('"')

        Debug.log(f"Downloaded {export_id} → {filename} ({len(response.content)} bytes)", "SUCCESS")
        return response.content, filename

    # -----------------------------------------------------------------
    # AUTH TEST
    # -----------------------------------------------------------------

    def test_authentication(self) -> bool:
        """Quick token validity check against the workspaces endpoint."""
        url = self.get_url_for("get_workspaces")
        response = self.get_request(url, self.headers)

        if response and response.status_code == 200:
            Debug.log("Token is valid.", "SUCCESS")
            return True

        Debug.log("Token is invalid or expired.", "ERROR")
        return False