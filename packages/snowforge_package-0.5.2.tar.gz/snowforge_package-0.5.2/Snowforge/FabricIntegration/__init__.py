"""
Snowforge FabricIntegration — Power BI and Fabric API operations.

Quick start::

    from Snowforge.FabricIntegration import FabricIntegration

    fabric = FabricIntegration(aws_profile="default")
    fabric.test_authentication()
"""

from .FabricIntegration import FabricIntegration
from .PowerAPI import PowerAPI

__all__ = ["FabricIntegration", "PowerAPI"]
