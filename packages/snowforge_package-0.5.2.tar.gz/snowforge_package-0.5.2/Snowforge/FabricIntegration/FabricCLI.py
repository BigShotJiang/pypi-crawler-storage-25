"""
CLI for Fabric pipeline and semantic model operations.

Usage::

    python -m Snowforge.FabricIntegration.FabricCLI --command test_authentication
    python -m Snowforge.FabricIntegration.FabricCLI --command start --workspace_id ... --item_id ...
"""

from __future__ import annotations

import argparse
import sys

from .FabricIntegration import FabricIntegration


def main(argv: list[str] | None = None) -> None:
    commands = [
        "start",
        "check",
        "semantic_model_reload",
        "test_authentication",
        "get_semantic_models",
        "check_semantic_model_status",
    ]

    parser = argparse.ArgumentParser(
        description="Trigger or monitor Fabric pipelines or semantic model refreshes."
    )
    parser.add_argument("--workspace_id", required=False, help="Fabric workspace ID")
    parser.add_argument("--item_id", required=False, help="Item ID")
    parser.add_argument("--command", required=True, choices=commands, help="Command to execute")
    parser.add_argument("--execution_id", required=False, help="Execution ID (for check)")
    parser.add_argument("--aws-profile", default="default", help="AWS profile for token retrieval")

    args = parser.parse_args(argv)
    fabric = FabricIntegration(aws_profile=args.aws_profile)

    match args.command:
        case "start":
            if not args.item_id or not args.workspace_id:
                print("Error: --item_id and --workspace_id are required for start.")
                sys.exit(1)
            execution_id = fabric.start_pipeline(args.workspace_id, args.item_id)
            if execution_id == "Error":
                sys.exit(1)
            print(execution_id)

        case "check":
            if not args.item_id or not args.workspace_id:
                print("Error: --item_id and --workspace_id are required for check.")
                sys.exit(1)
            _, status = fabric.check_pipeline_last_status(args.workspace_id, args.item_id)
            print(status)

        case "semantic_model_reload":
            if not args.item_id or not args.workspace_id:
                print("Error: --item_id and --workspace_id are required.")
                sys.exit(1)
            print(fabric.semantic_model_reload(args.workspace_id, args.item_id))

        case "test_authentication":
            sys.exit(0 if fabric.test_authentication() else 1)

        case "get_semantic_models":
            if not args.workspace_id:
                print("Error: --workspace_id is required.")
                sys.exit(1)
            for model in fabric.get_semantic_models(args.workspace_id):
                print(model)

        case "check_semantic_model_status":
            if not args.item_id or not args.workspace_id:
                print("Error: --item_id and --workspace_id are required.")
                sys.exit(1)
            print(fabric.check_semantic_model_status(args.workspace_id, args.item_id))


if __name__ == "__main__":
    main()
