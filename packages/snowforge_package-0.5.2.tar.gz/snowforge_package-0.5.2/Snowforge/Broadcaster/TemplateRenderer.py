"""
Jinja2-based template renderer for API request bodies and email content.
"""

from __future__ import annotations

import json
from pathlib import Path

from jinja2 import Environment, FileSystemLoader


class TemplateRenderer:
    """
    Render Jinja2 templates into Python dicts (for JSON APIs)
    or plain strings (for email bodies, etc.).
    """

    def __init__(self, template_dir: str | Path = "templates") -> None:
        self.env = Environment(
            loader=FileSystemLoader(str(template_dir)),
            autoescape=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )

    def render_json(self, template_name: str, data: dict) -> dict:
        """Render a template and parse the result as JSON."""
        raw = self._render_raw(template_name, data)
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Template '{template_name}' produced invalid JSON:\n{raw}"
            ) from exc

    def render_text(self, template_name: str, data: dict) -> str:
        """Render a template and return the raw string."""
        return self._render_raw(template_name, data)

    def _render_raw(self, template_name: str, data: dict) -> str:
        template = self.env.get_template(template_name)
        return template.render(data=data).strip()
