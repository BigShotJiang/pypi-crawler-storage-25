"""Allow ``python -m Snowforge.Broadcaster`` to launch the CLI."""

from .CLI import main

main()
