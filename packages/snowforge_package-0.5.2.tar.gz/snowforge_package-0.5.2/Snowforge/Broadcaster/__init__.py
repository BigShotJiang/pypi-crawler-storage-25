"""
Snowforge Broadcaster — export BI reports and deliver them via email/Teams.

Quick start
-----------
>>> from Snowforge.Broadcaster import SnowforgeBroadcaster, BroadcastConfig, SmtpConfig
>>> from Snowforge.Broadcaster.adapters import FabricExporter
>>>
>>> broadcaster = SnowforgeBroadcaster(
...     exporter=FabricExporter(my_fabric_instance),
...     smtp=SmtpConfig(host="smtp.example.com", port=25),
... )
>>> broadcaster.broadcast(config)
"""

from .SnowforgeBroadcaster import SnowforgeBroadcaster
from .BroadcastConfig import BroadcastConfig
from .ConfigProviders import ConfigProvider, JsonFileConfigProvider, SnowflakeConfigProvider
from .Email import Attachment, SmtpConfig
from .ReportExporter import ExportResult, ReportExporter
from .TemplateRenderer import TemplateRenderer
from .api import export_report, send_email, fetch_broadcast_configs

__all__ = [
    "SnowforgeBroadcaster",
    "BroadcastConfig",
    "ConfigProvider",
    "JsonFileConfigProvider",
    "SnowflakeConfigProvider",
    "SmtpConfig",
    "Attachment",
    "ExportResult",
    "ReportExporter",
    "TemplateRenderer",
    "export_report",
    "send_email",
    "fetch_broadcast_configs",
]
