"""
Data models for broadcast configuration.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class BroadcastConfig:
    """
    This is a DataClass. contains everything relevant to a broadcast job. 
    """

    sender: str
    recipients: list[str]
    workspace_id: str = ""
    report_id: str = ""
    channel: str = "email"
    subject: str = ""
    body: str = ""
    parameters: dict[str, Any] | None = None

    @classmethod
    def from_snowflake_row(cls, row: dict) -> BroadcastConfig:
        """
        Takes a row from the Snowflake DSB_RECIPIENT table and fills out this dataclass object.
        """
        return cls(
            sender=row.get("sender", ""),
            recipients=row.get("recipients", []),
            channel=row.get("channel", "email"),
            parameters=row.get("parameter"),
            body=row.get("body", ""),
        )
