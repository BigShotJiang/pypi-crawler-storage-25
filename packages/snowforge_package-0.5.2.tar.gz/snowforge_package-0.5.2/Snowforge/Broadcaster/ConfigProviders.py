"""
Config providers — pluggable sources for broadcast configuration.

A provider turns a job name (like ``SWF_TEST_BROADCAST``) into one or
more ``BroadcastConfig`` objects.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from .BroadcastConfig import BroadcastConfig
from ..Logging import Debug


class ConfigProvider(ABC):
    """Base class for config sources.
       Much like a interface in other languages, this ensures that every config provider implements a method 'fetch' with defined inputs and outputs.
    """

    @abstractmethod
    def fetch(self, job_name: str) -> list[BroadcastConfig]:
        """Return all broadcast configs for the given job."""
        pass


class SnowflakeConfigProvider(ConfigProvider):
    """
    Loads broadcast configs from the Snowflake ``DSB_RECIPIENT`` table.

    The table contains: SWF_NAME, CHANNEL, RECIPIENT, SENDER, PARAMETER.
    It does NOT contain workspace_id, report_id, object name etc. This must be supplied by the caller.

    Parameters
    ----------
    cursor : object
        An active Snowflake cursor (from ``connection.cursor()``).
    table : str
        Fully qualified table reference.
    """

    def __init__(self, cursor: object, table: str = "DEV_ADMIN.DOLPHIN_BRODCASTER.DSB_RECIPIENT") -> None:
        self._cursor = cursor
        self._table = table

    def fetch(self, job_name: str) -> list[BroadcastConfig]:
        """ Fetches config from the Snowflake table for the given job-name.
        """
        sql = f"""
        SELECT
            OBJECT_CONSTRUCT(
                'channel',    CHANNEL,
                'recipients', ARRAY_AGG(RECIPIENT),
                'sender',     SENDER,
                'parameter',  PARAMETER,
                'body',       CONTENT
            ) AS JSON_RESULT
        FROM {self._table}
        WHERE SWF_NAME like %s
        GROUP BY SWF_NAME,
                 CHANNEL,
                 PARAMETER,
                 SENDER,
                 CONTENT
        """
        rows = self._cursor.execute(sql, (job_name,)).fetchall()

        configs: list[BroadcastConfig] = []
        for row in rows:
            raw = row[0]
            data = json.loads(raw.strip()) if isinstance(raw, str) else raw
            configs.append(BroadcastConfig.from_snowflake_row(data))
            
        Debug.log(f"Loaded {len(configs)} broadcast config(s) for job '{job_name}'", "DEBUG")

        return configs


class JsonFileConfigProvider(ConfigProvider):
    """
    This should handle json source fro configs, but is not yet implemented.
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)

    def fetch(self, job_name: str) -> list[BroadcastConfig]:
        raise NotImplementedError("JsonFileConfigProvider is not yet implemented")