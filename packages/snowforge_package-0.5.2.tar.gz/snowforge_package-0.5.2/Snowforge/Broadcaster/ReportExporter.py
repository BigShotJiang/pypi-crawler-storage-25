"""
Abstract interface for report exporters.

Any BI integration (PowerBI/Fabric, QlikSense, QlikView, etc.)
must implement this protocol to be usable with SnowforgeBroadcaster.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class ExportResult:
    """The downloaded report artifact."""

    content: bytes
    filename: str


class ReportExporter(ABC):
    """
    Protocol every BI back-end must satisfy.

    Implementations handle authentication internally — the broadcaster
    never needs to know about tokens, sessions, or API specifics.
    """

    @abstractmethod
    def start_export(
        self,
        workspace_id: str,
        report_id: str,
        parameters: dict[str, Any] | None = None,
    ) -> str:
        """Kick off an async export and return an export/job ID."""
        ...

    @abstractmethod
    def poll_status(
        self,
        workspace_id: str,
        report_id: str,
        export_id: str,
    ) -> str:
        """
        Return one of the literal status strings:

        * ``"running"``  – still in progress
        * ``"completed"`` – ready to download
        * ``"failed"``   – export failed
        """
        ...

    @abstractmethod
    def download(
        self,
        workspace_id: str,
        report_id: str,
        export_id: str,
    ) -> ExportResult:
        """Download the finished report and return its bytes + filename."""
        ...
