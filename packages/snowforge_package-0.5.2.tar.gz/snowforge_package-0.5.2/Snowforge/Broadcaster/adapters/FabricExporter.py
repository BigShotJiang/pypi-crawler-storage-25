"""
Fabric / Power BI adapter for the ReportExporter protocol.

Wraps your existing ``FabricIntegration`` class so the broadcaster
doesn't depend on it directly.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ..ReportExporter import ExportResult, ReportExporter
from ..TemplateRenderer import TemplateRenderer
from ...Logging import Debug

_DEFAULT_TEMPLATE_DIR = Path(__file__).resolve().parent.parent / "templates"


class FabricExporter(ReportExporter):
    """
    Bridges ``FabricIntegration`` into the ``ReportExporter`` interface.

    Parameters
    ----------
    fabric : object
        An instance of your ``FabricIntegration`` class.  Accepted as a
        plain object so this module never imports FabricIntegration
        itself — you wire it up from the outside.
    template_renderer : TemplateRenderer, optional
        Renders export parameters through ``powerbi_body_template_json.j2``
        before sending them to the Fabric API.  A default renderer using
        the bundled templates directory is created if omitted.
    """

    def __init__(
        self,
        fabric: object,
        template_renderer: TemplateRenderer | None = None,
    ) -> None:
        self._fabric = fabric  # type: ignore[assignment]
        self._renderer = template_renderer or TemplateRenderer(_DEFAULT_TEMPLATE_DIR)

    # ------------------------------------------------------------------
    # ReportExporter implementation
    # ------------------------------------------------------------------

    def start_export(
        self,
        workspace_id: str,
        report_id: str,
        parameters: dict[str, Any] | None = None,
    ) -> str:
        body = None
        if parameters:
            body = self._renderer.render_json(
                "powerbi_body_template_json.j2", parameters
            )
            Debug.log(f"Rendered export body: {body}", "DEBUG")

        resp = self._fabric.export_paginated_report(
            self._fabric.access_token,
            workspace_id,
            report_id,
            body or parameters or None,
        )
        if resp is None:
            raise RuntimeError(
                f"Export request failed for report {report_id} in workspace {workspace_id}. "
                "Check earlier log messages for details."
            )
        export_id: str = resp.json()["id"]
        Debug.log(f"Started Fabric export {export_id}", "INFO")
        return export_id

    def poll_status(
        self,
        workspace_id: str,
        report_id: str,
        export_id: str,
    ) -> str:
        status_code = self._fabric.check_report_status(
            workspace_id, report_id, export_id
        )
        print(status_code)
        mapping = {200: "Completed", 202: "InProgress", 500: "Failed"}
        return mapping.get(status_code, "Failed")

    def download(
        self,
        workspace_id: str,
        report_id: str,
        export_id: str,
    ) -> ExportResult:
        content, name = self._fabric.download_report(
            workspace_id, report_id, export_id
        )
        return ExportResult(content=content, filename=name)
