"""
QlikSense adapter — placeholder for future implementation.

Implement the three ``ReportExporter`` methods to enable
QlikSense report exports through the broadcaster.
"""

from __future__ import annotations

from typing import Any

from ..ReportExporter import ExportResult, ReportExporter


class QlikSenseExporter(ReportExporter):
    """QlikSense exporter — not yet implemented."""

    def __init__(self, connection: object) -> None:
        self._conn = connection

    def start_export(
        self,
        workspace_id: str,
        report_id: str,
        parameters: dict[str, Any] | None = None,
    ) -> str:
        raise NotImplementedError("QlikSense exporter not yet implemented")

    def poll_status(
        self, workspace_id: str, report_id: str, export_id: str
    ) -> str:
        raise NotImplementedError

    def download(
        self, workspace_id: str, report_id: str, export_id: str
    ) -> ExportResult:
        raise NotImplementedError
