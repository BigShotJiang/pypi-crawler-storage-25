"""
Email dispatch for SnowforgeBroadcaster.

Handles plain-text messages with optional binary attachments over SMTP.
"""

from __future__ import annotations

import mimetypes
import smtplib
from dataclasses import dataclass
from email.message import EmailMessage

from ..Logging import Debug


@dataclass
class Attachment:
    """A single email attachment."""

    data: bytes
    filename: str
    mime_type: str | None = None

    def resolved_mime_type(self) -> str:
        if self.mime_type:
            return self.mime_type
        guessed, _ = mimetypes.guess_type(self.filename)
        return guessed or "application/octet-stream"


@dataclass
class SmtpConfig:
    """Connection settings for the outgoing mail server."""

    host: str = "localhost"
    port: int = 25
    use_tls: bool = False
    username: str | None = None
    password: str | None = None


def send_email(*, subject: str, sender: str, recipients: list[str] | str, body: str, attachments: list[Attachment] | None = None, smtp: SmtpConfig | None = None) -> None:
    """
    Build and dispatch a single email.

    Parameters
    ----------
    subject : str
        Email subject line.
    sender : str
        The *From* address (single address string).
    recipients : list[str] | str
        One or more *To* addresses.
    body : str
        Plain-text message body.
    attachments : list[Attachment], optional
        Files to attach.
    smtp : SmtpConfig, optional
        SMTP server settings.  Falls back to ``localhost:25``.
    """
    if isinstance(recipients, str):
        recipients = [recipients]

    smtp = smtp or SmtpConfig()

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    msg.set_content(body)

    for att in attachments or []:
        maintype, subtype = att.resolved_mime_type().split("/", 1)
        msg.add_attachment(att.data, maintype=maintype, subtype=subtype, filename=att.filename)

    with smtplib.SMTP(smtp.host, smtp.port) as server:
        if smtp.use_tls:
            server.starttls()
        if smtp.username and smtp.password:
            server.login(smtp.username, smtp.password)

        try:
            server.send_message(msg)
            return "'Sent'"
        except Exception as e:
            Debug.log(f"Failed to send email — subject='{subject}', to={', '.join(recipients)}. Error: {e}", "ERROR")
            return "'Failed'"

