"""
High-level convenience functions for external callers.

Three independent operations — use any combination:

    from Snowforge.Broadcaster import fetch_broadcast_configs, export_report, send_email

    # 1. Fetch broadcast configs from Snowflake
    configs = fetch_broadcast_configs("SWF_TEST_PAGINATED")

    # 2. Export a report (returns bytes + filename)
    result = export_report(
        workspace_id="...",
        report_id="...",
        parameters=configs[0].parameters,
    )

    # 3. Send an email with attachments
    send_email(
        sender="noreply@example.com",
        recipients=["user@example.com"],
        subject="Your report",
        body="See attached.",
        attachments=[(result.content, result.filename)],
    )
"""

from __future__ import annotations

from typing import Any

from .ReportExporter import ExportResult
from .BroadcastConfig import BroadcastConfig
from .Email import Attachment, SmtpConfig, send_email as _send_email
from ..Logging import Debug


def fetch_broadcast_configs(job_name: str, *, snowflake_profile: str = "default", table: str = "DEV_ADMIN.DOLPHIN_BRODCASTER.DSB_RECIPIENT") -> list[BroadcastConfig]:
    """
    Load broadcast configurations from the Snowflake DSB_RECIPIENT table.

    Each returned config contains: sender, recipients, channel, and
    parameters.  ``workspace_id`` and ``report_id`` are NOT in the
    table — supply them yourself when calling ``export_report``.

    Parameters
    ----------
    job_name : str
        The SWF_NAME to match in the DSB_RECIPIENT table
        (e.g. ``"SWF_TEST_PAGINATED"``).
    snowflake_profile : str
        Profile name from ``snowforge_config.toml`` for Snowflake
        connection.
    table : str
        Fully qualified Snowflake table reference.

    Returns
    -------
    list[BroadcastConfig]
        One config per unique (channel, sender, parameter) group.
    """
    from ..SnowflakeIntegration import SnowflakeIntegration
    from .ConfigProviders import SnowflakeConfigProvider

    conn = SnowflakeIntegration.connect(profile=snowflake_profile)
    provider = SnowflakeConfigProvider(cursor=conn.cursor(), table=table)
    configs = provider.fetch(job_name)
    Debug.log(f"Fetched {len(configs)} broadcast config(s) for job '{job_name}'", "INFO")

    return configs


def export_report(
    workspace_id: str,
    report_id: str,
    parameters: dict[str, Any] | None = None,
    *,
    aws_secret_name: str = "powerbi_refresh_token_secret",
    aws_profile: str = "default",
    poll_interval: float = 5.0,
    max_poll_attempts: int = 240,
) -> ExportResult:
    """
    Export a paginated Power BI report and return the downloaded file.

    Handles authentication, export submission, polling, and download
    internally.  The caller only needs workspace/report IDs and
    optional report parameters.

    Parameters
    ----------
    workspace_id : str
        Power BI workspace (group) ID.
    report_id : str
        Report ID inside the workspace.
    parameters : dict, optional
        Report parameter key/value pairs.  Pass ``None`` or ``{}``
        for reports without parameters.
    aws_secret_name : str
        AWS Secrets Manager entry holding the bearer token.
    aws_profile : str
        AWS profile to use (from ``snowforge_config.toml``).
    poll_interval : float
        Seconds between status polls.
    max_poll_attempts : int
        Maximum number of polls before raising ``TimeoutError``.

    Returns
    -------
    ExportResult
        ``.content`` (bytes) and ``.filename`` (str).
    """
    from ..FabricIntegration import FabricIntegration
    from .adapters.FabricExporter import FabricExporter
    from .SnowforgeBroadcaster import SnowforgeBroadcaster
    from .BroadcastConfig import BroadcastConfig

    fabric = FabricIntegration(
        aws_secret_name=aws_secret_name,
        aws_profile=aws_profile,
    )

    broadcaster = SnowforgeBroadcaster(
        exporter=FabricExporter(fabric),
        poll_interval=poll_interval,
        max_poll_attempts=max_poll_attempts,
    )

    config = BroadcastConfig(
        workspace_id=workspace_id,
        report_id=report_id,
        sender="",
        recipients=[],
        parameters=parameters or None,
    )

    result = broadcaster.export_report(config)
    Debug.log(f"Report exported: {result.filename}", "SUCCESS")
    return result


def send_email(
    sender: str,
    recipients: list[str],
    subject: str,
    body: str,
    attachments: list[tuple[bytes, str]] | None = None,
    *,
    smtp_host: str = "localhost",
    smtp_port: int = 25,
    smtp_use_tls: bool = False,
    smtp_username: str | None = None,
    smtp_password: str | None = None,
) -> None:
    """
    Send an email with optional file attachments.

    Completely independent from report export — call it with any
    files you want to attach.

    Parameters
    ----------
    sender : str
        From address.
    recipients : list[str]
        To addresses.
    subject : str
        Email subject line.
    body : str
        Plain-text message body.
    attachments : list of (bytes, filename) tuples, optional
        Files to attach.  Each tuple is ``(file_bytes, "name.pdf")``.
    smtp_host : str
        SMTP server hostname.
    smtp_port : int
        SMTP server port.
    smtp_use_tls : bool
        Enable STARTTLS.
    smtp_username : str, optional
        SMTP login username (if authentication is required).
    smtp_password : str, optional
        SMTP login password (if authentication is required).
    """
    smtp = SmtpConfig(
        host=smtp_host,
        port=smtp_port,
        use_tls=smtp_use_tls,
        username=smtp_username,
        password=smtp_password,
    )

    att_objects = [
        Attachment(data=data, filename=name)
        for data, name in (attachments or [])
    ]

    status = _send_email(
        subject=subject,
        sender=sender,
        recipients=recipients,
        body=body,
        attachments=att_objects,
        smtp=smtp,
    )

    return status
