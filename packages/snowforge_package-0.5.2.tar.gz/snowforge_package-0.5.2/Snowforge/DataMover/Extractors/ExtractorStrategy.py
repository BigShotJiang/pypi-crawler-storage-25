"""Abstract strategy contract for source-specific data extractors."""

from abc import ABC, abstractmethod

class ExtractorStrategy(ABC):
    """Abstract base class for extraction strategy implementations."""

    @abstractmethod
    def extract_table_query(self, fully_qualified_table_name: str, filter_statement: str = None, verbose: bool = False):
        """Extracts a table based on the provided criteria."""
        pass

    @abstractmethod
    def list_all_tables(self, database_name: str, verbose: bool = False):
        """Lists all tables in a given database."""
        pass
    
    @abstractmethod
    def export_external_table(self, query: str, output_path: str, table_name: str, verbose: bool = False):
        """Exports an external table from a database table."""
        pass