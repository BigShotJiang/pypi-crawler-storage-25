"""Extractor implementations used by the DataMover engine."""
