import os
import zipfile

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.trace_types import TraceTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.enums.types.parameter_types_extended import ParameterTypesExtended


# bifurcation data
class BifurcationData:
    """Class to manage and store bifurcation data for different types and parameters."""

    def __init__(self) -> None:
        """Initialize the BifurcationData object, setting up data structures for bifurcation types and plot data."""
        self.fixed_parameter_type: ParameterTypes | None = None
        self.fixed_parameter_value: str | None = None
        self.data: dict[TraceTypes, dict[int, dict[ParameterTypesExtended, dict[float, float | list[int] | list[float]]]]] = {}
        # create dictionary with bifurcation types
        for trace_types in TraceTypes:
            self.data[trace_types] = {}

    def clear_data(self) -> None:
        self.fixed_parameter_type = None
        self.fixed_parameter_value = None
        # clar trace types
        for trace_types in TraceTypes:
            self.data[trace_types] = {}

    def add_bifurcation_index(self, trace_types: TraceTypes, bifurcation_index: int) -> None:
        """Add a new bifurcation index for a given trace type.

        Args:
            trace_types (str): The type of bifurcation.
            bifurcation_index (int): The index to add.

        """
        # declare dictionary
        self.data[trace_types][bifurcation_index] = {}
        # create dicctionar for every parameter type
        for parameter_type_extended in ParameterTypesExtended:
            # set plot data values
            self.data[trace_types][bifurcation_index][parameter_type_extended] = {}

    # set data
    def set_data(self, line_parts: list[str], fixed_parameter_value_str: str) -> None:
        """Set the bifurcation data from food_web_bifurcation_explorer.a line of input and a fixed parameter value.

        Args:
            line_parts (list[str]): The parts of the input line.
            fixed_parameter_value_str (str): The fixed parameter value as a string.

        """
        fixed_parameter_value = float(fixed_parameter_value_str)
        # get parts type
        trace_types: TraceTypes = TraceTypes(line_parts[0])
        bifurcation_index: int = int(line_parts[1])
        sd: float = float(line_parts[2])
        sr: float = float(line_parts[3])
        sl: float = float(line_parts[4])
        biomass_values: list[float] = [float(x) for x in line_parts[5].split("_")]
        # check if add a new bifurcation index
        if bifurcation_index not in self.data[trace_types]:
            self.add_bifurcation_index(trace_types, bifurcation_index)
        self.data[trace_types][bifurcation_index][ParameterTypesExtended.DONOR][fixed_parameter_value] = sd
        self.data[trace_types][bifurcation_index][ParameterTypesExtended.RECIPIENT][fixed_parameter_value] = sr
        self.data[trace_types][bifurcation_index][ParameterTypesExtended.LOTKAVOLTERRA][fixed_parameter_value] = sl
        self.data[trace_types][bifurcation_index][ParameterTypesExtended.BIOMASS][fixed_parameter_value] = biomass_values
        if trace_types == TraceTypes.EXTINCT:
            # search all compartments with zero biomass
            extinct_compartments: list[int] = []
            for i, value in enumerate(biomass_values):
                if value < 0:
                    extinct_compartments.append(i)
            # set label
            self.data[trace_types][bifurcation_index][ParameterTypesExtended.LABELS][fixed_parameter_value] = extinct_compartments

    # check if exist data
    def exist(self, trace_types: TraceTypes) -> bool:
        """Check if data exists for a given trace type.

        Args:
            trace_types (str): The type of bifurcation.

        Returns:
            bool: True if data exists, False otherwise.

        """
        return len(self.data[trace_types]) > 0

    # get indexes
    def get_indexes(self, trace_types: TraceTypes) -> list[int]:
        """Get the list of indexes for a given trace type.

        Args:
            trace_types (str): The type of bifurcation.

        Returns:
            list: List of indexes.

        """
        return list(self.data[trace_types])

    # get X data
    def get_bifurcation_diagram_x(self, trace_types: TraceTypes, index: int) -> list[float]:
        """Get the X values for the bifurcation diagram.

        Args:
            trace_types (str): The type of bifurcation.
            index (int): The index to retrieve.

        Returns:
            list: List of X values.

        """
        # get x values
        if glob.config.fixed_parameter_value in self.data[trace_types][index][glob.config.dynamic_paramameter_type]:
            return [self.data[trace_types][index][glob.config.dynamic_paramameter_type][glob.config.fixed_parameter_value]]
        return []

    # get Y data
    def get_bifurcation_diagram_y(self, trace_types: TraceTypes, index: int, biomass_compartment: int) -> list[float]:
        """Get the Y values for the bifurcation diagram.

        Args:
            trace_types (str): The type of bifurcation.
            index (int): The index to retrieve.
            biomass_compartment (int): The biomass compartment index.

        Returns:
            list: List of Y values.

        """
        if glob.config.fixed_parameter_value in self.data[trace_types][index][ParameterTypesExtended.BIOMASS]:
            return [self.data[trace_types][index][ParameterTypesExtended.BIOMASS][glob.config.fixed_parameter_value][biomass_compartment]]
        return []

    # get labels
    def get_bifurcation_diagram_labels(self, trace_types: TraceTypes, index: int) -> list[str]:
        """Get the labels for the bifurcation diagram.

        Args:
            trace_types (str): The type of bifurcation.
            index (int): The index to retrieve.

        Returns:
            list: List of label strings.

        """
        if glob.config.fixed_parameter_value in self.data[trace_types][index][ParameterTypesExtended.LABELS]:
            # get compartment names instead of index
            label_indexes: list[int] = self.data[trace_types][index][ParameterTypesExtended.LABELS][glob.config.fixed_parameter_value]
            compartments_str = glob.config.get_current_compartments()
            # format: "label (index)"
            return [f"<b>{index + 1} ({compartments_str[index]})</b>" for index in label_indexes]
        return []