from dash import dcc, html

from food_web_bifurcation_explorer.callbacks.update_scatter_graphs import BifurcationDiagramTypes
from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.enums.types.bifurcation_distribution_types import BifurcationDistributionTypes
from food_web_bifurcation_explorer.enums.types.hopf_parameter_types import HopfParameterTypes
from food_web_bifurcation_explorer.frontend.distribution_module import bifurcation_distribution_logarithmic
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcation_distribution import (
    bifurcation_distribution_num_bins,
    bifurcation_distribution_num_contours,
    bifurcation_distribution_use_contours,
)
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcations.codimension_two import (
   bautin_distribution,
   bogdanov_takens_distribution,
   double_hopf_distribution,
)
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcations.codimension_one.hopf.subcritical import (
    subcritical_distribution_alternative,
    subcritical_distribution_empirical,
)
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcations.codimension_one.hopf.supercritical import (
    supercritical_distribution_alternative,
    supercritical_distribution_empirical,
)
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcations.codimension_one.saddlenode import (
    saddlenode_distribution_alternative,
    saddlenode_distribution_empirical,
)
from food_web_bifurcation_explorer.frontend.distribution_module.bifurcations.codimension_one.transcritical import (
    transcritical_distribution_alternative,
    transcritical_distribution_empirical,
)
from food_web_bifurcation_explorer.frontend.heatmap_module.bifurcations.codimension_two import (
    bautin_heatmap,
    bogdanov_takens_heatmap,
    double_hopf_heatmap,
)
from food_web_bifurcation_explorer.frontend.heatmap_module.bifurcations.codimension_one.hopf.subcritical import (
    subcritical_heatmap_empirical,
    subcritical_heatmap_alternative,
)
from food_web_bifurcation_explorer.frontend.heatmap_module.bifurcations.codimension_one.hopf.supercritical import (
    supercritical_heatmap_empirical,
    supercritical_heatmap_alternative,
)
from food_web_bifurcation_explorer.frontend.heatmap_module.bifurcations.codimension_one.saddlenode import(
    saddlenode_heatmap_alternative,
    saddlenode_heatmap_empirical
)
from food_web_bifurcation_explorer.frontend.heatmap_module.bifurcations.codimension_one.transcritical import (
    transcritical_heatmap_alternative,
    transcritical_heatmap_empirical,
)
from food_web_bifurcation_explorer.frontend.heatmap_module.color import heatmap_color_end_picker, heatmap_color_start_picker
from food_web_bifurcation_explorer.frontend.heatmap_module.general import heatmap_logarithmic, heatmap_resolution_selector, min_heatmap_value
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.codimension_two import (
   bautin_scatter,
   bogdanov_takens_scatter,
   double_hopf_scatter,
)
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.codimension_one.hopf.envelope import(
    envelope_scatter_empirical, 
    envelope_scatter_alternative,
)
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.codimension_one.hopf.subcritical import (
    subcritical_scatter_alternative,
    subcritical_scatter_empirical,
)
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.codimension_one.hopf.supercritical import (
    supercritical_scatter_alternative,
    supercritical_scatter_empirical,
)
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.codimension_one.saddlenode import (
    saddlenode_scatter_alternative, 
    saddlenode_scatter_empirical,
)
from food_web_bifurcation_explorer.frontend.scatter_module.bifurcations.codimension_one.transcritical import (
    transcritical_scatter_alternative,
    transcritical_scatter_empirical,
)
from food_web_bifurcation_explorer.frontend.scatter_module.biomass_compartment import biomass_compartment_first, biomass_compartment_second
from food_web_bifurcation_explorer.frontend.scatter_module.draw import branch_alternative, branch_empirical, lines, points
from food_web_bifurcation_explorer.frontend.scatter_module.eigenvalue_spectrum.alternative import (
    eigenvalue_spectrum_index_alternative,
    eigenvalue_spectrum_jump_alternative_a,
    eigenvalue_spectrum_jump_alternative_b,
    eigenvalue_spectrum_jump_alternative_c,
    eigenvalue_spectrum_jump_alternative_d,
    eigenvalue_spectrum_jump_alternative_e,
)
from food_web_bifurcation_explorer.frontend.scatter_module.eigenvalue_spectrum.empirical import (
    eigenvalue_spectrum_index_empirical,
    eigenvalue_spectrum_jump_empirical_a,
    eigenvalue_spectrum_jump_empirical_b,
    eigenvalue_spectrum_jump_empirical_c,
    eigenvalue_spectrum_jump_empirical_d,
    eigenvalue_spectrum_jump_empirical_e,
)
from food_web_bifurcation_explorer.frontend.scatter_module.equilibria import area, over_information, stable, unstable
from food_web_bifurcation_explorer.frontend.scatter_module.general import network_selector, resolution_selector
from food_web_bifurcation_explorer.frontend.scatter_module.others import eigenvalue_spectrum_index, extinct, internal_error
from food_web_bifurcation_explorer.frontend.scatter_module.parameters import fixed_parameter_type, fixed_parameter_value

# html layout
html_layout = html.Div(
    [
        # title
        html.H1(Labels.MAIN_TITLE, style=Styles.MAIN_TITLE),
        # DIV_CONTROL scatter
        html.Div(
            [
                # Group 1
                html.Div(
                    [
                        html.Label(Labels.NETWORK_SELECTOR, style=Styles.LABEL),
                        network_selector.build(),
                        html.Label(Labels.ZOOM_LEVEL, style=Styles.LABEL),
                        resolution_selector.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 2
                html.Div(
                    [
                        html.Label(Labels.BIOMASS_COMPARTMENT_FIRST, style=Styles.LABEL),
                        biomass_compartment_first.build(),
                        html.Label(Labels.BIOMASS_COMPARTMENT_SECOND, style=Styles.LABEL),
                        biomass_compartment_second.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 3
                html.Div(
                    [
                        html.Label(Labels.FIXED_PARAMETER_TYPE, style=Styles.LABEL),
                        fixed_parameter_type.build(),
                        html.Label(Labels.FIXED_PARAMETER_VALUE, style=Styles.LABEL),
                        fixed_parameter_value.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 4: Equilibria
                html.Div(
                    [
                        html.Label(Labels.EQUILIBRIA, style=Styles.LABEL),
                        area.build(),
                        stable.build(),
                        unstable.build(),
                        over_information.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 5: saddlenode & transcritical bifurcations
                html.Div(
                    [
                        # saddle node bifurcations
                        html.Label(Labels.SADDLENODE_BIFURCATIONS, style=Styles.LABEL),
                        saddlenode_scatter_empirical.build(),
                        saddlenode_scatter_alternative.build(),
                        # transcritical bifurcations
                        html.Label(
                            Labels.TRANSCRITICAL_BIFURCATIONS,
                            style=Styles.LABEL,
                        ),
                        transcritical_scatter_empirical.build(),
                        transcritical_scatter_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 6: hopf bifurcations
                html.Div(
                    [
                        # hopf subcritical bifurcations
                        html.Label(Labels.HOPF_SUBCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        subcritical_scatter_empirical.build(),
                        subcritical_scatter_alternative.build(),
                        # hopf supercritical bifurcations
                        html.Label(Labels.HOPF_SUPERCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        supercritical_scatter_empirical.build(),
                        supercritical_scatter_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 7: bautin & envelope
                html.Div(
                    [
                        html.Label(Labels.CODIMENSION_TWO, style=Styles.LABEL),
                        bautin_scatter.build(),
                        bogdanov_takens_scatter.build(),
                        double_hopf_scatter.build(),
                        html.Label(Labels.HOPF_ENVELOPES, style=Styles.LABEL),
                        envelope_scatter_empirical.build(),
                        envelope_scatter_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 8 : others
                html.Div(
                    [
                        html.Label(Labels.OTHERS, style=Styles.LABEL),
                        extinct.build(),
                        internal_error.build(),
                        eigenvalue_spectrum_index.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 9: Drawing Options
                html.Div(
                    [
                        html.Label(Labels.DRAWING_OPTIONS, style=Styles.LABEL),
                        branch_empirical.build(),
                        branch_alternative.build(),
                        lines.build(),
                        points.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 10: eigen value spectrum indices
                html.Div(
                    [
                        eigenvalue_spectrum_index_empirical.title(),
                        # subgroup 10: empirical
                        html.Div(
                            [
                                eigenvalue_spectrum_index_empirical.build(),
                                eigenvalue_spectrum_jump_empirical_a.build(),
                                eigenvalue_spectrum_jump_empirical_b.build(),
                                eigenvalue_spectrum_jump_empirical_c.build(),
                                eigenvalue_spectrum_jump_empirical_d.build(),
                                eigenvalue_spectrum_jump_empirical_e.build(),
                            ],
                            style=Styles.SUBGROUP_EIGENVALUES,
                        ),
                        eigenvalue_spectrum_index_alternative.title(),
                        # subgroup 10: alternative
                        html.Div(
                            [
                                eigenvalue_spectrum_index_alternative.build(),
                                eigenvalue_spectrum_jump_alternative_a.build(),
                                eigenvalue_spectrum_jump_alternative_b.build(),
                                eigenvalue_spectrum_jump_alternative_c.build(),
                                eigenvalue_spectrum_jump_alternative_d.build(),
                                eigenvalue_spectrum_jump_alternative_e.build(),
                            ],
                            style=Styles.SUBGROUP_EIGENVALUES,
                        ),
                    ],
                    style=Styles.GROUP_EIGENVALUES,
                ),
            ],
            style=Styles.DIV_CONTROL,
        ),
        # DIV_GRAPHS
        html.Div(
            [
                # ternary graph
                html.Div(
                    [
                        dcc.Graph(
                            id=IDs.FIGURE_SCATTER_TERNARY,
                            figure=glob.figures.scatter_ternary,
                            style=Styles.TERNARY,
                            config={"doubleClick": False, "scrollZoom": False, "responsive": True, "displayModeBar": True},
                        )
                    ],
                    id=IDs.DIV_SCATTER_TERNARY,
                    style=Styles.DIV_GRAPH_SCATTER_TERNARY,
                ),
                # DIV_RIGHT_PANEL
                html.Div(
                    [
                        # DIV_SMALL_ROW
                        html.Div(
                            [
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # bifurcation diagram A
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_BIFURCATION_DIAGRAM_FIRST,
                                            figure=glob.figures.bifurcation_diagrams[BifurcationDiagramTypes.FIRST],
                                            style=Styles.PLOT,
                                            config={"displayModeBar": True},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_BIFURCATION_DIAGRAM_FIRST,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # eigenvalue_spectrum empirical
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL,
                                            figure=glob.figures.eigenvalue_spectrum_empirical,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": True},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # hopf parameter L1
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_L1,
                                            figure=glob.figures.hopf_parameters[HopfParameterTypes.L1],
                                            style=Styles.PLOT,
                                            config={"displayModeBar": True},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_HOPF_PARAMETER_PLOT_L1,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # hopf parameter transversal crossing speed
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_TRANSVERSAL_CROSSING_SPEED,
                                            figure=glob.figures.hopf_parameters[HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED],
                                            style=Styles.PLOT,
                                            config={"displayModeBar": True},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_HOPF_PARAMETER_PLOT_TRANSVERSAL_CROSSING_SPEED,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                            ],
                            id=IDs.DIV_SCATTER_ROW_PLOTS_A,
                            style=Styles.DIV_SMALL_ROW,
                        ),
                        # DIV_SMALL_ROW
                        html.Div(
                            [
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # bifurcation diagram B
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_BIFURCATION_DIAGRAM_SECOND,
                                            figure=glob.figures.bifurcation_diagrams[BifurcationDiagramTypes.SECOND],
                                            style=Styles.PLOT,
                                            config={"displayModeBar": True},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_BIFURCATION_DIAGRAM_SECOND,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # eigenvalue_spectrum alternative
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE,
                                            figure=glob.figures.eigenvalue_spectrum_alternative,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": True},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # hopf parameter frequency
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_OSCILLATION_FREQUENCY,
                                            figure=glob.figures.hopf_parameters[HopfParameterTypes.OSCILLATION_FREQUENCY],
                                            style=Styles.PLOT,
                                            config={"displayModeBar": True},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_HOPF_PARAMETER_PLOT_FREQUENCY,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # hopf parameter normalization error
                                        dcc.Graph(
                                            id=IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_NORMALIZATION_ERROR,
                                            figure=glob.figures.hopf_parameters[HopfParameterTypes.NORMALIZATION_ERROR],
                                            style=Styles.PLOT,
                                            config={"displayModeBar": True},
                                        ),
                                    ],
                                    id=IDs.DIV_SCATTER_HOPF_PARAMETER_PLOT_NORMALIZATION_ERROR,
                                    style=Styles.DIV_GRAPH_SCATTER_PLOT,
                                ),
                            ],
                            id=IDs.DIV_SCATTER_ROW_PLOTS_B,
                            style=Styles.DIV_SMALL_ROW,
                        ),
                    ],
                    id=IDs.DIV_SCATTER_FOUR_PLOTS_ROW,
                    style=Styles.DIV_FOUR_PLOTS,
                ),
            ],
            id=IDs.DIV_MATRIX_01,
            style=Styles.DIV_GRAPHS,
        ),
        # DIV_CONTROL heatmap
        html.Div(
            [
                # Group 1: heatmap ternary options
                html.Div(
                    [
                        html.Label(Labels.HEATMAP_RESOLUTION, style=Styles.LABEL),
                        heatmap_resolution_selector.build(),
                        html.Label(Labels.MIN_COUNT_CONSIDERED, style=Styles.LABEL),
                        min_heatmap_value.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 2: color picker
                html.Div(
                    [
                        html.Label(Labels.START_COLOR, style=Styles.LABEL),
                        heatmap_color_start_picker.build(),
                        html.Label(Labels.END_COLOR, style=Styles.LABEL),
                        heatmap_color_end_picker.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 3: bifurcation distribution options
                html.Div(
                    [
                        html.Label(Labels.DRAWING_OPTIONS, style=Styles.LABEL),
                        heatmap_logarithmic.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 4: saddlenode and transcritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.SADDLENODE_BIFURCATIONS, style=Styles.LABEL),
                        saddlenode_heatmap_empirical.build(),
                        saddlenode_heatmap_alternative.build(),
                        html.Label(Labels.TRANSCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        transcritical_heatmap_empirical.build(),
                        transcritical_heatmap_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 5: hopf subcritical and supercritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.HOPF_SUBCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        subcritical_heatmap_empirical.build(),
                        subcritical_heatmap_alternative.build(),
                        html.Label(Labels.HOPF_SUPERCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        supercritical_heatmap_empirical.build(),
                        supercritical_heatmap_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 6: bautin
                html.Div(
                    [
                        html.Label(Labels.CODIMENSION_TWO, style=Styles.LABEL),
                        bautin_heatmap.build(),
                        bogdanov_takens_heatmap.build(),
                        double_hopf_heatmap.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
            ],
            style=Styles.DIV_CONTROL,
        ),
        # DIV_GRAPHS
        html.Div(
            [
                # ternary graph
                html.Div(
                    [
                        dcc.Graph(
                            id=IDs.FIGURE_HEATMAP_TERNARY,
                            figure=glob.figures.heatmap_ternary,
                            style=Styles.TERNARY,
                            config={"doubleClick": False, "scrollZoom": False, "responsive": True, "displayModeBar": True},
                        )
                    ],
                    id=IDs.DIV_HEATMAP_TERNARY,
                    style=Styles.DIV_GRAPH_HEATMAP_TERNARY,
                ),
                # DIV_TEXT_LIST
                html.Div(
                    [
                        html.Div(
                            id=IDs.TEXT_HEATMAP_NETWORK_LIST,
                            children=[html.P("Calculating data", style={"color": "gray"})],
                            style=Styles.LIST,
                        )
                    ],
                    id=IDs.DIV_HEATMAP_NETWORK_LIST,
                    style=Styles.DIV_HEATMAP_NETWORK_LIST,
                ),
            ],
            id=IDs.DIV_MATRIX_02,
            style=Styles.DIV_GRAPHS,
        ),
        # DIV_CONTROL distribution
        html.Div(
            [
                # Group 1: distribution options
                html.Div(
                    [
                        html.Label(Labels.BIFURCATION_DISTRIBUTION_NUM_BINS, style=Styles.LABEL),
                        bifurcation_distribution_num_bins.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 2: distribution configuration
                html.Div(
                    [
                        html.Label(Labels.BIFURCATION_DISTRIBUTIONS_NUM_CONTOURS, style=Styles.LABEL),
                        bifurcation_distribution_num_contours.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 3: distribution design
                html.Div(
                    [
                        html.Label(Labels.BIFURCATION_DISTRIBUTIONS_DESIGN, style=Styles.LABEL),
                        bifurcation_distribution_use_contours.build(),
                        bifurcation_distribution_logarithmic.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 4: saddlenode  bifurcations
                html.Div(
                    [
                        html.Label(Labels.SADDLENODE_BIFURCATIONS, style=Styles.LABEL),
                        saddlenode_distribution_empirical.build(),
                        saddlenode_distribution_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 5: transcritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.TRANSCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        transcritical_distribution_empirical.build(),
                        transcritical_distribution_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 6: hopf subcritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.HOPF_SUBCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        subcritical_distribution_empirical.build(),
                        subcritical_distribution_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 7: hopf supercritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.HOPF_SUPERCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        supercritical_distribution_empirical.build(),
                        supercritical_distribution_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 8: bautin
                html.Div(
                    [
                        html.Label(Labels.CODIMENSION_TWO, style=Styles.LABEL),
                        bautin_distribution.build(),
                        bogdanov_takens_distribution.build(),
                        double_hopf_distribution.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
            ],
            style=Styles.DIV_CONTROL,
        ),
        # DIV_GRAPHS
        html.Div(
            [
                # DIV_GRAPH_DISTRIBUTION
                html.Div(
                    [
                        # bifuraction distribution sdsr
                        dcc.Graph(
                            id=IDs.FIGURE_DISTRIBUTION_SD_SR,
                            figure=glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SD_SR],
                            style=Styles.PLOT,
                            config={"displayModeBar": True},
                        ),
                    ],
                    id=IDs.DIV_DISTRIBUTION_SD_SR,
                    style=Styles.DIV_GRAPH_DISTRIBUTION_PLOT,
                ),
                # DIV_GRAPH_DISTRIBUTION
                html.Div(
                    [
                        # bifuraction distribution sdsr
                        dcc.Graph(
                            id=IDs.FIGURE_DISTRIBUTION_SR_SL,
                            figure=glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SR_SL],
                            style=Styles.PLOT,
                            config={"displayModeBar": True},
                        ),
                    ],
                    id=IDs.DIV_DISTRIBUTION_SR_SL,
                    style=Styles.DIV_GRAPH_DISTRIBUTION_PLOT,
                ),
                # DIV_GRAPH_DISTRIBUTION
                html.Div(
                    [
                        # bifuraction distribution sdsr
                        dcc.Graph(
                            id=IDs.FIGURE_DISTRIBUTION_SL_SD,
                            figure=glob.figures.bifurcation_distribution[BifurcationDistributionTypes.SL_SD],
                            style=Styles.PLOT,
                            config={"displayModeBar": True},
                        ),
                    ],
                    id=IDs.DIV_DISTRIBUTION_SL_SD,
                    style=Styles.DIV_GRAPH_DISTRIBUTION_PLOT,
                ),
            ],
            id=IDs.DIV_MATRIX_03,
            style=Styles.DIV_GRAPHS,
        ),
    ]
)
