from dash import dcc

from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.frontend.ids import IDs


def build() -> dcc.Input:
    """Build and return a compact native color picker component."""
    return dcc.Input(
        id=IDs.COLOR_HEATMAP_START_PICKER,
        type="color",
        value=StaticOptions.DEFAULT_START_COLOR,
        debounce=True,
        style={
            "width": "100%",
            "cursor": "pointer",
            "height": "36px",
            "borderRadius": "5px",
            "border": "1px solid #ccc",
            "padding": "0 10px",
        },
    )
