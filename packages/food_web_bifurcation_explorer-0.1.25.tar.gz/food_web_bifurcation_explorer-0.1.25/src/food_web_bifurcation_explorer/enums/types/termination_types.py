from enum import Enum, unique

@unique
class TerminationTypes(str, Enum):
    """Enumeration for termination types."""

    FRONTIER = "frontier"
    INTERNAL_ERROR = "outOfParameters"
    EXTINCT = "extinction"
