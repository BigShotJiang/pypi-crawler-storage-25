from enum import Enum, unique

from food_web_bifurcation_explorer.enums.types.bifurcation.bifurcation_codimension_one_types import BifurcationCodimensionOneTypes
from food_web_bifurcation_explorer.enums.types.bifurcation.bifurcation_codimension_two_types import BifurcationCodimensionTwoTypes
from food_web_bifurcation_explorer.enums.types.termination_types import TerminationTypes


@unique
class TraceTypes(str, Enum):
    """Enumeration for bifurcation types."""

    # bifurcations of codimension one
    SADDLENODE = BifurcationCodimensionOneTypes.SADDLENODE.value
    TRANSCRITICAL = BifurcationCodimensionOneTypes.TRANSCRITICAL.value
    HOPF_SUBCRITICAL = BifurcationCodimensionOneTypes.HOPF_SUBCRITICAL.value
    HOPF_SUPERCRITICAL = BifurcationCodimensionOneTypes.HOPF_SUPERCRITICAL.value
    # bifurcations of codimension two
    BAUTIN = BifurcationCodimensionTwoTypes.BAUTIN.value
    BOGDANOV_TAKENS = BifurcationCodimensionTwoTypes.BOGDANOV_TAKENS.value
    DOUBLE_HOPF = BifurcationCodimensionTwoTypes.DOUBLE_HOPF.value
    # terminations
    FRONTIER = TerminationTypes.FRONTIER.value
    INTERNAL_ERROR = TerminationTypes.INTERNAL_ERROR.value
    EXTINCT = TerminationTypes.EXTINCT.value
