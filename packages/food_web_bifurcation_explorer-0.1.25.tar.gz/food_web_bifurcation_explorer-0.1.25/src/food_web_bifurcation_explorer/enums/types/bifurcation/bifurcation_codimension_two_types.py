from enum import Enum, unique


@unique
class BifurcationCodimensionTwoTypes(str, Enum):
    """Enumeration for codimension two bifurcation types."""

    # codimension two bifurcations
    BAUTIN = "bautin"
    BOGDANOV_TAKENS = "bogdanovTakens"
    DOUBLE_HOPF = "doubleHopf"
