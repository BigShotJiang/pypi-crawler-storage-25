from typing import Any

import plotly.graph_objects as go
from dash import Input, Output, callback, html

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.resolutions.ternary_heatmap_resolutions import TernaryHeatmapResolutions
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.graph.ternary.heatmap_ternary.update_heatmap_ternary import update_heatmap_ternary


# callback to update graphs
@callback(
    # outputs
    [
        Output(IDs.FIGURE_HEATMAP_TERNARY, "figure"),
        Output(IDs.TEXT_HEATMAP_NETWORK_LIST, "children"),
    ],
    # inputs
    [
        # heatmap options
        Input(IDs.DROPDOWN_HEATMAP_RESOLUTION, "value"),
        Input(IDs.TEXTFIELD_HEATMAP_MIN_VALUE, "value"),
        Input(IDs.COLOR_HEATMAP_START_PICKER, "value"),
        Input(IDs.COLOR_HEATMAP_END_PICKER, "value"),
        Input(IDs.CHECKBOX_HEATMAP_LOGARITHMIC, "value"),
        # codimension one bifurcations
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_SADDLENODE_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_SADDLENODE_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE, "value"),
        # codimension two bifurcations
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_BAUTIN, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_BOGDANOV_TAKENS, "value"),
        Input(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_DOUBLE_HOPF, "value"),
        # clicked coordinate
        Input(IDs.FIGURE_HEATMAP_TERNARY, "clickData"),
    ],
    # running
    running=[
        # Heatmap options
        (Output(IDs.DROPDOWN_HEATMAP_RESOLUTION, "disabled"), True, False),
        (Output(IDs.TEXTFIELD_HEATMAP_MIN_VALUE, "disabled"), True, False),
        (Output(IDs.COLOR_HEATMAP_START_PICKER, "disabled"), True, False),
        (Output(IDs.COLOR_HEATMAP_END_PICKER, "disabled"), True, False),
        (Output(IDs.CHECKBOX_HEATMAP_LOGARITHMIC, "disabled"), True, False),
        # codimension one bifurcations
        (Output(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_SADDLENODE_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_SADDLENODE_ALTERNATIVE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE, "disabled"), True, False),
        # codimension two bifurcations
        (Output(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_BAUTIN, "disabled"), True, False),
        (Output(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_BOGDANOV_TAKENS, "disabled"), True, False),
        (Output(IDs.CHECKBOX_HEATMAP_BIFURCATIONS_DOUBLE_HOPF, "disabled"), True, False),
    ],
)
# update heatmap graph
def update_heatmap_graphs(
    heatmap_resolution: str,
    heatmap_ternary_min_value: int,
    heatmap_start_color: str,
    heatmap_end_color: str,
    heatmap_ternary_logarithmic: list[bool],
    # codimension one bifurcations
    bifurcations_saddlenode_empirical: list[bool],
    bifurcations_saddlenode_alternative: list[bool],
    bifurcations_transcritical_empirical: list[bool],
    bifurcations_transcritical_alternative: list[bool],
    bifurcations_hopf_subcritical_empirical: list[bool],
    bifurcations_hopf_subcritical_alternative: list[bool],
    bifurcations_hopf_supercritical_empirical: list[bool],
    bifurcations_hopf_supercritical_alternative: list[bool],
    # codimension two bifurcations
    bifurcations_bautin: list[bool],
    bifurcations_bogdanov_takens: list[bool],
    bifurcations_double_hopf: list[bool],
    click_data: dict[str, Any],
) -> tuple[go.Figure]:

    # check if update parameter type
    try:
        glob.config.ternary_heatmap_resolution = TernaryHeatmapResolutions(heatmap_resolution)
    except ValueError:
        pass

    # heatmap min value
    glob.config.heatmap_ternary_min_value = heatmap_ternary_min_value

    # update color gradient
    if (glob.config.heatmap_start_color != heatmap_start_color) or (glob.config.heatmap_end_color != heatmap_end_color):
        glob.config.heatmap_start_color = heatmap_start_color
        glob.config.heatmap_end_color = heatmap_end_color

    # heatmap logarithmic
    glob.config.heatmap_ternary_logarithmic = bool(heatmap_ternary_logarithmic)

    # update only bifurcation flags
    glob.config.drawing_options.update_heatmap_flags(
        bool(bifurcations_saddlenode_empirical),
        bool(bifurcations_saddlenode_alternative),
        bool(bifurcations_transcritical_empirical),
        bool(bifurcations_transcritical_alternative),
        bool(bifurcations_hopf_subcritical_empirical),
        bool(bifurcations_hopf_subcritical_alternative),
        bool(bifurcations_hopf_supercritical_empirical),
        bool(bifurcations_hopf_supercritical_alternative),
        bool(bifurcations_bautin),
        bool(bifurcations_bogdanov_takens),
        bool(bifurcations_double_hopf),
    )

    # update ternary heatmap
    glob.figures.heatmap_ternary, visible_networks = update_heatmap_ternary()

    # join network strings
    networks_html = [html.P(net, style={"margin": "0"}) for net in visible_networks]

    # update heatmap clicked coordinate
    glob.config.heatmap_clicked_coordinate.update_coordinate(click_data)

    # return all figures
    return (
        # scatter ternary
        glob.figures.heatmap_ternary,
        networks_html,
    )
