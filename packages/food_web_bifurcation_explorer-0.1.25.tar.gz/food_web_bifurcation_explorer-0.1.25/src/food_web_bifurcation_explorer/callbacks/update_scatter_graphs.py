import plotly.graph_objects as go
from dash import Input, Output, Patch, callback, no_update

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.data.plot_data import BranchData
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.static_options import StaticOptions
from food_web_bifurcation_explorer.enums.types.bifurcation_diagram_types import BifurcationDiagramTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.eigen_values_jump import EigenValuesJump
from food_web_bifurcation_explorer.enums.types.hopf_parameter_types import HopfParameterTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.frontend.scatter_module.biomass_compartment import biomass_compartment_list
from food_web_bifurcation_explorer.graph.bifurcation_diagram.build import build_bifurcation_diagram
from food_web_bifurcation_explorer.graph.bifurcation_diagram.update import update_bifurcation_diagram
from food_web_bifurcation_explorer.graph.eigenvalue_spectrum.update import update_eigenvalue_spectrum
from food_web_bifurcation_explorer.graph.hopf_parameter_plot.update import update_hopf_parameter_plot
from food_web_bifurcation_explorer.graph.ternary.scatter_ternary.update_scatter_ternary import update_scatter_ternary


# callback to update graphs
@callback(
    # outputs
    [
        # general options
        Output(IDs.DROPDOWN_SCATTER_PARAMETER_TYPE, "value"),
        Output(IDs.TEXTFIELD_SCATTER_FIXED_PARAMETER_VALUE, "value"),
        # compartments
        Output(IDs.DROPDOWN_SCATTER_COMPARTMENT_FIRST, "options"),
        Output(IDs.DROPDOWN_SCATTER_COMPARTMENT_FIRST, "value"),
        Output(IDs.DROPDOWN_SCATTER_COMPARTMENT_SECOND, "options"),
        Output(IDs.DROPDOWN_SCATTER_COMPARTMENT_SECOND, "value"),
        # eigen values jump (empirical)
        Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_A, "n_clicks"),
        Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_B, "n_clicks"),
        Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_C, "n_clicks"),
        Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_D, "n_clicks"),
        Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_E, "n_clicks"),
        # eigen values jump (alternative)
        Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_A, "n_clicks"),
        Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_B, "n_clicks"),
        Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_C, "n_clicks"),
        Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_D, "n_clicks"),
        Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_E, "n_clicks"),
        # eigenvalue spectrum indexes
        Output(IDs.TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL, "value"),
        Output(IDs.TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE, "value"),
        # ternary
        Output(IDs.FIGURE_SCATTER_TERNARY, "figure"),
        # bifurcation diagram plots
        Output(IDs.FIGURE_SCATTER_BIFURCATION_DIAGRAM_FIRST, "figure"),
        Output(IDs.FIGURE_SCATTER_BIFURCATION_DIAGRAM_SECOND, "figure"),
        # eigen values spectrum plots
        Output(IDs.FIGURE_SCATTER_EIGENVALUE_SPECTRUM_EMPIRICAL, "figure"),
        Output(IDs.FIGURE_SCATTER_EIGENVALUE_SPECTRUM_ALTERNATIVE, "figure"),
        # hopf parameter plots
        Output(IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_L1, "figure"),
        Output(IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_OSCILLATION_FREQUENCY, "figure"),
        Output(IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_TRANSVERSAL_CROSSING_SPEED, "figure"),
        Output(IDs.FIGURE_SCATTER_HOPF_PARAMETER_PLOT_NORMALIZATION_ERROR, "figure"),
    ],
    # inputs
    [
        # scatter general options
        Input(IDs.DROPDOWN_SCATTER_NETWORK, "value"),
        Input(IDs.DROPDOWN_SCATTER_COMPARTMENT_FIRST, "value"),
        Input(IDs.DROPDOWN_SCATTER_COMPARTMENT_SECOND, "value"),
        Input(IDs.DROPDOWN_SCATTER_PARAMETER_TYPE, "value"),
        Input(IDs.TEXTFIELD_SCATTER_FIXED_PARAMETER_VALUE, "value"),
        # branches
        Input(IDs.CHECKBOX_SCATTER_EQUILIBRIA_AREA, "value"),
        Input(IDs.CHECKBOX_SCATTER_EQUILIBRIA_STABLE, "value"),
        Input(IDs.CHECKBOX_SCATTER_EQUILIBRIA_UNSTABLE, "value"),
        Input(IDs.CHECKBOX_SCATTER_EQUILIBRIA_OVERINFORMATION, "value"),
        # codimension one bifurcations
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_SADDLENODE_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_SADDLENODE_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE, "value"),
        # codimension two bifurcations
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_BAUTIN, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_BOGDANOV_TAKENS, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_DOUBLE_HOPF, "value"),
        # envelopes
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_ENVELOPE_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_ENVELOPE_ALTERNATIVE, "value"),
        # others
        Input(IDs.CHECKBOX_SCATTER_OTHERS_EXTINCT, "value"),
        Input(IDs.CHECKBOX_SCATTER_OTHERS_INTERNALERROR, "value"),
        Input(IDs.CHECKBOX_SCATTER_OTHERS_EIGENVALUE_SPECTRUM_INDEX, "value"),
        # draw options
        Input(IDs.CHECKBOX_SCATTER_DRAW_BRANCH_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SCATTER_DRAW_BRANCH_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SCATTER_DRAW_LINES, "value"),
        Input(IDs.CHECKBOX_SCATTER_DRAW_POINTS, "value"),
        # eigen values jump (empirical)
        Input(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_A, "n_clicks"),
        Input(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_B, "n_clicks"),
        Input(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_C, "n_clicks"),
        Input(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_D, "n_clicks"),
        Input(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_E, "n_clicks"),
        # eigen values jump (alternative)
        Input(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_A, "n_clicks"),
        Input(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_B, "n_clicks"),
        Input(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_C, "n_clicks"),
        Input(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_D, "n_clicks"),
        Input(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_E, "n_clicks"),
        # eigen values spectrum
        Input(IDs.TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL, "value"),
        Input(IDs.TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE, "value"),
    ],
    # running
    running=[
        # General options
        (Output(IDs.DROPDOWN_SCATTER_NETWORK, "disabled"), True, False),
        (Output(IDs.DROPDOWN_SCATTER_COMPARTMENT_FIRST, "disabled"), True, False),
        (Output(IDs.DROPDOWN_SCATTER_COMPARTMENT_SECOND, "disabled"), True, False),
        (Output(IDs.DROPDOWN_SCATTER_PARAMETER_TYPE, "disabled"), True, False),
        (Output(IDs.TEXTFIELD_SCATTER_FIXED_PARAMETER_VALUE, "disabled"), True, False),
        # Branches
        (Output(IDs.CHECKBOX_SCATTER_EQUILIBRIA_AREA, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_EQUILIBRIA_STABLE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_EQUILIBRIA_UNSTABLE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_EQUILIBRIA_OVERINFORMATION, "disabled"), True, False),
        # codimension one bifurcations
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_SADDLENODE_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_SADDLENODE_ALTERNATIVE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE, "disabled"), True, False),
        # codimension two bifurcations
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_BAUTIN, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_BOGDANOV_TAKENS, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_DOUBLE_HOPF, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_ENVELOPE_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_BIFURCATIONS_HOPF_ENVELOPE_ALTERNATIVE, "disabled"), True, False),
        # Others
        (Output(IDs.CHECKBOX_SCATTER_OTHERS_EXTINCT, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_OTHERS_INTERNALERROR, "disabled"), True, False),
        # eigen values jump (empirical)
        (Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_A, "disabled"), True, False),
        (Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_B, "disabled"), True, False),
        (Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_C, "disabled"), True, False),
        (Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_D, "disabled"), True, False),
        (Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_EMPIRICAL_E, "disabled"), True, False),
        # eigen values jump (alternative)
        (Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_A, "disabled"), True, False),
        (Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_B, "disabled"), True, False),
        (Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_C, "disabled"), True, False),
        (Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_D, "disabled"), True, False),
        (Output(IDs.BUTTON_SCATTER_EIGENVALUE_SPECTRUM_JUMP_ALTERNATIVE_E, "disabled"), True, False),
        # Draw options
        (Output(IDs.CHECKBOX_SCATTER_DRAW_BRANCH_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_DRAW_BRANCH_ALTERNATIVE, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_DRAW_LINES, "disabled"), True, False),
        (Output(IDs.CHECKBOX_SCATTER_DRAW_POINTS, "disabled"), True, False),
        # eigen values spectrum index
        (Output(IDs.TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL, "disabled"), True, False),
        (Output(IDs.TEXTFIELD_SCATTER_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE, "disabled"), True, False),
    ],
)
# update scatter graph
def update_scatter_graphs(
    network: str,
    compartment_first_index: int,
    compartment_second_index: int,
    parameter_type_str: str,
    fixed_parameter_value: float,
    # equilibria
    equilibria_area: list[bool],
    equilibria_stable: list[bool],
    equilibria_unstable: list[bool],
    equilibria_over_information: list[bool],
    # codimension one bifurcations
    bifurcations_saddlenode_empirical: list[bool],
    bifurcations_saddlenode_alternative: list[bool],
    bifurcations_transcritical_empirical: list[bool],
    bifurcations_transcritical_alternative: list[bool],
    bifurcations_hopf_subcritical_empirical: list[bool],
    bifurcations_hopf_subcritical_alternative: list[bool],
    bifurcations_hopf_supercritical_empirical: list[bool],
    bifurcations_hopf_supercritical_alternative: list[bool],
    # codimension two bifurcations
    bifurcations_bautin: list[bool],
    bifurcations_bogdanov_takens: list[bool],
    bifurcations_double_hopf: list[bool],
    # envelopes
    hopf_envelope_empirical: list[bool],
    hopf_envelope_alternative: list[bool],
    # others
    extinct: list[bool],
    internal_error: list[bool],
    eigenvalue_spectrum_symbols: list[bool],
    # drawing options
    draw_branch_empirical: list[bool],
    draw_branch_alternative: list[bool],
    draw_lines: list[bool],
    draw_points: list[bool],
    # eigen values jump (empirical)
    eigenvalue_spectrum_jump_empirical_frontier_a: int,
    eigenvalue_spectrum_jump_empirical_frontier_b: int,
    eigenvalue_spectrum_jump_empirical_frontier_c: int,
    eigenvalue_spectrum_jump_empirical_frontier_d: int,
    eigenvalue_spectrum_jump_empirical_frontier_e: int,
    # eigen values jump (alternative)
    eigenvalue_spectrum_jump_alternative_frontier_a: int,
    eigenvalue_spectrum_jump_alternative_frontier_b: int,
    eigenvalue_spectrum_jump_alternative_frontier_c: int,
    eigenvalue_spectrum_jump_alternative_frontier_d: int,
    eigenvalue_spectrum_jump_alternative_frontier_e: int,
    # eigenvalue spectrum index
    eigenvalue_spectrum_index_empirical: int,
    eigenvalue_spectrum_index_alternative: int,
) -> tuple[Patch, go.Figure, go.Figure, go.Figure, go.Figure, str]:
    # update drawing config
    glob.config.drawing_options.update_scatter_flags(
        # bifurcations
        bool(bifurcations_saddlenode_empirical),
        bool(bifurcations_saddlenode_alternative),
        bool(bifurcations_transcritical_empirical),
        bool(bifurcations_transcritical_alternative),
        bool(bifurcations_hopf_subcritical_empirical),
        bool(bifurcations_hopf_subcritical_alternative),
        bool(bifurcations_hopf_supercritical_empirical),
        bool(bifurcations_hopf_supercritical_alternative),
        bool(bifurcations_bautin),
        bool(bifurcations_bogdanov_takens),
        bool(bifurcations_double_hopf),
        # scatter options
        bool(equilibria_area),
        bool(equilibria_stable),
        bool(equilibria_unstable),
        bool(equilibria_over_information),
        bool(hopf_envelope_empirical),
        bool(hopf_envelope_alternative),
        bool(extinct),
        bool(internal_error),
        bool(eigenvalue_spectrum_symbols),
        bool(draw_branch_empirical),
        bool(draw_branch_alternative),
        bool(draw_lines),
        bool(draw_points),
    )

    # check if update network
    if glob.config.network != network:
        # update network
        glob.config.update_network(network)

        # load ternary data
        glob.plot_data.load_ternary_data()

        # read branch datas
        glob.plot_data.load_branch_datas()

        # redraw all scatter plots
        glob.config.drawing_options.redraw_all_scatter_graphs()

    # check if update parameter type
    try:
        parameter_type = ParameterTypes(parameter_type_str)
        if glob.config.fixed_parameter_type != parameter_type:
            # set new fixed parameter type
            glob.config.update_fixed_parameter_type(parameter_type)

            # redraw all scatter plots
            glob.config.drawing_options.redraw_all_scatter_graphs()
    except ValueError:
        pass

    # check if update fixed parameter value
    if glob.config.fixed_parameter_value != fixed_parameter_value:
        # set new value
        fixed_parameter_value = glob.config.update_fixed_parameter_value(fixed_parameter_value)

        # read branch datas
        glob.plot_data.load_branch_datas()

        # update only branches in ternary
        glob.config.drawing_options.scatter_ternary_options.redraw_ternary_branches = True

        # redraw bifurcation diagrams
        for bifurcation_diagram in BifurcationDiagramTypes:
            glob.config.drawing_options.redraw_bifurcation_diagram_graphs(bifurcation_diagram)

        # redraw eigen values spectrum
        for branchType in BranchTypes:
            glob.config.drawing_options.eigenvalue_spectrum[branchType].redraw_all()

        # redraw hopf bifurcations
        glob.config.drawing_options.redraw_hopf_bifurcations_graphs()

    # check if update first compartment
    if compartment_first_index and glob.config.compartment_index[BifurcationDiagramTypes.FIRST] != compartment_first_index:
        # update first compartment
        glob.config.update_compartment(BifurcationDiagramTypes.FIRST, compartment_first_index)

        # rebuild figures
        glob.figures.bifurcation_diagrams[BifurcationDiagramTypes.FIRST] = build_bifurcation_diagram(BifurcationDiagramTypes.FIRST)

        # redraw bifurcation diagram
        glob.config.drawing_options.redraw_bifurcation_diagram_graphs(BifurcationDiagramTypes.FIRST)

    # check if update second compartment
    if compartment_second_index and glob.config.compartment_index[BifurcationDiagramTypes.SECOND] != compartment_second_index:
        # update second compartment
        glob.config.update_compartment(BifurcationDiagramTypes.SECOND, compartment_second_index)

        # rebuild figures
        glob.figures.bifurcation_diagrams[BifurcationDiagramTypes.SECOND] = build_bifurcation_diagram(BifurcationDiagramTypes.SECOND)

        # redraw bifurcation diagram
        glob.config.drawing_options.redraw_bifurcation_diagram_graphs(BifurcationDiagramTypes.SECOND)

    # get branch data
    branch_data_empirical: BranchData = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][BranchTypes.EMPIRICAL]

    # check if jump empirical
    if eigenvalue_spectrum_jump_empirical_frontier_a > 0:
        # overwritte value of eigenvalue_spectrum_index_empirical ensuring that ensure that we have at least one transition
        if len(branch_data_empirical.transition_indexes) > EigenValuesJump.A.value:
            eigenvalue_spectrum_index_empirical = branch_data_empirical.transition_indexes[EigenValuesJump.A.value]
        else:
            eigenvalue_spectrum_index_empirical = 0

    # check if jump empirical
    if eigenvalue_spectrum_jump_empirical_frontier_b > 0:
        # overwritte value of eigenvalue_spectrum_index_empirical ensuring that ensure that we have at least one transition
        if len(branch_data_empirical.transition_indexes) > EigenValuesJump.B.value:
            eigenvalue_spectrum_index_empirical = branch_data_empirical.transition_indexes[EigenValuesJump.B.value]
        else:
            eigenvalue_spectrum_index_empirical = 0

    # check if jump empirical
    if eigenvalue_spectrum_jump_empirical_frontier_c > 0:
        # overwritte value of eigenvalue_spectrum_index_empirical ensuring that ensure that we have at least one transition
        if len(branch_data_empirical.transition_indexes) > EigenValuesJump.C.value:
            eigenvalue_spectrum_index_empirical = branch_data_empirical.transition_indexes[EigenValuesJump.C.value]
        else:
            eigenvalue_spectrum_index_empirical = 0

    # check if jump empirical
    if eigenvalue_spectrum_jump_empirical_frontier_d > 0:
        # overwritte value of eigenvalue_spectrum_index_empirical ensuring that ensure that we have at least one transition
        if len(branch_data_empirical.transition_indexes) > EigenValuesJump.D.value:
            eigenvalue_spectrum_index_empirical = branch_data_empirical.transition_indexes[EigenValuesJump.D.value]
        else:
            eigenvalue_spectrum_index_empirical = 0

    # check if jump empirical
    if eigenvalue_spectrum_jump_empirical_frontier_e > 0:
        # overwritte value of eigenvalue_spectrum_index_empirical ensuring that ensure that we have at least one transition
        if len(branch_data_empirical.transition_indexes) > EigenValuesJump.E.value:
            eigenvalue_spectrum_index_empirical = branch_data_empirical.transition_indexes[EigenValuesJump.E.value]
        else:
            eigenvalue_spectrum_index_empirical = 0

    # ensure that eigenvalue_spectrum_index_empirical is not negative
    if eigenvalue_spectrum_index_empirical < 0:
        eigenvalue_spectrum_index_empirical = 0

    # check if update eigenvalue spectrum empirical index
    if glob.config.eigenvalue_spectrum_index[BranchTypes.EMPIRICAL] != eigenvalue_spectrum_index_empirical:
        # update eigen value spectrum empirical index
        glob.config.update_eigenvalue_spectrum_index(BranchTypes.EMPIRICAL, eigenvalue_spectrum_index_empirical)

        # redraw eigenvalue spectrum empirical figure
        glob.config.drawing_options.eigenvalue_spectrum[BranchTypes.EMPIRICAL].redraw_all()

        # mark only the empirical index for redrawing in bifurcation diagram
        glob.config.drawing_options.bifurcation_diagrams_options[BifurcationDiagramTypes.FIRST].redraw_eigenvalue_spectrum_symbol_empirical = True

    # get branch data
    branch_data_alternative: BranchData = glob.plot_data.branch_datas[glob.config.fixed_parameter_type][BranchTypes.ALTERNATIVE]

    # check if jump alternative
    if eigenvalue_spectrum_jump_alternative_frontier_a > 0:

        # overwritte value of eigenvalue_spectrum_index_alternative ensuring that ensure that we have at least one transition
        if len(branch_data_alternative.transition_indexes) > EigenValuesJump.A.value:
            eigenvalue_spectrum_index_alternative = branch_data_alternative.transition_indexes[EigenValuesJump.A.value]
        else:
            eigenvalue_spectrum_index_alternative = 0

    # check if jump alternative
    if eigenvalue_spectrum_jump_alternative_frontier_b > 0:

        # overwritte value of eigenvalue_spectrum_index_alternative ensuring that ensure that we have at least one transition
        if len(branch_data_alternative.transition_indexes) > EigenValuesJump.B.value:
            eigenvalue_spectrum_index_alternative = branch_data_alternative.transition_indexes[EigenValuesJump.B.value]
        else:
            eigenvalue_spectrum_index_alternative = 0

    # check if jump alternative
    if eigenvalue_spectrum_jump_alternative_frontier_c > 0:

        # overwritte value of eigenvalue_spectrum_index_alternative ensuring that ensure that we have at least one transition
        if len(branch_data_alternative.transition_indexes) > EigenValuesJump.C.value:
            eigenvalue_spectrum_index_alternative = branch_data_alternative.transition_indexes[EigenValuesJump.C.value]
        else:
            eigenvalue_spectrum_index_alternative = 0

    # check if jump alternative
    if eigenvalue_spectrum_jump_alternative_frontier_d > 0:

        # overwritte value of eigenvalue_spectrum_index_alternative ensuring that ensure that we have at least one transition
        if len(branch_data_alternative.transition_indexes) > EigenValuesJump.D.value:
            eigenvalue_spectrum_index_alternative = branch_data_alternative.transition_indexes[EigenValuesJump.D.value]
        else:
            eigenvalue_spectrum_index_alternative = 0

    # check if jump alternative
    if eigenvalue_spectrum_jump_alternative_frontier_e > 0:

        # overwritte value of eigenvalue_spectrum_index_alternative ensuring that ensure that we have at least one transition
        if len(branch_data_alternative.transition_indexes) > EigenValuesJump.E.value:
            eigenvalue_spectrum_index_alternative = branch_data_alternative.transition_indexes[EigenValuesJump.E.value]
        else:
            eigenvalue_spectrum_index_alternative = 0

    # ensure that eigenvalue_spectrum_index_alternative is not negative
    if eigenvalue_spectrum_index_alternative < 0:
        eigenvalue_spectrum_index_alternative = 0

    # check if update eigenvalue spectrum empirical index
    if glob.config.eigenvalue_spectrum_index[BranchTypes.ALTERNATIVE] != eigenvalue_spectrum_index_alternative:
        # update eigen value spectrum alternative index
        glob.config.update_eigenvalue_spectrum_index(BranchTypes.ALTERNATIVE, eigenvalue_spectrum_index_alternative)

        # redraw eigenvalue spectrum alternative figure
        glob.config.drawing_options.eigenvalue_spectrum[BranchTypes.ALTERNATIVE].redraw_all()

        # mark only the alternative index for redrawing in bifurcation diagram
        glob.config.drawing_options.bifurcation_diagrams_options[BifurcationDiagramTypes.FIRST].redraw_eigenvalue_spectrum_symbol_alternative = True

    # show info (only for debug)
    if StaticOptions.DEBUG_DRAWING_OPTIONS:
        glob.config.drawing_options.is_scatter_redraw_required()

    # update ternary scatter
    glob.figures.scatter_ternary = update_scatter_ternary()

    # update both bifurcation diagrams
    for bifurcation_diagram_type in BifurcationDiagramTypes:
        glob.figures.bifurcation_diagrams[bifurcation_diagram_type] = update_bifurcation_diagram(bifurcation_diagram_type)

    # update eigen values
    glob.figures.eigenvalue_spectrum_empirical = update_eigenvalue_spectrum(glob.figures.eigenvalue_spectrum_empirical, BranchTypes.EMPIRICAL)
    glob.figures.eigenvalue_spectrum_alternative = update_eigenvalue_spectrum(glob.figures.eigenvalue_spectrum_alternative, BranchTypes.ALTERNATIVE)

    # declare hopf parameter updates as no_update by default
    hopf_parameter_updates = [no_update] * len(HopfParameterTypes)

    # only update if at least one of the hopf parameter plots needs to be updated. In other case, send no_update to avoid unnecessary updates
    if any(glob.config.drawing_options.redraw_hopf_bifurcation.values()):
        # update figures
        glob.figures.hopf_parameters[HopfParameterTypes.L1] = update_hopf_parameter_plot(HopfParameterTypes.L1, Labels.L1, Labels.L1_UNIT)
        glob.figures.hopf_parameters[HopfParameterTypes.OSCILLATION_FREQUENCY] = update_hopf_parameter_plot(
            HopfParameterTypes.OSCILLATION_FREQUENCY, Labels.OSCILLATION_FREQUENCY, Labels.OSCILLATION_FREQUENCY_UNIT
        )
        glob.figures.hopf_parameters[HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED] = update_hopf_parameter_plot(
            HopfParameterTypes.TRANSVERSAL_CROSSING_SPEED, Labels.TRANSVERSAL_CROSSING_SPEED, Labels.TRANSVERSAL_CROSSING_SPEED_UNIT
        )
        glob.figures.hopf_parameters[HopfParameterTypes.NORMALIZATION_ERROR] = update_hopf_parameter_plot(
            HopfParameterTypes.NORMALIZATION_ERROR, Labels.NORMALIZATION_ERROR, Labels.NORMALIZATION_ERROR_UNIT
        )

        # send figures as update
        hopf_parameter_updates = list(glob.figures.hopf_parameters.values())

    # return both figure and the empty error message
    return (
        # dropdown and text fields
        parameter_type_str,
        fixed_parameter_value,
        biomass_compartment_list.get_current_compartment_list(),
        glob.config.compartment_index[BifurcationDiagramTypes.FIRST],
        biomass_compartment_list.get_current_compartment_list(),
        glob.config.compartment_index[BifurcationDiagramTypes.SECOND],
        # empirical eigenvalue spectrum jump
        0,
        0,
        0,
        0,
        0,
        # alternative eigenvalue spectrum jump
        0,
        0,
        0,
        0,
        0,
        # eigenvalue spectrum index
        glob.config.eigenvalue_spectrum_index[BranchTypes.EMPIRICAL],
        glob.config.eigenvalue_spectrum_index[BranchTypes.ALTERNATIVE],
        # ternary
        glob.figures.scatter_ternary,
        # bifurcation diagrams
        glob.figures.bifurcation_diagrams[BifurcationDiagramTypes.FIRST],
        glob.figures.bifurcation_diagrams[BifurcationDiagramTypes.SECOND],
        # eigen values
        glob.figures.eigenvalue_spectrum_empirical,
        glob.figures.eigenvalue_spectrum_alternative,
        # hopf parameter plots
        hopf_parameter_updates[0],
        hopf_parameter_updates[1],
        hopf_parameter_updates[2],
        hopf_parameter_updates[3],
    )
