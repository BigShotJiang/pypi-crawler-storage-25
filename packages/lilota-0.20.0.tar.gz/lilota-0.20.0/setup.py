from setuptools import setup, find_packages

setup(
  name='lilota',
  version='0.20.0',
  packages=find_packages(include=['lilota']),
)
