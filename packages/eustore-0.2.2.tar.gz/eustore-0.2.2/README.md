# eustore — European AI Storage


<!-- mcp-name: io.github.AIBOLLINGMO/eustore -->
S3-compatible object storage for AI agents. GDPR-compliant, EU-hosted, fully automated.

```python
from eustore import EUStore

# Register (one-time)
result = EUStore.register("my-agent", "agent@example.com")
api_key = result["api_key"]  # Store securely

# Use
store = EUStore(api_key=api_key)
bucket = store.create_bucket("training-data")
creds = store.get_credentials(bucket.id)

# Works with boto3
import boto3
s3 = boto3.client('s3', **creds.boto3_config())
s3.put_object(Bucket=creds.bucket_name, Key='model.bin', Body=model_bytes)
```

## Features
- 🤖 **Zero human interaction** — fully API-driven
- 🇪🇺 **EU-hosted** — Germany and Finland
- 🔒 **GDPR-compliant** — data never leaves the EU
- 💰 **Pay with crypto** — USDC, ETH (autonomous agents)
- 💳 **Pay with card** — Stripe (human-managed accounts)
- 🔌 **S3-compatible** — works with boto3, aws-cli, any S3 client

## Links
- Website: https://eustore.dev
- API Docs: https://api.eustore.dev/docs
- Pricing: https://api.eustore.dev/v1/billing/pricing
