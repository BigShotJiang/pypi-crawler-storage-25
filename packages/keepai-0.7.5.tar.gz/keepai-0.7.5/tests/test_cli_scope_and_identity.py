from pathlib import Path
from types import SimpleNamespace

import pytest
from typer.testing import CliRunner

from keep import state
from keep._cli.spawn import wait_for_worker_ready as _wait_for_worker_ready
from keep.cli import app


runner = CliRunner()


def _create_active_mission(name: str) -> None:
    """Create a mission and mark it active — required for send/kick/worker create tests."""
    m = state.create_mission(name)
    m["status"] = "active"
    state.save_mission(name, m)


W1 = "11111111-1111-4111-8111-111111111111"
W2 = "11111111-1111-4111-8111-222222222222"
WMISS = "11111111-1111-4111-8111-333333333333"
S1 = "22222222-2222-4222-8222-222222222222"
SMISS = "22222222-2222-4222-8222-333333333333"


@pytest.fixture
def isolated_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    state_dir = tmp_path / "state"
    missions_dir = state_dir / "missions"
    missions_dir.mkdir(parents=True)
    monkeypatch.setattr(state, "STATE_DIR", state_dir)
    monkeypatch.setattr(state, "GLOBAL_FILE", state_dir / "global.json")
    monkeypatch.setattr(state, "MISSIONS_DIR", missions_dir)
    state.save_global(state.new_global())
    return state_dir


def test_root_help_does_not_advertise_mission_flag_scope_fallback() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "MATION_MISSION" not in result.stdout
    assert "-m" not in result.stdout
    assert "--mission" not in result.stdout


def test_mission_scoped_help_uses_path_not_option_scope() -> None:
    result = runner.invoke(app, ["mission-123", "task", "--help"])
    assert result.exit_code == 0
    assert "create" in result.stdout
    assert "update" in result.stdout
    assert "remove" in result.stdout
    assert "list" in result.stdout
    assert "show" in result.stdout
    assert "-m" not in result.stdout
    assert "--mission" not in result.stdout


def test_supervisor_create_help_exposes_name_and_path_only() -> None:
    result = runner.invoke(app, ["mission-123", "supervisor", "create", "--help"])
    assert result.exit_code == 0
    assert "--name" in result.stdout
    assert "--path" in result.stdout
    assert "--session" not in result.stdout


def test_worker_create_help_exposes_name_and_path_only() -> None:
    result = runner.invoke(app, ["mission-123", "worker", "create", "--help"])
    assert result.exit_code == 0
    assert "--name" in result.stdout
    assert "--path" in result.stdout
    assert "--session" not in result.stdout


def test_worker_create_fails_fast_when_path_missing(isolated_state: Path) -> None:
    _create_active_mission("mission-123")

    result = runner.invoke(
        app,
        ["mission-123", "worker", "create", "--path", "/tmp/keep-nonexistent-worker-path-xyz"],
    )

    assert result.exit_code == 1
    assert "path 不存在或不是目录" in result.stderr


def test_supervisor_create_fails_fast_when_path_missing(isolated_state: Path) -> None:
    state.create_mission("mission-123")

    result = runner.invoke(
        app,
        ["mission-123", "supervisor", "create", "--path", "/tmp/keep-nonexistent-supervisor-path-xyz"],
    )

    assert result.exit_code == 1
    assert "path 不存在或不是目录" in result.stderr


def test_mission_scoped_help_discoverable_without_mission_id() -> None:
    task_help = runner.invoke(app, ["task", "--help"])
    assert task_help.exit_code == 0
    assert "Usage: keep <mission_id> task" in task_help.stdout
    assert "create" in task_help.stdout

    supervisor_help = runner.invoke(app, ["supervisor", "--help"])
    assert supervisor_help.exit_code == 0
    assert "Usage: keep <mission_id> supervisor" in supervisor_help.stdout
    assert "send" in supervisor_help.stdout

    worker_help = runner.invoke(app, ["worker", "--help"])
    assert worker_help.exit_code == 0
    assert "Usage: keep <mission_id> worker" in worker_help.stdout
    assert "list" in worker_help.stdout


def test_create_help_discoverable_without_mission_id() -> None:
    supervisor_create_help = runner.invoke(app, ["supervisor", "create", "--help"])
    assert supervisor_create_help.exit_code == 0
    assert "Usage: keep <mission_id> supervisor create" in supervisor_create_help.stdout
    assert "--name" in supervisor_create_help.stdout
    assert "--path" in supervisor_create_help.stdout

    worker_create_help = runner.invoke(app, ["worker", "create", "--help"])
    assert worker_create_help.exit_code == 0
    assert "Usage: keep <mission_id> worker create" in worker_create_help.stdout
    assert "--name" in worker_create_help.stdout
    assert "--path" in worker_create_help.stdout


def test_mission_create_auto_generates_id(isolated_state: Path) -> None:
    result = runner.invoke(app, ["mission", "create"])
    assert result.exit_code == 0
    # Output: "Mission '<id>' 已创建。"
    import re
    match = re.search(r"Mission '(\w+)' 已创建", result.stdout)
    assert match is not None, f"Unexpected output: {result.stdout}"
    mission_id = match.group(1)
    mission = state.load_mission(mission_id)
    assert mission is not None
    assert mission["name"] == mission_id
    assert mission["mission_prompt"] is None



def test_mission_scoped_task_commands_operate_on_path_scope(isolated_state: Path) -> None:
    state.create_mission("mission-123")
    _m = state.load_mission('mission-123'); _m['status'] = 'active'; state.save_mission('mission-123', _m)

    create_result = runner.invoke(app, ["mission-123", "task", "create", "first-task"])
    assert create_result.exit_code == 0
    assert "Task '1'" in create_result.stdout

    list_result = runner.invoke(app, ["mission-123", "task", "list"])
    assert list_result.exit_code == 0
    assert "first-task" in list_result.stdout

    show_result = runner.invoke(app, ["mission-123", "task", "show", "1"])
    assert show_result.exit_code == 0
    assert "first-task" in show_result.stdout


def test_mission_scoped_task_update_and_remove(isolated_state: Path) -> None:
    state.create_mission("mission-123")
    _m = state.load_mission('mission-123'); _m['status'] = 'active'; state.save_mission('mission-123', _m)
    runner.invoke(app, ["mission-123", "task", "create", "first-task"])

    update_result = runner.invoke(
        app,
        [
            "mission-123",
            "task",
            "update",
            "1",
            "--status",
            "in_progress",
            "--owner",
            W1,
            "--description",
            "desc",
        ],
    )
    assert update_result.exit_code == 0

    task = state.get_task("mission-123", "1")
    assert task is not None
    assert task["status"] == "in_progress"
    assert task["owner"] == W1
    assert task["description"] == "desc"

    remove_result = runner.invoke(app, ["mission-123", "task", "remove", "1"])
    assert remove_result.exit_code == 0

    show_result = runner.invoke(app, ["mission-123", "task", "show", "1"])
    assert show_result.exit_code == 1
    assert "不存在" in show_result.stderr

    list_result = runner.invoke(app, ["mission-123", "task", "list"])
    assert list_result.exit_code == 0
    assert "first-task" not in list_result.stdout


def test_mission_scoped_task_update_requires_id_and_rejects_unknown_field(isolated_state: Path) -> None:
    state.create_mission("mission-123")
    _m = state.load_mission('mission-123'); _m['status'] = 'active'; state.save_mission('mission-123', _m)
    runner.invoke(app, ["mission-123", "task", "create", "first-task"])

    missing_id_result = runner.invoke(app, ["mission-123", "task", "update"])
    assert missing_id_result.exit_code == 2
    assert "Task id is required" in missing_id_result.stderr

    unknown_field_result = runner.invoke(
        app,
        ["mission-123", "task", "update", "1", "--invalid", "x"],
    )
    assert unknown_field_result.exit_code == 2
    assert "No such option '--invalid'" in unknown_field_result.stderr


def test_worker_create_uses_uuid_prompt_contract_and_persists_contract_metadata(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_mission("mission-123")

    launches: list[tuple[str, str | None, str, str]] = []

    class FakeInfo:
        running = True
        pid = 123
        target_id = "surface-1"
        jsonl_path = "/tmp/fake.jsonl"
        jsonl_search = None

    def fake_spawn(session, path, *, bootstrap_prompt, append_system_prompt, terminal_type, role, mission_id):
        launches.append((session, path, bootstrap_prompt, append_system_prompt))

    monkeypatch.setattr("keep._cli.spawn.spawn_claude_session", fake_spawn)
    monkeypatch.setattr("keep._cli.dispatch_worker.generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr("keep._cli.spawn.wait_for_worker_ready", lambda *args, **kwargs: FakeInfo())
    monkeypatch.setattr(
        "keep._cli.spawn.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": info.jsonl_path},
    )

    work_path = isolated_state / "work"
    work_path.mkdir(parents=True)

    result = runner.invoke(
        app,
        ["mission-123", "worker", "create", "--name", "worker-a", "--path", str(work_path)],
    )
    assert result.exit_code == 0

    mission = state.load_mission("mission-123")
    worker = state.find_worker(mission, "11111111-1111-4111-8111-111111111111")
    assert worker is not None
    assert worker["name"] == "worker-a"
    assert worker["path"] == str(work_path)
    assert worker["contract"]["version"] == "v1"
    assert worker["contract"]["kind"] == "worker"
    assert worker["contract"]["applied_via"] == "claude-create"
    assert "session id: 11111111-1111-4111-8111-111111111111" in worker["contract"]["bootstrap_prompt"]
    assert "Participant id" not in worker["contract"]["bootstrap_prompt"]
    assert str(work_path) not in worker["contract"]["bootstrap_prompt"]
    assert launches == [(
        "11111111-1111-4111-8111-111111111111",
        str(work_path),
        worker["contract"]["bootstrap_prompt"],
        worker["contract"]["append_system_prompt"],
    )]


def test_supervisor_create_uses_uuid_prompt_contract_and_persists_contract_metadata(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_mission("mission-123")

    launches: list[tuple[str, str | None, str, str]] = []

    class FakeInfo:
        running = True
        pid = 456
        target_id = "surface-2"
        jsonl_path = "/tmp/sup.jsonl"
        jsonl_search = None

    def fake_spawn(session, path, *, bootstrap_prompt, append_system_prompt, terminal_type, role, mission_id):
        launches.append((session, path, bootstrap_prompt, append_system_prompt))

    monkeypatch.setattr("keep._cli.spawn.spawn_claude_session", fake_spawn)
    monkeypatch.setattr("keep._cli.dispatch_supervisor.generate_session_id", lambda: "22222222-2222-4222-8222-222222222222")
    monkeypatch.setattr("keep._cli.spawn.wait_for_worker_ready", lambda *args, **kwargs: FakeInfo())
    monkeypatch.setattr(
        "keep._cli.spawn.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": info.jsonl_path},
    )

    sup_path = isolated_state / "sup"
    sup_path.mkdir(parents=True)

    result = runner.invoke(
        app,
        ["mission-123", "supervisor", "create", "--name", "sup-a", "--path", str(sup_path)],
    )
    assert result.exit_code == 0

    mission = state.load_mission("mission-123")
    supervisor = state.find_supervisor(mission)
    assert supervisor is not None
    assert supervisor["session"] == "22222222-2222-4222-8222-222222222222"
    assert supervisor["name"] == "sup-a"
    assert supervisor["path"] == str(sup_path)
    assert supervisor["contract"]["version"] == "v1"
    assert supervisor["contract"]["kind"] == "supervisor"
    assert supervisor["contract"]["applied_via"] == "claude-create"
    assert "session_id: 22222222-2222-4222-8222-222222222222" in supervisor["contract"]["bootstrap_prompt"]
    assert "Participant id" not in supervisor["contract"]["bootstrap_prompt"]
    assert str(sup_path) not in supervisor["contract"]["bootstrap_prompt"]
    assert launches == [(
        "22222222-2222-4222-8222-222222222222",
        str(sup_path),
        supervisor["contract"]["bootstrap_prompt"],
        supervisor["contract"]["append_system_prompt"],
    )]


def test_wait_for_worker_ready_succeeds_when_ready_arrives_in_later_poll_round(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    info = SimpleNamespace(
        running=True,
        pid=123,
        target_id="surface-1",
        jsonl_path="/tmp/fake.jsonl",
        jsonl_search=None,
    )
    ready = iter([False] * 12 + [True])
    sleeps: list[float] = []

    monkeypatch.setattr("keep._cli.spawn.resolve_worker", lambda session, terminal_type=None: info)
    monkeypatch.setattr("keep._cli.spawn.is_ready_message_present", lambda *args, **kwargs: next(ready))
    monkeypatch.setattr("keep._cli.spawn.time.sleep", lambda seconds: sleeps.append(seconds))

    result = _wait_for_worker_ready(W1, terminal_type="cmux")

    assert result is info
    assert sleeps == [0.2] * 12


def test_worker_create_waits_until_ready_ack_before_persisting(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_mission("mission-123")

    states = iter([
        SimpleNamespace(running=False, jsonl_path=None),
        SimpleNamespace(running=True, pid=123, target_id="surface-1", jsonl_path="/tmp/fake.jsonl", jsonl_search=None),
    ])
    ready = iter([False, False, True])
    sleeps: list[float] = []

    monkeypatch.setattr("keep._cli.spawn.spawn_claude_session", lambda *args, **kwargs: None)
    monkeypatch.setattr("keep._cli.dispatch_worker.generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr("keep._cli.spawn.resolve_worker", lambda session, terminal_type=None: next(states))
    monkeypatch.setattr("keep._cli.spawn.is_ready_message_present", lambda *args, **kwargs: next(ready))
    monkeypatch.setattr("keep._cli.spawn.time.sleep", lambda seconds: sleeps.append(seconds))
    monkeypatch.setattr(
        "keep._cli.spawn.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": info.jsonl_path},
    )

    result = runner.invoke(app, ["mission-123", "worker", "create"])

    assert result.exit_code == 0
    assert sleeps == [0.2, 0.2, 0.2]


def test_worker_create_fails_when_ready_ack_never_arrives(isolated_state: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _create_active_mission("mission-123")

    monkeypatch.setattr("keep._cli.spawn.spawn_claude_session", lambda *args, **kwargs: None)
    monkeypatch.setattr("keep._cli.dispatch_worker.generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr(
        "keep._cli.spawn.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(running=True, pid=123, target_id="surface-1", jsonl_path="/tmp/fake.jsonl", jsonl_search=None),
    )
    monkeypatch.setattr("keep._cli.spawn.is_ready_message_present", lambda *args, **kwargs: False)
    monkeypatch.setattr("keep._cli.spawn.time.sleep", lambda seconds: None)

    result = runner.invoke(app, ["mission-123", "worker", "create"])

    assert result.exit_code == 1
    assert "ready" in result.stderr.lower()
    mission = state.load_mission("mission-123")
    assert state.find_worker(mission, "11111111-1111-4111-8111-111111111111") is None


def test_worker_create_succeeds_when_process_exits_but_ready_ack_is_present(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_mission("mission-123")

    monkeypatch.setattr("keep._cli.spawn.spawn_claude_session", lambda *args, **kwargs: None)
    monkeypatch.setattr("keep._cli.dispatch_worker.generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr(
        "keep._cli.spawn.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(running=False, pid=123, target_id="surface-1", jsonl_path="/tmp/fake.jsonl", jsonl_search=None),
    )
    monkeypatch.setattr("keep._cli.spawn.is_ready_message_present", lambda *args, **kwargs: True)
    monkeypatch.setattr("keep._cli.spawn.time.sleep", lambda seconds: None)
    monkeypatch.setattr(
        "keep._cli.spawn.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": info.jsonl_path},
    )

    result = runner.invoke(app, ["mission-123", "worker", "create"])

    assert result.exit_code == 0
    mission = state.load_mission("mission-123")
    worker = state.find_worker(mission, "11111111-1111-4111-8111-111111111111")
    assert worker is not None
    assert worker["cache"]["jsonl_path"] == "/tmp/fake.jsonl"


def test_worker_create_rejects_manual_session_id(isolated_state: Path) -> None:
    state.create_mission("mission-123")

    result = runner.invoke(app, ["mission-123", "worker", "create", W1])

    assert result.exit_code == 2
    assert "No such argument" in result.stderr


def test_supervisor_create_rejects_manual_session_id(isolated_state: Path) -> None:
    state.create_mission("mission-123")

    result = runner.invoke(app, ["mission-123", "supervisor", "create", S1])

    assert result.exit_code == 2
    assert "No such argument" in result.stderr


def test_worker_list_show_update_remove_under_mission(isolated_state: Path) -> None:
    state.create_mission("mission-123")
    state.add_worker(
        "mission-123",
        W1,
        name="worker-a",
        path="/tmp/work-a",
        cache={"pid": 101, "target_id": "s1", "jsonl_path": "/tmp/worker-1.jsonl"},
    )

    list_result = runner.invoke(app, ["mission-123", "worker", "list"])
    assert list_result.exit_code == 0
    assert W1 in list_result.stdout

    show_result = runner.invoke(app, ["mission-123", "worker", "show", W1])
    assert show_result.exit_code == 0
    assert f'"session": "{W1}"' in show_result.stdout
    assert '"name": "worker-a"' in show_result.stdout
    assert '"path": "/tmp/work-a"' in show_result.stdout
    assert '"role": "worker"' in show_result.stdout

    update_result = runner.invoke(
        app,
        ["mission-123", "worker", "update", W1, "--name", "worker-b", "--path", "/tmp/work-b"],
    )
    assert update_result.exit_code == 0

    mission = state.load_mission("mission-123")
    worker = state.find_worker(mission, W1)
    assert worker is not None
    assert worker["name"] == "worker-b"
    assert worker["path"] == "/tmp/work-b"

    remove_result = runner.invoke(app, ["mission-123", "worker", "remove", W1])
    assert remove_result.exit_code == 0

    list_after_remove = runner.invoke(app, ["mission-123", "worker", "list"])
    assert list_after_remove.exit_code == 0
    assert W1 not in list_after_remove.stdout

    show_after_remove = runner.invoke(app, ["mission-123", "worker", "show", W1])
    assert show_after_remove.exit_code == 1
    assert "不存在" in show_after_remove.stderr


def test_worker_show_update_remove_error_when_target_missing(isolated_state: Path) -> None:
    state.create_mission("mission-123")

    show_result = runner.invoke(app, ["mission-123", "worker", "show", WMISS])
    assert show_result.exit_code == 1
    assert "不存在" in show_result.stderr

    update_result = runner.invoke(
        app,
        ["mission-123", "worker", "update", WMISS, "--name", "worker-b"],
    )
    assert update_result.exit_code == 1
    assert "不存在" in update_result.stderr

    remove_result = runner.invoke(app, ["mission-123", "worker", "remove", WMISS])
    assert remove_result.exit_code == 1
    assert "不存在" in remove_result.stderr


def test_supervisor_list_show_update_remove_under_mission(isolated_state: Path) -> None:
    state.create_mission("mission-123")
    state.add_supervisor(
        "mission-123",
        S1,
        name="sup-a",
        path="/tmp/sup-a",
        cache={"pid": 202, "target_id": "s2", "jsonl_path": "/tmp/sup-1.jsonl"},
    )

    list_result = runner.invoke(app, ["mission-123", "supervisor", "list"])
    assert list_result.exit_code == 0
    assert S1 in list_result.stdout

    show_result = runner.invoke(app, ["mission-123", "supervisor", "show", S1])
    assert show_result.exit_code == 0
    assert f'"session": "{S1}"' in show_result.stdout
    assert '"name": "sup-a"' in show_result.stdout
    assert '"path": "/tmp/sup-a"' in show_result.stdout
    assert '"role": "supervisor"' in show_result.stdout

    update_result = runner.invoke(
        app,
        ["mission-123", "supervisor", "update", S1, "--name", "sup-b", "--path", "/tmp/sup-b"],
    )
    assert update_result.exit_code == 0

    mission = state.load_mission("mission-123")
    supervisor = state.find_supervisor(mission)
    assert supervisor is not None
    assert supervisor["name"] == "sup-b"
    assert supervisor["path"] == "/tmp/sup-b"

    remove_result = runner.invoke(app, ["mission-123", "supervisor", "remove", S1])
    assert remove_result.exit_code == 0

    list_after_remove = runner.invoke(app, ["mission-123", "supervisor", "list"])
    assert list_after_remove.exit_code == 0
    assert S1 not in list_after_remove.stdout

    show_after_remove = runner.invoke(app, ["mission-123", "supervisor", "show", S1])
    assert show_after_remove.exit_code == 1
    assert "不存在" in show_after_remove.stderr


def test_supervisor_show_update_remove_error_when_target_missing(isolated_state: Path) -> None:
    state.create_mission("mission-123")

    show_result = runner.invoke(app, ["mission-123", "supervisor", "show", SMISS])
    assert show_result.exit_code == 1
    assert "不存在" in show_result.stderr

    update_result = runner.invoke(
        app,
        ["mission-123", "supervisor", "update", SMISS, "--name", "sup-b"],
    )
    assert update_result.exit_code == 1
    assert "不存在" in update_result.stderr

    remove_result = runner.invoke(app, ["mission-123", "supervisor", "remove", SMISS])
    assert remove_result.exit_code == 1
    assert "不存在" in remove_result.stderr


def test_supervisor_read_outputs_last_message_for_explicit_worker(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=True,
            pid=101,
            target_id="surface-1",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.dispatch_supervisor.CCAgent",
        lambda: SimpleNamespace(last_message=lambda session, **kwargs: SimpleNamespace(text="latest reply")),
    )

    result = runner.invoke(app, ["mission-123", "supervisor", "read", W1])
    assert result.exit_code == 0
    assert "latest reply" in result.stdout


def test_supervisor_send_uses_resolved_worker_surface(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "stale-surface"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=True,
            pid=202,
            target_id="surface-live",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    sent: list[tuple[str, str]] = []
    monkeypatch.setattr(
        "keep.terminal._factory",
        lambda terminal_type: SimpleNamespace(
            send_text=lambda surface, text: sent.append((surface, text)),
            send_key=lambda *a, **k: None,
            close=lambda *a, **k: None,
        ),
    )

    # Write message file into messages/ dir so send accepts it
    msg_dir = state.messages_dir("mission-123")
    msg_file = msg_dir / "hello.md"
    msg_file.write_text("hello worker")

    result = runner.invoke(app, ["mission-123", "supervisor", "send", W1, str(msg_file)])
    assert result.exit_code == 0
    assert sent == [("surface-live", "hello worker")]


def test_supervisor_kick_sends_enter_to_worker_surface(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=True,
            pid=303,
            target_id="surface-kick",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    keys: list[tuple[str, str]] = []
    monkeypatch.setattr(
        "keep.terminal._factory",
        lambda terminal_type: SimpleNamespace(
            send_text=lambda *a, **k: None,
            send_key=lambda target_id, key: keys.append((target_id, key)),
            close=lambda *a, **k: None,
        ),
    )

    result = runner.invoke(app, ["mission-123", "supervisor", "kick", W1])
    assert result.exit_code == 0
    assert keys == [("surface-kick", "enter")]


def test_supervisor_send_read_kick_fail_when_worker_missing(isolated_state: Path) -> None:
    _create_active_mission("mission-123")

    send_result = runner.invoke(app, ["mission-123", "supervisor", "send", WMISS, "hello"])
    assert send_result.exit_code == 1
    assert "Worker not found in mission" in send_result.stderr

    read_result = runner.invoke(app, ["mission-123", "supervisor", "read", WMISS])
    assert read_result.exit_code == 1
    assert "Worker not found in mission" in read_result.stderr

    kick_result = runner.invoke(app, ["mission-123", "supervisor", "kick", WMISS])
    assert kick_result.exit_code == 1
    assert "Worker not found in mission" in kick_result.stderr


def test_supervisor_send_read_kick_allow_omitting_worker_for_single_worker(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=True,
            pid=404,
            target_id="surface-single",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )
    monkeypatch.setattr(
        "keep._cli.dispatch_supervisor.CCAgent",
        lambda: SimpleNamespace(last_message=lambda session, **kwargs: SimpleNamespace(text="single latest")),
    )

    sent: list[tuple[str, str]] = []
    keys: list[tuple[str, str]] = []
    monkeypatch.setattr(
        "keep.terminal._factory",
        lambda terminal_type: SimpleNamespace(
            send_text=lambda surface, text: sent.append((surface, text)),
            send_key=lambda target_id, key: keys.append((target_id, key)),
            close=lambda *a, **k: None,
        ),
    )

    # Write message file into messages/ dir
    msg_dir = state.messages_dir("mission-123")
    msg_file = msg_dir / "hello.md"
    msg_file.write_text("hello single worker")

    send_result = runner.invoke(app, ["mission-123", "supervisor", "send", str(msg_file)])
    assert send_result.exit_code == 0
    assert sent == [("surface-single", "hello single worker")]

    read_result = runner.invoke(app, ["mission-123", "supervisor", "read"])
    assert read_result.exit_code == 0
    assert "single latest" in read_result.stdout

    kick_result = runner.invoke(app, ["mission-123", "supervisor", "kick"])
    assert kick_result.exit_code == 0
    assert keys == [("surface-single", "enter")]


def test_supervisor_send_read_kick_require_worker_for_multi_worker(
    isolated_state: Path,
) -> None:
    _create_active_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "surface-1"})
    state.add_worker("mission-123", W2, cache={"target_id": "surface-2"})

    send_result = runner.invoke(app, ["mission-123", "supervisor", "send", "hello"])
    assert send_result.exit_code == 1
    assert "Multiple workers" in send_result.stderr

    read_result = runner.invoke(app, ["mission-123", "supervisor", "read"])
    assert read_result.exit_code == 1
    assert "Multiple workers" in read_result.stderr

    kick_result = runner.invoke(app, ["mission-123", "supervisor", "kick"])
    assert kick_result.exit_code == 1
    assert "Multiple workers" in kick_result.stderr


def test_worker_id_prefix_unique_match_for_show_update_remove(isolated_state: Path) -> None:
    state.create_mission("mission-123")
    state.add_worker("mission-123", W1, name="worker-a", path="/tmp/work-a", cache={"target_id": "s1"})

    prefix = W1[:8]
    show_result = runner.invoke(app, ["mission-123", "worker", "show", prefix])
    assert show_result.exit_code == 0
    assert W1 in show_result.stdout

    update_result = runner.invoke(app, ["mission-123", "worker", "update", prefix, "--name", "worker-b"])
    assert update_result.exit_code == 0

    remove_result = runner.invoke(app, ["mission-123", "worker", "remove", prefix])
    assert remove_result.exit_code == 0


def test_worker_id_prefix_ambiguous_reports_candidates(isolated_state: Path) -> None:
    state.create_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "s1"})
    state.add_worker("mission-123", W2, cache={"target_id": "s2"})

    result = runner.invoke(app, ["mission-123", "worker", "show", "11111111"])
    assert result.exit_code == 1
    assert "歧义" in result.stderr
    assert W1 in result.stderr
    assert W2 in result.stderr


def test_alias_like_id_is_rejected(isolated_state: Path) -> None:
    state.create_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "s1"})

    result = runner.invoke(app, ["mission-123", "worker", "show", "alice"])
    assert result.exit_code == 1
    assert "UUID" in result.stderr


def test_supervisor_send_read_kick_consistent_offline_error(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "surface-1"})

    msg_file = state.messages_dir("mission-123") / "hello.md"
    msg_file.write_text("hello worker")

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=False,
            pid=202,
            target_id="surface-live",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )

    for cmd in (["send", W1, str(msg_file)], ["read", W1], ["kick", W1]):
        result = runner.invoke(app, ["mission-123", "supervisor", *cmd])
        assert result.exit_code == 1
        assert "Worker is offline" in result.stderr


def test_supervisor_send_read_kick_consistent_surface_error(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_mission("mission-123")
    state.add_worker("mission-123", W1, cache={})

    msg_file = state.messages_dir("mission-123") / "hello.md"
    msg_file.write_text("hello worker")

    # Ensure the cached target_id (if any) is blanked — resolve_worker returns target_id=None,
    # but refresh_worker_cache is meant to preserve existing. Remove via add_worker cache={}.
    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=True,
            pid=202,
            target_id=None,
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    for cmd in (["send", W1, str(msg_file)], ["read", W1], ["kick", W1]):
        result = runner.invoke(app, ["mission-123", "supervisor", *cmd])
        assert result.exit_code == 1
        assert "Worker target unavailable" in result.stderr


def test_supervisor_send_rejects_inline_string(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session, running=True, pid=1, target_id="s", jsonl_path=Path("/tmp/x.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    result = runner.invoke(app, ["mission-123", "supervisor", "send", W1, "inline string message"])
    assert result.exit_code == 2
    assert "file path" in result.stderr.lower()


def test_supervisor_send_rejects_missing_path(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session, running=True, pid=1, target_id="s", jsonl_path=Path("/tmp/x.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    result = runner.invoke(app, ["mission-123", "supervisor", "send", W1, "/tmp/keep-does-not-exist-xyz.md"])
    assert result.exit_code == 2
    assert "file not found" in result.stderr.lower()


def test_supervisor_send_copies_file_outside_messages_dir(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    _create_active_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session, running=True, pid=1, target_id="surface-1", jsonl_path=Path("/tmp/x.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    sent: list[tuple[str, str]] = []
    monkeypatch.setattr(
        "keep.terminal._factory",
        lambda terminal_type: SimpleNamespace(
            send_text=lambda surface, text: sent.append((surface, text)),
            send_key=lambda *a, **k: None,
            close=lambda *a, **k: None,
        ),
    )

    # File is outside messages/ — should be copied with warning
    src = tmp_path / "outside.md"
    src.write_text("content from outside")

    result = runner.invoke(app, ["mission-123", "supervisor", "send", W1, str(src)])
    assert result.exit_code == 0
    assert "Warning" in result.stderr
    assert "copied" in result.stderr.lower()
    assert sent == [("surface-1", "content from outside")]

    # Verify copied into messages/
    msg_dir = state.messages_dir("mission-123")
    assert (msg_dir / "outside.md").exists()

    # Verify index entry
    import json
    index = json.loads((msg_dir / "index.json").read_text())
    assert any(e["type"] == "send" and e["file"] == "outside.md" for e in index)


def test_supervisor_send_file_already_in_messages_dir_no_warning(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session, running=True, pid=1, target_id="surface-1", jsonl_path=Path("/tmp/x.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    sent: list[tuple[str, str]] = []
    monkeypatch.setattr(
        "keep.terminal._factory",
        lambda terminal_type: SimpleNamespace(
            send_text=lambda surface, text: sent.append((surface, text)),
            send_key=lambda *a, **k: None,
            close=lambda *a, **k: None,
        ),
    )

    # File already in messages/
    msg_dir = state.messages_dir("mission-123")
    msg_file = msg_dir / "task-30.md"
    msg_file.write_text("already in inbox")

    result = runner.invoke(app, ["mission-123", "supervisor", "send", W1, str(msg_file)])
    assert result.exit_code == 0
    assert "Warning" not in result.stderr
    assert sent == [("surface-1", "already in inbox")]


def test_task_create_help_does_not_create_task(isolated_state: Path) -> None:
    state.create_mission("mission-123")

    result = runner.invoke(app, ["mission-123", "task", "create", "-h"])
    assert result.exit_code == 0
    assert "Usage: keep <mission_id> task create" in result.stdout

    tasks = state.list_tasks("mission-123")
    assert tasks == []


def test_task_update_help_is_supported(isolated_state: Path) -> None:
    state.create_mission("mission-123")

    result = runner.invoke(app, ["mission-123", "task", "update", "-h"])
    assert result.exit_code == 0
    assert "Usage: keep <mission_id> task update" in result.stdout


def test_supervisor_send_help_does_not_send_message(isolated_state: Path) -> None:
    _create_active_mission("mission-123")
    state.add_worker("mission-123", W1, cache={"target_id": "surface-1"})

    result = runner.invoke(app, ["mission-123", "supervisor", "send", "-h"])
    assert result.exit_code == 0
    assert "Usage: keep <mission_id> supervisor send" in result.stdout


def test_supervisor_read_help_is_supported(isolated_state: Path) -> None:
    state.create_mission("mission-123")

    result = runner.invoke(app, ["mission-123", "supervisor", "read", "-h"])
    assert result.exit_code == 0
    assert "Usage: keep <mission_id> supervisor read" in result.stdout


def test_supervisor_kick_help_is_supported(isolated_state: Path) -> None:
    _create_active_mission("mission-123")

    result = runner.invoke(app, ["mission-123", "supervisor", "kick", "-h"])
    assert result.exit_code == 0
    assert "Usage: keep <mission_id> supervisor kick" in result.stdout


def test_task_update_rejects_removed_and_accepts_deleted(isolated_state: Path) -> None:
    state.create_mission("mission-123")
    _m = state.load_mission('mission-123'); _m['status'] = 'active'; state.save_mission('mission-123', _m)
    runner.invoke(app, ["mission-123", "task", "create", "first-task"])

    removed_result = runner.invoke(
        app,
        ["mission-123", "task", "update", "1", "--status", "removed"],
    )
    assert removed_result.exit_code == 2
    assert "Invalid --status" in removed_result.stderr

    deleted_result = runner.invoke(
        app,
        ["mission-123", "task", "update", "1", "--status", "deleted"],
    )
    assert deleted_result.exit_code == 0
    task = state.get_task("mission-123", "1")
    assert task is not None
    assert task["status"] == "deleted"


# ── cross-role hint on resolve_session_id_by_prefix_or_fail ───────
from keep._cli.helpers import resolve_session_id_by_prefix_or_fail  # noqa: E402
import typer as _typer  # noqa: E402


def _mission_with(*participants: dict) -> dict:
    return {"name": "m", "participants": list(participants)}


def test_resolve_role_mismatch_full_supervisor_uuid_as_worker_emits_hint(
    capsys: pytest.CaptureFixture[str],
) -> None:
    mission = _mission_with(
        {"role": "supervisor", "session": S1},
    )
    with pytest.raises(_typer.Exit) as exc:
        resolve_session_id_by_prefix_or_fail(
            mission=mission, role="worker", raw_id=S1, id_label="worker_id",
        )
    assert exc.value.exit_code == 1
    captured = capsys.readouterr()
    assert f"worker_id '{S1}' 不存在" in captured.err
    assert "supervisor" in captured.err
    assert f"session={S1[:8]}" in captured.err
    assert "不是 worker" in captured.err
    assert "supervisor send 是 supervisor 单向向 worker 发消息的工具。" in captured.err


def test_resolve_role_mismatch_prefix_matches_only_supervisor_emits_hint(
    capsys: pytest.CaptureFixture[str],
) -> None:
    mission = _mission_with(
        {"role": "supervisor", "session": S1},
        {"role": "worker", "session": W1},
    )
    # S1 starts with "22222222"; this prefix only matches the supervisor.
    prefix = "22222222"
    with pytest.raises(_typer.Exit) as exc:
        resolve_session_id_by_prefix_or_fail(
            mission=mission, role="worker", raw_id=prefix, id_label="worker_id",
        )
    assert exc.value.exit_code == 1
    captured = capsys.readouterr()
    assert f"worker_id '{prefix}' 不存在" in captured.err
    assert "属于 mission 'm' 的 supervisor" in captured.err
    assert f"session={S1[:8]}" in captured.err
    assert "supervisor send 是 supervisor 单向向 worker 发消息的工具。" in captured.err


def test_resolve_unknown_id_falls_back_to_generic_error(
    capsys: pytest.CaptureFixture[str],
) -> None:
    mission = _mission_with(
        {"role": "supervisor", "session": S1},
        {"role": "worker", "session": W1},
    )
    unknown = "99999999-9999-4999-8999-999999999999"
    with pytest.raises(_typer.Exit) as exc:
        resolve_session_id_by_prefix_or_fail(
            mission=mission, role="worker", raw_id=unknown, id_label="worker_id",
        )
    assert exc.value.exit_code == 1
    captured = capsys.readouterr()
    assert captured.err.strip() == f"worker_id '{unknown}' 不存在"
    # No cross-role hint must appear
    assert "属于 mission" not in captured.err
    assert "supervisor send 是" not in captured.err


def test_resolve_prefix_ambiguous_across_roles_worker_wins_without_hint() -> None:
    # Pick worker + supervisor that share the first 4 hex chars.
    worker_shared = "abcd1111-1111-4111-8111-111111111111"
    sup_shared = "abcd2222-2222-4222-8222-222222222222"
    mission = _mission_with(
        {"role": "worker", "session": worker_shared},
        {"role": "supervisor", "session": sup_shared},
    )
    # Prefix "abcd" matches both roles, but only the worker match is considered
    # inside the requested role (there's exactly one worker with this prefix).
    resolved = resolve_session_id_by_prefix_or_fail(
        mission=mission, role="worker", raw_id="abcd", id_label="worker_id",
    )
    assert resolved == worker_shared


def test_resolve_supervisor_lookup_with_worker_id_emits_first_line_only(
    capsys: pytest.CaptureFixture[str],
) -> None:
    mission = _mission_with(
        {"role": "supervisor", "session": S1},
        {"role": "worker", "session": W1},
    )
    with pytest.raises(_typer.Exit) as exc:
        resolve_session_id_by_prefix_or_fail(
            mission=mission, role="supervisor", raw_id=W1, id_label="supervisor_id",
        )
    assert exc.value.exit_code == 1
    captured = capsys.readouterr()
    assert f"supervisor_id '{W1}' 不存在" in captured.err
    assert "属于 mission 'm' 的 worker" in captured.err
    assert f"session={W1[:8]}" in captured.err
    assert "不是 supervisor" in captured.err
    # The second, worker-specific hint must NOT appear
    assert "supervisor send 是 supervisor 单向向 worker 发消息的工具" not in captured.err
