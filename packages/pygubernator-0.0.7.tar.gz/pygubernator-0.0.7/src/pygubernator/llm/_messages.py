"""LLM message and response types for pygubernator."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class ChatRole(StrEnum):
    """Role of a chat message participant."""

    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass(frozen=True, slots=True)
class ToolCall:
    """A tool call requested by the LLM.

    Attributes:
        id: Unique identifier for this tool call.
        name: Name of the tool to call.
        arguments: Arguments for the tool call.
    """

    id: str
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "arguments": self.arguments,
        }


@dataclass(frozen=True, slots=True)
class ToolCallDelta:
    """Incremental tool call data from a streaming response.

    Args:
        index: Tool call index in the response.
        id: Tool call ID (present in first delta only).
        name: Function name (present in first delta only).
        arguments_delta: Incremental JSON arguments string.
    """

    index: int
    id: str | None = None
    name: str | None = None
    arguments_delta: str = ""


@dataclass(frozen=True, slots=True)
class StreamChunk:
    """A single chunk from a streaming LLM response.

    Args:
        delta_content: Incremental text content.
        tool_calls_delta: Incremental tool call deltas.
        finish_reason: Set on the final chunk.
        usage: Token usage (set on the final chunk if available).
    """

    delta_content: str = ""
    tool_calls_delta: tuple[ToolCallDelta, ...] = ()
    finish_reason: str | None = None
    usage: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ChatMessage:
    """A single message in a chat conversation.

    Attributes:
        role: The role of the message sender.
        content: Text content of the message.
        tool_calls: Tool calls requested (assistant messages only).
        tool_call_id: ID of the tool call this responds to
            (tool messages only).
        name: Optional name for the message sender.
    """

    role: ChatRole
    content: str = ""
    tool_calls: tuple[ToolCall, ...] = ()
    tool_call_id: str | None = None
    name: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        d: dict[str, Any] = {
            "role": self.role.value,
            "content": self.content,
        }
        if self.tool_calls:
            d["tool_calls"] = [tc.to_dict() for tc in self.tool_calls]
        if self.tool_call_id is not None:
            d["tool_call_id"] = self.tool_call_id
        if self.name is not None:
            d["name"] = self.name
        return d


@dataclass(frozen=True, slots=True)
class LLMResponse:
    """Response from an LLM provider.

    Attributes:
        content: Text content of the response.
        tool_calls: Tool calls requested by the LLM.
        finish_reason: Why the LLM stopped generating.
        usage: Token usage statistics.
        model: Model identifier used.
    """

    content: str = ""
    tool_calls: tuple[ToolCall, ...] = ()
    finish_reason: str = "stop"
    usage: dict[str, int] = field(default_factory=dict)
    model: str = ""

    @property
    def has_tool_calls(self) -> bool:
        """Return True if the response contains tool calls."""
        return len(self.tool_calls) > 0

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary."""
        return {
            "content": self.content,
            "tool_calls": [tc.to_dict() for tc in self.tool_calls],
            "finish_reason": self.finish_reason,
            "usage": self.usage,
            "model": self.model,
        }
