"""OpenAI-compatible LLM provider using httpx."""

from __future__ import annotations

import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any

from pygubernator.errors import LLMError
from pygubernator.llm._messages import (
    LLMResponse,
    StreamChunk,
    ToolCall,
    ToolCallDelta,
)

logger = logging.getLogger(__name__)

_PROVIDER_NAME = "openai_compatible"


def _exc_text(exc: Exception) -> str:
    """Return a non-empty exception string."""
    text = str(exc).strip()
    return text if text else repr(exc)


def _response_text_snippet(resp: Any, max_len: int = 500) -> str:
    """Best-effort response text snippet for diagnostics."""
    try:
        raw = resp.text or ""
    except Exception:
        return ""
    raw = raw.strip()
    if len(raw) <= max_len:
        return raw
    return f"{raw[:max_len]}... [truncated]"


def _hint_for_httpx_error(exc: Exception) -> str | None:
    """Suggest likely fixes for common OpenAI-compatible failures."""
    name = type(exc).__name__
    if name in {"ConnectError", "ConnectTimeout"}:
        return (
            "Cannot connect to model server. Verify Ollama is running and "
            "base URL is reachable (e.g. http://127.0.0.1:11434/v1, or "
            "http://host.docker.internal:11434/v1 from Docker)."
        )
    if name == "ReadTimeout":
        return (
            "Model response timed out. Increase `request_timeout` on the chat model "
            "(or agent) node (e.g. 600–900 for slow local models), set env "
            "PYGUBERNATOR_OPENAI_COMPAT_READ_TIMEOUT, or run a warm-up completion."
        )
    return None


class OpenAICompatibleProvider:
    """LLM provider for any OpenAI-compatible API server.

    Works with Ollama, vLLM, Deepseek API, GLM API, LocalAI,
    LM Studio, and any server implementing ``/v1/chat/completions``.

    Args:
        api_base: Base URL (e.g. ``http://localhost:11434/v1``).
        model: Model identifier.
        api_key: API key (optional for local servers).
        max_tokens: Maximum tokens per response.
        temperature: Sampling temperature.
        top_p: Nucleus sampling parameter.
        timeout: HTTP **read** timeout in seconds (time to first byte + body for
            streaming-style responses). Connect/pool use shorter defaults.
            Default from env ``PYGUBERNATOR_OPENAI_COMPAT_READ_TIMEOUT`` or 600.
    """

    def __init__(
        self,
        api_base: str,
        model: str,
        api_key: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.0,
        top_p: float | None = None,
        timeout: float | None = None,
    ) -> None:
        self._api_base = api_base.rstrip("/")
        self._model = model
        self._api_key = api_key
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._top_p = top_p
        if timeout is not None:
            self._read_timeout = float(timeout)
        else:
            self._read_timeout = float(
                os.environ.get("PYGUBERNATOR_OPENAI_COMPAT_READ_TIMEOUT", "600"),
            )

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        """Send a chat completion request.

        Args:
            messages: Conversation messages in OpenAI format.
            tools: Optional tool schemas for function calling.

        Returns:
            LLM response with content and/or tool calls.

        Raises:
            LLMError: If the request fails.
        """
        client = self._make_client()
        body = self._build_request_body(messages, tools)

        try:
            async with client:
                resp = await client.post(
                    f"{self._api_base}/chat/completions",
                    json=body,
                )
                resp.raise_for_status()
                data = resp.json()
        except Exception as exc:
            context: dict[str, Any] = {
                "model": self._model,
                "api_base": self._api_base,
                "error_type": type(exc).__name__,
            }
            parts = [f"{type(exc).__name__}: {_exc_text(exc)}"]
            hint = _hint_for_httpx_error(exc)
            if hint:
                context["hint"] = hint
                parts.append(hint)

            # HTTPStatusError carries server response details that are critical
            # for diagnosing model-not-found, invalid payload, auth, etc.
            response = getattr(exc, "response", None)
            if response is not None:
                status = getattr(response, "status_code", None)
                if status is not None:
                    context["status_code"] = status
                    parts.append(f"status={status}")
                body_snippet = _response_text_snippet(response)
                if body_snippet:
                    context["response_body_snippet"] = body_snippet
                    parts.append(f"body={body_snippet}")

            raise LLMError(
                "OpenAI-compatible API call failed: " + " | ".join(parts),
                provider=_PROVIDER_NAME,
                context=context,
            ) from exc

        return self._parse_response(data)

    async def chat_stream(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> AsyncIterator[StreamChunk]:
        """Stream a chat completion response.

        Builds the same request body as ``chat()`` but enables
        streaming and yields ``StreamChunk`` objects as they arrive.

        Args:
            messages: Conversation messages in OpenAI format.
            tools: Optional tool schemas for function calling.

        Yields:
            StreamChunk objects with incremental content.

        Raises:
            LLMError: If the request fails.
        """
        client = self._make_client()
        body = self._build_request_body(messages, tools)
        body["stream"] = True
        body["stream_options"] = {"include_usage": True}

        try:
            async with (
                client,
                client.stream(
                    "POST",
                    f"{self._api_base}/chat/completions",
                    json=body,
                ) as response,
            ):
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    data = line[6:]
                    if data.strip() == "[DONE]":
                        break
                    chunk_json = json.loads(data)
                    yield _parse_stream_chunk(chunk_json)
        except LLMError:
            raise
        except Exception as exc:
            context: dict[str, Any] = {
                "model": self._model,
                "api_base": self._api_base,
                "error_type": type(exc).__name__,
            }
            parts = [
                f"{type(exc).__name__}: {_exc_text(exc)}",
            ]
            hint = _hint_for_httpx_error(exc)
            if hint:
                context["hint"] = hint
                parts.append(hint)
            raise LLMError(
                "OpenAI-compatible streaming call failed: " + " | ".join(parts),
                provider=_PROVIDER_NAME,
                context=context,
            ) from exc

    async def list_models(self) -> list[str]:
        """Fetch available models from the server.

        Returns:
            List of model identifiers.

        Raises:
            LLMError: If the request fails.
        """
        client = self._make_client()
        try:
            async with client:
                resp = await client.get(f"{self._api_base}/models")
                resp.raise_for_status()
                data = resp.json()
        except Exception as exc:
            raise LLMError(
                f"Failed to list models: {exc}",
                provider=_PROVIDER_NAME,
                context={"api_base": self._api_base},
            ) from exc

        models_data = data.get("data", [])
        return [m.get("id", "") for m in models_data if m.get("id")]

    async def health_check(self) -> bool:
        """Ping the server to check if it is reachable.

        Returns:
            True if the server responds, False otherwise.
        """
        client = self._make_client()
        try:
            async with client:
                resp = await client.get(
                    f"{self._api_base}/models",
                )
                return resp.status_code < 500
        except Exception:
            return False

    def _make_client(self) -> Any:
        """Create an httpx async client."""
        try:
            import httpx
        except ImportError as exc:
            raise LLMError(
                "httpx is required for OpenAICompatibleProvider. "
                "Install with: pip install pygubernator[workflow]",
                provider=_PROVIDER_NAME,
            ) from exc

        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        # Separate read vs connect: slow local models need long read, not long connect.
        t = httpx.Timeout(
            connect=30.0,
            read=self._read_timeout,
            write=120.0,
            pool=30.0,
        )
        return httpx.AsyncClient(
            headers=headers,
            timeout=t,
        )

    def _build_request_body(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Build the OpenAI-format request body."""
        body: dict[str, Any] = {
            "model": self._model,
            "messages": messages,
            "max_tokens": self._max_tokens,
            "temperature": self._temperature,
        }
        if self._top_p is not None:
            body["top_p"] = self._top_p
        if tools:
            body["tools"] = _format_tools(tools)
        return body

    @staticmethod
    def _parse_response(data: dict[str, Any]) -> LLMResponse:
        """Parse an OpenAI-format JSON response into LLMResponse."""
        choices = data.get("choices", [])
        if not choices:
            return LLMResponse(content="", finish_reason="stop")

        choice = choices[0]
        message = choice.get("message", {})

        tool_calls: list[ToolCall] = []
        raw_calls = message.get("tool_calls") or []
        for tc in raw_calls:
            func = tc.get("function", {})
            args = func.get("arguments", "{}")
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"raw": args}
            tool_calls.append(
                ToolCall(
                    id=tc.get("id", ""),
                    name=func.get("name", ""),
                    arguments=args,
                )
            )

        usage_data = data.get("usage") or {}
        usage: dict[str, int] = {}
        if usage_data:
            usage = {
                "prompt_tokens": usage_data.get("prompt_tokens", 0),
                "completion_tokens": usage_data.get("completion_tokens", 0),
                "total_tokens": usage_data.get("total_tokens", 0),
            }

        return LLMResponse(
            content=message.get("content") or "",
            tool_calls=tuple(tool_calls),
            finish_reason=choice.get("finish_reason") or "stop",
            usage=usage,
            model=data.get("model") or "",
        )


def _format_tools(
    tools: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Convert tool schemas to OpenAI-compatible format."""
    formatted: list[dict[str, Any]] = []
    for t in tools:
        formatted.append(
            {
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t.get("parameters", {}),
                },
            }
        )
    return formatted


def _parse_stream_chunk(data: dict[str, Any]) -> StreamChunk:
    """Parse one SSE JSON object into a StreamChunk.

    Args:
        data: Parsed JSON from a streaming SSE line.

    Returns:
        A StreamChunk with extracted delta fields.
    """
    choices = data.get("choices", [])
    delta_content = ""
    finish_reason: str | None = None
    tool_deltas: list[ToolCallDelta] = []

    if choices:
        choice = choices[0]
        delta = choice.get("delta", {})
        delta_content = delta.get("content") or ""
        finish_reason = choice.get("finish_reason")

        for tc in delta.get("tool_calls") or []:
            func = tc.get("function", {})
            tool_deltas.append(
                ToolCallDelta(
                    index=tc.get("index", 0),
                    id=tc.get("id"),
                    name=func.get("name"),
                    arguments_delta=func.get(
                        "arguments",
                        "",
                    ),
                ),
            )

    usage_data = data.get("usage") or {}
    usage: dict[str, int] = {}
    if usage_data:
        usage = {
            "prompt_tokens": usage_data.get(
                "prompt_tokens",
                0,
            ),
            "completion_tokens": usage_data.get(
                "completion_tokens",
                0,
            ),
            "total_tokens": usage_data.get(
                "total_tokens",
                0,
            ),
        }

    return StreamChunk(
        delta_content=delta_content,
        tool_calls_delta=tuple(tool_deltas),
        finish_reason=finish_reason,
        usage=usage,
    )
