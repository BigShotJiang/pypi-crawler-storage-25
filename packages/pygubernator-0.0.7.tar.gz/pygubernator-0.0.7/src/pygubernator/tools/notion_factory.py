"""Factory helpers to build Notion tool sets."""

from __future__ import annotations

import os
from typing import Any

from pygubernator.tools.notion_tools import create_notion_tools

_API_KEY_ENV = "PYGUBERNATOR_NOTION_API_KEY"


def create_tools_from_env(
    api_key_env_var: str = _API_KEY_ENV,
) -> list[Any]:
    """Create Notion tools using an API key from the environment.

    Args:
        api_key_env_var: Environment variable name storing the
            Notion integration token.

    Returns:
        A list of tool objects ready for registration.

    Raises:
        ValueError: If the env var is not set.
    """
    api_key = os.environ.get(api_key_env_var, "").strip()
    if not api_key:
        raise ValueError(
            f"Missing Notion API key. Set {api_key_env_var} "
            "to a Notion integration token.",
        )
    return create_notion_tools(api_key)
