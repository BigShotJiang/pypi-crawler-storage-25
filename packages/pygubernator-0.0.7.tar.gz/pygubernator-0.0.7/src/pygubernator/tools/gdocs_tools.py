"""Google Docs tools for creating and modifying documents."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)

try:
    from google.oauth2.service_account import (
        Credentials,  # type: ignore[import-untyped]
    )
    from googleapiclient.discovery import (
        build,  # type: ignore[import-untyped]
    )

    _HAS_GDOCS = True
except ImportError:
    _HAS_GDOCS = False

_SCOPES = ["https://www.googleapis.com/auth/documents"]


def _check_deps() -> None:
    """Raise if Google API dependencies are missing."""
    if not _HAS_GDOCS:
        msg = (
            "Google Docs dependencies not available. "
            "Install with: pip install google-api-python-client "
            "google-auth"
        )
        raise ImportError(msg)


def _extract_text(body: dict[str, Any]) -> str:
    """Extract plain text from a Google Docs body structure.

    Iterates over structural elements in ``body["content"]`` and
    concatenates all ``textRun.content`` values.

    Args:
        body: The ``body`` dict from a Google Docs API response.

    Returns:
        Concatenated plain text from all text runs.
    """
    parts: list[str] = []
    for element in body.get("content", []):
        paragraph = element.get("paragraph")
        if paragraph is None:
            continue
        for pe in paragraph.get("elements", []):
            text_run = pe.get("textRun")
            if text_run is not None:
                parts.append(text_run.get("content", ""))
    return "".join(parts)


class _DocsClient:
    """Thin wrapper around the Google Docs API v1.

    Args:
        credentials_path: Path to service account JSON key file.
    """

    def __init__(self, credentials_path: str) -> None:
        _check_deps()
        creds = Credentials.from_service_account_file(credentials_path, scopes=_SCOPES)
        service = build("docs", "v1", credentials=creds)
        self._docs = service.documents()

    # ------------------------------------------------------------------
    # Document operations
    # ------------------------------------------------------------------

    def create_document(self, title: str) -> dict[str, Any]:
        """Create a new empty Google Doc.

        Args:
            title: Document title.

        Returns:
            Dict with ``document_id`` and ``title``.
        """
        result = self._docs.create(body={"title": title}).execute()
        return {
            "document_id": result["documentId"],
            "title": result["title"],
        }

    def get_document(self, document_id: str) -> dict[str, Any]:
        """Get a document's title and full text content.

        Args:
            document_id: The Google Doc ID.

        Returns:
            Dict with ``document_id``, ``title``, and ``body_text``.
        """
        result = self._docs.get(documentId=document_id).execute()
        body_text = _extract_text(result.get("body", {}))
        return {
            "document_id": result["documentId"],
            "title": result["title"],
            "body_text": body_text,
        }

    # ------------------------------------------------------------------
    # Insert / Replace
    # ------------------------------------------------------------------

    def insert_text(
        self,
        document_id: str,
        text: str,
        index: int | None = None,
    ) -> dict[str, Any]:
        """Insert text at a position in a document.

        If *index* is ``None``, the text is appended at the end of
        the document body (just before the trailing newline).

        Args:
            document_id: The Google Doc ID.
            text: Text content to insert.
            index: 1-based character index. Defaults to end.

        Returns:
            Dict with ``inserted`` flag and ``index`` used.
        """
        if index is None:
            doc = self._docs.get(documentId=document_id).execute()
            body = doc.get("body", {})
            content = body.get("content", [])
            end_index = 1
            if content:
                last = content[-1]
                end_index = last.get("endIndex", 1)
            # Insert before the final newline.
            index = max(end_index - 1, 1)

        request = {
            "insertText": {
                "location": {"index": index},
                "text": text,
            }
        }
        self.batch_update(document_id, [request])
        return {"inserted": True, "index": index}

    def replace_text(
        self,
        document_id: str,
        find: str,
        replace: str,
    ) -> dict[str, Any]:
        """Find and replace all occurrences in a document.

        Args:
            document_id: The Google Doc ID.
            find: Text to search for (case-sensitive).
            replace: Replacement text.

        Returns:
            Dict with ``occurrences_changed`` count.
        """
        request = {
            "replaceAllText": {
                "containsText": {
                    "text": find,
                    "matchCase": True,
                },
                "replaceText": replace,
            }
        }
        result = self.batch_update(document_id, [request])
        replies = result.get("replies", [{}])
        count = replies[0].get("replaceAllText", {}).get("occurrencesChanged", 0)
        return {"occurrences_changed": count}

    # ------------------------------------------------------------------
    # Batch update
    # ------------------------------------------------------------------

    def batch_update(
        self,
        document_id: str,
        requests: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Execute a batchUpdate request.

        Args:
            document_id: The Google Doc ID.
            requests: List of request dicts.

        Returns:
            Dict with ``replies`` from the API.
        """
        body: dict[str, Any] = {"requests": requests}
        result = self._docs.batchUpdate(documentId=document_id, body=body).execute()
        return {"replies": result.get("replies", [])}


# ======================================================================
# Public factory
# ======================================================================


def create_gdocs_tools(
    credentials_path: str,
) -> list[Any]:
    """Create Google Docs tools backed by a service account.

    Args:
        credentials_path: Path to the service account JSON key file.

    Returns:
        List of tool objects ready for registration.
    """
    client = _DocsClient(credentials_path)

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    @tool(
        name="gdocs_create_document",
        description="Create a new empty Google Doc.",
    )
    async def gdocs_create_document(
        title: str,
    ) -> dict[str, Any]:
        """Create a new empty Google Doc.

        Args:
            title: Title for the new document.

        Returns:
            Dict with document_id and title.
        """
        return client.create_document(title)

    @tool(
        name="gdocs_get_document",
        description=("Get a Google Doc's title and full text content."),
    )
    async def gdocs_get_document(
        document_id: str,
    ) -> dict[str, Any]:
        """Get a Google Doc's title and body text.

        Args:
            document_id: The Google Doc ID from the URL.

        Returns:
            Dict with document_id, title, and body_text.
        """
        return client.get_document(document_id)

    @tool(
        name="gdocs_insert_text",
        description=(
            "Insert text at a position in a Google Doc. Defaults to end of document."
        ),
    )
    async def gdocs_insert_text(
        document_id: str,
        text: str,
        index: int | None = None,
    ) -> dict[str, Any]:
        """Insert text into a Google Doc.

        Args:
            document_id: The Google Doc ID.
            text: Text content to insert.
            index: 1-based character index. Defaults to end.

        Returns:
            Dict with inserted flag and index used.
        """
        return client.insert_text(document_id, text, index)

    @tool(
        name="gdocs_replace_text",
        description=("Find and replace all occurrences of text in a Google Doc."),
    )
    async def gdocs_replace_text(
        document_id: str,
        find: str,
        replace: str,
    ) -> dict[str, Any]:
        """Find and replace text in a Google Doc.

        Args:
            document_id: The Google Doc ID.
            find: Text to search for (case-sensitive).
            replace: Replacement text.

        Returns:
            Dict with occurrences_changed count.
        """
        return client.replace_text(document_id, find, replace)

    @tool(
        name="gdocs_batch_update",
        description=(
            "Execute batch update requests on a Google Doc "
            "for advanced formatting and operations."
        ),
    )
    async def gdocs_batch_update(
        document_id: str,
        requests: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Execute batch update requests on a Google Doc.

        Args:
            document_id: The Google Doc ID.
            requests: List of request dicts for the API.

        Returns:
            Dict with replies from the batch update.
        """
        return client.batch_update(document_id, requests)

    return [
        gdocs_create_document,
        gdocs_get_document,
        gdocs_insert_text,
        gdocs_replace_text,
        gdocs_batch_update,
    ]
