"""Tool wrappers for pycatalyst mock data generation."""

from __future__ import annotations

import logging
from dataclasses import is_dataclass
from enum import Enum
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)


def create_catalyst_tools(schemas: dict[str, Any]) -> list[Any]:
    """Create pycatalyst tools pre-loaded with schema definitions.

    Args:
        schemas: Mapping of schema name to SchemaSpec objects.

    Returns:
        List of tool objects ready for registration.
    """

    @tool(
        name="generate_data",
        description=(
            "Generate mock data records using a named schema. "
            "Returns a list of dictionaries."
        ),
    )
    async def generate_data(
        schema_name: str,
        count: int = 10,
        seed: int | None = None,
    ) -> list[dict[str, Any]]:
        """Generate mock data from a registered schema.

        Args:
            schema_name: Name of the schema to use.
            count: Number of records to generate.
            seed: Optional random seed for reproducibility.

        Returns:
            List of generated records.
        """
        try:
            from pycatalyst import GenerationEngine
        except ImportError as exc:
            raise RuntimeError(
                "pycatalyst is required: pip install pycatalyst"
            ) from exc

        if schema_name not in schemas:
            raise ValueError(
                f"Schema '{schema_name}' not found. Available: {list(schemas.keys())}"
            )

        engine = GenerationEngine()
        result = engine.generate(schemas[schema_name], count, seed)
        return list(result.records)

    @tool(
        name="build_schema",
        description=(
            "Build a pycatalyst SchemaSpec from field definitions. "
            "Returns a serializable schema dict."
        ),
    )
    async def build_schema(
        fields: dict[str, dict[str, Any]],
    ) -> dict[str, Any]:
        """Build a schema from field definitions.

        Args:
            fields: Mapping of field name to field config dicts.
                Each dict must have a ``"type"`` key (e.g. ``"string"``,
                ``"int"``). Other keys are treated as constraints
                (``"min"``, ``"max"``, ``"precision"``, ``"choices"``, etc.).

        Returns:
            Serialized SchemaSpec dictionary.
        """
        try:
            from pycatalyst import SchemaBuilder
        except ImportError as exc:
            raise RuntimeError(
                "pycatalyst is required: pip install pycatalyst"
            ) from exc

        def _to_jsonable(obj: Any) -> Any:
            if isinstance(obj, Enum):
                return obj.value
            if is_dataclass(obj):
                # Avoid dataclasses.asdict to keep control over Enum/tuple conversion
                # and to omit None values (SchemaSpec.from_config expects constraints
                # to be absent, not present as null).
                out: dict[str, Any] = {}
                for k in obj.__dataclass_fields__:  # type: ignore[attr-defined]
                    v = getattr(obj, k)
                    if v is None:
                        continue
                    out[k] = _to_jsonable(v)
                return out
            if isinstance(obj, dict):
                return {str(k): _to_jsonable(v) for k, v in obj.items()}
            if isinstance(obj, list | tuple):
                return [_to_jsonable(v) for v in obj]
            return obj

        def _add_field(
            builder: Any, name: str, type_name: str, cfg: dict[str, Any]
        ) -> None:
            t = type_name.strip().lower()

            # Common constraints (tests use min/max; builder uses min_val/max_val)
            min_val = cfg.get("min", cfg.get("min_val"))
            max_val = cfg.get("max", cfg.get("max_val"))

            if t in {"string", "str"}:
                builder.add_string(
                    name,
                    nullable=bool(cfg.get("nullable", False)),
                    min_len=cfg.get("min_len"),
                    max_len=cfg.get("max_len"),
                    pattern=cfg.get("pattern"),
                    format=cfg.get("format"),
                )
                return

            if t in {"int", "integer"}:
                builder.add_int(
                    name,
                    nullable=bool(cfg.get("nullable", False)),
                    min_val=min_val,
                    max_val=max_val,
                    distribution=cfg.get("distribution"),
                    mean=cfg.get("mean"),
                    std=cfg.get("std"),
                )
                return

            if t in {"float", "number"}:
                builder.add_float(
                    name,
                    nullable=bool(cfg.get("nullable", False)),
                    min_val=min_val,
                    max_val=max_val,
                    precision=cfg.get("precision"),
                    distribution=cfg.get("distribution"),
                    mean=cfg.get("mean"),
                    std=cfg.get("std"),
                )
                return

            if t in {"bool", "boolean"}:
                builder.add_bool(name, nullable=bool(cfg.get("nullable", False)))
                return

            if t in {"uuid"}:
                builder.add_uuid(name, nullable=bool(cfg.get("nullable", False)))
                return

            if t in {"date"}:
                builder.add_date(name, nullable=bool(cfg.get("nullable", False)))
                return

            if t in {"datetime", "timestamp"}:
                builder.add_datetime(name, nullable=bool(cfg.get("nullable", False)))
                return

            if t in {"enum"}:
                choices = cfg.get("choices")
                if not isinstance(choices, list) or not choices:
                    raise ValueError(
                        f"Field '{name}' type enum requires non-empty 'choices' list"
                    )
                builder.add_enum(
                    name, choices=choices, nullable=bool(cfg.get("nullable", False))
                )
                return

            raise ValueError(
                f"Unsupported field type '{type_name}' for '{name}'. "
                "Supported: string, int, float, bool, uuid, date, datetime, enum"
            )

        builder = SchemaBuilder("dynamic", description="Agent-built schema")
        for name, config in fields.items():
            field_config = dict(config)
            type_name = field_config.pop("type", None)
            if not isinstance(type_name, str) or not type_name.strip():
                raise ValueError(f"Field '{name}' is missing required key: type")
            _add_field(builder, name, type_name, field_config)
        schema = builder.build()
        # Return a config dict compatible with SchemaSpec.from_config
        return _to_jsonable(schema)

    return [generate_data, build_schema]
