"""Factory helpers to build Google Sheets tool sets."""

from __future__ import annotations

import os
from typing import Any

from pygubernator.tools.gsheets_tools import create_gsheets_tools

_CREDS_ENV = "PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH"


def create_tools_from_env(credentials_env_var: str = _CREDS_ENV) -> list[Any]:
    """Create Google Sheets tools using a credentials file path from env.

    Args:
        credentials_env_var: Environment variable name storing the JSON key path.

    Returns:
        A list of tool objects ready for registration.

    Raises:
        ValueError: If the env var is not set.
    """
    credentials_path = os.environ.get(credentials_env_var, "").strip()
    if not credentials_path:
        raise ValueError(
            f"Missing Google Sheets credentials path. Set {credentials_env_var} "
            "to a service-account JSON key path.",
        )
    return create_gsheets_tools(credentials_path)
