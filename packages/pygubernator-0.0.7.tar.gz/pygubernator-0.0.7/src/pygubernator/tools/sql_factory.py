"""Factory helpers to build SQL database tool sets."""

from __future__ import annotations

import os
from typing import Any

from pygubernator.tools.sql_tools import create_sql_tools

_CONN_ENV = "PYGUBERNATOR_SQL_CONNECTION_STRING"
_READONLY_ENV = "PYGUBERNATOR_SQL_READONLY"


def create_tools_from_env(
    connection_env_var: str = _CONN_ENV,
    readonly_env_var: str = _READONLY_ENV,
) -> list[Any]:
    """Create SQL tools using a connection string from env.

    Args:
        connection_env_var: Env var storing the database URL.
        readonly_env_var: Env var controlling readonly mode.
            Defaults to ``"1"`` (truthy = readonly).

    Returns:
        A list of tool objects ready for registration.

    Raises:
        ValueError: If the connection string env var is not set.
    """
    connection_string = os.environ.get(connection_env_var, "").strip()
    if not connection_string:
        msg = (
            f"Missing SQL connection string. "
            f"Set {connection_env_var} to a database URL."
        )
        raise ValueError(msg)
    readonly_raw = os.environ.get(readonly_env_var, "1").strip()
    readonly = readonly_raw in {"1", "true", "True", "yes"}
    return create_sql_tools(connection_string, readonly=readonly)
