"""Slack tools for sending messages and interacting with channels."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)

try:
    from slack_sdk.web.async_client import AsyncWebClient

    _HAS_SLACK = True
except ImportError:
    _HAS_SLACK = False


def _check_deps() -> None:
    """Raise if Slack SDK dependencies are missing."""
    if not _HAS_SLACK:
        msg = (
            "Slack SDK dependencies not available. Install with: pip install slack_sdk"
        )
        raise ImportError(msg)


class _SlackClient:
    """Thin async wrapper around the Slack Web API.

    Args:
        bot_token: Slack bot OAuth token.
    """

    def __init__(self, bot_token: str) -> None:
        _check_deps()
        self._client = AsyncWebClient(token=bot_token)

    # ------------------------------------------------------------------
    # Messaging
    # ------------------------------------------------------------------

    async def send_message(
        self,
        channel: str,
        text: str,
        thread_ts: str | None = None,
    ) -> dict[str, Any]:
        """Send a message to a Slack channel.

        Args:
            channel: Channel ID or name.
            text: Message text.
            thread_ts: Thread timestamp to reply to.

        Returns:
            Dict with channel, ts, and message.
        """
        resp = await self._client.chat_postMessage(
            channel=channel,
            text=text,
            thread_ts=thread_ts,
        )
        return {
            "channel": resp["channel"],
            "ts": resp["ts"],
            "message": resp.get("message", {}),
        }

    # ------------------------------------------------------------------
    # Channels
    # ------------------------------------------------------------------

    async def list_channels(
        self,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """List public Slack channels the bot can access.

        Args:
            limit: Maximum number of channels to return.

        Returns:
            List of channel dicts with id, name, topic,
            purpose, and num_members.
        """
        resp = await self._client.conversations_list(
            limit=limit,
            types="public_channel",
        )
        channels: list[dict[str, Any]] = []
        for ch in resp.get("channels", []):
            channels.append(
                {
                    "id": ch["id"],
                    "name": ch["name"],
                    "topic": ch.get("topic", {}).get("value", ""),
                    "purpose": ch.get("purpose", {}).get("value", ""),
                    "num_members": ch.get("num_members", 0),
                }
            )
        return channels

    # ------------------------------------------------------------------
    # History
    # ------------------------------------------------------------------

    async def read_messages(
        self,
        channel: str,
        limit: int = 10,
        oldest: str | None = None,
    ) -> list[dict[str, Any]]:
        """Read recent messages from a channel.

        Args:
            channel: Channel ID.
            limit: Maximum number of messages to return.
            oldest: Only return messages after this timestamp.

        Returns:
            List of message dicts with user, text, ts,
            and optional thread_ts.
        """
        kwargs: dict[str, Any] = {
            "channel": channel,
            "limit": limit,
        }
        if oldest is not None:
            kwargs["oldest"] = oldest

        resp = await self._client.conversations_history(**kwargs)
        messages: list[dict[str, Any]] = []
        for msg in resp.get("messages", []):
            entry: dict[str, Any] = {
                "user": msg.get("user", ""),
                "text": msg.get("text", ""),
                "ts": msg["ts"],
            }
            if "thread_ts" in msg:
                entry["thread_ts"] = msg["thread_ts"]
            messages.append(entry)
        return messages

    # ------------------------------------------------------------------
    # Reactions
    # ------------------------------------------------------------------

    async def add_reaction(
        self,
        channel: str,
        timestamp: str,
        emoji: str,
    ) -> dict[str, Any]:
        """Add an emoji reaction to a message.

        Args:
            channel: Channel ID containing the message.
            timestamp: Timestamp of the target message.
            emoji: Emoji name without colons.

        Returns:
            Dict confirming the reaction was added.
        """
        await self._client.reactions_add(
            channel=channel,
            timestamp=timestamp,
            name=emoji,
        )
        return {"ok": True}

    # ------------------------------------------------------------------
    # File uploads
    # ------------------------------------------------------------------

    async def upload_file(
        self,
        channels: str,
        content: str,
        filename: str,
        title: str | None = None,
    ) -> dict[str, Any]:
        """Upload text content as a file to a channel.

        Args:
            channels: Channel ID to share the file in.
            content: Text content of the file.
            filename: Name for the uploaded file.
            title: Optional title for the file.

        Returns:
            Dict with file_id and url.
        """
        resp = await self._client.files_upload_v2(
            channel=channels,
            content=content,
            filename=filename,
            title=title,
        )
        file_info = resp.get("file", {})
        return {
            "file_id": file_info.get("id", ""),
            "url": file_info.get("permalink", ""),
        }


# ======================================================================
# Public factory
# ======================================================================


def create_slack_tools(bot_token: str) -> list[Any]:
    """Create Slack tools backed by a bot token.

    Args:
        bot_token: Slack bot OAuth token.

    Returns:
        List of tool objects ready for registration.
    """
    client = _SlackClient(bot_token)

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    @tool(
        name="slack_send_message",
        description=("Send a message to a Slack channel or reply to a thread."),
    )
    async def slack_send_message(
        channel: str,
        text: str,
        thread_ts: str | None = None,
    ) -> dict[str, Any]:
        """Send a message to a Slack channel.

        Args:
            channel: Channel ID or name to post to.
            text: Message text to send.
            thread_ts: Thread timestamp to reply in.

        Returns:
            Dict with channel, ts, and message.
        """
        return await client.send_message(channel, text, thread_ts)

    @tool(
        name="slack_list_channels",
        description=("List public Slack channels the bot can access."),
    )
    async def slack_list_channels(
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """List public Slack channels.

        Args:
            limit: Maximum number of channels to return.

        Returns:
            List of channel dicts.
        """
        return await client.list_channels(limit)

    @tool(
        name="slack_read_messages",
        description=("Read recent messages from a Slack channel."),
    )
    async def slack_read_messages(
        channel: str,
        limit: int = 10,
        oldest: str | None = None,
    ) -> list[dict[str, Any]]:
        """Read recent messages from a channel.

        Args:
            channel: Channel ID to read from.
            limit: Maximum number of messages.
            oldest: Only messages after this timestamp.

        Returns:
            List of message dicts.
        """
        return await client.read_messages(channel, limit, oldest)

    @tool(
        name="slack_add_reaction",
        description=("Add an emoji reaction to a message."),
    )
    async def slack_add_reaction(
        channel: str,
        timestamp: str,
        emoji: str,
    ) -> dict[str, Any]:
        """Add an emoji reaction to a message.

        Args:
            channel: Channel ID containing the message.
            timestamp: Timestamp of the target message.
            emoji: Emoji name without colons.

        Returns:
            Dict confirming the reaction.
        """
        return await client.add_reaction(channel, timestamp, emoji)

    @tool(
        name="slack_upload_file",
        description=("Upload text content as a file to a Slack channel."),
    )
    async def slack_upload_file(
        channels: str,
        content: str,
        filename: str,
        title: str | None = None,
    ) -> dict[str, Any]:
        """Upload text content as a file to a channel.

        Args:
            channels: Channel ID to share the file in.
            content: Text content of the file.
            filename: Name for the uploaded file.
            title: Optional title for the file.

        Returns:
            Dict with file_id and url.
        """
        return await client.upload_file(channels, content, filename, title)

    return [
        slack_send_message,
        slack_list_channels,
        slack_read_messages,
        slack_add_reaction,
        slack_upload_file,
    ]
