"""Factory helpers to build Python execution tool sets from env."""

from __future__ import annotations

import os
from typing import Any

from pygubernator.tools.python_tools import create_python_tools

_ALLOWED_IMPORTS_ENV = "PYGUBERNATOR_PYTHON_ALLOWED_IMPORTS"
_TIMEOUT_ENV = "PYGUBERNATOR_PYTHON_TIMEOUT"


def create_tools_from_env() -> list[Any]:
    """Create Python execution tools using configuration from env.

    Reads:
        ``PYGUBERNATOR_PYTHON_ALLOWED_IMPORTS``: Comma-separated list
            of allowed module names.  Empty or unset means unrestricted.
        ``PYGUBERNATOR_PYTHON_TIMEOUT``: Max seconds for execution
            (default ``30``).

    Returns:
        A list of tool objects ready for registration.
    """
    raw_imports = os.environ.get(_ALLOWED_IMPORTS_ENV, "").strip()
    allowed_imports: list[str] | None = None
    if raw_imports:
        allowed_imports = [m.strip() for m in raw_imports.split(",") if m.strip()]

    timeout = int(os.environ.get(_TIMEOUT_ENV, "30"))

    return create_python_tools(
        allowed_imports=allowed_imports,
        timeout=timeout,
    )
