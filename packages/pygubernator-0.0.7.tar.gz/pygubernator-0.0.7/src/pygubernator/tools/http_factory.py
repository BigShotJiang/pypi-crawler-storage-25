"""Factory helpers to build HTTP tool sets from environment variables."""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from pygubernator.tools.http_tools import create_http_tools

logger = logging.getLogger(__name__)

_BASE_URL_ENV = "PYGUBERNATOR_HTTP_BASE_URL"
_HEADERS_ENV = "PYGUBERNATOR_HTTP_DEFAULT_HEADERS"
_TIMEOUT_ENV = "PYGUBERNATOR_HTTP_TIMEOUT"


def create_tools_from_env() -> list[Any]:
    """Create HTTP tools using configuration from environment variables.

    Reads the following env vars:
        - ``PYGUBERNATOR_HTTP_BASE_URL`` (optional, default ``""``).
        - ``PYGUBERNATOR_HTTP_DEFAULT_HEADERS`` (optional JSON string).
        - ``PYGUBERNATOR_HTTP_TIMEOUT`` (optional, default ``30.0``).

    Returns:
        A list of tool objects ready for registration.
    """
    base_url = os.environ.get(_BASE_URL_ENV, "").strip()

    raw_headers = os.environ.get(_HEADERS_ENV, "").strip()
    default_headers: dict[str, str] | None = None
    if raw_headers:
        default_headers = json.loads(raw_headers)

    raw_timeout = os.environ.get(_TIMEOUT_ENV, "").strip()
    timeout = float(raw_timeout) if raw_timeout else 30.0

    return create_http_tools(
        base_url=base_url,
        default_headers=default_headers,
        timeout=timeout,
    )
