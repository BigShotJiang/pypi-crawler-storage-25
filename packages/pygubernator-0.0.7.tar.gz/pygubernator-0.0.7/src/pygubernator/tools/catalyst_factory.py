"""Factory helpers for pycatalyst mock data tools."""

from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_SCHEMAS_ENV = "PYGUBERNATOR_CATALYST_SCHEMAS_PATH"


def _default_schemas() -> dict[str, Any]:
    """Build a set of demo schemas for common use cases."""
    try:
        from pycatalyst.schema.spec import SchemaBuilder
    except ImportError as exc:
        msg = (
            "pycatalyst required for catalyst tools. "
            "Install with: pip install pygubernator[workflow]"
        )
        raise ImportError(msg) from exc

    users = (
        SchemaBuilder("users", description="Demo user accounts")
        .add_uuid("id")
        .add_string("name", format="name")
        .add_string("email", format="email")
        .add_datetime("created_at")
        .build()
    )
    orders = (
        SchemaBuilder("orders", description="Demo order records")
        .add_uuid("id")
        .add_uuid("user_id")
        .add_float("amount", min_val=1.0, max_val=9999.99, precision=2)
        .add_enum(
            "status",
            ["pending", "confirmed", "shipped", "delivered"],
        )
        .add_datetime("created_at")
        .build()
    )
    products = (
        SchemaBuilder("products", description="Demo product catalog")
        .add_uuid("id")
        .add_string("name", min_len=2, max_len=60)
        .add_float("price", min_val=0.99, max_val=999.99, precision=2)
        .add_enum(
            "category",
            ["electronics", "clothing", "food", "books"],
        )
        .build()
    )

    risk_assessments = (
        SchemaBuilder("risk_assessments", description="Demo risk assessment records")
        .add_uuid("id")
        .add_string("applicant_name", format="name")
        .add_int("risk_score", min_val=0, max_val=100)
        .add_float("credit_amount", min_val=100.0, max_val=50000.0, precision=2)
        .add_enum("category", ["personal", "business", "mortgage"])
        .build()
    )

    return {
        "users": users,
        "orders": orders,
        "products": products,
        "risk_assessments": risk_assessments,
    }


def _load_schemas_from_file(path: str) -> dict[str, Any]:
    """Load SchemaSpec objects from a YAML file.

    Args:
        path: Filesystem path to a YAML file containing schemas.

    Returns:
        Mapping of schema name to SchemaSpec objects.
    """
    try:
        import yaml
    except ImportError as exc:
        raise ImportError("PyYAML required to load custom schemas") from exc

    from pycatalyst._types import SchemaSpec

    with open(path, encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)

    schemas: dict[str, Any] = {}
    for entry in raw.get("schemas", []):
        spec = SchemaSpec.from_config(entry)
        schemas[spec.name] = spec
    return schemas


def create_tools_from_env(
    schemas_env_var: str = _SCHEMAS_ENV,
) -> list[Any]:
    """Create pycatalyst tools with demo or custom schemas.

    Args:
        schemas_env_var: Env var for custom schemas YAML path.

    Returns:
        List of tool objects.
    """
    from pygubernator.tools.catalyst_tools import (
        create_catalyst_tools,
    )

    schemas_path = os.environ.get(schemas_env_var, "").strip()
    if schemas_path:
        logger.info("Loading catalyst schemas from %s", schemas_path)
        schemas = _load_schemas_from_file(schemas_path)
    else:
        logger.info("Using built-in demo catalyst schemas")
        schemas = _default_schemas()

    return create_catalyst_tools(schemas)
