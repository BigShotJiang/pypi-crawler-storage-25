"""Factory helpers for pystator state machine tools."""

from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_MACHINES_ENV = "PYGUBERNATOR_STATOR_MACHINES_PATH"


def _default_machines() -> dict[str, Any]:
    """Build demo state machines for common use cases."""
    try:
        from pystator import StateMachine
    except ImportError as exc:
        msg = "pystator required for stator tools. Install with: pip install pystator"
        raise ImportError(msg) from exc

    order_lifecycle = StateMachine.from_dict(
        {
            "states": [
                {"name": "pending", "type": "initial"},
                {"name": "confirmed", "type": "stable"},
                {"name": "shipped", "type": "stable"},
                {"name": "delivered", "type": "terminal"},
                {"name": "cancelled", "type": "terminal"},
            ],
            "transitions": [
                {
                    "trigger": "confirm",
                    "source": "pending",
                    "dest": "confirmed",
                },
                {
                    "trigger": "ship",
                    "source": "confirmed",
                    "dest": "shipped",
                },
                {
                    "trigger": "deliver",
                    "source": "shipped",
                    "dest": "delivered",
                },
                {
                    "trigger": "cancel",
                    "source": "pending",
                    "dest": "cancelled",
                },
                {
                    "trigger": "cancel",
                    "source": "confirmed",
                    "dest": "cancelled",
                },
            ],
        }
    )

    risk_classifier = StateMachine.from_dict(
        {
            "meta": {
                "machine_name": "risk_classifier",
                "classification": {"auto_route": True},
            },
            "states": [
                {"name": "intake", "type": "initial"},
                {
                    "name": "approved",
                    "type": "terminal",
                    "when": [{"field": "risk_score", "op": "gte", "value": 70}],
                },
                {
                    "name": "review_required",
                    "type": "stable",
                    "when": [
                        {
                            "all_of": [
                                {
                                    "field": "risk_score",
                                    "op": "gte",
                                    "value": 40,
                                },
                                {
                                    "field": "risk_score",
                                    "op": "lt",
                                    "value": 70,
                                },
                            ]
                        }
                    ],
                },
                {
                    "name": "rejected",
                    "type": "terminal",
                    "when": [{"field": "risk_score", "op": "lt", "value": 40}],
                },
            ],
            "transitions": [
                {
                    "trigger": "classify",
                    "source": "intake",
                    "dest": "approved",
                },
                {
                    "trigger": "classify",
                    "source": "intake",
                    "dest": "review_required",
                },
                {
                    "trigger": "classify",
                    "source": "intake",
                    "dest": "rejected",
                },
            ],
        }
    )

    return {
        "order_lifecycle": order_lifecycle,
        "risk_classifier": risk_classifier,
    }


def _load_machines_from_file(path: str) -> dict[str, Any]:
    """Load StateMachine objects from a YAML file.

    Args:
        path: Filesystem path to a YAML file with machine configs.

    Returns:
        Mapping of machine name to StateMachine objects.
    """
    try:
        import yaml
    except ImportError as exc:
        raise ImportError("PyYAML required to load custom machines") from exc

    from pystator import StateMachine

    with open(path, encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)

    machines: dict[str, Any] = {}
    for name, cfg in raw.get("machines", {}).items():
        machines[name] = StateMachine.from_dict(cfg)
    return machines


def create_tools_from_env(
    machines_env_var: str = _MACHINES_ENV,
) -> list[Any]:
    """Create pystator tools with demo or custom machines.

    Args:
        machines_env_var: Env var for custom machines YAML path.

    Returns:
        List of tool objects.
    """
    from pygubernator.tools.stator_tools import (
        create_stator_tools,
    )

    machines_path = os.environ.get(machines_env_var, "").strip()
    if machines_path:
        logger.info("Loading stator machines from %s", machines_path)
        machines = _load_machines_from_file(machines_path)
    else:
        logger.info("Using built-in demo stator machines")
        machines = _default_machines()

    return create_stator_tools(machines)
