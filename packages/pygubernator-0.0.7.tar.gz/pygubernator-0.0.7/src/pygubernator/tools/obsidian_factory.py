"""Factory helpers to build Obsidian vault tool sets."""

from __future__ import annotations

import logging
import os
from typing import Any

from pygubernator.tools.obsidian_tools import create_obsidian_tools

logger = logging.getLogger(__name__)

_VAULT_ENV = "PYGUBERNATOR_OBSIDIAN_VAULT_PATH"
_API_URL_ENV = "PYGUBERNATOR_OBSIDIAN_API_URL"
_API_KEY_ENV = "PYGUBERNATOR_OBSIDIAN_API_KEY"


def create_tools_from_env(
    vault_env_var: str = _VAULT_ENV,
    api_url_env_var: str = _API_URL_ENV,
    api_key_env_var: str = _API_KEY_ENV,
) -> list[Any]:
    """Create Obsidian vault tools using env-var configuration.

    Args:
        vault_env_var: Env var storing the vault directory path.
        api_url_env_var: Env var storing the optional REST API URL.
        api_key_env_var: Env var storing the optional REST API key.

    Returns:
        A list of tool objects ready for registration.

    Raises:
        ValueError: If the vault path env var is not set.
    """
    vault_path = os.environ.get(vault_env_var, "").strip()
    if not vault_path:
        raise ValueError(
            f"Missing Obsidian vault path. Set {vault_env_var} to the vault directory.",
        )
    api_url = os.environ.get(api_url_env_var, "").strip() or None
    api_key = os.environ.get(api_key_env_var, "").strip() or None
    return create_obsidian_tools(vault_path, api_url, api_key)
