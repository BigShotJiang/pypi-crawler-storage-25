"""Factory helpers to build Slack tool sets."""

from __future__ import annotations

import os
from typing import Any

from pygubernator.tools.slack_tools import create_slack_tools

_TOKEN_ENV = "PYGUBERNATOR_SLACK_BOT_TOKEN"


def create_tools_from_env(
    token_env_var: str = _TOKEN_ENV,
) -> list[Any]:
    """Create Slack tools using a bot token from env.

    Args:
        token_env_var: Environment variable name storing
            the Slack bot token.

    Returns:
        A list of tool objects ready for registration.

    Raises:
        ValueError: If the env var is not set.
    """
    bot_token = os.environ.get(token_env_var, "").strip()
    if not bot_token:
        raise ValueError(
            f"Missing Slack bot token. Set {token_env_var} "
            "to a valid Slack bot OAuth token.",
        )
    return create_slack_tools(bot_token)
