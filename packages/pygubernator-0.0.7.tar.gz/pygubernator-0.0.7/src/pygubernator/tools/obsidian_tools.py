"""Obsidian vault tools for reading, writing, and searching notes."""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)

try:
    import aiofiles  # type: ignore[import-untyped]

    _HAS_AIOFILES = True
except ImportError:
    _HAS_AIOFILES = False

try:
    import httpx  # type: ignore[import-untyped]

    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False


def _check_deps() -> None:
    """Raise if aiofiles is not installed."""
    if not _HAS_AIOFILES:
        msg = (
            "aiofiles is required for Obsidian vault tools. "
            "Install with: pip install aiofiles"
        )
        raise ImportError(msg)


def _first_matching_line(text: str, query_lower: str) -> str:
    """Return the first line containing the query."""
    for line in text.splitlines():
        if query_lower in line.lower():
            return line.strip()
    return ""


class _VaultClient:
    """Async client for Obsidian vault operations."""

    def __init__(
        self,
        vault_path: str,
        api_url: str | None = None,
        api_key: str | None = None,
    ) -> None:
        _check_deps()
        self._vault = Path(vault_path).resolve()
        if not self._vault.is_dir():
            msg = f"Vault path does not exist: {self._vault}"
            raise ValueError(msg)
        self._api_url = api_url
        self._api_key = api_key
        self._use_api = api_url is not None

    def _safe_path(self, path: str) -> Path:
        """Resolve *path* inside the vault; raise on traversal."""
        resolved = (self._vault / path).resolve()
        if not resolved.is_relative_to(self._vault):
            raise ValueError("Path traversal not allowed")
        return resolved

    def _api_headers(self) -> dict[str, str]:
        """Build authorization headers for the REST API."""
        if self._api_key:
            return {"Authorization": f"Bearer {self._api_key}"}
        return {}

    async def read_note(self, path: str) -> dict[str, Any]:
        """Read a note and return path, content, and size."""
        if self._use_api:
            async with httpx.AsyncClient(
                base_url=self._api_url,
                headers=self._api_headers(),
            ) as c:
                resp = await c.get(f"/vault/{path}")
                resp.raise_for_status()
                text = resp.text
        else:
            target = self._safe_path(path)
            async with aiofiles.open(
                target,
                encoding="utf-8",
            ) as f:
                text = await f.read()
        return {"path": path, "content": text, "size": len(text)}

    async def write_note(
        self,
        path: str,
        content: str,
    ) -> dict[str, Any]:
        """Create or overwrite a note; return path, size, created."""
        if self._use_api:
            async with httpx.AsyncClient(
                base_url=self._api_url,
                headers=self._api_headers(),
            ) as c:
                resp = await c.put(
                    f"/vault/{path}",
                    content=content,
                )
                resp.raise_for_status()
            return {
                "path": path,
                "size": len(content),
                "created": True,
            }
        target = self._safe_path(path)
        created = not target.exists()
        target.parent.mkdir(parents=True, exist_ok=True)
        async with aiofiles.open(
            target,
            mode="w",
            encoding="utf-8",
        ) as f:
            await f.write(content)
        return {
            "path": path,
            "size": len(content),
            "created": created,
        }

    async def append_note(
        self,
        path: str,
        content: str,
    ) -> dict[str, Any]:
        """Append content to an existing note."""
        if self._use_api:
            async with httpx.AsyncClient(
                base_url=self._api_url,
                headers=self._api_headers(),
            ) as c:
                resp = await c.post(
                    f"/vault/{path}",
                    content=content,
                )
                resp.raise_for_status()
        else:
            target = self._safe_path(path)
            async with aiofiles.open(
                target,
                mode="a",
                encoding="utf-8",
            ) as f:
                await f.write(content)
        return {"path": path, "appended_size": len(content)}

    async def search(
        self,
        query: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Search notes for *query*; return path and snippet."""
        if self._use_api:
            async with httpx.AsyncClient(
                base_url=self._api_url,
                headers=self._api_headers(),
            ) as c:
                resp = await c.post(
                    "/search/simple/",
                    params={"query": query},
                )
                resp.raise_for_status()
                return resp.json()[:limit]
        return await self._search_local(query, limit)

    async def _search_local(
        self,
        query: str,
        limit: int,
    ) -> list[dict[str, Any]]:
        """Walk the vault and find notes matching query."""
        matches: list[dict[str, Any]] = []
        q = query.lower()
        for root, _dirs, files in os.walk(self._vault):
            for fname in files:
                if not fname.endswith(".md"):
                    continue
                fpath = Path(root) / fname
                async with aiofiles.open(
                    fpath,
                    encoding="utf-8",
                ) as f:
                    text = await f.read()
                if q not in text.lower():
                    continue
                rel = str(fpath.relative_to(self._vault))
                snippet = _first_matching_line(text, q)
                matches.append({"path": rel, "snippet": snippet})
                if len(matches) >= limit:
                    return matches
        return matches

    async def list_notes(
        self,
        folder: str | None = None,
        recursive: bool = True,
    ) -> list[dict[str, Any]]:
        """List markdown notes in the vault or a subfolder."""
        if self._use_api:
            async with httpx.AsyncClient(
                base_url=self._api_url,
                headers=self._api_headers(),
            ) as c:
                ep = f"/vault/{folder}/" if folder else "/vault/"
                resp = await c.get(
                    ep,
                    params={"recursive": recursive},
                )
                resp.raise_for_status()
                return resp.json()
        base = self._safe_path(folder) if folder else self._vault
        glob_fn = base.rglob if recursive else base.glob
        return [
            {
                "path": str(p.relative_to(self._vault)),
                "size": p.stat().st_size,
            }
            for p in glob_fn("*.md")
        ]

    async def delete_note(self, path: str) -> dict[str, Any]:
        """Delete a note from the vault."""
        if self._use_api:
            async with httpx.AsyncClient(
                base_url=self._api_url,
                headers=self._api_headers(),
            ) as c:
                resp = await c.delete(f"/vault/{path}")
                resp.raise_for_status()
        else:
            self._safe_path(path).unlink()
        return {"path": path, "deleted": True}


# ======================================================================
# Public factory
# ======================================================================


def create_obsidian_tools(
    vault_path: str,
    api_url: str | None = None,
    api_key: str | None = None,
) -> list[Any]:
    """Create Obsidian vault tools backed by a local vault.

    Args:
        vault_path: Path to the Obsidian vault directory.
        api_url: Optional Obsidian Local REST API base URL.
        api_key: Optional API key for the REST API.

    Returns:
        List of tool objects ready for registration.
    """
    client = _VaultClient(vault_path, api_url, api_key)

    @tool(
        name="obsidian_read_note",
        description="Read a markdown note from the Obsidian vault.",
    )
    async def obsidian_read_note(path: str) -> dict[str, Any]:
        """Read a markdown note from the vault.

        Args:
            path: Relative path to the note (e.g. folder/note.md).

        Returns:
            Dict with path, content, and size.
        """
        return await client.read_note(path)

    @tool(
        name="obsidian_write_note",
        description=("Create or overwrite a markdown note in the Obsidian vault."),
    )
    async def obsidian_write_note(
        path: str,
        content: str,
    ) -> dict[str, Any]:
        """Create or overwrite a note in the vault.

        Args:
            path: Relative path to the note (e.g. folder/note.md).
            content: Markdown content to write.

        Returns:
            Dict with path, size, and created flag.
        """
        return await client.write_note(path, content)

    @tool(
        name="obsidian_append_note",
        description="Append content to an existing Obsidian note.",
    )
    async def obsidian_append_note(
        path: str,
        content: str,
    ) -> dict[str, Any]:
        """Append content to an existing note.

        Args:
            path: Relative path to the note.
            content: Content to append.

        Returns:
            Dict with path and appended_size.
        """
        return await client.append_note(path, content)

    @tool(
        name="obsidian_search",
        description=(
            "Search for notes containing the query text in the Obsidian vault."
        ),
    )
    async def obsidian_search(
        query: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Search for notes containing the query text.

        Args:
            query: Text to search for (case-insensitive).
            limit: Maximum number of results to return.

        Returns:
            List of dicts with path and snippet.
        """
        return await client.search(query, limit)

    @tool(
        name="obsidian_list_notes",
        description=("List markdown notes in the Obsidian vault or a subfolder."),
    )
    async def obsidian_list_notes(
        folder: str | None = None,
        recursive: bool = True,
    ) -> list[dict[str, Any]]:
        """List markdown notes in the vault.

        Args:
            folder: Optional subfolder to scope the listing.
            recursive: Whether to recurse into subdirectories.

        Returns:
            List of dicts with path and size.
        """
        return await client.list_notes(folder, recursive)

    @tool(
        name="obsidian_delete_note",
        description="Delete a note from the Obsidian vault.",
    )
    async def obsidian_delete_note(path: str) -> dict[str, Any]:
        """Delete a note from the vault.

        Args:
            path: Relative path to the note to delete.

        Returns:
            Dict confirming deletion.
        """
        return await client.delete_note(path)

    return [
        obsidian_read_note,
        obsidian_write_note,
        obsidian_append_note,
        obsidian_search,
        obsidian_list_notes,
        obsidian_delete_note,
    ]
