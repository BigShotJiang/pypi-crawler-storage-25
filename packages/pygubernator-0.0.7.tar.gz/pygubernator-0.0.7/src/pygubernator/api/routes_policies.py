"""Policy assignment and alert routes."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import func, select

from pygubernator.api.deps import AdminActor, AgentStore, CurrentActor
from pygubernator.api.models import (
    AlertRuleRequest,
    AlertRuleToggleRequest,
    PolicyAssignmentRequest,
)
from pygubernator.db.models import AlertRule, Incident, PolicyAssignment

router = APIRouter(prefix="/api/v1/policies", tags=["policies"])


@router.get("")
def get_policies(
    store: AgentStore, _: CurrentActor, agent_id: str | None = None
) -> dict:
    items = store.list_policies(agent_id)
    return {
        "items": [
            {
                "id": i.id,
                "agent_id": i.agent_id,
                "policy_type": i.policy_type,
                "policy_value": i.policy_value,
                "enabled": i.enabled,
                "created_at": i.created_at,
            }
            for i in items
        ]
    }


@router.post("")
def upsert_policy(
    payload: PolicyAssignmentRequest, store: AgentStore, actor: AdminActor
) -> dict:
    rec = PolicyAssignment(
        agent_id=payload.agent_id,
        policy_type=payload.policy_type,
        policy_value=payload.policy_value,
        enabled=payload.enabled,
    )
    store.add(rec)
    store.create_audit(
        actor=actor["actor"],
        action="policy.create",
        resource_type="policy_assignment",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return {"id": rec.id}


@router.get("/alerts")
def get_alerts(store: AgentStore, _: CurrentActor) -> dict:
    sess = store.session
    incident_counts = {
        alert_id: count
        for alert_id, count in sess.execute(
            select(Incident.alert_id, func.count(Incident.id))
            .where(Incident.alert_id.is_not(None), Incident.status != "resolved")
            .group_by(Incident.alert_id)
        ).all()
    }
    items = sess.scalars(select(AlertRule).order_by(AlertRule.created_at.desc())).all()
    return {
        "items": [
            {
                "id": i.id,
                "name": i.name,
                "severity": i.severity,
                "condition": i.condition,
                "enabled": i.enabled,
                "open_incidents": int(incident_counts.get(i.id, 0)),
                "firing": int(incident_counts.get(i.id, 0)) > 0,
            }
            for i in items
        ]
    }


@router.post("/alerts")
def create_alert(
    payload: AlertRuleRequest, store: AgentStore, actor: AdminActor
) -> dict:
    rec = AlertRule(
        name=payload.name,
        severity=payload.severity,
        condition=payload.condition,
        enabled=payload.enabled,
    )
    store.add(rec)
    store.create_audit(
        actor=actor["actor"],
        action="alert.create",
        resource_type="alert",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return {"id": rec.id}


@router.post("/alerts/{alert_id}/toggle")
def toggle_alert(
    alert_id: str,
    payload: AlertRuleToggleRequest,
    store: AgentStore,
    actor: AdminActor,
) -> dict:
    rec = store.session.get(AlertRule, alert_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Alert not found")
    rec.enabled = payload.enabled
    store.create_audit(
        actor=actor["actor"],
        action="alert.toggle",
        resource_type="alert",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return {"ok": True, "id": rec.id, "enabled": rec.enabled}


@router.get("/audit")
def get_audit_logs(
    store: AgentStore,
    _: CurrentActor,
    limit: int = Query(100, ge=1, le=500),
    resource_id: str | None = None,
    resource_type: str | None = None,
) -> dict:
    rows = store.list_audit_logs(
        limit=limit,
        resource_id=resource_id,
        resource_type=resource_type,
    )
    return {
        "items": [
            {
                "id": r.id,
                "actor": r.actor,
                "action": r.action,
                "resource_type": r.resource_type,
                "resource_id": r.resource_id,
                "details": r.details,
                "created_at": r.created_at,
            }
            for r in rows
        ]
    }


@router.get("/alerts/history")
def get_alert_history(
    store: AgentStore,
    _: CurrentActor,
    alert_id: str | None = None,
    limit: int = Query(100, ge=1, le=500),
) -> dict:
    query = (
        select(Incident)
        .where(Incident.alert_id.is_not(None))
        .order_by(Incident.created_at.desc())
    )
    if alert_id:
        query = query.where(Incident.alert_id == alert_id)
    rows = store.session.scalars(query.limit(limit)).all()
    return {
        "items": [
            {
                "id": row.id,
                "alert_id": row.alert_id,
                "title": row.title,
                "severity": row.severity,
                "status": row.status,
                "owner": row.owner,
                "created_at": row.created_at,
                "resolved_at": row.resolved_at,
            }
            for row in rows
        ]
    }
