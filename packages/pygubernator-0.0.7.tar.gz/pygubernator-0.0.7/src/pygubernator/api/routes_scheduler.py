"""Scheduler CRUD routes (admin-only)."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from pygubernator.api.deps import AdminActor, DbSession
from pygubernator.db.models import ScheduledJob

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/admin/schedules",
    tags=["scheduler"],
)


# --------------- Request / Response models ---------------


class JobCreate(BaseModel):
    """Request body for creating a scheduled job."""

    workflow_id: str = Field(..., description="Workflow to trigger")
    cron: str = Field(..., description="Cron expression")
    input_json: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True
    name: str = ""
    description: str = ""


class JobUpdate(BaseModel):
    """Request body for updating a scheduled job."""

    cron: str | None = None
    input_json: dict[str, Any] | None = None
    enabled: bool | None = None
    name: str | None = None
    description: str | None = None


class JobResponse(BaseModel):
    """Response model for a scheduled job."""

    id: str
    workflow_id: str
    name: str
    description: str
    cron_expression: str
    input_json: dict[str, Any]
    enabled: bool
    last_run_at: datetime | None
    next_run_at: datetime | None
    last_status: str
    created_by: str
    created_at: datetime
    updated_at: datetime


# --------------- Helpers ---------------


def _to_response(row: ScheduledJob) -> JobResponse:
    """Convert a DB row to a response model."""
    return JobResponse(
        id=row.id,
        workflow_id=row.workflow_id,
        name=row.name,
        description=row.description,
        cron_expression=row.cron_expression,
        input_json=row.input_json,
        enabled=row.enabled,
        last_run_at=row.last_run_at,
        next_run_at=row.next_run_at,
        last_status=row.last_status,
        created_by=row.created_by,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


def _validate_cron(expr: str) -> None:
    """Validate a cron expression or raise 422."""
    from pygubernator.scheduler._engine import (
        validate_cron,
    )

    if not validate_cron(expr):
        raise HTTPException(
            status_code=422,
            detail=f"Invalid cron expression: {expr}",
        )


# --------------- Endpoints ---------------


@router.get("")
def list_jobs(
    _admin: AdminActor,
    db: DbSession,
) -> dict:
    """List all scheduled jobs."""
    rows = db.query(ScheduledJob).all()
    items = [_to_response(r) for r in rows]
    return {
        "items": [i.model_dump(mode="json") for i in items],
    }


@router.post("", response_model=JobResponse)
def create_job(
    payload: JobCreate,
    _admin: AdminActor,
    db: DbSession,
) -> JobResponse:
    """Create a new scheduled job."""
    _validate_cron(payload.cron)

    from pygubernator.scheduler._engine import (
        compute_next_run,
    )

    row = ScheduledJob(
        workflow_id=payload.workflow_id,
        name=payload.name,
        description=payload.description,
        cron_expression=payload.cron,
        input_json=payload.input_json,
        enabled=payload.enabled,
        next_run_at=compute_next_run(payload.cron),
        created_by=str(_admin.get("actor", "system")),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    logger.info(
        "Created scheduled job %s for workflow %s",
        row.id,
        row.workflow_id,
    )
    return _to_response(row)


@router.patch(
    "/{job_id}",
    response_model=JobResponse,
)
def update_job(
    job_id: str,
    payload: JobUpdate,
    _admin: AdminActor,
    db: DbSession,
) -> JobResponse:
    """Update an existing scheduled job."""
    row = db.get(ScheduledJob, job_id)
    if not row:
        raise HTTPException(status_code=404, detail="Job not found")

    from pygubernator.scheduler._engine import (
        compute_next_run,
    )

    if payload.cron is not None:
        _validate_cron(payload.cron)
        row.cron_expression = payload.cron
        row.next_run_at = compute_next_run(payload.cron)
    if payload.input_json is not None:
        row.input_json = payload.input_json
    if payload.enabled is not None:
        row.enabled = payload.enabled
    if payload.name is not None:
        row.name = payload.name
    if payload.description is not None:
        row.description = payload.description
    db.commit()
    db.refresh(row)
    logger.info("Updated scheduled job %s", row.id)
    return _to_response(row)


@router.delete("/{job_id}")
def delete_job(
    job_id: str,
    _admin: AdminActor,
    db: DbSession,
) -> dict:
    """Delete a scheduled job."""
    row = db.get(ScheduledJob, job_id)
    if not row:
        raise HTTPException(status_code=404, detail="Job not found")
    db.delete(row)
    db.commit()
    logger.info("Deleted scheduled job %s", job_id)
    return {"ok": True, "deleted": job_id}


@router.post("/{job_id}/trigger")
def trigger_job(
    job_id: str,
    _admin: AdminActor,
    db: DbSession,
) -> dict:
    """Manually trigger a scheduled job now."""
    row = db.get(ScheduledJob, job_id)
    if not row:
        raise HTTPException(status_code=404, detail="Job not found")

    from pygubernator.agent_store.sqlalchemy import (
        SQLAlchemyAgentStore,
    )
    from pygubernator.scheduler._engine import (
        _execute_in_thread,
    )

    store = SQLAlchemyAgentStore(session=db)
    workflow = store.get_workflow(row.workflow_id)
    if workflow is None:
        raise HTTPException(
            status_code=404,
            detail="Workflow not found",
        )

    versions = store.list_workflow_versions(row.workflow_id)
    active = next((v for v in versions if v.active), None)
    if active is None:
        raise HTTPException(
            status_code=400,
            detail="No active workflow version",
        )

    run = store.create_workflow_run(
        workflow_id=row.workflow_id,
        workflow_version_id=active.id,
        input_json=dict(row.input_json or {}),
        created_by=str(_admin.get("actor", "system")),
    )
    db.commit()
    db.refresh(run)

    row.last_run_at = datetime.now(UTC)
    row.last_status = "triggered"
    db.commit()

    from pygubernator.db.session import (
        _get_session_factory,
    )

    _execute_in_thread(
        active.spec_json,
        dict(row.input_json or {}),
        run.id,
        _get_session_factory(),
    )

    logger.info(
        "Manually triggered job %s -> run %s",
        job_id,
        run.id[:12],
    )
    return {"ok": True, "run_id": run.id}
