"""Settings and connection-test routes (mirrors pycharter / pystator patterns)."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from pygubernator.api.deps import CurrentActor
from pygubernator.api.models import (
    ControlPlaneInfoResponse,
    DatabaseConfigResponse,
    DatabaseTestRequest,
    DatabaseTestResponse,
)
from pygubernator.config import ControlPlaneSettings
from pygubernator.config.database import get_database_url
from pygubernator.db.models import Workflow
from pygubernator.db.session import get_db

router = APIRouter(prefix="/api/v1/settings", tags=["settings"])


def _build_connection_string(
    connection_string: str | None = None,
    host: str | None = None,
    port: int | None = None,
    database: str | None = None,
    username: str | None = None,
    password: str | None = None,
) -> str:
    """Build database connection string from components."""
    if connection_string:
        return connection_string
    if not all([host, database]):
        raise ValueError(
            "Either connection_string or (host and database) must be provided"
        )
    if port is None:
        port = 5432
    if username and password:
        return f"postgresql://{username}:{password}@{host}:{port}/{database}"
    if username:
        return f"postgresql://{username}@{host}:{port}/{database}"
    return f"postgresql://{host}:{port}/{database}"


def _mask_database_url(url: str | None) -> str | None:
    if not url or "@" not in url:
        return url
    parts = url.split("@", 1)
    if ":" in parts[0] and "://" in parts[0]:
        user_pass = parts[0].split("://", 1)[1]
        if ":" in user_pass:
            user, _ = user_pass.split(":", 1)
            return parts[0].split("://", 1)[0] + "://" + user + ":****@" + parts[1]
    return url


@router.get(
    "/control-plane",
    response_model=ControlPlaneInfoResponse,
    summary="Listen address and public API URL from server config",
)
def get_control_plane_info(_: CurrentActor) -> ControlPlaneInfoResponse:
    """Expose bind host/port and public API URL (``pygubernator api`` config)."""
    s = ControlPlaneSettings.from_env()
    return ControlPlaneInfoResponse(
        api_host=s.api_host,
        api_port=s.api_port,
        api_url=s.api_url,
        ui_host=s.ui_host,
        ui_port=s.ui_port,
    )


@router.get(
    "/database-config",
    response_model=DatabaseConfigResponse,
    summary="Current database configuration",
)
def get_database_config_route(
    _: CurrentActor,
    db: Annotated[Session, Depends(get_db)],
) -> DatabaseConfigResponse:
    """Return which database the API is using (SQLite vs PostgreSQL, masked URL)."""
    configured_url = get_database_url()
    actual_url = (
        str(db.get_bind().url)
        if hasattr(db, "get_bind") and db.get_bind()
        else "unknown"
    )
    if actual_url.startswith("sqlite"):
        database_type = "SQLite"
        is_default = configured_url is None
    elif actual_url.startswith(("postgresql", "postgres")):
        database_type = "PostgreSQL"
        is_default = False
    else:
        database_type = "Unknown"
        is_default = False
    try:
        workflow_count = db.query(Workflow).count()
    except Exception:
        workflow_count = -1
    if is_default:
        message = (
            "No database URL configured. Using default SQLite. "
            "To use PostgreSQL, set PYGUBERNATOR_DATABASE_URL."
        )
        display_url = None
    else:
        display_url = configured_url
        if configured_url and "@" in configured_url:
            display_url = _mask_database_url(configured_url)
        message = f"Using {database_type} database"
    actual_display = actual_url.split("@")[-1] if "@" in actual_url else actual_url
    return DatabaseConfigResponse(
        configured_url=display_url,
        actual_url=actual_display,
        database_type=database_type,
        is_default=is_default,
        workflow_count=workflow_count,
        message=message,
    )


@router.post(
    "/test-database",
    response_model=DatabaseTestResponse,
    summary="Test an arbitrary database connection",
)
def test_database_route(
    request: DatabaseTestRequest,
    _: CurrentActor,
) -> DatabaseTestResponse:
    """Test a database connection (for Postgres or other URL built from fields)."""
    try:
        connection_string = _build_connection_string(
            connection_string=request.connection_string,
            host=request.host,
            port=request.port,
            database=request.database,
            username=request.username,
            password=request.password,
        )
        engine = create_engine(connection_string, pool_pre_ping=True)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return DatabaseTestResponse(
            success=True, message="Database connection successful"
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e
    except SQLAlchemyError as e:
        return DatabaseTestResponse(
            success=False, message=f"Database connection failed: {e!s}"
        )
    except Exception as e:
        return DatabaseTestResponse(success=False, message=f"Unexpected error: {e!s}")
