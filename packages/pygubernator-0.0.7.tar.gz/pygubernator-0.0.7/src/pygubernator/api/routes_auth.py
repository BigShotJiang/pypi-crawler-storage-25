"""Authentication routes backed by cfg/env users."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

from pygubernator.api.deps import (
    ACCESS_TOKEN_EXPIRE_SECONDS,
    CurrentActor,
    create_access_token,
    verify_credentials,
)
from pygubernator.config import get_auth_jwt_secret, get_auth_users, is_auth_disabled

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str
    password: str


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = ACCESS_TOKEN_EXPIRE_SECONDS
    role: str = "User"


class UserResponse(BaseModel):
    username: str
    role: str = "User"
    auth_disabled: bool = False


@router.post("/login")
def login(payload: LoginRequest) -> LoginResponse:
    if is_auth_disabled():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Authentication is disabled",
        )
    if not get_auth_users():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Authentication not configured (set credentials or auth service)",
        )
    if not get_auth_jwt_secret():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "JWT secret not configured "
                "(set PYGUBERNATOR_AUTH_JWT_SECRET in env or pygubernator.cfg [auth])"
            ),
        )

    matched = verify_credentials(payload.username, payload.password)
    if not matched:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    token = create_access_token(matched["username"], role=matched["role"])
    return LoginResponse(
        access_token=token,
        token_type="bearer",
        expires_in=ACCESS_TOKEN_EXPIRE_SECONDS,
        role=matched["role"],
    )


@router.post("/logout")
def logout() -> dict[str, str]:
    return {"message": "OK"}


@router.get("/me")
def me(current_user: CurrentActor) -> UserResponse:
    return UserResponse(
        username=str(current_user["actor"]),
        role=str(current_user.get("role", "User")),
        auth_disabled=bool(current_user.get("auth_disabled", False)),
    )
