"""FastAPI app for pygubernator control plane."""

from __future__ import annotations

import logging
import os
from pathlib import Path

import uvicorn
from fastapi import Depends, FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from pygubernator.api._rate_limit import RateLimitMiddleware
from pygubernator.api.deps import AdminActor, get_current_actor
from pygubernator.api.routes_agents import router as agents_router
from pygubernator.api.routes_auth import router as auth_router
from pygubernator.api.routes_chat import router as chat_router
from pygubernator.api.routes_credentials import router as credentials_router
from pygubernator.api.routes_events import router as events_router
from pygubernator.api.routes_llm import router as llm_router
from pygubernator.api.routes_notifications import (
    router as notifications_router,
)
from pygubernator.api.routes_observability import router as observability_router
from pygubernator.api.routes_policies import router as policies_router
from pygubernator.api.routes_runs import router as runs_router
from pygubernator.api.routes_scheduler import router as scheduler_router
from pygubernator.api.routes_settings import router as settings_router
from pygubernator.api.routes_webhooks import (
    admin_router as webhooks_admin_router,
)
from pygubernator.api.routes_webhooks import (
    trigger_router as webhooks_trigger_router,
)
from pygubernator.api.routes_workflows import router as workflows_router
from pygubernator.config import ControlPlaneSettings, get_ui_app_name, get_ui_theme
from pygubernator.db.config import get_db_url
from pygubernator.db.retention import purge_old_events
from pygubernator.db.session import get_db, init_db

logger = logging.getLogger(__name__)


def create_app() -> FastAPI:
    settings = ControlPlaneSettings.from_env()
    app = FastAPI(title="PyGubernator Control Plane API", version="0.1.0")
    cors_origins = [o.strip() for o in settings.allow_origins.split(",") if o.strip()]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(
        RateLimitMiddleware,
        max_requests=200,
        window_seconds=60.0,
    )
    app.include_router(auth_router)
    protected_dependencies = [Depends(get_current_actor)]
    app.include_router(agents_router, dependencies=protected_dependencies)
    app.include_router(runs_router, dependencies=protected_dependencies)
    app.include_router(observability_router, dependencies=protected_dependencies)
    app.include_router(policies_router, dependencies=protected_dependencies)
    app.include_router(workflows_router, dependencies=protected_dependencies)
    app.include_router(llm_router, dependencies=protected_dependencies)
    app.include_router(credentials_router, dependencies=protected_dependencies)
    app.include_router(chat_router, dependencies=protected_dependencies)
    app.include_router(notifications_router, dependencies=protected_dependencies)
    app.include_router(webhooks_admin_router, dependencies=protected_dependencies)
    app.include_router(scheduler_router, dependencies=protected_dependencies)
    app.include_router(settings_router, dependencies=protected_dependencies)
    app.include_router(webhooks_trigger_router)  # No auth — token in URL
    app.include_router(events_router)  # No auth — SSE via EventSource

    # --- Exception handlers (matching pystator pattern) ---

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        errors = []
        for err in exc.errors():
            loc = " -> ".join(str(item) for item in err.get("loc", []))
            errors.append({"field": loc, "message": err.get("msg", "")})
        return JSONResponse(
            status_code=422,
            content={"error": "Validation error", "details": errors},
        )

    @app.exception_handler(Exception)
    async def global_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        logger.error(
            "[GLOBAL] Unhandled %s on %s %s: %s",
            type(exc).__name__,
            request.method,
            request.url.path,
            exc,
            exc_info=True,
        )
        # Always include detail so errors are diagnosable
        content: dict[str, str] = {
            "error": "Internal server error",
            "detail": f"{type(exc).__name__}: {exc}",
        }
        return JSONResponse(status_code=500, content=content)

    @app.on_event("startup")
    def _init_change_bus() -> None:
        from pygubernator.events import ChangeBus

        app.state.change_bus = ChangeBus()

    @app.on_event("startup")
    def _startup() -> None:
        # Auto-init SQLite only if the file doesn't exist yet.
        db_url = get_db_url(required=False)
        if db_url and db_url.startswith("sqlite:///"):
            from pathlib import Path

            db_path = db_url[10:]
            if db_path != ":memory:" and not Path(db_path).exists():
                init_db(db_url)

    @app.on_event("startup")
    def _start_scheduler() -> None:
        try:
            from pygubernator.db.session import SessionLocal
            from pygubernator.scheduler._engine import Scheduler

            scheduler = Scheduler(db_session_factory=SessionLocal)
            scheduler.start()
            app.state.scheduler = scheduler
        except Exception:
            logger.warning("Scheduler start failed", exc_info=True)

    @app.on_event("startup")
    def _start_stale_run_reaper() -> None:
        """Mark stuck 'running' workflow runs as failed."""
        import threading

        def _reap_loop() -> None:
            import time as _time

            while True:
                _time.sleep(120)  # check every 2 min
                try:
                    _reap_stale_runs()
                except Exception:
                    logger.debug(
                        "Stale run reaper error",
                        exc_info=True,
                    )

        def _reap_stale_runs() -> None:
            from sqlalchemy import text

            db = next(get_db())
            try:
                cutoff = _WORKFLOW_TIMEOUT + 60  # grace
                db.execute(
                    text(
                        "UPDATE workflow_runs "
                        "SET status = 'failed', "
                        "error_message = 'Timed out (reaped)' "
                        "WHERE status = 'running' "
                        "AND started_at < datetime('now', :cutoff)"
                    ),
                    {"cutoff": f"-{int(cutoff)} seconds"},
                )
                db.commit()
            finally:
                db.close()

        _WORKFLOW_TIMEOUT = float(os.getenv("PYGUBERNATOR_WORKFLOW_TIMEOUT", "600"))
        thread = threading.Thread(
            target=_reap_loop,
            daemon=True,
            name="stale-run-reaper",
        )
        thread.start()

    @app.post("/api/v1/admin/retention")
    def run_retention(_admin: AdminActor) -> dict:
        db = next(get_db())
        try:
            result = purge_old_events(db, settings.event_retention_days)
        finally:
            db.close()
        return {"ok": True, **result}

    @app.get("/healthz")
    def healthz() -> dict:
        return {"status": "ok"}

    @app.get("/health")
    def health() -> dict:
        """Alias for ``/healthz`` (matches pycharter / pystator clients)."""
        return {"status": "ok"}

    @app.get("/api/v1/ui/config")
    def ui_config() -> dict:
        # Theme/name from cfg/env each request (not the import-time settings snapshot).
        return {
            "theme": get_ui_theme(),
            "app_name": get_ui_app_name(),
        }

    return app


app = create_app()


def _package_root() -> Path:
    """Return the pygubernator package directory (installed or editable)."""
    try:
        import pygubernator as _pkg

        return Path(_pkg.__file__).resolve().parent
    except ImportError:
        return Path(__file__).resolve().parent.parent


def _reload_dirs_excluding_ui() -> list[str]:
    """Dirs for uvicorn reload (exclude ui/ to avoid node_modules inotify limits)."""
    pkg_root = _package_root()
    return [
        str(d)
        for d in sorted(pkg_root.iterdir())
        if d.is_dir()
        and d.name != "ui"
        and not d.name.startswith("__")
        and not d.name.startswith(".")
    ]


def run_api(
    *,
    host: str | None = None,
    port: int | None = None,
    reload: bool = False,
) -> None:
    """Run the control-plane API with uvicorn (CLI / ``python -m`` entry)."""
    settings = ControlPlaneSettings.from_env()
    h = host if host is not None else settings.api_host
    p = port if port is not None else settings.api_port

    run_kw: dict[str, object] = {
        "host": h,
        "port": p,
        "reload": reload,
        "log_level": "info",
    }
    if reload:
        run_kw["reload_dirs"] = _reload_dirs_excluding_ui()

    uvicorn.run("pygubernator.api.main:app", **run_kw)


def serve_api() -> None:
    """Default production-style serve (config from env / .cfg only, no reload)."""
    settings = ControlPlaneSettings.from_env()
    run_api(host=settings.api_host, port=settings.api_port, reload=False)


if __name__ == "__main__":
    serve_api()
