"""Agent management routes."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from pygubernator.api.deps import AdminActor, AgentStore, CurrentActor
from pygubernator.api.models import (
    AgentCreateRequest,
    AgentDashboardOut,
    AgentOut,
    AgentUpdateRequest,
    AgentVersionCreateRequest,
    AgentVersionOut,
    PageMeta,
    RunEnqueueRequest,
    RunOut,
)
from pygubernator.db.models import AgentVersion

router = APIRouter(prefix="/api/v1/agents", tags=["agents"])


@router.get("")
def get_agents(
    store: AgentStore,
    _: CurrentActor,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    q: str | None = None,
) -> dict:
    items, total = store.list_agents(page=page, page_size=page_size)
    if q:
        ql = q.lower()
        items = [i for i in items if ql in i.name.lower() or ql in i.owner.lower()]
    return {
        "items": [AgentOut.model_validate(a).model_dump() for a in items],
        "meta": PageMeta(total=total, page=page, page_size=page_size).model_dump(),
    }


@router.post("", response_model=AgentOut)
def create_agent(
    payload: AgentCreateRequest, store: AgentStore, actor: AdminActor
) -> AgentOut:
    rec = store.create_agent(
        name=payload.name, owner=payload.owner, status=payload.status
    )
    store.create_audit(
        actor=actor["actor"],
        action="agent.create",
        resource_type="agent",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return AgentOut.model_validate(rec)


@router.get("/{agent_id}/dashboard", response_model=AgentDashboardOut)
def get_agent_dashboard(
    agent_id: str, store: AgentStore, _: CurrentActor
) -> AgentDashboardOut:
    """Return agent metadata and all versions in one round-trip."""
    rec = store.get_agent(agent_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Agent not found")
    versions = store.list_agent_versions(agent_id)
    return AgentDashboardOut(
        agent=AgentOut.model_validate(rec),
        versions=[AgentVersionOut.model_validate(v) for v in versions],
    )


@router.post("/{agent_id}/runs", response_model=RunOut)
def enqueue_run_for_agent(
    agent_id: str,
    payload: RunEnqueueRequest,
    store: AgentStore,
    actor: CurrentActor,
) -> RunOut:
    """Create a queued run for this agent (``agent_id`` is implicit from the path)."""
    agent = store.get_agent(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    if payload.agent_version_id:
        version = store.session.get(AgentVersion, payload.agent_version_id)
        if not version or version.agent_id != agent_id:
            raise HTTPException(
                status_code=404,
                detail="Agent version not found or does not belong to agent",
            )
    run = store.create_run(
        agent_id=agent_id,
        agent_version_id=payload.agent_version_id,
        status="queued",
        correlation_id=payload.correlation_id,
        trigger=payload.trigger,
        metadata_json=payload.metadata_json,
    )
    store.create_audit(
        actor=actor["actor"],
        action="run.create",
        resource_type="run",
        resource_id=run.id,
        details={**payload.model_dump(), "agent_id": agent_id},
    )
    store.commit()
    store.refresh(run)
    return RunOut.model_validate(run)


@router.delete("/{agent_id}", response_model=AgentOut)
def delete_agent_route(
    agent_id: str,
    store: AgentStore,
    actor: AdminActor,
) -> AgentOut:
    """Soft-delete an agent by setting archived to True."""
    rec = store.get_agent(agent_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Agent not found")
    rec.archived = True
    store.create_audit(
        actor=actor["actor"],
        action="agent.delete",
        resource_type="agent",
        resource_id=agent_id,
        details={"archived": True},
    )
    store.commit()
    store.refresh(rec)
    return AgentOut.model_validate(rec)


@router.get("/{agent_id}", response_model=AgentOut)
def get_agent_detail(agent_id: str, store: AgentStore, _: CurrentActor) -> AgentOut:
    rec = store.get_agent(agent_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Agent not found")
    return AgentOut.model_validate(rec)


@router.patch("/{agent_id}", response_model=AgentOut)
def update_agent(
    agent_id: str,
    payload: AgentUpdateRequest,
    store: AgentStore,
    actor: AdminActor,
) -> AgentOut:
    rec = store.get_agent(agent_id)
    if not rec:
        raise HTTPException(status_code=404, detail="Agent not found")
    if payload.status is not None:
        rec.status = payload.status
    if payload.archived is not None:
        rec.archived = payload.archived
    store.create_audit(
        actor=actor["actor"],
        action="agent.update",
        resource_type="agent",
        resource_id=agent_id,
        details=payload.model_dump(exclude_none=True),
    )
    store.commit()
    store.refresh(rec)
    return AgentOut.model_validate(rec)


@router.get("/{agent_id}/versions")
def get_agent_versions(agent_id: str, store: AgentStore, _: CurrentActor) -> dict:
    versions = store.list_agent_versions(agent_id)
    return {"items": [AgentVersionOut.model_validate(v).model_dump() for v in versions]}


@router.post("/{agent_id}/versions", response_model=AgentVersionOut)
def create_agent_version(
    agent_id: str,
    payload: AgentVersionCreateRequest,
    store: AgentStore,
    actor: AdminActor,
) -> AgentVersionOut:
    if not store.get_agent(agent_id):
        raise HTTPException(status_code=404, detail="Agent not found")
    config = payload.config
    if payload.provider:
        config = {**config, "provider": payload.provider.model_dump()}
    rec = store.create_agent_version(
        agent_id=agent_id,
        version=payload.version,
        model=payload.model,
        prompt=payload.prompt,
        tools=payload.tools,
        config=config,
    )
    store.create_audit(
        actor=actor["actor"],
        action="agent.version.create",
        resource_type="agent_version",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return AgentVersionOut.model_validate(rec)


@router.post("/{agent_id}/versions/{version_id}/activate", response_model=AgentOut)
def activate_version(
    agent_id: str, version_id: str, store: AgentStore, actor: AdminActor
) -> AgentOut:
    agent = store.get_agent(agent_id)
    version = store.get_agent_version(version_id)
    if not agent or not version or version.agent_id != agent_id:
        raise HTTPException(status_code=404, detail="Agent/version not found")
    store.activate_agent_version(agent, version_id)
    store.create_audit(
        actor=actor["actor"],
        action="agent.version.activate",
        resource_type="agent",
        resource_id=agent_id,
        details={"version_id": version_id},
    )
    store.commit()
    store.refresh(agent)
    return AgentOut.model_validate(agent)
