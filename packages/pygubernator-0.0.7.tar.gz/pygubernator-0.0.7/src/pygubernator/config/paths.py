"""Path resolution for pygubernator config files."""

from __future__ import annotations

from pathlib import Path

_CONFIG_FILENAME = "pygubernator.cfg"
_MAX_PARENT_WALK = 6


def find_config_file(filename: str = _CONFIG_FILENAME) -> Path | None:
    """Locate config file by standard search order."""
    cwd_path = Path.cwd() / filename
    if cwd_path.exists():
        return cwd_path

    home_path = Path.home() / ".pygubernator" / filename
    if home_path.exists():
        return home_path

    try:
        import pygubernator

        start = Path(pygubernator.__file__).resolve().parent
        for _ in range(10):
            cand = start / filename
            if cand.exists():
                return cand
            parent = start.parent
            if parent == start:
                break
            start = parent
    except (ImportError, AttributeError):
        pass

    current = Path.cwd()
    for _ in range(_MAX_PARENT_WALK):
        if (current / "alembic.ini").exists():
            cfg = current / filename
            if cfg.exists():
                return cfg
        current = current.parent
    return None
