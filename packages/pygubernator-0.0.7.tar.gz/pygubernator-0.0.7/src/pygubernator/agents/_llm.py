"""LLM agent: think-act-observe-decide loop."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import unittest.mock as unittest_mock
from collections.abc import AsyncIterator
from typing import Any

from pystator import StateMachine

from pygubernator._events import AgentEventType, EventBus
from pygubernator._protocols import LLMProvider, StreamingLLMProvider
from pygubernator._types import AgentResult, Message, ToolResult
from pygubernator.agents._base import BaseAgent
from pygubernator.agents._hooks import HookRegistry
from pygubernator.agents._machines import llm_lifecycle_config
from pygubernator.agents._validation import validate_tool_args
from pygubernator.llm._messages import (
    LLMResponse,
    StreamChunk,
    ToolCall,
    ToolCallDelta,
)
from pygubernator.tools._registry import ToolRegistry

logger = logging.getLogger(__name__)

# Default limits
_DEFAULT_TOOL_TIMEOUT = 30.0
_DEFAULT_MAX_TOOL_OUTPUT = 10_000


class LLMAgent(BaseAgent):
    """Agent that uses an LLM with tool calling.

    Implements the think -> act -> observe -> decide loop. The LLM
    generates responses, optionally calling tools. Tool results are
    fed back to the LLM until it produces a final response.

    Args:
        agent_id: Unique identifier.
        llm_provider: LLM provider implementing the LLMProvider
            protocol.
        tool_registry: Registry of available tools.
        system_prompt: System prompt for the LLM.
        max_iterations: Maximum think-act-observe iterations.
        lifecycle_machine: Optional lifecycle machine override.
        context: Optional initial context.
        event_bus: Optional event bus for emitting events.
        run_id: Optional run identifier for correlating events.
        hooks: Optional hook registry for lifecycle hooks.
        tool_timeout: Per-tool execution timeout in seconds.
        max_tool_output_chars: Truncate tool output beyond this.
    """

    def __init__(
        self,
        agent_id: str,
        llm_provider: LLMProvider,
        tool_registry: ToolRegistry | None = None,
        system_prompt: str = "",
        max_iterations: int = 10,
        lifecycle_machine: StateMachine | None = None,
        context: dict[str, Any] | None = None,
        event_bus: EventBus | None = None,
        run_id: str | None = None,
        hooks: HookRegistry | None = None,
        tool_timeout: float = _DEFAULT_TOOL_TIMEOUT,
        max_tool_output_chars: int = _DEFAULT_MAX_TOOL_OUTPUT,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            machine=lifecycle_machine,
            context=context,
            event_bus=event_bus,
            run_id=run_id,
        )
        self._llm = llm_provider
        self._tools = tool_registry
        self._system_prompt = system_prompt
        self._max_iterations = max_iterations
        self._hooks = hooks
        self._tool_timeout = tool_timeout
        self._max_tool_output = max_tool_output_chars
        self._llm_machine = StateMachine.from_dict(
            llm_lifecycle_config(max_iterations),
        )

    async def process(
        self,
        message: Message,
        history: list[dict[str, Any]] | None = None,
        output_schema: dict[str, Any] | None = None,
    ) -> AgentResult:
        """Process a message through the LLM loop.

        Args:
            message: The input message.
            history: Optional conversation history to prepend
                before the user message.
            output_schema: Optional JSON Schema to validate the
                final LLM output against.

        Returns:
            Result with LLM response and tool call details.
        """
        llm_session = self._llm_machine.create()
        llm_session.send("start")

        messages, tool_schemas = await self._prepare_messages(message, history)
        iterations = 0
        all_tool_results: list[dict[str, Any]] = []
        final_content = ""

        try:
            for iteration in range(self._max_iterations):
                iterations = iteration + 1
                messages, tool_schemas = await self._run_before_llm_hooks(
                    messages, tool_schemas, iterations
                )
                response = await self._call_llm(messages, tool_schemas, iterations)
                response = await self._run_after_llm_hooks(
                    messages, response, iterations
                )
                await self._emit_llm_response(response, iterations)

                if not response.has_tool_calls:
                    llm_session.send("no_tools")
                    final_content = response.content
                    break

                llm_session.send("thought")
                messages.append(_assistant_tool_msg(response))

                results = await self._execute_tools_parallel(
                    response.tool_calls,
                )
                for tc, result in zip(
                    response.tool_calls,
                    results,
                    strict=True,
                ):
                    all_tool_results.append(result.to_dict())
                    content = self._truncate_output(result)
                    messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": content,
                        },
                    )

                llm_session.send("acted")
                llm_session.send("observed")
                llm_session.send("continue")

            else:
                if iterations > 0:
                    final_content = response.content  # type: ignore[possibly-undefined]
                llm_session.send("finish")
                logger.warning(
                    "Agent %s stopped: max iterations (%d) reached",
                    self._agent_id,
                    self._max_iterations,
                )
                return self._build_result(
                    iterations,
                    final_content,
                    all_tool_results,
                    llm_session.current_state,
                    stopped_reason="max_iterations",
                    output_schema=output_schema,
                )

        except Exception as exc:
            return self._handle_loop_error(exc, iterations, llm_session)

        return self._build_result(
            iterations,
            final_content,
            all_tool_results,
            llm_session.current_state,
            output_schema=output_schema,
        )

    # ------------------------------------------------------------------
    # Parallel tool execution
    # ------------------------------------------------------------------

    async def _execute_tools_parallel(
        self,
        tool_calls: tuple[ToolCall, ...],
    ) -> list[ToolResult]:
        """Execute tool calls in parallel.

        Args:
            tool_calls: Tool calls from the LLM response.

        Returns:
            List of ToolResult in the same order as the input.
        """
        tasks: list[asyncio.Task[ToolResult]] = []
        for tc in tool_calls:
            tasks.append(asyncio.ensure_future(self._execute_single_tool(tc)))
        raw_results = await asyncio.gather(*tasks, return_exceptions=True)

        results: list[ToolResult] = []
        for tc, raw in zip(tool_calls, raw_results, strict=True):
            if isinstance(raw, Exception):
                raw = ToolResult(
                    tool_name=tc.name,
                    success=False,
                    error=str(raw),
                )
            results.append(raw)
        return results

    async def _execute_single_tool(self, tc: ToolCall) -> ToolResult:
        """Execute one tool call with hooks and validation.

        Handles before/after hooks, argument parsing,
        validation, timeout, and schema-enriched errors.

        Args:
            tc: The tool call to execute.

        Returns:
            The execution result.
        """
        tc_name = tc.name
        tc_args = self._parse_tool_args(tc)
        if isinstance(tc_args, ToolResult):
            return tc_args  # Parse error

        tc_name, tc_args = await self._run_before_tool_hook(tc_name, tc_args, tc.id)
        await self._emit(
            AgentEventType.TOOL_CALL_STARTED,
            {"tool_name": tc_name, "input": tc_args},
        )

        result = await self._run_tool_with_validation(tc_name, tc_args)

        result = await self._run_after_tool_hook(tc_name, tc_args, result, tc.id)
        result = self._enrich_error_context(tc_name, result)

        evt = (
            AgentEventType.TOOL_CALL_COMPLETED
            if result.success
            else AgentEventType.TOOL_CALL_FAILED
        )
        await self._emit(
            evt,
            {
                "tool_name": tc_name,
                "success": result.success,
                "error": result.error,
            },
        )
        return result

    def _parse_tool_args(self, tc: ToolCall) -> dict[str, Any] | ToolResult:
        """Safely parse tool call arguments.

        Args:
            tc: The tool call whose arguments to parse.

        Returns:
            Parsed dict or a ToolResult with the parse error.
        """
        try:
            if isinstance(tc.arguments, dict):
                return tc.arguments
            return json.loads(str(tc.arguments))
        except (json.JSONDecodeError, TypeError) as err:
            return ToolResult(
                tool_name=tc.name,
                success=False,
                error=(f"Failed to parse tool arguments: {err}. Raw: {tc.arguments!r}"),
            )

    async def _run_tool_with_validation(
        self,
        name: str,
        args: dict[str, Any],
    ) -> ToolResult:
        """Validate args then execute with timeout.

        Args:
            name: Tool name.
            args: Tool arguments.

        Returns:
            The tool result.
        """
        if not self._tools or not self._tools.has(name):
            return ToolResult(
                tool_name=name,
                success=False,
                output=None,
                error=f"Tool '{name}' not found",
            )

        tool_obj = self._tools.get(name)
        errors = validate_tool_args(args, tool_obj.parameters_schema, name)
        if errors:
            schema = tool_obj.parameters_schema
            return ToolResult(
                tool_name=name,
                success=False,
                error=(
                    f"Invalid arguments: {'; '.join(errors)}. Expected schema: {schema}"
                ),
            )

        try:
            return await asyncio.wait_for(
                self._tools.execute(name, args),
                timeout=self._tool_timeout,
            )
        except TimeoutError:
            return ToolResult(
                tool_name=name,
                success=False,
                error=(f"Tool '{name}' timed out after {self._tool_timeout}s"),
            )

    # ------------------------------------------------------------------
    # Output helpers
    # ------------------------------------------------------------------

    def _truncate_output(self, result: ToolResult) -> str:
        """Build tool message content, truncating if needed.

        Args:
            result: The tool result.

        Returns:
            Content string for the tool message.
        """
        raw = str(result.output) if result.success else str(result.error)
        if len(raw) > self._max_tool_output:
            return (
                raw[: self._max_tool_output]
                + f"\n... (truncated, {len(raw)} chars total)"
            )
        return raw

    def _enrich_error_context(self, name: str, result: ToolResult) -> ToolResult:
        """Add schema hint to failed tool results.

        Args:
            name: Tool name.
            result: The tool result.

        Returns:
            Possibly enriched ToolResult.
        """
        if result.success:
            return result
        if not self._tools or not self._tools.has(name):
            return result
        tool_obj = self._tools.get(name)
        schema_hint = json.dumps(tool_obj.parameters_schema, indent=2)
        return ToolResult(
            tool_name=result.tool_name,
            success=False,
            output=result.output,
            error=(f"{result.error}\n\nExpected parameters schema:\n{schema_hint}"),
        )

    def _build_result(
        self,
        iterations: int,
        final_content: str,
        tool_results: list[dict[str, Any]],
        llm_state: str,
        stopped_reason: str | None = None,
        output_schema: dict[str, Any] | None = None,
    ) -> AgentResult:
        """Build the final AgentResult.

        Args:
            iterations: Number of completed iterations.
            final_content: Final LLM response text.
            tool_results: Accumulated tool result dicts.
            llm_state: Current LLM state machine state.
            stopped_reason: Reason the loop stopped, if not
                natural completion.
            output_schema: Optional schema for output validation.

        Returns:
            The AgentResult.
        """
        metadata: dict[str, Any] = {
            "iterations": iterations,
            "response": final_content,
            "tool_results": tool_results,
            "llm_state": llm_state,
        }
        if stopped_reason:
            metadata["stopped_reason"] = stopped_reason

        if output_schema and final_content:
            metadata["output_validation_errors"] = _validate_output(
                final_content, output_schema
            )

        return AgentResult(
            agent_id=self._agent_id,
            success=True,
            messages_processed=1,
            errors=[],
            metadata=metadata,
        )

    def _handle_loop_error(
        self,
        exc: Exception,
        iterations: int,
        llm_session: Any,
    ) -> AgentResult:
        """Handle an exception from the main loop.

        Args:
            exc: The exception that was raised.
            iterations: Iterations completed before failure.
            llm_session: The LLM lifecycle session.

        Returns:
            A failure AgentResult.
        """
        err_msg = str(exc).strip() or repr(exc)
        logger.error(
            "LLMAgent %s failed: %s",
            self._agent_id,
            err_msg,
        )
        with contextlib.suppress(Exception):
            llm_session.send("fail")
        return AgentResult(
            agent_id=self._agent_id,
            success=False,
            messages_processed=0,
            errors=[err_msg],
            metadata={
                "iterations": iterations,
                "llm_state": llm_session.current_state,
            },
        )

    # ------------------------------------------------------------------
    # Hook helpers
    # ------------------------------------------------------------------

    async def _prepare_messages(
        self,
        message: Message,
        history: list[dict[str, Any]] | None,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]] | None]:
        """Build messages with BEFORE_PROMPT_BUILD hook.

        Args:
            message: The input message.
            history: Optional conversation history.

        Returns:
            Tuple of (messages, tool_schemas).
        """
        _sys_prompt = self._system_prompt
        _history = history
        _user_msg = str(
            message.payload.get("content", message.payload),
        )

        if self._hooks:
            from pygubernator.agents._hooks import (
                BeforePromptBuildContext,
                HookPoint,
            )

            ctx = BeforePromptBuildContext(
                system_prompt=_sys_prompt,
                history=_history,
                user_message=_user_msg,
            )
            ctx = await self._hooks.run(HookPoint.BEFORE_PROMPT_BUILD, ctx)
            _sys_prompt = ctx.system_prompt
            _history = ctx.history
            _user_msg = ctx.user_message

        messages: list[dict[str, Any]] = []
        if _sys_prompt:
            messages.append(
                {"role": "system", "content": _sys_prompt},
            )
        if _history:
            messages.extend(_history)
        messages.append(
            {"role": "user", "content": _user_msg},
        )
        tool_schemas = self._tools.get_schemas() if self._tools else None
        return messages, tool_schemas

    async def _run_before_llm_hooks(
        self,
        messages: list[dict[str, Any]],
        tool_schemas: list[dict[str, Any]] | None,
        iterations: int,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]] | None]:
        """Run BEFORE_LLM_CALL hooks."""
        if not self._hooks:
            return messages, tool_schemas
        from pygubernator.agents._hooks import (
            BeforeLLMCallContext,
            HookPoint,
        )

        ctx = BeforeLLMCallContext(
            messages=messages,
            tools=tool_schemas,
            iteration=iterations,
        )
        ctx = await self._hooks.run(HookPoint.BEFORE_LLM_CALL, ctx)
        return ctx.messages, ctx.tools

    async def _call_llm(
        self,
        messages: list[dict[str, Any]],
        tool_schemas: list[dict[str, Any]] | None,
        iterations: int,
    ) -> LLMResponse:
        """Call the LLM and emit request event."""
        await self._emit(
            AgentEventType.LLM_REQUEST_STARTED,
            {"iteration": iterations},
        )
        return await self._llm.chat(messages, tools=tool_schemas)

    async def _run_after_llm_hooks(
        self,
        messages: list[dict[str, Any]],
        response: LLMResponse,
        iterations: int,
    ) -> LLMResponse:
        """Run AFTER_LLM_CALL hooks."""
        if not self._hooks:
            return response
        from pygubernator.agents._hooks import (
            AfterLLMCallContext,
            HookPoint,
        )

        ctx = AfterLLMCallContext(
            messages=messages,
            response=response,
            iteration=iterations,
        )
        ctx = await self._hooks.run(HookPoint.AFTER_LLM_CALL, ctx)
        return ctx.response

    async def _emit_llm_response(self, response: LLMResponse, iterations: int) -> None:
        """Emit LLM_RESPONSE_RECEIVED event."""
        await self._emit(
            AgentEventType.LLM_RESPONSE_RECEIVED,
            {
                "iteration": iterations,
                "has_tool_calls": response.has_tool_calls,
                "finish_reason": response.finish_reason,
            },
        )

    async def _run_before_tool_hook(
        self,
        name: str,
        args: dict[str, Any],
        call_id: str,
    ) -> tuple[str, dict[str, Any]]:
        """Run BEFORE_TOOL_CALL hook."""
        if not self._hooks:
            return name, args
        from pygubernator.agents._hooks import (
            BeforeToolCallContext,
            HookPoint,
        )

        ctx = BeforeToolCallContext(
            tool_name=name,
            arguments=args,
            tool_call_id=call_id,
        )
        ctx = await self._hooks.run(HookPoint.BEFORE_TOOL_CALL, ctx)
        return ctx.tool_name, ctx.arguments

    async def _run_after_tool_hook(
        self,
        name: str,
        args: dict[str, Any],
        result: ToolResult,
        call_id: str,
    ) -> ToolResult:
        """Run AFTER_TOOL_CALL hook."""
        if not self._hooks:
            return result
        from pygubernator.agents._hooks import (
            AfterToolCallContext,
            HookPoint,
        )

        ctx = AfterToolCallContext(
            tool_name=name,
            arguments=args,
            result=result,
            tool_call_id=call_id,
        )
        ctx = await self._hooks.run(HookPoint.AFTER_TOOL_CALL, ctx)
        return ctx.result

    # ------------------------------------------------------------------
    # Streaming
    # ------------------------------------------------------------------

    def _streaming_provider_usable(self) -> bool:
        """Whether ``chat_stream`` should be used (vs ``process`` fallback).

        ``unittest.mock`` instances structurally satisfy
        ``StreamingLLMProvider`` at runtime but are not real stream
        sources; they must use the non-streaming path.
        """
        if isinstance(self._llm, unittest_mock.Mock):
            return False
        return isinstance(self._llm, StreamingLLMProvider)

    async def process_stream(
        self,
        message: Message,
        history: list[dict[str, Any]] | None = None,
    ) -> AsyncIterator[StreamChunk | AgentResult]:
        """Stream LLM responses, yielding chunks then a result.

        Mirrors ``process()`` but yields ``StreamChunk`` objects
        for each token. Tool-calling iterations yield chunks,
        execute tools, then resume streaming.

        Args:
            message: The input message.
            history: Optional conversation history.

        Yields:
            StreamChunk for each token, then AgentResult.
        """
        if not self._streaming_provider_usable():
            result = await self.process(message, history=history)
            yield result
            return

        messages = self._build_messages(message, history)
        tool_schemas = self._tools.get_schemas() if self._tools else None
        iterations = 0
        all_tool_results: list[dict[str, Any]] = []
        final_content = ""

        try:
            async for chunk_or_result in self._stream_loop(
                messages,
                tool_schemas,
                all_tool_results,
            ):
                if isinstance(chunk_or_result, StreamChunk):
                    iterations = chunk_or_result.usage.get(
                        "_iteration",
                        iterations,
                    )
                    if chunk_or_result.delta_content:
                        final_content += chunk_or_result.delta_content
                    yield chunk_or_result
                else:
                    iterations = chunk_or_result
        except Exception as exc:
            err_msg = str(exc).strip() or repr(exc)
            logger.error(
                "LLMAgent %s stream failed: %s",
                self._agent_id,
                err_msg,
            )
            yield AgentResult(
                agent_id=self._agent_id,
                success=False,
                messages_processed=0,
                errors=[err_msg],
                metadata={"iterations": iterations},
            )
            return

        yield AgentResult(
            agent_id=self._agent_id,
            success=True,
            messages_processed=1,
            errors=[],
            metadata={
                "iterations": iterations,
                "response": final_content,
                "tool_results": all_tool_results,
            },
        )

    def _build_messages(
        self,
        message: Message,
        history: list[dict[str, Any]] | None,
    ) -> list[dict[str, Any]]:
        """Build the initial message list for an LLM call.

        Args:
            message: The input message.
            history: Optional conversation history.

        Returns:
            List of message dicts ready for the LLM.
        """
        user_msg = str(
            message.payload.get("content", message.payload),
        )
        messages: list[dict[str, Any]] = []
        if self._system_prompt:
            messages.append({"role": "system", "content": self._system_prompt})
        if history:
            messages.extend(history)
        messages.append({"role": "user", "content": user_msg})
        return messages

    async def _stream_loop(
        self,
        messages: list[dict[str, Any]],
        tool_schemas: list[dict[str, Any]] | None,
        all_tool_results: list[dict[str, Any]],
    ) -> AsyncIterator[StreamChunk | int]:
        """Run the streaming think-act-observe loop.

        Yields StreamChunk objects for each token and an int
        (iteration count) as the final value.

        Args:
            messages: Conversation messages (mutated in place).
            tool_schemas: Tool schemas for the LLM.
            all_tool_results: Accumulator for tool results.

        Yields:
            StreamChunk for tokens, then final iteration count.
        """
        assert isinstance(self._llm, StreamingLLMProvider)
        for iteration in range(self._max_iterations):
            content_parts: list[str] = []
            tc_accum: dict[int, dict[str, Any]] = {}

            stream = self._llm.chat_stream(
                messages,
                tools=tool_schemas,
            )
            async for chunk in stream:
                yield chunk
                if chunk.delta_content:
                    content_parts.append(chunk.delta_content)
                for tcd in chunk.tool_calls_delta:
                    _accumulate_tool_delta(tc_accum, tcd)

            content = "".join(content_parts)
            tool_calls = _build_tool_calls(tc_accum)

            if not tool_calls:
                yield iteration + 1
                return

            messages.append(
                {
                    "role": "assistant",
                    "content": content,
                    "tool_calls": _openai_tool_calls_payload(tool_calls),
                },
            )

            for tc in tool_calls:
                await self._emit(
                    AgentEventType.TOOL_CALL_STARTED,
                    {
                        "tool_name": tc.name,
                        "input": tc.arguments,
                    },
                )
                if self._tools and self._tools.has(tc.name):
                    result = await self._tools.execute(tc.name, tc.arguments)
                else:
                    result = ToolResult(
                        tool_name=tc.name,
                        success=False,
                        output=None,
                        error=f"Tool '{tc.name}' not found",
                    )
                evt = (
                    AgentEventType.TOOL_CALL_COMPLETED
                    if result.success
                    else AgentEventType.TOOL_CALL_FAILED
                )
                await self._emit(
                    evt,
                    {
                        "tool_name": tc.name,
                        "success": result.success,
                        "error": result.error,
                    },
                )
                all_tool_results.append(result.to_dict())
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": str(result.output)
                        if result.success
                        else str(result.error),
                    },
                )

        # Max iterations reached
        yield self._max_iterations


# ------------------------------------------------------------------
# Module-level helpers
# ------------------------------------------------------------------


def _openai_tool_calls_payload(
    tool_calls: tuple[ToolCall, ...] | list[ToolCall],
) -> list[dict[str, Any]]:
    """Build ``tool_calls`` for OpenAI-compatible chat APIs.

    The API specifies ``function.arguments`` as a JSON **string**. Some servers
    (e.g. Ollama) reject an object here with unmarshaling errors.
    """
    return [
        {
            "id": tc.id,
            "type": "function",
            "function": {
                "name": tc.name,
                "arguments": json.dumps(tc.arguments) if tc.arguments else "{}",
            },
        }
        for tc in tool_calls
    ]


def _assistant_tool_msg(
    response: LLMResponse,
) -> dict[str, Any]:
    """Build the assistant message with tool calls."""
    return {
        "role": "assistant",
        "content": response.content,
        "tool_calls": _openai_tool_calls_payload(response.tool_calls),
    }


def _validate_output(
    content: str,
    schema: dict[str, Any],
) -> list[str]:
    """Validate final LLM output against a JSON Schema.

    Args:
        content: The raw LLM output string.
        schema: JSON Schema to validate against.

    Returns:
        List of validation error strings (empty if valid).
    """
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError:
        return ["Response is not valid JSON"]
    return validate_tool_args(parsed, schema, "output")


def _accumulate_tool_delta(
    accum: dict[int, dict[str, Any]],
    delta: ToolCallDelta,
) -> None:
    """Merge a ToolCallDelta into an accumulator dict.

    Args:
        accum: Accumulator mapping tool index to partial data.
        delta: The incremental tool call delta.
    """
    idx = delta.index
    if idx not in accum:
        accum[idx] = {"id": "", "name": "", "arguments": ""}
    entry = accum[idx]
    if delta.id:
        entry["id"] = delta.id
    if delta.name:
        entry["name"] = delta.name
    entry["arguments"] += delta.arguments_delta


def _build_tool_calls(
    accum: dict[int, dict[str, Any]],
) -> list[ToolCall]:
    """Convert accumulated tool deltas into ToolCall objects.

    Args:
        accum: Accumulator from ``_accumulate_tool_delta``.

    Returns:
        List of ToolCall objects.
    """
    calls: list[ToolCall] = []
    for idx in sorted(accum):
        entry = accum[idx]
        raw_args = entry["arguments"]
        try:
            args = json.loads(raw_args) if raw_args else {}
        except json.JSONDecodeError:
            args = {"raw": raw_args}
        calls.append(
            ToolCall(
                id=entry["id"],
                name=entry["name"],
                arguments=args,
            ),
        )
    return calls
