"""Builder-pattern Agent API for pygubernator."""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from typing import Any

from pygubernator._events import EventBus
from pygubernator._types import AgentResult, Message
from pygubernator.agents._llm import LLMAgent
from pygubernator.builder._types import AgentResponse
from pygubernator.errors import ConfigError
from pygubernator.llm._factory import create_provider
from pygubernator.llm._messages import StreamChunk
from pygubernator.tools._decorator import _DecoratedTool
from pygubernator.tools._registry import ToolRegistry
from pygubernator.workflow.nodes._memory import (
    MemoryStore,
    create_memory_store,
)

logger = logging.getLogger(__name__)


class AgentBuilder:
    """Fluent builder for constructing Agent instances.

    Usage::

        agent = (
            Agent.builder()
            .model("gpt-4o", api_key="sk-...")
            .system_prompt("You are helpful.")
            .tools([my_tool])
            .build()
        )
    """

    def __init__(self) -> None:
        self._model: str | None = None
        self._api_key: str | None = None
        self._api_base: str | None = None
        self._max_tokens: int = 4096
        self._temperature: float = 0.0
        self._system_prompt: str = ""
        self._tools: list[Any] = []
        self._memory_type: str | None = None
        self._window_size: int = 10
        self._max_iterations: int = 10
        self._event_bus: EventBus | None = None
        self._agent_id: str = "agent"
        self._tool_timeout: float = 30.0
        self._max_tool_output: int = 10_000

    def model(
        self,
        model: str,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.0,
    ) -> AgentBuilder:
        """Set the LLM model and provider options.

        Args:
            model: Model identifier (e.g. ``"gpt-4o"``).
            api_key: API key for authentication.
            api_base: Base URL for the provider.
            max_tokens: Maximum response tokens.
            temperature: Sampling temperature.

        Returns:
            The builder for chaining.
        """
        self._model = model
        self._api_key = api_key
        self._api_base = api_base
        self._max_tokens = max_tokens
        self._temperature = temperature
        return self

    def system_prompt(self, prompt: str) -> AgentBuilder:
        """Set the system prompt.

        Args:
            prompt: System prompt text.

        Returns:
            The builder for chaining.
        """
        self._system_prompt = prompt
        return self

    def tools(self, tools: list[Any]) -> AgentBuilder:
        """Set the tools available to the agent.

        Args:
            tools: List of tool objects or decorated functions.

        Returns:
            The builder for chaining.
        """
        self._tools = list(tools)
        return self

    def memory(
        self,
        memory_type: str,
        *,
        window_size: int = 10,
    ) -> AgentBuilder:
        """Configure conversation memory for sessions.

        Args:
            memory_type: Memory strategy (``"buffer"`` or
                ``"window"``).
            window_size: Window size for ``"window"`` mode.

        Returns:
            The builder for chaining.
        """
        self._memory_type = memory_type
        self._window_size = window_size
        return self

    def max_iterations(self, n: int) -> AgentBuilder:
        """Set the maximum think-act-observe iterations.

        Args:
            n: Maximum iteration count.

        Returns:
            The builder for chaining.
        """
        self._max_iterations = n
        return self

    def event_bus(self, bus: EventBus) -> AgentBuilder:
        """Attach an event bus for observability.

        Args:
            bus: The event bus instance.

        Returns:
            The builder for chaining.
        """
        self._event_bus = bus
        return self

    def agent_id(self, agent_id: str) -> AgentBuilder:
        """Set the agent identifier.

        Args:
            agent_id: Unique identifier for the agent.

        Returns:
            The builder for chaining.
        """
        self._agent_id = agent_id
        return self

    def tool_timeout(self, seconds: float) -> AgentBuilder:
        """Set per-tool execution timeout.

        Args:
            seconds: Timeout in seconds (default 30.0).

        Returns:
            The builder for chaining.
        """
        self._tool_timeout = seconds
        return self

    def max_tool_output(self, chars: int) -> AgentBuilder:
        """Set maximum tool output characters.

        Output exceeding this limit is truncated before being
        fed back to the LLM.

        Args:
            chars: Maximum characters (default 10000).

        Returns:
            The builder for chaining.
        """
        self._max_tool_output = chars
        return self

    def build(self) -> Agent:
        """Build the Agent from the current configuration.

        Returns:
            A fully configured Agent instance.

        Raises:
            ConfigError: If the model has not been set.
        """
        if not self._model:
            raise ConfigError(
                "Model must be set before building an Agent. "
                "Call .model('model-name') first."
            )

        provider = create_provider(
            self._model,
            api_key=self._api_key,
            api_base=self._api_base,
            max_tokens=self._max_tokens,
            temperature=self._temperature,
        )

        registry: ToolRegistry | None = None
        if self._tools:
            registry = ToolRegistry()
            registry.register_all(self._tools)

        llm_agent = LLMAgent(
            agent_id=self._agent_id,
            llm_provider=provider,
            tool_registry=registry,
            system_prompt=self._system_prompt,
            max_iterations=self._max_iterations,
            event_bus=self._event_bus,
            tool_timeout=self._tool_timeout,
            max_tool_output_chars=self._max_tool_output,
        )

        return Agent(
            _llm_agent=llm_agent,
            _provider=provider,
            _registry=registry,
            _system_prompt=self._system_prompt,
            _max_iterations=self._max_iterations,
            _memory_type=self._memory_type,
            _window_size=self._window_size,
        )


class Agent:
    """High-level agent facade with builder construction.

    Create via the builder pattern::

        agent = (
            Agent.builder()
            .model("gpt-4o")
            .system_prompt("Be helpful.")
            .build()
        )

    Use ``agent.run()`` for stateless one-shot calls, or
    ``agent.session()`` for multi-turn conversations with memory.
    """

    def __init__(
        self,
        *,
        _llm_agent: LLMAgent,
        _provider: Any,
        _registry: ToolRegistry | None,
        _system_prompt: str,
        _max_iterations: int,
        _memory_type: str | None,
        _window_size: int,
    ) -> None:
        self._llm_agent = _llm_agent
        self._provider = _provider
        self._registry = _registry
        self._system_prompt = _system_prompt
        self._max_iterations = _max_iterations
        self._memory_type = _memory_type
        self._window_size = _window_size

    @staticmethod
    def builder() -> AgentBuilder:
        """Create a new AgentBuilder.

        Returns:
            A fresh AgentBuilder instance.
        """
        return AgentBuilder()

    async def run(self, text: str) -> AgentResponse:
        """Run a single stateless request.

        Creates a ``Message``, passes it to the underlying
        ``LLMAgent.process()``, and wraps the result.

        Args:
            text: The user input text.

        Returns:
            An AgentResponse with the LLM's reply.
        """
        msg = Message(
            topic="builder",
            payload={"content": text},
        )
        result: AgentResult = await self._llm_agent.process(msg)
        return AgentResponse.from_agent_result(result)

    async def run_stream(
        self,
        text: str,
    ) -> AsyncIterator[StreamChunk | AgentResponse]:
        """Stream a response, yielding chunks then final result.

        Creates a ``Message``, passes it to the underlying
        ``LLMAgent.process_stream()``, and yields each
        ``StreamChunk``. The final item is an ``AgentResponse``.

        Args:
            text: The user input text.

        Yields:
            StreamChunk for each token, then AgentResponse.
        """
        msg = Message(
            topic="builder",
            payload={"content": text},
        )
        async for item in self._llm_agent.process_stream(msg):
            if isinstance(item, AgentResult):
                yield AgentResponse.from_agent_result(item)
            else:
                yield item

    def session(self) -> Session:
        """Create a new conversational session with memory.

        If no memory type was configured, defaults to a
        ``BufferMemoryStore``.

        Returns:
            A Session instance for multi-turn conversation.
        """
        memory = self._create_memory_store()
        return Session(
            _llm_agent=self._llm_agent,
            _memory=memory,
            _memory_type=self._memory_type,
            _window_size=self._window_size,
        )

    def as_tool(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
    ) -> Any:
        """Wrap this agent as a tool for use by other agents.

        Args:
            name: Tool name (defaults to sanitized agent_id).
            description: Tool description.

        Returns:
            A ``_DecoratedTool`` that delegates to ``self.run()``.
        """
        tool_name = name or self.agent_id.replace("-", "_")
        tool_desc = description or (f"Delegate to agent '{self.agent_id}'")

        async def _delegate(input: str) -> str:
            response = await self.run(input)
            return response.text

        schema: dict[str, Any] = {
            "type": "object",
            "properties": {
                "input": {
                    "type": "string",
                    "description": "The input text to send.",
                },
            },
            "required": ["input"],
        }
        return _DecoratedTool(
            func=_delegate,
            name=tool_name,
            description=tool_desc,
            parameters_schema=schema,
        )

    @property
    def agent_id(self) -> str:
        """The underlying LLM agent's identifier."""
        return self._llm_agent.agent_id

    @property
    def inner(self) -> LLMAgent:
        """Escape hatch to the underlying LLMAgent."""
        return self._llm_agent

    def _create_memory_store(self) -> MemoryStore:
        """Build a fresh memory store from the configured type."""
        mem_type = self._memory_type or "buffer"
        return create_memory_store(
            memory_type=mem_type,
            window_size=self._window_size,
        )


class Session:
    """Multi-turn conversational session with memory.

    Created via ``Agent.session()``. Each call to ``run()``
    appends messages to the memory store so the LLM sees
    prior conversation context.
    """

    def __init__(
        self,
        *,
        _llm_agent: LLMAgent,
        _memory: MemoryStore,
        _memory_type: str | None,
        _window_size: int,
    ) -> None:
        self._llm_agent = _llm_agent
        self._memory = _memory
        self._memory_type = _memory_type
        self._window_size = _window_size

    async def run(self, text: str) -> AgentResponse:
        """Send a message within this session.

        Reads conversation history from memory, calls the LLM
        with that history, then writes the user and assistant
        messages back to memory.

        Args:
            text: The user input text.

        Returns:
            An AgentResponse with the LLM's reply.
        """
        history = self._memory.get_messages()
        msg = Message(
            topic="builder",
            payload={"content": text},
        )
        result: AgentResult = await self._llm_agent.process(msg, history=history)
        response = AgentResponse.from_agent_result(result)

        self._memory.add_messages(
            [
                {"role": "user", "content": text},
                {"role": "assistant", "content": response.text},
            ]
        )

        return response

    async def run_stream(
        self,
        text: str,
    ) -> AsyncIterator[StreamChunk | AgentResponse]:
        """Stream a response with session history.

        Reads conversation history from memory, streams the LLM
        response yielding ``StreamChunk`` objects, then writes the
        user and assistant messages back to memory. The final item
        yielded is an ``AgentResponse``.

        Args:
            text: The user input text.

        Yields:
            StreamChunk for each token, then AgentResponse.
        """
        history = self._memory.get_messages()
        msg = Message(
            topic="builder",
            payload={"content": text},
        )
        final_response: AgentResponse | None = None
        async for item in self._llm_agent.process_stream(
            msg,
            history=history,
        ):
            if isinstance(item, AgentResult):
                final_response = AgentResponse.from_agent_result(item)
                yield final_response
            else:
                yield item

        if final_response is not None:
            self._memory.add_messages(
                [
                    {"role": "user", "content": text},
                    {
                        "role": "assistant",
                        "content": final_response.text,
                    },
                ]
            )

    @property
    def history(self) -> list[dict[str, str]]:
        """Current conversation history from memory.

        Returns:
            List of message dicts with ``role`` and ``content``.
        """
        return self._memory.get_messages()

    def clear(self) -> None:
        """Reset the session by replacing the memory store."""
        mem_type = self._memory_type or "buffer"
        self._memory = create_memory_store(
            memory_type=mem_type,
            window_size=self._window_size,
        )
