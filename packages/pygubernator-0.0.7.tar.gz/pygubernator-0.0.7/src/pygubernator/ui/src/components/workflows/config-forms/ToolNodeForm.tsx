"use client";

import { useEffect, useState } from "react";

import { apiGet } from "@/lib/api";
import type { TypedNodeConfigFormProps } from "./index";

/* ------------------------------------------------------------------ */
/* Types & fallback (used if API unavailable)                         */
/* ------------------------------------------------------------------ */

interface ToolPresetDef {
  label: string;
  name: string;
  factory_module: string;
  factory_function: string;
  envHint: string;
}

interface ApiToolPreset {
  id: string;
  label: string;
  name: string;
  factory_module: string;
  factory_function: string;
  env_hint: string;
}

/** Bundled copy — matches `pygubernator.workflow.tool_presets`. */
const FALLBACK_PRESETS: Record<string, ToolPresetDef> = {
  google_sheets: {
    label: "Google Sheets",
    name: "google_sheets",
    factory_module: "pygubernator.tools.gsheets_factory",
    factory_function: "create_tools_from_env",
    envHint: "PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH",
  },
  google_docs: {
    label: "Google Docs",
    name: "google_docs",
    factory_module: "pygubernator.tools.gdocs_factory",
    factory_function: "create_tools_from_env",
    envHint: "PYGUBERNATOR_GDOCS_CREDENTIALS_PATH",
  },
  slack: {
    label: "Slack",
    name: "slack",
    factory_module: "pygubernator.tools.slack_factory",
    factory_function: "create_tools_from_env",
    envHint: "PYGUBERNATOR_SLACK_BOT_TOKEN",
  },
  notion: {
    label: "Notion",
    name: "notion",
    factory_module: "pygubernator.tools.notion_factory",
    factory_function: "create_tools_from_env",
    envHint: "PYGUBERNATOR_NOTION_API_KEY",
  },
  sql: {
    label: "SQL Database",
    name: "sql",
    factory_module: "pygubernator.tools.sql_factory",
    factory_function: "create_tools_from_env",
    envHint: "PYGUBERNATOR_SQL_CONNECTION_STRING",
  },
  http: {
    label: "HTTP / REST",
    name: "http",
    factory_module: "pygubernator.tools.http_factory",
    factory_function: "create_tools_from_env",
    envHint: "PYGUBERNATOR_HTTP_BASE_URL (optional)",
  },
  python: {
    label: "Python Execution",
    name: "python",
    factory_module: "pygubernator.tools.python_factory",
    factory_function: "create_tools_from_env",
    envHint: "PYGUBERNATOR_PYTHON_ALLOWED_IMPORTS (optional)",
  },
  obsidian: {
    label: "Obsidian Vault",
    name: "obsidian",
    factory_module: "pygubernator.tools.obsidian_factory",
    factory_function: "create_tools_from_env",
    envHint: "PYGUBERNATOR_OBSIDIAN_VAULT_PATH",
  },
};

const CUSTOM_FACTORY = "__custom_factory__";
const CUSTOM_FUNCTION = "__custom_function__";

function apiPresetsToMap(items: ApiToolPreset[]): Record<string, ToolPresetDef> {
  const m: Record<string, ToolPresetDef> = {};
  for (const i of items) {
    m[i.id] = {
      label: i.label,
      name: i.name,
      factory_module: i.factory_module,
      factory_function: i.factory_function,
      envHint: i.env_hint,
    };
  }
  return m;
}

function isPresetKey(
  value: string,
  presets: Record<string, ToolPresetDef>,
): boolean {
  return Object.prototype.hasOwnProperty.call(presets, value);
}

function detectPreset(
  factoryModule: string,
  factoryFunction: string,
  presets: Record<string, ToolPresetDef>,
): string | "none" {
  for (const [key, def] of Object.entries(presets)) {
    if (
      factoryModule === def.factory_module &&
      factoryFunction === def.factory_function
    ) {
      return key;
    }
  }
  return "none";
}

function envHintForConfig(
  factoryModule: string,
  factoryFunction: string,
  presets: Record<string, ToolPresetDef>,
): string | null {
  const key = detectPreset(factoryModule, factoryFunction, presets);
  if (key === "none") return null;
  return presets[key].envHint;
}

/** What the main dropdown should show, derived from current config. */
function integrationSelectValue(
  modulePath: string,
  functionName: string,
  factoryModule: string,
  factoryFunction: string,
  presets: Record<string, ToolPresetDef>,
): "" | string | typeof CUSTOM_FACTORY | typeof CUSTOM_FUNCTION {
  const hasFn = Boolean(modulePath && functionName);
  const hasFactoryFields = Boolean(factoryModule || factoryFunction);

  if (hasFn && !hasFactoryFields) {
    return CUSTOM_FUNCTION;
  }
  if (hasFactoryFields) {
    const p = detectPreset(factoryModule, factoryFunction, presets);
    if (p !== "none") return p;
    return CUSTOM_FACTORY;
  }
  return "";
}

/* ------------------------------------------------------------------ */
/* Component                                                            */
/* ------------------------------------------------------------------ */

/** Config for Tool sub-nodes (merged into Agent / LLM as tools). */
export function ToolNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const [presets, setPresets] =
    useState<Record<string, ToolPresetDef>>(FALLBACK_PRESETS);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const data = await apiGet<{ items: ApiToolPreset[] }>(
          "/api/v1/workflows/tool-presets",
        );
        if (cancelled || !data.items?.length) return;
        setPresets(apiPresetsToMap(data.items));
      } catch {
        /* keep FALLBACK_PRESETS */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const name = typeof config.name === "string" ? config.name : "";
  const modulePath =
    typeof config.module === "string" ? config.module : "";
  const functionName =
    typeof config.function === "string" ? config.function : "";
  const factoryModule =
    typeof config.factory_module === "string"
      ? config.factory_module
      : "";
  const factoryFunction =
    typeof config.factory_function === "string"
      ? config.factory_function
      : "";
  const factoryArgsRaw =
    typeof config.factory_args === "object" &&
    config.factory_args !== null
      ? JSON.stringify(config.factory_args, null, 2)
      : "{}";

  const preset = detectPreset(factoryModule, factoryFunction, presets);
  const envHint = envHintForConfig(factoryModule, factoryFunction, presets);

  const integrationValue = integrationSelectValue(
    modulePath,
    functionName,
    factoryModule,
    factoryFunction,
    presets,
  );

  const applyPreset = (key: string) => {
    const def = presets[key];
    if (!def) return;
    onChange({
      ...config,
      name: name || def.name,
      factory_module: def.factory_module,
      factory_function: def.factory_function,
      factory_args: {},
      module: undefined,
      function: undefined,
    });
  };

  const setIntegration = (
    value: "" | string | typeof CUSTOM_FACTORY | typeof CUSTOM_FUNCTION,
  ) => {
    if (value === "") {
      onChange({
        ...config,
        module: undefined,
        function: undefined,
        factory_module: undefined,
        factory_function: undefined,
        factory_args: undefined,
      });
      return;
    }
    if (value === CUSTOM_FUNCTION) {
      onChange({
        ...config,
        factory_module: undefined,
        factory_function: undefined,
        factory_args: undefined,
      });
      return;
    }
    if (value === CUSTOM_FACTORY) {
      onChange({
        ...config,
        module: undefined,
        function: undefined,
      });
      return;
    }
    applyPreset(value);
  };

  const showPresetSummary =
    preset !== "none" &&
    isPresetKey(integrationValue, presets) &&
    preset === integrationValue;
  const showFactoryAdvanced = integrationValue === CUSTOM_FACTORY;
  const showFunctionFields = integrationValue === CUSTOM_FUNCTION;
  /** Factory path: built-in preset, manual factory, or existing factory config. */
  const showFactorySection =
    integrationValue !== "" &&
    integrationValue !== CUSTOM_FUNCTION &&
    (integrationValue === CUSTOM_FACTORY ||
      isPresetKey(integrationValue, presets) ||
      Boolean(factoryModule || factoryFunction));

  const presetDef =
    preset !== "none" && preset in presets ? presets[preset] : null;

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Integration</label>
        <p className="text-[11px] text-muted-foreground leading-snug">
          Pick a built-in bundle (Slack, Sheets, …). The list is provided by the
          server; tools load from env-based factories when this graph is run.
          Use advanced options only if you maintain custom Python modules.
        </p>
        <select
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={integrationValue}
          onChange={(e) => {
            const v = e.target.value;
            if (v === "" || v === CUSTOM_FACTORY || v === CUSTOM_FUNCTION) {
              setIntegration(v);
              return;
            }
            setIntegration(v);
          }}
        >
          <option value="">Choose an integration…</option>
          <optgroup label="Built-in">
            {Object.entries(presets).map(([key, def]) => (
              <option key={key} value={key}>
                {def.label}
              </option>
            ))}
          </optgroup>
          <optgroup label="Advanced">
            <option value={CUSTOM_FACTORY}>Custom factory (manual paths)</option>
            <option value={CUSTOM_FUNCTION}>
              Single Python function (module + name)
            </option>
          </optgroup>
        </select>
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Tool name</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          placeholder="e.g. slack (used as the key under the Agent)"
          value={name}
          onChange={(e) =>
            onChange({ ...config, name: e.target.value })
          }
        />
        <p className="text-[11px] text-muted-foreground">
          Defaults from the integration above; change only if you need a custom
          key.
        </p>
      </div>

      {showPresetSummary && presetDef && (
        <div className="rounded-md border border-border bg-muted/40 px-3 py-2 text-xs space-y-1">
          <p className="font-medium text-foreground">
            {presetDef.label}
          </p>
          <p className="text-muted-foreground font-mono break-all">
            {presetDef.factory_module}
            <span className="text-foreground"> · </span>
            {presetDef.factory_function}()
          </p>
          {envHint && (
            <p className="text-muted-foreground pt-1">
              Set server env{" "}
              <code className="rounded bg-muted px-1 py-0.5">{envHint}</code>
            </p>
          )}
        </div>
      )}

      {showFactorySection && (
        <>
          {showFactoryAdvanced && (
            <>
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium">
                  Factory module
                </label>
                <input
                  className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
                  placeholder="pygubernator.tools.slack_factory"
                  value={factoryModule}
                  onChange={(e) =>
                    onChange({
                      ...config,
                      factory_module: e.target.value,
                    })
                  }
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium">
                  Factory function
                </label>
                <input
                  className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
                  placeholder="create_tools_from_env"
                  value={factoryFunction}
                  onChange={(e) =>
                    onChange({
                      ...config,
                      factory_function: e.target.value,
                    })
                  }
                />
              </div>
            </>
          )}

          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium">
              Factory args (JSON)
            </label>
            <textarea
              className="flex min-h-[72px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
              placeholder="{}"
              value={factoryArgsRaw}
              onChange={(e) => {
                try {
                  onChange({
                    ...config,
                    factory_args: JSON.parse(
                      e.target.value || "{}",
                    ),
                  });
                } catch {
                  // Keep typing forgiving; update only when valid.
                }
              }}
            />
            {showFactoryAdvanced && envHint && (
              <p className="text-[11px] text-muted-foreground">
                Set env var{" "}
                <code className="rounded bg-muted px-1">
                  {envHint}
                </code>{" "}
                on the server.
              </p>
            )}
          </div>
        </>
      )}

      {showFunctionFields && (
        <>
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium">Module</label>
            <input
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
              placeholder="mypackage.tools"
              value={modulePath}
              onChange={(e) =>
                onChange({ ...config, module: e.target.value })
              }
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium">Function</label>
            <input
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
              placeholder="my_tool"
              value={functionName}
              onChange={(e) =>
                onChange({ ...config, function: e.target.value })
              }
            />
          </div>
          <p className="text-[11px] text-muted-foreground">
            For subgraph tools wired into an Agent, prefer an integration above.
            Single-function mode is for custom @tool callables in your codebase.
          </p>
        </>
      )}
    </div>
  );
}
