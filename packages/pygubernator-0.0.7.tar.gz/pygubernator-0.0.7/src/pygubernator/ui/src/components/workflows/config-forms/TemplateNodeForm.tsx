"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for template nodes: template string + output key. */
export function TemplateNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const template = typeof config.template === "string" ? config.template : "";
  const outputKey = typeof config.output_key === "string" ? config.output_key : "";

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Template</label>
        <textarea
          className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
          placeholder="Hello, {{name}}! Your order #{{order_id}} is ready."
          value={template}
          onChange={(e) => onChange({ ...config, template: e.target.value })}
        />
        <p className="text-[11px] text-muted-foreground">
          {"Use {{variable}} for interpolation"}
        </p>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Output Key</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          placeholder="rendered_text"
          value={outputKey}
          onChange={(e) => onChange({ ...config, output_key: e.target.value })}
        />
      </div>
    </div>
  );
}
