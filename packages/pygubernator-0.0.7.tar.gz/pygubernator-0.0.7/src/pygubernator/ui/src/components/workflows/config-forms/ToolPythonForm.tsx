"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for Python execution tool sub-nodes. */
export function ToolPythonForm({ config, onChange }: TypedNodeConfigFormProps) {
  const name = typeof config.name === "string" ? config.name : "python";

  const ctx = (
    typeof config.context === "object" && config.context !== null
      ? config.context
      : {}
  ) as Record<string, string | undefined>;

  const setCtx = (newCtx: Record<string, string | undefined>) => {
    const cleaned: Record<string, string> = {};
    for (const [k, v] of Object.entries(newCtx)) {
      if (v) cleaned[k] = v;
    }
    onChange({
      ...config,
      context: Object.keys(cleaned).length > 0 ? cleaned : undefined,
    });
  };

  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
        <div className="font-medium text-foreground mb-1">Python</div>
        Execute Python code, evaluate expressions, and install packages. Provides 3 tools.
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Tool Name</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={name}
          onChange={(e) => onChange({ ...config, name: e.target.value })}
        />
      </div>

      {/* --- Context (optional) --- */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          Context (optional)
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Allowed Imports</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            placeholder="pandas, numpy, json"
            value={ctx.allowed_imports ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, allowed_imports: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Comma-separated list of Python modules the agent may import.
          </p>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Description</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            placeholder="Use for data transformations with pandas"
            value={ctx.description ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, description: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Help the agent understand when and how to use Python.
          </p>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground">
        Optionally set env var <code className="rounded bg-muted px-1">PYGUBERNATOR_PYTHON_ALLOWED_IMPORTS</code> on the server.
      </p>
    </div>
  );
}
