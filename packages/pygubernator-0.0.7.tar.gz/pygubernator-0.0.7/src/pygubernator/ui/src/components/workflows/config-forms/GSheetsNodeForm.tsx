"use client";

import type { TypedNodeConfigFormProps } from "./index";

const GSHEETS_OPERATIONS = [
  "create_spreadsheet",
  "read_range",
  "write_range",
  "append_rows",
  "create_sheet",
  "delete_sheet",
  "rename_sheet",
  "format_cells",
] as const;

type GSheetsOp = (typeof GSHEETS_OPERATIONS)[number];

function str(config: Record<string, unknown>, key: string): string {
  const v = config[key];
  return typeof v === "string" ? v : v != null ? String(v) : "";
}

/** Config form for Google Sheets nodes: operation-specific fields. */
export function GSheetsNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const operation = (str(config, "operation") || "read_range") as GSheetsOp;
  const credEnv =
    str(config, "credentials_env_var") || "PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH";

  const set = (patch: Record<string, unknown>) => onChange({ ...config, ...patch });

  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground rounded-md border border-border bg-muted/40 px-2 py-1.5">
        To let an <strong>Agent</strong> read or write Sheets from your prompt, connect this node&apos;s{" "}
        <strong className="text-emerald-700">green top handle</strong> to the Agent&apos;s{" "}
        <strong>Tool</strong> port (not the main left input). Ensure{" "}
        <code className="text-[11px]">PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH</code> is set.
      </p>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Operation</label>
        <select
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
          value={operation}
          onChange={(e) => set({ operation: e.target.value })}
        >
          {GSHEETS_OPERATIONS.map((op) => (
            <option key={op} value={op}>
              {op}
            </option>
          ))}
        </select>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Credentials env var</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
          placeholder="PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH"
          value={credEnv}
          onChange={(e) => set({ credentials_env_var: e.target.value })}
        />
        <p className="text-xs text-muted-foreground">
          Must point to a service account JSON key path. Other fields can be wired from upstream nodes.
        </p>
      </div>

      {operation === "create_spreadsheet" && (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Title</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            value={str(config, "title")}
            onChange={(e) => set({ title: e.target.value })}
          />
        </div>
      )}

      {(operation === "read_range" ||
        operation === "write_range" ||
        operation === "append_rows" ||
        operation === "create_sheet" ||
        operation === "delete_sheet" ||
        operation === "rename_sheet" ||
        operation === "format_cells") && (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Spreadsheet ID</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
            value={str(config, "spreadsheet_id")}
            onChange={(e) => set({ spreadsheet_id: e.target.value })}
          />
        </div>
      )}

      {(operation === "read_range" ||
        operation === "write_range" ||
        operation === "append_rows") && (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Range (A1)</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
            placeholder="Sheet1!A1:B10"
            value={str(config, "range_a1")}
            onChange={(e) => set({ range_a1: e.target.value })}
          />
        </div>
      )}

      {(operation === "write_range" || operation === "append_rows") && (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Values (JSON array of rows)</label>
          <textarea
            className="min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-xs font-mono"
            placeholder='[["a","b"],[1,2]]'
            value={str(config, "values_json")}
            onChange={(e) => set({ values_json: e.target.value })}
          />
        </div>
      )}

      {operation === "create_sheet" && (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Sheet title</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            value={str(config, "sheet_title")}
            onChange={(e) => set({ sheet_title: e.target.value })}
          />
        </div>
      )}

      {(operation === "delete_sheet" ||
        operation === "rename_sheet" ||
        operation === "format_cells") && (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Sheet ID (numeric)</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
            value={str(config, "sheet_id")}
            onChange={(e) => set({ sheet_id: e.target.value })}
          />
        </div>
      )}

      {operation === "rename_sheet" && (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">New title</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            value={str(config, "new_title")}
            onChange={(e) => set({ new_title: e.target.value })}
          />
        </div>
      )}

      {operation === "format_cells" && (
        <div className="grid grid-cols-2 gap-2">
          {(["start_row", "end_row", "start_col", "end_col"] as const).map((k) => (
            <div key={k} className="flex flex-col gap-1">
              <label className="text-xs font-medium">{k}</label>
              <input
                className="flex h-8 w-full rounded-md border border-input bg-background px-2 py-1 text-xs font-mono"
                value={str(config, k)}
                onChange={(e) => set({ [k]: e.target.value })}
              />
            </div>
          ))}
          <div className="col-span-2 flex flex-col gap-1">
            <label className="text-xs font-medium">Bold</label>
            <select
              className="flex h-8 w-full rounded-md border border-input bg-background px-2 py-1 text-xs"
              value={str(config, "bold") === "true" ? "true" : "false"}
              onChange={(e) => set({ bold: e.target.value === "true" })}
            >
              <option value="false">No</option>
              <option value="true">Yes</option>
            </select>
          </div>
          <div className="col-span-2 flex flex-col gap-1">
            <label className="text-xs font-medium">Border style</label>
            <input
              className="flex h-8 w-full rounded-md border border-input bg-background px-2 py-1 text-xs"
              placeholder="SOLID"
              value={str(config, "border_style")}
              onChange={(e) => set({ border_style: e.target.value })}
            />
          </div>
          <div className="col-span-2 flex flex-col gap-1">
            <label className="text-xs font-medium">fg_color (JSON)</label>
            <input
              className="flex h-8 w-full rounded-md border border-input bg-background px-2 py-1 text-xs font-mono"
              placeholder='{"red":1,"green":0,"blue":0}'
              value={str(config, "fg_color")}
              onChange={(e) => set({ fg_color: e.target.value })}
            />
          </div>
          <div className="col-span-2 flex flex-col gap-1">
            <label className="text-xs font-medium">bg_color (JSON)</label>
            <input
              className="flex h-8 w-full rounded-md border border-input bg-background px-2 py-1 text-xs font-mono"
              value={str(config, "bg_color")}
              onChange={(e) => set({ bg_color: e.target.value })}
            />
          </div>
        </div>
      )}
    </div>
  );
}
