"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for Notion tool sub-nodes. */
export function ToolNotionForm({ config, onChange }: TypedNodeConfigFormProps) {
  const name = typeof config.name === "string" ? config.name : "notion";

  const ctx = (
    typeof config.context === "object" && config.context !== null
      ? config.context
      : {}
  ) as Record<string, string | undefined>;

  const setCtx = (newCtx: Record<string, string | undefined>) => {
    const cleaned: Record<string, string> = {};
    for (const [k, v] of Object.entries(newCtx)) {
      if (v) cleaned[k] = v;
    }
    onChange({
      ...config,
      context: Object.keys(cleaned).length > 0 ? cleaned : undefined,
    });
  };

  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
        <div className="font-medium text-foreground mb-1">Notion</div>
        Search, read, create, and update Notion pages and databases. Provides 6 tools.
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Tool Name</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={name}
          onChange={(e) => onChange({ ...config, name: e.target.value })}
        />
      </div>

      {/* --- Context (optional) --- */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          Context (optional)
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Database / Page ID</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
            placeholder="a1b2c3d4-e5f6-7890-abcd-ef1234567890"
            value={ctx.database_id ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, database_id: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            The agent will target this database or page by default.
          </p>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Default Operation</label>
          <select
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            value={ctx.default_operation ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, default_operation: e.target.value || undefined })
            }
          >
            <option value="">Any (agent decides)</option>
            <option value="search">Search</option>
            <option value="read">Read</option>
            <option value="create">Create</option>
            <option value="update">Update</option>
          </select>
          <p className="text-[11px] text-muted-foreground">
            Hint the agent toward a specific operation by default.
          </p>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground">
        Set env var <code className="rounded bg-muted px-1">PYGUBERNATOR_NOTION_API_KEY</code> on the server.
      </p>
    </div>
  );
}
