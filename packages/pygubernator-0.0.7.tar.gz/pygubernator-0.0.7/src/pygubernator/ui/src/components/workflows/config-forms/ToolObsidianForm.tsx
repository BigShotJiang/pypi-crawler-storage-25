"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for Obsidian vault tool sub-nodes. */
export function ToolObsidianForm({ config, onChange }: TypedNodeConfigFormProps) {
  const name = typeof config.name === "string" ? config.name : "obsidian";

  const ctx = (
    typeof config.context === "object" && config.context !== null
      ? config.context
      : {}
  ) as Record<string, string | undefined>;

  const setCtx = (newCtx: Record<string, string | undefined>) => {
    const cleaned: Record<string, string> = {};
    for (const [k, v] of Object.entries(newCtx)) {
      if (v) cleaned[k] = v;
    }
    onChange({
      ...config,
      context: Object.keys(cleaned).length > 0 ? cleaned : undefined,
    });
  };

  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
        <div className="font-medium text-foreground mb-1">Obsidian</div>
        Read, write, search, and manage Obsidian vault notes. Provides 6 tools.
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Tool Name</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={name}
          onChange={(e) => onChange({ ...config, name: e.target.value })}
        />
      </div>

      {/* --- Context (optional) --- */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          Context (optional)
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Vault Path</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
            placeholder="/home/user/my-vault"
            value={ctx.vault_path ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, vault_path: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Hint shown to the agent about the vault location.
          </p>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Default Folder</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            placeholder="Projects/Notes"
            value={ctx.default_folder ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, default_folder: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Scope searches and operations to this folder within the vault.
          </p>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground">
        Set env var <code className="rounded bg-muted px-1">PYGUBERNATOR_OBSIDIAN_VAULT_PATH</code> on the server.
      </p>
    </div>
  );
}
