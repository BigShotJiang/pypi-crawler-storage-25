"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for LLM agent nodes: prompt, system prompt, model, and iteration limit. */
export function LlmNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const promptTemplate =
    typeof config.prompt_template === "string" ? config.prompt_template : "";
  const systemPrompt =
    typeof config.system_prompt === "string" ? config.system_prompt : "";
  const maxIterations =
    typeof config.max_iterations === "number" ? config.max_iterations : 5;

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Prompt Template</label>
        <textarea
          className="flex min-h-[160px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
          placeholder="Summarize the following text:\n\n{{text}}"
          value={promptTemplate}
          onChange={(e) =>
            onChange({ ...config, prompt_template: e.target.value })
          }
        />
        <p className="text-[11px] text-muted-foreground">
          {"Jinja2 template rendered against upstream context. Use {{variable}} syntax."}
        </p>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">System Prompt</label>
        <textarea
          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          placeholder="You are a helpful assistant..."
          value={systemPrompt}
          onChange={(e) =>
            onChange({ ...config, system_prompt: e.target.value })
          }
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Max Iterations</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          min={1}
          max={50}
          value={maxIterations}
          onChange={(e) =>
            onChange({ ...config, max_iterations: Number(e.target.value) })
          }
        />
        <p className="text-[11px] text-muted-foreground">
          Maximum tool-calling loop iterations before stopping.
        </p>
      </div>
    </div>
  );
}
