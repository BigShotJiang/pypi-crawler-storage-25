"use client";

import ApiUnavailableBanner from "@/components/ApiUnavailableBanner";
import { AuthGuard } from "@/components/layout/AuthGuard";
import Navigation from "@/components/Navigation";
import { useAuthInit } from "@/hooks/use-auth-init";

export default function AppShell({ children }: { children: React.ReactNode }) {
  useAuthInit();

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <ApiUnavailableBanner />
      <main
        className="flex-1"
        style={{ minHeight: 0, overflow: "auto", position: "relative" }}
      >
        <AuthGuard>{children}</AuthGuard>
      </main>
    </div>
  );
}
