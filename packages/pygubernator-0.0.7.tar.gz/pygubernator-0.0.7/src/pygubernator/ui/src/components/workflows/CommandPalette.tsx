"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useWorkflowEditorStore } from "@/stores/workflow-editor";

interface Command {
  id: string;
  label: string;
  shortcut?: string;
  category: string;
  action: () => void;
}

interface CommandPaletteProps {
  onClose: () => void;
  onSave: () => void;
  onExecute: () => void;
  onFitView: () => void;
}

export function CommandPalette({ onClose, onSave, onExecute, onFitView }: CommandPaletteProps) {
  const [query, setQuery] = useState("");
  const [activeIdx, setActiveIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const commands: Command[] = useMemo(() => {
    const store = useWorkflowEditorStore.getState;
    return [
      { id: "save", label: "Save Workflow", shortcut: "Ctrl+S", category: "File", action: onSave },
      { id: "execute", label: "Execute Workflow", shortcut: "Ctrl+Enter", category: "File", action: onExecute },
      { id: "undo", label: "Undo", shortcut: "Ctrl+Z", category: "Edit", action: () => store().undo() },
      { id: "redo", label: "Redo", shortcut: "Ctrl+Shift+Z", category: "Edit", action: () => store().redo() },
      { id: "copy", label: "Copy", shortcut: "Ctrl+C", category: "Edit", action: () => store().copySelection() },
      { id: "cut", label: "Cut", shortcut: "Ctrl+X", category: "Edit", action: () => store().cutSelection() },
      { id: "paste", label: "Paste", shortcut: "Ctrl+V", category: "Edit", action: () => store().pasteClipboard() },
      { id: "selectAll", label: "Select All", shortcut: "Ctrl+A", category: "Edit", action: () => store().selectAll() },
      { id: "delete", label: "Delete Selection", shortcut: "Del", category: "Edit", action: () => store().deleteSelection() },
      {
        id: "duplicate", label: "Duplicate", shortcut: "Ctrl+D", category: "Edit",
        action: () => { store().copySelection(); store().pasteClipboard(); },
      },
      { id: "fitView", label: "Fit View", shortcut: "F", category: "View", action: onFitView },
    ];
  }, [onSave, onExecute, onFitView]);

  const filtered = useMemo(() => {
    if (!query.trim()) return commands;
    const q = query.toLowerCase();
    return commands.filter(
      (c) => c.label.toLowerCase().includes(q) || c.category.toLowerCase().includes(q),
    );
  }, [commands, query]);

  useEffect(() => {
    setActiveIdx(0);
  }, [filtered.length]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const runCommand = useCallback(
    (cmd: Command) => {
      onClose();
      cmd.action();
    },
    [onClose],
  );

  const onKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        setActiveIdx((i) => Math.min(i + 1, filtered.length - 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setActiveIdx((i) => Math.max(i - 1, 0));
      } else if (e.key === "Enter") {
        e.preventDefault();
        if (filtered[activeIdx]) runCommand(filtered[activeIdx]);
      }
    },
    [onClose, filtered, activeIdx, runCommand],
  );

  // Scroll active item into view
  useEffect(() => {
    const el = listRef.current?.children[activeIdx] as HTMLElement | undefined;
    el?.scrollIntoView({ block: "nearest" });
  }, [activeIdx]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-[20vh] bg-black/40"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-lg border bg-background shadow-2xl"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={onKeyDown}
      >
        <input
          ref={inputRef}
          className="w-full rounded-t-lg border-b bg-transparent px-4 py-3 text-sm outline-none placeholder:text-muted-foreground"
          placeholder="Type a command..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <div ref={listRef} className="max-h-[300px] overflow-y-auto p-1">
          {filtered.length === 0 && (
            <div className="px-4 py-3 text-sm text-muted-foreground">No commands found</div>
          )}
          {filtered.map((cmd, idx) => (
            <button
              key={cmd.id}
              className={`flex w-full items-center justify-between rounded-sm px-3 py-2 text-sm outline-none transition-colors ${
                idx === activeIdx ? "bg-accent text-accent-foreground" : "hover:bg-accent/50"
              }`}
              onClick={() => runCommand(cmd)}
              onMouseEnter={() => setActiveIdx(idx)}
            >
              <span>
                <span className="text-muted-foreground text-xs mr-2">{cmd.category}</span>
                {cmd.label}
              </span>
              {cmd.shortcut && (
                <kbd className="ml-4 text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
                  {cmd.shortcut}
                </kbd>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
