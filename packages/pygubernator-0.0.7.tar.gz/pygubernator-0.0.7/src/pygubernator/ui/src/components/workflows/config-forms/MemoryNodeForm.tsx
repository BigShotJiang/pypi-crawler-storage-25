"use client";

import type { TypedNodeConfigFormProps } from "./index";

const MEMORY_TYPES = ["buffer", "window"] as const;

const INPUT_CLS =
  "flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm";
const SHORT_CLS =
  "flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm";

/* ------------------------------------------------------------------ */
/*  Helpers                                                           */
/* ------------------------------------------------------------------ */

type Cfg = Record<string, unknown>;

function str(config: Cfg, key: string, fallback = ""): string {
  return typeof config[key] === "string" ? (config[key] as string) : fallback;
}

function num(config: Cfg, key: string, fallback: number): number {
  return typeof config[key] === "number" ? (config[key] as number) : fallback;
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-sm font-medium">{label}</label>
      {children}
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  );
}

function SectionDivider({ label }: { label: string }) {
  return (
    <div className="pt-2 pb-1">
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      <div className="border-t border-border/50 mt-1" />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Backend-specific config sections                                  */
/* ------------------------------------------------------------------ */

function SqliteFields({ config, onChange }: TypedNodeConfigFormProps) {
  return (
    <>
      <SectionDivider label="SQLite Connection" />
      <Field label="Database Path" hint="Relative or absolute path to the .db file.">
        <input
          className={INPUT_CLS}
          placeholder="memory.db"
          value={str(config, "db_path", "memory.db")}
          onChange={(e) => onChange({ ...config, db_path: e.target.value })}
        />
      </Field>
      <Field label="Table Name">
        <input
          className={INPUT_CLS}
          placeholder="messages"
          value={str(config, "table_name", "messages")}
          onChange={(e) => onChange({ ...config, table_name: e.target.value })}
        />
      </Field>
    </>
  );
}

function PostgresFields({ config, onChange }: TypedNodeConfigFormProps) {
  return (
    <>
      <SectionDivider label="PostgreSQL Connection" />
      <Field
        label="Connection String"
        hint="Leave blank to use the MEMORY_POSTGRES_DSN env var."
      >
        <input
          className={INPUT_CLS}
          placeholder="postgresql://user:pass@host:5432/db"
          value={str(config, "connection_string")}
          onChange={(e) =>
            onChange({ ...config, connection_string: e.target.value || undefined })
          }
        />
      </Field>
      <Field label="Table Name">
        <input
          className={INPUT_CLS}
          placeholder="messages"
          value={str(config, "table_name", "messages")}
          onChange={(e) => onChange({ ...config, table_name: e.target.value })}
        />
      </Field>
    </>
  );
}

function MongoFields({ config, onChange }: TypedNodeConfigFormProps) {
  return (
    <>
      <SectionDivider label="MongoDB Connection" />
      <Field
        label="Connection String"
        hint="Leave blank to use the MEMORY_MONGO_URI env var."
      >
        <input
          className={INPUT_CLS}
          placeholder="mongodb://localhost:27017"
          value={str(config, "connection_string")}
          onChange={(e) =>
            onChange({ ...config, connection_string: e.target.value || undefined })
          }
        />
      </Field>
      <Field label="Database Name">
        <input
          className={INPUT_CLS}
          placeholder="memory"
          value={str(config, "database_name", "memory")}
          onChange={(e) => onChange({ ...config, database_name: e.target.value })}
        />
      </Field>
      <Field label="Collection Name">
        <input
          className={INPUT_CLS}
          placeholder="messages"
          value={str(config, "collection_name", "messages")}
          onChange={(e) => onChange({ ...config, collection_name: e.target.value })}
        />
      </Field>
    </>
  );
}

function PineconeFields({ config, onChange }: TypedNodeConfigFormProps) {
  return (
    <>
      <SectionDivider label="Pinecone Connection" />
      <Field label="API Key" hint="Leave blank to use the PINECONE_API_KEY env var.">
        <input
          type="password"
          className={INPUT_CLS}
          placeholder="pc-..."
          value={str(config, "api_key")}
          onChange={(e) => onChange({ ...config, api_key: e.target.value || undefined })}
        />
      </Field>
      <Field label="Index Name">
        <input
          className={INPUT_CLS}
          placeholder="my-index"
          value={str(config, "index_name")}
          onChange={(e) => onChange({ ...config, index_name: e.target.value })}
        />
      </Field>
      <Field label="Namespace" hint="Optional — isolates data within the index.">
        <input
          className={INPUT_CLS}
          placeholder="default"
          value={str(config, "namespace")}
          onChange={(e) =>
            onChange({ ...config, namespace: e.target.value || undefined })
          }
        />
      </Field>
      <Field label="Embedding Dimension">
        <input
          type="number"
          className={SHORT_CLS}
          placeholder="1536"
          value={num(config, "dimension", 1536)}
          onChange={(e) =>
            onChange({ ...config, dimension: parseInt(e.target.value, 10) || 1536 })
          }
        />
      </Field>
    </>
  );
}

function ChromaFields({ config, onChange }: TypedNodeConfigFormProps) {
  return (
    <>
      <SectionDivider label="Chroma Connection" />
      <Field label="Host">
        <input
          className={INPUT_CLS}
          placeholder="localhost"
          value={str(config, "host", "localhost")}
          onChange={(e) => onChange({ ...config, host: e.target.value })}
        />
      </Field>
      <Field label="Port">
        <input
          type="number"
          className={SHORT_CLS}
          value={num(config, "port", 8000)}
          onChange={(e) =>
            onChange({ ...config, port: parseInt(e.target.value, 10) || 8000 })
          }
        />
      </Field>
      <Field label="Collection Name">
        <input
          className={INPUT_CLS}
          placeholder="messages"
          value={str(config, "collection_name", "messages")}
          onChange={(e) => onChange({ ...config, collection_name: e.target.value })}
        />
      </Field>
    </>
  );
}

function QdrantFields({ config, onChange }: TypedNodeConfigFormProps) {
  return (
    <>
      <SectionDivider label="Qdrant Connection" />
      <Field label="URL">
        <input
          className={INPUT_CLS}
          placeholder="http://localhost:6333"
          value={str(config, "url", "http://localhost:6333")}
          onChange={(e) => onChange({ ...config, url: e.target.value })}
        />
      </Field>
      <Field label="Collection Name">
        <input
          className={INPUT_CLS}
          placeholder="messages"
          value={str(config, "collection_name", "messages")}
          onChange={(e) => onChange({ ...config, collection_name: e.target.value })}
        />
      </Field>
      <Field label="API Key" hint="Optional — required for Qdrant Cloud.">
        <input
          type="password"
          className={INPUT_CLS}
          value={str(config, "api_key")}
          onChange={(e) => onChange({ ...config, api_key: e.target.value || undefined })}
        />
      </Field>
      <Field label="Embedding Dimension">
        <input
          type="number"
          className={SHORT_CLS}
          placeholder="1536"
          value={num(config, "dimension", 1536)}
          onChange={(e) =>
            onChange({ ...config, dimension: parseInt(e.target.value, 10) || 1536 })
          }
        />
      </Field>
    </>
  );
}

function WeaviateFields({ config, onChange }: TypedNodeConfigFormProps) {
  return (
    <>
      <SectionDivider label="Weaviate Connection" />
      <Field label="URL">
        <input
          className={INPUT_CLS}
          placeholder="http://localhost:8080"
          value={str(config, "url", "http://localhost:8080")}
          onChange={(e) => onChange({ ...config, url: e.target.value })}
        />
      </Field>
      <Field label="Class Name" hint="Weaviate class to store messages in.">
        <input
          className={INPUT_CLS}
          placeholder="MemoryMessage"
          value={str(config, "class_name", "MemoryMessage")}
          onChange={(e) => onChange({ ...config, class_name: e.target.value })}
        />
      </Field>
      <Field label="API Key" hint="Optional — required for Weaviate Cloud.">
        <input
          type="password"
          className={INPUT_CLS}
          value={str(config, "api_key")}
          onChange={(e) => onChange({ ...config, api_key: e.target.value || undefined })}
        />
      </Field>
    </>
  );
}

function MilvusFields({ config, onChange }: TypedNodeConfigFormProps) {
  return (
    <>
      <SectionDivider label="Milvus Connection" />
      <Field label="URI">
        <input
          className={INPUT_CLS}
          placeholder="http://localhost:19530"
          value={str(config, "uri", "http://localhost:19530")}
          onChange={(e) => onChange({ ...config, uri: e.target.value })}
        />
      </Field>
      <Field label="Collection Name">
        <input
          className={INPUT_CLS}
          placeholder="messages"
          value={str(config, "collection_name", "messages")}
          onChange={(e) => onChange({ ...config, collection_name: e.target.value })}
        />
      </Field>
      <Field label="Token" hint="Optional — required for Zilliz Cloud.">
        <input
          type="password"
          className={INPUT_CLS}
          value={str(config, "token")}
          onChange={(e) => onChange({ ...config, token: e.target.value || undefined })}
        />
      </Field>
      <Field label="Embedding Dimension">
        <input
          type="number"
          className={SHORT_CLS}
          placeholder="1536"
          value={num(config, "dimension", 1536)}
          onChange={(e) =>
            onChange({ ...config, dimension: parseInt(e.target.value, 10) || 1536 })
          }
        />
      </Field>
    </>
  );
}

/* ------------------------------------------------------------------ */
/*  Main form                                                         */
/* ------------------------------------------------------------------ */

/** Config form for Memory sub-nodes: backend, type, and connection details. */
export function MemoryNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const backend = str(config, "backend", "in_memory");
  const memoryType = str(config, "memory_type", "buffer");
  const windowSize = num(config, "window_size", 10);

  const set = (patch: Cfg) => onChange({ ...config, ...patch });

  return (
    <div className="space-y-3">
      {/* Storage Backend */}
      <Field label="Storage Backend">
        <select
          className={INPUT_CLS}
          value={backend}
          onChange={(e) => set({ backend: e.target.value })}
        >
          <optgroup label="In-Process">
            <option value="in_memory">In-Memory</option>
          </optgroup>
          <optgroup label="Databases">
            <option value="sqlite">SQLite</option>
            <option value="postgres">PostgreSQL</option>
            <option value="mongodb">MongoDB</option>
          </optgroup>
          <optgroup label="Vector Databases">
            <option value="pinecone">Pinecone</option>
            <option value="chroma">Chroma</option>
            <option value="qdrant">Qdrant</option>
            <option value="weaviate">Weaviate</option>
            <option value="milvus">Milvus</option>
          </optgroup>
        </select>
      </Field>

      {/* Memory Type (all backends) */}
      <Field label="Memory Type">
        <select
          className={INPUT_CLS}
          value={memoryType}
          onChange={(e) => set({ memory_type: e.target.value })}
        >
          {MEMORY_TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </Field>

      {memoryType === "window" && (
        <Field label="Window Size" hint="Number of recent messages to retain.">
          <input
            type="number"
            className={SHORT_CLS}
            min={1}
            max={100}
            value={windowSize}
            onChange={(e) => set({ window_size: parseInt(e.target.value, 10) || 10 })}
          />
        </Field>
      )}

      {/* Backend-specific fields */}
      {backend === "sqlite" && <SqliteFields config={config} onChange={onChange} />}
      {backend === "postgres" && <PostgresFields config={config} onChange={onChange} />}
      {backend === "mongodb" && <MongoFields config={config} onChange={onChange} />}
      {backend === "pinecone" && <PineconeFields config={config} onChange={onChange} />}
      {backend === "chroma" && <ChromaFields config={config} onChange={onChange} />}
      {backend === "qdrant" && <QdrantFields config={config} onChange={onChange} />}
      {backend === "weaviate" && <WeaviateFields config={config} onChange={onChange} />}
      {backend === "milvus" && <MilvusFields config={config} onChange={onChange} />}
    </div>
  );
}
