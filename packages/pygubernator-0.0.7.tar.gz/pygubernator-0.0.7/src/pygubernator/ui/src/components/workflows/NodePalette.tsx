"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useWorkflowNodeTypes } from "@/hooks/useWorkflowNodeTypes";

interface NodePaletteProps {
  onAddNode: (type: string) => void;
}

export default function NodePalette({ onAddNode }: NodePaletteProps) {
  const { nodeTypes } = useWorkflowNodeTypes();

  const handleDragStart = (e: React.DragEvent, type: string) => {
    e.dataTransfer.setData("application/pygubernator-node-type", type);
    e.dataTransfer.effectAllowed = "move";
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Nodes</CardTitle>
        <p className="text-xs text-muted-foreground">Drag onto canvas or click to add</p>
      </CardHeader>
      <CardContent className="space-y-1.5">
        {nodeTypes.map((nt) => (
          <div
            key={nt.type_name}
            draggable
            onDragStart={(e) => handleDragStart(e, nt.type_name)}
            onClick={() => onAddNode(nt.type_name)}
            className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg border border-transparent
                       hover:border-border hover:bg-muted/50 cursor-grab active:cursor-grabbing
                       transition-colors select-none"
          >
            <div
              className="w-3 h-3 rounded-full shrink-0"
              style={{ backgroundColor: nt.color ?? "#94a3b8" }}
            />
            <div className="min-w-0">
              <div className="text-sm font-medium leading-tight">{nt.display_name}</div>
              <div className="text-[11px] text-muted-foreground leading-tight">{nt.description}</div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
