"use client";

import { useEffect, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import { useWorkflowNodeTypes } from "@/hooks/useWorkflowNodeTypes";
import { getWorkflowCategoryLabel, getWorkflowNodeTypeMeta } from "@/lib/workflow-node-types";
import { validateNodeSpec } from "@/lib/workflow-validation";
import type { SpecNode, WorkflowNodeFieldItem } from "@/lib/types/workflow";
import { configFormRegistry, type TypedNodeConfigFormProps } from "@/components/workflows/config-forms";

interface NodeConfigFormProps {
  nodeId: string;
  nodeSpec: SpecNode;
  onUpdateConfig: (config: Record<string, unknown>) => void;
  onRemoveNode: () => void;
}

function MetadataFieldInput({
  field,
  value,
  onChange,
}: {
  field: WorkflowNodeFieldItem;
  value: unknown;
  onChange: (value: unknown) => void;
}) {
  const commonClassName =
    "flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm";

  if (field.field_type === "boolean") {
    return (
      <label className="inline-flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={Boolean(value)}
          onChange={(e) => onChange(e.target.checked)}
        />
        <span>{field.label}</span>
      </label>
    );
  }

  if (field.field_type === "select") {
    return (
      <select
        className={commonClassName}
        value={typeof value === "string" ? value : String(field.default ?? "")}
        onChange={(e) => onChange(e.target.value)}
      >
        {(field.options ?? []).map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    );
  }

  if (field.field_type === "json") {
    return (
      <textarea
        className="flex min-h-[110px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
        placeholder={field.placeholder ?? '{"key":"value"}'}
        value={typeof value === "string" ? value : JSON.stringify(value ?? field.default ?? {}, null, 2)}
        onChange={(e) => onChange(e.target.value)}
      />
    );
  }

  if (field.field_type === "code") {
    return (
      <textarea
        className="flex min-h-[140px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
        placeholder={field.placeholder ?? "Enter code..."}
        value={typeof value === "string" ? value : String(field.default ?? "")}
        onChange={(e) => onChange(e.target.value)}
      />
    );
  }

  if (field.field_type === "number") {
    return (
      <input
        type="number"
        className={commonClassName}
        value={typeof value === "number" ? value : Number(field.default ?? 0)}
        onChange={(e) => onChange(e.target.value === "" ? "" : Number(e.target.value))}
      />
    );
  }

  return (
    <input
      className={commonClassName}
      placeholder={field.placeholder ?? field.label}
      value={typeof value === "string" ? value : String(field.default ?? "")}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

function MetadataDrivenForm({
  fields,
  config,
  onChange,
}: {
  fields: WorkflowNodeFieldItem[];
  config: Record<string, unknown>;
  onChange: (config: Record<string, unknown>) => void;
}) {
  return (
    <div className="space-y-3">
      {fields.map((field) => (
        <div key={field.name} className="space-y-1">
          {field.field_type !== "boolean" && (
            <label className="text-sm font-medium flex items-center gap-2">
              <span>{field.label}</span>
              {field.required && <Badge variant="outline" className="px-1.5 py-0 text-[10px]">Required</Badge>}
            </label>
          )}
          <MetadataFieldInput
            field={field}
            value={config[field.name]}
            onChange={(nextValue) => onChange({ ...config, [field.name]: nextValue })}
          />
          {field.help_text && (
            <p className="text-[11px] text-muted-foreground">{field.help_text}</p>
          )}
        </div>
      ))}
    </div>
  );
}

/** Reusable form content: typed or metadata-driven config + JSON Advanced tab. */
export function NodeConfigForm({ nodeId, nodeSpec, onUpdateConfig, onRemoveNode }: NodeConfigFormProps) {
  const [tab, setTab] = useState<"config" | "advanced">("config");
  const [configText, setConfigText] = useState("{}");
  const { nodeTypes } = useWorkflowNodeTypes();

  useEffect(() => {
    setConfigText(JSON.stringify(nodeSpec.config ?? {}, null, 2));
  }, [nodeSpec, nodeId]);

  const meta =
    nodeTypes.find((item) => item.type_name === nodeSpec.type) ??
    getWorkflowNodeTypeMeta(nodeSpec.type);
  const TypedForm = configFormRegistry[nodeSpec.type] as
    | React.ComponentType<TypedNodeConfigFormProps>
    | undefined;
  const metadataFields = meta.fields ?? [];
  const validationIssues = validateNodeSpec(nodeSpec, meta);
  const missingRequired = validationIssues.filter((issue) => issue.code === "required_field_missing");
  const canShowGuided = Boolean(TypedForm) || metadataFields.length > 0;

  const applyConfig = () => {
    try {
      const parsed = JSON.parse(configText);
      onUpdateConfig(parsed);
    } catch {
      // keep current text, user can fix
    }
  };

  const handleTabSwitch = (next: "config" | "advanced") => {
    if (next === "advanced") {
      setConfigText(JSON.stringify(nodeSpec.config ?? {}, null, 2));
    } else if (next === "config" && tab === "advanced") {
      // Attempt to apply advanced JSON before switching back
      try {
        const parsed = JSON.parse(configText);
        onUpdateConfig(parsed);
      } catch {
        // keep as-is
      }
    }
    setTab(next);
  };

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-border/60 bg-muted/20 p-3 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div>
            <div className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              Configuration
            </div>
            <div className="text-sm font-medium">
              {meta.display_name} in {getWorkflowCategoryLabel(meta.category)}
            </div>
          </div>
          <div className="flex gap-1.5">
            {metadataFields.length > 0 && (
              <Badge variant="secondary">{metadataFields.length} fields</Badge>
            )}
            {missingRequired.length > 0 ? (
              <Badge variant="destructive">{missingRequired.length} missing</Badge>
            ) : (
              <Badge variant="outline">ready</Badge>
            )}
          </div>
        </div>
        {missingRequired.length > 0 ? (
          <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
            Missing required fields: {missingRequired.map((issue) => issue.message.replace(" is required", "")).join(", ")}
          </div>
        ) : (
          <div className="text-xs text-muted-foreground">
            Guided configuration is available for this node. Advanced JSON remains available for raw edits.
          </div>
        )}
      </div>

      {canShowGuided && (
        <div className="flex gap-1 border-b pb-1">
          <button
            className={`text-xs px-2 py-1 rounded-t transition-colors ${
              tab === "config" ? "bg-muted font-medium" : "text-muted-foreground hover:text-foreground"
            }`}
            onClick={() => handleTabSwitch("config")}
          >
            Config
          </button>
          <button
            className={`text-xs px-2 py-1 rounded-t transition-colors ${
              tab === "advanced" ? "bg-muted font-medium" : "text-muted-foreground hover:text-foreground"
            }`}
            onClick={() => handleTabSwitch("advanced")}
          >
            Advanced
          </button>
        </div>
      )}

      {tab === "config" && TypedForm ? (
        <TypedForm config={nodeSpec.config ?? {}} onChange={onUpdateConfig} />
      ) : tab === "config" && metadataFields.length > 0 ? (
        <MetadataDrivenForm
          fields={metadataFields}
          config={nodeSpec.config ?? {}}
          onChange={onUpdateConfig}
        />
      ) : (
        <div className="flex flex-col gap-1">
          <label className="text-sm text-muted-foreground">Configuration (JSON)</label>
          <textarea
            className="flex min-h-[200px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background font-mono placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            value={configText}
            onChange={(e) => setConfigText(e.target.value)}
          />
          <Button size="sm" onClick={applyConfig}>Apply</Button>
        </div>
      )}

      <div className="flex gap-2 pt-1">
        <Button size="sm" variant="destructive" onClick={onRemoveNode}>
          <Trash2 className="h-4 w-4 mr-1" /> Remove
        </Button>
      </div>
    </div>
  );
}

interface NodeConfigPanelProps {
  nodeId: string | null;
  nodeSpec: SpecNode | null;
  onUpdateConfig: (config: Record<string, unknown>) => void;
  onRemoveNode: () => void;
}

export default function NodeConfigPanel({ nodeId, nodeSpec, onUpdateConfig, onRemoveNode }: NodeConfigPanelProps) {
  if (!nodeId || !nodeSpec) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Node config</CardTitle>
          <CardDescription>Select a node to configure</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Click a node on the canvas to view and edit its configuration.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{nodeId}</CardTitle>
        <CardDescription>Type: {nodeSpec.type}</CardDescription>
      </CardHeader>
      <CardContent>
        <NodeConfigForm
          nodeId={nodeId}
          nodeSpec={nodeSpec}
          onUpdateConfig={onUpdateConfig}
          onRemoveNode={onRemoveNode}
        />
      </CardContent>
    </Card>
  );
}
