"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowRightLeft,
  Brain,
  ChevronDown,
  ChevronRight,
  Database,
  FilePlus2,
  FolderOpen,
  FolderPlus,
  GitBranch,
  LayoutGrid,
  MessageSquare,
  Plus,
  RefreshCw,
  Wrench,
} from "lucide-react";
import { useWorkflowNodeTypes } from "@/hooks/useWorkflowNodeTypes";
import { SidebarHeaderWithToggle } from "@/components/layout/SidebarHeaderWithToggle";
import type { SidebarLayoutApi } from "@/components/layout/ResizableWorkspaceLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiGet, apiPost } from "@/lib/api";
import { ROUTES } from "@/lib/constants";
import type { WorkflowNodeTypeItem } from "@/lib/types/workflow";
import { getWorkflowCategoryLabel } from "@/lib/workflow-node-types";
import { cn, formatDateTimeShort } from "@/lib/utils";

/* ---------- Node type definition ---------- */

interface NodeTypeItem {
  type: string;
  label: string;
  description: string;
  color: string;
}

/* ---------- Categorized node palette data ---------- */

interface NodeCategory {
  id: string;
  label: string;
  icon: typeof ArrowRightLeft;
  defaultOpen: boolean;
  nodes: NodeTypeItem[];
}

const CATEGORY_META: Record<string, Pick<NodeCategory, "label" | "icon" | "defaultOpen">> = {
  io: { label: "I/O", icon: ArrowRightLeft, defaultOpen: true },
  logic: { label: "Logic & Control", icon: GitBranch, defaultOpen: true },
  processing: { label: "Processing", icon: Wrench, defaultOpen: true },
  ai: { label: "AI & LLM", icon: Brain, defaultOpen: true },
  chat_models: { label: "Chat Models", icon: MessageSquare, defaultOpen: false },
  memory: { label: "Memory", icon: Database, defaultOpen: false },
  tools: { label: "Tools", icon: Wrench, defaultOpen: false },
};

/* ---------- Tab definitions ---------- */

type SidebarTab = "components" | "browser";
type CreateMode = "none" | "workflow" | "folder";

const SIDEBAR_TABS: Array<{ id: SidebarTab; label: string; icon: typeof LayoutGrid }> = [
  { id: "components", label: "Components", icon: LayoutGrid },
  { id: "browser", label: "Browser", icon: FolderOpen },
];

/* ---------- Types ---------- */

interface WorkflowBrowserItem {
  id: string;
  name: string;
  owner: string;
  status: string;
  created_at: string;
}

interface WorkflowEditorSidebarProps extends SidebarLayoutApi {
  onAddNode: (type: string) => void;
}

function toNodeItem(node: WorkflowNodeTypeItem): NodeTypeItem {
  return {
    type: node.type_name,
    label: node.display_name,
    description: node.description,
    color: node.color ?? "#94a3b8",
  };
}

function buildNodeCategories(nodeTypes: WorkflowNodeTypeItem[]): NodeCategory[] {
  const grouped = new Map<string, NodeTypeItem[]>();
  for (const node of nodeTypes) {
    const bucket = grouped.get(node.category) ?? [];
    bucket.push(toNodeItem(node));
    grouped.set(node.category, bucket);
  }
  return Array.from(grouped.entries())
    .map(([id, nodes]) => {
      const meta = CATEGORY_META[id] ?? { label: id, icon: LayoutGrid, defaultOpen: false };
      return {
        id,
        label: meta.label,
        icon: meta.icon,
        defaultOpen: meta.defaultOpen,
        nodes: nodes.sort((a, b) => a.label.localeCompare(b.label)),
      };
    })
    .sort((a, b) => a.label.localeCompare(b.label));
}

/* ---------- Component ---------- */

export default function WorkflowEditorSidebar({
  isPanelCollapsed,
  sidebarDisplayMode,
  onCollapseRequested,
  onExpandRequested,
  onAddNode,
}: WorkflowEditorSidebarProps) {
  const [tab, setTab] = useState<SidebarTab>("components");

  const isExpanded = sidebarDisplayMode === "expanded";
  const isCompact = sidebarDisplayMode === "compact";
  const isCollapsed = sidebarDisplayMode === "collapsed";

  return (
    <div className="flex flex-col h-full">
      <SidebarHeaderWithToggle
        isCollapsed={isPanelCollapsed}
        displayMode={sidebarDisplayMode}
        onToggle={isPanelCollapsed ? onExpandRequested : onCollapseRequested}
      >
        {/* Tab toggle — matching pycharter/pystator pattern */}
        <div className="flex rounded-lg border border-border/70 bg-background/50 p-0.5" role="tablist" aria-label="Sidebar mode">
          {SIDEBAR_TABS.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-label={item.label}
                title={item.label}
                aria-selected={active}
                onClick={() => setTab(item.id)}
                className={cn(
                  "inline-flex h-7 shrink-0 items-center rounded-md transition-colors text-xs font-medium",
                  isCompact ? "justify-center px-2 w-7" : "gap-1.5 px-2.5",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon className="h-3.5 w-3.5" />
                {!isCompact && <span>{item.label}</span>}
              </button>
            );
          })}
        </div>
      </SidebarHeaderWithToggle>

      {tab === "components" ? (
        <ComponentsTab
          isExpanded={isExpanded}
          isCompact={isCompact}
          isCollapsed={isCollapsed}
          onAddNode={onAddNode}
        />
      ) : (
        <BrowserTab
          isExpanded={isExpanded}
          isCollapsed={isCollapsed}
        />
      )}
    </div>
  );
}

/* ---------- Node row (shared between categories and flat search results) ---------- */

function NodeRow({
  node,
  isExpanded,
  isCollapsed,
  onAddNode,
  onDragStart,
}: {
  node: NodeTypeItem;
  isExpanded: boolean;
  isCollapsed: boolean;
  onAddNode: (type: string) => void;
  onDragStart: (e: React.DragEvent, type: string) => void;
}) {
  return (
    <div
      draggable={!isCollapsed}
      onDragStart={(e) => onDragStart(e, node.type)}
      className={cn(
        "group relative flex items-center gap-2 rounded-md border",
        "cursor-grab active:cursor-grabbing transition-colors select-none",
        "border-border/40 bg-background/70 hover:border-border hover:bg-muted/35",
        isCollapsed ? "justify-center px-1 py-2" : "px-2.5 py-1.5",
      )}
      title={isCollapsed ? node.label : undefined}
    >
      <div
        className="w-3 h-3 rounded-full shrink-0"
        style={{ backgroundColor: node.color }}
      />
      {!isCollapsed && (
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <div className="text-[13px] font-semibold leading-tight">{node.label}</div>
            {node.type.startsWith("chat_model_") && (
              <span className="rounded-full border border-border/70 bg-background/80 px-1.5 py-0.5 text-[9px] uppercase tracking-wide text-muted-foreground">
                model
              </span>
            )}
          </div>
          {isExpanded && (
            <div className="text-[11px] text-muted-foreground/90 leading-tight">
              {node.description}
            </div>
          )}
        </div>
      )}
      <Button
        type="button"
        variant="ghost"
        size="sm"
        draggable={false}
        title={isCollapsed ? `Add ${node.label}` : "Add to canvas"}
        aria-label={isCollapsed ? `Add ${node.label} to canvas` : `Add ${node.label} to canvas`}
        onClick={(e) => {
          e.stopPropagation();
          onAddNode(node.type);
        }}
        onPointerDown={(e) => e.stopPropagation()}
        className={cn(
          "shrink-0 p-0 h-7 w-7 text-muted-foreground hover:text-foreground",
          "opacity-0 pointer-events-none transition-opacity group-hover:opacity-100 group-hover:pointer-events-auto",
          "focus-visible:opacity-100 focus-visible:pointer-events-auto",
          isCollapsed && "absolute right-0 top-1/2 -translate-y-1/2",
        )}
      >
        <Plus className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}

/* ---------- Collapsible category group ---------- */

function CategoryGroup({
  category,
  isExpanded,
  isCompact,
  isCollapsed,
  onAddNode,
  onDragStart,
}: {
  category: NodeCategory;
  isExpanded: boolean;
  isCompact: boolean;
  isCollapsed: boolean;
  onAddNode: (type: string) => void;
  onDragStart: (e: React.DragEvent, type: string) => void;
}) {
  const [open, setOpen] = useState(category.defaultOpen);
  const Icon = category.icon;

  if (isCollapsed) {
    // In collapsed mode, show just colored dots
    return (
      <div className="space-y-0.5">
        {category.nodes.map((node) => (
          <NodeRow
            key={node.type}
            node={node}
            isExpanded={false}
            isCollapsed
            onAddNode={onAddNode}
            onDragStart={onDragStart}
          />
        ))}
      </div>
    );
  }

  return (
    <div
      className={cn(
        "rounded-md transition-colors",
        open
          ? "bg-muted/20"
          : "bg-transparent",
      )}
    >
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className={cn(
          "flex items-center gap-1.5 w-full text-left rounded-md px-2.5 py-2 transition-colors",
          "hover:bg-muted/50",
          open ? "text-foreground" : "text-muted-foreground hover:text-foreground",
        )}
      >
        {open ? (
          <ChevronDown className="h-3 w-3 shrink-0" />
        ) : (
          <ChevronRight className="h-3 w-3 shrink-0" />
        )}
        <Icon className="h-3.5 w-3.5 shrink-0" />
        <span className="text-xs font-semibold uppercase tracking-wide">
          {isCompact ? category.label.split(" ")[0] : category.label}
        </span>
        <span className="ml-auto inline-flex items-center rounded-sm border border-border/60 bg-background/80 px-1.5 py-0.5 text-[10px] text-muted-foreground tabular-nums">
          {category.nodes.length}
        </span>
      </button>

      {open && (
        <div className="ml-2 mb-1.5 mr-1.5 border-l-2 border-border/70 pl-2">
          <div className="space-y-0.5">
          {category.nodes.map((node) => (
            <NodeRow
              key={node.type}
              node={node}
              isExpanded={isExpanded}
              isCollapsed={false}
              onAddNode={onAddNode}
              onDragStart={onDragStart}
            />
          ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Components tab (categorized node palette) ---------- */

function ComponentsTab({
  isExpanded,
  isCompact,
  isCollapsed,
  onAddNode,
}: {
  isExpanded: boolean;
  isCompact: boolean;
  isCollapsed: boolean;
  onAddNode: (type: string) => void;
}) {
  const [search, setSearch] = useState("");
  const { nodeTypes } = useWorkflowNodeTypes();

  const nodeCategories = useMemo(() => buildNodeCategories(nodeTypes), [nodeTypes]);
  const allNodes = useMemo(
    () => nodeCategories.flatMap((category) => category.nodes),
    [nodeCategories],
  );

  const handleDragStart = (e: React.DragEvent, type: string) => {
    e.dataTransfer.setData("application/pygubernator-node-type", type);
    e.dataTransfer.effectAllowed = "move";
  };

  const isSearching = search.trim().length > 0;

  const filteredNodes = useMemo(() => {
    if (!isSearching) return [];
    const q = search.toLowerCase();
    return allNodes.filter(
      (nt) =>
        nt.label.toLowerCase().includes(q) ||
        nt.description.toLowerCase().includes(q) ||
        nt.type.toLowerCase().includes(q),
    );
  }, [allNodes, search, isSearching]);

  return (
    <>
      {!isCollapsed && (
        <div className="px-2 pb-1 pt-1 space-y-2">
          <input
            className="flex h-8 w-full rounded-md border border-input bg-background px-2 py-1 text-xs placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            placeholder="Search nodes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
        {isSearching ? (
          /* Flat search results */
          filteredNodes.length === 0 ? (
            <div className="text-xs text-muted-foreground text-center py-4">
              No matching nodes
            </div>
          ) : (
            <div className="space-y-0.5">
              {filteredNodes.map((node) => (
                <NodeRow
                  key={node.type}
                  node={node}
                  isExpanded={isExpanded}
                  isCollapsed={isCollapsed}
                  onAddNode={onAddNode}
                  onDragStart={handleDragStart}
                />
              ))}
            </div>
          )
        ) : (
          /* Categorized groups */
          <div className="space-y-1.5">
            {nodeCategories.map((cat) => (
            <CategoryGroup
              key={cat.id}
              category={cat}
              isExpanded={isExpanded}
              isCompact={isCompact}
              isCollapsed={isCollapsed}
              onAddNode={onAddNode}
              onDragStart={handleDragStart}
            />
            ))}
          </div>
        )}
      </div>

      {!isCollapsed && (
        <div className="px-3 py-2 border-t border-border/50">
          <p className="text-[11px] text-muted-foreground">
            {isCompact ? "Drag or + to add" : "Drag onto canvas, hover and click +, then inspect capabilities in the right panel"}
          </p>
        </div>
      )}
    </>
  );
}

/* ---------- Browser tab (workflow list + create) ---------- */

function BrowserTab({
  isExpanded,
  isCollapsed,
}: {
  isExpanded: boolean;
  isCollapsed: boolean;
}) {
  const router = useRouter();
  const [workflows, setWorkflows] = useState<WorkflowBrowserItem[]>([]);
  const [workflowPaths, setWorkflowPaths] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [newName, setNewName] = useState("");
  const [newFolderName, setNewFolderName] = useState("");
  const [creating, setCreating] = useState(false);
  const [creatingFolder, setCreatingFolder] = useState(false);
  const [selectedFolderPath, setSelectedFolderPath] = useState<string | null>(null);
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set());
  const [sectionCollapsed, setSectionCollapsed] = useState(false);
  const [createMode, setCreateMode] = useState<CreateMode>("none");
  const newWorkflowInputRef = useRef<HTMLInputElement>(null);
  const newFolderInputRef = useRef<HTMLInputElement>(null);
  const createControlsRef = useRef<HTMLDivElement>(null);
  const [browserError, setBrowserError] = useState<string | null>(null);
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string | null>(null);
  const [dragOverFolderPath, setDragOverFolderPath] = useState<string | null>(null);
  const [isRootDropActive, setIsRootDropActive] = useState(false);

  const normalizePath = (value: string): string =>
    value
      .split("/")
      .map((s) => s.trim())
      .filter(Boolean)
      .join("/");

  const bumpPatchVersion = (version: string): string => {
    const parts = version.split(".");
    if (parts.length !== 3) return `${version}.1`;
    const patch = Number.parseInt(parts[2] ?? "0", 10);
    if (Number.isNaN(patch)) return `${version}.1`;
    return `${parts[0]}.${parts[1]}.${patch + 1}`;
  };

  const readWorkflowPath = useCallback(async (workflowId: string): Promise<string> => {
    const versions = await apiGet<{ items: Array<{ version: string; spec_json: Record<string, unknown>; active: boolean }> }>(
      `/api/v1/workflows/${workflowId}/versions`,
    );
    const active = versions.items.find((v) => v.active) ?? versions.items[0];
    const meta = (active?.spec_json?.meta as Record<string, unknown> | undefined) ?? {};
    return typeof meta.path === "string" ? normalizePath(meta.path) : "";
  }, []);

  const persistWorkflowPath = async (workflowId: string, path: string) => {
    const versions = await apiGet<{ items: Array<{ version: string; spec_json: Record<string, unknown>; active: boolean }> }>(
      `/api/v1/workflows/${workflowId}/versions`,
    );
    const base = versions.items.find((v) => v.active) ?? versions.items[0];
    const baseVersion = base?.version ?? "1.0.0";
    const nextVersion = bumpPatchVersion(baseVersion);
    const spec = (base?.spec_json ?? { meta: {}, nodes: {}, edges: [] }) as Record<string, unknown>;
    const meta = { ...((spec.meta as Record<string, unknown> | undefined) ?? {}) };
    const cleaned = normalizePath(path);
    if (cleaned) meta.path = cleaned;
    else delete meta.path;
    await apiPost<{ version: string; spec_json: Record<string, unknown> }, { id: string }>(
      `/api/v1/workflows/${workflowId}/versions`,
      { version: nextVersion, spec_json: { ...spec, meta } },
    );
  };

  const loadWorkflows = useCallback(async () => {
    setLoading(true);
    setBrowserError(null);
    try {
      const data = await apiGet<{ items: WorkflowBrowserItem[] }>("/api/v1/workflows", {
        page_size: 100,
      });
      const items = data.items.filter((w) => w.status !== "deleted");
      setWorkflows(items);
      const entries = await Promise.all(
        items.map(async (wf) => [wf.id, await readWorkflowPath(wf.id)] as const),
      );
      const nextPaths: Record<string, string> = {};
      entries.forEach(([id, path]) => {
        nextPaths[id] = path;
      });
      setWorkflowPaths(nextPaths);
      const folders = new Set<string>();
      Object.values(nextPaths).forEach((path) => {
        if (!path) return;
        const segs = path.split("/");
        for (let i = 1; i <= segs.length; i += 1) {
          folders.add(segs.slice(0, i).join("/"));
        }
      });
      setExpandedFolders(folders);
    } catch {
      setBrowserError("Failed to load workflows");
    } finally {
      setLoading(false);
    }
  }, [readWorkflowPath]);

  useEffect(() => {
    loadWorkflows();
  }, [loadWorkflows]);

  useEffect(() => {
    if (createMode === "workflow") newWorkflowInputRef.current?.focus();
    if (createMode === "folder") newFolderInputRef.current?.focus();
  }, [createMode]);

  useEffect(() => {
    if (createMode === "none") return;
    const onPointerDown = (event: MouseEvent) => {
      const target = event.target as Node | null;
      if (!target) return;
      if (createControlsRef.current?.contains(target)) return;
      setCreateMode("none");
    };
    document.addEventListener("mousedown", onPointerDown);
    return () => document.removeEventListener("mousedown", onPointerDown);
  }, [createMode]);

  const createWorkflow = async (e: React.FormEvent) => {
    e.preventDefault();
    const name = newName.trim();
    if (!name) return;
    setCreating(true);
    try {
      const wf = await apiPost<{ name: string; owner: string }, WorkflowBrowserItem>(
        "/api/v1/workflows",
        { name, owner: "system" },
      );
      await apiPost<{ version: string; spec_json: Record<string, unknown> }, { id: string }>(
        `/api/v1/workflows/${wf.id}/versions`,
        {
          version: "1.0.0",
          spec_json: {
            meta: {
              name: wf.name,
              version: "1.0.0",
              path: selectedFolderPath ?? "",
            },
            nodes: {},
            edges: [],
          },
        },
      );
      setNewName("");
      setCreateMode("none");
      router.push(`${ROUTES.WORKFLOW_EDITOR}?id=${encodeURIComponent(wf.id)}`);
    } catch {
      setBrowserError("Failed to create workflow");
    } finally {
      setCreating(false);
    }
  };

  const createFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    const name = newFolderName.trim();
    if (!name) return;
    setCreatingFolder(true);
    const next = normalizePath(selectedFolderPath ? `${selectedFolderPath}/${name}` : name);
    setExpandedFolders((prev) => new Set(prev).add(next));
    setSelectedFolderPath(next);
    setNewFolderName("");
    setCreateMode("none");
    setCreatingFolder(false);
  };

  const filtered = useMemo(() => {
    if (!search.trim()) return workflows;
    const q = search.toLowerCase();
    return workflows.filter(
      (w) => w.name.toLowerCase().includes(q) || w.owner.toLowerCase().includes(q),
    );
  }, [search, workflows]);

  const visibleWorkflows = useMemo(
    () =>
      filtered.filter((w) => {
        const path = workflowPaths[w.id] ?? "";
        if (!selectedFolderPath) return !path;
        return path === selectedFolderPath;
      }),
    [filtered, workflowPaths, selectedFolderPath],
  );

  const folders = useMemo(() => {
    const set = new Set<string>();
    filtered.forEach((w) => {
      const path = workflowPaths[w.id] ?? "";
      if (!path) return;
      const segs = path.split("/");
      for (let i = 1; i <= segs.length; i += 1) {
        set.add(segs.slice(0, i).join("/"));
      }
    });
    return Array.from(set).sort();
  }, [filtered, workflowPaths]);

  const foldersByParent = useMemo(() => {
    const grouped = new Map<string | null, string[]>();
    folders.forEach((path) => {
      const idx = path.lastIndexOf("/");
      const parent = idx === -1 ? null : path.slice(0, idx);
      const bucket = grouped.get(parent) ?? [];
      bucket.push(path);
      grouped.set(parent, bucket);
    });
    return grouped;
  }, [folders]);

  const handleDropOnFolder = async (event: React.DragEvent, targetPath: string) => {
    event.preventDefault();
    const payload = event.dataTransfer.getData("application/pygubernator-browser-item");
    if (!payload) return;
    try {
      const parsed = JSON.parse(payload) as { kind: "workflow" | "folder"; id: string };
      if (parsed.kind === "workflow") {
        await persistWorkflowPath(parsed.id, targetPath);
      } else {
        const sourcePath = parsed.id;
        if (sourcePath === targetPath || targetPath.startsWith(`${sourcePath}/`)) return;
        const affected = workflows.filter((w) => {
          const path = workflowPaths[w.id] ?? "";
          return path === sourcePath || path.startsWith(`${sourcePath}/`);
        });
        await Promise.all(
          affected.map((w) => {
            const current = workflowPaths[w.id] ?? "";
            const suffix = current.slice(sourcePath.length).replace(/^\/+/, "");
            const next = normalizePath(suffix ? `${targetPath}/${suffix}` : targetPath);
            return persistWorkflowPath(w.id, next);
          }),
        );
      }
      await loadWorkflows();
    } catch {
      setBrowserError("Move failed");
    } finally {
      setDragOverFolderPath(null);
    }
  };

  const handleDropToRoot = async (event: React.DragEvent) => {
    event.preventDefault();
    const payload = event.dataTransfer.getData("application/pygubernator-browser-item");
    if (!payload) return;
    try {
      const parsed = JSON.parse(payload) as { kind: "workflow" | "folder"; id: string };
      if (parsed.kind === "workflow") {
        await persistWorkflowPath(parsed.id, "");
      } else {
        const sourcePath = parsed.id;
        const affected = workflows.filter((w) => {
          const path = workflowPaths[w.id] ?? "";
          return path === sourcePath || path.startsWith(`${sourcePath}/`);
        });
        await Promise.all(
          affected.map((w) => {
            const current = workflowPaths[w.id] ?? "";
            const suffix = current.slice(sourcePath.length).replace(/^\/+/, "");
            return persistWorkflowPath(w.id, suffix);
          }),
        );
      }
      await loadWorkflows();
    } catch {
      setBrowserError("Move failed");
    } finally {
      setIsRootDropActive(false);
      setDragOverFolderPath(null);
    }
  };

  const toggleFolderOpen = (folderPath: string) => {
    setExpandedFolders((prev) => {
      const next = new Set(prev);
      if (next.has(folderPath)) next.delete(folderPath);
      else next.add(folderPath);
      return next;
    });
  };

  const renderFolderTree = (parentPath: string | null, depth = 0): React.ReactNode => {
    const children = foldersByParent.get(parentPath) ?? [];
    if (children.length === 0) return null;
    return children.map((folderPath) => {
      const isOpen = expandedFolders.has(folderPath);
      const isSelected = selectedFolderPath === folderPath;
      const label = folderPath.split("/").at(-1) ?? folderPath;
      return (
        <div key={folderPath}>
          <div
            className={cn(
              "group flex w-full items-center gap-1 rounded-md px-1.5 py-1 text-xs transition-colors",
              isSelected
                ? "bg-primary/10 text-foreground"
                : "text-muted-foreground hover:bg-muted/50 hover:text-foreground",
              dragOverFolderPath === folderPath && "bg-primary/15 ring-1 ring-primary/40",
            )}
            style={{ paddingLeft: `${6 + depth * 14}px` }}
            draggable
            onDragStart={(evt) => {
              evt.dataTransfer.setData(
                "application/pygubernator-browser-item",
                JSON.stringify({ kind: "folder", id: folderPath }),
              );
              evt.dataTransfer.effectAllowed = "move";
            }}
            onDragOver={(evt) => {
              evt.preventDefault();
              setDragOverFolderPath(folderPath);
            }}
            onDragLeave={() => {
              setDragOverFolderPath((prev) => (prev === folderPath ? null : prev));
            }}
            onDrop={(evt) => void handleDropOnFolder(evt, folderPath)}
          >
            <button
              type="button"
              className="inline-flex items-center"
              onClick={(evt) => {
                evt.stopPropagation();
                toggleFolderOpen(folderPath);
              }}
              aria-label={isOpen ? "Collapse folder" : "Expand folder"}
            >
              {isOpen ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
            </button>
            <FolderOpen className="h-3.5 w-3.5 shrink-0" />
            <button
              type="button"
              className="flex-1 truncate text-left"
              onClick={() => setSelectedFolderPath(folderPath)}
            >
              {label}
            </button>
          </div>
          {isOpen && renderFolderTree(folderPath, depth + 1)}
        </div>
      );
    });
  };

  if (isCollapsed) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <FolderOpen className="h-4 w-4 text-muted-foreground" />
      </div>
    );
  }

  return (
    <>
      {/* Search */}
      <div className="px-2 pb-1 pt-1">
        <input
          className="flex h-8 w-full rounded-md border border-input bg-background px-2 py-1 text-xs placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
          placeholder="Search workflows..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div ref={createControlsRef} className="px-2 pb-1">
        <div className="flex items-center gap-1.5 px-2 py-1.5">
          <button
            type="button"
            onClick={() => setSectionCollapsed(!sectionCollapsed)}
            className="flex flex-1 items-center gap-1.5 text-left"
          >
            {sectionCollapsed ? (
              <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
            ) : (
              <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
            )}
            <GitBranch className="h-3.5 w-3.5" />
            <span className="text-xs font-semibold uppercase tracking-wider">Workflows</span>
          </button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-5 w-5 p-0"
            title="New workflow"
            onClick={() =>
              setCreateMode((prev) => (prev === "workflow" ? "none" : "workflow"))
            }
          >
            <FilePlus2 className="h-3 w-3" />
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-5 w-5 p-0"
            title="New folder"
            onClick={() =>
              setCreateMode((prev) => (prev === "folder" ? "none" : "folder"))
            }
          >
            <FolderPlus className="h-3 w-3" />
          </Button>
        </div>
      </div>

      {!sectionCollapsed && (
        <>
          {createMode === "workflow" && (
            <div className="px-2 pb-1">
              <form className="flex gap-1" onSubmit={(e) => void createWorkflow(e)}>
                <Input
                  ref={newWorkflowInputRef}
                  className="h-8 text-xs flex-1"
                  placeholder={selectedFolderPath ? "New workflow in folder..." : "New workflow name..."}
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                />
                <Button
                  type="submit"
                  variant="outline"
                  size="sm"
                  className="h-8 px-2 shrink-0"
                  disabled={creating || !newName.trim()}
                >
                  <Plus className="h-3.5 w-3.5" />
                </Button>
              </form>
            </div>
          )}
          {createMode === "folder" && (
            <div className="px-2 pb-2">
              <form className="flex gap-1" onSubmit={(e) => void createFolder(e)}>
                <Input
                  ref={newFolderInputRef}
                  className="h-8 text-xs flex-1"
                  placeholder={selectedFolderPath ? "New subfolder..." : "New folder..."}
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                />
                <Button
                  type="submit"
                  variant="outline"
                  size="sm"
                  className="h-8 px-2 shrink-0"
                  disabled={creatingFolder || !newFolderName.trim()}
                >
                  <FolderPlus className="h-3.5 w-3.5" />
                </Button>
              </form>
            </div>
          )}
          <div
            className={cn(
              "px-2 pb-1 rounded-md",
              isRootDropActive && "bg-primary/10 ring-1 ring-primary/40",
            )}
            onDragOver={(evt) => {
              evt.preventDefault();
              setIsRootDropActive(true);
            }}
            onDragLeave={() => setIsRootDropActive(false)}
            onDrop={(evt) => void handleDropToRoot(evt)}
          >
            <div className="mt-1 space-y-0.5">{renderFolderTree(null, 0)}</div>
          </div>
        </>
      )}

      {/* Workflow list */}
      <div className="flex-1 overflow-y-auto px-2 space-y-0.5">
        {browserError && (
          <div className="rounded-md border border-destructive/30 bg-destructive/10 px-2 py-1 text-[11px] text-destructive">
            {browserError}
          </div>
        )}
        {loading && (
          <div className="text-xs text-muted-foreground text-center py-4">
            Loading...
          </div>
        )}
        {!loading && visibleWorkflows.length === 0 && (
          <div className="text-xs text-muted-foreground text-center py-4">
            {workflows.length === 0 ? "No workflows yet" : "No matches in this folder"}
          </div>
        )}
        {visibleWorkflows.map((wf) => (
          <button
            key={wf.id}
            type="button"
            onClick={() => setSelectedWorkflowId(wf.id)}
            onDoubleClick={() =>
              router.push(`${ROUTES.WORKFLOW_EDITOR}?id=${encodeURIComponent(wf.id)}`)
            }
            draggable
            onDragStart={(evt) => {
              evt.dataTransfer.setData(
                "application/pygubernator-browser-item",
                JSON.stringify({ kind: "workflow", id: wf.id }),
              );
              evt.dataTransfer.effectAllowed = "move";
            }}
            className={cn(
              "flex flex-col w-full text-left rounded-lg border border-transparent px-3 py-2 hover:border-border hover:bg-muted/50 transition-colors",
              selectedWorkflowId === wf.id && "bg-primary/10 border-primary/30",
            )}
          >
            <div className="text-sm font-medium leading-tight truncate">{wf.name}</div>
            {isExpanded && (
              <div className="text-[11px] text-muted-foreground leading-tight mt-0.5">
                {wf.owner} · {formatDateTimeShort(wf.created_at)}
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Footer */}
      <div className="px-2 py-2 border-t border-border/50 flex items-center justify-between">
        <p className="text-[11px] text-muted-foreground">
          {visibleWorkflows.length} workflow{visibleWorkflows.length !== 1 ? "s" : ""}
        </p>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 px-1.5"
          onClick={() => void loadWorkflows()}
          disabled={loading}
        >
          <RefreshCw className={cn("h-3 w-3", loading && "animate-spin")} />
        </Button>
      </div>
    </>
  );
}
