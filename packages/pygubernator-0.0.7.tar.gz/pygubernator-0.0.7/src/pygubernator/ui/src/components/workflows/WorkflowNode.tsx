"use client";

import {
  type NodeProps,
  Handle,
  Position,
} from "@xyflow/react";
import type { WorkflowValidationIssue } from "@/lib/workflow-validation";
import { getWorkflowCategoryLabel, getWorkflowNodeTypeMeta } from "@/lib/workflow-node-types";
import { cn } from "@/lib/utils";

/* ---------- Colour map ---------- */

export const TYPE_COLORS: Record<string, { bg: string; border: string; text: string }> = {
  input:     { bg: "#dbeafe", border: "#60a5fa", text: "#1e40af" },
  output:    { bg: "#dcfce7", border: "#4ade80", text: "#166534" },
  template:  { bg: "#f3e8ff", border: "#c084fc", text: "#6b21a8" },
  condition: { bg: "#fef9c3", border: "#facc15", text: "#854d0e" },
  code:      { bg: "#ffedd5", border: "#fb923c", text: "#9a3412" },
  python_exec: { bg: "#dbeafe", border: "#3776ab", text: "#1e3a5f" },
  router:    { bg: "#fce7f3", border: "#f472b6", text: "#9d174d" },
  loop:      { bg: "#cffafe", border: "#22d3ee", text: "#155e75" },
  map:       { bg: "#ccfbf1", border: "#2dd4bf", text: "#115e59" },
  http:      { bg: "#fee2e2", border: "#f87171", text: "#991b1b" },
  gsheets:   { bg: "#dcfce7", border: "#0f9d58", text: "#14532d" },
  llm:                 { bg: "#e0e7ff", border: "#818cf8", text: "#3730a3" },
  agent:               { bg: "#fdf2f8", border: "#e879f9", text: "#86198f" },
  chat_model_openai:   { bg: "#d1fae5", border: "#10a37f", text: "#065f46" },
  chat_model_anthropic:{ bg: "#fef3c7", border: "#d97706", text: "#92400e" },
  chat_model_gemini:   { bg: "#dbeafe", border: "#4285f4", text: "#1e40af" },
  chat_model_ollama:   { bg: "#f1f5f9", border: "#808080", text: "#334155" },
  chat_model_deepseek: { bg: "#dbeafe", border: "#1a73e8", text: "#1e3a5f" },
  chat_model_glm:      { bg: "#fff4e6", border: "#ff6b35", text: "#8b3e1a" },
  chat_model_openai_compat: { bg: "#f3f4f6", border: "#6b7280", text: "#374151" },
  memory:              { bg: "#fef3c7", border: "#f59e0b", text: "#92400e" },
  tool:                { bg: "#d1fae5", border: "#34d399", text: "#065f46" },
  tool_gsheets:        { bg: "#dcfce7", border: "#0f9d58", text: "#14532d" },
  tool_gdocs:          { bg: "#dbeafe", border: "#4285f4", text: "#1e40af" },
  tool_slack:          { bg: "#f3e8ff", border: "#4a154b", text: "#581c87" },
  tool_notion:         { bg: "#f5f5f5", border: "#191919", text: "#171717" },
  tool_sql:            { bg: "#dbeafe", border: "#336791", text: "#1e3a5f" },
  tool_http:           { bg: "#fee2e2", border: "#f87171", text: "#991b1b" },
  tool_python:         { bg: "#dbeafe", border: "#3776ab", text: "#1e3a5f" },
  tool_obsidian:       { bg: "#f3e8ff", border: "#7c3aed", text: "#5b21b6" },
  tool_catalyst:       { bg: "#fef3c7", border: "#f59e0b", text: "#92400e" },
  tool_stator:         { bg: "#f3e8ff", border: "#8b5cf6", text: "#5b21b6" },
};

export const DEFAULT_COLOR = { bg: "#f1f5f9", border: "#94a3b8", text: "#334155" };

const STATUS_BADGE: Record<string, { icon: string; color: string; glow: string }> = {
  completed: { icon: "\u2713", color: "#16a34a", glow: "rgba(22,163,74,0.3)" },
  success:   { icon: "\u2713", color: "#16a34a", glow: "rgba(22,163,74,0.3)" },
  failed:    { icon: "\u2717", color: "#dc2626", glow: "rgba(220,38,38,0.3)" },
  running:   { icon: "\u25CB", color: "#ca8a04", glow: "rgba(202,138,4,0.3)" },
  pending:   { icon: "\u25CB", color: "#9ca3af", glow: "rgba(156,163,175,0.2)" },
  skipped:   { icon: "\u2014", color: "#9ca3af", glow: "rgba(156,163,175,0.2)" },
};

const VALIDATION_BADGE: Record<string, { icon: string; color: string; bg: string; text: string }> = {
  error: { icon: "!", color: "#dc2626", bg: "#fef2f2", text: "#991b1b" },
  warning: { icon: "!", color: "#d97706", bg: "#fffbeb", text: "#92400e" },
};

/* ---------- Custom node component ---------- */

export function WorkflowNode({ data, selected }: NodeProps) {
  const nodeData = data as {
    label: string;
    nodeType: string;
    runStatus?: string;
    runDuration?: number | null;
    validationSeverity?: "error" | "warning";
    validationCount?: number;
    validationIssues?: WorkflowValidationIssue[];
  };
  const color = TYPE_COLORS[nodeData.nodeType] ?? DEFAULT_COLOR;
  const meta = getWorkflowNodeTypeMeta(nodeData.nodeType);
  const badge = nodeData.runStatus ? STATUS_BADGE[nodeData.runStatus] ?? null : null;
  const validationBadge = nodeData.validationSeverity
    ? VALIDATION_BADGE[nodeData.validationSeverity]
    : null;
  const isSubNode = nodeData.nodeType.startsWith("chat_model_") || nodeData.nodeType.startsWith("tool_") || nodeData.nodeType === "memory" || nodeData.nodeType === "tool";
  const isGSheets = nodeData.nodeType === "gsheets";
  const isLlm = nodeData.nodeType === "llm" || nodeData.nodeType === "agent";
  const hasLeftInput = isLlm || nodeData.nodeType === "input" || nodeData.nodeType === "output";

  const SUB_PORTS = [
    { id: "sub:chat_model", label: "Model", left: "20%", color: "#a78bfa" },
    { id: "sub:memory",     label: "Memory", left: "50%", color: "#f59e0b" },
    { id: "sub:tool",       label: "Tool", left: "80%", color: "#34d399" },
  ];

  return (
    <div
      className={cn(
        "relative px-4 rounded-xl border-2 shadow-sm min-w-[160px] transition-shadow",
        isLlm ? "pt-3 pb-7" : "py-3",
        selected && "shadow-lg ring-2 ring-blue-500",
      )}
      style={{
        backgroundColor: color.bg,
        borderColor: validationBadge?.color ?? badge?.color ?? color.border,
        boxShadow: validationBadge
          ? `0 0 0 2px ${validationBadge.bg}, 0 0 12px ${validationBadge.color}33`
          : badge
            ? `0 0 8px ${badge.glow}`
            : undefined,
      }}
    >
      {/* gsheets: left data in, top → Agent Tool port, right data out */}
      {isGSheets ? (
        <>
          <Handle
            type="target"
            position={Position.Left}
            className="!w-3 !h-3 !bg-slate-400 !border-2 !border-white"
            style={{ top: "50%" }}
          />
          <Handle
            type="source"
            position={Position.Top}
            className="!w-3 !h-3 !border-2 !border-white"
            style={{ backgroundColor: "#34d399" }}
          />
          <div
            className="absolute text-[8px] font-semibold pointer-events-none text-emerald-800"
            style={{ left: "50%", top: 2, transform: "translateX(-50%)" }}
          >
            Tool → Agent
          </div>
        </>
      ) : isSubNode ? (
        <Handle type="source" position={Position.Top} className="!w-3 !h-3 !bg-slate-400 !border-2 !border-white" />
      ) : (
        <Handle
          type="target"
          position={hasLeftInput ? Position.Left : Position.Top}
          className="!w-3 !h-3 !bg-slate-400 !border-2 !border-white"
          style={hasLeftInput ? { top: "50%" } : undefined}
        />
      )}
      {/* Bottom / side sources */}
      {isGSheets ? (
        <Handle
          type="source"
          position={Position.Right}
          className="!w-3 !h-3 !bg-slate-400 !border-2 !border-white"
          style={{ top: "50%" }}
        />
      ) : isSubNode ? null : nodeData.nodeType === "condition" ? (
        <>
          <Handle
            type="source"
            position={Position.Bottom}
            id="true"
            className="!w-3 !h-3 !bg-green-500 !border-2 !border-white"
            style={{ left: "30%" }}
          />
          <Handle
            type="source"
            position={Position.Bottom}
            id="false"
            className="!w-3 !h-3 !bg-red-400 !border-2 !border-white"
            style={{ left: "70%" }}
          />
        </>
      ) : (
        <Handle
          type="source"
          position={Position.Right}
          className="!w-3 !h-3 !bg-slate-400 !border-2 !border-white"
          style={hasLeftInput ? { top: "50%" } : undefined}
        />
      )}
      {/* LLM/Agent sub-node target ports at bottom */}
      {isLlm && SUB_PORTS.map((port) => (
        <div key={port.id}>
          <Handle
            type="target"
            position={Position.Bottom}
            id={port.id}
            className="!w-3 !h-3 !border-2 !border-white"
            style={{ left: port.left, backgroundColor: port.color }}
          />
          <div
            className="absolute text-[8px] font-medium pointer-events-none"
            style={{ left: port.left, bottom: 2, transform: "translateX(-50%)", color: port.color }}
          >
            {port.label}
          </div>
        </div>
      ))}
      {badge && (
        <div
          className="absolute -top-2 -right-2 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
          style={{ backgroundColor: badge.color }}
        >
          {badge.icon}
        </div>
      )}
      {validationBadge && (
        <div
          className="absolute -top-2 -left-2 min-w-5 h-5 rounded-full flex items-center justify-center px-1 text-[10px] font-bold border"
          style={{
            color: validationBadge.text,
            backgroundColor: validationBadge.bg,
            borderColor: validationBadge.color,
          }}
          title={nodeData.validationIssues?.map((issue) => issue.message).join("\n")}
        >
          {validationBadge.icon}
          {(nodeData.validationCount ?? 0) > 1 ? (
            <span className="ml-0.5">{nodeData.validationCount}</span>
          ) : null}
        </div>
      )}
      <div className="flex items-center justify-between gap-2 mb-1">
        <div className="text-[10px] uppercase tracking-widest font-semibold" style={{ color: color.border }}>
          {meta.display_name}
        </div>
        <div className="rounded-full border border-white/70 bg-white/70 px-1.5 py-0.5 text-[9px] font-medium text-slate-600">
          {getWorkflowCategoryLabel(meta.category)}
        </div>
      </div>
      <div className="text-sm font-medium truncate max-w-[180px]" style={{ color: color.text }}>
        {nodeData.label}
      </div>
      <div className="mt-1 flex flex-wrap gap-1">
        {validationBadge && (
          <span
            className="rounded-full px-1.5 py-0.5 text-[9px] font-medium"
            style={{ backgroundColor: validationBadge.bg, color: validationBadge.text }}
          >
            {nodeData.validationCount} validation {nodeData.validationCount === 1 ? "issue" : "issues"}
          </span>
        )}
        {meta.supports_streaming && (
          <span className="rounded-full bg-white/80 px-1.5 py-0.5 text-[9px] font-medium text-slate-600">
            streaming
          </span>
        )}
        {meta.supports_checkpointing && (
          <span className="rounded-full bg-white/80 px-1.5 py-0.5 text-[9px] font-medium text-slate-600">
            resumable
          </span>
        )}
        {meta.runtime_kind === "config_only" && (
          <span className="rounded-full bg-white/80 px-1.5 py-0.5 text-[9px] font-medium text-slate-600">
            config
          </span>
        )}
      </div>
      {badge && nodeData.runDuration != null && (
        <div className="text-[10px] text-muted-foreground mt-0.5">
          {nodeData.runDuration}ms
        </div>
      )}
    </div>
  );
}
