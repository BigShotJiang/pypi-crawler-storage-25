"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for Mock Data (pycatalyst) tool sub-nodes. */
export function ToolCatalystForm({ config, onChange }: TypedNodeConfigFormProps) {
  const name = typeof config.name === "string" ? config.name : "catalyst";

  const ctx = (
    typeof config.context === "object" && config.context !== null
      ? config.context
      : {}
  ) as Record<string, string | undefined>;

  const setCtx = (newCtx: Record<string, string | undefined>) => {
    const cleaned: Record<string, string> = {};
    for (const [k, v] of Object.entries(newCtx)) {
      if (v) cleaned[k] = v;
    }
    onChange({
      ...config,
      context: Object.keys(cleaned).length > 0 ? cleaned : undefined,
    });
  };

  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
        <div className="font-medium text-foreground mb-1">Mock Data (pycatalyst)</div>
        Generate mock data from named schemas. Provides 2 tools: generate_data and build_schema.
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Tool Name</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={name}
          onChange={(e) => onChange({ ...config, name: e.target.value })}
        />
      </div>

      {/* --- Context (optional) --- */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          Context (optional)
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Schema Names</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            placeholder="users,orders,products"
            value={ctx.schema_names ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, schema_names: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Comma-separated list of schemas to use (e.g. users,orders).
          </p>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Record Count</label>
          <input
            type="number"
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            placeholder="10"
            value={ctx.record_count ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, record_count: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Default number of records to generate per request.
          </p>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground">
        Optionally set env var{" "}
        <code className="rounded bg-muted px-1">PYGUBERNATOR_CATALYST_SCHEMAS_PATH</code>{" "}
        for custom schemas.
      </p>
    </div>
  );
}
