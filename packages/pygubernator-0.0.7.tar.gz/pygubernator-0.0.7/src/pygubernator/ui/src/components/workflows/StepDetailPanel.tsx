"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

interface StepItem {
  id: string;
  workflow_run_id: string;
  node_id: string;
  node_type: string;
  status: string;
  input_json: Record<string, unknown>;
  output_json: Record<string, unknown>;
  error_message: string | null;
  output_handle: string;
  started_at: string | null;
  completed_at: string | null;
  duration_ms: number | null;
}

interface StepDetailPanelProps {
  step: StepItem | null;
}

export default function StepDetailPanel({ step }: StepDetailPanelProps) {
  if (!step) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Step detail</CardTitle>
          <CardDescription>Select a step to inspect</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Click a step in the table or DAG to view its details.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{step.node_id}</CardTitle>
        <CardDescription>
          {step.node_type} · {step.status} · handle: {step.output_handle}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4 text-sm">
        <div>
          <h4 className="font-medium text-muted-foreground mb-1">Timing</h4>
          <dl className="grid grid-cols-2 gap-x-4 gap-y-1">
            <dt className="text-muted-foreground">Duration</dt>
            <dd>{step.duration_ms != null ? `${step.duration_ms}ms` : "—"}</dd>
            <dt className="text-muted-foreground">Started</dt>
            <dd className="font-mono text-xs">{step.started_at ?? "—"}</dd>
            <dt className="text-muted-foreground">Completed</dt>
            <dd className="font-mono text-xs">{step.completed_at ?? "—"}</dd>
          </dl>
        </div>

        <div>
          <h4 className="font-medium text-muted-foreground mb-1">Input</h4>
          <pre className="text-xs bg-muted rounded-md p-2 overflow-auto max-h-40">
            {JSON.stringify(step.input_json, null, 2)}
          </pre>
        </div>

        <div>
          <h4 className="font-medium text-muted-foreground mb-1">Output</h4>
          <pre className="text-xs bg-muted rounded-md p-2 overflow-auto max-h-40">
            {JSON.stringify(step.output_json, null, 2)}
          </pre>
        </div>

        {step.error_message && (
          <div>
            <h4 className="font-medium text-red-600 mb-1">Error</h4>
            <pre className="text-xs bg-red-50 dark:bg-red-900/20 rounded-md p-2 text-red-600 whitespace-pre-wrap">
              {step.error_message}
            </pre>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
