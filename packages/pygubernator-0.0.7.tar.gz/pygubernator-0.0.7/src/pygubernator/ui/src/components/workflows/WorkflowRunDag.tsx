"use client";

import { cn } from "@/lib/utils";

interface StepItem {
  node_id: string;
  node_type: string;
  status: string;
  duration_ms: number | null;
}

interface WorkflowRunDagProps {
  steps: StepItem[];
  selectedStep: string | null;
  onSelectStep: (nodeId: string) => void;
}

const STATUS_COLORS: Record<string, string> = {
  completed: "bg-green-100 border-green-500 dark:bg-green-900/30 dark:border-green-500",
  success: "bg-green-100 border-green-500 dark:bg-green-900/30 dark:border-green-500",
  failed: "bg-red-100 border-red-500 dark:bg-red-900/30 dark:border-red-500",
  running: "bg-yellow-100 border-yellow-500 dark:bg-yellow-900/30 dark:border-yellow-500",
  skipped: "bg-gray-100 border-gray-400 dark:bg-gray-800/30 dark:border-gray-500",
  pending: "bg-gray-50 border-gray-300 dark:bg-gray-800/20 dark:border-gray-600",
};

export default function WorkflowRunDag({ steps, selectedStep, onSelectStep }: WorkflowRunDagProps) {
  if (steps.length === 0) {
    return (
      <div className="flex items-center justify-center h-32 text-muted-foreground border border-dashed rounded-lg">
        No steps recorded
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-3 p-4 border rounded-lg bg-muted/20 min-h-[120px]">
      {steps.map((step, idx) => {
        const colorClass = STATUS_COLORS[step.status] ?? STATUS_COLORS.pending;
        return (
          <div key={step.node_id + idx} className="flex items-center gap-2">
            <button
              type="button"
              className={cn(
                "px-3 py-2 rounded-lg border-2 text-sm shadow-sm transition-all min-w-[120px] text-center",
                colorClass,
                selectedStep === step.node_id && "ring-2 ring-primary shadow-md"
              )}
              onClick={() => onSelectStep(step.node_id)}
            >
              <div className="text-xs text-muted-foreground uppercase tracking-wide">{step.node_type}</div>
              <div className="font-medium truncate">{step.node_id}</div>
              {step.duration_ms != null && (
                <div className="text-xs text-muted-foreground">{step.duration_ms}ms</div>
              )}
            </button>
            {idx < steps.length - 1 && (
              <svg className="w-6 h-6 text-border shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M5 12h14m-4-4 4 4-4 4" />
              </svg>
            )}
          </div>
        );
      })}
    </div>
  );
}
