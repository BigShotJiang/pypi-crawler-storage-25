"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for HTTP / REST tool sub-nodes. */
export function ToolHttpForm({ config, onChange }: TypedNodeConfigFormProps) {
  const name = typeof config.name === "string" ? config.name : "http";

  const ctx = (
    typeof config.context === "object" && config.context !== null
      ? config.context
      : {}
  ) as Record<string, string | undefined>;

  const setCtx = (newCtx: Record<string, string | undefined>) => {
    const cleaned: Record<string, string> = {};
    for (const [k, v] of Object.entries(newCtx)) {
      if (v) cleaned[k] = v;
    }
    onChange({
      ...config,
      context: Object.keys(cleaned).length > 0 ? cleaned : undefined,
    });
  };

  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
        <div className="font-medium text-foreground mb-1">HTTP / REST</div>
        Make GET, POST, PUT, and DELETE requests to any API. Provides 4 tools.
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Tool Name</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={name}
          onChange={(e) => onChange({ ...config, name: e.target.value })}
        />
      </div>

      {/* --- Context (optional) --- */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          Context (optional)
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Base URL</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
            placeholder="https://api.example.com/v1"
            value={ctx.base_url ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, base_url: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            All requests will be relative to this URL.
          </p>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Default Headers (JSON)</label>
          <textarea
            className="flex min-h-[60px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
            placeholder='{"Authorization": "Bearer ..."}'
            value={ctx.default_headers ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, default_headers: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Headers to include with every request (JSON object).
          </p>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground">
        Optionally set env var <code className="rounded bg-muted px-1">PYGUBERNATOR_HTTP_BASE_URL</code> on the server.
      </p>
    </div>
  );
}
