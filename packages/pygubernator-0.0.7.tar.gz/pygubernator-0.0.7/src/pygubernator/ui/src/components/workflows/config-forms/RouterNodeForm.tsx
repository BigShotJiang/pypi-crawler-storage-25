"use client";

import { useCallback } from "react";
import type { TypedNodeConfigFormProps } from "./index";

interface RouteEntry {
  condition: string;
  handle: string;
}

/** Config form for router nodes: dynamic routes with conditions. */
export function RouterNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const routes: RouteEntry[] = Array.isArray(config.routes)
    ? (config.routes as RouteEntry[])
    : [];
  const defaultHandle = typeof config.default_handle === "string"
    ? config.default_handle
    : "default";

  const updateRoutes = useCallback(
    (next: RouteEntry[]) => onChange({ ...config, routes: next }),
    [config, onChange],
  );

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Routes</label>
        {routes.map((r, idx) => (
          <div key={idx} className="flex gap-1">
            <input
              className="flex h-8 flex-1 rounded-md border border-input bg-background px-2 py-1 text-xs font-mono"
              placeholder="condition"
              value={r.condition}
              onChange={(e) => {
                const next = [...routes];
                next[idx] = { ...r, condition: e.target.value };
                updateRoutes(next);
              }}
            />
            <input
              className="flex h-8 w-24 rounded-md border border-input bg-background px-2 py-1 text-xs"
              placeholder="handle"
              value={r.handle}
              onChange={(e) => {
                const next = [...routes];
                next[idx] = { ...r, handle: e.target.value };
                updateRoutes(next);
              }}
            />
            <button
              className="h-8 px-2 text-xs text-destructive hover:bg-destructive/10 rounded"
              onClick={() => updateRoutes(routes.filter((_, i) => i !== idx))}
            >
              X
            </button>
          </div>
        ))}
        <button
          className="text-xs text-primary hover:underline self-start"
          onClick={() => updateRoutes([...routes, { condition: "", handle: "" }])}
        >
          + Add Route
        </button>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Default Handle</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={defaultHandle}
          onChange={(e) => onChange({ ...config, default_handle: e.target.value })}
        />
      </div>
    </div>
  );
}
