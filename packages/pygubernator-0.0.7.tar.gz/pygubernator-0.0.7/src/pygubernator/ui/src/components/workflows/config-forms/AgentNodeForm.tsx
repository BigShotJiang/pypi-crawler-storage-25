"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for Agent nodes: task, allowed Python packages, system prompt, iteration limit. */
export function AgentNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const taskDescription =
    typeof config.task_description === "string" ? config.task_description : "";
  const packages =
    typeof config.packages === "string" ? config.packages : "";
  const systemPrompt =
    typeof config.system_prompt === "string" ? config.system_prompt : "";
  const maxIterations =
    typeof config.max_iterations === "number" ? config.max_iterations : 10;

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Task Description</label>
        <textarea
          className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          placeholder="Analyze the uploaded CSV and produce a summary report..."
          value={taskDescription}
          onChange={(e) =>
            onChange({ ...config, task_description: e.target.value })
          }
        />
        <p className="text-[11px] text-muted-foreground">
          Describe the task or prompt template. Use {"{{ variable }}"} to
          reference input fields (e.g. {"{{ message }}"}).
        </p>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Allowed Packages</label>
        <textarea
          className="flex min-h-[60px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
          placeholder="pandas, numpy, matplotlib, scikit-learn"
          value={packages}
          onChange={(e) =>
            onChange({ ...config, packages: e.target.value })
          }
        />
        <p className="text-[11px] text-muted-foreground">
          Comma-separated Python packages the agent may import and use.
        </p>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">System Prompt</label>
        <textarea
          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          placeholder="You are a data analyst agent. Write and execute Python code to complete the task."
          value={systemPrompt}
          onChange={(e) =>
            onChange({ ...config, system_prompt: e.target.value })
          }
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Max Iterations</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          min={1}
          max={50}
          value={maxIterations}
          onChange={(e) =>
            onChange({ ...config, max_iterations: Number(e.target.value) })
          }
        />
        <p className="text-[11px] text-muted-foreground">
          Maximum code-execution loop iterations before stopping.
        </p>
      </div>
    </div>
  );
}
