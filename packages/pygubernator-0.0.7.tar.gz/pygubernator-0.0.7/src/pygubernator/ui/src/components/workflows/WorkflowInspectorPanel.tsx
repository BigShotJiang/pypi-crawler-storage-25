"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { X } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { NodeConfigForm } from "@/components/workflows/NodeConfigPanel";
import { useWorkflowNodeTypes } from "@/hooks/useWorkflowNodeTypes";
import type { SpecNode, StepItem } from "@/lib/types/workflow";
import { getWorkflowCategoryLabel, getWorkflowNodeTypeMeta } from "@/lib/workflow-node-types";

interface WorkflowInspectorPanelProps {
  nodeId: string | null;
  nodeSpec: SpecNode | null;
  onUpdateConfig: (config: Record<string, unknown>) => void;
  onRemoveNode: () => void;
  onClose: () => void;
  runStep?: StepItem | null;
}

const MIN_WIDTH = 280;

const STATUS_COLORS: Record<string, string> = {
  completed: "text-green-600 bg-green-50",
  success: "text-green-600 bg-green-50",
  failed: "text-red-600 bg-red-50",
  running: "text-yellow-600 bg-yellow-50",
  pending: "text-gray-500 bg-gray-50",
  skipped: "text-gray-400 bg-gray-50",
};

export default function WorkflowInspectorPanel({
  nodeId,
  nodeSpec,
  onUpdateConfig,
  onRemoveNode,
  onClose,
  runStep,
}: WorkflowInspectorPanelProps) {
  const [width, setWidth] = useState(340);
  const dragRef = useRef<{ startX: number; startWidth: number } | null>(null);
  const { nodeTypes } = useWorkflowNodeTypes();

  const onMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      dragRef.current = { startX: e.clientX, startWidth: width };

      const onMouseMove = (ev: MouseEvent) => {
        if (!dragRef.current) return;
        const delta = dragRef.current.startX - ev.clientX;
        const next = Math.max(MIN_WIDTH, dragRef.current.startWidth + delta);
        setWidth(Math.min(next, window.innerWidth * 0.8));
      };

      const onMouseUp = () => {
        dragRef.current = null;
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
      };

      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    },
    [width],
  );

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [onClose]);

  if (!nodeId || !nodeSpec) return null;

  const meta = nodeTypes.find((item) => item.type_name === nodeSpec.type) ?? getWorkflowNodeTypeMeta(nodeSpec.type);
  const inputs = meta.inputs ?? [];
  const outputs = meta.outputs ?? [];
  const fields = meta.fields ?? [];

  return (
    <div
      className="absolute top-0 right-0 bottom-0 z-20 flex bg-background border-l shadow-lg"
      style={{
        width,
        animation: "inspectorSlideIn 0.2s ease-out",
      }}
    >
      <div
        className="w-1.5 shrink-0 cursor-col-resize hover:bg-primary/50 active:bg-primary transition-colors"
        onMouseDown={onMouseDown}
      />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-muted/30 shrink-0">
          <div className="min-w-0">
            <div className="text-sm font-semibold truncate">{nodeId}</div>
            <div className="text-xs text-muted-foreground">{meta.display_name} · {getWorkflowCategoryLabel(meta.category)}</div>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose} className="shrink-0 h-7 w-7 p-0">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <div className="rounded-xl border border-border/60 bg-gradient-to-br from-background via-muted/20 to-background p-3 space-y-3">
            <div className="space-y-1">
              <div className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                Node Profile
              </div>
              <div className="text-sm text-foreground">{meta.description}</div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <Badge variant="secondary">{getWorkflowCategoryLabel(meta.category)}</Badge>
              {meta.supports_streaming && <Badge variant="outline">Streaming</Badge>}
              {meta.supports_checkpointing && <Badge variant="outline">Resumable</Badge>}
              {meta.runtime_kind === "config_only" && <Badge variant="muted">Config-only</Badge>}
              {meta.supports_subgraph && <Badge variant="outline">Subgraph</Badge>}
            </div>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="rounded-lg bg-muted/40 p-2">
                <div className="text-muted-foreground">Inputs</div>
                <div className="mt-1 font-semibold">{inputs.length}</div>
              </div>
              <div className="rounded-lg bg-muted/40 p-2">
                <div className="text-muted-foreground">Outputs</div>
                <div className="mt-1 font-semibold">{outputs.length}</div>
              </div>
              <div className="rounded-lg bg-muted/40 p-2">
                <div className="text-muted-foreground">Fields</div>
                <div className="mt-1 font-semibold">{fields.length}</div>
              </div>
            </div>
            {(inputs.length > 0 || outputs.length > 0) && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Inputs</div>
                  <div className="space-y-1">
                    {inputs.length === 0 ? (
                      <div className="text-xs text-muted-foreground">None</div>
                    ) : inputs.map((port) => (
                      <div key={`in-${port.name}`} className="rounded-md border border-border/50 px-2 py-1 text-xs">
                        <span className="font-medium">{port.label ?? port.name}</span>
                        <span className="ml-2 text-muted-foreground">{port.kind}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Outputs</div>
                  <div className="space-y-1">
                    {outputs.length === 0 ? (
                      <div className="text-xs text-muted-foreground">None</div>
                    ) : outputs.map((port) => (
                      <div key={`out-${port.name}`} className="rounded-md border border-border/50 px-2 py-1 text-xs">
                        <span className="font-medium">{port.label ?? port.name}</span>
                        <span className="ml-2 text-muted-foreground">{port.kind}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          <NodeConfigForm
            nodeId={nodeId}
            nodeSpec={nodeSpec}
            onUpdateConfig={onUpdateConfig}
            onRemoveNode={onRemoveNode}
          />

          {runStep && (
            <div className="space-y-2 border-t pt-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Last Run
              </h4>
              <div className="flex items-center gap-2">
                <span className={`text-xs font-medium px-2 py-0.5 rounded ${STATUS_COLORS[runStep.status] ?? "text-gray-500 bg-gray-50"}`}>
                  {runStep.status}
                </span>
                {runStep.duration_ms != null && (
                  <span className="text-xs text-muted-foreground">{runStep.duration_ms}ms</span>
                )}
              </div>
              {runStep.error_message && (
                <div className="text-xs text-red-600 bg-red-50 rounded p-2 whitespace-pre-wrap">
                  {runStep.error_message}
                </div>
              )}
              {Object.keys(runStep.input_json ?? {}).length > 0 && (
                <details className="group">
                  <summary className="text-xs font-medium cursor-pointer text-muted-foreground">
                    Input
                  </summary>
                  <pre className="mt-1 text-[11px] bg-muted/50 rounded p-2 overflow-auto max-h-[160px]">
                    {JSON.stringify(runStep.input_json, null, 2)}
                  </pre>
                </details>
              )}
              {Object.keys(runStep.output_json ?? {}).length > 0 && (
                <details className="group">
                  <summary className="text-xs font-medium cursor-pointer text-muted-foreground">
                    Output
                  </summary>
                  <pre className="mt-1 text-[11px] bg-muted/50 rounded p-2 overflow-auto max-h-[160px]">
                    {JSON.stringify(runStep.output_json, null, 2)}
                  </pre>
                </details>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
