"use client";

import { useEffect, useRef } from "react";

import type { TypedNodeConfigFormProps } from "./index";

const DEFAULT_OLLAMA_BASE = "http://localhost:11434/v1";

/** Config form for Ollama Chat Model sub-nodes (local/self-hosted models). */
export function OllamaChatModelForm({ config, onChange }: TypedNodeConfigFormProps) {
  const seeded = useRef(false);
  // Persist defaults so workflow merge includes base_url (backend uses OpenAI-compat, not LiteLLM).
  useEffect(() => {
    if (seeded.current) return;
    seeded.current = true;
    if (config.base_url !== undefined && config.base_url !== "") return;
    onChange({ ...config, base_url: DEFAULT_OLLAMA_BASE });
  }, [config, onChange]);

  const baseUrl = typeof config.base_url === "string"
    ? config.base_url
    : DEFAULT_OLLAMA_BASE;
  const modelName = typeof config.model_name === "string" ? config.model_name : "";
  const temperature = typeof config.temperature === "number" ? config.temperature : 0.7;
  const topK = typeof config.top_k === "number" ? config.top_k : "";
  const topP = typeof config.top_p === "number" ? config.top_p : "";

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Base URL</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          placeholder={DEFAULT_OLLAMA_BASE}
          value={baseUrl}
          onChange={(e) => onChange({ ...config, base_url: e.target.value })}
        />
        <p className="text-[11px] text-muted-foreground">
          Use host.docker.internal instead of localhost when running in Docker.
        </p>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Model Name</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          placeholder="llama3, mistral, codellama..."
          value={modelName}
          onChange={(e) => onChange({ ...config, model_name: e.target.value })}
        />
        <p className="text-[11px] text-muted-foreground">
          Enter any model you have pulled via <code>ollama pull</code>.
        </p>
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Temperature</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          min={0}
          max={2}
          step={0.1}
          value={temperature}
          onChange={(e) => onChange({ ...config, temperature: parseFloat(e.target.value) || 0 })}
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Top K</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          placeholder="Optional"
          value={topK}
          onChange={(e) => {
            const v = e.target.value;
            onChange({ ...config, top_k: v ? parseInt(v, 10) : undefined });
          }}
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Top P</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          min={0}
          max={1}
          step={0.05}
          placeholder="Optional"
          value={topP}
          onChange={(e) => {
            const v = e.target.value;
            onChange({ ...config, top_p: v ? parseFloat(v) : undefined });
          }}
        />
      </div>
    </div>
  );
}
