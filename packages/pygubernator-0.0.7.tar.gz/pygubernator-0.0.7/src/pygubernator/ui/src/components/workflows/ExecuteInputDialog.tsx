"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MessageSquare, Play, Plus, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { apiGet } from "@/lib/api";
import type { SpecJson } from "@/lib/types/workflow";

interface SessionItem {
  session_id: string;
  run_count: number;
  last_run_at: string | null;
}

interface ExecuteInputDialogProps {
  spec: SpecJson;
  busy: boolean;
  workflowId: string | null;
  onExecute: (inputJson: Record<string, unknown>, sessionId?: string) => void;
  onClose: () => void;
}

/** Extract input keys from all InputNode(s) in the workflow spec. */
function collectInputKeys(spec: SpecJson): string[] {
  const nodes = spec.nodes ?? {};
  const keys: string[] = [];
  for (const node of Object.values(nodes)) {
    if (node.type === "input" && Array.isArray(node.config?.keys)) {
      for (const k of node.config.keys as string[]) {
        if (k && !keys.includes(k)) keys.push(k);
      }
    }
  }
  return keys;
}

/** Check whether the workflow has LLM or Agent nodes. */
function hasLLMOrAgentNode(spec: SpecJson): boolean {
  const nodes = spec.nodes ?? {};
  return Object.values(nodes).some(
    (n) => n.type === "llm" || n.type === "agent",
  );
}

/** Check whether the workflow has memory nodes (explicit or sub-node). */
function hasMemoryNode(spec: SpecJson): boolean {
  const nodes = spec.nodes ?? {};
  return Object.values(nodes).some(
    (n) =>
      n.type === "memory" ||
      (n.config && typeof n.config === "object" && "memory" in n.config),
  );
}

function generateSessionId(): string {
  return crypto.randomUUID();
}

/**
 * Modal dialog that collects user input before executing a workflow.
 *
 * If the workflow has InputNode(s), renders a field per configured key.
 * Otherwise, if there are LLM/Agent nodes, shows a single prompt textarea.
 * If memory nodes exist, shows a session selector for multi-turn support.
 */
export function ExecuteInputDialog({
  spec,
  busy,
  workflowId,
  onExecute,
  onClose,
}: ExecuteInputDialogProps) {
  const inputKeys = useMemo(() => collectInputKeys(spec), [spec]);
  const showPrompt = inputKeys.length === 0 && hasLLMOrAgentNode(spec);
  const showSessions = useMemo(() => hasMemoryNode(spec), [spec]);

  const [values, setValues] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    for (const key of inputKeys) init[key] = "";
    if (showPrompt) init["message"] = "";
    return init;
  });

  const [sessions, setSessions] = useState<SessionItem[]>([]);
  const [selectedSession, setSelectedSession] = useState<string>("new");

  const firstRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  useEffect(() => {
    firstRef.current?.focus();
  }, []);

  // Load existing sessions when dialog opens
  useEffect(() => {
    if (!showSessions || !workflowId) return;
    let cancelled = false;
    void (async () => {
      try {
        const res = await apiGet<{ items: SessionItem[] }>(
          `/api/v1/workflows/${workflowId}/sessions`,
        );
        if (!cancelled) setSessions(res.items ?? []);
      } catch {
        // Ignore errors loading sessions
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [showSessions, workflowId]);

  const setField = useCallback((key: string, value: string) => {
    setValues((prev) => ({ ...prev, [key]: value }));
  }, []);

  const handleSubmit = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();
      const sessionId = showSessions
        ? selectedSession === "new"
          ? generateSessionId()
          : selectedSession
        : undefined;
      onExecute(values, sessionId);
    },
    [values, onExecute, showSessions, selectedSession],
  );

  const onKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      }
    },
    [onClose],
  );

  const fields =
    inputKeys.length > 0 ? inputKeys : showPrompt ? ["message"] : [];

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh] bg-black/40"
      onClick={onClose}
      onKeyDown={onKeyDown}
    >
      <div
        className="w-full max-w-lg rounded-lg border bg-background shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b px-4 py-3">
          <h2 className="text-sm font-semibold">Execute Workflow</h2>
          <button
            className="text-muted-foreground hover:text-foreground transition-colors"
            onClick={onClose}
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Session selector (only when memory nodes exist) */}
          {showSessions && (
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium flex items-center gap-1.5">
                <MessageSquare className="h-3.5 w-3.5" />
                Session
              </label>
              <select
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
                value={selectedSession}
                onChange={(e) => setSelectedSession(e.target.value)}
              >
                <option value="new">
                  New conversation
                </option>
                {sessions.map((s) => (
                  <option key={s.session_id} value={s.session_id}>
                    {s.session_id.slice(0, 8)}... ({s.run_count} run
                    {s.run_count !== 1 ? "s" : ""}
                    {s.last_run_at
                      ? ` · ${new Date(s.last_run_at).toLocaleDateString()}`
                      : ""})
                  </option>
                ))}
              </select>
              <p className="text-xs text-muted-foreground">
                {selectedSession === "new"
                  ? "Start a fresh conversation with no prior context."
                  : "Continue an existing conversation with memory."}
              </p>
            </div>
          )}

          {fields.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              This workflow has no input fields. It will execute with empty
              input.
            </p>
          ) : (
            fields.map((key, idx) => (
              <div key={key} className="flex flex-col gap-1.5">
                <label
                  className="text-sm font-medium"
                  htmlFor={`exec-${key}`}
                >
                  {key}
                </label>
                {key === "message" && showPrompt ? (
                  <textarea
                    ref={
                      idx === 0
                        ? (firstRef as React.Ref<HTMLTextAreaElement>)
                        : undefined
                    }
                    id={`exec-${key}`}
                    className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    placeholder="Type your prompt..."
                    value={values[key] ?? ""}
                    onChange={(e) => setField(key, e.target.value)}
                  />
                ) : (
                  <input
                    ref={
                      idx === 0
                        ? (firstRef as React.Ref<HTMLInputElement>)
                        : undefined
                    }
                    id={`exec-${key}`}
                    className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    placeholder={`Enter ${key}...`}
                    value={values[key] ?? ""}
                    onChange={(e) => setField(key, e.target.value)}
                  />
                )}
              </div>
            ))
          )}

          {/* Footer */}
          <div className="flex justify-end gap-2 pt-2">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={onClose}
              disabled={busy}
            >
              Cancel
            </Button>
            <Button type="submit" size="sm" disabled={busy}>
              {selectedSession === "new" || !showSessions ? (
                <Plus className="h-3.5 w-3.5 mr-1.5" />
              ) : (
                <Play className="h-3.5 w-3.5 mr-1.5" />
              )}
              {busy
                ? "Running..."
                : selectedSession === "new" || !showSessions
                  ? "Execute"
                  : "Continue"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
