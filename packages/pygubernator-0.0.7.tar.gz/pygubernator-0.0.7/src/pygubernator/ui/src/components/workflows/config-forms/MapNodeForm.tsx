"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for map nodes: parallel mapping over a collection. */
export function MapNodeForm({ config, onChange }: TypedNodeConfigFormProps) {
  const collectionKey = typeof config.collection_key === "string" ? config.collection_key : "";
  const itemKey = typeof config.item_key === "string" ? config.item_key : "item";
  const transform = typeof config.transform === "string" ? config.transform : "";
  const maxConcurrency = typeof config.max_concurrency === "number" ? config.max_concurrency : 5;

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Collection Key</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          placeholder="items"
          value={collectionKey}
          onChange={(e) => onChange({ ...config, collection_key: e.target.value })}
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Item Key</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={itemKey}
          onChange={(e) => onChange({ ...config, item_key: e.target.value })}
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Transform</label>
        <textarea
          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
          placeholder="Transform expression applied to each item"
          value={transform}
          onChange={(e) => onChange({ ...config, transform: e.target.value })}
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Max Concurrency</label>
        <input
          type="number"
          className="flex h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={maxConcurrency}
          min={1}
          max={100}
          onChange={(e) => onChange({ ...config, max_concurrency: parseInt(e.target.value, 10) || 5 })}
        />
      </div>
    </div>
  );
}
