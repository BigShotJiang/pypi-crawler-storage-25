"use client";

import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiPost, ApiError } from "@/lib/api";

interface NewChatFormProps {
  onCreated: (sessionId: string) => void;
  onCancel: () => void;
}

interface SessionResponse {
  id: string;
  title: string;
  model: string;
  message_count: number;
  created_at: string;
  updated_at: string;
}

export function NewChatForm({ onCreated, onCancel }: NewChatFormProps) {
  const [model, setModel] = useState("gpt-4o");
  const [title, setTitle] = useState("");
  const [systemPrompt, setSystemPrompt] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleCreate() {
    if (!model.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const session = await apiPost<
        { model: string; title: string; system_prompt: string },
        SessionResponse
      >("/api/v1/chat/sessions", {
        model: model.trim(),
        title: title.trim() || "New conversation",
        system_prompt: systemPrompt,
      });
      onCreated(session.id);
    } catch (e) {
      if (e instanceof ApiError) {
        setError(e.message);
      } else {
        setError(
          e instanceof Error ? e.message : "Failed to create session."
        );
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="p-4 space-y-4">
      <h3 className="text-sm font-semibold">New Chat Session</h3>

      {error && (
        <div className="rounded-md border border-red-200 bg-red-50 p-2 text-sm text-red-800">
          {error}
        </div>
      )}

      <div className="space-y-2">
        <label htmlFor="chat-model" className="text-sm font-medium">
          Model
        </label>
        <Input
          id="chat-model"
          placeholder="e.g. gpt-4o, claude-3-opus"
          value={model}
          onChange={(e) => setModel(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <label htmlFor="chat-title" className="text-sm font-medium">
          Title (optional)
        </label>
        <Input
          id="chat-title"
          placeholder="New conversation"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <label htmlFor="chat-system" className="text-sm font-medium">
          System Prompt (optional)
        </label>
        <textarea
          id="chat-system"
          className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          placeholder="You are a helpful assistant..."
          value={systemPrompt}
          onChange={(e) => setSystemPrompt(e.target.value)}
        />
      </div>

      <div className="flex gap-2">
        <Button variant="outline" size="sm" onClick={onCancel} disabled={saving}>
          Cancel
        </Button>
        <Button
          size="sm"
          onClick={() => void handleCreate()}
          disabled={saving || !model.trim()}
        >
          {saving ? "Creating..." : "Create"}
        </Button>
      </div>
    </div>
  );
}
