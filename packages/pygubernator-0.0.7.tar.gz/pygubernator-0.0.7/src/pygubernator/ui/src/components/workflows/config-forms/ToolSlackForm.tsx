"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for Slack tool sub-nodes. */
export function ToolSlackForm({ config, onChange }: TypedNodeConfigFormProps) {
  const name = typeof config.name === "string" ? config.name : "slack";

  const ctx = (
    typeof config.context === "object" && config.context !== null
      ? config.context
      : {}
  ) as Record<string, string | undefined>;

  const setCtx = (newCtx: Record<string, string | undefined>) => {
    const cleaned: Record<string, string> = {};
    for (const [k, v] of Object.entries(newCtx)) {
      if (v) cleaned[k] = v;
    }
    onChange({
      ...config,
      context: Object.keys(cleaned).length > 0 ? cleaned : undefined,
    });
  };

  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
        <div className="font-medium text-foreground mb-1">Slack</div>
        Send messages, read channels, and upload files. Provides 5 tools.
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Tool Name</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={name}
          onChange={(e) => onChange({ ...config, name: e.target.value })}
        />
      </div>

      {/* --- Context (optional) --- */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          Context (optional)
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Default Channel</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            placeholder="#general"
            value={ctx.default_channel ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, default_channel: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            The agent will post to this channel by default.
          </p>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Thread Timestamp</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm font-mono"
            placeholder="1234567890.123456"
            value={ctx.thread_ts ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, thread_ts: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Reply within a specific thread instead of posting to the channel.
          </p>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground">
        Set env var <code className="rounded bg-muted px-1">PYGUBERNATOR_SLACK_BOT_TOKEN</code> on the server.
      </p>
    </div>
  );
}
