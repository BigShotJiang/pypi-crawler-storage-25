"use client";

import { cn } from "@/lib/utils";

interface TimelineStep {
  node_id: string;
  node_type: string;
  status: string;
  duration_ms: number | null;
  started_at: string | null;
  completed_at: string | null;
}

interface RunTimelineProps {
  steps: TimelineStep[];
  totalDurationMs: number | null;
}

const STATUS_COLORS: Record<string, string> = {
  completed: "bg-green-500",
  success: "bg-green-500",
  failed: "bg-red-500",
  running: "bg-yellow-500",
  skipped: "bg-gray-400",
  pending: "bg-gray-300",
};

export default function RunTimeline({ steps, totalDurationMs }: RunTimelineProps) {
  if (steps.length === 0 || !totalDurationMs || totalDurationMs <= 0) {
    return (
      <div className="text-sm text-muted-foreground p-4 border border-dashed rounded-lg text-center">
        No timing data available
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-xs text-muted-foreground mb-1">
        <span>0ms</span>
        <span>{totalDurationMs}ms</span>
      </div>
      {steps.map((step, idx) => {
        const duration = step.duration_ms ?? 0;
        const widthPct = Math.max((duration / totalDurationMs) * 100, 2);
        const barColor = STATUS_COLORS[step.status] ?? STATUS_COLORS.pending;

        return (
          <div key={step.node_id + idx} className="flex items-center gap-2">
            <span className="w-28 text-xs text-right truncate text-muted-foreground">{step.node_id}</span>
            <div className="flex-1 h-5 bg-muted rounded overflow-hidden relative">
              <div
                className={cn("h-full rounded transition-all", barColor)}
                style={{ width: `${widthPct}%` }}
              />
              {duration > 0 && (
                <span className="absolute inset-0 flex items-center justify-center text-xs font-medium">
                  {duration}ms
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
