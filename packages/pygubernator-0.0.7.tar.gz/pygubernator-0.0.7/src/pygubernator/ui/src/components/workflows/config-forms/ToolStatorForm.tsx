"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for State Machine (pystator) tool sub-nodes. */
export function ToolStatorForm({ config, onChange }: TypedNodeConfigFormProps) {
  const name = typeof config.name === "string" ? config.name : "stator";

  const ctx = (
    typeof config.context === "object" && config.context !== null
      ? config.context
      : {}
  ) as Record<string, string | undefined>;

  const setCtx = (newCtx: Record<string, string | undefined>) => {
    const cleaned: Record<string, string> = {};
    for (const [k, v] of Object.entries(newCtx)) {
      if (v) cleaned[k] = v;
    }
    onChange({
      ...config,
      context: Object.keys(cleaned).length > 0 ? cleaned : undefined,
    });
  };

  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
        <div className="font-medium text-foreground mb-1">State Machine (pystator)</div>
        Create sessions, send events, and query state. Provides 4 tools.
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Tool Name</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={name}
          onChange={(e) => onChange({ ...config, name: e.target.value })}
        />
      </div>

      {/* --- Context (optional) --- */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          Context (optional)
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Machine Name</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            placeholder="order_lifecycle"
            value={ctx.machine_name ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, machine_name: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Default state machine to use for new sessions.
          </p>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Entity ID</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            placeholder="entity-001"
            value={ctx.entity_id ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, entity_id: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Default entity ID for session operations.
          </p>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground">
        Optionally set env var{" "}
        <code className="rounded bg-muted px-1">PYGUBERNATOR_STATOR_MACHINES_PATH</code>{" "}
        for custom machine definitions.
      </p>
    </div>
  );
}
