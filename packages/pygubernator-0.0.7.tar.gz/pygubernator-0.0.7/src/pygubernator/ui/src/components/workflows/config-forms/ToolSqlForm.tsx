"use client";

import type { TypedNodeConfigFormProps } from "./index";

/** Config form for SQL Database tool sub-nodes. */
export function ToolSqlForm({ config, onChange }: TypedNodeConfigFormProps) {
  const name = typeof config.name === "string" ? config.name : "sql";

  const ctx = (
    typeof config.context === "object" && config.context !== null
      ? config.context
      : {}
  ) as Record<string, string | undefined>;

  const setCtx = (newCtx: Record<string, string | undefined>) => {
    const cleaned: Record<string, string> = {};
    for (const [k, v] of Object.entries(newCtx)) {
      if (v) cleaned[k] = v;
    }
    onChange({
      ...config,
      context: Object.keys(cleaned).length > 0 ? cleaned : undefined,
    });
  };

  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
        <div className="font-medium text-foreground mb-1">SQL Database</div>
        Query databases, list tables, and describe schemas. Provides 5 tools.
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium">Tool Name</label>
        <input
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
          value={name}
          onChange={(e) => onChange({ ...config, name: e.target.value })}
        />
      </div>

      {/* --- Context (optional) --- */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          Context (optional)
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Default Schema</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            placeholder="public"
            value={ctx.default_schema ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, default_schema: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Scope queries to this database schema by default.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="sql-read-only"
            className="h-4 w-4 rounded border border-input"
            checked={ctx.read_only !== "false"}
            onChange={(e) =>
              setCtx({
                ...ctx,
                read_only: e.target.checked ? undefined : "false",
              })
            }
          />
          <label htmlFor="sql-read-only" className="text-sm font-medium">
            Read-Only Mode
          </label>
        </div>
        <p className="text-[11px] text-muted-foreground -mt-1">
          When enabled, the agent will only run SELECT queries. Enabled by default.
        </p>
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">Description</label>
          <input
            className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
            placeholder="Sales analytics database"
            value={ctx.description ?? ""}
            onChange={(e) =>
              setCtx({ ...ctx, description: e.target.value || undefined })
            }
          />
          <p className="text-[11px] text-muted-foreground">
            Help the agent understand what data this database contains.
          </p>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground">
        Set env var <code className="rounded bg-muted px-1">PYGUBERNATOR_SQL_CONNECTION_STRING</code> on the server.
      </p>
    </div>
  );
}
