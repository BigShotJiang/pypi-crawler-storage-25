"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ExternalLink, Loader2, OctagonX, X } from "lucide-react";

import { Button, buttonVariants } from "@/components/ui/button";
import { ROUTES } from "@/lib/constants";
import { cn } from "@/lib/utils";

interface RunRow {
  id: string;
  status: string;
  duration_ms: number | null;
  started_at: string | null;
  workflow_id: string;
}

interface StepRow {
  node_id: string;
  status: string;
}

interface WorkflowRunStatusBannerProps {
  workflowId: string;
  run: RunRow;
  steps: StepRow[];
  onStop: () => void | Promise<void>;
  onDismiss: () => void;
  stopBusy: boolean;
}

function Elapsed({ startedAt }: { startedAt: string | null }) {
  const [sec, setSec] = useState(0);
  useEffect(() => {
    if (!startedAt) return;
    const start = new Date(startedAt).getTime();
    const tick = () => setSec(Math.max(0, Math.floor((Date.now() - start) / 1000)));
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, [startedAt]);
  return <span className="tabular-nums">{sec}s</span>;
}

export function WorkflowRunStatusBanner({
  workflowId,
  run,
  steps,
  onStop,
  onDismiss,
  stopBusy,
}: WorkflowRunStatusBannerProps) {
  const status = run.status;
  const isActive = status === "running" || status === "pending";
  const completed = steps.filter(
    (s) => s.status === "success" || s.status === "completed",
  ).length;
  const lastNode = steps.length > 0 ? steps[steps.length - 1]?.node_id : null;

  const statusLabel =
    status === "running"
      ? "Running"
      : status === "pending"
        ? "Pending"
        : status === "completed"
          ? "Completed"
          : status === "cancelled"
            ? "Cancelled"
            : status === "failed"
              ? "Failed"
              : status;

  return (
    <div
      className={cn(
        "mb-4 flex flex-col gap-3 rounded-lg border px-4 py-3",
        isActive && "border-primary/40 bg-primary/5",
        status === "completed" && "border-green-500/30 bg-green-500/5",
        status === "failed" && "border-destructive/30 bg-destructive/5",
        status === "cancelled" && "border-muted-foreground/30 bg-muted/30",
      )}
    >
      <div className="flex flex-wrap items-center gap-2 text-sm">
        {isActive && (
          <Loader2 className="h-4 w-4 shrink-0 animate-spin text-primary" aria-hidden />
        )}
        <span className="font-medium">{statusLabel}</span>
        <span className="text-muted-foreground">
          run {run.id.slice(0, 8)}…
          {run.started_at && isActive && (
            <>
              {" "}
              · elapsed <Elapsed startedAt={run.started_at} />
            </>
          )}
          {typeof run.duration_ms === "number" && !isActive && (
            <>
              {" "}
              · {run.duration_ms}ms
            </>
          )}
        </span>
        {(completed > 0 || steps.length > 0) && (
          <span className="text-muted-foreground">
            · Step {completed}/{steps.length}
            {lastNode ? ` · last: ${lastNode}` : ""}
          </span>
        )}
      </div>
      {isActive && (
        <p className="text-[11px] text-muted-foreground">
          Stop takes effect after the current DAG level finishes (not mid-node).
        </p>
      )}
      <div className="flex flex-wrap items-center gap-2">
        {isActive && (
          <Button
            type="button"
            variant="destructive"
            size="sm"
            disabled={stopBusy}
            onClick={() => void onStop()}
          >
            <OctagonX className="h-3.5 w-3.5 mr-1" />
            Stop run
          </Button>
        )}
        <Link
          href={`${ROUTES.RUNS}?workflow_id=${encodeURIComponent(workflowId)}&run_id=${encodeURIComponent(run.id)}`}
          className={cn(buttonVariants({ variant: "secondary", size: "sm" }))}
        >
          <ExternalLink className="h-3.5 w-3.5 mr-1" />
          View run
        </Link>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-8 px-2"
          onClick={onDismiss}
          aria-label="Dismiss banner"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
