"use client";

import { useEffect, useRef, useState } from "react";

import { getAccessToken } from "@/lib/auth-storage";
import { getApiBaseUrl } from "@/lib/settings";

/** SSE event types emitted by the workflow execution stream. */
export interface SSEEvent {
  type:
    | "workflow_started"
    | "workflow_completed"
    | "node_started"
    | "node_completed"
    | "node_failed"
    | "done"
    | "timeout";
  node_id?: string;
  status?: string;
  output?: Record<string, unknown>;
  error?: string;
  duration_ms?: number;
  success?: boolean;
  timestamp?: number;
}

/**
 * Connects to the SSE stream for a workflow run. Uses fetch + ReadableStream
 * instead of EventSource so that an Authorization token can be sent via query
 * parameter. Falls back gracefully when the stream is unavailable.
 */
export function useWorkflowSSE(
  runId: string | null,
  onEvent: (event: SSEEvent) => void,
): { connected: boolean } {
  const [connected, setConnected] = useState(false);
  const onEventRef = useRef(onEvent);
  onEventRef.current = onEvent;

  useEffect(() => {
    if (!runId) {
      setConnected(false);
      return;
    }

    const abortController = new AbortController();
    let active = true;

    async function connect() {
      const base = getApiBaseUrl();
      const token = getAccessToken();
      const url = `${base}/api/v1/workflows/runs/${runId}/stream?token=${encodeURIComponent(token || "")}`;

      try {
        const res = await fetch(url, {
          signal: abortController.signal,
          headers: { Accept: "text/event-stream" },
          cache: "no-store",
        });

        if (!res.ok || !res.body) {
          if (active) setConnected(false);
          return;
        }

        if (active) setConnected(true);

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        while (active) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          // Keep the last (potentially incomplete) line in the buffer
          buffer = lines.pop() ?? "";

          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith("data:")) continue;

            const jsonStr = trimmed.slice(5).trim();
            if (!jsonStr) continue;

            try {
              const parsed: SSEEvent = JSON.parse(jsonStr);
              onEventRef.current(parsed);

              if (parsed.type === "done") {
                // Stream is complete; close reader
                await reader.cancel();
                if (active) setConnected(false);
                return;
              }
            } catch {
              // Ignore malformed JSON lines
            }
          }
        }

        // Stream ended naturally
        if (active) setConnected(false);
      } catch (err: unknown) {
        if (err instanceof DOMException && err.name === "AbortError") {
          // Expected on cleanup
          return;
        }
        if (active) setConnected(false);
      }
    }

    void connect();

    return () => {
      active = false;
      abortController.abort();
      setConnected(false);
    };
  }, [runId]);

  return { connected };
}
