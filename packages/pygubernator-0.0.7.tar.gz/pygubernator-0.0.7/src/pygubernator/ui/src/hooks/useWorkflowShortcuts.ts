/** Keyboard shortcuts for the workflow editor. */

import { useEffect } from "react";
import { useWorkflowEditorStore } from "@/stores/workflow-editor";

/** Returns true if the active element is an input where shortcuts should not fire. */
function isInputFocused(): boolean {
  const el = document.activeElement;
  if (!el) return false;
  const tag = el.tagName.toLowerCase();
  if (tag === "input" || tag === "textarea" || tag === "select") return true;
  if ((el as HTMLElement).isContentEditable) return true;
  // Check if inside an open dialog
  if (el.closest("dialog[open]")) return true;
  return false;
}

export interface WorkflowShortcutActions {
  onSave?: () => void;
  onExecute?: () => void;
  onFitView?: () => void;
  onOpenPalette?: () => void;
  onOpenInspector?: (nodeId: string) => void;
}

export function useWorkflowShortcuts(actions?: WorkflowShortcutActions) {
  useEffect(() => {
    function handler(e: KeyboardEvent) {
      const meta = e.metaKey || e.ctrlKey;

      // Undo: Ctrl+Z (no shift)
      if (meta && e.key === "z" && !e.shiftKey) {
        if (isInputFocused()) return;
        e.preventDefault();
        useWorkflowEditorStore.getState().undo();
        return;
      }

      // Redo: Ctrl+Shift+Z or Ctrl+Y
      if (meta && ((e.key === "z" && e.shiftKey) || e.key === "y")) {
        if (isInputFocused()) return;
        e.preventDefault();
        useWorkflowEditorStore.getState().redo();
        return;
      }

      // Copy: Ctrl+C
      if (meta && e.key === "c" && !e.shiftKey) {
        if (isInputFocused()) return;
        e.preventDefault();
        useWorkflowEditorStore.getState().copySelection();
        return;
      }

      // Cut: Ctrl+X
      if (meta && e.key === "x" && !e.shiftKey) {
        if (isInputFocused()) return;
        e.preventDefault();
        useWorkflowEditorStore.getState().cutSelection();
        return;
      }

      // Paste: Ctrl+V
      if (meta && e.key === "v" && !e.shiftKey) {
        if (isInputFocused()) return;
        e.preventDefault();
        useWorkflowEditorStore.getState().pasteClipboard();
        return;
      }

      // Select All: Ctrl+A
      if (meta && e.key === "a" && !e.shiftKey) {
        if (isInputFocused()) return;
        e.preventDefault();
        useWorkflowEditorStore.getState().selectAll();
        return;
      }

      // Duplicate: Ctrl+D
      if (meta && e.key === "d" && !e.shiftKey) {
        if (isInputFocused()) return;
        e.preventDefault();
        const store = useWorkflowEditorStore.getState();
        store.copySelection();
        store.pasteClipboard();
        return;
      }

      // Save: Ctrl+S
      if (meta && e.key === "s" && !e.shiftKey) {
        e.preventDefault();
        actions?.onSave?.();
        return;
      }

      // Execute: Ctrl+Enter
      if (meta && e.key === "Enter") {
        e.preventDefault();
        actions?.onExecute?.();
        return;
      }

      // Open inspector for selected node: Enter
      if (!meta && e.key === "Enter" && !e.shiftKey && !e.altKey) {
        if (isInputFocused()) return;
        const ids = useWorkflowEditorStore.getState().selectedNodeIds;
        if (ids.length > 0) {
          e.preventDefault();
          actions?.onOpenInspector?.(ids[0]);
          return;
        }
      }

      // Delete selection: Delete or Backspace (when not in input)
      if (e.key === "Delete" || e.key === "Backspace") {
        if (isInputFocused()) return;
        const ids = useWorkflowEditorStore.getState().selectedNodeIds;
        if (ids.length > 0) {
          e.preventDefault();
          useWorkflowEditorStore.getState().deleteSelection();
          return;
        }
      }

      // Fit view: F
      if (e.key === "f" && !meta && !e.shiftKey && !e.altKey) {
        if (isInputFocused()) return;
        e.preventDefault();
        actions?.onFitView?.();
        return;
      }

      // Command palette: Ctrl+K
      if (meta && e.key === "k" && !e.shiftKey) {
        e.preventDefault();
        actions?.onOpenPalette?.();
        return;
      }
    }

    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [actions]);
}
