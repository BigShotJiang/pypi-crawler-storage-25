"use client";

import { useState, useCallback } from "react";

import { getApiBaseUrl } from "@/lib/settings";

export interface ApiHealthResult {
  success: boolean;
  message: string;
}

/** Test API health. Pass optional baseUrl to test an unsaved URL from the form. */
export function useApiHealth() {
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<ApiHealthResult | null>(null);

  const test = useCallback(async (overrideBaseUrl?: string) => {
    setTesting(true);
    setResult(null);
    const base = (overrideBaseUrl ?? getApiBaseUrl()).replace(/\/$/, "");
    const path = "/healthz";
    const url = base ? `${base}${path}` : path;
    try {
      const res = await fetch(url);
      const data = res.ok ? await res.json().catch(() => ({})) : null;
      const status =
        data && typeof data === "object" && data !== null && "status" in data
          ? String((data as { status?: string }).status)
          : res.ok
            ? "ok"
            : res.statusText;
      if (!res.ok) {
        throw new Error(status);
      }
      setResult({
        success: true,
        message: `Connected (${status}).`,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to reach API";
      setResult({ success: false, message: msg });
    } finally {
      setTesting(false);
    }
  }, []);

  return { testing, result, test };
}
