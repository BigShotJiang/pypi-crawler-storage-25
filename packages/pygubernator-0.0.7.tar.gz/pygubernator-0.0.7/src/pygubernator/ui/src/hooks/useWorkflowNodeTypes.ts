"use client";

import { useEffect, useState } from "react";

import { apiGet } from "@/lib/api";
import type { WorkflowNodeTypeItem } from "@/lib/types/workflow";
import { FALLBACK_WORKFLOW_NODE_TYPES } from "@/lib/workflow-node-types";

let cachedNodeTypes: WorkflowNodeTypeItem[] | null = null;
let inflightPromise: Promise<WorkflowNodeTypeItem[]> | null = null;

async function loadWorkflowNodeTypes(): Promise<WorkflowNodeTypeItem[]> {
  if (cachedNodeTypes) {
    return cachedNodeTypes;
  }
  if (!inflightPromise) {
    inflightPromise = apiGet<{ items: WorkflowNodeTypeItem[] }>("/api/v1/workflows/node-types")
      .then((response) => {
        cachedNodeTypes = response.items?.length ? response.items : FALLBACK_WORKFLOW_NODE_TYPES;
        return cachedNodeTypes;
      })
      .catch(() => {
        cachedNodeTypes = FALLBACK_WORKFLOW_NODE_TYPES;
        return cachedNodeTypes;
      })
      .finally(() => {
        inflightPromise = null;
      });
  }
  return inflightPromise;
}

export function useWorkflowNodeTypes() {
  const [nodeTypes, setNodeTypes] = useState<WorkflowNodeTypeItem[]>(cachedNodeTypes ?? FALLBACK_WORKFLOW_NODE_TYPES);
  const [loading, setLoading] = useState(cachedNodeTypes === null);

  useEffect(() => {
    let cancelled = false;
    void loadWorkflowNodeTypes().then((items) => {
      if (cancelled) return;
      setNodeTypes(items);
      setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  return { nodeTypes, loading };
}
