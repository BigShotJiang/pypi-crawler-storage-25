"use client";

import { useState, useCallback, useEffect } from "react";

import {
  getDatabaseConfig,
  testDatabase,
  type DatabaseConfigResponse,
  type DatabaseTestRequest,
  type DatabaseTestResponse,
} from "@/lib/api";

export type DbConfigState = {
  database_type: string;
  workflow_count: number;
  message: string;
  is_default: boolean;
} | null;

export function useDatabaseConfig() {
  const [config, setConfig] = useState<DbConfigState>(null);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<DatabaseTestResponse | null>(
    null
  );

  const fetchConfig = useCallback(async () => {
    try {
      const r: DatabaseConfigResponse = await getDatabaseConfig();
      setConfig({
        database_type: r.database_type,
        workflow_count: r.workflow_count,
        message: r.message,
        is_default: r.is_default,
      });
    } catch {
      setConfig(null);
    }
  }, []);

  useEffect(() => {
    void fetchConfig();
  }, [fetchConfig]);

  const test = useCallback(async (body: DatabaseTestRequest) => {
    setTesting(true);
    setTestResult(null);
    try {
      const result = await testDatabase(body);
      setTestResult(result);
    } catch (err: unknown) {
      const detail =
        err && typeof err === "object" && "message" in err
          ? String((err as Error).message)
          : "Failed to test database connection";
      setTestResult({ success: false, message: detail });
    } finally {
      setTesting(false);
    }
  }, []);

  return { config, fetchConfig, testing, testResult, test };
}
