import { useEffect, useRef } from "react";
import { usePathname, useRouter } from "next/navigation";

import { AUTH_SESSION_EXPIRED_EVENT, LOGIN_REASON_SESSION_EXPIRED, ROUTES } from "@/lib/constants";
import { useAuthStore } from "@/stores/auth";

const RETURN_URL_KEY = "pygubernator_return_url";

export function useAuthInit() {
  const router = useRouter();
  const pathname = usePathname();
  const checkAuth = useAuthStore((s) => s.checkAuth);
  const clearUser = useAuthStore((s) => s.clearUser);
  const didLoad = useRef(false);

  useEffect(() => {
    if (didLoad.current) return;
    didLoad.current = true;
    checkAuth();
  }, [checkAuth]);

  useEffect(() => {
    const handler = () => {
      clearUser();
      if (typeof window !== "undefined") {
        sessionStorage.setItem(RETURN_URL_KEY, pathname || ROUTES.HOME);
      }
      router.replace(`${ROUTES.LOGIN}?reason=${LOGIN_REASON_SESSION_EXPIRED}`);
    };
    window.addEventListener(AUTH_SESSION_EXPIRED_EVENT, handler);
    return () => window.removeEventListener(AUTH_SESSION_EXPIRED_EVENT, handler);
  }, [clearUser, pathname, router]);
}
