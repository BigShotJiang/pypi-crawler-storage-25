/** Zustand store for the workflow editor with undo/redo history and per-session snapshots. */

import { create } from "zustand";
import { devtools } from "zustand/middleware";
import type { SpecJson, SpecNode, SpecEdge, StepItem, WorkflowItem, VersionRow } from "@/lib/types/workflow";

const MAX_UNDO = 50;

const DEFAULT_SPEC: SpecJson = {
  meta: { name: "", version: "1.0.0" },
  nodes: {},
  edges: [],
};

/** Session key when editing a new workflow without a persisted id. */
export const DRAFT_SESSION_KEY = "__draft__";

/** React Flow pan/zoom; persisted per editor session so the canvas view survives navigation. */
export interface FlowViewport {
  x: number;
  y: number;
  zoom: number;
}

export interface SetSpecOptions {
  /** When true, clears undo/redo history (e.g. after loading from server). */
  replaceHistory?: boolean;
  /** When true, skips pushing an undo snapshot (e.g. drag position updates). */
  skipUndo?: boolean;
}

export interface ClipboardData {
  nodes: Record<string, SpecNode>;
  edges: { source: string; target: string; source_handle?: string; condition?: string | null }[];
}

/** Full editor state cached per workflow session (navigation-stable). */
export interface WorkflowEditorSessionSnapshot {
  spec: SpecJson;
  past: SpecJson[];
  future: SpecJson[];
  isDirty: boolean;
  selectedNodeIds: string[];
  clipboard: ClipboardData | null;
  runOverlay: Record<string, StepItem> | null;
  lastRunId: string | null;
  bottomPanelOpen: boolean;
  workflow: WorkflowItem | null;
  versions: VersionRow[];
  currentVersion: string;
  saveVersion: string;
  saveName: string;
  loadedVersionId: string | null;
  inspectorNodeId: string | null;
  paletteOpen: boolean;
  inputDialogOpen: boolean;
  /** null = not set yet (first paint will fitView); restored from snapshot when returning to the editor. */
  flowViewport: FlowViewport | null;
}

export interface HydrateFromServerInput {
  workflow: WorkflowItem | null;
  versions: VersionRow[];
  activeSpec: SpecJson;
  loadedVersionId: string | null;
  currentVersion: string;
  saveVersion: string;
  saveName: string;
}

export interface WorkflowEditorState {
  spec: SpecJson;
  past: SpecJson[];
  future: SpecJson[];
  isDirty: boolean;
  selectedNodeIds: string[];
  clipboard: ClipboardData | null;
  runOverlay: Record<string, StepItem> | null;
  lastRunId: string | null;
  bottomPanelOpen: boolean;

  /** URL-bound session: workflow id or {@link DRAFT_SESSION_KEY}. */
  activeSessionKey: string | null;
  sessionSnapshotsByKey: Record<string, WorkflowEditorSessionSnapshot>;

  workflow: WorkflowItem | null;
  versions: VersionRow[];
  versionsLoading: boolean;
  currentVersion: string;
  saveVersion: string;
  saveName: string;
  loadedVersionId: string | null;
  inspectorNodeId: string | null;
  paletteOpen: boolean;
  inputDialogOpen: boolean;
  flowViewport: FlowViewport | null;

  /**
   * Binds the store to a session key. Persists the previous session to `sessionSnapshotsByKey`
   * and restores from cache when present.
   * @returns true when cached state was restored (skip server hydrate).
   */
  switchSession: (newKey: string) => boolean;

  /** Apply server data and replace undo history (initial load or forced reload). */
  hydrateFromServer: (input: HydrateFromServerInput) => void;

  /** Drop cached snapshot so the next load fetches fresh server state. */
  clearSessionSnapshot: (key: string) => void;

  /**
   * When opening a draft with no cached snapshot, reset canvas + draft meta.
   * Does not run when a draft snapshot exists (navigation return).
   */
  resetForDraftIfNeeded: (sessionKey: string, hadCachedRestore: boolean) => void;

  persistEditorMeta: (
    partial: Partial<
      Pick<
        WorkflowEditorState,
        | "inspectorNodeId"
        | "paletteOpen"
        | "inputDialogOpen"
        | "saveVersion"
        | "saveName"
        | "currentVersion"
        | "loadedVersionId"
      >
    >,
  ) => void;

  setFlowViewport: (viewport: FlowViewport | null) => void;

  setVersionsLoading: (loading: boolean) => void;

  setSpec: (
    updater: SpecJson | ((prev: SpecJson) => SpecJson),
    options?: SetSpecOptions,
  ) => void;
  undo: () => void;
  redo: () => void;
  markSaved: () => void;

  addNode: (type: string) => string;
  removeNode: (nodeId: string) => void;
  updateNodeConfig: (nodeId: string, config: Record<string, unknown>) => void;
  updateNodes: (nodes: Record<string, SpecNode>, options?: SetSpecOptions) => void;
  updateEdges: (edges: SpecEdge[], options?: SetSpecOptions) => void;

  setSelectedNodeIds: (ids: string[]) => void;
  selectAll: () => void;

  copySelection: () => void;
  cutSelection: () => void;
  pasteClipboard: (offset?: number) => void;
  deleteSelection: () => void;

  setRunOverlay: (overlay: Record<string, StepItem> | null) => void;
  setLastRunId: (id: string | null) => void;
  toggleBottomPanel: () => void;

  /** After first-save draft → real id, move snapshot from draft key to workflow id. */
  promoteDraftSnapshotToWorkflowId: (workflowId: string) => void;
}

function buildSnapshot(s: WorkflowEditorState): WorkflowEditorSessionSnapshot {
  return {
    spec: deepClone(s.spec),
    past: deepClone(s.past),
    future: deepClone(s.future),
    isDirty: s.isDirty,
    selectedNodeIds: [...s.selectedNodeIds],
    clipboard: s.clipboard ? deepClone(s.clipboard) : null,
    runOverlay: s.runOverlay ? deepClone(s.runOverlay) : null,
    lastRunId: s.lastRunId,
    bottomPanelOpen: s.bottomPanelOpen,
    workflow: s.workflow ? deepClone(s.workflow) : null,
    versions: deepClone(s.versions),
    currentVersion: s.currentVersion,
    saveVersion: s.saveVersion,
    saveName: s.saveName,
    loadedVersionId: s.loadedVersionId,
    inspectorNodeId: s.inspectorNodeId,
    paletteOpen: s.paletteOpen,
    inputDialogOpen: s.inputDialogOpen,
    flowViewport: s.flowViewport ? { ...s.flowViewport } : null,
  };
}

function applySessionSnapshot(
  set: (partial: Partial<WorkflowEditorState>) => void,
  snap: WorkflowEditorSessionSnapshot,
) {
  set({
    spec: deepClone(snap.spec),
    past: deepClone(snap.past),
    future: deepClone(snap.future),
    isDirty: snap.isDirty,
    selectedNodeIds: [...snap.selectedNodeIds],
    clipboard: snap.clipboard ? deepClone(snap.clipboard) : null,
    runOverlay: snap.runOverlay ? deepClone(snap.runOverlay) : null,
    lastRunId: snap.lastRunId,
    bottomPanelOpen: snap.bottomPanelOpen,
    workflow: snap.workflow ? deepClone(snap.workflow) : null,
    versions: deepClone(snap.versions),
    currentVersion: snap.currentVersion,
    saveVersion: snap.saveVersion,
    saveName: snap.saveName,
    loadedVersionId: snap.loadedVersionId,
    inspectorNodeId: snap.inspectorNodeId,
    paletteOpen: snap.paletteOpen,
    inputDialogOpen: snap.inputDialogOpen,
    flowViewport: snap.flowViewport ? { ...snap.flowViewport } : null,
  });
}

function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj)) as T;
}

export const useWorkflowEditorStore = create<WorkflowEditorState>()(
  devtools(
    (set, get) => ({
      spec: deepClone(DEFAULT_SPEC),
      past: [],
      future: [],
      isDirty: false,
      selectedNodeIds: [],
      clipboard: null,
      runOverlay: null,
      lastRunId: null,
      bottomPanelOpen: false,

      activeSessionKey: null,
      sessionSnapshotsByKey: {},

      workflow: null,
      versions: [],
      versionsLoading: false,
      currentVersion: "",
      saveVersion: "1.0.0",
      saveName: "",
      loadedVersionId: null,
      inspectorNodeId: null,
      paletteOpen: false,
      inputDialogOpen: false,
      flowViewport: null,

      switchSession: (newKey: string) => {
        const s = get();
        const prev = s.activeSessionKey;

        if (prev === newKey) {
          return true;
        }

        if (prev !== null && prev !== newKey) {
          set({
            sessionSnapshotsByKey: {
              ...s.sessionSnapshotsByKey,
              [prev]: buildSnapshot(s),
            },
          });
        }

        set({ activeSessionKey: newKey });

        const snap = get().sessionSnapshotsByKey[newKey];
        if (snap) {
          applySessionSnapshot(set, snap);
          return true;
        }

        return false;
      },

      hydrateFromServer: (input) => {
        set({
          workflow: input.workflow ? deepClone(input.workflow) : null,
          versions: deepClone(input.versions),
          currentVersion: input.currentVersion,
          saveVersion: input.saveVersion,
          saveName: input.saveName,
          loadedVersionId: input.loadedVersionId,
        });
        get().setSpec(input.activeSpec, { replaceHistory: true });
      },

      clearSessionSnapshot: (key: string) => {
        set((state) => {
          const { [key]: _, ...rest } = state.sessionSnapshotsByKey;
          return { sessionSnapshotsByKey: rest };
        });
      },

      resetForDraftIfNeeded: (sessionKey, hadCachedRestore) => {
        if (sessionKey !== DRAFT_SESSION_KEY || hadCachedRestore) return;
        get().setSpec(
          { meta: { name: "", version: "1.0.0" }, nodes: {}, edges: [] },
          { replaceHistory: true },
        );
        set({
          workflow: null,
          versions: [],
          currentVersion: "",
          saveVersion: "1.0.0",
          saveName: "",
          loadedVersionId: null,
          inspectorNodeId: null,
          paletteOpen: false,
          inputDialogOpen: false,
          runOverlay: null,
          lastRunId: null,
          flowViewport: null,
        });
      },

      persistEditorMeta: (partial) => set(partial),

      setFlowViewport: (viewport) => set({ flowViewport: viewport }),

      setVersionsLoading: (loading) => set({ versionsLoading: loading }),

      promoteDraftSnapshotToWorkflowId: (workflowId: string) => {
        const s = get();
        const snap = buildSnapshot(s);
        const { [DRAFT_SESSION_KEY]: _, ...rest } = s.sessionSnapshotsByKey;
        set({
          sessionSnapshotsByKey: { ...rest, [workflowId]: snap },
          activeSessionKey: workflowId,
        });
      },

      setSpec: (updater, options) => {
        set((s) => {
          const next = typeof updater === "function" ? (updater as (prev: SpecJson) => SpecJson)(s.spec) : updater;
          if (options?.replaceHistory) {
            return { spec: next, past: [], future: [], isDirty: false };
          }
          if (options?.skipUndo) {
            return { spec: next, isDirty: true };
          }
          const snap = deepClone(s.spec);
          const newPast = [...s.past, snap].slice(-MAX_UNDO);
          return { spec: next, past: newPast, future: [], isDirty: true };
        });
      },

      undo: () => {
        const s = get();
        if (s.past.length === 0) return;
        const prev = s.past[s.past.length - 1];
        const newPast = s.past.slice(0, -1);
        const currentSnap = deepClone(s.spec);
        set({
          spec: prev,
          past: newPast,
          future: [currentSnap, ...s.future],
        });
      },

      redo: () => {
        const s = get();
        if (s.future.length === 0) return;
        const next = s.future[0];
        const newFuture = s.future.slice(1);
        const currentSnap = deepClone(s.spec);
        set({
          spec: next,
          past: [...s.past, currentSnap].slice(-MAX_UNDO),
          future: newFuture,
        });
      },

      markSaved: () => set({ isDirty: false }),

      addNode: (type: string) => {
        const id = `${type}_${Date.now().toString(36)}`;
        get().setSpec((prev) => ({
          ...prev,
          nodes: {
            ...(prev.nodes ?? {}),
            [id]: {
              type,
              config: {},
              position: {
                x: 250,
                y: Object.keys(prev.nodes ?? {}).length * 120 + 50,
              },
            },
          },
        }));
        set({ selectedNodeIds: [id] });
        return id;
      },

      removeNode: (nodeId: string) => {
        get().setSpec((prev) => {
          const { [nodeId]: _, ...rest } = prev.nodes ?? {};
          return {
            ...prev,
            nodes: rest,
            edges: (prev.edges ?? []).filter(
              (e) => e.source !== nodeId && e.target !== nodeId,
            ),
          };
        });
        set((s) => ({
          selectedNodeIds: s.selectedNodeIds.filter((id) => id !== nodeId),
        }));
      },

      updateNodeConfig: (nodeId, config) => {
        get().setSpec((prev) => ({
          ...prev,
          nodes: {
            ...(prev.nodes ?? {}),
            [nodeId]: { ...(prev.nodes ?? {})[nodeId], config },
          },
        }));
      },

      updateNodes: (nodes, options) => {
        get().setSpec(
          (prev) => ({ ...prev, nodes }),
          options,
        );
      },

      updateEdges: (edges, options) => {
        get().setSpec(
          (prev) => ({ ...prev, edges }),
          options,
        );
      },

      setSelectedNodeIds: (ids) => set({ selectedNodeIds: ids }),

      selectAll: () => {
        const nodes = get().spec.nodes ?? {};
        set({ selectedNodeIds: Object.keys(nodes) });
      },

      copySelection: () => {
        const s = get();
        const ids = new Set(s.selectedNodeIds);
        if (ids.size === 0) return;
        const allNodes = s.spec.nodes ?? {};
        const copiedNodes: Record<string, SpecNode> = {};
        for (const id of ids) {
          if (allNodes[id]) copiedNodes[id] = deepClone(allNodes[id]);
        }
        const copiedEdges = (s.spec.edges ?? []).filter(
          (e) => ids.has(e.source) && ids.has(e.target),
        );
        set({ clipboard: { nodes: copiedNodes, edges: deepClone(copiedEdges) } });
      },

      cutSelection: () => {
        get().copySelection();
        get().deleteSelection();
      },

      pasteClipboard: (offset = 50) => {
        const s = get();
        if (!s.clipboard) return;
        const idMap = new Map<string, string>();
        const newNodes: Record<string, SpecNode> = {};
        for (const [oldId, node] of Object.entries(s.clipboard.nodes)) {
          const newId = `${node.type}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`;
          idMap.set(oldId, newId);
          newNodes[newId] = {
            ...deepClone(node),
            position: {
              x: (node.position?.x ?? 250) + offset,
              y: (node.position?.y ?? 50) + offset,
            },
          };
        }
        const newEdges = s.clipboard.edges
          .filter((e) => idMap.has(e.source) && idMap.has(e.target))
          .map((e) => ({
            ...e,
            source: idMap.get(e.source)!,
            target: idMap.get(e.target)!,
          }));

        get().setSpec((prev) => ({
          ...prev,
          nodes: { ...(prev.nodes ?? {}), ...newNodes },
          edges: [...(prev.edges ?? []), ...newEdges],
        }));
        set({ selectedNodeIds: Array.from(idMap.values()) });
      },

      deleteSelection: () => {
        const s = get();
        if (s.selectedNodeIds.length === 0) return;
        const ids = new Set(s.selectedNodeIds);
        get().setSpec((prev) => {
          const nodes = { ...(prev.nodes ?? {}) };
          for (const id of ids) delete nodes[id];
          return {
            ...prev,
            nodes,
            edges: (prev.edges ?? []).filter(
              (e) => !ids.has(e.source) && !ids.has(e.target),
            ),
          };
        });
        set({ selectedNodeIds: [] });
      },

      setRunOverlay: (overlay) => set({ runOverlay: overlay }),
      setLastRunId: (id) => set({ lastRunId: id }),
      toggleBottomPanel: () => set((s) => ({ bottomPanelOpen: !s.bottomPanelOpen })),
    }),
    { name: "workflow-editor" },
  ),
);

// Granular selectors
export const selectSpec = (s: WorkflowEditorState) => s.spec;
export const selectPastLength = (s: WorkflowEditorState) => s.past.length;
export const selectFutureLength = (s: WorkflowEditorState) => s.future.length;
export const selectUndo = (s: WorkflowEditorState) => s.undo;
export const selectRedo = (s: WorkflowEditorState) => s.redo;
export const selectSetSpec = (s: WorkflowEditorState) => s.setSpec;
export const selectAddNode = (s: WorkflowEditorState) => s.addNode;
export const selectRemoveNode = (s: WorkflowEditorState) => s.removeNode;
export const selectUpdateNodeConfig = (s: WorkflowEditorState) => s.updateNodeConfig;
export const selectUpdateNodes = (s: WorkflowEditorState) => s.updateNodes;
export const selectUpdateEdges = (s: WorkflowEditorState) => s.updateEdges;
export const selectSelectedNodeIds = (s: WorkflowEditorState) => s.selectedNodeIds;
export const selectSetSelectedNodeIds = (s: WorkflowEditorState) => s.setSelectedNodeIds;
export const selectSelectAll = (s: WorkflowEditorState) => s.selectAll;
export const selectClipboard = (s: WorkflowEditorState) => s.clipboard;
export const selectCopySelection = (s: WorkflowEditorState) => s.copySelection;
export const selectCutSelection = (s: WorkflowEditorState) => s.cutSelection;
export const selectPasteClipboard = (s: WorkflowEditorState) => s.pasteClipboard;
export const selectDeleteSelection = (s: WorkflowEditorState) => s.deleteSelection;
export const selectRunOverlay = (s: WorkflowEditorState) => s.runOverlay;
export const selectLastRunId = (s: WorkflowEditorState) => s.lastRunId;
export const selectSetRunOverlay = (s: WorkflowEditorState) => s.setRunOverlay;
export const selectSetLastRunId = (s: WorkflowEditorState) => s.setLastRunId;
export const selectIsDirty = (s: WorkflowEditorState) => s.isDirty;
export const selectMarkSaved = (s: WorkflowEditorState) => s.markSaved;
export const selectBottomPanelOpen = (s: WorkflowEditorState) => s.bottomPanelOpen;
export const selectToggleBottomPanel = (s: WorkflowEditorState) => s.toggleBottomPanel;

export const selectWorkflow = (s: WorkflowEditorState) => s.workflow;
export const selectVersions = (s: WorkflowEditorState) => s.versions;
export const selectVersionsLoading = (s: WorkflowEditorState) => s.versionsLoading;
export const selectCurrentVersion = (s: WorkflowEditorState) => s.currentVersion;
export const selectSaveVersion = (s: WorkflowEditorState) => s.saveVersion;
export const selectSaveName = (s: WorkflowEditorState) => s.saveName;
export const selectLoadedVersionId = (s: WorkflowEditorState) => s.loadedVersionId;
export const selectInspectorNodeId = (s: WorkflowEditorState) => s.inspectorNodeId;
export const selectPaletteOpen = (s: WorkflowEditorState) => s.paletteOpen;
export const selectInputDialogOpen = (s: WorkflowEditorState) => s.inputDialogOpen;

export const selectSwitchSession = (s: WorkflowEditorState) => s.switchSession;
export const selectHydrateFromServer = (s: WorkflowEditorState) => s.hydrateFromServer;
export const selectClearSessionSnapshot = (s: WorkflowEditorState) => s.clearSessionSnapshot;
export const selectResetForDraftIfNeeded = (s: WorkflowEditorState) => s.resetForDraftIfNeeded;
export const selectPersistEditorMeta = (s: WorkflowEditorState) => s.persistEditorMeta;
export const selectSetVersionsLoading = (s: WorkflowEditorState) => s.setVersionsLoading;
export const selectPromoteDraftSnapshotToWorkflowId = (s: WorkflowEditorState) =>
  s.promoteDraftSnapshotToWorkflowId;
