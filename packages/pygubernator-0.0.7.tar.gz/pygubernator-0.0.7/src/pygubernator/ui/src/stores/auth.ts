import { create } from "zustand";

import { ApiError } from "@/lib/api";
import type { AuthMeResponse } from "@/lib/api/auth";
import { authApi, loginWithTimeout } from "@/lib/api/auth";
import { clearAccessToken, setAccessToken } from "@/lib/auth-storage";
import { ROUTES } from "@/lib/constants";

const AUTH_CHECK_TIMEOUT_MS = 5000;
const LOGIN_REQUEST_TIMEOUT_MS = 10000;
const RETURN_URL_KEY = "pygubernator_return_url";

function isConnectionError(err: unknown): boolean {
  if (!(err instanceof ApiError)) return false;
  return (
    err.status === 0 ||
    err.message.includes("Unable to connect") ||
    err.message.includes("timed out")
  );
}

export interface AuthState {
  user: AuthMeResponse | null;
  loading: boolean;
  apiUnavailable: boolean;
  checkAuth: () => Promise<void>;
  login: (username: string, password: string) => Promise<string>;
  logout: () => Promise<void>;
  clearUser: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  apiUnavailable: false,

  checkAuth: async () => {
    try {
      const me = await authApi.meWithTimeout(AUTH_CHECK_TIMEOUT_MS);
      set({ user: me, apiUnavailable: false });
    } catch (err) {
      if (err instanceof ApiError && err.status === 401) {
        set({ user: null, apiUnavailable: false });
      } else if (isConnectionError(err)) {
        set({ user: null, apiUnavailable: true });
      } else {
        set({ user: null, apiUnavailable: false });
      }
    } finally {
      set({ loading: false });
    }
  },

  login: async (username, password) => {
    const res = await loginWithTimeout(username, password, LOGIN_REQUEST_TIMEOUT_MS);
    setAccessToken(res.access_token);
    set({
      user: { username, role: res.role ?? "User", auth_disabled: false },
      apiUnavailable: false
    });
    const returnUrl =
      typeof window !== "undefined" ? sessionStorage.getItem(RETURN_URL_KEY) : null;
    sessionStorage.removeItem(RETURN_URL_KEY);
    return returnUrl || ROUTES.HOME;
  },

  logout: async () => {
    clearAccessToken();
    try {
      await authApi.logout();
    } catch {
      // Logout is best-effort for stateless JWT sessions.
    } finally {
      set({ user: null, apiUnavailable: false });
    }
  },

  clearUser: () => set({ user: null })
}));

export const selectUser = (s: AuthState) => s.user;
export const selectLoading = (s: AuthState) => s.loading;
export const selectApiUnavailable = (s: AuthState) => s.apiUnavailable;
export const selectIsAuthenticated = (s: AuthState) => !!s.user;
export const selectAuthDisabled = (s: AuthState) => s.user?.auth_disabled === true;
export const selectLogin = (s: AuthState) => s.login;
export const selectLogout = (s: AuthState) => s.logout;
