import { describe, it, expect, beforeEach } from "vitest";

import {
  useWorkflowEditorStore,
  DRAFT_SESSION_KEY,
} from "./workflow-editor";

function resetStore() {
  useWorkflowEditorStore.setState({
    spec: { meta: { name: "", version: "1.0.0" }, nodes: {}, edges: [] },
    past: [],
    future: [],
    isDirty: false,
    selectedNodeIds: [],
    clipboard: null,
    runOverlay: null,
    lastRunId: null,
    bottomPanelOpen: false,
    activeSessionKey: null,
    sessionSnapshotsByKey: {},
    workflow: null,
    versions: [],
    versionsLoading: false,
    currentVersion: "",
    saveVersion: "1.0.0",
    saveName: "",
    loadedVersionId: null,
    inspectorNodeId: null,
    paletteOpen: false,
    inputDialogOpen: false,
    flowViewport: null,
  });
}

describe("workflow-editor session snapshots", () => {
  beforeEach(() => resetStore());

  it("switchSession to a new key returns false when no cache", () => {
    expect(useWorkflowEditorStore.getState().switchSession("wf-a")).toBe(false);
    expect(useWorkflowEditorStore.getState().activeSessionKey).toBe("wf-a");
  });

  it("switchSession to the same key returns true (navigation-stable)", () => {
    const s = useWorkflowEditorStore.getState();
    expect(s.switchSession("wf-a")).toBe(false);
    expect(useWorkflowEditorStore.getState().switchSession("wf-a")).toBe(true);
  });

  it("A -> B -> A restores unsaved spec and editor meta", () => {
    const store = useWorkflowEditorStore.getState();
    expect(store.switchSession("wf-a")).toBe(false);
    store.setSpec(
      { meta: {}, nodes: { n1: { type: "noop", config: {} } }, edges: [] },
      { replaceHistory: true },
    );
    store.persistEditorMeta({ saveName: "Draft A", inspectorNodeId: "n1" });

    store.switchSession("wf-b");
    store.hydrateFromServer({
      workflow: {
        id: "wf-b",
        name: "B",
        description: "",
        owner: "x",
        status: "active",
      },
      versions: [],
      activeSpec: {
        meta: {},
        nodes: { n2: { type: "noop", config: {} } },
        edges: [],
      },
      loadedVersionId: null,
      currentVersion: "1.0.0",
      saveVersion: "1.0.1",
      saveName: "B",
    });

    expect(useWorkflowEditorStore.getState().spec.nodes?.n2).toBeDefined();

    useWorkflowEditorStore.getState().switchSession("wf-a");

    const restored = useWorkflowEditorStore.getState();
    expect(restored.spec.nodes?.n1).toBeDefined();
    expect(restored.spec.nodes?.n2).toBeUndefined();
    expect(restored.saveName).toBe("Draft A");
    expect(restored.inspectorNodeId).toBe("n1");
  });

  it("preserves undo stacks per workflow when switching sessions", () => {
    const store = useWorkflowEditorStore.getState();
    store.switchSession("wf-a");
    store.setSpec(
      { meta: {}, nodes: { n1: { type: "noop", config: {} } }, edges: [] },
      { replaceHistory: true },
    );
    store.setSpec((prev) => ({
      ...prev,
      nodes: {
        ...(prev.nodes ?? {}),
        n1: { ...prev.nodes!.n1, config: { x: 1 } },
      },
    }));
    expect(useWorkflowEditorStore.getState().past.length).toBeGreaterThan(0);

    store.switchSession("wf-b");
    store.hydrateFromServer({
      workflow: {
        id: "wf-b",
        name: "B",
        description: "",
        owner: "x",
        status: "active",
      },
      versions: [],
      activeSpec: { meta: {}, nodes: {}, edges: [] },
      loadedVersionId: null,
      currentVersion: "1.0.0",
      saveVersion: "1.0.0",
      saveName: "B",
    });

    useWorkflowEditorStore.getState().switchSession("wf-a");
    expect(useWorkflowEditorStore.getState().past.length).toBeGreaterThan(0);
  });

  it("resetForDraftIfNeeded clears canvas when opening draft without cache", () => {
    const store = useWorkflowEditorStore.getState();
    store.switchSession("wf-a");
    store.setSpec(
      { meta: {}, nodes: { n1: { type: "noop", config: {} } }, edges: [] },
      { replaceHistory: true },
    );
    store.switchSession(DRAFT_SESSION_KEY);
    useWorkflowEditorStore.getState().resetForDraftIfNeeded(DRAFT_SESSION_KEY, false);
    expect(
      Object.keys(useWorkflowEditorStore.getState().spec.nodes ?? {}),
    ).toEqual([]);
  });

  it("resetForDraftIfNeeded does not clear when draft was restored from cache", () => {
    const store = useWorkflowEditorStore.getState();
    store.switchSession(DRAFT_SESSION_KEY);
    store.setSpec(
      { meta: {}, nodes: { d1: { type: "noop", config: {} } }, edges: [] },
      { replaceHistory: true },
    );
    store.switchSession("wf-a");
    store.hydrateFromServer({
      workflow: {
        id: "wf-a",
        name: "A",
        description: "",
        owner: "x",
        status: "active",
      },
      versions: [],
      activeSpec: { meta: {}, nodes: {}, edges: [] },
      loadedVersionId: null,
      currentVersion: "1.0.0",
      saveVersion: "1.0.0",
      saveName: "A",
    });
    useWorkflowEditorStore.getState().switchSession(DRAFT_SESSION_KEY);
    useWorkflowEditorStore.getState().resetForDraftIfNeeded(DRAFT_SESSION_KEY, true);
    expect(useWorkflowEditorStore.getState().spec.nodes?.d1).toBeDefined();
  });

  it("promoteDraftSnapshotToWorkflowId captures live state under workflow id", () => {
    const store = useWorkflowEditorStore.getState();
    store.switchSession(DRAFT_SESSION_KEY);
    store.setSpec(
      { meta: {}, nodes: { d1: { type: "noop", config: {} } }, edges: [] },
      { replaceHistory: true },
    );
    store.promoteDraftSnapshotToWorkflowId("wf-new");
    expect(useWorkflowEditorStore.getState().activeSessionKey).toBe("wf-new");
    store.switchSession("wf-other");
    store.hydrateFromServer({
      workflow: {
        id: "wf-other",
        name: "O",
        description: "",
        owner: "x",
        status: "active",
      },
      versions: [],
      activeSpec: { meta: {}, nodes: {}, edges: [] },
      loadedVersionId: null,
      currentVersion: "1.0.0",
      saveVersion: "1.0.0",
      saveName: "O",
    });
    useWorkflowEditorStore.getState().switchSession("wf-new");
    expect(useWorkflowEditorStore.getState().spec.nodes?.d1).toBeDefined();
  });

  it("clearSessionSnapshot removes cached re-entry state", () => {
    const store = useWorkflowEditorStore.getState();
    store.switchSession("wf-a");
    store.setSpec(
      { meta: {}, nodes: { n1: { type: "noop", config: {} } }, edges: [] },
      { replaceHistory: true },
    );
    store.switchSession("wf-b");
    store.clearSessionSnapshot("wf-a");
    store.hydrateFromServer({
      workflow: {
        id: "wf-b",
        name: "B",
        description: "",
        owner: "x",
        status: "active",
      },
      versions: [],
      activeSpec: { meta: {}, nodes: {}, edges: [] },
      loadedVersionId: null,
      currentVersion: "1.0.0",
      saveVersion: "1.0.0",
      saveName: "B",
    });
    useWorkflowEditorStore.getState().switchSession("wf-a");
    expect(useWorkflowEditorStore.getState().spec.nodes?.n1).toBeUndefined();
  });
});
