"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Plus, RefreshCw, Trash2 } from "lucide-react";

import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import { Pagination } from "@/components/common/Pagination";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading, TableSkeleton } from "@/components/LoadingSpinner";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import { useToast } from "@/components/ui/toaster";
import { apiDelete, apiGet, apiPatch, apiPost } from "@/lib/api";
import { ROUTES } from "@/lib/constants";
import { cn, formatDateTimeShort } from "@/lib/utils";

interface AgentItem {
  id: string;
  name: string;
  owner: string;
  status: string;
  archived: boolean;
}

interface AgentDetail extends AgentItem {
  current_version_id: string | null;
  created_at: string;
  updated_at: string;
}

interface VersionRow {
  id: string;
  agent_id: string;
  version: string;
  model: string | null;
  prompt: string | null;
  active: boolean;
  created_at: string;
}

interface AuditRow {
  id: string;
  actor: string;
  action: string;
  resource_type: string;
  resource_id: string | null;
  created_at: string;
}

export default function AgentsPageInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const id = searchParams.get("id");
  const qParam = searchParams.get("q") ?? "";

  const [searchDraft, setSearchDraft] = useState(qParam);
  const [page, setPage] = useState(1);
  const [list, setList] = useState<{ items: AgentItem[]; meta: { total: number; page: number; page_size: number } } | null>(null);
  const [detail, setDetail] = useState<{
    agent: AgentDetail;
    versions: VersionRow[];
    policies: { items: Array<{ id: string; policy_type: string; enabled: boolean }> };
    audit: { items: AuditRow[] };
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const [newAgentName, setNewAgentName] = useState("");
  const [newAgentOwner, setNewAgentOwner] = useState("system");

  const [editStatus, setEditStatus] = useState("");
  const [editArchived, setEditArchived] = useState(false);

  const [newVersion, setNewVersion] = useState("");
  const [newModel, setNewModel] = useState("");
  const [newPrompt, setNewPrompt] = useState("");
  const [newProviderName, setNewProviderName] = useState("");
  const [newApiBase, setNewApiBase] = useState("");
  const [newApiKey, setNewApiKey] = useState("");
  const [providerPresets, setProviderPresets] = useState<
    Array<{
      name: string;
      provider_type: string;
      default_api_base: string | null;
      requires_api_key: boolean;
      models: string[];
      description: string;
    }>
  >([]);

  const [runVersionId, setRunVersionId] = useState<string>("");
  const [runTrigger, setRunTrigger] = useState("ui");
  const [runCorrelation, setRunCorrelation] = useState("");

  const [confirmArchive, setConfirmArchive] = useState(false);

  useEffect(() => { setSearchDraft(qParam); }, [qParam, id]);

  useEffect(() => {
    apiGet<{ items: typeof providerPresets }>("/api/v1/llm/providers")
      .then((data) => setProviderPresets(data.items))
      .catch(() => {});
  }, []);

  const loadList = useCallback(async (p: number = page) => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiGet<{ items: AgentItem[]; meta: { total: number; page: number; page_size: number } }>("/api/v1/agents", {
        page: p,
        page_size: 25,
        q: qParam.trim() || undefined
      });
      setList(data);
      setDetail(null);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, [qParam, page]);

  const loadDetail = useCallback(async (agentId: string) => {
    setLoading(true);
    setError(null);
    try {
      const [dash, policies, audit] = await Promise.all([
        apiGet<{ agent: AgentDetail; versions: VersionRow[] }>(
          `/api/v1/agents/${agentId}/dashboard`
        ),
        apiGet<{ items: Array<{ id: string; policy_type: string; enabled: boolean }> }>(
          `/api/v1/policies`,
          { agent_id: agentId }
        ),
        apiGet<{ items: AuditRow[] }>(`/api/v1/policies/audit`, {
          limit: 50,
          resource_id: agentId,
          resource_type: "agent"
        })
      ]);
      setDetail({
        agent: dash.agent,
        versions: dash.versions,
        policies,
        audit
      });
      setList(null);
      setEditStatus(dash.agent.status);
      setEditArchived(dash.agent.archived);
      const active = dash.versions.find((v) => v.active);
      setRunVersionId(active?.id ?? dash.versions[0]?.id ?? "");
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (id) loadDetail(id);
    else loadList(page);
  }, [id, loadDetail, loadList, page]);

  const refresh = () => { if (id) loadDetail(id); else loadList(page); };

  const handlePageChange = (p: number) => {
    setPage(p);
    loadList(p);
  };

  const applySearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    const q = searchDraft.trim();
    router.push(q ? `${ROUTES.AGENTS}?q=${encodeURIComponent(q)}` : ROUTES.AGENTS);
  };

  const createAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAgentName.trim()) return;
    setBusy(true);
    setError(null);
    try {
      const created = await apiPost<{ name: string; owner: string; status: string }, AgentDetail>(
        "/api/v1/agents",
        { name: newAgentName.trim(), owner: newAgentOwner.trim() || "system", status: "active" }
      );
      setNewAgentName("");
      toast(`Created agent "${created.name}".`, "success");
      router.push(`${ROUTES.AGENTS}?id=${encodeURIComponent(created.id)}`);
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const saveAgentMeta = async () => {
    if (!id) return;
    setBusy(true);
    setError(null);
    try {
      const updated = await apiPatch<{ status: string; archived: boolean }, AgentDetail>(
        `/api/v1/agents/${id}`,
        { status: editStatus, archived: editArchived }
      );
      setDetail((d) => (d ? { ...d, agent: updated } : null));
      toast("Agent updated.", "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const archiveAgent = async () => {
    if (!id) return;
    setConfirmArchive(false);
    setBusy(true);
    setError(null);
    try {
      await apiDelete<AgentDetail>(`/api/v1/agents/${id}`);
      toast("Agent archived.", "success");
      router.push(ROUTES.AGENTS);
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const activateVersion = async (versionId: string) => {
    if (!id) return;
    setBusy(true);
    setError(null);
    try {
      const updated = await apiPost<Record<string, never>, AgentDetail>(
        `/api/v1/agents/${id}/versions/${versionId}/activate`
      );
      setDetail((d) =>
        d ? { ...d, agent: updated, versions: d.versions.map((v) => ({ ...v, active: v.id === versionId })) } : null
      );
      setRunVersionId(versionId);
      toast("Active version updated.", "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const submitNewVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !newVersion.trim()) return;
    setBusy(true);
    setError(null);
    try {
      const selectedPreset = providerPresets.find((p) => p.name === newProviderName);
      const providerPayload = selectedPreset
        ? {
            provider_type: selectedPreset.provider_type,
            model: newModel.trim(),
            api_base: newApiBase.trim() || selectedPreset.default_api_base || undefined,
            api_key: newApiKey.trim() || undefined,
          }
        : undefined;
      const v = await apiPost<
        { version: string; model?: string; prompt?: string; provider?: unknown },
        VersionRow
      >(`/api/v1/agents/${id}/versions`, {
        version: newVersion.trim(),
        model: newModel.trim() || undefined,
        prompt: newPrompt.trim() || undefined,
        provider: providerPayload,
      });
      setDetail((d) => (d ? { ...d, versions: [v, ...d.versions] } : null));
      setNewVersion("");
      setNewModel("");
      setNewPrompt("");
      setNewProviderName("");
      setNewApiBase("");
      setNewApiKey("");
      toast(`Version ${v.version} created.`, "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const enqueueRun = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id) return;
    setBusy(true);
    setError(null);
    try {
      const run = await apiPost<
        { agent_version_id?: string; trigger?: string; correlation_id?: string },
        { id: string; status: string }
      >(`/api/v1/agents/${id}/runs`, {
        agent_version_id: runVersionId || undefined,
        trigger: runTrigger.trim() || "ui",
        correlation_id: runCorrelation.trim() || undefined
      });
      toast(`Run ${run.id.slice(0, 8)}... queued (${run.status}).`, "success");
      setRunCorrelation("");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  if (loading && !list && !detail) {
    return <PageContainer><PageLoading message="Loading agents..." /></PageContainer>;
  }

  if (id && detail) {
    const { agent, versions, policies, audit } = detail;
    return (
      <PageContainer>
        <PageHeader
          title={agent.name}
          description={`Owner ${agent.owner} · ${agent.status}${agent.archived ? " · archived" : ""}`}
          actions={
            <>
              <Button variant="outline" size="sm" onClick={refresh} disabled={loading || busy}>
                <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Refresh
              </Button>
              <Link
                href={`${ROUTES.OBS_RUNS}?agent_id=${encodeURIComponent(agent.id)}`}
                className={cn(buttonVariants({ variant: "secondary", size: "sm" }))}
              >
                View runs
              </Link>
              <Button variant="destructive" size="sm" onClick={() => setConfirmArchive(true)} disabled={busy || agent.archived}>
                <Trash2 className="h-4 w-4 mr-1" /> Archive
              </Button>
              <Link href={ROUTES.AGENTS} className={cn(buttonVariants({ variant: "secondary", size: "sm" }))}>
                Back to list
              </Link>
            </>
          }
        />
        {error && <ErrorDisplay error={error} className="mb-4" />}

        <ConfirmDialog
          open={confirmArchive}
          title="Archive agent"
          description={`Are you sure you want to archive "${agent.name}"? The agent will be soft-deleted.`}
          confirmLabel="Archive"
          variant="destructive"
          onConfirm={() => void archiveAgent()}
          onCancel={() => setConfirmArchive(false)}
        />

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Agent settings</CardTitle>
              <CardDescription>Status and archive flag</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex flex-col gap-1">
                <label className="text-muted-foreground">Status</label>
                <select
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value)}
                >
                  <option value="active">active</option>
                  <option value="paused">paused</option>
                  <option value="deprecated">deprecated</option>
                </select>
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={editArchived}
                  onChange={(e) => setEditArchived(e.target.checked)}
                  className="h-4 w-4 rounded border-input"
                />
                Archived
              </label>
              <Button size="sm" onClick={() => void saveAgentMeta()} disabled={busy}>
                Save changes
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Enqueue run</CardTitle>
              <CardDescription>Creates a queued run for this agent</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-3 text-sm" onSubmit={(e) => void enqueueRun(e)}>
                <div className="flex flex-col gap-1">
                  <label className="text-muted-foreground">Version</label>
                  <select
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    value={runVersionId}
                    onChange={(e) => setRunVersionId(e.target.value)}
                  >
                    {versions.length === 0 ? (
                      <option value="">No versions — create one first</option>
                    ) : (
                      versions.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.version}{v.active ? " (active)" : ""}
                        </option>
                      ))
                    )}
                  </select>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-muted-foreground">Trigger</label>
                  <Input value={runTrigger} onChange={(e) => setRunTrigger(e.target.value)} placeholder="ui" />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-muted-foreground">Correlation ID (optional)</label>
                  <Input value={runCorrelation} onChange={(e) => setRunCorrelation(e.target.value)} placeholder="trace key" />
                </div>
                <Button type="submit" size="sm" disabled={busy || versions.length === 0}>
                  Enqueue run
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="text-lg">Versions</CardTitle>
            <CardDescription>Register, inspect, and set the active version</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Version</TableHead>
                  <TableHead>Model</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {versions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-muted-foreground">
                      No versions yet. Add one below.
                    </TableCell>
                  </TableRow>
                ) : (
                  versions.map((v) => (
                    <TableRow key={v.id}>
                      <TableCell className="font-medium">
                        {v.version}
                        {v.active ? <span className="ml-2 text-xs text-primary font-normal">active</span> : null}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">{v.model ?? "—"}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">{formatDateTimeShort(v.created_at)}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={busy || v.active}
                          onClick={() => void activateVersion(v.id)}
                        >
                          Set active
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>

            <div>
              <h4 className="text-sm font-medium mb-2">New version</h4>
              <form className="grid gap-3 md:grid-cols-2" onSubmit={(e) => void submitNewVersion(e)}>
                <Input placeholder="Version label (e.g. 1.0.0)" value={newVersion} onChange={(e) => setNewVersion(e.target.value)} required />
                <div className="flex flex-col gap-1">
                  <select
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    value={newProviderName}
                    onChange={(e) => {
                      const name = e.target.value;
                      setNewProviderName(name);
                      const preset = providerPresets.find((p) => p.name === name);
                      if (preset) {
                        setNewApiBase(preset.default_api_base ?? "");
                        setNewModel(preset.models[0] ?? "");
                        setNewApiKey("");
                      } else {
                        setNewApiBase("");
                        setNewModel("");
                        setNewApiKey("");
                      }
                    }}
                  >
                    <option value="">Provider (optional)</option>
                    {providerPresets.map((p) => (
                      <option key={p.name} value={p.name}>
                        {p.name.charAt(0).toUpperCase() + p.name.slice(1)} — {p.description}
                      </option>
                    ))}
                  </select>
                </div>
                {(() => {
                  const preset = providerPresets.find((p) => p.name === newProviderName);
                  if (!preset) {
                    return (
                      <Input placeholder="Model (optional)" value={newModel} onChange={(e) => setNewModel(e.target.value)} />
                    );
                  }
                  return (
                    <>
                      {preset.models.length > 0 ? (
                        <div className="flex flex-col gap-1">
                          <select
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                            value={newModel}
                            onChange={(e) => setNewModel(e.target.value)}
                          >
                            {preset.models.map((m) => (
                              <option key={m} value={m}>{m}</option>
                            ))}
                          </select>
                        </div>
                      ) : (
                        <Input
                          placeholder="Model name (e.g. llama3.1)"
                          value={newModel}
                          onChange={(e) => setNewModel(e.target.value)}
                        />
                      )}
                      {preset.provider_type === "openai_compatible" && (
                        <div className="flex flex-col gap-1">
                          <Input
                            placeholder="API Base URL"
                            value={newApiBase}
                            onChange={(e) => setNewApiBase(e.target.value)}
                          />
                          <p className="text-[10px] text-muted-foreground">
                            Server endpoint (pre-filled from preset)
                          </p>
                        </div>
                      )}
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-2">
                          <Input
                            type="password"
                            placeholder={preset.requires_api_key ? "API Key (required)" : "API Key (optional)"}
                            value={newApiKey}
                            onChange={(e) => setNewApiKey(e.target.value)}
                          />
                          <span className={`shrink-0 text-[10px] font-medium px-1.5 py-0.5 rounded ${
                            preset.requires_api_key
                              ? "bg-red-100 text-red-700"
                              : "bg-green-100 text-green-700"
                          }`}>
                            {preset.requires_api_key ? "Key required" : "No key needed"}
                          </span>
                        </div>
                        {!preset.requires_api_key && (
                          <p className="text-[10px] text-muted-foreground">
                            Leave blank for local servers
                          </p>
                        )}
                      </div>
                    </>
                  );
                })()}
                <div className="md:col-span-2">
                  <textarea
                    className="flex min-h-[88px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                    placeholder="System prompt (optional)"
                    value={newPrompt}
                    onChange={(e) => setNewPrompt(e.target.value)}
                  />
                </div>
                <div className="md:col-span-2">
                  <Button type="submit" size="sm" disabled={busy}>
                    <Plus className="h-4 w-4 mr-1" /> Create version
                  </Button>
                </div>
              </form>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4 md:grid-cols-2 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Policies</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-sm space-y-2">
                {policies.items.length === 0 ? (
                  <p className="text-muted-foreground">No policies for this agent.</p>
                ) : (
                  policies.items.map((p) => (
                    <li key={p.id}>
                      {p.policy_type}{" "}
                      <span className="text-muted-foreground">({p.enabled ? "enabled" : "disabled"})</span>
                    </li>
                  ))
                )}
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Audit</CardTitle>
              <CardDescription>Actions on this agent (resource_type=agent)</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm space-y-2 max-h-64 overflow-y-auto">
                {audit.items.length === 0 ? (
                  <p className="text-muted-foreground">No audit entries for this agent.</p>
                ) : (
                  audit.items.map((a) => (
                    <li key={a.id} className="border-b border-border/40 pb-2 last:border-0">
                      <span className="font-medium">{a.action}</span>
                      <span className="text-muted-foreground">
                        {" "} · {a.actor} · {formatDateTimeShort(a.created_at)}
                      </span>
                    </li>
                  ))
                )}
              </ul>
            </CardContent>
          </Card>
        </div>

        <p className="mt-4 text-xs text-muted-foreground">
          ID <span className="font-mono">{agent.id}</span> · Created {formatDateTimeShort(agent.created_at)} · Updated {formatDateTimeShort(agent.updated_at)}
          {agent.current_version_id ? (
            <> · Current version id <span className="font-mono">{agent.current_version_id.slice(0, 8)}...</span></>
          ) : null}
        </p>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Agents"
        description={list ? `${list.meta.total} agent(s) registered` : "Registry and lifecycle"}
        actions={
          <Button variant="outline" size="sm" onClick={refresh} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
        }
      />
      {error && <ErrorDisplay error={error} className="mb-4" />}

      <div className="grid gap-4 lg:grid-cols-2 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Search</CardTitle>
            <CardDescription>Filter by name or owner (server-side)</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="flex flex-wrap gap-2" onSubmit={applySearch}>
              <Input
                className="max-w-md flex-1 min-w-[12rem]"
                placeholder="Name or owner..."
                value={searchDraft}
                onChange={(e) => setSearchDraft(e.target.value)}
              />
              <Button type="submit" variant="secondary" size="sm">Search</Button>
              {qParam ? (
                <Button type="button" variant="ghost" size="sm" onClick={() => router.push(ROUTES.AGENTS)}>
                  Clear
                </Button>
              ) : null}
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">New agent</CardTitle>
            <CardDescription>Creates a registry record (admin)</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-3" onSubmit={(e) => void createAgent(e)}>
              <Input placeholder="Unique name" value={newAgentName} onChange={(e) => setNewAgentName(e.target.value)} required />
              <Input placeholder="Owner (default: system)" value={newAgentOwner} onChange={(e) => setNewAgentOwner(e.target.value)} />
              <Button type="submit" size="sm" disabled={busy}>
                <Plus className="h-4 w-4 mr-1" /> Create agent
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      {loading && list ? <TableSkeleton rows={6} /> : null}
      {!loading && list && (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Archived</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {list.items.map((agent) => (
                <TableRow key={agent.id}>
                  <TableCell>
                    <Link
                      href={`${ROUTES.AGENTS}?id=${encodeURIComponent(agent.id)}`}
                      className="font-medium text-primary hover:underline"
                    >
                      {agent.name}
                    </Link>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{agent.owner}</TableCell>
                  <TableCell>{agent.status}</TableCell>
                  <TableCell>{agent.archived ? "yes" : "no"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <Pagination
            page={list.meta.page ?? page}
            pageSize={list.meta.page_size ?? 25}
            total={list.meta.total}
            onPageChange={handlePageChange}
          />
        </>
      )}
    </PageContainer>
  );
}
