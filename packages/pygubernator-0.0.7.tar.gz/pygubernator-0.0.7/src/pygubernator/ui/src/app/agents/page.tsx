import { Suspense } from "react";

import AgentsPageInner from "./AgentsPageInner";
import { PageLoading } from "@/components/LoadingSpinner";

export default function AgentsPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading…" />}>
      <AgentsPageInner />
    </Suspense>
  );
}
