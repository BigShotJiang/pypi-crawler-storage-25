"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { Play, RefreshCw, Search, Trash2, X } from "lucide-react";

import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import { Pagination } from "@/components/common/Pagination";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading, TableSkeleton } from "@/components/LoadingSpinner";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import WorkflowRunDag from "@/components/workflows/WorkflowRunDag";
import StepDetailPanel from "@/components/workflows/StepDetailPanel";
import { usePolling } from "@/hooks/usePolling";
import { ApiError, apiDelete, apiGet, apiPost } from "@/lib/api";
import { useToast } from "@/components/ui/toaster";
import { ROUTES } from "@/lib/constants";
import { cn, formatDateTimeShort } from "@/lib/utils";

/* ---------- Types ---------- */

interface WorkflowRunItem {
  id: string;
  workflow_id: string;
  workflow_name?: string;
  workflow_version_id: string | null;
  status: string;
  input_json: Record<string, unknown>;
  output_json: Record<string, unknown>;
  error_message: string | null;
  started_at: string | null;
  completed_at: string | null;
  duration_ms: number | null;
  created_by: string;
}

interface StepItem {
  id: string;
  workflow_run_id: string;
  node_id: string;
  node_type: string;
  status: string;
  input_json: Record<string, unknown>;
  output_json: Record<string, unknown>;
  error_message: string | null;
  output_handle: string;
  started_at: string | null;
  completed_at: string | null;
  duration_ms: number | null;
}

const STATUSES = ["all", "running", "completed", "failed", "cancelled"] as const;

const STATUS_COLORS: Record<string, string> = {
  completed: "text-green-600",
  failed: "text-red-600",
  running: "text-yellow-600",
  cancelled: "text-muted-foreground",
  pending: "text-muted-foreground",
};

/* ---------- Filter bar ---------- */

function FilterBar({
  search,
  onSearchChange,
  status,
  onStatusChange,
  onClear,
  loading,
  onRefresh,
}: {
  search: string;
  onSearchChange: (v: string) => void;
  status: string;
  onStatusChange: (v: string) => void;
  onClear: () => void;
  loading: boolean;
  onRefresh: () => void;
}) {
  const hasFilters = search || status !== "all";
  return (
    <div className="flex flex-wrap items-center gap-2 mb-4">
      <div className="relative flex-1 min-w-[200px] max-w-sm">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search runs..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-9 h-9"
        />
      </div>
      <div className="flex gap-1">
        {STATUSES.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => onStatusChange(s)}
            className={cn(
              "px-3 py-1.5 text-xs font-medium rounded-md transition-colors capitalize",
              status === s
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:text-foreground",
            )}
          >
            {s}
          </button>
        ))}
      </div>
      {hasFilters && (
        <Button variant="ghost" size="sm" onClick={onClear} className="h-8">
          <X className="h-3.5 w-3.5 mr-1" /> Clear
        </Button>
      )}
      <Button
        variant="outline"
        size="sm"
        onClick={onRefresh}
        disabled={loading}
        className="ml-auto h-8"
      >
        <RefreshCw
          className={`h-3.5 w-3.5 mr-1 ${loading ? "animate-spin" : ""}`}
        />
        Refresh
      </Button>
    </div>
  );
}

/* ---------- Run detail ---------- */

function RunDetail({
  runId,
  onBack,
}: {
  runId: string;
  onBack: string;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [detail, setDetail] = useState<{
    run: WorkflowRunItem;
    steps: StepItem[];
  } | null>(null);
  const [selectedStep, setSelectedStep] = useState<StepItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [replayBusy, setReplayBusy] = useState(false);

  const loadDetail = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiGet<{ run: WorkflowRunItem; steps: StepItem[] }>(
        `/api/v1/workflows/runs/${runId}`,
      );
      setDetail(data);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, [runId]);

  useEffect(() => {
    loadDetail();
  }, [loadDetail]);

  const isRunActive =
    detail?.run.status === "pending" || detail?.run.status === "running";

  usePolling(loadDetail, 5000, isRunActive ?? false);

  const handleDeleteRun = useCallback(async () => {
    const confirmed = window.confirm(
      `Delete run ${runId.slice(0, 8)}…? This cannot be undone.`,
    );
    if (!confirmed) return;
    setDeleteBusy(true);
    try {
      await apiDelete(`/api/v1/workflows/runs/${runId}`);
      toast("Run deleted", "success");
      router.push(onBack);
    } catch (e) {
      const msg =
        e instanceof ApiError
          ? e.message
          : e instanceof Error
            ? e.message
            : String(e);
      toast(msg, "error");
    } finally {
      setDeleteBusy(false);
    }
  }, [runId, onBack, router, toast]);

  const handleReplay = useCallback(async () => {
    if (!detail) return;
    setReplayBusy(true);
    try {
      const data = await apiPost<
        { input_json: Record<string, unknown> },
        { run: { id: string } }
      >(
        `/api/v1/workflows/${detail.run.workflow_id}/execute`,
        { input_json: detail.run.input_json },
      );
      toast("Replay started", "success");
      router.push(`${ROUTES.RUNS}?run_id=${data.run.id}`);
    } catch (e) {
      const msg =
        e instanceof ApiError
          ? e.message
          : e instanceof Error
            ? e.message
            : String(e);
      toast(msg, "error");
    } finally {
      setReplayBusy(false);
    }
  }, [detail, router, toast]);

  if (loading && !detail) {
    return <PageLoading message="Loading run..." />;
  }

  if (!detail) {
    return error ? <ErrorDisplay error={error} /> : null;
  }

  const { run, steps } = detail;

  return (
    <>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold">
            Run {run.id.slice(0, 8)}...
          </h2>
          <p className="text-sm text-muted-foreground">
            <span className={STATUS_COLORS[run.status] ?? ""}>
              {run.status}
            </span>
            {run.workflow_name ? ` · ${run.workflow_name}` : ""}
            {" · "}
            {run.duration_ms != null ? `${run.duration_ms}ms` : "—"}
            {run.created_by ? ` · by ${run.created_by}` : ""}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={loadDetail}
            disabled={loading}
          >
            <RefreshCw
              className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`}
            />{" "}
            Refresh
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => void handleReplay()}
            disabled={replayBusy || isRunActive}
            title="Re-run this workflow with the same inputs"
          >
            <Play className="h-4 w-4 mr-1" />
            {replayBusy ? "Replaying…" : "Replay"}
          </Button>
          <Button
            variant="destructive"
            size="sm"
            onClick={() => void handleDeleteRun()}
            disabled={deleteBusy || isRunActive}
            title={
              isRunActive
                ? "Cancel the run or wait until it finishes before deleting"
                : undefined
            }
          >
            <Trash2 className="h-4 w-4 mr-1" />
            {deleteBusy ? "Deleting…" : "Delete"}
          </Button>
          <Link
            href={onBack}
            className={cn(
              buttonVariants({ variant: "secondary", size: "sm" }),
            )}
          >
            Back to runs
          </Link>
        </div>
      </div>
      {error && <ErrorDisplay error={error} className="mb-4" />}

      <div className="grid gap-4 lg:grid-cols-[1fr_350px]">
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Step timeline</CardTitle>
              <CardDescription>{steps.length} step(s)</CardDescription>
            </CardHeader>
            <CardContent>
              <WorkflowRunDag
                steps={steps}
                selectedStep={selectedStep?.node_id ?? null}
                onSelectStep={(nodeId) => {
                  setSelectedStep(
                    steps.find((s) => s.node_id === nodeId) ?? null,
                  );
                }}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Steps</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Node</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Handle</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {steps.map((step) => (
                    <TableRow
                      key={step.id}
                      className={cn(
                        "cursor-pointer",
                        selectedStep?.id === step.id && "bg-muted/50",
                      )}
                      onClick={() => setSelectedStep(step)}
                    >
                      <TableCell className="font-medium">
                        {step.node_id}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {step.node_type}
                      </TableCell>
                      <TableCell className={STATUS_COLORS[step.status] ?? ""}>
                        {step.status}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {step.duration_ms != null
                          ? `${step.duration_ms}ms`
                          : "—"}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {step.output_handle}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {run.error_message && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-red-600">Error</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="text-sm whitespace-pre-wrap text-red-600">
                  {run.error_message}
                </pre>
              </CardContent>
            </Card>
          )}
        </div>

        <StepDetailPanel step={selectedStep} />
      </div>
    </>
  );
}

/* ---------- Run list ---------- */

function RunList({
  search,
  statusFilter,
  workflowId,
  loading,
  setLoading,
}: {
  search: string;
  statusFilter: string;
  workflowId: string | null;
  loading: boolean;
  setLoading: (v: boolean) => void;
}) {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const [list, setList] = useState<{
    items: WorkflowRunItem[];
    meta: { total: number; page: number; page_size: number };
  } | null>(null);
  const [error, setError] = useState<Error | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const loadList = useCallback(
    async (p: number = page) => {
      setLoading(true);
      setError(null);
      try {
        const params: Record<string, string | number | undefined> = {
          page: p,
          page_size: 25,
        };
        if (workflowId) params.workflow_id = workflowId;
        if (statusFilter !== "all") params.status = statusFilter;
        if (search) params.search = search;

        const data = await apiGet<{
          items: WorkflowRunItem[];
          meta: { total: number; page: number; page_size: number };
        }>("/api/v1/workflows/runs/list", params);
        setList(data);
      } catch (e) {
        setError(e instanceof Error ? e : new Error(String(e)));
      } finally {
        setLoading(false);
      }
    },
    [workflowId, statusFilter, search, page, setLoading],
  );

  // Reset page when filters change
  useEffect(() => {
    setPage(1);
  }, [search, statusFilter, workflowId]);

  useEffect(() => {
    loadList(page);
  }, [loadList, page]);

  const { lastUpdated } = usePolling(
    () => loadList(page),
    10000,
    true,
  );

  const handleDeleteRun = useCallback(
    async (run: WorkflowRunItem) => {
      if (run.status === "running") {
        toast(
          "Cannot delete a running run; cancel it first or wait until it finishes.",
          "error",
        );
        return;
      }
      const confirmed = window.confirm(
        `Delete run ${run.id.slice(0, 8)}…? This cannot be undone.`,
      );
      if (!confirmed) return;
      setDeletingId(run.id);
      try {
        await apiDelete(`/api/v1/workflows/runs/${run.id}`);
        toast("Run deleted", "success");
        await loadList(page);
      } catch (e) {
        const msg =
          e instanceof ApiError
            ? e.message
            : e instanceof Error
              ? e.message
              : String(e);
        toast(msg, "error");
      } finally {
        setDeletingId(null);
      }
    },
    [loadList, page, toast],
  );

  if (loading && !list) {
    return <TableSkeleton rows={6} />;
  }

  return (
    <>
      {error && <ErrorDisplay error={error} className="mb-4" />}
      {lastUpdated && (
        <p className="text-xs text-muted-foreground mb-2">
          {list?.meta.total ?? 0} run(s) · Last updated{" "}
          {lastUpdated.toLocaleTimeString()}
        </p>
      )}
      {!loading && list && list.items.length === 0 && (
        <p className="text-sm text-muted-foreground py-8 text-center">
          No runs found. Execute a workflow to see runs here.
        </p>
      )}
      {!loading && list && list.items.length > 0 && (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Run ID</TableHead>
                <TableHead>Workflow</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Created by</TableHead>
                <TableHead>Started</TableHead>
                <TableHead className="w-[100px] text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {list.items.map((run) => (
                <TableRow key={run.id}>
                  <TableCell>
                    <Link
                      href={`${ROUTES.RUNS}?run_id=${encodeURIComponent(run.id)}`}
                      className="font-medium text-primary hover:underline font-mono text-sm"
                    >
                      {run.id.slice(0, 12)}...
                    </Link>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {run.workflow_name || run.workflow_id.slice(0, 8) + "..."}
                  </TableCell>
                  <TableCell className={STATUS_COLORS[run.status] ?? ""}>
                    {run.status}
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {run.duration_ms != null ? `${run.duration_ms}ms` : "—"}
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {run.created_by}
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {run.started_at
                      ? formatDateTimeShort(run.started_at)
                      : "—"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                      disabled={deletingId === run.id || run.status === "running"}
                      title={
                        run.status === "running"
                          ? "Cannot delete while running"
                          : "Delete run"
                      }
                      aria-label="Delete run"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        void handleDeleteRun(run);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <Pagination
            page={list.meta.page ?? page}
            pageSize={list.meta.page_size ?? 25}
            total={list.meta.total}
            onPageChange={setPage}
          />
        </>
      )}
    </>
  );
}

/* ---------- Main page ---------- */

export default function RunsPageInner() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const runId = searchParams.get("run_id");
  const workflowId = searchParams.get("workflow_id");

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [loading, setLoading] = useState(true);

  // Debounce search input
  const [debouncedSearch, setDebouncedSearch] = useState("");
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(timer);
  }, [search]);

  const handleClear = () => {
    setSearch("");
    setStatusFilter("all");
    if (workflowId) {
      router.push(ROUTES.RUNS);
    }
  };

  // Detail view
  if (runId) {
    const backHref = workflowId
      ? `${ROUTES.RUNS}?workflow_id=${workflowId}`
      : ROUTES.RUNS;
    return (
      <PageContainer>
        <RunDetail runId={runId} onBack={backHref} />
      </PageContainer>
    );
  }

  // List view
  return (
    <PageContainer>
      <PageHeader
        title="Runs"
        description="Workflow execution history"
      />
      <FilterBar
        search={search}
        onSearchChange={setSearch}
        status={statusFilter}
        onStatusChange={setStatusFilter}
        onClear={handleClear}
        loading={loading}
        onRefresh={() => setLoading(true)}
      />
      <RunList
        search={debouncedSearch}
        statusFilter={statusFilter}
        workflowId={workflowId}
        loading={loading}
        setLoading={setLoading}
      />
    </PageContainer>
  );
}
