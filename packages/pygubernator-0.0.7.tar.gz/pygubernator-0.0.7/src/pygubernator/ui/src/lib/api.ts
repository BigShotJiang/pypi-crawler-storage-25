import { getApiBaseUrl } from "@/lib/settings";
import { clearAccessToken, getAccessToken } from "@/lib/auth-storage";
import { AUTH_SESSION_EXPIRED_EVENT } from "@/lib/constants";

function headers(): HeadersInit {
  const token = getAccessToken();
  return token
    ? {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      }
    : {
        "Content-Type": "application/json"
      };
}

/** Build absolute or same-origin URL for API calls. */
export function apiUrl(path: string, query?: Record<string, string | number | boolean | undefined | null>): string {
  const base = getApiBaseUrl();
  const p = path.startsWith("/") ? path : `/${path}`;
  if (!query || Object.keys(query).length === 0) {
    return `${base}${p}`;
  }
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(query)) {
    if (v === undefined || v === null || v === "") continue;
    q.set(k, String(v));
  }
  const s = q.toString();
  return s ? `${base}${p}?${s}` : `${base}${p}`;
}

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public body?: string
  ) {
    super(message);
    this.name = "ApiError";
  }
}

async function parseJsonOrText(res: Response): Promise<unknown> {
  const ct = res.headers.get("content-type") ?? "";
  if (ct.includes("application/json")) {
    try {
      return await res.json();
    } catch {
      return null;
    }
  }
  return await res.text();
}

function extractErrorMessage(data: unknown, status: number): string {
  if (typeof data === "object" && data !== null) {
    const obj = data as Record<string, unknown>;
    if (typeof obj.detail === "string") return obj.detail;
    if (typeof obj.message === "string") return obj.message;
    if (typeof obj.error === "string") return obj.error;
    if (Array.isArray(obj.errors) && obj.errors.length > 0) {
      return obj.errors.map(String).join("; ");
    }
  }
  if (typeof data === "string" && data.length > 0 && data.length < 500) {
    return data;
  }
  return `API ${status}`;
}

async function _request<T>(
  method: string,
  url: string,
  body?: unknown
): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      method,
      headers: headers(),
      body: body !== undefined ? JSON.stringify(body) : undefined,
      cache: "no-store"
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Failed to fetch";
    if (msg.includes("Failed to fetch") || msg.includes("NetworkError")) {
      throw new ApiError(
        `Unable to connect to API at ${getApiBaseUrl() || "(same origin)"}`,
        0
      );
    }
    throw e;
  }
  const data = await parseJsonOrText(res);
  if (!res.ok) {
    if (res.status === 401) {
      clearAccessToken();
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent(AUTH_SESSION_EXPIRED_EVENT));
      }
    }
    throw new ApiError(
      extractErrorMessage(data, res.status),
      res.status,
      String(data)
    );
  }
  return data as T;
}

export async function apiGet<T>(
  path: string,
  query?: Record<string, string | number | boolean | undefined | null>
): Promise<T> {
  return _request<T>("GET", apiUrl(path, query));
}

export async function apiPost<TReq extends object, TRes>(
  path: string,
  body?: TReq
): Promise<TRes> {
  return _request<TRes>("POST", apiUrl(path), body);
}

export async function apiPatch<TReq extends object, TRes>(
  path: string,
  body: TReq
): Promise<TRes> {
  return _request<TRes>("PATCH", apiUrl(path), body);
}

export async function apiDelete<T>(
  path: string
): Promise<T> {
  return _request<T>("DELETE", apiUrl(path));
}

// --- Settings (pycharter / pystator parity) ---

export interface DatabaseTestRequest {
  connection_string?: string;
  host?: string;
  port?: number;
  database?: string;
  username?: string;
  password?: string;
}

export interface DatabaseConfigResponse {
  configured_url: string | null;
  actual_url: string;
  database_type: string;
  is_default: boolean;
  workflow_count: number;
  message: string;
}

export interface DatabaseTestResponse {
  success: boolean;
  message: string;
}

export interface ControlPlaneInfoResponse {
  api_host: string;
  api_port: number;
  api_url: string;
  ui_host: string;
  ui_port: number;
}

export async function getDatabaseConfig(): Promise<DatabaseConfigResponse> {
  return apiGet<DatabaseConfigResponse>("/api/v1/settings/database-config");
}

export async function testDatabase(
  body: DatabaseTestRequest
): Promise<DatabaseTestResponse> {
  return apiPost<DatabaseTestRequest, DatabaseTestResponse>(
    "/api/v1/settings/test-database",
    body
  );
}

export async function getControlPlaneInfo(): Promise<ControlPlaneInfoResponse> {
  return apiGet<ControlPlaneInfoResponse>("/api/v1/settings/control-plane");
}
