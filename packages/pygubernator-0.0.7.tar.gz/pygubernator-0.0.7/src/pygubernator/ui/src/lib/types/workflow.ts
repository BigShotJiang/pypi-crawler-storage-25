/** Shared types for the workflow editor — persisted schema and API models. */

export interface SpecNode {
  type: string;
  config: Record<string, unknown>;
  position?: { x: number; y: number };
}

export interface SpecEdge {
  source: string;
  target: string;
  source_handle?: string;
  target_handle?: string;
  condition?: string | null;
}

export interface SpecJson {
  meta?: { name?: string; version?: string; description?: string };
  nodes?: Record<string, SpecNode>;
  edges?: SpecEdge[];
}

export interface WorkflowItem {
  id: string;
  name: string;
  description: string;
  owner: string;
  status: string;
}

export interface VersionRow {
  id: string;
  version: string;
  spec_json: SpecJson;
  active: boolean;
}

export interface StepItem {
  id: string;
  workflow_run_id: string;
  node_id: string;
  node_type: string;
  status: string;
  input_json: Record<string, unknown>;
  output_json: Record<string, unknown>;
  error_message: string | null;
  output_handle: string;
  started_at: string | null;
  completed_at: string | null;
  duration_ms: number | null;
}

export interface WorkflowNodePortItem {
  name: string;
  direction: string;
  kind: string;
  label?: string | null;
  multiple?: boolean;
}

export interface WorkflowNodeFieldItem {
  name: string;
  field_type: string;
  label: string;
  required?: boolean;
  default?: unknown;
  help_text?: string;
  options?: string[];
  placeholder?: string | null;
  visible_if?: Record<string, unknown>;
}

export interface WorkflowNodeTypeItem {
  type_name: string;
  display_name: string;
  category: string;
  description: string;
  color?: string | null;
  icon?: string | null;
  inputs?: WorkflowNodePortItem[];
  outputs?: WorkflowNodePortItem[];
  fields?: WorkflowNodeFieldItem[];
  tags?: string[];
  supports_streaming?: boolean;
  supports_checkpointing?: boolean;
  supports_subgraph?: boolean;
  runtime_kind?: string;
}
