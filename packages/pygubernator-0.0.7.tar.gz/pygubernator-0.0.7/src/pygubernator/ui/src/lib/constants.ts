/** Default app name (overridden by injected config / API). */
export const APP_NAME = "PyGubernator";

/** localStorage key for theme (inline script in layout reads this). */
export const THEME_STORAGE_KEY = "pygubernator-theme";

export const NAMED_THEME_IDS = [
  "ocean",
  "forest",
  "sunset",
  "high-contrast",
  "sepia",
  "violet",
  "cathay"
] as const;
export type NamedThemeId = (typeof NAMED_THEME_IDS)[number];

export const API_CONNECTION_ERROR_MESSAGE =
  "API server not connected. Start it with: pygubernator api";

export const AUTH_SESSION_EXPIRED_EVENT = "pygubernator:auth-session-expired";
export const LOGIN_REASON_SESSION_EXPIRED = "session_expired";

/**
 * When the workflow editor opens without `?id=`, restore this last-opened workflow
 * (e.g. after using the main nav). Use `/workflows/editor/?new=1` for a blank canvas.
 */
export const WORKFLOW_EDITOR_LAST_ID_KEY = "pygubernator-workflow-editor-last-id";

export const ROUTES = {
  HOME: "/",
  LOGIN: "/login",
  AGENTS: "/agents/",
  RUNS: "/runs/",
  OBSERVABILITY: "/observability/",
  OBS_INCIDENTS: "/observability/incidents/",
  OBS_RUNS: "/observability/runs/",
  OBS_ALERTS: "/observability/alerts/",
  WORKFLOWS: "/workflows/",
  WORKFLOW_EDITOR: "/workflows/editor/",
  WORKFLOW_RUNS: "/runs/",
  CHAT: "/chat/",
  SCHEDULES: "/schedules/",
  WEBHOOKS: "/webhooks/",
  SETTINGS: "/settings/"
} as const;
