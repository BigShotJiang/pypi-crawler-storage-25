import type { SpecNode, WorkflowNodeFieldItem, WorkflowNodeTypeItem } from "@/lib/types/workflow";
import { getWorkflowNodeTypeMeta } from "@/lib/workflow-node-types";

export type WorkflowValidationSeverity = "error" | "warning";

export interface WorkflowValidationIssue {
  code: string;
  message: string;
  severity: WorkflowValidationSeverity;
  field?: string;
}

function isFieldMissing(field: WorkflowNodeFieldItem, config: Record<string, unknown>): boolean {
  const value = config[field.name];
  if (!field.required) return false;
  if (value === null || value === undefined) return true;
  if (typeof value === "string") return value.trim().length === 0;
  if (Array.isArray(value)) return value.length === 0;
  return false;
}

export function validateNodeSpec(
  nodeSpec: SpecNode,
  metadata?: WorkflowNodeTypeItem,
): WorkflowValidationIssue[] {
  const meta = metadata ?? getWorkflowNodeTypeMeta(nodeSpec.type);
  const config = nodeSpec.config ?? {};
  const issues: WorkflowValidationIssue[] = [];

  for (const field of meta.fields ?? []) {
    if (isFieldMissing(field, config)) {
      issues.push({
        code: "required_field_missing",
        message: `${field.label} is required`,
        severity: "error",
        field: field.name,
      });
    }
  }


  return issues;
}

export function summarizeValidationIssues(issues: WorkflowValidationIssue[]) {
  const errorCount = issues.filter((issue) => issue.severity === "error").length;
  const warningCount = issues.filter((issue) => issue.severity === "warning").length;
  return {
    errorCount,
    warningCount,
    highestSeverity: errorCount > 0 ? "error" : warningCount > 0 ? "warning" : null,
  } as const;
}
