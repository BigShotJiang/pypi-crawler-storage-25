/**
 * Client-side settings (mirrors pycharter / pystator).
 * API base URL is stored in localStorage and overrides the build-time default.
 */

const SETTINGS_KEY = "pygubernator_settings";

const BUILD_DEFAULT_API =
  typeof process !== "undefined" && process.env.NEXT_PUBLIC_PYGUBERNATOR_API_URL
    ? process.env.NEXT_PUBLIC_PYGUBERNATOR_API_URL.replace(/\/$/, "")
    : "http://127.0.0.1:8010";

export interface AppSettings {
  apiServer: {
    url: string;
  };
  database: {
    enabled: boolean;
    connectionString?: string;
    host?: string;
    port?: number;
    database?: string;
    username?: string;
    password?: string;
  };
}

const DEFAULT_SETTINGS: AppSettings = {
  apiServer: {
    url: BUILD_DEFAULT_API,
  },
  database: {
    enabled: false,
  },
};

/**
 * Get current settings from localStorage.
 */
export function getSettings(): AppSettings {
  if (typeof window === "undefined") {
    return DEFAULT_SETTINGS;
  }

  try {
    const stored = localStorage.getItem(SETTINGS_KEY);
    if (stored) {
      const parsed = JSON.parse(stored) as Partial<AppSettings>;
      return {
        ...DEFAULT_SETTINGS,
        ...parsed,
        apiServer: {
          ...DEFAULT_SETTINGS.apiServer,
          ...parsed.apiServer,
        },
        database: {
          ...DEFAULT_SETTINGS.database,
          ...parsed.database,
        },
      };
    }
  } catch (error) {
    console.error("Failed to load settings:", error);
  }

  return DEFAULT_SETTINGS;
}

/**
 * Save settings to localStorage.
 */
export function saveSettings(settings: AppSettings): void {
  if (typeof window === "undefined") {
    return;
  }

  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (error) {
    console.error("Failed to save settings:", error);
    throw error;
  }
}

/**
 * Resolve API base URL for fetch(): localStorage overrides defaults.
 * In dev, when `NEXT_PUBLIC_PYGUBERNATOR_API_URL` is set, returns '' so requests
 * use same-origin `/api/*` (Next rewrites) and avoid CORS.
 */
export function getApiBaseUrl(): string {
  if (
    typeof window !== "undefined" &&
    process.env.NODE_ENV === "development" &&
    process.env.NEXT_PUBLIC_PYGUBERNATOR_API_URL
  ) {
    return "";
  }
  const settings = getSettings();
  const url = settings.apiServer.url || DEFAULT_SETTINGS.apiServer.url;
  return url.replace(/\/$/, "");
}
