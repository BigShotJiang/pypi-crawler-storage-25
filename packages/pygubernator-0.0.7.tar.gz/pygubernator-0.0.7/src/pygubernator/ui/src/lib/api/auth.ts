import { apiGet, apiPost } from "@/lib/api";

export interface AuthLoginResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  role?: string;
}

export interface AuthMeResponse {
  username: string;
  role: string;
  auth_disabled: boolean;
}

export function loginWithTimeout(
  username: string,
  password: string,
  _timeoutMs: number
): Promise<AuthLoginResponse> {
  return apiPost<{ username: string; password: string }, AuthLoginResponse>(
    "/api/v1/auth/login",
    { username, password }
  );
}

export function authMeWithTimeout(_timeoutMs: number): Promise<AuthMeResponse> {
  return apiGet<AuthMeResponse>("/api/v1/auth/me");
}

export const authApi = {
  login: (username: string, password: string) =>
    apiPost<{ username: string; password: string }, AuthLoginResponse>(
      "/api/v1/auth/login",
      { username, password }
    ),
  logout: () => apiPost<Record<string, never>, Record<string, string>>("/api/v1/auth/logout", {}),
  me: () => apiGet<AuthMeResponse>("/api/v1/auth/me"),
  meWithTimeout: authMeWithTimeout
};
