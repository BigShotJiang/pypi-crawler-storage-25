import type { WorkflowNodeTypeItem } from "@/lib/types/workflow";

export const FALLBACK_WORKFLOW_NODE_TYPES: WorkflowNodeTypeItem[] = [
  { type_name: "input", display_name: "Input", category: "io", description: "Workflow entry point", color: "#60a5fa" },
  { type_name: "output", display_name: "Output", category: "io", description: "Workflow exit point", color: "#4ade80" },
  { type_name: "condition", display_name: "Condition", category: "logic", description: "Boolean branching", color: "#facc15" },
  { type_name: "router", display_name: "Router", category: "logic", description: "Multi-way routing", color: "#f472b6" },
  { type_name: "loop", display_name: "Loop", category: "logic", description: "Iterate over items", color: "#22d3ee" },
  { type_name: "map", display_name: "Map", category: "logic", description: "Parallel map", color: "#2dd4bf" },
  { type_name: "template", display_name: "Template", category: "processing", description: "String templating", color: "#c084fc" },
  { type_name: "code", display_name: "Code", category: "processing", description: "Python expression", color: "#fb923c" },
  { type_name: "http", display_name: "HTTP", category: "processing", description: "HTTP request", color: "#f87171" },
  { type_name: "gsheets", display_name: "Google Sheets", category: "processing", description: "Google Sheets API (service account)", color: "#0f9d58" },
  { type_name: "llm", display_name: "LLM", category: "ai", description: "LLM call", color: "#818cf8", supports_streaming: true },
  { type_name: "agent", display_name: "Agent", category: "ai", description: "Python package agent", color: "#e879f9", supports_streaming: true, supports_checkpointing: true },
  { type_name: "chat_model_openai", display_name: "OpenAI", category: "chat_models", description: "ChatGPT models", color: "#10a37f", runtime_kind: "config_only" },
  { type_name: "chat_model_anthropic", display_name: "Anthropic", category: "chat_models", description: "Claude models", color: "#d97706", runtime_kind: "config_only" },
  { type_name: "chat_model_gemini", display_name: "Gemini", category: "chat_models", description: "Google Gemini models", color: "#4285f4", runtime_kind: "config_only" },
  { type_name: "chat_model_ollama", display_name: "Ollama", category: "chat_models", description: "Local and self-hosted models", color: "#808080", runtime_kind: "config_only" },
  { type_name: "chat_model_deepseek", display_name: "Deepseek", category: "chat_models", description: "Deepseek models", color: "#1a73e8", runtime_kind: "config_only" },
  { type_name: "chat_model_glm", display_name: "GLM", category: "chat_models", description: "GLM and ChatGLM models", color: "#ff6b35", runtime_kind: "config_only" },
  { type_name: "chat_model_openai_compat", display_name: "OpenAI-Compat", category: "chat_models", description: "Any OpenAI-compatible API", color: "#6b7280", runtime_kind: "config_only" },
  { type_name: "memory", display_name: "Memory", category: "memory", description: "Agent memory store", color: "#f59e0b" },
  { type_name: "tool", display_name: "Tool (Custom)", category: "tools", description: "Custom tool (advanced)", color: "#34d399" },
  { type_name: "tool_gsheets", display_name: "Google Sheets", category: "tools", description: "Read, write, and manage spreadsheets", color: "#0f9d58", runtime_kind: "config_only" },
  { type_name: "tool_gdocs", display_name: "Google Docs", category: "tools", description: "Create and edit Google Docs", color: "#4285f4", runtime_kind: "config_only" },
  { type_name: "tool_slack", display_name: "Slack", category: "tools", description: "Send messages and manage Slack channels", color: "#4a154b", runtime_kind: "config_only" },
  { type_name: "tool_notion", display_name: "Notion", category: "tools", description: "Read and write Notion pages and databases", color: "#191919", runtime_kind: "config_only" },
  { type_name: "tool_sql", display_name: "SQL Database", category: "tools", description: "Query and manage SQL databases", color: "#336791", runtime_kind: "config_only" },
  { type_name: "tool_http", display_name: "HTTP / REST", category: "tools", description: "Make HTTP requests to any API", color: "#f87171", runtime_kind: "config_only" },
  { type_name: "tool_python", display_name: "Python", category: "tools", description: "Execute Python code and expressions", color: "#3776ab", runtime_kind: "config_only" },
  { type_name: "tool_obsidian", display_name: "Obsidian", category: "tools", description: "Read and search Obsidian vault notes", color: "#7c3aed", runtime_kind: "config_only" },
  { type_name: "tool_catalyst", display_name: "Mock Data", category: "tools", description: "Generate mock data with pycatalyst", color: "#f59e0b", runtime_kind: "config_only" },
  { type_name: "tool_stator", display_name: "State Machine", category: "tools", description: "Manage state machines with pystator", color: "#8b5cf6", runtime_kind: "config_only" },
];

export const WORKFLOW_CATEGORY_LABELS: Record<string, string> = {
  io: "I/O",
  logic: "Logic & Control",
  processing: "Processing",
  ai: "AI & LLM",
  chat_models: "Chat Models",
  memory: "Memory",
  tools: "Tools",
};

const FALLBACK_BY_TYPE = new Map(
  FALLBACK_WORKFLOW_NODE_TYPES.map((item) => [item.type_name, item]),
);

export function getWorkflowCategoryLabel(category: string): string {
  return WORKFLOW_CATEGORY_LABELS[category] ?? category.replaceAll("_", " ");
}

export function getWorkflowNodeTypeMeta(typeName: string): WorkflowNodeTypeItem {
  return FALLBACK_BY_TYPE.get(typeName) ?? {
    type_name: typeName,
    display_name: typeName.replaceAll("_", " "),
    category: "other",
    description: typeName,
    color: "#94a3b8",
  };
}
