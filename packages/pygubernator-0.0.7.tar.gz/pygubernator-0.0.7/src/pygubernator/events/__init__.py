"""Config change event bus for real-time collaboration."""

from __future__ import annotations

from pygubernator.events._change_bus import ChangeBus, ChangeEvent

__all__ = ["ChangeBus", "ChangeEvent"]
