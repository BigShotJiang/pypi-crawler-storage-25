"""Agent supervisor for managing and coordinating agent groups."""

from __future__ import annotations

import asyncio
import contextlib
import logging
from enum import Enum

from pygubernator._events import EventBus
from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent
from pygubernator.errors import AgentError

logger = logging.getLogger(__name__)


class RestartPolicy(Enum):
    """Policy for restarting failed agents."""

    NEVER = "never"
    ON_FAILURE = "on_failure"
    ALWAYS = "always"


class AgentSupervisor:
    """Manages a set of agents with lifecycle and health monitoring.

    Args:
        restart_policy: How to handle agent failures.
        event_bus: Optional event bus for supervisor events.
        health_interval: Seconds between health checks (0 to disable).
    """

    def __init__(
        self,
        restart_policy: RestartPolicy = RestartPolicy.ON_FAILURE,
        event_bus: EventBus | None = None,
        health_interval: float = 0.0,
    ) -> None:
        self._agents: dict[str, BaseAgent] = {}
        self._restart_policy = restart_policy
        self._event_bus = event_bus
        self._health_interval = health_interval
        self._health_task: asyncio.Task[None] | None = None
        self._shutdown_event = asyncio.Event()

    def add_agent(self, agent: BaseAgent) -> None:
        """Register an agent with the supervisor.

        Args:
            agent: The agent to manage.

        Raises:
            AgentError: If an agent with the same ID is already registered.
        """
        if agent.agent_id in self._agents:
            raise AgentError(
                f"Agent '{agent.agent_id}' already registered",
                agent_id=agent.agent_id,
            )
        self._agents[agent.agent_id] = agent
        logger.info("Supervisor: added agent %s", agent.agent_id)

    def remove_agent(self, agent_id: str) -> None:
        """Remove an agent from the supervisor.

        Args:
            agent_id: ID of the agent to remove.

        Raises:
            KeyError: If the agent is not registered.
        """
        agent = self._agents.pop(agent_id)
        if agent.state not in ("stopped", "error", "idle"):
            agent.stop()
        logger.info("Supervisor: removed agent %s", agent_id)

    def start_all(self) -> None:
        """Start all managed agents."""
        for agent in self._agents.values():
            if agent.is_idle:
                agent.start()
                logger.info("Supervisor: started agent %s", agent.agent_id)

    def stop_all(self) -> None:
        """Stop all managed agents gracefully."""
        self._shutdown_event.set()
        if self._health_task and not self._health_task.done():
            self._health_task.cancel()
        for agent in self._agents.values():
            if agent.state not in ("stopped", "error", "idle"):
                agent.stop()
                logger.info("Supervisor: stopped agent %s", agent.agent_id)

    def status(self) -> dict[str, str]:
        """Get the status of all managed agents.

        Returns:
            Mapping of agent_id to current state.
        """
        return {agent_id: agent.state for agent_id, agent in self._agents.items()}

    @property
    def agents(self) -> dict[str, BaseAgent]:
        """All managed agents."""
        return dict(self._agents)

    async def check_health(self) -> dict[str, bool]:
        """Run a health check on all agents.

        Returns:
            Mapping of agent_id to health status.
        """
        results: dict[str, bool] = {}
        for agent_id, agent in self._agents.items():
            healthy = agent.state in ("running", "idle")
            results[agent_id] = healthy
            if not healthy and self._should_restart(agent):
                await self._restart_agent(agent)
        return results

    def _should_restart(self, agent: BaseAgent) -> bool:
        """Determine if an agent should be restarted."""
        if self._restart_policy == RestartPolicy.NEVER:
            return False
        if self._restart_policy == RestartPolicy.ALWAYS:
            return True
        # ON_FAILURE: only restart if in error state
        return agent.is_error

    async def _restart_agent(self, agent: BaseAgent) -> None:
        """Attempt to restart a failed agent using recover transition."""
        logger.warning(
            "Supervisor: restarting agent %s from state %s",
            agent.agent_id,
            agent.state,
        )
        try:
            result = agent.session.send("recover")
            if result.success:
                agent.start()
                logger.info("Supervisor: agent %s restarted", agent.agent_id)
            else:
                logger.error(
                    "Supervisor: recovery failed for %s: %s",
                    agent.agent_id,
                    result.error,
                )
        except Exception:
            logger.exception(
                "Supervisor: failed to restart agent %s",
                agent.agent_id,
            )

    async def _health_loop(self) -> None:
        """Periodic health check loop."""
        while not self._shutdown_event.is_set():
            try:
                await asyncio.wait_for(
                    self._shutdown_event.wait(),
                    timeout=self._health_interval,
                )
            except TimeoutError:
                await self.check_health()

    async def run(self) -> None:
        """Start agents and run health monitoring until shutdown.

        Call ``stop_all()`` or set the internal shutdown event to exit.
        """
        self.start_all()
        if self._health_interval > 0:
            self._health_task = asyncio.create_task(self._health_loop())
            with contextlib.suppress(asyncio.CancelledError):
                await self._health_task
        else:
            await self._shutdown_event.wait()
        self.stop_all()


class AgentPipeline:
    """Chains agents where output of one feeds into the next.

    Agents are connected via internal InMemoryTransport instances.
    Message flows: Agent1 output -> Agent2 input -> Agent3 input -> ...

    Args:
        agents: Ordered list of agents forming the pipeline.
    """

    def __init__(self, agents: list[BaseAgent]) -> None:
        if len(agents) < 2:
            raise ValueError("Pipeline requires at least 2 agents")
        self._agents = agents

    async def process(self, message: Message) -> AgentResult:
        """Process a message through the agent pipeline.

        Args:
            message: The initial input message.

        Returns:
            Result from the final agent in the pipeline.
        """
        current_result: AgentResult | None = None
        current_message = message

        for agent in self._agents:
            current_result = await agent.process(current_message)

            if not current_result.success:
                return current_result

            # Build next message from the result metadata
            current_message = Message(
                topic=f"pipeline.{agent.agent_id}",
                payload=current_result.metadata,
            )

        return current_result  # type: ignore[return-value]
