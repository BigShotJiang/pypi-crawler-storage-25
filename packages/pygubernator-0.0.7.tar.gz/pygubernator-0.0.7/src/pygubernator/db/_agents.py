"""Repository helpers for Agent and AgentVersion entities."""

from __future__ import annotations

from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from pygubernator.db._pagination import paginate
from pygubernator.db.models import Agent, AgentVersion

__all__ = [
    "activate_agent_version",
    "create_agent",
    "create_agent_version",
    "get_agent",
    "get_agent_version",
    "list_agent_versions",
    "list_agents",
    "update_agent",
]


def list_agents(
    db: Session, page: int = 1, page_size: int = 25
) -> tuple[list[Agent], int]:
    """List agents with pagination.

    Args:
        db: SQLAlchemy session.
        page: Page number (1-indexed).
        page_size: Results per page.

    Returns:
        Tuple of (agents, total_count).
    """
    total = db.scalar(select(func.count(Agent.id))) or 0
    items = db.scalars(
        paginate(select(Agent).order_by(Agent.created_at.desc()), page, page_size)
    ).all()
    return items, total


def get_agent(db: Session, agent_id: str) -> Agent | None:
    """Get an agent by ID."""
    return db.get(Agent, agent_id)


def get_agent_version(db: Session, version_id: str) -> AgentVersion | None:
    """Get an agent version by ID."""
    return db.get(AgentVersion, version_id)


def list_agent_versions(db: Session, agent_id: str) -> list[AgentVersion]:
    """List all versions for an agent, newest first."""
    return list(
        db.scalars(
            select(AgentVersion)
            .where(AgentVersion.agent_id == agent_id)
            .order_by(AgentVersion.created_at.desc())
        ).all()
    )


def create_agent(
    db: Session,
    *,
    name: str,
    owner: str = "system",
    status: str = "active",
) -> Agent:
    """Create a new Agent record.

    Args:
        db: SQLAlchemy session.
        name: Unique agent name.
        owner: Owner identifier.
        status: Initial status.

    Returns:
        The created Agent.
    """
    agent = Agent(name=name, owner=owner, status=status)
    db.add(agent)
    return agent


def update_agent(
    db: Session,
    agent: Agent,
    **kwargs: Any,
) -> Agent:
    """Update fields on an existing Agent.

    Args:
        db: SQLAlchemy session.
        agent: The Agent to update.
        **kwargs: Field names and values to set.

    Returns:
        The updated Agent.
    """
    for key, value in kwargs.items():
        if hasattr(agent, key):
            setattr(agent, key, value)
    return agent


def create_agent_version(
    db: Session,
    *,
    agent_id: str,
    version: str,
    model: str | None = None,
    prompt: str | None = None,
    tools: dict[str, Any] | None = None,
    config: dict[str, Any] | None = None,
    active: bool = False,
) -> AgentVersion:
    """Create a new AgentVersion record.

    Args:
        db: SQLAlchemy session.
        agent_id: Parent agent ID.
        version: Version string.
        model: LLM model name.
        prompt: System prompt.
        tools: Tool configuration.
        config: Additional config.
        active: Whether this version is active.

    Returns:
        The created AgentVersion.
    """
    av = AgentVersion(
        agent_id=agent_id,
        version=version,
        model=model,
        prompt=prompt,
        tools=tools or {},
        config=config or {},
        active=active,
    )
    db.add(av)
    return av


def activate_agent_version(db: Session, agent: Agent, version_id: str) -> None:
    """Activate a specific agent version, deactivating all others.

    Args:
        db: SQLAlchemy session.
        agent: The agent whose version to activate.
        version_id: The version ID to activate.
    """
    for version in agent.versions:
        version.active = version.id == version_id
    agent.current_version_id = version_id
