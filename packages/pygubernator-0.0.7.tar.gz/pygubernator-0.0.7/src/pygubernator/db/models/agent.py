"""Agent and agent version models."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Mapped,
    String,
    Text,
    _utcnow,
    mapped_column,
    relationship,
    uuid,
)


class Agent(Base):
    """Agent definition."""

    __tablename__ = "agents"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    name: Mapped[str] = mapped_column(String(120), index=True, unique=True)
    owner: Mapped[str] = mapped_column(String(120), default="system")
    status: Mapped[str] = mapped_column(String(32), default="active")
    archived: Mapped[bool] = mapped_column(Boolean, default=False)
    workspace_id: Mapped[str] = mapped_column(
        String(36),
        index=True,
        default="default",
    )
    current_version_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        onupdate=_utcnow,
    )
    versions: Mapped[list[AgentVersion]] = relationship(back_populates="agent")


class AgentVersion(Base):
    """Versioned agent configuration."""

    __tablename__ = "agent_versions"
    __table_args__ = (
        Index(
            "ix_agent_version_unique",
            "agent_id",
            "version",
            unique=True,
        ),
        {"schema": _SCHEMA},
    )

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    agent_id: Mapped[str] = mapped_column(
        ForeignKey(f"{_SCHEMA}.agents.id"), index=True
    )
    version: Mapped[str] = mapped_column(String(64))
    model: Mapped[str | None] = mapped_column(String(120), nullable=True)
    prompt: Mapped[str | None] = mapped_column(Text, nullable=True)
    tools: Mapped[dict] = mapped_column(JSON, default=dict)
    config: Mapped[dict] = mapped_column(JSON, default=dict)
    active: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    agent: Mapped[Agent] = relationship(back_populates="versions")


__all__ = ["Agent", "AgentVersion"]
