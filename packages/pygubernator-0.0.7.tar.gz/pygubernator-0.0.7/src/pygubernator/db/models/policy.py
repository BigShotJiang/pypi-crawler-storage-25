"""Policy assignment model."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    Boolean,
    DateTime,
    ForeignKey,
    Mapped,
    String,
    _utcnow,
    mapped_column,
    uuid,
)


class PolicyAssignment(Base):
    """Policy enforcement assignment for an agent."""

    __tablename__ = "policy_assignments"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    agent_id: Mapped[str] = mapped_column(
        ForeignKey(f"{_SCHEMA}.agents.id"), index=True
    )
    policy_type: Mapped[str] = mapped_column(String(64), index=True)
    policy_value: Mapped[dict] = mapped_column(JSON, default=dict)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        onupdate=_utcnow,
    )


__all__ = ["PolicyAssignment"]
