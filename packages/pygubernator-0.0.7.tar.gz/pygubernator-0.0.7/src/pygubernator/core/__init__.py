"""Stateless agent runtime: agents, tools, LLM, transport (no persistence imports)."""

from __future__ import annotations

import importlib
from typing import Any

_LAZY: dict[str, tuple[str, str]] = {
    "AgentEvent": ("pygubernator._events", "AgentEvent"),
    "AgentEventType": ("pygubernator._events", "AgentEventType"),
    "EventBus": ("pygubernator._events", "EventBus"),
    "EventHandler": ("pygubernator._events", "EventHandler"),
    "LLMProvider": ("pygubernator._protocols", "LLMProvider"),
    "Tool": ("pygubernator._protocols", "Tool"),
    "Transport": ("pygubernator._protocols", "Transport"),
    "AgentPipeline": ("pygubernator._supervisor", "AgentPipeline"),
    "AgentSupervisor": ("pygubernator._supervisor", "AgentSupervisor"),
    "RestartPolicy": ("pygubernator._supervisor", "RestartPolicy"),
    "AgentResult": ("pygubernator._types", "AgentResult"),
    "Message": ("pygubernator._types", "Message"),
    "StepResult": ("pygubernator._types", "StepResult"),
    "ToolResult": ("pygubernator._types", "ToolResult"),
    "BaseAgent": ("pygubernator.agents", "BaseAgent"),
    "LLMAgent": ("pygubernator.agents", "LLMAgent"),
    "PipelineAgent": ("pygubernator.agents", "PipelineAgent"),
    "PipelineStep": ("pygubernator.agents", "PipelineStep"),
    "StateMachineAgent": ("pygubernator.agents", "StateMachineAgent"),
    "AgentSettings": ("pygubernator.config._settings", "AgentSettings"),
    "ChatMessage": ("pygubernator.llm", "ChatMessage"),
    "ChatRole": ("pygubernator.llm", "ChatRole"),
    "LLMResponse": ("pygubernator.llm", "LLMResponse"),
    "OpenAICompatibleProvider": ("pygubernator.llm", "OpenAICompatibleProvider"),
    "ProviderConfig": ("pygubernator.llm", "ProviderConfig"),
    "ProviderType": ("pygubernator.llm", "ProviderType"),
    "ToolCall": ("pygubernator.llm", "ToolCall"),
    "create_provider": ("pygubernator.llm", "create_provider"),
    "LoggingMiddleware": ("pygubernator.middleware", "LoggingMiddleware"),
    "Middleware": ("pygubernator._middleware", "Middleware"),
    "MiddlewareChain": ("pygubernator._middleware", "MiddlewareChain"),
    "RetryMiddleware": ("pygubernator.middleware", "RetryMiddleware"),
    "TimeoutMiddleware": ("pygubernator.middleware", "TimeoutMiddleware"),
    "ValidationMiddleware": ("pygubernator.middleware", "ValidationMiddleware"),
    "run_batch": ("pygubernator.runners", "run_batch"),
    "run_stream": ("pygubernator.runners", "run_stream"),
    "ToolRegistry": ("pygubernator.tools", "ToolRegistry"),
    "tool": ("pygubernator.tools", "tool"),
    "InMemoryTransport": ("pygubernator.transport", "InMemoryTransport"),
}

__all__ = list(_LAZY.keys())


def __getattr__(name: str) -> Any:
    if name in _LAZY:
        mod_path, attr = _LAZY[name]
        mod = importlib.import_module(mod_path)
        return getattr(mod, attr)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(__all__)
