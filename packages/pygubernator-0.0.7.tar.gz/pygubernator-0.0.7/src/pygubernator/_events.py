"""Event types and bus for agent lifecycle and execution observability."""

from __future__ import annotations

import enum
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


class AgentEventType(enum.Enum):
    """Types of events emitted by agents and runners."""

    # Lifecycle events
    AGENT_STARTED = "agent.started"
    AGENT_STOPPED = "agent.stopped"
    AGENT_PAUSED = "agent.paused"
    AGENT_RESUMED = "agent.resumed"
    AGENT_ERROR = "agent.error"

    # Message processing
    MESSAGE_RECEIVED = "message.received"
    MESSAGE_PROCESSED = "message.processed"

    # Pipeline steps
    STEP_STARTED = "step.started"
    STEP_COMPLETED = "step.completed"
    STEP_FAILED = "step.failed"

    # Tool calls
    TOOL_CALL_STARTED = "tool_call.started"
    TOOL_CALL_COMPLETED = "tool_call.completed"
    TOOL_CALL_FAILED = "tool_call.failed"

    # LLM interactions
    LLM_REQUEST_STARTED = "llm.request.started"
    LLM_RESPONSE_RECEIVED = "llm.response.received"
    LLM_TOKEN_RECEIVED = "llm.token.received"

    # Run-level events
    RUN_STARTED = "run.started"
    RUN_COMPLETED = "run.completed"

    # Workflow events
    WORKFLOW_STARTED = "workflow.started"
    WORKFLOW_COMPLETED = "workflow.completed"
    WORKFLOW_NODE_STARTED = "workflow.node.started"
    WORKFLOW_NODE_COMPLETED = "workflow.node.completed"
    WORKFLOW_NODE_FAILED = "workflow.node.failed"
    WORKFLOW_EDGE_ROUTED = "workflow.edge.routed"
    WORKFLOW_EDGE_GUARDED = "workflow.edge.guarded"


@dataclass(frozen=True, slots=True)
class AgentEvent:
    """An event emitted during agent execution.

    Args:
        event_type: The type of event.
        agent_id: Identifier of the agent that emitted the event.
        timestamp: Unix timestamp when the event occurred.
        data: Arbitrary event payload.
        run_id: Optional run identifier for correlation.
        parent_event_id: Optional parent event for nesting.
    """

    event_type: AgentEventType
    agent_id: str
    timestamp: float = field(default_factory=time.time)
    data: dict[str, Any] = field(default_factory=dict)
    run_id: str | None = None
    parent_event_id: str | None = None


@runtime_checkable
class EventHandler(Protocol):
    """Protocol for objects that handle agent events."""

    async def handle(self, event: AgentEvent) -> None:
        """Handle an agent event.

        Args:
            event: The event to handle.
        """
        ...


class EventBus:
    """Fan-out event bus that dispatches events to registered handlers.

    Handlers are called concurrently for each event. Exceptions in
    individual handlers are logged but do not prevent other handlers
    from receiving the event.
    """

    def __init__(self) -> None:
        self._handlers: list[EventHandler] = []

    def add_handler(self, handler: EventHandler) -> None:
        """Register an event handler.

        Args:
            handler: Handler implementing the EventHandler protocol.
        """
        self._handlers.append(handler)

    def remove_handler(self, handler: EventHandler) -> None:
        """Remove a previously registered handler.

        Args:
            handler: The handler to remove.

        Raises:
            ValueError: If the handler is not registered.
        """
        self._handlers.remove(handler)

    async def emit(self, event: AgentEvent) -> None:
        """Emit an event to all registered handlers.

        Each handler is called sequentially. Exceptions are caught
        and logged so that one failing handler does not block others.

        Args:
            event: The event to dispatch.
        """
        for handler in self._handlers:
            try:
                await handler.handle(event)
            except Exception:
                logger.exception(
                    "Event handler %s failed for %s",
                    type(handler).__name__,
                    event.event_type.value,
                )

    @property
    def handler_count(self) -> int:
        """Number of registered handlers."""
        return len(self._handlers)
