"""Ephemeral in-memory store using SQLite :memory: (full schema, no duplicate logic)."""

from __future__ import annotations

from sqlalchemy.orm import sessionmaker

from pygubernator.agent_store.sqlalchemy import SQLAlchemyAgentStore
from pygubernator.db.base import Base, get_engine


class InMemoryAgentStore(SQLAlchemyAgentStore):
    """Agent store backed by an in-memory SQLite database (for tests and demos)."""

    def __init__(self) -> None:
        from pygubernator.db import models  # noqa: F401 — register metadata

        engine = get_engine("sqlite:///:memory:")
        Base.metadata.create_all(bind=engine)
        sess = sessionmaker(bind=engine, autoflush=False, autocommit=False)()
        super().__init__(sess, owns_session=True)

    def connect(self) -> None:
        super().connect()

    def disconnect(self) -> None:
        super().disconnect()


__all__ = ["InMemoryAgentStore"]
