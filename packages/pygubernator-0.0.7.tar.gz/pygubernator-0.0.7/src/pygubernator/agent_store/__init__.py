"""Pluggable persistence for PyGubernator (mirrors ContractStore / StateStore)."""

from __future__ import annotations

from pygubernator.agent_store.client import AgentStoreClient
from pygubernator.agent_store.protocols import (
    AgentStore,
    AuditStore,
    RunStore,
    WorkflowStore,
)

try:
    from pygubernator.agent_store.memory import InMemoryAgentStore
except ImportError:
    InMemoryAgentStore = None  # type: ignore[misc, assignment]

try:
    from pygubernator.agent_store.sqlalchemy import SQLAlchemyAgentStore
except ImportError:
    SQLAlchemyAgentStore = None  # type: ignore[misc, assignment]

__all__ = [
    "AgentStore",
    "AgentStoreClient",
    "AuditStore",
    "InMemoryAgentStore",
    "RunStore",
    "SQLAlchemyAgentStore",
    "WorkflowStore",
]
