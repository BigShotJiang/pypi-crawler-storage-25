"""Abstract persistence client for PyGubernator (mirrors ContractStore / StateStore)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any


class AgentStoreClient(ABC):
    """Persistence API for agents, runs, workflows, audit, policies, and incidents."""

    # --- lifecycle -----------------------------------------------------------

    @abstractmethod
    def connect(self) -> None:
        """Establish backend connection (no-op when using an injected session)."""

    @abstractmethod
    def disconnect(self) -> None:
        """Release backend resources."""

    def _require_connection(self) -> None:
        """Override in subclasses that track connection state."""
        return None

    # --- agents --------------------------------------------------------------

    @abstractmethod
    def list_agents(
        self, *, page: int = 1, page_size: int = 25
    ) -> tuple[list[Any], int]:
        """Return (agents, total_count)."""

    @abstractmethod
    def get_agent(self, agent_id: str) -> Any | None:
        """Get agent by id."""

    @abstractmethod
    def get_agent_version(self, version_id: str) -> Any | None:
        """Get agent version by id."""

    @abstractmethod
    def list_agent_versions(self, agent_id: str) -> list[Any]:
        """List versions for an agent."""

    @abstractmethod
    def create_agent(
        self,
        *,
        name: str,
        owner: str = "system",
        status: str = "active",
    ) -> Any:
        """Create agent row (not committed)."""

    @abstractmethod
    def update_agent(self, agent: Any, **kwargs: Any) -> Any:
        """Update agent fields."""

    @abstractmethod
    def create_agent_version(
        self,
        *,
        agent_id: str,
        version: str,
        model: str | None = None,
        prompt: str | None = None,
        tools: dict[str, Any] | None = None,
        config: dict[str, Any] | None = None,
        active: bool = False,
    ) -> Any:
        """Create agent version row (not committed)."""

    @abstractmethod
    def activate_agent_version(self, agent: Any, version_id: str) -> None:
        """Set active version for agent."""

    # --- audit ---------------------------------------------------------------

    @abstractmethod
    def create_audit(
        self,
        *,
        actor: str,
        action: str,
        resource_type: str,
        resource_id: str | None,
        details: dict[str, Any],
    ) -> Any:
        """Create audit log row (not committed)."""

    @abstractmethod
    def list_audit_logs(
        self,
        *,
        limit: int = 100,
        resource_id: str | None = None,
        resource_type: str | None = None,
    ) -> list[Any]:
        """List recent audit entries."""

    # --- incidents -----------------------------------------------------------

    @abstractmethod
    def get_incident(self, incident_id: str) -> Any | None:
        """Get incident by id."""

    @abstractmethod
    def list_incidents(
        self,
        *,
        status: str | None = None,
        severity: str | None = None,
        owner: str | None = None,
        limit: int = 100,
    ) -> list[Any]:
        """List incidents."""

    # --- policies ------------------------------------------------------------

    @abstractmethod
    def list_policies(self, agent_id: str | None = None) -> list[Any]:
        """List policy assignments."""

    # --- runs ----------------------------------------------------------------

    @abstractmethod
    def get_run(self, run_id: str) -> Any | None:
        """Get run by id."""

    @abstractmethod
    def create_run(
        self,
        *,
        agent_id: str,
        agent_version_id: str | None = None,
        status: str = "queued",
        correlation_id: str | None = None,
        trigger: str | None = None,
        metadata_json: dict[str, Any] | None = None,
    ) -> Any:
        """Create run row (not committed)."""

    @abstractmethod
    def update_run(self, run: Any, **kwargs: Any) -> Any:
        """Update run fields."""

    @abstractmethod
    def list_runs_filtered(
        self,
        *,
        page: int = 1,
        page_size: int = 25,
        status: str | None = None,
        agent_id: str | None = None,
        correlation_id: str | None = None,
        has_error: bool | None = None,
        created_from: datetime | None = None,
        created_to: datetime | None = None,
        sort_by: str = "created_at",
        sort_order: str = "desc",
    ) -> tuple[list[Any], int]:
        """List runs with filters."""

    @abstractmethod
    def get_run_status_facets(self) -> list[dict[str, int | str]]:
        """Counts grouped by run status."""

    @abstractmethod
    def create_run_event(
        self,
        *,
        run_id: str,
        event_type: str,
        level: str = "info",
        message: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> Any:
        """Create run event (not committed)."""

    @abstractmethod
    def list_run_events(
        self,
        run_id: str,
        *,
        page: int = 1,
        page_size: int = 100,
    ) -> tuple[list[Any], int]:
        """List events for a run."""

    @abstractmethod
    def create_tool_call(
        self,
        *,
        run_id: str,
        tool_name: str,
        status: str = "completed",
        latency_ms: int | None = None,
        input_payload: dict[str, Any] | None = None,
        output_payload: dict[str, Any] | None = None,
        error_message: str | None = None,
    ) -> Any:
        """Create tool call row (not committed)."""

    @abstractmethod
    def list_tool_calls(
        self,
        run_id: str,
        *,
        page: int = 1,
        page_size: int = 100,
    ) -> tuple[list[Any], int]:
        """List tool calls for a run."""

    # --- workflows -----------------------------------------------------------

    @abstractmethod
    def create_workflow(
        self,
        *,
        name: str,
        description: str = "",
        owner: str = "system",
        status: str = "active",
    ) -> Any:
        """Create workflow (not committed)."""

    @abstractmethod
    def get_workflow(self, workflow_id: str) -> Any | None:
        """Get workflow by id."""

    @abstractmethod
    def list_workflows(
        self,
        *,
        page: int = 1,
        page_size: int = 25,
        status: str | None = None,
    ) -> tuple[list[Any], int]:
        """List workflows."""

    @abstractmethod
    def update_workflow(self, workflow: Any, **kwargs: Any) -> Any:
        """Update workflow fields."""

    @abstractmethod
    def create_workflow_version(
        self,
        *,
        workflow_id: str,
        version: str,
        spec_json: dict[str, Any] | None = None,
        active: bool = False,
        created_by: str = "system",
    ) -> Any:
        """Create workflow version, or update spec if that version already exists."""

    @abstractmethod
    def list_workflow_versions(self, workflow_id: str) -> list[Any]:
        """List versions for a workflow."""

    @abstractmethod
    def activate_workflow_version(self, workflow: Any, version_id: str) -> None:
        """Activate a workflow version."""

    @abstractmethod
    def create_workflow_run(
        self,
        *,
        workflow_id: str,
        workflow_version_id: str | None = None,
        status: str = "pending",
        input_json: dict[str, Any] | None = None,
        created_by: str = "system",
    ) -> Any:
        """Create workflow run (not committed)."""

    @abstractmethod
    def get_workflow_run(self, run_id: str) -> Any | None:
        """Get workflow run by id."""

    @abstractmethod
    def list_workflow_runs(
        self,
        *,
        page: int = 1,
        page_size: int = 25,
        workflow_id: str | None = None,
        status: str | None = None,
    ) -> tuple[list[Any], int]:
        """List workflow runs."""

    @abstractmethod
    def update_workflow_run(self, run: Any, **kwargs: Any) -> Any:
        """Update workflow run."""

    @abstractmethod
    def delete_workflow_run(self, run_id: str) -> bool:
        """Delete workflow run and its step rows. Returns False if not found."""

    @abstractmethod
    def create_workflow_step_run(
        self,
        *,
        workflow_run_id: str,
        node_id: str,
        node_type: str,
        status: str = "pending",
        input_json: dict[str, Any] | None = None,
    ) -> Any:
        """Create workflow step run (not committed)."""

    @abstractmethod
    def list_step_runs(self, workflow_run_id: str) -> list[Any]:
        """List step runs for a workflow run."""

    @abstractmethod
    def update_workflow_step_run(self, step: Any, **kwargs: Any) -> Any:
        """Update workflow step run."""


__all__ = ["AgentStoreClient"]
