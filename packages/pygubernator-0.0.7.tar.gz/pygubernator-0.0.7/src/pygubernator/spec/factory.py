"""Build runtime agents from version-like configuration (YAML or ORM rows)."""

from __future__ import annotations

import importlib
import logging
from collections.abc import Callable

from pygubernator._events import EventBus
from pygubernator._protocols import LLMProvider
from pygubernator.agents._llm import LLMAgent
from pygubernator.errors import ConfigError
from pygubernator.spec.types import AgentVersionLike
from pygubernator.tools._registry import ToolRegistry

logger = logging.getLogger(__name__)

__all__ = [
    "create_llm_agent_from_version",
    "load_tools_from_version",
]


def load_tools_from_version(
    version: AgentVersionLike,
    registry: ToolRegistry | None = None,
) -> ToolRegistry:
    """Load tools from a version's ``tools`` mapping into a :class:`ToolRegistry`."""
    if registry is None:
        registry = ToolRegistry()

    tools = version.tools or {}
    if not tools:
        return registry

    for tool_name, tool_spec in tools.items():
        if not isinstance(tool_spec, dict):
            logger.warning(
                "Tool '%s' has invalid spec (expected dict), skipping",
                tool_name,
            )
            continue

        if "module" in tool_spec and "function" in tool_spec:
            try:
                module_path = tool_spec["module"]
                func_name = tool_spec["function"]
                module = importlib.import_module(module_path)
                tool_func = getattr(module, func_name)
                registry.register(tool_func)
                logger.debug(
                    "Loaded tool '%s' from %s.%s", tool_name, module_path, func_name
                )
            except (ImportError, AttributeError) as exc:
                raise ConfigError(
                    f"Failed to load tool '{tool_name}': {exc}",
                ) from exc
        else:
            logger.warning(
                "Tool '%s' spec missing 'module'/'function', skipping",
                tool_name,
            )

    return registry


def _default_provider_factory(model: str | None) -> LLMProvider:
    from pygubernator.llm._factory import create_provider

    return create_provider(model or "gpt-4")


def create_llm_agent_from_version(
    version: AgentVersionLike,
    llm_provider_factory: Callable[[str | None], LLMProvider] | None = None,
    tool_loader: (
        Callable[[AgentVersionLike, ToolRegistry | None], ToolRegistry] | None
    ) = None,
    event_bus: EventBus | None = None,
    run_id: str | None = None,
) -> LLMAgent:
    """Build :class:`~pygubernator.agents.LLMAgent` from a version-like spec."""
    config = version.config or {}

    provider_dict = config.get("provider")
    if provider_dict and isinstance(provider_dict, dict):
        from pygubernator.llm._config import ProviderConfig, ProviderType
        from pygubernator.llm._factory import create_provider_from_config

        pc = ProviderConfig(
            provider_type=ProviderType(provider_dict["provider_type"]),
            model=provider_dict.get("model", version.model or ""),
            api_base=provider_dict.get("api_base"),
            api_key=provider_dict.get("api_key"),
            max_tokens=provider_dict.get("max_tokens", 4096),
            temperature=provider_dict.get("temperature", 0.0),
            top_p=provider_dict.get("top_p"),
            top_k=provider_dict.get("top_k"),
            model_path=provider_dict.get("model_path"),
            n_ctx=provider_dict.get("n_ctx", 4096),
            n_gpu_layers=provider_dict.get("n_gpu_layers", -1),
            request_timeout=provider_dict.get("request_timeout"),
        )
        llm_provider = create_provider_from_config(pc)
    else:
        factory = llm_provider_factory or _default_provider_factory
        llm_provider = factory(version.model)

    if tool_loader is None:
        tool_loader = load_tools_from_version
    tool_registry = tool_loader(version, None)
    max_iterations = config.get("max_iterations", 10)
    if not isinstance(max_iterations, int) or max_iterations < 1:
        logger.warning(
            "Invalid max_iterations in config, using default: 10",
        )
        max_iterations = 10

    final_registry = tool_registry if len(tool_registry) > 0 else None

    return LLMAgent(
        agent_id=version.agent_id,
        llm_provider=llm_provider,
        tool_registry=final_registry,
        system_prompt=version.prompt or "",
        max_iterations=max_iterations,
        event_bus=event_bus,
        run_id=run_id,
    )
