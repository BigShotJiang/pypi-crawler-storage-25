"""Configuration-driven assembly: specs, YAML workflows, agent builders."""

from __future__ import annotations

from typing import Any

from pygubernator.spec.factory import (
    create_llm_agent_from_version,
    load_tools_from_version,
)
from pygubernator.spec.types import AgentVersionLike

__all__ = [
    "AgentVersionLike",
    "EdgeDef",
    "NodeDef",
    "WorkflowConfig",
    "WorkflowLoader",
    "WorkflowMeta",
    "create_llm_agent_from_version",
    "load_tools_from_version",
]


def __getattr__(name: str) -> Any:
    if name == "WorkflowLoader":
        from pygubernator.workflow.config._loader import WorkflowLoader

        return WorkflowLoader
    if name in ("EdgeDef", "NodeDef", "WorkflowConfig", "WorkflowMeta"):
        from pygubernator.workflow.config import _models

        return getattr(_models, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
