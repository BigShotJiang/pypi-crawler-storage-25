"""Protocols for configuration-driven assembly (no ORM required)."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class AgentVersionLike(Protocol):
    """Minimal shape needed to build an :class:`~pygubernator.agents.LLMAgent`."""

    agent_id: str
    model: str | None
    prompt: str | None
    tools: dict[str, Any]
    config: dict[str, Any]


__all__ = ["AgentVersionLike"]
