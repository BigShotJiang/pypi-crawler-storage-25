"""Pydantic validation models for workflow YAML configuration."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


class WorkflowMeta(BaseModel):
    """Metadata for a workflow definition.

    Args:
        name: Human-readable workflow name.
        version: Semantic version string.
        description: Brief description of the workflow.
    """

    name: str
    version: str = "1.0.0"
    description: str = ""


class PositionDef(BaseModel):
    """Visual position of a node on the canvas.

    Args:
        x: Horizontal position.
        y: Vertical position.
    """

    x: float = 0.0
    y: float = 0.0


class NodeDef(BaseModel):
    """Definition of a workflow node.

    Args:
        type: Node type identifier.
        config: Node-specific configuration.
        position: Optional visual position on the canvas.
    """

    type: Literal[
        "input",
        "output",
        "template",
        "condition",
        "code",
        "python_exec",
        "http",
        "gsheets",
        "llm",
        "router",
        "loop",
        "map",
        "memory",
        "agent",
        "chat_model_openai",
        "chat_model_anthropic",
        "chat_model_gemini",
        "chat_model_ollama",
        "chat_model_deepseek",
        "chat_model_glm",
        "chat_model_openai_compat",
        "tool",
        "tool_gsheets",
        "tool_gdocs",
        "tool_slack",
        "tool_notion",
        "tool_sql",
        "tool_http",
        "tool_python",
        "tool_obsidian",
        "tool_catalyst",
        "tool_stator",
    ]
    config: dict[str, Any] = Field(default_factory=dict)
    position: PositionDef = Field(default_factory=PositionDef)


class EdgeDef(BaseModel):
    """Definition of a directed edge between workflow nodes.

    Args:
        source: Source node ID.
        target: Target node ID.
        source_handle: Output handle on the source node.
        target_handle: Input handle on the target node.
        condition: Optional expression for conditional routing.
    """

    source: str
    target: str
    source_handle: str = "default"
    target_handle: str = "default"
    condition: str | None = None


class WorkflowConfig(BaseModel):
    """Top-level workflow configuration parsed from YAML.

    Args:
        meta: Workflow metadata.
        nodes: Node definitions keyed by node ID.
        edges: Edge definitions connecting nodes.
    """

    meta: WorkflowMeta
    nodes: dict[str, NodeDef]
    edges: list[EdgeDef]

    @model_validator(mode="after")
    def _validate_edge_refs(self) -> WorkflowConfig:
        """Validate that all edge source/target references exist."""
        node_ids = set(self.nodes.keys())
        for idx, edge in enumerate(self.edges):
            if edge.source not in node_ids:
                msg = (
                    f"Edge[{idx}] source '{edge.source}' "
                    f"not found in nodes: {sorted(node_ids)}"
                )
                raise ValueError(msg)
            if edge.target not in node_ids:
                msg = (
                    f"Edge[{idx}] target '{edge.target}' "
                    f"not found in nodes: {sorted(node_ids)}"
                )
                raise ValueError(msg)
        return self

    @model_validator(mode="after")
    def _validate_has_io(self) -> WorkflowConfig:
        """Warn-level check: workflow should have input and output nodes."""
        types = {n.type for n in self.nodes.values()}
        if "input" not in types:
            import logging

            logging.getLogger(__name__).warning(
                "Workflow '%s' has no input node", self.meta.name
            )
        if "output" not in types:
            import logging

            logging.getLogger(__name__).warning(
                "Workflow '%s' has no output node", self.meta.name
            )
        return self
