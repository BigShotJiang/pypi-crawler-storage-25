"""Convert Pydantic workflow config models to frozen WorkflowSpec."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._types import EdgeSpec, NodeSpec, WorkflowSpec
from pygubernator.workflow.config._models import WorkflowConfig

logger = logging.getLogger(__name__)

_SUB_NODE_PREFIXES = ("chat_model_", "tool_")
_SUB_NODE_TYPES = {"tool", "memory"}
_PARENT_TYPES = {"llm", "agent"}

_TOOL_TYPE_PRESETS: dict[str, dict[str, str]] = {
    "tool_gsheets": {
        "name": "google_sheets",
        "factory_module": "pygubernator.tools.gsheets_factory",
        "factory_function": "create_tools_from_env",
    },
    "tool_gdocs": {
        "name": "google_docs",
        "factory_module": "pygubernator.tools.gdocs_factory",
        "factory_function": "create_tools_from_env",
    },
    "tool_slack": {
        "name": "slack",
        "factory_module": "pygubernator.tools.slack_factory",
        "factory_function": "create_tools_from_env",
    },
    "tool_notion": {
        "name": "notion",
        "factory_module": "pygubernator.tools.notion_factory",
        "factory_function": "create_tools_from_env",
    },
    "tool_sql": {
        "name": "sql",
        "factory_module": "pygubernator.tools.sql_factory",
        "factory_function": "create_tools_from_env",
    },
    "tool_http": {
        "name": "http",
        "factory_module": "pygubernator.tools.http_factory",
        "factory_function": "create_tools_from_env",
    },
    "tool_python": {
        "name": "python",
        "factory_module": "pygubernator.tools.python_factory",
        "factory_function": "create_tools_from_env",
    },
    "tool_obsidian": {
        "name": "obsidian",
        "factory_module": "pygubernator.tools.obsidian_factory",
        "factory_function": "create_tools_from_env",
    },
    "tool_catalyst": {
        "name": "catalyst",
        "factory_module": "pygubernator.tools.catalyst_factory",
        "factory_function": "create_tools_from_env",
    },
    "tool_stator": {
        "name": "stator",
        "factory_module": "pygubernator.tools.stator_factory",
        "factory_function": "create_tools_from_env",
    },
}


def workflow_config_to_spec(config: WorkflowConfig) -> WorkflowSpec:
    """Transform a validated WorkflowConfig into a frozen WorkflowSpec.

    Resolves UI sub-nodes (``chat_model_*``, ``tool_*``, ``tool``)
    by merging their config into parent ``llm``/``agent`` nodes and
    removing them from the spec. Also validates graph integrity.

    Args:
        config: Validated Pydantic workflow config.

    Returns:
        Frozen WorkflowSpec ready for the execution engine.

    Raises:
        ConfigError: If the config has invalid references.
    """
    # Build mutable nodes and edges
    raw_nodes: dict[str, dict[str, Any]] = {
        nid: {
            "type": ndef.type,
            "config": dict(ndef.config),
            "position": (ndef.position.x, ndef.position.y),
        }
        for nid, ndef in config.nodes.items()
    }
    raw_edges = list(config.edges)

    # Resolve sub-nodes into parent nodes
    raw_nodes, raw_edges = _resolve_sub_nodes(raw_nodes, raw_edges)

    # Convert to frozen specs
    nodes = {
        nid: NodeSpec(
            node_id=nid,
            node_type=n["type"],
            config=n["config"],
            position=n["position"],
        )
        for nid, n in raw_nodes.items()
    }

    edges: list[EdgeSpec] = []
    referenced_nodes: set[str] = set()

    for idx, edef in enumerate(raw_edges):
        edge_id = f"edge_{idx}"
        referenced_nodes.add(edef.source)
        referenced_nodes.add(edef.target)

        edges.append(
            EdgeSpec(
                edge_id=edge_id,
                source_id=edef.source,
                target_id=edef.target,
                source_handle=edef.source_handle,
                target_handle=edef.target_handle,
                condition=edef.condition,
            )
        )

    orphaned = set(raw_nodes.keys()) - referenced_nodes
    if orphaned:
        logger.warning("Orphaned nodes (not referenced by any edge): %s", orphaned)

    _check_graph_connectivity(nodes, edges)

    return WorkflowSpec(
        name=config.meta.name,
        version=config.meta.version,
        description=config.meta.description,
        nodes=nodes,
        edges=tuple(edges),
    )


def _is_sub_node_type(node_type: str) -> bool:
    """Check if a node type is a UI sub-node."""
    if node_type in _SUB_NODE_TYPES:
        return True
    return any(node_type.startswith(p) for p in _SUB_NODE_PREFIXES)


def _resolve_sub_nodes(
    nodes: dict[str, dict[str, Any]],
    edges: list[Any],
) -> tuple[dict[str, dict[str, Any]], list[Any]]:
    """Merge sub-node configs into parent nodes and remove them.

    Sub-nodes (``chat_model_*``, ``tool_*``, ``tool``) are UI
    abstractions. When connected to a parent ``llm``/``agent`` node
    via a ``sub:*`` edge, their config is merged into the parent
    and they are removed from the spec.

    Args:
        nodes: Mutable node dict.
        edges: Edge definitions.

    Returns:
        Updated (nodes, edges) with sub-nodes resolved.
    """
    sub_node_ids: set[str] = set()
    sub_edges: set[int] = set()

    for idx, edge in enumerate(edges):
        target_handle = getattr(edge, "target_handle", "default")
        source_id = edge.source
        target_id = edge.target
        source_node = nodes.get(source_id)
        target_node = nodes.get(target_id)

        if not source_node or not target_node:
            continue

        source_type = source_node["type"]
        target_type = target_node["type"]

        is_sub_edge = target_handle.startswith("sub:")
        is_type_match = _is_sub_node_type(source_type) and target_type in _PARENT_TYPES
        if not is_sub_edge and not is_type_match:
            continue

        # Merge sub-node config into parent
        sub_config = source_node["config"]
        parent_config = target_node["config"]

        if source_type.startswith("chat_model_"):
            # Merge provider config fields into parent
            for key in (
                "model_name",
                "model",
                "api_key",
                "api_base",
                "base_url",
                "temperature",
                "max_tokens",
                "top_p",
                "top_k",
                "request_timeout",
                "timeout",
            ):
                if key in sub_config:
                    parent_config[key] = sub_config[key]
            # Ollama UI may show a default base URL without persisting it until the
            # user edits the field. Without base_url, create_provider() falls through
            # to LiteLLM with model=qwen3:14b (invalid). OpenAI-compat needs .../v1.
            if source_type == "chat_model_ollama" and not (
                parent_config.get("base_url") or parent_config.get("api_base")
            ):
                parent_config["base_url"] = "http://localhost:11434/v1"
            logger.debug(
                "Merged chat_model config from '%s' into '%s'",
                source_id,
                target_id,
            )
        elif source_type == "tool":
            # Accumulate tool configs
            existing_tools = parent_config.get("tools", {})
            tool_name = sub_config.get("name", source_id)
            existing_tools[tool_name] = {
                k: v for k, v in sub_config.items() if k != "name"
            }
            parent_config["tools"] = existing_tools
            logger.debug(
                "Merged tool config from '%s' into '%s'",
                source_id,
                target_id,
            )
        elif source_type.startswith("tool_"):
            # Map tool_* type to its preset factory config
            preset = _TOOL_TYPE_PRESETS.get(source_type)
            if preset:
                existing_tools = parent_config.get("tools", {})
                tool_name = sub_config.get("name", preset["name"])
                merged: dict[str, Any] = {
                    "factory_module": preset["factory_module"],
                    "factory_function": preset["factory_function"],
                    "factory_args": sub_config.get("factory_args", {}),
                }
                # Pass through context for system prompt injection
                tool_context = sub_config.get("context")
                if tool_context:
                    merged["context"] = tool_context
                existing_tools[tool_name] = merged
                parent_config["tools"] = existing_tools
            else:
                # Generic tool_* fallback
                existing_tools = parent_config.get("tools", {})
                tool_name = sub_config.get("name", source_id)
                existing_tools[tool_name] = {
                    k: v for k, v in sub_config.items() if k != "name"
                }
                parent_config["tools"] = existing_tools
            logger.debug(
                "Merged %s config from '%s' into '%s'",
                source_type,
                source_id,
                target_id,
            )
        elif source_type == "gsheets":
            # Dedicated Sheets DAG node: when wired to sub:tool, register the
            # same factory tools as tool_gsheets (agent-driven writes/reads).
            if target_handle != "sub:tool":
                continue
            existing_tools = parent_config.get("tools", {})
            tool_name = sub_config.get("name", "google_sheets")
            factory_args: dict[str, Any] = {}
            cred_env = sub_config.get("credentials_env_var")
            if isinstance(cred_env, str) and cred_env.strip():
                factory_args["credentials_env_var"] = cred_env.strip()
            merged_gs: dict[str, Any] = {
                "factory_module": "pygubernator.tools.gsheets_factory",
                "factory_function": "create_tools_from_env",
                "factory_args": factory_args,
            }
            tool_context = sub_config.get("context")
            if tool_context:
                merged_gs["context"] = tool_context
            existing_tools[tool_name] = merged_gs
            parent_config["tools"] = existing_tools
            logger.debug(
                "Merged gsheets tool factory from '%s' into '%s'",
                source_id,
                target_id,
            )
        elif source_type == "memory":
            parent_config["memory"] = dict(sub_config)
            logger.debug(
                "Merged memory config from '%s' into '%s'",
                source_id,
                target_id,
            )

        sub_node_ids.add(source_id)
        sub_edges.add(idx)

    # Remove sub-nodes and their edges
    for nid in sub_node_ids:
        del nodes[nid]

    remaining_edges = [e for idx, e in enumerate(edges) if idx not in sub_edges]
    # Also remove any other edges referencing removed sub-nodes
    remaining_edges = [
        e
        for e in remaining_edges
        if e.source not in sub_node_ids and e.target not in sub_node_ids
    ]

    if sub_node_ids:
        logger.info(
            "Resolved %d sub-node(s) into parent nodes: %s",
            len(sub_node_ids),
            sub_node_ids,
        )

    return nodes, remaining_edges


def _check_graph_connectivity(
    nodes: dict[str, NodeSpec],
    edges: list[EdgeSpec],
) -> None:
    """Check graph connectivity and warn about issues."""
    input_nodes = [n for n in nodes.values() if n.node_type == "input"]
    output_nodes = [n for n in nodes.values() if n.node_type == "output"]

    if not input_nodes:
        logger.warning("Workflow has no input nodes")
    if not output_nodes:
        logger.warning("Workflow has no output nodes")

    # Check that output nodes have at least one incoming edge
    targets = {e.target_id for e in edges}
    for output_node in output_nodes:
        if output_node.node_id not in targets:
            logger.warning(
                "Output node '%s' has no incoming edges",
                output_node.node_id,
            )

    # Check that input nodes have at least one outgoing edge
    sources = {e.source_id for e in edges}
    for input_node in input_nodes:
        if input_node.node_id not in sources:
            logger.warning(
                "Input node '%s' has no outgoing edges",
                input_node.node_id,
            )
