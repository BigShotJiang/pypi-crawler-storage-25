"""YAML/JSON config loader for workflow specifications."""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any

import yaml

from pygubernator.errors import ConfigError
from pygubernator.workflow._types import WorkflowSpec
from pygubernator.workflow.config._converter import workflow_config_to_spec
from pygubernator.workflow.config._models import WorkflowConfig

logger = logging.getLogger(__name__)

_ENV_PATTERN = re.compile(
    r"\$\{(?P<var>[A-Za-z_][A-Za-z0-9_]*)"
    r"(?::(?P<flag>[-?])(?P<val>[^}]*))?\}"
)


class WorkflowLoader:
    """Loads workflow specifications from YAML/JSON files or dicts.

    Supports environment variable substitution in string values:
    - ``${VAR}`` — replaced with env var value (error if unset)
    - ``${VAR:-default}`` — replaced with default if unset
    - ``${VAR:?error message}`` — raises ConfigError if unset
    """

    def load(self, path: str | Path) -> WorkflowSpec:
        """Load a workflow spec from a YAML or JSON file.

        Args:
            path: Path to the configuration file.

        Returns:
            Validated and frozen WorkflowSpec.

        Raises:
            ConfigError: If the file cannot be read or parsed.
        """
        file_path = Path(path)
        if not file_path.exists():
            raise ConfigError(
                f"Workflow config file not found: {file_path}",
                path=str(file_path),
            )

        try:
            raw = file_path.read_text(encoding="utf-8")
            data = yaml.safe_load(raw)
        except yaml.YAMLError as exc:
            raise ConfigError(
                f"Failed to parse YAML: {exc}",
                path=str(file_path),
            ) from exc

        if not isinstance(data, dict):
            raise ConfigError(
                "Workflow config must be a YAML mapping",
                path=str(file_path),
            )

        return self.load_dict(data)

    def load_dict(self, config: dict[str, Any]) -> WorkflowSpec:
        """Load a workflow spec from a raw dictionary.

        Args:
            config: Dictionary matching the WorkflowConfig schema.

        Returns:
            Validated and frozen WorkflowSpec.

        Raises:
            ConfigError: If validation fails.
        """
        substituted = _substitute_env_vars(config)
        try:
            parsed = WorkflowConfig.model_validate(substituted)
        except Exception as exc:
            raise ConfigError(
                f"Workflow config validation failed: {exc}",
            ) from exc

        return workflow_config_to_spec(parsed)


def _substitute_env_vars(obj: Any) -> Any:
    """Recursively substitute environment variables in string values."""
    if isinstance(obj, str):
        return _ENV_PATTERN.sub(_env_replacer, obj)
    if isinstance(obj, dict):
        return {k: _substitute_env_vars(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_substitute_env_vars(item) for item in obj]
    return obj


def _env_replacer(match: re.Match[str]) -> str:
    """Replace a single env var match."""
    var = match.group("var")
    flag = match.group("flag")
    val = match.group("val")
    env_value = os.environ.get(var)

    if env_value is not None:
        return env_value

    if flag == "-":
        return val or ""

    if flag == "?":
        raise ConfigError(
            f"Required environment variable '{var}' is not set: {val or 'no message'}",
        )

    raise ConfigError(
        f"Environment variable '{var}' is not set "
        f"(use ${{{{var}}:-default}} for a fallback)",
    )
