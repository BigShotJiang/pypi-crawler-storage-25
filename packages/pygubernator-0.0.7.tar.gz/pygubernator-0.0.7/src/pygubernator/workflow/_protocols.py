"""Protocols for workflow node types and factories."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from pygubernator.workflow._types import NodeContext, NodeResult


@runtime_checkable
class Node(Protocol):
    """Protocol for workflow node implementations.

    Nodes are lightweight execution units. The engine manages lifecycle;
    nodes only need to implement ``execute``.
    """

    @property
    def node_type(self) -> str:
        """Return the type identifier for this node (e.g. 'template')."""
        ...

    async def execute(self, context: NodeContext) -> NodeResult:
        """Execute the node with the given context.

        Args:
            context: Execution context with input data, variables,
                and node configuration.

        Returns:
            Result containing output data and status.
        """
        ...


@runtime_checkable
class NodeFactory(Protocol):
    """Protocol for creating node instances from configuration.

    Factories receive the node config dict and return a configured
    Node instance ready for execution.
    """

    def create(self, node_id: str, config: dict[str, Any]) -> Node:
        """Create a node instance from configuration.

        Args:
            node_id: Unique node identifier.
            config: Node-specific configuration dict.

        Returns:
            Configured node instance.
        """
        ...
