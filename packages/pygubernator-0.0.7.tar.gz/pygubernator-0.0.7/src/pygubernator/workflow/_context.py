"""Data-flow merging utilities for the workflow engine."""

from __future__ import annotations

import logging
from typing import Any

import networkx as nx

from pygubernator.workflow._types import NodeContext, NodeResult

logger = logging.getLogger(__name__)
_PASSTHROUGH_OUTPUT_KEYS = {"__memory_node_id__", "__memory_history__"}


def merge_upstream_outputs(
    node_id: str,
    graph: nx.DiGraph,
    node_results: dict[str, NodeResult],
    active_edges: set[str],
) -> dict[str, Any]:
    """Merge outputs from upstream nodes whose edges are active.

    Single upstream: flatten output directly into input_data.
    Multiple upstream: namespace by source node ID.

    Args:
        node_id: Target node to merge inputs for.
        graph: The workflow DAG.
        node_results: Results from already-executed nodes.
        active_edges: Set of active edge IDs.

    Returns:
        Merged input data dict.
    """
    predecessors: list[str] = []
    for pred in graph.predecessors(node_id):
        edge_data = graph.edges[pred, node_id]
        edge_id: str = edge_data.get("edge_id", "")
        if edge_id in active_edges and pred in node_results:
            predecessors.append(pred)

    if not predecessors:
        return {}

    if len(predecessors) == 1:
        return dict(node_results[predecessors[0]].output)

    merged: dict[str, Any] = {}
    for pred in predecessors:
        output = dict(node_results[pred].output)
        merged[pred] = output
        # Preserve special workflow keys at top level even with fan-in,
        # so downstream LLM/Agent nodes can consume memory context.
        for k in _PASSTHROUGH_OUTPUT_KEYS:
            if k in output:
                merged[k] = output[k]
    return merged


def build_node_context(
    node_id: str,
    input_data: dict[str, Any],
    variables: dict[str, Any],
    config: dict[str, Any],
) -> NodeContext:
    """Construct a NodeContext from merged upstream data.

    Args:
        node_id: The node being executed.
        input_data: Merged upstream outputs.
        variables: Shared workflow variables.
        config: Node-specific configuration.

    Returns:
        Frozen NodeContext instance.
    """
    return NodeContext(
        node_id=node_id,
        input_data=input_data,
        variables=variables,
        config=config,
    )
