"""Frozen dataclasses for validated, immutable workflow representations."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any


class NodeStatus(enum.Enum):
    """Execution status of a workflow node."""

    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"
    AWAITING_APPROVAL = "awaiting_approval"


@dataclass(frozen=True, slots=True)
class NodeSpec:
    """Specification for a single workflow node.

    Args:
        node_id: Unique identifier for this node.
        node_type: Type of node (e.g. "template", "condition", "code").
        config: Node-specific configuration dict.
        position: Optional (x, y) position for visual layout.
    """

    node_id: str
    node_type: str
    config: dict[str, Any] = field(default_factory=dict)
    position: tuple[float, float] = (0.0, 0.0)


@dataclass(frozen=True, slots=True)
class EdgeSpec:
    """A directed edge connecting nodes in a workflow.

    Args:
        edge_id: Unique identifier for this edge.
        source_id: Source node ID.
        target_id: Target node ID.
        source_handle: Output handle on the source node.
        target_handle: Input handle on the target node.
        condition: Optional expression for conditional routing.
    """

    edge_id: str
    source_id: str
    target_id: str
    source_handle: str = "default"
    target_handle: str = "default"
    condition: str | None = None


@dataclass(frozen=True, slots=True)
class WorkflowSpec:
    """Complete specification for a workflow.

    Args:
        name: Human-readable workflow name.
        version: Semantic version string.
        description: Brief description of the workflow's purpose.
        nodes: Node specifications keyed by node_id.
        edges: Directed edges connecting nodes.
    """

    name: str
    version: str
    description: str = ""
    nodes: dict[str, NodeSpec] = field(default_factory=dict)
    edges: tuple[EdgeSpec, ...] = ()


@dataclass(frozen=True, slots=True)
class NodeContext:
    """Execution context passed to a workflow node.

    Args:
        node_id: ID of the node being executed.
        input_data: Data from upstream nodes or workflow input.
        variables: Shared workflow variables (mutable scratch space).
        config: Node-specific configuration.
    """

    node_id: str
    input_data: dict[str, Any] = field(default_factory=dict)
    variables: dict[str, Any] = field(default_factory=dict)
    config: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class NodeResult:
    """Result of executing a single workflow node.

    Args:
        node_id: ID of the node that produced this result.
        status: Execution status.
        output: Output data from the node.
        error: Error message if the node failed.
        output_handle: Which output handle was activated.
    """

    node_id: str
    status: NodeStatus = NodeStatus.SUCCESS
    output: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    output_handle: str = "default"

    def to_dict(self) -> dict[str, Any]:
        """Serialize the node result to a dictionary.

        Returns:
            Dictionary representation of the node result.
        """
        return {
            "node_id": self.node_id,
            "status": self.status.value,
            "output": self.output,
            "error": self.error,
            "output_handle": self.output_handle,
        }


@dataclass(frozen=True, slots=True)
class WorkflowResult:
    """Result of executing a complete workflow.

    Args:
        name: Workflow name.
        success: Whether the workflow completed successfully.
        node_results: Results from each executed node.
        output: Final output data collected from output nodes.
        errors: Error descriptions encountered during execution.
        cancelled: True if stopped cooperatively (between DAG levels).
    """

    name: str
    success: bool
    node_results: dict[str, NodeResult] = field(default_factory=dict)
    output: dict[str, Any] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    cancelled: bool = False
    awaiting_approval: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Serialize the workflow result to a dictionary.

        Returns:
            Dictionary representation of the workflow result.
        """
        return {
            "name": self.name,
            "success": self.success,
            "node_results": {k: v.to_dict() for k, v in self.node_results.items()},
            "output": self.output,
            "errors": self.errors,
            "cancelled": self.cancelled,
            "awaiting_approval": self.awaiting_approval,
        }
