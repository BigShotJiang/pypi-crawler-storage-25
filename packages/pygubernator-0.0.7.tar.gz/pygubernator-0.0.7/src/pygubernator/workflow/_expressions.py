"""Safe AST-based expression evaluator for workflow conditions."""

from __future__ import annotations

import ast
import logging
import operator
from typing import Any

from pygubernator.errors import ExpressionError

logger = logging.getLogger(__name__)

_COMPARE_OPS: dict[type, Any] = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.Is: operator.is_,
    ast.IsNot: operator.is_not,
    ast.In: lambda a, b: a in b,
    ast.NotIn: lambda a, b: a not in b,
}

_BOOL_OPS: dict[type, Any] = {
    ast.And: all,
    ast.Or: any,
}

_UNARY_OPS: dict[type, Any] = {
    ast.Not: operator.not_,
    ast.USub: operator.neg,
}

_BIN_OPS: dict[type, Any] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
}

_MAX_EXPR_LENGTH = 500


class SafeExpressionEvaluator:
    """Evaluate expressions safely using AST walking.

    Supports comparisons, boolean logic, attribute access, subscripts,
    and basic arithmetic. No function calls, imports, or assignments.

    Args:
        namespace: Variables available in the expression.
    """

    def __init__(self, namespace: dict[str, Any] | None = None) -> None:
        self._namespace: dict[str, Any] = namespace or {}

    def evaluate(self, expr: str) -> Any:
        """Evaluate a safe expression string.

        Args:
            expr: Expression string to evaluate.

        Returns:
            The result of the expression.

        Raises:
            ExpressionError: If the expression is invalid or uses
                forbidden constructs.
        """
        if len(expr) > _MAX_EXPR_LENGTH:
            raise ExpressionError(
                f"Expression exceeds max length of {_MAX_EXPR_LENGTH}",
                expression=expr[:50] + "...",
            )

        try:
            tree = ast.parse(expr, mode="eval")
        except SyntaxError as exc:
            raise ExpressionError(
                f"Invalid expression syntax: {exc}",
                expression=expr,
            ) from exc

        return self._eval_node(tree.body)

    def evaluate_bool(self, expr: str) -> bool:
        """Evaluate an expression and return as boolean.

        Args:
            expr: Expression string to evaluate.

        Returns:
            Boolean result of the expression.
        """
        return bool(self.evaluate(expr))

    def _eval_node(self, node: ast.expr) -> Any:
        """Evaluate a single AST node."""
        if isinstance(node, ast.Constant):
            return node.value

        if isinstance(node, ast.Name):
            return self._resolve_name(node.id)

        if isinstance(node, ast.Attribute):
            obj = self._eval_node(node.value)
            if not hasattr(obj, node.attr):
                raise ExpressionError(
                    f"Object has no attribute '{node.attr}'",
                    expression=ast.dump(node),
                )
            return getattr(obj, node.attr)

        if isinstance(node, ast.Subscript):
            obj = self._eval_node(node.value)
            key = self._eval_node(node.slice)
            return obj[key]

        if isinstance(node, ast.Compare):
            return self._eval_compare(node)

        if isinstance(node, ast.BoolOp):
            return self._eval_boolop(node)

        if isinstance(node, ast.UnaryOp):
            return self._eval_unaryop(node)

        if isinstance(node, ast.BinOp):
            return self._eval_binop(node)

        if isinstance(node, ast.IfExp):
            test = self._eval_node(node.test)
            return self._eval_node(node.body) if test else self._eval_node(node.orelse)

        if isinstance(node, ast.List):
            return [self._eval_node(elt) for elt in node.elts]

        if isinstance(node, ast.Tuple):
            return tuple(self._eval_node(elt) for elt in node.elts)

        if isinstance(node, ast.Dict):
            keys = [self._eval_node(k) for k in node.keys if k is not None]
            values = [self._eval_node(v) for v in node.values]
            return dict(zip(keys, values, strict=False))

        raise ExpressionError(
            f"Unsupported expression type: {type(node).__name__}",
            expression=ast.dump(node),
        )

    def _resolve_name(self, name: str) -> Any:
        """Resolve a variable name from the namespace."""
        if name == "True":
            return True
        if name == "False":
            return False
        if name == "None":
            return None
        if name in self._namespace:
            return self._namespace[name]
        raise ExpressionError(
            f"Undefined variable: '{name}'",
            expression=name,
        )

    def _eval_compare(self, node: ast.Compare) -> bool:
        """Evaluate a comparison chain."""
        left = self._eval_node(node.left)
        for op, comparator in zip(node.ops, node.comparators, strict=False):
            right = self._eval_node(comparator)
            op_func = _COMPARE_OPS.get(type(op))
            if op_func is None:
                raise ExpressionError(
                    f"Unsupported comparison: {type(op).__name__}",
                    expression=ast.dump(node),
                )
            if not op_func(left, right):
                return False
            left = right
        return True

    def _eval_boolop(self, node: ast.BoolOp) -> Any:
        """Evaluate a boolean operation (and/or)."""
        op_func = _BOOL_OPS.get(type(node.op))
        if op_func is None:
            raise ExpressionError(
                f"Unsupported boolean op: {type(node.op).__name__}",
                expression=ast.dump(node),
            )
        values = [self._eval_node(v) for v in node.values]
        return op_func(values)

    def _eval_unaryop(self, node: ast.UnaryOp) -> Any:
        """Evaluate a unary operation."""
        op_func = _UNARY_OPS.get(type(node.op))
        if op_func is None:
            raise ExpressionError(
                f"Unsupported unary op: {type(node.op).__name__}",
                expression=ast.dump(node),
            )
        return op_func(self._eval_node(node.operand))

    def _eval_binop(self, node: ast.BinOp) -> Any:
        """Evaluate a binary operation."""
        op_func = _BIN_OPS.get(type(node.op))
        if op_func is None:
            raise ExpressionError(
                f"Unsupported binary op: {type(node.op).__name__}",
                expression=ast.dump(node),
            )
        left = self._eval_node(node.left)
        right = self._eval_node(node.right)
        return op_func(left, right)


def evaluate_condition(
    expr: str,
    namespace: dict[str, Any] | None = None,
) -> bool:
    """Evaluate a condition expression safely.

    Convenience function wrapping SafeExpressionEvaluator.

    Args:
        expr: Boolean expression string.
        namespace: Variables available in the expression.

    Returns:
        Boolean result.

    Raises:
        ExpressionError: If the expression is invalid.
    """
    evaluator = SafeExpressionEvaluator(namespace)
    return evaluator.evaluate_bool(expr)
