"""LLM integration workflow node."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._templates import render_template
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

try:
    from pygubernator._types import Message
    from pygubernator.agents import LLMAgent
    from pygubernator.tools import ToolRegistry

    _HAS_LLM = True
except ImportError:
    _HAS_LLM = False


class LLMNode(AbstractNode):
    """Sends a prompt to an LLM and returns the response.

    Wraps LLMAgent: NodeContext.input_data → Message → agent.process()
    → AgentResult.metadata["response"] → NodeResult.output["response"].

    Config:
        system_prompt: System prompt for the LLM (optional).
        prompt_template: Jinja2 template for the user prompt (required).
        model: Model identifier override (optional).
        max_iterations: Max tool-calling iterations (default: 5).
    """

    node_type = "llm"

    def __init__(
        self,
        node_id: str,
        config: dict[str, Any],
        llm_provider: Any,
        tool_registry: Any | None = None,
        provider_error: str | None = None,
    ) -> None:
        super().__init__(node_id, config)
        self._llm_provider = llm_provider
        self._tool_registry = tool_registry
        self._provider_error = provider_error

    async def execute(self, context: NodeContext) -> NodeResult:
        """Execute the LLM prompt.

        Args:
            context: Execution context with input data.

        Returns:
            Result with the LLM response.
        """
        if not _HAS_LLM:
            return self._failure(
                "LLM dependencies not available. "
                "Install with: pip install pygubernator[workflow]"
            )

        if self._llm_provider is None:
            return self._failure(self._provider_error or "No LLM provider available.")

        prompt_template = self._config.get("prompt_template", "")
        if not prompt_template:
            return self._failure("No prompt_template configured")

        system_prompt = self._config.get("system_prompt", "")
        max_iterations = self._config.get("max_iterations", 5)

        template_ctx = {**context.variables, **context.input_data}
        try:
            prompt = render_template(prompt_template, template_ctx)
        except Exception as exc:
            return self._failure(f"Prompt template error: {exc}")

        # Resolve memory: upstream MemoryNode or embedded sub-node config
        memory_history, memory_store = self._resolve_memory(context)

        # Compact memory if the store supports it
        if memory_store is not None and hasattr(memory_store, "prepare"):
            await memory_store.prepare()
            memory_history = memory_store.get_messages()

        try:
            agent = LLMAgent(
                agent_id=f"llm_node_{self._node_id}",
                llm_provider=self._llm_provider,
                tool_registry=self._tool_registry or ToolRegistry(),
                system_prompt=system_prompt,
                max_iterations=max_iterations,
            )

            message = Message(
                topic="workflow",
                payload={"content": prompt, **context.input_data},
            )
            result = await agent.process(message, history=memory_history)
        except Exception as exc:
            logger.error("LLM node %s failed: %s", self._node_id, exc)
            return self._failure(f"LLM execution failed: {exc}")

        response = result.metadata.get("response", "")

        # Write exchange back to memory store (if available)
        if memory_store is not None:
            try:
                memory_store.add_messages(
                    [
                        {"role": "user", "content": prompt},
                        {"role": "assistant", "content": response},
                    ]
                )
            except Exception as exc:
                logger.error(
                    "LLMNode %s memory writeback failed: %s",
                    self._node_id,
                    exc,
                )

        return self._success({"response": response})

    def _resolve_memory(
        self,
        context: NodeContext,
    ) -> tuple[list[dict[str, str]] | None, Any]:
        """Resolve memory from upstream node or embedded sub-node config.

        Args:
            context: Node execution context.

        Returns:
            Tuple of (history, store). Both are None if no memory is
            configured.
        """
        # Option 1: upstream MemoryNode provided history via DAG edge
        upstream_history = context.input_data.get("__memory_history__")
        if upstream_history is not None:
            memory_node_id = context.input_data.get("__memory_node_id__")
            store = None
            if memory_node_id:
                stores = context.variables.get("__memory_stores__", {})
                store = stores.get(memory_node_id)
            return upstream_history, store

        # Option 2: memory config merged as sub-node
        memory_config = self._config.get("memory")
        if not memory_config:
            return None, None

        from pygubernator.workflow.nodes._memory import (
            resolve_embedded_memory,
        )

        session_id = context.variables.get("__session_id__")
        try:
            return resolve_embedded_memory(
                node_id=self._node_id,
                memory_config=memory_config,
                session_id=session_id,
            )
        except Exception as exc:
            logger.error(
                "LLMNode %s embedded memory init failed: %s",
                self._node_id,
                exc,
            )
            return None, None


class LLMNodeFactory:
    """Factory for creating LLMNode instances with injected provider.

    Args:
        llm_provider: LLM provider instance.
        tool_registry: Optional tool registry for agent tool calls.
    """

    def __init__(
        self,
        llm_provider: Any,
        tool_registry: Any | None = None,
    ) -> None:
        self._llm_provider = llm_provider
        self._tool_registry = tool_registry

    def create(self, node_id: str, config: dict[str, Any]) -> LLMNode:
        """Create an LLMNode.

        If no provider was injected and the config contains provider
        settings (from a connected chat_model sub-node), auto-creates
        a provider via ``create_provider``.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured LLMNode instance.
        """
        provider = self._llm_provider
        provider_error: str | None = None
        if provider is None:
            provider, provider_error = self._resolve_provider_from_config(config)

        return LLMNode(
            node_id=node_id,
            config=config,
            llm_provider=provider,
            tool_registry=self._tool_registry,
            provider_error=provider_error,
        )

    @staticmethod
    def _resolve_provider_from_config(
        config: dict[str, Any],
    ) -> tuple[Any | None, str | None]:
        """Try to create a provider from node config fields.

        Returns:
            Tuple of (provider, error_message). On success error_message is None.
        """
        model = config.get("model_name") or config.get("model")
        if not model:
            return None, "No model configured. Attach a chat model sub-node."

        try:
            from pygubernator.llm._factory import create_provider

            rt = config.get("request_timeout", config.get("timeout"))
            extra: dict[str, Any] = {}
            if rt is not None:
                extra["request_timeout"] = float(rt)
            provider = create_provider(
                model=model,
                api_base=(config.get("base_url") or config.get("api_base")),
                api_key=config.get("api_key"),
                max_tokens=config.get("max_tokens", 4096),
                temperature=config.get("temperature", 0.0),
                **extra,
            )
            return provider, None
        except ImportError as exc:
            msg = f"Missing dependency for model '{model}': {exc}"
            logger.error(msg)
            return None, msg
        except Exception as exc:
            msg = f"Failed to create provider for model '{model}': {exc}"
            logger.error(msg, exc_info=True)
            return None, msg
