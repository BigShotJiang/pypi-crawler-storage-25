"""Memory node: conversation history store for LLM workflows."""

from __future__ import annotations

import logging
from typing import Any, Protocol, runtime_checkable

from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

_MEMORY_STORES_KEY = "__memory_stores__"
_SESSION_ID_KEY = "__session_id__"


@runtime_checkable
class MemoryStore(Protocol):
    """Protocol for conversation memory stores."""

    def get_messages(self) -> list[dict[str, str]]:
        """Return stored conversation messages.

        Returns:
            List of message dicts with ``role`` and ``content`` keys.
        """
        ...

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Append messages to the store.

        Args:
            messages: Messages to add.
        """
        ...


# Module-level cache for session-aware in-memory stores.
# Keyed by "{session_id}:{node_id}".
_SESSION_STORES: dict[str, MemoryStore] = {}


def clear_session_stores(session_id: str) -> None:
    """Remove all cached in-memory stores for a session.

    Args:
        session_id: The session whose stores should be cleared.
    """
    to_remove = [k for k in _SESSION_STORES if k.startswith(f"{session_id}:")]
    for k in to_remove:
        del _SESSION_STORES[k]


class BufferMemoryStore:
    """Unbounded memory store that retains all messages."""

    def __init__(self) -> None:
        self._messages: list[dict[str, str]] = []

    def get_messages(self) -> list[dict[str, str]]:
        """Return all stored messages.

        Returns:
            List of all message dicts.
        """
        return list(self._messages)

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Append messages to the buffer.

        Args:
            messages: Messages to add.
        """
        self._messages.extend(messages)


class WindowMemoryStore:
    """Sliding-window memory store that retains the last N messages.

    Args:
        window_size: Maximum number of messages to retain.
    """

    def __init__(self, window_size: int = 10) -> None:
        self._messages: list[dict[str, str]] = []
        self._window_size = window_size

    def get_messages(self) -> list[dict[str, str]]:
        """Return the last ``window_size`` messages.

        Returns:
            List of the most recent message dicts.
        """
        return list(self._messages[-self._window_size :])

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Append messages, trimming to the window size.

        Args:
            messages: Messages to add.
        """
        self._messages.extend(messages)


def create_memory_store(
    memory_type: str = "buffer",
    window_size: int = 10,
    backend: str = "in_memory",
    config: dict[str, Any] | None = None,
) -> MemoryStore:
    """Factory for creating memory store instances.

    Args:
        memory_type: Retrieval strategy — ``"buffer"``, ``"window"``,
            or ``"compacting"``.
        window_size: Window size (only used for ``"window"`` type).
        backend: Storage backend identifier.
        config: Full node config dict for backend-specific settings.

    Returns:
        A memory store instance.

    Raises:
        ValueError: If ``memory_type`` or ``backend`` is not recognised.
        ImportError: If the required library for a backend is missing.
    """
    cfg = config or {}

    if backend == "in_memory":
        if memory_type == "buffer":
            return BufferMemoryStore()
        if memory_type == "window":
            return WindowMemoryStore(window_size=window_size)
        if memory_type == "compacting":
            from pygubernator.workflow.nodes._memory_compacting import (
                CompactingMemoryStore,
            )

            inner = BufferMemoryStore()
            llm_provider = cfg.get("llm_provider")
            max_tokens = cfg.get("max_tokens", 8000)
            preserve_recent = cfg.get("preserve_recent", 4)
            model = cfg.get("model", "")
            return CompactingMemoryStore(
                inner=inner,
                llm_provider=llm_provider,
                max_tokens=max_tokens,
                preserve_recent=preserve_recent,
                model=model,
            )
        msg = f"Unknown memory_type: {memory_type!r}"
        raise ValueError(msg)

    return _create_persistent_store(backend, cfg)


# Maps backend name → (module_path, factory_function_name)
_BACKEND_REGISTRY: dict[str, tuple[str, str]] = {
    "sqlite": (
        "pygubernator.workflow.nodes._memory_sqlite",
        "create_sqlite_store",
    ),
    "postgres": (
        "pygubernator.workflow.nodes._memory_postgres",
        "create_postgres_store",
    ),
    "mongodb": (
        "pygubernator.workflow.nodes._memory_mongodb",
        "create_mongo_store",
    ),
    "pinecone": (
        "pygubernator.workflow.nodes._memory_vector",
        "create_pinecone_store",
    ),
    "chroma": (
        "pygubernator.workflow.nodes._memory_vector",
        "create_chroma_store",
    ),
    "qdrant": (
        "pygubernator.workflow.nodes._memory_vector",
        "create_qdrant_store",
    ),
    "weaviate": (
        "pygubernator.workflow.nodes._memory_vector",
        "create_weaviate_store",
    ),
    "milvus": (
        "pygubernator.workflow.nodes._memory_vector",
        "create_milvus_store",
    ),
}


def _create_persistent_store(backend: str, config: dict[str, Any]) -> MemoryStore:
    """Lazily import and instantiate a persistent memory store.

    Args:
        backend: Backend identifier (e.g. ``"sqlite"``, ``"postgres"``).
        config: Node configuration dict.

    Returns:
        A memory store instance.

    Raises:
        ValueError: If the backend is unknown.
        ImportError: If the required library is not installed.
    """
    import importlib

    entry = _BACKEND_REGISTRY.get(backend)
    if entry is None:
        msg = f"Unknown memory backend: {backend!r}"
        raise ValueError(msg)

    module_path, factory_name = entry
    module = importlib.import_module(module_path)
    factory_fn = getattr(module, factory_name)
    return factory_fn(config)  # type: ignore[no-any-return]


def resolve_embedded_memory(
    node_id: str,
    memory_config: dict[str, Any],
    session_id: str | None,
) -> tuple[list[dict[str, str]], MemoryStore]:
    """Create or retrieve a memory store from embedded sub-node config.

    Used by agent/LLM nodes when memory config has been merged into
    their own config by the sub-node resolver.

    Args:
        node_id: Parent node ID (used as part of the session cache key).
        memory_config: Memory configuration dict (backend, memory_type, etc.).
        session_id: Optional session ID for cross-run persistence.

    Returns:
        Tuple of (message_history, store).
    """
    backend = memory_config.get("backend", "in_memory")
    memory_type = memory_config.get("memory_type", "buffer")
    window_size = memory_config.get("window_size", 10)

    if session_id and backend == "in_memory":
        cache_key = f"{session_id}:{node_id}"
        if cache_key not in _SESSION_STORES:
            _SESSION_STORES[cache_key] = create_memory_store(
                memory_type=memory_type,
                window_size=window_size,
                backend=backend,
                config=memory_config,
            )
        store = _SESSION_STORES[cache_key]
    elif session_id and backend != "in_memory":
        cfg = {**memory_config, "session_id": session_id}
        store = create_memory_store(
            memory_type=memory_type,
            window_size=window_size,
            backend=backend,
            config=cfg,
        )
    else:
        store = create_memory_store(
            memory_type=memory_type,
            window_size=window_size,
            backend=backend,
            config=memory_config,
        )

    return store.get_messages(), store


class MemoryNode(AbstractNode):
    """Workflow node that provides conversation memory to downstream LLM nodes.

    Creates or reuses a ``MemoryStore`` in the shared ``variables`` dict
    and outputs the current message history for the downstream LLM node.

    Config:
        backend: Storage backend — ``"in_memory"`` (default), ``"sqlite"``,
            ``"postgres"``, ``"mongodb"``, ``"pinecone"``, ``"chroma"``,
            ``"qdrant"``, ``"weaviate"``, or ``"milvus"``.
        memory_type: ``"buffer"`` (default) or ``"window"``.
        window_size: Number of messages for window mode (default 10).

    Backend-specific keys (e.g. ``db_path``, ``connection_string``,
    ``api_key``) are passed through to the store constructor.
    """

    node_type = "memory"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Read or initialise the memory store and output history.

        When a ``__session_id__`` is present in ``context.variables``,
        the store is cached globally so it persists across workflow
        runs within the same session (multi-turn conversations).

        Args:
            context: Execution context with shared variables.

        Returns:
            Result containing ``__memory_node_id__`` and
            ``__memory_history__``.
        """
        stores = context.variables.setdefault(_MEMORY_STORES_KEY, {})
        session_id: str | None = context.variables.get(_SESSION_ID_KEY)

        if self._node_id not in stores:
            memory_type = self._config.get("memory_type", "buffer")
            window_size = self._config.get("window_size", 10)
            backend = self._config.get("backend", "in_memory")
            try:
                store = self._resolve_store(
                    session_id=session_id,
                    backend=backend,
                    memory_type=memory_type,
                    window_size=window_size,
                )
                stores[self._node_id] = store
            except Exception as exc:
                logger.error("MemoryNode %s store init failed: %s", self._node_id, exc)
                return self._failure(f"Memory store init failed: {exc}")

        store: MemoryStore = stores[self._node_id]
        try:
            history = store.get_messages()
        except Exception as exc:
            logger.error("MemoryNode %s get_messages failed: %s", self._node_id, exc)
            return self._failure(f"Memory read failed: {exc}")

        logger.debug("MemoryNode %s returning %d messages", self._node_id, len(history))

        return self._success(
            {
                "__memory_node_id__": self._node_id,
                "__memory_history__": history,
            }
        )

    def _resolve_store(
        self,
        *,
        session_id: str | None,
        backend: str,
        memory_type: str,
        window_size: int,
    ) -> MemoryStore:
        """Create or retrieve a memory store, with session caching.

        For in-memory backends with a session_id, the store is cached
        in the module-level ``_SESSION_STORES`` dict so it survives
        across workflow runs. For persistent backends, the session_id
        is passed through to scope queries.

        Args:
            session_id: Optional session ID for multi-turn support.
            backend: Storage backend name.
            memory_type: ``"buffer"`` or ``"window"``.
            window_size: Sliding window size for window mode.

        Returns:
            A MemoryStore instance.
        """
        if session_id and backend == "in_memory":
            cache_key = f"{session_id}:{self._node_id}"
            if cache_key in _SESSION_STORES:
                return _SESSION_STORES[cache_key]
            store = create_memory_store(
                memory_type=memory_type,
                window_size=window_size,
                backend=backend,
                config=self._config,
            )
            _SESSION_STORES[cache_key] = store
            return store

        if session_id and backend != "in_memory":
            cfg = {**self._config, "session_id": session_id}
            return create_memory_store(
                memory_type=memory_type,
                window_size=window_size,
                backend=backend,
                config=cfg,
            )

        return create_memory_store(
            memory_type=memory_type,
            window_size=window_size,
            backend=backend,
            config=self._config,
        )


class MemoryNodeFactory:
    """Factory for creating MemoryNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> MemoryNode:
        """Create a MemoryNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured MemoryNode instance.
        """
        return MemoryNode(node_id=node_id, config=config)
