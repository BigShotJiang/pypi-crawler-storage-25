"""Workflow node that executes another workflow spec inline."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)


class SubWorkflowNode(AbstractNode):
    """Executes a nested workflow spec as a single node.

    The sub-workflow receives the parent node's input_data as its
    initial input. Its output becomes this node's output.

    Config:
        workflow_spec: Inline workflow spec dict (required). Must
            be a valid workflow spec with nodes and edges.
        pass_variables: Whether to pass parent variables to the
            sub-workflow (default True).
    """

    node_type = "subworkflow"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Execute the nested workflow.

        Args:
            context: Execution context with input data.

        Returns:
            Result with the sub-workflow's output.
        """
        spec_dict = self._config.get("workflow_spec")
        if not spec_dict:
            return self._failure("SubWorkflowNode requires 'workflow_spec' in config")

        if not isinstance(spec_dict, dict):
            return self._failure("workflow_spec must be a dict")

        try:
            result = await self._run_sub_workflow(spec_dict, context)
        except Exception as exc:
            logger.error(
                "SubWorkflowNode %s failed: %s",
                self._node_id,
                exc,
                exc_info=True,
            )
            return self._failure(f"Sub-workflow execution failed: {exc}")

        if not result.success:
            errors = "; ".join(result.errors) if result.errors else "Unknown"
            return self._failure(f"Sub-workflow failed: {errors}")

        return self._success(dict(result.output))

    async def _run_sub_workflow(
        self,
        spec_dict: dict[str, Any],
        context: NodeContext,
    ) -> Any:
        """Build and execute the sub-workflow engine.

        Args:
            spec_dict: Raw workflow spec dictionary.
            context: Parent node execution context.

        Returns:
            WorkflowResult from the sub-workflow engine.
        """
        # Lazy imports to avoid circular dependencies
        from pygubernator.services._workflows import (
            build_node_registry,
        )
        from pygubernator.workflow._engine import WorkflowEngine
        from pygubernator.workflow.config._loader import (
            WorkflowLoader,
        )

        loader = WorkflowLoader()
        spec = loader.load_dict(spec_dict)
        registry = build_node_registry()
        engine = WorkflowEngine(spec=spec, registry=registry)

        pass_vars = self._config.get("pass_variables", True)
        variables = dict(context.variables) if pass_vars else {}

        return await engine.run(
            input_data=dict(context.input_data),
            variables=variables,
        )


class SubWorkflowNodeFactory:
    """Factory for creating SubWorkflowNode instances."""

    def create(
        self,
        node_id: str,
        config: dict[str, Any],
    ) -> SubWorkflowNode:
        """Create a SubWorkflowNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured SubWorkflowNode instance.
        """
        return SubWorkflowNode(node_id=node_id, config=config)
