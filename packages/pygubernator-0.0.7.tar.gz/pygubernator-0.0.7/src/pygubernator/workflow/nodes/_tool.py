"""Single tool execution workflow node."""

from __future__ import annotations

import importlib
import logging
from typing import Any

from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)


class ToolNode(AbstractNode):
    """Executes a single tool function loaded via importlib.

    Loads a ``@tool``-decorated function (or any async callable) from
    a Python module and executes it with merged parameters.

    Config:
        module: Dotted module path (e.g. ``mypackage.tools``).
        function: Function name within the module.
        params: Optional static parameters merged with upstream data.
    """

    node_type = "tool"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Execute the configured tool function.

        Args:
            context: Execution context with input data.

        Returns:
            Result with tool output.
        """
        module_path = self._config.get("module", "")
        func_name = self._config.get("function", "")

        if not module_path or not func_name:
            return self._failure("Tool node requires 'module' and 'function' in config")

        try:
            module = importlib.import_module(module_path)
            func = getattr(module, func_name)
        except (ImportError, AttributeError) as exc:
            return self._failure(
                f"Failed to load tool '{module_path}.{func_name}': {exc}"
            )

        # Merge static params with upstream input data
        static_params = self._config.get("params", {})
        params = {**context.input_data, **static_params}

        try:
            import asyncio

            if asyncio.iscoroutinefunction(func):
                result = await func(**params)
            else:
                result = func(**params)
        except TypeError as exc:
            # Parameter mismatch — try positional fallback
            return self._failure(f"Tool '{func_name}' parameter error: {exc}")
        except Exception as exc:
            logger.error("Tool node %s failed: %s", self._node_id, exc)
            return self._failure(f"Tool execution failed: {exc}")

        # Normalize result to dict
        output = result if isinstance(result, dict) else {"result": result}

        return self._success(output)


class ToolNodeFactory:
    """Factory for creating ToolNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> ToolNode:
        """Create a ToolNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured ToolNode instance.
        """
        return ToolNode(node_id=node_id, config=config)
