"""Autonomous LLM agent workflow node with tool calling."""

from __future__ import annotations

import importlib
import logging
from typing import Any

from pygubernator.workflow._templates import render_template
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

try:
    from pygubernator._types import Message
    from pygubernator.agents import LLMAgent
    from pygubernator.tools import ToolRegistry

    _HAS_AGENT = True
except ImportError:
    _HAS_AGENT = False


class AgentNode(AbstractNode):
    """Autonomous LLM agent with dynamic tool loading.

    Wraps ``LLMAgent`` with a provider created from config and tools
    loaded via importlib. Runs a think-act-observe loop.

    Config:
        model: Model identifier (e.g. ``ollama/llama3.1``, ``gpt-4o``).
        api_base: Optional server URL for OpenAI-compatible providers.
        api_key: Optional API key.
        system_prompt: System prompt for the agent.
        prompt_template: Jinja2 template for the user message.
        max_iterations: Max tool-calling loop iterations (default: 10).
        max_tokens: Max tokens per LLM response (default: 4096).
        temperature: Sampling temperature (default: 0.0).
        request_timeout: HTTP read timeout in seconds for OpenAI-compatible
            backends (default from env / 600). Increase for slow local models.
        tools: Dict of tool references. Supported specs:
            - Direct function: ``{module, function}``
            - Factory output: ``{factory_module, factory_function, factory_args}``
    """

    node_type = "agent"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Execute the agent with tool calling.

        Args:
            context: Execution context with input data.

        Returns:
            Result with the agent's final response.
        """
        logger.info(
            "[AGENT] execute node=%s, _HAS_AGENT=%s, config_keys=%s, input_keys=%s",
            self._node_id,
            _HAS_AGENT,
            list(self._config.keys()),
            list(context.input_data.keys()),
        )
        if not _HAS_AGENT:
            return self._failure(
                "Agent dependencies not available. "
                "Install with: pip install pygubernator[workflow]"
            )

        prompt_template = (
            self._config.get("prompt_template")
            or self._config.get("task_description")
            or ""
        )

        # Resolve LLM provider from config
        provider, provider_error = self._resolve_provider()
        logger.info(
            "[AGENT] provider resolved: type=%s, error=%s, model=%s",
            type(provider).__name__ if provider else "None",
            provider_error,
            self._config.get("model_name") or self._config.get("model"),
        )
        if provider is None:
            return self._failure(provider_error or "No model configured.")

        # Load tools from config
        registry, tool_errors = self._load_tools()
        if tool_errors:
            logger.error(
                "[AGENT] Tool loading errors for node %s: %s",
                self._node_id,
                tool_errors,
            )
            # Fail the node if ALL tools failed to load and tools
            # were configured — the agent can't do what was asked.
            tools_config = self._config.get("tools", {})
            if tools_config and len(registry) == 0:
                return self._failure(
                    "All tools failed to load: " + "; ".join(tool_errors)
                )

        system_prompt = self._config.get("system_prompt", "")

        # Inject tool context into system prompt
        tool_context_lines = _build_tool_context(self._config.get("tools", {}))
        if tool_context_lines:
            system_prompt = system_prompt + "\n\n" + tool_context_lines

        max_iterations = self._config.get("max_iterations", 10)

        template_ctx = {**context.variables, **context.input_data}
        try:
            if prompt_template:
                prompt = render_template(prompt_template, template_ctx)
            else:
                prompt = str(
                    context.input_data.get("message", "")
                    or context.input_data.get("prompt", "")
                    or context.input_data.get("query", "")
                )
        except Exception as exc:
            return self._failure(f"Prompt template error: {exc}")

        if not prompt:
            logger.warning("[AGENT] No prompt for node %s", self._node_id)
            return self._failure(
                "No prompt available. Set a task description or "
                "provide a 'message' input."
            )

        # Resolve memory: upstream MemoryNode or embedded sub-node config
        memory_history, memory_store = self._resolve_memory(context)

        # Compact memory if the store supports it
        if memory_store is not None and hasattr(memory_store, "prepare"):
            await memory_store.prepare()
            memory_history = memory_store.get_messages()

        logger.info(
            "[AGENT] Calling LLM: prompt_len=%d, system_prompt_len=%d, "
            "max_iter=%d, memory_msgs=%d",
            len(prompt),
            len(system_prompt),
            max_iterations,
            len(memory_history) if memory_history else 0,
        )
        try:
            agent = LLMAgent(
                agent_id=f"agent_node_{self._node_id}",
                llm_provider=provider,
                tool_registry=registry if len(registry) > 0 else None,
                system_prompt=system_prompt,
                max_iterations=max_iterations,
            )

            message = Message(
                topic="workflow",
                payload={"content": prompt, **context.input_data},
            )
            result = await agent.process(message, history=memory_history)
        except Exception as exc:
            logger.error(
                "[AGENT] node %s EXCEPTION: %s: %s",
                self._node_id,
                type(exc).__name__,
                exc,
                exc_info=True,
            )
            return self._failure(f"Agent execution failed: {exc}")

        logger.info(
            "[AGENT] node %s result: success=%s, errors=%s",
            self._node_id,
            result.success,
            result.errors[:2] if result.errors else [],
        )
        if not result.success:
            errors = "; ".join(result.errors) if result.errors else "Unknown error"
            return self._failure(f"Agent LLM call failed: {errors}")

        response = result.metadata.get("response", "")
        tool_results = result.metadata.get("tool_results", [])

        # Write exchange back to memory store (if available)
        if memory_store is not None:
            try:
                memory_store.add_messages(
                    [
                        {"role": "user", "content": prompt},
                        {"role": "assistant", "content": response},
                    ]
                )
            except Exception as exc:
                logger.error(
                    "AgentNode %s memory writeback failed: %s",
                    self._node_id,
                    exc,
                )

        return self._success(
            {
                "response": response,
                "tool_results": tool_results,
                "iterations": result.metadata.get("iterations", 0),
            }
        )

    def _resolve_memory(
        self,
        context: NodeContext,
    ) -> tuple[list[dict[str, str]] | None, Any]:
        """Resolve memory from upstream node or embedded sub-node config.

        Args:
            context: Node execution context.

        Returns:
            Tuple of (history, store). Both are None if no memory is
            configured.
        """
        # Option 1: upstream MemoryNode provided history via DAG edge
        upstream_history = context.input_data.get("__memory_history__")
        if upstream_history is not None:
            memory_node_id = context.input_data.get("__memory_node_id__")
            store = None
            if memory_node_id:
                stores = context.variables.get("__memory_stores__", {})
                store = stores.get(memory_node_id)
            return upstream_history, store

        # Option 2: memory config merged as sub-node
        memory_config = self._config.get("memory")
        if not memory_config:
            return None, None

        from pygubernator.workflow.nodes._memory import (
            resolve_embedded_memory,
        )

        session_id = context.variables.get("__session_id__")
        try:
            return resolve_embedded_memory(
                node_id=self._node_id,
                memory_config=memory_config,
                session_id=session_id,
            )
        except Exception as exc:
            logger.error(
                "AgentNode %s embedded memory init failed: %s",
                self._node_id,
                exc,
            )
            return None, None

    def _resolve_provider(self) -> tuple[Any | None, str | None]:
        """Create an LLM provider from config fields.

        Returns:
            Tuple of (provider, error_message). On success error_message is None.
        """
        model = self._config.get("model_name") or self._config.get("model")
        if not model:
            return None, "No model configured. Attach a chat model sub-node."

        try:
            from pygubernator.llm._factory import create_provider

            rt = self._config.get("request_timeout", self._config.get("timeout"))
            extra: dict[str, Any] = {}
            if rt is not None:
                extra["request_timeout"] = float(rt)
            provider = create_provider(
                model=model,
                api_base=(self._config.get("base_url") or self._config.get("api_base")),
                api_key=self._config.get("api_key"),
                max_tokens=self._config.get("max_tokens", 4096),
                temperature=self._config.get("temperature", 0.0),
                **extra,
            )
            return provider, None
        except ImportError as exc:
            msg = f"Missing dependency for model '{model}': {exc}"
            logger.error(msg)
            return None, msg
        except Exception as exc:
            msg = f"Failed to create provider for model '{model}': {exc}"
            logger.error(msg, exc_info=True)
            return None, msg

    def _load_tools(self) -> tuple[ToolRegistry, list[str]]:
        """Load tools from config's tools dict.

        Returns:
            Tuple of (registry, errors). Errors list any tools
            that failed to load so the caller can surface them.
        """
        registry = ToolRegistry()
        errors: list[str] = []
        tools_config = self._config.get("tools", {})
        if not isinstance(tools_config, dict):
            return registry, errors

        for tool_name, tool_spec in tools_config.items():
            if not isinstance(tool_spec, dict):
                errors.append(f"Tool '{tool_name}': invalid spec")
                continue

            result = self._load_single_tool(
                tool_name,
                tool_spec,
                registry,
            )
            if isinstance(result, str):
                errors.append(result)

        return registry, errors

    def _load_single_tool(
        self,
        tool_name: str,
        tool_spec: dict[str, Any],
        registry: ToolRegistry,
    ) -> str | bool:
        """Load one tool into the registry.

        Returns:
            True on success, or an error message string.
        """
        # Factory mode
        factory_module = tool_spec.get("factory_module", "")
        factory_function = tool_spec.get("factory_function", "")
        if factory_module and factory_function:
            return self._load_factory_tool(
                tool_name,
                tool_spec,
                factory_module,
                factory_function,
                registry,
            )

        # Direct module/function mode
        module_path = tool_spec.get("module", "")
        func_name = tool_spec.get("function", "")
        if module_path and func_name:
            return self._load_direct_tool(
                tool_name,
                module_path,
                func_name,
                registry,
            )

        msg = (
            f"Tool '{tool_name}': missing module/function "
            f"or factory_module/factory_function"
        )
        logger.warning(msg)
        return msg

    def _load_factory_tool(
        self,
        tool_name: str,
        tool_spec: dict[str, Any],
        factory_module: str,
        factory_function: str,
        registry: ToolRegistry,
    ) -> str | bool:
        """Load tools from a factory function."""
        factory_args = tool_spec.get("factory_args", {})
        if not isinstance(factory_args, dict):
            return f"Tool '{tool_name}': non-dict factory_args"
        try:
            module = importlib.import_module(factory_module)
            factory = getattr(module, factory_function)
            produced = factory(**factory_args)
        except ImportError as exc:
            msg = (
                f"Tool '{tool_name}': missing dependency — "
                f"{exc}. Install the required package."
            )
            logger.error(msg)
            return msg
        except Exception as exc:
            msg = (
                f"Tool '{tool_name}': factory "
                f"{factory_module}.{factory_function} failed: "
                f"{exc}"
            )
            logger.error(msg)
            return msg

        if not isinstance(produced, list):
            return f"Tool '{tool_name}': factory did not return a list"

        count = 0
        for tool_obj in produced:
            if (
                hasattr(tool_obj, "name")
                and hasattr(tool_obj, "execute")
                and hasattr(tool_obj, "parameters_schema")
            ):
                registry.register(tool_obj)
                count += 1

        logger.info(
            "Loaded %d tool(s) from '%s' via %s.%s",
            count,
            tool_name,
            factory_module,
            factory_function,
        )
        return True

    def _load_direct_tool(
        self,
        tool_name: str,
        module_path: str,
        func_name: str,
        registry: ToolRegistry,
    ) -> str | bool:
        """Load a single tool function directly."""
        try:
            module = importlib.import_module(module_path)
            func = getattr(module, func_name)
            registry.register(func)
            logger.debug(
                "Loaded tool '%s' from %s.%s",
                tool_name,
                module_path,
                func_name,
            )
            return True
        except ImportError as exc:
            msg = (
                f"Tool '{tool_name}': missing dependency — "
                f"{exc}. Install the required package."
            )
            logger.error(msg)
            return msg
        except (AttributeError, Exception) as exc:
            msg = f"Tool '{tool_name}': {exc}"
            logger.error(msg)
            return msg


def _build_tool_context(tools_config: dict[str, Any]) -> str:
    """Build system prompt additions from tool context fields."""
    lines: list[str] = []
    for tool_name, tool_spec in tools_config.items():
        if not isinstance(tool_spec, dict):
            continue
        context = tool_spec.get("context")
        if not context or not isinstance(context, dict):
            continue
        parts = [f"For the {tool_name} tools:"]
        for key, value in context.items():
            label = key.replace("_", " ").title()
            parts.append(f"  - {label}: {value}")
        lines.append("\n".join(parts))
    if not lines:
        return ""
    return "## Tool Context\n\n" + "\n\n".join(lines)


class AgentNodeFactory:
    """Factory for creating AgentNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> AgentNode:
        """Create an AgentNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured AgentNode instance.
        """
        return AgentNode(node_id=node_id, config=config)
