"""HTTP request workflow node."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._templates import render_config_value
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

try:
    import httpx

    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False

_ALLOWED_METHODS = frozenset({"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"})
_DEFAULT_TIMEOUT = 30.0


class HttpNode(AbstractNode):
    """Makes an HTTP request and returns the response.

    Config:
        url: Request URL (required, supports Jinja2 templates).
        method: HTTP method (default: GET).
        headers: Request headers dict (optional).
        body: Request body dict (optional, for POST/PUT/PATCH).
        timeout: Request timeout in seconds (default: 30).
    """

    node_type = "http"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Execute the HTTP request.

        Args:
            context: Execution context with input data.

        Returns:
            Result with response status, headers, and body.
        """
        if not _HAS_HTTPX:
            return self._failure(
                "httpx is required for HTTP nodes. "
                "Install with: pip install pygubernator[workflow]"
            )

        template_ctx = {**context.variables, **context.input_data}
        config = render_config_value(self._config, template_ctx)

        url = config.get("url", "")
        if not url:
            return self._failure("No URL configured")

        method = str(config.get("method", "GET")).upper()
        if method not in _ALLOWED_METHODS:
            return self._failure(f"Unsupported HTTP method: {method}")

        headers = config.get("headers", {})
        body = config.get("body")
        timeout = float(config.get("timeout", _DEFAULT_TIMEOUT))

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    json=body if body else None,
                )
        except httpx.TimeoutException:
            return self._failure(f"HTTP request timed out after {timeout}s")
        except Exception as exc:
            logger.error("HTTP node %s failed: %s", self._node_id, exc)
            return self._failure(f"HTTP request failed: {exc}")

        try:
            response_body = response.json()
        except Exception:
            response_body = response.text

        return self._success(
            {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "body": response_body,
            }
        )


class HttpNodeFactory:
    """Factory for creating HttpNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> HttpNode:
        """Create an HttpNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured HttpNode instance.
        """
        return HttpNode(node_id=node_id, config=config)
