"""Workflow input passthrough node."""

from __future__ import annotations

from typing import Any

from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode


class InputNode(AbstractNode):
    """Passes workflow input data through as node output.

    This is the entry point of a workflow. It forwards the input data
    unchanged, optionally selecting specific keys.

    Config:
        keys: Optional list of input keys to select. If empty, all
            input data is passed through.
    """

    node_type = "input"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Pass through input data.

        Args:
            context: Execution context with input data.

        Returns:
            Result containing the input data.
        """
        keys = self._config.get("keys", [])

        if keys:
            output = {k: context.input_data[k] for k in keys if k in context.input_data}
        else:
            output = dict(context.input_data)

        return self._success(output)


class InputNodeFactory:
    """Factory for creating InputNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> InputNode:
        """Create an InputNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured InputNode instance.
        """
        return InputNode(node_id=node_id, config=config)
