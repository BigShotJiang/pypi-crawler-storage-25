"""Vector-database-backed memory stores for conversation history."""

from __future__ import annotations

import hashlib
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Pinecone
# ---------------------------------------------------------------------------

try:
    from pinecone import Pinecone  # type: ignore[import-untyped]

    _HAS_PINECONE = True
except ImportError:
    _HAS_PINECONE = False


class PineconeMemoryStore:
    """Memory store backed by Pinecone.

    Args:
        api_key: Pinecone API key.
        index_name: Name of the Pinecone index.
        namespace: Optional namespace for isolation.
        dimension: Embedding vector dimension.
    """

    def __init__(
        self,
        api_key: str,
        index_name: str,
        namespace: str = "",
        dimension: int = 1536,
    ) -> None:
        if not _HAS_PINECONE:
            msg = (
                "pinecone is required for Pinecone memory. "
                "Install with: pip install pinecone"
            )
            raise ImportError(msg)
        self._pc = Pinecone(api_key=api_key)
        self._index = self._pc.Index(index_name)
        self._namespace = namespace or ""
        self._dimension = dimension
        self._messages: list[dict[str, str]] = []
        self._counter = 0

    def get_messages(self) -> list[dict[str, str]]:
        """Return stored messages.

        Returns:
            List of message dicts.
        """
        return list(self._messages)

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Upsert messages into Pinecone and the local cache.

        Args:
            messages: Messages to add.
        """
        vectors = []
        for msg in messages:
            self._counter += 1
            vid = hashlib.sha256(
                f"{self._counter}:{msg['role']}:{msg['content']}".encode()
            ).hexdigest()[:32]
            # Zero-vector placeholder; callers should swap in real
            # embeddings via a pre-processing step.
            vectors.append(
                {
                    "id": vid,
                    "values": [0.0] * self._dimension,
                    "metadata": {"role": msg["role"], "content": msg["content"]},
                }
            )
        if vectors:
            self._index.upsert(vectors=vectors, namespace=self._namespace)
        self._messages.extend(messages)


def create_pinecone_store(config: dict[str, Any]) -> PineconeMemoryStore:
    """Create a PineconeMemoryStore from node config.

    Args:
        config: Node configuration dict.

    Returns:
        Configured PineconeMemoryStore.
    """
    api_key = config.get("api_key") or os.environ.get("PINECONE_API_KEY", "")
    if not api_key:
        msg = "Pinecone api_key is required."
        raise ValueError(msg)
    index_name = config.get("index_name", "")
    if not index_name:
        msg = "Pinecone index_name is required."
        raise ValueError(msg)
    return PineconeMemoryStore(
        api_key=api_key,
        index_name=index_name,
        namespace=config.get("namespace", ""),
        dimension=config.get("dimension", 1536),
    )


# ---------------------------------------------------------------------------
# Chroma
# ---------------------------------------------------------------------------

try:
    import chromadb  # type: ignore[import-untyped]

    _HAS_CHROMA = True
except ImportError:
    _HAS_CHROMA = False


class ChromaMemoryStore:
    """Memory store backed by Chroma.

    Args:
        host: Chroma server host.
        port: Chroma server port.
        collection_name: Collection name.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 8000,
        collection_name: str = "messages",
    ) -> None:
        if not _HAS_CHROMA:
            msg = (
                "chromadb is required for Chroma memory. "
                "Install with: pip install chromadb"
            )
            raise ImportError(msg)
        self._client = chromadb.HttpClient(host=host, port=port)
        self._collection = self._client.get_or_create_collection(name=collection_name)
        self._messages: list[dict[str, str]] = []
        self._counter = 0

    def get_messages(self) -> list[dict[str, str]]:
        """Return stored messages.

        Returns:
            List of message dicts.
        """
        return list(self._messages)

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Add messages to Chroma and the local cache.

        Args:
            messages: Messages to add.
        """
        ids = []
        documents = []
        metadatas = []
        for msg in messages:
            self._counter += 1
            ids.append(f"msg_{self._counter}")
            documents.append(msg["content"])
            metadatas.append({"role": msg["role"]})
        if ids:
            self._collection.add(ids=ids, documents=documents, metadatas=metadatas)
        self._messages.extend(messages)


def create_chroma_store(config: dict[str, Any]) -> ChromaMemoryStore:
    """Create a ChromaMemoryStore from node config.

    Args:
        config: Node configuration dict.

    Returns:
        Configured ChromaMemoryStore.
    """
    return ChromaMemoryStore(
        host=config.get("host", "localhost"),
        port=config.get("port", 8000),
        collection_name=config.get("collection_name", "messages"),
    )


# ---------------------------------------------------------------------------
# Qdrant
# ---------------------------------------------------------------------------

try:
    from qdrant_client import QdrantClient  # type: ignore[import-untyped]
    from qdrant_client.models import (  # type: ignore[import-untyped]
        Distance,
        PointStruct,
        VectorParams,
    )

    _HAS_QDRANT = True
except ImportError:
    _HAS_QDRANT = False


class QdrantMemoryStore:
    """Memory store backed by Qdrant.

    Args:
        url: Qdrant server URL.
        collection_name: Collection name.
        api_key: Optional API key for Qdrant Cloud.
        dimension: Embedding vector dimension.
    """

    def __init__(
        self,
        url: str = "http://localhost:6333",
        collection_name: str = "messages",
        api_key: str = "",
        dimension: int = 1536,
    ) -> None:
        if not _HAS_QDRANT:
            msg = (
                "qdrant-client is required for Qdrant memory. "
                "Install with: pip install qdrant-client"
            )
            raise ImportError(msg)
        self._client = QdrantClient(url=url, api_key=api_key or None)
        self._collection = collection_name
        self._dimension = dimension
        self._messages: list[dict[str, str]] = []
        self._counter = 0
        self._ensure_collection()

    def _ensure_collection(self) -> None:
        """Create collection if it does not exist."""
        collections = [c.name for c in self._client.get_collections().collections]
        if self._collection not in collections:
            self._client.create_collection(
                collection_name=self._collection,
                vectors_config=VectorParams(
                    size=self._dimension, distance=Distance.COSINE
                ),
            )

    def get_messages(self) -> list[dict[str, str]]:
        """Return stored messages.

        Returns:
            List of message dicts.
        """
        return list(self._messages)

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Upsert messages into Qdrant and the local cache.

        Args:
            messages: Messages to add.
        """
        points = []
        for msg in messages:
            self._counter += 1
            points.append(
                PointStruct(
                    id=self._counter,
                    vector=[0.0] * self._dimension,
                    payload={
                        "role": msg["role"],
                        "content": msg["content"],
                    },
                )
            )
        if points:
            self._client.upsert(collection_name=self._collection, points=points)
        self._messages.extend(messages)


def create_qdrant_store(config: dict[str, Any]) -> QdrantMemoryStore:
    """Create a QdrantMemoryStore from node config.

    Args:
        config: Node configuration dict.

    Returns:
        Configured QdrantMemoryStore.
    """
    return QdrantMemoryStore(
        url=config.get("url", "http://localhost:6333"),
        collection_name=config.get("collection_name", "messages"),
        api_key=config.get("api_key", ""),
        dimension=config.get("dimension", 1536),
    )


# ---------------------------------------------------------------------------
# Weaviate
# ---------------------------------------------------------------------------

try:
    import weaviate  # type: ignore[import-untyped]

    _HAS_WEAVIATE = True
except ImportError:
    _HAS_WEAVIATE = False


class WeaviateMemoryStore:
    """Memory store backed by Weaviate.

    Args:
        url: Weaviate server URL.
        class_name: Weaviate class for messages.
        api_key: Optional API key for Weaviate Cloud.
    """

    def __init__(
        self,
        url: str = "http://localhost:8080",
        class_name: str = "MemoryMessage",
        api_key: str = "",
    ) -> None:
        if not _HAS_WEAVIATE:
            msg = (
                "weaviate-client is required for Weaviate memory. "
                "Install with: pip install weaviate-client"
            )
            raise ImportError(msg)
        auth = weaviate.auth.AuthApiKey(api_key=api_key) if api_key else None
        self._client = weaviate.Client(url=url, auth_client_secret=auth)
        self._class_name = class_name
        self._messages: list[dict[str, str]] = []
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        """Create the Weaviate class if it does not exist."""
        if not self._client.schema.contains({"class": self._class_name}):
            self._client.schema.create_class(
                {
                    "class": self._class_name,
                    "properties": [
                        {"name": "role", "dataType": ["text"]},
                        {"name": "content", "dataType": ["text"]},
                    ],
                }
            )

    def get_messages(self) -> list[dict[str, str]]:
        """Return stored messages.

        Returns:
            List of message dicts.
        """
        return list(self._messages)

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Add messages to Weaviate and the local cache.

        Args:
            messages: Messages to add.
        """
        for msg in messages:
            self._client.data_object.create(
                data_object={
                    "role": msg["role"],
                    "content": msg["content"],
                },
                class_name=self._class_name,
            )
        self._messages.extend(messages)


def create_weaviate_store(config: dict[str, Any]) -> WeaviateMemoryStore:
    """Create a WeaviateMemoryStore from node config.

    Args:
        config: Node configuration dict.

    Returns:
        Configured WeaviateMemoryStore.
    """
    return WeaviateMemoryStore(
        url=config.get("url", "http://localhost:8080"),
        class_name=config.get("class_name", "MemoryMessage"),
        api_key=config.get("api_key", ""),
    )


# ---------------------------------------------------------------------------
# Milvus
# ---------------------------------------------------------------------------

try:
    from pymilvus import (  # type: ignore[import-untyped]
        CollectionSchema,
        DataType,
        FieldSchema,
        MilvusClient,
    )

    _HAS_MILVUS = True
except ImportError:
    _HAS_MILVUS = False


class MilvusMemoryStore:
    """Memory store backed by Milvus / Zilliz Cloud.

    Args:
        uri: Milvus server URI.
        collection_name: Collection for storing messages.
        token: Optional authentication token.
        dimension: Embedding vector dimension.
    """

    def __init__(
        self,
        uri: str = "http://localhost:19530",
        collection_name: str = "messages",
        token: str = "",
        dimension: int = 1536,
    ) -> None:
        if not _HAS_MILVUS:
            msg = (
                "pymilvus is required for Milvus memory. "
                "Install with: pip install pymilvus"
            )
            raise ImportError(msg)
        self._client = MilvusClient(uri=uri, token=token or None)
        self._collection = collection_name
        self._dimension = dimension
        self._messages: list[dict[str, str]] = []
        self._counter = 0
        self._ensure_collection()

    def _ensure_collection(self) -> None:
        """Create collection if it does not exist."""
        if not self._client.has_collection(self._collection):
            fields = [
                FieldSchema("id", DataType.INT64, is_primary=True),
                FieldSchema("role", DataType.VARCHAR, max_length=32),
                FieldSchema("content", DataType.VARCHAR, max_length=65535),
                FieldSchema("vector", DataType.FLOAT_VECTOR, dim=self._dimension),
            ]
            schema = CollectionSchema(fields=fields)
            self._client.create_collection(
                collection_name=self._collection, schema=schema
            )

    def get_messages(self) -> list[dict[str, str]]:
        """Return stored messages.

        Returns:
            List of message dicts.
        """
        return list(self._messages)

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Insert messages into Milvus and the local cache.

        Args:
            messages: Messages to add.
        """
        data = []
        for msg in messages:
            self._counter += 1
            data.append(
                {
                    "id": self._counter,
                    "role": msg["role"],
                    "content": msg["content"],
                    "vector": [0.0] * self._dimension,
                }
            )
        if data:
            self._client.insert(collection_name=self._collection, data=data)
        self._messages.extend(messages)


def create_milvus_store(config: dict[str, Any]) -> MilvusMemoryStore:
    """Create a MilvusMemoryStore from node config.

    Args:
        config: Node configuration dict.

    Returns:
        Configured MilvusMemoryStore.
    """
    return MilvusMemoryStore(
        uri=config.get("uri", "http://localhost:19530"),
        collection_name=config.get("collection_name", "messages"),
        token=config.get("token", ""),
        dimension=config.get("dimension", 1536),
    )
