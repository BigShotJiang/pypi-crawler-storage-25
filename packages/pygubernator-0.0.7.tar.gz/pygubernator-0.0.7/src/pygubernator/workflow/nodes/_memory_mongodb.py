"""MongoDB-backed memory store for conversation history."""

from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

try:
    import pymongo  # type: ignore[import-untyped]

    _HAS_PYMONGO = True
except ImportError:
    _HAS_PYMONGO = False


class MongoMemoryStore:
    """Persistent memory store backed by MongoDB.

    Args:
        connection_string: MongoDB URI.
        database_name: Database to use.
        collection_name: Collection for storing messages.
        session_id: Optional session ID to scope messages.
    """

    def __init__(
        self,
        connection_string: str,
        database_name: str = "memory",
        collection_name: str = "messages",
        session_id: str | None = None,
    ) -> None:
        if not _HAS_PYMONGO:
            msg = (
                "pymongo is required for MongoDB memory. "
                "Install with: pip install pymongo"
            )
            raise ImportError(msg)
        self._client: pymongo.MongoClient = pymongo.MongoClient(  # type: ignore[type-arg]
            connection_string
        )
        self._collection = self._client[database_name][collection_name]
        self._session_id = session_id or "default"
        self._collection.create_index("session_id")

    def get_messages(self) -> list[dict[str, str]]:
        """Return stored messages for this session ordered by insertion.

        Returns:
            List of message dicts.
        """
        docs = self._collection.find(
            {"session_id": self._session_id},
            {"_id": 0, "role": 1, "content": 1},
        ).sort("_id", pymongo.ASCENDING)
        return [{"role": d["role"], "content": d["content"]} for d in docs]

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Persist messages to MongoDB.

        Args:
            messages: Messages to add.
        """
        if messages:
            self._collection.insert_many(
                [
                    {
                        "role": m["role"],
                        "content": m["content"],
                        "session_id": self._session_id,
                    }
                    for m in messages
                ]
            )


def create_mongo_store(config: dict[str, Any]) -> MongoMemoryStore:
    """Create a MongoMemoryStore from node config.

    Args:
        config: Node configuration dict.

    Returns:
        Configured MongoMemoryStore.
    """
    uri = config.get("connection_string") or os.environ.get("MEMORY_MONGO_URI", "")
    if not uri:
        msg = (
            "MongoDB connection_string is required. "
            "Set it in the node config or via MEMORY_MONGO_URI."
        )
        raise ValueError(msg)
    return MongoMemoryStore(
        connection_string=uri,
        database_name=config.get("database_name", "memory"),
        collection_name=config.get("collection_name", "messages"),
        session_id=config.get("session_id"),
    )
