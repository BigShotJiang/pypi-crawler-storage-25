"""Multi-output branching workflow node."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._expressions import SafeExpressionEvaluator
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)


class RouterNode(AbstractNode):
    """Evaluates routes in order, first match sets output_handle.

    Config:
        routes: List of dicts with "condition" (expression) and "handle".
        default_handle: Fallback handle if no route matches (default: "default").
    """

    node_type = "router"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Evaluate routes and select the first matching handle.

        Args:
            context: Execution context with input data.

        Returns:
            Result with output_handle set to the matched route handle.
        """
        routes = self._config.get("routes", [])
        default_handle = self._config.get("default_handle", "default")

        if not routes:
            return self._failure("No routes configured")

        namespace = {**context.variables, **context.input_data}
        evaluator = SafeExpressionEvaluator(namespace)

        for route in routes:
            condition = route.get("condition", "")
            handle = route.get("handle", "default")

            if not condition:
                continue

            try:
                if evaluator.evaluate_bool(condition):
                    return self._success(
                        dict(context.input_data),
                        output_handle=handle,
                    )
            except Exception as exc:
                logger.error(
                    "Router node %s route evaluation failed: %s",
                    self._node_id,
                    exc,
                )
                return self._failure(f"Route condition error: {exc}")

        return self._success(
            dict(context.input_data),
            output_handle=default_handle,
        )


class RouterNodeFactory:
    """Factory for creating RouterNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> RouterNode:
        """Create a RouterNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured RouterNode instance.
        """
        return RouterNode(node_id=node_id, config=config)
