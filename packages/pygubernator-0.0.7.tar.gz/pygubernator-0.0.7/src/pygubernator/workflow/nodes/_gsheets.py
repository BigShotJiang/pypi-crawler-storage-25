"""Google Sheets workflow node (service account via env)."""

from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Any

from pygubernator.workflow._templates import render_config_value
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

try:
    from pygubernator.tools.gsheets_tools import (
        _HAS_GSHEETS,
        create_sheets_client,
    )
except ImportError:
    _HAS_GSHEETS = False
    create_sheets_client = None  # type: ignore[misc,assignment]

_DEFAULT_CREDS_ENV = "PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH"

_OPERATIONS = frozenset(
    {
        "create_spreadsheet",
        "read_range",
        "write_range",
        "append_rows",
        "create_sheet",
        "delete_sheet",
        "rename_sheet",
        "format_cells",
    }
)


def _parse_values(raw: Any) -> list[list[Any]]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return raw
    if isinstance(raw, str) and raw.strip():
        return json.loads(raw)
    return []


def _as_int(value: Any, field: str) -> int:
    if value is None or value == "":
        raise ValueError(f"{field} is required")
    return int(value)


def _optional_color(raw: Any) -> dict[str, float] | None:
    if raw is None or raw == "":
        return None
    if isinstance(raw, dict):
        return raw
    return json.loads(raw) if isinstance(raw, str) else None


class GSheetsNode(AbstractNode):
    """Execute one Google Sheets operation using a service account JSON path from env.

    Config:
        operation: One of the supported operation names (required).
        credentials_env_var: Env var for credentials path (default:
            PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH).

    Operation-specific keys (can use ``{{ expr }}`` templates; upstream input
    fills missing keys):

        create_spreadsheet: title
        read_range: spreadsheet_id, range_a1 (or ``range``)
        write_range: spreadsheet_id, range_a1, values (list or JSON string)
        append_rows: spreadsheet_id, range_a1, values
        create_sheet: spreadsheet_id, sheet_title
        delete_sheet: spreadsheet_id, sheet_id
        rename_sheet: spreadsheet_id, sheet_id, new_title
        format_cells: spreadsheet_id, sheet_id, start_row, end_row,
            start_col, end_col; optional bold, border_style, fg_color, bg_color
            (last two as dict or JSON object string)
    """

    node_type = "gsheets"

    async def execute(self, context: NodeContext) -> NodeResult:
        if not _HAS_GSHEETS or create_sheets_client is None:
            return self._failure(
                "Google Sheets dependencies not available. "
                "Install with: pip install pygubernator[workflow]"
            )

        template_ctx = {**context.variables, **context.input_data}
        try:
            config = render_config_value(self._config, template_ctx)
        except Exception as exc:
            return self._failure(f"Config template error: {exc}")

        merged: dict[str, Any] = {**context.input_data, **config}
        operation = str(merged.get("operation", "")).strip()
        if not operation:
            return self._failure("gsheets node requires 'operation' in config")
        if operation not in _OPERATIONS:
            return self._failure(f"Unknown gsheets operation: {operation}")

        cred_env = str(
            merged.get("credentials_env_var", _DEFAULT_CREDS_ENV) or _DEFAULT_CREDS_ENV
        ).strip()
        cred_path = os.environ.get(cred_env, "").strip()
        if not cred_path:
            return self._failure(
                f"Set {cred_env} to a Google service account JSON key path",
            )

        try:
            client = create_sheets_client(cred_path)
        except Exception as exc:
            logger.exception("GSheets node %s failed to build client", self._node_id)
            return self._failure(f"Sheets client error: {exc}")

        def run_sync() -> dict[str, Any]:
            return self._dispatch_operation(client, operation, merged)

        try:
            result = await asyncio.to_thread(run_sync)
        except ValueError as exc:
            return self._failure(str(exc))
        except Exception as exc:
            logger.exception("GSheets node %s operation failed", self._node_id)
            return self._failure(f"Sheets API error: {exc}")

        return self._success(result)

    def _dispatch_operation(
        self,
        client: Any,
        operation: str,
        m: dict[str, Any],
    ) -> dict[str, Any]:
        if operation == "create_spreadsheet":
            title = str(m.get("title", "")).strip()
            if not title:
                raise ValueError("title is required for create_spreadsheet")
            return client.create_spreadsheet(title)

        if operation == "read_range":
            sid = str(m.get("spreadsheet_id", "")).strip()
            range_a1 = str(
                m.get("range_a1", m.get("range", "")),
            ).strip()
            if not sid or not range_a1:
                raise ValueError(
                    "spreadsheet_id and range_a1 (or range) required for read_range",
                )
            values = client.read_range(sid, range_a1)
            return {"values": values, "row_count": len(values)}

        if operation == "write_range":
            sid = str(m.get("spreadsheet_id", "")).strip()
            range_a1 = str(
                m.get("range_a1", m.get("range", "")),
            ).strip()
            values = _parse_values(m.get("values", m.get("values_json")))
            if not sid or not range_a1:
                raise ValueError(
                    "spreadsheet_id and range_a1 required for write_range",
                )
            return client.write_range(sid, range_a1, values)

        if operation == "append_rows":
            sid = str(m.get("spreadsheet_id", "")).strip()
            range_a1 = str(
                m.get("range_a1", m.get("range", "")),
            ).strip()
            values = _parse_values(m.get("values", m.get("values_json")))
            if not sid or not range_a1:
                raise ValueError(
                    "spreadsheet_id and range_a1 required for append_rows",
                )
            return client.append_rows(sid, range_a1, values)

        if operation == "create_sheet":
            sid = str(m.get("spreadsheet_id", "")).strip()
            sheet_title = str(m.get("sheet_title", m.get("title", ""))).strip()
            if not sid or not sheet_title:
                raise ValueError(
                    "spreadsheet_id and sheet_title required for create_sheet",
                )
            return client.create_sheet(sid, sheet_title)

        if operation == "delete_sheet":
            sid = str(m.get("spreadsheet_id", "")).strip()
            sheet_id = _as_int(m.get("sheet_id"), "sheet_id")
            if not sid:
                raise ValueError("spreadsheet_id required for delete_sheet")
            return client.delete_sheet(sid, sheet_id)

        if operation == "rename_sheet":
            sid = str(m.get("spreadsheet_id", "")).strip()
            sheet_id = _as_int(m.get("sheet_id"), "sheet_id")
            new_title = str(m.get("new_title", "")).strip()
            if not sid or not new_title:
                raise ValueError(
                    "spreadsheet_id and new_title required for rename_sheet",
                )
            return client.rename_sheet(sid, sheet_id, new_title)

        if operation == "format_cells":
            sid = str(m.get("spreadsheet_id", "")).strip()
            sheet_id = _as_int(m.get("sheet_id"), "sheet_id")
            start_row = _as_int(m.get("start_row"), "start_row")
            end_row = _as_int(m.get("end_row"), "end_row")
            start_col = _as_int(m.get("start_col"), "start_col")
            end_col = _as_int(m.get("end_col"), "end_col")
            if not sid:
                raise ValueError("spreadsheet_id required for format_cells")
            bold = m.get("bold")
            if isinstance(bold, str):
                bold = bold.lower() in ("1", "true", "yes")
            border = m.get("border_style")
            border_str = str(border).strip() if border else None
            return client.format_cells(
                sid,
                sheet_id,
                start_row,
                end_row,
                start_col,
                end_col,
                bold=bold if isinstance(bold, bool) else None,
                fg_color=_optional_color(m.get("fg_color")),
                bg_color=_optional_color(m.get("bg_color")),
                border_style=border_str or None,
            )

        raise ValueError(f"Unhandled operation {operation}")


class GSheetsNodeFactory:
    """Factory for GSheetsNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> GSheetsNode:
        return GSheetsNode(node_id=node_id, config=config)
