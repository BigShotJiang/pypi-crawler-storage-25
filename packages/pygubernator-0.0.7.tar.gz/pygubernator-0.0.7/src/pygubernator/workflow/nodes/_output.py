"""Workflow output collector node."""

from __future__ import annotations

from typing import Any

from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode


class OutputNode(AbstractNode):
    """Collects workflow output from upstream nodes.

    This is the exit point of a workflow. It collects input data
    into the workflow's final output.

    Config:
        keys: Optional list of keys to include in output. If empty,
            all input data is collected.
    """

    node_type = "output"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Collect output data.

        Args:
            context: Execution context with input data.

        Returns:
            Result containing the collected output.
        """
        keys = self._config.get("keys", [])

        if keys:
            output = {k: context.input_data[k] for k in keys if k in context.input_data}
        else:
            output = dict(context.input_data)

        return self._success(output)


class OutputNodeFactory:
    """Factory for creating OutputNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> OutputNode:
        """Create an OutputNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured OutputNode instance.
        """
        return OutputNode(node_id=node_id, config=config)
