"""Workflow node for executing Python code with package imports.

Unlike the sandboxed ``code`` node, this node provides full Python
builtins and configurable import allowlisting via ``_PythonExecutor``.
Users can import installed packages (e.g. pycatalyst, pystator) and
write arbitrary data-processing logic.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from pygubernator.tools.python_tools import _PythonExecutor
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT = 30
_MAX_CODE_LENGTH = 50_000


class PythonExecNode(AbstractNode):
    """Executes Python code with full builtins and optional import control.

    The code has access to ``input_data`` and ``variables`` dicts
    from upstream nodes.  Assign output to a ``result`` variable.

    Config:
        code: Python source code string (required).
        allowed_imports: List of allowed top-level module names.
            ``None`` or omitted means unrestricted.
        timeout: Maximum execution time in seconds (default 30).
    """

    node_type = "python_exec"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Execute the configured Python code.

        Args:
            context: Execution context with input data and variables.

        Returns:
            Result containing the ``result`` variable and any
            user-assigned variables from the code.
        """
        code_str = self._config.get("code", "")
        if not code_str:
            return self._failure("No code configured")

        if len(code_str) > _MAX_CODE_LENGTH:
            return self._failure(f"Code exceeds max length of {_MAX_CODE_LENGTH}")

        allowed_imports = self._config.get("allowed_imports")
        timeout = self._config.get("timeout", _DEFAULT_TIMEOUT)

        executor = _PythonExecutor(
            allowed_imports=allowed_imports,
            timeout=timeout,
        )

        variables = {
            "input_data": dict(context.input_data),
            "variables": dict(context.variables),
        }

        try:
            exec_result = await asyncio.wait_for(
                asyncio.to_thread(executor.exec_code, code_str, variables),
                timeout=timeout,
            )
        except TimeoutError:
            logger.error(
                "PythonExec node %s timed out after %ds",
                self._node_id,
                timeout,
            )
            return self._failure(f"Code execution timed out after {timeout}s")
        except ImportError as exc:
            logger.error("PythonExec node %s import error: %s", self._node_id, exc)
            return self._failure(f"Import error: {exc}")
        except Exception as exc:
            logger.error("PythonExec node %s failed: %s", self._node_id, exc)
            return self._failure(f"Code execution failed: {exc}")

        output: dict[str, Any] = {}
        if exec_result.get("result") is not None:
            output["result"] = exec_result["result"]
        user_vars = exec_result.get("variables", {})
        for key, value in user_vars.items():
            if key not in ("input_data", "variables"):
                output[key] = value

        return self._success(output)


class PythonExecNodeFactory:
    """Factory for creating PythonExecNode instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> PythonExecNode:
        """Create a PythonExecNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration with ``code`` key.

        Returns:
            Configured PythonExecNode instance.
        """
        return PythonExecNode(node_id=node_id, config=config)
