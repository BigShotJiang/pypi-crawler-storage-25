"""Workflow node that pauses execution for human approval."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.workflow._templates import render_template
from pygubernator.workflow._types import NodeContext, NodeResult, NodeStatus
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)


class ApprovalNode(AbstractNode):
    """Pauses workflow execution until a human approves or rejects.

    When executed, returns a result with AWAITING_APPROVAL status.
    The workflow engine detects this and pauses execution. The
    human provides input via the API, and the workflow resumes.

    Config:
        prompt: Jinja2 template for the approval prompt shown to
            the reviewer. Has access to input_data and variables.
        timeout_seconds: How long to wait for approval
            (default 86400).
    """

    node_type = "approval"

    async def execute(self, context: NodeContext) -> NodeResult:
        """Return an AWAITING_APPROVAL result to pause the workflow.

        Args:
            context: Execution context.

        Returns:
            Result with AWAITING_APPROVAL status and prompt.
        """
        prompt_template = self._config.get("prompt", "Approval required")
        timeout = self._config.get("timeout_seconds", 86400)

        template_ctx = {**context.variables, **context.input_data}
        try:
            prompt = render_template(prompt_template, template_ctx)
        except Exception:
            prompt = prompt_template

        logger.info(
            "ApprovalNode %s requesting approval: %s",
            self._node_id,
            prompt[:100],
        )

        return NodeResult(
            node_id=self._node_id,
            status=NodeStatus.AWAITING_APPROVAL,
            output={
                "approval_prompt": prompt,
                "timeout_seconds": timeout,
            },
        )


class ApprovalNodeFactory:
    """Factory for creating ApprovalNode instances."""

    def create(
        self,
        node_id: str,
        config: dict[str, Any],
    ) -> ApprovalNode:
        """Create an ApprovalNode.

        Args:
            node_id: Unique node identifier.
            config: Node configuration.

        Returns:
            Configured ApprovalNode instance.
        """
        return ApprovalNode(node_id=node_id, config=config)
