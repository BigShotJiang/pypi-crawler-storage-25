"""Compacting memory store with token-budget management."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.llm._tokens import count_messages_tokens
from pygubernator.workflow.nodes._memory import (
    BufferMemoryStore,
    MemoryStore,
)

logger = logging.getLogger(__name__)

_SUMMARIZE_PROMPT = (
    "Summarize the following conversation concisely. "
    "Preserve key facts, decisions, action items, and any "
    "specific identifiers (IDs, URLs, names). "
    "Write in third person past tense."
)


class CompactingMemoryStore:
    """Memory store that auto-summarizes old messages on token overflow.

    Wraps an inner ``MemoryStore`` and uses an LLM provider to
    summarize older messages when the total token count exceeds
    the configured budget. Recent messages are always preserved.

    Args:
        inner: The underlying memory store to delegate storage to.
        llm_provider: LLM provider implementing the ``chat`` method.
        max_tokens: Maximum token budget before compaction triggers.
        preserve_recent: Number of most-recent messages to keep
            verbatim (never summarized).
        model: Model name hint for token counting accuracy.
    """

    def __init__(
        self,
        inner: MemoryStore,
        llm_provider: Any,
        max_tokens: int = 8000,
        preserve_recent: int = 4,
        model: str = "",
    ) -> None:
        self._inner = inner
        self._llm_provider = llm_provider
        self._max_tokens = max_tokens
        self._preserve_recent = preserve_recent
        self._model = model
        self._compacted_cache: list[dict[str, str]] | None = None

    async def prepare(self) -> None:
        """Compact the conversation if it exceeds the token budget.

        Reads all messages from the inner store, checks the token
        count, and if over budget, summarizes the older messages
        via the LLM provider while preserving the most recent ones.
        """
        all_msgs = self._inner.get_messages()
        token_count = count_messages_tokens(all_msgs, self._model)

        if token_count <= self._max_tokens:
            self._compacted_cache = all_msgs
            return

        # Not enough messages to split meaningfully
        if len(all_msgs) <= self._preserve_recent:
            self._compacted_cache = all_msgs
            return

        old = all_msgs[: -self._preserve_recent]
        recent = all_msgs[-self._preserve_recent :]

        logger.info(
            "Compacting memory: %d tokens over %d budget, "
            "summarizing %d old messages, keeping %d recent",
            token_count,
            self._max_tokens,
            len(old),
            len(recent),
        )

        summary_text = await self._summarize(old)
        summary_msg: dict[str, str] = {
            "role": "system",
            "content": (f"[Conversation summary]: {summary_text}"),
        }
        self._compacted_cache = [summary_msg] + recent

    def get_messages(self) -> list[dict[str, str]]:
        """Return compacted messages if available, else raw history.

        Returns:
            List of message dicts with ``role`` and ``content`` keys.
        """
        if self._compacted_cache is not None:
            return list(self._compacted_cache)
        return self._inner.get_messages()

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Append messages and invalidate the compacted cache.

        Args:
            messages: Messages to add.
        """
        self._inner.add_messages(messages)
        self._compacted_cache = None

    async def _summarize(
        self,
        messages: list[dict[str, str]],
    ) -> str:
        """Summarize messages via LLM call.

        Args:
            messages: Older messages to condense into a summary.

        Returns:
            Summary text produced by the LLM.
        """
        lines: list[str] = []
        for msg in messages:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            lines.append(f"{role}: {content}")
        conversation_text = "\n".join(lines)

        summary_messages: list[dict[str, Any]] = [
            {"role": "system", "content": _SUMMARIZE_PROMPT},
            {"role": "user", "content": conversation_text},
        ]
        response = await self._llm_provider.chat(summary_messages)
        return response.content


def create_compacting_store(
    config: dict[str, Any],
) -> CompactingMemoryStore:
    """Create a CompactingMemoryStore from a config dict.

    Args:
        config: Must contain ``llm_provider``. Optional keys:
            ``max_tokens``, ``preserve_recent``, ``model``.

    Returns:
        Configured CompactingMemoryStore.
    """
    inner = BufferMemoryStore()
    return CompactingMemoryStore(
        inner=inner,
        llm_provider=config.get("llm_provider"),
        max_tokens=config.get("max_tokens", 8000),
        preserve_recent=config.get("preserve_recent", 4),
        model=config.get("model", ""),
    )
