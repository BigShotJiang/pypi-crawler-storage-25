"""OpenTelemetry metrics event handler."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator._events import AgentEvent, AgentEventType

logger = logging.getLogger(__name__)

# Event types that contribute to counters.
_COUNTER_EVENTS = {
    AgentEventType.MESSAGE_PROCESSED: "agent.messages.processed",
    AgentEventType.AGENT_ERROR: "agent.errors.total",
    AgentEventType.STEP_FAILED: "agent.steps.failed",
    AgentEventType.TOOL_CALL_COMPLETED: "agent.tool_calls.completed",
    AgentEventType.TOOL_CALL_FAILED: "agent.tool_calls.failed",
}

# Event types that contribute to histograms (via duration_ms in data).
_HISTOGRAM_EVENTS = {
    AgentEventType.STEP_COMPLETED: "agent.step.duration_ms",
    AgentEventType.STEP_FAILED: "agent.step.duration_ms",
    AgentEventType.LLM_RESPONSE_RECEIVED: "agent.llm.latency_ms",
}


class OTelMetricsHandler:
    """Records agent events as OpenTelemetry metrics.

    Creates counters and histograms for key agent operations.

    Args:
        meter_name: Name for the OTel meter.
        meter_provider: Optional MeterProvider. Uses the global
            provider if not supplied.
    """

    def __init__(
        self,
        meter_name: str = "pygubernator",
        meter_provider: Any | None = None,
    ) -> None:
        from opentelemetry import metrics

        if meter_provider is not None:
            meter = meter_provider.get_meter(meter_name)
        else:
            meter = metrics.get_meter(meter_name)
        self._counters: dict[str, Any] = {}
        self._histograms: dict[str, Any] = {}

        for evt, name in _COUNTER_EVENTS.items():
            self._counters[evt] = meter.create_counter(
                name=name,
                description=f"Count of {name} events",
            )

        for _evt, name in _HISTOGRAM_EVENTS.items():
            if name not in self._histograms:
                self._histograms[name] = meter.create_histogram(
                    name=name,
                    description=f"Duration histogram for {name}",
                    unit="ms",
                )

    async def handle(self, event: AgentEvent) -> None:
        """Record metrics for the event.

        Args:
            event: The agent event.
        """
        counter = self._counters.get(event.event_type)
        if counter is not None:
            counter.add(1, {"agent.id": event.agent_id})

        hist_name = _HISTOGRAM_EVENTS.get(event.event_type)
        if hist_name is not None:
            duration = event.data.get("duration_ms")
            if duration is not None:
                histogram = self._histograms[hist_name]
                histogram.record(
                    float(duration),
                    {"agent.id": event.agent_id},
                )
