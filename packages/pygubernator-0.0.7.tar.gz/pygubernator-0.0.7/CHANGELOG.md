# Changelog

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/).

## [0.0.7] - 2026-03-31

### Added

- Update scripts/ci.sh,src/pygubernator/tools/catalyst_tools.py

## [0.0.4] - 2026-03-24

### Added

- Add open-source LLM provider support, agent/tool workflow nodes, and editor UX improvements
- Add Google Sheets tools for ToolRegistry
- Expand memory node form with database backend selection
- Add persistent memory store backends

### Fixed

- Move LLM/Agent input handle to left side
- Move LLM/Agent output handle to right side
- Auto-save before executing workflow
- Resolve sub-nodes by type match, not just handle name

### Merge

- Bring Google Sheets tools into develop
- Bring memory node frontend form into develop

## [0.0.2] - 2026-03-19

