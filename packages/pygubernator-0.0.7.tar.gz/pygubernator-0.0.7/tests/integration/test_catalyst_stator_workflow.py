"""End-to-end integration test: pycatalyst -> agent tools -> pystator.

Validates the full workflow:
  1. Generate mock order data with pycatalyst via catalyst tools
  2. Create pystator state machine sessions for each order
  3. Drive state transitions (confirm -> ship -> deliver)
  4. Verify final states
"""

from __future__ import annotations

from typing import Any

import pytest
from pycatalyst import SchemaBuilder
from pystator import StateMachine

from pygubernator.tools.catalyst_tools import create_catalyst_tools
from pygubernator.tools.stator_tools import create_stator_tools


@pytest.fixture
def catalyst_tools() -> list[Any]:
    """Catalyst tools with an orders schema."""
    orders = (
        SchemaBuilder("orders", description="Order records")
        .add_uuid("id")
        .add_uuid("user_id")
        .add_float("amount", min_val=1.0, max_val=9999.99, precision=2)
        .add_enum(
            "status",
            ["pending", "confirmed", "shipped", "delivered"],
        )
        .add_datetime("created_at")
        .build()
    )
    return create_catalyst_tools({"orders": orders})


@pytest.fixture
def stator_tools() -> list[Any]:
    """Stator tools with an order lifecycle machine."""
    order_lifecycle = StateMachine.from_dict(
        {
            "states": [
                {"name": "pending", "type": "initial"},
                {"name": "confirmed", "type": "stable"},
                {"name": "shipped", "type": "stable"},
                {"name": "delivered", "type": "terminal"},
                {"name": "cancelled", "type": "terminal"},
            ],
            "transitions": [
                {"trigger": "confirm", "source": "pending", "dest": "confirmed"},
                {"trigger": "ship", "source": "confirmed", "dest": "shipped"},
                {"trigger": "deliver", "source": "shipped", "dest": "delivered"},
                {"trigger": "cancel", "source": "pending", "dest": "cancelled"},
                {"trigger": "cancel", "source": "confirmed", "dest": "cancelled"},
            ],
        }
    )
    return create_stator_tools({"order_lifecycle": order_lifecycle})


def _tool(tools: list[Any], name: str) -> Any:
    """Look up a tool by name."""
    return next(t for t in tools if t.name == name)


class TestCatalystStatorWorkflow:
    """Full pycatalyst -> pystator workflow tests."""

    @pytest.mark.asyncio
    async def test_generate_and_drive_single_order(
        self,
        catalyst_tools: list[Any],
        stator_tools: list[Any],
    ) -> None:
        """Generate one order, walk it through the full lifecycle."""
        # Step 1: Generate mock order data
        gen = _tool(catalyst_tools, "generate_data")
        gen_result = await gen.execute(
            {"schema_name": "orders", "count": 1, "seed": 42}
        )
        assert gen_result.success
        order = gen_result.output[0]
        order_id = order["id"]

        # Step 2: Create a state machine session for this order
        create = _tool(stator_tools, "create_session")
        cs_result = await create.execute(
            {
                "entity_id": order_id,
                "machine_name": "order_lifecycle",
                "context": {"amount": order["amount"]},
            }
        )
        assert cs_result.success
        assert cs_result.output["state"] == "pending"

        # Step 3: Drive transitions
        send = _tool(stator_tools, "send_event")
        get = _tool(stator_tools, "get_state")

        # confirm
        result = await send.execute({"entity_id": order_id, "trigger": "confirm"})
        assert result.success
        assert result.output["previous_state"] == "pending"
        assert result.output["current_state"] == "confirmed"

        # ship
        result = await send.execute(
            {
                "entity_id": order_id,
                "trigger": "ship",
                "payload": {"carrier": "ups"},
            }
        )
        assert result.success
        assert result.output["current_state"] == "shipped"

        # deliver
        result = await send.execute({"entity_id": order_id, "trigger": "deliver"})
        assert result.success
        assert result.output["current_state"] == "delivered"

        # Step 4: Verify final state
        state_result = await get.execute({"entity_id": order_id})
        assert state_result.success
        assert state_result.output["state"] == "delivered"

    @pytest.mark.asyncio
    async def test_generate_batch_and_drive_all(
        self,
        catalyst_tools: list[Any],
        stator_tools: list[Any],
    ) -> None:
        """Generate a batch of orders, confirm them all, cancel one."""
        gen = _tool(catalyst_tools, "generate_data")
        create = _tool(stator_tools, "create_session")
        send = _tool(stator_tools, "send_event")
        get = _tool(stator_tools, "get_state")
        triggers = _tool(stator_tools, "list_triggers")

        # Generate 5 orders
        gen_result = await gen.execute(
            {"schema_name": "orders", "count": 5, "seed": 99}
        )
        assert gen_result.success
        orders = gen_result.output
        assert len(orders) == 5

        # Create sessions for all orders
        for order in orders:
            cs = await create.execute(
                {
                    "entity_id": order["id"],
                    "machine_name": "order_lifecycle",
                }
            )
            assert cs.success

        # Check triggers for first order (should be in pending)
        trig_result = await triggers.execute({"entity_id": orders[0]["id"]})
        assert trig_result.success
        assert "confirm" in trig_result.output["triggers"]
        assert "cancel" in trig_result.output["triggers"]

        # Confirm all orders
        for order in orders:
            result = await send.execute(
                {"entity_id": order["id"], "trigger": "confirm"}
            )
            assert result.success
            assert result.output["current_state"] == "confirmed"

        # Cancel the last order
        cancel_result = await send.execute(
            {"entity_id": orders[-1]["id"], "trigger": "cancel"}
        )
        assert cancel_result.success
        assert cancel_result.output["current_state"] == "cancelled"

        # Ship and deliver remaining orders
        for order in orders[:-1]:
            ship = await send.execute({"entity_id": order["id"], "trigger": "ship"})
            assert ship.success

            deliver = await send.execute(
                {"entity_id": order["id"], "trigger": "deliver"}
            )
            assert deliver.success

        # Verify: 4 delivered, 1 cancelled
        delivered_count = 0
        cancelled_count = 0
        for order in orders:
            state = await get.execute({"entity_id": order["id"]})
            if state.output["state"] == "delivered":
                delivered_count += 1
            elif state.output["state"] == "cancelled":
                cancelled_count += 1
        assert delivered_count == 4
        assert cancelled_count == 1

    @pytest.mark.asyncio
    async def test_invalid_transition_returns_error(
        self,
        catalyst_tools: list[Any],
        stator_tools: list[Any],
    ) -> None:
        """Sending an invalid trigger returns an error, not an exception."""
        gen = _tool(catalyst_tools, "generate_data")
        create = _tool(stator_tools, "create_session")
        send = _tool(stator_tools, "send_event")

        # Generate and create session
        gen_result = await gen.execute({"schema_name": "orders", "count": 1, "seed": 7})
        order = gen_result.output[0]

        await create.execute(
            {
                "entity_id": order["id"],
                "machine_name": "order_lifecycle",
            }
        )

        # Try to ship a pending order (should fail)
        result = await send.execute({"entity_id": order["id"], "trigger": "ship"})
        assert result.success
        assert not result.output["success"]

    @pytest.mark.asyncio
    async def test_build_schema_then_generate(
        self,
        catalyst_tools: list[Any],
    ) -> None:
        """Build a schema dynamically, then generate from it."""
        from pycatalyst._types import SchemaSpec

        build = _tool(catalyst_tools, "build_schema")

        # Build a custom schema
        build_result = await build.execute(
            {
                "fields": {
                    "product_id": {"type": "uuid"},
                    "price": {"type": "float", "min": 0.99, "max": 99.99},
                    "in_stock": {"type": "bool"},
                }
            }
        )
        assert build_result.success
        schema_dict = build_result.output

        # Verify round-trip
        schema = SchemaSpec.from_config(schema_dict)
        assert schema.field_names == ("product_id", "price", "in_stock")

        # Register the dynamic schema and generate from it
        dynamic_tools = create_catalyst_tools({"products": schema})
        dyn_gen = _tool(dynamic_tools, "generate_data")
        result = await dyn_gen.execute({"schema_name": "products", "count": 3})
        assert result.success
        assert len(result.output) == 3
        for record in result.output:
            assert "product_id" in record
            assert "price" in record
            assert "in_stock" in record
