"""End-to-end pipeline integration test.

Simulates: generate data -> validate data -> load to state machine.
Uses mock versions of pycatalyst/pycharter to avoid hard deps.
"""

from __future__ import annotations

from typing import Any

import pytest

from pygubernator._events import EventBus
from pygubernator._handlers import MetricsEventHandler
from pygubernator._middleware import MiddlewareChain
from pygubernator._types import Message, StepResult
from pygubernator.agents._pipeline import PipelineAgent, PipelineStep
from pygubernator.middleware._logging import LoggingMiddleware
from pygubernator.runners._batch import run_batch
from pygubernator.transport._memory import InMemoryTransport

# -- Mock pipeline steps --


class GenerateStep(PipelineStep):
    """Simulates pycatalyst data generation."""

    async def execute(self, data: Any) -> StepResult:
        count = data.get("count", 3) if isinstance(data, dict) else 3
        records = [{"id": i, "name": f"item-{i}"} for i in range(count)]
        return StepResult(
            step_name=self.name,
            success=True,
            data=records,
            duration_ms=5.0,
        )


class ValidateStep(PipelineStep):
    """Simulates pycharter validation."""

    async def execute(self, data: Any) -> StepResult:
        if not isinstance(data, list):
            return StepResult(
                step_name=self.name,
                success=False,
                error="Expected list of records",
            )
        invalid = [r for r in data if "id" not in r]
        if invalid:
            return StepResult(
                step_name=self.name,
                success=False,
                error=f"{len(invalid)} record(s) missing 'id'",
            )
        return StepResult(
            step_name=self.name,
            success=True,
            data=data,
            duration_ms=2.0,
        )


class LoadStep(PipelineStep):
    """Simulates loading data into a downstream system."""

    async def execute(self, data: Any) -> StepResult:
        return StepResult(
            step_name=self.name,
            success=True,
            data={"loaded_count": len(data)},
            duration_ms=3.0,
        )


@pytest.mark.integration
class TestPipelineE2E:
    """Full pipeline integration test."""

    @pytest.mark.asyncio
    async def test_generate_validate_load_pipeline(self) -> None:
        bus = EventBus()
        metrics = MetricsEventHandler()
        bus.add_handler(metrics)

        agent = PipelineAgent(
            agent_id="etl-pipeline",
            steps=[
                GenerateStep("generate"),
                ValidateStep("validate"),
                LoadStep("load"),
            ],
            event_bus=bus,
        )

        transport = InMemoryTransport()
        transport.inject(
            "input",
            [Message(topic="input", payload={"count": 5})],
        )

        result = await run_batch(
            agent, transport, "input", max_messages=1, event_bus=bus
        )

        assert result.success
        assert result.messages_processed == 1

        m = metrics.get_metrics()
        assert m["counters"].get("step.started", 0) == 3
        assert m["counters"].get("step.completed", 0) == 3

    @pytest.mark.asyncio
    async def test_pipeline_with_middleware(self) -> None:
        agent = PipelineAgent(
            agent_id="mw-pipe",
            steps=[
                GenerateStep("generate"),
                ValidateStep("validate"),
                LoadStep("load"),
            ],
        )

        chain = MiddlewareChain(agent, [LoggingMiddleware()])

        msg = Message(topic="input", payload={"count": 2})
        result = await chain.process(msg)

        assert result.success
        steps = result.metadata.get("steps", [])
        assert len(steps) == 3

    @pytest.mark.asyncio
    async def test_pipeline_validation_failure(self) -> None:
        class BadGenerateStep(PipelineStep):
            async def execute(self, data: Any) -> StepResult:
                return StepResult(
                    step_name=self.name,
                    success=True,
                    data=[{"no_id": True}],
                )

        agent = PipelineAgent(
            agent_id="bad-pipe",
            steps=[
                BadGenerateStep("generate"),
                ValidateStep("validate"),
                LoadStep("load"),
            ],
        )

        msg = Message(topic="input", payload={})
        result = await agent.process(msg)
        assert not result.success
        assert "missing 'id'" in result.errors[0]
