"""Integration tests for python_exec node in a workflow context.

Tests the data flow: python_exec(pycatalyst) -> python_exec(pystator)
without requiring an LLM provider for the agent node.
"""

from __future__ import annotations

import textwrap

import pytest

from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._python_exec import PythonExecNode

_GENERATE_CODE = textwrap.dedent("""\
    from pycatalyst import SchemaBuilder, GenerationEngine

    schema = (
        SchemaBuilder('risk_assessments')
        .add_uuid('id')
        .add_string('name', format='name')
        .add_int('risk_score', min_val=0, max_val=100)
        .build()
    )
    engine = GenerationEngine()
    gen = engine.generate(schema, count=5, seed=42)
    result = list(gen.records)
""")

_CLASSIFY_CODE = textwrap.dedent("""\
    from pystator import StateMachine

    machine = StateMachine.from_dict({
        'meta': {
            'machine_name': 'risk_classifier',
            'classification': {'auto_route': True},
        },
        'states': [
            {'name': 'intake', 'type': 'initial'},
            {'name': 'approved', 'type': 'terminal',
             'when': [{'field': 'risk_score',
                        'op': 'gte', 'value': 70}]},
            {'name': 'review', 'type': 'stable',
             'when': [{'all_of': [
                 {'field': 'risk_score', 'op': 'gte', 'value': 40},
                 {'field': 'risk_score', 'op': 'lt', 'value': 70},
             ]}]},
            {'name': 'rejected', 'type': 'terminal',
             'when': [{'field': 'risk_score',
                        'op': 'lt', 'value': 40}]},
        ],
        'transitions': [
            {'trigger': 'classify', 'source': 'intake',
             'dest': 'approved'},
            {'trigger': 'classify', 'source': 'intake',
             'dest': 'review'},
            {'trigger': 'classify', 'source': 'intake',
             'dest': 'rejected'},
        ],
    })

    records = input_data.get('result', [])
    classified = []
    for record in records:
        session = machine.create()
        session.apply_data(risk_score=record['risk_score'])
        classified.append({
            'id': record['id'],
            'risk_score': record['risk_score'],
            'state': session.current_state,
        })
    result = classified
""")

_SIMPLE_CLASSIFY_CODE = textwrap.dedent("""\
    from pystator import StateMachine

    machine = StateMachine.from_dict({
        'meta': {'classification': {'auto_route': True}},
        'states': [
            {'name': 'intake', 'type': 'initial'},
            {'name': 'high', 'type': 'terminal',
             'when': [{'field': 'risk_score',
                        'op': 'gte', 'value': 50}]},
            {'name': 'low', 'type': 'terminal',
             'when': [{'field': 'risk_score',
                        'op': 'lt', 'value': 50}]},
        ],
        'transitions': [
            {'trigger': 'route', 'source': 'intake',
             'dest': 'high'},
            {'trigger': 'route', 'source': 'intake',
             'dest': 'low'},
        ],
    })
    records = input_data.get('result', [])
    states = {'high': 0, 'low': 0}
    for r in records:
        s = machine.create()
        s.apply_data(risk_score=r['risk_score'])
        st = s.current_state
        states[st] = states.get(st, 0) + 1
    result = states
""")

_SIMPLE_GEN_CODE = textwrap.dedent("""\
    from pycatalyst import SchemaBuilder, GenerationEngine

    schema = (
        SchemaBuilder('risk')
        .add_uuid('id')
        .add_int('risk_score', min_val=0, max_val=100)
        .build()
    )
    engine = GenerationEngine()
    gen = engine.generate(schema, count=10, seed=99)
    result = list(gen.records)
""")


def _ctx(
    input_data: dict | None = None,
) -> NodeContext:
    return NodeContext(
        node_id="test",
        input_data=input_data or {},
        variables={},
        config={},
    )


class TestCatalystToPystatorPipeline:
    """Test pycatalyst -> pystator pipeline via PythonExecNode."""

    @pytest.mark.asyncio
    async def test_generate_data_node(self) -> None:
        """PythonExecNode can generate data with pycatalyst."""
        node = PythonExecNode(
            "generate",
            config={
                "allowed_imports": ["pycatalyst"],
                "code": _GENERATE_CODE,
            },
        )
        res = await node.execute(_ctx())

        assert res.status == NodeStatus.SUCCESS
        records = res.output["result"]
        assert len(records) == 5
        for r in records:
            assert "id" in r
            assert "name" in r
            assert "risk_score" in r
            assert 0 <= r["risk_score"] <= 100

    @pytest.mark.asyncio
    async def test_pystator_classify_node(self) -> None:
        """PythonExecNode classifies data with pystator."""
        node = PythonExecNode(
            "classify",
            config={
                "allowed_imports": ["pystator"],
                "code": _CLASSIFY_CODE,
            },
        )
        ctx = _ctx(
            input_data={
                "result": [
                    {"id": "a", "risk_score": 85},
                    {"id": "b", "risk_score": 55},
                    {"id": "c", "risk_score": 20},
                ]
            },
        )
        res = await node.execute(ctx)

        assert res.status == NodeStatus.SUCCESS
        classified = res.output["result"]
        assert len(classified) == 3
        assert classified[0]["state"] == "approved"
        assert classified[1]["state"] == "review"
        assert classified[2]["state"] == "rejected"

    @pytest.mark.asyncio
    async def test_end_to_end_pipeline(self) -> None:
        """Full pipeline: generate -> classify."""
        # Step 1: Generate data
        gen_node = PythonExecNode(
            "generate",
            config={
                "allowed_imports": ["pycatalyst"],
                "code": _SIMPLE_GEN_CODE,
            },
        )
        gen_res = await gen_node.execute(_ctx())
        assert gen_res.status == NodeStatus.SUCCESS

        # Step 2: Classify (using output from step 1)
        classify_node = PythonExecNode(
            "classify",
            config={
                "allowed_imports": ["pystator"],
                "code": _SIMPLE_CLASSIFY_CODE,
            },
        )
        classify_res = await classify_node.execute(_ctx(input_data=gen_res.output))
        assert classify_res.status == NodeStatus.SUCCESS

        states = classify_res.output["result"]
        assert states["high"] + states["low"] == 10
        assert states["high"] > 0
        assert states["low"] > 0
