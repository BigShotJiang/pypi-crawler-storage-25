"""Tests for the Chat HTTP API (Feature 1)."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import FastAPI

from pygubernator.db.models import ChatSessionRecord

# --------------- Model tests ---------------


class TestChatSessionModel:
    """Test ChatSessionRecord model columns and values."""

    def test_tablename(self) -> None:
        assert ChatSessionRecord.__tablename__ == "chat_sessions"

    def test_custom_fields(self) -> None:
        row = ChatSessionRecord(
            title="My chat",
            model="gpt-4o",
            system_prompt="Be helpful",
            created_by="alice",
        )
        assert row.title == "My chat"
        assert row.model == "gpt-4o"
        assert row.system_prompt == "Be helpful"
        assert row.created_by == "alice"

    def test_column_defaults_declared(self) -> None:
        """Verify column defaults are declared on the table."""
        table = ChatSessionRecord.__table__
        assert table.c.title.default is not None
        assert table.c.model.default is not None
        assert table.c.created_by.default is not None


# --------------- Route tests ---------------


def _make_app() -> FastAPI:
    """Build a minimal app with chat routes."""
    from pygubernator.api.routes_chat import router

    app = FastAPI()
    app.include_router(router)
    return app


class TestChatRoutes:
    """Test that chat route paths are registered."""

    def test_list_sessions_path(self) -> None:
        app = _make_app()
        paths = [r.path for r in app.routes]
        assert "/api/v1/chat/sessions" in paths

    def test_create_session_path(self) -> None:
        app = _make_app()
        paths = [r.path for r in app.routes]
        assert "/api/v1/chat/sessions" in paths

    def test_get_session_path(self) -> None:
        app = _make_app()
        paths = [r.path for r in app.routes]
        assert "/api/v1/chat/sessions/{session_id}" in paths

    def test_delete_session_path(self) -> None:
        app = _make_app()
        paths = [r.path for r in app.routes]
        assert "/api/v1/chat/sessions/{session_id}" in paths

    def test_messages_path(self) -> None:
        app = _make_app()
        paths = [r.path for r in app.routes]
        expected = "/api/v1/chat/sessions/{session_id}/messages"
        assert expected in paths


# --------------- CRUD tests with mock DB ---------------


def _stub_actor() -> dict[str, str | bool]:
    return {
        "actor": "testuser",
        "role": "User",
        "auth_disabled": True,
    }


def _fake_session(
    session_id: str = "sess-1",
) -> ChatSessionRecord:
    row = ChatSessionRecord(
        id=session_id,
        title="Test chat",
        model="gpt-4o",
        system_prompt="Be helpful",
        messages_json=[],
        created_by="testuser",
    )
    row.created_at = datetime.now(UTC)
    row.updated_at = datetime.now(UTC)
    return row


class TestChatSessionCRUD:
    """Test session create/list/delete with mock DB."""

    def test_create_session(self) -> None:
        from pygubernator.api.routes_chat import (
            ChatSessionCreate,
            create_session,
        )

        now = datetime.now(UTC)

        def _refresh(row: Any) -> None:
            if row.id is None:
                row.id = "generated-id"
            row.created_at = now
            row.updated_at = now

        db = MagicMock()
        db.refresh = MagicMock(side_effect=_refresh)
        actor = _stub_actor()
        payload = ChatSessionCreate(
            model="gpt-4o",
            system_prompt="Hi",
            title="Chat 1",
        )
        resp = create_session(payload, actor, db)
        db.add.assert_called_once()
        db.commit.assert_called_once()
        assert resp.title == "Chat 1"
        assert resp.model == "gpt-4o"

    def test_list_sessions(self) -> None:
        from pygubernator.api.routes_chat import (
            list_sessions,
        )

        fake = _fake_session()
        query_mock = MagicMock()
        query_mock.filter.return_value = query_mock
        query_mock.order_by.return_value = query_mock
        query_mock.all.return_value = [fake]

        db = MagicMock()
        db.query.return_value = query_mock

        result = list_sessions(_stub_actor(), db)
        assert len(result["items"]) == 1
        assert result["items"][0]["title"] == "Test chat"

    def test_delete_session(self) -> None:
        from pygubernator.api.routes_chat import (
            delete_session,
        )

        fake = _fake_session()
        db = MagicMock()
        db.get.return_value = fake

        result = delete_session("sess-1", _stub_actor(), db)
        db.delete.assert_called_once_with(fake)
        db.commit.assert_called_once()
        assert result["ok"] is True

    def test_delete_session_not_found(self) -> None:
        from fastapi import HTTPException

        from pygubernator.api.routes_chat import (
            delete_session,
        )

        db = MagicMock()
        db.get.return_value = None

        with pytest.raises(HTTPException) as exc_info:
            delete_session("nope", _stub_actor(), db)
        assert exc_info.value.status_code == 404


# --------------- Message endpoint tests ---------------


class TestChatMessage:
    """Test the send_message endpoint with mock LLM."""

    @pytest.mark.asyncio
    async def test_send_message(self) -> None:
        from pygubernator.api.routes_chat import (
            ChatMessageRequest,
            send_message,
        )

        fake = _fake_session()
        db = MagicMock()
        db.get.return_value = fake
        db.refresh = MagicMock(side_effect=lambda r: None)

        mock_response = MagicMock()
        mock_response.content = "Hello back!"

        mock_provider = AsyncMock()
        mock_provider.chat.return_value = mock_response

        payload = ChatMessageRequest(message="Hello")

        with patch(
            "pygubernator.api.routes_chat.create_provider",
            return_value=mock_provider,
        ):
            result = await send_message("sess-1", payload, _stub_actor(), db)

        assert result.response == "Hello back!"
        assert result.session_id == "sess-1"
        assert result.message_count == 2
        db.commit.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_message_session_not_found(
        self,
    ) -> None:
        from fastapi import HTTPException

        from pygubernator.api.routes_chat import (
            ChatMessageRequest,
            send_message,
        )

        db = MagicMock()
        db.get.return_value = None
        payload = ChatMessageRequest(message="Hello")

        with pytest.raises(HTTPException) as exc_info:
            await send_message("nope", payload, _stub_actor(), db)
        assert exc_info.value.status_code == 404
