"""Tests for HTTP tools (mocking the httpx client)."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pygubernator.tools.http_tools import _HttpClient, create_http_tools

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_response(
    status_code: int = 200,
    json_body: Any = None,
    text_body: str = "",
    headers: dict[str, str] | None = None,
) -> MagicMock:
    """Build a mock httpx.Response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.headers = headers or {"content-type": "application/json"}
    if json_body is not None:
        resp.json.return_value = json_body
    else:
        resp.json.side_effect = ValueError("No JSON")
        resp.text = text_body
    return resp


def _make_client_and_mock() -> tuple[_HttpClient, MagicMock]:
    """Create an _HttpClient with its internal httpx client mocked."""
    mock_httpx_client = MagicMock()
    mock_httpx_client.get = AsyncMock()
    mock_httpx_client.post = AsyncMock()
    mock_httpx_client.put = AsyncMock()
    mock_httpx_client.delete = AsyncMock()

    with patch(
        "pygubernator.tools.http_tools.httpx.AsyncClient",
        return_value=mock_httpx_client,
    ):
        client = _HttpClient(base_url="https://api.example.com")
    return client, mock_httpx_client


def _make_tools_and_mock() -> tuple[list[Any], MagicMock]:
    """Create tools backed by a mocked httpx client."""
    mock_httpx_client = MagicMock()
    mock_httpx_client.get = AsyncMock()
    mock_httpx_client.post = AsyncMock()
    mock_httpx_client.put = AsyncMock()
    mock_httpx_client.delete = AsyncMock()

    with patch(
        "pygubernator.tools.http_tools.httpx.AsyncClient",
        return_value=mock_httpx_client,
    ):
        tools = create_http_tools(
            base_url="https://api.example.com",
        )
    return tools, mock_httpx_client


def _get_tool(tools: list[Any], name: str) -> Any:
    """Find a tool by name."""
    return next(t for t in tools if t.name == name)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestHttpToolsFactory:
    """Tests for create_http_tools factory."""

    def test_returns_four_tools(self) -> None:
        tools, _ = _make_tools_and_mock()
        assert len(tools) == 4

    def test_tool_names(self) -> None:
        tools, _ = _make_tools_and_mock()
        names = {t.name for t in tools}
        assert names == {
            "http_get",
            "http_post",
            "http_put",
            "http_delete",
        }

    def test_all_tools_have_schemas(self) -> None:
        tools, _ = _make_tools_and_mock()
        for t in tools:
            schema = t.parameters_schema
            assert schema["type"] == "object"
            assert "properties" in schema


# ---------------------------------------------------------------------------
# _HttpClient unit tests
# ---------------------------------------------------------------------------


class TestHttpClient:
    """Tests for the _HttpClient wrapper."""

    def test_creation(self) -> None:
        client, _ = _make_client_and_mock()
        assert client._base_url == "https://api.example.com"

    @pytest.mark.asyncio
    async def test_get(self) -> None:
        client, mock = _make_client_and_mock()
        mock.get.return_value = _mock_response(
            200,
            json_body={"key": "value"},
        )

        result = await client.get("/items")

        assert result["status_code"] == 200
        assert result["body"] == {"key": "value"}
        mock.get.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_get_with_params(self) -> None:
        client, mock = _make_client_and_mock()
        mock.get.return_value = _mock_response(
            200,
            json_body=[],
        )

        result = await client.get(
            "/search",
            params={"q": "test"},
        )

        assert result["status_code"] == 200
        mock.get.assert_awaited_once_with(
            "/search",
            headers=None,
            params={"q": "test"},
        )

    @pytest.mark.asyncio
    async def test_post(self) -> None:
        client, mock = _make_client_and_mock()
        mock.post.return_value = _mock_response(
            201,
            json_body={"id": 1},
        )

        result = await client.post(
            "/items",
            body={"name": "thing"},
        )

        assert result["status_code"] == 201
        assert result["body"]["id"] == 1
        mock.post.assert_awaited_once_with(
            "/items",
            json={"name": "thing"},
            headers=None,
        )

    @pytest.mark.asyncio
    async def test_put(self) -> None:
        client, mock = _make_client_and_mock()
        mock.put.return_value = _mock_response(
            200,
            json_body={"updated": True},
        )

        result = await client.put(
            "/items/1",
            body={"name": "updated"},
        )

        assert result["status_code"] == 200
        assert result["body"]["updated"] is True
        mock.put.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_delete(self) -> None:
        client, mock = _make_client_and_mock()
        mock.delete.return_value = _mock_response(204)

        result = await client.delete("/items/1")

        assert result["status_code"] == 204
        mock.delete.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_non_json_response(self) -> None:
        client, mock = _make_client_and_mock()
        mock.get.return_value = _mock_response(
            200,
            text_body="plain text",
        )

        result = await client.get("/text")

        assert result["status_code"] == 200
        assert result["body"] == "plain text"

    @pytest.mark.asyncio
    async def test_response_headers_included(self) -> None:
        client, mock = _make_client_and_mock()
        mock.get.return_value = _mock_response(
            200,
            json_body={},
            headers={"x-request-id": "abc123"},
        )

        result = await client.get("/items")

        assert result["headers"]["x-request-id"] == "abc123"


# ---------------------------------------------------------------------------
# Tool execution (end-to-end via @tool wrappers)
# ---------------------------------------------------------------------------


class TestHttpToolExecution:
    """Tests for executing tools through the @tool decorator."""

    @pytest.mark.asyncio
    async def test_http_get(self) -> None:
        tools, mock = _make_tools_and_mock()
        mock.get.return_value = _mock_response(
            200,
            json_body={"items": []},
        )
        t = _get_tool(tools, "http_get")

        result = await t.execute({"url": "/items"})

        assert result.success
        assert result.output["status_code"] == 200
        assert result.output["body"] == {"items": []}

    @pytest.mark.asyncio
    async def test_http_get_with_params(self) -> None:
        tools, mock = _make_tools_and_mock()
        mock.get.return_value = _mock_response(
            200,
            json_body=[],
        )
        t = _get_tool(tools, "http_get")

        result = await t.execute(
            {"url": "/search", "params": {"q": "hello"}},
        )

        assert result.success

    @pytest.mark.asyncio
    async def test_http_post(self) -> None:
        tools, mock = _make_tools_and_mock()
        mock.post.return_value = _mock_response(
            201,
            json_body={"id": 42},
        )
        t = _get_tool(tools, "http_post")

        result = await t.execute(
            {"url": "/items", "body": {"name": "new"}},
        )

        assert result.success
        assert result.output["body"]["id"] == 42

    @pytest.mark.asyncio
    async def test_http_put(self) -> None:
        tools, mock = _make_tools_and_mock()
        mock.put.return_value = _mock_response(
            200,
            json_body={"ok": True},
        )
        t = _get_tool(tools, "http_put")

        result = await t.execute(
            {"url": "/items/1", "body": {"name": "changed"}},
        )

        assert result.success
        assert result.output["body"]["ok"] is True

    @pytest.mark.asyncio
    async def test_http_delete(self) -> None:
        tools, mock = _make_tools_and_mock()
        mock.delete.return_value = _mock_response(204)
        t = _get_tool(tools, "http_delete")

        result = await t.execute({"url": "/items/1"})

        assert result.success
        assert result.output["status_code"] == 204

    @pytest.mark.asyncio
    async def test_request_error_returns_failure(self) -> None:
        tools, mock = _make_tools_and_mock()
        mock.get.side_effect = RuntimeError("connection refused")
        t = _get_tool(tools, "http_get")

        result = await t.execute({"url": "/fail"})

        assert not result.success
        assert "connection refused" in result.error


# ---------------------------------------------------------------------------
# Missing dependency
# ---------------------------------------------------------------------------


class TestMissingDependency:
    """Tests for behaviour when httpx is not installed."""

    def test_check_deps_raises_when_missing(self) -> None:
        with patch(
            "pygubernator.tools.http_tools._HAS_HTTPX",
            False,
        ):
            from pygubernator.tools.http_tools import _check_deps

            with pytest.raises(ImportError, match="httpx"):
                _check_deps()

    def test_client_init_raises_when_missing(self) -> None:
        with (
            patch(
                "pygubernator.tools.http_tools._HAS_HTTPX",
                False,
            ),
            pytest.raises(ImportError, match="httpx"),
        ):
            _HttpClient()


# ---------------------------------------------------------------------------
# Environment factory
# ---------------------------------------------------------------------------


class TestHttpFactory:
    """Tests for create_tools_from_env."""

    def test_defaults(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Factory works with no env vars set."""
        monkeypatch.delenv(
            "PYGUBERNATOR_HTTP_BASE_URL",
            raising=False,
        )
        monkeypatch.delenv(
            "PYGUBERNATOR_HTTP_DEFAULT_HEADERS",
            raising=False,
        )
        monkeypatch.delenv(
            "PYGUBERNATOR_HTTP_TIMEOUT",
            raising=False,
        )
        seen: dict[str, Any] = {}

        def fake_create(**kwargs: Any) -> list[Any]:
            seen.update(kwargs)
            return []

        from pygubernator.tools import http_factory

        monkeypatch.setattr(
            http_factory,
            "create_http_tools",
            fake_create,
        )

        tools = http_factory.create_tools_from_env()

        assert tools == []
        assert seen["base_url"] == ""
        assert seen["default_headers"] is None
        assert seen["timeout"] == 30.0

    def test_reads_env_vars(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Factory reads all three env vars correctly."""
        monkeypatch.setenv(
            "PYGUBERNATOR_HTTP_BASE_URL",
            "https://api.example.com",
        )
        monkeypatch.setenv(
            "PYGUBERNATOR_HTTP_DEFAULT_HEADERS",
            '{"Authorization": "Bearer tok"}',
        )
        monkeypatch.setenv("PYGUBERNATOR_HTTP_TIMEOUT", "60")

        seen: dict[str, Any] = {}

        def fake_create(**kwargs: Any) -> list[Any]:
            seen.update(kwargs)
            return []

        from pygubernator.tools import http_factory

        monkeypatch.setattr(
            http_factory,
            "create_http_tools",
            fake_create,
        )

        http_factory.create_tools_from_env()

        assert seen["base_url"] == "https://api.example.com"
        assert seen["default_headers"] == {
            "Authorization": "Bearer tok",
        }
        assert seen["timeout"] == 60.0

    def test_invalid_headers_json_raises(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Invalid JSON in PYGUBERNATOR_HTTP_DEFAULT_HEADERS raises."""
        monkeypatch.setenv(
            "PYGUBERNATOR_HTTP_DEFAULT_HEADERS",
            "not-json",
        )

        from pygubernator.tools import http_factory

        with pytest.raises(Exception):
            http_factory.create_tools_from_env()
