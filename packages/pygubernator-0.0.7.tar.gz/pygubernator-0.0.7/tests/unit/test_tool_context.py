"""Tests for tool context system prompt injection."""

from __future__ import annotations

import pytest

from pygubernator.workflow.config._converter import workflow_config_to_spec
from pygubernator.workflow.config._models import (
    EdgeDef,
    NodeDef,
    WorkflowConfig,
    WorkflowMeta,
)
from pygubernator.workflow.nodes._agent import _build_tool_context


class TestBuildToolContext:
    """Tests for _build_tool_context helper."""

    def test_empty_config_returns_empty_string(self) -> None:
        assert _build_tool_context({}) == ""

    def test_no_context_in_tools_returns_empty(self) -> None:
        tools = {
            "google_sheets": {
                "factory_module": "pygubernator.tools.gsheets_factory",
                "factory_function": "create_tools_from_env",
                "factory_args": {},
            },
        }
        assert _build_tool_context(tools) == ""

    def test_single_tool_with_context(self) -> None:
        tools = {
            "google_sheets": {
                "factory_module": "pygubernator.tools.gsheets_factory",
                "factory_function": "create_tools_from_env",
                "factory_args": {},
                "context": {
                    "spreadsheet_id": "1BxiMVs0XRA5nFMdKvBdBZjg",
                    "sheet_name": "Sales Data",
                    "default_operation": "read",
                },
            },
        }
        result = _build_tool_context(tools)
        assert result.startswith("## Tool Context")
        assert "For the google_sheets tools:" in result
        assert "Spreadsheet Id: 1BxiMVs0XRA5nFMdKvBdBZjg" in result
        assert "Sheet Name: Sales Data" in result
        assert "Default Operation: read" in result

    def test_multiple_tools_with_context(self) -> None:
        tools = {
            "google_sheets": {
                "factory_module": "m",
                "factory_function": "f",
                "context": {
                    "spreadsheet_id": "abc123",
                },
            },
            "slack": {
                "factory_module": "m",
                "factory_function": "f",
                "context": {
                    "default_channel": "#general",
                },
            },
        }
        result = _build_tool_context(tools)
        assert "For the google_sheets tools:" in result
        assert "Spreadsheet Id: abc123" in result
        assert "For the slack tools:" in result
        assert "Default Channel: #general" in result

    def test_mixed_tools_some_without_context(self) -> None:
        tools = {
            "google_sheets": {
                "factory_module": "m",
                "factory_function": "f",
                "context": {"spreadsheet_id": "abc123"},
            },
            "sql": {
                "factory_module": "m",
                "factory_function": "f",
                "factory_args": {},
            },
        }
        result = _build_tool_context(tools)
        assert "For the google_sheets tools:" in result
        assert "sql" not in result

    def test_non_dict_tool_spec_skipped(self) -> None:
        tools = {
            "broken": "not-a-dict",
            "valid": {
                "factory_module": "m",
                "factory_function": "f",
                "context": {"key": "value"},
            },
        }
        result = _build_tool_context(tools)
        assert "broken" not in result
        assert "For the valid tools:" in result

    def test_empty_context_dict_skipped(self) -> None:
        tools = {
            "google_sheets": {
                "factory_module": "m",
                "factory_function": "f",
                "context": {},
            },
        }
        assert _build_tool_context(tools) == ""

    def test_non_dict_context_skipped(self) -> None:
        tools = {
            "google_sheets": {
                "factory_module": "m",
                "factory_function": "f",
                "context": "not-a-dict",
            },
        }
        assert _build_tool_context(tools) == ""

    @pytest.mark.parametrize(
        ("key", "expected_label"),
        [
            ("spreadsheet_id", "Spreadsheet Id"),
            ("default_operation", "Default Operation"),
            ("base_url", "Base Url"),
            ("read_only", "Read Only"),
        ],
    )
    def test_key_to_label_conversion(self, key: str, expected_label: str) -> None:
        tools = {
            "test": {
                "context": {key: "val"},
            },
        }
        result = _build_tool_context(tools)
        assert f"{expected_label}: val" in result


class TestConverterPassesContext:
    """Tests that the converter passes context through to tool configs."""

    def test_tool_context_preserved_in_merged_config(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test", version="1.0.0"),
            nodes={
                "input": NodeDef(type="input"),
                "agent": NodeDef(
                    type="agent",
                    config={"system_prompt": "You are helpful."},
                ),
                "sheets": NodeDef(
                    type="tool_gsheets",
                    config={
                        "name": "google_sheets",
                        "context": {
                            "spreadsheet_id": "abc123",
                            "sheet_name": "Sheet1",
                        },
                    },
                ),
                "output": NodeDef(type="output"),
            },
            edges=[
                EdgeDef(source="input", target="agent"),
                EdgeDef(
                    source="sheets",
                    target="agent",
                    target_handle="sub:tools",
                ),
                EdgeDef(source="agent", target="output"),
            ],
        )
        spec = workflow_config_to_spec(config)
        agent_config = spec.nodes["agent"].config
        tools = agent_config["tools"]
        assert "google_sheets" in tools
        sheet_tool = tools["google_sheets"]
        assert sheet_tool["context"] == {
            "spreadsheet_id": "abc123",
            "sheet_name": "Sheet1",
        }

    def test_tool_without_context_has_no_context_key(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test", version="1.0.0"),
            nodes={
                "input": NodeDef(type="input"),
                "agent": NodeDef(type="agent", config={}),
                "slack": NodeDef(
                    type="tool_slack",
                    config={"name": "slack"},
                ),
                "output": NodeDef(type="output"),
            },
            edges=[
                EdgeDef(source="input", target="agent"),
                EdgeDef(
                    source="slack",
                    target="agent",
                    target_handle="sub:tools",
                ),
                EdgeDef(source="agent", target="output"),
            ],
        )
        spec = workflow_config_to_spec(config)
        agent_config = spec.nodes["agent"].config
        tools = agent_config["tools"]
        assert "slack" in tools
        assert "context" not in tools["slack"]
