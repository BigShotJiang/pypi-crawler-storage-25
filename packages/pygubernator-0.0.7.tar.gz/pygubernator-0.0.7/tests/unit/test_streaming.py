"""Tests for LLM response streaming support."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pygubernator._protocols import StreamingLLMProvider
from pygubernator._types import AgentResult, Message
from pygubernator.builder._agent import Agent
from pygubernator.builder._types import AgentResponse
from pygubernator.llm._messages import (
    LLMResponse,
    StreamChunk,
    ToolCallDelta,
)


class TestStreamChunk:
    """Tests for the StreamChunk dataclass."""

    def test_defaults(self) -> None:
        """StreamChunk defaults are empty/None."""
        chunk = StreamChunk()
        assert chunk.delta_content == ""
        assert chunk.tool_calls_delta == ()
        assert chunk.finish_reason is None
        assert chunk.usage == {}

    def test_with_content(self) -> None:
        """StreamChunk stores delta content."""
        chunk = StreamChunk(delta_content="Hello")
        assert chunk.delta_content == "Hello"

    def test_with_finish_reason(self) -> None:
        """StreamChunk stores finish reason."""
        chunk = StreamChunk(
            finish_reason="stop",
            usage={"total_tokens": 10},
        )
        assert chunk.finish_reason == "stop"
        assert chunk.usage["total_tokens"] == 10

    def test_frozen(self) -> None:
        """StreamChunk is immutable."""
        chunk = StreamChunk(delta_content="x")
        with pytest.raises(AttributeError):
            chunk.delta_content = "y"  # type: ignore[misc]


class TestToolCallDelta:
    """Tests for the ToolCallDelta dataclass."""

    def test_creation(self) -> None:
        """ToolCallDelta stores incremental data."""
        delta = ToolCallDelta(
            index=0,
            id="call_1",
            name="my_tool",
            arguments_delta='{"a":',
        )
        assert delta.index == 0
        assert delta.id == "call_1"
        assert delta.name == "my_tool"
        assert delta.arguments_delta == '{"a":'

    def test_defaults(self) -> None:
        """ToolCallDelta has sensible defaults."""
        delta = ToolCallDelta(index=0)
        assert delta.id is None
        assert delta.name is None
        assert delta.arguments_delta == ""

    def test_frozen(self) -> None:
        """ToolCallDelta is immutable."""
        delta = ToolCallDelta(index=0)
        with pytest.raises(AttributeError):
            delta.index = 1  # type: ignore[misc]


class TestStreamingProtocol:
    """Tests for the StreamingLLMProvider protocol."""

    def test_isinstance_check(self) -> None:
        """A class with chat and chat_stream passes isinstance."""

        class FakeStreaming:
            """Fake streaming provider."""

            async def chat(
                self,
                messages: list[dict[str, Any]],
                tools: list[dict[str, Any]] | None = None,
            ) -> LLMResponse:
                return LLMResponse()

            async def chat_stream(
                self,
                messages: list[dict[str, Any]],
                tools: list[dict[str, Any]] | None = None,
            ) -> Any:
                yield StreamChunk()

        assert isinstance(
            FakeStreaming(),
            StreamingLLMProvider,
        )

    def test_non_streaming_fails_check(self) -> None:
        """A class without chat_stream fails isinstance."""

        class FakeNonStreaming:
            """Fake non-streaming provider."""

            async def chat(
                self,
                messages: list[dict[str, Any]],
                tools: list[dict[str, Any]] | None = None,
            ) -> LLMResponse:
                return LLMResponse()

        assert not isinstance(
            FakeNonStreaming(),
            StreamingLLMProvider,
        )


class TestParseStreamChunk:
    """Tests for _parse_stream_chunk helper."""

    def test_content_chunk(self) -> None:
        """Parses a content delta chunk."""
        from pygubernator.llm._openai_compat import (
            _parse_stream_chunk,
        )

        data = {
            "choices": [
                {
                    "delta": {"content": "Hello"},
                    "finish_reason": None,
                }
            ],
        }
        chunk = _parse_stream_chunk(data)
        assert chunk.delta_content == "Hello"
        assert chunk.finish_reason is None

    def test_finish_chunk(self) -> None:
        """Parses a chunk with finish_reason."""
        from pygubernator.llm._openai_compat import (
            _parse_stream_chunk,
        )

        data = {
            "choices": [
                {
                    "delta": {},
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "prompt_tokens": 5,
                "completion_tokens": 3,
                "total_tokens": 8,
            },
        }
        chunk = _parse_stream_chunk(data)
        assert chunk.finish_reason == "stop"
        assert chunk.usage["total_tokens"] == 8

    def test_tool_call_delta(self) -> None:
        """Parses a chunk with tool call deltas."""
        from pygubernator.llm._openai_compat import (
            _parse_stream_chunk,
        )

        data = {
            "choices": [
                {
                    "delta": {
                        "tool_calls": [
                            {
                                "index": 0,
                                "id": "call_abc",
                                "function": {
                                    "name": "get_weather",
                                    "arguments": '{"city":',
                                },
                            }
                        ],
                    },
                    "finish_reason": None,
                }
            ],
        }
        chunk = _parse_stream_chunk(data)
        assert len(chunk.tool_calls_delta) == 1
        tcd = chunk.tool_calls_delta[0]
        assert tcd.index == 0
        assert tcd.id == "call_abc"
        assert tcd.name == "get_weather"
        assert tcd.arguments_delta == '{"city":'

    def test_empty_choices(self) -> None:
        """Handles response with no choices."""
        from pygubernator.llm._openai_compat import (
            _parse_stream_chunk,
        )

        chunk = _parse_stream_chunk({"choices": []})
        assert chunk.delta_content == ""
        assert chunk.finish_reason is None


async def _mock_stream() -> Any:
    """Yield test StreamChunks."""
    yield StreamChunk(delta_content="Hello")
    yield StreamChunk(delta_content=" world")
    yield StreamChunk(
        finish_reason="stop",
        usage={"total_tokens": 10},
    )


def _make_streaming_provider() -> MagicMock:
    """Create a mock streaming provider."""
    provider = MagicMock(
        spec=["chat", "chat_stream"],
    )

    async def _chat(
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        return LLMResponse(content="non-stream response")

    provider.chat = _chat
    provider.chat_stream = AsyncMock(
        return_value=_mock_stream(),
    )
    # Make it pass StreamingLLMProvider isinstance check
    provider.__class__ = type(
        "MockStreamingProvider",
        (),
        {
            "chat": _chat,
            "chat_stream": provider.chat_stream,
        },
    )
    return provider


class TestLLMAgentProcessStream:
    """Tests for LLMAgent.process_stream()."""

    @pytest.mark.asyncio
    async def test_yields_chunks_then_result(self) -> None:
        """process_stream yields StreamChunks then AgentResult."""
        from pygubernator.agents._llm import LLMAgent

        provider = MagicMock()

        async def _chat(
            messages: Any,
            tools: Any = None,
        ) -> LLMResponse:
            return LLMResponse(content="fallback")

        provider.chat = _chat
        provider.chat_stream = AsyncMock(
            return_value=_mock_stream(),
        )

        # Patch isinstance to recognise mock as streaming
        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            system_prompt="Be helpful.",
        )

        msg = Message(
            topic="test",
            payload={"content": "hi"},
        )

        # Since MagicMock won't pass isinstance check,
        # test the fallback path instead
        items: list[Any] = []
        async for item in agent.process_stream(msg):
            items.append(item)

        # Fallback path yields a single AgentResult
        assert len(items) == 1
        assert isinstance(items[0], AgentResult)

    @pytest.mark.asyncio
    async def test_streaming_with_real_protocol(
        self,
    ) -> None:
        """process_stream streams when provider implements protocol."""
        from pygubernator.agents._llm import LLMAgent

        class FakeStreamingProvider:
            """Fake provider implementing streaming."""

            async def chat(
                self,
                messages: list[dict[str, Any]],
                tools: list[dict[str, Any]] | None = None,
            ) -> LLMResponse:
                return LLMResponse(content="non-stream")

            async def chat_stream(
                self,
                messages: list[dict[str, Any]],
                tools: list[dict[str, Any]] | None = None,
            ) -> Any:
                yield StreamChunk(delta_content="Hi")
                yield StreamChunk(delta_content="!")
                yield StreamChunk(finish_reason="stop")

        provider = FakeStreamingProvider()
        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            system_prompt="Be helpful.",
        )

        msg = Message(
            topic="test",
            payload={"content": "hello"},
        )

        chunks: list[StreamChunk] = []
        result: AgentResult | None = None
        async for item in agent.process_stream(msg):
            if isinstance(item, StreamChunk):
                chunks.append(item)
            elif isinstance(item, AgentResult):
                result = item

        assert len(chunks) == 3
        assert chunks[0].delta_content == "Hi"
        assert chunks[1].delta_content == "!"
        assert result is not None
        assert result.success is True


class TestLLMAgentProcessStreamFallback:
    """Tests for fallback when provider is not streaming."""

    @pytest.mark.asyncio
    async def test_non_streaming_falls_back(self) -> None:
        """Non-streaming provider falls back to process()."""
        from pygubernator.agents._llm import LLMAgent

        async def _chat(
            messages: Any,
            tools: Any = None,
        ) -> LLMResponse:
            return LLMResponse(content="Hello!")

        provider = MagicMock()
        provider.chat = _chat

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            system_prompt="",
        )

        msg = Message(
            topic="test",
            payload={"content": "hi"},
        )

        items: list[Any] = []
        async for item in agent.process_stream(msg):
            items.append(item)

        assert len(items) == 1
        assert isinstance(items[0], AgentResult)
        assert items[0].success is True
        assert items[0].metadata["response"] == "Hello!"


class TestAgentRunStream:
    """Tests for Agent.run_stream()."""

    @pytest.mark.asyncio
    @patch("pygubernator.builder._agent.create_provider")
    async def test_run_stream_yields_chunks_and_response(
        self,
        mock_create: MagicMock,
    ) -> None:
        """run_stream yields StreamChunks then AgentResponse."""

        async def _chat(
            messages: Any,
            tools: Any = None,
        ) -> LLMResponse:
            return LLMResponse(content="Hello world")

        provider = MagicMock()
        provider.chat = _chat
        mock_create.return_value = provider

        agent = Agent.builder().model("gpt-4o").build()
        items: list[Any] = []
        async for item in agent.run_stream("hi"):
            items.append(item)

        # Fallback path: single AgentResponse
        assert len(items) == 1
        assert isinstance(items[0], AgentResponse)
        assert items[0].success is True

    @pytest.mark.asyncio
    @patch("pygubernator.builder._agent.create_provider")
    async def test_session_run_stream(
        self,
        mock_create: MagicMock,
    ) -> None:
        """Session.run_stream() yields items and updates memory."""

        async def _chat(
            messages: Any,
            tools: Any = None,
        ) -> LLMResponse:
            return LLMResponse(content="reply text")

        provider = MagicMock()
        provider.chat = _chat
        mock_create.return_value = provider

        agent = Agent.builder().model("gpt-4o").build()
        session = agent.session()

        items: list[Any] = []
        async for item in session.run_stream("hello"):
            items.append(item)

        assert len(items) == 1
        assert isinstance(items[0], AgentResponse)
        assert items[0].text == "reply text"

        # Memory should be updated
        history = session.history
        assert len(history) == 2
        assert history[0]["content"] == "hello"
        assert history[1]["content"] == "reply text"
