"""Tests for webhook trigger model, routes, and inbound triggering."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import MagicMock, patch

import pytest
from fastapi import HTTPException

from pygubernator.db.models import WebhookTrigger

# -------------------------------------------------------------------
# Model tests
# -------------------------------------------------------------------


class TestWebhookTriggerModel:
    """Tests for WebhookTrigger ORM model defaults."""

    def test_creation_with_explicit_values(self) -> None:
        """Verify explicit field values are preserved."""
        now = datetime.now(UTC)
        row = WebhookTrigger(
            workflow_id="wf-2",
            token="tok-xyz",
            name="My Hook",
            enabled=False,
            trigger_count=5,
            last_triggered_at=now,
            created_by="admin",
        )
        assert row.name == "My Hook"
        assert row.enabled is False
        assert row.trigger_count == 5
        assert row.last_triggered_at == now
        assert row.created_by == "admin"

    def test_nullable_last_triggered_at(self) -> None:
        """last_triggered_at accepts None."""
        row = WebhookTrigger(
            workflow_id="wf-1",
            token="tok-abc",
            last_triggered_at=None,
        )
        assert row.last_triggered_at is None

    def test_token_uniqueness_constraint(self) -> None:
        """Token column has unique=True in the schema."""
        table = WebhookTrigger.__table__
        token_col = table.c.token
        assert token_col.unique is True

    def test_tablename(self) -> None:
        """Table name matches expected value."""
        assert WebhookTrigger.__tablename__ == "webhook_triggers"

    def test_workflow_id_indexed(self) -> None:
        """workflow_id column is indexed for lookup performance."""
        table = WebhookTrigger.__table__
        col = table.c.workflow_id
        assert col.index is True


# -------------------------------------------------------------------
# Route definition tests
# -------------------------------------------------------------------


class TestWebhookRoutes:
    """Tests that webhook routers define expected paths."""

    def test_admin_router_paths(self) -> None:
        """Admin router has CRUD + regenerate paths."""
        from pygubernator.api.routes_webhooks import (
            admin_router,
        )

        paths = [r.path for r in admin_router.routes]
        prefix = "/api/v1/admin/webhooks"
        assert prefix in paths
        assert f"{prefix}/{{webhook_id}}" in paths
        assert f"{prefix}/{{webhook_id}}/regenerate" in paths

    def test_trigger_router_path(self) -> None:
        """Trigger router has the inbound POST path."""
        from pygubernator.api.routes_webhooks import (
            trigger_router,
        )

        paths = [r.path for r in trigger_router.routes]
        assert "/api/v1/webhooks/trigger/{token}" in paths


# -------------------------------------------------------------------
# Webhook creation
# -------------------------------------------------------------------


class TestWebhookCreate:
    """Tests for webhook creation via the route handler."""

    @patch("pygubernator.api.routes_webhooks.secrets.token_urlsafe")
    def test_create_generates_token(self, mock_urlsafe: MagicMock) -> None:
        """create_webhook generates a unique token."""
        from pygubernator.api.routes_webhooks import (
            WebhookCreate,
            create_webhook,
        )

        mock_urlsafe.return_value = "generated-token-abc"

        now = datetime.now(UTC)

        def _refresh(obj: object) -> None:
            """Simulate DB refresh by setting server defaults."""
            obj.id = "wh-generated"  # type: ignore[attr-defined]
            obj.trigger_count = 0  # type: ignore[attr-defined]
            obj.created_at = now  # type: ignore[attr-defined]
            obj.last_triggered_at = None  # type: ignore[attr-defined]
            obj.enabled = True  # type: ignore[attr-defined]

        mock_db = MagicMock()
        mock_db.refresh.side_effect = _refresh

        payload = WebhookCreate(workflow_id="wf-1", name="CI hook")
        actor: dict = {"actor": "admin", "role": "Admin"}

        result = create_webhook(payload, actor, mock_db)

        mock_urlsafe.assert_called_once_with(32)
        mock_db.add.assert_called_once()
        mock_db.commit.assert_called_once()
        assert result.token == "generated-token-abc"
        assert result.workflow_id == "wf-1"
        assert result.name == "CI hook"
        assert "/api/v1/webhooks/trigger/" in result.webhook_url

    def test_response_contains_webhook_url(self) -> None:
        """WebhookResponse includes the full trigger URL."""
        from pygubernator.api.routes_webhooks import (
            _to_response,
        )

        now = datetime.now(UTC)
        row = WebhookTrigger(
            id="wh-1",
            workflow_id="wf-1",
            token="my-token",
            name="test",
            enabled=True,
            trigger_count=0,
            created_at=now,
        )
        resp = _to_response(row)
        expected = "/api/v1/webhooks/trigger/my-token"
        assert resp.webhook_url == expected


# -------------------------------------------------------------------
# Inbound trigger
# -------------------------------------------------------------------


class TestWebhookTriggerInbound:
    """Tests for the inbound POST /trigger/{token} handler."""

    @patch("pygubernator.api.routes_webhooks.threading.Thread")
    def test_trigger_updates_counter(self, mock_thread_cls: MagicMock) -> None:
        """Triggering increments trigger_count and sets last_triggered_at."""
        from pygubernator.api.routes_webhooks import (
            trigger_webhook,
        )

        mock_thread = MagicMock()
        mock_thread_cls.return_value = mock_thread

        wh_row = MagicMock(spec=WebhookTrigger)
        wh_row.id = "wh-1"
        wh_row.workflow_id = "wf-1"
        wh_row.token = "tok-abc"
        wh_row.enabled = True
        wh_row.trigger_count = 3
        wh_row.last_triggered_at = None

        mock_wf = MagicMock()
        mock_wf.id = "wf-1"

        mock_version = MagicMock()
        mock_version.id = "v-1"
        mock_version.spec_json = {"nodes": {}}

        mock_run = MagicMock()
        mock_run.id = "run-123"

        mock_db = MagicMock()
        wh_query = MagicMock()
        wh_query.filter.return_value.first.return_value = wh_row
        ver_query = MagicMock()
        ver_query.filter.return_value.first.return_value = mock_version
        mock_db.query.side_effect = _multi_query(
            {
                "WebhookTrigger": wh_query,
                "WorkflowVersion": ver_query,
            }
        )
        mock_db.get.return_value = mock_wf
        mock_db.refresh.side_effect = lambda obj: setattr(obj, "id", "run-123")

        with patch("pygubernator.db.models.WorkflowRun") as mock_wr_cls:
            mock_wr_cls.return_value = mock_run
            result = trigger_webhook(
                token="tok-abc",
                body={"key": "val"},
                db=mock_db,
            )

        assert result["ok"] is True
        assert result["run_id"] == "run-123"
        assert wh_row.trigger_count == 4
        assert wh_row.last_triggered_at is not None
        mock_thread.start.assert_called_once()

    @patch("pygubernator.api.routes_webhooks.threading.Thread")
    def test_trigger_with_empty_body(self, mock_thread_cls: MagicMock) -> None:
        """Triggering with None body defaults to empty dict."""
        from pygubernator.api.routes_webhooks import (
            trigger_webhook,
        )

        mock_thread_cls.return_value = MagicMock()

        wh_row = MagicMock(spec=WebhookTrigger)
        wh_row.id = "wh-1"
        wh_row.workflow_id = "wf-1"
        wh_row.enabled = True
        wh_row.trigger_count = 0

        mock_version = MagicMock()
        mock_version.id = "v-1"
        mock_version.spec_json = {}

        mock_run = MagicMock()
        mock_run.id = "run-456"

        mock_db = MagicMock()
        wh_q = MagicMock()
        wh_q.filter.return_value.first.return_value = wh_row
        ver_q = MagicMock()
        ver_q.filter.return_value.first.return_value = mock_version
        mock_db.query.side_effect = _multi_query(
            {
                "WebhookTrigger": wh_q,
                "WorkflowVersion": ver_q,
            }
        )
        mock_db.get.return_value = MagicMock()
        mock_db.refresh.side_effect = lambda obj: None

        with patch("pygubernator.db.models.WorkflowRun") as mock_wr_cls:
            mock_wr_cls.return_value = mock_run
            result = trigger_webhook(token="tok", body=None, db=mock_db)

        assert result["ok"] is True


# -------------------------------------------------------------------
# Disabled webhook
# -------------------------------------------------------------------


class TestDisabledWebhook:
    """Tests for disabled webhook behaviour."""

    def test_disabled_webhook_returns_410(self) -> None:
        """A disabled webhook returns HTTP 410 Gone."""
        from pygubernator.api.routes_webhooks import (
            trigger_webhook,
        )

        wh_row = MagicMock(spec=WebhookTrigger)
        wh_row.enabled = False

        mock_db = MagicMock()
        q = MagicMock()
        q.filter.return_value.first.return_value = wh_row
        mock_db.query.return_value = q

        with pytest.raises(HTTPException) as exc_info:
            trigger_webhook(
                token="tok-disabled",
                body={},
                db=mock_db,
            )
        assert exc_info.value.status_code == 410


# -------------------------------------------------------------------
# Invalid token
# -------------------------------------------------------------------


class TestInvalidToken:
    """Tests for unknown webhook token."""

    def test_unknown_token_returns_404(self) -> None:
        """An unknown token returns HTTP 404."""
        from pygubernator.api.routes_webhooks import (
            trigger_webhook,
        )

        mock_db = MagicMock()
        q = MagicMock()
        q.filter.return_value.first.return_value = None
        mock_db.query.return_value = q

        with pytest.raises(HTTPException) as exc_info:
            trigger_webhook(
                token="nonexistent",
                body={},
                db=mock_db,
            )
        assert exc_info.value.status_code == 404


# -------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------


def _multi_query(
    mapping: dict[str, MagicMock],
) -> object:
    """Return a side_effect callable for db.query(Model).

    Routes calls to the right mock based on the model
    class name.
    """

    def _side_effect(model: type, *args: object) -> MagicMock:
        name = getattr(model, "__name__", str(model))
        return mapping.get(name, MagicMock())

    return _side_effect
