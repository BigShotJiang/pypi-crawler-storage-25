"""Tests for the ApprovalNode and workflow engine approval flow."""

from __future__ import annotations

from pygubernator.workflow._engine import WorkflowEngine
from pygubernator.workflow._registry import NodeTypeRegistry
from pygubernator.workflow._types import (
    EdgeSpec,
    NodeContext,
    NodeSpec,
    NodeStatus,
    WorkflowSpec,
)
from pygubernator.workflow.nodes._approval import (
    ApprovalNode,
    ApprovalNodeFactory,
)
from pygubernator.workflow.nodes._input import InputNodeFactory
from pygubernator.workflow.nodes._output import OutputNodeFactory


def _registry() -> NodeTypeRegistry:
    """Build a registry with built-in + approval factories."""
    reg = NodeTypeRegistry()
    reg.register("input", InputNodeFactory())
    reg.register("output", OutputNodeFactory())
    reg.register("approval", ApprovalNodeFactory())
    return reg


def _approval_spec() -> WorkflowSpec:
    """input -> approval -> output DAG."""
    return WorkflowSpec(
        name="approval_test",
        version="1.0.0",
        nodes={
            "start": NodeSpec(
                node_id="start",
                node_type="input",
            ),
            "approve": NodeSpec(
                node_id="approve",
                node_type="approval",
                config={
                    "prompt": "Please approve {{ name }}",
                    "timeout_seconds": 3600,
                },
            ),
            "end": NodeSpec(
                node_id="end",
                node_type="output",
            ),
        },
        edges=(
            EdgeSpec(
                edge_id="e1",
                source_id="start",
                target_id="approve",
            ),
            EdgeSpec(
                edge_id="e2",
                source_id="approve",
                target_id="end",
            ),
        ),
    )


class TestApprovalNode:
    """Tests for ApprovalNode execution."""

    async def test_returns_awaiting_approval_status(self) -> None:
        """Execute returns AWAITING_APPROVAL status."""
        node = ApprovalNode(
            node_id="test_approval",
            config={"prompt": "Approve?"},
        )
        ctx = NodeContext(
            node_id="test_approval",
            input_data={"key": "val"},
            variables={},
            config={"prompt": "Approve?"},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.AWAITING_APPROVAL
        assert result.node_id == "test_approval"

    async def test_prompt_rendered_from_template(self) -> None:
        """Prompt is rendered using Jinja2 template."""
        node = ApprovalNode(
            node_id="tpl",
            config={
                "prompt": "Approve {{ user }}?",
            },
        )
        ctx = NodeContext(
            node_id="tpl",
            input_data={"user": "Alice"},
            variables={},
            config={"prompt": "Approve {{ user }}?"},
        )
        result = await node.execute(ctx)
        assert result.output["approval_prompt"] == ("Approve Alice?")

    async def test_timeout_from_config(self) -> None:
        """Timeout is read from node config."""
        node = ApprovalNode(
            node_id="t",
            config={"timeout_seconds": 7200},
        )
        ctx = NodeContext(
            node_id="t",
            input_data={},
            variables={},
            config={"timeout_seconds": 7200},
        )
        result = await node.execute(ctx)
        assert result.output["timeout_seconds"] == 7200

    async def test_default_timeout(self) -> None:
        """Default timeout is 86400 when not configured."""
        node = ApprovalNode(node_id="d", config={})
        ctx = NodeContext(
            node_id="d",
            input_data={},
            variables={},
            config={},
        )
        result = await node.execute(ctx)
        assert result.output["timeout_seconds"] == 86400

    async def test_default_prompt(self) -> None:
        """Default prompt when none configured."""
        node = ApprovalNode(node_id="d", config={})
        ctx = NodeContext(
            node_id="d",
            input_data={},
            variables={},
            config={},
        )
        result = await node.execute(ctx)
        assert result.output["approval_prompt"] == ("Approval required")

    async def test_template_error_falls_back(self) -> None:
        """If template rendering fails, use raw template."""
        node = ApprovalNode(
            node_id="bad",
            config={
                "prompt": "Hello {{ undefined_var }}",
            },
        )
        ctx = NodeContext(
            node_id="bad",
            input_data={},
            variables={},
            config={"prompt": "Hello {{ undefined_var }}"},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.AWAITING_APPROVAL
        assert result.output["approval_prompt"] == ("Hello {{ undefined_var }}")


class TestApprovalNodeFactory:
    """Tests for ApprovalNodeFactory."""

    def test_creates_approval_node(self) -> None:
        """Factory returns ApprovalNode instance."""
        factory = ApprovalNodeFactory()
        node = factory.create(
            "n1",
            {"prompt": "OK?"},
        )
        assert isinstance(node, ApprovalNode)
        assert node.node_type == "approval"

    def test_factory_passes_config(self) -> None:
        """Factory passes config to the node."""
        factory = ApprovalNodeFactory()
        node = factory.create(
            "n1",
            {"prompt": "Check", "timeout_seconds": 60},
        )
        assert node._config["timeout_seconds"] == 60


class TestWorkflowEngineApproval:
    """Tests for engine pausing on approval nodes."""

    async def test_engine_pauses_on_approval(self) -> None:
        """Engine returns awaiting_approval=True with checkpoint."""
        engine = WorkflowEngine(
            spec=_approval_spec(),
            registry=_registry(),
        )
        result = await engine.run({"name": "Bob"})

        assert result.success is False
        assert result.awaiting_approval is True
        assert result.errors == []
        assert "__checkpoint__" in result.output
        assert result.output["approval_node_id"] == "approve"
        assert result.output["approval_prompt"] == ("Please approve Bob")

    async def test_checkpoint_contains_state(self) -> None:
        """Checkpoint includes node_results and graph state."""
        engine = WorkflowEngine(
            spec=_approval_spec(),
            registry=_registry(),
        )
        result = await engine.run({"name": "Test"})

        checkpoint = result.output["__checkpoint__"]
        assert "node_results" in checkpoint
        assert "active_edges" in checkpoint
        assert "active_nodes" in checkpoint
        assert "variables" in checkpoint
        assert "input_data" in checkpoint

        # start node should be completed
        nr = checkpoint["node_results"]
        assert "start" in nr
        assert nr["start"]["status"] == "success"

        # approve node should be in awaiting_approval
        assert "approve" in nr
        assert nr["approve"]["status"] == "awaiting_approval"

    async def test_input_node_executed_before_pause(self) -> None:
        """Input node runs before the approval pause."""
        engine = WorkflowEngine(
            spec=_approval_spec(),
            registry=_registry(),
        )
        result = await engine.run({"name": "Z"})

        start_result = result.node_results.get("start")
        assert start_result is not None
        assert start_result.status == NodeStatus.SUCCESS

    async def test_output_node_not_executed(self) -> None:
        """Output node does not run when paused."""
        engine = WorkflowEngine(
            spec=_approval_spec(),
            registry=_registry(),
        )
        result = await engine.run({"name": "Z"})

        end_result = result.node_results.get("end")
        assert end_result is None


class TestWorkflowEngineResume:
    """Tests for resuming a workflow from a checkpoint."""

    async def test_resume_completes_workflow(self) -> None:
        """Resuming from checkpoint finishes remaining nodes."""
        spec = _approval_spec()
        engine = WorkflowEngine(
            spec=spec,
            registry=_registry(),
        )
        paused = await engine.run({"name": "Alice"})
        assert paused.awaiting_approval is True

        checkpoint = paused.output["__checkpoint__"]
        approval_node_id = paused.output["approval_node_id"]

        engine2 = WorkflowEngine(
            spec=spec,
            registry=_registry(),
        )
        resumed = await engine2.run_from_checkpoint(
            checkpoint=checkpoint,
            approval_node_id=approval_node_id,
            approval_output={
                "decision": "approved",
                "comment": "Looks good",
            },
        )

        assert resumed.success is True
        assert resumed.awaiting_approval is False
        assert "end" in resumed.node_results
        assert resumed.node_results["end"].status == NodeStatus.SUCCESS

    async def test_resume_passes_approval_output(self) -> None:
        """Approval output flows to downstream nodes."""
        spec = _approval_spec()
        engine = WorkflowEngine(
            spec=spec,
            registry=_registry(),
        )
        paused = await engine.run({"name": "Bob"})

        checkpoint = paused.output["__checkpoint__"]
        approval_data = {"decision": "approved", "note": "ok"}

        engine2 = WorkflowEngine(
            spec=spec,
            registry=_registry(),
        )
        resumed = await engine2.run_from_checkpoint(
            checkpoint=checkpoint,
            approval_node_id="approve",
            approval_output=approval_data,
        )

        assert resumed.success is True
        # Output node collects upstream data
        end_result = resumed.node_results["end"]
        assert end_result.status == NodeStatus.SUCCESS
        # The output node receives the approval output
        assert end_result.output.get("decision") == "approved"

    async def test_resume_with_empty_approval_output(self) -> None:
        """Resume works with empty approval output."""
        spec = _approval_spec()
        engine = WorkflowEngine(
            spec=spec,
            registry=_registry(),
        )
        paused = await engine.run({"name": "X"})

        checkpoint = paused.output["__checkpoint__"]

        engine2 = WorkflowEngine(
            spec=spec,
            registry=_registry(),
        )
        resumed = await engine2.run_from_checkpoint(
            checkpoint=checkpoint,
            approval_node_id="approve",
            approval_output={},
        )
        assert resumed.success is True
