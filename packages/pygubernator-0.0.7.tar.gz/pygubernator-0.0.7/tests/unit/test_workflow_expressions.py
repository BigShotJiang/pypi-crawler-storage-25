"""Tests for safe expression evaluator."""

from __future__ import annotations

import pytest

from pygubernator.errors import ExpressionError
from pygubernator.workflow._expressions import (
    SafeExpressionEvaluator,
    evaluate_condition,
)


class TestSafeExpressionEvaluator:
    """Tests for the AST-based expression evaluator."""

    def test_simple_comparison(self) -> None:
        ev = SafeExpressionEvaluator({"x": 10})
        assert ev.evaluate("x > 5") is True
        assert ev.evaluate("x < 5") is False

    def test_equality(self) -> None:
        ev = SafeExpressionEvaluator({"status": "ok"})
        assert ev.evaluate("status == 'ok'") is True
        assert ev.evaluate("status != 'ok'") is False

    def test_boolean_and(self) -> None:
        ev = SafeExpressionEvaluator({"a": True, "b": True})
        assert ev.evaluate("a and b") is True

    def test_boolean_or(self) -> None:
        ev = SafeExpressionEvaluator({"a": False, "b": True})
        assert ev.evaluate("a or b") is True

    def test_not(self) -> None:
        ev = SafeExpressionEvaluator({"x": False})
        assert ev.evaluate("not x") is True

    def test_nested_boolean(self) -> None:
        ev = SafeExpressionEvaluator({"a": 1, "b": 2, "c": 3})
        assert ev.evaluate("a < b and b < c") is True

    def test_arithmetic(self) -> None:
        ev = SafeExpressionEvaluator({"x": 10, "y": 3})
        assert ev.evaluate("x + y") == 13
        assert ev.evaluate("x - y") == 7
        assert ev.evaluate("x * y") == 30
        assert ev.evaluate("x % y") == 1

    def test_constants(self) -> None:
        ev = SafeExpressionEvaluator()
        assert ev.evaluate("True") is True
        assert ev.evaluate("False") is False
        assert ev.evaluate("None") is None
        assert ev.evaluate("42") == 42
        assert ev.evaluate("'hello'") == "hello"

    def test_attribute_access(self) -> None:
        class Obj:
            value = 42

        ev = SafeExpressionEvaluator({"obj": Obj()})
        assert ev.evaluate("obj.value") == 42

    def test_subscript(self) -> None:
        ev = SafeExpressionEvaluator({"data": {"key": "val"}})
        assert ev.evaluate("data['key']") == "val"

    def test_in_operator(self) -> None:
        ev = SafeExpressionEvaluator({"items": [1, 2, 3]})
        assert ev.evaluate("2 in items") is True
        assert ev.evaluate("5 in items") is False
        assert ev.evaluate("5 not in items") is True

    def test_ternary(self) -> None:
        ev = SafeExpressionEvaluator({"x": 10})
        assert ev.evaluate("'big' if x > 5 else 'small'") == "big"
        assert ev.evaluate("'big' if x < 5 else 'small'") == "small"

    def test_list_literal(self) -> None:
        ev = SafeExpressionEvaluator()
        assert ev.evaluate("[1, 2, 3]") == [1, 2, 3]

    def test_dict_literal(self) -> None:
        ev = SafeExpressionEvaluator()
        assert ev.evaluate("{'a': 1}") == {"a": 1}

    def test_comparison_chain(self) -> None:
        ev = SafeExpressionEvaluator({"x": 5})
        assert ev.evaluate("1 < x < 10") is True
        assert ev.evaluate("1 < x < 3") is False

    def test_undefined_variable(self) -> None:
        ev = SafeExpressionEvaluator()
        with pytest.raises(ExpressionError, match="Undefined variable"):
            ev.evaluate("unknown_var")

    def test_invalid_syntax(self) -> None:
        ev = SafeExpressionEvaluator()
        with pytest.raises(ExpressionError, match="Invalid expression"):
            ev.evaluate("if x:")

    def test_expression_too_long(self) -> None:
        ev = SafeExpressionEvaluator()
        with pytest.raises(ExpressionError, match="exceeds max length"):
            ev.evaluate("x " * 300)

    def test_unsupported_node_type(self) -> None:
        ev = SafeExpressionEvaluator()
        with pytest.raises(ExpressionError, match="Unsupported"):
            ev.evaluate("lambda: 1")

    def test_attribute_not_found(self) -> None:
        ev = SafeExpressionEvaluator({"obj": object()})
        with pytest.raises(ExpressionError, match="no attribute"):
            ev.evaluate("obj.nonexistent")

    def test_unary_neg(self) -> None:
        ev = SafeExpressionEvaluator({"x": 5})
        assert ev.evaluate("-x") == -5

    def test_division(self) -> None:
        ev = SafeExpressionEvaluator()
        assert ev.evaluate("10 / 4") == 2.5

    def test_is_none(self) -> None:
        ev = SafeExpressionEvaluator({"x": None})
        assert ev.evaluate("x is None") is True

    def test_is_not_none(self) -> None:
        ev = SafeExpressionEvaluator({"x": 5})
        assert ev.evaluate("x is not None") is True


class TestEvaluateCondition:
    """Tests for the evaluate_condition convenience function."""

    def test_true_condition(self) -> None:
        assert evaluate_condition("x > 0", {"x": 5}) is True

    def test_false_condition(self) -> None:
        assert evaluate_condition("x > 0", {"x": -1}) is False

    def test_no_namespace(self) -> None:
        assert evaluate_condition("1 == 1") is True

    def test_raises_on_error(self) -> None:
        with pytest.raises(ExpressionError):
            evaluate_condition("undefined_var > 0")
