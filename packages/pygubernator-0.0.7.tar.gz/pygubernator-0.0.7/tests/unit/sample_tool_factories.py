"""Sample tools/factories used by unit tests."""

from __future__ import annotations

from typing import Any

from pygubernator.tools._decorator import tool


@tool(name="unit_echo", description="Echo a value")
async def unit_echo(value: str) -> dict[str, Any]:
    return {"value": value}


@tool(name="unit_sum", description="Sum two integers")
async def unit_sum(a: int, b: int) -> dict[str, Any]:
    return {"total": a + b}


def create_unit_tools(prefix: str = "") -> list[Any]:
    """Return two decorated tools for factory-loading tests."""
    if prefix:
        # Keep output deterministic while proving args are accepted.
        @tool(name=f"{prefix}_echo", description="Echo a value")
        async def prefixed_echo(value: str) -> dict[str, Any]:
            return {"value": value}

        @tool(name=f"{prefix}_sum", description="Sum two integers")
        async def prefixed_sum(a: int, b: int) -> dict[str, Any]:
            return {"total": a + b}

        return [prefixed_echo, prefixed_sum]
    return [unit_echo, unit_sum]


def create_invalid_tools() -> list[Any]:
    """Return invalid objects to verify validation behavior."""
    return [object(), {"not": "a tool"}]
