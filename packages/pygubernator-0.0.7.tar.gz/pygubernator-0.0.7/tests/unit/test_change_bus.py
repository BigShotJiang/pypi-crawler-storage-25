"""Tests for the config-change event bus (real-time collaboration)."""

from __future__ import annotations

import time

import pytest

from pygubernator.events import ChangeBus, ChangeEvent

# -- ChangeEvent tests ------------------------------------------------


class TestChangeEvent:
    """Tests for the ChangeEvent frozen dataclass."""

    def test_creation_with_defaults(self) -> None:
        event = ChangeEvent(
            topic="workflow",
            action="saved",
            resource_id="wf-1",
        )
        assert event.topic == "workflow"
        assert event.action == "saved"
        assert event.resource_id == "wf-1"
        assert event.revision == 0
        assert event.actor == "system"
        assert event.metadata == {}
        assert isinstance(event.timestamp, float)

    def test_creation_with_explicit_values(self) -> None:
        ts = time.time()
        event = ChangeEvent(
            topic="agent",
            action="deleted",
            resource_id="ag-99",
            revision=5,
            actor="alice",
            timestamp=ts,
            metadata={"reason": "cleanup"},
        )
        assert event.revision == 5
        assert event.actor == "alice"
        assert event.timestamp == ts
        assert event.metadata == {"reason": "cleanup"}

    def test_frozen(self) -> None:
        event = ChangeEvent(
            topic="workflow",
            action="saved",
            resource_id="wf-1",
        )
        with pytest.raises(AttributeError):
            event.topic = "other"  # type: ignore[misc]

    def test_default_timestamp_is_recent(self) -> None:
        before = time.time()
        event = ChangeEvent(topic="x", action="y", resource_id="z")
        after = time.time()
        assert before <= event.timestamp <= after


# -- ChangeBus tests ---------------------------------------------------


class TestChangeBus:
    """Tests for ChangeBus publish/subscribe mechanics."""

    def test_subscribe_and_publish(self) -> None:
        bus = ChangeBus()
        received: list[ChangeEvent] = []
        bus.subscribe("workflow", received.append)

        event = ChangeEvent(
            topic="workflow",
            action="saved",
            resource_id="wf-1",
        )
        bus.publish(event)

        assert len(received) == 1
        assert received[0] is event

    def test_wildcard_receives_all_topics(self) -> None:
        bus = ChangeBus()
        received: list[ChangeEvent] = []
        bus.subscribe("*", received.append)

        bus.publish(
            ChangeEvent(
                topic="workflow",
                action="saved",
                resource_id="wf-1",
            )
        )
        bus.publish(
            ChangeEvent(
                topic="agent",
                action="updated",
                resource_id="ag-2",
            )
        )

        assert len(received) == 2
        assert received[0].topic == "workflow"
        assert received[1].topic == "agent"

    def test_topic_filtering(self) -> None:
        bus = ChangeBus()
        wf_events: list[ChangeEvent] = []
        ag_events: list[ChangeEvent] = []
        bus.subscribe("workflow", wf_events.append)
        bus.subscribe("agent", ag_events.append)

        bus.publish(
            ChangeEvent(
                topic="workflow",
                action="saved",
                resource_id="wf-1",
            )
        )
        bus.publish(
            ChangeEvent(
                topic="agent",
                action="updated",
                resource_id="ag-2",
            )
        )

        assert len(wf_events) == 1
        assert len(ag_events) == 1

    def test_unsubscribe(self) -> None:
        bus = ChangeBus()
        received: list[ChangeEvent] = []
        bus.subscribe("workflow", received.append)
        bus.unsubscribe("workflow", received.append)

        bus.publish(
            ChangeEvent(
                topic="workflow",
                action="saved",
                resource_id="wf-1",
            )
        )
        assert len(received) == 0

    def test_unsubscribe_unknown_callback_is_noop(self) -> None:
        bus = ChangeBus()
        bus.unsubscribe("workflow", lambda e: None)  # no error

    def test_subscriber_count(self) -> None:
        bus = ChangeBus()
        assert bus.subscriber_count == 0

        cb1 = lambda e: None  # noqa: E731
        cb2 = lambda e: None  # noqa: E731
        bus.subscribe("workflow", cb1)
        bus.subscribe("agent", cb2)
        assert bus.subscriber_count == 2

        bus.unsubscribe("workflow", cb1)
        assert bus.subscriber_count == 1

    def test_multiple_subscribers_same_topic(self) -> None:
        bus = ChangeBus()
        r1: list[ChangeEvent] = []
        r2: list[ChangeEvent] = []
        bus.subscribe("workflow", r1.append)
        bus.subscribe("workflow", r2.append)

        bus.publish(
            ChangeEvent(
                topic="workflow",
                action="saved",
                resource_id="wf-1",
            )
        )
        assert len(r1) == 1
        assert len(r2) == 1

    def test_callback_exception_does_not_block_others(
        self,
    ) -> None:
        bus = ChangeBus()
        received: list[ChangeEvent] = []

        def _bad(event: ChangeEvent) -> None:
            raise RuntimeError("boom")

        bus.subscribe("workflow", _bad)
        bus.subscribe("workflow", received.append)

        bus.publish(
            ChangeEvent(
                topic="workflow",
                action="saved",
                resource_id="wf-1",
            )
        )
        # Second subscriber still received the event
        assert len(received) == 1

    def test_wildcard_plus_topic_receives_once(self) -> None:
        """A wildcard subscriber + topic subscriber = two calls."""
        bus = ChangeBus()
        all_events: list[ChangeEvent] = []
        wf_events: list[ChangeEvent] = []
        bus.subscribe("*", all_events.append)
        bus.subscribe("workflow", wf_events.append)

        bus.publish(
            ChangeEvent(
                topic="workflow",
                action="saved",
                resource_id="wf-1",
            )
        )
        assert len(all_events) == 1
        assert len(wf_events) == 1

    def test_no_subscribers_is_noop(self) -> None:
        bus = ChangeBus()
        bus.publish(
            ChangeEvent(
                topic="workflow",
                action="saved",
                resource_id="wf-1",
            )
        )  # should not raise
