"""Tests for DELETE endpoints (workflow soft-delete, agent archive)."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from pygubernator.api.main import create_app
from tests.unit.conftest import reset_test_db


def _headers() -> dict[str, str]:
    return {
        "X-API-Token": "dev-token",
        "X-Actor": "test",
        "X-Role": "admin",
    }


@pytest.fixture(autouse=True)
def _reset_db() -> None:
    reset_test_db()


class TestDeleteWorkflow:
    """Tests for DELETE /api/v1/workflows/{id}."""

    def test_delete_workflow_not_found(self):
        """Returns 404 when workflow does not exist."""
        client = TestClient(create_app())
        resp = client.delete(
            "/api/v1/workflows/no-such-id",
            headers=_headers(),
        )
        assert resp.status_code == 404

    def test_delete_workflow_sets_status_deleted(self):
        """Soft-delete sets status to 'deleted'."""
        client = TestClient(create_app())

        create_resp = client.post(
            "/api/v1/workflows",
            headers=_headers(),
            json={
                "name": "wf-to-delete",
                "description": "test",
                "owner": "system",
            },
        )
        assert create_resp.status_code == 200
        wf_id = create_resp.json()["id"]

        del_resp = client.delete(
            f"/api/v1/workflows/{wf_id}",
            headers=_headers(),
        )
        assert del_resp.status_code == 200
        assert del_resp.json()["status"] == "deleted"

        get_resp = client.get(
            f"/api/v1/workflows/{wf_id}",
            headers=_headers(),
        )
        assert get_resp.json()["status"] == "deleted"


class TestDeleteAgent:
    """Tests for DELETE /api/v1/agents/{id}."""

    def test_delete_agent_not_found(self):
        """Returns 404 when agent does not exist."""
        client = TestClient(create_app())
        resp = client.delete(
            "/api/v1/agents/no-such-id",
            headers=_headers(),
        )
        assert resp.status_code == 404

    def test_delete_agent_sets_archived(self):
        """Soft-delete sets archived to True."""
        client = TestClient(create_app())

        create_resp = client.post(
            "/api/v1/agents",
            headers=_headers(),
            json={
                "name": "agent-to-delete",
                "owner": "system",
                "status": "active",
            },
        )
        assert create_resp.status_code == 200
        agent_id = create_resp.json()["id"]

        del_resp = client.delete(
            f"/api/v1/agents/{agent_id}",
            headers=_headers(),
        )
        assert del_resp.status_code == 200
        assert del_resp.json()["archived"] is True
