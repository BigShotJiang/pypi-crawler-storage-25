"""Tests for Obsidian vault tools (local filesystem mode)."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest

from pygubernator.tools.obsidian_tools import (
    _VaultClient,
    create_obsidian_tools,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_vault(tmp_path: Path) -> Path:
    """Create a temporary vault with sample notes."""
    vault = tmp_path / "vault"
    vault.mkdir()
    (vault / "note1.md").write_text("# Hello\nThis is note one.")
    (vault / "note2.md").write_text("# World\nAnother note here.")
    sub = vault / "subfolder"
    sub.mkdir()
    (sub / "deep.md").write_text("# Deep\nNested note content.")
    return vault


def _get_tool(tools: list[Any], name: str) -> Any:
    """Find a tool by name."""
    return next(t for t in tools if t.name == name)


# ---------------------------------------------------------------------------
# _VaultClient creation
# ---------------------------------------------------------------------------


class TestVaultClientCreation:
    """Tests for _VaultClient constructor."""

    def test_creates_with_valid_path(self, tmp_path: Path) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        assert client._vault == vault.resolve()

    def test_rejects_nonexistent_path(self, tmp_path: Path) -> None:
        bad = tmp_path / "nope"
        with pytest.raises(ValueError, match="does not exist"):
            _VaultClient(str(bad))

    def test_api_mode_flag(self, tmp_path: Path) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(
            str(vault),
            api_url="http://localhost:27124",
            api_key="secret",
        )
        assert client._use_api is True

    def test_local_mode_by_default(self, tmp_path: Path) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        assert client._use_api is False


# ---------------------------------------------------------------------------
# _safe_path
# ---------------------------------------------------------------------------


class TestSafePath:
    """Tests for path traversal prevention."""

    def test_valid_relative_path(self, tmp_path: Path) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        result = client._safe_path("note1.md")
        assert result == vault.resolve() / "note1.md"

    def test_rejects_traversal(self, tmp_path: Path) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        with pytest.raises(ValueError, match="Path traversal"):
            client._safe_path("../../etc/passwd")

    def test_rejects_absolute_escape(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        with pytest.raises(ValueError, match="Path traversal"):
            client._safe_path("/etc/passwd")

    def test_subfolder_path_ok(self, tmp_path: Path) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        result = client._safe_path("subfolder/deep.md")
        assert result.is_relative_to(vault.resolve())


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------


class TestReadNote:
    """Tests for reading notes."""

    @pytest.mark.asyncio
    async def test_reads_content(self, tmp_path: Path) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        result = await client.read_note("note1.md")
        assert result["path"] == "note1.md"
        assert "Hello" in result["content"]
        assert result["size"] > 0

    @pytest.mark.asyncio
    async def test_read_missing_file(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        with pytest.raises(FileNotFoundError):
            await client.read_note("missing.md")


# ---------------------------------------------------------------------------
# Write
# ---------------------------------------------------------------------------


class TestWriteNote:
    """Tests for writing notes."""

    @pytest.mark.asyncio
    async def test_creates_new_note(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        result = await client.write_note(
            "new.md",
            "# New\nContent",
        )
        assert result["created"] is True
        assert result["size"] == len("# New\nContent")
        assert (vault / "new.md").read_text() == "# New\nContent"

    @pytest.mark.asyncio
    async def test_overwrites_existing(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        result = await client.write_note("note1.md", "Replaced")
        assert result["created"] is False
        assert (vault / "note1.md").read_text() == "Replaced"

    @pytest.mark.asyncio
    async def test_creates_parent_dirs(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        await client.write_note("a/b/c.md", "Deep")
        assert (vault / "a" / "b" / "c.md").read_text() == "Deep"


# ---------------------------------------------------------------------------
# Append
# ---------------------------------------------------------------------------


class TestAppendNote:
    """Tests for appending to notes."""

    @pytest.mark.asyncio
    async def test_appends_content(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        original = (vault / "note1.md").read_text()
        result = await client.append_note("note1.md", "\nExtra")
        assert result["appended_size"] == len("\nExtra")
        updated = (vault / "note1.md").read_text()
        assert updated == original + "\nExtra"


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


class TestSearch:
    """Tests for searching notes."""

    @pytest.mark.asyncio
    async def test_finds_matching_notes(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        results = await client.search("note")
        paths = {r["path"] for r in results}
        assert "note1.md" in paths
        assert "note2.md" in paths

    @pytest.mark.asyncio
    async def test_case_insensitive(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        results = await client.search("HELLO")
        assert len(results) >= 1
        assert results[0]["path"] == "note1.md"

    @pytest.mark.asyncio
    async def test_respects_limit(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        results = await client.search("note", limit=1)
        assert len(results) == 1

    @pytest.mark.asyncio
    async def test_returns_snippet(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        results = await client.search("Hello")
        match = next(r for r in results if r["path"] == "note1.md")
        assert "Hello" in match["snippet"]

    @pytest.mark.asyncio
    async def test_no_results(self, tmp_path: Path) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        results = await client.search("xyznonexistent")
        assert results == []


# ---------------------------------------------------------------------------
# List notes
# ---------------------------------------------------------------------------


class TestListNotes:
    """Tests for listing notes."""

    @pytest.mark.asyncio
    async def test_lists_all_notes(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        results = await client.list_notes()
        paths = {r["path"] for r in results}
        assert "note1.md" in paths
        assert "note2.md" in paths
        assert any("deep.md" in p for p in paths)

    @pytest.mark.asyncio
    async def test_list_with_folder_filter(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        results = await client.list_notes(folder="subfolder")
        paths = {r["path"] for r in results}
        assert all("subfolder" in p for p in paths)
        assert len(results) == 1

    @pytest.mark.asyncio
    async def test_non_recursive(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        results = await client.list_notes(recursive=False)
        paths = {r["path"] for r in results}
        assert "note1.md" in paths
        assert "note2.md" in paths
        # Deep note should not appear
        assert not any("deep.md" in p for p in paths)

    @pytest.mark.asyncio
    async def test_includes_size(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        results = await client.list_notes()
        for r in results:
            assert "size" in r
            assert r["size"] > 0


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------


class TestDeleteNote:
    """Tests for deleting notes."""

    @pytest.mark.asyncio
    async def test_deletes_file(self, tmp_path: Path) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        assert (vault / "note1.md").exists()
        result = await client.delete_note("note1.md")
        assert result["deleted"] is True
        assert not (vault / "note1.md").exists()

    @pytest.mark.asyncio
    async def test_delete_missing_raises(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        client = _VaultClient(str(vault))
        with pytest.raises(FileNotFoundError):
            await client.delete_note("gone.md")


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestObsidianToolsFactory:
    """Tests for create_obsidian_tools factory."""

    def test_returns_six_tools(self, tmp_path: Path) -> None:
        vault = _make_vault(tmp_path)
        tools = create_obsidian_tools(str(vault))
        assert len(tools) == 6

    def test_tool_names(self, tmp_path: Path) -> None:
        vault = _make_vault(tmp_path)
        tools = create_obsidian_tools(str(vault))
        names = {t.name for t in tools}
        assert names == {
            "obsidian_read_note",
            "obsidian_write_note",
            "obsidian_append_note",
            "obsidian_search",
            "obsidian_list_notes",
            "obsidian_delete_note",
        }

    def test_all_tools_have_schemas(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        tools = create_obsidian_tools(str(vault))
        for t in tools:
            schema = t.parameters_schema
            assert schema["type"] == "object"
            assert "properties" in schema

    def test_all_tools_have_descriptions(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        tools = create_obsidian_tools(str(vault))
        for t in tools:
            assert t.description, f"{t.name} has no description"


# ---------------------------------------------------------------------------
# Tool execution (end-to-end via @tool wrappers)
# ---------------------------------------------------------------------------


class TestObsidianToolExecution:
    """Tests for executing tools through the @tool decorator."""

    @pytest.mark.asyncio
    async def test_read_note_tool(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        tools = create_obsidian_tools(str(vault))
        t = _get_tool(tools, "obsidian_read_note")
        result = await t.execute({"path": "note1.md"})
        assert result.success
        assert "Hello" in result.output["content"]

    @pytest.mark.asyncio
    async def test_write_note_tool(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        tools = create_obsidian_tools(str(vault))
        t = _get_tool(tools, "obsidian_write_note")
        result = await t.execute(
            {"path": "fresh.md", "content": "# Fresh"},
        )
        assert result.success
        assert result.output["created"] is True

    @pytest.mark.asyncio
    async def test_search_tool(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        tools = create_obsidian_tools(str(vault))
        t = _get_tool(tools, "obsidian_search")
        result = await t.execute({"query": "Hello"})
        assert result.success
        assert len(result.output) >= 1

    @pytest.mark.asyncio
    async def test_error_returns_failure(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        tools = create_obsidian_tools(str(vault))
        t = _get_tool(tools, "obsidian_read_note")
        result = await t.execute({"path": "missing.md"})
        assert not result.success
        assert result.error is not None


# ---------------------------------------------------------------------------
# Factory from env
# ---------------------------------------------------------------------------


class TestObsidianFactory:
    """Tests for create_tools_from_env."""

    def test_missing_vault_raises(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.delenv(
            "PYGUBERNATOR_OBSIDIAN_VAULT_PATH",
            raising=False,
        )
        from pygubernator.tools import obsidian_factory

        with pytest.raises(ValueError):
            obsidian_factory.create_tools_from_env()

    def test_uses_env_vault_path(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        seen: dict[str, Any] = {}

        def fake_create(
            vault_path: str,
            api_url: str | None = None,
            api_key: str | None = None,
        ) -> list[Any]:
            seen["vault_path"] = vault_path
            seen["api_url"] = api_url
            seen["api_key"] = api_key
            return []

        monkeypatch.setenv(
            "PYGUBERNATOR_OBSIDIAN_VAULT_PATH",
            str(vault),
        )
        from pygubernator.tools import obsidian_factory

        monkeypatch.setattr(
            obsidian_factory,
            "create_obsidian_tools",
            fake_create,
        )
        tools = obsidian_factory.create_tools_from_env()
        assert tools == []
        assert seen["vault_path"] == str(vault)
        assert seen["api_url"] is None

    def test_passes_api_env_vars(
        self,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        seen: dict[str, Any] = {}

        def fake_create(
            vault_path: str,
            api_url: str | None = None,
            api_key: str | None = None,
        ) -> list[Any]:
            seen["api_url"] = api_url
            seen["api_key"] = api_key
            return []

        monkeypatch.setenv(
            "PYGUBERNATOR_OBSIDIAN_VAULT_PATH",
            str(vault),
        )
        monkeypatch.setenv(
            "PYGUBERNATOR_OBSIDIAN_API_URL",
            "http://localhost:27124",
        )
        monkeypatch.setenv(
            "PYGUBERNATOR_OBSIDIAN_API_KEY",
            "mykey",
        )
        from pygubernator.tools import obsidian_factory

        monkeypatch.setattr(
            obsidian_factory,
            "create_obsidian_tools",
            fake_create,
        )
        obsidian_factory.create_tools_from_env()
        assert seen["api_url"] == "http://localhost:27124"
        assert seen["api_key"] == "mykey"


# ---------------------------------------------------------------------------
# Missing dependency
# ---------------------------------------------------------------------------


class TestMissingDeps:
    """Tests for missing aiofiles dependency."""

    def test_missing_aiofiles_raises(
        self,
        tmp_path: Path,
    ) -> None:
        vault = _make_vault(tmp_path)
        with (
            patch(
                "pygubernator.tools.obsidian_tools._HAS_AIOFILES",
                False,
            ),
            pytest.raises(ImportError, match="aiofiles"),
        ):
            _VaultClient(str(vault))
