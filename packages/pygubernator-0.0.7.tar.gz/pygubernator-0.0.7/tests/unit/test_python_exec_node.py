"""Tests for PythonExecNode workflow node."""

from __future__ import annotations

import pytest

from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._python_exec import (
    PythonExecNode,
    PythonExecNodeFactory,
)


def _ctx(
    input_data: dict | None = None,
    variables: dict | None = None,
    config: dict | None = None,
) -> NodeContext:
    """Build a NodeContext for testing."""
    return NodeContext(
        node_id="test",
        input_data=input_data or {},
        variables=variables or {},
        config=config or {},
    )


class TestPythonExecNodeBasic:
    """Basic execution tests."""

    @pytest.mark.asyncio
    async def test_simple_assignment(self) -> None:
        node = PythonExecNode("n1", config={"code": "result = 42"})
        res = await node.execute(_ctx())
        assert res.status == NodeStatus.SUCCESS
        assert res.output["result"] == 42

    @pytest.mark.asyncio
    async def test_input_data_accessible(self) -> None:
        node = PythonExecNode(
            "n1",
            config={"code": "result = input_data['x'] * 2"},
        )
        res = await node.execute(_ctx(input_data={"x": 5}))
        assert res.status == NodeStatus.SUCCESS
        assert res.output["result"] == 10

    @pytest.mark.asyncio
    async def test_variables_accessible(self) -> None:
        node = PythonExecNode(
            "n1",
            config={"code": "result = variables.get('mode', 'default')"},
        )
        res = await node.execute(_ctx(variables={"mode": "test"}))
        assert res.output["result"] == "test"

    @pytest.mark.asyncio
    async def test_user_vars_in_output(self) -> None:
        node = PythonExecNode(
            "n1",
            config={"code": "my_var = 'hello'\nresult = 1"},
        )
        res = await node.execute(_ctx())
        assert res.output["result"] == 1
        assert res.output["my_var"] == "hello"

    @pytest.mark.asyncio
    async def test_no_code_fails(self) -> None:
        node = PythonExecNode("n1", config={})
        res = await node.execute(_ctx())
        assert res.status == NodeStatus.FAILED
        assert "No code" in res.error

    @pytest.mark.asyncio
    async def test_syntax_error_fails(self) -> None:
        node = PythonExecNode("n1", config={"code": "def ("})
        res = await node.execute(_ctx())
        assert res.status == NodeStatus.FAILED
        assert "failed" in res.error.lower()

    @pytest.mark.asyncio
    async def test_runtime_error_fails(self) -> None:
        node = PythonExecNode("n1", config={"code": "result = 1 / 0"})
        res = await node.execute(_ctx())
        assert res.status == NodeStatus.FAILED
        assert "failed" in res.error.lower()


class TestPythonExecNodeImports:
    """Tests for import functionality."""

    @pytest.mark.asyncio
    async def test_import_stdlib(self) -> None:
        node = PythonExecNode(
            "n1",
            config={"code": "import json\nresult = json.dumps({'a': 1})"},
        )
        res = await node.execute(_ctx())
        assert res.status == NodeStatus.SUCCESS
        assert res.output["result"] == '{"a": 1}'

    @pytest.mark.asyncio
    async def test_allowed_imports_permits(self) -> None:
        node = PythonExecNode(
            "n1",
            config={
                "allowed_imports": ["json"],
                "code": "import json\nresult = json.loads('[1,2]')",
            },
        )
        res = await node.execute(_ctx())
        assert res.status == NodeStatus.SUCCESS
        assert res.output["result"] == [1, 2]

    @pytest.mark.asyncio
    async def test_allowed_imports_blocks(self) -> None:
        node = PythonExecNode(
            "n1",
            config={
                "allowed_imports": ["json"],
                "code": "import os\nresult = os.getcwd()",
            },
        )
        res = await node.execute(_ctx())
        assert res.status == NodeStatus.FAILED
        assert "import" in res.error.lower()

    @pytest.mark.asyncio
    async def test_unrestricted_imports(self) -> None:
        node = PythonExecNode(
            "n1",
            config={
                "code": "import os\nresult = os.path.exists('/')",
            },
        )
        res = await node.execute(_ctx())
        assert res.status == NodeStatus.SUCCESS
        assert res.output["result"] is True

    @pytest.mark.asyncio
    async def test_import_pycatalyst(self) -> None:
        """Verify pycatalyst can be imported and used."""
        node = PythonExecNode(
            "n1",
            config={
                "allowed_imports": ["pycatalyst"],
                "code": (
                    "from pycatalyst import SchemaBuilder, GenerationEngine\n"
                    "schema = SchemaBuilder('test').add_int('x').build()\n"
                    "engine = GenerationEngine()\n"
                    "gen = engine.generate(schema, count=3, seed=42)\n"
                    "result = list(gen.records)\n"
                ),
            },
        )
        res = await node.execute(_ctx())
        assert res.status == NodeStatus.SUCCESS
        assert len(res.output["result"]) == 3
        assert all("x" in r for r in res.output["result"])

    @pytest.mark.asyncio
    async def test_import_pystator(self) -> None:
        """Verify pystator can be imported and used."""
        node = PythonExecNode(
            "n1",
            config={
                "allowed_imports": ["pystator"],
                "code": (
                    "from pystator import StateMachine\n"
                    "m = StateMachine.from_dict({\n"
                    "    'states': [\n"
                    "        {'name': 'a', 'type': 'initial'},\n"
                    "        {'name': 'b', 'type': 'terminal'},\n"
                    "    ],\n"
                    "    'transitions': [\n"
                    "        {'trigger': 'go', 'source': 'a', 'dest': 'b'},\n"
                    "    ],\n"
                    "})\n"
                    "s = m.create()\n"
                    "s.send('go')\n"
                    "result = s.current_state\n"
                ),
            },
        )
        res = await node.execute(_ctx())
        assert res.status == NodeStatus.SUCCESS
        assert res.output["result"] == "b"


class TestPythonExecNodeFactory:
    """Tests for the factory."""

    def test_creates_node(self) -> None:
        factory = PythonExecNodeFactory()
        node = factory.create("n1", {"code": "result = 1"})
        assert isinstance(node, PythonExecNode)
        assert node.node_type == "python_exec"
