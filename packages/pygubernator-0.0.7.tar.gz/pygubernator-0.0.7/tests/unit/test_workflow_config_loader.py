"""Tests for WorkflowLoader."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from pygubernator.errors import ConfigError
from pygubernator.workflow._types import WorkflowSpec
from pygubernator.workflow.config._loader import WorkflowLoader


@pytest.fixture()
def simple_yaml(tmp_path: Path) -> Path:
    """Create a simple valid workflow YAML file."""
    content = """\
meta:
  name: test-workflow
  version: "1.0.0"
  description: A test workflow

nodes:
  start:
    type: input
    config: {}
  end:
    type: output
    config: {}

edges:
  - source: start
    target: end
"""
    f = tmp_path / "test_workflow.yaml"
    f.write_text(content)
    return f


@pytest.fixture()
def env_var_yaml(tmp_path: Path) -> Path:
    """Create a YAML file with env var references."""
    content = """\
meta:
  name: ${WF_NAME:-default-workflow}
  version: "1.0.0"

nodes:
  start:
    type: input
    config: {}
  end:
    type: output
    config: {}

edges:
  - source: start
    target: end
"""
    f = tmp_path / "env_workflow.yaml"
    f.write_text(content)
    return f


class TestWorkflowLoader:
    """Tests for the WorkflowLoader."""

    def test_load_valid_yaml(self, simple_yaml: Path) -> None:
        loader = WorkflowLoader()
        spec = loader.load(simple_yaml)
        assert isinstance(spec, WorkflowSpec)
        assert spec.name == "test-workflow"
        assert spec.version == "1.0.0"
        assert len(spec.nodes) == 2
        assert len(spec.edges) == 1

    def test_load_file_not_found(self) -> None:
        loader = WorkflowLoader()
        with pytest.raises(ConfigError, match="not found"):
            loader.load("/nonexistent/path.yaml")

    def test_load_invalid_yaml(self, tmp_path: Path) -> None:
        bad = tmp_path / "bad.yaml"
        bad.write_text(":\n  invalid: [yaml\n")
        loader = WorkflowLoader()
        with pytest.raises(ConfigError, match="parse YAML"):
            loader.load(bad)

    def test_load_non_mapping(self, tmp_path: Path) -> None:
        f = tmp_path / "list.yaml"
        f.write_text("- item1\n- item2\n")
        loader = WorkflowLoader()
        with pytest.raises(ConfigError, match="mapping"):
            loader.load(f)

    def test_load_invalid_config(self, tmp_path: Path) -> None:
        f = tmp_path / "invalid.yaml"
        f.write_text("meta:\n  name: test\nnodes: {}\nedges: []\n")
        loader = WorkflowLoader()
        # Should fail because nodes is empty but that's fine for pydantic
        # Actually empty nodes is valid, just load it
        spec = loader.load(f)
        assert spec.name == "test"

    def test_load_dict(self) -> None:
        loader = WorkflowLoader()
        spec = loader.load_dict(
            {
                "meta": {"name": "dict-wf"},
                "nodes": {
                    "in": {"type": "input"},
                    "out": {"type": "output"},
                },
                "edges": [{"source": "in", "target": "out"}],
            }
        )
        assert spec.name == "dict-wf"

    def test_env_var_default(self, env_var_yaml: Path) -> None:
        loader = WorkflowLoader()
        # WF_NAME is not set, should use default
        os.environ.pop("WF_NAME", None)
        spec = loader.load(env_var_yaml)
        assert spec.name == "default-workflow"

    def test_env_var_set(
        self, env_var_yaml: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("WF_NAME", "my-workflow")
        loader = WorkflowLoader()
        spec = loader.load(env_var_yaml)
        assert spec.name == "my-workflow"

    def test_env_var_required_missing(self, tmp_path: Path) -> None:
        f = tmp_path / "req.yaml"
        f.write_text(
            "meta:\n  name: ${REQUIRED_VAR:?must be set}\n"
            "nodes:\n  n: {type: input}\nedges: []\n"
        )
        loader = WorkflowLoader()
        os.environ.pop("REQUIRED_VAR", None)
        with pytest.raises(ConfigError, match="must be set"):
            loader.load(f)

    def test_env_var_unset_no_default(self, tmp_path: Path) -> None:
        f = tmp_path / "nodefault.yaml"
        f.write_text(
            "meta:\n  name: ${UNSET_VAR}\nnodes:\n  n: {type: input}\nedges: []\n"
        )
        loader = WorkflowLoader()
        os.environ.pop("UNSET_VAR", None)
        with pytest.raises(ConfigError, match="not set"):
            loader.load(f)
