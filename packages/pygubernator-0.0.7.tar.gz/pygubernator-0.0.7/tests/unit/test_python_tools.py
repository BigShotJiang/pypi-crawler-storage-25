"""Tests for Python execution tools."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from pygubernator.tools import python_factory
from pygubernator.tools.python_tools import (
    _PythonExecutor,
    create_python_tools,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_tool(tools: list[Any], name: str) -> Any:
    """Find a tool by name."""
    return next(t for t in tools if t.name == name)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestPythonToolsFactory:
    """Tests for create_python_tools factory."""

    def test_returns_three_tools(self) -> None:
        tools = create_python_tools()
        assert len(tools) == 3

    def test_tool_names(self) -> None:
        tools = create_python_tools()
        names = {t.name for t in tools}
        assert names == {
            "python_exec",
            "python_eval",
            "python_install",
        }

    def test_all_tools_have_schemas(self) -> None:
        tools = create_python_tools()
        for t in tools:
            schema = t.parameters_schema
            assert schema["type"] == "object"
            assert "properties" in schema


# ---------------------------------------------------------------------------
# _PythonExecutor unit tests
# ---------------------------------------------------------------------------


class TestPythonExecutor:
    """Tests for the _PythonExecutor class."""

    def test_exec_simple(self) -> None:
        executor = _PythonExecutor()
        result = executor.exec_code("result = 1 + 1")
        assert result["result"] == 2

    def test_exec_with_variables(self) -> None:
        executor = _PythonExecutor()
        result = executor.exec_code(
            "result = x + y",
            variables={"x": 10, "y": 20},
        )
        assert result["result"] == 30

    def test_exec_with_import(self) -> None:
        executor = _PythonExecutor()
        code = 'import json; result = json.dumps({"a": 1})'
        result = executor.exec_code(code)
        assert result["result"] == '{"a": 1}'

    def test_exec_user_vars_returned(self) -> None:
        executor = _PythonExecutor()
        code = "a = 1\nb = 2\nresult = a + b"
        result = executor.exec_code(code)
        assert result["variables"]["a"] == 1
        assert result["variables"]["b"] == 2
        assert result["variables"]["result"] == 3

    def test_eval_expression(self) -> None:
        executor = _PythonExecutor()
        value = executor.eval_expression("2 ** 10")
        assert value == 1024

    def test_eval_with_variables(self) -> None:
        executor = _PythonExecutor()
        value = executor.eval_expression(
            "x * y",
            variables={"x": 6, "y": 7},
        )
        assert value == 42

    def test_allowed_imports_permits_listed(self) -> None:
        executor = _PythonExecutor(allowed_imports=["json"])
        result = executor.exec_code('import json; result = json.dumps({"ok": True})')
        assert result["result"] == '{"ok": true}'

    def test_allowed_imports_blocks_unlisted(self) -> None:
        executor = _PythonExecutor(allowed_imports=["json"])
        with pytest.raises(ImportError, match="not allowed"):
            executor.exec_code("import os")

    def test_allowed_imports_blocks_submodule(self) -> None:
        executor = _PythonExecutor(allowed_imports=["json"])
        with pytest.raises(ImportError, match="not allowed"):
            executor.exec_code("import os.path")

    def test_install_package(self) -> None:
        executor = _PythonExecutor()
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Successfully installed foo"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as m:
            result = executor.install_package("foo")

        assert result["success"] is True
        assert "Successfully installed" in result["stdout"]
        m.assert_called_once()

    def test_install_package_failure(self) -> None:
        executor = _PythonExecutor()
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "ERROR: No matching distribution"

        with patch("subprocess.run", return_value=mock_result):
            result = executor.install_package("nonexistent-pkg")

        assert result["success"] is False
        assert "ERROR" in result["stderr"]


# ---------------------------------------------------------------------------
# Tool execution (end-to-end via @tool wrappers)
# ---------------------------------------------------------------------------


class TestPythonToolExecution:
    """Tests for executing tools through the @tool decorator."""

    @pytest.mark.asyncio
    async def test_python_exec(self) -> None:
        tools = create_python_tools()
        t = _get_tool(tools, "python_exec")

        result = await t.execute({"code": "result = 1 + 1"})

        assert result.success
        assert result.output["result"] == 2

    @pytest.mark.asyncio
    async def test_python_exec_with_variables(self) -> None:
        tools = create_python_tools()
        t = _get_tool(tools, "python_exec")

        result = await t.execute(
            {
                "code": "result = x * 2",
                "variables": {"x": 21},
            }
        )

        assert result.success
        assert result.output["result"] == 42

    @pytest.mark.asyncio
    async def test_python_exec_import(self) -> None:
        tools = create_python_tools()
        t = _get_tool(tools, "python_exec")

        result = await t.execute(
            {
                "code": ('import json; result = json.dumps({"a": 1})'),
            }
        )

        assert result.success
        assert result.output["result"] == '{"a": 1}'

    @pytest.mark.asyncio
    async def test_python_eval(self) -> None:
        tools = create_python_tools()
        t = _get_tool(tools, "python_eval")

        result = await t.execute({"expression": "2 ** 10"})

        assert result.success
        assert result.output == 1024

    @pytest.mark.asyncio
    async def test_python_eval_with_variables(self) -> None:
        tools = create_python_tools()
        t = _get_tool(tools, "python_eval")

        result = await t.execute(
            {
                "expression": "a + b",
                "variables": {"a": 3, "b": 4},
            }
        )

        assert result.success
        assert result.output == 7

    @pytest.mark.asyncio
    async def test_python_install(self) -> None:
        tools = create_python_tools()
        t = _get_tool(tools, "python_install")

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Successfully installed bar"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result):
            result = await t.execute({"package": "bar"})

        assert result.success
        assert result.output["success"] is True

    @pytest.mark.asyncio
    async def test_exec_error_returns_failure(self) -> None:
        tools = create_python_tools()
        t = _get_tool(tools, "python_exec")

        result = await t.execute({"code": "raise ValueError('boom')"})

        assert not result.success
        assert "boom" in result.error

    @pytest.mark.asyncio
    async def test_timeout_handling(self) -> None:
        tools = create_python_tools(timeout=1)
        t = _get_tool(tools, "python_exec")

        result = await t.execute(
            {
                "code": ("import time; time.sleep(10); result = 'done'"),
            }
        )

        assert not result.success
        assert result.error is not None


# ---------------------------------------------------------------------------
# Environment factory
# ---------------------------------------------------------------------------


class TestPythonFactory:
    """Tests for the python_factory module."""

    def test_unrestricted_by_default(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.delenv("PYGUBERNATOR_PYTHON_ALLOWED_IMPORTS", raising=False)
        monkeypatch.delenv("PYGUBERNATOR_PYTHON_TIMEOUT", raising=False)

        seen: dict[str, Any] = {}

        def fake_create(
            allowed_imports: list[str] | None = None,
            timeout: int = 30,
        ) -> list[Any]:
            seen["allowed_imports"] = allowed_imports
            seen["timeout"] = timeout
            return []

        monkeypatch.setattr(python_factory, "create_python_tools", fake_create)
        tools = python_factory.create_tools_from_env()

        assert tools == []
        assert seen["allowed_imports"] is None
        assert seen["timeout"] == 30

    def test_allowed_imports_from_env(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv(
            "PYGUBERNATOR_PYTHON_ALLOWED_IMPORTS",
            "json,os,sys",
        )
        monkeypatch.setenv("PYGUBERNATOR_PYTHON_TIMEOUT", "60")

        seen: dict[str, Any] = {}

        def fake_create(
            allowed_imports: list[str] | None = None,
            timeout: int = 30,
        ) -> list[Any]:
            seen["allowed_imports"] = allowed_imports
            seen["timeout"] = timeout
            return []

        monkeypatch.setattr(python_factory, "create_python_tools", fake_create)
        python_factory.create_tools_from_env()

        assert seen["allowed_imports"] == ["json", "os", "sys"]
        assert seen["timeout"] == 60

    def test_empty_imports_means_unrestricted(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("PYGUBERNATOR_PYTHON_ALLOWED_IMPORTS", "")

        seen: dict[str, Any] = {}

        def fake_create(
            allowed_imports: list[str] | None = None,
            timeout: int = 30,
        ) -> list[Any]:
            seen["allowed_imports"] = allowed_imports
            return []

        monkeypatch.setattr(python_factory, "create_python_tools", fake_create)
        python_factory.create_tools_from_env()

        assert seen["allowed_imports"] is None
