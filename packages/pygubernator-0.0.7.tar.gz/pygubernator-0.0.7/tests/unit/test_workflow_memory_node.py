"""Tests for memory node, memory stores, and LLM integration."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pygubernator._types import AgentResult
from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._memory import (
    BufferMemoryStore,
    MemoryNode,
    MemoryNodeFactory,
    MemoryStore,
    WindowMemoryStore,
    create_memory_store,
)

# ---------------------------------------------------------------------------
# MemoryStore protocol conformance
# ---------------------------------------------------------------------------


class TestMemoryStoreProtocol:
    """Verify concrete stores satisfy the MemoryStore protocol."""

    def test_buffer_is_memory_store(self) -> None:
        assert isinstance(BufferMemoryStore(), MemoryStore)

    def test_window_is_memory_store(self) -> None:
        assert isinstance(WindowMemoryStore(), MemoryStore)


# ---------------------------------------------------------------------------
# BufferMemoryStore
# ---------------------------------------------------------------------------


class TestBufferMemoryStore:
    """Tests for the unbounded buffer memory store."""

    def test_empty(self) -> None:
        store = BufferMemoryStore()
        assert store.get_messages() == []

    def test_add_and_get(self) -> None:
        store = BufferMemoryStore()
        msgs = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        store.add_messages(msgs)
        assert store.get_messages() == msgs

    def test_retains_all(self) -> None:
        store = BufferMemoryStore()
        for i in range(20):
            store.add_messages([{"role": "user", "content": str(i)}])
        assert len(store.get_messages()) == 20

    def test_returns_copy(self) -> None:
        store = BufferMemoryStore()
        store.add_messages([{"role": "user", "content": "a"}])
        result = store.get_messages()
        result.clear()
        assert len(store.get_messages()) == 1


# ---------------------------------------------------------------------------
# WindowMemoryStore
# ---------------------------------------------------------------------------


class TestWindowMemoryStore:
    """Tests for the sliding-window memory store."""

    def test_empty(self) -> None:
        store = WindowMemoryStore(window_size=5)
        assert store.get_messages() == []

    def test_returns_last_n(self) -> None:
        store = WindowMemoryStore(window_size=3)
        for i in range(6):
            store.add_messages([{"role": "user", "content": str(i)}])
        result = store.get_messages()
        assert len(result) == 3
        assert result[0]["content"] == "3"
        assert result[-1]["content"] == "5"

    def test_fewer_than_window(self) -> None:
        store = WindowMemoryStore(window_size=10)
        store.add_messages([{"role": "user", "content": "only"}])
        assert len(store.get_messages()) == 1

    def test_returns_copy(self) -> None:
        store = WindowMemoryStore(window_size=5)
        store.add_messages([{"role": "user", "content": "a"}])
        result = store.get_messages()
        result.clear()
        assert len(store.get_messages()) == 1


# ---------------------------------------------------------------------------
# create_memory_store factory
# ---------------------------------------------------------------------------


class TestCreateMemoryStore:
    """Tests for the memory store factory function."""

    def test_default_buffer(self) -> None:
        store = create_memory_store()
        assert isinstance(store, BufferMemoryStore)

    def test_explicit_buffer(self) -> None:
        store = create_memory_store("buffer")
        assert isinstance(store, BufferMemoryStore)

    def test_window(self) -> None:
        store = create_memory_store("window", window_size=5)
        assert isinstance(store, WindowMemoryStore)

    def test_unknown_type_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown memory_type"):
            create_memory_store("unknown")


# ---------------------------------------------------------------------------
# MemoryNode
# ---------------------------------------------------------------------------


class TestMemoryNode:
    """Tests for the MemoryNode workflow node."""

    async def test_creates_store_in_variables(self) -> None:
        node = MemoryNode("mem1", config={})
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        assert "__memory_stores__" in variables
        assert "mem1" in variables["__memory_stores__"]
        assert isinstance(variables["__memory_stores__"]["mem1"], BufferMemoryStore)

    async def test_outputs_history_and_node_id(self) -> None:
        node = MemoryNode("mem1", config={})
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.output["__memory_node_id__"] == "mem1"
        assert result.output["__memory_history__"] == []

    async def test_reuses_existing_store(self) -> None:
        node = MemoryNode("mem1", config={})
        store = BufferMemoryStore()
        store.add_messages([{"role": "user", "content": "prior"}])
        variables: dict = {"__memory_stores__": {"mem1": store}}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert len(result.output["__memory_history__"]) == 1
        assert result.output["__memory_history__"][0]["content"] == "prior"
        # Store object should be the same instance
        assert variables["__memory_stores__"]["mem1"] is store

    async def test_window_store_from_config(self) -> None:
        node = MemoryNode("mem1", config={"memory_type": "window", "window_size": 3})
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        assert isinstance(variables["__memory_stores__"]["mem1"], WindowMemoryStore)

    async def test_invalid_memory_type_fails(self) -> None:
        node = MemoryNode("mem1", config={"memory_type": "bad"})
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.status == NodeStatus.FAILED
        assert "memory_type" in (result.error or "").lower()

    def test_node_type(self) -> None:
        assert MemoryNode.node_type == "memory"


class TestMemoryNodeFactory:
    """Tests for MemoryNodeFactory."""

    def test_create(self) -> None:
        factory = MemoryNodeFactory()
        node = factory.create("mem1", {"memory_type": "buffer"})
        assert isinstance(node, MemoryNode)
        assert node.node_type == "memory"


# ---------------------------------------------------------------------------
# LLMNode + memory integration
# ---------------------------------------------------------------------------


def _mock_provider(response_text: str = "Hello!") -> MagicMock:
    """Create a mock LLM provider."""
    provider = MagicMock()
    provider.chat = AsyncMock(
        return_value=MagicMock(
            content=response_text,
            tool_calls=[],
        ),
    )
    return provider


def _mock_tool_registry() -> MagicMock:
    """Create a mock tool registry."""
    registry = MagicMock()
    registry.list_tools.return_value = []
    registry.get_schemas.return_value = []
    return registry


class TestLLMNodeWithMemory:
    """Tests for LLMNode memory read/write integration."""

    async def test_history_forwarded_to_agent(self) -> None:
        from pygubernator.workflow.nodes._llm import LLMNode

        history = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        node = LLMNode(
            "llm1",
            config={"prompt_template": "Say {{ text }}"},
            llm_provider=_mock_provider(),
            tool_registry=_mock_tool_registry(),
        )
        ctx = NodeContext(
            node_id="llm1",
            input_data={
                "text": "something",
                "__memory_node_id__": "mem1",
                "__memory_history__": history,
            },
        )

        agent_result = AgentResult(
            agent_id="llm_node_llm1",
            success=True,
            messages_processed=1,
            metadata={"response": "OK"},
        )
        with patch("pygubernator.workflow.nodes._llm.LLMAgent") as mock_agent_cls:
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_agent_cls.return_value = mock_agent

            await node.execute(ctx)

            # Verify history was passed to agent.process()
            mock_agent.process.assert_called_once()
            call_kwargs = mock_agent.process.call_args
            assert call_kwargs.kwargs.get("history") == history

    async def test_write_back_to_store(self) -> None:
        from pygubernator.workflow.nodes._llm import LLMNode

        store = BufferMemoryStore()
        node = LLMNode(
            "llm1",
            config={"prompt_template": "Tell me about {{ topic }}"},
            llm_provider=_mock_provider(),
            tool_registry=_mock_tool_registry(),
        )
        variables: dict = {"__memory_stores__": {"mem1": store}}
        ctx = NodeContext(
            node_id="llm1",
            input_data={
                "topic": "cats",
                "__memory_node_id__": "mem1",
                "__memory_history__": [],
            },
            variables=variables,
        )

        agent_result = AgentResult(
            agent_id="llm_node_llm1",
            success=True,
            messages_processed=1,
            metadata={"response": "Cats are great"},
        )
        with patch("pygubernator.workflow.nodes._llm.LLMAgent") as mock_agent_cls:
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_agent_cls.return_value = mock_agent

            result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        messages = store.get_messages()
        assert len(messages) == 2
        assert messages[0]["role"] == "user"
        assert "cats" in messages[0]["content"]
        assert messages[1] == {"role": "assistant", "content": "Cats are great"}

    async def test_no_memory_no_write(self) -> None:
        """LLMNode without memory keys should not attempt store access."""
        from pygubernator.workflow.nodes._llm import LLMNode

        node = LLMNode(
            "llm1",
            config={"prompt_template": "Hello"},
            llm_provider=_mock_provider(),
            tool_registry=_mock_tool_registry(),
        )
        ctx = NodeContext(
            node_id="llm1",
            input_data={},
            variables={},
        )

        agent_result = AgentResult(
            agent_id="llm_node_llm1",
            success=True,
            messages_processed=1,
            metadata={"response": "Hi"},
        )
        with patch("pygubernator.workflow.nodes._llm.LLMAgent") as mock_agent_cls:
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_agent_cls.return_value = mock_agent

            result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        # No __memory_stores__ should have been created
        assert "__memory_stores__" not in ctx.variables


# ---------------------------------------------------------------------------
# LLMAgent history insertion
# ---------------------------------------------------------------------------


class TestLLMAgentHistory:
    """Tests for LLMAgent.process() history parameter."""

    async def test_history_inserted_between_system_and_user(self) -> None:
        from pygubernator._types import Message
        from pygubernator.agents._llm import LLMAgent

        provider = _mock_provider("response")
        # Make chat return an object with no tool calls
        provider.chat = AsyncMock(
            return_value=MagicMock(
                content="response",
                has_tool_calls=False,
                tool_calls=[],
                finish_reason="stop",
            ),
        )
        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            system_prompt="You are helpful",
            max_iterations=1,
        )

        history = [
            {"role": "user", "content": "earlier question"},
            {"role": "assistant", "content": "earlier answer"},
        ]
        message = Message(topic="test", payload={"content": "new question"})

        await agent.process(message, history=history)

        # Inspect the messages arg passed to provider.chat
        call_args = provider.chat.call_args
        messages = call_args.args[0] if call_args.args else call_args.kwargs["messages"]

        assert messages[0] == {"role": "system", "content": "You are helpful"}
        assert messages[1] == {"role": "user", "content": "earlier question"}
        assert messages[2] == {"role": "assistant", "content": "earlier answer"}
        assert messages[3] == {"role": "user", "content": "new question"}

    async def test_no_history_no_extra_messages(self) -> None:
        from pygubernator._types import Message
        from pygubernator.agents._llm import LLMAgent

        provider = _mock_provider("response")
        provider.chat = AsyncMock(
            return_value=MagicMock(
                content="response",
                has_tool_calls=False,
                tool_calls=[],
                finish_reason="stop",
            ),
        )
        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            system_prompt="system",
            max_iterations=1,
        )

        message = Message(topic="test", payload={"content": "hello"})
        await agent.process(message)

        call_args = provider.chat.call_args
        messages = call_args.args[0] if call_args.args else call_args.kwargs["messages"]

        assert len(messages) == 2
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"


# ---------------------------------------------------------------------------
# SqliteMemoryStore
# ---------------------------------------------------------------------------


class TestSqliteMemoryStore:
    """Tests for the SQLite-backed memory store."""

    def test_empty(self, tmp_path) -> None:
        from pygubernator.workflow.nodes._memory_sqlite import SqliteMemoryStore

        store = SqliteMemoryStore(db_path=str(tmp_path / "test.db"))
        assert store.get_messages() == []

    def test_add_and_get(self, tmp_path) -> None:
        from pygubernator.workflow.nodes._memory_sqlite import SqliteMemoryStore

        db = str(tmp_path / "test.db")
        store = SqliteMemoryStore(db_path=db)
        msgs = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        store.add_messages(msgs)
        assert store.get_messages() == msgs

    def test_persistence_across_instances(self, tmp_path) -> None:
        from pygubernator.workflow.nodes._memory_sqlite import SqliteMemoryStore

        db = str(tmp_path / "test.db")
        store1 = SqliteMemoryStore(db_path=db)
        store1.add_messages([{"role": "user", "content": "persisted"}])

        store2 = SqliteMemoryStore(db_path=db)
        assert len(store2.get_messages()) == 1
        assert store2.get_messages()[0]["content"] == "persisted"

    def test_invalid_table_name(self, tmp_path) -> None:
        from pygubernator.workflow.nodes._memory_sqlite import SqliteMemoryStore

        with pytest.raises(ValueError, match="Invalid SQL identifier"):
            SqliteMemoryStore(
                db_path=str(tmp_path / "test.db"),
                table_name="DROP TABLE; --",
            )

    def test_factory(self, tmp_path) -> None:
        from pygubernator.workflow.nodes._memory_sqlite import (
            create_sqlite_store,
        )

        store = create_sqlite_store(
            {"db_path": str(tmp_path / "test.db"), "table_name": "msgs"}
        )
        store.add_messages([{"role": "user", "content": "ok"}])
        assert len(store.get_messages()) == 1


# ---------------------------------------------------------------------------
# create_memory_store — backend routing
# ---------------------------------------------------------------------------


class TestCreateMemoryStoreBackends:
    """Tests for backend routing in create_memory_store."""

    def test_in_memory_default(self) -> None:
        store = create_memory_store()
        assert isinstance(store, BufferMemoryStore)

    def test_in_memory_explicit(self) -> None:
        store = create_memory_store(backend="in_memory")
        assert isinstance(store, BufferMemoryStore)

    def test_unknown_backend_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown memory backend"):
            create_memory_store(backend="nonexistent")

    def test_sqlite_backend(self, tmp_path) -> None:
        store = create_memory_store(
            backend="sqlite",
            config={"db_path": str(tmp_path / "test.db")},
        )
        store.add_messages([{"role": "user", "content": "via factory"}])
        assert len(store.get_messages()) == 1

    def test_postgres_missing_dsn_raises(self) -> None:
        with pytest.raises((ValueError, ImportError)):
            create_memory_store(backend="postgres", config={})

    def test_mongodb_missing_uri_raises(self) -> None:
        with pytest.raises((ValueError, ImportError)):
            create_memory_store(backend="mongodb", config={})


# ---------------------------------------------------------------------------
# MemoryNode with backends
# ---------------------------------------------------------------------------


class TestMemoryNodeBackends:
    """Tests for MemoryNode with different storage backends."""

    async def test_sqlite_backend(self, tmp_path) -> None:
        node = MemoryNode(
            "mem1",
            config={
                "backend": "sqlite",
                "db_path": str(tmp_path / "test.db"),
            },
        )
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        assert result.output["__memory_history__"] == []
        assert "mem1" in variables["__memory_stores__"]

    async def test_unknown_backend_fails(self) -> None:
        node = MemoryNode("mem1", config={"backend": "nonexistent"})
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.status == NodeStatus.FAILED
        assert "Unknown memory backend" in (result.error or "")

    async def test_import_error_fails_gracefully(self) -> None:
        """Missing library produces a clear failure, not a crash."""
        node = MemoryNode(
            "mem1",
            config={"backend": "postgres", "connection_string": "fake"},
        )
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        # Either ImportError (missing psycopg2) or connection error
        assert result.status == NodeStatus.FAILED


# ---------------------------------------------------------------------------
# AgentNode memory integration
# ---------------------------------------------------------------------------


class TestAgentNodeWithMemory:
    """Tests for AgentNode memory read/write integration."""

    async def test_history_forwarded_to_agent(self) -> None:
        """Verify __memory_history__ is passed to agent.process()."""
        from pygubernator.workflow.nodes._agent import AgentNode

        history = [
            {"role": "user", "content": "previous question"},
            {"role": "assistant", "content": "previous answer"},
        ]
        node = AgentNode(
            "agent1",
            config={
                "model_name": "ollama/test",
                "prompt_template": "Say {{ text }}",
            },
        )
        ctx = NodeContext(
            node_id="agent1",
            input_data={
                "text": "something",
                "__memory_node_id__": "mem1",
                "__memory_history__": history,
            },
        )

        agent_result = AgentResult(
            agent_id="agent_node_agent1",
            success=True,
            messages_processed=1,
            metadata={"response": "OK", "tool_results": [], "iterations": 1},
        )
        with (
            patch.object(
                node, "_resolve_provider", return_value=(_mock_provider(), None)
            ),
            patch("pygubernator.workflow.nodes._agent.LLMAgent") as mock_agent_cls,
        ):
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_agent_cls.return_value = mock_agent

            await node.execute(ctx)

            mock_agent.process.assert_called_once()
            call_kwargs = mock_agent.process.call_args
            assert call_kwargs.kwargs.get("history") == history

    async def test_write_back_to_store(self) -> None:
        """Verify user+assistant messages are written to the memory store."""
        from pygubernator.workflow.nodes._agent import AgentNode

        store = BufferMemoryStore()
        node = AgentNode(
            "agent1",
            config={
                "model_name": "ollama/test",
                "prompt_template": "Tell me about {{ topic }}",
            },
        )
        variables: dict = {"__memory_stores__": {"mem1": store}}
        ctx = NodeContext(
            node_id="agent1",
            input_data={
                "topic": "dogs",
                "__memory_node_id__": "mem1",
                "__memory_history__": [],
            },
            variables=variables,
        )

        agent_result = AgentResult(
            agent_id="agent_node_agent1",
            success=True,
            messages_processed=1,
            metadata={
                "response": "Dogs are loyal",
                "tool_results": [],
                "iterations": 1,
            },
        )
        with (
            patch.object(
                node, "_resolve_provider", return_value=(_mock_provider(), None)
            ),
            patch("pygubernator.workflow.nodes._agent.LLMAgent") as mock_agent_cls,
        ):
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_agent_cls.return_value = mock_agent

            result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        messages = store.get_messages()
        assert len(messages) == 2
        assert messages[0]["role"] == "user"
        assert "dogs" in messages[0]["content"]
        assert messages[1] == {"role": "assistant", "content": "Dogs are loyal"}

    async def test_no_memory_no_write(self) -> None:
        """AgentNode without memory keys should not attempt store access."""
        from pygubernator.workflow.nodes._agent import AgentNode

        node = AgentNode(
            "agent1",
            config={
                "model_name": "ollama/test",
                "prompt_template": "Hello",
            },
        )
        ctx = NodeContext(
            node_id="agent1",
            input_data={},
            variables={},
        )

        agent_result = AgentResult(
            agent_id="agent_node_agent1",
            success=True,
            messages_processed=1,
            metadata={"response": "Hi", "tool_results": [], "iterations": 1},
        )
        with (
            patch.object(
                node, "_resolve_provider", return_value=(_mock_provider(), None)
            ),
            patch("pygubernator.workflow.nodes._agent.LLMAgent") as mock_agent_cls,
        ):
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_agent_cls.return_value = mock_agent

            result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        assert "__memory_stores__" not in ctx.variables


# ---------------------------------------------------------------------------
# Session-aware memory stores
# ---------------------------------------------------------------------------


class TestMemoryNodeSessions:
    """Tests for multi-turn session support in MemoryNode."""

    async def test_session_creates_cached_store(self) -> None:
        """With __session_id__, in-memory store is cached globally."""
        from pygubernator.workflow.nodes._memory import _SESSION_STORES

        node = MemoryNode("mem1", config={"backend": "in_memory"})
        variables: dict = {"__session_id__": "sess-aaa"}
        ctx = NodeContext(node_id="mem1", variables=variables)

        result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        assert "sess-aaa:mem1" in _SESSION_STORES
        # Cleanup
        del _SESSION_STORES["sess-aaa:mem1"]

    async def test_session_reuses_across_runs(self) -> None:
        """Same session_id across separate runs reuses the store."""
        from pygubernator.workflow.nodes._memory import _SESSION_STORES

        node = MemoryNode("mem1", config={"backend": "in_memory"})

        # First run — empty history
        vars1: dict = {"__session_id__": "sess-bbb"}
        ctx1 = NodeContext(node_id="mem1", variables=vars1)
        r1 = await node.execute(ctx1)
        assert r1.output["__memory_history__"] == []

        # Simulate write-back (LLMNode would do this)
        store = vars1["__memory_stores__"]["mem1"]
        store.add_messages(
            [
                {"role": "user", "content": "hello"},
                {"role": "assistant", "content": "hi"},
            ]
        )

        # Second run — fresh variables but same session_id
        vars2: dict = {"__session_id__": "sess-bbb"}
        ctx2 = NodeContext(node_id="mem1", variables=vars2)
        r2 = await node.execute(ctx2)
        assert len(r2.output["__memory_history__"]) == 2
        assert r2.output["__memory_history__"][0]["content"] == "hello"

        # Cleanup
        del _SESSION_STORES["sess-bbb:mem1"]

    async def test_no_session_ephemeral(self) -> None:
        """Without __session_id__, stores are not globally cached."""
        from pygubernator.workflow.nodes._memory import _SESSION_STORES

        initial_count = len(_SESSION_STORES)
        node = MemoryNode("mem1", config={"backend": "in_memory"})
        variables: dict = {}
        ctx = NodeContext(node_id="mem1", variables=variables)

        await node.execute(ctx)

        assert len(_SESSION_STORES) == initial_count

    async def test_clear_session_stores(self) -> None:
        """clear_session_stores removes the correct entries."""
        from pygubernator.workflow.nodes._memory import (
            _SESSION_STORES,
            clear_session_stores,
        )

        _SESSION_STORES["sess-ccc:mem1"] = BufferMemoryStore()
        _SESSION_STORES["sess-ccc:mem2"] = BufferMemoryStore()
        _SESSION_STORES["sess-ddd:mem1"] = BufferMemoryStore()

        clear_session_stores("sess-ccc")

        assert "sess-ccc:mem1" not in _SESSION_STORES
        assert "sess-ccc:mem2" not in _SESSION_STORES
        assert "sess-ddd:mem1" in _SESSION_STORES

        # Cleanup
        del _SESSION_STORES["sess-ddd:mem1"]

    async def test_different_sessions_isolated(self) -> None:
        """Different session_ids produce independent stores."""
        from pygubernator.workflow.nodes._memory import _SESSION_STORES

        node = MemoryNode("mem1", config={"backend": "in_memory"})

        # Session A
        vars_a: dict = {"__session_id__": "sess-eee"}
        ctx_a = NodeContext(node_id="mem1", variables=vars_a)
        await node.execute(ctx_a)
        vars_a["__memory_stores__"]["mem1"].add_messages(
            [{"role": "user", "content": "from A"}],
        )

        # Session B
        vars_b: dict = {"__session_id__": "sess-fff"}
        ctx_b = NodeContext(node_id="mem1", variables=vars_b)
        r_b = await node.execute(ctx_b)

        # Session B should have empty history (independent)
        assert r_b.output["__memory_history__"] == []

        # Cleanup
        del _SESSION_STORES["sess-eee:mem1"]
        del _SESSION_STORES["sess-fff:mem1"]


# ---------------------------------------------------------------------------
# resolve_embedded_memory
# ---------------------------------------------------------------------------


class TestResolveEmbeddedMemory:
    """Tests for the resolve_embedded_memory helper."""

    def test_creates_buffer_store(self) -> None:
        from pygubernator.workflow.nodes._memory import resolve_embedded_memory

        history, store = resolve_embedded_memory(
            node_id="agent1",
            memory_config={"backend": "in_memory", "memory_type": "buffer"},
            session_id=None,
        )
        assert history == []
        assert isinstance(store, BufferMemoryStore)

    def test_creates_window_store(self) -> None:
        from pygubernator.workflow.nodes._memory import resolve_embedded_memory

        history, store = resolve_embedded_memory(
            node_id="agent1",
            memory_config={
                "backend": "in_memory",
                "memory_type": "window",
                "window_size": 5,
            },
            session_id=None,
        )
        assert history == []
        assert isinstance(store, WindowMemoryStore)

    def test_session_caches_store(self) -> None:
        from pygubernator.workflow.nodes._memory import (
            _SESSION_STORES,
            resolve_embedded_memory,
        )

        cfg = {"backend": "in_memory", "memory_type": "buffer"}

        # First call creates and caches
        _, store1 = resolve_embedded_memory("n1", cfg, session_id="s-emb1")
        assert "s-emb1:n1" in _SESSION_STORES

        # Add messages to the store
        store1.add_messages([{"role": "user", "content": "hi"}])

        # Second call reuses cached store with history
        history, store2 = resolve_embedded_memory("n1", cfg, session_id="s-emb1")
        assert store2 is store1
        assert len(history) == 1
        assert history[0]["content"] == "hi"

        del _SESSION_STORES["s-emb1:n1"]

    def test_no_session_creates_fresh_store(self) -> None:
        from pygubernator.workflow.nodes._memory import (
            _SESSION_STORES,
            resolve_embedded_memory,
        )

        initial_count = len(_SESSION_STORES)
        resolve_embedded_memory(
            node_id="n1",
            memory_config={"backend": "in_memory"},
            session_id=None,
        )
        assert len(_SESSION_STORES) == initial_count


# ---------------------------------------------------------------------------
# LLMNode + embedded memory config
# ---------------------------------------------------------------------------


class TestLLMNodeWithEmbeddedMemory:
    """Tests for LLMNode with memory merged as sub-node config."""

    async def test_embedded_memory_provides_history(self) -> None:
        from pygubernator.workflow.nodes._llm import LLMNode
        from pygubernator.workflow.nodes._memory import _SESSION_STORES

        node = LLMNode(
            "llm1",
            config={
                "prompt_template": "Say {{ text }}",
                "memory": {"backend": "in_memory", "memory_type": "buffer"},
            },
            llm_provider=_mock_provider(),
            tool_registry=_mock_tool_registry(),
        )
        ctx = NodeContext(
            node_id="llm1",
            input_data={"text": "hello"},
            variables={"__session_id__": "s-llm-emb1"},
        )

        agent_result = AgentResult(
            agent_id="llm_node_llm1",
            success=True,
            messages_processed=1,
            metadata={"response": "Hi there"},
        )
        with patch("pygubernator.workflow.nodes._llm.LLMAgent") as mock_cls:
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_cls.return_value = mock_agent

            result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS

        # Verify writeback happened in the session store
        store = _SESSION_STORES["s-llm-emb1:llm1"]
        messages = store.get_messages()
        assert len(messages) == 2
        assert messages[0]["role"] == "user"
        assert messages[1] == {"role": "assistant", "content": "Hi there"}

        del _SESSION_STORES["s-llm-emb1:llm1"]

    async def test_embedded_memory_second_turn_has_history(self) -> None:
        """Second invocation with same session sees prior history."""
        from pygubernator.workflow.nodes._llm import LLMNode
        from pygubernator.workflow.nodes._memory import _SESSION_STORES

        config = {
            "prompt_template": "{{ message }}",
            "memory": {"backend": "in_memory", "memory_type": "buffer"},
        }
        session_id = "s-llm-emb2"

        agent_result = AgentResult(
            agent_id="llm_node_llm1",
            success=True,
            messages_processed=1,
            metadata={"response": "First reply"},
        )

        # Turn 1
        node = LLMNode(
            "llm1",
            config=config,
            llm_provider=_mock_provider(),
            tool_registry=_mock_tool_registry(),
        )
        ctx1 = NodeContext(
            node_id="llm1",
            input_data={"message": "First question"},
            variables={"__session_id__": session_id},
        )
        with patch("pygubernator.workflow.nodes._llm.LLMAgent") as mock_cls:
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_cls.return_value = mock_agent
            await node.execute(ctx1)

        # Turn 2
        agent_result2 = AgentResult(
            agent_id="llm_node_llm1",
            success=True,
            messages_processed=1,
            metadata={"response": "Second reply"},
        )
        node2 = LLMNode(
            "llm1",
            config=config,
            llm_provider=_mock_provider(),
            tool_registry=_mock_tool_registry(),
        )
        ctx2 = NodeContext(
            node_id="llm1",
            input_data={"message": "Follow-up"},
            variables={"__session_id__": session_id},
        )
        with patch("pygubernator.workflow.nodes._llm.LLMAgent") as mock_cls:
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result2)
            mock_cls.return_value = mock_agent
            await node2.execute(ctx2)

            # Verify history from turn 1 was passed in turn 2
            call_kwargs = mock_agent.process.call_args
            history = call_kwargs.kwargs.get("history")
            assert history is not None
            assert len(history) == 2
            assert history[0]["content"] == "First question"
            assert history[1]["content"] == "First reply"

        del _SESSION_STORES[f"{session_id}:llm1"]


# ---------------------------------------------------------------------------
# AgentNode + embedded memory config
# ---------------------------------------------------------------------------


class TestAgentNodeWithEmbeddedMemory:
    """Tests for AgentNode with memory merged as sub-node config."""

    async def test_embedded_memory_writeback(self) -> None:
        from pygubernator.workflow.nodes._agent import AgentNode
        from pygubernator.workflow.nodes._memory import _SESSION_STORES

        node = AgentNode(
            "agent1",
            config={
                "model_name": "ollama/test",
                "prompt_template": "{{ question }}",
                "memory": {"backend": "in_memory", "memory_type": "buffer"},
            },
        )
        ctx = NodeContext(
            node_id="agent1",
            input_data={"question": "What is AI?"},
            variables={"__session_id__": "s-ag-emb1"},
        )

        agent_result = AgentResult(
            agent_id="agent_node_agent1",
            success=True,
            messages_processed=1,
            metadata={
                "response": "AI is...",
                "tool_results": [],
                "iterations": 1,
            },
        )
        with (
            patch.object(
                node, "_resolve_provider", return_value=(_mock_provider(), None)
            ),
            patch("pygubernator.workflow.nodes._agent.LLMAgent") as mock_cls,
        ):
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_cls.return_value = mock_agent

            result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS

        store = _SESSION_STORES["s-ag-emb1:agent1"]
        messages = store.get_messages()
        assert len(messages) == 2
        assert messages[0] == {"role": "user", "content": "What is AI?"}
        assert messages[1] == {"role": "assistant", "content": "AI is..."}

        del _SESSION_STORES["s-ag-emb1:agent1"]


class TestSqliteSessionIsolation:
    """Test session scoping in SQLite memory store."""

    def test_sqlite_session_isolation(self, tmp_path: Path) -> None:
        from pygubernator.workflow.nodes._memory_sqlite import (
            SqliteMemoryStore,
        )

        db_path = str(tmp_path / "test_sessions.db")

        store_a = SqliteMemoryStore(db_path=db_path, session_id="sess-a")
        store_b = SqliteMemoryStore(db_path=db_path, session_id="sess-b")

        store_a.add_messages([{"role": "user", "content": "from A"}])
        store_b.add_messages([{"role": "user", "content": "from B"}])

        msgs_a = store_a.get_messages()
        msgs_b = store_b.get_messages()

        assert len(msgs_a) == 1
        assert msgs_a[0]["content"] == "from A"
        assert len(msgs_b) == 1
        assert msgs_b[0]["content"] == "from B"

    def test_sqlite_default_session_backward_compat(
        self,
        tmp_path: Path,
    ) -> None:
        """Store without session_id uses 'default' session."""
        from pygubernator.workflow.nodes._memory_sqlite import (
            SqliteMemoryStore,
        )

        db_path = str(tmp_path / "test_default.db")

        store = SqliteMemoryStore(db_path=db_path)
        store.add_messages([{"role": "user", "content": "hello"}])

        msgs = store.get_messages()
        assert len(msgs) == 1
