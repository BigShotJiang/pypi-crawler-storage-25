"""Tests for the heartbeat/scheduler system."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import MagicMock, patch

import pytest

from pygubernator.db.models import ScheduledJob
from pygubernator.scheduler._engine import (
    Scheduler,
    compute_next_run,
    validate_cron,
)
from pygubernator.scheduler._models import (
    CronExpression,
    ScheduledJobConfig,
)

# ------------------------------------------------------------------
# Model tests
# ------------------------------------------------------------------


class TestScheduledJobModel:
    """Tests for the ScheduledJob DB model defaults."""

    def test_default_fields(self) -> None:
        """ScheduledJob persists expected defaults via DB."""
        from tests.unit.conftest import (
            reset_test_db,
            test_engine,
        )

        reset_test_db()
        from sqlalchemy.orm import Session

        session = Session(bind=test_engine)
        job = ScheduledJob(
            workflow_id="wf-1",
            cron_expression="*/5 * * * *",
        )
        session.add(job)
        session.commit()
        session.refresh(job)

        assert job.workflow_id == "wf-1"
        assert job.cron_expression == "*/5 * * * *"
        assert job.enabled is True
        assert job.last_status == "pending"
        assert job.name == ""
        assert job.description == ""
        assert job.created_by == "system"
        session.close()

    def test_id_auto_generated(self) -> None:
        """ID is populated by the default factory."""
        from tests.unit.conftest import (
            reset_test_db,
            test_engine,
        )

        reset_test_db()
        from sqlalchemy.orm import Session

        session = Session(bind=test_engine)
        job = ScheduledJob(
            workflow_id="wf-2",
            cron_expression="0 * * * *",
        )
        session.add(job)
        session.commit()
        session.refresh(job)
        assert job.id is not None
        assert len(job.id) == 36
        session.close()

    def test_nullable_datetimes(self) -> None:
        """last_run_at and next_run_at default to None."""
        job = ScheduledJob(
            workflow_id="wf-3",
            cron_expression="0 0 * * *",
        )
        assert job.last_run_at is None
        assert job.next_run_at is None


# ------------------------------------------------------------------
# Pydantic model tests
# ------------------------------------------------------------------


class TestScheduledJobConfig:
    """Tests for the ScheduledJobConfig pydantic model."""

    def test_defaults(self) -> None:
        cfg = ScheduledJobConfig(workflow_id="wf-1", cron="*/10 * * * *")
        assert cfg.input_json == {}
        assert cfg.enabled is True
        assert cfg.name == ""
        assert cfg.description == ""

    def test_all_fields(self) -> None:
        cfg = ScheduledJobConfig(
            workflow_id="wf-1",
            cron="0 * * * *",
            input_json={"key": "val"},
            enabled=False,
            name="my-job",
            description="daily run",
        )
        assert cfg.workflow_id == "wf-1"
        assert cfg.enabled is False
        assert cfg.input_json == {"key": "val"}


class TestCronExpression:
    """Tests for the CronExpression pydantic model."""

    def test_basic(self) -> None:
        expr = CronExpression(expression="*/5 * * * *")
        assert expr.expression == "*/5 * * * *"


# ------------------------------------------------------------------
# Cron parsing tests
# ------------------------------------------------------------------


class TestSchedulerCron:
    """Tests for cron expression parsing utilities."""

    def test_validate_cron_valid(self) -> None:
        assert validate_cron("*/5 * * * *") is True
        assert validate_cron("0 0 * * *") is True
        assert validate_cron("0 12 * * MON-FRI") is True

    def test_validate_cron_invalid(self) -> None:
        assert validate_cron("not-a-cron") is False
        assert validate_cron("") is False

    def test_compute_next_run_returns_future(self) -> None:
        now = datetime.now(UTC)
        next_time = compute_next_run("* * * * *", now)
        assert next_time > now

    def test_compute_next_run_every_5_minutes(self) -> None:
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=UTC)
        result = compute_next_run("*/5 * * * *", base)
        assert result.minute == 5
        assert result.hour == 0

    def test_compute_next_run_daily_midnight(self) -> None:
        base = datetime(2026, 3, 15, 12, 0, 0, tzinfo=UTC)
        result = compute_next_run("0 0 * * *", base)
        assert result.day == 16
        assert result.hour == 0
        assert result.minute == 0

    def test_compute_next_run_invalid_raises(self) -> None:
        with pytest.raises(Exception):
            compute_next_run("invalid-cron")


# ------------------------------------------------------------------
# Scheduler engine tests
# ------------------------------------------------------------------


class TestSchedulerEngine:
    """Tests for the Scheduler engine logic."""

    def test_init_sets_defaults(self) -> None:
        factory = MagicMock()
        sched = Scheduler(db_session_factory=factory, poll_interval=10.0)
        assert sched._poll_interval == 10.0
        assert sched.running is False

    def test_start_and_stop(self) -> None:
        """Scheduler starts a daemon thread and stops it."""
        factory = MagicMock()
        sched = Scheduler(
            db_session_factory=factory,
            poll_interval=0.1,
        )
        sched.start()
        assert sched.running is True
        sched.stop()
        assert sched.running is False

    @patch("pygubernator.scheduler._engine._execute_in_thread")
    def test_evaluate_jobs_triggers_due(self, mock_exec: MagicMock) -> None:
        """Due jobs are triggered."""
        from tests.unit.conftest import (
            reset_test_db,
            test_engine,
        )

        reset_test_db()
        from sqlalchemy.orm import Session

        session = Session(bind=test_engine)

        past = datetime(2020, 1, 1, tzinfo=UTC)
        job = ScheduledJob(
            workflow_id="wf-test",
            cron_expression="*/5 * * * *",
            enabled=True,
            next_run_at=past,
            name="due-job",
        )
        session.add(job)
        session.commit()

        factory = MagicMock(return_value=session)
        sched = Scheduler(db_session_factory=factory)

        with patch.object(sched, "_trigger_workflow"):
            sched._evaluate_jobs(session)

        session.refresh(job)
        assert job.last_run_at is not None
        # next_run_at should be updated to a future time
        # (SQLite may strip tzinfo, so compare naive)
        next_naive = job.next_run_at.replace(tzinfo=None)
        past_naive = past.replace(tzinfo=None)
        assert next_naive > past_naive
        session.close()

    def test_evaluate_jobs_skips_disabled(self) -> None:
        """Disabled jobs are not triggered."""
        from tests.unit.conftest import (
            reset_test_db,
            test_engine,
        )

        reset_test_db()
        from sqlalchemy.orm import Session

        session = Session(bind=test_engine)

        past = datetime(2020, 1, 1, tzinfo=UTC)
        job = ScheduledJob(
            workflow_id="wf-disabled",
            cron_expression="*/5 * * * *",
            enabled=False,
            next_run_at=past,
        )
        session.add(job)
        session.commit()

        factory = MagicMock(return_value=session)
        sched = Scheduler(db_session_factory=factory)
        with patch.object(sched, "_trigger_workflow") as mock_trigger:
            sched._evaluate_jobs(session)
            mock_trigger.assert_not_called()
        session.close()

    def test_evaluate_jobs_skips_not_due(self) -> None:
        """Jobs with future next_run_at are skipped."""
        from tests.unit.conftest import (
            reset_test_db,
            test_engine,
        )

        reset_test_db()
        from sqlalchemy.orm import Session

        session = Session(bind=test_engine)

        future = datetime(2099, 1, 1, tzinfo=UTC)
        job = ScheduledJob(
            workflow_id="wf-future",
            cron_expression="*/5 * * * *",
            enabled=True,
            next_run_at=future,
        )
        session.add(job)
        session.commit()

        factory = MagicMock(return_value=session)
        sched = Scheduler(db_session_factory=factory)
        with patch.object(sched, "_trigger_workflow") as mock_trigger:
            sched._evaluate_jobs(session)
            mock_trigger.assert_not_called()
        session.close()


# ------------------------------------------------------------------
# Route tests
# ------------------------------------------------------------------


class TestSchedulerRoutes:
    """Tests for scheduler API route definitions."""

    def test_router_has_expected_paths(self) -> None:
        from pygubernator.api.routes_scheduler import (
            router,
        )

        paths = [r.path for r in router.routes]
        prefix = "/api/v1/admin/schedules"
        assert prefix in paths
        assert f"{prefix}/{{job_id}}" in paths
        assert f"{prefix}/{{job_id}}/trigger" in paths

    def test_job_response_model_fields(self) -> None:
        from pygubernator.api.routes_scheduler import (
            JobResponse,
        )

        fields = set(JobResponse.model_fields.keys())
        expected = {
            "id",
            "workflow_id",
            "name",
            "description",
            "cron_expression",
            "input_json",
            "enabled",
            "last_run_at",
            "next_run_at",
            "last_status",
            "created_by",
            "created_at",
            "updated_at",
        }
        assert expected == fields

    def test_to_response_converts_row(self) -> None:
        from pygubernator.api.routes_scheduler import (
            _to_response,
        )

        now = datetime.now(UTC)
        row = MagicMock()
        row.id = "job-1"
        row.workflow_id = "wf-1"
        row.name = "Test"
        row.description = "desc"
        row.cron_expression = "*/5 * * * *"
        row.input_json = {"key": "val"}
        row.enabled = True
        row.last_run_at = None
        row.next_run_at = now
        row.last_status = "pending"
        row.created_by = "admin"
        row.created_at = now
        row.updated_at = now

        resp = _to_response(row)
        assert resp.id == "job-1"
        assert resp.workflow_id == "wf-1"
        assert resp.cron_expression == "*/5 * * * *"
        assert resp.input_json == {"key": "val"}


# ------------------------------------------------------------------
# Manual trigger tests
# ------------------------------------------------------------------


class TestManualTrigger:
    """Tests for the manual trigger endpoint logic."""

    def test_trigger_calls_execute(self) -> None:
        """Verify trigger_job references execute_in_thread."""
        import inspect

        from pygubernator.api.routes_scheduler import (
            trigger_job,
        )

        source = inspect.getsource(trigger_job)
        assert "_execute_in_thread" in source

    def test_validate_cron_rejects_invalid(self) -> None:
        from pygubernator.api.routes_scheduler import (
            _validate_cron,
        )

        with pytest.raises(Exception):
            _validate_cron("not-valid-cron")

    def test_validate_cron_accepts_valid(self) -> None:
        from pygubernator.api.routes_scheduler import (
            _validate_cron,
        )

        _validate_cron("*/5 * * * *")
