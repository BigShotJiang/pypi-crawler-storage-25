"""Tests for workflow import/export endpoints."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from pygubernator.api.main import create_app
from tests.unit.conftest import reset_test_db


def _headers() -> dict[str, str]:
    return {
        "X-API-Token": "dev-token",
        "X-Actor": "test",
        "X-Role": "admin",
    }


@pytest.fixture(autouse=True)
def _reset_db() -> None:
    reset_test_db()


@pytest.fixture
def client() -> TestClient:
    """Test client with a fresh database."""
    return TestClient(create_app())


def _create_workflow_with_version(
    client: TestClient,
    name: str = "export-wf",
) -> tuple[str, str]:
    """Create a workflow and a version, return IDs."""
    res = client.post(
        "/api/v1/workflows",
        headers=_headers(),
        json={
            "name": name,
            "description": "For export",
            "owner": "test",
        },
    )
    assert res.status_code == 200
    wf_id = res.json()["id"]

    spec = {"nodes": {"a": {"type": "input"}}}
    ver_res = client.post(
        f"/api/v1/workflows/{wf_id}/versions",
        headers=_headers(),
        json={
            "version": "1.0.0",
            "spec_json": spec,
        },
    )
    assert ver_res.status_code == 200
    ver_id = ver_res.json()["id"]

    # Activate the version
    client.post(
        f"/api/v1/workflows/{wf_id}/versions/{ver_id}/activate",
        headers=_headers(),
    )
    return wf_id, ver_id


class TestExportWorkflow:
    """Tests for the export endpoint."""

    def test_export_returns_spec_json(
        self,
        client: TestClient,
    ) -> None:
        """Export returns the workflow name and spec."""
        wf_id, _ = _create_workflow_with_version(client)
        res = client.get(
            f"/api/v1/workflows/{wf_id}/export",
            headers=_headers(),
        )
        assert res.status_code == 200
        body = res.json()
        assert "workflow" in body
        wf = body["workflow"]
        assert wf["name"] == "export-wf"
        assert wf["spec"] == {
            "nodes": {"a": {"type": "input"}},
        }
        assert wf["version"] == "1.0.0"

    def test_export_not_found(
        self,
        client: TestClient,
    ) -> None:
        """Export of a nonexistent workflow returns 404."""
        res = client.get(
            "/api/v1/workflows/nonexistent/export",
            headers=_headers(),
        )
        assert res.status_code == 404


class TestImportWorkflow:
    """Tests for the import endpoint."""

    def test_import_creates_workflow(
        self,
        client: TestClient,
    ) -> None:
        """Import creates a new workflow with a version."""
        spec = {"nodes": {"b": {"type": "output"}}}
        res = client.post(
            "/api/v1/workflows/import",
            headers=_headers(),
            json={
                "name": "imported-wf",
                "description": "From import",
                "spec": spec,
                "version": "2.0.0",
            },
        )
        assert res.status_code == 200
        body = res.json()
        assert "workflow" in body
        assert body["workflow"]["name"] == "imported-wf"

        # Verify the workflow is listable
        wf_id = body["workflow"]["id"]
        get_res = client.get(
            f"/api/v1/workflows/{wf_id}",
            headers=_headers(),
        )
        assert get_res.status_code == 200


class TestRoutePathsExist:
    """Verify route registration."""

    def test_export_route_exists(
        self,
        client: TestClient,
    ) -> None:
        """The export route is registered."""
        wf_id, _ = _create_workflow_with_version(
            client,
            name="route-check",
        )
        res = client.get(
            f"/api/v1/workflows/{wf_id}/export",
            headers=_headers(),
        )
        # Should not be 405 Method Not Allowed
        assert res.status_code != 405

    def test_import_route_exists(
        self,
        client: TestClient,
    ) -> None:
        """The import route is registered."""
        res = client.post(
            "/api/v1/workflows/import",
            headers=_headers(),
            json={"name": "probe", "spec": {}},
        )
        assert res.status_code != 405
