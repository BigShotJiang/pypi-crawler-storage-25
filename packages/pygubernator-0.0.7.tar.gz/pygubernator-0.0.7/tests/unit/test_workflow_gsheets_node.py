"""Tests for GSheetsNode."""

from __future__ import annotations

import pytest

from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._gsheets import GSheetsNode, GSheetsNodeFactory


@pytest.fixture
def patch_gsheets_client(monkeypatch: pytest.MonkeyPatch):
    """Inject a fake Sheets client factory."""
    import pygubernator.workflow.nodes._gsheets as gs_mod

    class _FakeClient:
        def read_range(self, spreadsheet_id: str, range_a1: str) -> list[list[str]]:
            assert spreadsheet_id == "sid1"
            assert range_a1 == "A1:B2"
            return [["a", "b"]]

        def create_spreadsheet(self, title: str) -> dict[str, str]:
            return {"spreadsheet_id": "new123", "title": title}

    monkeypatch.setattr(gs_mod, "_HAS_GSHEETS", True)
    monkeypatch.setattr(
        gs_mod,
        "create_sheets_client",
        lambda _path: _FakeClient(),
    )


class TestGSheetsNode:
    """GSheetsNode execution."""

    async def test_missing_operation_fails(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        import pygubernator.workflow.nodes._gsheets as gs_mod

        monkeypatch.setattr(gs_mod, "_HAS_GSHEETS", True)
        monkeypatch.setattr(gs_mod, "create_sheets_client", lambda _p: object())
        node = GSheetsNode("n1", {})
        ctx = NodeContext(node_id="n1", input_data={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "operation" in (result.error or "").lower()

    async def test_unknown_operation_fails(self, patch_gsheets_client) -> None:
        node = GSheetsNode("n1", {"operation": "not_real"})
        ctx = NodeContext(node_id="n1", input_data={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "Unknown" in (result.error or "")

    async def test_missing_credentials_env_fails(self, patch_gsheets_client) -> None:
        node = GSheetsNode("n1", {"operation": "read_range"})
        ctx = NodeContext(
            node_id="n1",
            input_data={"spreadsheet_id": "x", "range_a1": "A1"},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH" in (result.error or "")

    async def test_read_range_success(
        self,
        patch_gsheets_client,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH", "/fake/creds.json")
        node = GSheetsNode(
            "n1",
            {"operation": "read_range", "spreadsheet_id": "sid1", "range_a1": "A1:B2"},
        )
        ctx = NodeContext(node_id="n1", input_data={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output == {"values": [["a", "b"]], "row_count": 1}

    async def test_input_data_merges_with_config(
        self,
        patch_gsheets_client,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH", "/fake/creds.json")
        node = GSheetsNode("n1", {"operation": "read_range"})
        ctx = NodeContext(
            node_id="n1",
            input_data={"spreadsheet_id": "sid1", "range_a1": "A1:B2"},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS

    async def test_create_spreadsheet_success(
        self,
        patch_gsheets_client,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH", "/fake/creds.json")
        node = GSheetsNode(
            "n1",
            {"operation": "create_spreadsheet", "title": "My Book"},
        )
        ctx = NodeContext(node_id="n1", input_data={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output["spreadsheet_id"] == "new123"

    def test_factory(self) -> None:
        factory = GSheetsNodeFactory()
        node = factory.create("n1", {"operation": "read_range"})
        assert isinstance(node, GSheetsNode)
        assert node.node_type == "gsheets"
