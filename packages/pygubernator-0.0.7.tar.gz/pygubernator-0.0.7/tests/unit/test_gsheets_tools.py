"""Tests for Google Sheets tools (mocking the Google API client)."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from pygubernator.tools.gsheets_tools import _SheetsClient, create_gsheets_tools

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_sheets_service() -> MagicMock:
    """Build a mock Google Sheets API service."""
    return MagicMock()


def _make_client(sheets_mock: MagicMock) -> _SheetsClient:
    """Create a _SheetsClient with its _sheets attr replaced by a mock."""
    with patch.object(_SheetsClient, "__init__", lambda self, *a, **kw: None):
        client = _SheetsClient.__new__(_SheetsClient)
        client._sheets = sheets_mock
        return client


def _make_tools(sheets_mock: MagicMock) -> list[Any]:
    """Create tools backed by a mock Sheets service."""
    with patch.object(_SheetsClient, "__init__", lambda self, *a, **kw: None):
        # Temporarily replace __init__ so create_gsheets_tools skips auth
        tools = create_gsheets_tools("fake_creds.json")
    # Patch the _sheets attribute on the client captured inside the closure
    # by reaching through one of the tool functions.
    # The client is the same object for all tools, so patching via any works.
    # Find the client from the closure of the first tool's wrapped function.

    for t in tools:
        fn = t._func
        if hasattr(fn, "__closure__") and fn.__closure__:
            for cell in fn.__closure__:
                obj = cell.cell_contents
                if isinstance(obj, _SheetsClient):
                    obj._sheets = sheets_mock
                    return tools
    # Fallback: if closure search fails, the mock is already in place
    return tools


def _get_tool(tools: list[Any], name: str) -> Any:
    """Find a tool by name."""
    return next(t for t in tools if t.name == name)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestGsheetsToolsFactory:
    """Tests for create_gsheets_tools factory."""

    def test_returns_eight_tools(self) -> None:
        sheets = _mock_sheets_service()
        tools = _make_tools(sheets)
        assert len(tools) == 8

    def test_tool_names(self) -> None:
        sheets = _mock_sheets_service()
        tools = _make_tools(sheets)
        names = {t.name for t in tools}
        assert names == {
            "gsheets_create_spreadsheet",
            "gsheets_read_range",
            "gsheets_write_range",
            "gsheets_append_rows",
            "gsheets_create_sheet",
            "gsheets_delete_sheet",
            "gsheets_rename_sheet",
            "gsheets_format_cells",
        }

    def test_all_tools_have_schemas(self) -> None:
        sheets = _mock_sheets_service()
        tools = _make_tools(sheets)
        for t in tools:
            schema = t.parameters_schema
            assert schema["type"] == "object"
            assert "properties" in schema


# ---------------------------------------------------------------------------
# _SheetsClient unit tests
# ---------------------------------------------------------------------------


class TestSheetsClient:
    """Tests for the _SheetsClient wrapper."""

    def test_create_spreadsheet(self) -> None:
        sheets = _mock_sheets_service()
        sheets.create.return_value.execute.return_value = {
            "spreadsheetId": "abc123",
            "spreadsheetUrl": "https://docs.google.com/spreadsheets/d/abc123",
        }
        client = _make_client(sheets)

        result = client.create_spreadsheet("Test Sheet")

        assert result["spreadsheet_id"] == "abc123"
        assert "abc123" in result["url"]

    def test_read_range(self) -> None:
        sheets = _mock_sheets_service()
        sheets.values.return_value.get.return_value.execute.return_value = {
            "values": [["A", "B"], ["1", "2"]],
        }
        client = _make_client(sheets)

        result = client.read_range("abc123", "Sheet1!A1:B2")

        assert result == [["A", "B"], ["1", "2"]]

    def test_read_range_empty(self) -> None:
        sheets = _mock_sheets_service()
        sheets.values.return_value.get.return_value.execute.return_value = {}
        client = _make_client(sheets)

        result = client.read_range("abc123", "Sheet1!A1:B2")

        assert result == []

    def test_write_range(self) -> None:
        sheets = _mock_sheets_service()
        sheets.values.return_value.update.return_value.execute.return_value = {
            "updatedCells": 4,
        }
        client = _make_client(sheets)

        result = client.write_range("abc123", "Sheet1!A1:B2", [["X", "Y"], ["1", "2"]])

        assert result["updated_cells"] == 4

    def test_append_rows(self) -> None:
        sheets = _mock_sheets_service()
        sheets.values.return_value.append.return_value.execute.return_value = {
            "updates": {"updatedCells": 3},
        }
        client = _make_client(sheets)

        result = client.append_rows("abc123", "Sheet1!A:C", [["a", "b", "c"]])

        assert result["updated_cells"] == 3

    def test_create_sheet(self) -> None:
        sheets = _mock_sheets_service()
        sheets.batchUpdate.return_value.execute.return_value = {
            "replies": [
                {"addSheet": {"properties": {"sheetId": 42, "title": "NewTab"}}}
            ],
        }
        client = _make_client(sheets)

        result = client.create_sheet("abc123", "NewTab")

        assert result["sheet_id"] == 42
        assert result["title"] == "NewTab"

    def test_delete_sheet(self) -> None:
        sheets = _mock_sheets_service()
        sheets.batchUpdate.return_value.execute.return_value = {"replies": []}
        client = _make_client(sheets)

        result = client.delete_sheet("abc123", 42)

        assert result["deleted_sheet_id"] == 42

    def test_rename_sheet(self) -> None:
        sheets = _mock_sheets_service()
        sheets.batchUpdate.return_value.execute.return_value = {"replies": []}
        client = _make_client(sheets)

        result = client.rename_sheet("abc123", 42, "Renamed")

        assert result["sheet_id"] == 42
        assert result["new_title"] == "Renamed"

    def test_format_cells_bold(self) -> None:
        sheets = _mock_sheets_service()
        sheets.batchUpdate.return_value.execute.return_value = {"replies": []}
        client = _make_client(sheets)

        result = client.format_cells(
            spreadsheet_id="abc123",
            sheet_id=0,
            start_row=0,
            end_row=1,
            start_col=0,
            end_col=3,
            bold=True,
        )

        assert result["formatted"] is True
        call_args = sheets.batchUpdate.call_args
        body = call_args.kwargs.get("body") or call_args[1].get("body")
        req = body["requests"][0]["repeatCell"]
        assert req["cell"]["userEnteredFormat"]["textFormat"]["bold"] is True

    def test_format_cells_no_options(self) -> None:
        sheets = _mock_sheets_service()
        client = _make_client(sheets)

        result = client.format_cells(
            spreadsheet_id="abc123",
            sheet_id=0,
            start_row=0,
            end_row=1,
            start_col=0,
            end_col=1,
        )

        assert result["formatted"] is False


# ---------------------------------------------------------------------------
# Tool execution (end-to-end via @tool wrappers)
# ---------------------------------------------------------------------------


class TestGsheetsToolExecution:
    """Tests for executing tools through the @tool decorator."""

    @pytest.mark.asyncio
    async def test_create_spreadsheet(self) -> None:
        sheets = _mock_sheets_service()
        sheets.create.return_value.execute.return_value = {
            "spreadsheetId": "new_id",
            "spreadsheetUrl": "https://example.com/new_id",
        }
        tools = _make_tools(sheets)
        t = _get_tool(tools, "gsheets_create_spreadsheet")

        result = await t.execute({"title": "My Sheet"})

        assert result.success
        assert result.output["spreadsheet_id"] == "new_id"

    @pytest.mark.asyncio
    async def test_read_range(self) -> None:
        sheets = _mock_sheets_service()
        sheets.values.return_value.get.return_value.execute.return_value = {
            "values": [["hello"]],
        }
        tools = _make_tools(sheets)
        t = _get_tool(tools, "gsheets_read_range")

        result = await t.execute({"spreadsheet_id": "abc", "range": "Sheet1!A1"})

        assert result.success
        assert result.output["values"] == [["hello"]]
        assert result.output["row_count"] == 1

    @pytest.mark.asyncio
    async def test_write_range(self) -> None:
        sheets = _mock_sheets_service()
        sheets.values.return_value.update.return_value.execute.return_value = {
            "updatedCells": 2,
        }
        tools = _make_tools(sheets)
        t = _get_tool(tools, "gsheets_write_range")

        result = await t.execute(
            {
                "spreadsheet_id": "abc",
                "range": "Sheet1!A1:B1",
                "values": [["x", "y"]],
            }
        )

        assert result.success
        assert result.output["updated_cells"] == 2

    @pytest.mark.asyncio
    async def test_append_rows(self) -> None:
        sheets = _mock_sheets_service()
        sheets.values.return_value.append.return_value.execute.return_value = {
            "updates": {"updatedCells": 3},
        }
        tools = _make_tools(sheets)
        t = _get_tool(tools, "gsheets_append_rows")

        result = await t.execute(
            {
                "spreadsheet_id": "abc",
                "range": "Sheet1!A:C",
                "values": [["a", "b", "c"]],
            }
        )

        assert result.success
        assert result.output["updated_cells"] == 3

    @pytest.mark.asyncio
    async def test_format_cells(self) -> None:
        sheets = _mock_sheets_service()
        sheets.batchUpdate.return_value.execute.return_value = {"replies": []}
        tools = _make_tools(sheets)
        t = _get_tool(tools, "gsheets_format_cells")

        result = await t.execute(
            {
                "spreadsheet_id": "abc",
                "sheet_id": 0,
                "start_row": 0,
                "end_row": 1,
                "start_col": 0,
                "end_col": 3,
                "bold": True,
                "bg_color": {"red": 1.0, "green": 0.9, "blue": 0.0},
            }
        )

        assert result.success
        assert result.output["formatted"] is True

    @pytest.mark.asyncio
    async def test_api_error_returns_failure(self) -> None:
        sheets = _mock_sheets_service()
        sheets.create.return_value.execute.side_effect = RuntimeError("quota exceeded")
        tools = _make_tools(sheets)
        t = _get_tool(tools, "gsheets_create_spreadsheet")

        result = await t.execute({"title": "Fail"})

        assert not result.success
        assert "quota exceeded" in result.error
