"""Tests for repository CRUD helpers (SQLite in-memory)."""

from __future__ import annotations

import pytest
from sqlalchemy.orm import Session, sessionmaker

from pygubernator.db.repositories import (
    create_agent,
    create_agent_version,
    create_run,
    create_run_event,
    create_tool_call,
    get_agent,
    get_run,
    list_agents,
    list_run_events,
    list_runs_filtered,
    list_tool_calls,
    update_agent,
    update_run,
)
from tests.unit.conftest import reset_test_db, test_engine


@pytest.fixture
def db() -> Session:
    """Create an in-memory SQLite database for testing."""
    reset_test_db()
    factory = sessionmaker(bind=test_engine, autoflush=False, autocommit=False)
    session = factory()
    yield session
    session.close()


class TestAgentCrud:
    """Tests for Agent CRUD operations."""

    def test_create_and_get_agent(self, db: Session) -> None:
        agent = create_agent(db, name="test-agent", owner="alice")
        db.commit()
        db.refresh(agent)

        fetched = get_agent(db, agent.id)
        assert fetched is not None
        assert fetched.name == "test-agent"
        assert fetched.owner == "alice"

    def test_list_agents_pagination(self, db: Session) -> None:
        for i in range(5):
            create_agent(db, name=f"agent-{i}")
        db.commit()

        items, total = list_agents(db, page=1, page_size=2)
        assert total == 5
        assert len(items) == 2

    def test_update_agent(self, db: Session) -> None:
        agent = create_agent(db, name="orig")
        db.commit()
        db.refresh(agent)

        update_agent(db, agent, status="archived")
        db.commit()
        db.refresh(agent)
        assert agent.status == "archived"


class TestAgentVersionCrud:
    """Tests for AgentVersion CRUD."""

    def test_create_version(self, db: Session) -> None:
        agent = create_agent(db, name="agent-v")
        db.commit()
        db.refresh(agent)

        av = create_agent_version(
            db,
            agent_id=agent.id,
            version="1.0.0",
            model="gpt-4",
            active=True,
        )
        db.commit()
        db.refresh(av)

        assert av.version == "1.0.0"
        assert av.model == "gpt-4"
        assert av.active is True


class TestRunCrud:
    """Tests for Run CRUD operations."""

    def test_create_and_get_run(self, db: Session) -> None:
        agent = create_agent(db, name="run-agent")
        db.commit()
        db.refresh(agent)

        run = create_run(db, agent_id=agent.id, trigger="manual")
        db.commit()
        db.refresh(run)

        fetched = get_run(db, run.id)
        assert fetched is not None
        assert fetched.trigger == "manual"
        assert fetched.status == "queued"

    def test_update_run(self, db: Session) -> None:
        agent = create_agent(db, name="run-upd")
        db.commit()
        db.refresh(agent)

        run = create_run(db, agent_id=agent.id)
        db.commit()
        db.refresh(run)

        update_run(db, run, status="running", duration_ms=100)
        db.commit()
        db.refresh(run)
        assert run.status == "running"
        assert run.duration_ms == 100

    def test_list_runs(self, db: Session) -> None:
        agent = create_agent(db, name="list-agent")
        db.commit()
        db.refresh(agent)

        for _ in range(3):
            create_run(db, agent_id=agent.id)
        db.commit()

        items, total = list_runs_filtered(db, agent_id=agent.id)
        assert total == 3
        assert len(items) == 3

    def test_list_runs_all(self, db: Session) -> None:
        a1 = create_agent(db, name="a1")
        a2 = create_agent(db, name="a2")
        db.commit()
        db.refresh(a1)
        db.refresh(a2)

        create_run(db, agent_id=a1.id)
        create_run(db, agent_id=a2.id)
        db.commit()

        items, total = list_runs_filtered(db)
        assert total == 2


class TestRunEventCrud:
    """Tests for RunEvent CRUD."""

    def test_create_and_list_events(self, db: Session) -> None:
        agent = create_agent(db, name="evt-agent")
        db.commit()
        db.refresh(agent)

        run = create_run(db, agent_id=agent.id)
        db.commit()
        db.refresh(run)

        create_run_event(
            db,
            run_id=run.id,
            event_type="agent.started",
            message="started",
        )
        create_run_event(
            db,
            run_id=run.id,
            event_type="step.completed",
            level="info",
            payload={"duration_ms": 42},
        )
        db.commit()

        items, total = list_run_events(db, run.id)
        assert total == 2
        assert len(items) == 2


class TestToolCallCrud:
    """Tests for ToolCall CRUD."""

    def test_create_and_list_tool_calls(self, db: Session) -> None:
        agent = create_agent(db, name="tc-agent")
        db.commit()
        db.refresh(agent)

        run = create_run(db, agent_id=agent.id)
        db.commit()
        db.refresh(run)

        create_tool_call(
            db,
            run_id=run.id,
            tool_name="search",
            latency_ms=55,
            input_payload={"q": "test"},
            output_payload={"results": 3},
        )
        create_tool_call(
            db,
            run_id=run.id,
            tool_name="fetch",
            status="failed",
            error_message="timeout",
        )
        db.commit()

        items, total = list_tool_calls(db, run.id)
        assert total == 2
        assert items[0].tool_name in ("search", "fetch")
