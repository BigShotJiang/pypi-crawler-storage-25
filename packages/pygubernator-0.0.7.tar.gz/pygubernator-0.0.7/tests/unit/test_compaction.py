"""Tests for token counting and compacting memory store."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from pygubernator.llm._tokens import (
    count_messages_tokens,
    count_tokens,
)
from pygubernator.workflow.nodes._memory import create_memory_store
from pygubernator.workflow.nodes._memory_compacting import (
    CompactingMemoryStore,
)

# -------------------------------------------------------------------
# count_tokens
# -------------------------------------------------------------------


class TestCountTokens:
    """Tests for the count_tokens utility."""

    def test_basic_counting(self) -> None:
        # ~4 chars per token fallback
        result = count_tokens("Hello world, this is a test string")
        assert result > 0

    def test_empty_string(self) -> None:
        # Empty string should return at least 1
        assert count_tokens("") == 1

    def test_short_string(self) -> None:
        # 3 chars -> max(1, 3//4) = max(1, 0) = 1
        assert count_tokens("abc") == 1

    def test_longer_string(self) -> None:
        text = "a" * 100
        result = count_tokens(text)
        assert result == 25  # 100 // 4

    def test_unknown_model_falls_back(self) -> None:
        # An unrecognized model should still return a value
        result = count_tokens("some text", model="not-a-real-model")
        assert result > 0


# -------------------------------------------------------------------
# count_messages_tokens
# -------------------------------------------------------------------


class TestCountMessagesTokens:
    """Tests for the count_messages_tokens utility."""

    def test_multiple_messages(self) -> None:
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
        ]
        result = count_messages_tokens(messages)
        assert result > 0

    def test_empty_list(self) -> None:
        assert count_messages_tokens([]) == 0

    def test_per_message_overhead(self) -> None:
        # Each message adds +4 overhead tokens
        single = count_messages_tokens([{"role": "user", "content": "Hi"}])
        double = count_messages_tokens(
            [
                {"role": "user", "content": "Hi"},
                {"role": "user", "content": "Hi"},
            ]
        )
        # Two identical messages should be roughly 2x one
        assert double == single * 2

    def test_missing_keys(self) -> None:
        # Messages with missing role/content should not crash
        result = count_messages_tokens([{}])
        # Empty role + empty content = 0 chars -> 1 token + 4 overhead
        assert result == 5


# -------------------------------------------------------------------
# CompactingMemoryStore
# -------------------------------------------------------------------


def _make_provider(
    summary: str = "Summary of conversation",
) -> MagicMock:
    """Create a mock LLM provider for summarization."""
    provider = MagicMock()
    provider.chat = AsyncMock(
        return_value=MagicMock(content=summary),
    )
    return provider


def _make_messages(count: int) -> list[dict[str, str]]:
    """Generate a list of user/assistant message pairs."""
    msgs: list[dict[str, str]] = []
    for i in range(count):
        role = "user" if i % 2 == 0 else "assistant"
        msgs.append({"role": role, "content": f"Message {i}" * 20})
    return msgs


class TestCompactingMemoryStore:
    """Tests for the CompactingMemoryStore."""

    @pytest.mark.asyncio
    async def test_under_budget_no_compaction(self) -> None:
        """Messages under the token budget are returned unchanged."""
        from pygubernator.workflow.nodes._memory import (
            BufferMemoryStore,
        )

        inner = BufferMemoryStore()
        msgs = [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello"},
        ]
        inner.add_messages(msgs)

        store = CompactingMemoryStore(
            inner=inner,
            llm_provider=_make_provider(),
            max_tokens=50000,
            preserve_recent=2,
        )
        await store.prepare()

        result = store.get_messages()
        assert result == msgs

    @pytest.mark.asyncio
    async def test_over_budget_triggers_summarization(self) -> None:
        """Old messages are summarized when over token budget."""
        from pygubernator.workflow.nodes._memory import (
            BufferMemoryStore,
        )

        inner = BufferMemoryStore()
        msgs = _make_messages(20)
        inner.add_messages(msgs)

        provider = _make_provider("Summarized old conversation.")
        store = CompactingMemoryStore(
            inner=inner,
            llm_provider=provider,
            max_tokens=10,  # Very low to force compaction
            preserve_recent=4,
        )
        await store.prepare()

        result = store.get_messages()
        # First message should be the summary
        assert result[0]["role"] == "system"
        assert "[Conversation summary]" in result[0]["content"]
        assert "Summarized old conversation." in result[0]["content"]
        # Last 4 should be the recent messages
        assert result[1:] == msgs[-4:]
        provider.chat.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_preserve_recent_respected(self) -> None:
        """The last N messages are always preserved verbatim."""
        from pygubernator.workflow.nodes._memory import (
            BufferMemoryStore,
        )

        inner = BufferMemoryStore()
        msgs = _make_messages(10)
        inner.add_messages(msgs)

        store = CompactingMemoryStore(
            inner=inner,
            llm_provider=_make_provider(),
            max_tokens=1,
            preserve_recent=6,
        )
        await store.prepare()

        result = store.get_messages()
        # Summary + 6 recent
        assert len(result) == 7
        assert result[1:] == msgs[-6:]

    @pytest.mark.asyncio
    async def test_too_few_messages_no_split(self) -> None:
        """When total messages <= preserve_recent, no compaction."""
        from pygubernator.workflow.nodes._memory import (
            BufferMemoryStore,
        )

        inner = BufferMemoryStore()
        msgs = [{"role": "user", "content": "x" * 1000}]
        inner.add_messages(msgs)

        provider = _make_provider()
        store = CompactingMemoryStore(
            inner=inner,
            llm_provider=provider,
            max_tokens=1,  # Force over budget
            preserve_recent=4,
        )
        await store.prepare()

        result = store.get_messages()
        assert result == msgs
        provider.chat.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_add_messages_invalidates_cache(self) -> None:
        """Adding messages after prepare() clears the cache."""
        from pygubernator.workflow.nodes._memory import (
            BufferMemoryStore,
        )

        inner = BufferMemoryStore()
        inner.add_messages(
            [{"role": "user", "content": "Hello"}],
        )

        store = CompactingMemoryStore(
            inner=inner,
            llm_provider=_make_provider(),
            max_tokens=50000,
        )
        await store.prepare()
        assert store.get_messages() == [
            {"role": "user", "content": "Hello"},
        ]

        # Add new messages => cache invalidated
        store.add_messages(
            [{"role": "assistant", "content": "World"}],
        )
        # get_messages falls back to inner store
        result = store.get_messages()
        assert len(result) == 2
        assert result[1]["content"] == "World"

    @pytest.mark.asyncio
    async def test_get_messages_returns_cached(self) -> None:
        """After prepare(), get_messages returns the cached result."""
        from pygubernator.workflow.nodes._memory import (
            BufferMemoryStore,
        )

        inner = BufferMemoryStore()
        msgs = _make_messages(10)
        inner.add_messages(msgs)

        store = CompactingMemoryStore(
            inner=inner,
            llm_provider=_make_provider("The summary."),
            max_tokens=1,
            preserve_recent=2,
        )
        await store.prepare()

        # Call get_messages twice — should be same cached result
        first = store.get_messages()
        second = store.get_messages()
        assert first == second
        assert first[0]["role"] == "system"

    def test_get_messages_without_prepare(self) -> None:
        """Without calling prepare(), delegates to inner store."""
        from pygubernator.workflow.nodes._memory import (
            BufferMemoryStore,
        )

        inner = BufferMemoryStore()
        msgs = [{"role": "user", "content": "test"}]
        inner.add_messages(msgs)

        store = CompactingMemoryStore(
            inner=inner,
            llm_provider=_make_provider(),
            max_tokens=50000,
        )
        assert store.get_messages() == msgs


# -------------------------------------------------------------------
# create_memory_store with "compacting" type
# -------------------------------------------------------------------


class TestCreateMemoryStoreCompacting:
    """Test the factory function with compacting memory type."""

    def test_creates_compacting_store(self) -> None:
        provider = _make_provider()
        store = create_memory_store(
            memory_type="compacting",
            config={
                "llm_provider": provider,
                "max_tokens": 4000,
                "preserve_recent": 2,
                "model": "gpt-4o",
            },
        )
        assert isinstance(store, CompactingMemoryStore)

    def test_compacting_defaults(self) -> None:
        store = create_memory_store(
            memory_type="compacting",
            config={"llm_provider": _make_provider()},
        )
        assert isinstance(store, CompactingMemoryStore)
        assert store._max_tokens == 8000
        assert store._preserve_recent == 4
        assert store._model == ""
