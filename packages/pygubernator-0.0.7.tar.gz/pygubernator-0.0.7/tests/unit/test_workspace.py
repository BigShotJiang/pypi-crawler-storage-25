"""Tests for multi-tenancy workspace support."""

from __future__ import annotations

from typing import Any

import pytest
from sqlalchemy.orm import Session

from pygubernator.api.deps import get_workspace_id
from pygubernator.db.models import (
    Agent,
    ChatSessionRecord,
    NotificationRule,
    ScheduledJob,
    WebhookTrigger,
    Workflow,
)
from tests.unit.conftest import reset_test_db, test_engine


@pytest.fixture(autouse=True)
def _reset_db() -> None:
    reset_test_db()


def _insert_and_check(model_cls: type, **kwargs: Any) -> str:
    """Insert a model row and return its workspace_id."""
    with Session(test_engine) as sess:
        obj = model_cls(**kwargs)
        sess.add(obj)
        sess.commit()
        sess.refresh(obj)
        return obj.workspace_id


class TestWorkspaceIdDefault:
    """Verify workspace_id defaults to 'default' on INSERT."""

    def test_agent_defaults_to_default(self) -> None:
        """Agent.workspace_id defaults to 'default'."""
        ws = _insert_and_check(
            Agent,
            name="test-agent",
            owner="test",
        )
        assert ws == "default"

    def test_workflow_defaults_to_default(self) -> None:
        """Workflow.workspace_id defaults to 'default'."""
        ws = _insert_and_check(
            Workflow,
            name="test-wf",
            owner="test",
        )
        assert ws == "default"

    def test_scheduled_job_defaults_to_default(
        self,
    ) -> None:
        """ScheduledJob.workspace_id defaults to 'default'."""
        ws = _insert_and_check(
            ScheduledJob,
            workflow_id="abc",
            cron_expression="* * * * *",
        )
        assert ws == "default"

    def test_webhook_trigger_defaults_to_default(
        self,
    ) -> None:
        """WebhookTrigger.workspace_id defaults."""
        ws = _insert_and_check(
            WebhookTrigger,
            workflow_id="abc",
            token="tok123",
        )
        assert ws == "default"

    def test_chat_session_defaults_to_default(
        self,
    ) -> None:
        """ChatSessionRecord.workspace_id defaults."""
        ws = _insert_and_check(ChatSessionRecord)
        assert ws == "default"

    def test_notification_rule_defaults_to_default(
        self,
    ) -> None:
        """NotificationRule.workspace_id defaults."""
        ws = _insert_and_check(
            NotificationRule,
            name="r",
            event_type="run.completed",
            channel_type="email",
        )
        assert ws == "default"

    def test_agent_accepts_custom_workspace(
        self,
    ) -> None:
        """workspace_id can be set explicitly."""
        ws = _insert_and_check(
            Agent,
            name="custom-agent",
            owner="test",
            workspace_id="acme-corp",
        )
        assert ws == "acme-corp"


class TestGetWorkspaceId:
    """Tests for the get_workspace_id dependency."""

    def test_extracts_workspace_from_actor(self) -> None:
        """When the actor has workspace_id, use it."""
        actor: dict[str, Any] = {
            "actor": "alice",
            "role": "User",
            "workspace_id": "acme-corp",
            "auth_disabled": False,
        }
        assert get_workspace_id(actor) == "acme-corp"

    def test_defaults_when_missing(self) -> None:
        """Missing workspace_id falls back to 'default'."""
        actor: dict[str, Any] = {
            "actor": "bob",
            "role": "User",
            "auth_disabled": False,
        }
        assert get_workspace_id(actor) == "default"

    def test_defaults_with_auth_disabled(self) -> None:
        """Auth-disabled actors also get 'default'."""
        actor: dict[str, Any] = {
            "actor": "anonymous",
            "role": "Admin",
            "auth_disabled": True,
        }
        assert get_workspace_id(actor) == "default"


class TestWorkspaceIdDependencyType:
    """Verify the WorkspaceId annotated type is importable."""

    def test_workspace_id_importable(self) -> None:
        """WorkspaceId alias can be imported."""
        from pygubernator.api.deps import WorkspaceId

        assert WorkspaceId is not None
