"""Tests for catalyst and stator tool factory and converter integration."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from pygubernator.workflow._types import WorkflowSpec
from pygubernator.workflow.config._converter import (
    _TOOL_TYPE_PRESETS,
    workflow_config_to_spec,
)
from pygubernator.workflow.config._models import (
    EdgeDef,
    NodeDef,
    WorkflowConfig,
    WorkflowMeta,
)
from pygubernator.workflow.tool_presets import (
    TOOL_INTEGRATION_PRESETS,
)


class TestToolPresetRegistry:
    """Verify catalyst and stator appear in the preset list."""

    def test_catalyst_preset_exists(self) -> None:
        ids = {p.id for p in TOOL_INTEGRATION_PRESETS}
        assert "catalyst" in ids

    def test_stator_preset_exists(self) -> None:
        ids = {p.id for p in TOOL_INTEGRATION_PRESETS}
        assert "stator" in ids

    def test_catalyst_preset_fields(self) -> None:
        preset = next(p for p in TOOL_INTEGRATION_PRESETS if p.id == "catalyst")
        assert preset.name == "catalyst"
        assert "catalyst_factory" in preset.factory_module
        assert preset.factory_function == "create_tools_from_env"

    def test_stator_preset_fields(self) -> None:
        preset = next(p for p in TOOL_INTEGRATION_PRESETS if p.id == "stator")
        assert preset.name == "stator"
        assert "stator_factory" in preset.factory_module
        assert preset.factory_function == "create_tools_from_env"


class TestConverterPresets:
    """Verify _TOOL_TYPE_PRESETS contains the new entries."""

    def test_tool_catalyst_in_presets(self) -> None:
        assert "tool_catalyst" in _TOOL_TYPE_PRESETS
        entry = _TOOL_TYPE_PRESETS["tool_catalyst"]
        assert entry["name"] == "catalyst"
        assert "catalyst_factory" in entry["factory_module"]

    def test_tool_stator_in_presets(self) -> None:
        assert "tool_stator" in _TOOL_TYPE_PRESETS
        entry = _TOOL_TYPE_PRESETS["tool_stator"]
        assert entry["name"] == "stator"
        assert "stator_factory" in entry["factory_module"]


class TestNodeDefAcceptance:
    """Verify _models.py accepts the new node types."""

    def test_tool_catalyst_node_def(self) -> None:
        node = NodeDef(type="tool_catalyst", config={"name": "catalyst"})
        assert node.type == "tool_catalyst"

    def test_tool_stator_node_def(self) -> None:
        node = NodeDef(type="tool_stator", config={"name": "stator"})
        assert node.type == "tool_stator"


class TestConverterMergesToolNodes:
    """Verify converter resolves catalyst/stator sub-nodes."""

    def test_catalyst_merged_into_agent(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test"),
            nodes={
                "in": NodeDef(type="input"),
                "agent": NodeDef(type="agent"),
                "cat": NodeDef(
                    type="tool_catalyst",
                    config={"name": "my_catalyst"},
                ),
                "out": NodeDef(type="output"),
            },
            edges=[
                EdgeDef(source="in", target="agent"),
                EdgeDef(
                    source="cat",
                    target="agent",
                    target_handle="sub:tool",
                ),
                EdgeDef(source="agent", target="out"),
            ],
        )
        spec = workflow_config_to_spec(config)
        assert isinstance(spec, WorkflowSpec)
        # Sub-node should be removed; agent should have tools
        assert "cat" not in spec.nodes
        agent_cfg = spec.nodes["agent"].config
        assert "tools" in agent_cfg
        assert "my_catalyst" in agent_cfg["tools"]
        tool_entry = agent_cfg["tools"]["my_catalyst"]
        assert "catalyst_factory" in tool_entry["factory_module"]

    def test_stator_merged_into_agent(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test"),
            nodes={
                "in": NodeDef(type="input"),
                "agent": NodeDef(type="agent"),
                "sm": NodeDef(
                    type="tool_stator",
                    config={"name": "my_stator"},
                ),
                "out": NodeDef(type="output"),
            },
            edges=[
                EdgeDef(source="in", target="agent"),
                EdgeDef(
                    source="sm",
                    target="agent",
                    target_handle="sub:tool",
                ),
                EdgeDef(source="agent", target="out"),
            ],
        )
        spec = workflow_config_to_spec(config)
        assert isinstance(spec, WorkflowSpec)
        assert "sm" not in spec.nodes
        agent_cfg = spec.nodes["agent"].config
        assert "tools" in agent_cfg
        assert "my_stator" in agent_cfg["tools"]
        tool_entry = agent_cfg["tools"]["my_stator"]
        assert "stator_factory" in tool_entry["factory_module"]


class TestCatalystFactory:
    """Test catalyst_factory.create_tools_from_env."""

    @patch("pygubernator.tools.catalyst_factory._default_schemas")
    @patch("pygubernator.tools.catalyst_tools.create_catalyst_tools")
    def test_uses_defaults_when_no_env(
        self,
        mock_create: MagicMock,
        mock_schemas: MagicMock,
    ) -> None:
        demo_schema = MagicMock()
        mock_schemas.return_value = {"demo": demo_schema}
        mock_create.return_value = [MagicMock(), MagicMock()]

        from pygubernator.tools.catalyst_factory import (
            create_tools_from_env,
        )

        with patch.dict("os.environ", {}, clear=False):
            tools = create_tools_from_env()

        mock_schemas.assert_called_once()
        mock_create.assert_called_once_with({"demo": demo_schema})
        assert len(tools) == 2

    @patch("pygubernator.tools.catalyst_factory._load_schemas_from_file")
    @patch("pygubernator.tools.catalyst_tools.create_catalyst_tools")
    def test_uses_file_when_env_set(
        self,
        mock_create: MagicMock,
        mock_load: MagicMock,
    ) -> None:
        mock_load.return_value = {"custom": MagicMock()}
        mock_create.return_value = [MagicMock()]

        from pygubernator.tools.catalyst_factory import (
            create_tools_from_env,
        )

        with patch.dict(
            "os.environ",
            {"PYGUBERNATOR_CATALYST_SCHEMAS_PATH": "/tmp/s.yaml"},
        ):
            tools = create_tools_from_env()

        mock_load.assert_called_once_with("/tmp/s.yaml")
        assert len(tools) == 1


class TestStatorFactory:
    """Test stator_factory.create_tools_from_env."""

    @patch("pygubernator.tools.stator_factory._default_machines")
    @patch("pygubernator.tools.stator_tools.create_stator_tools")
    def test_uses_defaults_when_no_env(
        self,
        mock_create: MagicMock,
        mock_machines: MagicMock,
    ) -> None:
        mock_machines.return_value = {"demo": MagicMock()}
        mock_create.return_value = [MagicMock()] * 5

        from pygubernator.tools.stator_factory import (
            create_tools_from_env,
        )

        with patch.dict("os.environ", {}, clear=False):
            tools = create_tools_from_env()

        mock_machines.assert_called_once()
        mock_create.assert_called_once()
        assert len(tools) == 5

    @patch("pygubernator.tools.stator_factory._load_machines_from_file")
    @patch("pygubernator.tools.stator_tools.create_stator_tools")
    def test_uses_file_when_env_set(
        self,
        mock_create: MagicMock,
        mock_load: MagicMock,
    ) -> None:
        mock_load.return_value = {"custom": MagicMock()}
        mock_create.return_value = [MagicMock()]

        from pygubernator.tools.stator_factory import (
            create_tools_from_env,
        )

        with patch.dict(
            "os.environ",
            {"PYGUBERNATOR_STATOR_MACHINES_PATH": "/tmp/m.yaml"},
        ):
            tools = create_tools_from_env()

        mock_load.assert_called_once_with("/tmp/m.yaml")
        assert len(tools) == 1
