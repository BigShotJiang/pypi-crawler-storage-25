"""Tests for pygubernator exception hierarchy."""

from __future__ import annotations

from pygubernator.errors import (
    AgentError,
    ConfigError,
    ErrorCode,
    GubernatorError,
    LLMError,
    PipelineStepError,
    ToolError,
    TransportError,
)


class TestGubernatorError:
    """Tests for base GubernatorError."""

    def test_basic(self) -> None:
        err = GubernatorError("something failed")
        assert str(err) == "something failed"
        assert err.context == {}
        assert err.code is None

    def test_with_context_and_code(self) -> None:
        err = GubernatorError(
            "failed",
            context={"key": "val"},
            code=ErrorCode.AGENT_FAILED,
        )
        assert err.context == {"key": "val"}
        assert err.code == ErrorCode.AGENT_FAILED

    def test_to_dict(self) -> None:
        err = GubernatorError("msg", code=ErrorCode.TOOL_FAILED)
        d = err.to_dict()
        assert d["error_type"] == "GubernatorError"
        assert d["message"] == "msg"
        assert d["code"] == "TOOL_FAILED"

    def test_is_exception(self) -> None:
        assert issubclass(GubernatorError, Exception)


class TestSubclasses:
    """Tests for error subclasses."""

    def test_agent_error(self) -> None:
        err = AgentError("fail", agent_id="agent-1")
        assert err.agent_id == "agent-1"
        assert err.context["agent_id"] == "agent-1"
        assert err.code == ErrorCode.AGENT_FAILED
        assert isinstance(err, GubernatorError)

    def test_tool_error(self) -> None:
        err = ToolError("fail", tool_name="search")
        assert err.tool_name == "search"
        assert isinstance(err, GubernatorError)

    def test_transport_error(self) -> None:
        err = TransportError("fail", transport_type="kafka")
        assert err.transport_type == "kafka"
        assert isinstance(err, GubernatorError)

    def test_llm_error(self) -> None:
        err = LLMError("fail", provider="openai")
        assert err.provider == "openai"
        assert isinstance(err, GubernatorError)

    def test_pipeline_step_error(self) -> None:
        err = PipelineStepError("fail", step_name="extract")
        assert err.step_name == "extract"
        assert isinstance(err, GubernatorError)

    def test_config_error(self) -> None:
        err = ConfigError("fail", path="/etc/config.yaml")
        assert err.path == "/etc/config.yaml"
        assert isinstance(err, GubernatorError)
