"""Tests for integration credential encryption and helpers."""

from __future__ import annotations

import base64
import os
from unittest.mock import MagicMock, patch

import pytest

from pygubernator.config.integrations import (
    KNOWN_PROVIDERS,
    _derive_key,
    decrypt_value,
    encrypt_value,
    inject_credentials,
    mask_value,
)


class TestDeriveKey:
    """Tests for _derive_key."""

    def test_returns_bytes(self) -> None:
        key = _derive_key("test-secret")
        assert isinstance(key, bytes)

    def test_length_is_44_base64(self) -> None:
        key = _derive_key("test-secret")
        # url-safe base64 of 32 bytes = 44 chars
        assert len(key) == 44

    def test_deterministic(self) -> None:
        assert _derive_key("same") == _derive_key("same")

    def test_different_secrets_differ(self) -> None:
        assert _derive_key("a") != _derive_key("b")


class TestEncryptDecrypt:
    """Tests for encrypt_value / decrypt_value round-trip."""

    def test_round_trip(self) -> None:
        secret = "my-jwt-secret"
        plaintext = "sk-abc123456789"
        encrypted = encrypt_value(plaintext, secret)
        assert encrypted != plaintext
        decrypted = decrypt_value(encrypted, secret)
        assert decrypted == plaintext

    def test_different_secrets_fail(self) -> None:
        encrypted = encrypt_value("hello", "secret-A")
        with pytest.raises(Exception):
            decrypt_value(encrypted, "secret-B")

    def test_empty_string(self) -> None:
        secret = "s"
        assert decrypt_value(encrypt_value("", secret), secret) == ""

    def test_unicode(self) -> None:
        secret = "key"
        text = "credential-with-emoji"
        assert decrypt_value(encrypt_value(text, secret), secret) == text


class TestEncryptDecryptFallback:
    """Tests for base64 fallback when cryptography is absent."""

    def test_fallback_round_trip(self) -> None:
        with patch("pygubernator.config.integrations._HAS_CRYPTO", False):
            secret = "ignored"
            plaintext = "my-token-value"
            encoded = encrypt_value(plaintext, secret)
            # Should be plain base64
            assert base64.b64decode(encoded).decode("utf-8") == plaintext
            decoded = decrypt_value(encoded, secret)
            assert decoded == plaintext


class TestMaskValue:
    """Tests for mask_value."""

    def test_long_value(self) -> None:
        assert mask_value("abcdefghijklmnop") == "abcd****mnop"

    def test_short_value(self) -> None:
        assert mask_value("short") == "****"

    def test_exactly_10_chars(self) -> None:
        assert mask_value("1234567890") == "****"

    def test_eleven_chars(self) -> None:
        assert mask_value("12345678901") == "1234****8901"

    def test_empty(self) -> None:
        assert mask_value("") == "****"


class TestKnownProviders:
    """Tests for KNOWN_PROVIDERS dict."""

    def test_has_expected_keys(self) -> None:
        expected = {
            "google_sheets",
            "google_docs",
            "slack",
            "notion",
            "sql",
            "http",
            "obsidian",
            "python",
            "catalyst",
            "stator",
        }
        assert set(KNOWN_PROVIDERS.keys()) == expected

    def test_each_has_env_var_and_type(self) -> None:
        for name, info in KNOWN_PROVIDERS.items():
            assert "env_var" in info, f"{name} missing env_var"
            assert "type" in info, f"{name} missing type"


class TestInjectCredentials:
    """Tests for inject_credentials."""

    def test_skips_when_no_secret(self) -> None:
        session = MagicMock()
        with patch(
            "pygubernator.config.integrations.get_auth_jwt_secret",
            return_value=None,
        ):
            inject_credentials(session)
        # Should not query DB at all
        session.query.assert_not_called()

    def test_sets_env_vars(self) -> None:
        secret = "test-secret-123"
        encrypted = encrypt_value("my-api-key", secret)
        row = MagicMock()
        row.name = "slack-token"
        row.env_var = "PYGUBERNATOR_TEST_INJECT"
        row.encrypted_value = encrypted

        session = MagicMock()
        query = session.query.return_value
        query.filter.return_value.all.return_value = [row]

        with patch(
            "pygubernator.config.integrations.get_auth_jwt_secret",
            return_value=secret,
        ):
            inject_credentials(session)

        assert os.environ.get("PYGUBERNATOR_TEST_INJECT") == "my-api-key"
        # Clean up
        os.environ.pop("PYGUBERNATOR_TEST_INJECT", None)

    def test_handles_decrypt_error(self) -> None:
        row = MagicMock()
        row.name = "bad-cred"
        row.env_var = "PYGUBERNATOR_BAD_CRED"
        row.encrypted_value = "not-valid-ciphertext"

        session = MagicMock()
        query = session.query.return_value
        query.filter.return_value.all.return_value = [row]

        with patch(
            "pygubernator.config.integrations.get_auth_jwt_secret",
            return_value="secret",
        ):
            # Should not raise, just log the error
            inject_credentials(session)

        assert "PYGUBERNATOR_BAD_CRED" not in os.environ
