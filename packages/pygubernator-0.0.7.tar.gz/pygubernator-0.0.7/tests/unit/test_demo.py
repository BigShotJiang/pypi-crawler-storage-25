"""Tests for demo data factories and demo provider."""

from __future__ import annotations

from pygubernator.chat._demo_provider import DemoLLMProvider
from pygubernator.llm._messages import LLMResponse


class TestDemoLLMProvider:
    """Tests for the scripted demo LLM provider."""

    async def test_generate_keyword(self) -> None:
        """'generate' keyword triggers generate_data tool call."""
        provider = DemoLLMProvider()
        messages = [{"role": "user", "content": "Generate 3 orders"}]
        response = await provider.chat(messages)

        assert response.has_tool_calls
        tc = response.tool_calls[0]
        assert tc.name == "generate_data"
        assert tc.arguments["schema_name"] == "orders"
        assert tc.arguments["count"] == 3

    async def test_validate_keyword(self) -> None:
        """'validate' keyword triggers validate_batch tool call."""
        provider = DemoLLMProvider()
        messages = [{"role": "user", "content": "Validate those records"}]
        response = await provider.chat(messages)

        assert response.has_tool_calls
        assert response.tool_calls[0].name == "validate_batch"

    async def test_submit_keyword(self) -> None:
        """'submit' keyword triggers create_session tool call."""
        provider = DemoLLMProvider()
        messages = [{"role": "user", "content": "Submit an order"}]
        response = await provider.chat(messages)

        assert response.has_tool_calls
        tc = response.tool_calls[0]
        assert tc.name == "create_session"
        assert tc.arguments["machine_name"] == "order_lifecycle"

    async def test_unknown_input_returns_help(self) -> None:
        """Unrecognized input returns a help text response."""
        provider = DemoLLMProvider()
        messages = [{"role": "user", "content": "Tell me a joke"}]
        response = await provider.chat(messages)

        assert not response.has_tool_calls
        assert "generate" in response.content.lower()

    async def test_tool_result_followup(self) -> None:
        """After a tool result, provider returns text summary."""
        provider = DemoLLMProvider()
        messages = [
            {"role": "user", "content": "generate data"},
            {
                "role": "assistant",
                "content": "",
                "tool_calls": [
                    {
                        "id": "c1",
                        "type": "function",
                        "function": {
                            "name": "generate_data",
                            "arguments": "{}",
                        },
                    }
                ],
            },
            {
                "role": "tool",
                "tool_call_id": "c1",
                "content": "[{'id': 1}]",
            },
        ]
        response = await provider.chat(messages)

        assert not response.has_tool_calls
        assert "results" in response.content.lower()

    async def test_extract_count_default(self) -> None:
        """Generate without a number uses default count of 5."""
        provider = DemoLLMProvider()
        messages = [{"role": "user", "content": "Generate some orders"}]
        response = await provider.chat(messages)

        assert response.tool_calls[0].arguments["count"] == 5

    async def test_status_keyword(self) -> None:
        """'status' keyword triggers list_triggers tool call."""
        provider = DemoLLMProvider()
        messages = [{"role": "user", "content": "What's the status?"}]
        response = await provider.chat(messages)

        assert response.has_tool_calls
        assert response.tool_calls[0].name == "list_triggers"

    async def test_conforms_to_llm_response(self) -> None:
        """All responses are LLMResponse instances."""
        provider = DemoLLMProvider()
        for msg in ["generate", "validate", "submit", "hello"]:
            response = await provider.chat([{"role": "user", "content": msg}])
            assert isinstance(response, LLMResponse)
