"""Tests for database config, URL resolution, and type detection."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from pygubernator.db.config import (
    detect_db_type,
    get_db_url,
    is_default_db_url,
    require_alembic,
)


class TestDetectDbType:
    """Tests for detect_db_type."""

    def test_sqlite(self) -> None:
        assert detect_db_type("sqlite:///test.db") == "sqlite"

    def test_sqlite_memory(self) -> None:
        assert detect_db_type("sqlite:///:memory:") == "sqlite"

    def test_postgresql(self) -> None:
        url = "postgresql://user:pass@localhost/db"
        assert detect_db_type(url) == "postgresql"

    def test_postgres_short(self) -> None:
        url = "postgres://user:pass@localhost/db"
        assert detect_db_type(url) == "postgresql"

    def test_mongodb(self) -> None:
        assert detect_db_type("mongodb://localhost/db") == "mongodb"

    def test_unknown_defaults_to_sqlite(self) -> None:
        assert detect_db_type("mysql://localhost/db") == "sqlite"


class TestGetDbUrl:
    """Tests for get_db_url."""

    def test_explicit_url_returned(self) -> None:
        url = "sqlite:///explicit.db"
        assert get_db_url(url) == url

    @patch("pygubernator.db.config.get_database_url", return_value=None)
    def test_default_sqlite(self, mock_get: object) -> None:
        url = get_db_url(required=False)
        assert url.startswith("sqlite:///")
        assert url.endswith("pygubernator.db")

    @patch(
        "pygubernator.db.config.get_database_url",
        return_value="postgresql://localhost/mydb",
    )
    def test_env_url_used(self, mock_get: object) -> None:
        url = get_db_url()
        assert url == "postgresql://localhost/mydb"


class TestIsDefaultDbUrl:
    """Tests for is_default_db_url."""

    def test_non_sqlite_is_false(self) -> None:
        assert is_default_db_url("postgresql://localhost/db") is False

    def test_empty_is_false(self) -> None:
        assert is_default_db_url("") is False

    def test_different_sqlite_is_false(self) -> None:
        assert is_default_db_url("sqlite:///other.db") is False


class TestRequireAlembic:
    """Tests for require_alembic."""

    def test_no_error_when_available(self) -> None:
        # Alembic should be installed in dev environment
        require_alembic()

    @patch("pygubernator.db.config.ALEMBIC_AVAILABLE", False)
    def test_raises_when_unavailable(self) -> None:
        with pytest.raises(ImportError, match="alembic"):
            require_alembic()
