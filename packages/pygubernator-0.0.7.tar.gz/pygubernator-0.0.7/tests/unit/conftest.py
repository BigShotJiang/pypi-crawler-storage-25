"""Shared fixtures for unit tests that need a database."""

from __future__ import annotations

import pytest
from sqlalchemy import inspect, text

from pygubernator.db.base import Base, get_engine
from pygubernator.db.session import set_engine

# Single in-memory engine shared across all DB tests, with schema
# stripping enabled so pygubernator-schema models work on SQLite.
test_engine = get_engine("sqlite:///:memory:")
set_engine(test_engine)


@pytest.fixture(autouse=True)
def _ignore_repo_pygubernator_cfg(monkeypatch: pytest.MonkeyPatch) -> None:
    """Ignore workspace cfg and inherited auth; API tests use auth-disabled mode."""
    monkeypatch.setattr(
        "pygubernator.config._helpers.find_config_file",
        lambda *_a, **_k: None,
    )
    monkeypatch.delenv("PYGUBERNATOR_AUTH_USERS", raising=False)
    monkeypatch.delenv("PYGUBERNATOR_AUTH_JWT_SECRET", raising=False)
    monkeypatch.delenv("PYGUBERNATOR_AUTH_SERVICE_URL", raising=False)
    monkeypatch.delenv("PYGUBERNATOR_AUTH_INTROSPECT_PATH", raising=False)


def reset_test_db() -> None:
    """Drop all existing tables and recreate from metadata.

    Uses raw SQL for the drop because ``Base.metadata.drop_all`` relies
    on the inspector to find tables in schema ``pygubernator``, which
    SQLite doesn't support.  After the drop, ``create_all`` succeeds
    because the inspector sees no tables (schema miss) and the DDL has
    the schema prefix stripped by ``get_engine``'s event listener.
    """
    with test_engine.connect() as conn:
        conn.execute(text("PRAGMA foreign_keys=OFF"))
        for name in inspect(test_engine).get_table_names():
            conn.execute(text(f'DROP TABLE IF EXISTS "{name}"'))
        # Also drop alembic_version if present
        conn.execute(text("DROP TABLE IF EXISTS alembic_version"))
        conn.execute(text("PRAGMA foreign_keys=ON"))
        conn.commit()
    Base.metadata.create_all(bind=test_engine)
