"""Tests for Notion tools (mocking the httpx client)."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pygubernator.tools.notion_tools import (
    _NotionClient,
    create_notion_tools,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_response(
    json_data: Any,
    status_code: int = 200,
) -> MagicMock:
    """Build a mock httpx.Response-like object."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data
    resp.raise_for_status = MagicMock()
    return resp


def _make_client() -> tuple[_NotionClient, MagicMock]:
    """Create a _NotionClient with a mocked httpx client."""
    with patch.object(
        _NotionClient,
        "__init__",
        lambda self, *a, **kw: None,
    ):
        client = _NotionClient.__new__(_NotionClient)
        mock_http = MagicMock()
        mock_http.get = AsyncMock()
        mock_http.post = AsyncMock()
        mock_http.patch = AsyncMock()
        client._client = mock_http
        return client, mock_http


def _make_tools(
    mock_http: MagicMock | None = None,
) -> list[Any]:
    """Create tools backed by a mock httpx client."""
    with patch.object(
        _NotionClient,
        "__init__",
        lambda self, *a, **kw: None,
    ):
        tools = create_notion_tools("fake-api-key")

    if mock_http is None:
        return tools

    # Patch the _client attribute on the _NotionClient captured
    # inside the closure.
    for t in tools:
        fn = t._func
        if hasattr(fn, "__closure__") and fn.__closure__:
            for cell in fn.__closure__:
                obj = cell.cell_contents
                if isinstance(obj, _NotionClient):
                    obj._client = mock_http
                    return tools
    return tools


def _get_tool(tools: list[Any], name: str) -> Any:
    """Find a tool by name."""
    return next(t for t in tools if t.name == name)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestNotionToolsFactory:
    """Tests for create_notion_tools factory."""

    def test_returns_six_tools(self) -> None:
        tools = _make_tools()
        assert len(tools) == 6

    def test_tool_names(self) -> None:
        tools = _make_tools()
        names = {t.name for t in tools}
        assert names == {
            "notion_search",
            "notion_get_page",
            "notion_create_page",
            "notion_update_page",
            "notion_get_blocks",
            "notion_append_blocks",
        }

    def test_all_tools_have_schemas(self) -> None:
        tools = _make_tools()
        for t in tools:
            schema = t.parameters_schema
            assert schema["type"] == "object"
            assert "properties" in schema


# ---------------------------------------------------------------------------
# _NotionClient unit tests
# ---------------------------------------------------------------------------


class TestNotionClient:
    """Tests for the _NotionClient wrapper."""

    @pytest.mark.asyncio
    async def test_search(self) -> None:
        client, mock_http = _make_client()
        mock_http.post.return_value = _mock_response(
            {
                "results": [
                    {
                        "object": "page",
                        "id": "page-1",
                        "properties": {
                            "Name": {
                                "type": "title",
                                "title": [
                                    {"plain_text": "My Page"},
                                ],
                            },
                        },
                    },
                ],
            }
        )

        results = await client.search("My Page")

        assert len(results) == 1
        assert results[0]["id"] == "page-1"
        assert results[0]["title"] == "My Page"
        assert results[0]["object"] == "page"

    @pytest.mark.asyncio
    async def test_search_with_filter(self) -> None:
        client, mock_http = _make_client()
        mock_http.post.return_value = _mock_response(
            {
                "results": [],
            }
        )

        await client.search("query", filter_type="database")

        call_kwargs = mock_http.post.call_args
        body = call_kwargs.kwargs.get("json") or call_kwargs[1].get(
            "json",
        )
        assert body["filter"]["value"] == "database"

    @pytest.mark.asyncio
    async def test_search_database_title(self) -> None:
        client, mock_http = _make_client()
        mock_http.post.return_value = _mock_response(
            {
                "results": [
                    {
                        "object": "database",
                        "id": "db-1",
                        "title": [{"plain_text": "Tasks"}],
                        "properties": {},
                    },
                ],
            }
        )

        results = await client.search("Tasks")

        assert results[0]["title"] == "Tasks"

    @pytest.mark.asyncio
    async def test_get_page(self) -> None:
        client, mock_http = _make_client()
        mock_http.get.return_value = _mock_response(
            {
                "id": "page-1",
                "url": "https://notion.so/page-1",
                "properties": {
                    "Name": {
                        "type": "title",
                        "title": [{"plain_text": "Test"}],
                    },
                },
            }
        )

        result = await client.get_page("page-1")

        assert result["id"] == "page-1"
        assert result["url"] == "https://notion.so/page-1"
        assert result["title"] == "Test"

    @pytest.mark.asyncio
    async def test_create_page(self) -> None:
        client, mock_http = _make_client()
        mock_http.post.return_value = _mock_response(
            {
                "id": "new-page",
                "url": "https://notion.so/new-page",
            }
        )

        result = await client.create_page(
            parent_id="parent-1",
            title="New Page",
        )

        assert result["id"] == "new-page"
        assert result["url"] == "https://notion.so/new-page"

    @pytest.mark.asyncio
    async def test_create_page_with_content(self) -> None:
        client, mock_http = _make_client()
        mock_http.post.return_value = _mock_response(
            {
                "id": "new-page",
                "url": "https://notion.so/new-page",
            }
        )

        await client.create_page(
            parent_id="parent-1",
            title="New",
            content="Hello world",
        )

        call_kwargs = mock_http.post.call_args
        body = call_kwargs.kwargs.get("json") or call_kwargs[1].get(
            "json",
        )
        assert "children" in body
        block = body["children"][0]
        text = block["paragraph"]["rich_text"][0]["text"]
        assert text["content"] == "Hello world"

    @pytest.mark.asyncio
    async def test_create_page_with_properties(self) -> None:
        client, mock_http = _make_client()
        mock_http.post.return_value = _mock_response(
            {
                "id": "new-page",
                "url": "https://notion.so/new-page",
            }
        )

        props = {"Status": {"select": {"name": "Done"}}}
        await client.create_page(
            parent_id="db-1",
            title="Task",
            properties=props,
        )

        call_kwargs = mock_http.post.call_args
        body = call_kwargs.kwargs.get("json") or call_kwargs[1].get(
            "json",
        )
        assert body["parent"] == {"database_id": "db-1"}
        assert "Status" in body["properties"]

    @pytest.mark.asyncio
    async def test_update_page(self) -> None:
        client, mock_http = _make_client()
        mock_http.patch.return_value = _mock_response(
            {
                "id": "page-1",
            }
        )

        result = await client.update_page(
            "page-1",
            {"Status": {"select": {"name": "In Progress"}}},
        )

        assert result["id"] == "page-1"

    @pytest.mark.asyncio
    async def test_get_blocks(self) -> None:
        client, mock_http = _make_client()
        mock_http.get.return_value = _mock_response(
            {
                "results": [
                    {
                        "type": "paragraph",
                        "paragraph": {
                            "rich_text": [
                                {"plain_text": "Hello"},
                            ],
                        },
                    },
                ],
            }
        )

        blocks = await client.get_blocks("page-1")

        assert len(blocks) == 1
        assert blocks[0]["type"] == "paragraph"

    @pytest.mark.asyncio
    async def test_get_blocks_with_limit(self) -> None:
        client, mock_http = _make_client()
        mock_http.get.return_value = _mock_response(
            {
                "results": [],
            }
        )

        await client.get_blocks("page-1", limit=50)

        call_kwargs = mock_http.get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["page_size"] == 50

    @pytest.mark.asyncio
    async def test_append_blocks(self) -> None:
        client, mock_http = _make_client()
        mock_http.patch.return_value = _mock_response(
            {
                "results": [{"type": "paragraph", "id": "blk-1"}],
            }
        )

        children = [
            {
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [
                        {"text": {"content": "New block"}},
                    ],
                },
            },
        ]
        result = await client.append_blocks("page-1", children)

        assert len(result) == 1
        assert result[0]["id"] == "blk-1"


# ---------------------------------------------------------------------------
# Tool execution (end-to-end via @tool wrappers)
# ---------------------------------------------------------------------------


class TestNotionToolExecution:
    """Tests for executing tools through the @tool decorator."""

    @pytest.mark.asyncio
    async def test_search(self) -> None:
        mock_http = MagicMock()
        mock_http.post = AsyncMock(
            return_value=_mock_response(
                {
                    "results": [
                        {
                            "object": "page",
                            "id": "p1",
                            "properties": {
                                "Name": {
                                    "type": "title",
                                    "title": [
                                        {"plain_text": "Found"},
                                    ],
                                },
                            },
                        },
                    ],
                }
            ),
        )
        tools = _make_tools(mock_http)
        t = _get_tool(tools, "notion_search")

        result = await t.execute({"query": "Found"})

        assert result.success
        assert result.output[0]["title"] == "Found"

    @pytest.mark.asyncio
    async def test_get_page(self) -> None:
        mock_http = MagicMock()
        mock_http.get = AsyncMock(
            return_value=_mock_response(
                {
                    "id": "page-1",
                    "url": "https://notion.so/page-1",
                    "properties": {
                        "Name": {
                            "type": "title",
                            "title": [{"plain_text": "Pg"}],
                        },
                    },
                }
            ),
        )
        tools = _make_tools(mock_http)
        t = _get_tool(tools, "notion_get_page")

        result = await t.execute({"page_id": "page-1"})

        assert result.success
        assert result.output["id"] == "page-1"

    @pytest.mark.asyncio
    async def test_create_page(self) -> None:
        mock_http = MagicMock()
        mock_http.post = AsyncMock(
            return_value=_mock_response(
                {
                    "id": "new-page",
                    "url": "https://notion.so/new-page",
                }
            ),
        )
        tools = _make_tools(mock_http)
        t = _get_tool(tools, "notion_create_page")

        result = await t.execute(
            {
                "parent_id": "db-1",
                "title": "Test Page",
            }
        )

        assert result.success
        assert result.output["id"] == "new-page"

    @pytest.mark.asyncio
    async def test_update_page(self) -> None:
        mock_http = MagicMock()
        mock_http.patch = AsyncMock(
            return_value=_mock_response({"id": "page-1"}),
        )
        tools = _make_tools(mock_http)
        t = _get_tool(tools, "notion_update_page")

        result = await t.execute(
            {
                "page_id": "page-1",
                "properties": {"Status": {"select": {"name": "Done"}}},
            }
        )

        assert result.success
        assert result.output["id"] == "page-1"

    @pytest.mark.asyncio
    async def test_get_blocks(self) -> None:
        mock_http = MagicMock()
        mock_http.get = AsyncMock(
            return_value=_mock_response(
                {
                    "results": [{"type": "heading_1", "id": "b1"}],
                }
            ),
        )
        tools = _make_tools(mock_http)
        t = _get_tool(tools, "notion_get_blocks")

        result = await t.execute({"block_id": "page-1"})

        assert result.success
        assert len(result.output) == 1

    @pytest.mark.asyncio
    async def test_append_blocks(self) -> None:
        mock_http = MagicMock()
        mock_http.patch = AsyncMock(
            return_value=_mock_response(
                {
                    "results": [{"type": "paragraph", "id": "b2"}],
                }
            ),
        )
        tools = _make_tools(mock_http)
        t = _get_tool(tools, "notion_append_blocks")

        children = [
            {
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [
                        {"text": {"content": "Hello"}},
                    ],
                },
            },
        ]
        result = await t.execute(
            {
                "block_id": "page-1",
                "children": children,
            }
        )

        assert result.success
        assert result.output[0]["id"] == "b2"

    @pytest.mark.asyncio
    async def test_api_error_returns_failure(self) -> None:
        mock_http = MagicMock()
        mock_http.get = AsyncMock(
            side_effect=RuntimeError("rate limited"),
        )
        tools = _make_tools(mock_http)
        t = _get_tool(tools, "notion_get_page")

        result = await t.execute({"page_id": "page-1"})

        assert not result.success
        assert "rate limited" in result.error


# ---------------------------------------------------------------------------
# Factory (env-based)
# ---------------------------------------------------------------------------


class TestNotionFactory:
    """Tests for the notion_factory module."""

    def test_missing_env_raises(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from pygubernator.tools import notion_factory

        monkeypatch.delenv(
            "PYGUBERNATOR_NOTION_API_KEY",
            raising=False,
        )
        with pytest.raises(ValueError):
            notion_factory.create_tools_from_env()

    def test_uses_env_key(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from pygubernator.tools import notion_factory

        seen: dict[str, str] = {}

        def fake_create(api_key: str) -> list[Any]:
            seen["api_key"] = api_key
            return []

        monkeypatch.setenv(
            "PYGUBERNATOR_NOTION_API_KEY",
            "ntn_fake_key",
        )
        monkeypatch.setattr(
            notion_factory,
            "create_notion_tools",
            fake_create,
        )
        tools = notion_factory.create_tools_from_env()
        assert tools == []
        assert seen["api_key"] == "ntn_fake_key"

    def test_custom_env_name(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from pygubernator.tools import notion_factory

        seen: dict[str, str] = {}

        def fake_create(api_key: str) -> list[Any]:
            seen["api_key"] = api_key
            return []

        monkeypatch.setenv("CUSTOM_NOTION_KEY", "ntn_custom")
        monkeypatch.setattr(
            notion_factory,
            "create_notion_tools",
            fake_create,
        )
        tools = notion_factory.create_tools_from_env(
            "CUSTOM_NOTION_KEY",
        )
        assert tools == []
        assert seen["api_key"] == "ntn_custom"


# ---------------------------------------------------------------------------
# Dependency check
# ---------------------------------------------------------------------------


class TestNotionDependencyCheck:
    """Tests for missing httpx dependency handling."""

    def test_missing_httpx_raises(self) -> None:
        with (
            patch(
                "pygubernator.tools.notion_tools._HAS_HTTPX",
                False,
            ),
            pytest.raises(ImportError, match="httpx"),
        ):
            _NotionClient("fake-key")
