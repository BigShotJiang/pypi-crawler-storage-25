"""Tests for LLMNode."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

from pygubernator._types import AgentResult
from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._llm import LLMNode, LLMNodeFactory


def _mock_provider(response_text: str = "Hello!") -> MagicMock:
    """Create a mock LLM provider."""
    provider = MagicMock()
    provider.chat = AsyncMock(
        return_value=MagicMock(
            content=response_text,
            tool_calls=[],
        ),
    )
    return provider


def _mock_tool_registry() -> MagicMock:
    """Create a mock tool registry."""
    registry = MagicMock()
    registry.list_tools.return_value = []
    registry.get_schemas.return_value = []
    return registry


class TestLLMNode:
    """Tests for LLMNode."""

    async def test_basic_prompt(self) -> None:
        provider = _mock_provider("Generated response")
        node = LLMNode(
            "llm1",
            config={
                "prompt_template": "Summarize: {{ text }}",
                "max_iterations": 1,
            },
            llm_provider=provider,
            tool_registry=_mock_tool_registry(),
        )
        ctx = NodeContext(
            node_id="llm1",
            input_data={"text": "Some text"},
        )

        # Mock the agent process method to avoid full LLM agent execution
        agent_result = AgentResult(
            agent_id="llm_node_llm1",
            success=True,
            messages_processed=1,
            metadata={"response": "Generated response"},
        )
        node_module = "pygubernator.workflow.nodes._llm"
        from unittest.mock import patch

        with patch(f"{node_module}.LLMAgent") as mock_agent_cls:
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_agent_cls.return_value = mock_agent

            result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        assert result.output["response"] == "Generated response"

    async def test_no_prompt_template_fails(self) -> None:
        node = LLMNode(
            "llm1",
            config={},
            llm_provider=_mock_provider(),
        )
        ctx = NodeContext(node_id="llm1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "prompt_template" in (result.error or "")

    async def test_template_error_fails(self) -> None:
        node = LLMNode(
            "llm1",
            config={"prompt_template": "{{ undefined }}"},
            llm_provider=_mock_provider(),
        )
        ctx = NodeContext(node_id="llm1", input_data={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "template" in (result.error or "").lower()

    async def test_agent_failure(self) -> None:
        node = LLMNode(
            "llm1",
            config={"prompt_template": "Hello"},
            llm_provider=_mock_provider(),
            tool_registry=_mock_tool_registry(),
        )
        ctx = NodeContext(node_id="llm1")

        from unittest.mock import patch

        with patch(
            "pygubernator.workflow.nodes._llm.LLMAgent",
        ) as mock_cls:
            mock_cls.side_effect = RuntimeError("LLM unavailable")
            result = await node.execute(ctx)

        assert result.status == NodeStatus.FAILED
        assert "LLM" in (result.error or "")

    async def test_uses_variables_in_prompt(self) -> None:
        agent_result = AgentResult(
            agent_id="llm_node_llm1",
            success=True,
            messages_processed=1,
            metadata={"response": "OK"},
        )

        node = LLMNode(
            "llm1",
            config={"prompt_template": "Mode: {{ mode }}"},
            llm_provider=_mock_provider(),
            tool_registry=_mock_tool_registry(),
        )
        ctx = NodeContext(
            node_id="llm1",
            input_data={},
            variables={"mode": "test"},
        )

        from unittest.mock import patch

        with patch(
            "pygubernator.workflow.nodes._llm.LLMAgent",
        ) as mock_cls:
            mock_agent = MagicMock()
            mock_agent.process = AsyncMock(return_value=agent_result)
            mock_cls.return_value = mock_agent
            result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS

    def test_factory(self) -> None:
        provider = _mock_provider()
        factory = LLMNodeFactory(
            llm_provider=provider,
            tool_registry=_mock_tool_registry(),
        )
        node = factory.create("llm1", {"prompt_template": "hi"})
        assert isinstance(node, LLMNode)
        assert node.node_type == "llm"

    def test_factory_without_tool_registry(self) -> None:
        provider = _mock_provider()
        factory = LLMNodeFactory(llm_provider=provider)
        node = factory.create("llm1", {"prompt_template": "hi"})
        assert isinstance(node, LLMNode)
