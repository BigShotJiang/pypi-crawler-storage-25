"""Tests for the builder-pattern Agent API."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from pygubernator._types import AgentResult
from pygubernator.builder._agent import Agent, AgentBuilder
from pygubernator.builder._types import AgentResponse
from pygubernator.errors import ConfigError
from pygubernator.llm._messages import LLMResponse
from pygubernator.tools._decorator import _DecoratedTool
from pygubernator.workflow.nodes._memory import BufferMemoryStore


def _make_llm_response(
    content: str = "response text",
    tool_calls: tuple[Any, ...] = (),
    finish_reason: str = "stop",
) -> LLMResponse:
    """Build a mock LLMResponse."""
    return LLMResponse(
        content=content,
        tool_calls=tool_calls,
        finish_reason=finish_reason,
    )


def _mock_provider(
    responses: list[LLMResponse] | None = None,
) -> MagicMock:
    """Create a mock LLM provider that returns canned responses."""
    provider = MagicMock()
    resp_list = list(responses or [_make_llm_response()])
    idx = {"i": 0}

    async def _chat(
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        r = resp_list[min(idx["i"], len(resp_list) - 1)]
        idx["i"] += 1
        return r

    provider.chat = _chat
    return provider


class TestAgentBuilder:
    """Tests for AgentBuilder validation and construction."""

    def test_build_without_model_raises(self) -> None:
        """Building without a model must raise ConfigError."""
        builder = Agent.builder()
        with pytest.raises(ConfigError, match="Model must be set"):
            builder.build()

    @patch("pygubernator.builder._agent.create_provider")
    def test_build_with_model_succeeds(self, mock_create: MagicMock) -> None:
        """Building with a model should produce an Agent."""
        mock_create.return_value = _mock_provider()
        agent = Agent.builder().model("gpt-4o", api_key="sk-test").build()
        assert isinstance(agent, Agent)
        mock_create.assert_called_once_with(
            "gpt-4o",
            api_key="sk-test",
            api_base=None,
            max_tokens=4096,
            temperature=0.0,
        )

    @patch("pygubernator.builder._agent.create_provider")
    def test_tools_are_registered(self, mock_create: MagicMock) -> None:
        """Tools passed to the builder are registered."""
        mock_create.return_value = _mock_provider()
        mock_tool = MagicMock()
        mock_tool.name = "my_tool"
        agent = Agent.builder().model("gpt-4o").tools([mock_tool]).build()
        inner = agent.inner
        assert inner._tools is not None
        assert inner._tools.has("my_tool")

    @patch("pygubernator.builder._agent.create_provider")
    def test_memory_type_stored(self, mock_create: MagicMock) -> None:
        """Memory type is stored for session creation."""
        mock_create.return_value = _mock_provider()
        agent = Agent.builder().model("gpt-4o").memory("window", window_size=5).build()
        assert agent._memory_type == "window"
        assert agent._window_size == 5

    @patch("pygubernator.builder._agent.create_provider")
    def test_chaining_all_options(self, mock_create: MagicMock) -> None:
        """All builder methods return self for chaining."""
        mock_create.return_value = _mock_provider()
        from pygubernator._events import EventBus

        bus = EventBus()
        agent = (
            Agent.builder()
            .model("gpt-4o")
            .system_prompt("Be helpful.")
            .tools([])
            .memory("buffer")
            .max_iterations(5)
            .event_bus(bus)
            .agent_id("custom-agent")
            .build()
        )
        assert agent.agent_id == "custom-agent"

    def test_builder_returns_agent_builder(self) -> None:
        """Agent.builder() returns an AgentBuilder."""
        b = Agent.builder()
        assert isinstance(b, AgentBuilder)


class TestAgentRun:
    """Tests for Agent.run() stateless execution."""

    @pytest.mark.asyncio
    @patch("pygubernator.builder._agent.create_provider")
    async def test_run_returns_response(self, mock_create: MagicMock) -> None:
        """run() calls process and returns AgentResponse."""
        provider = _mock_provider(
            [
                _make_llm_response("Hello there!"),
            ]
        )
        mock_create.return_value = provider
        agent = Agent.builder().model("gpt-4o").build()

        response = await agent.run("Hi")
        assert isinstance(response, AgentResponse)
        assert response.text == "Hello there!"
        assert response.success is True
        assert response.iterations == 1
        assert response.tool_calls == []

    @pytest.mark.asyncio
    @patch("pygubernator.builder._agent.create_provider")
    async def test_run_failed_result(self, mock_create: MagicMock) -> None:
        """run() propagates failure from the LLM agent."""
        provider = MagicMock()

        async def _chat_err(messages: Any, tools: Any = None) -> Any:
            raise RuntimeError("LLM down")

        provider.chat = _chat_err
        mock_create.return_value = provider
        agent = Agent.builder().model("gpt-4o").build()

        response = await agent.run("Hi")
        assert response.success is False

    @pytest.mark.asyncio
    @patch("pygubernator.builder._agent.create_provider")
    async def test_run_raw_contains_agent_result(self, mock_create: MagicMock) -> None:
        """The raw field is the underlying AgentResult."""
        provider = _mock_provider()
        mock_create.return_value = provider
        agent = Agent.builder().model("gpt-4o").build()

        response = await agent.run("test")
        assert isinstance(response.raw, AgentResult)


class TestAgentResponse:
    """Tests for AgentResponse.from_agent_result."""

    def test_from_successful_result(self) -> None:
        """Extracts fields from a successful AgentResult."""
        result = AgentResult(
            agent_id="a",
            success=True,
            messages_processed=1,
            metadata={
                "response": "hi",
                "tool_results": [{"tool_name": "t"}],
                "iterations": 3,
            },
        )
        resp = AgentResponse.from_agent_result(result)
        assert resp.text == "hi"
        assert resp.tool_calls == [{"tool_name": "t"}]
        assert resp.iterations == 3
        assert resp.success is True

    def test_from_failed_result(self) -> None:
        """Handles a failed AgentResult gracefully."""
        result = AgentResult(
            agent_id="a",
            success=False,
            messages_processed=0,
            errors=["boom"],
            metadata={"iterations": 0},
        )
        resp = AgentResponse.from_agent_result(result)
        assert resp.text == ""
        assert resp.tool_calls == []
        assert resp.success is False


class TestAgentSession:
    """Tests for Session multi-turn conversation."""

    @pytest.mark.asyncio
    @patch("pygubernator.builder._agent.create_provider")
    async def test_session_accumulates_history(self, mock_create: MagicMock) -> None:
        """Each session.run() adds user+assistant to history."""
        provider = _mock_provider(
            [
                _make_llm_response("First reply"),
                _make_llm_response("Second reply"),
            ]
        )
        mock_create.return_value = provider
        agent = Agent.builder().model("gpt-4o").build()
        session = agent.session()

        await session.run("Hello")
        assert len(session.history) == 2
        assert session.history[0]["role"] == "user"
        assert session.history[0]["content"] == "Hello"
        assert session.history[1]["role"] == "assistant"
        assert session.history[1]["content"] == "First reply"

        await session.run("Follow up")
        assert len(session.history) == 4

    @pytest.mark.asyncio
    @patch("pygubernator.builder._agent.create_provider")
    async def test_session_clear_resets(self, mock_create: MagicMock) -> None:
        """clear() resets the session memory."""
        provider = _mock_provider(
            [
                _make_llm_response("reply"),
            ]
        )
        mock_create.return_value = provider
        agent = Agent.builder().model("gpt-4o").build()
        session = agent.session()

        await session.run("Hello")
        assert len(session.history) == 2

        session.clear()
        assert len(session.history) == 0

    @pytest.mark.asyncio
    @patch("pygubernator.builder._agent.create_provider")
    async def test_session_window_memory(self, mock_create: MagicMock) -> None:
        """Window memory trims old messages."""
        provider = _mock_provider(
            [
                _make_llm_response("r1"),
                _make_llm_response("r2"),
                _make_llm_response("r3"),
            ]
        )
        mock_create.return_value = provider
        agent = Agent.builder().model("gpt-4o").memory("window", window_size=2).build()
        session = agent.session()

        await session.run("a")
        await session.run("b")
        await session.run("c")

        # Window of 2 means last 2 messages visible
        history = session.history
        assert len(history) == 2

    @pytest.mark.asyncio
    @patch("pygubernator.builder._agent.create_provider")
    async def test_session_default_buffer_memory(self, mock_create: MagicMock) -> None:
        """Default memory is BufferMemoryStore."""
        provider = _mock_provider()
        mock_create.return_value = provider
        agent = Agent.builder().model("gpt-4o").build()
        session = agent.session()
        assert isinstance(session._memory, BufferMemoryStore)


class TestAgentAsTool:
    """Tests for Agent.as_tool() delegation."""

    @patch("pygubernator.builder._agent.create_provider")
    def test_as_tool_returns_decorated_tool(self, mock_create: MagicMock) -> None:
        """as_tool() returns a _DecoratedTool."""
        mock_create.return_value = _mock_provider()
        agent = Agent.builder().model("gpt-4o").agent_id("my-agent").build()
        t = agent.as_tool()
        assert isinstance(t, _DecoratedTool)
        # Hyphens replaced with underscores
        assert t.name == "my_agent"

    @patch("pygubernator.builder._agent.create_provider")
    def test_as_tool_custom_name(self, mock_create: MagicMock) -> None:
        """as_tool() accepts custom name and description."""
        mock_create.return_value = _mock_provider()
        agent = Agent.builder().model("gpt-4o").build()
        t = agent.as_tool(
            name="custom_tool",
            description="Does stuff",
        )
        assert t.name == "custom_tool"
        assert t.description == "Does stuff"

    @patch("pygubernator.builder._agent.create_provider")
    def test_as_tool_schema(self, mock_create: MagicMock) -> None:
        """as_tool() has an 'input' parameter in its schema."""
        mock_create.return_value = _mock_provider()
        agent = Agent.builder().model("gpt-4o").build()
        t = agent.as_tool()
        schema = t.parameters_schema
        assert "input" in schema["properties"]
        assert schema["required"] == ["input"]

    @pytest.mark.asyncio
    @patch("pygubernator.builder._agent.create_provider")
    async def test_as_tool_execute_calls_run(self, mock_create: MagicMock) -> None:
        """Executing the tool delegates to agent.run()."""
        provider = _mock_provider(
            [
                _make_llm_response("tool output"),
            ]
        )
        mock_create.return_value = provider
        agent = Agent.builder().model("gpt-4o").build()
        t = agent.as_tool()

        result = await t.execute({"input": "test query"})
        assert result.success is True
        assert result.output == "tool output"


class TestMultiAgent:
    """Tests for multi-agent delegation via as_tool."""

    @pytest.mark.asyncio
    @patch("pygubernator.builder._agent.create_provider")
    async def test_agent_b_uses_agent_a_tool(self, mock_create: MagicMock) -> None:
        """Agent B can delegate to Agent A via as_tool()."""
        provider_a = _mock_provider(
            [
                _make_llm_response("agent-a says hello"),
            ]
        )
        provider_b = _mock_provider(
            [
                _make_llm_response("agent-b relays"),
            ]
        )

        call_count = {"n": 0}
        providers = [provider_a, provider_b]

        def _select_provider(*args: Any, **kwargs: Any) -> Any:
            p = providers[min(call_count["n"], len(providers) - 1)]
            call_count["n"] += 1
            return p

        mock_create.side_effect = _select_provider

        agent_a = Agent.builder().model("gpt-4o").agent_id("agent-a").build()
        a_tool = agent_a.as_tool()

        agent_b = (
            Agent.builder().model("gpt-4o").agent_id("agent-b").tools([a_tool]).build()
        )

        # Verify the tool is registered in agent B
        assert agent_b.inner._tools is not None
        assert agent_b.inner._tools.has("agent_a")

        # Execute agent A's tool directly
        result = await a_tool.execute({"input": "hi"})
        assert result.success is True
        assert result.output == "agent-a says hello"
