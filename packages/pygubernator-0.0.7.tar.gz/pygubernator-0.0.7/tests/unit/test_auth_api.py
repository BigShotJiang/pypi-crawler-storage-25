from __future__ import annotations

import json

from fastapi.testclient import TestClient

from pygubernator.api.main import create_app
from pygubernator.config.auth import is_auth_disabled


def _auth_env(monkeypatch) -> None:
    monkeypatch.setenv(
        "PYGUBERNATOR_AUTH_USERS",
        json.dumps([{"username": "admin", "password": "changeme", "role": "Admin"}]),
    )
    monkeypatch.setenv("PYGUBERNATOR_AUTH_JWT_SECRET", "test-jwt-secret-for-unit-tests")
    monkeypatch.setenv("PYGUBERNATOR_AUTH_DISABLED", "0")


def test_is_auth_disabled_when_not_configured(monkeypatch) -> None:
    monkeypatch.delenv("PYGUBERNATOR_AUTH_USERS", raising=False)
    monkeypatch.delenv("PYGUBERNATOR_AUTH_JWT_SECRET", raising=False)
    monkeypatch.delenv("PYGUBERNATOR_AUTH_SERVICE_URL", raising=False)
    monkeypatch.setenv("PYGUBERNATOR_AUTH_DISABLED", "0")
    assert is_auth_disabled() is True


def test_is_auth_enabled_with_users_and_secret(monkeypatch) -> None:
    _auth_env(monkeypatch)
    assert is_auth_disabled() is False


def test_login_me_logout_flow(monkeypatch) -> None:
    _auth_env(monkeypatch)
    client = TestClient(create_app())

    login = client.post(
        "/api/v1/auth/login",
        json={"username": "admin", "password": "changeme"},
    )
    assert login.status_code == 200
    token = login.json()["access_token"]
    assert token

    me = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.status_code == 200
    assert me.json()["username"] == "admin"
    assert me.json()["role"] == "Admin"

    logout = client.post("/api/v1/auth/logout")
    assert logout.status_code == 200
    assert logout.json()["message"] == "OK"


def test_legacy_x_api_token_is_rejected(monkeypatch) -> None:
    _auth_env(monkeypatch)
    client = TestClient(create_app())

    res = client.get(
        "/api/v1/agents",
        headers={
            "X-API-Token": "dev-token",
            "X-Actor": "ui",
            "X-Role": "admin",
        },
    )
    assert res.status_code == 401
