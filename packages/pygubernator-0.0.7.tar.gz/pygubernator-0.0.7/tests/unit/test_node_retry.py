"""Tests for per-node retry logic in WorkflowEngine."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, patch

from pygubernator.workflow._engine import WorkflowEngine
from pygubernator.workflow._registry import NodeTypeRegistry
from pygubernator.workflow._types import (
    EdgeSpec,
    NodeContext,
    NodeResult,
    NodeSpec,
    NodeStatus,
    WorkflowSpec,
)
from pygubernator.workflow.nodes._input import InputNodeFactory
from pygubernator.workflow.nodes._output import OutputNodeFactory


def _registry() -> NodeTypeRegistry:
    """Build a minimal registry with built-in factories."""
    reg = NodeTypeRegistry()
    reg.register("input", InputNodeFactory())
    reg.register("output", OutputNodeFactory())
    return reg


class _FailNTimesNode:
    """Node that fails ``n`` times then succeeds."""

    node_type = "fail_n"

    def __init__(
        self,
        node_id: str,
        fail_count: int,
    ) -> None:
        self._node_id = node_id
        self._fail_count = fail_count
        self._calls = 0

    async def execute(
        self,
        ctx: NodeContext,
    ) -> NodeResult:
        """Fail for the first ``fail_count`` calls."""
        self._calls += 1
        if self._calls <= self._fail_count:
            return NodeResult(
                node_id=self._node_id,
                status=NodeStatus.FAILED,
                error="transient error",
            )
        return NodeResult(
            node_id=self._node_id,
            status=NodeStatus.SUCCESS,
            output={"done": True},
        )


class _FailNTimesFactory:
    """Factory for _FailNTimesNode."""

    def __init__(self, fail_count: int) -> None:
        self._fail_count = fail_count

    def create(
        self,
        node_id: str,
        config: dict[str, Any],
    ) -> _FailNTimesNode:
        """Create a node that fails a set number of times."""
        return _FailNTimesNode(
            node_id,
            self._fail_count,
        )


class _AlwaysSucceedNode:
    """Node that always succeeds."""

    node_type = "ok"

    def __init__(self, node_id: str) -> None:
        self._node_id = node_id

    async def execute(
        self,
        ctx: NodeContext,
    ) -> NodeResult:
        """Return success immediately."""
        return NodeResult(
            node_id=self._node_id,
            status=NodeStatus.SUCCESS,
            output={"ok": True},
        )


class _AlwaysSucceedFactory:
    """Factory for _AlwaysSucceedNode."""

    def create(
        self,
        node_id: str,
        config: dict[str, Any],
    ) -> _AlwaysSucceedNode:
        """Create a node that always succeeds."""
        return _AlwaysSucceedNode(node_id)


class TestNodeRetry:
    """Tests for per-node retry in the workflow engine."""

    async def test_no_retry_on_failure(self) -> None:
        """Node with retry_count=0 fails immediately."""
        reg = _registry()
        reg.register("fail_n", _FailNTimesFactory(10))

        spec = WorkflowSpec(
            name="no-retry",
            version="1.0.0",
            nodes={
                "start": NodeSpec(
                    node_id="start",
                    node_type="input",
                ),
                "bad": NodeSpec(
                    node_id="bad",
                    node_type="fail_n",
                    config={"retry_count": 0},
                ),
            },
            edges=(
                EdgeSpec(
                    edge_id="e1",
                    source_id="start",
                    target_id="bad",
                ),
            ),
        )
        engine = WorkflowEngine(
            spec=spec,
            registry=reg,
        )
        result = await engine.run({})
        assert result.success is False
        bad = result.node_results["bad"]
        assert bad.status == NodeStatus.FAILED

    @patch("pygubernator.workflow._engine.asyncio.sleep")
    async def test_retry_twice_then_give_up(
        self,
        mock_sleep: AsyncMock,
    ) -> None:
        """Node with retry_count=2 tries 3 times total."""
        mock_sleep.return_value = None

        reg = _registry()
        # Always fails (10 times > 3 attempts)
        reg.register("fail_n", _FailNTimesFactory(10))

        spec = WorkflowSpec(
            name="retry-exhaust",
            version="1.0.0",
            nodes={
                "start": NodeSpec(
                    node_id="start",
                    node_type="input",
                ),
                "bad": NodeSpec(
                    node_id="bad",
                    node_type="fail_n",
                    config={
                        "retry_count": 2,
                        "retry_delay": 0.01,
                    },
                ),
            },
            edges=(
                EdgeSpec(
                    edge_id="e1",
                    source_id="start",
                    target_id="bad",
                ),
            ),
        )
        engine = WorkflowEngine(
            spec=spec,
            registry=reg,
        )
        result = await engine.run({})
        assert result.success is False
        assert mock_sleep.call_count == 2

    @patch("pygubernator.workflow._engine.asyncio.sleep")
    async def test_succeeds_on_second_attempt(
        self,
        mock_sleep: AsyncMock,
    ) -> None:
        """Node fails once then succeeds on retry."""
        mock_sleep.return_value = None

        reg = _registry()
        reg.register("fail_n", _FailNTimesFactory(1))

        spec = WorkflowSpec(
            name="retry-recover",
            version="1.0.0",
            nodes={
                "start": NodeSpec(
                    node_id="start",
                    node_type="input",
                ),
                "flaky": NodeSpec(
                    node_id="flaky",
                    node_type="fail_n",
                    config={
                        "retry_count": 2,
                        "retry_delay": 0.01,
                    },
                ),
                "end": NodeSpec(
                    node_id="end",
                    node_type="output",
                ),
            },
            edges=(
                EdgeSpec(
                    edge_id="e1",
                    source_id="start",
                    target_id="flaky",
                ),
                EdgeSpec(
                    edge_id="e2",
                    source_id="flaky",
                    target_id="end",
                ),
            ),
        )
        engine = WorkflowEngine(
            spec=spec,
            registry=reg,
        )
        result = await engine.run({})
        assert result.success is True
        flaky = result.node_results["flaky"]
        assert flaky.status == NodeStatus.SUCCESS
        assert mock_sleep.call_count == 1

    async def test_retry_not_applied_to_success(
        self,
    ) -> None:
        """Successful nodes are not retried."""
        reg = _registry()
        reg.register("ok", _AlwaysSucceedFactory())

        spec = WorkflowSpec(
            name="no-retry-success",
            version="1.0.0",
            nodes={
                "start": NodeSpec(
                    node_id="start",
                    node_type="input",
                ),
                "good": NodeSpec(
                    node_id="good",
                    node_type="ok",
                    config={
                        "retry_count": 3,
                        "retry_delay": 0.01,
                    },
                ),
                "end": NodeSpec(
                    node_id="end",
                    node_type="output",
                ),
            },
            edges=(
                EdgeSpec(
                    edge_id="e1",
                    source_id="start",
                    target_id="good",
                ),
                EdgeSpec(
                    edge_id="e2",
                    source_id="good",
                    target_id="end",
                ),
            ),
        )
        engine = WorkflowEngine(
            spec=spec,
            registry=reg,
        )
        result = await engine.run({})
        assert result.success is True
        good = result.node_results["good"]
        assert good.status == NodeStatus.SUCCESS
