"""Tests for MapNode."""

from __future__ import annotations

from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._map import MapNode, MapNodeFactory


class TestMapNode:
    """Tests for MapNode."""

    async def test_parallel_map(self) -> None:
        node = MapNode(
            "m1",
            config={
                "collection_key": "items",
                "item_key": "x",
                "transform": "x * 3",
            },
        )
        ctx = NodeContext(
            node_id="m1",
            input_data={"items": [1, 2, 3]},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output["items"] == [3, 6, 9]
        assert result.output["count"] == 3

    async def test_concurrency_limit(self) -> None:
        node = MapNode(
            "m1",
            config={
                "collection_key": "items",
                "item_key": "x",
                "transform": "x + 1",
                "max_concurrency": 2,
            },
        )
        ctx = NodeContext(
            node_id="m1",
            input_data={"items": [10, 20, 30, 40]},
        )
        result = await node.execute(ctx)
        assert result.output["items"] == [11, 21, 31, 41]

    async def test_empty_collection(self) -> None:
        node = MapNode(
            "m1",
            config={
                "collection_key": "items",
                "transform": "item",
            },
        )
        ctx = NodeContext(node_id="m1", input_data={"items": []})
        result = await node.execute(ctx)
        assert result.output == {"items": [], "count": 0}

    async def test_no_transform_fails(self) -> None:
        node = MapNode(
            "m1",
            config={"collection_key": "items"},
        )
        ctx = NodeContext(node_id="m1", input_data={"items": [1]})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "transform" in (result.error or "").lower()

    async def test_no_collection_key_fails(self) -> None:
        node = MapNode("m1", config={"transform": "item"})
        ctx = NodeContext(node_id="m1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED

    async def test_missing_collection_fails(self) -> None:
        node = MapNode(
            "m1",
            config={
                "collection_key": "missing",
                "transform": "item",
            },
        )
        ctx = NodeContext(node_id="m1", input_data={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED

    async def test_transform_error_fails(self) -> None:
        node = MapNode(
            "m1",
            config={
                "collection_key": "items",
                "transform": "undefined + 1",
            },
        )
        ctx = NodeContext(
            node_id="m1",
            input_data={"items": [1]},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED

    async def test_index_available(self) -> None:
        node = MapNode(
            "m1",
            config={
                "collection_key": "items",
                "item_key": "x",
                "transform": "index",
            },
        )
        ctx = NodeContext(
            node_id="m1",
            input_data={"items": ["a", "b", "c"]},
        )
        result = await node.execute(ctx)
        assert result.output["items"] == [0, 1, 2]

    def test_factory(self) -> None:
        factory = MapNodeFactory()
        node = factory.create("m1", {"collection_key": "items", "transform": "item"})
        assert isinstance(node, MapNode)
        assert node.node_type == "map"
