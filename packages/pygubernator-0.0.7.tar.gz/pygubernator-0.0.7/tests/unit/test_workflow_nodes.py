"""Tests for built-in workflow nodes."""

from __future__ import annotations

from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._code import CodeNode, CodeNodeFactory
from pygubernator.workflow.nodes._condition import (
    ConditionNode,
    ConditionNodeFactory,
)
from pygubernator.workflow.nodes._input import InputNode, InputNodeFactory
from pygubernator.workflow.nodes._output import OutputNode, OutputNodeFactory
from pygubernator.workflow.nodes._template import (
    TemplateNode,
    TemplateNodeFactory,
)


class TestInputNode:
    """Tests for InputNode."""

    async def test_passthrough_all(self) -> None:
        node = InputNode("n1", config={})
        ctx = NodeContext(node_id="n1", input_data={"a": 1, "b": 2})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output == {"a": 1, "b": 2}

    async def test_select_keys(self) -> None:
        node = InputNode("n1", config={"keys": ["a"]})
        ctx = NodeContext(node_id="n1", input_data={"a": 1, "b": 2})
        result = await node.execute(ctx)
        assert result.output == {"a": 1}

    async def test_missing_key_ignored(self) -> None:
        node = InputNode("n1", config={"keys": ["a", "missing"]})
        ctx = NodeContext(node_id="n1", input_data={"a": 1})
        result = await node.execute(ctx)
        assert result.output == {"a": 1}

    def test_factory(self) -> None:
        factory = InputNodeFactory()
        node = factory.create("n1", {})
        assert isinstance(node, InputNode)
        assert node.node_type == "input"


class TestOutputNode:
    """Tests for OutputNode."""

    async def test_collect_all(self) -> None:
        node = OutputNode("n1", config={})
        ctx = NodeContext(node_id="n1", input_data={"result": "done"})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output == {"result": "done"}

    async def test_collect_selected_keys(self) -> None:
        node = OutputNode("n1", config={"keys": ["result"]})
        ctx = NodeContext(node_id="n1", input_data={"result": "done", "extra": "skip"})
        result = await node.execute(ctx)
        assert result.output == {"result": "done"}

    def test_factory(self) -> None:
        factory = OutputNodeFactory()
        node = factory.create("n1", {})
        assert isinstance(node, OutputNode)


class TestTemplateNode:
    """Tests for TemplateNode."""

    async def test_simple_template(self) -> None:
        node = TemplateNode("n1", config={"template": "Hello, {{ name }}!"})
        ctx = NodeContext(node_id="n1", input_data={"name": "World"})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output == {"result": "Hello, World!"}

    async def test_custom_output_key(self) -> None:
        node = TemplateNode(
            "n1",
            config={"template": "Hi", "output_key": "greeting"},
        )
        ctx = NodeContext(node_id="n1")
        result = await node.execute(ctx)
        assert "greeting" in result.output

    async def test_uses_variables(self) -> None:
        node = TemplateNode("n1", config={"template": "{{ count }}"})
        ctx = NodeContext(node_id="n1", variables={"count": 42})
        result = await node.execute(ctx)
        assert result.output["result"] == "42"

    async def test_empty_template_fails(self) -> None:
        node = TemplateNode("n1", config={})
        ctx = NodeContext(node_id="n1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "No template" in (result.error or "")

    async def test_undefined_variable_fails(self) -> None:
        node = TemplateNode("n1", config={"template": "{{ undefined }}"})
        ctx = NodeContext(node_id="n1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED

    def test_factory(self) -> None:
        factory = TemplateNodeFactory()
        node = factory.create("n1", {"template": "hi"})
        assert isinstance(node, TemplateNode)


class TestConditionNode:
    """Tests for ConditionNode."""

    async def test_true_condition(self) -> None:
        node = ConditionNode("n1", config={"condition": "x > 5"})
        ctx = NodeContext(node_id="n1", input_data={"x": 10})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output_handle == "true"
        assert result.output["result"] is True

    async def test_false_condition(self) -> None:
        node = ConditionNode("n1", config={"condition": "x > 5"})
        ctx = NodeContext(node_id="n1", input_data={"x": 1})
        result = await node.execute(ctx)
        assert result.output_handle == "false"
        assert result.output["result"] is False

    async def test_no_condition_fails(self) -> None:
        node = ConditionNode("n1", config={})
        ctx = NodeContext(node_id="n1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "No condition" in (result.error or "")

    async def test_invalid_expression_fails(self) -> None:
        node = ConditionNode("n1", config={"condition": "undefined > 0"})
        ctx = NodeContext(node_id="n1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED

    async def test_uses_variables(self) -> None:
        node = ConditionNode("n1", config={"condition": "flag == True"})
        ctx = NodeContext(node_id="n1", variables={"flag": True})
        result = await node.execute(ctx)
        assert result.output_handle == "true"

    def test_factory(self) -> None:
        factory = ConditionNodeFactory()
        node = factory.create("n1", {"condition": "True"})
        assert isinstance(node, ConditionNode)


class TestCodeNode:
    """Tests for CodeNode."""

    async def test_simple_code(self) -> None:
        node = CodeNode(
            "n1",
            config={"code": "output['result'] = input_data['x'] * 2"},
        )
        ctx = NodeContext(node_id="n1", input_data={"x": 5})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output == {"result": 10}

    async def test_uses_variables(self) -> None:
        node = CodeNode(
            "n1",
            config={"code": "output['total'] = variables['count'] + 1"},
        )
        ctx = NodeContext(node_id="n1", variables={"count": 9})
        result = await node.execute(ctx)
        assert result.output == {"total": 10}

    async def test_builtin_functions(self) -> None:
        node = CodeNode(
            "n1",
            config={"code": "output['length'] = len(input_data['items'])"},
        )
        ctx = NodeContext(node_id="n1", input_data={"items": [1, 2, 3]})
        result = await node.execute(ctx)
        assert result.output == {"length": 3}

    async def test_no_code_fails(self) -> None:
        node = CodeNode("n1", config={})
        ctx = NodeContext(node_id="n1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "No code" in (result.error or "")

    async def test_forbidden_import(self) -> None:
        node = CodeNode("n1", config={"code": "__import__('os')"})
        ctx = NodeContext(node_id="n1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "Forbidden" in (result.error or "")

    async def test_forbidden_eval(self) -> None:
        node = CodeNode("n1", config={"code": "eval('1+1')"})
        ctx = NodeContext(node_id="n1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "Forbidden" in (result.error or "")

    async def test_forbidden_open(self) -> None:
        node = CodeNode("n1", config={"code": "open('/etc/passwd')"})
        ctx = NodeContext(node_id="n1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED

    async def test_code_too_long_fails(self) -> None:
        node = CodeNode("n1", config={"code": "x = 1\n" * 2000})
        ctx = NodeContext(node_id="n1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "max length" in (result.error or "")

    async def test_runtime_error_fails(self) -> None:
        node = CodeNode("n1", config={"code": "output['x'] = 1 / 0"})
        ctx = NodeContext(node_id="n1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "execution failed" in (result.error or "").lower()

    def test_factory(self) -> None:
        factory = CodeNodeFactory()
        node = factory.create("n1", {"code": "pass"})
        assert isinstance(node, CodeNode)
