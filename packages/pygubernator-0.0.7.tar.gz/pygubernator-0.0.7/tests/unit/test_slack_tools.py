"""Tests for Slack tools (mocking the Slack SDK client)."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, patch

import pytest

from pygubernator.tools.slack_tools import (
    _SlackClient,
    create_slack_tools,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_client(mock_web_client: AsyncMock) -> _SlackClient:
    """Create a _SlackClient with its _client replaced by a mock."""
    with patch.object(_SlackClient, "__init__", lambda self, *a, **kw: None):
        client = _SlackClient.__new__(_SlackClient)
        client._client = mock_web_client
        return client


def _make_tools(mock_web_client: AsyncMock) -> list[Any]:
    """Create tools backed by a mock Slack client."""
    with patch.object(_SlackClient, "__init__", lambda self, *a, **kw: None):
        tools = create_slack_tools("xoxb-fake-token")

    for t in tools:
        fn = t._func
        if hasattr(fn, "__closure__") and fn.__closure__:
            for cell in fn.__closure__:
                obj = cell.cell_contents
                if isinstance(obj, _SlackClient):
                    obj._client = mock_web_client
                    return tools
    return tools


def _get_tool(tools: list[Any], name: str) -> Any:
    """Find a tool by name."""
    return next(t for t in tools if t.name == name)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestSlackToolsFactory:
    """Tests for create_slack_tools factory."""

    def test_returns_five_tools(self) -> None:
        mock_client = AsyncMock()
        tools = _make_tools(mock_client)
        assert len(tools) == 5

    def test_tool_names(self) -> None:
        mock_client = AsyncMock()
        tools = _make_tools(mock_client)
        names = {t.name for t in tools}
        assert names == {
            "slack_send_message",
            "slack_list_channels",
            "slack_read_messages",
            "slack_add_reaction",
            "slack_upload_file",
        }

    def test_all_tools_have_schemas(self) -> None:
        mock_client = AsyncMock()
        tools = _make_tools(mock_client)
        for t in tools:
            schema = t.parameters_schema
            assert schema["type"] == "object"
            assert "properties" in schema


# ---------------------------------------------------------------------------
# _SlackClient unit tests
# ---------------------------------------------------------------------------


class TestSlackClient:
    """Tests for the _SlackClient wrapper."""

    @pytest.mark.asyncio
    async def test_send_message(self) -> None:
        mock_web = AsyncMock()
        mock_web.chat_postMessage.return_value = {
            "channel": "C123",
            "ts": "1234567890.123456",
            "message": {"text": "hello"},
        }
        client = _make_client(mock_web)

        result = await client.send_message("C123", "hello")

        assert result["channel"] == "C123"
        assert result["ts"] == "1234567890.123456"
        assert result["message"]["text"] == "hello"

    @pytest.mark.asyncio
    async def test_send_message_with_thread(self) -> None:
        mock_web = AsyncMock()
        mock_web.chat_postMessage.return_value = {
            "channel": "C123",
            "ts": "1234567890.123456",
            "message": {"text": "reply"},
        }
        client = _make_client(mock_web)

        result = await client.send_message(
            "C123", "reply", thread_ts="1234567890.000000"
        )

        assert result["ts"] == "1234567890.123456"
        mock_web.chat_postMessage.assert_called_once_with(
            channel="C123",
            text="reply",
            thread_ts="1234567890.000000",
        )

    @pytest.mark.asyncio
    async def test_list_channels(self) -> None:
        mock_web = AsyncMock()
        mock_web.conversations_list.return_value = {
            "channels": [
                {
                    "id": "C001",
                    "name": "general",
                    "topic": {"value": "General chat"},
                    "purpose": {"value": "Company-wide"},
                    "num_members": 42,
                },
                {
                    "id": "C002",
                    "name": "random",
                    "topic": {},
                    "purpose": {},
                    "num_members": 10,
                },
            ],
        }
        client = _make_client(mock_web)

        result = await client.list_channels(limit=50)

        assert len(result) == 2
        assert result[0]["id"] == "C001"
        assert result[0]["name"] == "general"
        assert result[0]["topic"] == "General chat"
        assert result[0]["num_members"] == 42
        assert result[1]["topic"] == ""

    @pytest.mark.asyncio
    async def test_list_channels_empty(self) -> None:
        mock_web = AsyncMock()
        mock_web.conversations_list.return_value = {}
        client = _make_client(mock_web)

        result = await client.list_channels()

        assert result == []

    @pytest.mark.asyncio
    async def test_read_messages(self) -> None:
        mock_web = AsyncMock()
        mock_web.conversations_history.return_value = {
            "messages": [
                {
                    "user": "U001",
                    "text": "hello",
                    "ts": "1234567890.000001",
                },
                {
                    "user": "U002",
                    "text": "world",
                    "ts": "1234567890.000002",
                    "thread_ts": "1234567890.000001",
                },
            ],
        }
        client = _make_client(mock_web)

        result = await client.read_messages("C123", limit=5)

        assert len(result) == 2
        assert result[0]["user"] == "U001"
        assert result[0]["text"] == "hello"
        assert "thread_ts" not in result[0]
        assert result[1]["thread_ts"] == "1234567890.000001"

    @pytest.mark.asyncio
    async def test_read_messages_with_oldest(self) -> None:
        mock_web = AsyncMock()
        mock_web.conversations_history.return_value = {
            "messages": [],
        }
        client = _make_client(mock_web)

        result = await client.read_messages(
            "C123", limit=10, oldest="1234567890.000000"
        )

        assert result == []
        mock_web.conversations_history.assert_called_once_with(
            channel="C123",
            limit=10,
            oldest="1234567890.000000",
        )

    @pytest.mark.asyncio
    async def test_add_reaction(self) -> None:
        mock_web = AsyncMock()
        mock_web.reactions_add.return_value = {"ok": True}
        client = _make_client(mock_web)

        result = await client.add_reaction("C123", "1234567890.000001", "thumbsup")

        assert result["ok"] is True
        mock_web.reactions_add.assert_called_once_with(
            channel="C123",
            timestamp="1234567890.000001",
            name="thumbsup",
        )

    @pytest.mark.asyncio
    async def test_upload_file(self) -> None:
        mock_web = AsyncMock()
        mock_web.files_upload_v2.return_value = {
            "file": {
                "id": "F123",
                "permalink": "https://slack.com/files/F123",
            },
        }
        client = _make_client(mock_web)

        result = await client.upload_file(
            channels="C123",
            content="data,here",
            filename="report.csv",
            title="Report",
        )

        assert result["file_id"] == "F123"
        assert "F123" in result["url"]


# ---------------------------------------------------------------------------
# Tool execution (end-to-end via @tool wrappers)
# ---------------------------------------------------------------------------


class TestSlackToolExecution:
    """Tests for executing tools through the @tool decorator."""

    @pytest.mark.asyncio
    async def test_send_message(self) -> None:
        mock_web = AsyncMock()
        mock_web.chat_postMessage.return_value = {
            "channel": "C123",
            "ts": "1111.2222",
            "message": {"text": "hi"},
        }
        tools = _make_tools(mock_web)
        t = _get_tool(tools, "slack_send_message")

        result = await t.execute({"channel": "C123", "text": "hi"})

        assert result.success
        assert result.output["channel"] == "C123"

    @pytest.mark.asyncio
    async def test_list_channels(self) -> None:
        mock_web = AsyncMock()
        mock_web.conversations_list.return_value = {
            "channels": [
                {
                    "id": "C001",
                    "name": "general",
                    "topic": {"value": ""},
                    "purpose": {"value": ""},
                    "num_members": 5,
                },
            ],
        }
        tools = _make_tools(mock_web)
        t = _get_tool(tools, "slack_list_channels")

        result = await t.execute({"limit": 50})

        assert result.success
        assert len(result.output) == 1
        assert result.output[0]["name"] == "general"

    @pytest.mark.asyncio
    async def test_read_messages(self) -> None:
        mock_web = AsyncMock()
        mock_web.conversations_history.return_value = {
            "messages": [
                {
                    "user": "U001",
                    "text": "msg",
                    "ts": "1111.0000",
                },
            ],
        }
        tools = _make_tools(mock_web)
        t = _get_tool(tools, "slack_read_messages")

        result = await t.execute({"channel": "C123", "limit": 5})

        assert result.success
        assert result.output[0]["text"] == "msg"

    @pytest.mark.asyncio
    async def test_add_reaction(self) -> None:
        mock_web = AsyncMock()
        mock_web.reactions_add.return_value = {"ok": True}
        tools = _make_tools(mock_web)
        t = _get_tool(tools, "slack_add_reaction")

        result = await t.execute(
            {
                "channel": "C123",
                "timestamp": "1111.0000",
                "emoji": "rocket",
            }
        )

        assert result.success
        assert result.output["ok"] is True

    @pytest.mark.asyncio
    async def test_upload_file(self) -> None:
        mock_web = AsyncMock()
        mock_web.files_upload_v2.return_value = {
            "file": {
                "id": "F999",
                "permalink": "https://slack.com/f/F999",
            },
        }
        tools = _make_tools(mock_web)
        t = _get_tool(tools, "slack_upload_file")

        result = await t.execute(
            {
                "channels": "C123",
                "content": "hello world",
                "filename": "test.txt",
            }
        )

        assert result.success
        assert result.output["file_id"] == "F999"

    @pytest.mark.asyncio
    async def test_api_error_returns_failure(self) -> None:
        mock_web = AsyncMock()
        mock_web.chat_postMessage.side_effect = RuntimeError("rate_limited")
        tools = _make_tools(mock_web)
        t = _get_tool(tools, "slack_send_message")

        result = await t.execute({"channel": "C123", "text": "fail"})

        assert not result.success
        assert "rate_limited" in result.error


# ---------------------------------------------------------------------------
# Dependency check
# ---------------------------------------------------------------------------


class TestSlackDependencyCheck:
    """Tests for missing dependency handling."""

    def test_missing_deps_raises(self) -> None:
        with (
            patch(
                "pygubernator.tools.slack_tools._HAS_SLACK",
                False,
            ),
            pytest.raises(ImportError, match="slack_sdk"),
        ):
            from pygubernator.tools.slack_tools import (
                _check_deps,
            )

            _check_deps()


# ---------------------------------------------------------------------------
# Factory (env-based)
# ---------------------------------------------------------------------------


class TestSlackFactory:
    """Tests for the slack_factory env adapter."""

    def test_missing_env_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("PYGUBERNATOR_SLACK_BOT_TOKEN", raising=False)
        from pygubernator.tools import slack_factory

        with pytest.raises(ValueError):
            slack_factory.create_tools_from_env()

    def test_uses_env_token(self, monkeypatch: pytest.MonkeyPatch) -> None:
        seen: dict[str, str] = {}

        def fake_create(token: str) -> list[Any]:
            seen["token"] = token
            return []

        from pygubernator.tools import slack_factory

        monkeypatch.setenv(
            "PYGUBERNATOR_SLACK_BOT_TOKEN",
            "xoxb-test-token",
        )
        monkeypatch.setattr(
            slack_factory,
            "create_slack_tools",
            fake_create,
        )
        tools = slack_factory.create_tools_from_env()
        assert tools == []
        assert seen["token"] == "xoxb-test-token"

    def test_custom_env_name(self, monkeypatch: pytest.MonkeyPatch) -> None:
        seen: dict[str, str] = {}

        def fake_create(token: str) -> list[Any]:
            seen["token"] = token
            return []

        from pygubernator.tools import slack_factory

        monkeypatch.setenv("CUSTOM_SLACK_TOKEN", "xoxb-custom")
        monkeypatch.setattr(
            slack_factory,
            "create_slack_tools",
            fake_create,
        )
        tools = slack_factory.create_tools_from_env("CUSTOM_SLACK_TOKEN")
        assert tools == []
        assert seen["token"] == "xoxb-custom"
