"""Tests for configuration settings."""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from pygubernator.config._settings import AgentSettings
from pygubernator.errors import ConfigError


class TestAgentSettings:
    """Tests for AgentSettings."""

    def test_defaults(self) -> None:
        settings = AgentSettings()
        assert settings.agent_id == "agent-1"
        assert settings.agent_type == "pipeline"
        assert settings.max_iterations == 10
        assert settings.log_level == "INFO"

    def test_custom(self) -> None:
        settings = AgentSettings(
            agent_id="custom-1",
            llm_model="claude-3-opus",
            max_messages=50,
        )
        assert settings.agent_id == "custom-1"
        assert settings.llm_model == "claude-3-opus"
        assert settings.max_messages == 50

    def test_from_env(self) -> None:
        env = {
            "PYGUBERNATOR_AGENT_ID": "env-agent",
            "PYGUBERNATOR_LLM_MODEL": "gpt-4o",
            "PYGUBERNATOR_MAX_ITERATIONS": "20",
        }
        with patch.dict(os.environ, env, clear=False):
            settings = AgentSettings.from_env()
            assert settings.agent_id == "env-agent"
            assert settings.llm_model == "gpt-4o"
            assert settings.max_iterations == 20

    def test_from_env_defaults(self) -> None:
        with patch.dict(os.environ, {}, clear=False):
            settings = AgentSettings.from_env()
            assert settings.agent_id == "agent-1"


class TestAgentSettingsConfigError:
    """Tests for ConfigError on bad env vars."""

    @pytest.mark.parametrize(
        ("env_var", "bad_value"),
        [
            ("PYGUBERNATOR_LLM_MAX_TOKENS", "abc"),
            ("PYGUBERNATOR_MAX_ITERATIONS", "3.5"),
            ("PYGUBERNATOR_MAX_MESSAGES", "yes"),
        ],
    )
    def test_bad_int_env_var(self, env_var: str, bad_value: str) -> None:
        with (
            patch.dict(os.environ, {env_var: bad_value}, clear=False),
            pytest.raises(ConfigError, match="Invalid integer"),
        ):
            AgentSettings.from_env()

    def test_bad_float_env_var(self) -> None:
        with (
            patch.dict(
                os.environ,
                {"PYGUBERNATOR_LLM_TEMPERATURE": "hot"},
                clear=False,
            ),
            pytest.raises(ConfigError, match="Invalid float"),
        ):
            AgentSettings.from_env()

    def test_config_error_contains_context(self) -> None:
        with (
            patch.dict(
                os.environ,
                {"PYGUBERNATOR_LLM_MAX_TOKENS": "nope"},
                clear=False,
            ),
            pytest.raises(ConfigError) as exc_info,
        ):
            AgentSettings.from_env()
        assert exc_info.value.context["env_var"] == "PYGUBERNATOR_LLM_MAX_TOKENS"
        assert exc_info.value.context["value"] == "nope"
