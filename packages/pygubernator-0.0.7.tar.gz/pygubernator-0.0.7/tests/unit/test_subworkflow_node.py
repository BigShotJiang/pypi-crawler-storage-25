"""Tests for SubWorkflowNode."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

from pygubernator.workflow._types import (
    NodeContext,
    NodeStatus,
    WorkflowResult,
)
from pygubernator.workflow.nodes._subworkflow import (
    SubWorkflowNode,
    SubWorkflowNodeFactory,
)

_LOADER = "pygubernator.workflow.config._loader.WorkflowLoader"
_REGISTRY = "pygubernator.services._workflows.build_node_registry"
_ENGINE = "pygubernator.workflow._engine.WorkflowEngine"


def _make_spec_dict() -> dict[str, Any]:
    """Return a minimal valid inline workflow spec."""
    return {
        "meta": {
            "name": "sub-test",
            "version": "1.0.0",
        },
        "nodes": {
            "in": {
                "type": "input",
                "config": {},
                "position": {"x": 0, "y": 0},
            },
            "tmpl": {
                "type": "template",
                "config": {
                    "template": "Hello {{ name }}",
                },
                "position": {"x": 0, "y": 100},
            },
            "out": {
                "type": "output",
                "config": {},
                "position": {"x": 0, "y": 200},
            },
        },
        "edges": [
            {"source": "in", "target": "tmpl"},
            {"source": "tmpl", "target": "out"},
        ],
    }


def _mock_success_result(
    output: dict[str, Any] | None = None,
) -> WorkflowResult:
    """Create a successful WorkflowResult for mocking."""
    return WorkflowResult(
        name="sub-test",
        success=True,
        node_results={},
        output=output or {"result": "Hello World"},
        errors=[],
    )


def _mock_failure_result(
    errors: list[str] | None = None,
) -> WorkflowResult:
    """Create a failed WorkflowResult for mocking."""
    return WorkflowResult(
        name="sub-test",
        success=False,
        node_results={},
        output={},
        errors=errors or ["Something went wrong"],
    )


class TestSubWorkflowNode:
    """Tests for SubWorkflowNode."""

    async def test_execute_valid_spec(self) -> None:
        """Sub-workflow runs and produces output."""
        node = SubWorkflowNode(
            "sw1",
            config={"workflow_spec": _make_spec_dict()},
        )
        ctx = NodeContext(
            node_id="sw1",
            input_data={"name": "World"},
        )

        mock_engine = AsyncMock()
        mock_engine.run.return_value = _mock_success_result({"result": "Hello World"})

        with (
            patch(_LOADER) as mock_loader_cls,
            patch(_REGISTRY),
            patch(_ENGINE, return_value=mock_engine),
        ):
            mock_loader_cls.return_value.load_dict.return_value = MagicMock()
            result = await node.execute(ctx)

        assert result.status == NodeStatus.SUCCESS
        assert result.output == {"result": "Hello World"}

    async def test_missing_workflow_spec(self) -> None:
        """Node fails gracefully without workflow_spec."""
        node = SubWorkflowNode("sw1", config={})
        ctx = NodeContext(node_id="sw1")
        result = await node.execute(ctx)

        assert result.status == NodeStatus.FAILED
        assert "workflow_spec" in (result.error or "")

    async def test_invalid_spec_type(self) -> None:
        """Node fails when workflow_spec is not a dict."""
        node = SubWorkflowNode(
            "sw1",
            config={"workflow_spec": "not-a-dict"},
        )
        ctx = NodeContext(node_id="sw1")
        result = await node.execute(ctx)

        assert result.status == NodeStatus.FAILED
        assert "must be a dict" in (result.error or "")

    async def test_pass_variables_true(self) -> None:
        """Parent variables are passed when pass_variables=True."""
        node = SubWorkflowNode(
            "sw1",
            config={
                "workflow_spec": _make_spec_dict(),
                "pass_variables": True,
            },
        )
        ctx = NodeContext(
            node_id="sw1",
            input_data={"name": "World"},
            variables={"session": "abc123"},
        )

        mock_engine = AsyncMock()
        mock_engine.run.return_value = _mock_success_result()

        with (
            patch(_LOADER) as mock_loader_cls,
            patch(_REGISTRY),
            patch(_ENGINE, return_value=mock_engine),
        ):
            mock_loader_cls.return_value.load_dict.return_value = MagicMock()
            await node.execute(ctx)

        call_kwargs = mock_engine.run.call_args
        assert call_kwargs.kwargs["variables"] == {"session": "abc123"}

    async def test_pass_variables_false(self) -> None:
        """Variables NOT passed when pass_variables=False."""
        node = SubWorkflowNode(
            "sw1",
            config={
                "workflow_spec": _make_spec_dict(),
                "pass_variables": False,
            },
        )
        ctx = NodeContext(
            node_id="sw1",
            input_data={"name": "World"},
            variables={"session": "abc123"},
        )

        mock_engine = AsyncMock()
        mock_engine.run.return_value = _mock_success_result()

        with (
            patch(_LOADER) as mock_loader_cls,
            patch(_REGISTRY),
            patch(_ENGINE, return_value=mock_engine),
        ):
            mock_loader_cls.return_value.load_dict.return_value = MagicMock()
            await node.execute(ctx)

        call_args = mock_engine.run.call_args
        passed_vars = call_args.kwargs.get(
            "variables", call_args.args[1] if len(call_args.args) > 1 else {}
        )
        assert passed_vars == {}

    async def test_sub_workflow_failure_propagates(
        self,
    ) -> None:
        """Sub-workflow failure is reported as node failure."""
        node = SubWorkflowNode(
            "sw1",
            config={"workflow_spec": _make_spec_dict()},
        )
        ctx = NodeContext(
            node_id="sw1",
            input_data={"name": "World"},
        )

        mock_engine = AsyncMock()
        mock_engine.run.return_value = _mock_failure_result(
            ["Node 'tmpl' failed: template error"]
        )

        with (
            patch(_LOADER) as mock_loader_cls,
            patch(_REGISTRY),
            patch(_ENGINE, return_value=mock_engine),
        ):
            mock_loader_cls.return_value.load_dict.return_value = MagicMock()
            result = await node.execute(ctx)

        assert result.status == NodeStatus.FAILED
        assert "Sub-workflow failed" in (result.error or "")

    async def test_loader_exception_handled(self) -> None:
        """Exceptions during spec loading are caught."""
        node = SubWorkflowNode(
            "sw1",
            config={"workflow_spec": {"bad": "spec"}},
        )
        ctx = NodeContext(node_id="sw1")

        with patch(_LOADER) as mock_loader_cls:
            mock_loader_cls.return_value.load_dict.side_effect = ValueError(
                "invalid spec"
            )
            result = await node.execute(ctx)

        assert result.status == NodeStatus.FAILED
        assert "execution failed" in (result.error or "").lower()

    async def test_input_data_forwarded(self) -> None:
        """Parent input_data is forwarded to sub-workflow."""
        node = SubWorkflowNode(
            "sw1",
            config={"workflow_spec": _make_spec_dict()},
        )
        ctx = NodeContext(
            node_id="sw1",
            input_data={"name": "Alice", "extra": 42},
        )

        mock_engine = AsyncMock()
        mock_engine.run.return_value = _mock_success_result()

        with (
            patch(_LOADER) as mock_loader_cls,
            patch(_REGISTRY),
            patch(_ENGINE, return_value=mock_engine),
        ):
            mock_loader_cls.return_value.load_dict.return_value = MagicMock()
            await node.execute(ctx)

        call_args = mock_engine.run.call_args
        assert call_args.kwargs["input_data"] == {
            "name": "Alice",
            "extra": 42,
        }


class TestSubWorkflowNodeFactory:
    """Tests for SubWorkflowNodeFactory."""

    def test_creates_correct_type(self) -> None:
        """Factory creates SubWorkflowNode instances."""
        factory = SubWorkflowNodeFactory()
        node = factory.create("sw1", {"workflow_spec": _make_spec_dict()})
        assert isinstance(node, SubWorkflowNode)
        assert node.node_type == "subworkflow"

    def test_factory_passes_config(self) -> None:
        """Factory forwards config to the node."""
        factory = SubWorkflowNodeFactory()
        config: dict[str, Any] = {
            "workflow_spec": _make_spec_dict(),
            "pass_variables": False,
        }
        node = factory.create("sw1", config)
        assert node._config == config
