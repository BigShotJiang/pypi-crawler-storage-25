"""Tests for workflow API routes."""

from __future__ import annotations

import time

import pytest
from fastapi.testclient import TestClient

from pygubernator.api.main import create_app
from tests.unit.conftest import reset_test_db


def _headers() -> dict[str, str]:
    return {
        "X-API-Token": "dev-token",
        "X-Actor": "test",
        "X-Role": "admin",
    }


@pytest.fixture(autouse=True)
def _reset_db() -> None:
    reset_test_db()


@pytest.fixture
def client():
    return TestClient(create_app())


def _create_workflow(client, name="test-wf") -> dict:
    res = client.post(
        "/api/v1/workflows",
        headers=_headers(),
        json={"name": name, "description": "A test workflow", "owner": "test"},
    )
    assert res.status_code == 200
    return res.json()


class TestWorkflowCRUD:
    """Tests for workflow CRUD endpoints."""

    def test_create_workflow(self, client) -> None:
        data = _create_workflow(client)
        assert data["name"] == "test-wf"
        assert data["description"] == "A test workflow"
        assert data["owner"] == "test"
        assert data["status"] == "active"

    def test_list_workflows(self, client) -> None:
        _create_workflow(client, "wf-a")
        _create_workflow(client, "wf-b")
        res = client.get("/api/v1/workflows", headers=_headers())
        assert res.status_code == 200
        body = res.json()
        assert body["meta"]["total"] == 2
        assert len(body["items"]) == 2

    def test_list_workflows_search(self, client) -> None:
        _create_workflow(client, "alpha-workflow")
        _create_workflow(client, "beta-workflow")
        res = client.get("/api/v1/workflows?q=alpha", headers=_headers())
        assert res.status_code == 200
        items = res.json()["items"]
        assert len(items) == 1
        assert items[0]["name"] == "alpha-workflow"

    def test_list_tool_presets(self, client) -> None:
        res = client.get("/api/v1/workflows/tool-presets", headers=_headers())
        assert res.status_code == 200
        body = res.json()
        assert "items" in body
        assert len(body["items"]) >= 1
        slack = next((x for x in body["items"] if x["id"] == "slack"), None)
        assert slack is not None
        assert slack["factory_module"] == "pygubernator.tools.slack_factory"
        assert slack["factory_function"] == "create_tools_from_env"
        assert "env_hint" in slack

    def test_get_workflow(self, client) -> None:
        wf = _create_workflow(client)
        res = client.get(f"/api/v1/workflows/{wf['id']}", headers=_headers())
        assert res.status_code == 200
        assert res.json()["id"] == wf["id"]

    def test_get_workflow_not_found(self, client) -> None:
        res = client.get("/api/v1/workflows/nonexistent", headers=_headers())
        assert res.status_code == 404

    def test_update_workflow(self, client) -> None:
        wf = _create_workflow(client)
        res = client.patch(
            f"/api/v1/workflows/{wf['id']}",
            headers=_headers(),
            json={"status": "archived", "description": "Updated desc"},
        )
        assert res.status_code == 200
        assert res.json()["status"] == "archived"
        assert res.json()["description"] == "Updated desc"


class TestWorkflowVersions:
    """Tests for workflow version endpoints."""

    def test_create_and_list_versions(self, client) -> None:
        wf = _create_workflow(client)
        v1 = client.post(
            f"/api/v1/workflows/{wf['id']}/versions",
            headers=_headers(),
            json={"version": "1.0.0", "spec_json": {"name": "test"}},
        )
        assert v1.status_code == 200
        assert v1.json()["version"] == "1.0.0"

        versions = client.get(
            f"/api/v1/workflows/{wf['id']}/versions",
            headers=_headers(),
        )
        assert versions.status_code == 200
        assert len(versions.json()["items"]) == 1

    def test_create_version_same_label_updates_spec(self, client) -> None:
        wf = _create_workflow(client)
        wid = wf["id"]
        body = {"version": "1.0.0", "spec_json": {"meta": {"version": "1.0.0"}}}
        r1 = client.post(
            f"/api/v1/workflows/{wid}/versions",
            headers=_headers(),
            json=body,
        )
        assert r1.status_code == 200
        v_id = r1.json()["id"]
        body2 = {
            "version": "1.0.0",
            "spec_json": {"meta": {"version": "1.0.0"}, "nodes": {"n": {}}},
        }
        r2 = client.post(
            f"/api/v1/workflows/{wid}/versions",
            headers=_headers(),
            json=body2,
        )
        assert r2.status_code == 200
        assert r2.json()["id"] == v_id

        versions = client.get(
            f"/api/v1/workflows/{wid}/versions",
            headers=_headers(),
        )
        assert versions.status_code == 200
        assert len(versions.json()["items"]) == 1
        assert versions.json()["items"][0]["spec_json"]["nodes"] == {"n": {}}

    def test_activate_version(self, client) -> None:
        wf = _create_workflow(client)
        v1 = client.post(
            f"/api/v1/workflows/{wf['id']}/versions",
            headers=_headers(),
            json={"version": "1.0.0", "spec_json": {}},
        )
        v1_id = v1.json()["id"]

        res = client.post(
            f"/api/v1/workflows/{wf['id']}/versions/{v1_id}/activate",
            headers=_headers(),
        )
        assert res.status_code == 200

        versions = client.get(
            f"/api/v1/workflows/{wf['id']}/versions",
            headers=_headers(),
        )
        active = [v for v in versions.json()["items"] if v["active"]]
        assert len(active) == 1
        assert active[0]["id"] == v1_id

    def test_activate_version_not_found(self, client) -> None:
        wf = _create_workflow(client)
        res = client.post(
            f"/api/v1/workflows/{wf['id']}/versions/fake-id/activate",
            headers=_headers(),
        )
        assert res.status_code == 404

    def test_create_version_workflow_not_found(self, client) -> None:
        res = client.post(
            "/api/v1/workflows/fake-id/versions",
            headers=_headers(),
            json={"version": "1.0.0", "spec_json": {}},
        )
        assert res.status_code == 404


class TestWorkflowExecution:
    """Tests for workflow execution endpoint."""

    def _simple_spec(self) -> dict:
        return {
            "meta": {"name": "simple", "version": "1.0.0"},
            "nodes": {
                "in": {"type": "input"},
                "out": {
                    "type": "output",
                    "config": {"mappings": {"result": "{{ message }}"}},
                },
            },
            "edges": [{"source": "in", "target": "out"}],
        }

    def test_execute_workflow(self, client) -> None:
        wf = _create_workflow(client)
        client.post(
            f"/api/v1/workflows/{wf['id']}/versions",
            headers=_headers(),
            json={"version": "1.0.0", "spec_json": self._simple_spec()},
        )

        res = client.post(
            f"/api/v1/workflows/{wf['id']}/execute",
            headers=_headers(),
            json={"input_json": {"message": "hello"}},
        )
        assert res.status_code == 200
        body = res.json()
        assert body["result"]["success"] is True
        run_id = body["run"]["id"]
        status = body["run"]["status"]
        for _ in range(100):
            if status in ("completed", "failed"):
                break
            time.sleep(0.05)
            poll = client.get(
                f"/api/v1/workflows/runs/{run_id}",
                headers=_headers(),
            )
            assert poll.status_code == 200
            status = poll.json()["run"]["status"]
        assert status == "completed"

    def test_execute_no_version(self, client) -> None:
        wf = _create_workflow(client)
        res = client.post(
            f"/api/v1/workflows/{wf['id']}/execute",
            headers=_headers(),
            json={"input_json": {}},
        )
        assert res.status_code == 400

    def test_execute_workflow_not_found(self, client) -> None:
        res = client.post(
            "/api/v1/workflows/fake-id/execute",
            headers=_headers(),
            json={"input_json": {}},
        )
        assert res.status_code == 404


class TestWorkflowRuns:
    """Tests for workflow run endpoints."""

    def test_list_and_get_runs(self, client) -> None:
        wf = _create_workflow(client)
        client.post(
            f"/api/v1/workflows/{wf['id']}/versions",
            headers=_headers(),
            json={
                "version": "1.0.0",
                "spec_json": {
                    "meta": {"name": "t", "version": "1.0.0"},
                    "nodes": {"in": {"type": "input"}},
                    "edges": [],
                },
            },
        )

        exec_res = client.post(
            f"/api/v1/workflows/{wf['id']}/execute",
            headers=_headers(),
            json={"input_json": {}},
        )
        assert exec_res.status_code == 200
        run_id = exec_res.json()["run"]["id"]

        runs = client.get("/api/v1/workflows/runs/list", headers=_headers())
        assert runs.status_code == 200
        assert runs.json()["meta"]["total"] >= 1

        detail = client.get(f"/api/v1/workflows/runs/{run_id}", headers=_headers())
        assert detail.status_code == 200
        assert detail.json()["run"]["id"] == run_id

    def test_get_run_trace(self, client) -> None:
        wf = _create_workflow(client)
        client.post(
            f"/api/v1/workflows/{wf['id']}/versions",
            headers=_headers(),
            json={
                "version": "1.0.0",
                "spec_json": {
                    "meta": {"name": "t", "version": "1.0.0"},
                    "nodes": {"in": {"type": "input"}},
                    "edges": [],
                },
            },
        )
        exec_res = client.post(
            f"/api/v1/workflows/{wf['id']}/execute",
            headers=_headers(),
            json={"input_json": {"x": 1}},
        )
        run_id = exec_res.json()["run"]["id"]

        trace = client.get(
            f"/api/v1/workflows/runs/{run_id}/trace",
            headers=_headers(),
        )
        assert trace.status_code == 200
        assert trace.json()["run_id"] == run_id
        assert len(trace.json()["trace"]) >= 1

    def test_get_run_not_found(self, client) -> None:
        res = client.get("/api/v1/workflows/runs/fake-id", headers=_headers())
        assert res.status_code == 404

    def test_cancel_run_not_found(self, client) -> None:
        res = client.post(
            "/api/v1/workflows/runs/fake-run-id/cancel",
            headers=_headers(),
            json={},
        )
        assert res.status_code == 404

    def test_cancel_completed_run_returns_409(self, client) -> None:
        wf = _create_workflow(client)
        client.post(
            f"/api/v1/workflows/{wf['id']}/versions",
            headers=_headers(),
            json={
                "version": "1.0.0",
                "spec_json": {
                    "meta": {"name": "t", "version": "1.0.0"},
                    "nodes": {
                        "in": {"type": "input"},
                        "out": {
                            "type": "output",
                            "config": {"mappings": {"r": "{{ message }}"}},
                        },
                    },
                    "edges": [{"source": "in", "target": "out"}],
                },
            },
        )
        exec_res = client.post(
            f"/api/v1/workflows/{wf['id']}/execute",
            headers=_headers(),
            json={"input_json": {"message": "x"}},
        )
        assert exec_res.status_code == 200
        run_id = exec_res.json()["run"]["id"]
        # Let the background thread finish and release the DB session before polling.
        time.sleep(0.8)
        st = ""
        for _ in range(80):
            poll = client.get(
                f"/api/v1/workflows/runs/{run_id}",
                headers=_headers(),
            )
            if poll.status_code != 200:
                time.sleep(0.1)
                continue
            st = poll.json()["run"]["status"]
            if st in ("completed", "failed", "cancelled"):
                break
            time.sleep(0.1)
        assert st in ("completed", "failed", "cancelled")
        can = client.post(
            f"/api/v1/workflows/runs/{run_id}/cancel",
            headers=_headers(),
            json={},
        )
        assert can.status_code == 409

    def test_delete_run_not_found(self, client) -> None:
        res = client.delete(
            "/api/v1/workflows/runs/fake-run-id",
            headers=_headers(),
        )
        assert res.status_code == 404

    def test_delete_completed_run_removes_record(self, client) -> None:
        wf = _create_workflow(client)
        client.post(
            f"/api/v1/workflows/{wf['id']}/versions",
            headers=_headers(),
            json={
                "version": "1.0.0",
                "spec_json": {
                    "meta": {"name": "t", "version": "1.0.0"},
                    "nodes": {
                        "in": {"type": "input"},
                        "out": {
                            "type": "output",
                            "config": {"mappings": {"r": "{{ message }}"}},
                        },
                    },
                    "edges": [{"source": "in", "target": "out"}],
                },
            },
        )
        exec_res = client.post(
            f"/api/v1/workflows/{wf['id']}/execute",
            headers=_headers(),
            json={"input_json": {"message": "x"}},
        )
        assert exec_res.status_code == 200
        run_id = exec_res.json()["run"]["id"]
        time.sleep(0.8)
        st = ""
        for _ in range(80):
            poll = client.get(
                f"/api/v1/workflows/runs/{run_id}",
                headers=_headers(),
            )
            if poll.status_code != 200:
                time.sleep(0.1)
                continue
            st = poll.json()["run"]["status"]
            if st in ("completed", "failed", "cancelled"):
                break
            time.sleep(0.1)
        assert st in ("completed", "failed", "cancelled")

        deleted = client.delete(
            f"/api/v1/workflows/runs/{run_id}",
            headers=_headers(),
        )
        assert deleted.status_code == 204

        gone = client.get(
            f"/api/v1/workflows/runs/{run_id}",
            headers=_headers(),
        )
        assert gone.status_code == 404

    def test_delete_run_immediately_after_execute(self, client) -> None:
        """Delete right after start: 409 if still running, else 204 if already done."""
        wf = _create_workflow(client)
        client.post(
            f"/api/v1/workflows/{wf['id']}/versions",
            headers=_headers(),
            json={
                "version": "1.0.0",
                "spec_json": {
                    "meta": {"name": "t", "version": "1.0.0"},
                    "nodes": {
                        "in": {"type": "input"},
                        "out": {
                            "type": "output",
                            "config": {"mappings": {"r": "{{ message }}"}},
                        },
                    },
                    "edges": [{"source": "in", "target": "out"}],
                },
            },
        )
        exec_res = client.post(
            f"/api/v1/workflows/{wf['id']}/execute",
            headers=_headers(),
            json={"input_json": {"message": "x"}},
        )
        assert exec_res.status_code == 200
        run_id = exec_res.json()["run"]["id"]
        del_res = client.delete(
            f"/api/v1/workflows/runs/{run_id}",
            headers=_headers(),
        )
        assert del_res.status_code in (204, 409)
        if del_res.status_code == 409:
            assert "running" in str(del_res.json().get("detail", "")).lower()
