"""Tests for SQL database tools using an in-memory SQLite database."""

from __future__ import annotations

from typing import Any
from unittest.mock import patch

import pytest

from pygubernator.tools.sql_tools import (
    _SqlClient,
    create_sql_tools,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_MEMORY_URL = "sqlite:///:memory:"


def _make_client(
    readonly: bool = True,
) -> _SqlClient:
    """Create a client backed by an in-memory SQLite DB."""
    return _SqlClient(_MEMORY_URL, readonly=readonly)


def _seed_table(client: _SqlClient) -> None:
    """Create and populate a test table."""
    with client._engine.connect() as conn:
        from sqlalchemy import text

        conn.execute(
            text(
                "CREATE TABLE users ("
                "  id INTEGER PRIMARY KEY,"
                "  name TEXT NOT NULL,"
                "  email TEXT"
                ")"
            )
        )
        conn.execute(
            text(
                "INSERT INTO users (id, name, email) "
                "VALUES (1, 'Alice', 'alice@example.com')"
            )
        )
        conn.execute(
            text(
                "INSERT INTO users (id, name, email) "
                "VALUES (2, 'Bob', 'bob@example.com')"
            )
        )
        conn.commit()


def _get_tool(tools: list[Any], name: str) -> Any:
    """Find a tool by name."""
    return next(t for t in tools if t.name == name)


# ---------------------------------------------------------------------------
# _SqlClient unit tests
# ---------------------------------------------------------------------------


class TestSqlClientQuery:
    """Tests for _SqlClient.query."""

    def test_select_returns_rows(self) -> None:
        client = _make_client()
        _seed_table(client)
        rows = client.query("SELECT id, name FROM users")
        assert len(rows) == 2
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    def test_select_with_params(self) -> None:
        client = _make_client()
        _seed_table(client)
        rows = client.query(
            "SELECT name FROM users WHERE id = :uid",
            {"uid": 2},
        )
        assert len(rows) == 1
        assert rows[0]["name"] == "Bob"

    def test_query_rejects_insert(self) -> None:
        client = _make_client()
        with pytest.raises(ValueError, match="read-only"):
            client.query("INSERT INTO t VALUES (1)")

    def test_query_rejects_update(self) -> None:
        client = _make_client()
        with pytest.raises(ValueError, match="read-only"):
            client.query("UPDATE t SET x = 1")

    def test_query_rejects_delete(self) -> None:
        client = _make_client()
        with pytest.raises(ValueError, match="read-only"):
            client.query("DELETE FROM t")

    def test_query_rejects_drop(self) -> None:
        client = _make_client()
        with pytest.raises(ValueError, match="read-only"):
            client.query("DROP TABLE t")

    def test_query_rejects_empty(self) -> None:
        client = _make_client()
        with pytest.raises(ValueError, match="Empty"):
            client.query("   ")

    def test_query_allows_with(self) -> None:
        client = _make_client()
        _seed_table(client)
        rows = client.query("WITH cte AS (SELECT * FROM users) SELECT name FROM cte")
        assert len(rows) == 2


class TestSqlClientExecute:
    """Tests for _SqlClient.execute."""

    def test_execute_insert(self) -> None:
        client = _make_client(readonly=False)
        _seed_table(client)
        result = client.execute(
            "INSERT INTO users (id, name, email) VALUES (3, 'Charlie', 'c@example.com')"
        )
        assert result["affected_rows"] == 1
        rows = client.query("SELECT * FROM users")
        assert len(rows) == 3

    def test_execute_update(self) -> None:
        client = _make_client(readonly=False)
        _seed_table(client)
        result = client.execute("UPDATE users SET name = 'Alicia' WHERE id = 1")
        assert result["affected_rows"] == 1

    def test_execute_delete(self) -> None:
        client = _make_client(readonly=False)
        _seed_table(client)
        result = client.execute("DELETE FROM users WHERE id = 2")
        assert result["affected_rows"] == 1

    def test_readonly_blocks_execute(self) -> None:
        client = _make_client(readonly=True)
        _seed_table(client)
        with pytest.raises(ValueError, match="readonly"):
            client.execute("INSERT INTO users (id, name) VALUES (99, 'Blocked')")


class TestSqlClientIntrospection:
    """Tests for schema introspection methods."""

    def test_list_tables(self) -> None:
        client = _make_client()
        _seed_table(client)
        tables = client.list_tables()
        assert "users" in tables

    def test_describe_table(self) -> None:
        client = _make_client()
        _seed_table(client)
        columns = client.describe_table("users")
        names = {col["name"] for col in columns}
        assert names == {"id", "name", "email"}
        id_col = next(c for c in columns if c["name"] == "id")
        assert id_col["primary_key"] is True

    def test_describe_table_types(self) -> None:
        client = _make_client()
        _seed_table(client)
        columns = client.describe_table("users")
        for col in columns:
            assert "type" in col
            assert isinstance(col["type"], str)

    def test_list_schemas(self) -> None:
        client = _make_client()
        schemas = client.list_schemas()
        assert isinstance(schemas, list)
        # SQLite always has at least 'main'
        assert "main" in schemas


# ---------------------------------------------------------------------------
# Factory tests
# ---------------------------------------------------------------------------


class TestCreateSqlTools:
    """Tests for the create_sql_tools factory."""

    def test_returns_five_tools(self) -> None:
        tools = create_sql_tools(_MEMORY_URL)
        assert len(tools) == 5

    def test_tool_names(self) -> None:
        tools = create_sql_tools(_MEMORY_URL)
        names = {t.name for t in tools}
        assert names == {
            "sql_query",
            "sql_execute",
            "sql_list_tables",
            "sql_describe_table",
            "sql_list_schemas",
        }

    def test_all_tools_have_schemas(self) -> None:
        tools = create_sql_tools(_MEMORY_URL)
        for t in tools:
            schema = t.parameters_schema
            assert schema["type"] == "object"
            assert "properties" in schema


# ---------------------------------------------------------------------------
# Tool execution (end-to-end via @tool wrappers)
# ---------------------------------------------------------------------------


def _make_seeded_tools(
    readonly: bool = True,
) -> list[Any]:
    """Create tools and seed the underlying database."""
    tools = create_sql_tools(_MEMORY_URL, readonly=readonly)
    # Reach into the closure to find the client and seed it.
    for t in tools:
        fn = t._func
        if hasattr(fn, "__closure__") and fn.__closure__:
            for cell in fn.__closure__:
                obj = cell.cell_contents
                if isinstance(obj, _SqlClient):
                    _seed_table(obj)
                    return tools
    return tools


class TestSqlToolExecution:
    """Tests for executing tools through the @tool decorator."""

    @pytest.mark.asyncio
    async def test_sql_query(self) -> None:
        tools = _make_seeded_tools()
        t = _get_tool(tools, "sql_query")
        result = await t.execute({"query": "SELECT name FROM users"})
        assert result.success
        assert len(result.output) == 2

    @pytest.mark.asyncio
    async def test_sql_query_with_params(self) -> None:
        tools = _make_seeded_tools()
        t = _get_tool(tools, "sql_query")
        result = await t.execute(
            {
                "query": ("SELECT name FROM users WHERE id = :uid"),
                "params": {"uid": 1},
            }
        )
        assert result.success
        assert result.output[0]["name"] == "Alice"

    @pytest.mark.asyncio
    async def test_sql_execute_write(self) -> None:
        tools = _make_seeded_tools(readonly=False)
        t = _get_tool(tools, "sql_execute")
        result = await t.execute(
            {
                "query": (
                    "INSERT INTO users (id, name, email) "
                    "VALUES (3, 'Charlie', 'c@test.com')"
                ),
            }
        )
        assert result.success
        assert result.output["affected_rows"] == 1

    @pytest.mark.asyncio
    async def test_sql_execute_blocked_in_readonly(
        self,
    ) -> None:
        tools = _make_seeded_tools(readonly=True)
        t = _get_tool(tools, "sql_execute")
        result = await t.execute({"query": "INSERT INTO users VALUES (9, 'X', 'x')"})
        assert not result.success
        assert "readonly" in result.error

    @pytest.mark.asyncio
    async def test_sql_list_tables(self) -> None:
        tools = _make_seeded_tools()
        t = _get_tool(tools, "sql_list_tables")
        result = await t.execute({})
        assert result.success
        assert "users" in result.output

    @pytest.mark.asyncio
    async def test_sql_describe_table(self) -> None:
        tools = _make_seeded_tools()
        t = _get_tool(tools, "sql_describe_table")
        result = await t.execute({"table_name": "users"})
        assert result.success
        names = {c["name"] for c in result.output}
        assert "id" in names
        assert "name" in names

    @pytest.mark.asyncio
    async def test_sql_list_schemas(self) -> None:
        tools = _make_seeded_tools()
        t = _get_tool(tools, "sql_list_schemas")
        result = await t.execute({})
        assert result.success
        assert "main" in result.output

    @pytest.mark.asyncio
    async def test_query_error_returns_failure(
        self,
    ) -> None:
        tools = _make_seeded_tools()
        t = _get_tool(tools, "sql_query")
        result = await t.execute({"query": "SELECT * FROM nonexistent_table"})
        assert not result.success
        assert result.error


# ---------------------------------------------------------------------------
# Factory env tests
# ---------------------------------------------------------------------------


class TestSqlFactory:
    """Tests for the sql_factory env helper."""

    def test_missing_env_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from pygubernator.tools import sql_factory

        monkeypatch.delenv(
            "PYGUBERNATOR_SQL_CONNECTION_STRING",
            raising=False,
        )
        with pytest.raises(ValueError):
            sql_factory.create_tools_from_env()

    def test_uses_env_connection_string(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from pygubernator.tools import sql_factory

        seen: dict[str, Any] = {}

        def fake_create(conn: str, readonly: bool = True) -> list[Any]:
            seen["conn"] = conn
            seen["readonly"] = readonly
            return []

        monkeypatch.setenv(
            "PYGUBERNATOR_SQL_CONNECTION_STRING",
            "sqlite:///test.db",
        )
        monkeypatch.setattr(sql_factory, "create_sql_tools", fake_create)
        tools = sql_factory.create_tools_from_env()
        assert tools == []
        assert seen["conn"] == "sqlite:///test.db"
        assert seen["readonly"] is True

    def test_readonly_false_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from pygubernator.tools import sql_factory

        seen: dict[str, Any] = {}

        def fake_create(conn: str, readonly: bool = True) -> list[Any]:
            seen["readonly"] = readonly
            return []

        monkeypatch.setenv(
            "PYGUBERNATOR_SQL_CONNECTION_STRING",
            "sqlite:///test.db",
        )
        monkeypatch.setenv("PYGUBERNATOR_SQL_READONLY", "0")
        monkeypatch.setattr(sql_factory, "create_sql_tools", fake_create)
        sql_factory.create_tools_from_env()
        assert seen["readonly"] is False


# ---------------------------------------------------------------------------
# Missing dependency test
# ---------------------------------------------------------------------------


class TestMissingDependency:
    """Test behaviour when SQLAlchemy is not available."""

    def test_check_deps_raises(self) -> None:
        with patch(
            "pygubernator.tools.sql_tools._HAS_SQLALCHEMY",
            False,
        ):
            from pygubernator.tools.sql_tools import (
                _check_deps,
            )

            with pytest.raises(ImportError, match="SQLAlchemy"):
                _check_deps()
