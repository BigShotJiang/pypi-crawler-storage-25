"""Tests for Google Docs tools (mocking the Google API client)."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from pygubernator.tools.gdocs_tools import (
    _DocsClient,
    _extract_text,
    create_gdocs_tools,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_docs_service() -> MagicMock:
    """Build a mock Google Docs API service."""
    return MagicMock()


def _make_client(docs_mock: MagicMock) -> _DocsClient:
    """Create a _DocsClient with its _docs attr replaced."""
    with patch.object(_DocsClient, "__init__", lambda self, *a, **kw: None):
        client = _DocsClient.__new__(_DocsClient)
        client._docs = docs_mock
        return client


def _make_tools(docs_mock: MagicMock) -> list[Any]:
    """Create tools backed by a mock Docs service."""
    with patch.object(_DocsClient, "__init__", lambda self, *a, **kw: None):
        tools = create_gdocs_tools("fake_creds.json")

    for t in tools:
        fn = t._func
        if hasattr(fn, "__closure__") and fn.__closure__:
            for cell in fn.__closure__:
                obj = cell.cell_contents
                if isinstance(obj, _DocsClient):
                    obj._docs = docs_mock
                    return tools
    return tools


def _get_tool(tools: list[Any], name: str) -> Any:
    """Find a tool by name."""
    return next(t for t in tools if t.name == name)


# ---------------------------------------------------------------------------
# _extract_text helper
# ---------------------------------------------------------------------------


class TestExtractText:
    """Tests for the _extract_text helper function."""

    def test_empty_body(self) -> None:
        assert _extract_text({}) == ""

    def test_empty_content(self) -> None:
        assert _extract_text({"content": []}) == ""

    def test_single_paragraph(self) -> None:
        body = {
            "content": [
                {"paragraph": {"elements": [{"textRun": {"content": "Hello world"}}]}}
            ]
        }
        assert _extract_text(body) == "Hello world"

    def test_multiple_paragraphs(self) -> None:
        body = {
            "content": [
                {"paragraph": {"elements": [{"textRun": {"content": "Line 1\n"}}]}},
                {"paragraph": {"elements": [{"textRun": {"content": "Line 2\n"}}]}},
            ]
        }
        assert _extract_text(body) == "Line 1\nLine 2\n"

    def test_multiple_text_runs_in_paragraph(self) -> None:
        body = {
            "content": [
                {
                    "paragraph": {
                        "elements": [
                            {"textRun": {"content": "Hello "}},
                            {"textRun": {"content": "world"}},
                        ]
                    }
                }
            ]
        }
        assert _extract_text(body) == "Hello world"

    def test_non_paragraph_elements_skipped(self) -> None:
        body = {
            "content": [
                {"sectionBreak": {}},
                {"paragraph": {"elements": [{"textRun": {"content": "text"}}]}},
                {"table": {}},
            ]
        }
        assert _extract_text(body) == "text"

    def test_elements_without_text_run(self) -> None:
        body = {
            "content": [
                {
                    "paragraph": {
                        "elements": [
                            {"inlineObjectElement": {"id": "123"}},
                            {"textRun": {"content": "after image"}},
                        ]
                    }
                }
            ]
        }
        assert _extract_text(body) == "after image"


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


class TestGdocsToolsFactory:
    """Tests for create_gdocs_tools factory."""

    def test_returns_five_tools(self) -> None:
        docs = _mock_docs_service()
        tools = _make_tools(docs)
        assert len(tools) == 5

    def test_tool_names(self) -> None:
        docs = _mock_docs_service()
        tools = _make_tools(docs)
        names = {t.name for t in tools}
        assert names == {
            "gdocs_create_document",
            "gdocs_get_document",
            "gdocs_insert_text",
            "gdocs_replace_text",
            "gdocs_batch_update",
        }

    def test_all_tools_have_schemas(self) -> None:
        docs = _mock_docs_service()
        tools = _make_tools(docs)
        for t in tools:
            schema = t.parameters_schema
            assert schema["type"] == "object"
            assert "properties" in schema


# ---------------------------------------------------------------------------
# _DocsClient unit tests
# ---------------------------------------------------------------------------


class TestDocsClient:
    """Tests for the _DocsClient wrapper."""

    def test_create_document(self) -> None:
        docs = _mock_docs_service()
        docs.create.return_value.execute.return_value = {
            "documentId": "doc123",
            "title": "My Doc",
        }
        client = _make_client(docs)

        result = client.create_document("My Doc")

        assert result["document_id"] == "doc123"
        assert result["title"] == "My Doc"

    def test_get_document(self) -> None:
        docs = _mock_docs_service()
        docs.get.return_value.execute.return_value = {
            "documentId": "doc123",
            "title": "My Doc",
            "body": {
                "content": [
                    {"paragraph": {"elements": [{"textRun": {"content": "Hello\n"}}]}}
                ]
            },
        }
        client = _make_client(docs)

        result = client.get_document("doc123")

        assert result["document_id"] == "doc123"
        assert result["title"] == "My Doc"
        assert result["body_text"] == "Hello\n"

    def test_get_document_empty_body(self) -> None:
        docs = _mock_docs_service()
        docs.get.return_value.execute.return_value = {
            "documentId": "doc123",
            "title": "Empty",
            "body": {"content": []},
        }
        client = _make_client(docs)

        result = client.get_document("doc123")

        assert result["body_text"] == ""

    def test_insert_text_with_index(self) -> None:
        docs = _mock_docs_service()
        docs.batchUpdate.return_value.execute.return_value = {"replies": []}
        client = _make_client(docs)

        result = client.insert_text("doc123", "Hello", 1)

        assert result["inserted"] is True
        assert result["index"] == 1
        call_args = docs.batchUpdate.call_args
        body = call_args.kwargs.get("body") or call_args[1].get("body")
        req = body["requests"][0]["insertText"]
        assert req["text"] == "Hello"
        assert req["location"]["index"] == 1

    def test_insert_text_at_end(self) -> None:
        docs = _mock_docs_service()
        docs.get.return_value.execute.return_value = {
            "body": {
                "content": [
                    {"endIndex": 10},
                    {"endIndex": 25},
                ]
            }
        }
        docs.batchUpdate.return_value.execute.return_value = {"replies": []}
        client = _make_client(docs)

        result = client.insert_text("doc123", "Appended")

        assert result["inserted"] is True
        # End index is 25, so insert at 24 (before newline).
        assert result["index"] == 24

    def test_insert_text_at_end_empty_doc(self) -> None:
        docs = _mock_docs_service()
        docs.get.return_value.execute.return_value = {"body": {"content": []}}
        docs.batchUpdate.return_value.execute.return_value = {"replies": []}
        client = _make_client(docs)

        result = client.insert_text("doc123", "First")

        assert result["inserted"] is True
        assert result["index"] == 1

    def test_replace_text(self) -> None:
        docs = _mock_docs_service()
        docs.batchUpdate.return_value.execute.return_value = {
            "replies": [{"replaceAllText": {"occurrencesChanged": 3}}]
        }
        client = _make_client(docs)

        result = client.replace_text("doc123", "old", "new")

        assert result["occurrences_changed"] == 3
        call_args = docs.batchUpdate.call_args
        body = call_args.kwargs.get("body") or call_args[1].get("body")
        req = body["requests"][0]["replaceAllText"]
        assert req["containsText"]["text"] == "old"
        assert req["containsText"]["matchCase"] is True
        assert req["replaceText"] == "new"

    def test_replace_text_no_matches(self) -> None:
        docs = _mock_docs_service()
        docs.batchUpdate.return_value.execute.return_value = {
            "replies": [{"replaceAllText": {}}]
        }
        client = _make_client(docs)

        result = client.replace_text("doc123", "missing", "x")

        assert result["occurrences_changed"] == 0

    def test_batch_update(self) -> None:
        docs = _mock_docs_service()
        docs.batchUpdate.return_value.execute.return_value = {
            "replies": [{"someReply": {}}]
        }
        client = _make_client(docs)

        requests = [{"insertText": {"text": "hi"}}]
        result = client.batch_update("doc123", requests)

        assert result["replies"] == [{"someReply": {}}]


# ---------------------------------------------------------------------------
# Tool execution (end-to-end via @tool wrappers)
# ---------------------------------------------------------------------------


class TestGdocsToolExecution:
    """Tests for executing tools through the @tool decorator."""

    @pytest.mark.asyncio
    async def test_create_document(self) -> None:
        docs = _mock_docs_service()
        docs.create.return_value.execute.return_value = {
            "documentId": "new_doc",
            "title": "New Doc",
        }
        tools = _make_tools(docs)
        t = _get_tool(tools, "gdocs_create_document")

        result = await t.execute({"title": "New Doc"})

        assert result.success
        assert result.output["document_id"] == "new_doc"

    @pytest.mark.asyncio
    async def test_get_document(self) -> None:
        docs = _mock_docs_service()
        docs.get.return_value.execute.return_value = {
            "documentId": "doc1",
            "title": "Test",
            "body": {
                "content": [
                    {"paragraph": {"elements": [{"textRun": {"content": "body\n"}}]}}
                ]
            },
        }
        tools = _make_tools(docs)
        t = _get_tool(tools, "gdocs_get_document")

        result = await t.execute({"document_id": "doc1"})

        assert result.success
        assert result.output["body_text"] == "body\n"

    @pytest.mark.asyncio
    async def test_insert_text(self) -> None:
        docs = _mock_docs_service()
        docs.batchUpdate.return_value.execute.return_value = {"replies": []}
        tools = _make_tools(docs)
        t = _get_tool(tools, "gdocs_insert_text")

        result = await t.execute(
            {
                "document_id": "doc1",
                "text": "Hello",
                "index": 1,
            }
        )

        assert result.success
        assert result.output["inserted"] is True

    @pytest.mark.asyncio
    async def test_replace_text(self) -> None:
        docs = _mock_docs_service()
        docs.batchUpdate.return_value.execute.return_value = {
            "replies": [{"replaceAllText": {"occurrencesChanged": 2}}]
        }
        tools = _make_tools(docs)
        t = _get_tool(tools, "gdocs_replace_text")

        result = await t.execute(
            {
                "document_id": "doc1",
                "find": "foo",
                "replace": "bar",
            }
        )

        assert result.success
        assert result.output["occurrences_changed"] == 2

    @pytest.mark.asyncio
    async def test_batch_update(self) -> None:
        docs = _mock_docs_service()
        docs.batchUpdate.return_value.execute.return_value = {"replies": [{}]}
        tools = _make_tools(docs)
        t = _get_tool(tools, "gdocs_batch_update")

        result = await t.execute(
            {
                "document_id": "doc1",
                "requests": [{"insertText": {"text": "test"}}],
            }
        )

        assert result.success
        assert result.output["replies"] == [{}]

    @pytest.mark.asyncio
    async def test_api_error_returns_failure(self) -> None:
        docs = _mock_docs_service()
        docs.create.return_value.execute.side_effect = RuntimeError("quota exceeded")
        tools = _make_tools(docs)
        t = _get_tool(tools, "gdocs_create_document")

        result = await t.execute({"title": "Fail"})

        assert not result.success
        assert "quota exceeded" in result.error


# ---------------------------------------------------------------------------
# Dependency check
# ---------------------------------------------------------------------------


class TestGdocsDependencyCheck:
    """Tests for missing dependency handling."""

    def test_missing_deps_raises_import_error(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import pygubernator.tools.gdocs_tools as mod

        monkeypatch.setattr(mod, "_HAS_GDOCS", False)
        with pytest.raises(ImportError, match="not available"):
            mod._check_deps()


# ---------------------------------------------------------------------------
# Factory env helper
# ---------------------------------------------------------------------------


class TestGdocsFactoryEnv:
    """Tests for create_tools_from_env in gdocs_factory."""

    def test_missing_env_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from pygubernator.tools import gdocs_factory

        monkeypatch.delenv(
            "PYGUBERNATOR_GDOCS_CREDENTIALS_PATH",
            raising=False,
        )
        with pytest.raises(ValueError):
            gdocs_factory.create_tools_from_env()

    def test_uses_env_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from pygubernator.tools import gdocs_factory

        seen: dict[str, str] = {}

        def fake_create(path: str) -> list[Any]:
            seen["path"] = path
            return []

        monkeypatch.setenv(
            "PYGUBERNATOR_GDOCS_CREDENTIALS_PATH",
            "/tmp/fake-sa.json",
        )
        monkeypatch.setattr(gdocs_factory, "create_gdocs_tools", fake_create)
        tools = gdocs_factory.create_tools_from_env()
        assert tools == []
        assert seen["path"] == "/tmp/fake-sa.json"

    def test_custom_env_name(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from pygubernator.tools import gdocs_factory

        seen: dict[str, str] = {}

        def fake_create(path: str) -> list[Any]:
            seen["path"] = path
            return []

        monkeypatch.setenv("CUSTOM_GDOCS_PATH", "/tmp/custom.json")
        monkeypatch.setattr(gdocs_factory, "create_gdocs_tools", fake_create)
        tools = gdocs_factory.create_tools_from_env("CUSTOM_GDOCS_PATH")
        assert tools == []
        assert seen["path"] == "/tmp/custom.json"
