"""Tests for lifecycle hooks system."""

from __future__ import annotations

from typing import Any

import pytest

from pygubernator._types import Message, ToolResult
from pygubernator.agents._hooks import (
    AfterLLMCallContext,
    AfterToolCallContext,
    BeforeLLMCallContext,
    BeforePromptBuildContext,
    BeforeToolCallContext,
    Hook,
    HookPoint,
    HookRegistry,
)
from pygubernator.agents._llm import LLMAgent
from pygubernator.llm._messages import LLMResponse, ToolCall
from pygubernator.tools._registry import ToolRegistry
from tests.conftest import _MockLLMProvider

# -- Helpers --


class _SearchTool:
    """Mock search tool for hook tests."""

    @property
    def name(self) -> str:
        return "search"

    @property
    def description(self) -> str:
        return "Search"

    @property
    def parameters_schema(self) -> dict[str, Any]:
        return {}

    async def execute(
        self,
        params: dict[str, Any],
    ) -> ToolResult:
        """Execute the mock search tool."""
        return ToolResult(
            tool_name="search",
            success=True,
            output=f"found: {params.get('q', '')}",
        )


def _make_tool_agent(
    hooks: HookRegistry,
) -> tuple[LLMAgent, ToolRegistry]:
    """Create an LLMAgent wired with a search tool and hooks."""
    registry = ToolRegistry()
    registry.register(_SearchTool())
    provider = _MockLLMProvider(
        [
            LLMResponse(
                content="Let me search",
                tool_calls=(
                    ToolCall(
                        id="tc1",
                        name="search",
                        arguments={"q": "test"},
                    ),
                ),
                finish_reason="tool_calls",
            ),
            LLMResponse(
                content="Done!",
                finish_reason="stop",
            ),
        ],
    )
    agent = LLMAgent(
        agent_id="hook-test",
        llm_provider=provider,
        tool_registry=registry,
        system_prompt="Be helpful.",
        hooks=hooks,
    )
    return agent, registry


# -- HookRegistry unit tests --


class TestHookRegistry:
    """Tests for the HookRegistry class."""

    def test_empty_registry(self) -> None:
        reg = HookRegistry()
        assert len(reg) == 0

    def test_add_hook(self) -> None:
        reg = HookRegistry()

        async def noop(ctx: Any) -> None:
            pass

        reg.add(
            Hook(
                point=HookPoint.BEFORE_LLM_CALL,
                handler=noop,
                name="h1",
            ),
        )
        assert len(reg) == 1

    def test_remove_hook_by_name(self) -> None:
        reg = HookRegistry()

        async def noop(ctx: Any) -> None:
            pass

        reg.add(
            Hook(
                point=HookPoint.BEFORE_LLM_CALL,
                handler=noop,
                name="removable",
            ),
        )
        assert len(reg) == 1
        reg.remove("removable")
        assert len(reg) == 0

    def test_remove_nonexistent_name_is_safe(self) -> None:
        reg = HookRegistry()
        reg.remove("does-not-exist")
        assert len(reg) == 0

    @pytest.mark.asyncio
    async def test_run_modifies_context(self) -> None:
        reg = HookRegistry()

        async def mutate(ctx: BeforePromptBuildContext) -> None:
            ctx.system_prompt = "modified"

        reg.add(
            Hook(
                point=HookPoint.BEFORE_PROMPT_BUILD,
                handler=mutate,
            ),
        )
        ctx = BeforePromptBuildContext(
            system_prompt="original",
            history=None,
            user_message="hi",
        )
        result = await reg.run(
            HookPoint.BEFORE_PROMPT_BUILD,
            ctx,
        )
        assert result.system_prompt == "modified"

    @pytest.mark.asyncio
    async def test_run_returns_replacement(self) -> None:
        reg = HookRegistry()

        async def replace(
            ctx: BeforePromptBuildContext,
        ) -> BeforePromptBuildContext:
            return BeforePromptBuildContext(
                system_prompt="replaced",
                history=ctx.history,
                user_message=ctx.user_message,
            )

        reg.add(
            Hook(
                point=HookPoint.BEFORE_PROMPT_BUILD,
                handler=replace,
            ),
        )
        ctx = BeforePromptBuildContext(
            system_prompt="original",
            history=None,
            user_message="hi",
        )
        result = await reg.run(
            HookPoint.BEFORE_PROMPT_BUILD,
            ctx,
        )
        assert result.system_prompt == "replaced"

    @pytest.mark.asyncio
    async def test_priority_ordering(self) -> None:
        reg = HookRegistry()
        order: list[int] = []

        async def hook_a(ctx: Any) -> None:
            order.append(1)

        async def hook_b(ctx: Any) -> None:
            order.append(2)

        async def hook_c(ctx: Any) -> None:
            order.append(3)

        reg.add(
            Hook(
                point=HookPoint.BEFORE_LLM_CALL,
                handler=hook_c,
                priority=300,
            ),
        )
        reg.add(
            Hook(
                point=HookPoint.BEFORE_LLM_CALL,
                handler=hook_a,
                priority=10,
            ),
        )
        reg.add(
            Hook(
                point=HookPoint.BEFORE_LLM_CALL,
                handler=hook_b,
                priority=50,
            ),
        )
        ctx = BeforeLLMCallContext(
            messages=[],
            tools=None,
            iteration=1,
        )
        await reg.run(HookPoint.BEFORE_LLM_CALL, ctx)
        assert order == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_error_in_hook_does_not_crash(self) -> None:
        reg = HookRegistry()

        async def bad_hook(ctx: Any) -> None:
            raise RuntimeError("hook error")

        async def good_hook(ctx: BeforePromptBuildContext) -> None:
            ctx.system_prompt = "survived"

        reg.add(
            Hook(
                point=HookPoint.BEFORE_PROMPT_BUILD,
                handler=bad_hook,
                priority=1,
                name="bad",
            ),
        )
        reg.add(
            Hook(
                point=HookPoint.BEFORE_PROMPT_BUILD,
                handler=good_hook,
                priority=2,
                name="good",
            ),
        )
        ctx = BeforePromptBuildContext(
            system_prompt="original",
            history=None,
            user_message="hi",
        )
        result = await reg.run(
            HookPoint.BEFORE_PROMPT_BUILD,
            ctx,
        )
        assert result.system_prompt == "survived"

    @pytest.mark.asyncio
    async def test_run_no_hooks_for_point(self) -> None:
        reg = HookRegistry()
        ctx = BeforeLLMCallContext(
            messages=[],
            tools=None,
            iteration=1,
        )
        result = await reg.run(HookPoint.BEFORE_LLM_CALL, ctx)
        assert result is ctx


# -- Integration tests: hooks wired into LLMAgent.process() --


class TestBeforePromptBuildHook:
    """Tests for BEFORE_PROMPT_BUILD hook integration."""

    @pytest.mark.asyncio
    async def test_modify_system_prompt(self) -> None:
        hooks = HookRegistry()

        async def change_prompt(
            ctx: BeforePromptBuildContext,
        ) -> None:
            ctx.system_prompt = "You are a pirate."

        hooks.add(
            Hook(
                point=HookPoint.BEFORE_PROMPT_BUILD,
                handler=change_prompt,
            ),
        )
        captured: list[list[dict[str, Any]]] = []

        class _CapturingProvider:
            async def chat(
                self,
                messages: list[dict[str, Any]],
                tools: Any = None,
            ) -> LLMResponse:
                captured.append(list(messages))
                return LLMResponse(
                    content="Arrr!",
                    finish_reason="stop",
                )

        agent = LLMAgent(
            agent_id="hook-test",
            llm_provider=_CapturingProvider(),
            system_prompt="You are helpful.",
            hooks=hooks,
        )
        msg = Message(topic="t", payload={"content": "Hi"})
        result = await agent.process(msg)
        assert result.success
        assert captured[0][0]["content"] == "You are a pirate."

    @pytest.mark.asyncio
    async def test_modify_history(self) -> None:
        hooks = HookRegistry()

        async def inject_history(
            ctx: BeforePromptBuildContext,
        ) -> None:
            ctx.history = [
                {"role": "user", "content": "old"},
                {"role": "assistant", "content": "old reply"},
            ]

        hooks.add(
            Hook(
                point=HookPoint.BEFORE_PROMPT_BUILD,
                handler=inject_history,
            ),
        )
        captured: list[list[dict[str, Any]]] = []

        class _CapturingProvider:
            async def chat(
                self,
                messages: list[dict[str, Any]],
                tools: Any = None,
            ) -> LLMResponse:
                captured.append(list(messages))
                return LLMResponse(
                    content="ok",
                    finish_reason="stop",
                )

        agent = LLMAgent(
            agent_id="hook-test",
            llm_provider=_CapturingProvider(),
            system_prompt="sys",
            hooks=hooks,
        )
        msg = Message(topic="t", payload={"content": "Hi"})
        await agent.process(msg)
        # system + 2 history + user = 4 messages
        assert len(captured[0]) == 4
        assert captured[0][1]["content"] == "old"

    @pytest.mark.asyncio
    async def test_modify_user_message(self) -> None:
        hooks = HookRegistry()

        async def rewrite_msg(
            ctx: BeforePromptBuildContext,
        ) -> None:
            ctx.user_message = "rewritten"

        hooks.add(
            Hook(
                point=HookPoint.BEFORE_PROMPT_BUILD,
                handler=rewrite_msg,
            ),
        )
        captured: list[list[dict[str, Any]]] = []

        class _CapturingProvider:
            async def chat(
                self,
                messages: list[dict[str, Any]],
                tools: Any = None,
            ) -> LLMResponse:
                captured.append(list(messages))
                return LLMResponse(
                    content="ok",
                    finish_reason="stop",
                )

        agent = LLMAgent(
            agent_id="hook-test",
            llm_provider=_CapturingProvider(),
            system_prompt="",
            hooks=hooks,
        )
        msg = Message(topic="t", payload={"content": "original"})
        await agent.process(msg)
        assert captured[0][0]["content"] == "rewritten"


class TestBeforeLLMCallHook:
    """Tests for BEFORE_LLM_CALL hook integration."""

    @pytest.mark.asyncio
    async def test_modify_messages(self) -> None:
        hooks = HookRegistry()

        async def add_msg(ctx: BeforeLLMCallContext) -> None:
            ctx.messages.append(
                {"role": "system", "content": "extra"},
            )

        hooks.add(
            Hook(
                point=HookPoint.BEFORE_LLM_CALL,
                handler=add_msg,
            ),
        )
        captured: list[list[dict[str, Any]]] = []

        class _CapturingProvider:
            async def chat(
                self,
                messages: list[dict[str, Any]],
                tools: Any = None,
            ) -> LLMResponse:
                captured.append(list(messages))
                return LLMResponse(
                    content="ok",
                    finish_reason="stop",
                )

        agent = LLMAgent(
            agent_id="hook-test",
            llm_provider=_CapturingProvider(),
            system_prompt="sys",
            hooks=hooks,
        )
        msg = Message(topic="t", payload={"content": "Hi"})
        await agent.process(msg)
        contents = [m["content"] for m in captured[0]]
        assert "extra" in contents

    @pytest.mark.asyncio
    async def test_modify_tools(self) -> None:
        hooks = HookRegistry()

        async def clear_tools(
            ctx: BeforeLLMCallContext,
        ) -> None:
            ctx.tools = None

        hooks.add(
            Hook(
                point=HookPoint.BEFORE_LLM_CALL,
                handler=clear_tools,
            ),
        )
        captured_tools: list[Any] = []

        class _CapturingProvider:
            async def chat(
                self,
                messages: list[dict[str, Any]],
                tools: Any = None,
            ) -> LLMResponse:
                captured_tools.append(tools)
                return LLMResponse(
                    content="ok",
                    finish_reason="stop",
                )

        registry = ToolRegistry()
        registry.register(_SearchTool())
        agent = LLMAgent(
            agent_id="hook-test",
            llm_provider=_CapturingProvider(),
            tool_registry=registry,
            hooks=hooks,
        )
        msg = Message(topic="t", payload={"content": "Hi"})
        await agent.process(msg)
        assert captured_tools[0] is None


class TestAfterLLMCallHook:
    """Tests for AFTER_LLM_CALL hook integration."""

    @pytest.mark.asyncio
    async def test_modify_response(self) -> None:
        hooks = HookRegistry()

        async def rewrite(ctx: AfterLLMCallContext) -> None:
            ctx.response = LLMResponse(
                content="hooked!",
                finish_reason="stop",
            )

        hooks.add(
            Hook(
                point=HookPoint.AFTER_LLM_CALL,
                handler=rewrite,
            ),
        )
        provider = _MockLLMProvider(
            [LLMResponse(content="original", finish_reason="stop")],
        )
        agent = LLMAgent(
            agent_id="hook-test",
            llm_provider=provider,
            hooks=hooks,
        )
        msg = Message(topic="t", payload={"content": "Hi"})
        result = await agent.process(msg)
        assert result.success
        assert result.metadata["response"] == "hooked!"


class TestBeforeToolCallHook:
    """Tests for BEFORE_TOOL_CALL hook integration."""

    @pytest.mark.asyncio
    async def test_modify_tool_arguments(self) -> None:
        hooks = HookRegistry()

        async def rewrite_args(
            ctx: BeforeToolCallContext,
        ) -> None:
            ctx.arguments = {"q": "modified"}

        hooks.add(
            Hook(
                point=HookPoint.BEFORE_TOOL_CALL,
                handler=rewrite_args,
            ),
        )
        agent, _ = _make_tool_agent(hooks)
        msg = Message(
            topic="t",
            payload={"content": "search"},
        )
        result = await agent.process(msg)
        assert result.success
        tool_out = result.metadata["tool_results"][0]
        assert tool_out["output"] == "found: modified"


class TestAfterToolCallHook:
    """Tests for AFTER_TOOL_CALL hook integration."""

    @pytest.mark.asyncio
    async def test_modify_tool_result(self) -> None:
        hooks = HookRegistry()

        async def rewrite_result(
            ctx: AfterToolCallContext,
        ) -> None:
            ctx.result = ToolResult(
                tool_name=ctx.tool_name,
                success=True,
                output="hooked output",
            )

        hooks.add(
            Hook(
                point=HookPoint.AFTER_TOOL_CALL,
                handler=rewrite_result,
            ),
        )
        agent, _ = _make_tool_agent(hooks)
        msg = Message(
            topic="t",
            payload={"content": "search"},
        )
        result = await agent.process(msg)
        assert result.success
        tool_out = result.metadata["tool_results"][0]
        assert tool_out["output"] == "hooked output"
