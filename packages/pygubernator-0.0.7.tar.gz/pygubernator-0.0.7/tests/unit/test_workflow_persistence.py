"""Tests for workflow persistence — DB models and repository functions."""

from __future__ import annotations

import pytest
from sqlalchemy.orm import sessionmaker

from pygubernator.db.repositories import (
    activate_workflow_version,
    create_workflow,
    create_workflow_run,
    create_workflow_step_run,
    create_workflow_version,
    get_workflow,
    get_workflow_run,
    list_step_runs,
    list_workflow_runs,
    list_workflow_versions,
    list_workflows,
    update_workflow,
    update_workflow_run,
    update_workflow_step_run,
)
from tests.unit.conftest import reset_test_db, test_engine

_TestSessionLocal = sessionmaker(bind=test_engine, autoflush=False, autocommit=False)


@pytest.fixture(autouse=True)
def _reset_db() -> None:
    reset_test_db()


@pytest.fixture
def db():
    session = _TestSessionLocal()
    try:
        yield session
    finally:
        session.close()


class TestWorkflowCRUD:
    """Tests for Workflow create/read/update/list operations."""

    def test_create_and_get_workflow(self, db) -> None:
        wf = create_workflow(db, name="wf-1", description="Test", owner="me")
        db.commit()
        db.refresh(wf)

        fetched = get_workflow(db, wf.id)
        assert fetched is not None
        assert fetched.name == "wf-1"
        assert fetched.description == "Test"
        assert fetched.owner == "me"
        assert fetched.status == "active"

    def test_get_workflow_not_found(self, db) -> None:
        assert get_workflow(db, "nonexistent") is None

    def test_list_workflows(self, db) -> None:
        create_workflow(db, name="wf-a")
        create_workflow(db, name="wf-b")
        db.commit()

        items, total = list_workflows(db)
        assert total == 2
        assert len(items) == 2

    def test_list_workflows_status_filter(self, db) -> None:
        create_workflow(db, name="active-wf", status="active")
        create_workflow(db, name="archived-wf", status="archived")
        db.commit()

        items, total = list_workflows(db, status="active")
        assert total == 1
        assert items[0].name == "active-wf"

    def test_update_workflow(self, db) -> None:
        wf = create_workflow(db, name="wf-update")
        db.commit()
        db.refresh(wf)

        update_workflow(db, wf, status="archived", description="Updated")
        db.commit()
        db.refresh(wf)

        assert wf.status == "archived"
        assert wf.description == "Updated"


class TestWorkflowVersionCRUD:
    """Tests for WorkflowVersion operations."""

    def test_create_and_list_versions(self, db) -> None:
        wf = create_workflow(db, name="wf-ver")
        db.commit()
        db.refresh(wf)

        create_workflow_version(
            db,
            workflow_id=wf.id,
            version="1.0.0",
            spec_json={"nodes": {}},
            created_by="tester",
        )
        create_workflow_version(
            db,
            workflow_id=wf.id,
            version="2.0.0",
            spec_json={"nodes": {"a": {}}},
        )
        db.commit()

        versions = list_workflow_versions(db, wf.id)
        assert len(versions) == 2
        assert versions[0].version in ("1.0.0", "2.0.0")

    def test_create_same_version_updates_spec(self, db) -> None:
        wf = create_workflow(db, name="wf-dup-ver")
        db.commit()
        db.refresh(wf)

        create_workflow_version(
            db,
            workflow_id=wf.id,
            version="1.0.0",
            spec_json={"nodes": {"a": 1}},
        )
        create_workflow_version(
            db,
            workflow_id=wf.id,
            version="1.0.0",
            spec_json={"nodes": {"a": 2}},
        )
        db.commit()

        versions = list_workflow_versions(db, wf.id)
        assert len(versions) == 1
        assert versions[0].spec_json == {"nodes": {"a": 2}}

    def test_activate_workflow_version(self, db) -> None:
        wf = create_workflow(db, name="wf-activate")
        db.commit()
        db.refresh(wf)

        v1 = create_workflow_version(
            db, workflow_id=wf.id, version="1.0.0", active=True
        )
        v2 = create_workflow_version(db, workflow_id=wf.id, version="2.0.0")
        db.commit()
        db.refresh(wf)

        activate_workflow_version(db, wf, v2.id)
        db.commit()
        db.refresh(v1)
        db.refresh(v2)

        assert v1.active is False
        assert v2.active is True


class TestWorkflowRunCRUD:
    """Tests for WorkflowRun operations."""

    def test_create_and_get_workflow_run(self, db) -> None:
        wf = create_workflow(db, name="wf-run")
        db.commit()
        db.refresh(wf)

        run = create_workflow_run(
            db,
            workflow_id=wf.id,
            input_json={"key": "value"},
            created_by="tester",
        )
        db.commit()
        db.refresh(run)

        fetched = get_workflow_run(db, run.id)
        assert fetched is not None
        assert fetched.workflow_id == wf.id
        assert fetched.input_json == {"key": "value"}
        assert fetched.status == "pending"

    def test_list_workflow_runs(self, db) -> None:
        wf = create_workflow(db, name="wf-runs-list")
        db.commit()
        db.refresh(wf)

        create_workflow_run(db, workflow_id=wf.id, status="running")
        create_workflow_run(db, workflow_id=wf.id, status="completed")
        db.commit()

        items, total = list_workflow_runs(db)
        assert total == 2

        items, total = list_workflow_runs(db, status="running")
        assert total == 1

    def test_update_workflow_run(self, db) -> None:
        wf = create_workflow(db, name="wf-update-run")
        db.commit()
        db.refresh(wf)

        run = create_workflow_run(db, workflow_id=wf.id)
        db.commit()
        db.refresh(run)

        update_workflow_run(
            db,
            run,
            status="completed",
            output_json={"result": 42},
            duration_ms=1500,
        )
        db.commit()
        db.refresh(run)

        assert run.status == "completed"
        assert run.output_json == {"result": 42}
        assert run.duration_ms == 1500


class TestWorkflowStepRunCRUD:
    """Tests for WorkflowStepRun operations."""

    def test_create_and_list_step_runs(self, db) -> None:
        wf = create_workflow(db, name="wf-steps")
        db.commit()
        db.refresh(wf)

        run = create_workflow_run(db, workflow_id=wf.id)
        db.commit()
        db.refresh(run)

        create_workflow_step_run(
            db,
            workflow_run_id=run.id,
            node_id="node_a",
            node_type="template",
            input_json={"text": "hello"},
        )
        create_workflow_step_run(
            db,
            workflow_run_id=run.id,
            node_id="node_b",
            node_type="code",
        )
        db.commit()

        steps = list_step_runs(db, run.id)
        assert len(steps) == 2

    def test_update_step_run(self, db) -> None:
        wf = create_workflow(db, name="wf-step-update")
        db.commit()
        db.refresh(wf)

        run = create_workflow_run(db, workflow_id=wf.id)
        db.commit()
        db.refresh(run)

        step = create_workflow_step_run(
            db,
            workflow_run_id=run.id,
            node_id="node_x",
            node_type="condition",
        )
        db.commit()
        db.refresh(step)

        update_workflow_step_run(
            db,
            step,
            status="completed",
            output_json={"branch": "yes"},
            output_handle="yes",
            duration_ms=50,
        )
        db.commit()
        db.refresh(step)

        assert step.status == "completed"
        assert step.output_json == {"branch": "yes"}
        assert step.output_handle == "yes"
        assert step.duration_ms == 50


class TestEnginePersistCallback:
    """Tests for WorkflowEngine persist_callback integration."""

    def test_persist_callback_is_called(self) -> None:
        """Engine calls persist_callback after each node execution."""
        import asyncio

        from pygubernator.workflow._engine import WorkflowEngine
        from pygubernator.workflow._registry import NodeTypeRegistry
        from pygubernator.workflow._types import (
            EdgeSpec,
            NodeResult,
            NodeSpec,
            WorkflowSpec,
        )
        from pygubernator.workflow.nodes._input import InputNodeFactory
        from pygubernator.workflow.nodes._output import OutputNodeFactory
        from pygubernator.workflow.nodes._template import (
            TemplateNodeFactory,
        )

        registry = NodeTypeRegistry()
        registry.register("input", InputNodeFactory())
        registry.register("output", OutputNodeFactory())
        registry.register("template", TemplateNodeFactory())

        spec = WorkflowSpec(
            name="callback-test",
            version="1.0.0",
            nodes={
                "in": NodeSpec(node_id="in", node_type="input"),
                "out": NodeSpec(
                    node_id="out",
                    node_type="output",
                    config={"mappings": {"result": "{{ message }}"}},
                ),
            },
            edges=(EdgeSpec(edge_id="e1", source_id="in", target_id="out"),),
        )

        calls: list[tuple[str, NodeResult]] = []

        def on_persist(node_id: str, result: NodeResult) -> None:
            calls.append((node_id, result))

        engine = WorkflowEngine(
            spec=spec,
            registry=registry,
            persist_callback=on_persist,
        )
        result = asyncio.run(engine.run({"message": "hi"}))

        assert result.success
        assert len(calls) == 2
        node_ids = [c[0] for c in calls]
        assert "in" in node_ids
        assert "out" in node_ids

    def test_persist_callback_error_does_not_break_engine(self) -> None:
        """Engine continues even if persist_callback raises."""
        import asyncio

        from pygubernator.workflow._engine import WorkflowEngine
        from pygubernator.workflow._registry import NodeTypeRegistry
        from pygubernator.workflow._types import (
            NodeSpec,
            WorkflowSpec,
        )
        from pygubernator.workflow.nodes._input import InputNodeFactory

        registry = NodeTypeRegistry()
        registry.register("input", InputNodeFactory())

        spec = WorkflowSpec(
            name="callback-err",
            version="1.0.0",
            nodes={"in": NodeSpec(node_id="in", node_type="input")},
        )

        def bad_callback(node_id, result):
            raise RuntimeError("callback boom")

        engine = WorkflowEngine(
            spec=spec,
            registry=registry,
            persist_callback=bad_callback,
        )
        result = asyncio.run(engine.run({}))
        assert result.success
