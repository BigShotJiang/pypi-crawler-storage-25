"""Tests for pycatalyst tool wrappers using real pycatalyst."""

from __future__ import annotations

from typing import Any

import pytest
from pycatalyst import SchemaBuilder

from pygubernator.tools.catalyst_tools import create_catalyst_tools


@pytest.fixture
def demo_schemas() -> dict[str, Any]:
    """Build demo schemas for testing."""
    users = (
        SchemaBuilder("users", description="Test users")
        .add_uuid("id")
        .add_string("name", format="name")
        .add_int("age", min_val=18, max_val=99)
        .build()
    )
    orders = (
        SchemaBuilder("orders", description="Test orders")
        .add_uuid("id")
        .add_float("amount", min_val=1.0, max_val=9999.99, precision=2)
        .add_enum("status", ["pending", "confirmed", "shipped"])
        .build()
    )
    return {"users": users, "orders": orders}


@pytest.fixture
def catalyst_tools(demo_schemas: dict[str, Any]) -> list[Any]:
    return create_catalyst_tools(demo_schemas)


class TestCatalystToolsFactory:
    """Tests for create_catalyst_tools factory."""

    def test_returns_two_tools(self, catalyst_tools: list[Any]) -> None:
        assert len(catalyst_tools) == 2
        names = {t.name for t in catalyst_tools}
        assert names == {"generate_data", "build_schema"}


class TestGenerateData:
    """Tests for the generate_data tool with real pycatalyst."""

    @pytest.mark.asyncio
    async def test_generates_records(self, catalyst_tools: list[Any]) -> None:
        gen = next(t for t in catalyst_tools if t.name == "generate_data")
        result = await gen.execute({"schema_name": "users", "count": 5})
        assert result.success
        assert len(result.output) == 5
        for record in result.output:
            assert "id" in record
            assert "name" in record
            assert "age" in record

    @pytest.mark.asyncio
    async def test_generates_orders(self, catalyst_tools: list[Any]) -> None:
        gen = next(t for t in catalyst_tools if t.name == "generate_data")
        result = await gen.execute({"schema_name": "orders", "count": 3})
        assert result.success
        assert len(result.output) == 3
        for record in result.output:
            assert "id" in record
            assert "amount" in record
            assert record["status"] in ("pending", "confirmed", "shipped")

    @pytest.mark.asyncio
    async def test_seed_reproducibility(self, catalyst_tools: list[Any]) -> None:
        gen = next(t for t in catalyst_tools if t.name == "generate_data")
        r1 = await gen.execute({"schema_name": "users", "count": 3, "seed": 42})
        r2 = await gen.execute({"schema_name": "users", "count": 3, "seed": 42})
        assert r1.output == r2.output

    @pytest.mark.asyncio
    async def test_unknown_schema_fails(self, catalyst_tools: list[Any]) -> None:
        gen = next(t for t in catalyst_tools if t.name == "generate_data")
        result = await gen.execute({"schema_name": "nonexistent", "count": 1})
        assert not result.success
        assert "not found" in result.error

    @pytest.mark.asyncio
    async def test_returns_list_of_dicts(self, catalyst_tools: list[Any]) -> None:
        gen = next(t for t in catalyst_tools if t.name == "generate_data")
        result = await gen.execute({"schema_name": "users", "count": 2})
        assert result.success
        assert isinstance(result.output, list)
        assert all(isinstance(r, dict) for r in result.output)


class TestBuildSchema:
    """Tests for the build_schema tool with real pycatalyst."""

    @pytest.mark.asyncio
    async def test_builds_schema_from_fields(self, catalyst_tools: list[Any]) -> None:
        build = next(t for t in catalyst_tools if t.name == "build_schema")
        result = await build.execute(
            {
                "fields": {
                    "name": {"type": "string"},
                    "age": {"type": "int", "min": 0, "max": 150},
                    "active": {"type": "bool"},
                }
            }
        )
        assert result.success
        schema_dict = result.output
        assert schema_dict["name"] == "dynamic"
        assert len(schema_dict["fields"]) == 3
        field_names = [f["name"] for f in schema_dict["fields"]]
        assert "name" in field_names
        assert "age" in field_names
        assert "active" in field_names

    @pytest.mark.asyncio
    async def test_schema_round_trip(self, catalyst_tools: list[Any]) -> None:
        """Built schema can be loaded back via SchemaSpec.from_config."""
        from pycatalyst._types import SchemaSpec

        build = next(t for t in catalyst_tools if t.name == "build_schema")
        result = await build.execute(
            {
                "fields": {
                    "id": {"type": "uuid"},
                    "value": {"type": "float", "min": 0.0, "max": 100.0},
                }
            }
        )
        assert result.success
        schema = SchemaSpec.from_config(result.output)
        assert schema.name == "dynamic"
        assert schema.field_names == ("id", "value")
