"""Tests for event system: EventBus, handlers, and agent event emission."""

from __future__ import annotations

import logging
from typing import Any

import pytest
from pystator import StateMachine

from pygubernator._events import AgentEvent, AgentEventType, EventBus
from pygubernator._handlers import LoggingEventHandler, MetricsEventHandler
from pygubernator._types import AgentResult, Message, StepResult, ToolResult
from pygubernator.agents._base import BaseAgent
from pygubernator.agents._llm import LLMAgent
from pygubernator.agents._machines import base_lifecycle_config
from pygubernator.agents._pipeline import PipelineAgent, PipelineStep
from pygubernator.agents._state_machine import StateMachineAgent
from pygubernator.llm._messages import LLMResponse, ToolCall
from pygubernator.tools._registry import ToolRegistry
from tests.conftest import _MockLLMProvider

# -- Helpers --


class _EventEmittingAgent(BaseAgent):
    """Concrete BaseAgent for testing event emission."""

    async def process(self, message: Message) -> AgentResult:
        await self._emit(AgentEventType.MESSAGE_RECEIVED, {"topic": message.topic})
        await self._emit(AgentEventType.MESSAGE_PROCESSED)
        return AgentResult(
            agent_id=self.agent_id,
            success=True,
            messages_processed=1,
        )


class _CollectingHandler:
    """Handler that collects all events for assertions."""

    def __init__(self) -> None:
        self.events: list[AgentEvent] = []

    async def handle(self, event: AgentEvent) -> None:
        self.events.append(event)


class _FailingHandler:
    """Handler that raises on every event."""

    async def handle(self, event: AgentEvent) -> None:
        raise RuntimeError("handler boom")


# -- EventBus tests --


class TestEventBus:
    """Tests for EventBus fan-out and error isolation."""

    @pytest.mark.asyncio
    async def test_emit_fans_out_to_all_handlers(self) -> None:
        bus = EventBus()
        h1 = _CollectingHandler()
        h2 = _CollectingHandler()
        bus.add_handler(h1)
        bus.add_handler(h2)

        event = AgentEvent(
            event_type=AgentEventType.AGENT_STARTED,
            agent_id="a1",
        )
        await bus.emit(event)

        assert len(h1.events) == 1
        assert len(h2.events) == 1
        assert h1.events[0].event_type == AgentEventType.AGENT_STARTED

    @pytest.mark.asyncio
    async def test_handler_exception_does_not_block_others(self) -> None:
        bus = EventBus()
        failing = _FailingHandler()
        collector = _CollectingHandler()
        bus.add_handler(failing)
        bus.add_handler(collector)

        event = AgentEvent(
            event_type=AgentEventType.AGENT_STARTED,
            agent_id="a1",
        )
        await bus.emit(event)

        # collector still received the event despite failing handler
        assert len(collector.events) == 1

    @pytest.mark.asyncio
    async def test_remove_handler(self) -> None:
        bus = EventBus()
        h = _CollectingHandler()
        bus.add_handler(h)
        bus.remove_handler(h)

        event = AgentEvent(
            event_type=AgentEventType.AGENT_STARTED,
            agent_id="a1",
        )
        await bus.emit(event)
        assert len(h.events) == 0

    def test_handler_count(self) -> None:
        bus = EventBus()
        assert bus.handler_count == 0
        h = _CollectingHandler()
        bus.add_handler(h)
        assert bus.handler_count == 1

    @pytest.mark.asyncio
    async def test_emit_with_no_handlers(self) -> None:
        bus = EventBus()
        event = AgentEvent(
            event_type=AgentEventType.AGENT_STARTED,
            agent_id="a1",
        )
        await bus.emit(event)  # should not raise


# -- LoggingEventHandler tests --


class TestLoggingEventHandler:
    """Tests for LoggingEventHandler log levels."""

    @pytest.mark.asyncio
    async def test_info_event(self, caplog: pytest.LogCaptureFixture) -> None:
        handler = LoggingEventHandler()
        event = AgentEvent(
            event_type=AgentEventType.AGENT_STARTED,
            agent_id="a1",
        )
        with caplog.at_level(logging.INFO):
            await handler.handle(event)
        assert "agent.started" in caplog.text

    @pytest.mark.asyncio
    async def test_error_event(self, caplog: pytest.LogCaptureFixture) -> None:
        handler = LoggingEventHandler()
        event = AgentEvent(
            event_type=AgentEventType.AGENT_ERROR,
            agent_id="a1",
            data={"error": "boom"},
        )
        with caplog.at_level(logging.ERROR):
            await handler.handle(event)
        assert "agent.error" in caplog.text

    @pytest.mark.asyncio
    async def test_warning_event(self, caplog: pytest.LogCaptureFixture) -> None:
        handler = LoggingEventHandler()
        event = AgentEvent(
            event_type=AgentEventType.AGENT_PAUSED,
            agent_id="a1",
        )
        with caplog.at_level(logging.WARNING):
            await handler.handle(event)
        assert "agent.paused" in caplog.text


# -- MetricsEventHandler tests --


class TestMetricsEventHandler:
    """Tests for MetricsEventHandler accumulation."""

    @pytest.mark.asyncio
    async def test_counter_accumulation(self) -> None:
        handler = MetricsEventHandler()
        for _ in range(3):
            await handler.handle(
                AgentEvent(
                    event_type=AgentEventType.AGENT_STARTED,
                    agent_id="a1",
                )
            )
        metrics = handler.get_metrics()
        assert metrics["counters"]["agent.started"] == 3

    @pytest.mark.asyncio
    async def test_duration_recording(self) -> None:
        handler = MetricsEventHandler()
        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.STEP_COMPLETED,
                agent_id="a1",
                data={"duration_ms": 42.5},
            )
        )
        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.STEP_COMPLETED,
                agent_id="a1",
                data={"duration_ms": 10.0},
            )
        )
        metrics = handler.get_metrics()
        assert metrics["durations"]["step.completed"] == [42.5, 10.0]

    @pytest.mark.asyncio
    async def test_reset(self) -> None:
        handler = MetricsEventHandler()
        await handler.handle(
            AgentEvent(
                event_type=AgentEventType.AGENT_STARTED,
                agent_id="a1",
            )
        )
        handler.reset()
        metrics = handler.get_metrics()
        assert metrics["counters"] == {}


# -- BaseAgent event emission tests --


class TestBaseAgentEvents:
    """Tests for _emit in BaseAgent subclasses."""

    @pytest.mark.asyncio
    async def test_emit_with_bus(self) -> None:
        bus = EventBus()
        collector = _CollectingHandler()
        bus.add_handler(collector)

        agent = _EventEmittingAgent("test-1", event_bus=bus)
        msg = Message(topic="t", payload={"v": 1})
        await agent.process(msg)

        types = [e.event_type for e in collector.events]
        assert AgentEventType.MESSAGE_RECEIVED in types
        assert AgentEventType.MESSAGE_PROCESSED in types

    @pytest.mark.asyncio
    async def test_emit_without_bus(self) -> None:
        agent = _EventEmittingAgent("test-1")
        msg = Message(topic="t", payload={"v": 1})
        result = await agent.process(msg)
        assert result.success  # no errors even without bus


# -- PipelineAgent event emission --


class _ExtractStep(PipelineStep):
    async def execute(self, data: Any) -> StepResult:
        return StepResult(step_name=self.name, success=True, data=data)


class _FailStep(PipelineStep):
    async def execute(self, data: Any) -> StepResult:
        return StepResult(step_name=self.name, success=False, error="step failed")


class TestPipelineAgentEvents:
    """Tests for PipelineAgent step event emission."""

    @pytest.mark.asyncio
    async def test_step_events_emitted(self) -> None:
        bus = EventBus()
        collector = _CollectingHandler()
        bus.add_handler(collector)

        agent = PipelineAgent(
            agent_id="pipe-1",
            steps=[_ExtractStep("e1"), _ExtractStep("e2")],
            event_bus=bus,
        )
        msg = Message(topic="t", payload={"data": "raw"})
        result = await agent.process(msg)
        assert result.success

        types = [e.event_type for e in collector.events]
        assert types.count(AgentEventType.STEP_STARTED) == 2
        assert types.count(AgentEventType.STEP_COMPLETED) == 2

    @pytest.mark.asyncio
    async def test_step_failure_event(self) -> None:
        bus = EventBus()
        collector = _CollectingHandler()
        bus.add_handler(collector)

        agent = PipelineAgent(
            agent_id="pipe-1",
            steps=[_ExtractStep("e1"), _FailStep("bad")],
            event_bus=bus,
        )
        msg = Message(topic="t", payload={})
        result = await agent.process(msg)
        assert not result.success

        types = [e.event_type for e in collector.events]
        assert AgentEventType.STEP_FAILED in types


# -- LLMAgent event emission --


class TestLLMAgentEvents:
    """Tests for LLMAgent LLM and tool call event emission."""

    @pytest.mark.asyncio
    async def test_llm_events_emitted(self) -> None:
        bus = EventBus()
        collector = _CollectingHandler()
        bus.add_handler(collector)

        provider = _MockLLMProvider(
            [
                LLMResponse(content="Hello!", finish_reason="stop"),
            ]
        )
        agent = LLMAgent(
            agent_id="llm-1",
            llm_provider=provider,
            event_bus=bus,
        )
        msg = Message(topic="t", payload={"content": "Hi"})
        result = await agent.process(msg)
        assert result.success

        types = [e.event_type for e in collector.events]
        assert AgentEventType.LLM_REQUEST_STARTED in types
        assert AgentEventType.LLM_RESPONSE_RECEIVED in types

    @pytest.mark.asyncio
    async def test_tool_call_events(self) -> None:
        bus = EventBus()
        collector = _CollectingHandler()
        bus.add_handler(collector)

        registry = ToolRegistry()

        class _SearchTool:
            @property
            def name(self) -> str:
                return "search"

            @property
            def description(self) -> str:
                return "Search"

            @property
            def parameters_schema(self) -> dict[str, Any]:
                return {}

            async def execute(self, params: dict[str, Any]) -> ToolResult:
                return ToolResult(tool_name="search", success=True, output="found it")

        registry.register(_SearchTool())
        provider = _MockLLMProvider(
            [
                LLMResponse(
                    content="searching",
                    tool_calls=(ToolCall(id="tc1", name="search", arguments={}),),
                    finish_reason="tool_calls",
                ),
                LLMResponse(content="done", finish_reason="stop"),
            ]
        )
        agent = LLMAgent(
            agent_id="llm-1",
            llm_provider=provider,
            tool_registry=registry,
            event_bus=bus,
        )
        msg = Message(topic="t", payload={"content": "find"})
        result = await agent.process(msg)
        assert result.success

        types = [e.event_type for e in collector.events]
        assert AgentEventType.TOOL_CALL_STARTED in types
        assert AgentEventType.TOOL_CALL_COMPLETED in types


# -- StateMachineAgent event emission --


class TestStateMachineAgentEvents:
    """Tests for StateMachineAgent message events."""

    @pytest.mark.asyncio
    async def test_message_events(self) -> None:
        bus = EventBus()
        collector = _CollectingHandler()
        bus.add_handler(collector)

        workflow = StateMachine.from_dict(base_lifecycle_config())

        def handler(msg: Message, ctx: dict[str, Any]) -> dict[str, Any]:
            return {"event": "start"}

        agent = StateMachineAgent(
            agent_id="sm-1",
            workflow_machine=workflow,
            handler=handler,
            event_bus=bus,
        )
        msg = Message(topic="t", payload={"v": 1})
        result = await agent.process(msg)
        assert result.success

        types = [e.event_type for e in collector.events]
        assert AgentEventType.MESSAGE_RECEIVED in types
        assert AgentEventType.MESSAGE_PROCESSED in types
