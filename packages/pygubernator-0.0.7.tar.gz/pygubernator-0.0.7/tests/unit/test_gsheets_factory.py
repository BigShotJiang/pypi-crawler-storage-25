"""Tests for Google Sheets tool-factory adapter."""

from __future__ import annotations

import pytest

from pygubernator.tools import gsheets_factory


class TestGSheetsFactory:
    def test_missing_env_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH", raising=False)
        with pytest.raises(ValueError):
            gsheets_factory.create_tools_from_env()

    def test_uses_env_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        seen: dict[str, str] = {}

        def fake_create(path: str):
            seen["path"] = path
            return []

        monkeypatch.setenv(
            "PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH",
            "/tmp/fake-service-account.json",
        )
        monkeypatch.setattr(gsheets_factory, "create_gsheets_tools", fake_create)
        tools = gsheets_factory.create_tools_from_env()
        assert tools == []
        assert seen["path"] == "/tmp/fake-service-account.json"

    def test_custom_env_name(self, monkeypatch: pytest.MonkeyPatch) -> None:
        seen: dict[str, str] = {}

        def fake_create(path: str):
            seen["path"] = path
            return []

        monkeypatch.setenv("CUSTOM_GSHEETS_PATH", "/tmp/custom.json")
        monkeypatch.setattr(gsheets_factory, "create_gsheets_tools", fake_create)
        tools = gsheets_factory.create_tools_from_env("CUSTOM_GSHEETS_PATH")
        assert tools == []
        assert seen["path"] == "/tmp/custom.json"
