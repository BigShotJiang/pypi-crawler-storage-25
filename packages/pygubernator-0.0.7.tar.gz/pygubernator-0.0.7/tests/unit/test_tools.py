"""Tests for tool system."""

from __future__ import annotations

import types

import pytest

from pygubernator._types import ToolResult
from pygubernator.errors import ToolError
from pygubernator.tools._decorator import (
    _parse_arg_descriptions,
    _resolve_json_type,
    tool,
)
from pygubernator.tools._registry import ToolRegistry
from tests.conftest import _MockTool


class TestToolRegistry:
    """Tests for ToolRegistry."""

    def test_register_and_get(self) -> None:
        registry = ToolRegistry()
        t = _MockTool()
        registry.register(t)
        assert registry.has("mock")
        assert registry.get("mock") is t

    def test_register_duplicate_raises(self) -> None:
        registry = ToolRegistry()
        registry.register(_MockTool())
        with pytest.raises(ToolError):
            registry.register(_MockTool())

    def test_unregister(self) -> None:
        registry = ToolRegistry()
        registry.register(_MockTool())
        registry.unregister("mock")
        assert not registry.has("mock")

    def test_unregister_missing_raises(self) -> None:
        registry = ToolRegistry()
        with pytest.raises(ToolError):
            registry.unregister("missing")

    def test_get_missing_raises(self) -> None:
        registry = ToolRegistry()
        with pytest.raises(ToolError):
            registry.get("missing")

    @pytest.mark.asyncio
    async def test_execute(self) -> None:
        registry = ToolRegistry()
        registry.register(_MockTool())
        result = await registry.execute("mock", {})
        assert result.success
        assert result.output == "done"

    @pytest.mark.asyncio
    async def test_execute_error(self) -> None:
        class _FailTool(_MockTool):
            async def execute(self, params: dict) -> ToolResult:
                raise RuntimeError("boom")

        registry = ToolRegistry()
        registry.register(_FailTool("fail"))
        result = await registry.execute("fail", {})
        assert not result.success
        assert "boom" in (result.error or "")

    def test_list_tools(self) -> None:
        registry = ToolRegistry()
        registry.register(_MockTool("a"))
        registry.register(_MockTool("b"))
        assert sorted(registry.list_tools()) == ["a", "b"]

    def test_get_schemas(self) -> None:
        registry = ToolRegistry()
        registry.register(_MockTool())
        schemas = registry.get_schemas()
        assert len(schemas) == 1
        assert schemas[0]["name"] == "mock"

    def test_len_and_contains(self) -> None:
        registry = ToolRegistry()
        assert len(registry) == 0
        registry.register(_MockTool())
        assert len(registry) == 1
        assert "mock" in registry


class TestToolDecorator:
    """Tests for @tool decorator."""

    def test_sync_function(self) -> None:
        @tool(name="add", description="Add numbers")
        def add(a: int, b: int) -> int:
            return a + b

        assert add.name == "add"
        assert add.description == "Add numbers"

    def test_async_function(self) -> None:
        @tool(description="Search")
        async def search(query: str) -> str:
            return f"results for {query}"

        assert search.name == "search"

    @pytest.mark.asyncio
    async def test_execute_sync(self) -> None:
        @tool(name="double")
        def double(x: int) -> int:
            """Double a number."""
            return x * 2

        result = await double.execute({"x": 5})
        assert result.success
        assert result.output == 10

    @pytest.mark.asyncio
    async def test_execute_async(self) -> None:
        @tool(name="greet")
        async def greet(name: str) -> str:
            """Greet someone."""
            return f"hello {name}"

        result = await greet.execute({"name": "world"})
        assert result.success
        assert result.output == "hello world"

    @pytest.mark.asyncio
    async def test_execute_error(self) -> None:
        @tool(name="fail")
        def fail() -> None:
            """Always fails."""
            raise ValueError("boom")

        result = await fail.execute({})
        assert not result.success
        assert "boom" in (result.error or "")

    def test_inferred_schema(self) -> None:
        @tool(name="calc")
        def calc(x: int, y: float = 0.0) -> float:
            """Calculate."""
            return x + y

        schema = calc.parameters_schema
        assert "x" in schema["properties"]
        assert "x" in schema["required"]
        assert "y" not in schema["required"]


# -- Batch registration tests --


class TestToolRegistryBatch:
    """Tests for register_all and register_module."""

    def test_register_all(self) -> None:
        registry = ToolRegistry()
        registry.register_all([_MockTool("a"), _MockTool("b"), _MockTool("c")])
        assert len(registry) == 3
        assert registry.has("a")
        assert registry.has("b")
        assert registry.has("c")

    def test_register_all_empty(self) -> None:
        registry = ToolRegistry()
        registry.register_all([])
        assert len(registry) == 0

    def test_register_module(self) -> None:
        # Create a fake module with @tool-decorated functions.
        mod = types.ModuleType("fake_tools")

        @tool(description="Tool one")
        def alpha(x: str) -> str:
            """Tool one."""
            return x

        @tool(description="Tool two")
        def beta(y: int) -> int:
            """Tool two."""
            return y

        mod.alpha = alpha  # type: ignore[attr-defined]
        mod.beta = beta  # type: ignore[attr-defined]
        mod.not_a_tool = "just a string"  # type: ignore[attr-defined]

        registry = ToolRegistry()
        count = registry.register_module(mod)
        assert count == 2
        assert registry.has("alpha")
        assert registry.has("beta")

    def test_register_module_empty(self) -> None:
        mod = types.ModuleType("empty")
        registry = ToolRegistry()
        count = registry.register_module(mod)
        assert count == 0


# -- Schema inference tests --


class TestResolveJsonType:
    """Tests for _resolve_json_type."""

    def test_primitives(self) -> None:
        assert _resolve_json_type(str) == {"type": "string"}
        assert _resolve_json_type(int) == {"type": "integer"}
        assert _resolve_json_type(float) == {"type": "number"}
        assert _resolve_json_type(bool) == {"type": "boolean"}

    def test_list_bare(self) -> None:
        assert _resolve_json_type(list) == {"type": "array"}

    def test_list_parameterized(self) -> None:
        assert _resolve_json_type(list[str]) == {
            "type": "array",
            "items": {"type": "string"},
        }

    def test_dict_bare(self) -> None:
        assert _resolve_json_type(dict) == {"type": "object"}

    def test_dict_parameterized(self) -> None:
        assert _resolve_json_type(dict[str, int]) == {
            "type": "object",
            "additionalProperties": {"type": "integer"},
        }

    def test_optional_unwrap(self) -> None:
        assert _resolve_json_type(str | None) == {"type": "string"}

    def test_optional_list(self) -> None:
        assert _resolve_json_type(list[str] | None) == {
            "type": "array",
            "items": {"type": "string"},
        }

    def test_unknown_fallback(self) -> None:
        class Custom:
            pass

        assert _resolve_json_type(Custom) == {"type": "string"}


class TestParseArgDescriptions:
    """Tests for _parse_arg_descriptions."""

    def test_google_style_docstring(self) -> None:
        def func(query: str, limit: int) -> None:
            """Do something.

            Args:
                query: The search query string.
                limit: Maximum number of results.

            Returns:
                Nothing.
            """

        descs = _parse_arg_descriptions(func)
        assert descs["query"] == "The search query string."
        assert descs["limit"] == "Maximum number of results."

    def test_multiline_description(self) -> None:
        def func(name: str) -> None:
            """Do something.

            Args:
                name: The name of the thing
                    that we are looking for.

            Returns:
                Nothing.
            """

        descs = _parse_arg_descriptions(func)
        assert descs["name"] == "The name of the thing that we are looking for."

    def test_no_docstring(self) -> None:
        def func(x: int) -> None:
            pass

        assert _parse_arg_descriptions(func) == {}

    def test_no_args_section(self) -> None:
        def func(x: int) -> None:
            """Just a summary."""

        assert _parse_arg_descriptions(func) == {}


class TestSchemaInferenceIntegration:
    """Tests for @tool schema inference with improved types and docstrings."""

    def test_list_return_type_in_schema(self) -> None:
        @tool(description="Search")
        async def search(query: str, max_results: int = 10) -> list[str]:
            """Search the web.

            Args:
                query: The search query string.
                max_results: Maximum results to return.
            """
            return []

        schema = search.parameters_schema
        assert schema["properties"]["query"] == {
            "type": "string",
            "description": "The search query string.",
        }
        assert schema["properties"]["max_results"] == {
            "type": "integer",
            "description": "Maximum results to return.",
        }
        assert "query" in schema["required"]
        assert "max_results" not in schema["required"]

    def test_optional_param(self) -> None:
        @tool(description="Fetch")
        def fetch(url: str, timeout: float | None = None) -> str:
            """Fetch a URL.

            Args:
                url: The URL to fetch.
                timeout: Request timeout in seconds.
            """
            return ""

        schema = fetch.parameters_schema
        assert schema["properties"]["timeout"] == {
            "type": "number",
            "description": "Request timeout in seconds.",
        }

    def test_dict_param(self) -> None:
        @tool(description="Send")
        def send(headers: dict[str, str]) -> None:
            """Send something."""
            pass

        schema = send.parameters_schema
        assert schema["properties"]["headers"] == {
            "type": "object",
            "additionalProperties": {"type": "string"},
        }
