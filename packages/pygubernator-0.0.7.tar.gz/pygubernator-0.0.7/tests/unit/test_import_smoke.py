"""Smoke test: verify pygubernator imports and key names are accessible."""

from __future__ import annotations

import pytest


@pytest.mark.unit
class TestImportSmoke:
    """Verify the public API is importable."""

    def test_import_package(self) -> None:
        """Importing pygubernator should succeed."""
        import pygubernator

        assert hasattr(pygubernator, "__version__")

    def test_core_types_accessible(self) -> None:
        """Core types should be importable from the top-level package."""
        from pygubernator import (
            AgentResult,
            Message,
            StepResult,
            ToolResult,
        )

        assert AgentResult is not None
        assert Message is not None
        assert StepResult is not None
        assert ToolResult is not None

    def test_agents_accessible(self) -> None:
        """Agent classes should be importable from the top-level package."""
        from pygubernator import (
            BaseAgent,
            LLMAgent,
            PipelineAgent,
            StateMachineAgent,
        )

        assert BaseAgent is not None
        assert LLMAgent is not None
        assert PipelineAgent is not None
        assert StateMachineAgent is not None

    def test_protocols_accessible(self) -> None:
        """Protocol types should be importable from the top-level package."""
        from pygubernator import LLMProvider, Tool, Transport

        assert LLMProvider is not None
        assert Tool is not None
        assert Transport is not None

    def test_runners_accessible(self) -> None:
        """Runner functions should be importable from the top-level package."""
        from pygubernator import run_batch, run_stream

        assert callable(run_batch)
        assert callable(run_stream)

    def test_errors_accessible(self) -> None:
        """Error classes should be importable from the top-level package."""
        from pygubernator import (
            AgentError,
            ConfigError,
            GubernatorError,
            LLMError,
            ToolError,
            TransportError,
        )

        assert issubclass(AgentError, GubernatorError)
        assert issubclass(ConfigError, GubernatorError)
        assert issubclass(LLMError, GubernatorError)
        assert issubclass(ToolError, GubernatorError)
        assert issubclass(TransportError, GubernatorError)
