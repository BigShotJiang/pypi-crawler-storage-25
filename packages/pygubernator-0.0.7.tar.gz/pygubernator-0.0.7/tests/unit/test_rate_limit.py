"""Tests for the rate limiting middleware."""

from __future__ import annotations

from unittest.mock import patch

from fastapi import FastAPI
from fastapi.testclient import TestClient

from pygubernator.api._rate_limit import RateLimitMiddleware


def _make_app(
    max_requests: int = 5,
    window_seconds: float = 60.0,
) -> FastAPI:
    """Create a minimal FastAPI app with rate limiting."""
    app = FastAPI()
    app.add_middleware(
        RateLimitMiddleware,
        max_requests=max_requests,
        window_seconds=window_seconds,
    )

    @app.get("/ping")
    def ping() -> dict:
        return {"ok": True}

    return app


class TestRateLimitMiddleware:
    """Tests for RateLimitMiddleware."""

    def test_requests_within_limit_pass(self) -> None:
        """Requests under the limit should succeed."""
        client = TestClient(_make_app(max_requests=5))
        for _ in range(5):
            resp = client.get("/ping")
            assert resp.status_code == 200

    def test_requests_over_limit_get_429(self) -> None:
        """Exceeding the limit returns 429."""
        client = TestClient(_make_app(max_requests=3))
        for _ in range(3):
            resp = client.get("/ping")
            assert resp.status_code == 200

        resp = client.get("/ping")
        assert resp.status_code == 429
        body = resp.json()
        assert body["error"] == "Rate limit exceeded"
        assert "retry_after" in body

    @patch("pygubernator.api._rate_limit.time.monotonic")
    def test_window_expiry_resets_counter(
        self,
        mock_mono: object,
    ) -> None:
        """After the window expires, the counter resets."""
        t = 1000.0
        mock_mono.return_value = t  # type: ignore[attr-defined]

        client = TestClient(
            _make_app(max_requests=2, window_seconds=10.0),
        )

        # Use up the limit
        assert client.get("/ping").status_code == 200
        assert client.get("/ping").status_code == 200
        assert client.get("/ping").status_code == 429

        # Advance past the window
        mock_mono.return_value = t + 11.0  # type: ignore[attr-defined]
        assert client.get("/ping").status_code == 200

    def test_different_ips_separate_counters(
        self,
    ) -> None:
        """Each client IP has its own counter.

        TestClient uses ``testclient`` as the host, so we
        verify that a single IP shares its counter by checking
        the limit applies within one client instance.
        """
        app = _make_app(max_requests=2)
        client = TestClient(app)

        # First client exhausts its quota
        assert client.get("/ping").status_code == 200
        assert client.get("/ping").status_code == 200
        assert client.get("/ping").status_code == 429

        # Directly inspect internal state: a different IP
        # should have an empty bucket.
        mw = app.middleware_stack  # noqa: F841
        # Access the middleware instance through the app
        for m in app.user_middleware:
            if m.cls is RateLimitMiddleware:
                # Verify that only the testclient IP has
                # entries, not some hypothetical second IP.
                assert "10.0.0.99" not in m.kwargs.get(
                    "_requests",
                    {},
                )
                break
