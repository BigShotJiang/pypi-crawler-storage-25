"""Tests for RouterNode."""

from __future__ import annotations

from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._router import RouterNode, RouterNodeFactory


class TestRouterNode:
    """Tests for RouterNode."""

    async def test_first_match_wins(self) -> None:
        node = RouterNode(
            "r1",
            config={
                "routes": [
                    {"condition": "x > 10", "handle": "high"},
                    {"condition": "x > 5", "handle": "medium"},
                ],
                "default_handle": "low",
            },
        )
        ctx = NodeContext(node_id="r1", input_data={"x": 8})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output_handle == "medium"

    async def test_default_fallback(self) -> None:
        node = RouterNode(
            "r1",
            config={
                "routes": [
                    {"condition": "x > 100", "handle": "high"},
                ],
                "default_handle": "low",
            },
        )
        ctx = NodeContext(node_id="r1", input_data={"x": 1})
        result = await node.execute(ctx)
        assert result.output_handle == "low"

    async def test_no_routes_fails(self) -> None:
        node = RouterNode("r1", config={"routes": []})
        ctx = NodeContext(node_id="r1")
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "No routes" in (result.error or "")

    async def test_expression_error_fails(self) -> None:
        node = RouterNode(
            "r1",
            config={
                "routes": [
                    {"condition": "undefined_var > 0", "handle": "a"},
                ],
            },
        )
        ctx = NodeContext(node_id="r1", input_data={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "error" in (result.error or "").lower()

    async def test_passthrough_input_data(self) -> None:
        node = RouterNode(
            "r1",
            config={
                "routes": [
                    {"condition": "True", "handle": "go"},
                ],
            },
        )
        ctx = NodeContext(node_id="r1", input_data={"key": "val"})
        result = await node.execute(ctx)
        assert result.output == {"key": "val"}

    async def test_uses_variables(self) -> None:
        node = RouterNode(
            "r1",
            config={
                "routes": [
                    {"condition": "mode == 'fast'", "handle": "fast"},
                ],
                "default_handle": "slow",
            },
        )
        ctx = NodeContext(
            node_id="r1",
            input_data={},
            variables={"mode": "fast"},
        )
        result = await node.execute(ctx)
        assert result.output_handle == "fast"

    def test_factory(self) -> None:
        factory = RouterNodeFactory()
        node = factory.create("r1", {"routes": []})
        assert isinstance(node, RouterNode)
        assert node.node_type == "router"
