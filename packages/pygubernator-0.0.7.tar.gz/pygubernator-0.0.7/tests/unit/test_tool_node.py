"""Tests for the tool workflow node."""

from __future__ import annotations

import pytest

from pygubernator.workflow._types import NodeContext, NodeStatus
from pygubernator.workflow.nodes._tool import ToolNode, ToolNodeFactory


class TestToolNode:
    """Tests for ToolNode execution."""

    @pytest.mark.asyncio
    async def test_missing_module_config(self) -> None:
        node = ToolNode(node_id="t1", config={})
        ctx = NodeContext(node_id="t1", input_data={}, variables={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "module" in result.error

    @pytest.mark.asyncio
    async def test_missing_function_config(self) -> None:
        node = ToolNode(node_id="t1", config={"module": "json"})
        ctx = NodeContext(node_id="t1", input_data={}, variables={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "function" in result.error

    @pytest.mark.asyncio
    async def test_import_error(self) -> None:
        node = ToolNode(
            node_id="t1",
            config={
                "module": "nonexistent_module_xyz",
                "function": "foo",
            },
        )
        ctx = NodeContext(node_id="t1", input_data={}, variables={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "Failed to load" in result.error

    @pytest.mark.asyncio
    async def test_attribute_error(self) -> None:
        node = ToolNode(
            node_id="t1",
            config={
                "module": "json",
                "function": "nonexistent_function_xyz",
            },
        )
        ctx = NodeContext(node_id="t1", input_data={}, variables={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.FAILED
        assert "Failed to load" in result.error

    @pytest.mark.asyncio
    async def test_sync_function_success(self) -> None:
        node = ToolNode(
            node_id="t1",
            config={
                "module": "json",
                "function": "dumps",
                "params": {"obj": {"key": "value"}},
            },
        )
        ctx = NodeContext(node_id="t1", input_data={}, variables={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output["result"] == '{"key": "value"}'

    @pytest.mark.asyncio
    async def test_dict_result_passthrough(self) -> None:
        """Functions returning dicts should pass through."""
        node = ToolNode(
            node_id="t1",
            config={
                "module": "json",
                "function": "loads",
                "params": {"s": '{"a": 1}'},
            },
        )
        ctx = NodeContext(node_id="t1", input_data={}, variables={})
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        assert result.output == {"a": 1}

    @pytest.mark.asyncio
    async def test_static_params_override_input(self) -> None:
        node = ToolNode(
            node_id="t1",
            config={
                "module": "json",
                "function": "dumps",
                "params": {"obj": {"static": True}},
            },
        )
        ctx = NodeContext(
            node_id="t1",
            input_data={"obj": {"from_input": True}},
            variables={},
        )
        result = await node.execute(ctx)
        assert result.status == NodeStatus.SUCCESS
        # Static params should override input
        assert "static" in result.output["result"]


class TestToolNodeFactory:
    """Tests for ToolNodeFactory."""

    def test_create(self) -> None:
        factory = ToolNodeFactory()
        node = factory.create("t1", {"module": "json", "function": "dumps"})
        assert isinstance(node, ToolNode)
        assert node._node_id == "t1"
