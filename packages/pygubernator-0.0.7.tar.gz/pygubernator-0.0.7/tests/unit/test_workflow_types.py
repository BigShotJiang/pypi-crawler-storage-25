"""Tests for workflow type definitions."""

from __future__ import annotations

import pytest

from pygubernator.workflow._types import (
    EdgeSpec,
    NodeContext,
    NodeResult,
    NodeSpec,
    NodeStatus,
    WorkflowResult,
    WorkflowSpec,
)


class TestNodeSpec:
    """Tests for NodeSpec frozen dataclass."""

    def test_create_minimal(self) -> None:
        spec = NodeSpec(node_id="n1", node_type="template")
        assert spec.node_id == "n1"
        assert spec.node_type == "template"
        assert spec.config == {}
        assert spec.position == (0.0, 0.0)

    def test_create_with_config(self) -> None:
        spec = NodeSpec(
            node_id="n1",
            node_type="code",
            config={"code": "x = 1"},
            position=(100.0, 200.0),
        )
        assert spec.config == {"code": "x = 1"}
        assert spec.position == (100.0, 200.0)

    def test_frozen(self) -> None:
        spec = NodeSpec(node_id="n1", node_type="input")
        with pytest.raises(AttributeError):
            spec.node_id = "n2"  # type: ignore[misc]


class TestEdgeSpec:
    """Tests for EdgeSpec frozen dataclass."""

    def test_create_minimal(self) -> None:
        edge = EdgeSpec(edge_id="e1", source_id="n1", target_id="n2")
        assert edge.source_handle == "default"
        assert edge.condition is None

    def test_create_with_condition(self) -> None:
        edge = EdgeSpec(
            edge_id="e1",
            source_id="n1",
            target_id="n2",
            source_handle="true",
            condition="status == 'ok'",
        )
        assert edge.source_handle == "true"
        assert edge.condition == "status == 'ok'"


class TestNodeContext:
    """Tests for NodeContext frozen dataclass."""

    def test_create_defaults(self) -> None:
        ctx = NodeContext(node_id="n1")
        assert ctx.input_data == {}
        assert ctx.variables == {}
        assert ctx.config == {}

    def test_create_with_data(self) -> None:
        ctx = NodeContext(
            node_id="n1",
            input_data={"key": "value"},
            variables={"count": 1},
            config={"template": "hello"},
        )
        assert ctx.input_data["key"] == "value"
        assert ctx.variables["count"] == 1


class TestNodeResult:
    """Tests for NodeResult frozen dataclass."""

    def test_success_default(self) -> None:
        result = NodeResult(node_id="n1")
        assert result.status == NodeStatus.SUCCESS
        assert result.output == {}
        assert result.error is None
        assert result.output_handle == "default"

    def test_failure(self) -> None:
        result = NodeResult(
            node_id="n1",
            status=NodeStatus.FAILED,
            error="something broke",
        )
        assert result.status == NodeStatus.FAILED
        assert result.error == "something broke"

    def test_to_dict(self) -> None:
        result = NodeResult(
            node_id="n1",
            output={"data": 42},
            output_handle="true",
        )
        d = result.to_dict()
        assert d["node_id"] == "n1"
        assert d["status"] == "success"
        assert d["output"] == {"data": 42}
        assert d["output_handle"] == "true"


class TestWorkflowSpec:
    """Tests for WorkflowSpec frozen dataclass."""

    def test_create_minimal(self) -> None:
        spec = WorkflowSpec(name="test", version="1.0.0")
        assert spec.name == "test"
        assert spec.nodes == {}
        assert spec.edges == ()

    def test_create_full(self) -> None:
        nodes = {
            "n1": NodeSpec(node_id="n1", node_type="input"),
            "n2": NodeSpec(node_id="n2", node_type="output"),
        }
        edges = (EdgeSpec(edge_id="e0", source_id="n1", target_id="n2"),)
        spec = WorkflowSpec(
            name="test",
            version="1.0.0",
            description="A test workflow",
            nodes=nodes,
            edges=edges,
        )
        assert len(spec.nodes) == 2
        assert len(spec.edges) == 1


class TestWorkflowResult:
    """Tests for WorkflowResult frozen dataclass."""

    def test_success(self) -> None:
        result = WorkflowResult(
            name="test",
            success=True,
            output={"result": "done"},
        )
        assert result.success
        assert result.errors == []

    def test_to_dict(self) -> None:
        node_result = NodeResult(node_id="n1", output={"x": 1})
        result = WorkflowResult(
            name="test",
            success=True,
            node_results={"n1": node_result},
            output={"final": "data"},
        )
        d = result.to_dict()
        assert d["name"] == "test"
        assert "n1" in d["node_results"]
        assert d["node_results"]["n1"]["output"] == {"x": 1}
        assert d["cancelled"] is False


class TestNodeStatus:
    """Tests for NodeStatus enum."""

    def test_values(self) -> None:
        assert NodeStatus.PENDING.value == "pending"
        assert NodeStatus.RUNNING.value == "running"
        assert NodeStatus.SUCCESS.value == "success"
        assert NodeStatus.FAILED.value == "failed"
        assert NodeStatus.SKIPPED.value == "skipped"
