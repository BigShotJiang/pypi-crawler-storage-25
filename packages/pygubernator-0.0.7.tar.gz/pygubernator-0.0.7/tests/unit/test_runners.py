"""Tests for batch and stream runners."""

from __future__ import annotations

import asyncio

import pytest

from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent
from pygubernator.runners._batch import run_batch
from pygubernator.runners._stream import run_stream
from pygubernator.transport._memory import InMemoryTransport


class _TestAgent(BaseAgent):
    """Agent for runner tests."""

    def __init__(self) -> None:
        super().__init__("test-runner")
        self.processed: list[Message] = []

    async def process(self, message: Message) -> AgentResult:
        self.processed.append(message)
        return AgentResult(
            agent_id=self.agent_id,
            success=True,
            messages_processed=1,
        )


class TestRunBatch:
    """Tests for run_batch."""

    @pytest.mark.asyncio
    async def test_batch_processes_all(self) -> None:
        transport = InMemoryTransport()
        messages = [Message(topic="t", payload={"i": i}) for i in range(3)]
        transport.inject("t", messages)

        agent = _TestAgent()
        result = await run_batch(agent, transport, "t", max_messages=10)

        assert result.success
        assert result.messages_processed == 3
        assert len(agent.processed) == 3
        assert transport.is_closed

    @pytest.mark.asyncio
    async def test_batch_empty_topic(self) -> None:
        transport = InMemoryTransport()
        agent = _TestAgent()
        result = await run_batch(agent, transport, "empty")
        assert result.success
        assert result.messages_processed == 0

    @pytest.mark.asyncio
    async def test_batch_agent_stopped(self) -> None:
        transport = InMemoryTransport()
        transport.inject("t", [Message(topic="t")])
        agent = _TestAgent()
        await run_batch(agent, transport, "t")
        assert agent.state == "stopped"


class TestRunStream:
    """Tests for run_stream."""

    @pytest.mark.asyncio
    async def test_stream_processes_until_shutdown(self) -> None:
        transport = InMemoryTransport()
        messages = [Message(topic="t", payload={"i": i}) for i in range(3)]
        transport.inject("t", messages)

        agent = _TestAgent()
        shutdown = asyncio.Event()

        async def _stop_after_delay() -> None:
            await asyncio.sleep(0.1)
            shutdown.set()

        asyncio.create_task(_stop_after_delay())
        result = await run_stream(
            agent,
            transport,
            "t",
            shutdown_event=shutdown,
            batch_size=10,
        )

        assert result.messages_processed == 3
        assert agent.state == "stopped"

    @pytest.mark.asyncio
    async def test_stream_immediate_shutdown(self) -> None:
        transport = InMemoryTransport()
        agent = _TestAgent()
        shutdown = asyncio.Event()
        shutdown.set()

        result = await run_stream(agent, transport, "t", shutdown_event=shutdown)
        assert result.messages_processed == 0
