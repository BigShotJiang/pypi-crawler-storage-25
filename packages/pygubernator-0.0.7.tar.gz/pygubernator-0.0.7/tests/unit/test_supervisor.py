"""Tests for AgentSupervisor and AgentPipeline."""

from __future__ import annotations

import pytest

from pygubernator._supervisor import AgentPipeline, AgentSupervisor, RestartPolicy
from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent
from pygubernator.errors import AgentError

# -- Helpers --


class _EchoAgent(BaseAgent):
    """Agent that echoes the message payload in metadata."""

    async def process(self, message: Message) -> AgentResult:
        return AgentResult(
            agent_id=self.agent_id,
            success=True,
            messages_processed=1,
            metadata={"echo": message.payload},
        )


class _FailProcessAgent(BaseAgent):
    """Agent that returns failure."""

    async def process(self, message: Message) -> AgentResult:
        return AgentResult(
            agent_id=self.agent_id,
            success=False,
            errors=["process failed"],
        )


# -- AgentSupervisor tests --


class TestAgentSupervisor:
    """Tests for AgentSupervisor lifecycle management."""

    def test_add_and_status(self) -> None:
        sup = AgentSupervisor()
        a1 = _EchoAgent("a1")
        a2 = _EchoAgent("a2")
        sup.add_agent(a1)
        sup.add_agent(a2)

        status = sup.status()
        assert status == {"a1": "idle", "a2": "idle"}

    def test_add_duplicate_raises(self) -> None:
        sup = AgentSupervisor()
        a1 = _EchoAgent("a1")
        sup.add_agent(a1)
        with pytest.raises(AgentError, match="already registered"):
            sup.add_agent(_EchoAgent("a1"))

    def test_start_all(self) -> None:
        sup = AgentSupervisor()
        a1 = _EchoAgent("a1")
        a2 = _EchoAgent("a2")
        sup.add_agent(a1)
        sup.add_agent(a2)
        sup.start_all()

        assert a1.is_running
        assert a2.is_running

    def test_stop_all(self) -> None:
        sup = AgentSupervisor()
        a1 = _EchoAgent("a1")
        sup.add_agent(a1)
        sup.start_all()
        sup.stop_all()

        assert a1.is_stopped

    def test_remove_agent(self) -> None:
        sup = AgentSupervisor()
        a1 = _EchoAgent("a1")
        sup.add_agent(a1)
        sup.start_all()
        sup.remove_agent("a1")

        assert a1.is_stopped
        assert "a1" not in sup.status()

    def test_remove_idle_agent(self) -> None:
        sup = AgentSupervisor()
        a1 = _EchoAgent("a1")
        sup.add_agent(a1)
        sup.remove_agent("a1")
        assert "a1" not in sup.status()

    def test_remove_nonexistent_raises(self) -> None:
        sup = AgentSupervisor()
        with pytest.raises(KeyError):
            sup.remove_agent("missing")

    @pytest.mark.asyncio
    async def test_health_check_healthy(self) -> None:
        sup = AgentSupervisor()
        a1 = _EchoAgent("a1")
        sup.add_agent(a1)
        sup.start_all()

        health = await sup.check_health()
        assert health["a1"] is True
        sup.stop_all()

    @pytest.mark.asyncio
    async def test_health_check_stopped_not_healthy(self) -> None:
        sup = AgentSupervisor(restart_policy=RestartPolicy.NEVER)
        a1 = _EchoAgent("a1")
        sup.add_agent(a1)
        a1.stop()

        health = await sup.check_health()
        assert health["a1"] is False

    def test_agents_property(self) -> None:
        sup = AgentSupervisor()
        a1 = _EchoAgent("a1")
        sup.add_agent(a1)
        assert "a1" in sup.agents


# -- AgentPipeline tests --


class TestAgentPipeline:
    """Tests for AgentPipeline chaining."""

    @pytest.mark.asyncio
    async def test_two_agent_pipeline(self) -> None:
        a1 = _EchoAgent("a1")
        a2 = _EchoAgent("a2")
        pipeline = AgentPipeline([a1, a2])

        msg = Message(topic="input", payload={"data": "hello"})
        result = await pipeline.process(msg)

        assert result.success
        assert result.agent_id == "a2"

    @pytest.mark.asyncio
    async def test_pipeline_stops_on_failure(self) -> None:
        a1 = _EchoAgent("a1")
        a2 = _FailProcessAgent("a2")
        a3 = _EchoAgent("a3")
        pipeline = AgentPipeline([a1, a2, a3])

        msg = Message(topic="input", payload={"data": "hello"})
        result = await pipeline.process(msg)

        assert not result.success
        assert result.agent_id == "a2"

    def test_pipeline_requires_two_agents(self) -> None:
        with pytest.raises(ValueError, match="at least 2"):
            AgentPipeline([_EchoAgent("a1")])

    @pytest.mark.asyncio
    async def test_pipeline_passes_metadata_forward(self) -> None:
        class _TagAgent(BaseAgent):
            async def process(self, message: Message) -> AgentResult:
                tag = message.payload.get("tag", "none")
                return AgentResult(
                    agent_id=self.agent_id,
                    success=True,
                    messages_processed=1,
                    metadata={"tag": f"{tag}+{self.agent_id}"},
                )

        a1 = _TagAgent("step1")
        a2 = _TagAgent("step2")
        pipeline = AgentPipeline([a1, a2])

        msg = Message(topic="in", payload={"tag": "start"})
        result = await pipeline.process(msg)

        assert result.success
        assert result.metadata["tag"] == "start+step1+step2"
