"""Tests for LLM message types."""

from __future__ import annotations

from pygubernator.llm._messages import (
    ChatMessage,
    ChatRole,
    LLMResponse,
    ToolCall,
)


class TestChatRole:
    """Tests for ChatRole enum."""

    def test_values(self) -> None:
        assert ChatRole.SYSTEM.value == "system"
        assert ChatRole.USER.value == "user"
        assert ChatRole.ASSISTANT.value == "assistant"
        assert ChatRole.TOOL.value == "tool"


class TestToolCall:
    """Tests for ToolCall dataclass."""

    def test_create(self) -> None:
        tc = ToolCall(id="tc1", name="search", arguments={"q": "test"})
        assert tc.id == "tc1"
        assert tc.name == "search"
        assert tc.arguments == {"q": "test"}

    def test_to_dict(self) -> None:
        tc = ToolCall(id="tc1", name="search")
        d = tc.to_dict()
        assert d["id"] == "tc1"
        assert d["name"] == "search"
        assert d["arguments"] == {}


class TestChatMessage:
    """Tests for ChatMessage dataclass."""

    def test_user_message(self) -> None:
        msg = ChatMessage(role=ChatRole.USER, content="hello")
        assert msg.role == ChatRole.USER
        assert msg.content == "hello"
        assert msg.tool_calls == ()

    def test_assistant_with_tools(self) -> None:
        tc = ToolCall(id="1", name="search")
        msg = ChatMessage(
            role=ChatRole.ASSISTANT,
            content="Let me search",
            tool_calls=(tc,),
        )
        assert len(msg.tool_calls) == 1

    def test_to_dict_basic(self) -> None:
        msg = ChatMessage(role=ChatRole.USER, content="hi")
        d = msg.to_dict()
        assert d["role"] == "user"
        assert d["content"] == "hi"
        assert "tool_calls" not in d

    def test_to_dict_with_tool_calls(self) -> None:
        tc = ToolCall(id="1", name="search")
        msg = ChatMessage(
            role=ChatRole.ASSISTANT,
            tool_calls=(tc,),
        )
        d = msg.to_dict()
        assert "tool_calls" in d
        assert len(d["tool_calls"]) == 1

    def test_tool_response(self) -> None:
        msg = ChatMessage(
            role=ChatRole.TOOL,
            content="result",
            tool_call_id="tc1",
        )
        d = msg.to_dict()
        assert d["tool_call_id"] == "tc1"


class TestLLMResponse:
    """Tests for LLMResponse dataclass."""

    def test_text_response(self) -> None:
        r = LLMResponse(content="Hello!", model="gpt-4")
        assert r.content == "Hello!"
        assert not r.has_tool_calls
        assert r.finish_reason == "stop"

    def test_tool_call_response(self) -> None:
        tc = ToolCall(id="1", name="search")
        r = LLMResponse(tool_calls=(tc,), finish_reason="tool_calls")
        assert r.has_tool_calls
        assert len(r.tool_calls) == 1

    def test_to_dict(self) -> None:
        r = LLMResponse(content="hi", model="gpt-4")
        d = r.to_dict()
        assert d["content"] == "hi"
        assert d["model"] == "gpt-4"
        assert d["tool_calls"] == []
