"""Tests for InMemoryAgentStore."""

from __future__ import annotations

from pygubernator.agent_store.memory import InMemoryAgentStore


def test_in_memory_agent_store_create_agent() -> None:
    store = InMemoryAgentStore()
    store.connect()
    try:
        a = store.create_agent(name="demo", owner="test", status="active")
        store.commit()
        store.refresh(a)
        assert a.name == "demo"
        got = store.get_agent(a.id)
        assert got is not None
        assert got.id == a.id
    finally:
        store.disconnect()
