"""Tests for the Notification dispatch system (Feature 2)."""

from __future__ import annotations

import logging
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import FastAPI

from pygubernator._events import AgentEvent, AgentEventType
from pygubernator.db.models import NotificationRule
from pygubernator.notifications._channels import (
    LogChannel,
    SlackChannel,
    WebhookChannel,
)
from pygubernator.notifications._dispatcher import (
    NotificationDispatcher,
)

# --------------- WebhookChannel tests ---------------


class TestWebhookChannel:
    """Test WebhookChannel HTTP delivery."""

    @pytest.mark.asyncio
    async def test_send_success(self) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 200

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_resp
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "pygubernator.notifications._channels.httpx.AsyncClient",
            return_value=mock_client,
        ):
            ch = WebhookChannel(url="https://example.com/hook")
            ok = await ch.send("Test", "body", {"key": "val"})

        assert ok is True
        mock_client.post.assert_called_once()
        call_kwargs = mock_client.post.call_args
        assert call_kwargs.kwargs["json"]["subject"] == "Test"

    @pytest.mark.asyncio
    async def test_send_failure_status(self) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 500

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_resp
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "pygubernator.notifications._channels.httpx.AsyncClient",
            return_value=mock_client,
        ):
            ch = WebhookChannel(url="https://example.com/hook")
            ok = await ch.send("Test", "body", {})

        assert ok is False

    @pytest.mark.asyncio
    async def test_send_http_error(self) -> None:
        import httpx

        mock_client = AsyncMock()
        mock_client.post.side_effect = httpx.ConnectError("fail")
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "pygubernator.notifications._channels.httpx.AsyncClient",
            return_value=mock_client,
        ):
            ch = WebhookChannel(url="https://bad.example")
            ok = await ch.send("Test", "body", {})

        assert ok is False


# --------------- SlackChannel tests ---------------


class TestSlackChannel:
    """Test SlackChannel webhook delivery."""

    @pytest.mark.asyncio
    async def test_send_success(self) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 200

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_resp
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "pygubernator.notifications._channels.httpx.AsyncClient",
            return_value=mock_client,
        ):
            ch = SlackChannel(webhook_url="https://hooks.slack.com/x")
            ok = await ch.send("Alert", "Something happened", {})

        assert ok is True
        call_kwargs = mock_client.post.call_args
        payload = call_kwargs.kwargs["json"]
        assert "*Alert*" in payload["text"]
        assert "Something happened" in payload["text"]

    @pytest.mark.asyncio
    async def test_send_non_200(self) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 403

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_resp
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch(
            "pygubernator.notifications._channels.httpx.AsyncClient",
            return_value=mock_client,
        ):
            ch = SlackChannel(webhook_url="https://hooks.slack.com/x")
            ok = await ch.send("Alert", "body", {})

        assert ok is False


# --------------- LogChannel tests ---------------


class TestLogChannel:
    """Test LogChannel logging."""

    @pytest.mark.asyncio
    async def test_send_logs_message(self, caplog: pytest.LogCaptureFixture) -> None:
        ch = LogChannel()
        with caplog.at_level(logging.INFO):
            ok = await ch.send("MySubject", "MyBody", {"x": 1})
        assert ok is True
        assert "MySubject" in caplog.text
        assert "MyBody" in caplog.text


# --------------- NotificationDispatcher tests ---------------


class TestNotificationDispatcher:
    """Test dispatcher routing and EventHandler integration."""

    @pytest.mark.asyncio
    async def test_notify_sends_to_all_channels(
        self,
    ) -> None:
        ch1 = AsyncMock()
        ch1.send = AsyncMock(return_value=True)
        ch2 = AsyncMock()
        ch2.send = AsyncMock(return_value=True)

        d = NotificationDispatcher()
        d.add_channel(ch1)
        d.add_channel(ch2)
        assert d.channel_count == 2

        await d.notify("sub", "body", {"k": "v"})

        ch1.send.assert_called_once_with("sub", "body", {"k": "v"})
        ch2.send.assert_called_once_with("sub", "body", {"k": "v"})

    @pytest.mark.asyncio
    async def test_notify_no_channels(self) -> None:
        d = NotificationDispatcher()
        await d.notify("sub", "body")  # no error

    @pytest.mark.asyncio
    async def test_notify_channel_error_isolated(
        self,
    ) -> None:
        ch_bad = AsyncMock()
        ch_bad.send = AsyncMock(side_effect=RuntimeError("boom"))
        ch_good = AsyncMock()
        ch_good.send = AsyncMock(return_value=True)

        d = NotificationDispatcher()
        d.add_channel(ch_bad)
        d.add_channel(ch_good)

        await d.notify("sub", "body")
        ch_good.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_handle_workflow_completed(self) -> None:
        ch = AsyncMock()
        ch.send = AsyncMock(return_value=True)

        d = NotificationDispatcher()
        d.add_channel(ch)

        event = AgentEvent(
            event_type=AgentEventType.WORKFLOW_COMPLETED,
            agent_id="agent-1",
            data={"workflow_name": "etl_pipeline"},
        )
        await d.handle(event)

        ch.send.assert_called_once()
        call_args = ch.send.call_args
        assert "etl_pipeline" in call_args.args[0]
        assert "completed" in call_args.args[0].lower()

    @pytest.mark.asyncio
    async def test_handle_workflow_failed(self) -> None:
        ch = AsyncMock()
        ch.send = AsyncMock(return_value=True)

        d = NotificationDispatcher()
        d.add_channel(ch)

        event = AgentEvent(
            event_type=AgentEventType.WORKFLOW_COMPLETED,
            agent_id="agent-1",
            data={
                "workflow_name": "etl",
                "error": "timeout",
            },
        )
        await d.handle(event)

        call_args = ch.send.call_args
        assert "failed" in call_args.args[0].lower()
        assert "timeout" in call_args.args[1]

    @pytest.mark.asyncio
    async def test_handle_ignores_other_events(
        self,
    ) -> None:
        ch = AsyncMock()
        ch.send = AsyncMock(return_value=True)

        d = NotificationDispatcher()
        d.add_channel(ch)

        event = AgentEvent(
            event_type=AgentEventType.AGENT_STARTED,
            agent_id="agent-1",
        )
        await d.handle(event)

        ch.send.assert_not_called()


# --------------- NotificationRule model tests --------


class TestNotificationRuleModel:
    """Test NotificationRule model columns and values."""

    def test_tablename(self) -> None:
        assert NotificationRule.__tablename__ == "notification_rules"

    def test_custom_fields(self) -> None:
        row = NotificationRule(
            name="my-rule",
            event_type="workflow.completed",
            channel_type="slack",
            channel_config={"webhook_url": "https://x"},
            enabled=False,
        )
        assert row.name == "my-rule"
        assert row.event_type == "workflow.completed"
        assert row.channel_type == "slack"
        assert row.enabled is False

    def test_column_defaults_declared(self) -> None:
        """Verify column defaults are declared on the table."""
        table = NotificationRule.__table__
        assert table.c.enabled.default is not None
        assert table.c.created_by.default is not None


# --------------- Notification route tests ---------------


def _make_app() -> FastAPI:
    """Build minimal app with notification routes."""
    from pygubernator.api.routes_notifications import router

    app = FastAPI()
    app.include_router(router)
    return app


class TestNotificationRoutes:
    """Test that notification route paths are registered."""

    def test_list_path(self) -> None:
        app = _make_app()
        paths = [r.path for r in app.routes]
        assert "/api/v1/admin/notifications" in paths

    def test_create_path(self) -> None:
        app = _make_app()
        paths = [r.path for r in app.routes]
        assert "/api/v1/admin/notifications" in paths

    def test_update_path(self) -> None:
        app = _make_app()
        paths = [r.path for r in app.routes]
        expected = "/api/v1/admin/notifications/{rule_id}"
        assert expected in paths

    def test_delete_path(self) -> None:
        app = _make_app()
        paths = [r.path for r in app.routes]
        expected = "/api/v1/admin/notifications/{rule_id}"
        assert expected in paths

    def test_test_path(self) -> None:
        app = _make_app()
        paths = [r.path for r in app.routes]
        expected = "/api/v1/admin/notifications/{rule_id}/test"
        assert expected in paths
