"""Tests for LLM agent robustness features."""

from __future__ import annotations

import asyncio
import json
from typing import Any
from unittest.mock import AsyncMock

import pytest

from pygubernator._types import Message, ToolResult
from pygubernator.agents._llm import LLMAgent
from pygubernator.agents._validation import validate_tool_args
from pygubernator.llm._messages import LLMResponse, ToolCall
from pygubernator.tools._registry import ToolRegistry

# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


class _MockProvider:
    """Mock LLM provider that returns canned responses."""

    def __init__(self, responses: list[LLMResponse]) -> None:
        self._responses = list(responses)
        self._idx = 0
        self.chat = AsyncMock(side_effect=self._chat)

    async def _chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        """Return the next canned response."""
        resp = self._responses[min(self._idx, len(self._responses) - 1)]
        self._idx += 1
        return resp


def _make_provider(
    responses: list[LLMResponse],
) -> _MockProvider:
    """Create a mock LLM provider returning canned responses."""
    return _MockProvider(responses)


class _MockTool:
    """Concrete mock tool for robustness tests."""

    def __init__(
        self,
        name: str = "my_tool",
        schema: dict[str, Any] | None = None,
        result: ToolResult | None = None,
        delay: float = 0.0,
    ) -> None:
        self._name = name
        self._schema = schema or {
            "type": "object",
            "properties": {
                "arg": {"type": "string"},
            },
            "required": ["arg"],
        }
        self._result = result
        self._delay = delay
        self.execute = AsyncMock(side_effect=self._do_execute)

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return f"Mock {self._name}"

    @property
    def parameters_schema(self) -> dict[str, Any]:
        return self._schema

    async def _do_execute(self, params: dict[str, Any]) -> ToolResult:
        """Run the mock execution."""
        if self._delay > 0:
            await asyncio.sleep(self._delay)
        return self._result or ToolResult(
            tool_name=self._name,
            success=True,
            output="done",
        )


def _make_tool(
    name: str = "my_tool",
    schema: dict[str, Any] | None = None,
    result: ToolResult | None = None,
    delay: float = 0.0,
) -> _MockTool:
    """Create a mock tool with configurable behavior."""
    return _MockTool(
        name=name,
        schema=schema,
        result=result,
        delay=delay,
    )


def _msg(text: str = "hello") -> Message:
    return Message(topic="test", payload={"content": text})


def _tc(
    name: str = "my_tool",
    args: dict[str, Any] | None = None,
    tc_id: str = "tc1",
) -> ToolCall:
    return ToolCall(
        id=tc_id,
        name=name,
        arguments=args if args is not None else {"arg": "val"},
    )


def _tool_response(
    *tool_calls: ToolCall,
    content: str = "",
) -> LLMResponse:
    return LLMResponse(
        content=content,
        tool_calls=tuple(tool_calls),
        finish_reason="tool_calls",
    )


def _final_response(content: str = "done") -> LLMResponse:
    return LLMResponse(
        content=content,
        tool_calls=(),
        finish_reason="stop",
    )


# ------------------------------------------------------------------
# Feature 1: Parallel Tool Execution
# ------------------------------------------------------------------


class TestParallelExecution:
    """Tool calls execute concurrently via asyncio.gather."""

    @pytest.mark.asyncio
    async def test_multiple_tools_run_in_parallel(
        self,
    ) -> None:
        """Two tool calls should run concurrently."""
        tool_a = _make_tool(name="tool_a")
        tool_b = _make_tool(name="tool_b")
        registry = ToolRegistry()
        registry.register(tool_a)
        registry.register(tool_b)

        tc_a = _tc("tool_a", {"arg": "a"}, "tc_a")
        tc_b = _tc("tool_b", {"arg": "b"}, "tc_b")
        provider = _make_provider(
            [
                _tool_response(tc_a, tc_b),
                _final_response(),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            tool_registry=registry,
        )
        result = await agent.process(_msg())

        assert result.success
        tool_a.execute.assert_called_once()
        tool_b.execute.assert_called_once()
        tool_results = result.metadata["tool_results"]
        assert len(tool_results) == 2

    @pytest.mark.asyncio
    async def test_parallel_exception_captured(
        self,
    ) -> None:
        """An exception in one tool does not crash others."""
        tool_ok = _make_tool(name="tool_ok")
        tool_bad = _make_tool(name="tool_bad")
        # Override execute to raise
        tool_bad.execute = AsyncMock(  # type: ignore[assignment]
            side_effect=RuntimeError("boom")
        )
        registry = ToolRegistry()
        registry.register(tool_ok)
        registry.register(tool_bad)

        tc_ok = _tc("tool_ok", {"arg": "a"}, "tc_ok")
        tc_bad = _tc("tool_bad", {"arg": "b"}, "tc_bad")
        provider = _make_provider(
            [
                _tool_response(tc_ok, tc_bad),
                _final_response(),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            tool_registry=registry,
        )
        result = await agent.process(_msg())
        assert result.success
        tool_results = result.metadata["tool_results"]
        # tool_bad's result should be a failure
        bad_result = [r for r in tool_results if r["tool_name"] == "tool_bad"]
        assert len(bad_result) == 1
        assert not bad_result[0]["success"]


# ------------------------------------------------------------------
# Feature 2: Tool Argument Validation
# ------------------------------------------------------------------


class TestArgumentValidation:
    """validate_tool_args catches invalid arguments."""

    def test_missing_required(self) -> None:
        schema = {
            "type": "object",
            "properties": {"x": {"type": "string"}},
            "required": ["x"],
        }
        errors = validate_tool_args({}, schema, "t")
        assert any("Missing required" in e for e in errors)

    def test_wrong_type(self) -> None:
        schema = {
            "type": "object",
            "properties": {"x": {"type": "string"}},
        }
        errors = validate_tool_args({"x": 42}, schema, "t")
        assert any("expected string" in e for e in errors)

    def test_valid_args(self) -> None:
        schema = {
            "type": "object",
            "properties": {"x": {"type": "string"}},
            "required": ["x"],
        }
        errors = validate_tool_args({"x": "ok"}, schema, "t")
        assert errors == []

    @pytest.mark.asyncio
    async def test_validation_error_fed_back(self) -> None:
        """Invalid args produce error result, not crash."""
        tool = _make_tool(name="my_tool")
        registry = ToolRegistry()
        registry.register(tool)

        # Missing required "arg"
        tc = _tc("my_tool", {}, "tc1")
        provider = _make_provider(
            [
                _tool_response(tc),
                _final_response(),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            tool_registry=registry,
        )
        result = await agent.process(_msg())
        assert result.success
        tr = result.metadata["tool_results"]
        assert len(tr) == 1
        assert not tr[0]["success"]
        assert "Missing required" in tr[0]["error"]


# ------------------------------------------------------------------
# Feature 3: JSON Parsing Error Recovery
# ------------------------------------------------------------------


class TestJsonParsingRecovery:
    """Malformed tool arguments produce errors, not crashes."""

    @pytest.mark.asyncio
    async def test_bad_args_returns_error(self) -> None:
        """Non-dict arguments that fail JSON parse."""
        tool = _make_tool(name="my_tool")
        registry = ToolRegistry()
        registry.register(tool)

        # ToolCall with arguments that are a string (not dict)
        bad_tc = ToolCall(
            id="tc1",
            name="my_tool",
            arguments="not-valid-json{{{",  # type: ignore[arg-type]
        )
        provider = _make_provider(
            [
                _tool_response(bad_tc),
                _final_response(),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            tool_registry=registry,
        )
        result = await agent.process(_msg())
        assert result.success
        tr = result.metadata["tool_results"]
        assert len(tr) == 1
        assert not tr[0]["success"]
        assert "Failed to parse" in tr[0]["error"]


# ------------------------------------------------------------------
# Feature 4: Per-Tool Timeouts
# ------------------------------------------------------------------


class TestToolTimeout:
    """Slow tools time out gracefully."""

    @pytest.mark.asyncio
    async def test_timeout_produces_error(self) -> None:
        """Tool exceeding timeout returns error result."""
        tool = _make_tool(name="slow", delay=5.0)
        registry = ToolRegistry()
        registry.register(tool)

        tc = _tc("slow", {"arg": "v"}, "tc1")
        provider = _make_provider(
            [
                _tool_response(tc),
                _final_response(),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            tool_registry=registry,
            tool_timeout=0.05,
        )
        result = await agent.process(_msg())
        assert result.success
        tr = result.metadata["tool_results"]
        assert len(tr) == 1
        assert not tr[0]["success"]
        assert "timed out" in tr[0]["error"]


# ------------------------------------------------------------------
# Feature 5: Better Error Context
# ------------------------------------------------------------------


class TestErrorContext:
    """Failed tool results include schema hint."""

    @pytest.mark.asyncio
    async def test_schema_in_error(self) -> None:
        """Error message includes parameter schema."""
        tool = _make_tool(name="my_tool")
        registry = ToolRegistry()
        registry.register(tool)

        # Missing required arg -> validation error
        tc = _tc("my_tool", {}, "tc1")
        provider = _make_provider(
            [
                _tool_response(tc),
                _final_response(),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            tool_registry=registry,
        )
        result = await agent.process(_msg())
        tr = result.metadata["tool_results"]
        assert len(tr) == 1
        assert "Expected parameters schema" in tr[0]["error"]


# ------------------------------------------------------------------
# Feature 6: Explicit Max-Iteration Messaging
# ------------------------------------------------------------------


class TestMaxIterationMessage:
    """Max iterations sets stopped_reason in metadata."""

    @pytest.mark.asyncio
    async def test_stopped_reason_set(self) -> None:
        """Hitting max_iterations yields metadata flag."""
        tool = _make_tool(name="my_tool")
        registry = ToolRegistry()
        registry.register(tool)

        # Every response has tool calls -- never finishes
        tc = _tc("my_tool", {"arg": "v"}, "tc1")
        tool_resp = _tool_response(tc)
        provider = _make_provider([tool_resp] * 5)

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            tool_registry=registry,
            max_iterations=3,
        )
        result = await agent.process(_msg())
        assert result.success
        assert result.metadata["stopped_reason"] == "max_iterations"
        assert result.metadata["iterations"] == 3


# ------------------------------------------------------------------
# Feature 7: Tool Output Truncation
# ------------------------------------------------------------------


class TestOutputTruncation:
    """Large tool output is truncated."""

    @pytest.mark.asyncio
    async def test_output_truncated(self) -> None:
        """Output longer than max_tool_output_chars is cut."""
        big_output = "x" * 500
        tool = _make_tool(
            name="my_tool",
            result=ToolResult(
                tool_name="my_tool",
                success=True,
                output=big_output,
            ),
        )
        registry = ToolRegistry()
        registry.register(tool)

        tc = _tc("my_tool", {"arg": "v"}, "tc1")
        provider = _make_provider(
            [
                _tool_response(tc),
                _final_response(),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            tool_registry=registry,
            max_tool_output_chars=100,
        )
        result = await agent.process(_msg())
        assert result.success
        # Check the message appended had truncated content
        # (provider.chat was called twice; second call has
        # the tool message)
        second_call_messages = provider.chat.call_args_list[1][0][0]
        tool_msg = [m for m in second_call_messages if m["role"] == "tool"][0]
        assert "truncated" in tool_msg["content"]
        assert len(tool_msg["content"]) < 500

    @pytest.mark.asyncio
    async def test_small_output_not_truncated(self) -> None:
        """Output below limit is not truncated."""
        tool = _make_tool(
            name="my_tool",
            result=ToolResult(
                tool_name="my_tool",
                success=True,
                output="short",
            ),
        )
        registry = ToolRegistry()
        registry.register(tool)

        tc = _tc("my_tool", {"arg": "v"}, "tc1")
        provider = _make_provider(
            [
                _tool_response(tc),
                _final_response(),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
            tool_registry=registry,
            max_tool_output_chars=10000,
        )
        result = await agent.process(_msg())
        assert result.success
        second_call_messages = provider.chat.call_args_list[1][0][0]
        tool_msg = [m for m in second_call_messages if m["role"] == "tool"][0]
        assert "truncated" not in tool_msg["content"]


# ------------------------------------------------------------------
# Feature 8: Structured Output Validation
# ------------------------------------------------------------------


class TestOutputSchemaValidation:
    """Final LLM output validated against output_schema."""

    @pytest.mark.asyncio
    async def test_valid_json_output(self) -> None:
        """Valid JSON matching schema has no errors."""
        provider = _make_provider(
            [
                _final_response(content=json.dumps({"name": "Alice"})),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
        )
        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        }
        result = await agent.process(_msg(), output_schema=schema)
        assert result.success
        assert result.metadata["output_validation_errors"] == []

    @pytest.mark.asyncio
    async def test_invalid_json_output(self) -> None:
        """Non-JSON output is flagged."""
        provider = _make_provider(
            [
                _final_response(content="not json"),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
        )
        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
        }
        result = await agent.process(_msg(), output_schema=schema)
        assert result.success
        errors = result.metadata["output_validation_errors"]
        assert "not valid JSON" in errors[0]

    @pytest.mark.asyncio
    async def test_missing_required_in_output(self) -> None:
        """JSON output missing required field is flagged."""
        provider = _make_provider(
            [
                _final_response(content=json.dumps({"age": 30})),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
        )
        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        }
        result = await agent.process(_msg(), output_schema=schema)
        errors = result.metadata["output_validation_errors"]
        assert any("Missing required" in e for e in errors)

    @pytest.mark.asyncio
    async def test_no_schema_no_validation(self) -> None:
        """Without output_schema, no validation metadata."""
        provider = _make_provider(
            [
                _final_response(content="plain text"),
            ]
        )

        agent = LLMAgent(
            agent_id="test",
            llm_provider=provider,
        )
        result = await agent.process(_msg())
        assert "output_validation_errors" not in result.metadata
