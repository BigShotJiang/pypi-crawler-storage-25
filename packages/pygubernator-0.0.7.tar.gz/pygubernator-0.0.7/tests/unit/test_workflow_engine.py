"""Tests for WorkflowEngine."""

from __future__ import annotations

import asyncio

import pytest

from pygubernator._events import AgentEvent, AgentEventType, EventBus
from pygubernator.errors import ExecutionError
from pygubernator.workflow._engine import ExecutionMode, WorkflowEngine
from pygubernator.workflow._registry import NodeTypeRegistry
from pygubernator.workflow._types import (
    EdgeSpec,
    NodeContext,
    NodeResult,
    NodeSpec,
    NodeStatus,
    WorkflowSpec,
)
from pygubernator.workflow.nodes._condition import ConditionNodeFactory
from pygubernator.workflow.nodes._input import InputNodeFactory
from pygubernator.workflow.nodes._output import OutputNodeFactory
from pygubernator.workflow.nodes._template import TemplateNodeFactory


def _registry() -> NodeTypeRegistry:
    """Build a registry with built-in factories."""
    reg = NodeTypeRegistry()
    reg.register("input", InputNodeFactory())
    reg.register("output", OutputNodeFactory())
    reg.register("template", TemplateNodeFactory())
    reg.register("condition", ConditionNodeFactory())
    return reg


def _linear_spec() -> WorkflowSpec:
    """input → template → output."""
    return WorkflowSpec(
        name="linear",
        version="1.0.0",
        nodes={
            "start": NodeSpec(node_id="start", node_type="input"),
            "greet": NodeSpec(
                node_id="greet",
                node_type="template",
                config={
                    "template": "Hello, {{ name }}!",
                    "output_key": "greeting",
                },
            ),
            "end": NodeSpec(node_id="end", node_type="output"),
        },
        edges=(
            EdgeSpec(edge_id="e1", source_id="start", target_id="greet"),
            EdgeSpec(edge_id="e2", source_id="greet", target_id="end"),
        ),
    )


def _conditional_spec() -> WorkflowSpec:
    """input → condition → (true_path | false_path) → output."""
    return WorkflowSpec(
        name="conditional",
        version="1.0.0",
        nodes={
            "start": NodeSpec(node_id="start", node_type="input"),
            "check": NodeSpec(
                node_id="check",
                node_type="condition",
                config={"condition": "vip == True"},
            ),
            "vip_msg": NodeSpec(
                node_id="vip_msg",
                node_type="template",
                config={
                    "template": "VIP: {{ name }}",
                    "output_key": "message",
                },
            ),
            "reg_msg": NodeSpec(
                node_id="reg_msg",
                node_type="template",
                config={
                    "template": "Regular: {{ name }}",
                    "output_key": "message",
                },
            ),
            "end": NodeSpec(node_id="end", node_type="output"),
        },
        edges=(
            EdgeSpec(edge_id="e1", source_id="start", target_id="check"),
            EdgeSpec(
                edge_id="e2",
                source_id="check",
                target_id="vip_msg",
                source_handle="true",
            ),
            EdgeSpec(
                edge_id="e3",
                source_id="check",
                target_id="reg_msg",
                source_handle="false",
            ),
            EdgeSpec(edge_id="e4", source_id="vip_msg", target_id="end"),
            EdgeSpec(edge_id="e5", source_id="reg_msg", target_id="end"),
        ),
    )


class TestWorkflowEngine:
    """Tests for WorkflowEngine."""

    async def test_linear_workflow(self) -> None:
        engine = WorkflowEngine(
            spec=_linear_spec(),
            registry=_registry(),
        )
        result = await engine.run({"name": "Alice"})
        assert result.success is True
        assert result.output["greeting"] == "Hello, Alice!"
        assert result.node_results["start"].status == NodeStatus.SUCCESS
        assert result.node_results["greet"].status == NodeStatus.SUCCESS
        assert result.node_results["end"].status == NodeStatus.SUCCESS

    async def test_should_cancel_stops_before_next_level(self) -> None:
        """Cooperative cancel returns before remaining topological levels run."""
        spec = WorkflowSpec(
            name="two_level",
            version="1.0.0",
            nodes={
                "a": NodeSpec(node_id="a", node_type="input"),
                "b": NodeSpec(node_id="b", node_type="output"),
            },
            edges=(EdgeSpec(edge_id="e", source_id="a", target_id="b"),),
        )
        calls: list[int] = [0]

        def should_cancel() -> bool:
            calls[0] += 1
            return calls[0] >= 2

        engine = WorkflowEngine(
            spec=spec,
            registry=_registry(),
            should_cancel=should_cancel,
        )
        result = await engine.run({})
        assert result.cancelled is True
        assert result.success is False
        assert "Cancelled" in result.errors[0]
        assert "a" in result.node_results
        assert "b" not in result.node_results

    async def test_conditional_routing_true_branch(self) -> None:
        engine = WorkflowEngine(
            spec=_conditional_spec(),
            registry=_registry(),
        )
        result = await engine.run({"name": "Alice", "vip": True})
        assert result.success is True
        assert result.output["message"] == "VIP: Alice"
        assert result.node_results["vip_msg"].status == NodeStatus.SUCCESS
        assert result.node_results["reg_msg"].status == NodeStatus.SKIPPED

    async def test_conditional_routing_false_branch(self) -> None:
        engine = WorkflowEngine(
            spec=_conditional_spec(),
            registry=_registry(),
        )
        result = await engine.run({"name": "Bob", "vip": False})
        assert result.success is True
        assert result.output["message"] == "Regular: Bob"
        assert result.node_results["vip_msg"].status == NodeStatus.SKIPPED
        assert result.node_results["reg_msg"].status == NodeStatus.SUCCESS

    async def test_fan_out(self) -> None:
        """One node feeds two downstream nodes."""
        spec = WorkflowSpec(
            name="fan_out",
            version="1.0.0",
            nodes={
                "start": NodeSpec(node_id="start", node_type="input"),
                "a": NodeSpec(
                    node_id="a",
                    node_type="template",
                    config={"template": "A: {{ x }}", "output_key": "a_out"},
                ),
                "b": NodeSpec(
                    node_id="b",
                    node_type="template",
                    config={"template": "B: {{ x }}", "output_key": "b_out"},
                ),
            },
            edges=(
                EdgeSpec(edge_id="e1", source_id="start", target_id="a"),
                EdgeSpec(edge_id="e2", source_id="start", target_id="b"),
            ),
        )
        engine = WorkflowEngine(spec=spec, registry=_registry())
        result = await engine.run({"x": "val"})
        assert result.success is True
        assert result.node_results["a"].output["a_out"] == "A: val"
        assert result.node_results["b"].output["b_out"] == "B: val"

    async def test_fan_in_merge(self) -> None:
        """Two nodes converge into one; verify merged (namespaced) input."""
        spec = WorkflowSpec(
            name="fan_in",
            version="1.0.0",
            nodes={
                "start": NodeSpec(node_id="start", node_type="input"),
                "a": NodeSpec(
                    node_id="a",
                    node_type="template",
                    config={
                        "template": "Hello",
                        "output_key": "a_out",
                    },
                ),
                "b": NodeSpec(
                    node_id="b",
                    node_type="template",
                    config={
                        "template": "World",
                        "output_key": "b_out",
                    },
                ),
                "end": NodeSpec(node_id="end", node_type="output"),
            },
            edges=(
                EdgeSpec(edge_id="e1", source_id="start", target_id="a"),
                EdgeSpec(edge_id="e2", source_id="start", target_id="b"),
                EdgeSpec(edge_id="e3", source_id="a", target_id="end"),
                EdgeSpec(edge_id="e4", source_id="b", target_id="end"),
            ),
        )
        engine = WorkflowEngine(spec=spec, registry=_registry())
        result = await engine.run({})
        assert result.success is True
        # Fan-in: output node receives namespaced data
        end_result = result.node_results["end"]
        assert end_result.status == NodeStatus.SUCCESS

    async def test_diamond_dag(self) -> None:
        """A→B, A→C, B→D, C→D diamond pattern."""
        spec = WorkflowSpec(
            name="diamond",
            version="1.0.0",
            nodes={
                "a": NodeSpec(node_id="a", node_type="input"),
                "b": NodeSpec(
                    node_id="b",
                    node_type="template",
                    config={"template": "B", "output_key": "b"},
                ),
                "c": NodeSpec(
                    node_id="c",
                    node_type="template",
                    config={"template": "C", "output_key": "c"},
                ),
                "d": NodeSpec(node_id="d", node_type="output"),
            },
            edges=(
                EdgeSpec(edge_id="e1", source_id="a", target_id="b"),
                EdgeSpec(edge_id="e2", source_id="a", target_id="c"),
                EdgeSpec(edge_id="e3", source_id="b", target_id="d"),
                EdgeSpec(edge_id="e4", source_id="c", target_id="d"),
            ),
        )
        engine = WorkflowEngine(spec=spec, registry=_registry())
        result = await engine.run({"x": 1})
        assert result.success is True
        assert result.node_results["d"].status == NodeStatus.SUCCESS

    async def test_node_failure_propagates(self) -> None:
        spec = WorkflowSpec(
            name="fail",
            version="1.0.0",
            nodes={
                "start": NodeSpec(node_id="start", node_type="input"),
                "bad": NodeSpec(
                    node_id="bad",
                    node_type="template",
                    config={},  # Missing template → failure
                ),
                "end": NodeSpec(node_id="end", node_type="output"),
            },
            edges=(
                EdgeSpec(edge_id="e1", source_id="start", target_id="bad"),
                EdgeSpec(edge_id="e2", source_id="bad", target_id="end"),
            ),
        )
        engine = WorkflowEngine(spec=spec, registry=_registry())
        result = await engine.run({})
        assert result.success is False
        assert len(result.errors) > 0
        assert "bad" in result.errors[0]

    async def test_dry_run_mode(self) -> None:
        engine = WorkflowEngine(
            spec=_linear_spec(),
            registry=_registry(),
            mode=ExecutionMode.DRY_RUN,
        )
        result = await engine.run({"name": "test"})
        assert result.success is True
        assert result.node_results == {}
        assert result.output == {}

    async def test_cycle_detection(self) -> None:
        spec = WorkflowSpec(
            name="cyclic",
            version="1.0.0",
            nodes={
                "a": NodeSpec(node_id="a", node_type="input"),
                "b": NodeSpec(node_id="b", node_type="template", config={}),
            },
            edges=(
                EdgeSpec(edge_id="e1", source_id="a", target_id="b"),
                EdgeSpec(edge_id="e2", source_id="b", target_id="a"),
            ),
        )
        engine = WorkflowEngine(spec=spec, registry=_registry())
        with pytest.raises(ExecutionError, match="cycles"):
            await engine.run({})

    async def test_concurrent_execution(self) -> None:
        """Verify same-level nodes run concurrently."""
        execution_order: list[str] = []

        class SlowNode:
            """A node that takes time to simulate concurrency."""

            node_type = "slow"

            def __init__(self, node_id: str, delay: float) -> None:
                self._node_id = node_id
                self._delay = delay

            async def execute(self, context: NodeContext) -> NodeResult:
                execution_order.append(f"{self._node_id}_start")
                await asyncio.sleep(self._delay)
                execution_order.append(f"{self._node_id}_end")
                return NodeResult(
                    node_id=self._node_id,
                    status=NodeStatus.SUCCESS,
                    output={"done": True},
                )

        class SlowNodeFactory:
            def __init__(self, delay: float) -> None:
                self._delay = delay

            def create(
                self,
                node_id: str,
                config: dict,
            ) -> SlowNode:
                return SlowNode(node_id, self._delay)

        reg = _registry()
        reg.register("slow", SlowNodeFactory(delay=0.05))

        spec = WorkflowSpec(
            name="concurrent",
            version="1.0.0",
            nodes={
                "start": NodeSpec(node_id="start", node_type="input"),
                "a": NodeSpec(node_id="a", node_type="slow"),
                "b": NodeSpec(node_id="b", node_type="slow"),
            },
            edges=(
                EdgeSpec(edge_id="e1", source_id="start", target_id="a"),
                EdgeSpec(edge_id="e2", source_id="start", target_id="b"),
            ),
        )
        engine = WorkflowEngine(spec=spec, registry=reg)
        result = await engine.run({})
        assert result.success is True

        # Both should start before either ends (concurrent)
        starts = [e for e in execution_order if e.endswith("_start")]
        ends = [e for e in execution_order if e.endswith("_end")]
        assert len(starts) == 2
        assert len(ends) == 2
        # Both starts should appear before first end
        first_end_idx = execution_order.index(ends[0])
        assert all(execution_order.index(s) < first_end_idx for s in starts)

    async def test_event_emission(self) -> None:
        events: list[AgentEvent] = []

        class Collector:
            async def handle(self, event: AgentEvent) -> None:
                events.append(event)

        bus = EventBus()
        bus.add_handler(Collector())

        engine = WorkflowEngine(
            spec=_linear_spec(),
            registry=_registry(),
            event_bus=bus,
        )
        await engine.run({"name": "test"})

        event_types = [e.event_type for e in events]
        assert AgentEventType.WORKFLOW_STARTED in event_types
        assert AgentEventType.WORKFLOW_COMPLETED in event_types
        assert AgentEventType.WORKFLOW_NODE_STARTED in event_types
        assert AgentEventType.WORKFLOW_NODE_COMPLETED in event_types

    async def test_empty_workflow(self) -> None:
        spec = WorkflowSpec(
            name="empty",
            version="1.0.0",
            nodes={},
            edges=(),
        )
        engine = WorkflowEngine(spec=spec, registry=_registry())
        result = await engine.run({})
        assert result.success is True
        assert result.output == {}
        assert result.node_results == {}

    async def test_skipped_nodes_in_result(self) -> None:
        result = await WorkflowEngine(
            spec=_conditional_spec(),
            registry=_registry(),
        ).run({"name": "X", "vip": True})
        skipped = {
            nid
            for nid, r in result.node_results.items()
            if r.status == NodeStatus.SKIPPED
        }
        assert "reg_msg" in skipped

    async def test_edge_condition_evaluation(self) -> None:
        """Edge with condition expression filters routing."""
        spec = WorkflowSpec(
            name="edge_cond",
            version="1.0.0",
            nodes={
                "start": NodeSpec(node_id="start", node_type="input"),
                "a": NodeSpec(
                    node_id="a",
                    node_type="template",
                    config={"template": "A", "output_key": "msg"},
                ),
                "b": NodeSpec(
                    node_id="b",
                    node_type="template",
                    config={"template": "B", "output_key": "msg"},
                ),
            },
            edges=(
                EdgeSpec(
                    edge_id="e1",
                    source_id="start",
                    target_id="a",
                    condition="x > 5",
                ),
                EdgeSpec(
                    edge_id="e2",
                    source_id="start",
                    target_id="b",
                ),
            ),
        )
        engine = WorkflowEngine(spec=spec, registry=_registry())

        # x=10 → condition passes, both a and b execute
        result = await engine.run({"x": 10})
        assert result.node_results["a"].status == NodeStatus.SUCCESS
        assert result.node_results["b"].status == NodeStatus.SUCCESS

        # x=1 → condition fails, a skipped, b executes
        result2 = await engine.run({"x": 1})
        assert result2.node_results["a"].status == NodeStatus.SKIPPED
        assert result2.node_results["b"].status == NodeStatus.SUCCESS

    async def test_shared_variables_across_nodes(self) -> None:
        """Verify variables dict is shared across all nodes."""
        spec = WorkflowSpec(
            name="vars",
            version="1.0.0",
            nodes={
                "start": NodeSpec(node_id="start", node_type="input"),
                "t": NodeSpec(
                    node_id="t",
                    node_type="template",
                    config={
                        "template": "{{ greeting }} {{ name }}",
                        "output_key": "msg",
                    },
                ),
                "end": NodeSpec(node_id="end", node_type="output"),
            },
            edges=(
                EdgeSpec(edge_id="e1", source_id="start", target_id="t"),
                EdgeSpec(edge_id="e2", source_id="t", target_id="end"),
            ),
        )
        engine = WorkflowEngine(spec=spec, registry=_registry())
        result = await engine.run(
            {"name": "World"},
            variables={"greeting": "Hi"},
        )
        assert result.success is True
        assert result.output["msg"] == "Hi World"
