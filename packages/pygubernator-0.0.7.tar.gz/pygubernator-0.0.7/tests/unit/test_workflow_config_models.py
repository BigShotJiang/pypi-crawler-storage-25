"""Tests for workflow config Pydantic models."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from pygubernator.workflow.config._models import (
    EdgeDef,
    NodeDef,
    PositionDef,
    WorkflowConfig,
    WorkflowMeta,
)


class TestWorkflowMeta:
    """Tests for WorkflowMeta model."""

    def test_minimal(self) -> None:
        meta = WorkflowMeta(name="test")
        assert meta.name == "test"
        assert meta.version == "1.0.0"
        assert meta.description == ""

    def test_full(self) -> None:
        meta = WorkflowMeta(name="test", version="2.0.0", description="A workflow")
        assert meta.version == "2.0.0"


class TestNodeDef:
    """Tests for NodeDef model."""

    def test_minimal(self) -> None:
        node = NodeDef(type="input")
        assert node.type == "input"
        assert node.config == {}
        assert node.position.x == 0.0

    def test_with_config(self) -> None:
        node = NodeDef(
            type="template",
            config={"template": "hello"},
            position=PositionDef(x=100, y=200),
        )
        assert node.config["template"] == "hello"
        assert node.position.x == 100

    def test_invalid_type_raises(self) -> None:
        with pytest.raises(ValidationError):
            NodeDef(type="invalid_type")

    def test_all_valid_types(self) -> None:
        for t in [
            "input",
            "output",
            "template",
            "condition",
            "code",
            "http",
            "gsheets",
            "llm",
            "router",
            "loop",
            "map",
        ]:
            node = NodeDef(type=t)
            assert node.type == t


class TestEdgeDef:
    """Tests for EdgeDef model."""

    def test_minimal(self) -> None:
        edge = EdgeDef(source="n1", target="n2")
        assert edge.source == "n1"
        assert edge.target == "n2"
        assert edge.source_handle == "default"
        assert edge.condition is None

    def test_with_condition(self) -> None:
        edge = EdgeDef(
            source="n1",
            target="n2",
            source_handle="true",
            condition="x > 0",
        )
        assert edge.source_handle == "true"
        assert edge.condition == "x > 0"


class TestWorkflowConfig:
    """Tests for WorkflowConfig model."""

    def test_minimal_valid(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test"),
            nodes={
                "n1": NodeDef(type="input"),
                "n2": NodeDef(type="output"),
            },
            edges=[EdgeDef(source="n1", target="n2")],
        )
        assert config.meta.name == "test"
        assert len(config.nodes) == 2
        assert len(config.edges) == 1

    def test_invalid_edge_source_raises(self) -> None:
        with pytest.raises(ValidationError, match="source"):
            WorkflowConfig(
                meta=WorkflowMeta(name="test"),
                nodes={"n1": NodeDef(type="input")},
                edges=[EdgeDef(source="missing", target="n1")],
            )

    def test_invalid_edge_target_raises(self) -> None:
        with pytest.raises(ValidationError, match="target"):
            WorkflowConfig(
                meta=WorkflowMeta(name="test"),
                nodes={"n1": NodeDef(type="input")},
                edges=[EdgeDef(source="n1", target="missing")],
            )

    def test_empty_edges_valid(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test"),
            nodes={"n1": NodeDef(type="input")},
            edges=[],
        )
        assert len(config.edges) == 0

    def test_from_dict(self) -> None:
        data = {
            "meta": {"name": "test"},
            "nodes": {
                "start": {"type": "input"},
                "end": {"type": "output"},
            },
            "edges": [{"source": "start", "target": "end"}],
        }
        config = WorkflowConfig.model_validate(data)
        assert config.meta.name == "test"
        assert "start" in config.nodes
