"""Tests for workflow config-to-spec converter."""

from __future__ import annotations

from pygubernator.workflow._types import WorkflowSpec
from pygubernator.workflow.config._converter import workflow_config_to_spec
from pygubernator.workflow.config._models import (
    EdgeDef,
    NodeDef,
    PositionDef,
    WorkflowConfig,
    WorkflowMeta,
)


class TestWorkflowConfigToSpec:
    """Tests for the workflow_config_to_spec function."""

    def test_basic_conversion(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test", version="1.0.0", description="A test"),
            nodes={
                "n1": NodeDef(type="input"),
                "n2": NodeDef(type="output"),
            },
            edges=[EdgeDef(source="n1", target="n2")],
        )
        spec = workflow_config_to_spec(config)
        assert isinstance(spec, WorkflowSpec)
        assert spec.name == "test"
        assert spec.version == "1.0.0"
        assert spec.description == "A test"
        assert len(spec.nodes) == 2
        assert len(spec.edges) == 1

    def test_node_types_preserved(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test"),
            nodes={
                "n1": NodeDef(type="input"),
                "n2": NodeDef(
                    type="template",
                    config={"template": "hello"},
                ),
                "n3": NodeDef(type="output"),
            },
            edges=[
                EdgeDef(source="n1", target="n2"),
                EdgeDef(source="n2", target="n3"),
            ],
        )
        spec = workflow_config_to_spec(config)
        assert spec.nodes["n1"].node_type == "input"
        assert spec.nodes["n2"].node_type == "template"
        assert spec.nodes["n2"].config == {"template": "hello"}

    def test_position_preserved(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test"),
            nodes={
                "n1": NodeDef(
                    type="input",
                    position=PositionDef(x=100, y=200),
                ),
                "n2": NodeDef(type="output"),
            },
            edges=[EdgeDef(source="n1", target="n2")],
        )
        spec = workflow_config_to_spec(config)
        assert spec.nodes["n1"].position == (100.0, 200.0)

    def test_edge_properties_preserved(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test"),
            nodes={
                "n1": NodeDef(type="condition", config={"condition": "True"}),
                "n2": NodeDef(type="output"),
            },
            edges=[
                EdgeDef(
                    source="n1",
                    target="n2",
                    source_handle="true",
                    condition="result == True",
                ),
            ],
        )
        spec = workflow_config_to_spec(config)
        assert spec.edges[0].source_handle == "true"
        assert spec.edges[0].condition == "result == True"

    def test_edge_ids_auto_generated(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test"),
            nodes={
                "n1": NodeDef(type="input"),
                "n2": NodeDef(type="template", config={"template": "x"}),
                "n3": NodeDef(type="output"),
            },
            edges=[
                EdgeDef(source="n1", target="n2"),
                EdgeDef(source="n2", target="n3"),
            ],
        )
        spec = workflow_config_to_spec(config)
        assert spec.edges[0].edge_id == "edge_0"
        assert spec.edges[1].edge_id == "edge_1"

    def test_orphaned_nodes_warning(self, caplog: object) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="test"),
            nodes={
                "n1": NodeDef(type="input"),
                "n2": NodeDef(type="output"),
                "orphan": NodeDef(type="template", config={"template": "x"}),
            },
            edges=[EdgeDef(source="n1", target="n2")],
        )
        spec = workflow_config_to_spec(config)
        # The orphaned node should still be in the spec
        assert "orphan" in spec.nodes

    def test_tool_factory_subnode_config_merged_into_agent(self) -> None:
        config = WorkflowConfig(
            meta=WorkflowMeta(name="factory-tools"),
            nodes={
                "start": NodeDef(type="input"),
                "agent1": NodeDef(
                    type="agent",
                    config={"model": "gpt-4o", "prompt_template": "{{ task }}"},
                ),
                "tool_gsheets": NodeDef(
                    type="tool",
                    config={
                        "name": "google_sheets",
                        "factory_module": "pygubernator.tools.gsheets_factory",
                        "factory_function": "create_tools_from_env",
                        "factory_args": {"credentials_env_var": "CUSTOM_ENV"},
                    },
                ),
                "done": NodeDef(type="output"),
            },
            edges=[
                EdgeDef(source="start", target="agent1"),
                EdgeDef(
                    source="tool_gsheets",
                    target="agent1",
                    target_handle="sub:tool",
                ),
                EdgeDef(source="agent1", target="done"),
            ],
        )
        spec = workflow_config_to_spec(config)
        tools = spec.nodes["agent1"].config["tools"]
        assert "google_sheets" in tools
        gs = tools["google_sheets"]
        assert gs["factory_module"] == "pygubernator.tools.gsheets_factory"
        assert gs["factory_function"] == "create_tools_from_env"
        assert gs["factory_args"]["credentials_env_var"] == "CUSTOM_ENV"

    def test_gsheets_node_merged_into_agent_via_sub_tool(self) -> None:
        """Dedicated gsheets node on sub:tool registers the Sheets tool factory."""
        config = WorkflowConfig(
            meta=WorkflowMeta(name="gsheets-agent"),
            nodes={
                "start": NodeDef(type="input"),
                "agent1": NodeDef(
                    type="agent",
                    config={
                        "model": "gpt-4o",
                        "prompt_template": "{{ task }}",
                    },
                ),
                "sheets1": NodeDef(
                    type="gsheets",
                    config={
                        "operation": "read_range",
                        "credentials_env_var": "MY_GSHEETS_CREDS",
                    },
                ),
                "done": NodeDef(type="output"),
            },
            edges=[
                EdgeDef(source="start", target="agent1"),
                EdgeDef(
                    source="sheets1",
                    target="agent1",
                    target_handle="sub:tool",
                ),
                EdgeDef(source="agent1", target="done"),
            ],
        )
        spec = workflow_config_to_spec(config)
        assert "sheets1" not in spec.nodes
        tools = spec.nodes["agent1"].config["tools"]
        assert "google_sheets" in tools
        gs = tools["google_sheets"]
        assert gs["factory_module"] == "pygubernator.tools.gsheets_factory"
        assert gs["factory_function"] == "create_tools_from_env"
        assert gs["factory_args"]["credentials_env_var"] == "MY_GSHEETS_CREDS"

    def test_gsheets_stays_when_only_main_input_to_agent(self) -> None:
        """gsheets → agent default edge does not register tools or remove the node."""
        config = WorkflowConfig(
            meta=WorkflowMeta(name="gsheets-side"),
            nodes={
                "start": NodeDef(type="input"),
                "agent1": NodeDef(
                    type="agent",
                    config={"model": "gpt-4o", "prompt_template": "{{ task }}"},
                ),
                "sheets1": NodeDef(type="gsheets", config={"operation": "read_range"}),
                "done": NodeDef(type="output"),
            },
            edges=[
                EdgeDef(source="start", target="agent1"),
                EdgeDef(source="sheets1", target="agent1"),
                EdgeDef(source="agent1", target="done"),
            ],
        )
        spec = workflow_config_to_spec(config)
        assert "sheets1" in spec.nodes
        assert "tools" not in spec.nodes["agent1"].config
