"""Smoke tests for CLI workflow commands."""

from __future__ import annotations

import tempfile
from pathlib import Path
from unittest.mock import patch

import yaml

from pygubernator.cli import main


def _create_workflow_file(spec: dict) -> Path:
    """Write a workflow spec to a temp YAML file."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump(spec, f)
    return Path(f.name)


SIMPLE_SPEC = {
    "meta": {"name": "cli-test", "version": "1.0.0"},
    "nodes": {
        "in": {"type": "input"},
        "out": {
            "type": "output",
            "config": {"mappings": {"result": "{{ message }}"}},
        },
    },
    "edges": [{"source": "in", "target": "out"}],
}


class TestCLIWorkflowRun:
    """Tests for ``pygubernator workflow run``."""

    def test_workflow_run_success(self) -> None:
        path = _create_workflow_file(SIMPLE_SPEC)
        with patch(
            "sys.argv",
            [
                "pygubernator",
                "workflow",
                "run",
                str(path),
                "--input",
                '{"message": "hello"}',
            ],
        ):
            code = main()
        assert code == 0

    def test_workflow_run_dry_run(self) -> None:
        path = _create_workflow_file(SIMPLE_SPEC)
        with patch(
            "sys.argv",
            [
                "pygubernator",
                "workflow",
                "run",
                str(path),
                "--dry-run",
            ],
        ):
            code = main()
        assert code == 0

    def test_workflow_run_invalid_json_input(self) -> None:
        path = _create_workflow_file(SIMPLE_SPEC)
        with patch(
            "sys.argv",
            [
                "pygubernator",
                "workflow",
                "run",
                str(path),
                "--input",
                "not-json",
            ],
        ):
            code = main()
        assert code == 1

    def test_workflow_run_missing_file(self) -> None:
        with patch(
            "sys.argv",
            [
                "pygubernator",
                "workflow",
                "run",
                "/tmp/nonexistent-workflow.yaml",
            ],
        ):
            code = main()
        assert code == 1
