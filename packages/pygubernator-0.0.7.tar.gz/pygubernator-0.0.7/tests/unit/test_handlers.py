"""Tests for built-in event handlers (Logging, Metrics, Database)."""

from __future__ import annotations

import asyncio
import logging
from unittest.mock import MagicMock

from pygubernator._events import AgentEvent, AgentEventType
from pygubernator._handlers import (
    DatabaseEventHandler,
    LoggingEventHandler,
    MetricsEventHandler,
)


def _make_event(
    event_type: AgentEventType,
    agent_id: str = "test-agent",
    run_id: str | None = "run-1",
    data: dict | None = None,
) -> AgentEvent:
    """Create a test event."""
    import time

    return AgentEvent(
        event_type=event_type,
        agent_id=agent_id,
        timestamp=time.time(),
        data=data or {},
        run_id=run_id,
    )


class TestLoggingEventHandler:
    """Tests for LoggingEventHandler."""

    def test_info_event(self, caplog) -> None:
        handler = LoggingEventHandler()
        event = _make_event(AgentEventType.AGENT_STARTED)
        with caplog.at_level(logging.INFO):
            asyncio.run(handler.handle(event))
        assert "agent.started" in caplog.text

    def test_error_event(self, caplog) -> None:
        handler = LoggingEventHandler()
        event = _make_event(
            AgentEventType.AGENT_ERROR,
            data={"message": "something broke"},
        )
        with caplog.at_level(logging.ERROR):
            asyncio.run(handler.handle(event))
        assert "agent.error" in caplog.text

    def test_warning_event(self, caplog) -> None:
        handler = LoggingEventHandler()
        event = _make_event(AgentEventType.AGENT_PAUSED)
        with caplog.at_level(logging.WARNING):
            asyncio.run(handler.handle(event))
        assert "agent.paused" in caplog.text


class TestMetricsEventHandler:
    """Tests for MetricsEventHandler."""

    def test_counter_increments(self) -> None:
        handler = MetricsEventHandler()
        event = _make_event(AgentEventType.AGENT_STARTED)
        asyncio.run(handler.handle(event))
        asyncio.run(handler.handle(event))

        metrics = handler.get_metrics()
        assert metrics["counters"]["agent.started"] == 2

    def test_duration_recorded(self) -> None:
        handler = MetricsEventHandler()
        event = _make_event(
            AgentEventType.TOOL_CALL_COMPLETED,
            data={"duration_ms": 42.5},
        )
        asyncio.run(handler.handle(event))

        metrics = handler.get_metrics()
        assert 42.5 in metrics["durations"]["tool_call.completed"]

    def test_reset_clears_metrics(self) -> None:
        handler = MetricsEventHandler()
        asyncio.run(handler.handle(_make_event(AgentEventType.AGENT_STARTED)))

        handler.reset()
        metrics = handler.get_metrics()
        assert metrics["counters"] == {}
        assert metrics["durations"] == {}

    def test_event_without_duration(self) -> None:
        handler = MetricsEventHandler()
        event = _make_event(AgentEventType.AGENT_STOPPED)
        asyncio.run(handler.handle(event))

        metrics = handler.get_metrics()
        assert "agent.stopped" in metrics["counters"]
        assert "agent.stopped" not in metrics["durations"]


class TestDatabaseEventHandler:
    """Tests for DatabaseEventHandler."""

    def test_skips_event_without_run_id(self) -> None:
        factory = MagicMock()
        handler = DatabaseEventHandler(session_factory=factory)
        event = _make_event(AgentEventType.AGENT_STARTED, run_id=None)
        asyncio.run(handler.handle(event))

        factory.assert_not_called()

    def test_persists_run_event(self) -> None:
        mock_db = MagicMock()
        factory = MagicMock(return_value=mock_db)
        handler = DatabaseEventHandler(session_factory=factory)

        event = _make_event(AgentEventType.AGENT_STARTED)
        asyncio.run(handler.handle(event))

        mock_db.add.assert_called_once()
        mock_db.commit.assert_called_once()
        mock_db.close.assert_called_once()

    def test_persists_tool_call_event(self) -> None:
        mock_db = MagicMock()
        factory = MagicMock(return_value=mock_db)
        handler = DatabaseEventHandler(session_factory=factory)

        event = _make_event(
            AgentEventType.TOOL_CALL_COMPLETED,
            data={"tool_name": "my_tool", "duration_ms": 100},
        )
        asyncio.run(handler.handle(event))

        mock_db.add.assert_called_once()
        mock_db.commit.assert_called_once()

    def test_persists_failed_tool_call(self) -> None:
        mock_db = MagicMock()
        factory = MagicMock(return_value=mock_db)
        handler = DatabaseEventHandler(session_factory=factory)

        event = _make_event(
            AgentEventType.TOOL_CALL_FAILED,
            data={"tool_name": "bad_tool", "error": "boom"},
        )
        asyncio.run(handler.handle(event))

        mock_db.add.assert_called_once()

    def test_handles_db_error_gracefully(self, caplog) -> None:
        mock_db = MagicMock()
        mock_db.commit.side_effect = RuntimeError("db down")
        factory = MagicMock(return_value=mock_db)
        handler = DatabaseEventHandler(session_factory=factory)

        event = _make_event(AgentEventType.AGENT_STOPPED)
        with caplog.at_level(logging.ERROR):
            asyncio.run(handler.handle(event))

        mock_db.rollback.assert_called_once()
        mock_db.close.assert_called_once()
        assert "Failed to persist event" in caplog.text
