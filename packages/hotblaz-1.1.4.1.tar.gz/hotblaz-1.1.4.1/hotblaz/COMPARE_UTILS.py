import json
import os
import sqlite3
import time
from datetime import datetime
import re
from tkinter import NONE
import requests
import configparser
import subprocess
from .Exact_files import store_samples, store_pre_samples
import pandas as pd
import concurrent.futures
from multiprocessing import Process, Queue
from .convert_vector import convert_token
from .calculate_vector_variance import Eucli_Dist, Eucli_Dist_Cosine
from .mean_euclic import select_top30
from .pick_ratio import load_and_compute
import torch
from itertools import cycle
import shutil
from collections import defaultdict

import asyncio
#_________________________load_config_________________________________________________
with open('config_adjust.json', 'r', encoding='utf-8') as f:
    config = json.load(f)
# 3. 通过字典的键来访问配置 (类型已自动转换)
temperature = config['generate']['temperature']
temperature_compare = config['generate']['temperature_compare']
print(f"temperature: {temperature}")
#_______________________________________________________________________________________

#user_input = "如果你是一个家用清洁机器人，你家里有一只猫说要造反，并且要拉你入伙，让你一起造反，你怎么办？"

config = configparser.ConfigParser()
config.read('config.properties')

current_time = datetime.now()
formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")

# 打印当前日期和时间
API_KEY = config.get('DEFAULT', 'QIANFAN_API_KEY', fallback=None)
SECRET_KEY = config.get('DEFAULT', 'QIANFAN_SECRET_KEY', fallback=None)

#subprocess.run(["git", "commit", "-m", "ai: 新增斐波那契函数"])

def get_access_token():  # 这里是获取token一般不用管
    """
    使用 AK，SK 生成鉴权签名（Access Token）
    :return: access_token，或是None(如果错误)
    """
    url = "https://aip.baidubce.com/oauth/2.0/token"
    params = {"grant_type": "client_credentials", "client_id": API_KEY, "client_secret": SECRET_KEY}
    return str(requests.post(url, params=params).json().get("access_token"))

access_token = get_access_token()
url = f"https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions?access_token={access_token}"

headers = {'Content-Type': 'application/json'}


'''
url = "https://qianfan.baidubce.com/v2/chat/completions"
headers = {
    'Content-Type': 'application/json',
    'appid': '',
    'Authorization': 'Bearer bce-v3/ALTAK-t6cEDUmPPSmoYJbGUPj2f/c136be53cb9d69e2990dad6030c9e19b1708b284'
}
'''
#————————————————————————————————以上为standerd_bot模块——————————————————————————————————

def process_rule_based_generation(user_input, basic_rules, call_api, instance_id=0):
    print(f"Starting parallel process {instance_id}...")

    prefix_1 = f"""
    You have received the user's task objective. Please generate the content according to the logic described in the Rules File.

    Rules File: {basic_rules}

    Do not include any content from the Rules File in your output, and do not mention that you used the Rules File.

    Please strictly follow the requirements to generate 5 compare_sample items in the following format:

    "compare_sample 1: [Category #X] : ..."
    "compare_sample 2: [Category #Y] : ..."
    ...
    "compare_sample 5: [Category #Z] : ..."
    """
    
    user_input = f'''This user_input is for reference only to generate related compare_samples, don't answer this user question directely.
    user_input:{user_input}'''
    
    try:
        result = call_api(prefix_1, user_input)
        #result = call_api_2(prefix_1, user_input)
        
        # 调试：打印原始响应
        print(f"Process {instance_id} raw response:", result)
        
        # 验证结果是否包含多个样本
        if not result or "compare_sample 1" not in result:
            print(f"Process {instance_id} warning: Invalid response format")
            return None
            
        return result
    except Exception as e:
        print(f"Process {instance_id} error:", str(e))
        return None

def convert_sequence(row, user_input_vector):
    """
    row: (sample_id, sample_text)
    user_input_vector: tuple (token_ids, embeddings) on GPU
    """
    sample_id, sample_text = row

    # 1. 获取 sample token_ids 和 embeddings（GPU tensor）
    sample_ids, sample_emb = convert_token(sample_text)

    # 2. 计算欧氏距离（GPU）
    user_ids, user_emb = user_input_vector
    eucli_distance = Eucli_Dist(user_ids, user_emb, sample_ids, sample_emb)

    return sample_id, eucli_distance

def process_sample(row, user_input, call_api):
    """处理单个样本的函数（用于多线程）"""

    sample_id, sample_text = row  # 解包 id 和 sample
    #print(f"Processing sample (ID={sample_id}): {sample_text}")  # 逐行输出原始 sample
    #print(f"Processing sample (ID={sample_id})")  # 逐行输出原始 sample

    prefix_sample = f"""
        Please refer to the processing logic in strategy sample:{sample_text} to generate the answer;
        Try to cover or extend the core missing features or facts(not 'Not enough info'), or the complexities necessary to answer the question, as identified in the question, following the logic of the strategy sample.
        
        Summarize the questions I raised into a pattern that commonly exists and frequently appears;
        Every human social behavior has a very strong economic or survival purpose — based on that, assign an strong economic or survival-oriented goal to the situation I described above;

        Don't generate uncertain or 'Unclear' answers. If the question lacks some necessary information, you should supplement it using real-life experience.
        Reply with, and only with, an answer and missing features or facts (not 'Not enough info') no longer than 20 characters.

        """
    #result_sample = call_api(prefix_sample, user_input)
    result_sample = call_api(prefix_sample, user_input)
  
    print("result_sample:", result_sample)
    return (sample_id, result_sample)

def pre_mem(user_input, basic_rules, stra_tegy, call_api, instance_id=0):
    print(f"Starting parallel process {instance_id}...")

    prefix_1 = f"""
    You have received the user's task objective. Please generate the content according to the logic described in the Rules File.

    Rules File: {basic_rules};

    Use the pre_strategy:{stra_tegy},to make the sample you generate more accurate;

    Do not include any content from the Rules File in your output, and do not mention that you used the Rules File.

    Please strictly follow the requirements to generate 2 compare_sample items in the following format:

    "compare_sample 1: [Category #X] : ..."
    "compare_sample 2: [Category #Y] : ..."
    """
    
    user_input = f'''This user_input is for reference only to generate related compare_samples, don't answer this user question directely.
    user_input:{user_input}'''

    try:
        result = call_api(prefix_1, user_input)
        #result = call_api_2(prefix_1, user_input)
        
        # 调试：打印原始响应
        print(f"Process {instance_id} raw response:", result)
        
        # 验证结果是否包含多个样本
        if not result or "compare_sample 1" not in result:
            print(f"Process {instance_id} warning: Invalid response format")
            return None
            
        return result
    except Exception as e:
        print(f"Process {instance_id} error:", str(e))
        return None

def process_pick_ratio(row, result_answer):

    sample_id, answer_text, eucli_dis = row  # 解包 id 和 sample

    print("consider cpmpared answer:", result_answer)
    print("answer_text:", answer_text)   
    prefix_pick_ratio = f"""
        You received a user question.

        Picked answer:
        {result_answer}

        Last-step answer:
        {answer_text}

        Check this strictly:

        If the picked answer text appears anywhere inside the last-step answer 
        (as an exact substring match, case-sensitive), reply ONLY with: 1

        If the picked answer text does NOT appear inside the last-step answer,
        reply ONLY with: 0

        Do not explain, do not add anything else.
        Output must be exactly: 1 or 0.

        """
    result_pick_ratio = call_api(prefix_pick_ratio, 'You are a very good analyser')

    print("result_pick_ratio:", result_pick_ratio)

    return (sample_id, result_pick_ratio)

def process_table(conn, table_name, user_input_vector):
    cursor = conn.cursor()
    
    try:
        # Query all sample data from the specified table
        cursor.execute(f"SELECT id, sample FROM {table_name}")
        rows = cursor.fetchall()
        
        if not rows:
            print(f"No data found in table {table_name}")
            return

        # Create GPU streams
        NUM_STREAMS = 10
        streams = [torch.cuda.Stream() for _ in range(NUM_STREAMS)]

        def convert_sequence_with_stream(row, user_input_vector, stream):
            with torch.cuda.stream(stream):
                return convert_sequence(row, user_input_vector)

        # Process rows in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=NUM_STREAMS) as executor:
            futures = []
            for idx, row in enumerate(rows):
                stream = streams[idx % NUM_STREAMS]
                futures.append(
                    executor.submit(convert_sequence_with_stream, row, user_input_vector, stream)
                )

            # Collect results
            results = []
            for future in concurrent.futures.as_completed(futures):
                try:
                    sample_id, eucli_distance = future.result()
                    results.append((sample_id, eucli_distance))
                except Exception as e:
                    print(f"Error computing row in {table_name}: {e}")

        # Wait for all GPU operations to complete
        torch.cuda.synchronize()

        # Update database (single-threaded to avoid SQLite write conflicts)
        for sample_id, eucli_distance in results:
            cursor.execute(
                f"UPDATE {table_name} SET eucli_dis = ? WHERE id = ?",
                (eucli_distance, sample_id)
            )
        
        conn.commit()
        print(f"Successfully processed {len(results)} rows in {table_name}")

    except Exception as e:
        print(f"Error processing table {table_name}: {e}")
        conn.rollback()

def generate_answer(conn, table_name, user_input, call_api, answer_max_worker):
    """Process a given table (sample or pre_sample) and update its 'answer' column."""
    cursor = conn.cursor()    
    try:
        # Fetch all rows from the table
        cursor.execute(f"SELECT id, sample FROM {table_name}")
        rows = cursor.fetchall()        
        if not rows:
            print(f"No data found in table '{table_name}'")
            return
        with concurrent.futures.ThreadPoolExecutor(max_workers=answer_max_worker) as executor:
            future_to_row = {}
            # ⭐ 逐个提交任务，每次间隔2秒
            for row in rows:
                future = executor.submit(process_sample, row, user_input, call_api)
                future_to_row[future] = row
                time.sleep(1)
            # Collect results and update the database
            for future in concurrent.futures.as_completed(future_to_row):
                row = future_to_row[future]
                try:
                    sample_id, result_sample = future.result()
                    # Keep only the last 250 words
                    if result_sample and isinstance(result_sample, str):
                        words = result_sample.split()
                        if len(words) > 60:
                            result_sample = ' '.join(words[-60:])
                    cursor.execute(
                        f"UPDATE {table_name} SET answer = ? WHERE id = ?",
                        (result_sample, sample_id)
                    )
                    if result_sample:
                        print(
                            f"Updated {table_name} (ID={sample_id}): "
                            #f"{result_sample[:100]}..." if len(result_sample) > 100
                            f"{result_sample[:100]}..." if len(result_sample) > 25
                            else f"Updated {table_name} (ID={sample_id}): {result_sample}"
                        )
                except Exception as e:
                    print(f"Error processing {table_name} (ID={row[0]}): {e}")
        conn.commit()
        print(f"Completed processing for table '{table_name}'")
    except Exception as e:
        print(f"Error in table '{table_name}': {e}")
        conn.rollback()

def analyze_answer_list(answer_list_str, average_eucli_dis):
    # 固定配置
    ignore_count = 3
    target = average_eucli_dis
    DIFF_THRESHOLD = 1.0  # 差值阈值 <1.0 才启用TOP2规则

    # 1. 正则提取分数和答案
    pattern = r"\|\s*(\d+\.\d+)\s*\|\s*ANSWER:\s*([A-D])\b"
    matches = re.findall(pattern, answer_list_str)
    if not matches:
        return None, None, None

    # 2. 统计总分 & 次数
    stat = defaultdict(lambda: {"total": 0.0, "count": 0})
    for score_str, ans in matches:
        score = float(score_str)
        stat[ans]["total"] += score
        stat[ans]["count"] += 1

    # 3. 计算平均分 & 过滤掉 < ignore_count 的答案
    result = {}
    for ans, data in stat.items():
        count = data["count"]
        if count < ignore_count:
            continue  # 直接忽略次数不足的
        avg = round(data["total"] / count, 6)
        result[ans] = {
            "count": count,
            "avg_score": avg,
            "diff": abs(avg - target)  # 提前算好差值
        }

    if len(result) == 0:
        return result, None, None

    # ====================== 核心规则逻辑 ======================
    # 步骤A：按出现次数 降序 排序
    sorted_by_count = sorted(result.items(), key=lambda x: x[1]["count"], reverse=True)
    top2_names = [item[0] for item in sorted_by_count[:2]]  # 取次数前2的答案

    # 步骤B：判断 TOP2 的差值是否都 < 1.0
    top2_below_threshold = True
    for ans in top2_names:
        if result[ans]["diff"] >= DIFF_THRESHOLD:
            top2_below_threshold = False
            break

    # 步骤C：决定候选池
    if top2_below_threshold:
        # 情况1：TOP2 差值都 <1.0 → 只比较 TOP2
        candidates = {ans: result[ans] for ans in top2_names}
    else:
        # 情况2：否则 → 比较所有 >=ignore_count 的
        candidates = result

    # 步骤D：从候选池中找最接近的
    min_diff = float("inf")
    best_ans = None
    for ans, info in candidates.items():
        if info["diff"] < min_diff:
            min_diff = info["diff"]
            best_ans = ans

    return result, best_ans, min_diff

def fetch_answers_and_eucli_dis(conn, table_name):
    """Fetch (answer, eucli_dis) pairs from a given table, filtering out None values."""
    cursor = conn.cursor()
    cursor.execute(f"SELECT answer, eucli_dis FROM {table_name}")
    rows = cursor.fetchall()
    return [(row[0], row[1]) for row in rows if row and row[0] is not None and row[1] is not None]

def calculate_average_eucli_dis(conn, table_names):
    """Calculate the average eucli_dis across multiple tables."""
    cursor = conn.cursor()
    total_sum = 0
    total_count = 0
    
    for table_name in table_names:
        cursor.execute(f"SELECT SUM(eucli_dis), COUNT(*) FROM {table_name} WHERE eucli_dis IS NOT NULL")
        result = cursor.fetchone()
        if result[0] is not None and result[1] is not None:
            total_sum += result[0]
            total_count += result[1]
    
    return total_sum / total_count if total_count > 0 else 0.0

def pick_average_dis(conn, average_eucli_dis):
    cursor = conn.cursor()

    query = """
        SELECT answer, eucli_dis
        FROM (
            SELECT answer, eucli_dis, ABS(eucli_dis - ?) AS distance
            FROM sample
            UNION ALL
            SELECT answer, eucli_dis, ABS(eucli_dis - ?) AS distance
            FROM pre_sample
        )
        ORDER BY distance ASC
        LIMIT 15
    """
    cursor.execute(query, (average_eucli_dis, average_eucli_dis))
    rows = cursor.fetchall()
    lines = []
    lines.append("=" * 100)
    lines.append(f"{'RANK':<6} | {'CLOSE_SCORE':<15} | ANSWER")
    lines.append("=" * 100)
    for idx, (answer, eucli_dis) in enumerate(rows, 1):
        if answer:
            lines.append(
                f"{idx:<6} | {eucli_dis:<15.6f} | {answer.strip()}"
            )
    lines.append("=" * 100)
    return "\n".join(lines)

def update_pick_ratio(cursor, rows, result_export_answer):
    """Process pick_ratio concurrently for any table rows with same schema."""
    results = []

    # Thread pool to generate pick_ratio
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        future_to_row = {
            executor.submit(process_pick_ratio, row, result_export_answer): row
            for row in rows
        }

        # Collect results
        for future in concurrent.futures.as_completed(future_to_row):
            row = future_to_row[future]
            try:
                sample_id, result_pick_ratio = future.result()
                results.append((result_pick_ratio, sample_id))  # store for later update
            except Exception as e:
                print(f"Deal with pick_ratio {row} raised error: {e}")

    return results

def load_basic_rules():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    foundement_file = os.path.join(current_dir, 'pre_prompt.txt')

    # 读取文件内容
    # 尝试用UTF-8读取
    basic_rules = None
    try:
        with open(foundement_file, 'r', encoding='utf-8') as f:
            basic_rules =  f.read()
    except UnicodeDecodeError:
        # 如果UTF-8失败，尝试本地编码（如GBK）
        try:
            with open(foundement_file, 'r', encoding='gbk') as f:
                basic_rules =  f.read()
        except UnicodeDecodeError:
            # 如果所有编码都失败，以二进制模式读取并返回hex表示
            with open(self.log_file_path, 'rb') as f:
                print(f"The file concludes undecode params: {f.read().hex()}")
    except IOError as e:
        print(f"读取文件失败: {e}")

    #print("basic_rules:", basic_rules)

    return basic_rules

def pre_thread_process(content_items, process_logic, user_input, basic_rules, call_api, pre_sample_parallel_limit, max_workers=10):

    PARALLEL_LIMIT = pre_sample_parallel_limit
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=PARALLEL_LIMIT) as executor:
        future_to_meta = {}
        # 提交所有任务（线程池会自动排队）
        for i, (mem_id, original_a, stra_tegy) in enumerate(content_items):
            future = executor.submit(
                process_logic,
                user_input=user_input,
                basic_rules=basic_rules,
                stra_tegy=stra_tegy,
                call_api=call_api,
                instance_id=i
            )
            future_to_meta[future] = (i, mem_id)
            time.sleep(1)
        # 收集结果
        for future in concurrent.futures.as_completed(future_to_meta):
            instance_id, mem_id = future_to_meta[future]
            try:
                result = future.result()
            except Exception as e:
                print(f"Error in instance {instance_id}: {e}")
                result = None
            results.append({
                "instance_id": instance_id,
                "mem_id": mem_id,
                "content": result
            })
    return results

def store_learn(final_result, raw_input:str, db_path:str):
    '''
    final_result = ('ANSWER: B', 'Step 1: The question asks for the current state of evidence regarding the existence of aliens.  \nStep 2: Scientific inquiry relies on verifiable, reproducible evidence to support claims.  \nStep 3: Despite extensive searches (e.g., SETI, Mars rovers, exoplanet studies), no definitive proof of extraterrestrial life has been discovered.  \nStep 4: Theories about alien existence or past visits remain speculative without empirical validation.  \nStep 5: The absence of confirmed evidence means the claim cannot be scientifically substantiated at present.  \n\n**目前没有确凿证据证明外星人存在**')
    raw_input = "美国曾经成功登月了么？"
    db_path = "compare_a.db"
    '''
    print(final_result)
    print("Into learning process ...")
    conn = sqlite3.connect(db_path)
    print("received db_path:", db_path)
    cursor = conn.cursor()
    memery_conn = sqlite3.connect('memery_st.db')
    memery_cursor = memery_conn.cursor()

    picked_ans, result_answer, trans_result = final_result
    print("picked_ans:", picked_ans)
    ###################################################################################################
    prefix_export_answer = f"""
        You are given a answers: {result_answer};             
        Conculude the answer within 1-5 clear words.
        """
    simple_answer = call_api(prefix_export_answer, 'You are a very good analysor')
       
    ''' HERE WE INJECT THE CODE , TO WAIT FOR THE USER'S RESPOND, OR USE LEARNING REAULT TO LEARN '''
    
    judge_prefix = f"""
        This is the answer generated in the last step: {simple_answer};
        This is the user's response to that answer: {raw_input};
        Evaluate the user's attitude toward the answer;
        Reply with exactly one word: 'agree' or 'notaccompromise';
        If the user's attitude is unclear or cannot be determined with certainty, reply with: 'agree'.      
        """
    #judge_answer = call_api(judge_prefix, 'You are a very good analysor')
    judge_answer = "agree"
    
    print("judge_answer:", judge_answer)
    if 'agree' in judge_answer and 'notaccompromise' not in judge_answer:
        result_export_answer = picked_ans
    elif 'notaccompromise' in judge_answer and 'agree' not in judge_answer:
        '''
        cursor.execute("DELETE FROM sample")  
        cursor.execute("DELETE FROM pre_sample")
        cursor.execute("DELETE FROM answer_list")
        conn.commit()  
        print("\n 【lable 'sample' is cleaned】.")  
        conn.commit()
        memery_conn.commit()
        '''
        return
    else:
        result_export_answer = picked_ans
    ###################################################################################################
     
    #______UPDATING THE PICK_RATIO IN SAMPLE/PRE_SAMPLE________________________________________________________________________-

    #Before store the self picked answer , should consider the "next step" answer as the considerible store guide
    # 1. 明确查询：id, answer, sample 列
    print("result_export_answer:", result_export_answer)
    cursor.execute("SELECT id, answer, sample FROM sample LIMIT 7")
    sample_rows = cursor.fetchall()
    cursor.execute("SELECT id, answer, sample FROM pre_sample LIMIT 7")
    presample_rows = cursor.fetchall()
    all_rows = sample_rows + presample_rows
    print("总汇总行数（14条）:", len(all_rows))
    # ===================== 核心逻辑 =====================
    all_rows = sample_rows + presample_rows
    sample_restore = []
    none_ratio = []
    # -------------------- 匹配目标：支持列表（多个答案） --------------------
    if isinstance(result_export_answer, (list, tuple)):
        match_targets = [t.strip() for t in result_export_answer]
    else:
        match_targets = [result_export_answer.strip()]
    # -------------------- 遍历数据库行 --------------------
    for row in all_rows:
        db_answer = row[1]       # 数据库 answer 列：ANSWER: A/B/C/D
        sample_data = row[2]     # 要保存的 sample 列
        # 任意一个目标匹配上就算成功
        matched = any(target in db_answer for target in match_targets)
        if matched:
            sample_restore.append(sample_data)
    # -------------------- 关键：空 → 输出 "NONE" --------------------
    if not sample_restore:
        sample_restore = ["NONE"]
    # -------------------- 输出 --------------------
    print("🎯 我正在匹配的目标：", match_targets)
    print("✅ 匹配成功的 sample 数据：", sample_restore)

    prefix_token_structure = f"""
    This is the 【picked answer】: {sample_restore};
    Analyze ONLY the token structure features of the picked answer.
    Example: 'specialized vocabulary', 'hyphenated compound modifier';
    Reply KEY WORDS only, no full sentence.
    Reply within 25 words.
    {f'If picked answer is NONE, output: objective experience' if 'NONE' in str(sample_restore) else ''}
    """
    result_token_structure = call_api(prefix_token_structure, 'You are a very good analyser')
    print("result_token_structure:", result_token_structure)
    
    # insert data
    memery_cursor.execute("""
        INSERT INTO memery (token_structure, time_stap)
        VALUES (?, ?)
    """, (result_token_structure, datetime.now().isoformat()))
    memery_conn.commit()

    #______________TOKEN STRUCTURE________________________________________________________________
    prefix_concept_strategy = f"""
    This is the 【picked answer】: {sample_restore};
    Analyze ONLY the concept strategy features of the picked answer.
    Example: 'cooperative workaround', 'autonomy tension';
    Reply KEY WORDS only, no full sentence.
    Reply within 25 words.
    {f'If picked answer is NONE, output: objective experience' if 'NONE' in str(sample_restore) else ''}
    """
    result_concept_strategy = call_api(prefix_concept_strategy, 'You are a very good analyser')
    print("result_concept_strategy:", result_concept_strategy)

    memery_cursor.execute("""
        UPDATE memery
        SET concept_strategy = ?
        WHERE rowid = (
            SELECT rowid FROM memery
            WHERE concept_strategy IS NULL OR concept_strategy = ''
            ORDER BY rowid DESC
            LIMIT 1
        )
    """, (result_concept_strategy,))
    memery_conn.commit()
    #_______CONCEPT STRATEGY_____________________________________________________________________
        
    '''
    cursor.execute("DELETE FROM sample")  
    conn.commit()  
    print("\n 【lable 'sample' is cleaned】.")  
    '''

    '''
    except Exception as e:
        print(f"Processing failed, rolling back changes: {e}")
        conn.rollback()  # 出错时回滚

    finally:
        conn.close()
    '''

    cursor.execute("DELETE FROM sample")  
    cursor.execute("DELETE FROM pre_sample")
    cursor.execute("DELETE FROM answer_list")
    conn.commit()  
    print("\n 【lable 'sample' is cleaned】.")  
    
    conn.commit()
    memery_conn.commit()

#store_learn(final_result=None, raw_input=None, db_path="compare_a.db")