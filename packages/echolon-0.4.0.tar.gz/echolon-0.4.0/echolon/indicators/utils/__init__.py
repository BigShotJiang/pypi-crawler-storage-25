# Indicator utilities
