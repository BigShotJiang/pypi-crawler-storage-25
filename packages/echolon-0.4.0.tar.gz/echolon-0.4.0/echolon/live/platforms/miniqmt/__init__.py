# MiniQMT platform integration
