"""Multi-turn billing session with aggregates, budgets, and session_close telemetry."""

from __future__ import annotations

import asyncio
import threading
import time
import uuid
from collections import Counter
from typing import Any, Callable, Dict, Optional, Union

from .exceptions import MetricAIBudgetExceeded
from .payload import build_track_payload, compute_billable_inr, derive_tool_fields, new_idempotency_key
from .types import SimulationResult, TrackResult


class MetricAISession:
    """
    Groups ``track()`` / ``atrack()`` calls under one ``session_id``.

    On exit, sends ``event_type=session_close`` with aggregates. The session_close event uses
    ``session_id`` as the ``Idempotency-Key`` header (stable close semantics).

    Also calls :meth:`MetricAI.complete_session` so existing proxy session APIs stay in sync.
    """

    def __init__(
        self,
        client: MetricAI,
        *,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        max_budget_inr: Optional[float] = None,
        soft_budget_inr: Optional[float] = None,
        on_budget_warning: Optional[Callable[[float, float, str], None]] = None,
    ) -> None:
        self._client = client
        self.session_id = session_id or str(uuid.uuid4())
        self.agent_id = agent_id
        self.user_id = user_id
        self.max_budget_inr = max_budget_inr
        self.soft_budget_inr = soft_budget_inr
        self.on_budget_warning = on_budget_warning
        self._turn = 0
        self._t0 = time.perf_counter()
        self._total_input = 0
        self._total_output = 0
        self._total_cost: float = 0.0
        self._cost_known = False
        self._cumulative_context = 0
        self._total_tool_calls = 0
        self._tool_types: set[str] = set()
        self._exec_type_counts: Counter[str] = Counter()
        self._soft_warned = False
        self._budget_warning_active = False
        self._exit_status: str = "completed"
        self._closed = False
        self._lock = threading.RLock()  # reliability-fix: FIX-5
        self._async_lock: Optional[asyncio.Lock] = None  # reliability-fix: FIX-5

    def __enter__(self) -> MetricAISession:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._closed:
            return False
        if exc_type is not None and self._exit_status != "budget_exceeded":
            self._exit_status = "error"
        self._finalize_sync()
        self._closed = True
        return False

    async def __aenter__(self) -> MetricAISession:
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self._closed:
            return False
        if exc_type is not None and self._exit_status != "budget_exceeded":
            self._exit_status = "error"
        await self._finalize_async()
        self._closed = True
        return False

    def _build_close_extra(self, duration_ms: int) -> Dict[str, Any]:
        dominant_et = None
        if self._exec_type_counts:
            dominant_et = self._exec_type_counts.most_common(1)[0][0]
        summary = {
            "total_tool_calls": self._total_tool_calls,
            "tool_types_used": sorted(self._tool_types),
            "dominant_execution_type": dominant_et,
        }
        return {
            "total_turns": self._turn,
            "total_input_tokens": self._total_input,
            "total_output_tokens": self._total_output,
            "total_cost_inr": self._total_cost if self._cost_known else None,
            "cumulative_context_tokens": self._cumulative_context,
            "session_duration_ms": duration_ms,
            "status": self._exit_status,
            "session_tool_summary": summary,
        }

    def _finalize_sync(self) -> None:
        duration_ms = int((time.perf_counter() - self._t0) * 1000)
        extra = self._build_close_extra(duration_ms)
        body = build_track_payload(
            event_type="session_close",
            session_id=self.session_id,
            agent_id=self.agent_id,
            user_id=self.user_id,
            extra=extra,
        )
        try:
            self._client._telemetry_send(body, idempotency_key=self.session_id)
        except Exception:
            pass
        try:
            self._client.complete_session(self.session_id)
        except Exception:
            pass

    async def _finalize_async(self) -> None:
        duration_ms = int((time.perf_counter() - self._t0) * 1000)
        extra = self._build_close_extra(duration_ms)
        body = build_track_payload(
            event_type="session_close",
            session_id=self.session_id,
            agent_id=self.agent_id,
            user_id=self.user_id,
            extra=extra,
        )
        try:
            await self._client._telemetry_send_async(body, idempotency_key=self.session_id)
        except Exception:
            pass
        try:
            await asyncio.to_thread(self._client.complete_session, self.session_id)
        except Exception:
            pass

    def _turn_cost(self, kwargs: Dict[str, Any]) -> Optional[float]:
        if kwargs.get("cost_inr") is not None:
            return float(kwargs["cost_inr"])
        oc = kwargs.get("outcome")
        if oc:
            bill = compute_billable_inr(oc)  # type: ignore[arg-type]
            if bill is not None:
                return float(bill)
        return None

    def _after_track(self, kwargs: Dict[str, Any]) -> None:
        it = kwargs.get("input_tokens")
        ot = kwargs.get("output_tokens")
        if it is not None:
            self._total_input += int(it)
        if ot is not None:
            self._total_output += int(ot)
        ct = kwargs.get("context_tokens")
        if ct is not None:
            self._cumulative_context += int(ct)
        c = self._turn_cost(kwargs)
        if c is not None:
            self._total_cost += c
            self._cost_known = True
        tools = kwargs.get("tools")
        if tools:
            tic, et = derive_tool_fields(tools)  # type: ignore[arg-type]
            if tic:
                self._total_tool_calls += int(tic)
            for t in tools:
                tt = (t.get("type") or "").strip()
                if tt:
                    self._tool_types.add(tt)
            if et:
                self._exec_type_counts[et] += 1

    def _check_soft_budget(self, spent: float) -> None:
        if self.soft_budget_inr is None or self._soft_warned:
            return
        if spent < float(self.soft_budget_inr):
            return
        self._soft_warned = True
        self._budget_warning_active = True
        body = build_track_payload(
            event_type="budget_warning",
            session_id=self.session_id,
            agent_id=self.agent_id,
            user_id=self.user_id,
            extra={"spent_inr": spent, "soft_budget_inr": float(self.soft_budget_inr)},
        )

        def _run() -> None:
            try:
                self._client._telemetry_send(body, idempotency_key=new_idempotency_key())
            except Exception:
                pass

        threading.Thread(target=_run, daemon=True, name="metricai_budget_warning").start()
        if self.on_budget_warning:
            try:
                self.on_budget_warning(spent, float(self.soft_budget_inr), self.session_id)
            except Exception:
                pass

    def _check_hard_budget(self, spent: float) -> None:
        if self.max_budget_inr is None:
            return
        if spent <= float(self.max_budget_inr):
            return
        self._exit_status = "budget_exceeded"
        duration_ms = int((time.perf_counter() - self._t0) * 1000)
        extra = self._build_close_extra(duration_ms)
        body = build_track_payload(
            event_type="session_close",
            session_id=self.session_id,
            agent_id=self.agent_id,
            user_id=self.user_id,
            extra=extra,
        )
        try:
            self._client._telemetry_send(body, idempotency_key=self.session_id)
        except Exception:
            pass
        try:
            self._client.complete_session(self.session_id)
        except Exception:
            pass
        self._closed = True
        raise MetricAIBudgetExceeded(
            budget_inr=float(self.max_budget_inr),
            spent_inr=spent,
            session_id=self.session_id,
            agent_id=self.agent_id,
        )

    def track(self, **kwargs: Any) -> Union[TrackResult, SimulationResult, None]:
        with self._lock:  # reliability-fix: FIX-5
            if self._closed:  # type: ignore[misc]  # reliability-fix: FIX-5
                return None  # type: ignore[unreachable]  # reliability-fix: FIX-5
            self._turn += 1  # reliability-fix: FIX-5
            merged: Dict[str, Any] = {**kwargs}  # reliability-fix: FIX-5
            merged["session_id"] = merged.get("session_id", self.session_id)  # reliability-fix: FIX-5
            merged["agent_id"] = merged["agent_id"] if "agent_id" in merged else self.agent_id  # reliability-fix: FIX-5
            merged["user_id"] = merged["user_id"] if "user_id" in merged else self.user_id  # reliability-fix: FIX-5
            merged["turn_number"] = self._turn  # reliability-fix: FIX-5
            if self._budget_warning_active:  # reliability-fix: FIX-5
                merged["budget_warning"] = True  # reliability-fix: FIX-5
            result = self._client.track(**merged)  # reliability-fix: FIX-5
            self._after_track(merged)  # reliability-fix: FIX-5
            spent = self._total_cost  # reliability-fix: FIX-5
            self._check_soft_budget(spent)  # reliability-fix: FIX-5
            self._check_hard_budget(spent)  # reliability-fix: FIX-5
        return result  # reliability-fix: FIX-5

    async def atrack(self, **kwargs: Any) -> Union[TrackResult, SimulationResult, None]:
        if self._async_lock is None:  # reliability-fix: FIX-5
            self._async_lock = asyncio.Lock()  # reliability-fix: FIX-5
        async with self._async_lock:  # type: ignore[unreachable]  # reliability-fix: FIX-5
            if self._closed:  # type: ignore[unreachable]  # reliability-fix: FIX-5
                return None  # type: ignore[unreachable]  # reliability-fix: FIX-5
            self._turn += 1  # reliability-fix: FIX-5
            merged = {**kwargs}  # reliability-fix: FIX-5
            merged["session_id"] = merged.get("session_id", self.session_id)  # reliability-fix: FIX-5
            merged["agent_id"] = merged["agent_id"] if "agent_id" in merged else self.agent_id  # reliability-fix: FIX-5
            merged["user_id"] = merged["user_id"] if "user_id" in merged else self.user_id  # reliability-fix: FIX-5
            merged["turn_number"] = self._turn  # reliability-fix: FIX-5
            if self._budget_warning_active:  # reliability-fix: FIX-5
                merged["budget_warning"] = True  # reliability-fix: FIX-5
            result = await self._client.atrack(**merged)  # reliability-fix: FIX-5
            self._after_track(merged)  # reliability-fix: FIX-5
            spent = self._total_cost  # reliability-fix: FIX-5
            self._check_soft_budget(spent)  # reliability-fix: FIX-5
            self._check_hard_budget(spent)  # reliability-fix: FIX-5
        return result  # reliability-fix: FIX-5
