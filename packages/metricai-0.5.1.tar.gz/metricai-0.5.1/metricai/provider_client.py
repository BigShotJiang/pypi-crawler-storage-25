"""Central MetricAI proxy auth and provider SDK constructor kwargs."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .config import normalize_provider_for_proxy

METRICAI_KEY_PREFIXES = ("metricai_", "mtr_")


def is_metricai_api_key(value: str) -> bool:
    """True when *value* looks like a MetricAI platform API key (not a provider secret)."""
    v = (value or "").strip()
    return bool(v) and v.startswith(METRICAI_KEY_PREFIXES)


def build_metricai_auth_headers(api_key: str) -> Dict[str, str]:
    """
    MetricAI proxy authentication headers.

    Primary auth is ``Authorization: Bearer``; ``X-MetricAI-API-Key`` is a transitional alias.
    """
    key = api_key.strip()
    return {
        "Authorization": f"Bearer {key}",
        "X-MetricAI-API-Key": key,
    }


def apply_idempotency_headers(headers: Dict[str, str], idempotency_key: str) -> Dict[str, str]:
    """Emit both canonical and legacy idempotency header names (same value)."""
    headers["X-MetricAI-Idempotency-Key"] = idempotency_key
    headers["X-Idempotency-Key"] = idempotency_key
    return headers


def merge_proxy_default_headers(
    *,
    api_key: str,
    attribution_headers: Dict[str, str],
    extra_headers: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    """Full ``default_headers`` for provider SDK constructors."""
    merged: Dict[str, str] = {}
    merged.update(build_metricai_auth_headers(api_key))
    merged.update(attribution_headers)
    if extra_headers:
        merged.update(extra_headers)
    return merged


def build_provider_sdk_kwargs(
    provider: str,
    *,
    api_key: str,
    base_url: str,
    default_headers: Dict[str, str],
) -> Dict[str, Any]:
    """
    Constructor kwargs for official provider SDKs routed through MetricAI.

    OpenAI-shaped providers use ``api_key=`` (Bearer). Anthropic uses ``auth_token=`` (Bearer).
    *default_headers* should already include auth and attribution (from :func:`build_proxy_attribution_headers`).
    Raw ``Anthropic(api_key=metricai_…)`` also works when the proxy accepts MetricAI ``X-Api-Key``.
    """
    segment = normalize_provider_for_proxy(provider)
    if segment == "claude":
        return {
            "auth_token": api_key,
            "base_url": base_url,
            "default_headers": default_headers,
        }
    return {
        "api_key": api_key,
        "base_url": base_url,
        "default_headers": default_headers,
    }


def metricai_auth_credential_key(provider: str) -> str:
    """Key name in ``get_proxy_config()`` return dict: ``api_key`` or ``auth_token``."""
    segment = normalize_provider_for_proxy(provider)
    return "auth_token" if segment == "claude" else "api_key"
