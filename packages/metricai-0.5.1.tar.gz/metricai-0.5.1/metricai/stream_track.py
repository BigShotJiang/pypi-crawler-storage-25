"""Streaming LLM wrapper: accumulate chunks, latency, tokens; flush via ``track()``."""

from __future__ import annotations

import inspect
import json
import time
from typing import Any, Callable, Dict, Optional, Union


def _heuristic_tokens(text: str) -> int:
    if not text:
        return 0
    return max(1, len(text) // 4)


def _accumulate_openai_grok_chunk(chunk: Dict[str, Any], state: Dict[str, Any]) -> None:
    u = chunk.get("usage")
    if isinstance(u, dict) and (u.get("prompt_tokens") is not None or u.get("completion_tokens") is not None):
        if u.get("prompt_tokens") is not None:
            state["prompt_from_usage"] = int(u["prompt_tokens"])
        if u.get("completion_tokens") is not None:
            state["completion_from_usage"] = int(u["completion_tokens"])
    choices = chunk.get("choices") or []
    if choices:
        delta = choices[0].get("delta") or {}
        c = delta.get("content")
        if isinstance(c, str) and c:
            state["out_chars"] = state.get("out_chars", 0) + len(c)


def _accumulate_claude_chunk(chunk: Dict[str, Any], state: Dict[str, Any]) -> None:
    u = chunk.get("usage") or {}
    if isinstance(u, dict):
        if u.get("input_tokens") is not None:
            state["prompt_from_usage"] = int(u["input_tokens"])
        if u.get("output_tokens") is not None:
            state["completion_from_usage"] = int(u["output_tokens"])
    msg = chunk.get("message") or {}
    u2 = msg.get("usage") if isinstance(msg, dict) else None
    if isinstance(u2, dict):
        if u2.get("input_tokens") is not None:
            state["prompt_from_usage"] = int(u2["input_tokens"])
        if u2.get("output_tokens") is not None:
            state["completion_from_usage"] = int(u2["output_tokens"])
    delta = chunk.get("delta") or {}
    if isinstance(delta, dict):
        t = delta.get("text")
        if isinstance(t, str) and t:
            state["out_chars"] = state.get("out_chars", 0) + len(t)
    if chunk.get("type") == "content_block_delta":
        d = chunk.get("delta") or {}
        if isinstance(d, dict) and d.get("type") == "text_delta":
            t = d.get("text")
            if isinstance(t, str) and t:
                state["out_chars"] = state.get("out_chars", 0) + len(t)


def _accumulate_gemini_chunk(chunk: Dict[str, Any], state: Dict[str, Any]) -> None:
    um = chunk.get("usageMetadata") or {}
    if isinstance(um, dict):
        if um.get("promptTokenCount") is not None:
            state["prompt_from_usage"] = int(um["promptTokenCount"])
        if um.get("candidatesTokenCount") is not None:
            state["completion_from_usage"] = int(um["candidatesTokenCount"])
    cands = chunk.get("candidates") or []
    for c in cands:
        parts = (c.get("content") or {}).get("parts") or []
        for p in parts:
            t = p.get("text")
            if isinstance(t, str) and t:
                state["out_chars"] = state.get("out_chars", 0) + len(t)


def _accumulate_chunk(provider: str, chunk: Dict[str, Any], state: Dict[str, Any]) -> None:
    p = provider.lower()
    if p in ("openai", "grok"):
        _accumulate_openai_grok_chunk(chunk, state)
    elif p == "claude":
        _accumulate_claude_chunk(chunk, state)
    elif p == "gemini":
        _accumulate_gemini_chunk(chunk, state)
    else:
        _accumulate_openai_grok_chunk(chunk, state)


def _finalize_tokens(provider: str, state: Dict[str, Any]) -> tuple[int, int]:
    pin = state.get("prompt_from_usage")
    cout = state.get("completion_from_usage")
    out_chars = state.get("out_chars", 0)
    if pin is not None and cout is not None:
        return int(pin), int(cout)
    if cout is not None:
        return int(pin or 0), int(cout)
    if pin is not None:
        return int(pin), int(_heuristic_tokens(" " * out_chars) if out_chars else 0)
    return 0, _heuristic_tokens(" " * out_chars) if out_chars else 0


class StreamingTrackContext:
    """
    Wrap a streaming call: call ``feed_parsed_chunk`` or ``feed_sse_data_line`` for each event;
    on exit, sends one ``track()`` with stream metrics.

    Re-raises LLM/stream errors after flushing telemetry (HTTP remains fail-open).
    """

    def __init__(
        self,
        provider: str,
        track_fn: Callable[..., Any],
        track_kwargs: Dict[str, Any],
    ) -> None:
        self._provider = provider
        self._track_fn = track_fn
        self._track_kwargs = dict(track_kwargs)
        self._t0 = 0.0
        self._first_token_t: Optional[float] = None
        self._chunk_count = 0
        self._state: Dict[str, Any] = {}
        self._interrupted = False

    def __enter__(self) -> StreamingTrackContext:
        self._t0 = time.perf_counter()
        return self

    def _final_track_kwargs(self, exc_type: Any) -> Dict[str, Any]:
        end = time.perf_counter()
        total_ms = int((end - self._t0) * 1000)
        first_ms: Optional[int] = None
        if self._first_token_t is not None:
            first_ms = int((self._first_token_t - self._t0) * 1000)
        interrupted = self._interrupted or exc_type is not None
        pin, pout = _finalize_tokens(self._provider, self._state)
        if self._track_kwargs.get("input_tokens") is not None:
            pin = self._track_kwargs["input_tokens"]
        if self._track_kwargs.get("output_tokens") is not None:
            pout = self._track_kwargs["output_tokens"]
        manual_lat = self._track_kwargs.get("latency_ms")
        latency = manual_lat if manual_lat is not None else total_ms
        return {
            **self._track_kwargs,
            "provider": self._provider,
            "input_tokens": pin,
            "output_tokens": pout,
            "stream": True,
            "latency_ms": latency,
            "first_token_latency_ms": first_ms,
            "total_latency_ms": total_ms,
            "chunk_count": self._chunk_count,
            "stream_interrupted": interrupted,
        }

    def __exit__(self, exc_type, exc, tb) -> None:
        self._track_fn(**self._final_track_kwargs(exc_type))
        return False

    def mark_interrupted(self) -> None:
        self._interrupted = True

    def feed_sse_data_line(self, line: str) -> None:
        line = line.strip()
        if not line.startswith("data:"):
            return
        data = line[5:].strip()
        if data == "[DONE]":
            return
        try:
            chunk = json.loads(data)
        except json.JSONDecodeError:
            return
        self.feed_parsed_chunk(chunk)

    def feed_parsed_chunk(self, chunk: Union[Dict[str, Any], Any]) -> None:
        if not isinstance(chunk, dict):
            return
        if self._first_token_t is None:
            self._first_token_t = time.perf_counter()
        self._chunk_count += 1
        _accumulate_chunk(self._provider, chunk, self._state)


class AsyncStreamingTrackContext:
    """Async counterpart to :class:`StreamingTrackContext`."""

    def __init__(self, provider: str, track_fn: Callable[..., Any], track_kwargs: Dict[str, Any]):
        self._ctx = StreamingTrackContext(provider, track_fn, track_kwargs)

    async def __aenter__(self) -> AsyncStreamingTrackContext:
        self._ctx.__enter__()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        kw = self._ctx._final_track_kwargs(exc_type)
        res = self._track_fn(**kw)
        if inspect.isawaitable(res):
            await res

    def mark_interrupted(self) -> None:
        self._ctx.mark_interrupted()

    def feed_sse_data_line(self, line: str) -> None:
        self._ctx.feed_sse_data_line(line)

    def feed_parsed_chunk(self, chunk: Union[Dict[str, Any], Any]) -> None:
        self._ctx.feed_parsed_chunk(chunk)
