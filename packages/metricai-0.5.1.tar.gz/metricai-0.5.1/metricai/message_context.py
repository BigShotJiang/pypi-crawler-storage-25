"""Trim OpenAI-shaped message lists while preserving tool-call / tool-result linkage."""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from metricai.context_estimate import estimate_context_tokens


def estimate_messages_prompt_tokens(
    messages: List[Dict[str, Any]],
    tools: Optional[List[Dict[str, Any]]] = None,
    *,
    model: Optional[str] = None,
) -> int:
    """
    Heuristic prompt size: message text via :func:`metricai.context_estimate.estimate_context_tokens`
    plus serialized tool definitions and tool-call metadata.
    """
    base = estimate_context_tokens(messages, model=model)
    extra = 0
    for m in messages:
        tcs = m.get("tool_calls")
        if tcs:
            extra += len(json.dumps(tcs, default=str))
    if tools:
        extra += len(json.dumps(tools, default=str))
    return base + max(1, extra // 4)


def trim_messages_keep_recent_user_turns(
    messages: List[Dict[str, Any]],
    keep_recent_turns: int,
    *,
    preserve_leading_system: bool = True,
) -> List[Dict[str, Any]]:
    """
    Keep the system message (if any) and messages starting at the Nth-from-last user message.

    Preserves complete trailing segments so tool messages stay paired with their assistant
    ``tool_calls`` blocks.
    """
    if keep_recent_turns <= 0:
        return list(messages)

    system: List[Dict[str, Any]] = []
    body = messages
    if preserve_leading_system and messages and messages[0].get("role") == "system":
        system = [messages[0]]
        body = messages[1:]

    user_indices = [i for i, m in enumerate(body) if m.get("role") == "user"]
    if len(user_indices) <= keep_recent_turns:
        return system + body

    start = user_indices[-keep_recent_turns]
    return system + body[start:]
