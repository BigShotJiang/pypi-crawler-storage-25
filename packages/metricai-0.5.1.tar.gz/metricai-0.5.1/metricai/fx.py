"""USD→INR helpers for SDK account display (wallet stored in USD)."""

from __future__ import annotations

import os
from typing import Optional

import httpx

_DEFAULT_FX = 83.0


def usd_to_inr_from_env() -> float:
    raw = os.getenv("METRICAI_USD_INR_RATE")
    if raw is None:
        return _DEFAULT_FX
    try:
        rate = float(raw)
        return rate if rate > 0 else _DEFAULT_FX
    except (TypeError, ValueError):
        return _DEFAULT_FX


def fetch_usd_inr_rate(base_url: str, timeout: float = 10.0) -> float:
    """Read ``GET /v1/fx/usd-inr``; fall back to env/default on failure."""
    url = f"{base_url.rstrip('/')}/v1/fx/usd-inr"
    try:
        with httpx.Client(timeout=timeout) as client:
            response = client.get(url)
        response.raise_for_status()
        data = response.json()
        rate = float(data.get("rate") or 0)
        return rate if rate > 0 else usd_to_inr_from_env()
    except Exception:
        return usd_to_inr_from_env()
