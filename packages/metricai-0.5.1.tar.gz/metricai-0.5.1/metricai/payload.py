"""
Build telemetry JSON bodies for :meth:`metricai.client.MetricAI.track` from high-level parameters.

Merges optional :class:`~metricai.billing_event.BillingEvent` last so canonical schema fields win.

**Provider category:** N/A (transport payload).

**Fail-open:** N/A (pure serialization).
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional, Tuple

from .types import Modalities, OutcomeConfig, Tool

if TYPE_CHECKING:
    from .billing_event import BillingEvent

SERVER_SIDE_TOOL_TYPES = frozenset(
    {
        "web_search",
        "code_execution",
        "file_search",
        "image_generation",
        "computer_use",
    }
)
CLIENT_SIDE_TOOL_TYPES = frozenset(
    {
        "function_call",
        "mcp_tool",
        "retrieval",
    }
)

MODALITY_KEY_NAMES = {
    "text_tokens": "text",
    "image_count": "image",
    "audio_seconds": "audio",
    "pdf_pages": "pdf",
    "embedding_dimensions": "embedding",
    "video_seconds": "video",
}


def _modalities_present(modalities: Optional[Modalities]) -> List[str]:
    if not modalities:
        return []
    out: List[str] = []
    for key in (
        "text_tokens",
        "image_count",
        "audio_seconds",
        "pdf_pages",
        "embedding_dimensions",
        "video_seconds",
    ):
        if key not in modalities:
            continue
        val = modalities.get(key)  # type: ignore[union-attr]
        if val is not None:
            out.append(key)
    return out


def derive_dominant_modality(modalities: Optional[Modalities]) -> Optional[str]:
    keys = _modalities_present(modalities)
    if not keys:
        return None
    if keys == ["text_tokens"]:
        return "text"
    non_text = [k for k in keys if k != "text_tokens"]
    if len(non_text) == 0:
        return "text"
    if len(keys) > 1 or len(non_text) > 1:
        return "multimodal"
    return MODALITY_KEY_NAMES.get(non_text[0], non_text[0])


def derive_tool_fields(
    tools: Optional[List[Tool]],
) -> Tuple[Optional[int], Optional[str]]:
    if not tools:
        return None, None
    inv_count = sum(1 for t in tools if t.get("invoked") is True)
    server = False
    client = False
    for t in tools:
        ttype = (t.get("type") or "").strip()
        if not ttype:
            continue
        if ttype in SERVER_SIDE_TOOL_TYPES:
            server = True
        elif ttype in CLIENT_SIDE_TOOL_TYPES:
            client = True
    if server and client:
        et: Optional[str] = "mixed"
    elif server:
        et = "server_side"
    elif client:
        et = "client_side"
    else:
        et = None
    return inv_count, et


def compute_billable_inr(outcome: Optional[OutcomeConfig]) -> Optional[float]:
    if not outcome:
        return None
    success = outcome.get("success", False)
    if success:
        v = outcome.get("charge_on_success_inr")
        return float(v) if v is not None else None
    v = outcome.get("charge_on_failure_inr")
    if v is not None:
        return float(v)
    return 0.0


def outcome_charge_matched(outcome: Optional[OutcomeConfig], billable: Optional[float]) -> bool:
    """Whether the charge branch aligns with ``outcome.success``."""
    if not outcome:
        return True
    success = outcome.get("success", False)
    if success:
        return outcome.get("charge_on_success_inr") is not None and billable is not None
    return outcome.get("charge_on_failure_inr") is not None or billable == 0.0


def build_track_payload(
    *,
    event_type: Literal["turn", "session_close", "budget_warning"] = "turn",
    provider: Optional[str] = None,
    model: Optional[str] = None,
    input_tokens: Optional[int] = None,
    output_tokens: Optional[int] = None,
    stream: bool = False,
    session_id: Optional[str] = None,
    turn_number: Optional[int] = None,
    agent_id: Optional[str] = None,
    user_id: Optional[str] = None,
    context_tokens: Optional[int] = None,
    tools: Optional[List[Tool]] = None,
    modalities: Optional[Modalities] = None,
    outcome: Optional[OutcomeConfig] = None,
    simulate: bool = False,
    latency_ms: Optional[int] = None,
    cost_inr: Optional[float] = None,
    mcp_call: bool = False,
    budget_warning: bool = False,
    first_token_latency_ms: Optional[int] = None,
    total_latency_ms: Optional[int] = None,
    chunk_count: Optional[int] = None,
    stream_interrupted: Optional[bool] = None,
    success: Optional[bool] = None,
    extra: Optional[Dict[str, Any]] = None,
    billing_event: Optional["BillingEvent"] = None,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {"event_type": event_type}
    if provider is not None:
        body["provider"] = provider
    if model is not None:
        body["model"] = model
    if input_tokens is not None:
        body["input_tokens"] = input_tokens
    if output_tokens is not None:
        body["output_tokens"] = output_tokens
    if stream:
        body["streamed"] = True
    if session_id is not None:
        body["session_id"] = session_id
    if turn_number is not None:
        body["turn_number"] = turn_number
    if agent_id is not None:
        body["agent_id"] = agent_id
    if user_id is not None:
        body["user_id"] = user_id
    if context_tokens is not None:
        body["context_tokens"] = context_tokens
    if tools:
        body["tools"] = [dict(t) for t in tools]
        tic, et = derive_tool_fields(tools)
        if tic is not None:
            body["tool_invocation_count"] = tic
        if et is not None:
            body["execution_type"] = et
    if modalities:
        body["modalities"] = dict(modalities)
        dm = derive_dominant_modality(modalities)
        if dm is not None:
            body["dominant_modality"] = dm
    if outcome:
        body["outcome"] = dict(outcome)
        bill = compute_billable_inr(outcome)
        if bill is not None:
            body["billable_amount_inr"] = bill
    if simulate:
        body["simulated"] = True
    if latency_ms is not None:
        body["latency_ms"] = latency_ms
    if cost_inr is not None:
        body["cost_inr"] = cost_inr
    if mcp_call:
        body["mcp_call"] = True
    if budget_warning:
        body["budget_warning"] = True
    if first_token_latency_ms is not None:
        body["first_token_latency_ms"] = first_token_latency_ms
    if total_latency_ms is not None:
        body["total_latency_ms"] = total_latency_ms
    if chunk_count is not None:
        body["chunk_count"] = chunk_count
    if stream_interrupted is not None:
        body["stream_interrupted"] = stream_interrupted
    if success is not None:
        body["success"] = success
    if extra:
        body.update(extra)
    if billing_event is not None:
        # Canonical schema fields (schema_version, provider_category, cost_unit, …) — last write wins.
        body.update(billing_event.to_telemetry_dict())
    return body


def new_idempotency_key() -> str:
    return str(uuid.uuid4())
