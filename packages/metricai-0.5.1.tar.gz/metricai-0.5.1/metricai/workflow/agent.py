"""MetricAI-native agent loop using the OpenAI SDK against the MetricAI proxy."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Set, cast

from metricai.conversation_budget import ConversationBudgetRuntime
from metricai.message_context import estimate_messages_prompt_tokens, trim_messages_keep_recent_user_turns
from metricai.tool_output_policy import compact_tool_result
from metricai.types import AgentRunReport, GovernanceTerminationReason, ToolCallTraceEntry

if TYPE_CHECKING:
    from metricai.client import MetricAI


class AgentResponse:
    def __init__(
        self,
        content: str,
        usage: Any,
        model: str,
        iterations: int = 1,
        error: Optional[str] = None,
        *,
        run_report: Optional[AgentRunReport] = None,
    ) -> None:
        self.content = content
        self.usage = usage
        self.model = model
        self.iterations = iterations
        self.error = error
        self.run_report = run_report

    @property
    def input_tokens(self) -> int:
        return int(getattr(self.usage, "prompt_tokens", 0) or 0) if self.usage else 0

    @property
    def output_tokens(self) -> int:
        return int(getattr(self.usage, "completion_tokens", 0) or 0) if self.usage else 0

    def __repr__(self) -> str:
        return (
            f"AgentResponse(model={self.model!r}, "
            f"tokens={self.input_tokens}+{self.output_tokens}, "
            f"iterations={self.iterations})"
        )


class MetricAIAgent:
    """Tool-capable agent using :meth:`MetricAI.openai_sdk` with optional governance v1."""

    def __init__(
        self,
        client: "MetricAI",
        agent_id: str,
        user_id: str,
        *,
        provider: str = "openai",
        model: str = "gpt-4o",
        system_prompt: Optional[str] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        budget_cap_inr: Optional[float] = None,
        billing_mode: str = "hybrid",
        max_iterations: int = 10,
        max_conversation_tokens: Optional[int] = None,
        max_tool_calls: Optional[int] = None,
        max_single_tool_result_tokens: Optional[int] = None,
        keep_recent_turns: Optional[int] = None,
        tool_result_preserve_keys: Optional[Set[str]] = None,
    ) -> None:
        self.client = client
        self.agent_id = agent_id
        self.user_id = user_id
        self.provider = provider.lower().strip()
        self.model = model
        self.system_prompt = system_prompt
        self.tools = list(tools or [])
        self.budget_cap_inr = budget_cap_inr
        self.billing_mode = billing_mode
        self.max_iterations = max_iterations
        self.max_conversation_tokens = max_conversation_tokens
        self.max_tool_calls = max_tool_calls
        self.max_single_tool_result_tokens = max_single_tool_result_tokens
        self.keep_recent_turns = keep_recent_turns
        self.tool_result_preserve_keys = tool_result_preserve_keys
        self._history: List[Dict[str, Any]] = []

    def _governance_enabled(self) -> bool:
        return any(
            [
                self.max_conversation_tokens is not None,
                self.max_tool_calls is not None,
                self.max_single_tool_result_tokens is not None,
                self.keep_recent_turns is not None,
            ]
        )

    def _get_llm_client(self, session_id: Optional[str] = None) -> Any:
        if self.provider != "openai":
            raise ValueError("MetricAIAgent currently supports provider='openai' only")
        kw: Dict[str, Any] = {
            "session_id": session_id,
            "billing_mode": self.billing_mode,
            "budget_cap_inr": self.budget_cap_inr,
        }
        return self.client.openai_sdk(self.agent_id, self.user_id, **kw)

    def run(self, message: str, session_id: Optional[str] = None) -> AgentResponse:
        if self._governance_enabled():
            return self._run_governed(message, session_id=session_id)
        return self._run_legacy(message, session_id=session_id)

    def _run_legacy(self, message: str, session_id: Optional[str] = None) -> AgentResponse:
        llm = self._get_llm_client(session_id=session_id)
        self._history.append({"role": "user", "content": message})

        messages: List[Dict[str, Any]] = []
        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})
        messages.extend(self._history)

        iteration = 0
        while iteration < self.max_iterations:
            kwargs: Dict[str, Any] = {"model": self.model, "messages": messages}
            if self.tools:
                kwargs["tools"] = self.tools

            response = llm.chat.completions.create(**kwargs)
            choice = response.choices[0]
            usage = getattr(response, "usage", None)

            if choice.finish_reason == "tool_calls" and getattr(choice.message, "tool_calls", None):
                msg = choice.message
                if hasattr(msg, "model_dump"):
                    messages.append(msg.model_dump(exclude_none=True))
                else:
                    messages.append(
                        {
                            "role": "assistant",
                            "content": msg.content,
                            "tool_calls": msg.tool_calls,
                        }
                    )
                for tc in choice.message.tool_calls:
                    tool_result = self._execute_tool(tc)
                    messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": str(tool_result),
                        }
                    )
                iteration += 1
                continue

            final_content = choice.message.content or ""
            self._history.append({"role": "assistant", "content": final_content})
            return AgentResponse(
                content=final_content,
                usage=usage,
                model=self.model,
                iterations=iteration + 1,
            )

        return AgentResponse(
            content="Max iterations reached.",
            usage=None,
            model=self.model,
            iterations=self.max_iterations,
            error="max_iterations_exceeded",
        )

    def _run_governed(self, message: str, session_id: Optional[str] = None) -> AgentResponse:
        llm = self._get_llm_client(session_id=session_id)
        self._history.append({"role": "user", "content": message})

        messages: List[Dict[str, Any]] = []
        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})
        messages.extend(self._history)

        budget = ConversationBudgetRuntime(max_conversation_tokens=self.max_conversation_tokens)
        tool_calls_used = 0
        tool_trace: List[ToolCallTraceEntry] = []
        iteration = 0
        llm_calls_made = 0
        last_usage: Any = None
        termination: GovernanceTerminationReason = "completed"

        while iteration < self.max_iterations:
            if self.keep_recent_turns is not None:
                messages = trim_messages_keep_recent_user_turns(
                    messages,
                    int(self.keep_recent_turns),
                    preserve_leading_system=True,
                )

            if self.max_conversation_tokens is not None:
                est = estimate_messages_prompt_tokens(messages, self.tools, model=self.model)
                if budget.would_exceed_after(est):
                    termination = "insufficient_remaining_budget_for_request"
                    report = self._build_run_report(
                        budget,
                        llm_calls_made,
                        tool_calls_used,
                        tool_trace,
                        termination,
                        last_usage,
                    )
                    return AgentResponse(
                        content="Conversation token budget insufficient for this request (estimated).",
                        usage=last_usage,
                        model=self.model,
                        iterations=llm_calls_made,
                        error=termination,
                        run_report=report,
                    )

            kwargs: Dict[str, Any] = {"model": self.model, "messages": messages}
            if self.tools:
                kwargs["tools"] = self.tools

            response = llm.chat.completions.create(**kwargs)
            llm_calls_made += 1
            choice = response.choices[0]
            last_usage = getattr(response, "usage", None)
            budget.record_llm_usage(last_usage)

            if budget.assert_under_hard_cap():
                termination = "conversation_token_budget_exceeded"
                report = self._build_run_report(
                    budget,
                    llm_calls_made,
                    tool_calls_used,
                    tool_trace,
                    termination,
                    last_usage,
                )
                return AgentResponse(
                    content="Conversation token budget exceeded.",
                    usage=last_usage,
                    model=self.model,
                    iterations=llm_calls_made,
                    error=termination,
                    run_report=report,
                )

            if choice.finish_reason == "tool_calls" and getattr(choice.message, "tool_calls", None):
                tclist = list(choice.message.tool_calls)
                if self.max_tool_calls is not None:
                    if tool_calls_used + len(tclist) > int(self.max_tool_calls):
                        termination = "tool_call_limit_exceeded"
                        report = self._build_run_report(
                            budget,
                            llm_calls_made,
                            tool_calls_used,
                            tool_trace,
                            termination,
                            last_usage,
                        )
                        return AgentResponse(
                            content="Tool call limit exceeded.",
                            usage=last_usage,
                            model=self.model,
                            iterations=llm_calls_made,
                            error=termination,
                            run_report=report,
                        )

                msg = choice.message
                if hasattr(msg, "model_dump"):
                    messages.append(msg.model_dump(exclude_none=True))
                else:
                    messages.append(
                        {
                            "role": "assistant",
                            "content": msg.content,
                            "tool_calls": msg.tool_calls,
                        }
                    )
                for tc in tclist:
                    t0 = time.perf_counter()
                    tool_result = self._execute_tool(tc)
                    text, truncated, inj = compact_tool_result(
                        tool_result,
                        max_single_tool_result_tokens=self.max_single_tool_result_tokens,
                        preserve_keys=self.tool_result_preserve_keys,
                    )
                    latency_ms = int((time.perf_counter() - t0) * 1000)
                    tool_calls_used += 1
                    name = getattr(getattr(tc, "function", None), "name", "") or ""
                    tid = getattr(tc, "id", None)
                    tool_trace.append(
                        {
                            "name": name,
                            "tool_call_id": tid,
                            "tokens_injected": inj,
                            "truncated": truncated,
                            "latency_ms": latency_ms,
                        }
                    )
                    messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": text,
                        }
                    )
                iteration += 1
                continue

            final_content = choice.message.content or ""
            self._history.append({"role": "assistant", "content": final_content})
            termination = "completed"
            report = self._build_run_report(
                budget,
                llm_calls_made,
                tool_calls_used,
                tool_trace,
                termination,
                last_usage,
            )
            return AgentResponse(
                content=final_content,
                usage=last_usage,
                model=self.model,
                iterations=llm_calls_made,
                run_report=report,
            )

        termination = "max_iterations_exceeded"
        report = self._build_run_report(
            budget,
            llm_calls_made,
            tool_calls_used,
            tool_trace,
            termination,
            last_usage,
        )
        return AgentResponse(
            content="Max iterations reached.",
            usage=last_usage,
            model=self.model,
            iterations=llm_calls_made,
            error="max_iterations_exceeded",
            run_report=report,
        )

    def _build_run_report(
        self,
        budget: ConversationBudgetRuntime,
        llm_calls_made: int,
        tool_calls_used: int,
        tool_trace: List[ToolCallTraceEntry],
        termination: GovernanceTerminationReason,
        last_usage: Any,
    ) -> AgentRunReport:
        return cast(
            AgentRunReport,
            {
                "termination_reason": termination,
                "iterations_used": llm_calls_made,
                "tool_calls_used": tool_calls_used,
                "per_step_usage": budget.per_step_usage,
                "aggregated_usage": budget.aggregated_usage,
                "budget_status": budget.budget_status(),
                "tool_trace": list(tool_trace),
            },
        )

    def _execute_tool(self, tool_call: Any) -> Any:
        return f"Tool {tool_call.function.name} executed."

    def add_tool(
        self,
        tool_fn: Callable[..., Any],
        name: str,
        description: str,
        parameters: Dict[str, Any],
    ) -> "MetricAIAgent":
        _ = tool_fn
        self.tools.append(
            {
                "type": "function",
                "function": {
                    "name": name,
                    "description": description,
                    "parameters": parameters,
                },
            }
        )
        return self
