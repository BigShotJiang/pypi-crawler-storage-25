"""Sequential multi-agent pipeline sharing one ``session_id``."""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Dict, List, Optional

if TYPE_CHECKING:
    from metricai.client import MetricAI
    from metricai.workflow.agent import AgentResponse, MetricAIAgent


class PipelineResult:
    def __init__(
        self,
        final_output: str,
        stage_outputs: List["AgentResponse"],
        stage_costs: Dict[str, float],
        pipeline_id: str,
    ) -> None:
        self.final_output = final_output
        self.stage_outputs = stage_outputs
        self.stage_costs = stage_costs
        self.pipeline_id = pipeline_id


class MetricAIPipeline:
    """Run :class:`~metricai.workflow.agent.MetricAIAgent` instances in order under one session."""

    def __init__(
        self,
        client: "MetricAI",
        pipeline_id: str,
        user_id: str,
        agents: List["MetricAIAgent"],
        budget_cap_inr: Optional[float] = None,
    ) -> None:
        self.client = client
        self.pipeline_id = pipeline_id
        self.user_id = user_id
        self.agents = agents
        self.budget_cap_inr = budget_cap_inr
        self._stage_costs: Dict[str, float] = {}

    def run(self, initial_input: str) -> PipelineResult:
        from metricai.workflow.agent import AgentResponse

        session_id = str(uuid.uuid4())
        current = initial_input
        outputs: List[AgentResponse] = []

        for agent in self.agents:
            resp = agent.run(current, session_id=session_id)
            outputs.append(resp)
            self._stage_costs[agent.agent_id] = 0.0
            current = resp.content

        return PipelineResult(
            final_output=current,
            stage_outputs=outputs,
            stage_costs=self._stage_costs,
            pipeline_id=self.pipeline_id,
        )
