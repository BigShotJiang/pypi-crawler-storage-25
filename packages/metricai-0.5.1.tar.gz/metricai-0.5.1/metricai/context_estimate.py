"""Heuristic context size estimation for developers (not required for billing)."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union


def estimate_context_tokens(messages: List[Dict[str, Any]], model: Optional[str] = None) -> int:
    """
    Rough token estimate: ~4 characters per token over serialized message text.

    ``model`` is reserved for future tokenizer-specific estimates.
    """
    _ = model
    total_chars = 0
    for m in messages:
        content = m.get("content")
        total_chars += _content_chars(content)
    if total_chars <= 0:
        return 0
    return max(1, total_chars // 4)


def _content_chars(content: Union[str, List[Dict[str, Any]], None]) -> int:
    if content is None:
        return 0
    if isinstance(content, str):
        return len(content)
    if isinstance(content, list):
        n = 0
        for part in content:
            if not isinstance(part, dict):
                continue
            if "text" in part and isinstance(part["text"], str):
                n += len(part["text"])
        return n
    return 0
