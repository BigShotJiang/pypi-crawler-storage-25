"""Conversation-level token budget runtime for governance v1."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from metricai.types import NormalizedLLMUsage, TokenBudgetStatus

from metricai.usage_normalizer import merge_normalized_usage, normalize_llm_usage


@dataclass
class ConversationBudgetRuntime:
    """Tracks cumulative normalized usage against ``max_conversation_tokens``."""

    max_conversation_tokens: Optional[int] = None
    _aggregated: NormalizedLLMUsage = field(
        default_factory=lambda: normalize_llm_usage(None, usage_source="unknown")
    )
    _per_step: List[NormalizedLLMUsage] = field(default_factory=list)

    def record_llm_usage(self, usage: object) -> None:
        step = normalize_llm_usage(usage, usage_source="provider")
        self._per_step.append(step)
        self._aggregated = merge_normalized_usage(self._aggregated, step)

    def used_total_tokens(self) -> int:
        return int(self._aggregated.get("total_tokens") or 0) or (
            int(self._aggregated.get("input_tokens") or 0) + int(self._aggregated.get("output_tokens") or 0)
        )

    def remaining_tokens(self) -> Optional[int]:
        if self.max_conversation_tokens is None:
            return None
        return max(0, int(self.max_conversation_tokens) - self.used_total_tokens())

    def budget_status(self) -> TokenBudgetStatus:
        used_in = int(self._aggregated.get("input_tokens") or 0)
        used_out = int(self._aggregated.get("output_tokens") or 0)
        used_tot = self.used_total_tokens()
        out: TokenBudgetStatus = {
            "used_input_tokens": used_in,
            "used_output_tokens": used_out,
            "used_total_tokens": used_tot,
        }
        if self.max_conversation_tokens is not None:
            out["max_conversation_tokens"] = int(self.max_conversation_tokens)
            out["remaining_tokens"] = self.remaining_tokens()
        return out

    def would_exceed_after(self, additional_tokens: int) -> bool:
        if self.max_conversation_tokens is None:
            return False
        return self.used_total_tokens() + max(0, additional_tokens) > int(self.max_conversation_tokens)

    def assert_under_hard_cap(self) -> bool:
        """Return True if already at or over cap (caller should terminate)."""
        if self.max_conversation_tokens is None:
            return False
        return self.used_total_tokens() >= int(self.max_conversation_tokens)

    @property
    def per_step_usage(self) -> List[NormalizedLLMUsage]:
        return list(self._per_step)

    @property
    def aggregated_usage(self) -> NormalizedLLMUsage:
        return dict(self._aggregated)
