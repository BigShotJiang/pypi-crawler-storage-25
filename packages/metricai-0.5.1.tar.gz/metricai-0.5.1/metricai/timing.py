"""Wall-clock helper for attaching ``latency_ms`` to ``track()``."""

from __future__ import annotations

import time
from typing import Optional


class TimedCall:
    """Context manager; after exit, ``elapsed_ms`` is set."""

    __slots__ = ("_t0", "elapsed_ms")

    def __init__(self) -> None:
        self._t0: float = 0.0
        self.elapsed_ms: int = 0

    def __enter__(self) -> TimedCall:
        self._t0 = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc, tb) -> Optional[bool]:
        self.elapsed_ms = int((time.perf_counter() - self._t0) * 1000)
        return None


def timed_call() -> TimedCall:
    """Measure an LLM call, then pass ``latency_ms=t.elapsed_ms`` to ``track()``."""
    return TimedCall()
