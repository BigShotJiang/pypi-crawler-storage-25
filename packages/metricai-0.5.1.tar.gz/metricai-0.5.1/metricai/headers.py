"""MetricAI proxy attribution headers (``X-Agent-ID``, ``X-User-ID``, etc.)."""

from __future__ import annotations

import uuid
from typing import Dict, Optional

from .payload import new_idempotency_key


def build_proxy_attribution_headers(
    *,
    api_key: str,
    agent_id: Optional[str],
    user_id: Optional[str],
    session_id: Optional[str] = None,
    billing_mode: Optional[str] = None,
    default_billing_mode: str = "hybrid",
    budget_cap_inr: Optional[float] = None,
    default_budget_cap_inr: Optional[float] = None,
    idempotency_key: Optional[str] = None,
    key_mode: str = "byok",
    graph_id: Optional[str] = None,
    node_id: Optional[str] = None,
    crew_id: Optional[str] = None,
    task_id: Optional[str] = None,
    outcome_rule_id: Optional[str] = None,
    outcome_threshold: Optional[float] = None,
) -> Dict[str, str]:
    """
    Headers for LLM calls through the MetricAI proxy.

    Proxy auth is via ``Authorization: Bearer`` (set automatically when the provider SDK
    uses ``api_key=<METRICAI_API_KEY>``). ``X-MetricAI-API-Key`` is a transitional alias.
    """
    sid = session_id or str(uuid.uuid4())
    ikey = idempotency_key or new_idempotency_key()
    bill = billing_mode or default_billing_mode
    resolved_agent_id = agent_id or "untagged"
    resolved_user_id = user_id or "anonymous"

    from .provider_client import apply_idempotency_headers, build_metricai_auth_headers

    headers: Dict[str, str] = {
        **build_metricai_auth_headers(api_key),
        "X-Agent-ID": resolved_agent_id,
        "X-User-ID": str(resolved_user_id),
        "X-Session-ID": sid,
        "X-Billing-Mode": bill,
    }
    apply_idempotency_headers(headers, ikey)
    if key_mode == "managed":
        headers["X-Key-Mode"] = "managed"

    cap = budget_cap_inr if budget_cap_inr is not None else default_budget_cap_inr
    if cap is not None:
        headers["X-Budget-Cap-INR"] = str(cap)

    if graph_id:
        headers["X-Graph-ID"] = graph_id
    if node_id:
        headers["X-Node-ID"] = node_id
    if crew_id:
        headers["X-Crew-ID"] = crew_id
    if task_id:
        headers["X-Task-ID"] = task_id
    if outcome_rule_id:
        headers["X-Outcome-Rule-ID"] = outcome_rule_id
    if outcome_threshold is not None:
        headers["X-Outcome-Threshold"] = str(outcome_threshold)

    return headers
