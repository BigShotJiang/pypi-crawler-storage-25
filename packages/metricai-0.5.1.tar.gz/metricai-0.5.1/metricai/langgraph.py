"""LangGraph helpers for MetricAI attribution."""

from __future__ import annotations

from functools import wraps
from typing import Any, Callable, Dict, Optional, TypeVar, cast

from metricai.context import attribution_scope
from metricai.headers import build_proxy_attribution_headers

F = TypeVar("F", bound=Callable[..., Any])


def _state_value(state: Any, key: str) -> Optional[str]:
    if isinstance(state, dict):
        value = state.get(key)
        return str(value) if value is not None else None
    value = getattr(state, key, None)
    return str(value) if value is not None else None


def _with_metricai_headers(state: Any, headers: Dict[str, str]) -> Any:
    if isinstance(state, dict):
        updated = dict(state)
        existing = updated.get("metricai_headers")
        if isinstance(existing, dict):
            updated["metricai_headers"] = {**existing, **headers}
        else:
            updated["metricai_headers"] = headers
        return updated
    return state


def metricai_node(
    *,
    agent_id: str,
    metricai_key: str,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    graph_id: Optional[str] = None,
    node_id: Optional[str] = None,
    environment: Optional[str] = None,
    billing_mode: Optional[str] = None,
    budget_cap_inr: Optional[float] = None,
    outcome_rule_id: Optional[str] = None,
    outcome_threshold: Optional[float] = None,
    idempotency_key: Optional[str] = None,
) -> Callable[[F], F]:
    """
    Decorate a LangGraph node with request-scoped MetricAI attribution.

    The wrapper reads ``state["user_id"]`` when ``user_id`` is not provided and exposes
    the generated headers as ``state["metricai_headers"]`` for nodes that pass
    per-request headers manually.
    """

    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(state: Any, *args: Any, **kwargs: Any) -> Any:
            resolved_user_id = user_id or _state_value(state, "user_id") or "anonymous"
            resolved_session_id = session_id or _state_value(state, "session_id")
            headers = build_proxy_attribution_headers(
                api_key=metricai_key,
                agent_id=agent_id,
                user_id=resolved_user_id,
                session_id=resolved_session_id,
                billing_mode=billing_mode,
                budget_cap_inr=budget_cap_inr,
                graph_id=graph_id,
                node_id=node_id or getattr(func, "__name__", None),
                outcome_rule_id=outcome_rule_id,
                outcome_threshold=outcome_threshold,
                idempotency_key=idempotency_key,
            )
            if environment:
                headers["X-Environment"] = environment

            enriched_state = _with_metricai_headers(state, headers)
            with attribution_scope(
                agent_id=agent_id,
                user_id=resolved_user_id,
                session_id=headers.get("X-Session-ID"),
            ):
                return func(enriched_state, *args, **kwargs)

        return cast(F, wrapper)

    return decorator


__all__ = ["metricai_node"]
