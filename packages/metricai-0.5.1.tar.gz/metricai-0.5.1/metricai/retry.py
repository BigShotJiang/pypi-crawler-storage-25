from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class RetryConfig:
    max_retries: int = 2
    backoff_factor: float = 1.5
    max_backoff_seconds: float = 30.0
    retry_on_provider_errors: bool = True
    retry_on_proxy_errors: bool = True
    use_idempotency_keys: bool = True


@dataclass(frozen=True)
class QuotaStatus:
    plan: str
    requests_used: int
    quota_limit: int
    requests_remaining: int
    overage_requests: int
    cycle_end_date: str


def retry_config_from_env() -> RetryConfig:
    max_retries = _int_env("METRICAI_MAX_RETRIES", 2)
    backoff_factor = _float_env("METRICAI_BACKOFF_FACTOR", 1.5)
    max_backoff_seconds = _float_env("METRICAI_MAX_BACKOFF_SECONDS", 30.0)
    return RetryConfig(
        max_retries=max(max_retries, 0),
        backoff_factor=max(backoff_factor, 1.0),
        max_backoff_seconds=max(max_backoff_seconds, 1.0),
    )


def _int_env(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _float_env(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return float(raw)
    except ValueError:
        return default
