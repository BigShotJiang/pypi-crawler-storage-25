"""MetricAI SDK configuration and proxy URL helpers."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Dict, Literal, Optional, Tuple

from .routing_sdk import RoutingConfig

DEFAULT_PROXY_BASE_URL = "https://proxy.metricai.co.in"
SUPPORTED_PROVIDERS = ("openai", "anthropic", "gemini", "bedrock", "grok", "tavily")

# Map spec / common names to HTTP proxy path segment under /v1/proxy/{segment}.
_SPEC_TO_PROXY_PATH: Dict[str, str] = {
    "openai": "openai",
    "anthropic": "claude",
    "claude": "claude",
    "gemini": "gemini",
    "bedrock": "bedrock",
    "groq": "grok",
    "grok": "grok",
    "tavily": "tavily",
}

# Legacy alias kept for normalize_provider_for_proxy name.
_SPEC_TO_INTERNAL = _SPEC_TO_PROXY_PATH


def normalize_provider_for_proxy(name: str) -> str:
    """Map spec names (e.g. ``anthropic``, ``groq``) to proxy path segment (``claude``, ``grok``)."""
    key = (name or "").strip().lower()
    if key not in _SPEC_TO_INTERNAL:
        supported = ", ".join(sorted(set(_SPEC_TO_INTERNAL.keys())))
        raise ValueError(f"Unsupported provider: {name!r}. Supported: {supported}")
    return _SPEC_TO_INTERNAL[key]


# Map ``llm_keys`` dict keys to HTTP headers the MetricAI proxy accepts for BYOK.
LLM_KEY_TO_HEADER: Dict[str, str] = {
    "openai": "X-OpenAI-API-Key",
    "anthropic": "X-Claude-API-Key",
    "claude": "X-Claude-API-Key",
    "gemini": "X-Gemini-API-Key",
    "bedrock": "X-Bedrock-API-Key",
    "groq": "X-Grok-API-Key",
    "grok": "X-Grok-API-Key",
}


def llm_keys_to_proxy_headers(llm_keys: Optional[Dict[str, str]]) -> Dict[str, str]:
    """Turn ``llm_keys`` from :class:`MetricAIConfig` into extra proxy headers."""
    if not llm_keys:
        return {}
    out: Dict[str, str] = {}
    for provider, secret in llm_keys.items():
        if not secret:
            continue
        p = (provider or "").strip().lower()
        header = LLM_KEY_TO_HEADER.get(p)
        if not header:
            raise ValueError(
                f"Unknown llm_keys provider {provider!r}. "
                f"Known: {', '.join(sorted(set(LLM_KEY_TO_HEADER.keys())))}"
            )
        out[header] = secret
    return out


@dataclass
class MetricAIConfig:
    """SDK defaults for proxy routing, BYOK vs managed, and billing-related headers."""

    api_key: str
    mode: Literal["byok", "managed"] = "byok"
    llm_keys: Dict[str, str] = field(default_factory=dict)
    proxy_base_url: str = DEFAULT_PROXY_BASE_URL
    environment: Literal["production", "sandbox"] = "production"
    default_billing_mode: Literal["usage", "outcome", "hybrid"] = "hybrid"
    default_budget_cap_inr: Optional[float] = None
    fail_open: bool = True
    #: Default agent id when integrations do not supply one (set via :func:`metricai.runtime.init`).
    default_agent_id: str = "default-agent"
    #: Optional deploy/stage label (e.g. ``production``, ``staging``); forwarded in telemetry extras.
    environment_tag: Optional[str] = None
    #: Provider ids for hook-based integrations (Bedrock/Tavily). ``None`` = all; ``()`` = none.
    active_providers: Optional[Tuple[str, ...]] = None
    #: Optional per-request routing hints (headers); policies are stored via :class:`~metricai.routing_sdk.RoutingManager`.
    routing: Optional[RoutingConfig] = None

    def proxy_url_for(self, provider: str) -> str:
        """Full base URL for provider SDK ``base_url`` (OpenAI-compatible layout)."""
        segment = normalize_provider_for_proxy(provider)
        base = self.proxy_base_url.rstrip("/")
        return f"{base}/v1/proxy/{segment}"


def resolve_proxy_base_url(explicit: Optional[str]) -> str:
    return (explicit or os.getenv("METRICAI_PROXY_URL") or DEFAULT_PROXY_BASE_URL).rstrip("/")


def resolve_api_base_url(explicit: Optional[str], *, proxy_base_url: str) -> str:
    """Telemetry and REST API host (defaults to proxy host)."""
    return (
        explicit
        or os.getenv("METRICAI_API_URL")
        or os.getenv("METRICAI_BASE_URL")
        or proxy_base_url
    ).rstrip("/")
