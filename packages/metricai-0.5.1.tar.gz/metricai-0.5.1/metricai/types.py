"""Pydantic models for REST API responses and TypedDicts for telemetry/track payloads."""

from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional, TypedDict

from pydantic import BaseModel
from typing_extensions import NotRequired


# ---------------------------------------------------------------------------
# TypedDicts — track / telemetry payloads (developer hints & structured docs)
# ---------------------------------------------------------------------------

ToolType = Literal[
    "web_search",
    "code_execution",
    "file_search",
    "image_generation",
    "computer_use",
    "function_call",
    "mcp_tool",
    "retrieval",
]


class Tool(TypedDict):
    """Tool/function entry for tool intelligence metering."""

    name: str
    type: NotRequired[str]
    invoked: NotRequired[bool]
    provider: NotRequired[str]


class OutcomeConfig(TypedDict):
    """Outcome-based billing fields."""

    success: bool
    outcome_type: NotRequired[str]
    charge_on_success_inr: NotRequired[float]
    charge_on_failure_inr: NotRequired[float]


class OutcomeConfigModel(BaseModel):
    """Validated outcome billing configuration."""

    success: bool
    outcome_type: Optional[str] = None
    charge_on_success_inr: Optional[float] = None
    charge_on_failure_inr: Optional[float] = None

    @classmethod
    def success_charge(cls, *, charge_inr: float, outcome_type: Optional[str] = None) -> "OutcomeConfigModel":
        return cls(success=True, charge_on_success_inr=charge_inr, outcome_type=outcome_type)

    @classmethod
    def failure_charge(cls, *, charge_inr: float = 0.0, outcome_type: Optional[str] = None) -> "OutcomeConfigModel":
        return cls(success=False, charge_on_failure_inr=charge_inr, outcome_type=outcome_type)

    @classmethod
    def hybrid(
        cls,
        *,
        success_charge_inr: float,
        base_charge_inr: float = 0.0,
        outcome_type: Optional[str] = None,
    ) -> "OutcomeConfigModel":
        return cls(
            success=True,
            charge_on_success_inr=success_charge_inr,
            charge_on_failure_inr=base_charge_inr,
            outcome_type=outcome_type,
        )

    def to_outcome_dict(self) -> OutcomeConfig:
        data: OutcomeConfig = {"success": self.success}
        if self.outcome_type is not None:
            data["outcome_type"] = self.outcome_type
        if self.charge_on_success_inr is not None:
            data["charge_on_success_inr"] = self.charge_on_success_inr
        if self.charge_on_failure_inr is not None:
            data["charge_on_failure_inr"] = self.charge_on_failure_inr
        return data


class Modalities(TypedDict, total=False):
    """Per-modality usage for multimodal billing."""

    text_tokens: int
    image_count: int
    audio_seconds: float
    pdf_pages: int
    embedding_dimensions: int
    video_seconds: float


class TrackResult(TypedDict, total=False):
    """Returned from ``MetricAI.track()`` when the event was accepted (non-simulate)."""

    ok: bool
    status_code: int


class SimulationResult(TypedDict):
    """Returned when ``simulate=True`` on ``track()``."""

    would_charge_inr: float
    outcome_matched: bool
    """True when the applied charge branch matches ``outcome.success`` (success path vs failure path)."""


class BudgetStatus(TypedDict, total=False):
    """Optional snapshot of budget state (e.g. for debugging)."""

    spent_inr: float
    max_budget_inr: NotRequired[float]
    soft_budget_inr: NotRequired[float]
    warning_active: bool


class SessionToolSummary(TypedDict, total=False):
    """Aggregated tool stats included in ``session_close``."""

    total_tool_calls: int
    tool_types_used: list[str]
    dominant_execution_type: NotRequired[Optional[str]]


class SessionSummary(TypedDict, total=False):
    """Shape of fields sent on session close (reference for consumers)."""

    session_id: str
    total_turns: int
    total_input_tokens: int
    total_output_tokens: int
    total_cost_inr: NotRequired[Optional[float]]
    cumulative_context_tokens: int
    session_duration_ms: int
    status: Literal["completed", "error", "budget_exceeded"]
    session_tool_summary: NotRequired[SessionToolSummary]


# ---------------------------------------------------------------------------
# Pydantic — HTTP response models (unchanged contract)
# ---------------------------------------------------------------------------


class SessionState(BaseModel):
    session_id: str
    agent_id: Optional[str] = None
    user_id: Optional[str] = None
    turn_count: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cumulative_context: int = 0
    total_cost_inr: float = 0.0
    context_efficiency: Optional[float] = None  # output / cumulative_context
    avg_cost_per_turn: Optional[float] = None
    status: str = "active"
    started_at: Optional[datetime] = None
    last_activity_at: Optional[datetime] = None


class SessionTurn(BaseModel):
    turn_number: int
    provider: str
    model: str
    input_tokens: int
    output_tokens: int
    context_tokens: int
    cost_inr: float
    latency_ms: Optional[int] = None
    streamed: bool = False
    created_at: Optional[datetime] = None


class SessionDetail(BaseModel):
    session: SessionState
    turns: list[SessionTurn]


class WalletBalance(BaseModel):
    balance_inr: float
    currency: str = "INR"


class UsageStats(BaseModel):
    total_tokens: int
    input_tokens: int
    output_tokens: int
    total_cost_inr: float
    request_count: int


# ---------------------------------------------------------------------------
# Governance v1 — conversation budgets, tool loops, run reports
# ---------------------------------------------------------------------------

GovernanceTerminationReason = Literal[
    "completed",
    "max_iterations_exceeded",
    "conversation_token_budget_exceeded",
    "tool_call_limit_exceeded",
    "insufficient_remaining_budget_for_request",
]


class NormalizedLLMUsage(TypedDict, total=False):
    """Cross-provider usage snapshot (additive fields; ints optional per provider)."""

    input_tokens: int
    output_tokens: int
    total_tokens: int
    reasoning_tokens: int
    cache_read_tokens: int
    cache_write_tokens: int
    usage_source: Literal["provider", "estimated", "unknown"]
    raw: dict


class TokenBudgetStatus(TypedDict, total=False):
    """Conversation token budget snapshot after a run or step."""

    max_conversation_tokens: NotRequired[int]
    used_input_tokens: int
    used_output_tokens: int
    used_total_tokens: int
    remaining_tokens: NotRequired[int]


class ToolCallTraceEntry(TypedDict, total=False):
    """One tool invocation record for AgentRunReport."""

    name: str
    tool_call_id: NotRequired[str]
    tokens_injected: int
    truncated: bool
    latency_ms: NotRequired[int]


class AgentRunReport(TypedDict, total=False):
    """Structured result from a governed :class:`~metricai.workflow.agent.MetricAIAgent` run."""

    termination_reason: GovernanceTerminationReason
    iterations_used: int
    tool_calls_used: int
    per_step_usage: list[NormalizedLLMUsage]
    aggregated_usage: NormalizedLLMUsage
    budget_status: TokenBudgetStatus
    tool_trace: list[ToolCallTraceEntry]


class GovernanceBudgetPolicy(TypedDict, total=False):
    """Optional conversation-level token cap (whole workflow, not single generation)."""

    max_conversation_tokens: int


class GovernanceToolPolicy(TypedDict, total=False):
    """Tool loop and tool-result limits."""

    max_tool_calls: int
    max_single_tool_result_tokens: int


class GovernanceContextPolicy(TypedDict, total=False):
    """Recent-turn trimming before each model call when set."""

    keep_recent_turns: int
