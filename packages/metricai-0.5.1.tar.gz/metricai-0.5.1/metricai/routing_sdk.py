"""Routing API manager (policies + analytics)."""

from __future__ import annotations

import json
from base64 import b64encode
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, Optional

import httpx

if TYPE_CHECKING:
    from .client import MetricAI


@dataclass
class RoutingConfig:
    """Optional per-client routing hints sent as proxy headers (policy still lives server-side)."""

    strategy: str
    config: Dict[str, Any] = field(default_factory=dict)
    override_model: Optional[str] = None


def routing_headers_from_config(rc: Optional[RoutingConfig]) -> Dict[str, str]:
    if rc is None:
        return {}
    out: Dict[str, str] = {"X-MetricAI-Routing-Strategy": rc.strategy}
    if rc.config:
        out["X-MetricAI-Routing-Config"] = b64encode(
            json.dumps(rc.config, separators=(",", ":")).encode("utf-8")
        ).decode("ascii")
    if rc.override_model:
        out["X-MetricAI-Model-Override"] = rc.override_model
    return out


class RoutingManager:
    """Calls ``/v1/routing/*`` REST endpoints (same API key as the client)."""

    def __init__(self, client: "MetricAI") -> None:
        self._client = client

    def configure(self, agent_id: str, strategy: str, config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._client._post(
            "/v1/routing/policies",
            {"agent_id": agent_id, "strategy": strategy, "config": config or {}},
        )

    async def aconfigure(
        self,
        agent_id: str,
        strategy: str,
        config: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        return await self._client._apost(
            "/v1/routing/policies",
            {"agent_id": agent_id, "strategy": strategy, "config": config or {}},
        )

    def get(self, agent_id: str) -> Dict[str, Any]:
        return self._client._get(f"/v1/routing/policies/{agent_id}")

    async def aget(self, agent_id: str) -> Dict[str, Any]:
        return await self._client._aget(f"/v1/routing/policies/{agent_id}")

    def analytics(
        self,
        agent_id: str,
        start_date: str,
        end_date: str,
        granularity: str = "day",
    ) -> Dict[str, Any]:
        return self._client._get(
            "/v1/routing/analytics",
            params={
                "agent_id": agent_id,
                "start_date": start_date,
                "end_date": end_date,
                "granularity": granularity,
            },
        )

    async def aanalytics(
        self,
        agent_id: str,
        start_date: str,
        end_date: str,
        granularity: str = "day",
    ) -> Dict[str, Any]:
        return await self._client._aget(
            "/v1/routing/analytics",
            params={
                "agent_id": agent_id,
                "start_date": start_date,
                "end_date": end_date,
                "granularity": granularity,
            },
        )
