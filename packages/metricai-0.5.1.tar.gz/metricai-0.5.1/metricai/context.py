"""
Request-scoped attribution (agent, user, session) for provider integrations and framework adapters.

**Provider category:** N/A (cross-cutting).

**Fail-open:** Missing context falls back to :class:`~metricai.config.MetricAIConfig` defaults;
failures reading context never raise into user application code.
"""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Iterator, Optional

from .session import SessionContext


@dataclass
class AttributionContext:
    """Active agent / user / session for metering when explicit IDs are not passed per call."""

    agent_id: Optional[str] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None


_attr_ctx: ContextVar[Optional[AttributionContext]] = ContextVar("metricai_attr", default=None)


def get_attribution() -> AttributionContext:
    """Current attribution or empty defaults."""
    v = _attr_ctx.get()
    return v if v is not None else AttributionContext()


def set_attribution(ctx: AttributionContext) -> None:
    _attr_ctx.set(ctx)


@contextmanager
def attribution_scope(
    *,
    agent_id: Optional[str] = None,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
) -> Iterator[AttributionContext]:
    """Bind agent/user/session for the current task (async-safe via contextvars)."""
    prev = _attr_ctx.get()
    merged = AttributionContext(
        agent_id=agent_id if agent_id is not None else (prev.agent_id if prev else None),
        user_id=user_id if user_id is not None else (prev.user_id if prev else None),
        session_id=session_id if session_id is not None else (prev.session_id if prev else None),
    )
    token = _attr_ctx.set(merged)
    try:
        yield merged
    finally:
        _attr_ctx.reset(token)


@contextmanager
def named_session(
    name: str,
    *,
    agent_id: Optional[str] = None,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
) -> Iterator[SessionContext]:
    """
    Open a named logical session: all nested code sees the same ``SessionContext``.

    ``name`` is stored on :class:`~metricai.session.SessionContext` as ``session_name``; the HTTP
    ``X-Session-ID`` is ``session_id`` or a new UUID.
    """
    import uuid

    sid = session_id or str(uuid.uuid4())
    ctx = SessionContext(session_id=sid, agent_id=agent_id, user_id=user_id, session_name=name)
    with attribution_scope(agent_id=agent_id, user_id=user_id, session_id=sid):
        yield ctx
