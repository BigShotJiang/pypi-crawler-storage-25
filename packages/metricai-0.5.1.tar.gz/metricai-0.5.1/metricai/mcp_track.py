"""Convenience wrapper for MCP tool invocations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional, Union

from .types import SimulationResult, TrackResult, Tool

if TYPE_CHECKING:
    from .client import MetricAI


def track_mcp_call(
    client: MetricAI,
    mcp_server_name: str,
    tool_name: str,
    *,
    session_id: Optional[str] = None,
    agent_id: Optional[str] = None,
    latency_ms: Optional[int] = None,
    success: Optional[bool] = None,
    input_tokens: Optional[int] = None,
    output_tokens: Optional[int] = None,
    **kwargs: Any,
) -> Union[TrackResult, SimulationResult, None]:
    """
    Report an MCP tool call via :meth:`MetricAI.track` with ``mcp_call=True`` and a synthetic
    ``tools`` list (``type=mcp_tool``, ``provider`` = server name).
    """
    tools: list[Tool] = [
        {
            "name": tool_name,
            "type": "mcp_tool",
            "invoked": True,
            "provider": mcp_server_name,
        }
    ]
    return client.track(
        tools=tools,
        mcp_call=True,
        session_id=session_id,
        agent_id=agent_id,
        latency_ms=latency_ms,
        success=success,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        **kwargs,
    )
