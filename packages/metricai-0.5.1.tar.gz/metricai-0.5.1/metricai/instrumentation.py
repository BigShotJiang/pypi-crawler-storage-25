"""
Global monkey-patch instrumentation for provider SDK clients.

Call :func:`instrument` once after :func:`metricai.runtime.init` to route all subsequent
``OpenAI()`` / ``Anthropic()`` constructions through the MetricAI proxy without editing call sites.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Callable, Dict, List, Optional, Set

from .config import llm_keys_to_proxy_headers, normalize_provider_for_proxy
from .context import get_attribution
from .headers import build_proxy_attribution_headers
from .provider_client import build_provider_sdk_kwargs

_LOG = logging.getLogger(__name__)

_INSTRUMENTED: Set[str] = set()

_ORIGINAL_INIT: Dict[str, Callable[..., None]] = {}
_PATCHED_CLASSES: Dict[str, type] = {}

_PROVIDER_ENV = {
    "openai": "OPENAI_API_KEY",
    "claude": "ANTHROPIC_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "grok": "GROK_API_KEY",
    "groq": "GROK_API_KEY",
}

_BYOK_HEADER_FOR_PROVIDER = {
    "openai": "X-OpenAI-API-Key",
    "claude": "X-Claude-API-Key",
    "gemini": "X-Gemini-API-Key",
    "grok": "X-Grok-API-Key",
}


_INSTRUMENT_CLIENT: Any | None = None


def _resolve_client() -> Any:
    if _INSTRUMENT_CLIENT is not None:
        return _INSTRUMENT_CLIENT
    from .runtime import get_metricai

    return get_metricai()


def _byok_from_kwargs(provider: str, kwargs: dict[str, Any], explicit: Optional[dict[str, str]]) -> Optional[str]:
    if explicit:
        header = _BYOK_HEADER_FOR_PROVIDER.get(provider)
        if header and explicit.get(header):
            return explicit[header]
    llm_keys = getattr(_resolve_client().config, "llm_keys", {}) or {}
    segment = provider
    for key in (segment, "anthropic" if segment == "claude" else None, "groq" if segment == "grok" else None):
        if key and llm_keys.get(key):
            return llm_keys[key]
    env_name = _PROVIDER_ENV.get(provider)
    if env_name:
        return os.environ.get(env_name)
    return None


def _merge_default_headers(
    client: Any,
    provider: str,
    existing: Optional[Dict[str, str]],
    byok_key: Optional[str],
) -> Dict[str, str]:
    attr = get_attribution()
    merged = build_proxy_attribution_headers(
        api_key=client._api_key,
        agent_id=attr.agent_id or client._agent_id,
        user_id=attr.user_id or client._user_id,
        session_id=attr.session_id or client._client_header_defaults.get("session_id"),
        key_mode=client.config.mode,
        default_billing_mode=client.config.default_billing_mode,
        default_budget_cap_inr=client.config.default_budget_cap_inr,
    )
    merged.update(getattr(client, "_extra_proxy_headers", {}) or {})
    header = _BYOK_HEADER_FOR_PROVIDER.get(provider)
    if byok_key and header:
        merged[header] = byok_key
    if existing:
        merged.update(existing)
    return merged


def _make_patch(provider: str, class_name: str, import_path: str) -> None:
    if provider in _INSTRUMENTED:
        return

    module_path, _, cls_name = import_path.rpartition(".")
    mod = __import__(module_path, fromlist=[cls_name])
    cls = getattr(mod, cls_name)
    original_init = cls.__init__
    _ORIGINAL_INIT[provider] = original_init

    def patched_init(self: Any, *args: Any, **kwargs: Any) -> None:
        if getattr(self, "_metricai_instrumented", False):
            return original_init(self, *args, **kwargs)

        client = _resolve_client()
        proxy_segment = normalize_provider_for_proxy(provider)
        if kwargs.get("base_url"):
            _LOG.debug(
                "metricai.instrument: preserving caller base_url=%s for %s",
                kwargs["base_url"],
                class_name,
            )
        else:
            kwargs["base_url"] = client.config.proxy_url_for(provider)

        byok = _byok_from_kwargs(proxy_segment, kwargs, kwargs.get("default_headers"))
        default_headers = _merge_default_headers(
            client,
            proxy_segment,
            kwargs.get("default_headers"),
            byok,
        )
        sdk_kwargs = build_provider_sdk_kwargs(
            provider,
            api_key=client._api_key,
            base_url=kwargs.get("base_url") or client.config.proxy_url_for(provider),
            default_headers=default_headers,
        )
        kwargs.pop("api_key", None)
        kwargs.pop("auth_token", None)
        kwargs.update(sdk_kwargs)

        original_init(self, *args, **kwargs)
        self._metricai_instrumented = True

    cls.__init__ = patched_init  # type: ignore[method-assign]
    _PATCHED_CLASSES[provider] = cls
    _INSTRUMENTED.add(provider)
    _LOG.info("MetricAI instrumented %s.%s", module_path, cls_name)


def restore_instrumentation() -> None:
    """Restore provider SDK ``__init__`` hooks (for tests). Idempotent."""
    global _INSTRUMENT_CLIENT
    _INSTRUMENT_CLIENT = None
    for provider, original_init in list(_ORIGINAL_INIT.items()):
        cls = _PATCHED_CLASSES.get(provider)
        if cls is not None:
            cls.__init__ = original_init  # type: ignore[method-assign]
    _ORIGINAL_INIT.clear()
    _PATCHED_CLASSES.clear()
    _INSTRUMENTED.clear()


def instrument(
    *,
    providers: Optional[List[str]] = None,
    openai_api_key: Optional[str] = None,
    anthropic_api_key: Optional[str] = None,
    gemini_api_key: Optional[str] = None,
    grok_api_key: Optional[str] = None,
    metricai_client: Any | None = None,
) -> None:
    """
    Monkey-patch provider SDK constructors after :func:`metricai.runtime.init`.

    Idempotent: safe to call multiple times; each provider is patched at most once.
    """
    global _INSTRUMENT_CLIENT
    if metricai_client is not None:
        _INSTRUMENT_CLIENT = metricai_client
    client = _resolve_client()
    if openai_api_key:
        client.config.llm_keys["openai"] = openai_api_key
    if anthropic_api_key:
        client.config.llm_keys["anthropic"] = anthropic_api_key
        client.config.llm_keys["claude"] = anthropic_api_key
    if gemini_api_key:
        client.config.llm_keys["gemini"] = gemini_api_key
    if grok_api_key:
        client.config.llm_keys["grok"] = grok_api_key
        client.config.llm_keys["groq"] = grok_api_key

    want = providers or ["openai", "anthropic", "gemini", "grok"]
    normalized = {normalize_provider_for_proxy(p) for p in want}

    openai_compatible = normalized & {"openai", "gemini", "grok"}
    if openai_compatible:
        _make_patch("openai", "OpenAI", "openai.OpenAI")
    if "claude" in normalized:
        _make_patch("claude", "Anthropic", "anthropic.Anthropic")


def patch_openai(metricai_client: Any | None = None) -> None:
    instrument(providers=["openai"], metricai_client=metricai_client)


def patch_anthropic(metricai_client: Any | None = None) -> None:
    instrument(providers=["anthropic"], metricai_client=metricai_client)


def patch_gemini(metricai_client: Any | None = None) -> None:
    instrument(providers=["gemini"], metricai_client=metricai_client)


def patch_grok(metricai_client: Any | None = None) -> None:
    instrument(providers=["grok"], metricai_client=metricai_client)
