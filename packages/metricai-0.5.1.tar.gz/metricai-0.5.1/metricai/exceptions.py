from __future__ import annotations

from typing import Any, Optional


class MetricAIError(Exception):
    """Base exception for all MetricAI SDK errors."""


class MetricAIConfigError(MetricAIError):
    """Raised when SDK configuration is missing or invalid."""


class MetricAIQuotaExhaustedError(MetricAIError):
    """Raised when plan quota is exhausted (HTTP 402)."""

    def __init__(
        self,
        *,
        plan: str,
        requests_used: int,
        quota_limit: int,
        upgrade_url: str,
        message: Optional[str] = None,
    ) -> None:
        self.plan = plan
        self.requests_used = requests_used
        self.quota_limit = quota_limit
        self.upgrade_url = upgrade_url
        super().__init__(
            message
            or (
                f"MetricAI quota exhausted for plan={plan!r}: "
                f"{requests_used}/{quota_limit} requests used. Upgrade: {upgrade_url}"
            )
        )


class MetricAIFeatureNotAvailableError(MetricAIError):
    """Raised when plan does not include a requested feature (HTTP 403)."""

    def __init__(
        self,
        *,
        feature: str,
        required_plan: str,
        current_plan: str,
        upgrade_url: str,
        message: Optional[str] = None,
    ) -> None:
        self.feature = feature
        self.required_plan = required_plan
        self.current_plan = current_plan
        self.upgrade_url = upgrade_url
        super().__init__(
            message
            or (
                f"Feature {feature!r} requires plan {required_plan!r} "
                f"(current plan: {current_plan!r}). Upgrade: {upgrade_url}"
            )
        )


class MetricAIAuthError(MetricAIError):
    """Raised when MetricAI API key is invalid/expired (HTTP 401)."""


class MetricAIRateLimitError(MetricAIError):
    """Raised when proxy returns rate limit (HTTP 429)."""

    def __init__(self, retry_after_seconds: int, message: Optional[str] = None) -> None:
        self.retry_after_seconds = retry_after_seconds
        super().__init__(message or f"Rate limited. Retry after {retry_after_seconds} seconds.")


class MetricAIProviderError(MetricAIError):
    """Raised for upstream provider errors forwarded by MetricAI."""

    def __init__(
        self,
        *,
        provider: str,
        provider_status_code: int,
        provider_error_message: str,
        request_id: Optional[str] = None,
    ) -> None:
        self.provider = provider
        self.provider_status_code = provider_status_code
        self.provider_error_message = provider_error_message
        self.request_id = request_id
        super().__init__(
            f"Provider {provider} returned {provider_status_code}: {provider_error_message}"
        )


class MetricAIProxyError(MetricAIError):
    """Raised for MetricAI proxy infrastructure failures (HTTP 5xx)."""

    def __init__(self, *, status_code: int, request_id: Optional[str] = None) -> None:
        self.status_code = status_code
        self.request_id = request_id
        super().__init__(f"MetricAI proxy error {status_code} (request_id={request_id})")


class MetricAIStreamError(MetricAIError):
    """Raised when a streaming response fails mid-stream."""

    def __init__(
        self,
        *,
        chunks_received: int,
        provider: str,
        request_id: Optional[str] = None,
        message: Optional[str] = None,
    ) -> None:
        self.chunks_received = chunks_received
        self.provider = provider
        self.request_id = request_id
        super().__init__(
            message
            or (
                f"Streaming interrupted for provider={provider!r} after "
                f"{chunks_received} chunks (request_id={request_id})"
            )
        )


def parse_metricai_error(status_code: int, body: Optional[dict[str, Any]], headers: dict[str, str]) -> MetricAIError:
    """Map HTTP response details to typed MetricAI exceptions."""
    payload = body or {}
    request_id = headers.get("x-metricai-request-id") or headers.get("x-request-id")
    message = str(payload.get("message") or payload.get("detail") or "").strip()

    if status_code == 401:
        detail = message or "Authentication failed. Check your MetricAI API key."
        if "sdk telemetry" in detail.lower() or "track" in detail.lower():
            detail = (
                message
                or (
                    "SDK telemetry (track/atrack) requires a MetricAI API key, not a dashboard "
                    "session JWT. Use X-MetricAI-API-Key or Authorization: Bearer <metricai_api_key>."
                )
            )
        return MetricAIAuthError(detail)
    if status_code == 402:
        return MetricAIQuotaExhaustedError(
            plan=str(payload.get("plan") or "developer"),
            requests_used=int(payload.get("requests_used") or 0),
            quota_limit=int(payload.get("quota_limit") or 0),
            upgrade_url=str(payload.get("upgrade_url") or ""),
            message=message or None,
        )
    if status_code == 403:
        return MetricAIFeatureNotAvailableError(
            feature=str(payload.get("feature") or "unknown"),
            required_plan=str(payload.get("required_plan") or "unknown"),
            current_plan=str(payload.get("current_plan") or "unknown"),
            upgrade_url=str(payload.get("upgrade_url") or ""),
            message=message or None,
        )
    if status_code == 429:
        retry_after_raw = headers.get("retry-after") or payload.get("retry_after_seconds") or 1
        try:
            retry_after = int(retry_after_raw)
        except (TypeError, ValueError):
            retry_after = 1
        return MetricAIRateLimitError(retry_after_seconds=max(retry_after, 1), message=message or None)
    if status_code >= 500:
        return MetricAIProxyError(status_code=status_code, request_id=request_id)

    provider = str(payload.get("provider") or "unknown")
    provider_status = int(payload.get("provider_status_code") or status_code)
    provider_message = str(payload.get("provider_error_message") or message or "Provider request failed")
    return MetricAIProviderError(
        provider=provider,
        provider_status_code=provider_status,
        provider_error_message=provider_message,
        request_id=request_id,
    )


# Backward-compatible names from <=0.2.x
AuthenticationError = MetricAIAuthError
ProviderError = MetricAIProviderError
InsufficientBalanceError = MetricAIQuotaExhaustedError
ProxyBudgetCapExceededError = MetricAIQuotaExhaustedError


class MetricAIBudgetExceeded(MetricAIError):
    """Backward-compatible session budget exception."""

    def __init__(
        self,
        *,
        budget_inr: float,
        spent_inr: float,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        message: Optional[str] = None,
    ) -> None:
        self.budget_inr = budget_inr
        self.spent_inr = spent_inr
        self.session_id = session_id
        self.agent_id = agent_id
        super().__init__(
            message
            or (
                f"Session budget exceeded: spent {spent_inr:.2f} INR "
                f"(cap {budget_inr:.2f} INR, session={session_id!r})."
            )
        )
