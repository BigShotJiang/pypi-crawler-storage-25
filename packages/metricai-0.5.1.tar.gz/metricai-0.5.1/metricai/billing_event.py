"""
Canonical versioned billing event schema for all MetricAI provider integrations.

**Provider category:** N/A (shared contract for LLM, model_gateway, and tool providers).

**Fail-open:** This module only defines data shapes; emission failures are handled by callers
(typically :class:`~metricai.telemetry_http.TelemetryTransport`) and must never block user code.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Literal, Optional

# Bump when adding/removing/renaming serialized fields consumed by the backend parser.
BILLING_EVENT_SCHEMA_VERSION = "1.0"

ProviderCategory = Literal["llm", "model_gateway", "tool"]
CostUnit = Literal["token", "token_gateway", "api_call"]


@dataclass
class BillingEvent:
    """
    Single canonical billing event produced by every provider integration.

    **provider_category**
      - ``llm``: token-metered LLM (OpenAI, direct Anthropic, etc.).
      - ``model_gateway``: one client endpoint, many models (e.g. AWS Bedrock); ``model_name``
        must be the resolved underlying model id for pricing.
      - ``tool``: non-LLM API (e.g. Tavily search) metered per call or tier, not per token.

    **cost_unit**
      - ``token`` / ``token_gateway``: use ``input_tokens`` / ``output_tokens`` (null for unknown).
      - ``api_call``: token fields should be ``None``; use ``tool_call_count`` (usually 1) and
        ``extra`` for tier/query metadata.

    **raw_response**
      Optional copy of the object returned to application code (or a shallow summary). Telemetry
      may omit or redact this in ``to_telemetry_dict`` to avoid huge payloads — the application
      still receives the full value from the provider wrapper.
    """

    provider_name: str
    model_name: Optional[str]
    provider_category: ProviderCategory
    cost_unit: CostUnit
    latency_ms: int
    agent_id: Optional[str]
    user_id: Optional[str]
    session_id: Optional[str]
    request_timestamp_iso: str
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    schema_version: str = BILLING_EVENT_SCHEMA_VERSION
    gateway_provider: Optional[str] = None
    tool_call_count: Optional[int] = None
    raw_response: Any = None
    extra: Dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def now_iso() -> str:
        return datetime.now(timezone.utc).isoformat()

    def to_telemetry_dict(self, *, include_raw_response: bool = False) -> Dict[str, Any]:
        """
        Flatten into the JSON shape merged into :func:`metricai.payload.build_track_payload` output.

        Large ``raw_response`` values are omitted unless ``include_raw_response=True`` (tests/debug).
        """
        d: Dict[str, Any] = {
            "schema_version": self.schema_version,
            "provider_category": self.provider_category,
            "cost_unit": self.cost_unit,
            "provider": self.provider_name,
            "model": self.model_name,
            "latency_ms": self.latency_ms,
            "agent_id": self.agent_id,
            "user_id": self.user_id,
            "session_id": self.session_id,
            "request_timestamp": self.request_timestamp_iso,
        }
        if self.input_tokens is not None:
            d["input_tokens"] = self.input_tokens
        if self.output_tokens is not None:
            d["output_tokens"] = self.output_tokens
        if self.gateway_provider:
            d["gateway_provider"] = self.gateway_provider
        if self.tool_call_count is not None:
            d["tool_call_count"] = self.tool_call_count
        if self.extra:
            d.update(self.extra)
        if include_raw_response and self.raw_response is not None:
            d["raw_response"] = self.raw_response
        return d

    def to_serializable_dict(self) -> Dict[str, Any]:
        """Full dataclass as dict (for debugging); ``raw_response`` may be non-JSON-serializable."""
        return asdict(self)
