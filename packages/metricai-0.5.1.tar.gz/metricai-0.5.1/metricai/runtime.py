"""
Process-wide MetricAI client registration and provider activation (single ``init()`` entry point).

**Provider category:** N/A.

**Fail-open:** Activation hooks swallow errors so a broken optional integration never crashes imports.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from .config import DEFAULT_PROXY_BASE_URL

if TYPE_CHECKING:
    from .client import MetricAI

_GLOBAL: Optional["MetricAI"] = None


def get_metricai() -> "MetricAI":
    """Return the client created by :func:`init`, or raise if ``init`` was not called."""
    if _GLOBAL is None:
        raise RuntimeError("MetricAI not initialized: call metricai.runtime.init() first.")
    return _GLOBAL


def init(
    api_key: str,
    *,
    default_agent_id: str = "default-agent",
    backend_endpoint: str = DEFAULT_PROXY_BASE_URL,
    environment: Optional[str] = None,
    default_session_id: Optional[str] = None,
    default_user_id: Optional[str] = None,
    auto_instrument: bool = False,
    validate: bool = False,
    **client_kwargs: Any,
) -> "MetricAI":
    """
    Single SDK initialization — call once at process startup.

    Initializes process-global MetricAI client.
    """
    global _GLOBAL
    from .client import MetricAI

    merged_kwargs = dict(client_kwargs)
    merged_kwargs.setdefault("base_url", backend_endpoint.rstrip("/"))
    client = MetricAI(
        api_key=api_key,
        agent_id=default_agent_id,
        session_id=default_session_id,
        user_id=default_user_id,
        environment=environment or "production",
        **merged_kwargs,
    )
    _GLOBAL = client
    try:
        from .providers.registry import activate as _activate_providers

        prov = client.config.active_providers
        _activate_providers(client, list(prov) if prov is not None else None)
    except Exception as e:
        import logging

        logging.getLogger(__name__).warning(
            "MetricAI optional provider activation failed: %s",
            e,
            exc_info=True,
        )
    if validate:
        client.validate_api_key()
    if auto_instrument:
        from .instrumentation import instrument

        instrument()
    return client
