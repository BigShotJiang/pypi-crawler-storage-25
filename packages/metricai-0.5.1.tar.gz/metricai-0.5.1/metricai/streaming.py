import json
from typing import Any, Iterator, AsyncIterator, Optional


def iter_sse_lines(raw_stream) -> Iterator[str]:
    """
    Iterate over raw SSE lines from an httpx streaming response.
    Yields the data payload string for each event (strips 'data: ' prefix).
    Stops at [DONE].
    """
    for line in raw_stream.iter_lines():
        line = line.strip()
        if not line or not line.startswith("data: "):
            continue
        data = line[6:]
        if data == "[DONE]":
            break
        yield data


async def aiter_sse_lines(raw_stream) -> AsyncIterator[str]:
    """Async version of iter_sse_lines for use with async httpx."""
    async for line in raw_stream.aiter_lines():
        line = line.strip()
        if not line or not line.startswith("data: "):
            continue
        data = line[6:]
        if data == "[DONE]":
            break
        yield data


def stream_text_delta_from_chunk(chunk: dict[str, Any], provider: str) -> str:
    """
    Extract one assistant text delta from a single proxy SSE JSON object.

    - **openai** / **grok** / **gemini** (wrapped): OpenAI ``choices[0].delta.content``.
    - **claude**: Anthropic stream events, e.g. ``type == content_block_delta`` with
      ``delta.type == text_delta`` and ``delta.text`` (as forwarded by MetricAI).
    """
    if provider == "claude":
        if chunk.get("type") == "content_block_delta":
            d = chunk.get("delta")
            if isinstance(d, dict) and d.get("type") == "text_delta":
                t = d.get("text")
                return t if isinstance(t, str) else ""
        return ""

    choices = chunk.get("choices")
    if not isinstance(choices, list) or not choices:
        return ""
    first = choices[0]
    if not isinstance(first, dict):
        return ""
    delta = first.get("delta")
    if not isinstance(delta, dict):
        return ""
    c = delta.get("content")
    return c if isinstance(c, str) else ""


class StreamingResponse:
    """
    Wraps a streaming LLM response from MetricAI proxy.
    Transparently passes through chunks while tracking token usage.

    For synchronous :meth:`MetricAIProxy.stream`, pass ``stream_cm`` and ``client`` so the
    underlying ``httpx`` stream context and client stay open until iteration finishes (otherwise
    the client may be garbage-collected and the body raises ``StreamClosed``).
    """

    def __init__(
        self,
        raw_stream,
        provider: str,
        *,
        stream_cm: Any = None,
        client: Any = None,
    ):
        self._stream = raw_stream
        self._provider = provider
        self._chunks: list[dict] = []
        self._stream_cm = stream_cm
        self._client = client
        self._sync_closed = False

    def _close_sync(self) -> None:
        if self._sync_closed:
            return
        self._sync_closed = True
        if self._stream_cm is not None:
            self._stream_cm.__exit__(None, None, None)
            self._stream_cm = None
        if self._client is not None:
            self._client.close()
            self._client = None

    def __iter__(self):
        try:
            for data in iter_sse_lines(self._stream):
                try:
                    chunk = json.loads(data)
                    self._chunks.append(chunk)
                    yield chunk
                except json.JSONDecodeError:
                    continue
        finally:
            self._close_sync()

    async def __aiter__(self):
        async for data in aiter_sse_lines(self._stream):
            try:
                chunk = json.loads(data)
                self._chunks.append(chunk)
                yield chunk
            except json.JSONDecodeError:
                continue

    def get_text(self) -> str:
        """Reconstruct full assistant text from accumulated chunks (provider-aware)."""
        parts: list[str] = []
        for chunk in self._chunks:
            piece = stream_text_delta_from_chunk(chunk, self._provider)
            if piece:
                parts.append(piece)
        return "".join(parts)
