"""Zero-change proxy helpers and MetricAI error parser."""

from __future__ import annotations

import os
from typing import Any, Callable

import httpx

from .config import normalize_provider_for_proxy
from .exceptions import MetricAIConfigError, MetricAIError, parse_metricai_error
from .headers import build_proxy_attribution_headers
from .provider_client import metricai_auth_credential_key
from .proxy_transport import MetricAIProxy  # noqa: F401 — re-export for backward compatibility
from .retry import RetryConfig


def get_proxy_config(
    provider: str,
    api_key: str,
    agent_id: str | None = None,
    session_id: str | None = None,
    user_id: str | None = None,
    retry_config: RetryConfig | None = None,
) -> dict[str, Any]:
    """
    Return proxy configuration for zero-change integration pattern.

    RetryConfig is accepted for API symmetry but not applied in this mode.
    """
    if not isinstance(api_key, str) or not api_key.strip():
        raise MetricAIConfigError("`api_key` must be a non-empty string.")

    normalized_provider = normalize_provider_for_proxy(provider)
    base_domain = os.getenv("METRICAI_PROXY_URL", "https://proxy.metricai.co.in").rstrip("/")
    base_url = f"{base_domain}/v1/proxy/{normalized_provider}"

    headers = build_proxy_attribution_headers(
        api_key=api_key,
        agent_id=agent_id or "untagged",
        user_id=user_id or "anonymous",
        session_id=session_id,
    )
    headers["X-MetricAI-Request-Mode"] = "standard"

    def error_parser(error: Exception) -> MetricAIError | None:
        if isinstance(error, MetricAIError):
            return error
        response: httpx.Response | None = None
        if isinstance(error, httpx.HTTPStatusError):
            response = error.response
        elif isinstance(error, httpx.Response) and error.status_code >= 400:
            response = error
        if response is None:
            return None
        try:
            body = response.json()
        except Exception:
            body = {"detail": response.text}
        return parse_metricai_error(
            status_code=response.status_code,
            body=body,
            headers={k.lower(): v for k, v in response.headers.items()},
        )

    cred_key = metricai_auth_credential_key(provider)
    out: dict[str, Any] = {
        cred_key: api_key,
        "base_url": base_url,
        "default_headers": headers,
        "error_parser": error_parser,
    }
    return out
