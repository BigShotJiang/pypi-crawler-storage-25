"""Fail-open HTTP transport for SDK telemetry with retries, buffer, and idempotency."""

from __future__ import annotations

import asyncio
import logging
import time
from collections import deque
from typing import Any, Deque, Dict, List, Optional, Tuple

import httpx

_LOG = logging.getLogger(__name__)

BUFFER_MAX = 100
DEFAULT_BACKOFFS = (0.5, 1.0)


class TelemetryTransport:
    """
    POST JSON events to MetricAI ingest. Network/5xx errors retry; failures can be buffered.
    """

    def __init__(
        self,
        *,
        post_url: str,
        api_key: str,
        timeout_seconds: float = 3.0,
        max_retries: int = 2,
        enable_buffer: bool = True,
        raise_on_error: bool = False,
    ) -> None:
        self._post_url = post_url
        self._api_key = api_key
        self._timeout = timeout_seconds
        self._max_retries = max(0, max_retries)
        self._enable_buffer = enable_buffer
        self._raise_on_error = raise_on_error
        self._buffer: Deque[Tuple[Dict[str, Any], str]] = deque(maxlen=BUFFER_MAX)
        self._buffer_overflow_count: int = 0  # reliability-fix: FIX-10

    @property
    def buffer_overflow_count(self) -> int:  # reliability-fix: FIX-10
        return self._buffer_overflow_count  # reliability-fix: FIX-10

    @property
    def post_url(self) -> str:  # reliability-fix: FIX-10
        return self._post_url  # reliability-fix: FIX-10 (used by buffer warning log)

    def _headers(self, idempotency_key: str) -> dict:
        return {
            "X-MetricAI-API-Key": self._api_key,
            "Content-Type": "application/json",
            "Idempotency-Key": idempotency_key,
        }

    def _should_retry(self, response: Optional[httpx.Response]) -> bool:
        if response is None:
            return True
        return response.status_code >= 500

    def send_event(
        self,
        body: Dict[str, Any],
        idempotency_key: str,
        *,
        background: bool = False,  # reliability-fix: FIX-6
    ) -> Optional[httpx.Response]:
        """Sync POST; returns last response or None on fail-open. Flushes buffer before new event."""
        _ = background  # Used by :class:`MetricAI` to tag executor-backed sends (no signature change in callers)  # reliability-fix: FIX-6
        queue: List[Tuple[Dict[str, Any], str]] = []
        if self._enable_buffer:
            while self._buffer:
                queue.append(self._buffer.popleft())
        queue.append((body, idempotency_key))

        last_response: Optional[httpx.Response] = None
        for i, (payload, ikey) in enumerate(queue):
            response = self._post_once_with_retries(payload, ikey)
            if response is None:
                if self._enable_buffer:
                    for item in reversed(queue[i:]):  # reliability-fix: FIX-10
                        if (  # reliability-fix: FIX-10
                            self._buffer.maxlen is not None  # reliability-fix: FIX-10
                            and len(self._buffer) >= int(self._buffer.maxlen)  # reliability-fix: FIX-10
                        ):  # reliability-fix: FIX-10
                            _LOG.warning(  # reliability-fix: FIX-10
                                (  # reliability-fix: FIX-10
                                    "MetricAI telemetry buffer is full (%d events). "  # reliability-fix: FIX-10
                                    "Oldest event will be dropped. Check connectivity to %s."  # reliability-fix: FIX-10
                                ),  # reliability-fix: FIX-10
                                self._buffer.maxlen,  # reliability-fix: FIX-10
                                self._post_url,  # reliability-fix: FIX-10
                            )  # reliability-fix: FIX-10
                            self._buffer_overflow_count += 1  # reliability-fix: FIX-10
                        self._buffer.appendleft(item)  # reliability-fix: FIX-10
                return None
            last_response = response
        return last_response

    def _post_once_with_retries(
        self,
        body: Dict[str, Any],
        idempotency_key: str,
    ) -> Optional[httpx.Response]:
        attempts = 1 + self._max_retries
        last_error: Optional[BaseException] = None
        for attempt in range(attempts):
            response: Optional[httpx.Response] = None
            try:
                with httpx.Client(timeout=self._timeout) as client:
                    response = client.post(
                        self._post_url,
                        headers=self._headers(idempotency_key),
                        json=body,
                    )
                if response.status_code >= 500:
                    last_error = httpx.HTTPStatusError(
                        "server error", request=response.request, response=response
                    )
                    if attempt < attempts - 1:
                        time.sleep(DEFAULT_BACKOFFS[min(attempt, len(DEFAULT_BACKOFFS) - 1)])
                    continue
                if 400 <= response.status_code < 500:
                    _LOG.warning(
                        "MetricAI telemetry client error %s: %s",
                        response.status_code,
                        response.text[:500],
                    )
                    if self._raise_on_error:
                        response.raise_for_status()
                    return None
                response.raise_for_status()
                return response
            except httpx.TimeoutException as e:
                last_error = e
                if attempt < attempts - 1:
                    time.sleep(DEFAULT_BACKOFFS[min(attempt, len(DEFAULT_BACKOFFS) - 1)])
            except httpx.TransportError as e:
                last_error = e
                if attempt < attempts - 1:
                    time.sleep(DEFAULT_BACKOFFS[min(attempt, len(DEFAULT_BACKOFFS) - 1)])
            except httpx.HTTPStatusError as e:
                last_error = e
                if self._should_retry(e.response) and attempt < attempts - 1:
                    time.sleep(DEFAULT_BACKOFFS[min(attempt, len(DEFAULT_BACKOFFS) - 1)])
                elif not self._should_retry(e.response):
                    break
        _LOG.warning("MetricAI telemetry failed after retries: %s", last_error)
        if self._raise_on_error and last_error is not None:
            raise last_error
        return None

    async def send_event_async(
        self,
        body: Dict[str, Any],
        idempotency_key: str,
        *,
        background: bool = False,  # reliability-fix: FIX-6
    ) -> Optional[httpx.Response]:
        """Async POST; same semantics as ``send_event``."""
        _ = background  # reliability-fix: FIX-6
        queue: List[Tuple[Dict[str, Any], str]] = []
        if self._enable_buffer:
            while self._buffer:
                queue.append(self._buffer.popleft())
        queue.append((body, idempotency_key))

        last_response: Optional[httpx.Response] = None
        for i, (payload, ikey) in enumerate(queue):
            response = await self._apost_once_with_retries(payload, ikey)
            if response is None:
                if self._enable_buffer:
                    for item in reversed(queue[i:]):  # reliability-fix: FIX-10
                        if (  # reliability-fix: FIX-10
                            self._buffer.maxlen is not None  # reliability-fix: FIX-10
                            and len(self._buffer) >= int(self._buffer.maxlen)  # reliability-fix: FIX-10
                        ):  # reliability-fix: FIX-10
                            _LOG.warning(  # reliability-fix: FIX-10
                                (  # reliability-fix: FIX-10
                                    "MetricAI telemetry buffer is full (%d events). "  # reliability-fix: FIX-10
                                    "Oldest event will be dropped. Check connectivity to %s."  # reliability-fix: FIX-10
                                ),  # reliability-fix: FIX-10
                                self._buffer.maxlen,  # reliability-fix: FIX-10
                                self._post_url,  # reliability-fix: FIX-10
                            )  # reliability-fix: FIX-10
                            self._buffer_overflow_count += 1  # reliability-fix: FIX-10
                        self._buffer.appendleft(item)  # reliability-fix: FIX-10
                return None
            last_response = response
        return last_response

    async def _apost_once_with_retries(
        self,
        body: Dict[str, Any],
        idempotency_key: str,
    ) -> Optional[httpx.Response]:
        attempts = 1 + self._max_retries
        last_error: Optional[BaseException] = None
        for attempt in range(attempts):
            try:
                async with httpx.AsyncClient(timeout=self._timeout) as client:
                    response = await client.post(
                        self._post_url,
                        headers=self._headers(idempotency_key),
                        json=body,
                    )
                if response.status_code >= 500:
                    last_error = httpx.HTTPStatusError(
                        "server error", request=response.request, response=response
                    )
                    if attempt < attempts - 1:
                        await asyncio.sleep(
                            DEFAULT_BACKOFFS[min(attempt, len(DEFAULT_BACKOFFS) - 1)]
                        )
                    continue
                if 400 <= response.status_code < 500:
                    _LOG.warning(
                        "MetricAI telemetry client error %s: %s",
                        response.status_code,
                        response.text[:500],
                    )
                    if self._raise_on_error:
                        response.raise_for_status()
                    return None
                response.raise_for_status()
                return response
            except httpx.TimeoutException as e:
                last_error = e
                if attempt < attempts - 1:
                    await asyncio.sleep(
                        DEFAULT_BACKOFFS[min(attempt, len(DEFAULT_BACKOFFS) - 1)]
                    )
            except httpx.TransportError as e:
                last_error = e
                if attempt < attempts - 1:
                    await asyncio.sleep(
                        DEFAULT_BACKOFFS[min(attempt, len(DEFAULT_BACKOFFS) - 1)]
                    )
            except httpx.HTTPStatusError as e:
                last_error = e
                if self._should_retry(e.response) and attempt < attempts - 1:
                    await asyncio.sleep(
                        DEFAULT_BACKOFFS[min(attempt, len(DEFAULT_BACKOFFS) - 1)]
                    )
                elif not self._should_retry(e.response):
                    break
        _LOG.warning("MetricAI telemetry failed after retries: %s", last_error)
        if self._raise_on_error and last_error is not None:
            raise last_error
        return None
