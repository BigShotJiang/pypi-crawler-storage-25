# reliability-fix: FIX-4
"""Token usage helpers for LangChain/LangGraph callbacks (multi-provider)."""

from __future__ import annotations

from typing import Any, Optional, Tuple


# reliability-fix: FIX-4
def _extract_tokens(llm_output: dict) -> Tuple[Optional[int], Optional[int]]:
    """
    Supports both OpenAI-style and Anthropic-style token usage keys.
    Returns (input_tokens, output_tokens).
    """
    # reliability-fix: FIX-4
    raw = llm_output or {}
    # reliability-fix: FIX-4
    usage: Any = raw.get("token_usage") or raw.get("usage") or {}
    # reliability-fix: FIX-4
    if not isinstance(usage, dict):
        # reliability-fix: FIX-4
        return None, None
    # reliability-fix: FIX-4
    input_raw = (
        usage.get("input_tokens")
        or usage.get("prompt_tokens")
        or usage.get("promptTokenCount")
        or None
    )
    # reliability-fix: FIX-4
    output_raw = (
        usage.get("output_tokens")
        or usage.get("completion_tokens")
        or usage.get("candidatesTokenCount")
        or None
    )
    # reliability-fix: FIX-4
    it: Optional[int] = int(input_raw) if input_raw is not None else None
    # reliability-fix: FIX-4
    ot: Optional[int] = int(output_raw) if output_raw is not None else None
    # reliability-fix: FIX-4
    return it, ot
