"""LangGraph-oriented callback tracer for per-node attribution (client-side aggregates)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, List, Optional
from uuid import UUID

if TYPE_CHECKING:
    from metricai.client import MetricAI

from metricai.context import get_attribution
from metricai.integrations._token_utils import _extract_tokens

try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.outputs import LLMResult
except ImportError as _e:
    raise ImportError(
        "metricai.integrations.langgraph requires langchain-core. "
        'pip install langchain-core or pip install "metricai[langgraph]"'
    ) from _e


@dataclass
class NodeMetrics:
    node_id: str
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: int = 0
    cost_inr: float = 0.0


class MetricAIGraphTracer(BaseCallbackHandler):
    """Tracks per-run chain/node context and aggregates token usage into ``node_metrics``."""

    def __init__(
        self,
        client: "MetricAI",
        graph_id: str,
        user_id: str,
        *,
        agent_id: str = "langgraph",
        track_nodes: bool = True,
        provider: str = "openai",
        model_fallback: str = "unknown",
    ) -> None:
        self.client = client
        self.graph_id = graph_id
        self.user_id = user_id
        self.agent_id = agent_id
        self.track_nodes = track_nodes
        self.provider = provider
        self.model_fallback = model_fallback
        self.node_metrics: Dict[str, NodeMetrics] = {}
        self._current_node: Optional[str] = None
        self._starts: Dict[str, int] = {}

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        if not self.track_nodes:
            return
        name = serialized.get("name")
        if not name and serialized.get("id"):
            sid = serialized["id"]
            if isinstance(sid, list) and sid:
                name = sid[-1]
        node_name = str(name or "unknown")
        self._current_node = node_name
        if node_name not in self.node_metrics:
            self.node_metrics[node_name] = NodeMetrics(node_id=node_name)

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        self._starts[str(run_id)] = __import__("time").time()

    def on_llm_end(self, response: LLMResult, *, run_id: UUID, **kwargs: Any) -> None:
        if not self._current_node:
            return
        llm_out = response.llm_output or {}
        u_src: Dict[str, Any] = dict(llm_out) if llm_out else {}
        if not (u_src.get("token_usage") or u_src.get("usage")) and response.generations:
            gi = getattr(response.generations[0], "generation_info", None) or {}
            if isinstance(gi, dict):
                u_src["token_usage"] = gi
        _it, _ot = _extract_tokens(u_src)  # reliability-fix: FIX-4
        pt = int(_it or 0)  # reliability-fix: FIX-4
        ct = int(_ot or 0)  # reliability-fix: FIX-4
        m = self.node_metrics.setdefault(self._current_node, NodeMetrics(node_id=self._current_node))
        m.input_tokens += pt
        m.output_tokens += ct
        t0 = self._starts.pop(str(run_id), None)
        if t0 is not None:
            ms = int((__import__("time").time() - t0) * 1000)
            m.latency_ms += ms
        try:
            attr = get_attribution()
            self.client.track(
                provider=self.provider,
                model=str(llm_out.get("model_name") or self.model_fallback),
                input_tokens=pt,
                output_tokens=ct,
                agent_id=attr.agent_id or self.agent_id,
                user_id=attr.user_id or self.user_id,
                session_id=attr.session_id,
                extra={
                    "graph_id": self.graph_id,
                    "node_id": self._current_node,
                    "source": "langgraph_tracer",
                },
            )
        except Exception:
            pass

    def summary(self) -> Dict[str, Any]:
        return {
            nid: {
                "input_tokens": m.input_tokens,
                "output_tokens": m.output_tokens,
                "total_tokens": m.input_tokens + m.output_tokens,
                "latency_ms": m.latency_ms,
            }
            for nid, m in self.node_metrics.items()
        }


def instrument_graph(graph: Any, client: "MetricAI", graph_id: str, user_id: str, **kwargs: Any):
    """
    Wrap a compiled LangGraph (or Runnable) so ``invoke`` / ``ainvoke`` append :class:`MetricAIGraphTracer`
    to ``config["callbacks"]``.
    """
    tracer = MetricAIGraphTracer(client=client, graph_id=graph_id, user_id=user_id, **kwargs)

    class InstrumentedGraph:
        def __init__(self, app: Any, tr: MetricAIGraphTracer) -> None:
            self._app = app
            self.tracer = tr

        def invoke(self, inputs: Dict[str, Any], config: Optional[Dict[str, Any]] = None, **kw: Any):
            config = dict(config or {})
            cb = list(config.get("callbacks") or [])
            cb.append(self.tracer)
            config["callbacks"] = cb
            return self._app.invoke(inputs, config=config, **kw)

        async def ainvoke(self, inputs: Dict[str, Any], config: Optional[Dict[str, Any]] = None, **kw: Any):
            config = dict(config or {})
            cb = list(config.get("callbacks") or [])
            cb.append(self.tracer)
            config["callbacks"] = cb
            return await self._app.ainvoke(inputs, config=config, **kw)

    return InstrumentedGraph(graph, tracer), tracer
