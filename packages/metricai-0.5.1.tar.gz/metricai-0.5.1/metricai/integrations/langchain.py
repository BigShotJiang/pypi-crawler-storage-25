"""LangChain/LangGraph integration helpers for MetricAI 0.3."""

from __future__ import annotations

from typing import Any, Callable, Optional

from metricai.exceptions import MetricAIError

try:
    from langchain_core.callbacks import BaseCallbackHandler
except ImportError as _e:
    raise ImportError(
        "metricai.integrations.langchain requires langchain-core. "
        'Install: pip install langchain-core or pip install "metricai[langchain]"'
    ) from _e


class MetricAICallbackHandler(BaseCallbackHandler):
    def __init__(
        self,
        client: Any,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        *,
        agent_id_resolver: Optional[Callable[[str], Optional[str]]] = None,
        session_id_resolver: Optional[Callable[[str], Optional[str]]] = None,
        user_id_resolver: Optional[Callable[[str], Optional[str]]] = None,
    ) -> None:
        self.client = client
        self.agent_id = agent_id
        self.session_id = session_id
        self.user_id = user_id
        self.agent_id_resolver = agent_id_resolver
        self.session_id_resolver = session_id_resolver
        self.user_id_resolver = user_id_resolver

    def _resolve(self, run_id: Any) -> dict[str, Optional[str]]:
        run = str(run_id)
        return {
            "agent_id": self.agent_id_resolver(run) if self.agent_id_resolver else self.agent_id,
            "session_id": self.session_id_resolver(run) if self.session_id_resolver else self.session_id,
            "user_id": self.user_id_resolver(run) if self.user_id_resolver else self.user_id,
        }

    def on_llm_start(self, serialized: Any, prompts: Any, *, run_id: Any, **kwargs: Any) -> Any:
        ctx = self._resolve(run_id)
        metadata = kwargs.setdefault("metadata", {})
        metadata["metricai_headers"] = self.client._build_headers(
            context=self.client._extract_metricai_kwargs(
                {
                    "metricai_agent_id": ctx["agent_id"],
                    "metricai_session_id": ctx["session_id"],
                    "metricai_user_id": ctx["user_id"],
                }
            )
        )

    def on_llm_error(self, error: BaseException, *, run_id: Any, **kwargs: Any) -> Any:
        if isinstance(error, MetricAIError):
            raise error


MetricAIChat = object
MetricAILLM = object
