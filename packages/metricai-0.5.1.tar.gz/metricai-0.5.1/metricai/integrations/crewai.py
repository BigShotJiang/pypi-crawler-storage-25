"""CrewAI integration wrappers for MetricAI context propagation."""

from __future__ import annotations

from typing import Any, Optional

def _sanitize_role(role: Any) -> str:
    value = str(role or "agent").strip().replace(" ", "-")
    return value[:128]


class MetricAICrewWrapper:
    def __init__(self, client: Any, crew: Any) -> None:
        self._client = client
        self._crew = crew

    def kickoff(self, *args: Any, **kwargs: Any) -> Any:
        execution_id = str(kwargs.get("execution_id") or getattr(self._crew, "id", "crew-session"))[:128]
        for agent in getattr(self._crew, "agents", []):
            role = _sanitize_role(getattr(agent, "role", "agent"))
            llm = getattr(agent, "llm", None)
            if llm is None:
                continue
            if hasattr(llm, "create") and callable(llm.create):
                original = llm.create

                def _wrapped_create(*c_args: Any, __original: Any = original, __role: str = role, **c_kwargs: Any) -> Any:
                    c_kwargs.setdefault("metricai_agent_id", __role)
                    c_kwargs.setdefault("metricai_session_id", execution_id)
                    return __original(*c_args, **c_kwargs)

                llm.create = _wrapped_create
        return self._crew.kickoff(*args, **kwargs)

    def cost_summary(self) -> dict[str, Any]:
        """
        NOT IMPLEMENTED — returns an empty dict.

        Crew-level cost aggregation is not available in this SDK version; use the
        MetricAI dashboard or ``MetricAISession`` telemetry totals instead.
        """
        return {}


# Backward compatibility
MetricAICrew = MetricAICrewWrapper
MetricAICrewLLM = object
