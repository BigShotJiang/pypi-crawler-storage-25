"""Django middleware for MetricAI attribution context."""

from __future__ import annotations

from typing import Callable, Optional

from metricai.context import attribution_scope

try:
    from django.http import HttpRequest, HttpResponse
except ImportError as e:
    raise ImportError("MetricAIDjangoMiddleware requires Django.") from e


class MetricAIDjangoMiddleware:
    """Set MetricAI attribution contextvars for each Django request."""

    def __init__(
        self,
        get_response: Callable[[HttpRequest], HttpResponse],
        *,
        user_id_extractor: Callable[[HttpRequest], Optional[str]],
        agent_id_extractor: Optional[Callable[[HttpRequest], Optional[str]]] = None,
        session_id_extractor: Optional[Callable[[HttpRequest], Optional[str]]] = None,
    ) -> None:
        self.get_response = get_response
        self._user_id_extractor = user_id_extractor
        self._agent_id_extractor = agent_id_extractor
        self._session_id_extractor = session_id_extractor

    def __call__(self, request: HttpRequest) -> HttpResponse:
        user_id = self._user_id_extractor(request)
        agent_id = self._agent_id_extractor(request) if self._agent_id_extractor else None
        session_id = self._session_id_extractor(request) if self._session_id_extractor else None
        with attribution_scope(user_id=user_id, agent_id=agent_id, session_id=session_id):
            return self.get_response(request)
