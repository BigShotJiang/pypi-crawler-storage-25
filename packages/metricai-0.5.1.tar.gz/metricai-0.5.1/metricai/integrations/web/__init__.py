"""Web framework integrations for per-request attribution."""

from .fastapi import MetricAIFastAPIMiddleware

__all__ = ["MetricAIFastAPIMiddleware"]

try:
    from .django import MetricAIDjangoMiddleware
except ImportError:
    MetricAIDjangoMiddleware = None  # type: ignore[misc, assignment]

if MetricAIDjangoMiddleware is not None:
    __all__.append("MetricAIDjangoMiddleware")
