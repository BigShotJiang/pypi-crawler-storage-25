"""FastAPI middleware for MetricAI attribution context."""

from __future__ import annotations

from typing import Awaitable, Callable, Optional

from metricai.context import attribution_scope

try:
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.requests import Request
    from starlette.responses import Response
except ImportError as e:
    raise ImportError(
        "MetricAIFastAPIMiddleware requires starlette (install fastapi or starlette)."
    ) from e


class MetricAIFastAPIMiddleware(BaseHTTPMiddleware):
    """
    Bind ``attribution_scope`` for each HTTP request so LLM calls inherit ``user_id`` / ``agent_id``.

    Example::

        app.add_middleware(
            MetricAIFastAPIMiddleware,
            user_id_extractor=lambda req: str(req.state.user.id),
            agent_id_extractor=lambda req: "api",
        )
    """

    def __init__(
        self,
        app,
        *,
        user_id_extractor: Callable[[Request], Optional[str]],
        agent_id_extractor: Optional[Callable[[Request], Optional[str]]] = None,
        session_id_extractor: Optional[Callable[[Request], Optional[str]]] = None,
    ) -> None:
        super().__init__(app)
        self._user_id_extractor = user_id_extractor
        self._agent_id_extractor = agent_id_extractor
        self._session_id_extractor = session_id_extractor

    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        user_id = self._user_id_extractor(request)
        agent_id = self._agent_id_extractor(request) if self._agent_id_extractor else None
        session_id = self._session_id_extractor(request) if self._session_id_extractor else None
        with attribution_scope(user_id=user_id, agent_id=agent_id, session_id=session_id):
            return await call_next(request)
