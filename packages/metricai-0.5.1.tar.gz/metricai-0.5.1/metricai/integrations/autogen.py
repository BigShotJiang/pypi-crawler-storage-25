"""AutoGen middleware for MetricAI retries and header injection."""

from __future__ import annotations

from typing import Any, Dict, Optional


class MetricAIAutoGenMiddleware:
    """
    Wrap AutoGen OpenAIWrapper and route calls through MetricAI.

    Note: disable AutoGen retries (`max_retries=0`) when using this middleware.
    """

    def __init__(self, client: Any, openai_wrapper: Any) -> None:
        self.client = client
        self.openai_wrapper = openai_wrapper
        self._original_create = openai_wrapper.create

    def create(self, *args: Any, **kwargs: Any) -> Any:
        kwargs.setdefault("metricai_agent_id", kwargs.pop("agent_id", None))
        kwargs.setdefault("metricai_session_id", kwargs.pop("session_id", None))
        kwargs.setdefault("metricai_user_id", kwargs.pop("user_id", None))
        wrapped = self.client.openai()
        if hasattr(wrapped, "chat") and hasattr(wrapped.chat, "completions"):
            return wrapped.chat.completions.create(*args, **kwargs)
        return self._original_create(*args, **kwargs)

    def apply(self) -> Any:
        self.openai_wrapper.create = self.create
        return self.openai_wrapper


def openai_client_for_autogen(client: Any, *, agent_id: str, user_id: str, session_id: Optional[str] = None) -> Any:
    return client.with_context(agent_id=agent_id, user_id=user_id, session_id=session_id).openai()


def llm_config_stub(
    *,
    model: str = "gpt-4o-mini",
    temperature: float = 0.2,
) -> Dict[str, Any]:
    """Minimal config dict placeholder; prefer passing ``openai_client_for_autogen`` output to agents."""
    return {"model": model, "temperature": temperature}
