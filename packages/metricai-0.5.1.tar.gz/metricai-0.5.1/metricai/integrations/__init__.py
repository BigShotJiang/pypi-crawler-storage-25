"""Optional integrations (LangChain, LangGraph, CrewAI).

Core export remains :class:`ChatMetricAI` (requires ``langchain-core``).

Other integrations are imported lazily so ``crewai`` / ``langgraph`` stay optional::

    from metricai.integrations.langchain import MetricAIChat, MetricAICallbackHandler, MetricAILLM
    from metricai.integrations.langgraph import MetricAIGraphTracer, instrument_graph
    from metricai.integrations.crewai import MetricAICrewLLM, MetricAICrew
"""

from __future__ import annotations

from typing import Any

from metricai.integrations.langchain_chat import ChatMetricAI

__all__ = [
    "ChatMetricAI",
    "MetricAICallbackHandler",
    "MetricAILLM",
    "MetricAIChat",
    "MetricAIGraphTracer",
    "instrument_graph",
    "MetricAICrewLLM",
    "MetricAICrew",
    "MetricAICrewWrapper",
    "MetricAILlamaIndexHandler",
    "attach_to_settings",
    "MetricAIAutoGenMiddleware",
]


def __getattr__(name: str) -> Any:
    if name in ("MetricAICallbackHandler", "MetricAILLM", "MetricAIChat"):
        from metricai.integrations.langchain import MetricAIChat, MetricAICallbackHandler, MetricAILLM

        if name == "MetricAICallbackHandler":
            return MetricAICallbackHandler
        if name == "MetricAILLM":
            return MetricAILLM
        return MetricAIChat
    if name in ("MetricAIGraphTracer", "instrument_graph"):
        from metricai.integrations.langgraph import MetricAIGraphTracer, instrument_graph

        if name == "MetricAIGraphTracer":
            return MetricAIGraphTracer
        return instrument_graph
    if name in ("MetricAICrewLLM", "MetricAICrew", "MetricAICrewWrapper"):
        from metricai.integrations.crewai import MetricAICrew, MetricAICrewLLM, MetricAICrewWrapper

        if name == "MetricAICrewLLM":
            return MetricAICrewLLM
        if name == "MetricAICrewWrapper":
            return MetricAICrewWrapper
        return MetricAICrew
    if name in ("MetricAILlamaIndexHandler", "attach_to_settings"):
        from metricai.integrations.llamaindex import MetricAILlamaIndexHandler, attach_to_settings

        if name == "MetricAILlamaIndexHandler":
            return MetricAILlamaIndexHandler
        return attach_to_settings
    if name == "MetricAIAutoGenMiddleware":
        from metricai.integrations.autogen import MetricAIAutoGenMiddleware

        return MetricAIAutoGenMiddleware
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
