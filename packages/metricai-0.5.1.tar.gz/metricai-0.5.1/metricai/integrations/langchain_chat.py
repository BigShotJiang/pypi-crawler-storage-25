"""
LangChain ``BaseChatModel`` for MetricAI proxy routes.

Requires: ``pip install langchain-core`` (or ``pip install "metricai[langchain]"``).

Usage (same style as ``ChatOpenAI`` in the LangChain docs)::

    from langchain_core.messages import HumanMessage
    from metricai.integrations.langchain_chat import ChatMetricAI

    llm = ChatMetricAI(
        model="gpt-4o-mini",
        metricai_api_key="metricai_...",
        base_url="http://localhost:8000",
        provider="openai",
        extra_proxy_headers={"X-OpenAI-API-Key": os.environ["OPENAI_API_KEY"]},
    )
    msg = llm.invoke([HumanMessage(content="What is 2+2?")])
    print(msg.content)
"""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any, Literal, Optional, cast

from pydantic import Field, PrivateAttr

from metricai.config import DEFAULT_PROXY_BASE_URL
from metricai.client import MetricAI

DEFAULT_BASE_URL = DEFAULT_PROXY_BASE_URL
from metricai.streaming import stream_text_delta_from_chunk

try:
    from langchain_core.callbacks import CallbackManagerForLLMRun
    from langchain_core.language_models.chat_models import BaseChatModel
    from langchain_core.messages import AIMessage, AIMessageChunk, BaseMessage, convert_to_openai_messages
    from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
except ImportError as e:
    raise ImportError(
        "ChatMetricAI requires langchain-core. Install with: pip install langchain-core "
        'or pip install "metricai[langchain]"'
    ) from e


ProviderName = Literal["openai", "claude", "gemini", "grok"]


class ChatMetricAI(BaseChatModel):
    """Chat model that calls the MetricAI HTTP proxy (``/v1/proxy/{provider}``) via :class:`MetricAI`."""

    model: str = Field(default="gpt-4o-mini", description="Upstream model id forwarded to the proxy.")
    metricai_api_key: str = Field(..., repr=False, description="MetricAI dashboard API key (``metricai_...``).")
    base_url: str = Field(
        default=DEFAULT_BASE_URL,
        description="MetricAI API base URL (no trailing path segment).",
    )
    provider: ProviderName = Field(
        default="openai",
        description="Which proxy route to use: openai, claude, gemini, or grok.",
    )
    extra_proxy_headers: Optional[dict[str, str]] = Field(
        default=None,
        description="BYOK headers (e.g. X-OpenAI-API-Key, X-Claude-API-Key, X-Grok-API-Key).",
    )
    timeout: int = Field(default=60, ge=1, description="HTTP timeout seconds for proxy calls.")

    _client: MetricAI = PrivateAttr()

    def model_post_init(self, __context: Any) -> None:
        self._client = MetricAI(
            api_key=self.metricai_api_key,
            base_url=self.base_url.rstrip("/"),
            timeout=self.timeout,
            extra_proxy_headers=self.extra_proxy_headers,
        )

    @property
    def _llm_type(self) -> str:
        return "chat-metricai"

    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        return {"model": self.model, "provider": self.provider, "base_url": self.base_url}

    def _proxy(self):
        return getattr(self._client, self.provider)()

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: CallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> ChatResult:
        oa_messages = convert_to_openai_messages(messages)
        if not isinstance(oa_messages, list):
            oa_messages = [oa_messages]
        req: dict[str, Any] = dict(kwargs)
        if stop:
            req["stop"] = stop
        resp = self._proxy().complete(model=self.model, messages=oa_messages, **req)
        text = _assistant_text_from_proxy_json(resp)
        ai = AIMessage(content=text)
        return ChatResult(
            generations=[ChatGeneration(message=ai)],
            llm_output={"raw": resp},
        )

    def _stream(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: CallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> Iterator[ChatGenerationChunk]:
        oa_messages = convert_to_openai_messages(messages)
        if not isinstance(oa_messages, list):
            oa_messages = [oa_messages]
        req: dict[str, Any] = dict(kwargs)
        if stop:
            req["stop"] = stop
        stream = self._proxy().stream(model=self.model, messages=oa_messages, **req)
        prov = self.provider
        for chunk in stream:
            if not isinstance(chunk, dict):
                continue
            piece = stream_text_delta_from_chunk(chunk, prov)
            if not piece:
                continue
            yield ChatGenerationChunk(
                message=cast("AIMessageChunk", AIMessageChunk(content=piece)),
            )


def _assistant_text_from_proxy_json(resp: dict[str, Any]) -> str:
    """Best-effort assistant string from MetricAI proxy JSON (OpenAI-shaped or normalized)."""
    am = resp.get("assistant_message")
    if isinstance(am, dict):
        c = am.get("content")
        if isinstance(c, str):
            return c
    choices = resp.get("choices")
    if isinstance(choices, list) and choices:
        m = choices[0].get("message") if isinstance(choices[0], dict) else None
        if isinstance(m, dict):
            c = m.get("content")
            if isinstance(c, str):
                return c
    return ""
