"""LlamaIndex callback integration for MetricAI context and errors."""

from __future__ import annotations

from typing import Any, Dict, Optional

from metricai.exceptions import MetricAIError

try:
    from llama_index.core.callbacks.base_handler import BaseCallbackHandler
    from llama_index.core.callbacks.schema import CBEventType
except ImportError as _e:
    raise ImportError(
        "metricai.integrations.llamaindex requires llama-index-core. "
        "Install: pip install llama-index-core"
    ) from _e


class MetricAILlamaIndexHandler(BaseCallbackHandler):

    def __init__(
        self,
        client: Any,
        *,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> None:
        super().__init__(event_starts_to_ignore=[], event_ends_to_ignore=[])
        self.client = client
        self.agent_id = agent_id
        self.session_id = session_id
        self.user_id = user_id

    def on_event_start(self, event_type: Any, payload: Optional[Dict[str, Any]] = None, event_id: str = "", **kwargs: Any) -> None:
        if event_type != CBEventType.LLM:
            return
        if payload is None:
            payload = {}
        payload["metricai_headers"] = self.client._build_headers(
            context=self.client._extract_metricai_kwargs(
                {
                    "metricai_agent_id": self.agent_id,
                    "metricai_session_id": self.session_id,
                    "metricai_user_id": self.user_id,
                }
            )
        )

    def on_event_end(
        self,
        event_type: Any,
        payload: Optional[Dict[str, Any]] = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> None:
        if event_type != CBEventType.LLM:
            return
        err = kwargs.get("error")
        if isinstance(err, MetricAIError):
            raise err


def attach_to_settings(settings: Any, handler: MetricAILlamaIndexHandler) -> None:
    """Merge ``handler`` into ``Settings.callback_manager`` (LlamaIndex global settings)."""
    try:
        cm = getattr(settings, "callback_manager", None)
        if cm is None:
            from llama_index.core.callbacks import CallbackManager

            cm = CallbackManager([])
            settings.callback_manager = cm
        cm.add_handler(handler)
    except Exception:
        pass
