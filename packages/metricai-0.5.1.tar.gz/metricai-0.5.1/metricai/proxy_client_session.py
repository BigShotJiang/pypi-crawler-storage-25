"""Session context for native OpenAI / Anthropic SDK clients (shared ``session_id``).

This is distinct from :class:`~metricai.metricai_session.MetricAISession`, which aggregates
telemetry ``track()`` / ``atrack()`` calls.
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from .client import MetricAI


class MetricAIProxyClientSession:
    """
    Groups proxy calls under one ``X-Session-ID`` when using :meth:`MetricAI.openai_sdk` /
    :meth:`MetricAI.anthropic_sdk` / etc.

    On exit, calls :meth:`MetricAI.complete_session` when ``complete_on_exit`` is True (default).
    """

    def __init__(
        self,
        client: "MetricAI",
        agent_id: str,
        user_id: str,
        *,
        session_id: Optional[str] = None,
        budget_cap_inr: Optional[float] = None,
        complete_on_exit: bool = True,
        **kwargs: Any,
    ) -> None:
        self._client = client
        self.agent_id = agent_id
        self.user_id = user_id
        self.session_id = session_id or str(uuid.uuid4())
        self.budget_cap_inr = budget_cap_inr
        self._kwargs = kwargs
        self._complete_on_exit = complete_on_exit

    def __enter__(self) -> "MetricAIProxyClientSession":
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._complete_on_exit:
            try:
                self._client.complete_session(self.session_id)
            except Exception:
                pass
        return None

    def openai_sdk(self, **kwargs: Any) -> Any:
        merged = {**self._kwargs, **kwargs}
        return self._client.openai_sdk(
            self.agent_id,
            self.user_id,
            session_id=self.session_id,
            budget_cap_inr=self.budget_cap_inr,
            **merged,
        )

    def anthropic_sdk(self, **kwargs: Any) -> Any:
        merged = {**self._kwargs, **kwargs}
        return self._client.anthropic_sdk(
            self.agent_id,
            self.user_id,
            session_id=self.session_id,
            budget_cap_inr=self.budget_cap_inr,
            **merged,
        )

    def gemini_sdk(self, **kwargs: Any) -> Any:
        merged = {**self._kwargs, **kwargs}
        return self._client.gemini_sdk(
            self.agent_id,
            self.user_id,
            session_id=self.session_id,
            budget_cap_inr=self.budget_cap_inr,
            **merged,
        )

    def grok_sdk(self, **kwargs: Any) -> Any:
        merged = {**self._kwargs, **kwargs}
        return self._client.grok_sdk(
            self.agent_id,
            self.user_id,
            session_id=self.session_id,
            budget_cap_inr=self.budget_cap_inr,
            **merged,
        )
