from .billing_event import BILLING_EVENT_SCHEMA_VERSION, BillingEvent
from .client import MetricAI, MetricAIClient
from .config import MetricAIConfig
from .routing_sdk import RoutingConfig, RoutingManager
from .context import attribution_scope, get_attribution, named_session
from .context_estimate import estimate_context_tokens
from .exceptions import (
    MetricAIAuthError,
    MetricAIConfigError,
    MetricAIError,
    MetricAIFeatureNotAvailableError,
    MetricAIProviderError,
    MetricAIProxyError,
    MetricAIQuotaExhaustedError,
    MetricAIRateLimitError,
    MetricAIStreamError,
)
from .retry import QuotaStatus, RetryConfig
from .mcp_track import track_mcp_call
from .metricai_session import MetricAISession
from .proxy_client_session import MetricAIProxyClientSession
from .session import SessionContext  # deprecated — not in __all__
from .runtime import get_metricai, init
from .instrumentation import instrument
from .types import OutcomeConfigModel
from .timing import TimedCall, timed_call
from .conversation_budget import ConversationBudgetRuntime
from .message_context import estimate_messages_prompt_tokens, trim_messages_keep_recent_user_turns
from .tool_output_policy import compact_tool_result
from .usage_normalizer import merge_normalized_usage, normalize_llm_usage
from .workflow.agent import AgentResponse, MetricAIAgent

# Alias for imports like: `from metricai import metricaiclient`
metricaiclient = MetricAI

__all__ = [
    "MetricAI",
    "MetricAIClient",
    "MetricAIConfig",
    "RoutingConfig",
    "RoutingManager",
    "MetricAIProxyClientSession",
    "metricaiclient",
    "MetricAISession",
    "MetricAIError",
    "MetricAIConfigError",
    "MetricAIAuthError",
    "MetricAIProviderError",
    "MetricAIProxyError",
    "MetricAIQuotaExhaustedError",
    "MetricAIFeatureNotAvailableError",
    "MetricAIRateLimitError",
    "MetricAIStreamError",
    "RetryConfig",
    "QuotaStatus",
    "estimate_context_tokens",
    "track_mcp_call",
    "timed_call",
    "TimedCall",
    "BillingEvent",
    "BILLING_EVENT_SCHEMA_VERSION",
    "init",
    "get_metricai",
    "instrument",
    "OutcomeConfigModel",
    "get_attribution",
    "attribution_scope",
    "named_session",
    "ConversationBudgetRuntime",
    "normalize_llm_usage",
    "merge_normalized_usage",
    "compact_tool_result",
    "estimate_messages_prompt_tokens",
    "trim_messages_keep_recent_user_turns",
    "MetricAIAgent",
    "AgentResponse",
]

__version__ = "0.5.1"
