﻿"""
HTTP proxy wrapper for OpenAI-shaped calls via MetricAI (``/v1/proxy/{provider}``).

**Provider category:** ``llm`` (token-metered server-side on the proxy).

**Fail-open:** Hosted MetricAI proxy endpoints fail open server-side. This local convenience
wrapper still maps HTTP errors it receives to typed exceptions.
"""

import json
import sys

import httpx
from typing import Any, AsyncIterator, Callable, Dict, Iterator, Optional

from .exceptions import (
    AuthenticationError,
    InsufficientBalanceError,
    ProviderError,
    ProxyBudgetCapExceededError,
)
from .provider_client import build_metricai_auth_headers
from .session import SessionContext
from .streaming import StreamingResponse


# OpenAI-shaped providers POST to .../chat/completions so the server returns native
# OpenAI ``chat.completion`` JSON (official SDK parity). Claude uses the Anthropic path.
PROVIDER_PATHS = {
    "openai": "/v1/proxy/openai/chat/completions",
    "claude": "/v1/proxy/claude",
    "gemini": "/v1/proxy/gemini/chat/completions",
    "grok": "/v1/proxy/grok/chat/completions",
}


class MetricAIProxy:
    """
    Proxy wrapper for a single LLM provider through MetricAI.

    **Tool calls and metering:** Pass OpenAI-shaped ``tools=[...]`` on ``complete`` / ``stream`` (via
    ``**kwargs``) so the proxy can classify declared tool types. If the request body cannot include a
    ``tools`` array (non-OpenAI shapes), you may pass canonical types in
    ``provider_extras={"metricai_tool_types_declared": ["web_search", ...]}`` ΓÇö detection from the
    request/response still overrides this when present. A future ``metricai-js`` client should mirror
    the same JSON fields.

    Usage:
        proxy = client.openai(session=session_ctx)
        response = proxy.complete(model="gpt-4o-mini", messages=[...], tools=[...])
        stream   = proxy.stream(model="gpt-4o-mini", messages=[...], tools=[...])
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        provider: str,
        session: Optional[SessionContext] = None,
        timeout: int = 60,
        *,
        extra_headers: Optional[Dict[str, str]] = None,
        routing_sink: Optional[Callable[[httpx.Headers], None]] = None,
    ):
        self._base_url = base_url.rstrip("/")
        self._api_key  = api_key
        self._provider = provider
        self._session  = session
        self._timeout  = timeout
        self._path     = PROVIDER_PATHS[provider]
        self._extra_headers = dict(extra_headers) if extra_headers else {}
        self._routing_sink = routing_sink

    def _build_headers(self) -> dict:
        headers = {
            **build_metricai_auth_headers(self._api_key),
            "Content-Type": "application/json",
        }
        if self._session:
            headers.update(self._session.to_headers())
        headers.update(self._extra_headers)
        return headers

    def _maybe_capture_routing(self, headers: httpx.Headers) -> None:
        if self._routing_sink:
            self._routing_sink(headers)

    def _handle_error(self, response: httpx.Response):
        if response.status_code == 401:
            try:
                body = response.json()
                detail = body.get("detail", response.text)
            except Exception:
                detail = response.text
            if isinstance(detail, list):
                detail = json.dumps(detail)
            msg = str(detail).strip() if detail else "Unauthorized"
            raise AuthenticationError(msg)
        if response.status_code == 402:
            try:
                data = response.json()
            except Exception:
                data = {}
            err = data.get("error")
            if err == "budget_exceeded" or data.get("cap_inr") is not None:
                cap = data.get("cap_inr")
                cur = data.get("current_spend_inr")
                try:
                    cap_f = float(cap) if cap is not None else None
                except (TypeError, ValueError):
                    cap_f = None
                try:
                    cur_f = float(cur) if cur is not None else None
                except (TypeError, ValueError):
                    cur_f = None
                msg = data.get("message") or data.get("detail")
                if not isinstance(msg, str):
                    msg = str(msg) if msg else None
                raise ProxyBudgetCapExceededError(
                    agent_id=data.get("agent_id"),
                    cap_inr=cap_f,
                    current_spend_inr=cur_f,
                    message=msg,
                )
            bal_raw = data.get("wallet_balance", 0.0)
            try:
                balance = float(bal_raw)
            except (TypeError, ValueError):
                balance = 0.0
            detail = data.get("detail")
            if isinstance(detail, list):
                detail = json.dumps(detail)
            msg = None
            if isinstance(detail, str) and detail.strip():
                msg = detail.strip()
            raise InsufficientBalanceError(balance, message=msg)
        if response.status_code >= 400:
            try:
                msg = response.json().get("detail", response.text)
            except Exception:
                msg = response.text
            raise ProviderError(self._provider, response.status_code, msg)

    def complete(self, model: str, messages: list, **kwargs) -> dict:
        """
        Non-streaming completion. Returns the upstream JSON body: native OpenAI
        ``chat.completion`` shape for openai/gemini/grok (``.../chat/completions`` route).

        Args:
            model:    LLM model name (e.g. 'gpt-4o-mini')
            messages: OpenAI-style messages list
            **kwargs: Provider params (e.g. ``temperature``, ``max_tokens``). Include ``tools=`` for
                tool definitions; optional ``provider_extras`` may contain
                ``metricai_tool_types_declared`` when ``tools`` is not in OpenAI shape. Server-side
                detection from the forwarded request/response takes precedence when both exist.
        """
        payload = {"model": model, "messages": messages, "stream": False, **kwargs}

        with httpx.Client(timeout=self._timeout) as client:
            response = client.post(
                f"{self._base_url}{self._path}",
                json=payload,
                headers=self._build_headers(),
            )

        self._handle_error(response)
        self._maybe_capture_routing(response.headers)
        return response.json()

    async def acomplete(self, model: str, messages: list, **kwargs) -> dict:
        """Async version of ``complete()``; same ``tools`` / ``provider_extras`` behavior."""
        payload = {"model": model, "messages": messages, "stream": False, **kwargs}

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(
                f"{self._base_url}{self._path}",
                json=payload,
                headers=self._build_headers(),
            )

        self._handle_error(response)
        self._maybe_capture_routing(response.headers)
        return response.json()

    def stream(self, model: str, messages: list, **kwargs) -> StreamingResponse:
        """
        Streaming completion. Returns a StreamingResponse you can iterate over.

        Pass ``tools=`` and other kwargs like ``complete()`` for correct tool metering on the final
        assistant message.

        Example:
            for chunk in proxy.stream(model="gpt-4o-mini", messages=[...]):
                delta = chunk["choices"][0]["delta"].get("content", "")
                print(delta, end="", flush=True)
        """
        payload = {
            "model":    model,
            "messages": messages,
            "stream":   True,
            **kwargs,
        }
        headers = {**self._build_headers(), "Accept": "text/event-stream"}

        client = httpx.Client(timeout=self._timeout)
        stream_cm = client.stream(
            "POST",
            f"{self._base_url}{self._path}",
            json=payload,
            headers=headers,
        )
        try:
            response = stream_cm.__enter__()
        except BaseException:
            client.close()
            raise
        try:
            self._handle_error(response)
        except BaseException:
            stream_cm.__exit__(*sys.exc_info())
            client.close()
            raise
        self._maybe_capture_routing(response.headers)
        return StreamingResponse(
            response,
            self._provider,
            stream_cm=stream_cm,
            client=client,
        )

    async def astream(self, model: str, messages: list, **kwargs):
        """Async streaming; same tool-related kwargs as ``stream()``."""
        payload = {
            "model":    model,
            "messages": messages,
            "stream":   True,
            **kwargs,
        }
        headers = {**self._build_headers(), "Accept": "text/event-stream"}

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            async with client.stream(
                "POST",
                f"{self._base_url}{self._path}",
                json=payload,
                headers=headers,
            ) as response:
                self._handle_error(response)
                self._maybe_capture_routing(response.headers)
                async for chunk in StreamingResponse(response, self._provider):
                    yield chunk
