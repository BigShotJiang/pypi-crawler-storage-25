"""
Abstract provider contract for MetricAI integrations.

**Provider category:** Declared per implementation (``llm`` | ``model_gateway`` | ``tool``).

**Fail-open:** Interface only; concrete integrations must catch errors and never block user calls.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from ..billing_event import ProviderCategory


@runtime_checkable
class MetricAIProvider(Protocol):
    """Every file in ``metricai.providers`` should expose a small module-level contract."""

    provider_id: str
    provider_category: ProviderCategory

    def activate(self, client: Any) -> None:
        """Register hooks (optional integrations) or no-op for pure proxy routes."""
        ...
