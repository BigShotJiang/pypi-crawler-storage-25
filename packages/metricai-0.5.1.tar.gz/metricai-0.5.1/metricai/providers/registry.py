"""
Central registry: one import line per provider module so new providers stay isolated.

**Provider category:** N/A.

**Fail-open:** Activation catches exceptions per provider.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Callable, Dict, List, Optional

if TYPE_CHECKING:
    from metricai.client import MetricAI

_LOG = logging.getLogger(__name__)

_HOOKS: Dict[str, Callable[["MetricAI"], None]] = {}


def register_hook(provider_id: str, fn: Callable[["MetricAI"], None]) -> None:
    _HOOKS[provider_id] = fn


def activate(client: "MetricAI", only: Optional[List[str]]) -> None:
    keys = list(_HOOKS.keys()) if only is None else [k for k in only if k in _HOOKS]
    for k in keys:
        try:
            _HOOKS[k](client)
        except Exception as e:
            _LOG.warning("Provider '%s' failed to activate: %s", k, e, exc_info=True)
            continue


def _load_builtin_providers() -> None:
    # One import per provider file — add new providers here only.
    from . import bedrock as _bedrock  # noqa: F401
    from . import claude_route as _claude_route  # noqa: F401
    from . import gemini_route as _gemini_route  # noqa: F401
    from . import grok_route as _grok_route  # noqa: F401
    from . import openai_route as _openai_route  # noqa: F401
    from . import tavily_provider as _tavily_provider  # noqa: F401


_load_builtin_providers()
