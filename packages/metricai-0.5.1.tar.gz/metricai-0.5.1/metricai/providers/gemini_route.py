"""
Google Gemini proxy route registration (OpenAI-compatible ``/v1/proxy/gemini``).

**Provider category:** ``llm``.

**Fail-open:** Hook is a no-op; :meth:`metricai.client.MetricAI.gemini_sdk` unchanged.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..billing_event import ProviderCategory
from .registry import register_hook

if TYPE_CHECKING:
    from metricai.client import MetricAI

provider_id = "gemini"
provider_category: ProviderCategory = "llm"


def _activate(client: "MetricAI") -> None:
    from ..instrumentation import patch_gemini

    patch_gemini(client)


register_hook("gemini", _activate)
