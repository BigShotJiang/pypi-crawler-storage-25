"""
AWS Bedrock ``bedrock-runtime`` client instrumentation (model gateway — token pricing per underlying model).

**Provider category:** ``model_gateway`` (``cost_unit``: ``token_gateway``).

**Fail-open:** Any exception in metering paths falls back to returning the raw Bedrock response/stream
unchanged; telemetry failures never block execution.
"""

from __future__ import annotations

import base64
import io
import json
import logging
import time
import weakref
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, cast

_LOG = logging.getLogger(__name__)
_PRE_INIT_BEDROCK_CLIENTS: List[weakref.ReferenceType[Any]] = []

from ..billing_event import BillingEvent
from ..context import get_attribution

_DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "bedrock_pricing.json"


def _load_pricing() -> Dict[str, Any]:
    try:
        raw = _DATA_PATH.read_text(encoding="utf-8")
        return cast(Dict[str, Any], json.loads(raw))
    except Exception:
        return {"models": {}}


def _bedrock_model_id_candidates(model_id: str) -> list[str]:  # reliability-fix: FIX-8
    s = (model_id or "").strip()  # reliability-fix: FIX-8
    out: list[str] = []  # reliability-fix: FIX-8
    if s:  # reliability-fix: FIX-8
        out.append(s)  # reliability-fix: FIX-8
    if ":" in s:  # reliability-fix: FIX-8
        out.append(s.split(":", 1)[0])  # reliability-fix: FIX-8
        out.append(s.rsplit(":", 1)[0])  # strip trailing :vN  # reliability-fix: FIX-8
    return list(dict.fromkeys([x for x in out if x]))  # dedupe, preserve order  # reliability-fix: FIX-8


def _price_for_model(model_id: str) -> Tuple[Optional[float], Optional[float]]:  # reliability-fix: FIX-8
    """Resolve per-1K USD pricing; tries full id, first segment, and strip-last-``:`` suffix."""  # reliability-fix: FIX-8
    cfg = _load_pricing()  # reliability-fix: FIX-8
    models = cfg.get("models") or {}  # reliability-fix: FIX-8
    for cand in _bedrock_model_id_candidates(model_id):  # reliability-fix: FIX-8
        m = models.get(cand)  # reliability-fix: FIX-8
        if isinstance(m, dict):  # reliability-fix: FIX-8
            return (m.get("input_per_1k_usd"), m.get("output_per_1k_usd"))  # reliability-fix: FIX-8
    return None, None  # reliability-fix: FIX-8


def _extract_usage_from_json(parsed: Dict[str, Any]) -> Tuple[Optional[int], Optional[int]]:
    u = parsed.get("usage")
    if isinstance(u, dict):
        if u.get("input_tokens") is not None and u.get("output_tokens") is not None:
            return int(u["input_tokens"]), int(u["output_tokens"])
        if u.get("prompt_tokens") is not None and u.get("completion_tokens") is not None:
            return int(u["prompt_tokens"]), int(u["completion_tokens"])
    um = parsed.get("usageMetadata") or parsed.get("usage_metadata")
    if isinstance(um, dict):
        inp = um.get("inputTokens") or um.get("input_tokens") or um.get("promptTokens")
        out = um.get("outputTokens") or um.get("output_tokens") or um.get("completionTokens")
        if inp is not None and out is not None:
            return int(inp), int(out)
    metrics = parsed.get("amazon-bedrock-invocationMetrics") or parsed.get("InvocationMetrics")
    if isinstance(metrics, dict):
        inp = metrics.get("inputTokenCount")
        out = metrics.get("outputTokenCount")
        if inp is not None and out is not None:
            return int(inp), int(out)
    return None, None


def _read_body_bytes(body: Any) -> bytes:
    if body is None:
        return b""
    if isinstance(body, (bytes, bytearray)):
        return bytes(body)
    read = getattr(body, "read", None)
    if callable(read):
        try:
            return cast(bytes, read())
        except Exception:
            return b""
    return b""


def _emit(
    client_metricai: Any,
    *,
    model_id: str,
    latency_ms: int,
    inp: Optional[int],
    out: Optional[int],
    extra: Optional[Dict[str, Any]] = None,
) -> None:
    try:
        attr = get_attribution()
        agent_id = attr.agent_id
        user_id = attr.user_id
        session_id = attr.session_id
        if agent_id is None:
            agent_id = client_metricai.config.default_agent_id
        inp_p, out_p = _price_for_model(model_id)
        ev_extra: Dict[str, Any] = {
            "bedrock_model_id": model_id,
            "pricing_input_per_1k_usd": inp_p,
            "pricing_output_per_1k_usd": out_p,
        }
        if extra:
            ev_extra.update(extra)
        ev = BillingEvent(
            provider_name="aws-bedrock",
            model_name=model_id,
            provider_category="model_gateway",
            cost_unit="token_gateway",
            latency_ms=latency_ms,
            agent_id=agent_id,
            user_id=user_id,
            session_id=session_id,
            request_timestamp_iso=BillingEvent.now_iso(),
            input_tokens=inp,
            output_tokens=out,
            gateway_provider="aws-bedrock",
            extra=ev_extra,
        )
        client_metricai.track_billing_event(ev)
    except Exception:
        return


# __del__ is not guaranteed; also emit on GeneratorExit / full drain.  # reliability-fix: FIX-11
class _ResponseStreamWithTelemetry:  # reliability-fix: FIX-11
    """Idempotent _emit: abandoned streams get ``stream_interrupted=True``; full drain → ``False``."""

    def __init__(self, base_stream: Any, model_id_str: str, t0: float, client: Any) -> None:
        self._base = base_stream
        self._model_id = model_id_str
        self._t0 = t0
        self._client = client
        self._last_usage: Dict[str, Any] = {}
        self._telemetry_emitted = False

    def _emit_billing(self, stream_interrupted: bool) -> None:  # reliability-fix: FIX-11
        if self._telemetry_emitted:
            return
        self._telemetry_emitted = True
        try:
            ms = int((time.perf_counter() - self._t0) * 1000)
            _emit(
                self._client,
                model_id=self._model_id,
                latency_ms=ms,
                inp=self._last_usage.get("i"),
                out=self._last_usage.get("o"),
                extra={
                    "api": "invoke_model_with_response_stream",  # reliability-fix: FIX-11
                    "stream_interrupted": stream_interrupted,  # reliability-fix: FIX-11
                },
            )
        except Exception:  # reliability-fix: FIX-11
            return

    def __iter__(self) -> Any:  # type: ignore[return]
        try:
            for ev in self._base:
                try:
                    chunk = (
                        ev.get("chunk")
                        if isinstance(ev, dict)
                        else getattr(ev, "get", lambda _k: None)("chunk")
                    )
                    if chunk:
                        b64 = chunk.get("bytes") if isinstance(chunk, dict) else None
                        if b64:
                            raw = base64.b64decode(b64)
                            try:
                                j = json.loads(raw.decode("utf-8", errors="replace"))
                                i, o = _extract_usage_from_json(j)
                                if i is not None:
                                    self._last_usage["i"] = i
                                if o is not None:
                                    self._last_usage["o"] = o
                            except Exception:  # reliability-fix: FIX-11
                                pass
                except Exception:  # reliability-fix: FIX-11
                    pass
                yield ev
        except GeneratorExit:  # reliability-fix: FIX-11
            self._emit_billing(stream_interrupted=True)
            raise
        except Exception:  # reliability-fix: FIX-11
            self._emit_billing(stream_interrupted=True)
            raise
        self._emit_billing(stream_interrupted=False)  # reliability-fix: FIX-11

    def __del__(self) -> None:  # reliability-fix: FIX-11
        if not self._telemetry_emitted:
            self._emit_billing(stream_interrupted=True)  # reliability-fix: FIX-11


# reliability-fix: FIX-11
class _ConverseStreamWithTelemetry:  # reliability-fix: FIX-11
    """Converse stream variant of :class:`_ResponseStreamWithTelemetry` (usage in dict items)."""

    def __init__(self, base: Any, model_id_str: str, t0: float, client: Any) -> None:  # reliability-fix: FIX-11
        self._base = base
        self._model_id = model_id_str
        self._t0 = t0
        self._client = client
        self._last_i: Optional[int] = None
        self._last_o: Optional[int] = None
        self._telemetry_emitted = False

    def _emit_billing(self, stream_interrupted: bool) -> None:  # reliability-fix: FIX-11
        if self._telemetry_emitted:
            return
        self._telemetry_emitted = True
        try:  # reliability-fix: FIX-11
            ms = int((time.perf_counter() - self._t0) * 1000)  # reliability-fix: FIX-11
            _emit(
                self._client,
                model_id=self._model_id,
                latency_ms=ms,
                inp=self._last_i,  # reliability-fix: FIX-11
                out=self._last_o,  # reliability-fix: FIX-11
                extra={  # reliability-fix: FIX-11
                    "api": "converse_stream",  # reliability-fix: FIX-11
                    "stream_interrupted": stream_interrupted,  # reliability-fix: FIX-11
                },
            )  # reliability-fix: FIX-11
        except Exception:  # reliability-fix: FIX-11
            return

    def __iter__(self) -> Any:  # type: ignore[return]
        try:  # reliability-fix: FIX-11
            for item in self._base:  # reliability-fix: FIX-11
                try:  # reliability-fix: FIX-11
                    if isinstance(item, dict):  # reliability-fix: FIX-11
                        meta = item.get("metadata") or item  # reliability-fix: FIX-11
                        if isinstance(meta, dict):  # reliability-fix: FIX-11
                            u = meta.get("usage")  # reliability-fix: FIX-11
                            if isinstance(u, dict):  # reliability-fix: FIX-11
                                if u.get("inputTokens") is not None:  # reliability-fix: FIX-11
                                    self._last_i = int(u["inputTokens"])  # reliability-fix: FIX-11
                                if u.get("outputTokens") is not None:  # reliability-fix: FIX-11
                                    self._last_o = int(u["outputTokens"])  # reliability-fix: FIX-11
                except Exception:  # reliability-fix: FIX-11
                    pass
                yield item
        except GeneratorExit:  # reliability-fix: FIX-11
            self._emit_billing(stream_interrupted=True)  # reliability-fix: FIX-11
            raise
        except Exception:  # reliability-fix: FIX-11
            self._emit_billing(stream_interrupted=True)  # reliability-fix: FIX-11
            raise
        self._emit_billing(stream_interrupted=False)  # reliability-fix: FIX-11

    def __del__(self) -> None:  # reliability-fix: FIX-11
        if not self._telemetry_emitted:
            self._emit_billing(stream_interrupted=True)  # reliability-fix: FIX-11


def wrap_bedrock_runtime_client(runtime_client: Any, metricai_client: Any) -> Any:
    """
    Wrap a boto3 ``bedrock-runtime`` client: ``invoke_model``, streaming invoke, ``converse``, and
    ``converse_stream`` emit :class:`~metricai.billing_event.BillingEvent` after completion.
    """
    if getattr(runtime_client, "_metricai_wrapped", False):
        return runtime_client

    orig_invoke = runtime_client.invoke_model
    orig_invoke_stream = getattr(runtime_client, "invoke_model_with_response_stream", None)
    orig_converse = getattr(runtime_client, "converse", None)
    orig_converse_stream = getattr(runtime_client, "converse_stream", None)

    def invoke_model(*args: Any, **kwargs: Any) -> Any:
        t0 = time.perf_counter()
        model_id = kwargs.get("modelId") or kwargs.get("model_id") or (args[0] if args else None)
        model_id_str = str(model_id or "")
        resp = orig_invoke(*args, **kwargs)
        try:
            if isinstance(resp, dict) and "body" in resp:
                raw = _read_body_bytes(resp.get("body"))
                parsed: Dict[str, Any] = {}
                if raw:
                    try:
                        parsed = json.loads(raw.decode("utf-8", errors="replace"))
                    except Exception:
                        parsed = {}
                inp, out = _extract_usage_from_json(parsed)
                ms = int((time.perf_counter() - t0) * 1000)
                _emit(
                    metricai_client,
                    model_id=model_id_str,
                    latency_ms=ms,
                    inp=inp,
                    out=out,
                    extra={"api": "invoke_model"},
                )
                resp["body"] = io.BytesIO(raw)
        except Exception:
            pass
        return resp

    def invoke_model_with_response_stream(*args: Any, **kwargs: Any) -> Any:
        t0 = time.perf_counter()
        model_id = kwargs.get("modelId") or kwargs.get("model_id") or (args[0] if args else None)
        model_id_str = str(model_id or "")
        resp = orig_invoke_stream(*args, **kwargs) if orig_invoke_stream else None
        if resp is None:
            return resp
        stream = resp.get("body") if isinstance(resp, dict) else getattr(resp, "get", lambda _k: None)("body")
        if stream is None:
            return resp

        if isinstance(resp, dict):
            out = dict(resp)
            out["body"] = _ResponseStreamWithTelemetry(  # reliability-fix: FIX-11
                stream,  # type: ignore[misc]  # reliability-fix: FIX-11
                model_id_str,  # type: ignore[misc]  # reliability-fix: FIX-11
                t0,  # type: ignore[misc]  # reliability-fix: FIX-11
                metricai_client,  # type: ignore[misc]  # reliability-fix: FIX-11
            )
            return out
        return resp

    def converse(*args: Any, **kwargs: Any) -> Any:
        t0 = time.perf_counter()
        model_id = kwargs.get("modelId") or kwargs.get("model_id")
        if model_id is None and args:
            model_id = args[0].get("modelId") if isinstance(args[0], dict) else None
        model_id_str = str(model_id or "")
        out = orig_converse(*args, **kwargs) if orig_converse else None
        try:
            parsed = out if isinstance(out, dict) else {}
            usage = parsed.get("usage") if isinstance(parsed, dict) else {}
            inp = out_t = None
            if isinstance(usage, dict):
                inp = usage.get("inputTokens") or usage.get("input_tokens")
                out_t = usage.get("outputTokens") or usage.get("output_tokens")
            ms = int((time.perf_counter() - t0) * 1000)
            _emit(
                metricai_client,
                model_id=model_id_str,
                latency_ms=ms,
                inp=int(inp) if inp is not None else None,
                out=int(out_t) if out_t is not None else None,
                extra={"api": "converse"},
            )
        except Exception:
            pass
        return out

    def converse_stream(*args: Any, **kwargs: Any) -> Any:
        t0 = time.perf_counter()
        model_id = kwargs.get("modelId") or kwargs.get("model_id")
        if model_id is None and args:
            model_id = args[0].get("modelId") if isinstance(args[0], dict) else None
        model_id_str = str(model_id or "")
        stream_out = orig_converse_stream(*args, **kwargs) if orig_converse_stream else None
        if stream_out is None:
            return stream_out

        try:  # reliability-fix: FIX-11
            if isinstance(stream_out, dict) and "stream" in stream_out:  # reliability-fix: FIX-11
                outd = dict(stream_out)  # reliability-fix: FIX-11
                outd["stream"] = _ConverseStreamWithTelemetry(  # type: ignore[misc]  # reliability-fix: FIX-11
                    stream_out["stream"],  # reliability-fix: FIX-11
                    model_id_str,  # type: ignore[misc]  # reliability-fix: FIX-11
                    t0,  # type: ignore[misc]  # reliability-fix: FIX-11
                    metricai_client,  # type: ignore[misc]  # reliability-fix: FIX-11
                )  # type: ignore[misc]  # reliability-fix: FIX-11
                return outd  # reliability-fix: FIX-11
        except Exception:  # reliability-fix: FIX-11
            pass  # reliability-fix: FIX-11
        return _ConverseStreamWithTelemetry(  # type: ignore[return]  # reliability-fix: FIX-11
            cast(Any, stream_out),  # type: ignore[misc]  # reliability-fix: FIX-11
            model_id_str,  # type: ignore[misc]  # reliability-fix: FIX-11
            t0,  # type: ignore[misc]  # reliability-fix: FIX-11
            metricai_client,  # type: ignore[misc]  # reliability-fix: FIX-11
        )  # type: ignore[misc]  # reliability-fix: FIX-11

    runtime_client.invoke_model = invoke_model
    if orig_invoke_stream:
        runtime_client.invoke_model_with_response_stream = invoke_model_with_response_stream
    if orig_converse:
        runtime_client.converse = converse
    if orig_converse_stream:
        runtime_client.converse_stream = converse_stream
    setattr(runtime_client, "_metricai_wrapped", True)
    return runtime_client


def instrument_boto3_client(client: Any, metricai: Any) -> Any:
    """Wrap an existing ``bedrock-runtime`` client created before :func:`metricai.runtime.init`."""
    return wrap_bedrock_runtime_client(client, metricai)


def _activate(metricai: Any) -> None:
    try:
        import boto3
    except Exception:
        return
    if getattr(boto3, "_metricai_bedrock_patched", False):
        return
    pre = [c() for c in _PRE_INIT_BEDROCK_CLIENTS if c() is not None]
    if pre:
        _LOG.warning(
            "MetricAI: %d bedrock-runtime client(s) were created before init(); "
            "call metricai.providers.bedrock.instrument_boto3_client(client) to meter them.",
            len(pre),
        )
    real_client = boto3.client

    def _client(service_name: str, *args: Any, **kwargs: Any) -> Any:
        c = real_client(service_name, *args, **kwargs)
        if service_name == "bedrock-runtime":
            if not getattr(boto3, "_metricai_bedrock_patched", False):
                _PRE_INIT_BEDROCK_CLIENTS.append(weakref.ref(c))
            try:
                return wrap_bedrock_runtime_client(c, metricai)
            except Exception:
                return c
        return c

    boto3.client = _client  # type: ignore[assignment]
    setattr(boto3, "_metricai_bedrock_patched", True)


from .registry import register_hook

register_hook("bedrock", _activate)
