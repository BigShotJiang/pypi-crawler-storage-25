"""
OpenAI-compatible proxy route registration (HTTP ``/v1/proxy/openai``).

**Provider category:** ``llm`` (token-metered via MetricAI proxy + telemetry).

**Fail-open:** Hook is a no-op; proxy and :meth:`metricai.client.MetricAI.openai_sdk` behave as before.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..billing_event import ProviderCategory
from .registry import register_hook

if TYPE_CHECKING:
    from metricai.client import MetricAI

provider_id = "openai"
provider_category: ProviderCategory = "llm"


def _activate(client: "MetricAI") -> None:
    from ..instrumentation import patch_openai

    patch_openai(client)


register_hook("openai", _activate)
