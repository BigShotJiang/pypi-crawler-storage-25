"""
Anthropic Claude proxy route registration (HTTP ``/v1/proxy/claude``).

**Provider category:** ``llm``.

**Fail-open:** Hook is a no-op; :meth:`metricai.client.MetricAI.anthropic_sdk` unchanged.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..billing_event import ProviderCategory
from .registry import register_hook

if TYPE_CHECKING:
    from metricai.client import MetricAI

provider_id = "claude"
provider_category: ProviderCategory = "llm"


def _activate(client: "MetricAI") -> None:
    from ..instrumentation import patch_anthropic

    patch_anthropic(client)


register_hook("claude", _activate)
