"""
Tavily search client instrumentation (tool provider — per-call metering, not tokens).

**Provider category:** ``tool`` (``cost_unit``: ``api_call``).

**Fail-open:** Search results are always returned; telemetry errors are swallowed.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, cast

from ..billing_event import BillingEvent
from ..context import get_attribution

_DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "tavily_pricing.json"


def _load_pricing() -> Dict[str, Any]:
    try:
        return cast(Dict[str, Any], json.loads(_DATA_PATH.read_text(encoding="utf-8")))
    except Exception:
        return {}


def _emit_tool(
    metricai: Any,
    *,
    latency_ms: int,
    search_type: str,
    query_preview: str,
    max_results: Optional[int],
    cost_usd: float,
) -> None:
    try:
        attr = get_attribution()
        agent_id = attr.agent_id or metricai.config.default_agent_id
        user_id = attr.user_id
        session_id = attr.session_id
        ev = BillingEvent(
            provider_name="tavily",
            model_name=None,
            provider_category="tool",
            cost_unit="api_call",
            latency_ms=latency_ms,
            agent_id=agent_id,
            user_id=user_id,
            session_id=session_id,
            request_timestamp_iso=BillingEvent.now_iso(),
            input_tokens=None,
            output_tokens=None,
            tool_call_count=1,
            extra={
                "tavily_search_type": search_type,
                "query_preview": query_preview[:500],
                "max_results": max_results,
                "estimated_cost_usd": cost_usd,
            },
        )
        metricai.track_billing_event(ev)
    except Exception:
        return


def wrap_tavily_client(client: Any, metricai: Any) -> Any:
    """Wrap a ``tavily.TavilyClient`` instance (``search`` and ``get_search_context``)."""
    if getattr(client, "_metricai_wrapped", False):
        return client
    pricing = _load_pricing()
    basic = float(pricing.get("basic_search_usd") or 0.0)
    adv = float(pricing.get("advanced_search_usd") or basic)
    ctx_usd = float(pricing.get("get_search_context_usd") or basic)

    orig_search = client.search
    orig_ctx = getattr(client, "get_search_context", None)

    def search(*args: Any, **kwargs: Any) -> Any:
        t0 = time.perf_counter()
        out = orig_search(*args, **kwargs)
        try:
            q = ""
            if args:
                q = str(args[0])
            elif kwargs.get("query"):
                q = str(kwargs.get("query"))
            max_results = kwargs.get("max_results")
            adv_flag = bool(kwargs.get("search_depth") == "advanced" or kwargs.get("advanced") is True)
            ms = int((time.perf_counter() - t0) * 1000)
            tier = "advanced" if adv_flag else "basic"
            cost = adv if adv_flag else basic
            _emit_tool(
                metricai,
                latency_ms=ms,
                search_type=tier,
                query_preview=q,
                max_results=int(max_results) if max_results is not None else None,
                cost_usd=cost,
            )
        except Exception:
            pass
        return out

    def get_search_context(*args: Any, **kwargs: Any) -> Any:
        t0 = time.perf_counter()
        if orig_ctx is None:
            return None
        out = orig_ctx(*args, **kwargs)
        try:
            q = str(kwargs.get("query") or (args[0] if args else ""))
            max_results = kwargs.get("max_results")
            ms = int((time.perf_counter() - t0) * 1000)
            _emit_tool(
                metricai,
                latency_ms=ms,
                search_type="get_search_context",
                query_preview=q,
                max_results=int(max_results) if max_results is not None else None,
                cost_usd=ctx_usd,
            )
        except Exception:
            pass
        return out

    client.search = search  # type: ignore[assignment]
    if orig_ctx is not None:
        client.get_search_context = get_search_context  # type: ignore[assignment]
    setattr(client, "_metricai_wrapped", True)
    return client


def _activate(metricai: Any) -> None:
    try:
        from tavily import TavilyClient  # type: ignore
    except Exception:
        return
    if getattr(TavilyClient, "_metricai_class_patched", False):
        return
    orig_init = TavilyClient.__init__

    def __init__(self: Any, *args: Any, **kwargs: Any) -> None:
        orig_init(self, *args, **kwargs)
        try:
            wrap_tavily_client(self, metricai)
        except Exception:
            pass

    TavilyClient.__init__ = __init__  # type: ignore[assignment]
    setattr(TavilyClient, "_metricai_class_patched", True)


from .registry import register_hook

register_hook("tavily", _activate)
