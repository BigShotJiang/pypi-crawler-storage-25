"""
xAI Grok proxy route registration (``/v1/proxy/grok``).

**Provider category:** ``llm``.

**Fail-open:** Hook is a no-op; :meth:`metricai.client.MetricAI.grok_sdk` unchanged.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..billing_event import ProviderCategory
from .registry import register_hook

if TYPE_CHECKING:
    from metricai.client import MetricAI

provider_id = "grok"
provider_category: ProviderCategory = "llm"


def _activate(client: "MetricAI") -> None:
    from ..instrumentation import patch_grok

    patch_grok(client)


register_hook("grok", _activate)
