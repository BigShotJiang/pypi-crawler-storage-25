"""Pluggable provider integrations (proxy routes, Bedrock, Tavily, …)."""

from __future__ import annotations

from .bedrock import wrap_bedrock_runtime_client
from .registry import activate, register_hook
from .tavily_provider import wrap_tavily_client

__all__ = [
    "activate",
    "register_hook",
    "wrap_bedrock_runtime_client",
    "wrap_tavily_client",
]
