﻿"""
MetricAI user-facing client: proxy routes, native SDK factories, telemetry, sessions.

**Provider category:** N/A (orchestrates LLM proxy + :class:`~metricai.billing_event.BillingEvent` emission).

**Fail-open:** Telemetry transport errors do not raise unless ``raise_on_error=True``; budget/session
helpers swallow errors on best-effort server calls.
"""

import logging
import os
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import httpx
import json
from typing import Any, Dict, List, Literal, Optional, Tuple, Union

from .config import (
    DEFAULT_PROXY_BASE_URL,
    MetricAIConfig,
    llm_keys_to_proxy_headers,
)
from .exceptions import AuthenticationError
from .headers import build_proxy_attribution_headers
from .provider_client import build_metricai_auth_headers, build_provider_sdk_kwargs
from .metricai_session import MetricAISession
from .payload import (
    build_track_payload,
    compute_billable_inr,
    new_idempotency_key,
    outcome_charge_matched,
)
from .billing_event import BillingEvent
from .proxy_transport import MetricAIProxy
from .session import SessionContext
from .stream_track import AsyncStreamingTrackContext, StreamingTrackContext
from .telemetry_http import TelemetryTransport
from .routing_sdk import RoutingConfig, RoutingManager, routing_headers_from_config

_LOG = logging.getLogger(__name__)
from .types import (
    Modalities,
    OutcomeConfig,
    SessionDetail,
    SessionState,
    SimulationResult,
    Tool,
    TrackResult,
    UsageStats,
    WalletBalance,
)


DEFAULT_BASE_URL = DEFAULT_PROXY_BASE_URL
DEFAULT_TELEMETRY_PATH = "/v1/sdk/events"
ProviderName = Literal["openai", "anthropic", "gemini", "bedrock", "grok"]

_PROVIDER_ENV_KEYS = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "claude": "ANTHROPIC_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "grok": "GROK_API_KEY",
}


class MetricAI:
    """
    Main MetricAI client.

    Quickstart:
        from metricai import MetricAI, timed_call

        client = MetricAI(api_key="metricai_...")

        # (a) Basic proxy call ΓÇö unchanged
        response = client.openai().complete(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Hello"}],
        )

        # (b) Session tracking with budget cap (telemetry + proxy headers)
        with MetricAISession(
            client, agent_id="booking-agent", user_id="user_123", max_budget_inr=50.0
        ) as session:
            session.track(provider="openai", model="gpt-4o-mini", input_tokens=100, output_tokens=50)

        # (c) Streaming with tool calls (wrap your SSE iterator)
        with client.track_stream(
            provider="openai",
            model="gpt-4o-mini",
            tools=[{"name": "web_search", "type": "web_search", "invoked": True}],
        ) as st:
            for line in raw_sse_lines:
                st.feed_sse_data_line(line)

        # (d) Outcome billing: simulate first, then live
        client.track(
            provider="openai",
            model="gpt-4o-mini",
            outcome={
                "success": True,
                "outcome_type": "booking_confirmed",
                "charge_on_success_inr": 2.5,
            },
            simulate=True,
        )
        with timed_call() as t:
            _ = run_agent_task()
        client.track(
            provider="openai",
            model="gpt-4o-mini",
            outcome={"success": True, "charge_on_success_inr": 2.5},
            latency_ms=t.elapsed_ms,
        )

        # Legacy: proxy session headers (Phase 1)
        with client.session(agent_id="booking-agent", user_id="user_123") as session:
            client.openai(session=session).complete(model="gpt-4o-mini", messages=[...])
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 60,
        *,
        provider: Optional[ProviderName] = None,
        provider_key: Optional[str] = None,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        billing_mode: Optional[str] = None,
        budget_cap_inr: Optional[float] = None,
        graph_id: Optional[str] = None,
        node_id: Optional[str] = None,
        crew_id: Optional[str] = None,
        task_id: Optional[str] = None,
        outcome_rule_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        outcome_threshold: Optional[float] = None,
        config: Optional[MetricAIConfig] = None,
        telemetry_events_path: str = DEFAULT_TELEMETRY_PATH,
        telemetry_base_url: Optional[str] = None,
        telemetry_timeout_seconds: float = 3.0,
        max_retries: int = 2,
        enable_buffer: bool = True,
        raise_on_error: bool = False,
        extra_proxy_headers: Optional[Dict[str, str]] = None,
        mode: Literal["byok", "managed"] = "byok",
        llm_keys: Optional[Dict[str, str]] = None,
        default_billing_mode: Literal["usage", "outcome", "hybrid"] = "hybrid",
        default_budget_cap_inr: Optional[float] = None,
        fail_open: bool = True,
        environment: Literal["production", "sandbox"] = "production",
        default_agent_id: str = "default-agent",
        environment_tag: Optional[str] = None,
        active_providers: Optional[Tuple[str, ...]] = None,
        routing: Optional[RoutingConfig] = None,
        background_telemetry: bool = False,  # reliability-fix: FIX-6
    ):
        """
        background_telemetry (bool, default False):
            When True, telemetry POSTs run in a background thread.
            Recommended for web servers. track() returns None immediately.
            Call client.shutdown() on application exit to flush pending events.
        """  # reliability-fix: FIX-6
        resolved_key = api_key or os.environ.get("METRICAI_API_KEY")
        if config is not None and not resolved_key:
            resolved_key = config.api_key
        if not resolved_key:
            raise AuthenticationError("MetricAI API key is required.")

        provider_name = (provider or "openai").strip().lower()
        if provider_name not in ("openai", "anthropic", "gemini", "bedrock", "grok"):
            raise ValueError(
                "Unsupported provider: "
                f"{provider!r}. Supported: openai, anthropic, gemini, bedrock, grok"
            )

        proxy_base = (
            base_url
            or os.environ.get("METRICAI_PROXY_URL")
            or (config.proxy_base_url if config is not None else DEFAULT_BASE_URL)
        ).rstrip("/")

        merged_llm: Dict[str, str] = {}
        if config is not None:
            merged_llm.update(config.llm_keys)
        if llm_keys:
            merged_llm.update(llm_keys)
        resolved_provider_key = provider_key
        if resolved_provider_key is None and provider_name not in merged_llm:
            resolved_provider_key = self._provider_key_from_env(provider_name)
        if resolved_provider_key:
            merged_llm[provider_name] = resolved_provider_key

        if config is None:
            self._config = MetricAIConfig(
                api_key=resolved_key,
                mode=mode,
                llm_keys=merged_llm,
                proxy_base_url=proxy_base,
                environment=environment,
                default_billing_mode=default_billing_mode,
                default_budget_cap_inr=default_budget_cap_inr,
                fail_open=fail_open,
                default_agent_id=default_agent_id,
                environment_tag=environment_tag,
                active_providers=active_providers,
                routing=routing,
            )
        else:
            rep_kw = {
                "api_key": resolved_key,
                "llm_keys": merged_llm,
                "proxy_base_url": proxy_base,
                "default_agent_id": default_agent_id,
                "environment_tag": environment_tag,
            }
            if active_providers is not None:
                rep_kw["active_providers"] = active_providers
            if routing is not None:
                rep_kw["routing"] = routing
            self._config = replace(config, **rep_kw)

        self._api_key = self._config.api_key
        self._base_url = self._config.proxy_base_url
        self._timeout = timeout
        self._provider: str = provider_name
        self._agent_id = agent_id
        self._user_id = user_id
        self._client_header_defaults = {
            "session_id": session_id,
            "billing_mode": billing_mode,
            "budget_cap_inr": budget_cap_inr,
            "graph_id": graph_id,
            "node_id": node_id,
            "crew_id": crew_id,
            "task_id": task_id,
            "outcome_rule_id": outcome_rule_id,
            "idempotency_key": idempotency_key,
            "outcome_threshold": outcome_threshold,
        }
        self._extra_proxy_headers: Dict[str, str] = dict(extra_proxy_headers or {})
        self._extra_proxy_headers.update(llm_keys_to_proxy_headers(self._config.llm_keys))
        self._extra_proxy_headers.update(routing_headers_from_config(self._config.routing))
        self._last_routing_decision: Optional[Dict[str, Any]] = None

        if self._config.mode == "managed":
            _LOG.warning(
                "MetricAI managed mode is enabled: provider calls may use MetricAI-managed keys "
                "and billing. Use mode='byok' unless you intend managed billing."
            )
        if self._config.mode == "byok" and self._config.llm_keys:
            self._register_llm_keys(dict(self._config.llm_keys))

        self._telemetry_events_path = telemetry_events_path
        self._telemetry_base_url = telemetry_base_url.rstrip("/") if telemetry_base_url else None
        tel_url = (
            self._telemetry_base_url
            if self._telemetry_base_url
            else f"{self._base_url}{telemetry_events_path}"
        )
        self._telemetry = TelemetryTransport(
            post_url=tel_url,
            api_key=self._api_key,
            timeout_seconds=telemetry_timeout_seconds,
            max_retries=max_retries,
            enable_buffer=enable_buffer,
            raise_on_error=raise_on_error,
        )
        self._background_telemetry = bool(background_telemetry)  # reliability-fix: FIX-6
        self._telemetry_executor: Optional[ThreadPoolExecutor] = None  # reliability-fix: FIX-6
        if self._background_telemetry:  # reliability-fix: FIX-6
            self._telemetry_executor = ThreadPoolExecutor(max_workers=2)  # reliability-fix: FIX-6

        try:
            from .providers.registry import activate as _activate_providers

            prov = self._config.active_providers
            _activate_providers(self, list(prov) if prov is not None else None)
        except Exception as e:
            _LOG.warning(
                "MetricAI optional provider activation failed (e.g. Bedrock/Tavily hooks not "
                "registered): %s",
                e,
                exc_info=True,
            )

    def shutdown(self) -> None:  # reliability-fix: FIX-6
        """Flush background telemetry: wait up to 5s for the executor to finish in-flight work."""
        ex = self._telemetry_executor  # reliability-fix: FIX-6
        if ex is None:  # reliability-fix: FIX-6
            return  # reliability-fix: FIX-6

        def _wait() -> None:  # reliability-fix: FIX-6
            ex.shutdown(wait=True)  # reliability-fix: FIX-6

        th = threading.Thread(target=_wait, daemon=True)  # reliability-fix: FIX-6
        th.start()  # reliability-fix: FIX-6
        th.join(timeout=5.0)  # reliability-fix: FIX-6
        self._telemetry_executor = None  # reliability-fix: FIX-6

    @property
    def config(self) -> MetricAIConfig:
        """Effective :class:`~metricai.config.MetricAIConfig` (BYOK/managed, proxy base URL, defaults)."""
        return self._config

    @property
    def client(self) -> Any:
        """Configured provider SDK client using constructor-level provider, keys, and attribution."""
        if self._provider == "openai":
            return self.openai_sdk()
        if self._provider == "anthropic":
            return self.anthropic_sdk()
        if self._provider == "gemini":
            return self.gemini_sdk()
        if self._provider == "bedrock":
            return self.bedrock_sdk()
        if self._provider == "grok":
            return self.grok_sdk()
        raise ValueError(f"Unsupported provider: {self._provider}")

    @staticmethod
    def _provider_key_from_env(provider: str) -> Optional[str]:
        env_name = _PROVIDER_ENV_KEYS.get(provider)
        return os.environ.get(env_name) if env_name else None

    @property
    def last_routing_decision(self) -> Optional[Dict[str, Any]]:
        """Parsed ``X-MetricAI-Routed-Model`` JSON from the most recent proxy response, if any."""
        return self._last_routing_decision

    @property
    def routing(self) -> RoutingManager:
        """Manage routing policies and analytics (``/v1/routing``)."""
        return RoutingManager(self)

    def _store_routing_headers(self, headers: httpx.Headers) -> None:
        raw = headers.get("X-MetricAI-Routed-Model")
        if not raw:
            self._last_routing_decision = None
            return
        try:
            self._last_routing_decision = json.loads(raw)
        except Exception:
            self._last_routing_decision = {"raw": raw}

    def _register_llm_keys(self, llm_keys: Dict[str, str]) -> None:
        """Reserved for future vault registration (``POST /v1/keys/register``). No-op today."""
        _ = llm_keys

    def _resolve_agent_user(
        self,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> Tuple[str, str]:
        return agent_id or self._agent_id or "untagged", user_id or self._user_id or "anonymous"

    def _resolve_header_kwargs(self, overrides: Dict[str, Any]) -> Dict[str, Any]:
        resolved = dict(self._client_header_defaults)
        for key, value in overrides.items():
            if value is not None:
                resolved[key] = value
        return resolved

    def headers(
        self,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        *,
        session_id: Optional[str] = None,
        billing_mode: Optional[str] = None,
        budget_cap_inr: Optional[float] = None,
        graph_id: Optional[str] = None,
        node_id: Optional[str] = None,
        crew_id: Optional[str] = None,
        task_id: Optional[str] = None,
        outcome_rule_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        outcome_threshold: Optional[float] = None,
    ) -> Dict[str, str]:
        """MetricAI proxy attribution headers (``X-Agent-ID``, ``X-User-ID``, ...). Auth via Bearer."""
        return build_proxy_attribution_headers(
            api_key=self._api_key,
            agent_id=agent_id,
            user_id=user_id,
            session_id=session_id,
            billing_mode=billing_mode,
            default_billing_mode=self._config.default_billing_mode,
            budget_cap_inr=budget_cap_inr,
            default_budget_cap_inr=self._config.default_budget_cap_inr,
            idempotency_key=idempotency_key,
            key_mode=self._config.mode,
            graph_id=graph_id,
            node_id=node_id,
            crew_id=crew_id,
            task_id=task_id,
            outcome_rule_id=outcome_rule_id,
            outcome_threshold=outcome_threshold,
        )

    def _merge_sdk_default_headers(self, attribution: Dict[str, str]) -> Dict[str, str]:
        merged = {**attribution, **self._extra_proxy_headers}
        return merged

    def _sdk_headers(
        self,
        agent_id: Optional[str],
        user_id: Optional[str],
        *,
        session_id: Optional[str] = None,
        billing_mode: Optional[str] = None,
        budget_cap_inr: Optional[float] = None,
        graph_id: Optional[str] = None,
        node_id: Optional[str] = None,
        crew_id: Optional[str] = None,
        task_id: Optional[str] = None,
        outcome_rule_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        outcome_threshold: Optional[float] = None,
    ) -> Dict[str, str]:
        resolved_agent_id, resolved_user_id = self._resolve_agent_user(agent_id, user_id)
        return self.headers(
            agent_id=resolved_agent_id,
            user_id=resolved_user_id,
            session_id=session_id,
            billing_mode=billing_mode,
            budget_cap_inr=budget_cap_inr,
            graph_id=graph_id,
            node_id=node_id,
            crew_id=crew_id,
            task_id=task_id,
            outcome_rule_id=outcome_rule_id,
            idempotency_key=idempotency_key,
            outcome_threshold=outcome_threshold,
        )

    def openai_sdk(
        self,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        *,
        session_id: Optional[str] = None,
        billing_mode: Optional[str] = None,
        budget_cap_inr: Optional[float] = None,
        graph_id: Optional[str] = None,
        node_id: Optional[str] = None,
        crew_id: Optional[str] = None,
        task_id: Optional[str] = None,
        outcome_rule_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        outcome_threshold: Optional[float] = None,
    ) -> Any:
        """Official ``openai.OpenAI`` client with ``base_url`` set to the MetricAI OpenAI proxy route."""
        try:
            from openai import OpenAI
        except ImportError as e:
            raise ImportError(
                "openai_sdk requires the 'openai' package. Install: pip install openai"
            ) from e

        header_kwargs = self._resolve_header_kwargs(
            {
                "session_id": session_id,
                "billing_mode": billing_mode,
                "budget_cap_inr": budget_cap_inr,
                "graph_id": graph_id,
                "node_id": node_id,
                "crew_id": crew_id,
                "task_id": task_id,
                "outcome_rule_id": outcome_rule_id,
                "idempotency_key": idempotency_key,
                "outcome_threshold": outcome_threshold,
            }
        )
        attr = self._sdk_headers(
            agent_id,
            user_id,
            **header_kwargs,
        )
        dh = self._merge_sdk_default_headers(attr)
        return OpenAI(
            **build_provider_sdk_kwargs(
                "openai",
                api_key=self._api_key,
                base_url=self._config.proxy_url_for("openai"),
                default_headers=dh,
            )
        )

    def provider_sdk(
        self,
        provider: str,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        *,
        session_id: Optional[str] = None,
        billing_mode: Optional[str] = None,
        budget_cap_inr: Optional[float] = None,
        graph_id: Optional[str] = None,
        node_id: Optional[str] = None,
        crew_id: Optional[str] = None,
        task_id: Optional[str] = None,
        outcome_rule_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        outcome_threshold: Optional[float] = None,
    ) -> Any:
        """Return the official provider SDK client for *provider* (openai, anthropic, gemini, grok)."""
        segment = (provider or "").strip().lower()
        factories = {
            "openai": self.openai_sdk,
            "anthropic": self.anthropic_sdk,
            "claude": self.anthropic_sdk,
            "gemini": self.gemini_sdk,
            "groq": self.grok_sdk,
            "grok": self.grok_sdk,
        }
        factory = factories.get(segment)
        if factory is None:
            raise ValueError(
                f"Unsupported provider for provider_sdk: {provider!r}. "
                "Use openai, anthropic, gemini, or grok."
            )
        return factory(
            agent_id,
            user_id,
            session_id=session_id,
            billing_mode=billing_mode,
            budget_cap_inr=budget_cap_inr,
            graph_id=graph_id,
            node_id=node_id,
            crew_id=crew_id,
            task_id=task_id,
            outcome_rule_id=outcome_rule_id,
            idempotency_key=idempotency_key,
            outcome_threshold=outcome_threshold,
        )

    def anthropic_sdk(
        self,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        *,
        session_id: Optional[str] = None,
        billing_mode: Optional[str] = None,
        budget_cap_inr: Optional[float] = None,
        graph_id: Optional[str] = None,
        node_id: Optional[str] = None,
        crew_id: Optional[str] = None,
        task_id: Optional[str] = None,
        outcome_rule_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        outcome_threshold: Optional[float] = None,
    ) -> Any:
        """Official ``anthropic.Anthropic`` client targeting the MetricAI Claude proxy route.

        Uses ``auth_token=`` (``Authorization: Bearer``). Do not use ``api_key=`` — Anthropic sends that as ``X-Api-Key``, which the proxy ignores for MetricAI auth.
        """
        try:
            from anthropic import Anthropic
        except ImportError as e:
            raise ImportError(
                "anthropic_sdk requires the 'anthropic' package. Install: pip install anthropic"
            ) from e

        header_kwargs = self._resolve_header_kwargs(
            {
                "session_id": session_id,
                "billing_mode": billing_mode,
                "budget_cap_inr": budget_cap_inr,
                "graph_id": graph_id,
                "node_id": node_id,
                "crew_id": crew_id,
                "task_id": task_id,
                "outcome_rule_id": outcome_rule_id,
                "idempotency_key": idempotency_key,
                "outcome_threshold": outcome_threshold,
            }
        )
        attr = self._sdk_headers(
            agent_id,
            user_id,
            **header_kwargs,
        )
        dh = self._merge_sdk_default_headers(attr)
        return Anthropic(
            **build_provider_sdk_kwargs(
                "anthropic",
                api_key=self._api_key,
                base_url=self._config.proxy_url_for("anthropic"),
                default_headers=dh,
            )
        )

    def gemini_sdk(
        self,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        *,
        session_id: Optional[str] = None,
        billing_mode: Optional[str] = None,
        budget_cap_inr: Optional[float] = None,
        graph_id: Optional[str] = None,
        node_id: Optional[str] = None,
        crew_id: Optional[str] = None,
        task_id: Optional[str] = None,
        outcome_rule_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        outcome_threshold: Optional[float] = None,
    ) -> Any:
        """OpenAI-compatible client pointed at the MetricAI Gemini proxy (same SDK as ``openai_sdk``)."""
        try:
            from openai import OpenAI
        except ImportError as e:
            raise ImportError(
                "gemini_sdk requires the 'openai' package. Install: pip install openai"
            ) from e

        header_kwargs = self._resolve_header_kwargs(
            {
                "session_id": session_id,
                "billing_mode": billing_mode,
                "budget_cap_inr": budget_cap_inr,
                "graph_id": graph_id,
                "node_id": node_id,
                "crew_id": crew_id,
                "task_id": task_id,
                "outcome_rule_id": outcome_rule_id,
                "idempotency_key": idempotency_key,
                "outcome_threshold": outcome_threshold,
            }
        )
        attr = self._sdk_headers(
            agent_id,
            user_id,
            **header_kwargs,
        )
        dh = self._merge_sdk_default_headers(attr)
        return OpenAI(
            **build_provider_sdk_kwargs(
                "gemini",
                api_key=self._api_key,
                base_url=self._config.proxy_url_for("gemini"),
                default_headers=dh,
            )
        )

    def grok_sdk(
        self,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        *,
        session_id: Optional[str] = None,
        billing_mode: Optional[str] = None,
        budget_cap_inr: Optional[float] = None,
        graph_id: Optional[str] = None,
        node_id: Optional[str] = None,
        crew_id: Optional[str] = None,
        task_id: Optional[str] = None,
        outcome_rule_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        outcome_threshold: Optional[float] = None,
    ) -> Any:
        """OpenAI-compatible client pointed at the MetricAI Grok proxy."""
        try:
            from openai import OpenAI
        except ImportError as e:
            raise ImportError(
                "grok_sdk requires the 'openai' package. Install: pip install openai"
            ) from e

        header_kwargs = self._resolve_header_kwargs(
            {
                "session_id": session_id,
                "billing_mode": billing_mode,
                "budget_cap_inr": budget_cap_inr,
                "graph_id": graph_id,
                "node_id": node_id,
                "crew_id": crew_id,
                "task_id": task_id,
                "outcome_rule_id": outcome_rule_id,
                "idempotency_key": idempotency_key,
                "outcome_threshold": outcome_threshold,
            }
        )
        attr = self._sdk_headers(
            agent_id,
            user_id,
            **header_kwargs,
        )
        dh = self._merge_sdk_default_headers(attr)
        return OpenAI(
            **build_provider_sdk_kwargs(
                "grok",
                api_key=self._api_key,
                base_url=self._config.proxy_url_for("groq"),
                default_headers=dh,
            )
        )

    def bedrock_sdk(self, **client_kwargs: Any) -> Any:
        """Wrapped boto3 ``bedrock-runtime`` client for Bedrock usage metering."""
        try:
            import boto3
        except ImportError as e:
            raise ImportError(
                "bedrock_sdk requires the 'boto3' package. Install: pip install boto3"
            ) from e
        from .providers.bedrock import wrap_bedrock_runtime_client

        runtime_client = boto3.client("bedrock-runtime", **client_kwargs)
        return wrap_bedrock_runtime_client(runtime_client, self)

    def proxy_sdk_session(
        self,
        agent_id: str,
        user_id: str,
        *,
        session_id: Optional[str] = None,
        budget_cap_inr: Optional[float] = None,
        complete_on_exit: bool = True,
        **kwargs: Any,
    ) -> "MetricAIProxyClientSession":
        """Context manager: one ``session_id`` for native SDK clients; completes server session on exit."""
        from .proxy_client_session import MetricAIProxyClientSession

        return MetricAIProxyClientSession(
            self,
            agent_id,
            user_id,
            session_id=session_id,
            budget_cap_inr=budget_cap_inr,
            complete_on_exit=complete_on_exit,
            **kwargs,
        )

    def _telemetry_send(self, body: Dict[str, Any], idempotency_key: str) -> Optional[httpx.Response]:
        if self._background_telemetry and self._telemetry_executor is not None:  # reliability-fix: FIX-6
            self._telemetry_executor.submit(  # type: ignore[unreachable]  # reliability-fix: FIX-6
                lambda: self._telemetry.send_event(  # reliability-fix: FIX-6
                    body,  # type: ignore[misc]  # reliability-fix: FIX-6
                    idempotency_key,  # type: ignore[misc]  # reliability-fix: FIX-6
                    background=True,  # type: ignore[misc]  # reliability-fix: FIX-6
                )  # reliability-fix: FIX-6
            )  # reliability-fix: FIX-6
            return None  # type: ignore[unreachable]  # reliability-fix: FIX-6
        return self._telemetry.send_event(body, idempotency_key)  # reliability-fix: FIX-6

    async def _telemetry_send_async(
        self, body: Dict[str, Any], idempotency_key: str
    ) -> Optional[httpx.Response]:
        if self._background_telemetry and self._telemetry_executor is not None:  # reliability-fix: FIX-6
            self._telemetry_executor.submit(  # type: ignore[unreachable]  # reliability-fix: FIX-6
                lambda: self._telemetry.send_event(  # type: ignore[misc]  # reliability-fix: FIX-6
                    body,  # type: ignore[misc]  # reliability-fix: FIX-6
                    idempotency_key,  # type: ignore[misc]  # reliability-fix: FIX-6
                    background=True,  # type: ignore[misc]  # reliability-fix: FIX-6
                )  # reliability-fix: FIX-6
            )  # reliability-fix: FIX-6
            return None  # reliability-fix: FIX-6
        return await self._telemetry.send_event_async(body, idempotency_key)  # reliability-fix: FIX-6

    # ------------------------------------------------------------------ #
    # Telemetry ΓÇö track / atrack
    # ------------------------------------------------------------------ #

    def track(
        self,
        *,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        input_tokens: Optional[int] = None,
        output_tokens: Optional[int] = None,
        stream: bool = False,
        session_id: Optional[str] = None,
        turn_number: Optional[int] = None,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        context_tokens: Optional[int] = None,
        tools: Optional[List[Tool]] = None,
        modalities: Optional[Modalities] = None,
        outcome: Optional[OutcomeConfig] = None,
        simulate: bool = False,
        latency_ms: Optional[int] = None,
        cost_inr: Optional[float] = None,
        mcp_call: bool = False,
        budget_warning: bool = False,
        idempotency_key: Optional[str] = None,
        success: Optional[bool] = None,
        first_token_latency_ms: Optional[int] = None,
        total_latency_ms: Optional[int] = None,
        chunk_count: Optional[int] = None,
        stream_interrupted: Optional[bool] = None,
        event_type: Literal["turn", "session_close", "budget_warning"] = "turn",
        extra: Optional[Dict[str, Any]] = None,
    ) -> Union[TrackResult, SimulationResult, None]:
        """
        Send a telemetry / billing event to MetricAI (``POST`` ingest path).

        All parameters are optional except what your dashboard expects for a given event.
        Idempotency: a fresh UUID4 is sent as ``Idempotency-Key`` unless ``idempotency_key``
        is provided. Fails open (logs warning, returns ``None``) unless ``raise_on_error=True``
        on the client.

        ``stream=True`` adds ``\"streamed\": true`` to the payload. ``simulate=True`` adds
        ``\"simulated\": true`` and returns a :class:`~metricai.types.SimulationResult` with
        ``would_charge_inr`` and ``outcome_matched`` (whether outcome-based charges align with
        ``outcome.success``).
        """
        if outcome is not None and hasattr(outcome, "to_outcome_dict"):
            outcome = outcome.to_outcome_dict()
        ikey = idempotency_key or new_idempotency_key()
        body = build_track_payload(
            event_type=event_type,
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            stream=stream,
            session_id=session_id,
            turn_number=turn_number,
            agent_id=agent_id,
            user_id=user_id,
            context_tokens=context_tokens,
            tools=tools,
            modalities=modalities,
            outcome=outcome,
            simulate=simulate,
            latency_ms=latency_ms,
            cost_inr=cost_inr,
            mcp_call=mcp_call,
            budget_warning=budget_warning,
            success=success,
            first_token_latency_ms=first_token_latency_ms,
            total_latency_ms=total_latency_ms,
            chunk_count=chunk_count,
            stream_interrupted=stream_interrupted,
            extra=extra,
        )
        body["idempotency_key"] = str(ikey)  # reliability-fix: FIX-9
        if simulate:
            bill = compute_billable_inr(outcome)
            would = float(bill) if bill is not None else 0.0
            matched = outcome_charge_matched(outcome, compute_billable_inr(outcome))
            self._telemetry_send(body, ikey)  # reliability-fix: FIX-6
            return SimulationResult(would_charge_inr=would, outcome_matched=matched)

        response = self._telemetry_send(body, ikey)  # reliability-fix: FIX-6
        if response is None:
            return None
        return TrackResult(ok=True, status_code=response.status_code)

    def track_billing_event(
        self,
        event: BillingEvent,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Union[TrackResult, None]:
        """
        Send a canonical :class:`~metricai.billing_event.BillingEvent` (schema version + category).
        Fail-open semantics match :meth:`track`.
        """
        ikey = idempotency_key or new_idempotency_key()
        extra: Dict[str, Any] = {}
        if self._config.environment_tag:
            extra["environment_tag"] = self._config.environment_tag
        body = build_track_payload(billing_event=event, extra=extra or None)
        body["idempotency_key"] = str(ikey)  # reliability-fix: FIX-9
        response = self._telemetry_send(body, ikey)
        if response is None:
            return None
        return TrackResult(ok=True, status_code=response.status_code)

    async def atrack_billing_event(
        self,
        event: BillingEvent,
        *,
        idempotency_key: Optional[str] = None,
    ) -> Union[TrackResult, None]:
        """Async :meth:`track_billing_event`."""
        ikey = idempotency_key or new_idempotency_key()
        extra: Dict[str, Any] = {}
        if self._config.environment_tag:
            extra["environment_tag"] = self._config.environment_tag
        body = build_track_payload(billing_event=event, extra=extra or None)
        body["idempotency_key"] = str(ikey)  # reliability-fix: FIX-9
        response = await self._telemetry_send_async(body, ikey)
        if response is None:
            return None
        return TrackResult(ok=True, status_code=response.status_code)

    async def atrack(
        self,
        *,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        input_tokens: Optional[int] = None,
        output_tokens: Optional[int] = None,
        stream: bool = False,
        session_id: Optional[str] = None,
        turn_number: Optional[int] = None,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        context_tokens: Optional[int] = None,
        tools: Optional[List[Tool]] = None,
        modalities: Optional[Modalities] = None,
        outcome: Optional[OutcomeConfig] = None,
        simulate: bool = False,
        latency_ms: Optional[int] = None,
        cost_inr: Optional[float] = None,
        mcp_call: bool = False,
        budget_warning: bool = False,
        idempotency_key: Optional[str] = None,
        success: Optional[bool] = None,
        first_token_latency_ms: Optional[int] = None,
        total_latency_ms: Optional[int] = None,
        chunk_count: Optional[int] = None,
        stream_interrupted: Optional[bool] = None,
        event_type: Literal["turn", "session_close", "budget_warning"] = "turn",
        extra: Optional[Dict[str, Any]] = None,
    ) -> Union[TrackResult, SimulationResult, None]:
        """Async version of :meth:`track`."""
        if outcome is not None and hasattr(outcome, "to_outcome_dict"):
            outcome = outcome.to_outcome_dict()
        ikey = idempotency_key or new_idempotency_key()
        body = build_track_payload(
            event_type=event_type,
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            stream=stream,
            session_id=session_id,
            turn_number=turn_number,
            agent_id=agent_id,
            user_id=user_id,
            context_tokens=context_tokens,
            tools=tools,
            modalities=modalities,
            outcome=outcome,
            simulate=simulate,
            latency_ms=latency_ms,
            cost_inr=cost_inr,
            mcp_call=mcp_call,
            budget_warning=budget_warning,
            success=success,
            first_token_latency_ms=first_token_latency_ms,
            total_latency_ms=total_latency_ms,
            chunk_count=chunk_count,
            stream_interrupted=stream_interrupted,
            extra=extra,
        )
        body["idempotency_key"] = str(ikey)  # reliability-fix: FIX-9
        if simulate:
            bill = compute_billable_inr(outcome)
            would = float(bill) if bill is not None else 0.0
            matched = outcome_charge_matched(outcome, compute_billable_inr(outcome))
            await self._telemetry_send_async(body, ikey)  # reliability-fix: FIX-6
            return SimulationResult(would_charge_inr=would, outcome_matched=matched)

        response = await self._telemetry_send_async(body, ikey)  # reliability-fix: FIX-6
        if response is None:
            return None
        return TrackResult(ok=True, status_code=response.status_code)

    def track_response(
        self,
        response: Any,
        *,
        provider: str,
        model: str,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        **kwargs: Any,
    ) -> Union[TrackResult, SimulationResult, None]:
        """
        Extract token usage from a provider response object and call :meth:`track`.

        Do not use for proxy-routed responses (the proxy meters server-side).
        """
        if getattr(response, "_metricai_instrumented", False) or getattr(
            response, "_metricai_proxy_routed", False
        ):
            _LOG.warning(
                "track_response skipped: response appears proxy-routed (double-count risk)."
            )
            return None
        from .usage_normalizer import normalize_llm_usage

        usage = normalize_llm_usage(getattr(response, "usage", None))
        return self.track(
            provider=provider,
            model=model,
            input_tokens=int(usage.get("input_tokens") or 0),
            output_tokens=int(usage.get("output_tokens") or 0),
            agent_id=agent_id,
            user_id=user_id,
            **kwargs,
        )

    def validate_api_key(self) -> dict[str, Any]:
        """Call ``GET /v1/auth/ping`` to verify the API key (raises on 401)."""
        from .exceptions import MetricAIAuthError, parse_metricai_error

        url = f"{self._base_url.rstrip('/')}/v1/auth/ping"
        headers = build_metricai_auth_headers(self._api_key)
        with httpx.Client(timeout=self._timeout) as client:
            response = client.get(url, headers=headers)
        if response.status_code == 401:
            raise MetricAIAuthError("Invalid or revoked MetricAI API key.")
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            body = {}
            try:
                body = response.json()
            except Exception:
                body = {"detail": response.text}
            raise parse_metricai_error(
                status_code=exc.response.status_code,
                body=body,
                headers={k.lower(): v for k, v in response.headers.items()},
            )
        return response.json()

    def track_stream(self, *, provider: str, **track_kwargs: Any) -> StreamingTrackContext:
        """
        Context manager for streaming: pass ``feed_sse_data_line`` / ``feed_parsed_chunk`` for
        each chunk; on exit, one :meth:`track` is sent with ``stream=True`` and latency/token fields.
        """
        return StreamingTrackContext(provider, self.track, track_kwargs)

    def atrack_stream(self, *, provider: str, **track_kwargs: Any) -> AsyncStreamingTrackContext:
        """Async streaming helper; flushes via :meth:`atrack`."""
        return AsyncStreamingTrackContext(provider, self.atrack, track_kwargs)

    def metricai_session(
        self,
        *,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        max_budget_inr: Optional[float] = None,
        soft_budget_inr: Optional[float] = None,
        on_budget_warning: Optional[Any] = None,
    ) -> MetricAISession:
        """Factory for :class:`MetricAISession` bound to this client."""
        return MetricAISession(
            self,
            session_id=session_id,
            agent_id=agent_id,
            user_id=user_id,
            max_budget_inr=max_budget_inr,
            soft_budget_inr=soft_budget_inr,
            on_budget_warning=on_budget_warning,
        )

    # ------------------------------------------------------------------ #
    # Provider proxies
    # ------------------------------------------------------------------ #

    def openai(self, session: Optional[SessionContext] = None) -> MetricAIProxy:
        """Returns a proxy configured for OpenAI."""
        return MetricAIProxy(
            self._base_url,
            self._api_key,
            "openai",
            session,
            self._timeout,
            extra_headers=self._extra_proxy_headers,
            routing_sink=self._store_routing_headers,
        )

    def claude(self, session: Optional[SessionContext] = None) -> MetricAIProxy:
        """Returns a proxy configured for Anthropic Claude."""
        return MetricAIProxy(
            self._base_url,
            self._api_key,
            "claude",
            session,
            self._timeout,
            extra_headers=self._extra_proxy_headers,
            routing_sink=self._store_routing_headers,
        )

    def gemini(self, session: Optional[SessionContext] = None) -> MetricAIProxy:
        """Returns a proxy configured for Google Gemini."""
        return MetricAIProxy(
            self._base_url,
            self._api_key,
            "gemini",
            session,
            self._timeout,
            extra_headers=self._extra_proxy_headers,
            routing_sink=self._store_routing_headers,
        )

    def grok(self, session: Optional[SessionContext] = None) -> MetricAIProxy:
        """Returns a proxy configured for xAI Grok."""
        return MetricAIProxy(
            self._base_url,
            self._api_key,
            "grok",
            session,
            self._timeout,
            extra_headers=self._extra_proxy_headers,
            routing_sink=self._store_routing_headers,
        )

    # ------------------------------------------------------------------ #
    # Session management (Phase 1)
    # ------------------------------------------------------------------ #

    def session(
        self,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> "SessionManager":
        """
        Context manager that creates a session and marks it complete on exit.

        with client.session(agent_id="my-agent", user_id="user_123") as session:
            client.openai(session=session).complete(...)
        """
        return SessionManager(self, SessionContext(session_id, agent_id, user_id))

    def get_session(self, session_id: str) -> SessionDetail:
        """Fetch a session and all its turns from MetricAI."""
        response = self._get(f"/v1/sessions/{session_id}")
        return SessionDetail(**response)

    def list_sessions(
        self,
        agent_id: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[SessionState]:
        """List recent sessions for this MetricAI account."""
        params = {"limit": limit, "offset": offset}
        if agent_id:
            params["agent_id"] = agent_id
        response = self._get("/v1/sessions", params=params)
        return [SessionState(**s) for s in response.get("sessions", [])]

    def complete_session(self, session_id: str) -> bool:
        """Mark a session as completed."""
        self._post(f"/v1/sessions/{session_id}/complete")
        return True

    # ------------------------------------------------------------------ #
    # Wallet & observability
    # ------------------------------------------------------------------ #

    def get_balance(self) -> WalletBalance:
        """Get current wallet balance in INR (converted from USD storage)."""
        from .fx import fetch_usd_inr_rate

        response = self._get("/v1/wallet/balance")
        balance_usd = float(response.get("balance_usd") or 0)
        fx = fetch_usd_inr_rate(self._base_url, timeout=float(self._timeout))
        return WalletBalance(balance_inr=round(balance_usd * fx, 4), currency="INR")

    def get_usage(self) -> UsageStats:
        """Get token usage and cost stats for this account."""
        response = self._get("/v1/usage/summary")
        return UsageStats(
            total_tokens=int(response.get("total_tokens") or 0),
            input_tokens=int(response.get("input_tokens") or 0),
            output_tokens=int(response.get("output_tokens") or 0),
            total_cost_inr=float(response.get("total_cost_inr") or 0),
            request_count=int(response.get("request_count") or 0),
        )

    # ------------------------------------------------------------------ #
    # Internal HTTP helpers
    # ------------------------------------------------------------------ #

    def _headers(self) -> dict:
        return {
            "X-MetricAI-API-Key": self._api_key,
            "Content-Type": "application/json",
        }

    def _get(self, path: str, params: dict = None) -> dict:
        with httpx.Client(timeout=self._timeout) as client:
            response = client.get(
                f"{self._base_url}{path}",
                headers=self._headers(),
                params=params,
            )
        response.raise_for_status()
        return response.json()

    def _post(self, path: str, json: dict = None) -> dict:
        with httpx.Client(timeout=self._timeout) as client:
            response = client.post(
                f"{self._base_url}{path}",
                headers=self._headers(),
                json=json or {},
            )
        response.raise_for_status()
        return response.json()

    async def _aget(self, path: str, params: dict = None) -> dict:
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.get(
                f"{self._base_url}{path}",
                headers=self._headers(),
                params=params,
            )
        response.raise_for_status()
        return response.json()

    async def _apost(self, path: str, json: dict = None) -> dict:
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(
                f"{self._base_url}{path}",
                headers=self._headers(),
                json=json or {},
            )
        response.raise_for_status()
        return response.json()


class SessionManager:
    """Context manager returned by client.session()."""

    def __init__(self, client: MetricAI, ctx: SessionContext):
        self._client = client
        self.context = ctx

    def __enter__(self) -> SessionContext:
        return self.context

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Mark session complete even if an exception occurred
        try:
            self._client.complete_session(self.context.session_id)
        except Exception:
            pass  # Fail silently — never raise in __exit__
        return False  # Do not suppress exceptions


class MetricAIClient(MetricAI):
    """
    Canonical SDK entrypoint (v0.3+) with stricter config validation and quota helpers.

    ``MetricAI`` remains a backward-compatible alias.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        retry_config: Optional[Any] = None,
        environment: Optional[str] = None,
        proxy_base_url: Optional[str] = None,
        timeout: float = 60.0,
        *,
        base_url: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        from .exceptions import MetricAIConfigError
        from .retry import RetryConfig, retry_config_from_env

        resolved_key = api_key or os.environ.get("METRICAI_API_KEY")
        if not isinstance(resolved_key, str) or not resolved_key.strip():
            raise MetricAIConfigError("`api_key` must be a non-empty string.")

        resolved_env = environment or os.getenv("METRICAI_ENVIRONMENT", "production")
        if resolved_env not in ("production", "sandbox"):
            raise MetricAIConfigError("`environment` must be either 'production' or 'sandbox'.")

        if retry_config is None:
            retry_config = retry_config_from_env()
        if not isinstance(retry_config, RetryConfig):
            raise MetricAIConfigError("`retry_config` must be a RetryConfig instance.")
        self._retry_config = retry_config

        host = proxy_base_url or base_url
        super().__init__(
            api_key=resolved_key,
            base_url=host,
            timeout=int(timeout),
            agent_id=agent_id,
            user_id=user_id,
            session_id=session_id,
            environment=resolved_env,  # type: ignore[arg-type]
            **kwargs,
        )

    def headers(
        self,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        *,
        session_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        request_mode: str = "standard",
        **kwargs: Any,
    ) -> Dict[str, str]:
        resolved_session = session_id or self._client_header_defaults.get("session_id")
        h = super().headers(
            agent_id=agent_id or self._agent_id,
            user_id=user_id or self._user_id,
            session_id=resolved_session,
            idempotency_key=idempotency_key,
            **kwargs,
        )
        h["X-MetricAI-Request-Mode"] = request_mode
        return h

    def get_quota_status(self) -> Any:
        from .retry import QuotaStatus

        payload = self._get("/v1/billing/subscription")
        plan = str(payload.get("plan_slug") or "")
        cycle = payload.get("current_cycle") or {}
        requests_used = int(
            cycle.get("live_requests_used") or cycle.get("requests_used") or 0
        )
        quota_limit = int(cycle.get("included_quota") or 0)
        overage = int(
            cycle.get("overage_requests_live")
            or max(0, requests_used - quota_limit)
            if quota_limit > 0
            else 0
        )
        requests_remaining = max(0, quota_limit - requests_used) if quota_limit > 0 else 0
        cycle_end = cycle.get("cycle_end")
        if cycle_end is not None and hasattr(cycle_end, "isoformat"):
            cycle_end_date = cycle_end.isoformat()
        else:
            cycle_end_date = str(cycle_end or "")
        return QuotaStatus(
            plan=plan,
            requests_used=requests_used,
            quota_limit=quota_limit,
            requests_remaining=requests_remaining,
            overage_requests=overage,
            cycle_end_date=cycle_end_date,
        )


# Backward compatibility alias.
MetricAI = MetricAIClient  # type: ignore[misc,assignment]
