"""Deterministic tool-result compaction for governance v1."""

from __future__ import annotations

import json
from typing import Any, List, Optional, Set, Tuple


_DEFAULT_MARKER = "\n\n[metricai: tool output truncated to token budget]"


def estimate_token_chars(text: str) -> int:
    """Align with :func:`metricai.context_estimate.estimate_context_tokens` heuristic (~4 chars/token)."""
    if not text:
        return 0
    return max(1, len(text) // 4)


def compact_tool_result(
    content: Any,
    *,
    max_single_tool_result_tokens: Optional[int],
    preserve_keys: Optional[Set[str]] = None,
    marker: str = _DEFAULT_MARKER,
) -> Tuple[str, bool, int]:
    """
    Return ``(text, truncated, estimated_injected_tokens)``.

    If ``max_single_tool_result_tokens`` is None, no truncation is applied.
    """
    text = content if isinstance(content, str) else str(content)
    if max_single_tool_result_tokens is None or max_single_tool_result_tokens <= 0:
        return text, False, estimate_token_chars(text)

    max_chars = max(4, int(max_single_tool_result_tokens) * 4)
    if len(text) <= max_chars:
        return text, False, estimate_token_chars(text)

    trimmed = _truncate_with_optional_json_keys(text, max_chars, preserve_keys or set())
    if len(trimmed) > max_chars:
        trimmed = trimmed[: max_chars - len(marker)] + marker
    else:
        trimmed = trimmed + marker
    return trimmed, True, estimate_token_chars(trimmed)


def _truncate_with_optional_json_keys(text: str, max_chars: int, preserve_keys: Set[str]) -> str:
    if not preserve_keys:
        return text[:max_chars]
    try:
        data = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return text[:max_chars]
    if isinstance(data, dict):
        slim = {k: data[k] for k in preserve_keys if k in data}
        if not slim:
            slim = {k: data[k] for k in list(data.keys())[: min(8, len(data))]}
        out = json.dumps(slim, default=str)
        return out[:max_chars]
    if isinstance(data, list) and data and isinstance(data[0], dict):
        keys = preserve_keys or set(data[0].keys())
        slim_list = [{k: row.get(k) for k in keys if k in row} for row in data[:50]]
        out = json.dumps(slim_list, default=str)
        return out[:max_chars]
    return text[:max_chars]
