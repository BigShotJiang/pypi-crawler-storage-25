"""Normalize provider ``usage`` objects into :class:`~metricai.types.NormalizedLLMUsage`."""

from __future__ import annotations

import json
from typing import Any, Dict, Optional, cast

from metricai.types import NormalizedLLMUsage


def _usage_as_dict(usage: Any) -> Dict[str, Any]:
    if usage is None:
        return {}
    if isinstance(usage, dict):
        return dict(usage)
    md = getattr(usage, "model_dump", None)
    if callable(md):
        try:
            return cast(Dict[str, Any], md())
        except Exception:
            pass
    model_fields = getattr(usage, "model_fields", None)
    if model_fields is not None:
        out: Dict[str, Any] = {}
        for k in model_fields:
            v = getattr(usage, k, None)
            if v is not None:
                out[k] = v
        return out
    raw_dict = getattr(usage, "__dict__", None)
    if isinstance(raw_dict, dict) and raw_dict:
        return {k: v for k, v in raw_dict.items() if not k.startswith("_")}
    return {}


def normalize_llm_usage(
    usage: Any,
    *,
    usage_source: str = "provider",
) -> NormalizedLLMUsage:
    """
    Map OpenAI-shaped (and common alias) usage into a stable dict.

    Unknown shapes still return ``raw`` for forward compatibility.
    """
    u = _usage_as_dict(usage)
    if not u:
        return cast(
            NormalizedLLMUsage,
            {"usage_source": cast(Any, "unknown")},
        )

    inp = (
        u.get("prompt_tokens")
        if u.get("prompt_tokens") is not None
        else u.get("input_tokens")
    )
    out = (
        u.get("completion_tokens")
        if u.get("completion_tokens") is not None
        else u.get("output_tokens")
    )
    total = u.get("total_tokens")
    if total is None and inp is not None and out is not None:
        total = int(inp) + int(out)

    reasoning = None
    ctd = u.get("completion_tokens_details")
    if isinstance(ctd, dict) and ctd.get("reasoning_tokens") is not None:
        reasoning = int(ctd["reasoning_tokens"])
    if reasoning is None and u.get("reasoning_tokens") is not None:
        reasoning = int(u["reasoning_tokens"])

    cache_read = None
    cache_write = None
    pd = u.get("prompt_tokens_details")
    if isinstance(pd, dict):
        if pd.get("cached_tokens") is not None:
            cache_read = int(pd["cached_tokens"])
    if u.get("cache_read_input_tokens") is not None:
        cache_read = int(u["cache_read_input_tokens"])
    if u.get("cache_creation_input_tokens") is not None:
        cache_write = int(u["cache_creation_input_tokens"])

    result: NormalizedLLMUsage = {
        "usage_source": cast(Any, usage_source if usage_source in ("provider", "estimated", "unknown") else "unknown"),
        "raw": dict(u),
    }
    if inp is not None:
        result["input_tokens"] = int(inp)
    if out is not None:
        result["output_tokens"] = int(out)
    if total is not None:
        result["total_tokens"] = int(total)
    if reasoning is not None:
        result["reasoning_tokens"] = reasoning
    if cache_read is not None:
        result["cache_read_tokens"] = cache_read
    if cache_write is not None:
        result["cache_write_tokens"] = cache_write
    return result


def merge_normalized_usage(acc: NormalizedLLMUsage, step: NormalizedLLMUsage) -> NormalizedLLMUsage:
    """Sum numeric fields for session aggregation (best-effort)."""

    def g(d: NormalizedLLMUsage, k: str) -> int:
        v = d.get(k)  # type: ignore[arg-type]
        return int(v) if v is not None else 0

    merged: NormalizedLLMUsage = {
        "usage_source": cast(Any, "provider"),
        "raw": {"merged_steps": [acc.get("raw"), step.get("raw")]},
    }
    for k in ("input_tokens", "output_tokens", "total_tokens", "reasoning_tokens", "cache_read_tokens", "cache_write_tokens"):
        s = g(step, k) + g(acc, k)
        if s:
            merged[k] = s  # type: ignore[literal-required]
    if not merged.get("total_tokens"):
        it = merged.get("input_tokens") or 0
        ot = merged.get("output_tokens") or 0
        if it or ot:
            merged["total_tokens"] = it + ot
    return merged


def step_total_tokens(norm: NormalizedLLMUsage) -> int:
    t = norm.get("total_tokens")
    if t is not None:
        return int(t)
    i = norm.get("input_tokens")
    o = norm.get("output_tokens")
    if i is not None or o is not None:
        return int(i or 0) + int(o or 0)
    return 0


def usage_json_fingerprint(obj: Any) -> str:
    """Stable short string for tests (avoid dict order issues)."""
    return json.dumps(_usage_as_dict(obj), sort_keys=True, default=str)
