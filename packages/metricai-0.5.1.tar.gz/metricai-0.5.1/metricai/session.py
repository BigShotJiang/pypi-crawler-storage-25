import uuid
import warnings
from contextlib import contextmanager
from typing import Generator, Optional


class SessionContext:
    """
    Holds session metadata for a single agent run.
    Pass this to MetricAIProxy to group all LLM calls under one session.
    """

    def __init__(
        self,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        user_id: Optional[str] = None,
        *,
        session_name: Optional[str] = None,
    ):
        warnings.warn(
            "SessionContext is deprecated; use MetricAIProxyClientSession or MetricAISession.",
            DeprecationWarning,
            stacklevel=2,
        )
        self.session_id = session_id or str(uuid.uuid4())
        self.agent_id   = agent_id
        self.user_id    = user_id
        self.session_name = session_name

    def to_headers(self) -> dict:
        """Convert session context to MetricAI proxy headers."""
        headers = {"X-Session-ID": self.session_id}
        if self.agent_id:
            headers["X-Agent-ID"] = self.agent_id
        if self.user_id:
            headers["X-User-ID"] = self.user_id
        return headers

    def __repr__(self):
        return (
            f"SessionContext(session_id={self.session_id!r}, "
            f"agent_id={self.agent_id!r}, user_id={self.user_id!r}, "
            f"session_name={getattr(self, 'session_name', None)!r})"
        )
