# MetricAI Proxy Provider Examples

This document contains ready-to-run Python snippets for using MetricAI proxy routing with OpenAI-compatible and Anthropic SDKs.

**Attribution:** Include `X-Agent-ID` and `X-User-ID` in every request so dashboard costs group by agent and end user. If omitted, MetricAI defaults to `untagged` and `anonymous` (the request still succeeds).

## Prerequisites

- `METRICAI_API_KEY` set in your environment (format: `metricai_...` from the dashboard)
- Provider key set in your environment:
  - OpenAI: `OPENAI_API_KEY`
  - Anthropic: `ANTHROPIC_API_KEY`
  - Gemini: `GEMINI_API_KEY`
  - Grok: `GROK_API_KEY` (or `XAI_API_KEY`, if that is what your setup uses)

---

## OpenAI via MetricAI

```python
from openai import OpenAI
import os

client = OpenAI(
    api_key=os.environ["METRICAI_API_KEY"],
    base_url="https://proxy.metricai.co.in/v1/proxy/openai",
    default_headers={
        "X-OpenAI-API-Key": os.environ["OPENAI_API_KEY"].strip(),
        "X-Agent-ID": "your-agent-name",
        "X-User-ID": "your-user-id",
    },
)

response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Hi, How are you?"}],
)

print(response.choices[0].message.content)
```

---

## Anthropic (Claude) via MetricAI

Same shape as OpenAI/Gemini: use `api_key=` with your **MetricAI** key. The Anthropic SDK sends it as `X-Api-Key`, which the proxy accepts for MetricAI auth. You may also use `auth_token=` (sends `Authorization: Bearer`).

```python
from anthropic import Anthropic
import os

client = Anthropic(
    api_key=os.environ["METRICAI_API_KEY"].strip(),
    base_url="https://proxy.metricai.co.in/v1/proxy/claude",
    default_headers={
        "X-Claude-API-Key": os.environ["ANTHROPIC_API_KEY"].strip(),
        "X-Agent-ID": "your-agent-name",
        "X-User-ID": "your-user-id",
    },
)

response = client.messages.create(
    model="claude-3-5-sonnet-20241022",
    max_tokens=120,
    messages=[
        {"role": "user", "content": "Hi, how are you?"}
    ],
)

print(response.content[0].text)
```

---

## Gemini via MetricAI

```python
from openai import OpenAI
import os

client = OpenAI(
    api_key=os.environ["METRICAI_API_KEY"],
    base_url="https://proxy.metricai.co.in/v1/proxy/gemini",
    default_headers={
        "X-Gemini-API-Key": os.environ["GEMINI_API_KEY"].strip(),
        "X-Agent-ID": "your-agent-name",
        "X-User-ID": "your-user-id",
    },
)

response = client.chat.completions.create(
    model="gemini-1.5-flash",
    messages=[{"role": "user", "content": "Hi, how are you?"}],
)

print(response.choices[0].message.content)
```

---

## Grok via MetricAI

```python
from openai import OpenAI
import os

client = OpenAI(
    api_key=os.environ["METRICAI_API_KEY"],
    base_url="https://proxy.metricai.co.in/v1/proxy/grok",
    default_headers={
        "X-Grok-API-Key": os.environ["GROK_API_KEY"].strip(),
        "X-Agent-ID": "your-agent-name",
        "X-User-ID": "your-user-id",
    },
)

response = client.chat.completions.create(
    model="grok-2-latest",
    messages=[{"role": "user", "content": "Hi, how are you?"}],
)

print(response.choices[0].message.content)
```

---

## Quick Troubleshooting

- `401 Invalid or revoked MetricAI API key`: verify `METRICAI_API_KEY`
- `404 Not Found`: incorrect proxy base URL for your deployment
- `402 Insufficient balance`: MetricAI-side quota/wallet issue (not provider wallet)
