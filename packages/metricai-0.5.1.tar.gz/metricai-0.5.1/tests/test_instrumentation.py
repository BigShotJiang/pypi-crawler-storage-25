"""Global instrument() monkey-patch tests."""

from __future__ import annotations

import sys
import types
from typing import Any, Dict, Optional

import pytest

from metricai import attribution_scope
from metricai.instrumentation import _INSTRUMENTED, instrument, restore_instrumentation
from metricai.runtime import init


class _FakeOpenAI:
    instances: list["_FakeOpenAI"] = []

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        default_headers: Optional[Dict[str, str]] = None,
        **_: Any,
    ) -> None:
        self.api_key = api_key
        self.base_url = str(base_url).rstrip("/")
        self.default_headers = dict(default_headers or {})
        _FakeOpenAI.instances.append(self)


@pytest.fixture(autouse=True)
def _reset_instrumented() -> None:
    _INSTRUMENTED.clear()
    _FakeOpenAI.instances.clear()
    _FakeAnthropic.instances.clear()
    yield
    restore_instrumentation()


@pytest.fixture
def fake_openai_module(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(sys.modules, "openai", types.SimpleNamespace(OpenAI=_FakeOpenAI))


def test_instrument_patches_openai_after_init(fake_openai_module: None) -> None:
    init(api_key="mai_test_key", base_url="https://proxy.test", default_agent_id="app-agent")
    instrument(providers=["openai"], openai_api_key="sk-byok")

    from openai import OpenAI

    client = OpenAI()
    assert client.api_key == "mai_test_key"
    assert client.base_url == "https://proxy.test/v1/proxy/openai"
    assert client.default_headers["X-MetricAI-API-Key"] == "mai_test_key"
    assert "X-MetricAI-Key" not in client.default_headers
    assert client.default_headers["X-OpenAI-API-Key"] == "sk-byok"


def test_instrument_is_idempotent(fake_openai_module: None) -> None:
    init(api_key="mai_test_key", base_url="https://proxy.test")
    instrument(providers=["openai"])
    instrument(providers=["openai"])
    assert "openai" in _INSTRUMENTED


class _FakeAnthropic:
    instances: list["_FakeAnthropic"] = []

    def __init__(
        self,
        *args: Any,
        auth_token: Optional[str] = None,
        api_key: Optional[str] = None,
        base_url: str = "",
        default_headers: Optional[Dict[str, str]] = None,
        **_: Any,
    ) -> None:
        self.auth_token = auth_token
        self.api_key = api_key
        self.base_url = str(base_url).rstrip("/")
        self.default_headers = dict(default_headers or {})
        _FakeAnthropic.instances.append(self)


@pytest.fixture
def fake_anthropic_module(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(
        sys.modules, "anthropic", types.SimpleNamespace(Anthropic=_FakeAnthropic)
    )


def test_instrument_patches_anthropic_with_auth_token(
    fake_anthropic_module: None,
) -> None:
    init(api_key="mai_test_key", base_url="https://proxy.test", default_agent_id="app-agent")
    instrument(providers=["anthropic"], anthropic_api_key="sk-ant-byok")

    from anthropic import Anthropic

    client = Anthropic()
    assert client.auth_token == "mai_test_key"
    assert client.base_url == "https://proxy.test/v1/proxy/claude"
    assert client.default_headers["X-MetricAI-API-Key"] == "mai_test_key"
    assert client.default_headers["Authorization"] == "Bearer mai_test_key"
    assert client.default_headers["X-Claude-API-Key"] == "sk-ant-byok"
    assert "X-MetricAI-Idempotency-Key" in client.default_headers


def test_attribution_scope_flows_into_headers(fake_openai_module: None) -> None:
    init(api_key="mai_test_key", base_url="https://proxy.test")
    instrument(providers=["openai"], openai_api_key="sk-byok")

    from openai import OpenAI

    with attribution_scope(user_id="user-42", agent_id="scoped-agent"):
        client = OpenAI()
    assert client.default_headers["X-User-ID"] == "user-42"
    assert client.default_headers["X-Agent-ID"] == "scoped-agent"
