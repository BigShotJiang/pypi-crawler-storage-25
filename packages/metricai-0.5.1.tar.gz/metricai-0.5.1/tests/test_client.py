import pytest

from metricai import MetricAIClient
from metricai.exceptions import MetricAIConfigError
from metricai.retry import RetryConfig


def test_metricai_requires_api_key() -> None:
    with pytest.raises(MetricAIConfigError):
        MetricAIClient(api_key="")


def test_metricai_validates_environment() -> None:
    with pytest.raises(MetricAIConfigError):
        MetricAIClient(api_key="mak_test", environment="dev")


def test_metricai_validates_retry_config_type() -> None:
    with pytest.raises(MetricAIConfigError):
        MetricAIClient(api_key="mak_test", retry_config="bad")  # type: ignore[arg-type]


def test_headers_include_expected_defaults() -> None:
    client = MetricAIClient(
        api_key="mak_test",
        agent_id="agent-1",
        session_id="session-1",
        user_id="user-1",
        retry_config=RetryConfig(max_retries=0),
    )
    headers = client.headers()
    assert headers["X-MetricAI-API-Key"] == "mak_test"
    assert "X-MetricAI-Key" not in headers
    assert headers["X-Agent-ID"] == "agent-1"
    assert headers["X-Session-ID"] == "session-1"
    assert headers["X-User-ID"] == "user-1"
    assert headers["X-MetricAI-Request-Mode"] == "standard"
