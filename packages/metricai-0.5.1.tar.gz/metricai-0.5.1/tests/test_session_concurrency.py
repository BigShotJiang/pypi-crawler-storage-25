"""reliability-fix: FIX-5 — MetricAISession budget and spend are serialized under a lock."""

from __future__ import annotations

import threading
from unittest.mock import patch

import pytest
import respx
from httpx import Response

from metricai import MetricAI, MetricAISession
from metricai.exceptions import MetricAIBudgetExceeded

API = "https://t.test"
TEL = f"{API}/v1/sdk/events"


@respx.mock
def test_session_concurrent_tracks_respect_max_budget() -> None:
    respx.post(TEL).mock(return_value=Response(200, json={}))
    c = MetricAI(api_key="mak_x", base_url=API)  # reliability-fix: FIX-5
    with patch.object(c, "complete_session", lambda s: None):  # type: ignore[misc]  # reliability-fix: FIX-5
        s = MetricAISession(c, max_budget_inr=50.0, agent_id="a", user_id="u")  # reliability-fix: FIX-5

    errors = 0  # reliability-fix: FIX-5

    def one() -> None:  # reliability-fix: FIX-5
        nonlocal errors
        for _ in range(3):
            try:
                s.track(  # reliability-fix: FIX-5
                    provider="openai",  # reliability-fix: FIX-5
                    model="gpt-4o-mini",  # reliability-fix: FIX-5
                    cost_inr=10.0,  # type: ignore[misc]  # reliability-fix: FIX-5
                )  # reliability-fix: FIX-5
            except MetricAIBudgetExceeded:
                errors += 1
                return

    futs = [threading.Thread(target=one) for _ in range(10)]  # type: ignore[misc]  # reliability-fix: FIX-5
    for t_ in futs:  # reliability-fix: FIX-5
        t_.start()  # type: ignore[misc]  # reliability-fix: FIX-5
    for t_ in futs:  # reliability-fix: FIX-5
        t_.join()  # type: ignore[misc]  # reliability-fix: FIX-5

    assert s._total_cost <= 60.0  # type: ignore[misc]  # at most one 10.0 over cap  # reliability-fix: FIX-5
    assert errors >= 1  # at least one thread should hit the hard cap  # reliability-fix: FIX-5
