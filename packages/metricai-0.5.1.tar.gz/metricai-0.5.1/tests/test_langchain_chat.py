"""ChatMetricAI (LangChain) smoke tests."""

import pytest

pytest.importorskip("langchain_core")

from metricai.integrations.langchain_chat import ChatMetricAI


def test_chat_metricai_llm_type_and_params() -> None:
    llm = ChatMetricAI(metricai_api_key="mak_test", model="gpt-4o-mini", provider="openai")
    assert llm._llm_type == "chat-metricai"
    p = llm._identifying_params
    assert p["model"] == "gpt-4o-mini"
    assert p["provider"] == "openai"
