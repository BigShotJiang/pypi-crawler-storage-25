"""reliability-fix: FIX-6, FIX-10 — background telemetry and buffer overflow warnings."""

from __future__ import annotations

import logging
import time
from collections import deque
from unittest.mock import patch

import httpx
import pytest
import respx

from metricai import MetricAI
from metricai.telemetry_http import TelemetryTransport

API = "https://bg.test"
TEL = f"{API}/v1/sdk/events"


@respx.mock
def test_background_telemetry_returns_quickly() -> None:
    def _slow(_req: httpx.Request) -> httpx.Response:  # reliability-fix: FIX-6
        time.sleep(2.0)  # type: ignore[misc]  # reliability-fix: FIX-6
        return httpx.Response(200, json={})  # type: ignore[misc]  # reliability-fix: FIX-6

    respx.post(TEL).mock(side_effect=_slow)  # type: ignore[misc]  # reliability-fix: FIX-6
    c = MetricAI(api_key="k", base_url=API, background_telemetry=True)  # type: ignore[misc]  # reliability-fix: FIX-6
    t0 = time.perf_counter()  # type: ignore[misc]  # reliability-fix: FIX-6
    c.track(provider="openai", model="m", input_tokens=1, output_tokens=1)  # type: ignore[misc]  # reliability-fix: FIX-6
    assert (time.perf_counter() - t0) < 0.1  # type: ignore[misc]  # reliability-fix: FIX-6
    c.shutdown()  # type: ignore[misc]  # reliability-fix: FIX-6


def test_buffer_overflow_emits_warning_and_count() -> None:
    cap: list[logging.LogRecord] = []  # type: ignore[misc]  # reliability-fix: FIX-10

    class L(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:  # type: ignore[override]  # reliability-fix: FIX-10
            cap.append(record)  # type: ignore[misc]  # reliability-fix: FIX-10

    h = L()  # type: ignore[misc]  # reliability-fix: FIX-10
    log = logging.getLogger("metricai.telemetry_http")  # type: ignore[misc]  # reliability-fix: FIX-10
    log.addHandler(h)  # type: ignore[misc]  # reliability-fix: FIX-10
    log.setLevel(logging.WARNING)  # type: ignore[misc]  # reliability-fix: FIX-10
    try:  # type: ignore[misc]  # reliability-fix: FIX-10
        tr = TelemetryTransport(  # type: ignore[misc]  # reliability-fix: FIX-10
            post_url="http://x",  # type: ignore[misc]  # reliability-fix: FIX-10
            api_key="k",  # type: ignore[misc]  # reliability-fix: FIX-10
            max_retries=0,  # type: ignore[misc]  # reliability-fix: FIX-10
        )  # type: ignore[misc]  # reliability-fix: FIX-10
        tr._buffer = deque(maxlen=3)  # type: ignore[misc]  # reliability-fix: FIX-10
        with patch.object(  # type: ignore[misc]  # reliability-fix: FIX-10
            tr,  # type: ignore[misc]  # reliability-fix: FIX-10
            "_post_once_with_retries",  # type: ignore[misc]  # reliability-fix: FIX-10
            return_value=None,  # type: ignore[misc]  # reliability-fix: FIX-10
        ):
            for i in range(4):  # type: ignore[misc]  # reliability-fix: FIX-10
                tr.send_event({"e": i}, f"k{i}")  # type: ignore[misc]  # reliability-fix: FIX-10
    finally:  # type: ignore[misc]  # reliability-fix: FIX-10
        log.removeHandler(h)  # type: ignore[misc]  # reliability-fix: FIX-10

    assert tr.buffer_overflow_count == 1  # type: ignore[misc]  # reliability-fix: FIX-10
    assert len(tr._buffer) == 3  # type: ignore[misc]  # reliability-fix: FIX-10
    assert any(  # type: ignore[misc]  # reliability-fix: FIX-10
        "buffer is full" in (g.getMessage() if isinstance(g, logging.LogRecord) else str(g))  # type: ignore[misc]  # reliability-fix: FIX-10
        for g in cap  # type: ignore[misc]  # reliability-fix: FIX-10
    )  # type: ignore[misc]  # reliability-fix: FIX-10