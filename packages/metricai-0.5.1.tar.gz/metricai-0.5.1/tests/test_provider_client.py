"""Tests for centralized MetricAI proxy auth helpers."""

from __future__ import annotations

from metricai.headers import build_proxy_attribution_headers
from metricai.provider_client import (
    build_metricai_auth_headers,
    build_provider_sdk_kwargs,
    is_metricai_api_key,
    metricai_auth_credential_key,
)


def test_build_metricai_auth_headers() -> None:
    h = build_metricai_auth_headers("metricai_test_key")
    assert h["Authorization"] == "Bearer metricai_test_key"
    assert h["X-MetricAI-API-Key"] == "metricai_test_key"


def test_is_metricai_api_key_prefixes() -> None:
    assert is_metricai_api_key("metricai_abc")
    assert is_metricai_api_key("mtr_xyz")
    assert not is_metricai_api_key("sk-ant-abc")
    assert not is_metricai_api_key("")


def test_build_provider_sdk_kwargs_openai() -> None:
    attr = build_proxy_attribution_headers(
        api_key="metricai_x",
        agent_id="a1",
        user_id="u1",
        idempotency_key="idem-1",
    )
    kw = build_provider_sdk_kwargs(
        "openai",
        api_key="metricai_x",
        base_url="https://proxy.test/v1/proxy/openai",
        default_headers=attr,
    )
    assert kw["api_key"] == "metricai_x"
    assert "auth_token" not in kw
    assert kw["default_headers"]["Authorization"] == "Bearer metricai_x"
    assert kw["default_headers"]["X-MetricAI-Idempotency-Key"] == "idem-1"
    assert kw["default_headers"]["X-Idempotency-Key"] == "idem-1"


def test_build_provider_sdk_kwargs_anthropic() -> None:
    attr = build_proxy_attribution_headers(
        api_key="metricai_x",
        agent_id="a1",
        user_id="u1",
    )
    kw = build_provider_sdk_kwargs(
        "anthropic",
        api_key="metricai_x",
        base_url="https://proxy.test/v1/proxy/claude",
        default_headers=attr,
    )
    assert kw["auth_token"] == "metricai_x"
    assert "api_key" not in kw
    assert "X-Claude-API-Key" not in kw["default_headers"]  # BYOK added separately


def test_metricai_auth_credential_key() -> None:
    assert metricai_auth_credential_key("openai") == "api_key"
    assert metricai_auth_credential_key("anthropic") == "auth_token"
    assert metricai_auth_credential_key("claude") == "auth_token"
