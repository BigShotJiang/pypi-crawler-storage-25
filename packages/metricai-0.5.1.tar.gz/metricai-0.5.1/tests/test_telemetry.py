"""Telemetry ingest, MetricAISession, streaming track, simulate, budgets, tools."""

from __future__ import annotations

import json
import re
from typing import Any

import httpx
import pytest
import respx

from metricai import (
    MetricAI,
    MetricAISession,
    estimate_context_tokens,
    timed_call,
    track_mcp_call,
)
from metricai.exceptions import MetricAIBudgetExceeded


API_BASE = "https://api.test"
TELEMETRY = f"{API_BASE}/v1/sdk/events"


@pytest.fixture
def api_key() -> str:
    return "mak_test"


@respx.mock
def test_track_includes_idempotency_key_in_json_body_matches_header(api_key: str) -> None:
    """reliability-fix: FIX-9 — POST body contains idempotency_key and matches Idempotency-Key header."""
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["key"] = request.headers.get("idempotency-key") or request.headers.get("Idempotency-Key")
        captured["body"] = json.loads(request.content.decode() or "{}")
        return httpx.Response(200, json={"ok": True})

    respx.post(TELEMETRY).mock(side_effect=handler)
    client = MetricAI(api_key=api_key, base_url=API_BASE)
    r = client.track(
        provider="openai",
        model="gpt-4o-mini",
        input_tokens=1,
        output_tokens=1,
    )
    assert r is not None
    b = captured["body"]
    assert b.get("idempotency_key")
    assert re.match(
        r"^[0-9a-fA-F-]{36}$",
        b["idempotency_key"],
    )
    assert str(b["idempotency_key"]).lower() == str(captured["key"]).lower()


@respx.mock
def test_track_sends_idempotency_and_streamed_flag(api_key: str) -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["key"] = request.headers.get("idempotency-key")
        captured["body"] = json.loads(request.content.decode() or "{}")
        return httpx.Response(200, json={"ok": True})

    respx.post(TELEMETRY).mock(side_effect=handler)
    client = MetricAI(api_key=api_key, base_url=API_BASE)
    r = client.track(
        provider="openai",
        model="gpt-4o-mini",
        input_tokens=10,
        output_tokens=5,
        stream=True,
        idempotency_key="custom-key",
    )
    assert r is not None and r.get("ok") is True
    assert captured["key"] == "custom-key"
    assert captured["body"]["streamed"] is True
    assert captured["body"]["event_type"] == "turn"


@respx.mock
def test_track_tools_derived_fields(api_key: str) -> None:
    bodies: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        bodies.append(json.loads(request.content.decode() or "{}"))
        return httpx.Response(200, json={})

    respx.post(TELEMETRY).mock(side_effect=handler)
    client = MetricAI(api_key=api_key, base_url=API_BASE)
    client.track(
        provider="openai",
        model="m",
        tools=[
            {"name": "s", "type": "web_search", "invoked": True},
            {"name": "f", "type": "function_call", "invoked": True},
        ],
    )
    assert bodies[0]["tool_invocation_count"] == 2
    assert bodies[0]["execution_type"] == "mixed"


@respx.mock
def test_track_modalities_dominant(api_key: str) -> None:
    bodies: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        bodies.append(json.loads(request.content.decode() or "{}"))
        return httpx.Response(200, json={})

    respx.post(TELEMETRY).mock(side_effect=handler)
    client = MetricAI(api_key=api_key, base_url=API_BASE)
    client.track(
        provider="openai",
        model="m",
        input_tokens=100,
        modalities={"text_tokens": 80, "image_count": 2},
    )
    assert bodies[0]["dominant_modality"] == "multimodal"


@respx.mock
def test_simulate_returns_simulation_result(api_key: str) -> None:
    respx.post(TELEMETRY).mock(return_value=httpx.Response(200, json={}))
    client = MetricAI(api_key=api_key, base_url=API_BASE)
    sr = client.track(
        simulate=True,
        outcome={"success": True, "charge_on_success_inr": 3.5},
    )
    assert sr["would_charge_inr"] == 3.5
    assert sr["outcome_matched"] is True


@respx.mock
def test_track_stream_opensai_flushes_track(api_key: str) -> None:
    bodies: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        bodies.append(json.loads(request.content.decode() or "{}"))
        return httpx.Response(200, json={})

    respx.post(TELEMETRY).mock(side_effect=handler)
    client = MetricAI(api_key=api_key, base_url=API_BASE)
    with client.track_stream(provider="openai", model="gpt-4o-mini") as st:
        st.feed_sse_data_line('data: {"choices":[{"delta":{"content":"Hi"}}]}\n')
        st.feed_sse_data_line("data: [DONE]\n")
    assert len(bodies) == 1
    b = bodies[0]
    assert b["streamed"] is True
    assert b["chunk_count"] == 1
    assert b["first_token_latency_ms"] is not None
    assert b["total_latency_ms"] >= 0


@respx.mock
def test_track_stream_interrupted_on_exception(api_key: str) -> None:
    bodies: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        bodies.append(json.loads(request.content.decode() or "{}"))
        return httpx.Response(200, json={})

    respx.post(TELEMETRY).mock(side_effect=handler)
    client = MetricAI(api_key=api_key, base_url=API_BASE)
    with pytest.raises(RuntimeError):
        with client.track_stream(provider="openai", model="m") as st:
            st.feed_sse_data_line('data: {"choices":[{"delta":{"content":"x"}}]}\n')
            raise RuntimeError("boom")
    assert bodies[0]["stream_interrupted"] is True


@respx.mock
def test_metricai_session_close_and_complete(api_key: str) -> None:
    events: list[dict] = []
    complete_hits: list[str] = []
    close_keys: list[str | None] = []

    def tel(request: httpx.Request) -> httpx.Response:
        events.append(json.loads(request.content.decode() or "{}"))
        close_keys.append(request.headers.get("idempotency-key"))
        return httpx.Response(200, json={})

    def complete(request: httpx.Request) -> httpx.Response:
        complete_hits.append(str(request.url.path))
        return httpx.Response(200, json={})

    respx.post(TELEMETRY).mock(side_effect=tel)
    respx.post(url__regex=re.compile(r"/v1/sessions/[^/]+/complete$")).mock(side_effect=complete)

    client = MetricAI(api_key=api_key, base_url=API_BASE)
    with MetricAISession(client, agent_id="a1", user_id="u1") as session:
        sid = session.session_id
        session.track(provider="openai", model="m", input_tokens=5, output_tokens=3, context_tokens=100)
        session.track(provider="openai", model="m", input_tokens=2, output_tokens=1)

    closes = [e for e in events if e.get("event_type") == "session_close"]
    assert len(closes) == 1
    assert closes[0]["session_id"] == sid
    assert closes[0]["total_turns"] == 2
    assert closes[0]["cumulative_context_tokens"] == 100
    assert close_keys[-1] == sid
    assert len(complete_hits) == 1


@respx.mock
def test_metricai_session_close_total_turns_in_extra_merge(api_key: str) -> None:
    events: list[dict] = []

    def tel(request: httpx.Request) -> httpx.Response:
        events.append(json.loads(request.content.decode() or "{}"))
        return httpx.Response(200, json={})

    respx.post(TELEMETRY).mock(side_effect=tel)
    respx.post(url__regex=re.compile(r"/v1/sessions/[^/]+/complete$")).mock(
        return_value=httpx.Response(200, json={})
    )

    client = MetricAI(api_key=api_key, base_url=API_BASE)
    with MetricAISession(client) as session:
        session.track(provider="openai", model="m", input_tokens=1, output_tokens=1)

    close = [e for e in events if e.get("event_type") == "session_close"][0]
    assert close["total_turns"] == 1
    assert close["total_input_tokens"] == 1
    assert close["total_output_tokens"] == 1
    assert close["cumulative_context_tokens"] == 0


@respx.mock
def test_budget_exceeded_raises_after_close(api_key: str) -> None:
    events: list[dict] = []

    def tel(request: httpx.Request) -> httpx.Response:
        events.append(json.loads(request.content.decode() or "{}"))
        return httpx.Response(200, json={})

    respx.post(TELEMETRY).mock(side_effect=tel)
    respx.post(url__regex=re.compile(r"/v1/sessions/[^/]+/complete$")).mock(
        return_value=httpx.Response(200, json={})
    )

    client = MetricAI(api_key=api_key, base_url=API_BASE)
    with pytest.raises(MetricAIBudgetExceeded) as ei:
        with MetricAISession(client, max_budget_inr=10.0) as session:
            session.track(cost_inr=6.0, provider="openai", model="m")
            session.track(cost_inr=6.0, provider="openai", model="m")
    assert ei.value.spent_inr == 12.0
    assert ei.value.budget_inr == 10.0
    closes = [e for e in events if e.get("event_type") == "session_close"]
    assert closes[-1]["status"] == "budget_exceeded"


def test_estimate_context_tokens() -> None:
    n = estimate_context_tokens(
        [{"role": "user", "content": "abcd"}],
        model="gpt-4o-mini",
    )
    assert n == 1


@respx.mock
def test_track_mcp_call_payload(api_key: str) -> None:
    bodies: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        bodies.append(json.loads(request.content.decode() or "{}"))
        return httpx.Response(200, json={})

    respx.post(TELEMETRY).mock(side_effect=handler)
    client = MetricAI(api_key=api_key, base_url=API_BASE)
    track_mcp_call(client, "github-mcp", "create_issue", session_id="s1", latency_ms=42)
    b = bodies[0]
    assert b["mcp_call"] is True
    assert b["tools"][0]["provider"] == "github-mcp"
    assert b["tools"][0]["type"] == "mcp_tool"


def test_timed_call_elapsed() -> None:
    with timed_call() as t:
        pass
    assert isinstance(t.elapsed_ms, int)
    assert t.elapsed_ms >= 0


@respx.mock
def test_telemetry_retry_then_success(api_key: str) -> None:
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] == 1:
            return httpx.Response(503, json={})
        return httpx.Response(200, json={})

    respx.post(TELEMETRY).mock(side_effect=handler)
    client = MetricAI(api_key=api_key, base_url=API_BASE, max_retries=2, telemetry_timeout_seconds=5.0)
    r = client.track(provider="openai", model="m")
    assert r is not None
    assert calls["n"] == 2


@pytest.mark.asyncio
@respx.mock
async def test_atrack_async(api_key: str) -> None:
    respx.post(TELEMETRY).mock(return_value=httpx.Response(200, json={}))
    client = MetricAI(api_key=api_key, base_url=API_BASE)
    r = await client.atrack(provider="gemini", model="gem", input_tokens=1, output_tokens=2)
    assert r is not None and r.get("ok") is True
