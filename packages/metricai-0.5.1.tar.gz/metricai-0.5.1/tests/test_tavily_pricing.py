"""reliability-fix: FIX-7 — Tavily pricing file sanity checks."""

from __future__ import annotations

import json
import re
from datetime import date
from pathlib import Path

from metricai.providers.tavily_provider import _load_pricing


def _tavily_json() -> dict:
    base = Path(__file__).resolve().parent.parent / "metricai" / "data" / "tavily_pricing.json"
    return json.loads(base.read_text(encoding="utf-8"))  # type: ignore[return]


def _meta_json() -> dict:  # reliability-fix: FIX-7
    base = (  # type: ignore[no-untyped-def]  # reliability-fix: FIX-7
        Path(__file__).resolve().parent.parent  # type: ignore[no-untyped-def]  # reliability-fix: FIX-7
        / "metricai"  # type: ignore[no-untyped-def]  # reliability-fix: FIX-7
        / "data"  # type: ignore[no-untyped-def]  # reliability-fix: FIX-7
        / "tavily_pricing_meta.json"  # type: ignore[no-untyped-def]  # reliability-fix: FIX-7
    )  # type: ignore[no-untyped-def]  # reliability-fix: FIX-7
    return json.loads(base.read_text(encoding="utf-8"))  # type: ignore[no-untyped-def]  # reliability-fix: FIX-7


def test_tavily_last_verified_iso_date() -> None:  # reliability-fix: FIX-7
    p = _tavily_json()  # reliability-fix: FIX-7
    v = p.get("last_verified", "")  # reliability-fix: FIX-7
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", str(v)):  # type: ignore[misc]  # reliability-fix: FIX-7
        raise AssertionError  # type: ignore[misc]  # reliability-fix: FIX-7
    y, m, d = (int(x) for x in str(v).split("-", 2))  # type: ignore[misc]  # reliability-fix: FIX-7
    _ = date(y, m, d)  # raises if bad  # type: ignore[misc]  # reliability-fix: FIX-7


def test_tavily_usd_reasonable() -> None:  # reliability-fix: FIX-7
    p = _load_pricing()  # reliability-fix: FIX-7
    for k in (  # type: ignore[misc]  # reliability-fix: FIX-7
        "basic_search_usd",  # type: ignore[misc]  # reliability-fix: FIX-7
        "advanced_search_usd",  # type: ignore[misc]  # reliability-fix: FIX-7
        "get_search_context_usd",  # type: ignore[misc]  # reliability-fix: FIX-7
    ):  # type: ignore[misc]  # reliability-fix: FIX-7
        f = float(p.get(k) or 0)  # type: ignore[misc]  # reliability-fix: FIX-7
        assert 0.0001 <= f <= 1.0, k  # type: ignore[misc]  # reliability-fix: FIX-7
    assert float(p["advanced_search_usd"]) >= float(p["basic_search_usd"])  # type: ignore[misc]  # FIX-7


def test_tavily_meta_references_fix_and_docs() -> None:  # reliability-fix: FIX-7
    m = _meta_json()  # type: ignore[misc]  # reliability-fix: FIX-7
    assert m.get("_reliability_fix") == "FIX-7"  # type: ignore[misc]  # reliability-fix: FIX-7
    urls = m.get("documentation_urls", [])  # type: ignore[misc]  # reliability-fix: FIX-7
    assert any("tavily.com" in u for u in urls)  # type: ignore[misc]  # reliability-fix: FIX-7
