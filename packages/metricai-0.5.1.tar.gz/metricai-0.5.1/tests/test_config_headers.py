from metricai.config import MetricAIConfig, normalize_provider_for_proxy, resolve_proxy_base_url
from metricai.proxy import get_proxy_config


def test_normalize_provider_maps_spec_names() -> None:
    assert normalize_provider_for_proxy("anthropic") == "claude"
    assert normalize_provider_for_proxy("groq") == "grok"
    assert normalize_provider_for_proxy("openai") == "openai"


def test_metricai_config_proxy_url() -> None:
    cfg = MetricAIConfig(api_key="mak_x", proxy_base_url="https://api.test")
    assert cfg.proxy_url_for("openai") == "https://api.test/v1/proxy/openai"
    assert cfg.proxy_url_for("groq") == "https://api.test/v1/proxy/grok"
    assert cfg.proxy_url_for("anthropic") == "https://api.test/v1/proxy/claude"


def test_proxy_config_returns_error_parser() -> None:
    cfg = get_proxy_config("openai", "mak_123", agent_id="a1", session_id="s1", user_id="u1")
    assert cfg["base_url"] == "https://proxy.metricai.co.in/v1/proxy/openai"
    assert cfg["api_key"] == "mak_123"
    assert cfg["default_headers"]["X-MetricAI-API-Key"] == "mak_123"
    assert cfg["default_headers"]["Authorization"] == "Bearer mak_123"
    assert "X-MetricAI-Key" not in cfg["default_headers"]
    assert cfg["default_headers"]["X-Agent-ID"] == "a1"
    assert "X-MetricAI-Idempotency-Key" in cfg["default_headers"]
    assert "X-Idempotency-Key" in cfg["default_headers"]
    assert callable(cfg["error_parser"])


def test_proxy_config_anthropic_returns_auth_token() -> None:
    cfg = get_proxy_config("anthropic", "mak_123", agent_id="a1", user_id="u1")
    assert cfg["base_url"] == "https://proxy.metricai.co.in/v1/proxy/claude"
    assert cfg["auth_token"] == "mak_123"
    assert "api_key" not in cfg
    assert cfg["default_headers"]["Authorization"] == "Bearer mak_123"


def test_resolve_proxy_url_from_env(monkeypatch) -> None:
    monkeypatch.setenv("METRICAI_PROXY_URL", "https://custom.proxy")
    assert resolve_proxy_base_url(None) == "https://custom.proxy"
