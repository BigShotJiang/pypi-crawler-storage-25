"""reliability-fix: FIX-4 — multi-provider token extraction for LangChain-style outputs."""

import pytest

from metricai.integrations._token_utils import _extract_tokens


def test_openai_shaped_token_usage() -> None:
    llm = {"token_usage": {"prompt_tokens": 10, "completion_tokens": 5}}  # reliability-fix: FIX-4
    assert _extract_tokens(llm) == (10, 5)  # reliability-fix: FIX-4


def test_anthropic_shaped_token_usage() -> None:
    llm = {"token_usage": {"input_tokens": 10, "output_tokens": 5}}  # reliability-fix: FIX-4
    assert _extract_tokens(llm) == (10, 5)  # reliability-fix: FIX-4


def test_gemini_shaped_token_usage() -> None:
    llm = {  # reliability-fix: FIX-4
        "token_usage": {"promptTokenCount": 10, "candidatesTokenCount": 5}  # reliability-fix: FIX-4
    }  # reliability-fix: FIX-4
    assert _extract_tokens(llm) == (10, 5)  # reliability-fix: FIX-4


def test_empty_usage_returns_none() -> None:
    assert _extract_tokens({}) == (None, None)  # reliability-fix: FIX-4
