"""reliability-fix: FIX-13 — MetricAICrew.cost_summary explicit non-implementation."""

from __future__ import annotations

import inspect

from metricai.integrations.crewai import MetricAICrew  # type: ignore[misc]  # FIX-13


def test_cost_summary_is_not_implemented_and_empty() -> None:  # reliability-fix: FIX-13
    doc = inspect.getdoc(MetricAICrew.cost_summary) or ""  # type: ignore[misc]  # FIX-13
    assert "NOT IMPLEMENTED" in doc  # type: ignore[misc]  # FIX-13
    c = object.__new__(MetricAICrew)  # bypass Crew init (optional dependency)  # type: ignore[misc]  # FIX-13
    assert MetricAICrew.cost_summary(c) == {}  # type: ignore[misc]  # FIX-13
