"""Canonical billing event schema and telemetry merge."""

import json

import httpx
import pytest
import respx

from metricai import BillingEvent, MetricAI
from metricai.payload import build_track_payload

API_BASE = "https://api.test"
TELEMETRY = f"{API_BASE}/v1/sdk/events"


@pytest.fixture
def api_key() -> str:
    return "mak_test"


def test_billing_event_to_telemetry_dict() -> None:
    ev = BillingEvent(
        provider_name="aws-bedrock",
        model_name="anthropic.claude-3-haiku-20240307-v1:0",
        provider_category="model_gateway",
        cost_unit="token_gateway",
        latency_ms=12,
        agent_id="a",
        user_id="u",
        session_id="s",
        request_timestamp_iso=BillingEvent.now_iso(),
        input_tokens=1,
        output_tokens=2,
        gateway_provider="aws-bedrock",
        extra={"k": "v"},
    )
    d = ev.to_telemetry_dict()
    assert d["schema_version"]
    assert d["provider_category"] == "model_gateway"
    assert d["cost_unit"] == "token_gateway"
    assert d["provider"] == "aws-bedrock"


def test_build_track_payload_merges_billing_event(api_key: str) -> None:
    ev = BillingEvent(
        provider_name="tavily",
        model_name=None,
        provider_category="tool",
        cost_unit="api_call",
        latency_ms=5,
        agent_id="a1",
        user_id="u1",
        session_id="s1",
        request_timestamp_iso=BillingEvent.now_iso(),
        tool_call_count=1,
    )
    body = build_track_payload(billing_event=ev)
    assert body["event_type"] == "turn"
    assert body["schema_version"]
    assert body["tool_call_count"] == 1


@respx.mock
def test_track_billing_event_post(api_key: str) -> None:
    bodies: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        raw = request.content.decode() if request.content else "{}"
        bodies.append(json.loads(raw) if raw else {})
        return httpx.Response(200, json={"ok": True})

    respx.post(TELEMETRY).mock(side_effect=handler)
    client = MetricAI(api_key=api_key, base_url=API_BASE, environment_tag="staging")
    ev = BillingEvent(
        provider_name="openai",
        model_name="gpt-4o-mini",
        provider_category="llm",
        cost_unit="token",
        latency_ms=20,
        agent_id="a",
        user_id="u",
        session_id=None,
        request_timestamp_iso=BillingEvent.now_iso(),
        input_tokens=3,
        output_tokens=4,
    )
    r = client.track_billing_event(ev)
    assert r is not None and r.get("ok") is True
    assert bodies[0]["environment_tag"] == "staging"
    assert bodies[0]["provider_category"] == "llm"
