"""Governance v1: budgets, tool limits, trimming, usage normalization."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from metricai.conversation_budget import ConversationBudgetRuntime
from metricai.message_context import estimate_messages_prompt_tokens, trim_messages_keep_recent_user_turns
from metricai.tool_output_policy import compact_tool_result
from metricai.usage_normalizer import merge_normalized_usage, normalize_llm_usage
from metricai.workflow.agent import MetricAIAgent


@pytest.fixture
def mock_llm() -> MagicMock:
    return MagicMock()


@pytest.fixture
def mock_client(mock_llm: MagicMock) -> MagicMock:
    client = MagicMock()
    client.openai_sdk.return_value = mock_llm
    return client


def test_legacy_run_has_no_run_report(mock_client: MagicMock, mock_llm: MagicMock) -> None:
    resp = SimpleNamespace(
        choices=[
            SimpleNamespace(
                finish_reason="stop",
                message=SimpleNamespace(content="hi", tool_calls=None),
            )
        ],
        usage=SimpleNamespace(prompt_tokens=3, completion_tokens=2, total_tokens=5),
    )
    mock_llm.chat.completions.create.return_value = resp
    agent = MetricAIAgent(mock_client, "ag", "u1", model="gpt-4o-mini")
    out = agent.run("hello")
    assert out.run_report is None
    assert out.content == "hi"


def test_max_tool_calls_blocks_batch(mock_client: MagicMock, mock_llm: MagicMock) -> None:
    tc1 = SimpleNamespace(id="t1", function=SimpleNamespace(name="x", arguments="{}"))
    tc2 = SimpleNamespace(id="t2", function=SimpleNamespace(name="y", arguments="{}"))
    resp = SimpleNamespace(
        choices=[
            SimpleNamespace(
                finish_reason="tool_calls",
                message=SimpleNamespace(content=None, tool_calls=[tc1, tc2]),
            )
        ],
        usage=SimpleNamespace(prompt_tokens=10, completion_tokens=1, total_tokens=11),
    )
    mock_llm.chat.completions.create.return_value = resp
    agent = MetricAIAgent(mock_client, "ag", "u1", model="m", max_tool_calls=1)
    out = agent.run("q")
    assert out.error == "tool_call_limit_exceeded"
    assert out.run_report is not None
    assert out.run_report["termination_reason"] == "tool_call_limit_exceeded"
    assert out.run_report["tool_calls_used"] == 0


def test_governed_success_two_tool_then_final(mock_client: MagicMock, mock_llm: MagicMock) -> None:
    tc1 = SimpleNamespace(id="t1", function=SimpleNamespace(name="x", arguments="{}"))
    tc2 = SimpleNamespace(id="t2", function=SimpleNamespace(name="y", arguments="{}"))
    resp_tool = SimpleNamespace(
        choices=[
            SimpleNamespace(
                finish_reason="tool_calls",
                message=SimpleNamespace(content=None, tool_calls=[tc1, tc2]),
            )
        ],
        usage=SimpleNamespace(prompt_tokens=8, completion_tokens=2, total_tokens=10),
    )
    resp_final = SimpleNamespace(
        choices=[
            SimpleNamespace(
                finish_reason="stop",
                message=SimpleNamespace(content="ok", tool_calls=None),
            )
        ],
        usage=SimpleNamespace(prompt_tokens=20, completion_tokens=5, total_tokens=25),
    )
    mock_llm.chat.completions.create.side_effect = [resp_tool, resp_final]
    agent = MetricAIAgent(
        mock_client,
        "ag",
        "u1",
        model="m",
        max_tool_calls=5,
        max_single_tool_result_tokens=500,
    )
    out = agent.run("q")
    assert out.content == "ok"
    assert out.run_report is not None
    assert out.run_report["termination_reason"] == "completed"
    assert out.run_report["tool_calls_used"] == 2
    assert len(out.run_report["tool_trace"]) == 2
    assert out.run_report["aggregated_usage"]["total_tokens"] == 35


def test_conversation_token_preflight(mock_client: MagicMock, mock_llm: MagicMock) -> None:
    agent = MetricAIAgent(
        mock_client,
        "ag",
        "u1",
        model="m",
        system_prompt="x" * 4000,
        max_conversation_tokens=10,
    )
    out = agent.run("hello there this is a long user message " * 50)
    assert out.error == "insufficient_remaining_budget_for_request"
    assert mock_llm.chat.completions.create.call_count == 0


def test_conversation_token_exceeded_after_call(mock_client: MagicMock, mock_llm: MagicMock) -> None:
    resp = SimpleNamespace(
        choices=[
            SimpleNamespace(
                finish_reason="stop",
                message=SimpleNamespace(content="done", tool_calls=None),
            )
        ],
        usage=SimpleNamespace(prompt_tokens=500, completion_tokens=100, total_tokens=600),
    )
    mock_llm.chat.completions.create.return_value = resp
    agent = MetricAIAgent(mock_client, "ag", "u1", model="m", max_conversation_tokens=50)
    out = agent.run("short")
    assert out.error == "conversation_token_budget_exceeded"
    assert out.run_report["termination_reason"] == "conversation_token_budget_exceeded"


def test_trim_messages_keep_recent_user_turns() -> None:
    msgs = [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "u1"},
        {"role": "assistant", "content": "a1"},
        {"role": "user", "content": "u2"},
        {"role": "assistant", "content": "a2"},
        {"role": "user", "content": "u3"},
    ]
    trimmed = trim_messages_keep_recent_user_turns(msgs, 2)
    assert trimmed[0]["role"] == "system"
    assert any(m.get("content") == "u2" for m in trimmed)
    assert any(m.get("content") == "u3" for m in trimmed)
    assert not any(m.get("content") == "u1" for m in trimmed[1:])


def test_compact_tool_result_truncates() -> None:
    long = "word " * 2000
    text, truncated, inj = compact_tool_result(long, max_single_tool_result_tokens=50)
    assert truncated is True
    assert "metricai: tool output truncated" in text
    assert inj <= 70


def test_normalize_llm_usage_reasoning() -> None:
    u = {
        "prompt_tokens": 1,
        "completion_tokens": 2,
        "total_tokens": 3,
        "completion_tokens_details": {"reasoning_tokens": 7},
    }
    n = normalize_llm_usage(u)
    assert n["reasoning_tokens"] == 7
    assert n["input_tokens"] == 1


def test_merge_normalized_usage() -> None:
    a = normalize_llm_usage(None, usage_source="unknown")
    b = normalize_llm_usage({"prompt_tokens": 2, "completion_tokens": 3, "total_tokens": 5})
    m = merge_normalized_usage(a, b)
    assert m["input_tokens"] == 2
    assert m["output_tokens"] == 3
    assert m["total_tokens"] == 5


def test_conversation_budget_runtime() -> None:
    b = ConversationBudgetRuntime(max_conversation_tokens=100)
    b.record_llm_usage({"prompt_tokens": 40, "completion_tokens": 10, "total_tokens": 50})
    assert b.remaining_tokens() == 50
    assert not b.assert_under_hard_cap()
    b.record_llm_usage({"prompt_tokens": 60, "completion_tokens": 10, "total_tokens": 70})
    assert b.assert_under_hard_cap()


def test_estimate_messages_includes_tools() -> None:
    msgs = [{"role": "user", "content": "hi"}]
    tools = [{"type": "function", "function": {"name": "f", "parameters": {}}}]
    est = estimate_messages_prompt_tokens(msgs, tools, model=None)
    assert est > 1
