"""MetricAIProxy header construction."""

from __future__ import annotations

from metricai.proxy_transport import MetricAIProxy


def test_metricai_proxy_build_headers_includes_bearer() -> None:
    proxy = MetricAIProxy(
        base_url="https://proxy.test",
        api_key="metricai_test",
        provider="openai",
    )
    headers = proxy._build_headers()
    assert headers["Authorization"] == "Bearer metricai_test"
    assert headers["X-MetricAI-API-Key"] == "metricai_test"
    assert headers["Content-Type"] == "application/json"
