"""reliability-fix: FIX-8, FIX-11 — Bedrock pricing resolution and stream telemetry flags."""

from __future__ import annotations

import base64
import json
from typing import Any, List

from metricai.billing_event import BillingEvent
from metricai.providers.bedrock import (
    _ConverseStreamWithTelemetry,
    _ResponseStreamWithTelemetry,
    _bedrock_model_id_candidates,
    _load_pricing,
    _price_for_model,
    wrap_bedrock_runtime_client,
)


def test_bedrock_model_id_candidates_dedupes_version_suffix() -> None:  # reliability-fix: FIX-8
    c = _bedrock_model_id_candidates("amazon.nova-micro-v1:0")
    assert "amazon.nova-micro-v1:0" in c
    assert c[0] == "amazon.nova-micro-v1:0"


def test_price_for_model_known_nova() -> None:  # reliability-fix: FIX-8
    p_in, p_out = _price_for_model("amazon.nova-micro-v1:0")
    data = _load_pricing()  # reliability-fix: FIX-8
    expected = (data.get("models") or {}).get("amazon.nova-micro-v1:0", {})
    assert p_in == expected.get("input_per_1k_usd")
    assert p_out == expected.get("output_per_1k_usd")


def test_price_for_model_alias_stripped_suffix() -> None:  # reliability-fix: FIX-8
    p_in, p_out = _price_for_model("meta.llama3-8b-instruct-v1:0")
    data = _load_pricing()
    m = (data.get("models") or {}).get("meta.llama3-8b-instruct-v1:0")
    assert p_in == m.get("input_per_1k_usd") and p_out == m.get("output_per_1k_usd")


def test_price_for_model_unknown() -> None:  # reliability-fix: FIX-8
    p_in, p_out = _price_for_model("provider.fictional-tiny-model-v1:0")
    assert p_in is None and p_out is None


def test_price_for_model_haiku_alias() -> None:  # reliability-fix: FIX-8
    a, b = _price_for_model("anthropic.claude-3-5-haiku")
    data = _load_pricing()
    m = (data.get("models") or {}).get("anthropic.claude-3-5-haiku")
    assert a == m.get("input_per_1k_usd")
    assert b == m.get("output_per_1k_usd")


def test_bedrock_pricing_json_has_last_verified() -> None:  # reliability-fix: FIX-8
    cfg = _load_pricing()
    assert cfg.get("last_verified")
    assert isinstance((cfg.get("models") or {}), dict)


class _TrackMock:
    def __init__(self) -> None:
        self.events: List[BillingEvent] = []

    @property
    def config(self) -> Any:  # reliability-fix: FIX-11
        return type("C", (), {"default_agent_id": "t-agent"})()  # reliability-fix: FIX-11

    def track_billing_event(self, ev: BillingEvent) -> None:  # reliability-fix: FIX-11
        self.events.append(ev)  # reliability-fix: FIX-11


def _stream_chunk_b64(usage: dict) -> dict:  # reliability-fix: FIX-11
    payload = json.dumps({"usage": usage}, separators=(",", ":"))
    b64 = base64.b64encode(payload.encode("utf-8")).decode("ascii")
    return {"chunk": {"bytes": b64}}  # reliability-fix: FIX-11


def test_stream_full_drain_interrupted_false() -> None:  # reliability-fix: FIX-11
    mock = _TrackMock()
    items = [  # reliability-fix: FIX-11
        _stream_chunk_b64(
            {  # reliability-fix: FIX-11
                "input_tokens": 3,  # reliability-fix: FIX-11
                "output_tokens": 1,  # reliability-fix: FIX-11
            }  # reliability-fix: FIX-11
        ),  # reliability-fix: FIX-11
    ]
    s = _ResponseStreamWithTelemetry(iter(items), "amazon.titan-text-express-v1", 0.0, mock)
    for _ in s:  # reliability-fix: FIX-11
        pass
    assert len(mock.events) == 1
    ex = mock.events[0].extra
    assert ex.get("stream_interrupted") is False
    assert ex.get("api") == "invoke_model_with_response_stream"


def test_stream_partial_consume_interrupted_true() -> None:  # reliability-fix: FIX-11
    mock = _TrackMock()  # reliability-fix: FIX-11
    # Two chunks: consume one then close so the wrapped iterator is abandoned mid-way.  # reliability-fix: FIX-11
    items: List[dict] = [
        _stream_chunk_b64({"input_tokens": 1, "output_tokens": 0}),
        _stream_chunk_b64({"input_tokens": 0, "output_tokens": 0}),
    ]
    s = _ResponseStreamWithTelemetry(
        iter(items), "amazon.titan-text-express-v1", 0.0, mock
    )  # reliability-fix: FIX-11
    it = iter(s)
    next(it)  # first chunk, second still pending  # reliability-fix: FIX-11
    it.close()  # reliability-fix: FIX-11
    assert len(mock.events) == 1
    assert mock.events[0].extra.get("stream_interrupted") is True  # reliability-fix: FIX-11


def test_converse_stream_class_flags() -> None:  # reliability-fix: FIX-11
    mock = _TrackMock()  # reliability-fix: FIX-11
    row = {  # reliability-fix: FIX-11
        "metadata": {  # reliability-fix: FIX-11
            "usage": {  # reliability-fix: FIX-11
                "inputTokens": 2,  # reliability-fix: FIX-11
                "outputTokens": 4,  # reliability-fix: FIX-11
            }  # reliability-fix: FIX-11
        }  # reliability-fix: FIX-11
    }  # reliability-fix: FIX-11
    s = _ConverseStreamWithTelemetry(  # reliability-fix: FIX-11
        iter([row]),  # type: ignore[misc]  # reliability-fix: FIX-11
        "x",  # reliability-fix: FIX-11
        0.0,  # reliability-fix: FIX-11
        mock,  # reliability-fix: FIX-11
    )  # reliability-fix: FIX-11
    for _ in s:  # type: ignore[misc]  # reliability-fix: FIX-11
        pass  # type: ignore[misc]  # reliability-fix: FIX-11
    assert mock.events[0].extra.get("api") == "converse_stream"  # type: ignore[misc]  # reliability-fix: FIX-11
    assert mock.events[0].extra.get("stream_interrupted") is False  # type: ignore[misc]  # reliability-fix: FIX-11


def test_wrapped_runtime_invoke_stream_uses_telemetry_wrapper() -> None:  # reliability-fix: FIX-11
    mock = _TrackMock()  # reliability-fix: FIX-11

    class R:  # type: ignore[misc]  # reliability-fix: FIX-11
        def invoke_model(self, *a: Any, **k: Any) -> Any:  # type: ignore[no-untyped-def]  # FIX-11
            return {"body": b""}  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11

        def invoke_model_with_response_stream(  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
            self,  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
            *a: Any,  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
            **k: Any,  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
        ) -> dict:  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
            return {  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
                "body": iter(  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
                    [  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
                        _stream_chunk_b64(  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
                            {  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
                                "input_tokens": 1,  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
                                "output_tokens": 2,  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
                            }  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
                        ),  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
                    ]  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
                )  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11
            }  # type: ignore[no-untyped-def]  # reliability-fix: FIX-11

    c = wrap_bedrock_runtime_client(R(), mock)  # type: ignore[misc]  # reliability-fix: FIX-11
    out = c.invoke_model_with_response_stream(modelId="meta.llama3-8b-instruct-v1:0")  # type: ignore[misc]  # reliability-fix: FIX-11
    b = out["body"]  # type: ignore[misc]  # reliability-fix: FIX-11
    for _ in b:  # type: ignore[misc]  # reliability-fix: FIX-11
        pass
    assert len(mock.events) == 1  # type: ignore[misc]  # reliability-fix: FIX-11
    assert mock.events[0].extra.get("stream_interrupted") is False  # type: ignore[misc]  # reliability-fix: FIX-11
