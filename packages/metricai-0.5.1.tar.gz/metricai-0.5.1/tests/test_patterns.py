"""Integration-pattern tests for MetricAI proxy and SDK factory usage."""

from __future__ import annotations

import sys
import types
from typing import Any, Dict, Optional

import httpx
import pytest
import respx

from metricai import MetricAI
from metricai.exceptions import AuthenticationError


API_BASE = "https://proxy.test"
MISSING_KEY_MESSAGE = "Missing MetricAI API key. Provide 'Authorization: Bearer <metricai_api_key>' (primary)"


class _FakeCompletions:
    def __init__(self, owner: "_FakeOpenAI") -> None:
        self._owner = owner

    def create(
        self,
        *,
        model: str,
        messages: list[dict[str, str]],
        extra_headers: Optional[Dict[str, str]] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        headers = dict(self._owner.default_headers)
        headers.update(extra_headers or {})
        self._owner.last_headers = headers
        return {"model": model, "messages": messages, "headers": headers}


class _FakeChat:
    def __init__(self, owner: "_FakeOpenAI") -> None:
        self.completions = _FakeCompletions(owner)


class _FakeOpenAI:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        default_headers: Optional[Dict[str, str]] = None,
        **_: Any,
    ) -> None:
        self.api_key = api_key
        self.base_url = str(base_url).rstrip("/")
        self.default_headers = dict(default_headers or {})
        self.last_headers: Dict[str, str] = {}
        self.chat = _FakeChat(self)


@pytest.fixture
def fake_openai(monkeypatch: pytest.MonkeyPatch) -> type[_FakeOpenAI]:
    from metricai import runtime
    from metricai.instrumentation import restore_instrumentation

    restore_instrumentation()
    runtime._GLOBAL = None  # type: ignore[attr-defined]
    monkeypatch.delenv("METRICAI_API_KEY", raising=False)
    monkeypatch.setitem(sys.modules, "openai", types.SimpleNamespace(OpenAI=_FakeOpenAI))
    return _FakeOpenAI


def test_pattern_a_raw_openai_client_base_url_override(fake_openai: type[_FakeOpenAI]) -> None:
    from openai import OpenAI

    client = OpenAI(
        api_key="mai-test",
        base_url=f"{API_BASE}/v1/proxy/openai",
        default_headers={
            "X-OpenAI-API-Key": "sk-test",
            "X-Agent-ID": "contract-agent",
            "X-User-ID": "user-1",
        },
    )

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello"}],
    )

    assert client.base_url == f"{API_BASE}/v1/proxy/openai"
    assert client.api_key == "mai-test"
    assert response["headers"]["X-Agent-ID"] == "contract-agent"
    assert response["headers"]["X-User-ID"] == "user-1"


def test_pattern_b_metricai_client_factory(fake_openai: type[_FakeOpenAI]) -> None:
    metricai = MetricAI(
        api_key="mai-test",
        base_url=API_BASE,
        provider="openai",
        provider_key="sk-test",
        agent_id="contract-agent",
        user_id="user-1",
    )
    client = metricai.client

    assert isinstance(client, fake_openai)
    assert metricai._api_key == "mai-test"
    assert client.base_url == f"{API_BASE}/v1/proxy/openai"
    assert "X-MetricAI-Key" not in client.default_headers
    assert client.default_headers.get("X-MetricAI-API-Key") == "mai-test"
    assert client.default_headers.get("Authorization") == "Bearer mai-test"
    assert client.default_headers.get("X-OpenAI-API-Key") == "sk-test"
    assert client.default_headers["X-Agent-ID"] == "contract-agent"
    assert client.default_headers["X-User-ID"] == "user-1"


def test_pattern_c_per_request_extra_headers_override(fake_openai: type[_FakeOpenAI]) -> None:
    from openai import OpenAI

    base_client = OpenAI(
        api_key="mai-test",
        base_url=f"{API_BASE}/v1/proxy/openai",
        default_headers={
            "X-Agent-ID": "startup-agent",
            "X-User-ID": "startup-user",
        },
    )

    response = base_client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello"}],
        extra_headers={
            "X-Agent-ID": "request-agent",
            "X-User-ID": "request-user",
        },
    )

    assert response["headers"]["X-Agent-ID"] == "request-agent"
    assert response["headers"]["X-User-ID"] == "request-user"
    assert base_client.api_key == "mai-test"


def test_missing_agent_id_defaults_to_untagged() -> None:
    client = MetricAI(api_key="mai-test", base_url=API_BASE)
    assert client.headers(user_id="user-1")["X-Agent-ID"] == "untagged"


def test_missing_user_id_defaults_to_anonymous() -> None:
    client = MetricAI(api_key="mai-test", base_url=API_BASE)
    assert client.headers(agent_id="agent-1")["X-User-ID"] == "anonymous"


@respx.mock
def test_missing_metricai_key_returns_401_message() -> None:
    respx.post(f"{API_BASE}/v1/proxy/openai/chat/completions").mock(
        return_value=httpx.Response(401, json={"detail": MISSING_KEY_MESSAGE})
    )

    client = MetricAI(api_key="mai-test", base_url=API_BASE)
    client._api_key = ""
    with pytest.raises(AuthenticationError, match="Missing MetricAI API key"):
        client.openai().complete(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )


def test_fail_open_proxy_down_reaches_provider_directly() -> None:
    pytest.xfail("Fail-open forwarding is implemented by the hosted MetricAI proxy, not the Python SDK.")
