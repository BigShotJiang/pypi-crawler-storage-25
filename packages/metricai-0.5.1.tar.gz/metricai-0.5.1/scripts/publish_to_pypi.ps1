# Publish metricai (this SDK) to PyPI from your machine.
# Prerequisites:
#   pip install build twine
#   Set TWINE_USERNAME=__token__ and TWINE_PASSWORD=<pypi API token>
#
# Bump version in pyproject.toml before building.

$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

if (-not $env:TWINE_PASSWORD) {
    Write-Error "Set TWINE_PASSWORD to your PyPI API token and TWINE_USERNAME=__token__"
}

python -m build
python -m twine check dist/*
python -m twine upload dist/*
