"""
Manual smoke test for the MetricAI Python SDK against a real API (hosted or local backend).

Setup:
  - Install the SDK: pip install -e ".[dev]"  (from metricai-sdk/)
  - Export credentials (or use a .env file if python-dotenv is installed):

      set METRICAI_API_KEY=mak_your_key
      optional: set METRICAI_BASE_URL=https://api.metricai.co.in
      optional: set METRICAI_BASE_URL=http://127.0.0.1:8000   (local uvicorn)

Run:
  python scripts/local_sdk_smoke.py
  python scripts/local_sdk_smoke.py --proxy          # also calls /v1/proxy/openai (uses quota)

Without METRICAI_API_KEY, only runs offline checks (version + estimate_context_tokens) and exits 1.
"""

from __future__ import annotations

import argparse
import os
import sys


def _load_dotenv() -> None:
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass


def main() -> int:
    _load_dotenv()
    parser = argparse.ArgumentParser(description="Local MetricAI SDK smoke test")
    parser.add_argument(
        "--api-key",
        default=os.environ.get("METRICAI_API_KEY", ""),
        help="Defaults to METRICAI_API_KEY",
    )
    parser.add_argument(
        "--base-url",
        default=os.environ.get("METRICAI_BASE_URL", ""),
        help="Defaults to METRICAI_BASE_URL or SDK default (https://api.metricai.co.in)",
    )
    parser.add_argument(
        "--proxy",
        action="store_true",
        help="Run a minimal OpenAI proxy completion (consumes API / model quota)",
    )
    args = parser.parse_args()

    import httpx

    from metricai import MetricAI, __version__, estimate_context_tokens

    n = estimate_context_tokens([{"role": "user", "content": "ping"}], model="gpt-4o-mini")
    print(f"metricai SDK version: {__version__}")
    print(f"estimate_context_tokens (offline): {n}")

    if not args.api_key.strip():
        print("\nSkipping live checks: set METRICAI_API_KEY or pass --api-key.")
        return 1

    kwargs: dict = {"api_key": args.api_key.strip()}
    if args.base_url.strip():
        kwargs["base_url"] = args.base_url.strip()
    client = MetricAI(**kwargs)

    try:
        bal = client.get_balance()
        print(f"wallet: {bal.balance_inr} {bal.currency}")
    except httpx.HTTPError as e:
        print(f"get_balance failed: {e}", file=sys.stderr)
        return 1

    try:
        sim = client.track(
            simulate=True,
            outcome={"success": True, "charge_on_success_inr": 0.01},
        )
        if sim is not None:
            print(f"track(simulate=True): would_charge_inr={sim['would_charge_inr']}")
    except httpx.HTTPError as e:
        print(f"track(simulate) failed: {e}", file=sys.stderr)
        return 1

    if args.proxy:
        try:
            resp = client.openai().complete(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "Reply with exactly: ok"}],
                max_tokens=8,
            )
            text = resp["choices"][0]["message"].get("content", "")
            print(f"proxy openai complete: {text!r}")
        except httpx.HTTPError as e:
            print(f"proxy complete failed: {e}", file=sys.stderr)
            return 1

    print("smoke: ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
