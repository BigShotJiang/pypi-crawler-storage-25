# Changelog

## 0.5.1

- Unified proxy auth: all SDK paths emit `Authorization: Bearer` and `X-MetricAI-API-Key`; idempotency uses both `X-MetricAI-Idempotency-Key` and `X-Idempotency-Key`.
- Backend accepts MetricAI API keys via Anthropic SDK `X-Api-Key` (raw `Anthropic(api_key=METRICAI_API_KEY)` matches OpenAI/Gemini shape).
- Added `metricai.provider_client` helpers and `MetricAI.provider_sdk(provider)` dispatch.
- `get_proxy_config("anthropic")` returns `auth_token` (not `api_key`); `MetricAIProxy` sends Bearer auth.
- Provider hook activation passes the `MetricAI` client into `instrument()` (no `init()` required for `MetricAI()` constructor).
- Ingress idempotency replay accepts `X-Idempotency-Key` and `Idempotency-Key`.

## 0.5.0

- SDK no longer emits `X-MetricAI-Key`; proxy auth uses `Authorization: Bearer` via provider `api_key=`. `X-MetricAI-API-Key` retained as transitional alias. Server still accepts legacy `X-MetricAI-Key`.
- `anthropic_sdk()` and `instrument()` for Claude use `auth_token=` (Bearer); raw `api_key=` also works when the proxy accepts MetricAI `X-Api-Key`.
- Added `metricai.integrations.web.MetricAIFastAPIMiddleware` and `MetricAIDjangoMiddleware` for per-request attribution.
- Added `GET /v1/auth/ping` (backend) and `MetricAI.validate_api_key()` / `init(..., validate=True)`.
- Added `OutcomeConfigModel` with factory helpers; `track()` accepts models via `to_outcome_dict()`.
- Added `track_response()` helper for non-proxy provider responses.
- Deprecated public export of `SessionContext`; use `MetricAIProxyClientSession` or `MetricAISession`.
- Bedrock: `instrument_boto3_client()` and warning for clients created before `init()`.
- Managed mode: `X-Key-Mode` header only sent when `mode="managed"`; startup warning logged.

## 0.4.0

- Added `metricai.instrument()` for global OpenAI/Anthropic SDK monkey-patching after `init()`.
- Provider SDK `api_key` is the MetricAI key (Bearer auth); BYOK via `X-*-API-Key` headers.
- `get_proxy_config()` returns `api_key` for vendor SDK constructors.
- Removed `dummy` / `metricai` placeholder keys from docs and factories.
- `init(..., auto_instrument=True)` optionally patches provider SDKs at startup.

## 0.3.1

- Fixed proxy URL contract to `https://proxy.metricai.co.in/v1/proxy/{provider}` (was `/{provider}/v1`).
- Restored telemetry APIs (`track`, `atrack`, `track_stream`, `complete_session`, `.client` factory).
- Wired `runtime.init()` to provider `activate()` hooks (Bedrock/Tavily).
- Backend: 308 redirect from legacy `/{provider}/v1/*` paths.

## 0.3.0

- Added `MetricAIClient` as the canonical SDK entrypoint and kept `MetricAI` as a compatibility alias.
- Added strict initialization validation with `MetricAIConfigError` for API key, environment, retry config, and attribution field limits.
- Added centralized header construction via internal `_build_headers()` for all outbound requests.
- Added support for required/optional MetricAI headers:
  `X-MetricAI-Key`, `X-Agent-ID`, `X-Session-ID`, `X-User-ID`,
  `X-MetricAI-Idempotency-Key`, and `X-MetricAI-Request-Mode`.
- Added dynamic attribution kwargs on wrapped provider calls:
  `metricai_agent_id`, `metricai_session_id`, `metricai_user_id`, and `metricai_idempotency_key`.
- Added full error taxonomy in `metricai.exceptions`:
  `MetricAIError`, `MetricAIConfigError`, `MetricAIQuotaExhaustedError`,
  `MetricAIFeatureNotAvailableError`, `MetricAIAuthError`, `MetricAIRateLimitError`,
  `MetricAIProviderError`, `MetricAIProxyError`, and `MetricAIStreamError`.
- Added response error parser to convert proxy/provider HTTP errors into typed MetricAI errors.
- Added retry model via `RetryConfig` with capped exponential backoff, rate-limit handling, and idempotency-key reuse per logical call.
- Added `QuotaStatus` dataclass and `MetricAIClient.get_quota_status()` for billing usage checks (`GET /v1/billing/usage`).
- Added zero-change proxy helper `metricai.proxy.get_proxy_config(provider, ...)` returning `base_url`, `default_headers`, and `error_parser`.
- Updated integrations for LangChain, CrewAI, LlamaIndex, and AutoGen middleware wrappers to propagate MetricAI context and typed errors.
- Bumped package version to `0.3.0`.
