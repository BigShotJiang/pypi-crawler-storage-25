# MetricAI Python SDK — Developer documentation

Version **0.5.0** (see `CHANGELOG.md`). This document reflects the SDK as implemented in the `metricai` package source.

---

## Section 1 — What MetricAI Does in One Paragraph

You need predictable cost and usage data for LLM and tool calls without rewriting your agents. MetricAI sits between your application and provider APIs: you point official SDKs or HTTP clients at MetricAI’s proxy URLs (or wrap boto3/Tavily), and the platform meters traffic server-side. The Python SDK configures those endpoints, attaches attribution headers (`X-Agent-ID`, `X-User-ID`, `X-Session-ID`, billing mode, budgets), and can send extra telemetry events to MetricAI’s ingest API. You keep calling the same completion APIs you use today; metering and dashboard visibility come from routing and headers, not from replacing your agent logic.

---

## Section 2 — Requirements

**Python:** `>=3.10` (from `pyproject.toml`).

**Core dependencies (always installed with `metricai`):**

| Package | Constraint |
|---------|------------|
| `httpx` | `>=0.27.0` |
| `pydantic` | `>=2.0.0` |
| `typing_extensions` | `>=4.0.0` |

**Optional extras (install as `pip install "metricai[extra]"` or `metricai[all]`):**

| Extra | Packages |
|-------|----------|
| `openai` | `openai>=1.0.0` |
| `anthropic` | `anthropic>=0.30.0` |
| `langchain` | `langchain-core>=0.2`, `langchain-openai>=0.1.0`, `langchain-anthropic>=0.1.0` |
| `langgraph` | `langchain-core>=0.2`, `langgraph>=0.1.0` |
| `crewai` | `crewai>=0.35.0` |
| `bedrock` | `boto3>=1.34.0` |
| `tavily` | `tavily-python>=0.3.0` |
| `llamaindex` | `llama-index-core>=0.10.0` |
| `dev` | `pytest>=7.0`, `pytest-asyncio>=0.23`, `respx`, `python-dotenv` |

**External access you need:**

- A **MetricAI API key** (format used in examples: `metricai_...`). Obtain it from your MetricAI dashboard at [https://metricai.co.in](https://metricai.co.in).
- Network reachability to the MetricAI proxy (default base URL: `https://proxy.metricai.co.in`).
- For **BYOK** (`MetricAIConfig.mode == "byok"`), provider API keys you pass via `provider_key`, `llm_keys`, environment variables, or proxy headers (OpenAI, Anthropic, Gemini, Grok, etc.), or managed keys if your MetricAI deployment provides them.
- For **AWS Bedrock** wrapping, AWS credentials and permissions for `bedrock-runtime` (standard boto3 credential chain).
- For **Tavily**, a Tavily API key as required by `tavily-python`.

---

## Section 3 — Installation

```bash
# install_metricai.sh
pip install metricai
```

With optional integrations:

```bash
# install_metricai_extras.sh
pip install "metricai[langchain,openai]"
```

**API key via environment variable** (read automatically by `MetricAI` and `metricai.runtime.init` when `api_key` is omitted):

```bash
# set_metricai_api_key.sh
set METRICAI_API_KEY=metricai_your_key_here
```

**API key via constructor** (direct config):

```python
# config_api_key.py
from metricai import MetricAI

client = MetricAI(api_key="metricai_your_key_here")
```

---

## Section 4 — Integration Patterns

### Pattern A — One-line startup instrumentation (recommended for existing apps)

For existing apps with many `OpenAI()` / `Anthropic()` call sites, call `init()` once at startup with `auto_instrument=True`. No per-file changes.

```python
# app_startup.py
import os
import metricai

metricai.init(
    api_key=os.environ["METRICAI_API_KEY"],
    default_agent_id="my-app",
    validate=True,
    auto_instrument=True,
    openai_api_key=os.environ.get("OPENAI_API_KEY"),
)

# Everywhere else — unchanged
from openai import OpenAI
client = OpenAI()
```

### Pattern B — SDK factory (recommended for new apps)

Use `MetricAI(...).openai_sdk()` when you construct provider clients explicitly. Returns the official provider SDK with proxy `base_url` and attribution headers pre-set.

```python
# openai_sdk_factory.py
import os
from metricai import MetricAI

client = MetricAI(
    api_key=os.environ["METRICAI_API_KEY"],
    llm_keys={"openai": os.environ["OPENAI_API_KEY"]},
)
sdk = client.openai_sdk(agent_id="contract-agent", user_id="user-42")
response = sdk.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello"}],
)
```

`METRICAI_API_KEY` is read automatically when `api_key` is omitted. `METRICAI_PROXY_URL` can override the proxy host and defaults to `https://proxy.metricai.co.in`. Pass provider keys via `llm_keys={...}` (multi-provider) or environment variables (`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`).

### Pattern C — Manual proxy headers (advanced)

Set `base_url` to the MetricAI proxy route and pass BYOK + attribution headers. Use `api_key=` with your MetricAI key for all official SDKs (OpenAI, Anthropic, Gemini, Grok). Anthropic sends the MetricAI key as `X-Api-Key`; OpenAI-shaped SDKs send `Authorization: Bearer`. Or use `client.provider_sdk("gemini", agent_id=..., user_id=...)`.

```python
# openai_zero_learning.py
import os
from openai import OpenAI

client = OpenAI(
    api_key=os.environ["METRICAI_API_KEY"],
    base_url="https://proxy.metricai.co.in/v1/proxy/openai",
    default_headers={
        "X-OpenAI-API-Key": os.environ["OPENAI_API_KEY"].strip(),
        "X-Agent-ID": "contract-agent",
        "X-User-ID": "user-42",
    },
)

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello"}],
)
```

Provider proxy routes stay stable: OpenAI uses `/v1/proxy/openai`, Anthropic uses `/v1/proxy/claude`, and Gemini uses `/v1/proxy/gemini` through the OpenAI-compatible client shape.

### Pattern D — Per-Request Attribution (advanced, web apps)

For web apps and workers where `user_id` or `agent_id` changes per request, instantiate the provider client once and pass request context with `extra_headers`. Provider SDKs merge `extra_headers` over `default_headers`, so per-request values win.

```python
# dynamic_attribution.py
import os
from openai import OpenAI

base_client = OpenAI(
    api_key=os.environ["METRICAI_API_KEY"],
    base_url="https://proxy.metricai.co.in/v1/proxy/openai",
    default_headers={
        "X-OpenAI-API-Key": os.environ["OPENAI_API_KEY"].strip(),
    },
)

def call_llm(prompt: str, user_id: str, agent_id: str):
    return base_client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
        extra_headers={
            "X-Agent-ID": agent_id,
            "X-User-ID": user_id,
        },
    )
```

### Production Rollout

Day 1: Add `base_url` only. Verify proxy calls still succeed.

Day 3: Add `X-Agent-ID` to each LLM call so dashboard costs group by feature or agent.

Day 5: Add `X-User-ID` from your auth context for end-user attribution.

Day 7: Set budget caps per agent in the dashboard or with `X-Budget-Cap-INR`.

### Header Contract

MetricAI authenticates via `Authorization: Bearer <METRICAI_API_KEY>` (sent automatically by the OpenAI SDK when you pass `api_key=`). `X-MetricAI-API-Key` is a transitional alias. `X-MetricAI-Key` is accepted as a legacy server fallback only.

**Anthropic SDK:** Use `api_key=os.environ["METRICAI_API_KEY"]` (same as OpenAI/Gemini). The SDK sends it as `X-Api-Key`, which the proxy accepts for MetricAI auth. `auth_token=` still works (`Authorization: Bearer`). Provider secrets stay in `X-Claude-API-Key`, never in `api_key`/`auth_token`.

`X-Agent-ID` is recommended as a string agent or feature name. If missing, MetricAI attributes the call to `untagged` and does not fail the request.

`X-User-ID` is recommended as a string end-user id from your auth system. If missing, MetricAI attributes the call to `anonymous` and does not fail the request.

Optional headers are: `X-Session-ID` string conversation id, `X-Environment` string such as `production` or `staging`, `X-Billing-Mode` enum `usage | outcome | hybrid`, `X-Budget-Cap-INR` float daily hard cap, `X-Idempotency-Key` string retry dedupe key, `X-Outcome-Rule-ID` string outcome rule id, `X-Outcome-Threshold` float `0-1`, `X-Graph-ID` string LangGraph id, `X-Node-ID` string LangGraph node id, `X-Crew-ID` string CrewAI id, and `X-Task-ID` string CrewAI task id.

### Fail-Open Behavior

MetricAI proxy is fail-open by design. If the MetricAI proxy is unreachable or returns a `5xx`, the hosted proxy forwards the request directly to the LLM provider so your application does not see a MetricAI outage. MetricAI records the failed metering event for reconciliation and marks the billing data for that call as `unmetered`.

---

## Section 5 — Initialization and Configuration

### `metricai.runtime.init`

| Parameter | Type | Required | Default | Purpose |
|-----------|------|----------|---------|---------|
| `api_key` | `str` | Yes | — | MetricAI API key. |
| `default_agent_id` | `str` | No | `"default-agent"` | Default agent id passed into `MetricAI` / config. |
| `backend_endpoint` | `str` | No | `DEFAULT_PROXY_BASE_URL` (`https://proxy.metricai.co.in`) | MetricAI API/proxy base URL (no trailing path). |
| `environment` | `Optional[str]` | No | `None` | If set, passed to `MetricAI` as `environment_tag` (deploy/stage label in telemetry extras), **not** the `production` / `sandbox` config field. |
| `active_providers` | `Optional[List[str]]` | No | `None` | Subset of provider ids for hook registration (`bedrock`, `tavily`, etc.); `None` activates all registered hooks. |
| `validate` | `bool` | No | `False` | If `True`, calls `client.validate_api_key()` (`GET /v1/auth/ping`) during init. |
| `auto_instrument` | `bool` | No | `False` | If `True`, patches provider SDKs at startup via `instrument()`. |
| `**client_kwargs` | Any | No | — | Forwarded to `MetricAI` (e.g. `llm_keys`, `mode`, `telemetry_timeout_seconds`). |

Returns a `MetricAI` instance and stores it for `get_metricai()`.

### `MetricAI` constructor

| Parameter | Type | Required | Default | Purpose |
|-----------|------|----------|---------|---------|
| `api_key` | `Optional[str]` | Conditionally | `None` | MetricAI key; if omitted, uses `METRICAI_API_KEY` or `config.api_key`. Required unless `config` supplies a key. |
| `base_url` | `Optional[str]` | No | `METRICAI_PROXY_URL` or `https://proxy.metricai.co.in` | Proxy/API base URL. |
| `timeout` | `int` | No | `60` | HTTP timeout (seconds) for `httpx` calls in `get`/`post` and proxy usage. |
| `provider` | `"openai" \| "anthropic" \| "gemini" \| "bedrock"` | No | `"openai"` | Provider used by the `.client` factory. |
| `provider_key` | `Optional[str]` | No | Provider env var | Single-provider shorthand when only one BYOK key is needed on `.client`. |
| `agent_id` | `Optional[str]` | No | `"untagged"` | Constructor-level attribution used by `.client` and factory aliases. |
| `user_id` | `Optional[str]` | No | `"anonymous"` | Constructor-level end-user attribution used by `.client` and factory aliases. |
| `config` | `Optional[MetricAIConfig]` | No | `None` | Full config object; merged with constructor args. |
| `telemetry_events_path` | `str` | No | `"/v1/sdk/events"` | Path appended to base URL for telemetry unless `telemetry_base_url` is set. |
| `telemetry_base_url` | `Optional[str]` | No | `None` | Absolute base for telemetry only; if unset, `{base_url}{telemetry_events_path}`. |
| `telemetry_timeout_seconds` | `float` | No | `3.0` | Timeout for telemetry POSTs. |
| `max_retries` | `int` | No | `2` | Retry count for telemetry (see Section 12). |
| `enable_buffer` | `bool` | No | `True` | Buffer failed telemetry (max 100 events) for retry. |
| `raise_on_error` | `bool` | No | `False` | If `True`, telemetry/client errors can raise instead of fail-open. |
| `extra_proxy_headers` | `Optional[Dict[str, str]]` | No | `None` | Extra headers merged into proxy requests; BYOK headers from `llm_keys` are merged in. |
| `mode` | `Literal["byok","managed"]` | No | `"byok"` | Key mode forwarded in headers (`X-Key-Mode`). |
| `llm_keys` | `Optional[Dict[str, str]]` | No | `None` | Primary multi-provider BYOK keys mapped to `X-OpenAI-API-Key`, `X-Claude-API-Key`, etc. |
| `default_billing_mode` | `Literal["usage","outcome","hybrid"]` | No | `"hybrid"` | Default `X-Billing-Mode` when not overridden per call. |
| `default_budget_cap_inr` | `Optional[float]` | No | `None` | Default budget cap header value when not overridden. |
| `fail_open` | `bool` | No | `True` | Stored on config (semantic flag for integrations). |
| `environment` | `Literal["production","sandbox"]` | No | `"production"` | Config environment field. |
| `default_agent_id` | `str` | No | `"default-agent"` | Used when integrations omit agent id (e.g. Bedrock/Tavily attribution). |
| `environment_tag` | `Optional[str]` | No | `None` | Added to extras when sending `track_billing_event` / `BillingEvent`. |
| `active_providers` | `Optional[Tuple[str, ...]]` | No | `None` | Same as `init`: which provider hooks to run. |

If optional provider activation fails, the client logs a warning (including exception info) and continues.

### Full initialization example

```python
# full_init_example.py
import os
from metricai import MetricAI
from metricai.config import MetricAIConfig

cfg = MetricAIConfig(
    api_key=os.environ["METRICAI_API_KEY"],
    mode="byok",
    proxy_base_url="https://proxy.metricai.co.in",
    environment="production",
    default_billing_mode="hybrid",
    default_budget_cap_inr=500.0,
    fail_open=True,
    default_agent_id="billing-demo",
    environment_tag="staging",
    active_providers=("bedrock", "tavily"),
)

client = MetricAI(
    config=cfg,
    llm_keys={"openai": os.environ["OPENAI_API_KEY"]},
    agent_id="billing-demo",
    user_id="user-42",
    timeout=90,
    telemetry_events_path="/v1/sdk/events",
    telemetry_timeout_seconds=5.0,
    max_retries=3,
    enable_buffer=True,
    raise_on_error=False,
)
```

Use `llm_keys={...}` for multi-provider BYOK on one `MetricAI` instance. Use `provider_key=` only when you need a single-provider shorthand for the legacy `.client` factory.

---

## Section 6 — Provider Integrations

### OpenAI

The integration routes the official `openai.OpenAI` client through MetricAI: `base_url` becomes `{proxy_base_url}/v1/proxy/openai`, `api_key` is your MetricAI key (Bearer auth), and default headers include `X-Agent-ID`, `X-User-ID`, `X-Session-ID`, `X-Billing-Mode`, `X-Idempotency-Key`, and optional budget/outcome headers from `MetricAI.headers()`. `X-MetricAI-API-Key` is a transitional alias; the server still accepts legacy `X-MetricAI-Key`.

**Installation:** `pip install "metricai[openai]"` (or `openai` alone).

**Before (direct OpenAI):**

```python
# before_openai.py
import os
from openai import OpenAI
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
client.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": "Hi"}])
```

**After (MetricAI — zero-learning proxy):**

```python
# after_openai_metricai.py
import os
from openai import OpenAI

client = OpenAI(
    api_key=os.environ["METRICAI_API_KEY"],
    base_url="https://proxy.metricai.co.in/v1/proxy/openai",
    default_headers={
        "X-OpenAI-API-Key": os.environ["OPENAI_API_KEY"].strip(),
        "X-Agent-ID": "svc-booking",
        "X-User-ID": "user-42",
    },
)
client.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": "Hi"}])
```

| Captured | Notes |
|----------|--------|
| Model id | From request (`model`). |
| Tokens | Usage from provider response (metered server-side on proxy path). |
| Latency | Server-side. |
| Cost (INR) | Platform billing from proxied usage. |
| Agent / user / session | From `X-Agent-ID`, `X-User-ID`, `X-Session-ID`. |
| Idempotency | `X-MetricAI-Idempotency-Key` and `X-Idempotency-Key` (same value). |

---

### Anthropic Claude

Same pattern with `anthropic.Anthropic`. `base_url` is `{proxy_base_url}/v1/proxy/claude`. If you prefer the SDK factory, use `client.anthropic_sdk(agent_id=..., user_id=...)`.

**Installation:** `pip install "metricai[anthropic]"`.

```python
# claude_metricai.py
import os
from anthropic import Anthropic

ac = Anthropic(
    api_key=os.environ["METRICAI_API_KEY"].strip(),
    base_url="https://proxy.metricai.co.in/v1/proxy/claude",
    default_headers={
        "X-Claude-API-Key": os.environ["ANTHROPIC_API_KEY"].strip(),
        "X-Agent-ID": "contract-agent",
        "X-User-ID": "user-42",
    },
)
ac.messages.create(
    model="claude-3-5-sonnet-20241022",
    max_tokens=120,
    messages=[{"role": "user", "content": "Hi, how are you?"}],
)
```

| Captured | Notes |
|----------|--------|
| Model | Request model id. |
| Tokens / cost / latency | Proxy metering. |
| Attribution | Same header family as OpenAI. |

---

### Google Gemini

Gemini uses the **OpenAI-compatible** client with `base_url` `{proxy_base_url}/v1/proxy/gemini`.

**Installation:** `pip install "metricai[openai]"`.

```python
# gemini_metricai.py
import os
from openai import OpenAI

g = OpenAI(
    api_key=os.environ["METRICAI_API_KEY"],
    base_url="https://proxy.metricai.co.in/v1/proxy/gemini",
    default_headers={
        "X-Gemini-API-Key": os.environ["GEMINI_API_KEY"].strip(),
        "X-Agent-ID": "contract-agent",
        "X-User-ID": "user-42",
    },
)
g.chat.completions.create(
    model="gemini-1.5-flash",
    messages=[{"role": "user", "content": "Hi, how are you?"}],
)
```

| Captured | Notes |
|----------|--------|
| Model / tokens / cost / latency | Same as other LLM proxy routes. |

---

### Grok

`grok_sdk()` uses `proxy_url_for("groq")`, which maps to the **`grok` proxy segment** (`/v1/proxy/grok`). The integration file is a no-op hook; routing is entirely via `OpenAI` + proxy URL.

**Installation:** `pip install "metricai[openai]"`.

```python
# grok_metricai.py
import os
from openai import OpenAI

gk = OpenAI(
    api_key=os.environ["METRICAI_API_KEY"],
    base_url="https://proxy.metricai.co.in/v1/proxy/grok",
    default_headers={
        "X-Grok-API-Key": os.environ["GROK_API_KEY"].strip(),
        "X-Agent-ID": "contract-agent",
        "X-User-ID": "user-42",
    },
)
gk.chat.completions.create(
    model="grok-2-latest",
    messages=[{"role": "user", "content": "Hi, how are you?"}],
)
```

| Captured | Notes |
|----------|--------|
| Model / tokens / cost / latency | Proxy path `grok`. |

---

### AWS Bedrock

This path **wraps boto3** `bedrock-runtime` clients created after MetricAI initializes: `invoke_model`, `invoke_model_with_response_stream`, `converse`, and `converse_stream` emit a `BillingEvent` via `track_billing_event`. Activation patches `boto3.client` only when the `bedrock` hook runs and boto3 imports succeed.

**Installation:** `pip install "metricai[bedrock]"`.

**Pricing note:** `metricai/data/bedrock_pricing.json` lists USD **per 1K tokens** (`input_per_1k_usd`, `output_per_1k_usd`) keyed by full Bedrock model id (or prefix before `:`). `_price_for_model` attaches `pricing_input_per_1k_usd` / `pricing_output_per_1k_usd` to the event **`extra`** dict. If the model id is missing, those fields are `None`; the SDK still emits tokens and latency. **Adding a custom model:** extend `bedrock_pricing.json` under `models` with your model id and rates.

```python
# bedrock_invoke.py
import os
import boto3
from metricai import MetricAI
from metricai.context import attribution_scope

MetricAI(api_key=os.environ["METRICAI_API_KEY"], active_providers=("bedrock",))
# Credentials: env AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY / AWS_REGION or ~/.aws/credentials
runtime = boto3.client("bedrock-runtime", region_name="ap-south-1")
with attribution_scope(agent_id="etl-agent", user_id="user-bedrock-1", session_id="sess-001"):
    body = '{"messages":[{"role":"user","content":[{"text":"Say hi in 3 words."}]}],"max_tokens":64,"anthropic_version":"bedrock-2023-05-31"}'
    resp = runtime.invoke_model(
        modelId="anthropic.claude-3-haiku-20240307-v1:0",
        body=body,
        contentType="application/json",
        accept="application/json",
    )
    _ = resp["body"].read()
```

```python
# bedrock_stream.py
import os
import boto3
from metricai import MetricAI
from metricai.context import attribution_scope

MetricAI(api_key=os.environ["METRICAI_API_KEY"], active_providers=("bedrock",))
runtime = boto3.client("bedrock-runtime", region_name="ap-south-1")
with attribution_scope(agent_id="stream-agent", user_id="user-2", session_id="sess-stream"):
    out = runtime.invoke_model_with_response_stream(
        modelId="anthropic.claude-3-haiku-20240307-v1:0",
        body=b'{"messages":[{"role":"user","content":[{"text":"Count to 3"}]}],"max_tokens":50,"anthropic_version":"bedrock-2023-05-31"}',
        contentType="application/json",
    )
    for ev in out["body"]:
        pass
```

| Captured | Notes |
|----------|--------|
| `model_name` | Bedrock model id. |
| `input_tokens` / `output_tokens` | Parsed from response JSON where available. |
| `latency_ms` | Wall time for the call. |
| `gateway_provider` | `"aws-bedrock"`. |
| `extra` | Includes `bedrock_model_id`, pricing fields, `api` name (`invoke_model`, etc.). |

---

### Tavily Search

Wraps `tavily.TavilyClient` instances at construction time: `search` and `get_search_context` emit `BillingEvent` with `cost_unit="api_call"`. Pricing comes from `metricai/data/tavily_pricing.json` (`basic_search_usd`, `advanced_search_usd`, `get_search_context_usd`).

**Installation:** `pip install "metricai[tavily]"`.

```python
# tavily_basic_advanced.py
import os
from tavily import TavilyClient
from metricai import MetricAI
from metricai.context import named_session

MetricAI(api_key=os.environ["METRICAI_API_KEY"], active_providers=("tavily",))
with named_session("research-run", agent_id="analyst", user_id="user-5") as sctx:
    tv = TavilyClient(api_key=os.environ["TAVILY_API_KEY"])
    tv.search("MetricAI billing India", max_results=5)
    tv.search("deep dive", search_depth="advanced", max_results=10)
```

`named_session` sets contextvars so `get_attribution()` inside the Tavily wrapper resolves `agent_id`, `user_id`, and `session_id` for the billing event.

**LangChain:** If you construct `TavilyClient` while a `named_session` / `attribution_scope` is active (including inside LangChain tool execution), the same attribution applies. There is no separate LangChain-specific Tavily hook in the SDK.

| Captured | Notes |
|----------|--------|
| `latency_ms` | Round-trip time. |
| `tool_call_count` | `1` per call. |
| `extra` | `tavily_search_type`, `query_preview`, `max_results`, `estimated_cost_usd` (from JSON rates). |

---

## Section 7 — Sessions

In MetricAI, a **session** is a stable identifier (`session_id`) that groups related usage for attribution and dashboards. There is no top-level `metricai.session` function; use `MetricAI.session()`, `MetricAI.metricai_session()`, or `metricai.context.named_session` as below.

**Legacy HTTP proxy session (`SessionContext`):** groups `MetricAIProxy.complete` / `stream` calls and completes the server session when the block exits.

```python
# session_legacy_proxy.py
import os
from metricai import MetricAI

client = MetricAI(
    api_key=os.environ["METRICAI_API_KEY"],
    llm_keys={"openai": os.environ["OPENAI_API_KEY"]},
)
with client.session(agent_id="legacy-agent", user_id="user-z") as sctx:
    client.openai(session=sctx).complete(model="gpt-4o-mini", messages=[{"role": "user", "content": "Ping."}], max_tokens=16)
```

### Pattern 1 — Context manager (`MetricAISession`)

```python
# session_context_manager.py
import os
from metricai import MetricAI

client = MetricAI(api_key=os.environ["METRICAI_API_KEY"])
with client.metricai_session(agent_id="agent-a", user_id="user-1", session_id=None) as s:
    s.track(provider="openai", model="gpt-4o-mini", input_tokens=120, output_tokens=40, cost_inr=0.85)
```

All `track()` calls inside the block get the same `session_id`, `turn_number` increments, and on exit the SDK sends `event_type=session_close` with aggregates (`total_turns`, `total_input_tokens`, `total_output_tokens`, `total_cost_inr` if derivable, `cumulative_context_tokens`, `session_duration_ms`, `status`, `session_tool_summary`). It also calls `complete_session(session_id)` on the REST API (errors swallowed). **Dashboard (prose):** you see one closed session with those aggregate fields and linkage to turns if the backend stores them.

### Pattern 2 — Manual completion (`MetricAIProxyClientSession`)

Use this when you use native OpenAI/Anthropic SDKs with a shared session id and want explicit control over when the server session is completed.

```python
# session_manual_complete.py
import os
from metricai import MetricAI

client = MetricAI(
    api_key=os.environ["METRICAI_API_KEY"],
    llm_keys={"openai": os.environ["OPENAI_API_KEY"]},
)
ps = client.proxy_sdk_session(agent_id="agent-a", user_id="user-1", complete_on_exit=False)
ps.__enter__()
try:
    oai = ps.openai_sdk()
    oai.chat.completions.create(model="gpt-4o-mini", messages=[{"role": "user", "content": "Hello"}])
finally:
    client.complete_session(ps.session_id)
    ps.__exit__(None, None, None)
```

If you use `complete_on_exit=True` (default), calling `complete_session` yourself is redundant.

### Pattern 3 — Named session across tasks (`named_session`)

```python
# session_named_async.py
import os
import asyncio
from metricai import MetricAI
from metricai.context import named_session

client = MetricAI(api_key=os.environ["METRICAI_API_KEY"])

async def worker():
    with named_session("job-42", agent_id="worker", user_id="user-9") as ctx:
        await asyncio.sleep(0)
        client.track(provider="openai", model="gpt-4o-mini", input_tokens=50, output_tokens=10, session_id=ctx.session_id, agent_id="worker", user_id="user-9")

asyncio.run(worker())
```

`ctx.session_name` is `"job-42"`; `X-Session-ID` for HTTP would be `ctx.session_id`. **Dashboard:** events include the same `session_id` for correlation across threads/tasks when you pass it to `track()` or use wrappers that read `get_attribution()`.

---

## Section 8 — Framework Integrations

### LangChain

**Callback + chain:** `MetricAICallbackHandler` mirrors LLM end/error and tool start to `client.track()`. `MetricAIChat` returns a LangChain `BaseChatModel` pointing at the MetricAI proxy.

```python
# langchain_chain_complete.py
import os
from langchain_core.messages import HumanMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from metricai import MetricAI
from metricai.langchain import MetricAIChat, MetricAICallbackHandler

client = MetricAI()
handler = MetricAICallbackHandler(client=client, agent_id="lc-chain", user_id="user-88", provider="openai", model_fallback="gpt-4o-mini")
llm = MetricAIChat(
    provider="openai",
    provider_key=os.environ["OPENAI_API_KEY"],
    model="gpt-4o-mini",
    agent_id="lc-chain",
    user_id="user-88",
)
prompt = ChatPromptTemplate.from_messages([("human", "{q}")])
chain = prompt | llm | StrOutputParser()
out = chain.invoke({"q": "What is 2+2? One word."}, config={"callbacks": [handler]})
print(out)
```

The old `metricai.integrations.langchain.MetricAILLM` import remains available as a compatibility alias, but new code should import `MetricAIChat` from `metricai.langchain`.

**Agent-style multi-step:** The repo does not ship a full ReAct/AgentExecutor example in `examples/`; use `MetricAIAgent` (workflow, OpenAI-only) or LangGraph below. **Tavily in LangChain:** ensure `named_session` or `attribution_scope` is active when the Tavily client runs so `session_id` is set (see Section 6).

**Alternative chat model:** `metricai.integrations.langchain_chat.ChatMetricAI` wraps `MetricAIProxy` directly (see `examples/langchain_metricai_sample.py`).

### LlamaIndex

`MetricAILlamaIndexHandler` implements LlamaIndex `BaseCallbackHandler` and sends `track()` on LLM events.

```python
# llamaindex_complete.py
import os
from llama_index.core import Document, VectorStoreIndex, Settings
from metricai import MetricAI
from metricai.integrations.llamaindex import MetricAILlamaIndexHandler, attach_to_settings

client = MetricAI(api_key=os.environ["METRICAI_API_KEY"])
handler = MetricAILlamaIndexHandler(client, agent_id="idx-1", user_id="user-2", provider="openai", model_fallback="gpt-4o-mini")
attach_to_settings(Settings, handler)
index = VectorStoreIndex.from_documents([Document.example()])
qe = index.as_query_engine()
print(str(qe.query("What is in the document?")))
```

Requires `pip install "metricai[llamaindex]"` and a working LlamaIndex LLM configuration compatible with your environment.

### CrewAI

`MetricAICrew` injects `MetricAICrewLLM` for agents missing an `llm`. **`cost_summary()` is a stub** — it returns an empty map until a per-crew billing API exists.

```python
# crewai_complete.py
import os
from crewai import Agent, Task
from metricai import MetricAI
from metricai.integrations.crewai import MetricAICrew

client = MetricAI(
    api_key=os.environ["METRICAI_API_KEY"],
    llm_keys={"openai": os.environ["OPENAI_API_KEY"]},
)
researcher = Agent(role="Researcher", goal="Summarize", backstory="Analyst")
writer = Agent(role="Writer", goal="One line", backstory="Writer")
t1 = Task(description="Topic: AI billing", agent=researcher, expected_output="Bullets")
t2 = Task(description="One sentence", agent=writer, expected_output="One line")
crew = MetricAICrew(client=client, crew_id="c1", user_id="user-101", agents=[researcher, writer], tasks=[t1, t2], provider="openai", model="gpt-4o-mini")
print(crew.kickoff())
print(crew.cost_summary())
```

Multi-agent attribution uses **distinct `agent_id`** per CrewAI agent (derived from `role`) in `MetricAICrewLLM` headers.

### AutoGen

The module **does not patch AutoGen**. It exposes `openai_client_for_autogen()` (= `openai_sdk`) and `llm_config_stub()`. You wire the returned client into your AutoGen agents yourself.

```python
# autogen_bridge.py
import os
from metricai import MetricAI
from metricai.integrations.autogen import openai_client_for_autogen

client = MetricAI(
    api_key=os.environ["METRICAI_API_KEY"],
    llm_keys={"openai": os.environ["OPENAI_API_KEY"]},
)
oai = openai_client_for_autogen(client, agent_id="autogen-1", user_id="user-3", session_id=None)
# Pass oai into your AssistantAgent / llm_config per AutoGen docs.
```

### LangGraph

For simple node-level attribution, use the decorator import path:

```python
# langgraph_metricai_node.py
from metricai.langgraph import metricai_node

@metricai_node(agent_id="researcher", metricai_key="metricai_your_key_here")
def researcher_node(state):
    # state["user_id"] is read automatically for X-User-ID attribution.
    # state["metricai_headers"] is available if you pass per-request headers manually.
    return llm.invoke(state["messages"])
```

`instrument_graph` wraps a compiled graph’s `invoke` / `ainvoke` to append `MetricAIGraphTracer` to callbacks; `MetricAIGraphTracer` aggregates per chain node and calls `track()` on LLM ends.

```python
# langgraph_complete.py
import os
from typing_extensions import TypedDict
from langgraph.graph import END, StateGraph
from metricai import MetricAI
from metricai.integrations.langgraph import instrument_graph

class State(TypedDict):
    task: str
    result: str

def node_echo(state: State) -> dict:
    return {"result": f"done: {state['task']}"}

client = MetricAI(api_key=os.environ["METRICAI_API_KEY"])
g = StateGraph(State)
g.add_node("a", node_echo)
g.set_entry_point("a")
g.add_edge("a", END)
app = g.compile()
wrapped, tracer = instrument_graph(app, client=client, graph_id="g1", user_id="u1", provider="openai")
print(wrapped.invoke({"task": "hello"}))
print(tracer.summary())
```

---

## Section 9 — Outcome-Based Billing

**Usage billing:** Charges derived from measured tokens/usage (typical proxy path). **Outcome billing:** You send an `outcome` object on `track()` / `atrack()`; `compute_billable_inr` sets `billable_amount_inr` from `charge_on_success_inr` or `charge_on_failure_inr` per `success`. **Hybrid:** Default header mode `hybrid` means both usage and outcome rules can apply per product configuration on the server — the SDK only forwards `X-Billing-Mode` and payload fields.

```python
# billing_mode_usage.py
import os
from metricai import MetricAI

client = MetricAI(api_key=os.environ["METRICAI_API_KEY"])
client.track(provider="openai", model="gpt-4o-mini", input_tokens=100, output_tokens=50)
```

```python
# billing_mode_outcome.py
import os
from metricai import MetricAI

client = MetricAI(api_key=os.environ["METRICAI_API_KEY"])
client.track(provider="openai", model="gpt-4o-mini", outcome={"success": True, "outcome_type": "doc_summary", "charge_on_success_inr": 15.0})
```

```python
# billing_mode_hybrid_config.py
from metricai import MetricAI
import os
client = MetricAI(api_key=os.environ["METRICAI_API_KEY"], default_billing_mode="hybrid")
```

**End-to-end outcome example (document summarization):**

```python
# outcome_doc_summary.py
import os
from metricai import MetricAI, timed_call

client = MetricAI(api_key=os.environ["METRICAI_API_KEY"])

def summarize_doc(text: str) -> tuple[bool, str]:
    # Your LLM call (proxy or other); return success if output is non-empty
    ok = len(text.strip()) > 0
    return ok, "Summary ready" if ok else ""

with timed_call() as t:
    success, _ = summarize_doc("Chapter one about billing.")
client.track(
    provider="openai",
    model="gpt-4o-mini",
    outcome={"success": success, "outcome_type": "doc_summary", "charge_on_success_inr": 12.0, "charge_on_failure_inr": 0.0},
    latency_ms=t.elapsed_ms,
    agent_id="summarizer",
    user_id="user-docs-1",
)
```

On success, `billable_amount_inr` in the payload uses `charge_on_success_inr` (see `compute_billable_inr`). On failure, `charge_on_failure_inr` applies when provided; otherwise billable can be `0.0`. Timeouts or exceptions in your code should result in `success=False` in your own `track()` call if you want failure pricing — the SDK does not auto-detect agent failure without you passing `outcome`.

**Simulate before commit:**

```python
# outcome_simulate.py
import os
from metricai import MetricAI

client = MetricAI(api_key=os.environ["METRICAI_API_KEY"])
sim = client.track(simulate=True, provider="openai", model="gpt-4o-mini", outcome={"success": True, "charge_on_success_inr": 25.0})
print(sim["would_charge_inr"], sim["outcome_matched"])
```

`simulate=True` adds `"simulated": true` to the body, still POSTs the event, and returns `SimulationResult` with `would_charge_inr` and `outcome_matched`.

---

## Section 10 — Budget Caps

**Per-request / header caps:** Pass `budget_cap_inr` into `MetricAI(...)`, `MetricAI.headers()`, `.client` factory setup, or `metricai_session` via `MetricAIProxyClientSession`. Headers include `X-Budget-Cap-INR` when set.

**Session hard cap:** `MetricAISession(..., max_budget_inr=100.0)` accumulates cost from `cost_inr` on `track()` or from outcome `compute_billable_inr`. When cumulative spend exceeds the cap, it sends `session_close`, calls `complete_session`, sets status `budget_exceeded`, and raises `MetricAIBudgetExceeded`.

**Soft threshold:** `soft_budget_inr` triggers `event_type=budget_warning` telemetry and optional `on_budget_warning(spent_inr, soft_budget_inr, session_id)` once.

**Different agents:** Use different `MetricAISession` instances or different `agent_id` / `user_id` so caps are not shared.

```python
# budget_session.py
import os
from metricai import MetricAI

client = MetricAI(api_key=os.environ["METRICAI_API_KEY"])

def warn(spent: float, soft: float, sid: str) -> None:
    print(f"warn spent={spent} soft={soft} sid={sid}")

with client.metricai_session(agent_id="a1", user_id="u1", max_budget_inr=50.0, soft_budget_inr=40.0, on_budget_warning=warn) as s:
    s.track(provider="openai", model="gpt-4o-mini", cost_inr=45.0)
```

### Conversation token governance (v1)

Separate from INR caps: :class:`~metricai.workflow.agent.MetricAIAgent` can enforce **conversation-level token budgets**, **cumulative tool-call limits**, **per-tool-result compaction**, and **recent-user-turn trimming** when any of these constructor kwargs is set: ``max_conversation_tokens``, ``max_tool_calls``, ``max_single_tool_result_tokens``, ``keep_recent_turns`` (optional ``tool_result_preserve_keys`` for JSON-shaped tool outputs). When unset, the agent behaves as before (no ``run_report`` on :class:`~metricai.workflow.agent.AgentResponse`).

- **Preflight:** Before each completion, estimated prompt size (messages + tools) is compared to ``max_conversation_tokens``; if the next call would exceed the cap, the run stops with ``termination_reason=insufficient_remaining_budget_for_request`` (no provider call).
- **Post-call:** After each completion, normalized usage is accumulated; if cumulative totals exceed the cap, ``termination_reason=conversation_token_budget_exceeded``.
- **Tool batching:** If ``len(tool_calls) + tool_calls_used > max_tool_calls``, the run stops with ``tool_call_limit_exceeded`` before executing tools.
- **Primitives:** ``metricai.conversation_budget.ConversationBudgetRuntime``, ``metricai.usage_normalizer.normalize_llm_usage``, ``metricai.message_context.trim_messages_keep_recent_user_turns``, ``metricai.tool_output_policy.compact_tool_result`` (also re-exported from ``metricai``).

Structured output: ``AgentResponse.run_report`` (``AgentRunReport`` in ``metricai.types``) includes ``termination_reason``, ``per_step_usage``, ``aggregated_usage``, ``budget_status``, and ``tool_trace``.

---

## Section 11 — Billing Event Schema Reference

Canonical type: `metricai.billing_event.BillingEvent` (`BILLING_EVENT_SCHEMA_VERSION` is `"1.0"`).

| Field | Type | Required | Description | Populated by (SDK) |
|-------|------|----------|-------------|---------------------|
| `provider_name` | `str` | Yes | Provider slug, e.g. `aws-bedrock`, `tavily`. | Bedrock, Tavily wrappers; manual events. |
| `model_name` | `Optional[str]` | Yes* | `*` required field but value may be `None` for tools. | Bedrock: model id; Tavily: `None`. |
| `provider_category` | `llm` \| `model_gateway` \| `tool` | Yes | High-level category. | Bedrock: `model_gateway`; Tavily: `tool`. |
| `cost_unit` | `token` \| `token_gateway` \| `api_call` | Yes | How charging is interpreted. | Bedrock: `token_gateway`; Tavily: `api_call`. |
| `latency_ms` | `int` | Yes | Round-trip latency. | Wrappers. |
| `agent_id` | `Optional[str]` | Yes | May be `None` in edge cases; usually from attribution or `default_agent_id`. | Wrappers. |
| `user_id` | `Optional[str]` | Yes | End user. | Wrappers. |
| `session_id` | `Optional[str]` | Yes | Session correlation. | Wrappers when attribution set. |
| `request_timestamp_iso` | `str` | Yes | UTC ISO timestamp. | `BillingEvent.now_iso()`. |
| `input_tokens` | `Optional[int]` | No | Input tokens if known. | Bedrock when parsed. |
| `output_tokens` | `Optional[int]` | No | Output tokens if known. | Bedrock when parsed. |
| `schema_version` | `str` | No (default) | Schema version string. | Default `1.0`. |
| `gateway_provider` | `Optional[str]` | No | Gateway name. | Bedrock: `aws-bedrock`. |
| `tool_call_count` | `Optional[int]` | No | Number of tool calls. | Tavily: `1`. |
| `raw_response` | `Any` | No | Optional raw object. | Not sent in telemetry unless `include_raw_response=True` in `to_telemetry_dict`. |
| `extra` | `Dict[str, Any]` | No | Free-form metadata. | Bedrock/Tavily attach pricing and API name; `environment_tag` merged at client for `track_billing_event`. |

LLM traffic through **HTTP proxy** is generally **not** emitted as `BillingEvent` in the SDK — it is metered on the server. You can still call `track()` or `track_billing_event()` manually for custom pipelines.

---

## Section 12 — Error Handling and Fail-Open Behaviour

**Principle:** Telemetry uses `TelemetryTransport`: on network failure or after retries, it logs a warning and returns `None` unless `raise_on_error=True`. Your LLM calls through the proxy still execute; you may lose telemetry for that event.

**Exceptions you may see:**

- `AuthenticationError` — missing/invalid MetricAI key when constructing `MetricAI`, or HTTP 401 from proxy helpers.
- `AuthenticationError` on `track()` / `atrack()` — `POST /v1/sdk/events` requires a **MetricAI API key** (`X-MetricAI-API-Key` or `Authorization: Bearer <metricai_api_key>`). A dashboard **session JWT** returns 401 with an explicit message; use the API key for server-side telemetry.
- `InsufficientBalanceError` — HTTP 402 from proxy.
- `ProviderError` — other HTTP errors from proxy.
- `MetricAIBudgetExceeded` — session hard budget (Section 10).
- `ImportError` — optional packages missing (e.g. `openai_sdk` without `openai`).

**No user-registered error callback** exists on `TelemetryTransport`; failures are logged with `logging`. Set `raise_on_error=True` on `MetricAI` to surface failures.

**Retries:** `max_retries` default `2` → up to `1 + max_retries` attempts; backoff sleeps `0.5s`, `1.0s` between attempts. Retries apply to 5xx, timeouts, and transport errors; 4xx responses log and return `None` unless `raise_on_error`.

---

## Section 13 — Troubleshooting

**Provider activation failed silently**

- Check logs for: `MetricAI optional provider activation failed (e.g. Bedrock/Tavily hooks not registered): ...` (from `MetricAI.__init__`) or `Provider '%s' failed to activate: ...` (from `registry.activate`).
- Ensure optional deps are installed (`boto3`, `tavily-python`) and `active_providers` includes the hook name if you restricted it.

**Billing events not in dashboard**

- **Costs / consolidated token stats**: The **Cost analytics** page (`/dashboard/costs`) loads **`GET /transactions/logs`**, which merges proxy transaction rows with SDK `track()` rows from `billing_events` (`ingest_source: sdk_http`). The main dashboard rollup also uses **`GET /stats/tokens`**, which includes the same SDK aggregates. INR-only `track()` fields (`cost_inr`, outcome `billable_amount_inr`) are converted to USD using the platform `USD_TO_INR` rate. Simulated `track(simulate=True)` rows are excluded. Sign in with the **same account** as your MetricAI API key.
- **Tool Intelligence** (`/v1/analytics/tool-calls`): Includes proxy completions with `tool_types_invoked`, **and** SDK-ingested tool/API usage (`sdk_cost_unit: api_call` or `sdk_tool_call_count` &gt; 0), grouped under the canonical tool type `sdk_metered`.
- Verify `METRICAI_API_KEY` and that proxy requests include `X-Agent-ID` / `X-User-ID` (use `openai_sdk` or `headers()`).
- For `MetricAISession`, ensure the context manager exits so `session_close` is sent.
- Confirm connectivity to `base_url` and telemetry URL; telemetry failures are swallowed unless `raise_on_error=True`.
- If `track()` returns 202 but costs look wrong in the dashboard, check the response for `fx_conversion_warning` (USD conversion skipped when the platform FX rate was unavailable).

**Account helpers (`get_balance`, `get_usage`, `get_quota_status`)**

- `get_balance()` calls `GET /v1/wallet/balance` (API key or JWT). Wallet storage is **USD**; the SDK converts to INR for `WalletBalance.balance_inr` using `GET /v1/fx/usd-inr` (env fallback: `METRICAI_USD_INR_RATE`).
- `get_usage()` calls `GET /v1/usage/summary` (lifetime token/cost totals).
- `get_quota_status()` calls `GET /v1/billing/subscription` and maps the current billing cycle to `QuotaStatus`.

**Bedrock model not in pricing registry**

- `pricing_input_per_1k_usd` / `pricing_output_per_1k_usd` in the event `extra` may be `None`; add the model id to `metricai/data/bedrock_pricing.json`.

**Idempotency key collisions**

- Each `track()` generates a new UUID unless you pass `idempotency_key`. `MetricAISession` uses `session_id` as the telemetry idempotency key for `session_close`. Reusing the same key on distinct logical events can dedupe server-side (product-dependent).

**LangChain + Tavily attribution**

- Confirm `get_attribution().session_id` is set during the tool call (wrap with `named_session` or `attribution_scope`).

---

## Section 14 — Changelog and version

**Current version:** `0.2.0` (`metricai.__version__` and `pyproject.toml`).

### Changelog

| Version | Date | Notes |
|---------|------|-------|
| 0.2.0 | — | Initial documented release for this guide. |
| _next_ | — | _Add entries here._ |

---

_End of document._
