"""
Shared helpers for examples: MetricAI client + provider selection from environment.

Environment (common):

- ``METRICAI_API_KEY`` — required.
- ``METRICAI_BASE_URL`` — optional (default ``https://api.metricai.co.in``).
- ``METRICAI_EXAMPLE_PROVIDER`` — ``openai`` | ``claude`` | ``gemini`` | ``grok`` (default ``openai``).

BYOK keys (set the one matching your provider):

- ``OPENAI_API_KEY``
- ``ANTHROPIC_API_KEY`` or ``CLAUDE_API_KEY``
- ``GEMINI_API_KEY`` or ``GOOGLE_API_KEY``
- ``GROK_API_KEY`` or ``XAI_API_KEY``

Optional default models per provider::

    METRICAI_MODEL_OPENAI=gpt-4o-mini
    METRICAI_MODEL_CLAUDE=claude-3-5-haiku-20241022
    METRICAI_MODEL_GEMINI=gemini-2.0-flash
    METRICAI_MODEL_GROK=grok-2-latest
"""

from __future__ import annotations

import os
from typing import Literal

from metricai import MetricAI

ProviderName = Literal["openai", "claude", "gemini", "grok"]

_DEFAULT_MODELS: dict[ProviderName, str] = {
    "openai": "gpt-4o-mini",
    "claude": "claude-3-5-haiku-20241022",
    "gemini": "gemini-2.0-flash",
    "grok": "grok-2-latest",
}

_ENV_MODEL = {
    "openai": "METRICAI_MODEL_OPENAI",
    "claude": "METRICAI_MODEL_CLAUDE",
    "gemini": "METRICAI_MODEL_GEMINI",
    "grok": "METRICAI_MODEL_GROK",
}


def base_url() -> str:
    return os.environ.get("METRICAI_BASE_URL", "https://api.metricai.co.in").rstrip("/")


def example_provider() -> ProviderName:
    p = (os.environ.get("METRICAI_EXAMPLE_PROVIDER") or "openai").strip().lower()
    if p in ("anthropic",):
        p = "claude"
    if p in ("groq",):
        p = "grok"
    if p not in ("openai", "claude", "gemini", "grok"):
        raise SystemExit(
            f"METRICAI_EXAMPLE_PROVIDER must be openai|claude|gemini|grok, got {p!r}"
        )
    return p  # type: ignore[return-value]


def llm_keys_from_env() -> dict[str, str]:
    """Collect BYOK keys present in the environment (may include multiple providers)."""
    keys: dict[str, str] = {}
    if v := (os.environ.get("OPENAI_API_KEY") or "").strip():
        keys["openai"] = v
    if v := (os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("CLAUDE_API_KEY") or "").strip():
        keys["anthropic"] = v
    if v := (os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or "").strip():
        keys["gemini"] = v
    if v := (os.environ.get("GROK_API_KEY") or os.environ.get("XAI_API_KEY") or "").strip():
        keys["grok"] = v
    return keys


def require_llm_key_for(provider: ProviderName, keys: dict[str, str]) -> None:
    need = {
        "openai": ("openai", "OPENAI_API_KEY"),
        "claude": ("anthropic", "ANTHROPIC_API_KEY or CLAUDE_API_KEY"),
        "gemini": ("gemini", "GEMINI_API_KEY or GOOGLE_API_KEY"),
        "grok": ("grok", "GROK_API_KEY or XAI_API_KEY"),
    }
    k, hint = need[provider]
    if k not in keys:
        raise SystemExit(f"For METRICAI_EXAMPLE_PROVIDER={provider}, set {hint}")


def default_model_for(provider: ProviderName) -> str:
    env_name = _ENV_MODEL[provider]
    return (os.environ.get(env_name) or "").strip() or _DEFAULT_MODELS[provider]


def metricai_client() -> MetricAI:
    mak = (os.environ.get("METRICAI_API_KEY") or "").strip()
    if not mak:
        raise SystemExit("Set METRICAI_API_KEY")

    keys = llm_keys_from_env()
    if not keys:
        raise SystemExit(
            "Set at least one BYOK key: OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, or GROK_API_KEY"
        )

    return MetricAI(
        api_key=mak,
        base_url=base_url(),
        llm_keys=keys,
        mode="byok",
    )


def metricai_client_for_provider(provider: ProviderName) -> MetricAI:
    """Same as :func:`metricai_client` but ensures the key for ``provider`` exists."""
    mak = (os.environ.get("METRICAI_API_KEY") or "").strip()
    if not mak:
        raise SystemExit("Set METRICAI_API_KEY")

    keys = llm_keys_from_env()
    require_llm_key_for(provider, keys)

    return MetricAI(
        api_key=mak,
        base_url=base_url(),
        llm_keys=keys,
        mode="byok",
    )
