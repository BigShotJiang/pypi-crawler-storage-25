"""
Exercise all MetricAI proxy SDK factories (OpenAI + Anthropic + Gemini + Grok).

Official SDKs merge ``base_url`` with fixed paths; the API exposes matching routes:

- ``openai.OpenAI`` -> ``/openai/chat/completions`` (also ``/openai``)
- ``anthropic.Anthropic`` -> ``/claude/v1/messages`` (also ``/claude``)
- ``openai.OpenAI`` (Gemini) -> ``/gemini/chat/completions`` (also ``/gemini``)
- ``openai.OpenAI`` (Grok) -> ``/grok/chat/completions`` (also ``/grok``)

Environment:

- ``METRICAI_API_KEY`` (required)
- ``METRICAI_PROXY_URL`` or ``METRICAI_BASE_URL`` (optional; default ``https://proxy.metricai.co.in``)
- Provider keys (set those you want to test):

  - ``OPENAI_API_KEY``
  - ``ANTHROPIC_API_KEY`` or ``CLAUDE_API_KEY``
  - ``GEMINI_API_KEY`` or ``GOOGLE_API_KEY``
  - ``GROK_API_KEY`` or ``XAI_API_KEY``

Run::

    python examples/provider_sdk_check.py
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _load_dotenv() -> None:
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    root = Path(__file__).resolve().parents[2]
    load_dotenv(root / ".env")


def _base() -> str:
    _load_dotenv()
    from metricai.config import DEFAULT_PROXY_BASE_URL

    return (
        os.environ.get("METRICAI_PROXY_URL")
        or os.environ.get("METRICAI_BASE_URL")
        or DEFAULT_PROXY_BASE_URL
    ).rstrip("/")


def _keys() -> dict[str, str]:
    out: dict[str, str] = {}
    if k := os.environ.get("OPENAI_API_KEY"):
        out["openai"] = k
    if k := os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("CLAUDE_API_KEY"):
        out["anthropic"] = k
    if k := os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY"):
        out["gemini"] = k
    if k := os.environ.get("GROK_API_KEY") or os.environ.get("XAI_API_KEY"):
        out["grok"] = k
    return out


def main() -> int:
    from metricai import MetricAI

    mak = os.environ.get("METRICAI_API_KEY", "").strip()
    if not mak:
        print("Set METRICAI_API_KEY", file=sys.stderr)
        return 1

    llm_keys = _keys()
    if not llm_keys:
        print("Set at least one of: OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, GROK_API_KEY", file=sys.stderr)
        return 1

    client = MetricAI(api_key=mak, base_url=_base(), llm_keys=llm_keys, mode="byok")
    uid = "provider-sdk-check"

    if "openai" in llm_keys:
        oai = client.openai_sdk(agent_id="check-openai", user_id=uid)
        r = oai.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Reply with exactly: ok-openai"}],
        )
        print("openai:", (r.choices[0].message.content or "")[:200])

    if "anthropic" in llm_keys:
        anth = client.anthropic_sdk(agent_id="check-claude", user_id=uid)
        r = anth.messages.create(
            model="claude-3-5-haiku-20241022",
            max_tokens=32,
            messages=[{"role": "user", "content": "Reply with exactly: ok-claude"}],
        )
        text = ""
        for b in getattr(r, "content", []) or []:
            if getattr(b, "type", None) == "text":
                text += getattr(b, "text", "")
        print("claude:", text[:200])

    if "gemini" in llm_keys:
        gem = client.gemini_sdk(agent_id="check-gemini", user_id=uid)
        r = gem.chat.completions.create(
            model="gemini-2.0-flash",
            messages=[{"role": "user", "content": "Reply with exactly: ok-gemini"}],
        )
        print("gemini:", (r.choices[0].message.content or "")[:200])

    if "grok" in llm_keys:
        gk = client.grok_sdk(agent_id="check-grok", user_id=uid)
        r = gk.chat.completions.create(
            model="grok-2-latest",
            messages=[{"role": "user", "content": "Reply with exactly: ok-grok"}],
        )
        print("grok:", (r.choices[0].message.content or "")[:200])

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
