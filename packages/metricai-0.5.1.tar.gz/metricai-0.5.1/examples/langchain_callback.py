"""
LangChain: :class:`~metricai.integrations.langchain.MetricAILLM` + callback.

Select provider::

    set METRICAI_EXAMPLE_PROVIDER=openai    # default
    set METRICAI_EXAMPLE_PROVIDER=claude
    set METRICAI_EXAMPLE_PROVIDER=gemini
    set METRICAI_EXAMPLE_PROVIDER=grok

Environment:

- ``METRICAI_API_KEY`` — MetricAI dashboard key.
- BYOK key for the chosen provider (see ``_provider_env.py``).
- ``METRICAI_BASE_URL`` (optional).

If you see ``getaddrinfo failed`` / ``APIConnectionError``, fix DNS or use::

    set METRICAI_BASE_URL=http://127.0.0.1:8000

Optional — bypass MetricAI and call OpenAI directly::

    set DIRECT_OPENAI=1
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from langchain_core.messages import HumanMessage

from metricai.integrations.langchain import MetricAICallbackHandler, MetricAILLM

from _provider_env import default_model_for, example_provider, metricai_client_for_provider

_direct = os.environ.get("DIRECT_OPENAI", "").lower() in ("1", "true", "yes")

if _direct:
    try:
        from langchain_openai import ChatOpenAI
    except ImportError as e:
        raise SystemExit("pip install langchain-openai") from e

    llm = ChatOpenAI(model="gpt-4o-mini", api_key=os.environ["OPENAI_API_KEY"])
    msg = llm.invoke([HumanMessage(content="Say hi in three words.")])
    print(getattr(msg, "content", msg))
else:
    provider = example_provider()
    client = metricai_client_for_provider(provider)
    model = default_model_for(provider)

    lc_provider = provider
    if lc_provider == "claude":
        lc_provider = "anthropic"

    handler = MetricAICallbackHandler(
        client=client,
        agent_id="support-chain",
        user_id="user_456",
        provider=provider,
        model_fallback=model,
    )
    llm = MetricAILLM(
        client,
        agent_id="support-chain",
        user_id="user_456",
        provider=lc_provider,  # type: ignore[arg-type]
        model=model,
    )

    msg = llm.invoke([HumanMessage(content="Say hi in three words.")], config={"callbacks": [handler]})
    print(getattr(msg, "content", msg))
