"""
LangChain + MetricAI — idiomatic chat model (``ChatMetricAI``).

Uses :class:`metricai.integrations.langchain_chat.ChatMetricAI` against ``/v1/proxy/{provider}``.

Install::

    pip install "metricai[langchain]"
    pip install -e .

Select provider::

    set METRICAI_EXAMPLE_PROVIDER=openai    # default
    set METRICAI_EXAMPLE_PROVIDER=claude
    set METRICAI_EXAMPLE_PROVIDER=gemini
    set METRICAI_EXAMPLE_PROVIDER=grok

Environment::

    METRICAI_API_KEY=mak_...
    METRICAI_BASE_URL=http://localhost:8000   # optional
    OPENAI_API_KEY=... / ANTHROPIC_API_KEY=... / GEMINI_API_KEY=... / GROK_API_KEY=...

Run::

    python examples/langchain_metricai_sample.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    from langchain_core.messages import HumanMessage
    from langchain_core.output_parsers import StrOutputParser
    from langchain_core.prompts import ChatPromptTemplate
except ImportError:
    print("Install: pip install langchain-core", file=sys.stderr)
    raise

from metricai.integrations.langchain_chat import ChatMetricAI

from _provider_env import (
    base_url,
    default_model_for,
    example_provider,
    llm_keys_from_env,
    require_llm_key_for,
)


def _extra_proxy_headers(provider: str) -> dict[str, str]:
    keys = llm_keys_from_env()
    require_llm_key_for(provider, keys)  # type: ignore[arg-type]
    if provider == "openai":
        return {"X-OpenAI-API-Key": keys["openai"]}
    if provider == "claude":
        return {"X-Claude-API-Key": keys["anthropic"]}
    if provider == "gemini":
        return {"X-Gemini-API-Key": keys["gemini"]}
    return {"X-Grok-API-Key": keys["grok"]}


def build_llm() -> ChatMetricAI:
    import os

    api_key = os.environ.get("METRICAI_API_KEY", "").strip()
    if not api_key:
        raise SystemExit("Set METRICAI_API_KEY")

    provider = example_provider()
    model = default_model_for(provider)
    extra = _extra_proxy_headers(provider)

    chat_provider: str = provider
    if chat_provider == "claude":
        chat_provider = "claude"

    return ChatMetricAI(
        model=model,
        metricai_api_key=api_key,
        base_url=base_url(),
        provider=chat_provider,  # type: ignore[arg-type]
        extra_proxy_headers=extra,
    )


def main() -> int:
    llm = build_llm()

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "You answer briefly in plain text."),
            ("human", "{question}"),
        ]
    )
    chain = prompt | llm | StrOutputParser()

    out = chain.invoke({"question": "What is 2+2? One short sentence."})
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
