"""
CrewAI crew with :class:`~metricai.integrations.crewai.MetricAICrew` (requires ``crewai``).

Select LLM provider (OpenAI-compatible vs Anthropic)::

    set METRICAI_EXAMPLE_PROVIDER=openai    # default
    set METRICAI_EXAMPLE_PROVIDER=claude
    set METRICAI_EXAMPLE_PROVIDER=gemini
    set METRICAI_EXAMPLE_PROVIDER=grok

Set ``METRICAI_API_KEY`` and the matching BYOK key. Run::

    python examples/crewai_crew.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from crewai import Agent, Task

from metricai.integrations.crewai import MetricAICrew

from _provider_env import default_model_for, example_provider, metricai_client_for_provider


def main() -> int:
    provider = example_provider()
    client = metricai_client_for_provider(provider)
    model = default_model_for(provider)

    crew_provider = provider
    if crew_provider == "claude":
        crew_provider = "anthropic"

    researcher = Agent(role="Researcher", goal="Summarize", backstory="Analyst")
    writer = Agent(role="Writer", goal="Write one line", backstory="Writer")

    t1 = Task(description="Topic: AI billing", agent=researcher, expected_output="Bullets")
    t2 = Task(description="Turn bullets into one sentence", agent=writer, expected_output="One line")

    crew = MetricAICrew(
        client=client,
        crew_id="research-crew-v1",
        user_id="user_101",
        agents=[researcher, writer],
        tasks=[t1, t2],
        provider=crew_provider,
        model=model,
    )
    print(crew.kickoff())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
