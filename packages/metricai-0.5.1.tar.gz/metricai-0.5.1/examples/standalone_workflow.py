"""Standalone :class:`~metricai.workflow.agent.MetricAIAgent` (OpenAI proxy)."""

import os

from metricai import MetricAI
from metricai.workflow import MetricAIAgent

client = MetricAI(
    api_key=os.environ["METRICAI_API_KEY"],
    llm_keys={"gemini": os.environ["GEMINI_API_KEY"]},
)

agent = MetricAIAgent(
    client,
    agent_id="booking-agent-v2",
    user_id="user_123",
    model="gemini-2.0-flash",
    system_prompt="You are a concise assistant.",
    budget_cap_inr=50.0,
    billing_mode="hybrid",
)

resp = agent.run("What is 2+2? Reply with the number only.")
print(resp.content)
