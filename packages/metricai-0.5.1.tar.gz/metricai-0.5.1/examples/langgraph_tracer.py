"""
LangGraph + :func:`~metricai.integrations.langgraph.instrument_graph`.

**Default:** one dummy node (no upstream LLM) — only needs ``METRICAI_API_KEY``.

**With LLM** (OpenAI / Claude / Gemini / Grok through MetricAI proxy)::

    set METRICAI_GRAPH_USE_LLM=1
    set METRICAI_EXAMPLE_PROVIDER=gemini
    set METRICAI_API_KEY=...
    set GEMINI_API_KEY=...

Also::

    pip install langgraph langchain-core langchain-openai langchain-anthropic

Run::

    python examples/langgraph_tracer.py
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from typing_extensions import TypedDict

from langgraph.graph import END, StateGraph

from metricai import MetricAI
from metricai.integrations.langgraph import instrument_graph

from _provider_env import (
    base_url,
    default_model_for,
    example_provider,
    llm_keys_from_env,
    metricai_client_for_provider,
    require_llm_key_for,
)


class State(TypedDict):
    task: str
    result: str


def node_echo(state: State) -> dict:
    return {"result": f"done: {state['task']}"}


def _extra_headers(provider: str) -> dict[str, str]:
    keys = llm_keys_from_env()
    require_llm_key_for(provider, keys)  # type: ignore[arg-type]
    if provider == "openai":
        return {"X-OpenAI-API-Key": keys["openai"]}
    if provider == "claude":
        return {"X-Claude-API-Key": keys["anthropic"]}
    if provider == "gemini":
        return {"X-Gemini-API-Key": keys["gemini"]}
    return {"X-Grok-API-Key": keys["grok"]}


def main() -> int:
    mak = (os.environ.get("METRICAI_API_KEY") or "").strip()
    if not mak:
        raise SystemExit("Set METRICAI_API_KEY")

    use_llm = os.environ.get("METRICAI_GRAPH_USE_LLM", "").lower() in ("1", "true", "yes")

    if use_llm:
        try:
            from langchain_core.messages import HumanMessage
            from metricai.integrations.langchain_chat import ChatMetricAI
        except ImportError as e:
            raise SystemExit("pip install langchain-core") from e

        provider = example_provider()
        client = metricai_client_for_provider(provider)
        model = default_model_for(provider)
        extra = _extra_headers(provider)
        chat_prov = "claude" if provider == "claude" else provider

        llm = ChatMetricAI(
            model=model,
            metricai_api_key=mak,
            base_url=base_url(),
            provider=chat_prov,  # type: ignore[arg-type]
            extra_proxy_headers=extra,
        )

        def node_llm(state: State) -> dict:
            msg = llm.invoke([HumanMessage(content=f"Reply in 5 words max. Task: {state['task']}")])
            text = getattr(msg, "content", str(msg))
            return {"result": text}

        g = StateGraph(State)
        g.add_node("llm", node_llm)
        g.set_entry_point("llm")
        g.add_edge("llm", END)
        trace_kw = {"provider": provider}
    else:
        client = MetricAI(api_key=mak, base_url=base_url())
        g = StateGraph(State)
        g.add_node("a", node_echo)
        g.set_entry_point("a")
        g.add_edge("a", END)
        trace_kw = {"provider": "openai"}

    app = g.compile()
    wrapped, tracer = instrument_graph(
        app,
        client=client,
        graph_id="demo-graph",
        user_id="u1",
        **trace_kw,
    )
    out = wrapped.invoke({"task": "hello"})
    print(out)
    print(tracer.summary())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
