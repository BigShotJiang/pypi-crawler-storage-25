"""
Example using `metricaiclient`: telemetry, wallet (or local mock), and chat probes for
OpenAI (ChatGPT API), Anthropic Claude, Google Gemini, and xAI Grok — all through MetricAI proxy routes.

Environment:

    METRICAI_API_KEY=mak_...
    METRICAI_BASE_URL=http://localhost:8000   # optional

Models (optional; defaults match common E2E choices):

    METRICAI_MODEL_OPENAI=gpt-4o-mini
    METRICAI_MODEL_CLAUDE=claude-3-haiku-20240307
    METRICAI_MODEL_GEMINI=gemini-2.0-flash
    METRICAI_MODEL_GROK=grok-4-1-fast-non-reasoning

Run only some providers:

    METRICAI_ONLY=openai,gemini

Skip non-streaming or streaming section:

    METRICAI_SKIP_COMPLETE=1
    METRICAI_SKIP_STREAM=1

Probe prompt (optional):

    METRICAI_PROBE_MESSAGE=Reply in one short sentence: what is 2+2?

**Bring-your-own keys (BYOK)** — the server needs upstream keys unless it has shared keys in
its config. Set any of these so the example adds the matching proxy headers (same as
``check_metricai_e2e_models.py``):

    ANTHROPIC_API_KEY or CLAUDE_API_KEY  ->  X-Claude-API-Key
    GROK_API_KEY or XAI_API_KEY          ->  X-Grok-API-Key
    GEMINI_API_KEY or GOOGLE_API_KEY     ->  X-Gemini-API-Key
    OPENAI_API_KEY                       ->  X-OpenAI-API-Key

Local wallet mock: see METRICAI_USE_MOCK_WALLET / METRICAI_MOCK_BALANCE_USD in code below.

Run:

    python examples/metricaiclient_example.py
"""

from __future__ import annotations

import os
from typing import Any

from metricai import MetricAI, metricaiclient
from metricai.streaming import stream_text_delta_from_chunk


def _extra_proxy_headers_from_env() -> dict[str, str]:
    """Map common env vars to MetricAI proxy BYOK headers (see backend ``proxy_use_cases``)."""
    h: dict[str, str] = {}
    claude = (
        os.environ.get("CLAUDE_API_KEY")
        or os.environ.get("ANTHROPIC_API_KEY")
        or os.environ.get("X_CLAUDE_API_KEY", "")
    ).strip()
    if claude:
        h["X-Claude-API-Key"] = claude
    grok = (os.environ.get("GROK_API_KEY") or os.environ.get("XAI_API_KEY") or os.environ.get("X_GROK_API_KEY", "")).strip()
    if grok:
        h["X-Grok-API-Key"] = grok
    gem = (
        os.environ.get("GEMINI_API_KEY")
        or os.environ.get("GOOGLE_API_KEY")
        or os.environ.get("X_GEMINI_API_KEY", "")
    ).strip()
    if gem:
        h["X-Gemini-API-Key"] = gem
    oa = (os.environ.get("OPENAI_API_KEY") or os.environ.get("X_OPENAI_API_KEY", "")).strip()
    if oa:
        h["X-OpenAI-API-Key"] = oa
    return h


def _use_mock_wallet(base_url: str) -> bool:
    if os.environ.get("METRICAI_USE_MOCK_WALLET", "").strip().lower() in ("1", "true", "yes"):
        return True
    host = base_url.lower()
    return "localhost" in host or "127.0.0.1" in host


def _text_from_message(msg: dict[str, Any]) -> str:
    """Normalize string or multimodal ``content`` list to plain text."""
    c = msg.get("content")
    if isinstance(c, str):
        return c.strip()
    if isinstance(c, list):
        parts: list[str] = []
        for p in c:
            if isinstance(p, dict):
                if p.get("type") == "text" and "text" in p:
                    parts.append(str(p["text"]))
                elif "text" in p:
                    parts.append(str(p["text"]))
            elif isinstance(p, str):
                parts.append(p)
        return "".join(parts).strip()
    return ""


def _reply_preview(resp: dict[str, Any], max_len: int = 400) -> str:
    """MetricAI may return ``assistant_message`` (normalized) and/or OpenAI-style ``choices``."""
    am = resp.get("assistant_message")
    if isinstance(am, dict):
        t = _text_from_message(am)
        if t:
            return t if len(t) <= max_len else t[: max_len - 3] + "..."
    choices = resp.get("choices")
    if isinstance(choices, list) and choices:
        m = choices[0].get("message")
        if isinstance(m, dict):
            t = _text_from_message(m)
            if t:
                return t if len(t) <= max_len else t[: max_len - 3] + "..."
    return "(no assistant text in response)"


def _only_providers() -> set[str] | None:
    raw = os.environ.get("METRICAI_ONLY", "").strip()
    if not raw:
        return None
    return {x.strip().lower() for x in raw.split(",") if x.strip()}


def _env_flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes")


# (label, client attribute, default model, env var for model override)
_PROVIDER_SPECS: list[tuple[str, str, str, str]] = [
    ("openai", "openai", "gpt-4o-mini", "METRICAI_MODEL_OPENAI"),
    ("claude", "claude", "claude-3-haiku-20240307", "METRICAI_MODEL_CLAUDE"),
    ("gemini", "gemini", "gemini-2.0-flash", "METRICAI_MODEL_GEMINI"),
    ("grok", "grok", "grok-4-1-fast-non-reasoning", "METRICAI_MODEL_GROK"),
]


def _probe_messages() -> list[dict[str, Any]]:
    probe = os.environ.get(
        "METRICAI_PROBE_MESSAGE",
        "Reply in one short sentence only: What is 2+2?",
    )
    return [{"role": "user", "content": probe}]


def _stream_delta_text(chunk: dict[str, Any], provider: str) -> str:
    """One SSE JSON line’s assistant text (OpenAI-style or Claude Anthropic events)."""
    return stream_text_delta_from_chunk(chunk, provider)


def _run_provider_probes(client: MetricAI) -> None:
    only = _only_providers()
    messages = _probe_messages()

    print("\n--- proxy chat probes (non-streaming) ---")
    for key, attr, default_model, env_model in _PROVIDER_SPECS:
        if only is not None and key not in only:
            continue
        model = os.environ.get(env_model, default_model).strip() or default_model
        proxy = getattr(client, attr)()
        try:
            resp = proxy.complete(
                model=model,
                messages=messages,
                max_tokens=256,
            )
            preview = _reply_preview(resp)
            print(f"[{key}] model={model!r} -> {preview}")
        except Exception as e:
            print(f"[{key}] model={model!r} FAILED: {e}")


def _run_provider_stream_probes(client: MetricAI) -> None:
    """Iterate SSE chunks; count token-sized deltas; full text via :meth:`StreamingResponse.get_text`."""
    only = _only_providers()
    messages = _probe_messages()
    max_preview = int(os.environ.get("METRICAI_STREAM_PREVIEW_CHARS", "280"))

    print("\n--- proxy streaming (SSE chunks) ---")
    for key, attr, default_model, env_model in _PROVIDER_SPECS:
        if only is not None and key not in only:
            continue
        model = os.environ.get(env_model, default_model).strip() or default_model
        proxy = getattr(client, attr)()
        try:
            stream = proxy.stream(
                model=model,
                messages=messages,
                max_tokens=256,
            )
            chunks_with_text = 0
            for chunk in stream:
                if _stream_delta_text(chunk, key):
                    chunks_with_text += 1
            assembled = stream.get_text()
            prev = assembled if len(assembled) <= max_preview else assembled[: max_preview - 3] + "..."
            print(
                f"[{key}] stream model={model!r} "
                f"sse_chunks_with_text={chunks_with_text} total_chars={len(assembled)} "
                f"text={prev!r}"
            )
        except Exception as e:
            print(f"[{key}] stream model={model!r} FAILED: {e}")


def main() -> None:
    api_key = os.environ.get("METRICAI_API_KEY", "").strip()
    base_url = os.environ.get("METRICAI_BASE_URL", "").strip()

    if not api_key:
        raise SystemExit("Set METRICAI_API_KEY")

    extra = _extra_proxy_headers_from_env()
    if extra:
        print("BYOK headers from env:", ", ".join(sorted(extra.keys())))

    kwargs: dict[str, Any] = {"api_key": api_key, "extra_proxy_headers": extra or None}
    if base_url:
        kwargs["base_url"] = base_url

    client = metricaiclient(**kwargs)

    result = client.track(
        simulate=True,
        outcome={"success": True, "charge_on_success_inr": 0.01},
    )
    print("track(simulate=True):", result)

    resolved_base = base_url or "https://api.metricai.co.in"
    if _use_mock_wallet(resolved_base):
        mock_usd = float(os.environ.get("METRICAI_MOCK_BALANCE_USD", "1000"))
        print(f"balance (local mock, not from API): {mock_usd} USD")
    else:
        try:
            balance = client.get_balance()
            print("balance:", balance.balance_inr, balance.currency)
        except Exception as e:
            print("get_balance failed:", e)

    if not _env_flag("METRICAI_SKIP_COMPLETE"):
        _run_provider_probes(client)
    if not _env_flag("METRICAI_SKIP_STREAM"):
        _run_provider_stream_probes(client)


if __name__ == "__main__":
    main()
