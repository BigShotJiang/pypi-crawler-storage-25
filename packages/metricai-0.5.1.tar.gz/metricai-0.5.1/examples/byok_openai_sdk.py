"""
BYOK: official OpenAI / Anthropic / Gemini / Grok Python SDKs via the MetricAI proxy.

Set ``METRICAI_API_KEY`` and the BYOK key for the provider you want. Select provider::

    set METRICAI_EXAMPLE_PROVIDER=openai     # default
    set METRICAI_EXAMPLE_PROVIDER=claude
    set METRICAI_EXAMPLE_PROVIDER=gemini
    set METRICAI_EXAMPLE_PROVIDER=grok

Optional: ``METRICAI_BASE_URL``, ``METRICAI_MODEL_*`` — see ``_provider_env.py``.

Run from ``metricai-sdk`` root::

    python examples/byok_openai_sdk.py
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow ``import _provider_env`` when running as ``python examples/byok_openai_sdk.py``
sys.path.insert(0, str(Path(__file__).resolve().parent))

from _provider_env import default_model_for, example_provider, metricai_client_for_provider


def main() -> int:
    provider = example_provider()
    client = metricai_client_for_provider(provider)
    model = default_model_for(provider)
    uid = "demo-user"

    if provider == "openai":
        sdk = client.openai_sdk(agent_id="demo-agent", user_id=uid)
        r = sdk.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": "Say hello in one sentence."}],
        )
        print(r.choices[0].message.content)
    elif provider == "claude":
        sdk = client.anthropic_sdk(agent_id="demo-agent", user_id=uid)
        r = sdk.messages.create(
            model=model,
            max_tokens=256,
            messages=[{"role": "user", "content": "Say hello in one sentence."}],
        )
        text = ""
        for b in getattr(r, "content", []) or []:
            if getattr(b, "type", None) == "text":
                text += getattr(b, "text", "")
        print(text)
    elif provider == "gemini":
        sdk = client.gemini_sdk(agent_id="demo-agent", user_id=uid)
        r = sdk.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": "Say hello in one sentence."}],
        )
        print(r.choices[0].message.content)
    else:
        sdk = client.grok_sdk(agent_id="demo-agent", user_id=uid)
        r = sdk.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": "Say hello in one sentence."}],
        )
        print(r.choices[0].message.content)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
