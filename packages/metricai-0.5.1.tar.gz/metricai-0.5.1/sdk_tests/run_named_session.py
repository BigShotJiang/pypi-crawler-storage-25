"""
``named_session`` + ``track()`` with explicit ``session_id`` from context (METRICAI_SDK.md §7).

Uses only ``METRICAI_API_KEY``.

Run::

    cd metricai-sdk
    pip install -e .
    python -m sdk_tests.run_named_session
"""

from __future__ import annotations

from metricai.context import named_session

from sdk_tests._common import client_minimal


def main() -> int:
    c = client_minimal()

    with named_session("sdk-named-job", agent_id="worker-sdk", user_id="user-named-9") as ctx:
        c.track(
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=50,
            output_tokens=10,
            session_id=ctx.session_id,
            agent_id="worker-sdk",
            user_id="user-named-9",
        )
        print("session_name:", ctx.session_name, "session_id:", ctx.session_id)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
