"""
``metricai.runtime.init`` and ``get_metricai()`` (METRICAI_SDK.md §5).

Uses only ``METRICAI_API_KEY``. After ``init``, calls ``track()`` via the global client.

Run::

    cd metricai-sdk
    pip install -e .
    python -m sdk_tests.run_runtime_init
"""

from __future__ import annotations

import os
import sys

from metricai.runtime import get_metricai, init


def main() -> int:
    mak = (os.environ.get("METRICAI_API_KEY") or "").strip()
    if not mak:
        print("Set METRICAI_API_KEY", file=sys.stderr)
        return 1

    base = os.environ.get("METRICAI_BASE_URL", "https://api.metricai.co.in").rstrip("/")

    init(
        api_key=mak,
        backend_endpoint=base,
        default_agent_id="sdk-init-demo",
        environment="staging-tag-example",
    )
    c = get_metricai()
    c.track(
        provider="openai",
        model="gpt-4o-mini",
        input_tokens=10,
        output_tokens=5,
        agent_id="after-init",
        user_id="user-runtime-init",
    )
    print("init + get_metricai + track completed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
