"""
OpenAI chat completion via MetricAI proxy (METRICAI_SDK.md §6 OpenAI).

Environment: ``METRICAI_API_KEY``, ``OPENAI_API_KEY``; optional ``METRICAI_BASE_URL``.

Run::

    cd metricai-sdk
    pip install -e ".[openai]"
    python -m sdk_tests.run_openai_proxy
"""

from __future__ import annotations

import sys


def main() -> int:
    from sdk_tests._common import client, llm_keys_from_env

    if "openai" not in llm_keys_from_env():
        print("Set OPENAI_API_KEY", file=sys.stderr)
        return 1

    m = client()
    oai = m.openai_sdk(agent_id="sdk-test-openai", user_id="user-sdk-openai-001")
    r = oai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Say hi in exactly three words."}],
    )
    text = (r.choices[0].message.content or "").strip()
    print("openai response:", text[:500])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
