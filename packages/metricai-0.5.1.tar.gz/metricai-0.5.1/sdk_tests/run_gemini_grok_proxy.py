"""
Gemini and Grok OpenAI-compatible clients via MetricAI (METRICAI_SDK.md §6).

Runs each provider only if the matching env key is set.

Environment:

- ``METRICAI_API_KEY``
- ``GEMINI_API_KEY`` or ``GOOGLE_API_KEY`` (Gemini)
- ``GROK_API_KEY`` or ``XAI_API_KEY`` (Grok)

Run::

    cd metricai-sdk
    pip install -e ".[openai]"
    python -m sdk_tests.run_gemini_grok_proxy
"""

from __future__ import annotations

import sys


def main() -> int:
    from sdk_tests._common import client, llm_keys_from_env

    keys = llm_keys_from_env()
    if "gemini" not in keys and "grok" not in keys:
        print(
            "Set GEMINI_API_KEY or GROK_API_KEY (or GOOGLE_API_KEY / XAI_API_KEY)",
            file=sys.stderr,
        )
        return 1

    m = client()
    uid = "user-sdk-gemini-grok"

    if "gemini" in keys:
        g = m.gemini_sdk(agent_id="sdk-test-gemini", user_id=uid)
        r = g.chat.completions.create(
            model="gemini-2.0-flash",
            messages=[{"role": "user", "content": "Say ok-gemini in two words."}],
        )
        print("gemini:", (r.choices[0].message.content or "")[:300])

    if "grok" in keys:
        gk = m.grok_sdk(agent_id="sdk-test-grok", user_id=uid)
        r = gk.chat.completions.create(
            model="grok-2-latest",
            messages=[{"role": "user", "content": "Say ok-grok in two words."}],
        )
        print("grok:", (r.choices[0].message.content or "")[:300])

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
