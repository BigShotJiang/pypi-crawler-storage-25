"""
Shared environment helpers for manual SDK runs (see METRICAI_SDK.md).

Required for proxy scripts: ``METRICAI_API_KEY`` and at least one BYOK key.

Optional: ``METRICAI_PROXY_URL`` or ``METRICAI_BASE_URL`` (default ``https://proxy.metricai.co.in``).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

from metricai import MetricAI
from metricai.config import DEFAULT_PROXY_BASE_URL


def _load_root_dotenv() -> None:
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    root = Path(__file__).resolve().parents[2]
    load_dotenv(root / ".env")
    load_dotenv(root / "metricaigit" / ".env")


def base_url() -> str:
    _load_root_dotenv()
    return (
        os.environ.get("METRICAI_PROXY_URL")
        or os.environ.get("METRICAI_BASE_URL")
        or DEFAULT_PROXY_BASE_URL
    ).rstrip("/")


def require_metricai_api_key() -> str:
    _load_root_dotenv()
    key = (os.environ.get("METRICAI_API_KEY") or "").strip()
    if not key:
        print("Set METRICAI_API_KEY", file=sys.stderr)
        sys.exit(1)
    return key


def llm_keys_from_env() -> dict[str, str]:
    keys: dict[str, str] = {}
    if v := (os.environ.get("OPENAI_API_KEY") or "").strip():
        keys["openai"] = v
    if v := (os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("CLAUDE_API_KEY") or "").strip():
        keys["anthropic"] = v
    if v := (os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or "").strip():
        keys["gemini"] = v
    if v := (os.environ.get("GROK_API_KEY") or os.environ.get("XAI_API_KEY") or "").strip():
        keys["grok"] = v
    return keys


def client(**kwargs: Any) -> MetricAI:
    """Build a :class:`~metricai.MetricAI` client with BYOK keys from the environment."""
    mak = require_metricai_api_key()
    keys = llm_keys_from_env()
    if not keys:
        print(
            "Set at least one BYOK key: OPENAI_API_KEY, ANTHROPIC_API_KEY, "
            "GEMINI_API_KEY, or GROK_API_KEY",
            file=sys.stderr,
        )
        sys.exit(1)
    merged = {"api_key": mak, "base_url": base_url(), "llm_keys": keys, "mode": "byok"}
    merged.update(kwargs)
    return MetricAI(**merged)


def client_minimal(**kwargs: Any) -> MetricAI:
    """Client with only ``METRICAI_API_KEY`` (for ``track()`` / session tests without proxy keys)."""
    mak = require_metricai_api_key()
    merged = {"api_key": mak, "base_url": base_url()}
    merged.update(kwargs)
    return MetricAI(**merged)
