"""
Anthropic Claude via MetricAI proxy (METRICAI_SDK.md §6 Anthropic).

Environment: ``METRICAI_API_KEY``, ``ANTHROPIC_API_KEY`` (or ``CLAUDE_API_KEY``).

Run::

    cd metricai-sdk
    pip install -e ".[anthropic]"
    python -m sdk_tests.run_anthropic_proxy
"""

from __future__ import annotations

import sys


def main() -> int:
    from sdk_tests._common import client, llm_keys_from_env

    keys = llm_keys_from_env()
    if "anthropic" not in keys:
        print("Set ANTHROPIC_API_KEY or CLAUDE_API_KEY", file=sys.stderr)
        return 1

    m = client()
    ac = m.anthropic_sdk(agent_id="sdk-test-claude", user_id="user-sdk-claude-001")
    r = ac.messages.create(
        model="claude-haiku-4-5",
        max_tokens=128,
        messages=[{"role": "user", "content": "Reply with exactly: ok-claude-sdk"}],
    )
    text = ""
    for block in getattr(r, "content", []) or []:
        if getattr(block, "type", None) == "text":
            text += getattr(block, "text", "")
    print("claude response:", text[:500])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
