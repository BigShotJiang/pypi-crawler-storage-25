"""
Live integration matrix for MetricAI proxy auth across all providers.

Loads ``.env`` from the repo root (``metricai_ne/.env``).

Patterns:
  A — raw provider SDK (same shape as PROXY_PROVIDER_EXAMPLES.md)
  B — ``MetricAI.*_sdk()`` factories
  C — ``metricai.init()`` + ``instrument()``
  P — ``validate_api_key()`` ping

Run::

    cd metricai-sdk
    pip install -e ".[openai,anthropic,dev]"
    python -m sdk_tests.run_all_providers
"""

from __future__ import annotations

import os
import sys
from typing import Callable, Dict, List, Tuple

from sdk_tests._common import base_url, client, llm_keys_from_env, require_metricai_api_key


def _pattern_a_openai(mak: str, keys: dict[str, str]) -> Tuple[bool, str]:
    if "openai" not in keys:
        return False, "skip (no OPENAI_API_KEY)"
    from openai import OpenAI

    c = OpenAI(
        api_key=mak,
        base_url=f"{base_url()}/v1/proxy/openai",
        default_headers={
            "X-OpenAI-API-Key": keys["openai"],
            "X-Agent-ID": "sdk-matrix-a",
            "X-User-ID": "matrix-user",
        },
    )
    r = c.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "Reply with exactly: ok-a-openai"}],
        max_tokens=16,
    )
    text = (r.choices[0].message.content or "")[:200]
    return "ok" in text.lower(), text


def _pattern_a_anthropic(mak: str, keys: dict[str, str]) -> Tuple[bool, str]:
    if "anthropic" not in keys:
        return False, "skip (no ANTHROPIC_API_KEY)"
    from anthropic import Anthropic

    c = Anthropic(
        api_key=mak,
        base_url=f"{base_url()}/v1/proxy/claude",
        default_headers={
            "X-Claude-API-Key": keys["anthropic"],
            "X-Agent-ID": "sdk-matrix-a",
            "X-User-ID": "matrix-user",
        },
    )
    r = c.messages.create(
        model="claude-haiku-4-5",
        max_tokens=32,
        messages=[{"role": "user", "content": "Reply with exactly: ok-a-claude"}],
    )
    text = ""
    for block in getattr(r, "content", []) or []:
        if getattr(block, "type", None) == "text":
            text += getattr(block, "text", "")
    return "ok" in text.lower(), text[:200]


def _pattern_a_gemini(mak: str, keys: dict[str, str]) -> Tuple[bool, str]:
    if "gemini" not in keys:
        return False, "skip (no GEMINI_API_KEY)"
    from openai import OpenAI

    c = OpenAI(
        api_key=mak,
        base_url=f"{base_url()}/v1/proxy/gemini",
        default_headers={
            "X-Gemini-API-Key": keys["gemini"],
            "X-Agent-ID": "sdk-matrix-a",
            "X-User-ID": "matrix-user",
        },
    )
    r = c.chat.completions.create(
        model="gemini-2.0-flash",
        messages=[{"role": "user", "content": "Reply with exactly: ok-a-gemini"}],
        max_tokens=16,
    )
    text = (r.choices[0].message.content or "")[:200]
    return "ok" in text.lower(), text


def _pattern_b(m: object, provider: str) -> Tuple[bool, str]:
    keys = llm_keys_from_env()
    if provider not in keys and provider != "anthropic":
        return False, f"skip (no key for {provider})"
    if provider == "anthropic" and "anthropic" not in keys:
        return False, "skip (no ANTHROPIC_API_KEY)"

    uid = "matrix-user-b"
    if provider == "openai":
        c = m.openai_sdk(agent_id="sdk-matrix-b", user_id=uid)
        r = c.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Reply with exactly: ok-b-openai"}],
            max_tokens=16,
        )
        text = (r.choices[0].message.content or "")[:200]
    elif provider == "anthropic":
        c = m.anthropic_sdk(agent_id="sdk-matrix-b", user_id=uid)
        r = c.messages.create(
            model="claude-haiku-4-5",
            max_tokens=32,
            messages=[{"role": "user", "content": "Reply with exactly: ok-b-claude"}],
        )
        text = ""
        for block in getattr(r, "content", []) or []:
            if getattr(block, "type", None) == "text":
                text += getattr(block, "text", "")
        text = text[:200]
    elif provider == "gemini":
        c = m.gemini_sdk(agent_id="sdk-matrix-b", user_id=uid)
        r = c.chat.completions.create(
            model="gemini-2.0-flash",
            messages=[{"role": "user", "content": "Reply with exactly: ok-b-gemini"}],
            max_tokens=16,
        )
        text = (r.choices[0].message.content or "")[:200]
    else:
        c = m.grok_sdk(agent_id="sdk-matrix-b", user_id=uid)
        r = c.chat.completions.create(
            model="grok-2-latest",
            messages=[{"role": "user", "content": "Reply with exactly: ok-b-grok"}],
            max_tokens=16,
        )
        text = (r.choices[0].message.content or "")[:200]
    return "ok" in text.lower(), text


def _pattern_c(provider: str, mak: str, keys: dict[str, str]) -> Tuple[bool, str]:
    from metricai.instrumentation import restore_instrumentation
    from metricai.runtime import init

    restore_instrumentation()
    from metricai.instrumentation import instrument

    init(
        api_key=mak,
        backend_endpoint=base_url(),
        llm_keys=keys,
        auto_instrument=False,
    )
    instrument(
        providers=[provider],
        openai_api_key=keys.get("openai"),
        anthropic_api_key=keys.get("anthropic"),
        gemini_api_key=keys.get("gemini"),
        grok_api_key=keys.get("grok"),
    )
    if provider == "openai" and "openai" not in keys:
        return False, "skip"
    if provider == "anthropic" and "anthropic" not in keys:
        return False, "skip"
    if provider == "gemini" and "gemini" not in keys:
        return False, "skip"
    if provider == "grok" and "grok" not in keys:
        return False, "skip"

    try:
        if provider == "anthropic":
            from anthropic import Anthropic

            c = Anthropic()
            r = c.messages.create(
                model="claude-haiku-4-5",
                max_tokens=32,
                messages=[{"role": "user", "content": "Reply with exactly: ok-c-claude"}],
            )
            text = ""
            for block in getattr(r, "content", []) or []:
                if getattr(block, "type", None) == "text":
                    text += getattr(block, "text", "")
            return "ok" in text.lower(), text[:200]
        from openai import OpenAI

        c = OpenAI()
        model = {
            "openai": "gpt-4o-mini",
            "gemini": "gemini-2.0-flash",
            "grok": "grok-2-latest",
        }[provider]
        r = c.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": f"Reply with exactly: ok-c-{provider}"}],
            max_tokens=16,
        )
        text = (r.choices[0].message.content or "")[:200]
        return "ok" in text.lower(), text
    finally:
        restore_instrumentation()


def main() -> int:
    from sdk_tests._common import _load_root_dotenv

    _load_root_dotenv()
    mak = require_metricai_api_key()
    keys = llm_keys_from_env()
    m = client()

    print(f"Proxy base: {base_url()}")
    print(f"BYOK keys present: {', '.join(sorted(keys)) or '(none)'}")

    rows: List[Tuple[str, str, bool, str]] = []

    def run(label: str, provider: str, fn: Callable[[], Tuple[bool, str]]) -> None:
        try:
            ok, detail = fn()
            rows.append((label, provider, ok, detail))
            status = "PASS" if ok else ("SKIP" if detail.startswith("skip") else "FAIL")
            print(f"  [{status}] {label} / {provider}: {detail[:120]}")
        except Exception as exc:
            rows.append((label, provider, False, str(exc)))
            print(f"  [FAIL] {label} / {provider}: {exc}")

    for prov, fn_a in [
        ("openai", lambda: _pattern_a_openai(mak, keys)),
        ("anthropic", lambda: _pattern_a_anthropic(mak, keys)),
        ("gemini", lambda: _pattern_a_gemini(mak, keys)),
    ]:
        run("A-raw", prov, fn_a)

    for prov in ("openai", "anthropic", "gemini", "grok"):
        run("B-factory", prov, lambda p=prov: _pattern_b(m, p))

    for prov in ("openai", "anthropic", "gemini", "grok"):
        run("C-instrument", prov, lambda p=prov: _pattern_c(p, mak, keys))

    try:
        m.validate_api_key()
        run("P-ping", "all", lambda: (True, "validate_api_key ok"))
    except Exception as exc:
        run("P-ping", "all", lambda: (False, str(exc)))

    failed = [r for r in rows if not r[2] and not r[3].startswith("skip")]
    skipped = [r for r in rows if r[3].startswith("skip")]
    passed = [r for r in rows if r[2]]

    print()
    print(f"Summary: {len(passed)} passed, {len(skipped)} skipped, {len(failed)} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
