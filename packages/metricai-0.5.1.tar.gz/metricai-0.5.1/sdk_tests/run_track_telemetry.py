"""
Manual ``track()`` calls: usage, outcome, ``timed_call``, and ``simulate=True`` (METRICAI_SDK.md §9).

Uses only ``METRICAI_API_KEY`` (no provider completion). Telemetry POSTs to the ingest path;
failures are logged unless ``raise_on_error=True``.

Run::

    cd metricai-sdk
    pip install -e .
    python -m sdk_tests.run_track_telemetry
"""

from __future__ import annotations

from sdk_tests._common import client_minimal


def main() -> int:
    from metricai import timed_call

    c = client_minimal()

    c.track(
        provider="openai",
        model="gpt-4o-mini",
        input_tokens=100,
        output_tokens=50,
        agent_id="sdk-track-demo",
        user_id="user-track-1",
    )

    c.track(
        provider="openai",
        model="gpt-4o-mini",
        outcome={
            "success": True,
            "outcome_type": "doc_summary",
            "charge_on_success_inr": 12.0,
            "charge_on_failure_inr": 0.0,
        },
        agent_id="sdk-outcome-demo",
        user_id="user-outcome-1",
    )

    with timed_call() as t:
        pass
    c.track(
        provider="openai",
        model="gpt-4o-mini",
        outcome={
            "success": True,
            "outcome_type": "sdk_smoke",
            "charge_on_success_inr": 1.0,
        },
        latency_ms=t.elapsed_ms,
        agent_id="sdk-timed",
        user_id="user-timed-1",
    )

    sim = c.track(
        simulate=True,
        provider="openai",
        model="gpt-4o-mini",
        outcome={"success": True, "charge_on_success_inr": 25.0},
    )
    if sim is not None:
        print("simulate:", getattr(sim, "would_charge_inr", sim))

    print("track telemetry script finished (check dashboard / logs for ingest).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
