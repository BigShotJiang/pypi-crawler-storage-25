"""
``MetricAISession`` context manager: aggregated turns and ``session_close`` (METRICAI_SDK.md §7).

Uses only ``METRICAI_API_KEY``.

Run::

    cd metricai-sdk
    pip install -e .
    python -m sdk_tests.run_metricai_session
"""

from __future__ import annotations

from sdk_tests._common import client_minimal


def main() -> int:
    c = client_minimal()

    with c.metricai_session(
        agent_id="sdk-session-demo",
        user_id="user-session-1",
        session_id=None,
    ) as s:
        s.track(
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=120,
            output_tokens=40,
            cost_inr=0.85,
        )
        s.track(
            provider="openai",
            model="gpt-4o-mini",
            input_tokens=30,
            output_tokens=10,
            cost_inr=0.1,
        )

    print("metricai_session block completed (session_close sent on exit).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
