"""Manual runnable scripts to exercise the MetricAI SDK (not pytest)."""
