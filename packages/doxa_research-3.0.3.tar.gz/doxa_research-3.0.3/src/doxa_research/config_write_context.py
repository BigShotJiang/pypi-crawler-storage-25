"""Shared write-target context for config file mutations."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from doxa_research.config import ConfigManager
from doxa_research.config_document import ConfigDocument
from doxa_research.config_profiles import ProfileLayer, collect_profile_catalog
from doxa_research.paths import user_config_file


class ConfigTargetConflictError(ValueError):
    """Raised when a write target is ambiguous by command options."""


@dataclass(frozen=True)
class ConfigWriteContext:
    """Resolved target and raw read context for config mutation commands.

    This class owns the write-target contract shared by config mutators:
    ``--project`` writes ``./doxa.config.toml``, ``--config PATH`` writes
    that path, and the default writes the user config file.
    """

    target_path: Path
    project: bool
    config_path: Path | None

    @classmethod
    def resolve(
        cls,
        *,
        project: bool,
        config_path: str | Path | None = None,
    ) -> ConfigWriteContext:
        normalized = Path(config_path).expanduser().resolve() if config_path else None
        if project and normalized is not None:
            raise ConfigTargetConflictError("--config cannot be used with --project")

        if project:
            target_path = Path.cwd() / "doxa.config.toml"
        elif normalized is not None:
            target_path = normalized
        else:
            target_path = user_config_file()

        return cls(target_path=target_path, project=project, config_path=normalized)

    def load_document(self) -> ConfigDocument:
        """Load the target document for mutation."""
        return ConfigDocument.load(self.target_path)

    def raw_profile_catalog(self) -> list[ProfileLayer]:
        """Collect profiles without resolving the currently selected profile."""
        manager = ConfigManager(self.config_path)
        user_raw = (
            manager._load_toml_file(manager.user_config_path)
            if manager.user_config_path.exists()
            else {}
        )
        project_raw, project_path = manager._load_project_config_with_path()
        return collect_profile_catalog(
            user_config=user_raw,
            project_config=project_raw,
            user_path=manager.user_config_path,
            project_path=project_path,
        )

    def target_has_profile(self, name: str) -> bool:
        """Return True iff `[profiles.<name>]` exists in the target file.

        Same-tier check used by P35's `modes set-default --profile X` rule.
        Inspects ONLY the target file — does not consider the merged
        catalog across user/project tiers.
        """
        if not self.target_path.exists():
            return False
        return self.load_document().has_profile(name)


__all__ = ["ConfigTargetConflictError", "ConfigWriteContext"]
