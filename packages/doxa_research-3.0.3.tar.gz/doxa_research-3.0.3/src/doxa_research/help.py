"""Command-specific help text renderers."""

from __future__ import annotations

import difflib
import re
import sys
import warnings

import click
from rich.console import Console

console = Console()


# Two-section split for the Click group help renderer.
RUN_COMMANDS: tuple[str, ...] = ("ask", "resume", "cancel", "status", "list")
ADMIN_COMMANDS: tuple[str, ...] = (
    "init",
    "config",
    "modes",
    "providers",
    "completion",
    "help",
)


# P36 Layer 1: curated typed-token → full-invocation map for the
# unknown-command did-you-mean suggestion. Captures cases where the user
# typed a leaf name from a multi-level command path (e.g. `profiles`,
# which lives at `doxa config profiles`).
_KNOWN_SUBPATHS: dict[str, str] = {
    "profiles": "doxa config profiles",
    "profile": "doxa config profiles",
    "set": "doxa config set",
    "get": "doxa config get",
    "unset": "doxa config unset",
    "path": "doxa config path",
    "edit": "doxa config edit",
    "add": "doxa modes add",
    "remove": "doxa modes remove",
    "rename": "doxa modes rename",
    "copy": "doxa modes copy",
}


# P36 Layer 1: a "single token that looks like a command name" is
# overwhelmingly a typo, not a research prompt. Multi-token strings,
# quoted strings with spaces, and option-only invocations preserve
# the existing bare-prompt fallback.
_COMMAND_NAME_RE = re.compile(r"^[a-z][a-z0-9_-]*$")


def _suggest_command(typed: str, registered: list[str]) -> str | None:
    """Return a 'doxa ...' suggestion string, or None if no good match."""
    if typed in _KNOWN_SUBPATHS:
        return _KNOWN_SUBPATHS[typed]
    matches = difflib.get_close_matches(typed, registered, n=1, cutoff=0.7)
    if matches:
        return f"doxa {matches[0]}"
    return None


def _format_unknown_command_error(
    typed: str,
    registered: list[str],
    registered_run: list[str],
    registered_admin: list[str],
) -> str:
    """Render the structured 'unknown command' error body.

    Output format matches the design notes in
    docs/superpowers/plans/2026-05-01-help-uniform-errors.md.
    The suggestion paragraph is omitted entirely if no good match exists.
    """
    lines: list[str] = [f"Error: unknown command '{typed}'", ""]
    suggestion = _suggest_command(typed, registered)
    if suggestion is not None:
        lines.append(f"Did you mean '{suggestion}'?")
        lines.append("")
    lines.append("Available top-level commands:")
    if registered_run:
        lines.append(f"  Run research:  {', '.join(registered_run)}")
    if registered_admin:
        lines.append(f"  Manage doxa-research:  {', '.join(registered_admin)}")
    lines.append("")
    lines.append("Run `doxa --help` for the full command list and options.")
    return "\n".join(lines)


def _run_research_default(*args, **kwargs):
    # Lazy import to avoid circular import (cli.py imports from help.py)
    from doxa_research.cli import _run_research_default as _impl

    return _impl(*args, **kwargs)


def _dispatch_click_fallback(ctx: click.Context, args: list[str]):
    # Lazy import to avoid circular import (cli.py imports DoxaGroup).
    from doxa_research.cli import _dispatch_click_fallback as _impl

    return _impl(ctx, args, _run_research_default)


def _visible_help_context(ctx: click.Context | None) -> click.Context | None:
    while ctx is not None and getattr(ctx.command, "hidden", False):
        ctx = ctx.parent
    return ctx


class HelpFirstUsageError(click.UsageError):
    """Usage error that renders the most specific command help before the error."""

    def __init__(
        self,
        original: click.UsageError,
        *,
        fallback_ctx: click.Context | None = None,
    ):
        self.original = original
        help_ctx = _visible_help_context(original.ctx) or fallback_ctx
        super().__init__(original.format_message(), ctx=help_ctx)

    def format_message(self) -> str:
        return self.original.format_message()

    def show(self, file=None) -> None:
        if file is None:
            file = sys.stderr
        if self.ctx is not None:
            click.echo(self.ctx.get_help(), file=file)
            click.echo(file=file)
        click.echo(f"Error: {self.format_message()}", file=file)


def _help_first_usage_error(
    error: click.UsageError,
    *,
    fallback_ctx: click.Context | None = None,
) -> HelpFirstUsageError:
    if isinstance(error, HelpFirstUsageError):
        return error
    return HelpFirstUsageError(error, fallback_ctx=fallback_ctx)


class DoxaGroup(click.Group):
    """Top-level Click group for `doxa_research`.

    Adds three behaviors a stock click.Group can't provide:
      1. resolve_command returns None instead of raising on unknown args
         (so invoke can dispatch mode-positional or bare-prompt fallback).
      2. invoke routes positional mode names to the research path.
      3. invoke routes bare prompts to default-mode research.

    The two-section help renderer is added in Task 11.
    """

    def parse_args(self, ctx: click.Context, args: list[str]):
        # Q6-PR2-C1: legacy --resume / -R flag is gated to the new subcommand.
        # Scan the raw argv BEFORE delegating to super().parse_args so we can
        # emit a Click-native error with the migration hint on stderr.
        for token in args:
            if token in ("--resume", "-R") or token.startswith("--resume="):
                ctx.fail("no such option: --resume (use 'doxa resume OP_ID')")
        return super().parse_args(ctx, args)

    def resolve_command(self, ctx: click.Context, args: list[str]):
        try:
            return super().resolve_command(ctx, args)
        except click.UsageError:
            # Caller (invoke) will handle mode-positional and bare-prompt cases.
            return None, None, args

    def invoke(self, ctx: click.Context):
        # Imported lazily so tests can monkeypatch doxa_research.config.BUILTIN_MODES.
        from doxa_research.config import BUILTIN_MODES

        # ctx.protected_args is required in Click 8.x for group dispatch (ctx.args
        # only holds the first token). Deprecated in Click 9.0; revisit when we
        # bump Click. Suppressed narrowly to avoid noise in user output / CI logs.
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message=r".*protected_args.*",
                category=DeprecationWarning,
            )
            args = list(ctx.protected_args) + list(ctx.args)
        if args:
            first = args[0]
            help_requested = ("--help" in args) or ("-h" in args)
            # P36 Layer 1: --help/-h short-circuit. Registered subcommands
            # and builtin modes still flow through their own dispatch (Click
            # handles --help natively for registered commands; the mode
            # dispatcher owns mode help). Anything else is a typo and gets
            # the structured "unknown command" error rather than the
            # misleading API-key error from the bare-prompt fallback.
            if help_requested and first not in self.commands and first not in BUILTIN_MODES:
                self._emit_unknown_command_error(ctx, first)
            # P36 Layer 1: single-token unknown command (no --help). Match
            # the command-name shape so multi-token / quoted / option-only
            # bare prompts still route through the research fallback.
            if (
                len(args) == 1
                and not first.startswith("-")
                and _COMMAND_NAME_RE.match(first)
                and first not in self.commands
                and first not in BUILTIN_MODES
            ):
                self._emit_unknown_command_error(ctx, first)
            # Path 1: registered subcommand → standard dispatch
            if first in self.commands:
                try:
                    return super().invoke(ctx)
                except click.UsageError as error:
                    raise _help_first_usage_error(error, fallback_ctx=ctx) from error
            # Path 2: positional mode dispatch
            if first in BUILTIN_MODES:
                return _dispatch_click_fallback(ctx, args)
            # Path 3: bare-prompt fallback (whole arg vector is the prompt)
            return _dispatch_click_fallback(ctx, args)
        # No args: option-only research/resume/interactive fallback.
        return _dispatch_click_fallback(ctx, args)

    def _emit_unknown_command_error(self, ctx: click.Context, typed: str):
        """Print the structured 'unknown command' error and exit 2."""
        registered = sorted(self.commands.keys())
        registered_run = [n for n in RUN_COMMANDS if n in self.commands]
        registered_admin = [n for n in ADMIN_COMMANDS if n in self.commands]
        message = _format_unknown_command_error(typed, registered, registered_run, registered_admin)
        click.echo(message, err=True)
        ctx.exit(2)

    def format_commands(self, ctx: click.Context, formatter):
        """Render commands in two sections: Run research / Manage doxa_research."""
        registered = set(self.commands.keys())

        run_rows = [
            (name, self.commands[name].get_short_help_str(limit=60))
            for name in RUN_COMMANDS
            if name in registered
        ]
        admin_rows = [
            (name, self.commands[name].get_short_help_str(limit=60))
            for name in ADMIN_COMMANDS
            if name in registered
        ]

        if run_rows:
            with formatter.section("Run research"):
                formatter.write_dl(run_rows)
        if admin_rows:
            with formatter.section("Manage doxa_research"):
                formatter.write_dl(admin_rows)

    def format_epilog(self, ctx: click.Context, formatter):
        """Render the modes-positional epilog block + worked examples."""
        from doxa_research.config import BUILTIN_MODES

        with formatter.section("Modes (positional)"):
            modes_str = ", ".join(sorted(BUILTIN_MODES))
            formatter.write_text(f"Pass as the first positional argument: {modes_str}")
            formatter.write_paragraph()
            formatter.write_text("Run `doxa modes` for provider, model, and kind per mode.")
            formatter.write_paragraph()
            formatter.write_text('Example: doxa deep_research "explain transformers"')

        with formatter.section("Workflow chain"):
            formatter.write_text(
                "clarification → exploration → deep_dive → tutorial → solution → prd → tdd"
            )

        with formatter.section("Examples"):
            formatter.write_text('doxa "how does DNS work"')
            formatter.write_text('doxa clarification "k8s networking" --project k8s')
            formatter.write_text("doxa deep_research --auto --project k8s --async")
            formatter.write_text("doxa resume op_abc123")
            formatter.write_text("doxa cancel op_abc123")
            formatter.write_text('Debug API issues: doxa deep_research "topic" -v')

        super().format_epilog(ctx, formatter)


def show_config_help():
    """Show detailed help for the config command."""
    console.print("\n[bold]doxa config[/bold] - Inspect and edit configuration")
    console.print("\n[bold]Usage:[/bold]")
    console.print("  doxa config <OP> [ARGS...]")
    console.print("\n[bold]Ops:[/bold]")
    console.print("  get <KEY> [--layer L] [--raw] [--json] [--show-secrets]")
    console.print("     Print a single value from the merged config.")
    console.print("  set <KEY> <VALUE> [--project] [--string]")
    console.print("     Write a value to the user config (or project with --project).")
    console.print("  unset <KEY> [--project]")
    console.print("     Remove a key from the target file (empty tables are pruned).")
    console.print("  list [--layer L] [--keys] [--json] [--show-secrets]")
    console.print("     Print the merged config (or a single layer).")
    console.print("  path [--project]")
    console.print("     Print the target config file path.")
    console.print("  edit [--project]")
    console.print("     Open the target config file in $EDITOR (fallback: vi).")
    console.print("  profiles <SUBCOMMAND>")
    console.print("     Manage configuration profiles (list/show/current/add/set/unset/")
    console.print("     remove/set-default/unset-default). Run `doxa config profiles --help`.")
    console.print("  help")
    console.print("     Show this help.")
    console.print("\n[bold]Examples:[/bold]")
    console.print("  $ doxa config get general.default_mode")
    console.print("  $ doxa config set general.default_mode exploration")
    console.print("  $ doxa config set --project execution.poll_interval 15")
    console.print("  $ doxa config list --keys")
    console.print("  $ doxa config path")
    console.print("  $ doxa config profiles list")
    console.print("  $ doxa config profiles current")
    console.print("  $ doxa config profiles add fast")
    console.print("  $ doxa config profiles set fast general.default_mode thinking")
    console.print("  $ doxa config profiles set-default fast")
    console.print("\n[bold]Notable keys:[/bold]")
    console.print("  execution.prompt_max_bytes  Cap on --prompt-file / stdin bytes")
    console.print("                              (default: 1048576 = 1 MiB)")
    console.print("\n[bold]Profile selection:[/bold]")
    console.print("  --profile NAME (also DOXA_PROFILE env, or general.default_profile in config)")
    console.print("  Profile sections live under [profiles.<name>] and overlay top-level config.")
    console.print(
        "  Manage profiles with `doxa config profiles ...` (read-only leaves honor --profile;"
    )
    console.print("  mutator leaves take the profile name as a positional argument).")
    console.print("\n[bold]Notes:[/bold]")
    console.print("  API key values are masked by default; use --show-secrets to reveal.")
    console.print("  Writes preserve comments and formatting of the target TOML file.")


def render_auth_help() -> str:
    return (
        "Authentication — recommended order:\n"
        "\n"
        "1. Environment variables (recommended):\n"
        "     export OPENAI_API_KEY=sk-...\n"
        "     export PERPLEXITY_API_KEY=pplx-...\n"
        "     export GEMINI_API_KEY=AIza...\n"
        "\n"
        "2. Config file (persistent, per-machine): ~/.config/doxa_research/doxa.config.toml\n"
        "     [providers.openai]\n"
        '     api_key = "sk-..."\n'
        "     [providers.perplexity]\n"
        '     api_key = "pplx-..."\n'
        "     [providers.gemini]\n"
        '     api_key = "AIza..."\n'
        "\n"
        "3. CLI flags (last resort — exposes keys in shell history; not recommended):\n"
        '     doxa --api-key-openai sk-... deep_research "..."\n'
        '     doxa --api-key-gemini AIza... ask --mode gemini_quick "..."\n'
    )


def show_auth_help() -> None:
    console.print(render_auth_help(), markup=False)


__all__ = [
    "ADMIN_COMMANDS",
    "RUN_COMMANDS",
    "DoxaGroup",
    "render_auth_help",
    "show_auth_help",
    "show_config_help",
]
