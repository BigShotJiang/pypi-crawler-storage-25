"""`doxa resume OP_ID` Click subcommand.

Per Q1-PR2-C (Tight + Honor) accepts a focused set of options:
  --verbose / -v
  --config / -c PATH
  --quiet / -Q
  --no-metadata
  --timeout / -T SECS
  --api-key-{openai,perplexity,mock} VALUE

All other globals are naturally rejected by Click (they are not declared
on this subcommand).
"""

from __future__ import annotations

import click

from doxa_research.cli_subcommands._option_policy import (
    DEFAULT_HONOR,
    inherited_api_keys,
    validate_inherited_options,
)
from doxa_research.completion.sources import operation_ids as _operation_ids_completer

_RESUME_HONOR = DEFAULT_HONOR | {
    "verbose",
    "quiet",
    "no_metadata",
    "timeout",
    "api_key_openai",
    "api_key_perplexity",
    "api_key_mock",
    "cancel_on_interrupt",
}


@click.command(name="resume")
@click.argument("operation_id", metavar="OP_ID", shell_complete=_operation_ids_completer)
@click.option("--verbose", "-v", is_flag=True, help="Enable debug output")
@click.option("--config", "-c", "config_path", help="Path to custom config file")
@click.option("--quiet", "-Q", is_flag=True, help="Minimal output during execution")
@click.option(
    "--no-metadata",
    is_flag=True,
    help="Disable metadata headers and prompt section in output files",
)
@click.option("--timeout", "-T", type=float, help="Override request timeout in seconds")
@click.option("--api-key-openai", help="API key for OpenAI provider")
@click.option("--api-key-perplexity", help="API key for Perplexity provider")
@click.option("--api-key-mock", help="API key for Mock provider")
@click.option(
    "--cancel-on-interrupt/--no-cancel-on-interrupt",
    "cancel_on_interrupt",
    default=None,
    help=(
        "On Ctrl-C during the resume polling loop, also cancel the upstream "
        "provider job (default: per [execution].cancel_upstream_on_interrupt "
        "config, default true)."
    ),
)
@click.option(
    "--async",
    "-A",
    "async_check",
    is_flag=True,
    help=(
        "Do one status check per provider, save any newly-completed results, "
        "and exit without entering the polling loop. Combine with --json to "
        "emit a snapshot envelope including a `newly_completed` field."
    ),
)
@click.option("--json", "as_json", is_flag=True, help="Emit JSON snapshot envelope")
@click.pass_context
def resume(
    ctx: click.Context,
    operation_id: str,
    verbose: bool,
    config_path: str | None,
    quiet: bool,
    no_metadata: bool,
    timeout: float | None,
    api_key_openai: str | None,
    api_key_perplexity: str | None,
    api_key_mock: str | None,
    cancel_on_interrupt: bool | None,
    async_check: bool,
    as_json: bool,
) -> None:
    """Resume a previously-checkpointed operation by ID."""
    validate_inherited_options(ctx, "resume", _RESUME_HONOR)

    # Local import: avoids cli.py → cli_subcommands → cli.py circular at module load.
    import doxa_research.run as _doxa_run
    from doxa_research.cli import _apply_config_path, _build_app_context, _run_maybe_async

    if as_json:
        import asyncio as _asyncio
        import contextlib as _ctx_mod
        import io as _io

        from doxa_research.json_output import emit_error, emit_json

        effective_config = config_path or (ctx.obj or {}).get("config_path")
        _apply_config_path(effective_config)

        # Verify the operation exists BEFORE doing any work (envelope path
        # for missing-op exits 6 same as the non-json path).
        data = _doxa_run.get_resume_snapshot_data(operation_id)
        if data is None:
            emit_error(
                "OPERATION_NOT_FOUND",
                f"Operation {operation_id} not found",
                {"operation_id": operation_id},
                exit_code=6,
            )
        if data["status"] == "failed_permanent":
            emit_error(
                "OPERATION_FAILED_PERMANENTLY",
                data["last_error"] or "operation failed permanently",
                data,
                exit_code=7,
            )

        if async_check:
            # P18-T38: do one tick, then emit snapshot + newly_completed.
            inherited = ctx.obj or {}
            root_api_keys_local = inherited_api_keys(ctx)
            tick_app_ctx = _build_app_context(False, as_json=True)
            tick_cli_keys = {
                "openai": api_key_openai or root_api_keys_local["openai"],
                "perplexity": api_key_perplexity or root_api_keys_local["perplexity"],
                "mock": api_key_mock or root_api_keys_local["mock"],
            }
            sink = _io.StringIO()
            tick: dict | None = None
            try:
                with _ctx_mod.redirect_stdout(sink), _ctx_mod.redirect_stderr(sink):
                    tick = _asyncio.run(
                        _doxa_run.resume_operation(
                            operation_id,
                            False,
                            ctx=tick_app_ctx,
                            quiet=True,
                            no_metadata=bool(no_metadata or inherited.get("no_metadata")),
                            timeout_override=(
                                timeout if timeout is not None else inherited.get("timeout")
                            ),
                            cli_api_keys=tick_cli_keys,
                            async_check=True,
                        )
                    )
            except SystemExit as exc:
                if exc.code not in (None, 0):
                    emit_error(
                        "RESUME_FAILED",
                        f"resume --async failed (exit {exc.code})",
                        {"operation_id": operation_id, "exit_code": exc.code},
                        exit_code=exc.code if isinstance(exc.code, int) else 1,
                    )
            # Re-snapshot to pick up checkpoint changes from the tick.
            data = _doxa_run.get_resume_snapshot_data(operation_id) or data
            data["newly_completed"] = (
                list(tick.get("newly_completed", [])) if tick is not None else []
            )

        emit_json(data)

    # Group-level inheritance for honored values per Q1-PR2-C
    inherited = ctx.obj or {}
    effective_verbose = bool(verbose or inherited.get("verbose"))
    effective_quiet = bool(quiet or inherited.get("quiet"))
    effective_no_metadata = bool(no_metadata or inherited.get("no_metadata"))
    effective_timeout = timeout if timeout is not None else inherited.get("timeout")
    effective_config = config_path or inherited.get("config_path")
    effective_cancel_on_interrupt = (
        cancel_on_interrupt
        if cancel_on_interrupt is not None
        else inherited.get("cancel_on_interrupt")
    )
    root_api_keys = inherited_api_keys(ctx)
    cli_api_keys = {
        "openai": api_key_openai or root_api_keys["openai"],
        "perplexity": api_key_perplexity or root_api_keys["perplexity"],
        "mock": api_key_mock or root_api_keys["mock"],
    }

    _apply_config_path(effective_config)
    app_ctx = _build_app_context(
        effective_verbose, cancel_on_interrupt=effective_cancel_on_interrupt
    )
    _run_maybe_async(
        _doxa_run.resume_operation(
            operation_id,
            effective_verbose,
            ctx=app_ctx,
            quiet=effective_quiet,
            no_metadata=effective_no_metadata,
            timeout_override=effective_timeout,
            cli_api_keys=cli_api_keys,
            async_check=async_check,
        )
    )


__all__ = ["resume"]
