"""Tests for QtiClient initialization and configuration."""

import os
from unittest.mock import patch

import pytest

from timeback_qti import QtiClient


class TestQtiClientInit:
    """Tests for client initialization."""

    def test_staging_environment(self):
        """Staging environment should use staging URL."""
        client = QtiClient(env="staging", client_id="id", client_secret="secret")
        assert "qti" in client._transport.base_url or "staging" in client._transport.base_url

    def test_production_environment(self):
        """Production environment should use production URL."""
        client = QtiClient(env="production", client_id="id", client_secret="secret")
        assert "dev" not in client._transport.base_url
        assert "staging" not in client._transport.base_url

    def test_custom_base_url(self):
        """Custom base URL should override environment."""
        with patch.dict(
            os.environ,
            {
                "QTI_CLIENT_ID": "id",
                "QTI_CLIENT_SECRET": "secret",
                "QTI_TOKEN_URL": "https://auth.example.com/oauth2/token",
            },
        ):
            client = QtiClient(
                base_url="https://custom.example.com",
                auth_url="https://auth.example.com/oauth2/token",
            )
            assert client._transport.base_url == "https://custom.example.com"

    def test_explicit_credentials(self):
        """Explicit credentials should work."""
        client = QtiClient(
            env="staging",
            client_id="my-id",
            client_secret="my-secret",
        )
        assert client._provider is not None
        tm = client._provider.get_token_manager("qti")
        assert tm is not None
        assert tm._config.client_id == "my-id"
        assert tm._config.client_secret == "my-secret"

    def test_missing_credentials_raises(self):
        """Missing credentials should raise ValueError."""
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("QTI_CLIENT_ID", None)
            os.environ.pop("QTI_CLIENT_SECRET", None)
            os.environ.pop("TIMEBACK_API_CLIENT_ID", None)
            os.environ.pop("TIMEBACK_API_CLIENT_SECRET", None)
            os.environ.pop("TIMEBACK_CLIENT_ID", None)
            os.environ.pop("TIMEBACK_CLIENT_SECRET", None)
            with pytest.raises(ValueError, match="Missing required environment variable"):
                QtiClient(env="staging")

    def test_default_platform_is_beyond_ai(self):
        """Default platform should be BEYOND_AI."""
        client = QtiClient(env="staging", client_id="id", client_secret="secret")
        assert "qti" in client._transport.base_url or "alpha-1edtech" in client._transport.base_url

    def test_beyond_ai_platform(self):
        """BEYOND_AI platform should succeed."""
        client = QtiClient(
            platform="BEYOND_AI",
            env="staging",
            client_id="id",
            client_secret="secret",
        )
        assert client._transport.base_url is not None

    def test_custom_provider(self):
        """Custom base URL and auth should work."""
        client = QtiClient(
            base_url="https://custom.api.com",
            auth_url="https://custom.auth.com/token",
            client_id="test-id",
            client_secret="test-secret",
        )
        assert client._transport.base_url == "https://custom.api.com"


class TestQtiClientResources:
    """Tests for client resource initialization."""

    def test_all_resources_initialized(self):
        """Client should initialize all resources."""
        client = QtiClient(env="staging", client_id="id", client_secret="secret")

        assert hasattr(client, "assessment_items")
        assert hasattr(client, "assessment_tests")
        assert hasattr(client, "stimuli")
        assert hasattr(client, "validate")
        assert hasattr(client, "lesson")
        assert hasattr(client, "general")


class TestQtiClientTransport:
    """Tests for transport access."""

    def test_get_transport(self):
        """Client should expose transport via get_transport()."""
        client = QtiClient(env="staging", client_id="id", client_secret="secret")

        transport = client.get_transport()
        assert transport is not None
        assert transport.base_url is not None


class TestQtiClientCheckAuth:
    """Tests for check_auth."""

    @pytest.mark.asyncio
    async def test_check_auth_raises_without_provider(self):
        """check_auth should raise when no provider is set (custom transport)."""

        from timeback_common import QtiPaths

        class MockTransport:
            base_url = "https://mock.api.com"
            paths = QtiPaths()

            async def close(self) -> None:
                pass

        client = QtiClient(transport=MockTransport())

        with pytest.raises(RuntimeError, match="Cannot check auth"):
            await client.check_auth()


class TestQtiClientContextManager:
    """Tests for context manager support."""

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Client should work as async context manager."""
        async with QtiClient(env="staging", client_id="id", client_secret="secret") as client:
            assert client._provider is not None
