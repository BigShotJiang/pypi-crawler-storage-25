"""Fixture-driven tests for QTI lesson resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_qti.lib.testing import create_recording_transport
from timeback_qti.resources.lesson import LessonResource

FIXTURES_DIR = fixtures_dir("qti", "lesson")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": LessonResource(transport), "calls": transport.calls}


test_qti_lesson_fixtures = make_resource_fixture_test(
    name="qti > lesson",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
