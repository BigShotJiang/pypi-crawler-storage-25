"""Fixture-driven tests for QTI validate resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_qti.lib.testing import create_recording_transport
from timeback_qti.resources.validate import ValidateResource

FIXTURES_DIR = fixtures_dir("qti", "validate")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": ValidateResource(transport), "calls": transport.calls}


test_qti_validate_fixtures = make_resource_fixture_test(
    name="qti > validate",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
