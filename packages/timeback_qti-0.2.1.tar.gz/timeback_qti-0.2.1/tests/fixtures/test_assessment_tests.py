"""Fixture-driven tests for QTI assessment tests resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_qti.lib.testing import create_recording_transport
from timeback_qti.resources.assessment_tests import AssessmentTestsResource

FIXTURES_DIR = fixtures_dir("qti", "assessment-tests")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": AssessmentTestsResource(transport), "calls": transport.calls}


test_qti_assessment_tests_fixtures = make_resource_fixture_test(
    name="qti > assessment-tests",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
