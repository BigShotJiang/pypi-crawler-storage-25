"""QTI transport and pagination utilities."""
