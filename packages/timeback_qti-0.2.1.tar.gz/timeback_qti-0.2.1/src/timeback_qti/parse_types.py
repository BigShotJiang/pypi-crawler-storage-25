"""
QTI Parse Types

Type definitions for QTI XML parsing utilities.
"""

from __future__ import annotations

from pydantic import BaseModel


class QtiChoice(BaseModel):
    """A single choice option extracted from a `<qti-simple-choice>` element."""

    identifier: str
    text: str


class QtiInlineFeedback(BaseModel):
    """Inline feedback extracted from a `<qti-feedback-inline>` element."""

    outcome_identifier: str
    identifier: str
    show_hide: str
    content: str


class QtiModalFeedback(BaseModel):
    """Modal feedback extracted from a `<qti-modal-feedback>` element."""

    outcome_identifier: str
    identifier: str
    show_hide: str
    content: str


class QtiInteractionAttributes(BaseModel):
    """Attributes from a `<qti-choice-interaction>` element."""

    response_identifier: str
    shuffle: bool
    max_choices: int


class QtiResponseDeclaration(BaseModel):
    """Response declaration extracted from a `<qti-response-declaration>` element."""

    identifier: str
    cardinality: str
    base_type: str | None


class ParsedQtiItem(BaseModel):
    """Complete parsed result from a QTI assessment item XML string."""

    prompt: str
    choices: list[QtiChoice]
    correct_answer: str | None
    feedback: list[QtiInlineFeedback]
    modal_feedback: list[QtiModalFeedback]
    interaction: QtiInteractionAttributes | None
    response_declaration: QtiResponseDeclaration | None
