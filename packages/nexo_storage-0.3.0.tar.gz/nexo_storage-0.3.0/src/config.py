from typing import Annotated

from pydantic import BaseModel, Field


class StorageConfigMixin[T: BaseModel | None](BaseModel):
    storage: Annotated[T, Field(..., description="Storage config")]
