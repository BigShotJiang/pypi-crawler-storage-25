import io
from copy import deepcopy
from datetime import UTC, datetime, timedelta
from typing import Annotated
from uuid import uuid4

from nexo.database.enums import Connection
from nexo.database.handlers import RedisHandler
from nexo.database.utils import build_cache_key
from nexo.enums.expiration import Expiration
from nexo.logging.config import LogConfig
from nexo.logging.logger import Client as ClientLogger
from nexo.schemas.application import ApplicationContext, OptApplicationContext
from nexo.schemas.bus import ListOfAnyPublishers
from nexo.schemas.connection import OptConnectionContext
from nexo.schemas.error.enums import ErrorCode
from nexo.schemas.exception.factory import MaleoExceptionFactory
from nexo.schemas.extractor import extract_details
from nexo.schemas.operation.context import DefaultOperationContext
from nexo.schemas.operation.enums import OperationType
from nexo.schemas.operation.enums import Target as OperationTarget
from nexo.schemas.operation.mixins import Timestamp
from nexo.schemas.operation.resource import (
    CreateResourceOperationAction,
    CreateSingleResourceOperation,
    ReadResourceOperationAction,
    ReadSingleResourceOperation,
)
from nexo.schemas.resource import AggregateField, ResourceIdentifier
from nexo.schemas.response import SingleDataResponse
from nexo.schemas.security.authentication import OptAnyAuthentication
from nexo.schemas.security.authorization import OptAnyAuthorization
from nexo.schemas.security.impersonation import OptImpersonation
from nexo.types.string import OptStr
from nexo.types.uuid import OptUUID
from pydantic import Field

from minio import Minio
from minio.error import S3Error
from minio.helpers import DictType

from .common import STORAGE_RESOURCE
from .enums import Disposition
from .schemas import Asset, BucketName

MINIO_STORAGE_RESOURCE = deepcopy(STORAGE_RESOURCE)
MINIO_STORAGE_RESOURCE.identifiers.append(
    ResourceIdentifier(
        key="minio",
        name="MinIO",
        slug="minio",
    )
)


class MinIOConfig(BucketName):
    endpoint: Annotated[str, Field(..., description="MinIO server endpoint")]
    access_key: Annotated[str, Field(..., description="MinIO access key")]
    secret_key: Annotated[str, Field(..., description="MinIO secret key")]
    secure: Annotated[bool, Field(True, description="Use HTTPS")] = True


class MinIOStorage:
    def __init__(
        self,
        config: MinIOConfig,
        log_config: LogConfig,
        *,
        application_context: OptApplicationContext = None,
        redis: RedisHandler,
        publishers: ListOfAnyPublishers,
    ) -> None:
        self._config = config

        self._application_context = (
            application_context
            if application_context is not None
            else ApplicationContext.new()
        )

        self._logger = ClientLogger(
            log_config,
            environment=self._application_context.environment,
            service_key=self._application_context.service_key,
            client_key=MINIO_STORAGE_RESOURCE.identifiers[-1].key,
        )

        self._operation_context = DefaultOperationContext.CLIENT_SERVICE_INTERNAL.value

        self._client = Minio(**self._config.model_dump(exclude={"bucket_name"}))

        if not self._client.bucket_exists(self._config.bucket_name):
            raise ValueError(f"Bucket '{self._config.bucket_name}' does not exist.")

        self._redis = redis
        self._namespace = self._redis.config.build_client_namespace(
            MINIO_STORAGE_RESOURCE.aggregate(AggregateField.KEY, sep=":"),
            client=MINIO_STORAGE_RESOURCE.identifiers[-1].key,
        )

        self._publishers = publishers
        self._root_location = self._application_context.service_key

    def _resolve_object_name(
        self,
        location: str,
        root_location_override: OptStr = None,
    ) -> str:
        if root_location_override is None or (
            isinstance(root_location_override, str) and len(root_location_override) <= 0
        ):
            return f"{self._root_location}/{location}"
        return f"{root_location_override}/{location}"

    async def upload(
        self,
        content: bytes,
        location: str,
        content_type: OptStr = None,
        *,
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        root_location_override: OptStr = None,
        make_public: bool = False,
        expiration: Expiration = Expiration.EXP_15MN,
    ) -> SingleDataResponse[Asset, None]:
        operation_id = operation_id if operation_id is not None else uuid4()
        operation_action = CreateResourceOperationAction()
        executed_at = datetime.now(tz=UTC)

        object_name = self._resolve_object_name(location, root_location_override)

        resource = deepcopy(MINIO_STORAGE_RESOURCE)
        resource.details = {"location": location, "object_name": object_name}

        try:
            data = io.BytesIO(content)
            self._client.put_object(
                bucket_name=self._config.bucket_name,
                object_name=object_name,
                data=data,
                length=len(content),
                content_type=content_type or "text/plain",
            )

            if make_public:
                # MinIO public URL — no signing, direct endpoint access
                scheme = "https" if self._config.secure else "http"
                url = f"{scheme}://{self._config.endpoint}/{self._config.bucket_name}/{object_name}"
            else:
                url = self._client.presigned_get_object(
                    bucket_name=self._config.bucket_name,
                    object_name=object_name,
                    expires=timedelta(seconds=expiration.value),
                )

            client = self._redis.manager.client.get(Connection.ASYNC)
            cache_key = build_cache_key(object_name, namespace=self._namespace)
            await client.set(name=cache_key, value=url, ex=expiration.value)

            asset = Asset(url=url)
            response = SingleDataResponse[Asset, None].new(data=asset)
            operation = CreateSingleResourceOperation[Asset, None](
                application_context=self._application_context,
                id=operation_id,
                is_ai=is_ai,
                context=self._operation_context,
                action=operation_action,
                timestamp=Timestamp.completed_now(executed_at),
                summary=f"Successfully uploaded object to '{location}'",
                connection_context=connection_context,
                authentication=authentication,
                authorization=authorization,
                impersonation=impersonation,
                resource=resource,
                response=response,
            )
            operation.log_and_publish(self._logger, self._publishers)
            return response

        except Exception as e:
            exc = MaleoExceptionFactory.from_code(
                ErrorCode.INTERNAL_SERVER_ERROR,
                details=extract_details(e),
                operation_type=OperationType.RESOURCE,
                application_context=self._application_context,
                operation_id=operation_id,
                is_ai_operation=is_ai,
                operation_context=self._operation_context,
                operation_action=operation_action,
                resource=resource,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary=f"Error raised while uploading to '{location}'",
                connection_context=connection_context,
                authentication=authentication,
                authorization=authorization,
                impersonation=impersonation,
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            raise exc from e

    async def generate_signed_url(
        self,
        location: str,
        disposition: Disposition = Disposition.ATTACHMENT,
        filename: OptStr = None,
        *,
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        root_location_override: OptStr = None,
        use_cache: bool = True,
        expiration: Expiration = Expiration.EXP_15MN,
    ) -> SingleDataResponse[Asset, None]:
        operation_id = operation_id if operation_id is not None else uuid4()
        operation_action = ReadResourceOperationAction()
        executed_at = datetime.now(tz=UTC)

        object_name = self._resolve_object_name(location, root_location_override)

        resource = deepcopy(MINIO_STORAGE_RESOURCE)
        resource.details = {"location": location, "object_name": object_name}

        if use_cache:
            client = self._redis.manager.client.get(Connection.ASYNC)
            cache_key = build_cache_key(object_name, namespace=self._namespace)
            url = await client.get(cache_key)
            if url is not None:
                operation_context = deepcopy(self._operation_context)
                operation_context.target.type = OperationTarget.CACHE
                asset = Asset(url=url)
                response = SingleDataResponse[Asset, None].new(data=asset)
                operation = ReadSingleResourceOperation[Asset, None](
                    application_context=self._application_context,
                    id=operation_id,
                    is_ai=is_ai,
                    context=operation_context,
                    action=operation_action,
                    resource=resource,
                    timestamp=Timestamp.completed_now(executed_at),
                    summary=f"Retrieved signed url for '{location}' from cache",
                    connection_context=connection_context,
                    authentication=authentication,
                    authorization=authorization,
                    impersonation=impersonation,
                    response=response,
                )
                operation.log_and_publish(self._logger, self._publishers)
                return response

        # Check object existence via stat
        try:
            self._client.stat_object(self._config.bucket_name, object_name)
        except S3Error as e:
            if e.code == "NoSuchKey":
                exc = MaleoExceptionFactory.from_code(
                    ErrorCode.NOT_FOUND,
                    operation_type=OperationType.RESOURCE,
                    application_context=self._application_context,
                    operation_id=operation_id,
                    is_ai_operation=is_ai,
                    operation_context=self._operation_context,
                    operation_action=operation_action,
                    resource=resource,
                    operation_timestamp=Timestamp.completed_now(executed_at),
                    operation_summary=f"Asset '{location}' not found",
                    connection_context=connection_context,
                    authentication=authentication,
                    authorization=authorization,
                    impersonation=impersonation,
                )
                exc.log_and_publish_operation(self._logger, self._publishers)
                raise exc from e
            raise

        # Build response-content-disposition header
        if disposition is Disposition.ATTACHMENT:
            response_disposition = (
                f"attachment; filename={filename}" if filename else None
            )
        else:
            response_disposition = "inline"

        extra_query_params: DictType | None = (
            {"response-content-disposition": response_disposition}
            if response_disposition
            else None
        )

        url = self._client.presigned_get_object(
            bucket_name=self._config.bucket_name,
            object_name=object_name,
            expires=timedelta(seconds=expiration.value),
            extra_query_params=extra_query_params,
        )

        client = self._redis.manager.client.get(Connection.ASYNC)
        cache_key = build_cache_key(object_name, namespace=self._namespace)
        await client.set(name=cache_key, value=url, ex=expiration.value)

        asset = Asset(url=url)
        response = SingleDataResponse[Asset, None].new(data=asset)
        operation = ReadSingleResourceOperation[Asset, None](
            application_context=self._application_context,
            id=operation_id,
            is_ai=is_ai,
            context=self._operation_context,
            action=operation_action,
            resource=resource,
            timestamp=Timestamp.completed_now(executed_at),
            summary=f"Successfully generated signed url for asset '{location}'",
            connection_context=connection_context,
            authentication=authentication,
            authorization=authorization,
            impersonation=impersonation,
            response=response,
        )
        operation.log_and_publish(self._logger, self._publishers)
        return response
