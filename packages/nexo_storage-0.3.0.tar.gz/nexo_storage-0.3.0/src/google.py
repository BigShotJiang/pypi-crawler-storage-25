from copy import deepcopy
from datetime import UTC, datetime, timedelta
from uuid import uuid4

from nexo.database.enums import Connection
from nexo.database.handlers import RedisHandler
from nexo.database.utils import build_cache_key
from nexo.enums.expiration import Expiration
from nexo.logging.config import LogConfig
from nexo.logging.logger import Client as ClientLogger
from nexo.schemas.application import ApplicationContext, OptApplicationContext
from nexo.schemas.bus import ListOfAnyPublishers
from nexo.schemas.connection import OptConnectionContext
from nexo.schemas.error.enums import ErrorCode
from nexo.schemas.exception.factory import MaleoExceptionFactory
from nexo.schemas.extractor import extract_details
from nexo.schemas.operation.context import DefaultOperationContext
from nexo.schemas.operation.enums import OperationType
from nexo.schemas.operation.enums import Target as OperationTarget
from nexo.schemas.operation.mixins import Timestamp
from nexo.schemas.operation.resource import (
    CreateResourceOperationAction,
    CreateSingleResourceOperation,
    ReadResourceOperationAction,
    ReadSingleResourceOperation,
)
from nexo.schemas.resource import AggregateField, ResourceIdentifier
from nexo.schemas.response import SingleDataResponse
from nexo.schemas.security.authentication import OptAnyAuthentication
from nexo.schemas.security.authorization import OptAnyAuthorization
from nexo.schemas.security.impersonation import OptImpersonation
from nexo.types.misc import OptPathOrStr
from nexo.types.string import OptStr
from nexo.types.uuid import OptUUID
from nexo.utils.loaders.google import load, validate

from google.cloud.storage import Bucket, Client
from google.oauth2.service_account import Credentials

from .common import STORAGE_RESOURCE
from .enums import Disposition
from .schemas import Asset, BucketName

GOOGLE_CLOUD_STORAGE_RESOURCE = deepcopy(STORAGE_RESOURCE)
GOOGLE_CLOUD_STORAGE_RESOURCE.identifiers.append(
    ResourceIdentifier(
        key="google_cloud_storage",
        name="Google Cloud Storage",
        slug="google-cloud-storage",
    )
)


class GoogleCloudStorageConfig(BucketName):
    pass


OptGoogleCloudStorageConfig = GoogleCloudStorageConfig | None


class GoogleCloudStorage:
    def __init__(
        self,
        config: GoogleCloudStorageConfig,
        log_config: LogConfig,
        *,
        application_context: OptApplicationContext = None,
        credentials: Credentials | None = None,
        credentials_path: OptPathOrStr = None,
        redis: RedisHandler,
        publishers: ListOfAnyPublishers,
    ) -> None:
        self._config = config

        self._application_context = (
            application_context
            if application_context is not None
            else ApplicationContext.new()
        )

        self._logger = ClientLogger(
            log_config,
            environment=self._application_context.environment,
            service_key=self._application_context.service_key,
            client_key=GOOGLE_CLOUD_STORAGE_RESOURCE.identifiers[-1].key,
        )

        self._operation_context = DefaultOperationContext.CLIENT_SERVICE_INTERNAL.value

        if (credentials is None and credentials_path is None) or (
            credentials is not None and credentials_path is not None
        ):
            raise ValueError(
                "Only either 'credentials' and 'credentials_path' must be given"
            )

        if credentials is not None:
            self._credentials = credentials
        else:
            self._credentials = load(credentials_path)

        validate(self._credentials)

        self._client = Client(credentials=self._credentials)

        self._bucket = self._client.lookup_bucket(bucket_name=self._config.bucket_name)
        if self._bucket is None:
            self._client.close()
            raise ValueError(f"Bucket '{self._config.bucket_name}' does not exist.")

        self._redis = redis
        self._namespace = self._redis.config.build_client_namespace(
            GOOGLE_CLOUD_STORAGE_RESOURCE.aggregate(AggregateField.KEY, sep=":"),
            client=GOOGLE_CLOUD_STORAGE_RESOURCE.identifiers[-1].key,
        )

        self._publishers = publishers

        self._root_location = self._application_context.service_key

    @property
    def bucket(self) -> Bucket:
        if self._bucket is None:
            raise ValueError("Bucket has not been initialized.")
        return self._bucket

    async def upload(
        self,
        content: bytes,
        location: str,
        content_type: OptStr = None,
        *,
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        root_location_override: OptStr = None,
        make_public: bool = False,
        expiration: Expiration = Expiration.EXP_15MN,
    ) -> SingleDataResponse[Asset, None]:
        operation_id = operation_id if operation_id is not None else uuid4()
        operation_action = CreateResourceOperationAction()

        executed_at = datetime.now(tz=UTC)

        if root_location_override is None or (
            isinstance(root_location_override, str) and len(root_location_override) <= 0
        ):
            blob_name = f"{self._root_location}/{location}"
        else:
            blob_name = f"{root_location_override}/{location}"

        resource = deepcopy(GOOGLE_CLOUD_STORAGE_RESOURCE)
        resource.details = {"location": location, "blob_name": blob_name}

        try:
            blob = self.bucket.blob(blob_name=blob_name)
            blob.upload_from_string(content, content_type=content_type or "text/plain")

            if make_public:
                blob.make_public()
                url = blob.public_url
            else:
                url = blob.generate_signed_url(
                    version="v4",
                    expiration=timedelta(seconds=expiration.value),
                    method="GET",
                )

            client = self._redis.manager.client.get(Connection.ASYNC)
            cache_key = build_cache_key(blob_name, namespace=self._namespace)
            await client.set(name=cache_key, value=url, ex=expiration.value)

            asset = Asset(url=url)
            response = SingleDataResponse[Asset, None].new(data=asset)
            operation = CreateSingleResourceOperation[Asset, None](
                application_context=self._application_context,
                id=operation_id,
                is_ai=is_ai,
                context=self._operation_context,
                action=operation_action,
                timestamp=Timestamp.completed_now(executed_at),
                summary=f"Successfully uploaded object to '{location}'",
                connection_context=connection_context,
                authentication=authentication,
                authorization=authorization,
                impersonation=impersonation,
                resource=resource,
                response=response,
            )
            operation.log_and_publish(self._logger, self._publishers)
            return response
        except Exception as e:
            exc = MaleoExceptionFactory.from_code(
                ErrorCode.INTERNAL_SERVER_ERROR,
                details=extract_details(e),
                operation_type=OperationType.RESOURCE,
                application_context=self._application_context,
                operation_id=operation_id,
                is_ai_operation=is_ai,
                operation_context=self._operation_context,
                operation_action=operation_action,
                resource=resource,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary=(f"Error raised while uploading to '{location}'"),
                connection_context=connection_context,
                authentication=authentication,
                authorization=authorization,
                impersonation=impersonation,
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            raise exc from e

    async def generate_signed_url(
        self,
        location: str,
        disposition: Disposition = Disposition.ATTACHMENT,
        filename: OptStr = None,
        *,
        operation_id: OptUUID = None,
        is_ai: bool = False,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        root_location_override: OptStr = None,
        use_cache: bool = True,
        expiration: Expiration = Expiration.EXP_15MN,
    ) -> SingleDataResponse[Asset, None]:
        operation_id = operation_id if operation_id is not None else uuid4()
        operation_action = ReadResourceOperationAction()

        executed_at = datetime.now(tz=UTC)

        if root_location_override is None or (
            isinstance(root_location_override, str) and len(root_location_override) <= 0
        ):
            blob_name = f"{self._root_location}/{location}"
        else:
            blob_name = f"{root_location_override}/{location}"

        resource = deepcopy(GOOGLE_CLOUD_STORAGE_RESOURCE)
        resource.details = {"location": location, "blob_name": blob_name}

        if use_cache:
            client = self._redis.manager.client.get(Connection.ASYNC)
            cache_key = build_cache_key(blob_name, namespace=self._namespace)
            url = await client.get(cache_key)
            if url is not None:
                operation_context = deepcopy(self._operation_context)
                operation_context.target.type = OperationTarget.CACHE
                asset = Asset(url=url)
                response = SingleDataResponse[Asset, None].new(data=asset)
                operation = ReadSingleResourceOperation[Asset, None](
                    application_context=self._application_context,
                    id=operation_id,
                    is_ai=is_ai,
                    context=operation_context,
                    action=operation_action,
                    resource=resource,
                    timestamp=Timestamp.completed_now(executed_at),
                    summary=f"Retrieved signed url for '{location}' from cache",
                    connection_context=connection_context,
                    authentication=authentication,
                    authorization=authorization,
                    impersonation=impersonation,
                    response=response,
                )
                operation.log_and_publish(self._logger, self._publishers)

                return response

        blob = self.bucket.blob(blob_name=blob_name)
        if not blob.exists():
            exc = MaleoExceptionFactory.from_code(
                ErrorCode.NOT_FOUND,
                operation_type=OperationType.RESOURCE,
                application_context=self._application_context,
                operation_id=operation_id,
                is_ai_operation=is_ai,
                operation_context=self._operation_context,
                operation_action=operation_action,
                resource=resource,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary=f"Asset '{location}' not found",
                connection_context=connection_context,
                authentication=authentication,
                authorization=authorization,
                impersonation=impersonation,
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            raise exc

        if disposition is Disposition.ATTACHMENT:
            if filename is None:
                response_disposition = None
            else:
                response_disposition = (
                    f"{Disposition.ATTACHMENT.value}; filename={filename}"
                )
        elif disposition is Disposition.INLINE:
            response_disposition = "inline"

        url = blob.generate_signed_url(
            expiration=timedelta(seconds=expiration.value),
            response_disposition=response_disposition,
            version="v4",
        )

        client = self._redis.manager.client.get(Connection.ASYNC)
        cache_key = build_cache_key(blob_name, namespace=self._namespace)
        await client.set(name=cache_key, value=url, ex=expiration.value)

        asset = Asset(url=url)
        response = SingleDataResponse[Asset, None].new(data=asset)
        operation = ReadSingleResourceOperation[Asset, None](
            application_context=self._application_context,
            id=operation_id,
            is_ai=is_ai,
            context=self._operation_context,
            action=operation_action,
            resource=resource,
            timestamp=Timestamp.completed_now(executed_at),
            summary=f"Successfully generated signed url for asset '{location}'",
            connection_context=connection_context,
            authentication=authentication,
            authorization=authorization,
            impersonation=impersonation,
            response=response,
        )
        operation.log_and_publish(self._logger, self._publishers)

        return response
