from nexo.schemas.resource import Resource, ResourceIdentifier

STORAGE_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(
            key="storage",
            name="Storage",
            slug="storages",
        )
    ],
    details=None,
)
