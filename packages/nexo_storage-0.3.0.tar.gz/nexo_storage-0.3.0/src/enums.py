from enum import StrEnum


class Disposition(StrEnum):
    ATTACHMENT = "attachment"
    INLINE = "inline"
