from typing import Annotated

from pydantic import BaseModel, Field


class Asset(BaseModel):
    url: Annotated[str, Field(..., description="Asset's URL")]


class BucketName(BaseModel):
    bucket_name: Annotated[str, Field(..., description="Bucket's Name")]
