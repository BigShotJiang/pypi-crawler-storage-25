# zarrnii.atlas

Atlas handling via `ZarrNiiAtlas`, including TemplateFlow integration for
brain atlas operations.

::: zarrnii.atlas
    handler: python
    options:
      show_root_heading: false
      show_object_full_path: true
      show_category_heading: true
      show_symbol_type_heading: false
      members_order: source
      merge_init_into_class: true
      show_docstring_description: true
      docstring_section_style: list
      show_source: true
      filters:
        - "!^_"  # hide private members
        - "!^Template"
        - "!^Ambiguous"
