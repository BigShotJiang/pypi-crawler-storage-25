"""Tests for RDM-106 sub-agent provenance — UpstreamPointer, attach_upstream, envelope wiring."""
import os
import pytest

from redmtz import UpstreamPointer, attach_upstream, govern, GovernanceBlocked
from redmtz.provenance import (
    get_current_upstream,
    _reset_env_cache_for_tests,
    ENV_ACTOR_ID,
    ENV_EVENT_HASH,
)
from redmtz.envelope import CanonicalEnvelope

_FAKE_HASH = "a" * 64


# ── Public API surface ────────────────────────────────────────────────────────

class TestPublicExports:
    def test_upstream_pointer_exported(self):
        import redmtz
        assert hasattr(redmtz, "UpstreamPointer")

    def test_attach_upstream_exported(self):
        import redmtz
        assert hasattr(redmtz, "attach_upstream")

    def test_mandate_not_exported(self):
        import redmtz
        assert not hasattr(redmtz, "MandateContext")
        assert not hasattr(redmtz, "attach_mandate")
        assert not hasattr(redmtz, "get_current_mandate")

    def test_mandate_not_in_seatbelt_provenance(self):
        import redmtz.provenance as prov
        assert not hasattr(prov, "MandateContext")
        assert not hasattr(prov, "attach_mandate")
        assert not hasattr(prov, "get_current_mandate")


# ── UpstreamPointer ───────────────────────────────────────────────────────────

class TestUpstreamPointer:
    def test_immutable(self):
        p = UpstreamPointer(actor_id="agent-1", event_hash=_FAKE_HASH)
        with pytest.raises(Exception):
            p.actor_id = "tampered"

    def test_to_dict(self):
        p = UpstreamPointer(actor_id="agent-1", event_hash=_FAKE_HASH)
        assert p.to_dict() == {"actor_id": "agent-1", "event_hash": _FAKE_HASH}

    def test_equality(self):
        a = UpstreamPointer(actor_id="x", event_hash=_FAKE_HASH)
        b = UpstreamPointer(actor_id="x", event_hash=_FAKE_HASH)
        assert a == b


# ── attach_upstream context manager ──────────────────────────────────────────

class TestAttachUpstream:
    def test_context_sets_pointer(self):
        assert get_current_upstream() is None
        with attach_upstream(actor_id="parent", event_hash=_FAKE_HASH) as p:
            result = get_current_upstream()
            assert result is not None
            assert result.actor_id == "parent"
            assert result.event_hash == _FAKE_HASH
        assert get_current_upstream() is None

    def test_context_yields_pointer(self):
        with attach_upstream(actor_id="orch", event_hash=_FAKE_HASH) as p:
            assert isinstance(p, UpstreamPointer)
            assert p.actor_id == "orch"

    def test_context_restored_after_exit(self):
        with attach_upstream(actor_id="outer", event_hash=_FAKE_HASH):
            with attach_upstream(actor_id="inner", event_hash="b" * 64):
                assert get_current_upstream().actor_id == "inner"
            assert get_current_upstream().actor_id == "outer"

    def test_invalid_actor_id_empty(self):
        with pytest.raises(ValueError, match="actor_id"):
            with attach_upstream(actor_id="", event_hash=_FAKE_HASH):
                pass

    def test_invalid_event_hash_empty(self):
        with pytest.raises(ValueError, match="event_hash"):
            with attach_upstream(actor_id="parent", event_hash=""):
                pass

    def test_whitespace_actor_id_rejected(self):
        with pytest.raises(ValueError):
            with attach_upstream(actor_id="   ", event_hash=_FAKE_HASH):
                pass

    def test_strips_whitespace(self):
        with attach_upstream(actor_id="  parent  ", event_hash=f"  {_FAKE_HASH}  ") as p:
            assert p.actor_id == "parent"
            assert p.event_hash == _FAKE_HASH


# ── Env-var subprocess fallback ───────────────────────────────────────────────

class TestEnvVarFallback:
    def setup_method(self):
        _reset_env_cache_for_tests()
        os.environ.pop(ENV_ACTOR_ID, None)
        os.environ.pop(ENV_EVENT_HASH, None)

    def teardown_method(self):
        _reset_env_cache_for_tests()
        os.environ.pop(ENV_ACTOR_ID, None)
        os.environ.pop(ENV_EVENT_HASH, None)

    def test_env_vars_set_upstream(self):
        os.environ[ENV_ACTOR_ID]   = "subprocess-parent"
        os.environ[ENV_EVENT_HASH] = _FAKE_HASH
        result = get_current_upstream()
        assert result is not None
        assert result.actor_id == "subprocess-parent"
        assert result.event_hash == _FAKE_HASH

    def test_partial_env_vars_returns_none(self):
        os.environ[ENV_ACTOR_ID] = "only-actor"
        result = get_current_upstream()
        assert result is None

    def test_no_env_vars_returns_none(self):
        result = get_current_upstream()
        assert result is None

    def test_context_overrides_env_var(self):
        os.environ[ENV_ACTOR_ID]   = "env-parent"
        os.environ[ENV_EVENT_HASH] = _FAKE_HASH
        with attach_upstream(actor_id="ctx-parent", event_hash="b" * 64):
            result = get_current_upstream()
            assert result.actor_id == "ctx-parent"


# ── Envelope wiring ───────────────────────────────────────────────────────────

class TestEnvelopeWiring:
    def _build_envelope(self, **ctx_kwargs):
        ce = CanonicalEnvelope()
        actor = {"type": "test", "identity": "test.fn", "credential_method": "test"}
        if ctx_kwargs:
            with attach_upstream(**ctx_kwargs) as _:
                return ce.build(
                    actor=actor,
                    action={"verb": "execute", "domain": "test", "resource": "fn"},
                    gate_decisions=[],
                    policy={"name": "audit_mode", "version": "1.0.0", "hash": "x"},
                    execution_result={"status": "allow"},
                    sign=False,
                )
        return ce.build(
            actor=actor,
            action={"verb": "execute", "domain": "test", "resource": "fn"},
            gate_decisions=[],
            policy={"name": "audit_mode", "version": "1.0.0", "hash": "x"},
            execution_result={"status": "allow"},
            sign=False,
        )

    def test_upstream_in_envelope_when_context_active(self):
        env = self._build_envelope(actor_id="parent-orch", event_hash=_FAKE_HASH)
        upstream = env["actor"].get("upstream")
        assert upstream is not None
        assert upstream["actor_id"] == "parent-orch"
        assert upstream["event_hash"] == _FAKE_HASH

    def test_upstream_absent_when_no_context(self):
        env = self._build_envelope()
        assert "upstream" not in env["actor"]

    def test_caller_actor_dict_not_mutated(self):
        ce = CanonicalEnvelope()
        actor = {"type": "test", "identity": "test.fn", "credential_method": "test"}
        original_keys = set(actor.keys())
        with attach_upstream(actor_id="parent", event_hash=_FAKE_HASH):
            ce.build(
                actor=actor,
                action={"verb": "execute", "domain": "test", "resource": "fn"},
                gate_decisions=[],
                policy={"name": "audit_mode", "version": "1.0.0", "hash": "x"},
                execution_result={"status": "allow"},
                sign=False,
            )
        assert set(actor.keys()) == original_keys


# ── End-to-end via @govern ────────────────────────────────────────────────────

class TestDecoratorEndToEnd:
    def test_blocked_envelope_contains_upstream(self):
        @govern(rules="destructive_actions", policy="safe_defaults")
        def drop_it(query: str):
            pass

        with attach_upstream(actor_id="orchestrator-1", event_hash=_FAKE_HASH):
            with pytest.raises(GovernanceBlocked) as exc_info:
                drop_it("DROP TABLE users")

        upstream = exc_info.value.envelope["actor"].get("upstream")
        assert upstream is not None
        assert upstream["actor_id"] == "orchestrator-1"
        assert upstream["event_hash"] == _FAKE_HASH

    def test_root_agent_envelope_no_upstream(self):
        @govern(rules="destructive_actions", policy="safe_defaults")
        def drop_it2(query: str):
            pass

        with pytest.raises(GovernanceBlocked) as exc_info:
            drop_it2("DROP TABLE users")

        assert "upstream" not in exc_info.value.envelope["actor"]
