# Copyright 2026 Robert Benitez
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
redmtz.provenance — Sub-Agent Provenance Context (RDM-106)
REDMTZ Seatbelt

Extends the RDM-019 canonical envelope to carry provenance pointers so
sub-agent actions chain back to the spawning actor. Ships observability
only — NOT authorization. See `actor.upstream` sub-field of the envelope.

Architectural invariant:
    The upstream pointer is set by harness code at child-init time,
    frozen immutable thereafter, and MUST NOT be settable by agent-
    authored or LLM-reachable code paths. For subprocesses, harness
    sets env vars before launch; child reads them once at first use.

Usage (in-process harness):

    from redmtz.provenance import attach_upstream

    with attach_upstream(actor_id="parent-orchestrator",
                         event_hash="abc123..."):
        child_agent_function()     # every @govern envelope gets upstream

Usage (subprocess harness):

    Parent sets env vars before launching subprocess:
        SEATBELT_UPSTREAM_ACTOR_ID=parent-orchestrator
        SEATBELT_UPSTREAM_EVENT_HASH=abc123...
    Subprocess reads once at first @govern invocation; cached frozen.

Founder: Robert Benitez
"""

import contextvars
import os
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Iterator, Optional


ENV_ACTOR_ID   = "SEATBELT_UPSTREAM_ACTOR_ID"
ENV_EVENT_HASH = "SEATBELT_UPSTREAM_EVENT_HASH"


@dataclass(frozen=True)
class UpstreamPointer:
    """
    Immutable pointer to the spawning actor's event in the ledger.

    Two fields only — this is observability metadata, not authority.
    No delegation_bounds. No parent_signature. No attestation.
    """
    actor_id:   str
    event_hash: str

    def to_dict(self) -> dict:
        return {"actor_id": self.actor_id, "event_hash": self.event_hash}


# Module-private ContextVar. Accessible only via attach_upstream()
# and get_current_upstream(). Agent-authored code should not touch this.
_UPSTREAM_CONTEXT: contextvars.ContextVar[Optional[UpstreamPointer]] = (
    contextvars.ContextVar("_redmtz_upstream", default=None)
)

# One-shot env-var cache. Read exactly once per process lifetime.
_ENV_CACHE_SENTINEL: Any = object()
_env_cache: Any = _ENV_CACHE_SENTINEL


def _read_env_upstream() -> Optional[UpstreamPointer]:
    """Read subprocess-spawn env vars exactly once; cache frozen thereafter."""
    global _env_cache
    if _env_cache is _ENV_CACHE_SENTINEL:
        actor_id   = os.environ.get(ENV_ACTOR_ID, "").strip()
        event_hash = os.environ.get(ENV_EVENT_HASH, "").strip()
        if actor_id and event_hash:
            _env_cache = UpstreamPointer(
                actor_id=actor_id, event_hash=event_hash
            )
        else:
            _env_cache = None
    return _env_cache


@contextmanager
def attach_upstream(actor_id: str, event_hash: str) -> Iterator[UpstreamPointer]:
    """
    Harness-level context manager. Sets the upstream pointer for every
    @govern envelope produced inside the `with` block.

    Args:
        actor_id:   Opaque identifier of the spawning actor.
        event_hash: Hash of the spawning actor's event in the ledger
                    (typically the envelope.hash_chain.current_hash).

    Raises:
        ValueError: On empty or non-string arguments.

    Thread-safety: ContextVar values are inherited by asyncio tasks but
    NOT by threading.Thread children. If your harness spawns threads
    (e.g. CrewAI worker threads), set SEATBELT_UPSTREAM_* env vars
    before thread launch and rely on the env-var fallback path instead.

    Intended caller: harness/adapter code that spawns a child agent or
    sub-task. MUST NOT be called from agent-authored or LLM-reachable
    code paths.
    """
    if not isinstance(actor_id, str) or not actor_id.strip():
        raise ValueError("actor_id must be a non-empty string")
    if not isinstance(event_hash, str) or not event_hash.strip():
        raise ValueError("event_hash must be a non-empty string")

    pointer = UpstreamPointer(
        actor_id=actor_id.strip(), event_hash=event_hash.strip()
    )
    token = _UPSTREAM_CONTEXT.set(pointer)
    try:
        yield pointer
    finally:
        _UPSTREAM_CONTEXT.reset(token)


def get_current_upstream() -> Optional[UpstreamPointer]:
    """
    Return the active upstream pointer, or None if this actor is a root.

    Resolution order:
      1. Active `attach_upstream()` context (in-process harness).
      2. Env-var fallback (subprocess harness), read-once and cached.

    Returns a frozen UpstreamPointer or None. Callers must treat the
    returned value as immutable.
    """
    pointer = _UPSTREAM_CONTEXT.get()
    if pointer is not None:
        return pointer
    return _read_env_upstream()


def _reset_env_cache_for_tests() -> None:
    """Test helper — clears the one-shot env cache. DO NOT call in production."""
    global _env_cache
    _env_cache = _ENV_CACHE_SENTINEL
