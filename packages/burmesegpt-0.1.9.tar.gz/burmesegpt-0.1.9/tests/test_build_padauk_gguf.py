from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path


def _load_build_module():
    script_path = Path(__file__).resolve().parents[1] / "scripts" / "build_padauk_gguf.py"
    spec = importlib.util.spec_from_file_location("build_padauk_gguf", script_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_cmd_validate_gguf_uses_llama_cli_stable_flags(monkeypatch, tmp_path: Path) -> None:
    build_padauk_gguf = _load_build_module()
    llama_cpp_dir = tmp_path / "llama.cpp"
    llama_bin_dir = llama_cpp_dir / "build" / "bin"
    llama_bin_dir.mkdir(parents=True)
    (llama_bin_dir / "llama-cli").write_text("", encoding="utf-8")

    model_path = tmp_path / "padauk-f16.gguf"
    model_path.write_bytes(b"GGUF")

    commands: list[list[str]] = []

    monkeypatch.setattr(build_padauk_gguf, "_check_llama_cpp", lambda path: None)
    monkeypatch.setattr(
        build_padauk_gguf,
        "assert_padauk_gguf_metadata",
        lambda path: {
            "general.architecture": "gemma4",
            "gemma4.attention.shared_kv_layers": 18,
        },
    )
    monkeypatch.setattr(build_padauk_gguf, "_run", lambda command: commands.append(command))

    args = argparse.Namespace(llama_cpp_dir=llama_cpp_dir, model=model_path)

    assert build_padauk_gguf.cmd_validate_gguf(args) == 0
    assert commands == [
        [
            str(llama_bin_dir / "llama-cli"),
            "-m",
            str(model_path.resolve()),
            "-ngl",
            "0",
            "-c",
            "256",
            "-b",
            "64",
            "-p",
            "hello",
            "-n",
            "1",
            "-no-cnv",
            "--single-turn",
            "--simple-io",
            "--no-warmup",
        ]
    ]
