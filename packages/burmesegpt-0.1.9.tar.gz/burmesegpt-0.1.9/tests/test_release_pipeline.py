from __future__ import annotations

import json
import struct
from pathlib import Path

import pytest

from burmesegpt.release_pipeline import (
    ReleasePipelineError,
    assert_padauk_gguf_metadata,
    is_gemma4_shared_kv_runtime_error,
    read_gguf_metadata,
    update_manifest_sha256_text,
    update_sha256sums_text,
    verify_converter_python_env,
    verify_padauk_source_tree,
)


def _write_source_tree(
    root: Path,
    *,
    num_hidden_layers: int = 42,
    num_kv_shared_layers: int = 18,
    include_index: bool = True,
    include_shards: bool = True,
    k_layers: range | None = None,
    v_layers: range | None = None,
) -> None:
    (root / "config.json").write_text(
        json.dumps(
            {
                "architectures": ["Gemma4ForConditionalGeneration"],
                "model_type": "gemma4",
                "text_config": {
                    "num_hidden_layers": num_hidden_layers,
                    "num_kv_shared_layers": num_kv_shared_layers,
                },
            }
        ),
        encoding="utf-8",
    )
    (root / "tokenizer.json").write_text("{}", encoding="utf-8")
    (root / "tokenizer_config.json").write_text("{}", encoding="utf-8")

    if not include_index:
        return

    expected_non_shared_layers = num_hidden_layers - num_kv_shared_layers
    k_layers = k_layers if k_layers is not None else range(expected_non_shared_layers)
    v_layers = v_layers if v_layers is not None else range(expected_non_shared_layers)

    weight_map: dict[str, str] = {}
    for layer in range(num_hidden_layers):
        shard = f"model-{1 + (layer % 4):05d}-of-00004.safetensors"
        weight_map[f"model.language_model.layers.{layer}.self_attn.q_proj.weight"] = shard
        weight_map[f"model.language_model.layers.{layer}.self_attn.o_proj.weight"] = shard
    for layer in k_layers:
        shard = f"model-{1 + (layer % 4):05d}-of-00004.safetensors"
        weight_map[f"model.language_model.layers.{layer}.self_attn.k_proj.weight"] = shard
    for layer in v_layers:
        shard = f"model-{1 + (layer % 4):05d}-of-00004.safetensors"
        weight_map[f"model.language_model.layers.{layer}.self_attn.v_proj.weight"] = shard

    (root / "model.safetensors.index.json").write_text(
        json.dumps({"metadata": {"total_size": 1}, "weight_map": weight_map}),
        encoding="utf-8",
    )

    if include_shards:
        for shard in sorted(set(weight_map.values())):
            (root / shard).write_bytes(b"shard")


def _encode_string(value: str) -> bytes:
    raw = value.encode("utf-8")
    return struct.pack("<Q", len(raw)) + raw


def _encode_value(value: object) -> tuple[int, bytes]:
    if isinstance(value, str):
        return 8, _encode_string(value)
    if isinstance(value, bool):
        return 7, struct.pack("<?", value)
    if isinstance(value, int):
        return 5, struct.pack("<i", value)
    raise TypeError(f"Unsupported test GGUF value: {value!r}")


def _write_fake_gguf(path: Path, metadata: dict[str, object]) -> None:
    chunks = [b"GGUF", struct.pack("<I", 3), struct.pack("<Q", 0), struct.pack("<Q", len(metadata))]
    for key, value in metadata.items():
        value_type, encoded = _encode_value(value)
        chunks.append(_encode_string(key))
        chunks.append(struct.pack("<I", value_type))
        chunks.append(encoded)
    path.write_bytes(b"".join(chunks))


def test_verify_padauk_source_tree_accepts_expected_shared_kv_layout(tmp_path: Path) -> None:
    _write_source_tree(tmp_path)

    report = verify_padauk_source_tree(tmp_path)

    assert report.num_hidden_layers == 42
    assert report.num_kv_shared_layers == 18
    assert report.first_shared_kv_layer == 24
    assert report.q_proj_layers == tuple(range(42))
    assert report.k_proj_layers == tuple(range(24))
    assert report.v_proj_layers == tuple(range(24))
    assert report.o_proj_layers == tuple(range(42))


def test_verify_padauk_source_tree_rejects_missing_midlayer_k_proj(tmp_path: Path) -> None:
    bad_layers = [layer for layer in range(24) if layer != 12]
    _write_source_tree(tmp_path, k_layers=range(0))
    _write_source_tree(tmp_path, k_layers=range(24), v_layers=range(24))
    index = json.loads((tmp_path / "model.safetensors.index.json").read_text(encoding="utf-8"))
    del index["weight_map"]["model.language_model.layers.12.self_attn.k_proj.weight"]
    (tmp_path / "model.safetensors.index.json").write_text(json.dumps(index), encoding="utf-8")

    with pytest.raises(ReleasePipelineError, match="k_proj layers do not match"):
        verify_padauk_source_tree(tmp_path)


def test_verify_padauk_source_tree_rejects_wrong_shared_kv_tail_size(tmp_path: Path) -> None:
    _write_source_tree(tmp_path, k_layers=range(25), v_layers=range(25))

    with pytest.raises(ReleasePipelineError, match="k_proj layers do not match"):
        verify_padauk_source_tree(tmp_path)


def test_verify_padauk_source_tree_rejects_missing_shard_or_index(tmp_path: Path) -> None:
    _write_source_tree(tmp_path, include_index=False)
    with pytest.raises(ReleasePipelineError, match="Missing required source files"):
        verify_padauk_source_tree(tmp_path)

    other = tmp_path / "with-index"
    other.mkdir()
    _write_source_tree(other, include_shards=False)
    with pytest.raises(ReleasePipelineError, match="Missing safetensor shards"):
        verify_padauk_source_tree(other)


def test_read_gguf_metadata_and_assert_shared_kv(tmp_path: Path) -> None:
    gguf_path = tmp_path / "padauk.gguf"
    _write_fake_gguf(
        gguf_path,
        {
            "general.architecture": "gemma4",
            "gemma4.attention.shared_kv_layers": 18,
            "gemma4.block_count": 42,
        },
    )

    metadata = read_gguf_metadata(gguf_path)
    assert metadata["general.architecture"] == "gemma4"
    assert metadata["gemma4.attention.shared_kv_layers"] == 18
    assert_padauk_gguf_metadata(gguf_path)


def test_is_gemma4_shared_kv_runtime_error_requires_metadata_and_signature() -> None:
    metadata = {
        "general.architecture": "gemma4",
        "gemma4.attention.shared_kv_layers": 18,
    }
    exc = RuntimeError("missing tensor 'blk.24.attn_k.weight'")

    assert is_gemma4_shared_kv_runtime_error(exc, metadata) is True
    assert is_gemma4_shared_kv_runtime_error(RuntimeError("other"), metadata) is False
    assert is_gemma4_shared_kv_runtime_error(exc, None) is False


def test_verify_converter_python_env_rejects_import_mismatch(monkeypatch) -> None:
    versions = {
        "transformers": "4.12.2",
        "huggingface_hub": "1.8.0",
        "safetensors": "0.7.0",
    }

    monkeypatch.setattr("burmesegpt.release_pipeline.sys.version_info", (3, 10, 0))
    monkeypatch.setattr("importlib.metadata.version", lambda name: versions[name])

    def fake_import(name: str):
        if name in {"transformers", "huggingface_hub"}:
            return object()
        raise AssertionError(f"unexpected import_module({name!r})")

    monkeypatch.setattr("importlib.import_module", fake_import)

    real_import = __import__

    def fake___import__(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "transformers" and fromlist == ("AutoConfig",):
            raise ImportError("cannot import name 'HfFolder'")
        if name == "huggingface_hub" and fromlist == ("snapshot_download",):
            return real_import(name, globals, locals, fromlist, level)
        return real_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr("builtins.__import__", fake___import__)

    with pytest.raises(ReleasePipelineError, match="Converter Python environment is inconsistent"):
        verify_converter_python_env()


def test_manifest_and_sha256sum_text_updates_are_targeted() -> None:
    manifest_text = """
QUANT_FILENAMES: dict[str, str] = {
    "q4_k_m": "padauk-gemma-q4_k_m.gguf",
    "q5_k_m": "padauk-gemma-q5_k_m.gguf",
    "q8_0": "padauk-gemma-q8_0.gguf",
}

PACKAGE_SHA256: dict[str, str | None] = {
    "q4_k_m": None,
    "q5_k_m": None,
    "q8_0": "oldhash",
}
""".strip()
    updated_manifest = update_manifest_sha256_text(manifest_text, "q8_0", "newhash")
    assert '"q8_0": "padauk-gemma-q8_0.gguf"' in updated_manifest
    assert '"q8_0": "newhash"' in updated_manifest

    updated_sha = update_sha256sums_text(
        "oldhash  padauk-gemma-q8_0.gguf\n",
        "padauk-gemma-q8_0.gguf",
        "newhash",
    )
    assert updated_sha == "newhash  padauk-gemma-q8_0.gguf\n"
