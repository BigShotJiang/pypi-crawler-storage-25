from __future__ import annotations

import sys
from pathlib import Path

import pytest

from burmesegpt import padauk_agent
from burmesegpt.agent import (
    GGUFValidationError,
    HashMismatchError,
    SERVE_BACKEND_AUTO,
    SERVE_BACKEND_PYTHON,
    SERVE_BACKEND_STANDALONE,
    ServeConfig,
    ServerLaunchError,
    file_sha256,
)
from burmesegpt.release_pipeline import gemma4_shared_kv_runtime_guidance


def test_file_sha256_changes_when_content_changes(tmp_path: Path) -> None:
    model_file = tmp_path / "model.gguf"
    model_file.write_bytes(b"padauk")
    first_hash = file_sha256(model_file)

    model_file.write_bytes(b"padauk-tampered")
    second_hash = file_sha256(model_file)

    assert first_hash != second_hash


def test_ensure_model_rejects_tampered_checksum(monkeypatch, tmp_path: Path) -> None:
    model_filename = "padauk-gemma-q4_k_m.gguf"

    def fake_hf_hub_download(*, filename: str, local_dir: str, **_kwargs):
        path = Path(local_dir) / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        if filename == model_filename:
            path.write_bytes(b"tampered")
            return str(path)
        if filename == "SHA256SUMS.txt":
            path.write_text(
                "0000000000000000000000000000000000000000000000000000000000000000  "
                f"{model_filename}\n",
                encoding="utf-8",
            )
            return str(path)
        raise AssertionError(f"unexpected file requested: {filename}")

    monkeypatch.setattr("burmesegpt.agent.hf_hub_download", fake_hf_hub_download)

    agent = padauk_agent(
        quant="q4_k_m",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=tmp_path,
    )
    with pytest.raises(HashMismatchError):
        agent.ensure_model()


def test_validate_model_rejects_bad_gguf_header(monkeypatch, tmp_path: Path) -> None:
    model_path = tmp_path / "bad.gguf"
    model_path.write_bytes(b"NOTG-rest")

    agent = padauk_agent(
        quant="q4_k_m",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=tmp_path,
    )
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)

    with pytest.raises(GGUFValidationError):
        agent.validate_model(runtime_check=False)


def test_validate_model_runtime_load_failure_is_actionable(monkeypatch, tmp_path: Path) -> None:
    model_path = tmp_path / "good.gguf"
    model_path.write_bytes(b"GGUFpayload")

    class _BrokenLlama:
        def __init__(self, **_kwargs):
            raise RuntimeError("missing tensor blk.0.attn_q.weight")

    agent = padauk_agent(
        quant="q4_k_m",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=tmp_path,
    )
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)
    monkeypatch.setattr(agent, "_load_llama_class", lambda: _BrokenLlama)

    with pytest.raises(RuntimeError, match="llama_cpp failed to load"):
        agent.validate_model(runtime_check=True)


def test_validate_model_reports_gemma4_shared_kv_loader_mismatch(monkeypatch, tmp_path: Path) -> None:
    model_path = tmp_path / "good.gguf"
    model_path.write_bytes(b"GGUFpayload")

    class _BrokenLlama:
        def __init__(self, **_kwargs):
            raise RuntimeError("missing tensor 'blk.24.attn_k.weight'")

    agent = padauk_agent(
        quant="q8_0",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=tmp_path,
    )
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)
    monkeypatch.setattr(agent, "_load_llama_class", lambda: _BrokenLlama)
    monkeypatch.setattr(
        "burmesegpt.agent.read_gguf_metadata",
        lambda _path: {
            "general.architecture": "gemma4",
            "gemma4.attention.shared_kv_layers": 18,
        },
    )

    with pytest.raises(RuntimeError, match="standalone llama.cpp >= b8751"):
        agent.validate_model(runtime_check=True)


def test_validate_model_reports_gemma4_shared_kv_guidance_for_generic_load_failure(
    monkeypatch, tmp_path: Path
) -> None:
    model_path = tmp_path / "good.gguf"
    model_path.write_bytes(b"GGUFpayload")

    class _BrokenLlama:
        def __init__(self, **_kwargs):
            raise ValueError(f"Failed to load model from file: {model_path}")

    agent = padauk_agent(
        quant="q8_0",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=tmp_path,
    )
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)
    monkeypatch.setattr(agent, "_load_llama_class", lambda: _BrokenLlama)
    monkeypatch.setattr(
        "burmesegpt.agent.read_gguf_metadata",
        lambda _path: {
            "general.architecture": "gemma4",
            "gemma4.attention.shared_kv_layers": 18,
        },
    )

    with pytest.raises(RuntimeError, match="checksum and GGUF header validation"):
        agent.validate_model(runtime_check=True)


def test_serve_reports_gemma4_shared_kv_loader_mismatch_before_server_launch(
    monkeypatch, tmp_path: Path
) -> None:
    model_path = tmp_path / "good.gguf"
    model_path.write_bytes(b"GGUFpayload")

    agent = padauk_agent(
        quant="q8_0",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=tmp_path,
    )
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)
    monkeypatch.setattr(
        "burmesegpt.agent.read_gguf_metadata",
        lambda _path: {
            "general.architecture": "gemma4",
            "gemma4.attention.shared_kv_layers": 18,
        },
    )
    monkeypatch.setattr(agent, "_discover_llama_server", lambda _path: None)
    monkeypatch.setattr(
        agent,
        "_validate_runtime_load",
        lambda _path: (_ for _ in ()).throw(
            RuntimeError(
                "llama_cpp failed to load good.gguf: missing tensor 'blk.24.attn_k.weight'. "
                f"The GGUF artifact may be corrupted or incompatible. {gemma4_shared_kv_runtime_guidance()}"
            )
        ),
    )

    with pytest.raises(ServerLaunchError, match="standalone llama.cpp >= b8751"):
        agent.serve(wait=False, backend=SERVE_BACKEND_PYTHON)


def test_discover_llama_server_prefers_explicit_then_env_then_path(
    monkeypatch, tmp_path: Path
) -> None:
    agent = padauk_agent(cache_dir=tmp_path)
    explicit = tmp_path / "explicit-llama-server"
    explicit.write_text("", encoding="utf-8")
    explicit.chmod(0o755)

    env_path = tmp_path / "env-llama-server"
    env_path.write_text("", encoding="utf-8")
    env_path.chmod(0o755)
    path_server = tmp_path / "path-server"
    path_server.write_text("", encoding="utf-8")
    path_server.chmod(0o755)

    monkeypatch.setenv("BURMESEGPT_LLAMA_SERVER", str(env_path))
    monkeypatch.setattr("burmesegpt.agent.shutil.which", lambda _name: str(path_server))

    assert agent._discover_llama_server(str(explicit)) == explicit
    assert agent._discover_llama_server(None) == env_path
    monkeypatch.delenv("BURMESEGPT_LLAMA_SERVER", raising=False)
    assert agent._discover_llama_server(None) == path_server


def test_discover_llama_server_rejects_invalid_explicit_path(tmp_path: Path) -> None:
    agent = padauk_agent(cache_dir=tmp_path)

    with pytest.raises(ServerLaunchError, match="--llama-server-path"):
        agent._discover_llama_server(str(tmp_path / "missing-llama-server"))


def test_select_serve_backend_auto_uses_standalone_for_shared_kv(
    monkeypatch, tmp_path: Path
) -> None:
    agent = padauk_agent(cache_dir=tmp_path)
    standalone = tmp_path / "llama-server"
    standalone.write_text("", encoding="utf-8")
    standalone.chmod(0o755)
    monkeypatch.setattr(agent, "_discover_llama_server", lambda _path: standalone)

    backend, selected_path = agent._select_serve_backend(
        config=ServeConfig(backend=SERVE_BACKEND_AUTO),
        metadata={
            "general.architecture": "gemma4",
            "gemma4.attention.shared_kv_layers": 18,
        },
    )

    assert backend == SERVE_BACKEND_STANDALONE
    assert selected_path == standalone


def test_build_standalone_server_command_uses_expected_flags(tmp_path: Path) -> None:
    agent = padauk_agent(cache_dir=tmp_path)
    config = ServeConfig(
        host="0.0.0.0",
        port=9000,
        model_alias="padauk-agent",
        n_ctx=4096,
        n_gpu_layers=12,
        api_key="sk-test",
    )

    command = agent._build_standalone_server_command(
        config,
        Path("/models/padauk.gguf"),
        Path("/usr/local/bin/llama-server"),
    )

    assert command == [
        "/usr/local/bin/llama-server",
        "--model",
        "/models/padauk.gguf",
        "--alias",
        "padauk-agent",
        "--host",
        "0.0.0.0",
        "--port",
        "9000",
        "--ctx-size",
        "4096",
        "--n-gpu-layers",
        "12",
        "--api-key",
        "sk-test",
    ]


def test_serve_auto_prefers_standalone_for_shared_kv(monkeypatch, tmp_path: Path) -> None:
    model_path = tmp_path / "good.gguf"
    model_path.write_bytes(b"GGUFpayload")
    standalone = tmp_path / "llama-server"
    standalone.write_text("", encoding="utf-8")
    standalone.chmod(0o755)
    popen_calls: list[list[str]] = []

    class _FakeProcess:
        def poll(self) -> None:
            return None

    agent = padauk_agent(cache_dir=tmp_path)
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)
    monkeypatch.setattr(
        "burmesegpt.agent.read_gguf_metadata",
        lambda _path: {
            "general.architecture": "gemma4",
            "gemma4.attention.shared_kv_layers": 18,
        },
    )
    monkeypatch.setattr(agent, "_discover_llama_server", lambda _path: standalone)
    monkeypatch.setattr(
        agent,
        "_validate_runtime_load",
        lambda _path: (_ for _ in ()).throw(AssertionError("python runtime should not be used")),
    )
    monkeypatch.setattr(
        "burmesegpt.agent.subprocess.Popen",
        lambda command, text=True: popen_calls.append(command) or _FakeProcess(),
    )

    process = agent.serve(wait=False)

    assert process is not None
    assert popen_calls == [
        [
            str(standalone),
            "--model",
            str(model_path),
            "--alias",
            "padauk-agent",
            "--host",
            "127.0.0.1",
            "--port",
            "8000",
            "--ctx-size",
            "8192",
            "--n-gpu-layers",
            "-1",
            "--api-key",
            "sk-no-key-required",
        ]
    ]


def test_serve_backend_python_keeps_llama_cpp_path(monkeypatch, tmp_path: Path) -> None:
    model_path = tmp_path / "good.gguf"
    model_path.write_bytes(b"GGUFpayload")
    popen_calls: list[list[str]] = []

    class _FakeProcess:
        def poll(self) -> None:
            return None

    agent = padauk_agent(cache_dir=tmp_path)
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)
    monkeypatch.setattr("burmesegpt.agent.read_gguf_metadata", lambda _path: {})
    monkeypatch.setattr(agent, "_discover_llama_server", lambda _path: None)
    monkeypatch.setattr(agent, "_validate_runtime_load", lambda _path: None)
    monkeypatch.setattr(
        "burmesegpt.agent.subprocess.Popen",
        lambda command, text=True: popen_calls.append(command) or _FakeProcess(),
    )

    process = agent.serve(wait=False, backend=SERVE_BACKEND_PYTHON)

    assert process is not None
    assert popen_calls
    assert popen_calls[0][:3] == [sys.executable, "-m", "llama_cpp.server"]


def test_serve_standalone_requires_binary(monkeypatch, tmp_path: Path) -> None:
    model_path = tmp_path / "good.gguf"
    model_path.write_bytes(b"GGUFpayload")

    agent = padauk_agent(cache_dir=tmp_path)
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)
    monkeypatch.setattr("burmesegpt.agent.read_gguf_metadata", lambda _path: {})
    monkeypatch.setattr(agent, "_discover_llama_server", lambda _path=None: None)

    with pytest.raises(ServerLaunchError, match="no executable llama-server was found"):
        agent.serve(wait=False, backend=SERVE_BACKEND_STANDALONE)


def test_serve_auto_uses_python_for_non_shared_kv(monkeypatch, tmp_path: Path) -> None:
    model_path = tmp_path / "good.gguf"
    model_path.write_bytes(b"GGUFpayload")
    popen_calls: list[list[str]] = []

    class _FakeProcess:
        def poll(self) -> None:
            return None

    agent = padauk_agent(cache_dir=tmp_path)
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)
    monkeypatch.setattr("burmesegpt.agent.read_gguf_metadata", lambda _path: {})
    monkeypatch.setattr(agent, "_discover_llama_server", lambda _path: None)
    monkeypatch.setattr(agent, "_validate_runtime_load", lambda _path: None)
    monkeypatch.setattr(
        "burmesegpt.agent.subprocess.Popen",
        lambda command, text=True: popen_calls.append(command) or _FakeProcess(),
    )

    process = agent.serve(wait=False)

    assert process is not None
    assert popen_calls
    assert popen_calls[0][:3] == [sys.executable, "-m", "llama_cpp.server"]


def test_select_serve_backend_allows_python_override(monkeypatch, tmp_path: Path) -> None:
    agent = padauk_agent(cache_dir=tmp_path)
    monkeypatch.setattr(agent, "_discover_llama_server", lambda _path: tmp_path / "llama-server")
    backend, standalone_path = agent._select_serve_backend(
        config=ServeConfig(backend=SERVE_BACKEND_PYTHON),
        metadata={"general.architecture": "gemma4", "gemma4.attention.shared_kv_layers": 18},
    )

    assert backend == SERVE_BACKEND_PYTHON
    assert standalone_path is None
