#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from burmesegpt.release_pipeline import (  # noqa: E402
    PADAUK_GGUF_REPO_ID,
    PADAUK_SOURCE_REPO_ID,
    ReleasePipelineError,
    assert_padauk_gguf_metadata,
    file_sha256,
    update_manifest_sha256_text,
    update_sha256sums_text,
    verify_converter_python_env,
    verify_llama_cpp_checkout,
    verify_padauk_source_tree,
)

DEFAULT_OUT_DIR = ROOT / "build" / "gguf-release"
DEFAULT_F16_NAME = "padauk-f16.gguf"
DEFAULT_Q8_NAME = "padauk-gemma-q8_0.gguf"


def _run(command: list[str]) -> None:
    subprocess.run(command, check=True)


def _print_source_report(hf_src: Path) -> None:
    report = verify_padauk_source_tree(hf_src)
    print(f"Source repo check passed: {hf_src}")
    print(f"  text layers: {report.num_hidden_layers}")
    print(f"  shared KV tail layers: {report.num_kv_shared_layers}")
    print(f"  non-shared KV layers: 0..{report.first_shared_kv_layer - 1}")
    print(f"  shard count: {len(report.shard_files)}")


def _check_llama_cpp(llama_cpp_dir: Path) -> None:
    head = verify_llama_cpp_checkout(llama_cpp_dir)
    print(f"llama.cpp compatibility check passed: {llama_cpp_dir} ({head})")


def _paths(args: argparse.Namespace) -> tuple[Path, Path, Path]:
    out_dir = args.out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    f16_path = out_dir / DEFAULT_F16_NAME
    q8_path = out_dir / DEFAULT_Q8_NAME
    return out_dir, f16_path, q8_path


def cmd_preflight(args: argparse.Namespace) -> int:
    _check_llama_cpp(args.llama_cpp_dir)
    versions = verify_converter_python_env()
    print(
        "Converter environment check passed: "
        + ", ".join(f"{name}={version}" for name, version in sorted(versions.items()))
    )
    _print_source_report(args.hf_src)
    return 0


def cmd_convert_f16(args: argparse.Namespace) -> int:
    _check_llama_cpp(args.llama_cpp_dir)
    versions = verify_converter_python_env()
    print(
        "Converter environment check passed: "
        + ", ".join(f"{name}={version}" for name, version in sorted(versions.items()))
    )
    _print_source_report(args.hf_src)
    _, f16_path, _ = _paths(args)
    convert_script = args.llama_cpp_dir / "convert_hf_to_gguf.py"
    if not convert_script.exists():
        raise ReleasePipelineError(f"Missing converter script: {convert_script}")
    _run(
        [
            sys.executable,
            str(convert_script),
            str(args.hf_src),
            "--outfile",
            str(f16_path),
            "--outtype",
            "f16",
        ]
    )
    assert_padauk_gguf_metadata(f16_path)
    print(f"Created F16 GGUF: {f16_path}")
    return 0


def cmd_validate_gguf(args: argparse.Namespace) -> int:
    _check_llama_cpp(args.llama_cpp_dir)
    model_path = args.model.resolve()
    metadata = assert_padauk_gguf_metadata(model_path)
    print(
        f"GGUF metadata check passed: architecture={metadata['general.architecture']}, "
        f"shared_kv_layers={metadata['gemma4.attention.shared_kv_layers']}"
    )
    llama_bin_dir = args.llama_cpp_dir / "build" / "bin"
    validate_binary = llama_bin_dir / "llama-cli"
    if not validate_binary.exists():
        raise ReleasePipelineError(f"Missing llama validation binary in {llama_bin_dir}")
    # Keep the smoke test on llama-cli so Gemma 4 never enters the chat-template/Jinja path.
    runtime_smoke_cmd = [
        str(validate_binary),
        "-m",
        str(model_path),
        "-ngl",
        "0",
        "-c",
        "256",
        "-b",
        "64",
        "-p",
        "hello",
        "-n",
        "1",
        "-no-cnv",
        "--single-turn",
        "--simple-io",
        "--no-warmup",
    ]
    _run(runtime_smoke_cmd)
    print(f"Runtime load validation passed: {model_path}")
    return 0


def cmd_quantize_q8(args: argparse.Namespace) -> int:
    _check_llama_cpp(args.llama_cpp_dir)
    _, f16_path, q8_path = _paths(args)
    if not f16_path.exists():
        raise ReleasePipelineError(f"Missing F16 input GGUF: {f16_path}")
    quantize = args.llama_cpp_dir / "build" / "bin" / "llama-quantize"
    if not quantize.exists():
        raise ReleasePipelineError(f"Missing llama-quantize binary: {quantize}")
    _run([str(quantize), str(f16_path), str(q8_path), "Q8_0"])
    assert_padauk_gguf_metadata(q8_path)
    print(f"Created Q8_0 GGUF: {q8_path}")
    return 0


def cmd_write_sha256(args: argparse.Namespace) -> int:
    out_dir, _, q8_path = _paths(args)
    if not q8_path.exists():
        raise ReleasePipelineError(f"Missing Q8_0 GGUF: {q8_path}")
    sha256_value = file_sha256(q8_path)
    sha_path = out_dir / "SHA256SUMS.txt"
    sha_path.write_text(f"{sha256_value}  {q8_path.name}\n", encoding="utf-8")
    print(f"Wrote SHA256SUMS: {sha_path}")
    print(f"{sha256_value}  {q8_path.name}")
    return 0


def cmd_update_release_metadata(args: argparse.Namespace) -> int:
    out_dir, _, q8_path = _paths(args)
    sha_path = out_dir / "SHA256SUMS.txt"
    if not q8_path.exists():
        raise ReleasePipelineError(f"Missing Q8_0 GGUF: {q8_path}")
    if not sha_path.exists():
        raise ReleasePipelineError(f"Missing checksum file: {sha_path}")

    sha256_value = file_sha256(q8_path)
    manifest_path = ROOT / "src" / "burmesegpt" / "manifest.py"
    model_sha_path = ROOT / "model" / "SHA256SUMS.txt"

    manifest_text = manifest_path.read_text(encoding="utf-8")
    manifest_path.write_text(
        update_manifest_sha256_text(manifest_text, "q8_0", sha256_value),
        encoding="utf-8",
    )

    if model_sha_path.exists():
        current_sha_text = model_sha_path.read_text(encoding="utf-8")
    else:
        current_sha_text = ""
    model_sha_path.write_text(
        update_sha256sums_text(current_sha_text, q8_path.name, sha256_value),
        encoding="utf-8",
    )

    print(f"Updated manifest hash for q8_0 in {manifest_path}")
    print(f"Updated local checksum file in {model_sha_path}")
    print(f"Source repo: {PADAUK_SOURCE_REPO_ID}")
    print(f"GGUF repo: {PADAUK_GGUF_REPO_ID}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build and validate Padauk Gemma 4 GGUF artifacts with shared-KV safety checks."
    )
    parser.add_argument(
        "--llama-cpp-dir",
        type=Path,
        required=True,
        help="Path to a standalone llama.cpp checkout (minimum b8751, recommended b8833).",
    )
    parser.add_argument(
        "--hf-src",
        type=Path,
        required=True,
        help=f"Local source model checkout downloaded from {PADAUK_SOURCE_REPO_ID}.",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=DEFAULT_OUT_DIR,
        help=f"Output directory for built GGUF artifacts (default: {DEFAULT_OUT_DIR}).",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    preflight = subparsers.add_parser("preflight", help="Verify source repo completeness and llama.cpp compatibility.")
    preflight.set_defaults(func=cmd_preflight)

    convert_f16 = subparsers.add_parser("convert-f16", help="Convert the HF source checkpoint to an F16 GGUF.")
    convert_f16.set_defaults(func=cmd_convert_f16)

    validate_gguf = subparsers.add_parser("validate-gguf", help="Validate GGUF metadata and runtime load with llama-cli.")
    validate_gguf.add_argument("--model", type=Path, required=True, help="GGUF model file to validate.")
    validate_gguf.set_defaults(func=cmd_validate_gguf)

    quantize_q8 = subparsers.add_parser("quantize-q8_0", help="Quantize the F16 GGUF to Q8_0.")
    quantize_q8.set_defaults(func=cmd_quantize_q8)

    write_sha = subparsers.add_parser("write-sha256", help="Write SHA256SUMS.txt for the Q8_0 artifact.")
    write_sha.set_defaults(func=cmd_write_sha256)

    update_metadata = subparsers.add_parser(
        "update-release-metadata",
        help="Update package manifest and local checksum metadata from the validated Q8_0 artifact.",
    )
    update_metadata.set_defaults(func=cmd_update_release_metadata)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except ReleasePipelineError as exc:
        print(f"Release pipeline failed: {exc}", file=sys.stderr)
        return 1
    except subprocess.CalledProcessError as exc:
        print(f"Command failed with exit code {exc.returncode}: {' '.join(exc.cmd)}", file=sys.stderr)
        return exc.returncode or 1


if __name__ == "__main__":
    raise SystemExit(main())
