# PyPI Release Guide (Manual)

Maintainer-only release flow for `burmesegpt`. This is separate from end-user install and usage.

Package extras stay unchanged:

- `server` and `full` still depend on `llama-cpp-python[server]`.
- `openai` still installs the OpenAI client integration.
- `dev` still carries build, test, and publishing helpers.

That dependency layout does not mean the current PyPI `llama-cpp-python` build is the maintainer authority for Gemma 4 shared-KV serving. For Gemma 4 conversion, smoke tests, and GGUF release validation, use a standalone `llama.cpp` source build pinned to `b8833`, with `b8751` as the minimum supported floor.

## 1) Prerequisites

- Python packaging tools:

```bash
python -m pip install --upgrade build twine
```

- PyPI account (and TestPyPI account if using staging first).
- Bump `version` in `pyproject.toml` before building.

## 2) Clean and Build

```bash
rm -rf dist build *.egg-info
python -m build
```

Expected output: both `dist/*.tar.gz` (sdist) and `dist/*.whl` (wheel).

## 3) Validate Package Metadata

```bash
twine check dist/*
```

Fix any rendering or metadata errors before upload.

## 4) Release Gate

Do not upload until these pass:

1. `make preflight` passes.
2. `make gguf-release` produces the final GGUF artifacts intended for upload.
3. Checksum sync: regenerate `SHA256SUMS.txt` for release GGUF files and sync pinned hashes (if used) for package release.
4. GGUF magic check: verify the first 4 bytes are `b'GGUF'` for each GGUF artifact.
5. Runtime load check: run a local `llama-cli` load or smoke test from the standalone pinned `llama.cpp` build against the artifact before release.
6. Conditional validation: if `burmesegpt validate` exists in this codebase, run it locally and require it to pass. If it does not exist, use the checks above.

Treat `make preflight` as the validation gate. If it fails, stop the release even if packaging metadata is otherwise ready.

## 5) Token Setup (Twine)

Create API tokens in:
- TestPyPI: <https://test.pypi.org/manage/account/token/>
- PyPI: <https://pypi.org/manage/account/token/>

Set credentials in shell:

```bash
export TWINE_USERNAME="__token__"
export TWINE_PASSWORD="pypi-<your-token>"
```

For TestPyPI, replace `TWINE_PASSWORD` with your `pypi-...` TestPyPI token.

## 6) Optional: TestPyPI First

Upload:

```bash
twine upload --repository-url https://test.pypi.org/legacy/ dist/*
```

Install smoke test:

```bash
python -m pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple burmesegpt
python -m pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple "burmesegpt[server]"
burmesegpt info
```

## 7) Upload to PyPI

```bash
twine upload dist/*
```

Then verify:
- <https://pypi.org/project/burmesegpt/>
- install works for `burmesegpt` and `burmesegpt[server]`
- key CLI paths (`download`, `serve`, `run`, `info`) still work
- Gemma 4 maintainers: do not use this PyPI smoke test as the only serving proof for shared-KV releases; keep the standalone `llama.cpp` validation in the GGUF flow.

## 8) Trusted Publishing (Recommended)

Manual `twine` uploads rely on long-lived API tokens.  
Trusted Publishing lets CI (for example, GitHub Actions) publish via short-lived OIDC credentials without storing PyPI tokens.

If you automate releases later, configure a trusted publisher in PyPI and keep `twine` as a local fallback.

### GitHub Trusted Publisher fields (PyPI Pending Publisher)

For this repo/workflow (`.github/workflows/publish-pypi.yml`), use:

- Owner: `WaiYanNyeinNaing`
- Repository name: `burmese-gpt-pypi-api`
- Workflow name: `publish-pypi.yml`
- Environment name: `pypi`

These values must match the GitHub workflow exactly, including the `environment.name` in the `publish` job.
