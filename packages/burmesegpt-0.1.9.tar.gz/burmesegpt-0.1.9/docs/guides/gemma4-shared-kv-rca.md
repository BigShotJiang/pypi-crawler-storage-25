# Gemma 4 Shared-KV RCA

## Summary

The documentation previously blurred three separate concerns:

- converting from the source Hugging Face checkpoint repo,
- publishing validated artifacts to the GGUF repo,
- and serving through the packaged PyPI `llama-cpp-python` dependency.

That was acceptable for older flows, but it is not precise enough for Gemma 4 shared-KV models.

## Root Cause

Gemma 4 shared-KV support depends on runtime behavior in `llama.cpp` that is newer than the currently documented packaged PyPI serving path. The docs implied that:

- downloading from any Hugging Face repo was interchangeable,
- "latest source build" was specific enough for reproducible release work,
- and PyPI `llama-cpp-python` serving was an adequate proof point for Gemma 4.

Those assumptions make the maintainer path non-reproducible and can hide runtime mismatches until after a GGUF is published.

## Documentation Policy After This Fix

- Convert only from the source HF checkpoint repo, never from the published GGUF repo.
- Pin standalone `llama.cpp` release work to `b8833`.
- Treat `b8751` as the minimum supported floor for Gemma 4 shared-KV work.
- Use `make preflight` and `make gguf-release` as the maintainer workflow and release gate.
- Keep PyPI extras `server`, `openai`, `full`, and `dev` as documented package options, but do not claim that the current PyPI `llama-cpp-python` build alone is sufficient for Gemma 4 shared-KV serving validation.

## Scope

This RCA is documentation-only. It does not change package dependencies or runtime code in this worktree.
