# PyPI Install Quickstart (User Guide)

Use this guide for the shortest working path: install, download, run, and test.

## Requirements

- Python `>=3.10`
- Internet access for PyPI and model download
- a working `llama-server` binary

## 1) Install From PyPI

```bash
python3 -m venv .venv
source .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install "burmesegpt[full]"
```

If `python3` is below 3.10:

```bash
/opt/homebrew/bin/python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install "burmesegpt[full]"
```

## 2) Download Model

```bash
export BURMESEGPT_LLAMA_SERVER="$HOME/llama.cpp/build/bin/llama-server"
burmesegpt download --quant q8_0
```

## 3) Run Local API Server

```bash
burmesegpt serve --quant q8_0 --backend auto --host 127.0.0.1 --port 8000
```

If your `llama-server` binary is in a different location, point to it explicitly:

```bash
export BURMESEGPT_LLAMA_SERVER="/absolute/path/to/llama-server"
```

## 4) Test API With curl

In another terminal:

```bash
source .venv/bin/activate
curl http://127.0.0.1:8000/v1/models
```

```bash
source .venv/bin/activate
curl http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk-no-key-required" \
  -d '{
    "model": "padauk-agent",
    "messages": [{"role": "user", "content": "မင်္ဂလာပါ"}]
  }'
```

## 5) Test With OpenAI Agents SDK

```bash
source .venv/bin/activate
python -m pip install openai-agents
```

```python
import asyncio

from openai import AsyncOpenAI
from agents import Agent, Runner, set_default_openai_api, set_default_openai_client, set_tracing_disabled

set_tracing_disabled(True)
set_default_openai_api("chat_completions")
set_default_openai_client(
    AsyncOpenAI(base_url="http://127.0.0.1:8000/v1", api_key="sk-no-key-required")
)

padauk = Agent(name="Padauk Assistant", model="padauk-agent", instructions="Reply in Burmese by default.")

async def main() -> None:
    result = await Runner.run(padauk, input="မင်္ဂလာပါ")
    print(result.final_output)

asyncio.run(main())
```

## 6) Need The Advanced Maintainer Docs?

If you are rebuilding or publishing the model, use:

- `docs/guides/hf-to-gguf-quantization-guide.md`
- `docs/guides/pypi-release-guide.md`
