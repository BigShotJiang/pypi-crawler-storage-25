from __future__ import annotations

import hashlib
import importlib
import importlib.metadata
import json
import re
import struct
import sys
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO


PADAUK_SOURCE_REPO_ID = "WYNN747/Burmese-GPT-Padauk"
PADAUK_GGUF_REPO_ID = "WYNN747/padauk-burmese-agentic-llm"
GEMMA4_SHARED_KV_FIX_COMMIT = "e62fa13c2497b2cd1958cb496e9489e86bbd5182"
MIN_LLAMA_CPP_TAG = "b8751"
RECOMMENDED_LLAMA_CPP_TAG = "b8833"
GEMMA4_SHARED_KV_ERROR_PATTERN = re.compile(
    r"missing tensor 'blk\.(?P<layer>\d+)\.attn_k(?:_norm)?\.weight'"
)

_TEXT_PROJ_PATTERNS = {
    "q_proj": re.compile(r"^model\.language_model\.layers\.(\d+)\.self_attn\.q_proj\.weight$"),
    "k_proj": re.compile(r"^model\.language_model\.layers\.(\d+)\.self_attn\.k_proj\.weight$"),
    "v_proj": re.compile(r"^model\.language_model\.layers\.(\d+)\.self_attn\.v_proj\.weight$"),
    "o_proj": re.compile(r"^model\.language_model\.layers\.(\d+)\.self_attn\.o_proj\.weight$"),
}


class ReleasePipelineError(RuntimeError):
    """Raised when a maintainer GGUF release step fails."""


@dataclass(frozen=True)
class SourceRepoInspection:
    source_dir: Path
    num_hidden_layers: int
    num_kv_shared_layers: int
    shard_files: tuple[str, ...]
    q_proj_layers: tuple[int, ...]
    k_proj_layers: tuple[int, ...]
    v_proj_layers: tuple[int, ...]
    o_proj_layers: tuple[int, ...]

    @property
    def first_shared_kv_layer(self) -> int:
        return self.num_hidden_layers - self.num_kv_shared_layers


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ReleasePipelineError(f"Unable to read {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise ReleasePipelineError(f"Invalid JSON in {path}: {exc}") from exc


def _collect_layers(weight_map: dict[str, str], proj_name: str) -> tuple[int, ...]:
    pattern = _TEXT_PROJ_PATTERNS[proj_name]
    layers = sorted(
        int(match.group(1))
        for name in weight_map
        if (match := pattern.match(name))
    )
    return tuple(layers)


def verify_padauk_source_tree(source_dir: Path) -> SourceRepoInspection:
    required_files = [
        "config.json",
        "tokenizer_config.json",
        "model.safetensors.index.json",
    ]
    missing_files = [name for name in required_files if not (source_dir / name).exists()]
    if missing_files:
        missing = ", ".join(missing_files)
        raise ReleasePipelineError(f"Missing required source files in {source_dir}: {missing}")

    tokenizer_candidates = ["tokenizer.json", "tokenizer.model"]
    if not any((source_dir / name).exists() for name in tokenizer_candidates):
        joined = ", ".join(tokenizer_candidates)
        raise ReleasePipelineError(
            f"Missing tokenizer files in {source_dir}: expected at least one of {joined}"
        )

    config = _load_json(source_dir / "config.json")
    index = _load_json(source_dir / "model.safetensors.index.json")

    text_config = config.get("text_config") or {}
    num_hidden_layers = text_config.get("num_hidden_layers")
    num_kv_shared_layers = text_config.get("num_kv_shared_layers")
    if not isinstance(num_hidden_layers, int) or not isinstance(num_kv_shared_layers, int):
        raise ReleasePipelineError(
            "config.json is missing text_config.num_hidden_layers or text_config.num_kv_shared_layers"
        )

    weight_map = index.get("weight_map")
    if not isinstance(weight_map, dict) or not weight_map:
        raise ReleasePipelineError("model.safetensors.index.json is missing a valid weight_map")

    shard_files = tuple(sorted(set(weight_map.values())))
    missing_shards = [name for name in shard_files if not (source_dir / name).exists()]
    if missing_shards:
        missing = ", ".join(missing_shards)
        raise ReleasePipelineError(f"Missing safetensor shards in {source_dir}: {missing}")

    q_proj_layers = _collect_layers(weight_map, "q_proj")
    k_proj_layers = _collect_layers(weight_map, "k_proj")
    v_proj_layers = _collect_layers(weight_map, "v_proj")
    o_proj_layers = _collect_layers(weight_map, "o_proj")

    expected_all_layers = tuple(range(num_hidden_layers))
    first_shared_kv_layer = num_hidden_layers - num_kv_shared_layers
    expected_kv_layers = tuple(range(first_shared_kv_layer))

    if q_proj_layers != expected_all_layers:
        raise ReleasePipelineError(
            f"q_proj layers do not match 0..{num_hidden_layers - 1}: found {list(q_proj_layers)}"
        )
    if o_proj_layers != expected_all_layers:
        raise ReleasePipelineError(
            f"o_proj layers do not match 0..{num_hidden_layers - 1}: found {list(o_proj_layers)}"
        )
    if k_proj_layers != expected_kv_layers:
        raise ReleasePipelineError(
            "k_proj layers do not match Gemma 4 shared-KV layout: "
            f"expected {list(expected_kv_layers)}, found {list(k_proj_layers)}"
        )
    if v_proj_layers != expected_kv_layers:
        raise ReleasePipelineError(
            "v_proj layers do not match Gemma 4 shared-KV layout: "
            f"expected {list(expected_kv_layers)}, found {list(v_proj_layers)}"
        )

    return SourceRepoInspection(
        source_dir=source_dir,
        num_hidden_layers=num_hidden_layers,
        num_kv_shared_layers=num_kv_shared_layers,
        shard_files=shard_files,
        q_proj_layers=q_proj_layers,
        k_proj_layers=k_proj_layers,
        v_proj_layers=v_proj_layers,
        o_proj_layers=o_proj_layers,
    )


def _read_exact(fh: BinaryIO, size: int) -> bytes:
    data = fh.read(size)
    if len(data) != size:
        raise ReleasePipelineError(f"Unexpected end of GGUF metadata while reading {size} bytes")
    return data


def _read_string(fh: BinaryIO) -> str:
    length = struct.unpack("<Q", _read_exact(fh, 8))[0]
    return _read_exact(fh, length).decode("utf-8", "replace")


def _read_value(fh: BinaryIO, value_type: int) -> Any:
    if value_type == 8:
        return _read_string(fh)
    if value_type == 9:
        subtype = struct.unpack("<I", _read_exact(fh, 4))[0]
        length = struct.unpack("<Q", _read_exact(fh, 8))[0]
        values = []
        for _ in range(length):
            values.append(_read_value(fh, subtype))
        return values
    if value_type == 7:
        return bool(struct.unpack("<?", _read_exact(fh, 1))[0])

    fmt_map = {
        0: "<B",
        1: "<b",
        2: "<H",
        3: "<h",
        4: "<I",
        5: "<i",
        6: "<f",
        10: "<Q",
        11: "<q",
        12: "<d",
    }
    fmt = fmt_map.get(value_type)
    if fmt is None:
        raise ReleasePipelineError(f"Unsupported GGUF value type: {value_type}")
    return struct.unpack(fmt, _read_exact(fh, struct.calcsize(fmt)))[0]


def read_gguf_metadata(path: Path) -> dict[str, Any]:
    try:
        with path.open("rb") as fh:
            magic = _read_exact(fh, 4)
            if magic != b"GGUF":
                raise ReleasePipelineError(f"Invalid GGUF header in {path}: found {magic!r}")

            version = struct.unpack("<I", _read_exact(fh, 4))[0]
            if version == 1:
                _ = struct.unpack("<I", _read_exact(fh, 4))[0]
                n_kv = struct.unpack("<I", _read_exact(fh, 4))[0]
            else:
                _ = struct.unpack("<Q", _read_exact(fh, 8))[0]
                n_kv = struct.unpack("<Q", _read_exact(fh, 8))[0]

            metadata: dict[str, Any] = {}
            for _ in range(n_kv):
                key = _read_string(fh)
                value_type = struct.unpack("<I", _read_exact(fh, 4))[0]
                metadata[key] = _read_value(fh, value_type)
    except OSError as exc:
        raise ReleasePipelineError(f"Unable to read GGUF file {path}: {exc}") from exc
    except struct.error as exc:
        raise ReleasePipelineError(
            f"Unable to parse GGUF metadata from {path}; file may be truncated: {exc}"
        ) from exc

    return metadata


def assert_padauk_gguf_metadata(
    path: Path,
    *,
    expected_architecture: str = "gemma4",
    expected_shared_kv_layers: int = 18,
) -> dict[str, Any]:
    metadata = read_gguf_metadata(path)
    architecture = metadata.get("general.architecture")
    shared_kv_layers = metadata.get("gemma4.attention.shared_kv_layers")

    if architecture != expected_architecture:
        raise ReleasePipelineError(
            f"Unexpected GGUF architecture for {path}: expected {expected_architecture}, found {architecture!r}"
        )
    if shared_kv_layers != expected_shared_kv_layers:
        raise ReleasePipelineError(
            f"Unexpected Gemma 4 shared_kv_layers for {path}: "
            f"expected {expected_shared_kv_layers}, found {shared_kv_layers!r}"
        )
    return metadata


def looks_like_gemma4_shared_kv_metadata(metadata: dict[str, Any] | None) -> bool:
    if not metadata:
        return False
    return (
        metadata.get("general.architecture") == "gemma4"
        and metadata.get("gemma4.attention.shared_kv_layers") == 18
    )


def is_gemma4_shared_kv_runtime_error(exc: Exception, metadata: dict[str, Any] | None) -> bool:
    if not looks_like_gemma4_shared_kv_metadata(metadata):
        return False
    return bool(GEMMA4_SHARED_KV_ERROR_PATTERN.search(str(exc)))


def gemma4_shared_kv_runtime_guidance() -> str:
    return (
        "This GGUF uses Gemma 4 shared-KV tail layers. The currently published "
        "llama-cpp-python wheels still vendor a llama.cpp revision older than the April 10, 2026 "
        f"shared-KV load fix ({MIN_LLAMA_CPP_TAG} minimum, {RECOMMENDED_LLAMA_CPP_TAG} recommended). "
        "Use standalone llama.cpp >= b8751, ideally b8833, or build llama-cpp-python from source "
        "against a newer llama.cpp checkout."
    )


def verify_converter_python_env() -> dict[str, str]:
    if sys.version_info < (3, 10):
        version = ".".join(str(part) for part in sys.version_info[:3])
        raise ReleasePipelineError(
            f"Converter environment is using Python {version}. Use Python 3.10 or newer for this workflow."
        )

    versions: dict[str, str] = {}
    for package_name in ("transformers", "huggingface_hub", "safetensors"):
        try:
            versions[package_name] = importlib.metadata.version(package_name)
        except importlib.metadata.PackageNotFoundError as exc:
            raise ReleasePipelineError(
                f'Missing "{package_name}" in the converter environment. '
                "Install llama.cpp conversion requirements into a clean venv first."
            ) from exc

    try:
        importlib.import_module("transformers")
        importlib.import_module("huggingface_hub")
        from transformers import AutoConfig  # noqa: F401
        from huggingface_hub import snapshot_download  # noqa: F401
    except Exception as exc:
        details = ", ".join(f"{name}={version}" for name, version in sorted(versions.items()))
        raise ReleasePipelineError(
            "Converter Python environment is inconsistent. "
            f"Detected packages: {details}. "
            "Recreate the venv, install only llama.cpp conversion requirements first, then add "
            '"huggingface_hub[cli]" without upgrading transformers or huggingface_hub past that solver result.'
        ) from exc

    return versions


def verify_llama_cpp_checkout(llama_cpp_dir: Path) -> str:
    if not (llama_cpp_dir / ".git").exists():
        raise ReleasePipelineError(f"{llama_cpp_dir} is not a git checkout of llama.cpp")

    head = subprocess.run(
        ["git", "-C", str(llama_cpp_dir), "rev-parse", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()

    compatible = subprocess.run(
        [
            "git",
            "-C",
            str(llama_cpp_dir),
            "merge-base",
            "--is-ancestor",
            GEMMA4_SHARED_KV_FIX_COMMIT,
            "HEAD",
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    if compatible.returncode != 0:
        raise ReleasePipelineError(
            f"llama.cpp checkout at {llama_cpp_dir} ({head}) is too old for Gemma 4 shared-KV GGUFs. "
            f"Use at least {MIN_LLAMA_CPP_TAG}; {RECOMMENDED_LLAMA_CPP_TAG} is the recommended pinned target."
        )
    return head


def update_manifest_sha256_text(text: str, quant: str, sha256_value: str) -> str:
    block_pattern = re.compile(
        r"(PACKAGE_SHA256: dict\[str, str \| None\] = \{\n)(.*?)(\n\})",
        re.DOTALL,
    )
    match = block_pattern.search(text)
    if match is None:
        raise ReleasePipelineError("Could not locate PACKAGE_SHA256 block in manifest.py")

    body = match.group(2)
    entry_pattern = re.compile(rf'("{re.escape(quant)}": )(".*?"|None)')
    replacement = rf'\1"{sha256_value}"'
    updated_body, count = entry_pattern.subn(replacement, body, count=1)
    if count != 1:
        raise ReleasePipelineError(f'Could not update PACKAGE_SHA256 entry for "{quant}"')
    return text[: match.start(2)] + updated_body + text[match.end(2) :]


def update_sha256sums_text(text: str, filename: str, sha256_value: str) -> str:
    lines = text.splitlines()
    output: list[str] = []
    replaced = False
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        parts = stripped.split()
        if len(parts) >= 2 and parts[-1] == filename:
            output.append(f"{sha256_value}  {filename}")
            replaced = True
        else:
            output.append(stripped)
    if not replaced:
        output.append(f"{sha256_value}  {filename}")
    return "\n".join(output) + "\n"
