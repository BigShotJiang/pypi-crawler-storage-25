from __future__ import annotations

__all__ = ["PadaukAgent", "padauk_agent"]


def __getattr__(name: str):
    if name in {"PadaukAgent", "padauk_agent"}:
        from .agent import PadaukAgent, padauk_agent

        return {"PadaukAgent": PadaukAgent, "padauk_agent": padauk_agent}[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
