"""Tests for annotation support (Phase 1 + 2)."""
import pytest
from vital_ai_vitalsigns.model.annotation import AnnotationValue
from vital_ai_vitalsigns.impl.annotation_registry import (
    is_annotation_property,
    register_annotation_property,
    unregister_annotation_property,
)

RDFS_LABEL = 'http://www.w3.org/2000/01/rdf-schema#label'
RDFS_COMMENT = 'http://www.w3.org/2000/01/rdf-schema#comment'


# --- AnnotationValue ---

class TestAnnotationValue:

    def test_basic_creation(self):
        av = AnnotationValue("hello")
        assert str(av) == "hello"
        assert av.lang is None

    def test_creation_with_lang(self):
        av = AnnotationValue("bonjour", lang="fr")
        assert str(av) == "bonjour"
        assert av.lang == "fr"

    def test_equality(self):
        a = AnnotationValue("hello", lang="en")
        b = AnnotationValue("hello", lang="en")
        assert a == b

    def test_inequality_value(self):
        a = AnnotationValue("hello", lang="en")
        b = AnnotationValue("world", lang="en")
        assert a != b

    def test_inequality_lang(self):
        a = AnnotationValue("hello", lang="en")
        b = AnnotationValue("hello", lang="fr")
        assert a != b

    def test_equality_with_string(self):
        av = AnnotationValue("hello")
        assert av == "hello"

    def test_hash(self):
        a = AnnotationValue("hello", lang="en")
        b = AnnotationValue("hello", lang="en")
        assert hash(a) == hash(b)
        s = {a, b}
        assert len(s) == 1

    def test_repr(self):
        av = AnnotationValue("hello")
        assert "AnnotationValue" in repr(av)

    def test_repr_with_lang(self):
        av = AnnotationValue("hello", lang="en")
        assert "lang='en'" in repr(av)

    def test_to_json(self):
        av = AnnotationValue("hello")
        assert av.to_json() == {"value": "hello"}

    def test_to_json_with_lang(self):
        av = AnnotationValue("hello", lang="en")
        assert av.to_json() == {"value": "hello", "lang": "en"}

    def test_from_json_string(self):
        av = AnnotationValue.from_json("hello")
        assert str(av) == "hello"
        assert av.lang is None

    def test_from_json_dict(self):
        av = AnnotationValue.from_json({"value": "hello", "lang": "en"})
        assert str(av) == "hello"
        assert av.lang == "en"

    def test_to_rdf_inherits_iproperty(self):
        av = AnnotationValue("hello", lang="en")
        rdf = av.to_rdf()
        assert rdf["lang"] == "en"
        assert rdf["value"] == "hello"


# --- Annotation Registry ---

class TestAnnotationRegistry:

    def test_known_uris(self):
        assert is_annotation_property(RDFS_LABEL)
        assert is_annotation_property(RDFS_COMMENT)
        assert is_annotation_property('http://www.w3.org/2002/07/owl#versionInfo')

    def test_unknown_uri(self):
        assert not is_annotation_property('http://example.org/foo')

    def test_register_custom(self):
        custom = 'http://example.org/custom-annotation'
        assert not is_annotation_property(custom)
        register_annotation_property(custom)
        assert is_annotation_property(custom)
        unregister_annotation_property(custom)
        assert not is_annotation_property(custom)


# --- GraphObject Annotation API ---

class TestGraphObjectAnnotationAPI:

    def _make_node(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        node = VITAL_Node()
        node.URI = "urn:ann-test-1"
        return node

    def test_set_and_get_annotation(self):
        node = self._make_node()
        node.set_annotation(RDFS_LABEL, "My Node")
        assert node.get_annotation(RDFS_LABEL) == "My Node"

    def test_set_annotation_none_removes(self):
        node = self._make_node()
        node.set_annotation(RDFS_LABEL, "My Node")
        node.set_annotation(RDFS_LABEL, None)
        assert node.get_annotation(RDFS_LABEL) is None

    def test_add_annotation_multiple(self):
        node = self._make_node()
        node.add_annotation(RDFS_LABEL, "Cat", lang="en")
        node.add_annotation(RDFS_LABEL, "Chat", lang="fr")
        values = node.get_annotations(RDFS_LABEL)
        assert len(values) == 2
        assert values[0] == AnnotationValue("Cat", lang="en")
        assert values[1] == AnnotationValue("Chat", lang="fr")

    def test_get_annotation_by_lang(self):
        node = self._make_node()
        node.add_annotation(RDFS_LABEL, "Cat", lang="en")
        node.add_annotation(RDFS_LABEL, "Chat", lang="fr")
        assert node.get_annotation(RDFS_LABEL, lang="en") == "Cat"
        assert node.get_annotation(RDFS_LABEL, lang="fr") == "Chat"
        assert node.get_annotation(RDFS_LABEL, lang="de") is None

    def test_remove_annotation_by_lang(self):
        node = self._make_node()
        node.add_annotation(RDFS_LABEL, "Cat", lang="en")
        node.add_annotation(RDFS_LABEL, "Chat", lang="fr")
        node.remove_annotation(RDFS_LABEL, lang="en")
        values = node.get_annotations(RDFS_LABEL)
        assert len(values) == 1
        assert values[0].lang == "fr"

    def test_remove_annotation_all(self):
        node = self._make_node()
        node.add_annotation(RDFS_LABEL, "Cat", lang="en")
        node.add_annotation(RDFS_LABEL, "Chat", lang="fr")
        node.remove_annotation(RDFS_LABEL)
        assert node.get_annotations(RDFS_LABEL) == []

    def test_get_annotations_empty(self):
        node = self._make_node()
        assert node.get_annotations(RDFS_LABEL) == []
        assert node.get_annotation(RDFS_LABEL) is None

    def test_set_annotation_marks_modified(self):
        node = self._make_node()
        node.mark_serialized()
        assert not node.is_modified()
        node.set_annotation(RDFS_LABEL, "Test")
        assert node.is_modified()

    def test_add_annotation_marks_modified(self):
        node = self._make_node()
        node.mark_serialized()
        node.add_annotation(RDFS_LABEL, "Test")
        assert node.is_modified()

    def test_remove_annotation_marks_modified(self):
        node = self._make_node()
        node.set_annotation(RDFS_LABEL, "Test")
        node.mark_serialized()
        node.remove_annotation(RDFS_LABEL)
        assert node.is_modified()


# --- Convenience Accessors ---

class TestConvenienceAccessors:

    def _make_node(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        node = VITAL_Node()
        node.URI = "urn:conv-test-1"
        return node

    def test_rdfs_label_setattr(self):
        node = self._make_node()
        node.rdfs_label = "My Label"
        assert node.get_annotation(RDFS_LABEL) == "My Label"

    def test_rdfs_label_getattr(self):
        node = self._make_node()
        node.set_annotation(RDFS_LABEL, "My Label")
        assert node.rdfs_label == "My Label"

    def test_rdfs_label_getattr_none(self):
        node = self._make_node()
        assert node.rdfs_label is None

    def test_rdfs_comment_setattr(self):
        node = self._make_node()
        node.rdfs_comment = "A comment"
        assert node.get_annotation(RDFS_COMMENT) == "A comment"

    def test_rdfs_comment_getattr(self):
        node = self._make_node()
        node.set_annotation(RDFS_COMMENT, "A comment")
        assert node.rdfs_comment == "A comment"

    def test_rdfs_label_clear_via_none(self):
        node = self._make_node()
        node.rdfs_label = "Label"
        node.rdfs_label = None
        assert node.rdfs_label is None

    def test_get_rdfs_label_with_lang(self):
        node = self._make_node()
        node.add_annotation(RDFS_LABEL, "Cat", lang="en")
        node.add_annotation(RDFS_LABEL, "Chat", lang="fr")
        assert node.get_rdfs_label(lang="en") == "Cat"
        assert node.get_rdfs_label(lang="fr") == "Chat"

    def test_set_rdfs_label_with_lang(self):
        node = self._make_node()
        node.set_rdfs_label("Cat", lang="en")
        node.set_rdfs_label("Chat", lang="fr")
        assert node.get_rdfs_label(lang="en") == "Cat"
        assert node.get_rdfs_label(lang="fr") == "Chat"

    def test_set_rdfs_label_replaces_lang(self):
        node = self._make_node()
        node.set_rdfs_label("Cat", lang="en")
        node.set_rdfs_label("Kitty", lang="en")
        assert node.get_rdfs_label(lang="en") == "Kitty"
        assert len(node.get_annotations(RDFS_LABEL)) == 1


# --- set_property with lang ---

class TestSetPropertyLang:

    def test_set_property_with_lang(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        node = VITAL_Node()
        node.URI = "urn:sp-test"
        node.set_property("name", "John", lang="en")
        prop = node._properties.get("http://vital.ai/ontology/vital-core#hasName")
        assert prop is not None
        assert prop.lang == "en"


# --- RDF Round-trip ---

class TestAnnotationRdfRoundTrip:

    def test_rdf_roundtrip_single_label(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:ann-rdf-1"
        node.name = "TestNode"
        node.set_annotation(RDFS_LABEL, "My Label")

        rdf_str = node.to_rdf()
        restored = GraphObject.from_rdf(rdf_str)

        assert restored.get_annotation(RDFS_LABEL) == "My Label"

    def test_rdf_roundtrip_label_with_lang(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:ann-rdf-2"
        node.name = "TestNode"
        node.add_annotation(RDFS_LABEL, "Cat", lang="en")
        node.add_annotation(RDFS_LABEL, "Chat", lang="fr")

        rdf_str = node.to_rdf()
        restored = GraphObject.from_rdf(rdf_str)

        assert restored.get_rdfs_label(lang="en") == "Cat"
        assert restored.get_rdfs_label(lang="fr") == "Chat"
        assert len(restored.get_annotations(RDFS_LABEL)) == 2

    def test_rdf_roundtrip_comment(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:ann-rdf-3"
        node.name = "TestNode"
        node.set_annotation(RDFS_COMMENT, "A description", lang="en")

        rdf_str = node.to_rdf()
        restored = GraphObject.from_rdf(rdf_str)

        assert restored.get_rdfs_comment(lang="en") == "A description"

    def test_rdf_roundtrip_no_annotations(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:ann-rdf-4"
        node.name = "TestNode"

        rdf_str = node.to_rdf()
        restored = GraphObject.from_rdf(rdf_str)

        assert restored.get_annotations(RDFS_LABEL) == []
        assert str(restored.name) == "TestNode"

    def test_rdf_list_roundtrip_annotations(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        n1 = VITAL_Node()
        n1.URI = "urn:ann-rdf-list-1"
        n1.name = "Node1"
        n1.set_annotation(RDFS_LABEL, "First", lang="en")

        n2 = VITAL_Node()
        n2.URI = "urn:ann-rdf-list-2"
        n2.name = "Node2"
        n2.set_annotation(RDFS_LABEL, "Second", lang="de")

        rdf_str = n1.to_rdf() + n2.to_rdf()
        restored = GraphObject.from_rdf_list(rdf_str)
        assert len(restored) == 2

        by_uri = {str(r._properties.get("http://vital.ai/ontology/vital-core#URIProp")): r for r in restored}
        assert by_uri["urn:ann-rdf-list-1"].get_rdfs_label(lang="en") == "First"
        assert by_uri["urn:ann-rdf-list-2"].get_rdfs_label(lang="de") == "Second"


# --- Triples Round-trip ---

class TestAnnotationTriplesRoundTrip:

    def test_triples_roundtrip_label(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:ann-tri-1"
        node.name = "TestNode"
        node.add_annotation(RDFS_LABEL, "Hello", lang="en")
        node.add_annotation(RDFS_LABEL, "Hola", lang="es")

        triples = node.to_triples()
        restored = GraphObject.from_triples(iter(triples))

        assert restored.get_rdfs_label(lang="en") == "Hello"
        assert restored.get_rdfs_label(lang="es") == "Hola"

    def test_triples_list_roundtrip_annotations(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        n1 = VITAL_Node()
        n1.URI = "urn:ann-tl-1"
        n1.name = "N1"
        n1.set_annotation(RDFS_LABEL, "Label1")

        n2 = VITAL_Node()
        n2.URI = "urn:ann-tl-2"
        n2.name = "N2"
        n2.set_annotation(RDFS_COMMENT, "Comment2", lang="fr")

        combined = n1.to_triples() + n2.to_triples()
        restored = GraphObject.from_triples_list(iter(combined))
        assert len(restored) == 2

        by_uri = {str(r._properties.get("http://vital.ai/ontology/vital-core#URIProp")): r for r in restored}
        assert by_uri["urn:ann-tl-1"].get_annotation(RDFS_LABEL) == "Label1"
        assert by_uri["urn:ann-tl-2"].get_rdfs_comment(lang="fr") == "Comment2"

    def test_triples_annotations_not_in_properties(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:ann-tri-sep"
        node.name = "TestNode"
        node.set_annotation(RDFS_LABEL, "MyLabel")

        triples = node.to_triples()
        restored = GraphObject.from_triples(iter(triples))

        assert RDFS_LABEL not in restored._properties
        assert restored.get_annotation(RDFS_LABEL) == "MyLabel"


# --- JSON Round-trip ---

class TestAnnotationJsonRoundTrip:

    def test_json_roundtrip_single_label(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject
        import json

        node = VITAL_Node()
        node.URI = "urn:ann-json-1"
        node.name = "TestNode"
        node.set_annotation(RDFS_LABEL, "My Label")

        json_str = node.to_json()
        data = json.loads(json_str)
        assert 'annotations' in data
        assert RDFS_LABEL in data['annotations']

        restored = GraphObject.from_json(json_str)
        assert restored.get_annotation(RDFS_LABEL) == "My Label"

    def test_json_roundtrip_label_with_lang(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:ann-json-2"
        node.name = "TestNode"
        node.add_annotation(RDFS_LABEL, "Dog", lang="en")
        node.add_annotation(RDFS_LABEL, "Hund", lang="de")

        json_str = node.to_json()
        restored = GraphObject.from_json(json_str)

        assert restored.get_rdfs_label(lang="en") == "Dog"
        assert restored.get_rdfs_label(lang="de") == "Hund"
        assert len(restored.get_annotations(RDFS_LABEL)) == 2

    def test_json_map_roundtrip(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject
        import json

        node = VITAL_Node()
        node.URI = "urn:ann-jsonmap-1"
        node.name = "TestNode"
        node.set_annotation(RDFS_COMMENT, "A note", lang="en")

        json_str = node.to_json()
        data = json.loads(json_str)
        restored = GraphObject.from_json_map(data)

        assert restored.get_rdfs_comment(lang="en") == "A note"

    def test_json_no_annotations(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject
        import json

        node = VITAL_Node()
        node.URI = "urn:ann-json-none"
        node.name = "TestNode"

        json_str = node.to_json()
        data = json.loads(json_str)
        assert 'annotations' not in data

        restored = GraphObject.from_json(json_str)
        assert restored.get_annotations(RDFS_LABEL) == []

    def test_json_list_roundtrip(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject
        import json

        n1 = VITAL_Node()
        n1.URI = "urn:ann-jl-1"
        n1.name = "N1"
        n1.set_annotation(RDFS_LABEL, "First")

        n2 = VITAL_Node()
        n2.URI = "urn:ann-jl-2"
        n2.name = "N2"
        n2.set_annotation(RDFS_COMMENT, "Note2", lang="fr")

        json_str = json.dumps([json.loads(n1.to_json()), json.loads(n2.to_json())])
        restored = GraphObject.from_json_list(json_str)
        assert len(restored) == 2

        by_uri = {str(r.URI): r for r in restored}
        assert by_uri["urn:ann-jl-1"].get_annotation(RDFS_LABEL) == "First"
        assert by_uri["urn:ann-jl-2"].get_rdfs_comment(lang="fr") == "Note2"


# --- Dict Round-trip ---

class TestAnnotationDictRoundTrip:

    def test_dict_roundtrip(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:ann-dict-1"
        node.name = "TestNode"
        node.add_annotation(RDFS_LABEL, "Hello", lang="en")
        node.add_annotation(RDFS_LABEL, "Bonjour", lang="fr")

        d = node.to_dict()
        assert 'annotations' in d
        assert RDFS_LABEL in d['annotations']

        restored = GraphObject.from_dict(d)
        assert restored.get_rdfs_label(lang="en") == "Hello"
        assert restored.get_rdfs_label(lang="fr") == "Bonjour"

    def test_dict_no_annotations(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node

        node = VITAL_Node()
        node.URI = "urn:ann-dict-none"
        node.name = "TestNode"

        d = node.to_dict()
        assert 'annotations' not in d

    def test_dict_list_roundtrip(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        n1 = VITAL_Node()
        n1.URI = "urn:ann-dl-1"
        n1.name = "N1"
        n1.set_annotation(RDFS_LABEL, "L1")

        n2 = VITAL_Node()
        n2.URI = "urn:ann-dl-2"
        n2.name = "N2"
        n2.set_annotation(RDFS_COMMENT, "C2", lang="de")

        dict_list = [n1.to_dict(), n2.to_dict()]
        restored = GraphObject.from_dict_list(dict_list)
        assert len(restored) == 2

        by_uri = {str(r.URI): r for r in restored}
        assert by_uri["urn:ann-dl-1"].get_annotation(RDFS_LABEL) == "L1"
        assert by_uri["urn:ann-dl-2"].get_rdfs_comment(lang="de") == "C2"


# --- Property Map Round-trip ---

class TestAnnotationPropertyMapRoundTrip:

    def test_property_map_roundtrip(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:ann-pm-1"
        node.name = "TestNode"
        node.set_annotation(RDFS_LABEL, "MapLabel", lang="en")

        pm = node.to_property_map()
        assert 'annotations' in pm

        restored = GraphObject.from_property_map(
            pm['subject_uri'], pm['type_uri'], pm['properties'],
            annotations=pm.get('annotations'))
        assert restored.get_rdfs_label(lang="en") == "MapLabel"

    def test_property_map_no_annotations(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:ann-pm-none"
        node.name = "TestNode"

        pm = node.to_property_map()
        assert 'annotations' not in pm

        restored = GraphObject.from_property_map(
            pm['subject_uri'], pm['type_uri'], pm['properties'])
        assert restored.get_annotations(RDFS_LABEL) == []

    def test_property_maps_roundtrip(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        n1 = VITAL_Node()
        n1.URI = "urn:ann-pms-1"
        n1.name = "N1"
        n1.set_annotation(RDFS_LABEL, "PL1")

        n2 = VITAL_Node()
        n2.URI = "urn:ann-pms-2"
        n2.name = "N2"
        n2.set_annotation(RDFS_COMMENT, "PC2", lang="es")

        pms = GraphObject.to_property_maps([n1, n2])
        assert len(pms) == 2
        assert 'annotations' in pms[0]
        assert 'annotations' in pms[1]

        restored = GraphObject.from_property_maps(pms)
        assert len(restored) == 2

        by_uri = {str(r.URI): r for r in restored}
        assert by_uri["urn:ann-pms-1"].get_annotation(RDFS_LABEL) == "PL1"
        assert by_uri["urn:ann-pms-2"].get_rdfs_comment(lang="es") == "PC2"


# --- Ontology Manager Helpers ---

class TestOntologyManagerHelpers:
    """Test ontology manager annotation helpers with a small injected RDF graph."""

    @pytest.fixture(autouse=True)
    def setup_manager(self):
        from rdflib import Graph, URIRef, Literal, Namespace, RDF, OWL, RDFS
        from vital_ai_vitalsigns.ontology.vitalsigns_ontology_manager import VitalSignsOntologyManager

        g = Graph()
        EX = Namespace("http://example.org/ont#")

        g.add((EX.MyClass, RDF.type, OWL.Class))
        g.add((EX.MyClass, RDFS.label, Literal("My Class")))
        g.add((EX.MyClass, RDFS.label, Literal("Ma Classe", lang="fr")))
        g.add((EX.MyClass, RDFS.comment, Literal("A test class")))
        g.add((EX.MyClass, RDFS.comment, Literal("Une classe de test", lang="fr")))

        g.add((EX.hasAge, RDF.type, OWL.DatatypeProperty))
        g.add((EX.hasAge, RDFS.label, Literal("age")))
        g.add((EX.hasAge, RDFS.label, Literal("edad", lang="es")))
        g.add((EX.hasAge, RDFS.comment, Literal("Age of entity")))

        self.manager = VitalSignsOntologyManager()
        self.manager._domain_graph = g
        self.manager._domain_graph_loaded = True
        self.CLASS_URI = "http://example.org/ont#MyClass"
        self.PROP_URI = "http://example.org/ont#hasAge"

    def test_get_class_label(self):
        label = self.manager.get_class_label(self.CLASS_URI)
        assert label is not None
        assert label in ("My Class", "Ma Classe")

    def test_get_class_label_with_lang(self):
        assert self.manager.get_class_label(self.CLASS_URI, lang="fr") == "Ma Classe"

    def test_get_class_label_no_match(self):
        assert self.manager.get_class_label(self.CLASS_URI, lang="zh") is None

    def test_get_class_label_unknown_uri(self):
        assert self.manager.get_class_label("http://example.org/ont#Unknown") is None

    def test_get_class_comment(self):
        comment = self.manager.get_class_comment(self.CLASS_URI)
        assert comment is not None
        assert comment in ("A test class", "Une classe de test")

    def test_get_class_comment_with_lang(self):
        assert self.manager.get_class_comment(self.CLASS_URI, lang="fr") == "Une classe de test"

    def test_get_class_annotations(self):
        anns = self.manager.get_class_annotations(self.CLASS_URI)
        assert RDFS_LABEL in anns
        assert RDFS_COMMENT in anns
        labels = anns[RDFS_LABEL]
        assert len(labels) == 2
        label_values = {v for v, l in labels}
        assert "My Class" in label_values
        assert "Ma Classe" in label_values
        fr_labels = [(v, l) for v, l in labels if l == "fr"]
        assert len(fr_labels) == 1
        assert fr_labels[0][0] == "Ma Classe"

    def test_get_class_annotations_empty(self):
        anns = self.manager.get_class_annotations("http://example.org/ont#Unknown")
        assert anns == {}

    def test_get_property_label(self):
        label = self.manager.get_property_label(self.PROP_URI)
        assert label is not None
        assert label in ("age", "edad")

    def test_get_property_label_with_lang(self):
        assert self.manager.get_property_label(self.PROP_URI, lang="es") == "edad"

    def test_get_property_label_no_match(self):
        assert self.manager.get_property_label(self.PROP_URI, lang="zh") is None

    def test_get_property_comment(self):
        assert self.manager.get_property_comment(self.PROP_URI) == "Age of entity"

    def test_get_property_comment_no_match(self):
        assert self.manager.get_property_comment(self.PROP_URI, lang="de") is None


# --- Gap 1+2: Flat annotation keys in property maps ---

class TestPropertyMapFlatAnnotations:
    """Test that from_property_map accepts annotation URIs as flat keys in the
    properties dict (the VitalGraph SPARQL read path), not just nested under
    'annotations'."""

    def test_flat_string_value(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:flat-1"
        node.name = "TestNode"
        pm = node.to_property_map()

        pm['properties'][RDFS_LABEL] = "Flat Label"

        restored = GraphObject.from_property_map(
            pm['subject_uri'], pm['type_uri'], pm['properties'])
        assert restored.get_annotation(RDFS_LABEL) == "Flat Label"

    def test_flat_dict_value_with_lang(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:flat-2"
        node.name = "TestNode"
        pm = node.to_property_map()

        pm['properties'][RDFS_LABEL] = {"value": "Bonjour", "lang": "fr"}

        restored = GraphObject.from_property_map(
            pm['subject_uri'], pm['type_uri'], pm['properties'])
        assert restored.get_rdfs_label(lang="fr") == "Bonjour"

    def test_flat_rdflib_literal_with_lang(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject
        from rdflib import Literal

        node = VITAL_Node()
        node.URI = "urn:flat-3"
        node.name = "TestNode"
        pm = node.to_property_map()

        pm['properties'][RDFS_LABEL] = Literal("Hallo", lang="de")

        restored = GraphObject.from_property_map(
            pm['subject_uri'], pm['type_uri'], pm['properties'])
        assert restored.get_rdfs_label(lang="de") == "Hallo"

    def test_flat_list_of_values(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:flat-4"
        node.name = "TestNode"
        pm = node.to_property_map()

        pm['properties'][RDFS_LABEL] = [
            "Label A",
            {"value": "Label B", "lang": "en"},
        ]

        restored = GraphObject.from_property_map(
            pm['subject_uri'], pm['type_uri'], pm['properties'])
        anns = restored.get_annotations(RDFS_LABEL)
        assert len(anns) == 2
        values = {str(av) for av in anns}
        assert "Label A" in values
        assert "Label B" in values

    def test_flat_and_nested_annotations_combined(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:flat-5"
        node.name = "TestNode"
        pm = node.to_property_map()

        pm['properties'][RDFS_LABEL] = "Flat One"

        nested_anns = {
            RDFS_COMMENT: [{"value": "A comment", "lang": "en"}]
        }

        restored = GraphObject.from_property_map(
            pm['subject_uri'], pm['type_uri'], pm['properties'],
            annotations=nested_anns)
        assert restored.get_annotation(RDFS_LABEL) == "Flat One"
        assert restored.get_rdfs_comment(lang="en") == "A comment"

    def test_flat_annotation_in_from_property_maps(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        n1 = VITAL_Node()
        n1.URI = "urn:flat-batch-1"
        n1.name = "N1"
        pm1 = n1.to_property_map()
        pm1['properties'][RDFS_LABEL] = "Batch Label"

        restored = GraphObject.from_property_maps([pm1])
        assert len(restored) == 1
        assert restored[0].get_annotation(RDFS_LABEL) == "Batch Label"

    def test_flat_annotation_not_in_domain_properties(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:flat-6"
        node.name = "TestNode"
        pm = node.to_property_map()

        pm['properties'][RDFS_LABEL] = "Should be annotation"

        restored = GraphObject.from_property_map(
            pm['subject_uri'], pm['type_uri'], pm['properties'])
        assert RDFS_LABEL not in restored._properties
        assert restored.get_annotation(RDFS_LABEL) == "Should be annotation"


# --- Gap 8: Bulk set convenience methods ---

class TestBulkSetAnnotations:

    def test_set_rdfs_labels(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node

        node = VITAL_Node()
        node.URI = "urn:bulk-1"
        node.set_rdfs_labels({"en": "Cat", "fr": "Chat", "de": "Katze"})

        assert node.get_rdfs_label(lang="en") == "Cat"
        assert node.get_rdfs_label(lang="fr") == "Chat"
        assert node.get_rdfs_label(lang="de") == "Katze"
        assert len(node.get_annotations(RDFS_LABEL)) == 3

    def test_set_rdfs_labels_replaces_existing(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node

        node = VITAL_Node()
        node.URI = "urn:bulk-2"
        node.set_rdfs_label("Old Label", lang="en")
        node.set_rdfs_label("Ancien", lang="fr")
        assert len(node.get_annotations(RDFS_LABEL)) == 2

        node.set_rdfs_labels({"en": "New Label", "es": "Nueva"})
        assert len(node.get_annotations(RDFS_LABEL)) == 2
        assert node.get_rdfs_label(lang="en") == "New Label"
        assert node.get_rdfs_label(lang="es") == "Nueva"
        assert node.get_rdfs_label(lang="fr") is None

    def test_set_rdfs_labels_with_none_key(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node

        node = VITAL_Node()
        node.URI = "urn:bulk-3"
        node.set_rdfs_labels({None: "No lang", "en": "English"})

        assert node.get_rdfs_label() in ("No lang", "English")
        assert node.get_rdfs_label(lang="en") == "English"
        assert len(node.get_annotations(RDFS_LABEL)) == 2

    def test_set_rdfs_comments(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node

        node = VITAL_Node()
        node.URI = "urn:bulk-4"
        node.set_rdfs_comments({"en": "A node", "fr": "Un noeud"})

        assert node.get_rdfs_comment(lang="en") == "A node"
        assert node.get_rdfs_comment(lang="fr") == "Un noeud"

    def test_set_annotations_by_lang_general(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node

        OWL_VERSION = 'http://www.w3.org/2002/07/owl#versionInfo'
        node = VITAL_Node()
        node.URI = "urn:bulk-5"
        node.set_annotations_by_lang(OWL_VERSION, {None: "1.0", "en": "Version 1.0"})

        assert node.get_annotation(OWL_VERSION) in ("1.0", "Version 1.0")
        assert node.get_annotation(OWL_VERSION, lang="en") == "Version 1.0"

    def test_set_rdfs_labels_roundtrip_json(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:bulk-rt"
        node.name = "TestNode"
        node.set_rdfs_labels({"en": "Dog", "fr": "Chien", "de": "Hund"})

        json_str = node.to_json()
        restored = GraphObject.from_json(json_str)

        assert restored.get_rdfs_label(lang="en") == "Dog"
        assert restored.get_rdfs_label(lang="fr") == "Chien"
        assert restored.get_rdfs_label(lang="de") == "Hund"
        assert len(restored.get_annotations(RDFS_LABEL)) == 3
