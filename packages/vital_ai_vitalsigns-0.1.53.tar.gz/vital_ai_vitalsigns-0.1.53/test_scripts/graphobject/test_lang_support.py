"""Tests for IProperty lang support (Phase 0)."""
import pytest
from vital_ai_vitalsigns.model.properties.IProperty import IProperty
from vital_ai_vitalsigns.model.properties.StringProperty import StringProperty
from vital_ai_vitalsigns.model.properties.IntegerProperty import IntegerProperty
from vital_ai_vitalsigns.model.properties.BooleanProperty import BooleanProperty
from vital_ai_vitalsigns.model.properties.DoubleProperty import DoubleProperty
from vital_ai_vitalsigns.model.properties.FloatProperty import FloatProperty
from vital_ai_vitalsigns.model.properties.LongProperty import LongProperty
from vital_ai_vitalsigns.model.properties.DateTimeProperty import DateTimeProperty
from vital_ai_vitalsigns.model.properties.URIProperty import URIProperty
from vital_ai_vitalsigns.model.properties.GeoLocationProperty import GeoLocationProperty
from vital_ai_vitalsigns.model.properties.TruthProperty import TruthProperty
from vital_ai_vitalsigns.model.properties.OtherProperty import OtherProperty
import rdflib


# --- IProperty base ---

class TestIPropertyLang:

    def test_default_lang_is_none(self):
        p = IProperty("hello")
        assert p.lang is None

    def test_lang_can_be_set(self):
        p = IProperty("hello", lang="en")
        assert p.lang == "en"
        assert p.value == "hello"

    def test_lang_mutable(self):
        p = IProperty("hello")
        p.lang = "de"
        assert p.lang == "de"


# --- Subclass constructors ---

class TestSubclassLangPassthrough:

    def test_string_property(self):
        p = StringProperty("hello", lang="en")
        assert p.lang == "en"
        assert p.value == "hello"

    def test_string_property_default(self):
        p = StringProperty("hello")
        assert p.lang is None

    def test_integer_property(self):
        p = IntegerProperty(42, lang="en")
        assert p.lang == "en"

    def test_boolean_property(self):
        p = BooleanProperty(True, lang="en")
        assert p.lang == "en"

    def test_double_property(self):
        p = DoubleProperty(3.14, lang="en")
        assert p.lang == "en"

    def test_float_property(self):
        p = FloatProperty(1.5, lang="en")
        assert p.lang == "en"

    def test_long_property(self):
        p = LongProperty(100, lang="en")
        assert p.lang == "en"

    def test_datetime_property(self):
        p = DateTimeProperty("2024-01-01T00:00:00", lang="en")
        assert p.lang == "en"

    def test_uri_property(self):
        p = URIProperty("http://example.org", lang="en")
        assert p.lang == "en"

    def test_geolocation_property(self):
        p = GeoLocationProperty("0.0;0.0", lang="en")
        assert p.lang == "en"

    def test_truth_property(self):
        p = TruthProperty("yes", lang="en")
        assert p.lang == "en"

    def test_other_property(self):
        p = OtherProperty("test", lang="en")
        assert p.lang == "en"


# --- to_rdf with lang ---

class TestToRdfLang:

    def test_to_rdf_without_lang(self):
        p = StringProperty("hello")
        rdf = p.to_rdf()
        assert "lang" not in rdf
        assert rdf["datatype"] == rdflib.XSD.string

    def test_to_rdf_with_lang(self):
        p = StringProperty("hello", lang="en")
        rdf = p.to_rdf()
        assert rdf["lang"] == "en"
        assert rdf["value"] == "hello"
        assert "datatype" not in rdf

    def test_to_rdf_integer_with_lang(self):
        p = IntegerProperty(42, lang="en")
        rdf = p.to_rdf()
        assert rdf["lang"] == "en"
        assert rdf["value"] == "42"


# --- VitalSignsImpl lang preservation ---

class TestVitalSignsImplLangPreservation:

    def test_create_property_with_trait_from_classes_preserves_lang(self):
        from vital_ai_vitalsigns.vitalsigns import VitalSigns
        from vital_ai_vitalsigns.impl.vitalsigns_impl import VitalSignsImpl

        vs = VitalSigns()

        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        node = VITAL_Node()
        node.URI = "urn:node1"
        node.name = StringProperty("John", lang="en")

        prop = node._properties.get("http://vital.ai/ontology/vital-core#hasName")
        assert prop is not None
        assert prop.lang == "en"
        assert str(prop) == "John"

    def test_assignment_preserves_lang_between_objects(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node

        n1 = VITAL_Node()
        n1.URI = "urn:node1"
        n1.name = StringProperty("John", lang="fr")

        n2 = VITAL_Node()
        n2.URI = "urn:node2"
        n2.name = n1.name

        prop = n2._properties.get("http://vital.ai/ontology/vital-core#hasName")
        assert prop is not None
        assert prop.lang == "fr"
        assert str(prop) == "John"

    def test_plain_string_assignment_no_lang(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node

        node = VITAL_Node()
        node.URI = "urn:node1"
        node.name = "Alice"

        prop = node._properties.get("http://vital.ai/ontology/vital-core#hasName")
        assert prop is not None
        assert prop.lang is None
        assert str(prop) == "Alice"


# --- RDF round-trip ---

class TestRdfRoundTripLang:

    def test_rdf_roundtrip_with_lang(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:node-lang-test"
        node.name = StringProperty("Chat", lang="fr")

        rdf_str = node.to_rdf()

        restored = GraphObject.from_rdf(rdf_str)

        assert str(restored.name) == "Chat"
        prop = restored._properties.get("http://vital.ai/ontology/vital-core#hasName")
        assert prop.lang == "fr"

    def test_rdf_roundtrip_without_lang(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:node-no-lang"
        node.name = "Cat"

        rdf_str = node.to_rdf()
        restored = GraphObject.from_rdf(rdf_str)

        assert str(restored.name) == "Cat"
        prop = restored._properties.get("http://vital.ai/ontology/vital-core#hasName")
        assert prop.lang is None

    def test_rdf_list_roundtrip_with_lang(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        n1 = VITAL_Node()
        n1.URI = "urn:lang-list-1"
        n1.name = StringProperty("Hund", lang="de")

        n2 = VITAL_Node()
        n2.URI = "urn:lang-list-2"
        n2.name = StringProperty("Dog", lang="en")

        rdf1 = n1.to_rdf()
        rdf2 = n2.to_rdf()
        combined = rdf1 + rdf2

        restored = GraphObject.from_rdf_list(combined)
        assert len(restored) == 2

        by_uri = {str(r._properties.get("http://vital.ai/ontology/vital-core#URIProp")): r for r in restored}

        r1 = by_uri["urn:lang-list-1"]
        r2 = by_uri["urn:lang-list-2"]

        p1 = r1._properties.get("http://vital.ai/ontology/vital-core#hasName")
        p2 = r2._properties.get("http://vital.ai/ontology/vital-core#hasName")
        assert p1.lang == "de"
        assert p2.lang == "en"


# --- Triples round-trip ---

class TestTriplesRoundTripLang:

    def test_triples_roundtrip_with_lang(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        node = VITAL_Node()
        node.URI = "urn:triples-lang"
        node.name = StringProperty("Gato", lang="es")

        triples = node.to_triples()

        restored = GraphObject.from_triples(iter(triples))

        prop = restored._properties.get("http://vital.ai/ontology/vital-core#hasName")
        assert str(prop) == "Gato"
        assert prop.lang == "es"

    def test_triples_list_roundtrip_with_lang(self):
        from vital_ai_vitalsigns.model.VITAL_Node import VITAL_Node
        from vital_ai_vitalsigns.model.GraphObject import GraphObject

        n1 = VITAL_Node()
        n1.URI = "urn:tl-1"
        n1.name = StringProperty("Katze", lang="de")

        n2 = VITAL_Node()
        n2.URI = "urn:tl-2"
        n2.name = StringProperty("Cat", lang="en")

        t1 = n1.to_triples()
        t2 = n2.to_triples()
        combined = t1 + t2

        restored = GraphObject.from_triples_list(iter(combined))
        assert len(restored) == 2

        by_uri = {str(r._properties.get("http://vital.ai/ontology/vital-core#URIProp")): r for r in restored}
        p1 = by_uri["urn:tl-1"]._properties.get("http://vital.ai/ontology/vital-core#hasName")
        p2 = by_uri["urn:tl-2"]._properties.get("http://vital.ai/ontology/vital-core#hasName")
        assert p1.lang == "de"
        assert p2.lang == "en"
