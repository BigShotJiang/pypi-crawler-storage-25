from __future__ import annotations

from typing import TypeVar, List, Optional
from vital_ai_vitalsigns.model.vital_constants import VitalConstants
from vital_ai_vitalsigns.model.annotation import AnnotationValue

G = TypeVar('G', bound=Optional['GraphObject'])


class GraphObjectDictUtils:
    """Utility class containing dictionary-related functionality for GraphObject."""

    @staticmethod
    def to_dict_impl(graph_object) -> dict:
        """Implementation of to_dict functionality."""
        serializable_dict = {}

        for uri, prop in graph_object._properties.items():
            prop_value = prop.get_value()
            if uri == VitalConstants.uri_prop_uri:
                serializable_dict['URI'] = prop_value
            else:
                serializable_dict[uri] = prop_value

        from vital_ai_vitalsigns.model.VITAL_GraphContainerObject import VITAL_GraphContainerObject
        if isinstance(graph_object, VITAL_GraphContainerObject):
            for name, prop in graph_object._extern_properties.items():
                prop_value = prop.get_value()
                uri = "urn:extern:" + name
                serializable_dict[uri] = prop_value

        class_uri = graph_object.get_class_uri()

        serializable_dict['type'] = class_uri

        serializable_dict[VitalConstants.vitaltype_uri] = class_uri

        serializable_dict['types'] = [class_uri]

        if graph_object._annotations:
            ann_dict = {}
            for ann_uri, ann_values in graph_object._annotations.items():
                ann_dict[ann_uri] = [av.to_json() for av in ann_values]
            serializable_dict['annotations'] = ann_dict

        return serializable_dict

    @staticmethod
    def from_dict_impl(cls, dict_map: dict, *, modified=False) -> G:
        """Implementation of from_dict functionality."""
        from vital_ai_vitalsigns.vitalsigns import VitalSigns

        data = dict_map

        type_uri = data['type']

        vitaltype_class_uri = data.get(VitalConstants.vitaltype_uri)

        vs = VitalSigns()

        registry = vs.get_registry()

        # graph_object_cls = registry.vitalsigns_classes[type_uri]

        graph_object_cls = registry.get_vitalsigns_class(type_uri)

        # TODO switch to this
        # graph_object_cls = registry.get_vitalsigns_class(vitaltype_class_uri)

        graph_object = graph_object_cls(modified=modified)

        uri_dict, short_name_dict = graph_object_cls._get_property_lookup_dicts()

        from vital_ai_vitalsigns.impl.vitalsigns_impl import VitalSignsImpl

        for key, value in data.items():
            if key == 'type':
                continue
            if key == 'types':
                continue
            if key == 'vitaltype':  # is this used?
                continue
            if key == VitalConstants.vitaltype_uri:
                continue
            if key == VitalConstants.uri_prop_uri:
                graph_object.URI = value
                continue
            if key == 'annotations':
                if isinstance(value, dict):
                    for ann_uri, ann_list in value.items():
                        for av_data in ann_list:
                            av = AnnotationValue.from_json(av_data)
                            graph_object.add_annotation(ann_uri, av)
                continue

            entry = uri_dict.get(key)
            if entry is None:
                entry = short_name_dict.get(key)
            if entry:
                uri = entry['uri']
                if value is None:
                    graph_object._properties.pop(uri, None)
                else:
                    graph_object._properties[uri] = VitalSignsImpl.create_property_with_trait_from_classes(
                        entry['prop_class'], entry['trait_class'], value)
            else:
                setattr(graph_object, key, value)

        return graph_object

    @staticmethod
    def to_dict_list_impl(graph_object_list) -> List[dict]:
        """Implementation of to_dict_list functionality."""
        dict_list = []
        
        for graph_object in graph_object_list:
            dict_obj = GraphObjectDictUtils.to_dict_impl(graph_object)
            dict_list.append(dict_obj)
        
        return dict_list

    @staticmethod
    def from_dict_list_impl(cls, dict_list: List[dict], *, modified=False) -> List[G]:
        """Implementation of from_dict_list functionality."""
        graph_object_list = []

        for data in dict_list:
            graph_object = cls.from_dict(data, modified=modified)
            graph_object_list.append(graph_object)

        return graph_object_list