#!/usr/bin/env python3

import argparse
from ast import arg
import sys
from pathlib import Path
import logging
import datetime
from oceanproc.bids_wrapper import dicom_to_bids, remove_unusable_runs, extend_session
from oceanproc.group_series import map_fmap_to_func, map_fmap_to_func_with_pairing_file
from oceanproc.preprocessing_wrapper import process_data, adult_defaults, infant_defaults, mount_opts, insert_dummy_frames
from oceanproc.segmentation_wrapper import segmentation_args, segment_anatomical
from oceanproc.events_long import create_events_and_confounds
from oceanproc.utils import *
from oceanproc.oceanparse import OceanParser
from bids import BIDSLayout, BIDSLayoutIndexer
import shutil
import grp
import os
from textwrap import dedent

logging.basicConfig(level=logging.INFO,
                    handlers=[logging.StreamHandler(stream=sys.stdout)],
                    format=default_log_format)
logger = logging.getLogger()


@debug_logging
def make_work_directory(dir_path:Path, subject:str, session:str) -> Path:
    dir_to_make = dir_path / f"sub-{subject}_ses-{session}"
    if dir_to_make.exists():
        want_to_delete = prompt_user_continue(dedent("""
            A work directory already exists for this subject and session.
            Would you like to delete its contents and start fresh?
            """))
        if want_to_delete:
            logger.debug("removing the old working directory and its contents")
            shutil.rmtree(dir_to_make)
        else:
            return dir_to_make
    dir_to_make.mkdir()
    logger.info(f"creating a new working directory at the path: {dir_to_make}")
    return dir_to_make


def main():

    def ExistingPath(path):
        p = Path(path)
        if not p.exists():
            raise argparse.ArgumentTypeError(
                f"path string <{path}> does not represent an existing path"
            )
        return p.resolve()

    def ExistingDir(path):
        p = ExistingPath(path)
        if not p.is_dir():
            raise argparse.ArgumentTypeError(
                f"path string <{path}> does not represent an existing directory"
            )
        return p

    def ExistingFile(path):
        p = ExistingPath(path)
        if not p.is_file():
            raise argparse.ArgumentTypeError(
                f"path string <{path}> does not represent an existing file"
            )
        return p

    def ValidPermissions(permissions):
        try:
            validate_permissions_string(permissions)
        except ValueError:
            raise argparse.ArgumentTypeError(
                f"permissions string <{permissions}> does not represent a valid permissions string"
            )
        return permissions

    def ValidGroup(group):
        try:
            group_id = grp.getgrnam(group).gr_gid
            valid_groups = os.getgroups()
            if group_id not in valid_groups:
                raise argparse.ArgumentTypeError(
                    f"current user does not belong to group <{group}>"
                )
        except KeyError:
            raise argparse.ArgumentTypeError(
                f"group name <{group}> is not a valid system user group"
            )
        return group

    default_user_group = grp.getgrgid(os.getgid()).gr_name
    default_file_permissions = "771"
    
    parser = OceanParser(
        prog="oceanproc",
        description="Ocean Labs adult MRI preprocessing",
        exit_on_error=False,
        fromfile_prefix_chars="@",
        epilog="An arguments file can be accepted with @FILEPATH.\nAny additional arguments not listed in the help message will be passed to the preprocessing subprocess.",
        allow_abbrev=False
    )
    parser.add_argument("--version", action="version", version='%(prog)s v1.3.0')
    session_args = parser.add_argument_group("Session Specific")
    config_args = parser.add_argument_group("Configuration Arguments", "These arguments are saved to a file if the '--export_args' option is used")
    parser.register("type", "Full-Path", lambda p: Path(p).resolve())

    session_args.add_argument("--subject", "-su", required=True,
                              help="The identifier of the subject to preprocess")
    session_args.add_argument("--session", "-se", required=True,
                              help="The identifier of the session to preprocess")
    session_args.add_argument("--source_data", "-sd", type=ExistingDir,
                              help="The path to the directory containing the raw DICOM files for this subject and session")
    session_args.add_argument("--skip_dcm2bids", action="store_true",
                              help="Flag to indicate that dcm2bids does not need to be run for this subject and session")
    session_args.add_argument("--usability_file", "-u", type=ExistingFile,
                              help="The path to the usability file for this subject and session; this file can be either be an xml or json file. All runs will be used if no file is provided.")
    session_args.add_argument("--longitudinal", "-lg", type=ExistingPath, nargs="+", action="append",
                              help="Addtional sourcedata and usability pair to include with this BIDs subject and session")
    session_args.add_argument("--skip_fmap_pairing", action="store_true",
                              help="Flag to indicate that the pairing of fieldmaps to BOLD runs does not need to be performed for this subject and session")
    session_args.add_argument("--skip_segmentation", action="store_true",
                              help="Flag to indicate that segmentation does not need to be run for this subject and session")
    session_args.add_argument("--skip_preproc", action="store_true",
                              help="Flag to indicate that preprocessing does not need to be run for this subject and session")
    session_args.add_argument("--skip_event_files", action="store_true",
                              help="Flag to indicate that the making of a long formatted events file is not needed for the subject and session")
    session_args.add_argument("--export_args", "-ea", type=Path,
                              help="Path to a file to save the current configuration arguments")
    session_args.add_argument("--keep_work_dir", action="store_true",
                              help="Flag to stop the deletion of the fMRIPrep working directory")
    session_args.add_argument("--debug_mode", action="store_true",
                              help="Flag to run the program in debug mode for more verbose logging")
    session_args.add_argument("--fmap_pairing_file", type=ExistingFile,
                              help="Path to JSON containing info on how to pair fieldmaps to BOLD runs.")

    config_args.add_argument("--bids_path", "-b", type=ExistingDir, required=True,
                             help="The path to the directory containing the raw nifti data for all subjects, in BIDS format")
    config_args.add_argument("--derivs_path", "-d", type=ExistingDir, required=True,
                             help="The path to the BIDS formated derivatives directory for this subject")
    config_args.add_argument("--derivs_subfolder", "-ds", default=None,
                             help=f"""The subfolder in the derivatives directory where bids style outputs should be stored. 
                                  The default is {adult_defaults.derivs_subfolder} or {infant_defaults.derivs_subfolder} if the '--infant' flag is set.""")
    config_args.add_argument("--bids_config", "-c", type=ExistingFile, required=True,
                             help="The path to the dcm2bids config file to use for this subject and session")
    config_args.add_argument("--nordic_config", "-n", type=ExistingFile,
                             help="The path to the second dcm2bids config file to use for this subject and session. This implies that the session contains NORDIC data")
    config_args.add_argument("--nifti", action=argparse.BooleanOptionalAction,
                             help="Flag to specify that the source directory contains files of type NIFTI (.nii/.jsons) instead of DICOM")
    config_args.add_argument("--keep_all_niftis", action=argparse.BooleanOptionalAction,
                             help="Oceanproc will try its best to remove 'weird' NIFTI files that can be introduced during conversion from DICOM. This flag specifies that oceanproc should not do that and keep all of the files instead.")
    config_args.add_argument("--anat_only", action=argparse.BooleanOptionalAction,
                             help="Flag to specify only anatomical images should be processed.")
    config_args.add_argument("--fd_spike_threshold", "-fd", type=float, default=0.9,
                             help="framewise displacement threshold (in mm) to determine outlier framee (Default is 0.9).")
    config_args.add_argument("--skip_bids_validation", action=argparse.BooleanOptionalAction,
                             help="Specifies skipping BIDS validation (only enabled for fMRIprep step)")
    config_args.add_argument("--fs_subjects_dir", "-fs", type=ExistingDir,
                             help="The path to the directory that contains previous FreeSurfer outputs/derivatives to use for fMRIPrep. If empty, this is the path where new FreeSurfer outputs will be stored.")
    config_args.add_argument("--allow_uneven_fmap_groups", action="store_true",
                             help="Flag to allow for automated fieldmap pairing when there's more AP- than PA-encoded fieldmaps, or vice versa (will still error out if at least one of each is not present.)")
    config_args.add_argument("--extract_best_fmap", action="store_true",
                             help="Flag to specify that the lowest variance fieldmap volume should be extracted from each fieldmap, and used for distortion correction (opposed to all volumes being used)")
    config_args.add_argument("--dscans_path", type=ExistingDir,
                             help="""The path to the directory containing 'dscans' files for inserting dummy scans into bold runs. Must be named exactly as corresponding bold image except with 'dscans' as 
                             the suffix and '.tsv' as the extension. Contents of the file must be a column, titled 'dummy_scan', with ones and zeros. Ones denote which frames should be dummy scans.""")
    config_args.add_argument("--precomputed_derivatives", "-pd", type="Full-Path", dest="derivatives", nargs="*",
                             help="A list of paths to any BIDS-style precomputed derivatives that should be used in preprocessing. (Ex. /path/to/bibsnet)")
    config_args.add_argument("--work_dir", "-w", type=ExistingDir, required=True,
                             help="The path to the working directory used to store intermediate files")
    config_args.add_argument("--fs_license", "-l", type=ExistingFile, required=True,
                             help="The path to the license file for the local installation of FreeSurfer")
    config_args.add_argument("--image_version", "-iv", default=None,
                             help=f"""The version of fmriprep to use; It is reccomended that an entire study use the same version. 
                                  The default is {adult_defaults.image_version} or {infant_defaults.image_version} if the '--infant' flag is set.""")
    config_args.add_argument("--infant", "-I", action=argparse.BooleanOptionalAction,
                             help="Flag to specify that NiBabies should be used instead of fMRIPrep")
    config_args.add_argument("--preproc_image_path", "-pi", type=ExistingFile,
                             help="Path to a fMRIPrep or NiBabies apptainer image to use for preprocessing. If provided, this apptainer image will be used instead of docker. (NiBabies images should still be used with the '--infant' flag)")
    config_args.add_argument("--bibsnet_image_path", "-bi", type=ExistingFile,
                             help="Path to the BIBSnet apptainer image to use for segmentation. If provided, BIBSnet segmentation will be run and the outputs will be used for preprocessing. (Must be used with the '--infant' flag)")
    config_args.add_argument("--bibsnet_work", "-bw", type=ExistingDir,
                             help="The path to the working directory used to store intermediate files for BIBSnet")
    config_args.add_argument("--permissions_group", "-g", type=ValidGroup, default=default_user_group,
                             help=f"The user group that should own all of the created files. (Default is for the current user is '{default_user_group}'")
    config_args.add_argument("--file_permissions", "-fp", type=ValidPermissions, default=default_file_permissions,
                             help=f"The file permissions that all output files should have, represented in numeric format. (Default permissions is '{default_file_permissions}'")
    args, unknown_args = parser.parse_known_args()

    if args.infant:
        flags.infant = True

    defaults = infant_defaults if flags.infant else adult_defaults
    for k,v in defaults.__dict__.items():
        if k in args.__dict__ and args.__dict__[k] is None:
            args.__dict__[k] = v

    unknown_args = extract_options(unknown_args)

    bibsnet_path = (args.derivs_path / "bibsnet").resolve()
    if flags.infant and args.bibsnet_image_path:
        if args.derivatives is None:
            args.derivatives = [bibsnet_path]
        elif bibsnet_path not in args.derivatives:
            args.derivatives.append(bibsnet_path)

    if args.longitudinal:
        for lg_group in args.longitudinal:
            if not lg_group[0].is_dir():
                parser.error(f"Cannot find the souredata directory at the path: {lg_group[0]}")
            if len(lg_group) == 1:
                lg_group.append(None)
            elif len(lg_group) == 2:
                if not (lg_group[1].suffix in [".xml", ".json"]) or not lg_group[1].is_file():
                    parser.error(f"usability file must be a .xml or .json file, and it must exist: {lg_group[1]}")
            else:
                parser.error(f"longitudinal argument cannot have more than 2 elements: {lg_group}")
        flags.longitudinal = True

    preproc_image = f"{defaults.image_name}:{args.image_version}"
    if args.preproc_image_path:
        flags.apptainer = True
        preproc_image = args.preproc_image_path

    preproc_derivs_path = args.derivs_path / args.derivs_subfolder

    log_dir = preproc_derivs_path / f"sub-{args.subject}/log"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"sub-{args.subject}_ses-{args.session}_oceanproc_desc-{datetime.datetime.now().strftime('%m-%d-%y_%I-%M%p')}.log"
    add_file_handler(logger, log_path)
    if args.debug_mode:
        flags.debug = True
        logger.setLevel(logging.DEBUG)
    
    flags.file_permissions = args.file_permissions
    flags.permissions_group = args.permissions_group
    flags.gid = grp.getgrnam(flags.permissions_group).gr_gid
    flags.uid = os.getuid()

    logger.info("Starting oceanproc...")
    logger.info(f"Log will be stored at {log_path}")

    ##### Export the current configuration arguments to a file #####
    if args.export_args:
        try:
            assert args.export_args.parent.exists() and args.export_args.suffix, "Argument export path must be a file path in a directory that exists"
            logger.info(f"####### Exporting Configuration Arguments to: '{args.export_args}' #######")
            export_args_to_file(args, config_args, args.export_args, extra_args=unknown_args)
            update_permissions(permissions=flags.file_permissions, path=args.export_args, group=flags.permissions_group)
        except Exception as e:
            logger.exception(e)
            exit_program_early(e)


    # log the input arguments
    for k,v in (dict(args._get_kwargs())).items():
        logger.info(f" {k} : {v}")
    logger.info(f"extra arguments: {unknown_args}")

    preproc_work_dir = make_work_directory(dir_path=args.work_dir,
                                           subject=args.subject,
                                           session=args.session)
    bibsnet_work_dir = args.bibsnet_work if args.bibsnet_work else args.work_dir

    dicom_sessions = [(args.source_data, args.usability_file, args.bids_path)]
    if flags.longitudinal:
        for soure_dir, use_file in args.longitudinal:
            dicom_sessions.append((soure_dir, use_file, preproc_work_dir))

    for index, (souredata_path, use_file, bids_path) in enumerate(dicom_sessions):
        ##### Convert raw DICOMs to BIDS structure #####
        if not args.skip_dcm2bids:
            dicom_to_bids(
                subject=args.subject,
                session=args.session,
                source_dir=souredata_path,
                bids_dir=bids_path,
                usability_file=use_file,
                bids_config=args.bids_config,
                nordic_config=args.nordic_config,
                nifti=args.nifti,
                skip_validate=args.skip_bids_validation,
                skip_prompt=index > 0,
                session_index=index,
                keep_all_niftis=args.keep_all_niftis
            )
            if index > 0:
                extend_session(subject=args.subject,
                               session=args.session,
                               tmp_dir=bids_path,
                               bids_dir=args.bids_path)
                
    # create a bids layout object
    ignore_list = ["tmp_dcm2bids"]
    if (bids_path / ".bidsignore").is_file():
        with open(bids_path / ".bidsignore", "r") as f:
            ignore_list.extend(f.readlines())
    ignore_list = list(set(ignore_list))
    other_sub_paths = [
      p.name for p in bids_path.glob("sub-*") 
      if not f"sub-{args.subject}".startswith(p.name) and p.is_dir()  # 'startswith' to account for pybids regexifying after the end of subject name
    ]
    ignore_list.extend(other_sub_paths)
    bids_layout = BIDSLayout(args.bids_path, validate=False, indexer=BIDSLayoutIndexer(ignore=ignore_list, validate=False))

    ##### Remove the scans marked as 'unusable' #####
    remove_unusable_runs(
        bids_layout=bids_layout,
        subject=args.subject,
        session=args.session
    )

    ##### Pair field maps to functional runs #####
    if not args.anat_only and not args.skip_fmap_pairing:
        if args.fmap_pairing_file:
            bids_session_dir = args.bids_path / f"sub-{args.subject}/ses-{args.session}"
            map_fmap_to_func_with_pairing_file(
                bids_session_dir,
                args.fmap_pairing_file
            )
        else:
            # update the bids layout
            bids_layout = BIDSLayout(args.bids_path, validate=False, indexer=BIDSLayoutIndexer(ignore=ignore_list, validate=False))
            map_fmap_to_func(
                subject=args.subject,
                session=args.session,
                layout=bids_layout,
                allow_uneven_fmap_groups=args.allow_uneven_fmap_groups,
                extract_best_fmap=args.extract_best_fmap
            )

    ##### Run BIBSnet #####
    bibsnet_args = {key:unknown_args[key] for key in segmentation_args if key in unknown_args}
    for key in segmentation_args:
        if key in unknown_args:
            del unknown_args[key]

    if flags.infant and args.bibsnet_image_path and (not args.skip_segmentation):
        segment_anatomical(
            subject=args.subject,
            session=args.session,
            bids_path=args.bids_path,
            derivs_path=args.derivs_path,
            work_path=bibsnet_work_dir,
            bibsnet_image=args.bibsnet_image_path,
            remove_work_folder=False,
            **bibsnet_args
        )

        if not bibsnet_path.exists():
            exit_program_early(f"Cannot find the outputs for BIBSnet at the path {bibsnet_path}")


    ##### Insert dummy scans in requested #####
    if args.dscans_path:
        insert_dummy_frames(
            subject=args.subject,
            session=args.session,
            dscan_dir=args.dscans_path,
            bids_layout=bids_layout
        )


    ##### Run fMRIPrep or NiBabies #####
    all_opts = dict(args._get_kwargs())

    additional_mounts = {make_option(True, mo, convert_underscore=True).strip():all_opts[mo] for mo in mount_opts if all_opts[mo]}
    fmrip_options = {"skip_bids_validation",
                     "fd_spike_threshold",
                     "anat_only"}

    if not args.skip_preproc:
        process_data(
            subject=args.subject,
            session=args.session,
            bids_path=args.bids_path,
            derivs_path=preproc_derivs_path,
            work_path=preproc_work_dir,
            license_file=args.fs_license,
            image_name=preproc_image,
            additional_mounts=additional_mounts,
            remove_work_folder=not args.keep_work_dir,
            **({o:all_opts[o] for o in fmrip_options} | unknown_args)
        )

    ##### Create long formatted event files #####
    if not args.skip_event_files and not args.anat_only:
        create_events_and_confounds(
            bids_path=args.bids_path,
            derivs_path=preproc_derivs_path,
            sub=args.subject,
            ses=args.session,
            fd_thresh=args.fd_spike_threshold
        )

    log_linebreak()
    logger.info("####### [DONE] Finished all processing, exiting now #######")


if __name__ == "__main__":
    main()
