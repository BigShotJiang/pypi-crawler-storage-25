#!/usr/bin/env python3

import json
from datetime import datetime, timedelta
import argparse
from pathlib import Path
from bids import BIDSLayout
import logging

from bids.layout import BIDSFile
from .utils import exit_program_early, debug_logging, log_linebreak, flags, update_permissions
import nibabel as nib
import numpy as np

module_logger = logging.getLogger("fsspec")
module_logger.setLevel(logging.CRITICAL)

logger = logging.getLogger(__name__)

DEFAULT_LOCALIZER_LABEL = "00"
EXTRACTED_ACQ_VALUE = "bestVol"

def get_empty_group():
    return {"task":set(), "fmapAP": set(), "fmapPA": set()}


def get_json_sidecar(bids_file:BIDSFile|str, bids_layout:BIDSLayout) -> BIDSFile:
    if isinstance(bids_file, BIDSFile):
        bids_file = bids_file.path
    sidecar_ents = bids_layout.parse_file_entities(bids_file) | {"extension":".json"}
    if "fmap" in sidecar_ents:
        del sidecar_ents["fmap"]
    sidecar_files = bids_layout.get(**sidecar_ents)
    valid_files = [bf for bf in sidecar_files if set(sidecar_ents.keys()) == set(bids_layout.parse_file_entities(bf).keys())]
    if len(valid_files) != 1:
        exit_program_early(f"Cannot find the associated JSON file for bids file: {bids_file}")
    return valid_files[0]


def reset_intended_for(fmap_file:BIDSFile|str, bids_layout:BIDSLayout):
    sidecar_file = get_json_sidecar(fmap_file, bids_layout)
    jd = sidecar_file.get_dict()
    jd["IntendedFor"] = []
    with open(sidecar_file.path, "w") as out_file:
        json.dump(jd, out_file, indent=4)


def get_func_from_bids(bids_layout: BIDSLayout,
                       subject:str,
                       session:str,
                       groupings: list[dict[str:set]]):

    func_files = bids_layout.get(subject=subject, session=session, suffix="bold", datatype="func", extension="nii.gz")
    if len(func_files) == 0:
        exit_program_early("Could not find any functional BOLD files for this subject and session.")

    for bold_file in func_files:
        acq_time = datetime.strptime(bold_file.entities["AcquisitionTime"], "%H:%M:%S.%f")
        localizer_block_label = bold_file.entities["localizer_block"] if "localizer_block" in bold_file.entities else DEFAULT_LOCALIZER_LABEL
        if localizer_block_label not in groupings:
            groupings[localizer_block_label] = get_empty_group()
        groupings[localizer_block_label]["task"].add((bold_file, acq_time))


def get_fmap_from_bids(bids_layout: BIDSLayout,
                       subject:str,
                       session:str,
                       groupings: list[dict[str:set]]):

    fmap_files = bids_layout.get(subject=subject, session=session, suffix="epi", datatype="fmap", extension="nii.gz")
    if len(fmap_files) == 0:
        exit_program_early("Could not find any fieldmap files for this subject and session.")

    for epi_file in fmap_files:
        reset_intended_for(epi_file, bids_layout)
        file_entities = bids_layout.parse_file_entities(epi_file.path)
        # skip previously extracted acqusitions
        if ("acquisition" in file_entities) and file_entities["acquisition"] == EXTRACTED_ACQ_VALUE:
            continue
        acq_time = datetime.strptime(epi_file.entities["AcquisitionTime"], "%H:%M:%S.%f")
        direction = f"fmap{epi_file.entities['direction']}"
        localizer_block_label = epi_file.entities["localizer_block"] if "localizer_block" in epi_file.entities else DEFAULT_LOCALIZER_LABEL
        if localizer_block_label not in groupings:
            groupings[localizer_block_label] = get_empty_group()
        groupings[localizer_block_label][direction].add((epi_file, acq_time))


def uneven_fmap_pairing(localizer_group: dict) -> tuple:
    """
    If the number of AP/PA fieldmaps is different, this algorithm
    will return N pairs of AP/PA fieldmap sets, where N is the number
    of whichever fieldmap type has less fieldmaps. It will find one
    fieldmap of each type, and pair it with its counterpart whose
    acquisition time is closest to its own.

    For example, if a group consists of two AP scans and one PA scan collected in order
    (and all are marked as usable), this would return a tuple containing one fieldmap
    pair consisting of the second AP scan and the first PA scan.

    Note that the pairs will always be returned in the order (AP, PA).

    :param localizer_group: Dictionary containing fieldmap information within a localizer group
    :type localizer_group: dict
    :return: Tuple of pairs of AP/PA fieldmaps
    :rtype: tuple
    """
    fmap_pairs = []  # casted into tuple at the end
    sortedAPs = sorted(localizer_group["fmapAP"], key=lambda x: x[1])
    sortedPAs = sorted(localizer_group["fmapPA"], key=lambda x: x[1])
    if len(sortedAPs) > len(sortedPAs):
        bigger, smaller, reversed_order = sortedAPs, sortedPAs, False
    else:
        bigger, smaller, reversed_order = sortedPAs, sortedAPs, True
    diff = timedelta.max
    while len(smaller) > 0:
        cur_smaller = smaller.pop(0)
        while len(bigger) > 0 and (cur_diff := abs(bigger[0][1] - cur_smaller[1])) < diff:
            cur_bigger = bigger.pop(0)
            cur_pair = (cur_smaller, cur_bigger) if reversed_order else (cur_bigger, cur_smaller)
            diff = cur_diff
        diff = timedelta.max
        fmap_pairs.append(cur_pair)
        assert len(bigger) >= len(smaller)
        if len(bigger) == len(smaller):
            fmap_pairs.extend(
                zip(smaller, bigger) if reversed_order else zip(bigger, smaller)
            )
            bigger.clear()
            smaller.clear()
    return tuple(fmap_pairs)


def even_fmap_pairing(localizer_group: dict) -> tuple:
    """
    If the number of AP/PA fieldmaps are the same in a localizer
    group, pair them in order of appearance.

    Note that the pairs will always be returned in the order (AP, PA).

    :param localizer_group: Dictionary containing fieldmap information within a localizer group
    :type localizer_group: dict
    :return: Tuple of pairs of AP/PA fieldmaps
    :rtype: tuple
    """
    return tuple(
        zip(
            sorted(localizer_group["fmapAP"], key=lambda x: x[1]),
            sorted(localizer_group["fmapPA"], key=lambda x: x[1])
        )
    )


@debug_logging
def map_fmap_to_func(subject:str,
                     session:str,
                     layout:BIDSLayout,
                     allow_uneven_fmap_groups: bool = False,
                     extract_best_fmap: bool = False):
    
    logger.info("####### Pairing field maps to functional runs #######\n")

    groups = dict()
    get_func_from_bids(bids_layout=layout,
                       subject=subject,
                       session=session,
                       groupings=groups)

    get_fmap_from_bids(bids_layout=layout,
                       subject=subject,
                       session=session,
                       groupings=groups)

    groups = list(groups.values())
    logger.info("Localizer groups: ")
    for group_num, g in enumerate(groups):
        logger.info(f"\tgroup : {group_num}")
        for k, v in g.items():
            logger.info(f"\t\t{k}: {v}")

    for group in groups:
        if len(group["fmapAP"]) != len(group["fmapPA"]):
            if not allow_uneven_fmap_groups:
                exit_program_early(f"--allow_uneven_fmap_groups not set. (#AP: {len(group['fmapAP'])}, #PA: {len(group['fmapPA'])})")
            elif len(group["fmapPA"]) == 0 or len(group["fmapAP"]) == 0:
                exit_program_early(f"Not enough fieldmaps in one direction (AP:\n{group['fmapAP']}, {len(group['fmapAP'])=}\nPA:\n{group['fmapAP']}, {len(group['fmapPA'])=})")
            fmap_pairs = uneven_fmap_pairing(group)
        else:
            fmap_pairs = even_fmap_pairing(group)

        fmap_times = []
        # get times for field maps
        for i, ((ap_file, ap_acq_time), (pa_file, pa_acq_time)) in enumerate(fmap_pairs):
            times = sorted((ap_acq_time, pa_acq_time))
            fmap_times.append(times[0] + (abs(times[1] - times[0]) / 2))

        # pair task runs with field maps based on closest Acquisition Time
        time_pairings = {s:[] for s in fmap_pairs}
        for (t_file, t_acq_time) in group["task"]:
            diff = list(map(lambda x: abs(x - t_acq_time), fmap_times))
            pairing = fmap_pairs[diff.index(min(diff))]
            time_pairings[pairing].append(t_file)
        
        # gather the sidecar files and extract volumes if requested
        file_pairing = dict()
        for (ap_tup, pa_tup), task_files in time_pairings.items():
            if extract_best_fmap:
                ap_info = extract_best_acqusition(ap_tup[0], layout)
                pa_info = extract_best_acqusition(pa_tup[0], layout)
            else:
                ap_info = (ap_tup[0], get_json_sidecar(ap_tup[0], layout))
                pa_info = (pa_tup[0], get_json_sidecar(pa_tup[0], layout))
            file_pairing[(ap_info, pa_info)] = task_files

        # add the list of task run files that are paired with each field map in their json files
        pairing_strs = []
        for fmap_info, task_files in file_pairing.items():
            for fmap_file, fmap_json in fmap_info:
                intended_for = [tf.relpath.split("/", 1)[-1] for tf in task_files]
                task_series = set([f"{tf.filename}({str(tf.entities['SeriesNumber'])})" for tf in task_files])
                jd = None
                with open(fmap_json.path, "r") as fjson:
                    jd = json.load(fjson)
                jd["IntendedFor"] = intended_for
                with open(fmap_json.path, "w") as out_file:
                    logger.debug(f"writing field map pairing information to file: {fmap_json.filename}")
                    json.dump(jd, out_file, indent=4)
                pairing_strs.append((f"{fmap_file.filename}:{jd['SeriesNumber']}", ' '.join(task_series)))

        # report the fieldmap pairings
        if len(pairing_strs) > 0:
            logger.info("Field map pairings:")
            for ps in pairing_strs:
                logger.info(f"{ps[0]} -->  {ps[1]}")


def map_fmap_to_func_with_pairing_file(bids_dir_path: Path,
                                       pairing_json: Path):
    log_linebreak()
    for json_path in bids_dir_path.glob("fmap/*json"):  # reset IntendedFor field in all fmap json
        with open(json_path) as f:
            json_obj = json.load(f)
        json_obj["IntendedFor"] = []
        with open(json_path, "w") as f:
            json.dump(json_obj, f, indent=4)
    logger.info("####### Pairing field maps to functional runs using pairing file #######\n")
    with pairing_json.open() as f:
        pairing_dict = json.load(f)
    pairings_list = pairing_dict["pairings"]
    for pairing in pairings_list:
        fmap_jsons = bids_dir_path.glob(f"fmap/*{pairing['fmap']}*json")
        func_paths = []
        for func in pairing["func"]:
            func_paths.extend(
                [str(p.relative_to(bids_dir_path.parent)) for p in bids_dir_path.parent.glob(f"*/func/*{func}*nii.gz")]
            )
        for fmap_json in fmap_jsons:
            with fmap_json.open() as f:
                fmap_dict = json.load(f)
            fmap_dict["IntendedFor"] = func_paths
            with fmap_json.open('w') as f:
                json.dump(fmap_dict, f, indent=4)


def extract_best_acqusition(fmap_file: str|BIDSFile, bids_layout: BIDSLayout) -> tuple[BIDSFile]:

    if isinstance(fmap_file, BIDSFile):
        fmap_file = fmap_file.path

    fmap_img = nib.load(fmap_file)
    fmap_data = fmap_img.get_fdata()
    assert len(fmap_data.shape) == 4, f"Fieldmap supplied does not have 4 dimensions : {fmap_file}"

    # file the volume with the lowest standard deviation
    slice_diffs = np.diff(fmap_data, axis=2)
    vol_stds = np.nanstd(slice_diffs, axis=(0,1,2))
    best_vol = np.argmin(vol_stds)

    # create a new bids name for the best volume
    new_entities = bids_layout.parse_file_entities(fmap_file) | {"acquisition" : EXTRACTED_ACQ_VALUE}
    best_acq_fmap = bids_layout.build_path(new_entities)
    # save out the new image
    best_acq_fmap_img = fmap_img.__class__(fmap_data[:,:,:,best_vol], affine=fmap_img.affine)
    logger.info(f"saving extracted fieldmap to path: {best_acq_fmap}")
    nib.save(best_acq_fmap_img, best_acq_fmap)

    # create a new bids name for the sidecar file
    sidecar_entities = new_entities | {"extension": ".json"}
    best_acq_json = bids_layout.build_path(sidecar_entities)
    # find the original sidecar file and copy it
    fmap_json = get_json_sidecar(fmap_file, bids_layout)
    jd = {}
    with open(fmap_json.path, "r") as fjs:
        jd = json.load(fjs)

    # add metadata and save
    jd["Sources"] = ["bids::"+str(Path(fmap_json.path).relative_to(bids_layout.root))]
    jd["ExtractedVolume"] = int(best_vol + 1)
    with open(best_acq_json, "w") as out_js:
        json.dump(jd, out_js, indent=4)

    for fmap_out_path in [best_acq_fmap, best_acq_json]:
        update_permissions(
            permissions=flags.file_permissions,
            path=fmap_out_path,
            group=flags.permissions_group,
        )

    return (BIDSFile(best_acq_fmap), BIDSFile(best_acq_json))
    


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog="group_series.py",
        description="Grouping field maps to BOLD task runs"
    )
    parser.add_argument("xml_ses_file", type=Path, help="The path to the xml file for this session")
    parser.add_argument("bids_ses_dir", type=Path, help="The path to the bids directory for this session")
    args = parser.parse_args()

    map_fmap_to_func(xml_path=args.xml_ses_file,
                     bids_dir_path=args.bids_ses_dir)
