from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field
from packaging.requirements import Requirement
from pathlib import Path
from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from repoplone._types.pipeline import PipelineReleaseStep


Requirements = dict[str, Requirement]


@dataclass
class Changelogs:
    """Changelog locations."""

    root: Path
    backend: Path
    frontend: Path

    def sanity(self) -> bool:
        return self.root.exists()


@dataclass
class Package:
    """Package information."""

    enabled: bool
    name: str
    path: Path
    changelog: Path
    towncrier: Path
    base_package: str
    code_path: Path
    base_package_version: str = ""
    publish: bool = True
    version: str = ""

    def sanity(self) -> bool:
        if not self.enabled:
            return True
        return (
            self.path.exists() and self.changelog.exists() and self.towncrier.exists()
        )


@dataclass
class BackendPackage(Package):
    """Backend package information."""

    managed_by_uv: bool = False
    python_version: str = ""
    python_versions: list[str] = field(default_factory=list)
    plone_versions: list[str] = field(default_factory=list)


@dataclass
class FrontendPackage(Package):
    """Frontend package information."""

    volto_version: str = ""


@dataclass
class TowncrierSection:
    """Towncrier section."""

    section_id: str
    name: str
    path: Path

    def sanity(self) -> bool:
        return self.path.exists() if self.path else False


@dataclass
class TowncrierSettings:
    """Towncrier settings."""

    sections: list[TowncrierSection]

    def __getattr__(self, name: str):
        for section in self.sections:
            if section.section_id == name:
                return section
        raise AttributeError(f"{name} not found")

    def sanity(self) -> bool:
        sections = self.sections
        checks = [section.sanity() for section in sections]
        return all(checks)


@dataclass
class RepositorySettings:
    """Settings for a distribution."""

    name: str
    managed_by_uv: bool
    root_path: Path
    version: str
    version_format: str
    container_images_prefix: str
    backend: BackendPackage
    frontend: FrontendPackage
    version_path: Path
    compose_path: list[Path]
    towncrier: TowncrierSettings
    changelogs: Changelogs
    release_steps: list[PipelineReleaseStep] = field(default_factory=list)
    remote_origin: str = ""
    issues_url: str = ""
    _tmp_changelog: str = ""

    @property
    def path(self) -> Path:
        return self.root_path

    def sanity(self) -> bool:
        steps = [
            self.root_path.exists(),
            self.backend.sanity(),
            self.frontend.sanity(),
            self.version_path.exists(),
            all(path.exists() for path in self.compose_path),
            self.towncrier.sanity(),
            self.changelogs.sanity(),
        ]
        return all(steps)
