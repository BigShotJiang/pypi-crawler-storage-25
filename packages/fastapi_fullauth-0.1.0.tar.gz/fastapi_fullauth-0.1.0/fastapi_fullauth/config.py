import warnings
from typing import Literal

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class FullAuthConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="FULLAUTH_", case_sensitive=True)

    SECRET_KEY: str | None = None
    ALGORITHM: str = "HS256"

    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30
    REFRESH_TOKEN_ROTATION: bool = True

    PASSWORD_HASH_ALGORITHM: Literal["argon2id", "bcrypt"] = "argon2id"
    PASSWORD_MIN_LENGTH: int = 8

    MAX_LOGIN_ATTEMPTS: int = 5
    LOCKOUT_DURATION_MINUTES: int = 15

    RATE_LIMIT_ENABLED: bool = False
    RATE_LIMIT_BACKEND: Literal["memory", "redis"] = "memory"

    AUTH_RATE_LIMIT_ENABLED: bool = True
    AUTH_RATE_LIMIT_LOGIN: int = 5
    AUTH_RATE_LIMIT_REGISTER: int = 3
    AUTH_RATE_LIMIT_PASSWORD_RESET: int = 3
    AUTH_RATE_LIMIT_WINDOW_SECONDS: int = 60

    REDIS_URL: str | None = None

    BLACKLIST_ENABLED: bool = True
    BLACKLIST_BACKEND: Literal["memory", "redis"] = "memory"

    INJECT_SECURITY_HEADERS: bool = True

    CSRF_ENABLED: bool = False
    CSRF_SECRET: str | None = None

    COOKIE_NAME: str = "fullauth_access"
    COOKIE_SECURE: bool = True
    COOKIE_HTTPONLY: bool = True
    COOKIE_SAMESITE: Literal["lax", "strict", "none"] = "lax"
    COOKIE_DOMAIN: str | None = None

    API_PREFIX: str = "/api/v1"
    AUTH_ROUTER_PREFIX: str = "/auth"
    ROUTER_TAGS: list[str] = ["Auth"]

    @model_validator(mode="after")
    def _ensure_secret_key(self) -> "FullAuthConfig":
        if self.SECRET_KEY is None:
            from fastapi_fullauth.utils import generate_secret_key

            object.__setattr__(self, "SECRET_KEY", generate_secret_key())
            warnings.warn(
                "FULLAUTH_SECRET_KEY is not set. A random key has been generated. "
                "Tokens will be invalidated on restart. "
                "Set FULLAUTH_SECRET_KEY for production.",
                UserWarning,
                stacklevel=2,
            )
        return self
