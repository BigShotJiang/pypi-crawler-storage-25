"""Data export service for BOFS.

The Results class and associated helpers for building participant data exports,
DataFrames, and summary statistics.
"""

from sqlalchemy.orm import Query
from BOFS.globals import db, questionnaires, page_list
import sqlalchemy
from BOFS.admin.util import csv_string, questionnaire_name_and_tag, condition_num_to_label
from flask import current_app
import pandas as pd
import os
from datetime import datetime, timezone
from typing import Union

from BOFS.util import utcnow_naive
from BOFS.validation import is_sql_expression_safe

MAX_CACHE_SECONDS = 60 * 2


def _safe_sql_text(expr: str, source: str):
    """Wrap a researcher-authored expression in db.text after validating it.

    Raises ValueError if the expression isn't allow-list-clean. Validation
    also runs at table load time (see validation.validate_table); this is
    defence in depth so a hand-built export definition or a config path that
    bypasses validation can't reach raw db.text().
    """
    ok, why = is_sql_expression_safe(expr)
    if not ok:
        raise ValueError(f"Unsafe SQL expression in {source}: {why}")
    return db.text(expr)


def _safe_literal_column(expr: str, source: str):
    ok, why = is_sql_expression_safe(expr)
    if not ok:
        raise ValueError(f"Unsafe SQL expression in {source}: {why}")
    return db.literal_column(expr)


class Results(object):
    def __init__(self, filter_criterion=None, cache_path: Union[str, None] = None):
        self.cache_path = cache_path
        use_cache = False

        if cache_path is not None:
            if os.path.exists(cache_path):
                modified_time = datetime.fromtimestamp(os.path.getmtime(cache_path), tz=timezone.utc).replace(tzinfo=None)
                if (utcnow_naive() - modified_time).total_seconds() < MAX_CACHE_SECONDS:
                    use_cache = True

        self.df = None
        self.column_list: list[str] = []
        self.export_data: Union[dict[str, dict], dict] = {}
        """Keys are participant IDs, value is a dictionary of all columns."""
        self.query_participants: Query
        self.query_filter_criterion = filter_criterion

        if use_cache:
            self.load_data_frame()
        else:
            self.handle_participants_table()
            self.handle_questionnaires()
            self.handle_custom_exports()

    def handle_participants_table(self) -> None:
        """
        Add participant columns to column_list and their data to export_data.
        :param column_list: A list of strings that will be the columns in the CSV export.
        :param export_data: Gets updated with data for the participants
        :return: A SQLAlchemy query.
        """
        self.query_participants = db.session.query(db.Participant)

        if self.query_filter_criterion is not None:
            self.query_participants = self.query_participants.filter(self.query_filter_criterion)

        self.column_list.extend([
            "participantID",
            "externalID",
            "condition",
            "duration",
            "finished"
        ])

        query_result = self.query_participants.all()

        for row in query_result:
            self.export_data[row.participantID] = {
                'participantID': row.participantID,
                'externalID': row.mTurkID,
                'condition': condition_num_to_label(row.condition),
                'duration': row.duration,
                'finished': row.finished
            }

    def handle_questionnaires(self) -> None:
        list_of_questionnaires = page_list.get_questionnaire_list(include_tags=True)

        query_questionnaires = self.query_participants
        q_columns = {}
        q_calculated_columns = {}

        # First loop constructs the query and fetches the column names
        for entry in list_of_questionnaires:
            q_columns[entry] = []
            q_calculated_columns[entry] = []
            questionnaire_name, questionnaire_tag = questionnaire_name_and_tag(entry)

            # The python class that describes the questionnaire
            questionnaire = questionnaires[questionnaire_name]

            # Add the questionnaire's table/class to the query...
            questionnaire_db_class = db.aliased(questionnaire.db_class, name=entry)
            join_condition = db.and_(questionnaire_db_class.participantID == db.Participant.participantID,
                                     questionnaire_db_class.tag == questionnaire_tag
                                     )

            query_questionnaires = query_questionnaires.outerjoin(questionnaire_db_class, join_condition). \
                add_entity(questionnaire_db_class)

            # Make a list of the columns to later construct the CSV header row
            # This could also be done with questionnaire.fields
            for column in questionnaire.fetch_fields():
                self.column_list.append(entry + "_" + column.id)
                q_columns[entry].append(column.id)

            # Similarly, make a list of calculated columns to later be part of the CSV header row.
            for column in questionnaire.get_calculated_fields():
                self.column_list.append(entry + "_" + column)
                q_calculated_columns[entry].append(column)

            # Duration always gets added
            self.column_list.append(entry + "_duration")

        query_result = query_questionnaires.all()

        # Now we get the actual data
        for row in query_result:
            for entry in list_of_questionnaires:  # Need to look through the questionnaires again
                questionnaire_data = getattr(row, entry)

                if questionnaire_data:
                    # Regular columns first
                    for col in q_columns[entry]:
                        self.export_data[row.Participant.participantID][entry + "_" + col] = (
                            getattr(questionnaire_data, col))

                    # Now calculated columns
                    for col in q_calculated_columns[entry]:
                        if questionnaire_data:
                            self.export_data[row.Participant.participantID][entry + "_" + col] = (
                                getattr(questionnaire_data, col)())

                    # Duration always gets added
                    self.export_data[row.Participant.participantID][entry + "_duration"] = questionnaire_data.duration()

    def handle_custom_exports(self) -> None:
        # Repeated measures in other tables...
        custom_exports = []

        for export in current_app.config['EXPORT']:
            levels, fields, base_query = self.create_export_base_query(export)
            custom_exports.append({'options': export, 'fields': fields, 'base_query': base_query, 'levels': levels})

        # For custom exports, add columns based on levels determined by prior query
        for export in custom_exports:
            if export['levels']:
                for level in export['levels']:
                    for field in export['options']['fields']:
                        column_header = str.format("{}", field)
                        for level_name in level:
                            column_header += str.format("_{}", str(level_name).replace(" ", "_"))
                        self.column_list.append(column_header)
            else:
                for field in export['options']['fields']:
                    self.column_list.append(str.format(u"{}", field))

        query_result = self.query_participants.all()

        # Now we get the actual data
        for row in query_result:
            participant_id = row.participantID

            for export in custom_exports:
                query = export['base_query']
                query = query.filter(db.literal_column('participantID') == row.participantID)
                custom_export_data = query.all()  # Running separate queries will get the job done, but be kind of slow with many participants...

                export_row_index = 0
                for custom_export_row in custom_export_data:
                    for field in export['fields']:
                        export_column_name = field
                        if export['levels']:
                            export_column_name = field + "_" + str(export['levels'][export_row_index][0])

                        self.export_data[participant_id][export_column_name] = getattr(custom_export_row, field)

                    export_row_index += 1

    def create_export_base_query(self, export_definition: dict) -> tuple[list, list, "Query"]:
        """
        Builds the base query for exporting values in blueprint-defined tables.
        To be used for each entry in the config's EXPORT
        :param export_definition:
        :return: levels, fields, baseQuery
        """
        table = getattr(db, export_definition['table'])

        levels = None
        fields = []
        filter = None
        groupBy = None
        orderBy = None
        having = None

        export_label = (
            f"EXPORT[table={export_definition.get('table')!r}]"
        )

        if 'filter' in export_definition and export_definition['filter'] != '':
            filter = _safe_sql_text(
                export_definition['filter'], f"{export_label} filter"
            )

        if 'order_by' in export_definition and export_definition['order_by'] != '':
            orderBy = getattr(table, export_definition['order_by'])

        # Determine how many columns to add to the export. If group_by is not used, then it's just one column
        if 'group_by' in export_definition and export_definition['group_by'] != '':
            if 'having' in export_definition and export_definition['having'] != '':  # Having can only work if group_by is used.
                having = _safe_sql_text(
                    export_definition['having'], f"{export_label} having"
                )

            levelsQ = db.session.query()

            if isinstance(export_definition['group_by'], list):
                groupBy = []
                for gb in export_definition['group_by']:
                    groupBy.append(getattr(table, gb))
                    levelsQ = levelsQ.add_columns(getattr(table, gb))
                    levelsQ = levelsQ.group_by(getattr(table, gb))
            else:
                groupBy = getattr(table, export_definition['group_by'])
                levelsQ = levelsQ.add_columns(groupBy)
                levelsQ = levelsQ.group_by(groupBy)

            if orderBy:
                levelsQ = levelsQ.order_by(orderBy)

            if filter is not None:
                levels = levelsQ.filter(filter).all()
            else:
                levels = levelsQ.all()

        # pk = db.inspect(table).primary_key[0]
        baseQuery = db.session.query(table)

        if groupBy:
            if isinstance(groupBy, list):
                for gb in groupBy:
                    baseQuery = baseQuery.group_by(getattr(table, 'participantID'), gb)
            else:
                baseQuery = baseQuery.group_by(getattr(table, 'participantID'), groupBy)

            if having is not None:
                baseQuery = baseQuery.having(having)
        else:
            baseQuery = baseQuery.group_by(getattr(table, 'participantID'))

        if orderBy:
            baseQuery = baseQuery.order_by(orderBy)

        if filter is not None:
            baseQuery = baseQuery.filter(filter)

        # Add the fields to the basequery
        for field in export_definition['fields']:
            if hasattr(table, field) and callable(getattr(table, field)):
                continue  # We can't include this python property as part of the query
            fields.append(field)
            baseQuery = baseQuery.add_columns(
                _safe_literal_column(
                    export_definition['fields'][field],
                    f"{export_label} fields[{field!r}]",
                ).label(field)
            )

        return levels, fields, baseQuery

    def load_data_frame(self):
        df = pd.read_json(self.cache_path)
        self.handle_participants_table()

        # Compare participant identities, not just counts. A count check
        # alone misses the case where one participant was added since the
        # cache was written and another was excluded — the IDs differ but
        # the totals match, then the per-ID lookup below raises IndexError
        # on the missing-from-cache row.
        cached_ids = set(df["participantID"].tolist()) if "participantID" in df.columns else set()
        live_ids = set(self.export_data.keys())

        if cached_ids != live_ids:
            self.handle_questionnaires()
            self.handle_custom_exports()
            return

        self.df = df
        self.column_list = self.df.columns.values.tolist()

        for participantID in self.df["participantID"].values.tolist():
            self.export_data[participantID] = {}
            for column in self.column_list:
                self.export_data[participantID][column] = self.df[df["participantID"] == participantID][column].values.tolist()[0]

    def build_data_frame(self) -> "pd.DataFrame":
        if self.df is not None:
            return self.df

        data = []
        for key in self.export_data:
            data.append(self.export_data[key])

        self.df = pd.DataFrame(data)

        if self.cache_path is not None:
            self.df.to_json(self.cache_path)

        return self.df

    def build_export_csv(self) -> str:
        rows = [list(self.column_list)]
        for row in self.export_data.values():
            rows.append([row.get(column, "") for column in self.column_list])
        # csv_string ends with a trailing newline; existing callers expected
        # no trailing newline, so strip it.
        return csv_string(rows).rstrip("\n")

    @staticmethod
    def build_filter_from_args(args):
        """Construct a SQLAlchemy filter from request.args query parameters.

        Each toggle, when off, adds a restricting clause; when on, leaves the
        category in the export. Recognized params (literal string 'true' /
        'false', case-insensitive):
          - includeUnfinished (default False) — when False, restrict to finished participants.
          - includeExcluded   (default False) — when False, restrict to non-excluded participants.
          - includeMissing    (default True)  — accepted but currently unused by the filter; kept for API parity.

        Returns: a ClauseElement (db.and_), or None when both toggles are on
        (no filter at all).
        """
        def _parse(name, default):
            value = args.get(name)
            if value is None:
                return default
            if isinstance(value, bool):
                return value
            return str(value).strip().lower() in ('true', 'on', '1', 'yes')

        include_unfinished = _parse('includeUnfinished', False)
        include_excluded   = _parse('includeExcluded', False)
        _parse('includeMissing', True)  # accepted for API parity; not used by the filter

        clauses = []
        if not include_unfinished:
            clauses.append(db.Participant.finished == True)
        if not include_excluded:
            clauses.append(db.or_(db.Participant.excludeFromCount == False,
                                  db.Participant.excludeFromCount == None))

        if not clauses:
            return None
        return db.and_(*clauses)

    @staticmethod
    def calculate_results(cache_path):
        """Build a Results, its DataFrame, and per-numeric-column SummaryStats.

        Returns (results, df, summary_stats) where summary_stats is a dict keyed
        by column name, valued by SummaryStats. Filters to finished, non-excluded
        participants. Used by the admin /results and /results_boxplot routes.
        """
        from BOFS.admin.SummaryStats import SummaryStats  # avoid circular at module load
        # Match fetch_progress_summary: legacy rows can have NULL excludeFromCount,
        # which ``== False`` filters out. ``or_`` keeps them in the results.
        results = Results(
            db.and_(
                db.Participant.finished == True,
                db.or_(
                    db.Participant.excludeFromCount == False,
                    db.Participant.excludeFromCount == None,  # noqa: E711
                ),
            ),
            cache_path,
        )
        df = results.build_data_frame()

        summary_stats = {}
        if len(df) > 0:
            df_grouped = df.groupby(by="condition")
            for column in list(df_grouped.head()):
                dtype = df[column].head().dtype.name
                if dtype in ['int64', 'float64', 'bool'] and column not in ['participantID', 'condition', 'duration', 'finished']:
                    summary_stats[column] = SummaryStats(df_grouped, column)

        return results, df, summary_stats
