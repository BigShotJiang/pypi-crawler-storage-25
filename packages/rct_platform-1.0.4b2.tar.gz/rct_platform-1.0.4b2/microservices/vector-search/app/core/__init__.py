"""Core vector engine"""
