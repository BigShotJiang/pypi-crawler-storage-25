"""
Atlas Memory SDK
================
Persistent, multi-layered cognitive memory for AI agents.

Classes
-------
AtlasMemory       — Knowledge-graph memory client (legacy memory-service)
CognitiveBrain    — Cognitive AI Brain client (CAB-QA, multi-vector memory)
AsyncCognitiveBrain — Async version of CognitiveBrain (requires httpx)

Usage
-----
  from atlas_memory import CognitiveBrain

  brain = CognitiveBrain(
      api_key="atlas_...",
      base_url="https://your-atlas-instance.com",
      user_id="user-123",
  )
  brain.add("Apollo is built on FastAPI and PostgreSQL.")
  results = brain.search("What stack does Apollo use?")
  print(results.context)
"""

from atlas_memory.client import AtlasMemory
from atlas_memory.cognitive_brain import (
    CognitiveBrain,
    AsyncCognitiveBrain,
    IngestResult,
    SearchResult,
)

__all__ = [
    "AtlasMemory",
    "CognitiveBrain",
    "AsyncCognitiveBrain",
    "IngestResult",
    "SearchResult",
]

__version__ = "2.0.0"