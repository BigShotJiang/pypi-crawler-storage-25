"""
Atlas Cognitive Brain SDK — Python client for the CAB-QA service.

Provides:
  CognitiveBrain        — sync client (only `requests` needed)
  AsyncCognitiveBrain   — async client (requires `httpx`)

Usage:
  from atlas_memory import CognitiveBrain

  brain = CognitiveBrain(
      api_key="atlas_...",
      base_url="https://your-atlas-instance.com",
      user_id="user-123",
      session_id="session-abc",   # optional
  )

  # Ingest
  brain.add("Project Apollo uses PostgreSQL on AWS RDS.")

  # Retrieve
  results = brain.search("What database are we using?")
  print(results.context)

  # Graph QA
  answer = brain.ask("Who owns the backend API for Apollo?")
"""

from __future__ import annotations
import json
import time
import logging
from typing import Optional, List, Dict, Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger("atlas_cognitive_brain")


# ── Retry strategy ────────────────────────────────────────
def _build_session(retries: int = 3, backoff: float = 1.0) -> requests.Session:
    """HTTP session with exponential backoff on 429/503."""
    session = requests.Session()
    retry = Retry(
        total=retries,
        backoff_factor=backoff,
        status_forcelist=[429, 503, 504],
        allowed_methods=["POST", "GET", "DELETE"],
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


# ── Response wrappers ─────────────────────────────────────

class IngestResult:
    """Result of a brain.add() call."""
    def __init__(self, data: dict):
        self.facts_ingested: int = data.get("facts_ingested", 0)
        self.episodic_chunks: int = data.get("episodic_chunks", 0)
        self.entities_extracted: int = data.get("entities_extracted", 0)
        self.triples_extracted: int = data.get("triples_extracted", 0)
        self.latency_ms: float = data.get("latency_ms", 0.0)
        self.msg: str = data.get("msg", "")
        self._raw = data

    def __repr__(self):
        return (f"IngestResult(facts={self.facts_ingested}, "
                f"chunks={self.episodic_chunks}, latency={self.latency_ms:.0f}ms)")


class SearchResult:
    """Result of a brain.search() call."""
    def __init__(self, data: dict):
        self.context: str = data.get("context", "")
        self.facts: List[Dict[str, Any]] = data.get("facts", [])
        self.episodic_count: int = data.get("episodic_count", 0)
        self.semantic_count: int = data.get("semantic_count", 0)
        self.working_count: int = data.get("working_count", 0)
        self.reasoning_chain: Optional[List[str]] = data.get("reasoning_chain")
        self.latency_ms: float = data.get("latency_ms", 0.0)
        self._raw = data

    def __iter__(self):
        """Iterate over facts for backward-compat with list-based usage."""
        return iter(self.facts)

    def __len__(self):
        return len(self.facts)

    def format(self, max_facts: int = 5) -> str:
        """Format for LLM system-prompt injection."""
        if not self.facts:
            return ""
        lines = ["[Memory Context]"]
        for f in self.facts[:max_facts]:
            score = f.get("score", 0)
            confidence = "high" if score > 0.6 else "medium"
            source = f.get("source_type", "memory")
            lines.append(f"- {f['fact']}  ({confidence} confidence, via {source})")
        return "\n".join(lines)

    def __repr__(self):
        return (f"SearchResult(facts={len(self.facts)}, "
                f"latency={self.latency_ms:.0f}ms)")


# ============================================================
# SYNC CLIENT
# ============================================================

class CognitiveBrain:
    """
    Sync Python client for the Atlas CAB-QA Cognitive Brain service.

    Vendor-agnostic: works with OpenAI, Anthropic, Gemini, LangChain,
    CrewAI, LlamaIndex, AutoGen, or any plain Python agent.

    Parameters
    ----------
    api_key    : Atlas API key (starts with 'atlas_')
    base_url   : Base URL of your Atlas deployment
    user_id    : User/org identifier for memory isolation
    session_id : Optional session for working memory context
    persona    : Memory namespace (default 'shared')
    timeout    : HTTP timeout (seconds). Ingest can be slow on first call.
    retries    : Number of retries on transient errors (429/503)
    use_llm    : If False, use spaCy-only extraction (cheaper, faster)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8000",
        user_id: str = "default",
        session_id: Optional[str] = None,
        persona: str = "shared",
        timeout: int = 300,
        retries: int = 3,
        use_llm: bool = True,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.user_id = user_id
        self.session_id = session_id
        self.persona = persona
        self.timeout = timeout
        self.use_llm = use_llm
        self._headers = {"x-api-key": api_key, "Content-Type": "application/json"}
        self._session = _build_session(retries=retries)

    # ── Core Memory API (Mem0-compatible surface) ─────────

    def add(
        self,
        text: str,
        source: str = "user",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> IngestResult:
        """
        Ingest text into the cognitive memory system.
        Equivalent to Mem0's `m.add(messages, user_id=...)`.

        Automatically:
        - Chunks text via SemanticChunker
        - Extracts knowledge graph triples
        - Stores in episodic (Qdrant) + semantic (Neo4j) + working (Redis)
        - Deduplicates against existing memories
        """
        payload = {
            "text": text,
            "user_id": self.user_id,
            "persona": self.persona,
            "source": source,
        }
        if self.session_id:
            payload["session_id"] = self.session_id
        if metadata:
            payload["metadata"] = metadata
        return IngestResult(self._post("/brain/ingest", payload))

    # Mem0-compatible alias
    def ingest(self, text: str, **kwargs) -> IngestResult:
        """Alias for add(). Mem0-compatible."""
        return self.add(text, **kwargs)

    def search(
        self,
        query: str,
        k: int = 5,
        include_episodic: bool = True,
        include_semantic: bool = True,
        include_working: bool = True,
        max_hops: Optional[int] = None,
    ) -> SearchResult:
        """
        Query-adaptive retrieval across all memory layers.
        Returns a SearchResult with .context (formatted string) and .facts (list).

        Equivalent to Mem0's `m.search(query, user_id=...)`.
        """
        payload = {
            "query": query,
            "user_id": self.user_id,
            "k": k,
            "include_episodic": include_episodic,
            "include_semantic": include_semantic,
            "include_working": include_working,
        }
        if self.session_id:
            payload["session_id"] = self.session_id
        if self.persona:
            payload["persona"] = self.persona
        if max_hops is not None:
            payload["max_hops"] = max_hops
        return SearchResult(self._post("/brain/retrieve", payload))

    # Mem0-compatible alias
    def get_relevant(self, query: str, **kwargs) -> SearchResult:
        """Alias for search(). Mem0-compatible."""
        return self.search(query, **kwargs)

    def ask(self, question: str, max_hops: int = 3) -> str:
        """
        Natural-language graph QA: Graph → Cypher → grounded answer.
        Uses multi-hop reasoning for complex relational questions.
        This is a differentiator feature not available in Mem0.
        """
        payload = {
            "query": question,
            "user_id": self.user_id,
            "max_hops": max_hops,
        }
        result = self._post("/brain/retrieve/graph-qa", payload)
        return result.get("answer", "")

    def consolidate(self, force: bool = False) -> dict:
        """
        Trigger memory consolidation (decay + prune + LLM compression).
        Call periodically to keep memory healthy and compact.
        """
        payload = {"user_id": self.user_id, "persona": self.persona, "force": force}
        return self._post("/brain/consolidate", payload)

    def prune(self, threshold: Optional[float] = None, dry_run: bool = True) -> dict:
        """
        Preview or execute memory pruning below confidence threshold.
        Set dry_run=False to actually delete.
        """
        payload = {"user_id": self.user_id, "dry_run": dry_run}
        if threshold is not None:
            payload["threshold"] = threshold
        return self._post("/brain/prune", payload)

    def stats(self) -> dict:
        """Return memory statistics: entity count, relation count, episodic chunks."""
        return self._post("/brain/stats", {"user_id": self.user_id, "persona": self.persona})

    def health(self) -> dict:
        """Check service health (Neo4j, Redis, Qdrant, models)."""
        r = self._session.get(
            f"{self.base_url}/brain/health",
            headers=self._headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def format_context(self, result: SearchResult, max_facts: int = 5) -> str:
        """Format SearchResult for LLM system-prompt injection."""
        return result.format(max_facts=max_facts)

    # ── OpenAI Function Calling ───────────────────────────

    def get_openai_tools(self) -> list[dict]:
        """
        Return tool definitions for OpenAI function calling API.
        Includes save, search, and graph QA tools.
        """
        return [
            {
                "type": "function",
                "function": {
                    "name": "atlas_save_memory",
                    "description": (
                        "Save important facts, decisions, or context to long-term cognitive memory. "
                        "Call this when the user shares something that should be remembered across "
                        "conversations — preferences, project state, decisions, team assignments."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "text": {
                                "type": "string",
                                "description": "The information to save. Can be a full sentence or paragraph.",
                            }
                        },
                        "required": ["text"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "atlas_search_memory",
                    "description": (
                        "Search long-term cognitive memory for context relevant to the current question. "
                        "Call this BEFORE answering questions about past decisions, project state, "
                        "team structure, or anything the user may have mentioned previously."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "Natural language query for what to retrieve.",
                            },
                            "k": {
                                "type": "integer",
                                "description": "Number of facts to retrieve (default 5).",
                                "default": 5,
                            },
                        },
                        "required": ["query"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "atlas_graph_qa",
                    "description": (
                        "Answer complex relational questions using multi-hop graph reasoning. "
                        "Use this for questions like 'Who owns X?' or 'What depends on Y?' "
                        "that require traversing relationships in the knowledge graph."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "question": {
                                "type": "string",
                                "description": "The relational question to answer.",
                            }
                        },
                        "required": ["question"],
                    },
                },
            },
        ]

    def handle_tool_call(self, tool_name: str, tool_args: dict) -> str:
        """Execute an OpenAI tool call and return a string result."""
        if tool_name == "atlas_save_memory":
            result = self.add(tool_args["text"])
            return f"Saved {result.facts_ingested} fact(s), {result.episodic_chunks} chunk(s) to memory."

        if tool_name == "atlas_search_memory":
            result = self.search(tool_args["query"], k=tool_args.get("k", 5))
            return result.format() if result.facts else "No relevant memories found."

        if tool_name == "atlas_graph_qa":
            answer = self.ask(tool_args["question"])
            return answer if answer else "Could not find a graph-based answer."

        return f"Unknown tool: {tool_name}"

    # ── LangChain Tools ───────────────────────────────────

    def get_langchain_tools(self) -> list:
        """
        Return LangChain Tool objects for use in LangChain/LangGraph agents.
        Requires: pip install langchain-core
        """
        try:
            from langchain_core.tools import Tool
        except ImportError:
            raise ImportError("Install with: pip install langchain-core")

        return [
            Tool(
                name="atlas_save_memory",
                func=lambda text: self.add(text).msg,
                description=(
                    "Save important facts or decisions to long-term cognitive memory. "
                    "Input: a sentence or paragraph describing what to remember."
                ),
            ),
            Tool(
                name="atlas_search_memory",
                func=lambda query: self.search(query).format(),
                description=(
                    "Search long-term cognitive memory. "
                    "Input: natural language query about past context."
                ),
            ),
            Tool(
                name="atlas_graph_qa",
                func=lambda q: self.ask(q),
                description=(
                    "Answer complex relational questions via multi-hop graph reasoning. "
                    "Input: a question about relationships between entities."
                ),
            ),
        ]

    # ── CrewAI Tools ──────────────────────────────────────

    def get_crewai_tools(self) -> list:
        """
        Return CrewAI-compatible BaseTool objects.
        Requires: pip install crewai
        """
        try:
            from crewai.tools import BaseTool
        except ImportError:
            raise ImportError("Install with: pip install crewai")

        brain = self

        class SaveMemoryTool(BaseTool):
            name: str = "atlas_save_memory"
            description: str = (
                "Save important facts, decisions, or context to long-term cognitive memory."
            )
            def _run(self, text: str) -> str:
                result = brain.add(text)
                return f"Saved {result.facts_ingested} fact(s) to memory."

        class SearchMemoryTool(BaseTool):
            name: str = "atlas_search_memory"
            description: str = (
                "Search long-term cognitive memory for relevant context."
                " Input: natural language query."
            )
            def _run(self, query: str) -> str:
                return brain.search(query).format()

        class GraphQATool(BaseTool):
            name: str = "atlas_graph_qa"
            description: str = (
                "Answer complex relational questions using knowledge graph reasoning."
            )
            def _run(self, question: str) -> str:
                return brain.ask(question)

        return [SaveMemoryTool(), SearchMemoryTool(), GraphQATool()]

    # ── LlamaIndex Tools ──────────────────────────────────

    def get_llamaindex_tools(self) -> list:
        """
        Return LlamaIndex FunctionTool objects.
        Requires: pip install llama-index-core
        """
        try:
            from llama_index.core.tools import FunctionTool
        except ImportError:
            raise ImportError("Install with: pip install llama-index-core")

        return [
            FunctionTool.from_defaults(
                fn=lambda text: self.add(text).msg,
                name="atlas_save_memory",
                description="Save facts or context to long-term cognitive memory.",
            ),
            FunctionTool.from_defaults(
                fn=lambda query: self.search(query).format(),
                name="atlas_search_memory",
                description="Search long-term cognitive memory for relevant context.",
            ),
            FunctionTool.from_defaults(
                fn=lambda question: self.ask(question),
                name="atlas_graph_qa",
                description="Answer relational questions using knowledge graph reasoning.",
            ),
        ]

    # ── Internal ──────────────────────────────────────────

    def _post(self, path: str, payload: dict) -> dict:
        try:
            r = self._session.post(
                f"{self.base_url}{path}",
                headers=self._headers,
                json=payload,
                timeout=self.timeout,
            )
            if r.status_code == 401:
                raise PermissionError(f"Auth failed: {r.json().get('detail', r.text)}")
            if r.status_code == 429:
                raise RuntimeError(f"Rate limit exceeded: {r.json().get('detail', r.text)}")
            r.raise_for_status()
            return r.json()
        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(
                f"Cannot connect to Atlas at {self.base_url}. "
                "Is the service running? Check docker compose status."
            ) from e

    def __repr__(self):
        return (f"CognitiveBrain(base_url={self.base_url!r}, "
                f"user_id={self.user_id!r}, session_id={self.session_id!r})")


# ============================================================
# ASYNC CLIENT
# ============================================================

class AsyncCognitiveBrain:
    """
    Async version of CognitiveBrain using httpx.
    For use in async agent frameworks, async FastAPI apps, LangGraph, etc.

    Requires: pip install httpx

    Usage:
        brain = AsyncCognitiveBrain(api_key="atlas_...", user_id="user-123")
        async with brain:
            result = await brain.add("Apollo uses PostgreSQL.")
            search = await brain.search("What database?")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8000",
        user_id: str = "default",
        session_id: Optional[str] = None,
        persona: str = "shared",
        timeout: int = 300,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.user_id = user_id
        self.session_id = session_id
        self.persona = persona
        self.timeout = timeout
        self._headers = {"x-api-key": api_key, "Content-Type": "application/json"}
        self._client = None

    async def __aenter__(self):
        import httpx
        self._client = httpx.AsyncClient(
            headers=self._headers,
            timeout=self.timeout,
        )
        return self

    async def __aexit__(self, *_):
        if self._client:
            await self._client.aclose()

    def _get_client(self):
        if self._client is None:
            try:
                import httpx
                self._client = httpx.AsyncClient(
                    headers=self._headers,
                    timeout=self.timeout,
                )
            except ImportError:
                raise ImportError("Install with: pip install httpx")
        return self._client

    async def _post(self, path: str, payload: dict) -> dict:
        import httpx
        client = self._get_client()
        for attempt in range(3):
            try:
                r = await client.post(f"{self.base_url}{path}", json=payload)
                if r.status_code in (429, 503) and attempt < 2:
                    await __import__("asyncio").sleep(2 ** attempt)
                    continue
                if r.status_code == 401:
                    raise PermissionError(f"Auth failed: {r.json().get('detail', r.text)}")
                r.raise_for_status()
                return r.json()
            except httpx.ConnectError as e:
                if attempt == 2:
                    raise ConnectionError(
                        f"Cannot connect to Atlas at {self.base_url}."
                    ) from e
                await __import__("asyncio").sleep(2 ** attempt)
        return {}

    def _base_payload(self) -> dict:
        p = {"user_id": self.user_id, "persona": self.persona}
        if self.session_id:
            p["session_id"] = self.session_id
        return p

    async def add(self, text: str, source: str = "user", metadata: dict | None = None) -> IngestResult:
        """Async ingest text into cognitive memory."""
        payload = {**self._base_payload(), "text": text, "source": source}
        if metadata:
            payload["metadata"] = metadata
        return IngestResult(await self._post("/brain/ingest", payload))

    # Mem0-compatible alias
    async def ingest(self, text: str, **kwargs) -> IngestResult:
        return await self.add(text, **kwargs)

    async def search(self, query: str, k: int = 5, max_hops: int | None = None) -> SearchResult:
        """Async query-adaptive retrieval."""
        payload = {**self._base_payload(), "query": query, "k": k}
        if max_hops is not None:
            payload["max_hops"] = max_hops
        return SearchResult(await self._post("/brain/retrieve", payload))

    async def ask(self, question: str, max_hops: int = 3) -> str:
        """Async graph QA."""
        payload = {**self._base_payload(), "query": question, "max_hops": max_hops}
        result = await self._post("/brain/retrieve/graph-qa", payload)
        return result.get("answer", "")

    async def consolidate(self, force: bool = False) -> dict:
        return await self._post("/brain/consolidate", {**self._base_payload(), "force": force})

    async def stats(self) -> dict:
        return await self._post("/brain/stats", self._base_payload())

    # ── LangChain async tools ─────────────────────────────

    def get_langchain_tools(self) -> list:
        """Return async-compatible LangChain tools."""
        try:
            from langchain_core.tools import StructuredTool
            from pydantic import BaseModel, Field as PField
        except ImportError:
            raise ImportError("Install with: pip install langchain-core pydantic")

        brain = self

        class SaveInput(BaseModel):
            text: str = PField(description="Information to save to memory")

        class SearchInput(BaseModel):
            query: str = PField(description="Query to search memory")
            k: int = PField(default=5, description="Number of results")

        class AskInput(BaseModel):
            question: str = PField(description="Relational question for graph QA")

        async def _save(text: str) -> str:
            r = await brain.add(text)
            return r.msg

        async def _search(query: str, k: int = 5) -> str:
            r = await brain.search(query, k=k)
            return r.format()

        async def _ask(question: str) -> str:
            return await brain.ask(question)

        return [
            StructuredTool.from_function(
                coroutine=_save, name="atlas_save_memory",
                description="Save facts to long-term cognitive memory.",
                args_schema=SaveInput,
            ),
            StructuredTool.from_function(
                coroutine=_search, name="atlas_search_memory",
                description="Search long-term cognitive memory for relevant context.",
                args_schema=SearchInput,
            ),
            StructuredTool.from_function(
                coroutine=_ask, name="atlas_graph_qa",
                description="Answer relational questions via knowledge graph reasoning.",
                args_schema=AskInput,
            ),
        ]

    def __repr__(self):
        return (f"AsyncCognitiveBrain(base_url={self.base_url!r}, "
                f"user_id={self.user_id!r})")
