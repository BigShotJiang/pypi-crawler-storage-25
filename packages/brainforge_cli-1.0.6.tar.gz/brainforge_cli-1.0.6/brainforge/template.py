import os

import click

JOB_TEMPLATE = """# Job Template for BrainForge CLI
slurm:
  job-name: "name"
  partition: "partition"
  account: "account"
  nodes: 1
  ntasks: 1
  mem: "8G"
  cpus-per-task: 4
  output: "logs/job_%A_%a.out"
  error: "logs/job_%A_%a.err"

execution:
  modules:
    - singularity
  env:
    SINGULARITY_IMAGE: "/path/to/container.sif"
    HOST_INPUT_DIR: "/path/to/input"
    HOST_OUTPUT_DIR: "/path/to/output"
  participants:
    - "sub-01"
    - "sub-02"
    - "sub-03"
  command: "singularity run --bind $HOST_INPUT_DIR:/input --bind $HOST_OUTPUT_DIR:/output $SINGULARITY_IMAGE --participant $PARTICIPANT"
"""


def generate_yaml_template(output_name):
    # Ensure we don't accidentally overwrite without warning, though
    # for simplicity we'll just open and write.
    # If file exists, click.confirm could be used, but let's keep it simple first.
    if os.path.exists(output_name):
        click.confirm(f"File '{output_name}' already exists. Overwrite?", abort=True)

    with open(output_name, 'w') as f:
        f.write(JOB_TEMPLATE)

    click.secho(
        f"Successfully generated template: {output_name}", fg="green"
    )
