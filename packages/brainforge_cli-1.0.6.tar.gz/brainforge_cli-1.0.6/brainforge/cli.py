import sys

import brainforge.auth as auth
import click
from brainforge.ingest import ingest_derivatives as _ingest_derivatives
from brainforge.ingest import ingest_raw_data as _ingest_raw_data
from brainforge.job_logs import fetch_logs
from brainforge.job_status import check_status
from brainforge.run import generate_sbatch_script
from brainforge.run import parse_spec
from brainforge.run import submit_job
from brainforge.run import validate_spec
from brainforge import __version__
from brainforge.template import generate_yaml_template


@click.group()
@click.version_option(version=__version__)
def main():
    """
    BrainForge CLI: The premier interface for executing neuroimaging analyses.

    Provides tools for generating SLURM job configurations, securely
    submitting arrays to the cluster, and tracking runtime statuses.
    """
    pass


@main.command()
def info():
    """Display information about Brainforge CLI and its current version."""
    click.echo(f"Welcome to the Brainforge CLI v{__version__}")
    click.echo("Run 'brainforge --help' to see all available commands.")


@main.command()
def login():
    """Authenticate with Globus."""
    auth.login()


@main.command()
def logout():
    """Logout of Globus."""
    auth.logout()





@main.command(name='run')
@click.argument('spec_file', type=click.Path(exists=True, dir_okay=False), required=False)
@click.option(
    '--yaml',
    'yaml_str',
    help="Parse the YAML spec directly from a string instead of a file.",
)
@click.option(
    '--dry-run',
    is_flag=True,
    help="Generate and print the sbatch script without submitting to SLURM.",
)
def run_job(spec_file, yaml_str, dry_run):
    """
    Submit a SLURM job using a YAML specification file or string.

    Takes a SPEC_FILE containing `slurm` and `execution` blocks.
    Will automatically detect if this is a single job or a multiple job
    (array job) based on the presence of `participant` or `participants`.
    """
    import yaml
    if yaml_str:
        try:
            spec = yaml.safe_load(yaml_str)
        except Exception as e:
            click.secho(f"Error parsing YAML string: {e}", fg="red")
            sys.exit(1)
    elif spec_file:
        spec = parse_spec(spec_file)
    else:
        click.secho("Error: You must provide either a SPEC_FILE argument or a --yaml configuration.", fg="red")
        sys.exit(1)

    # Validate the spec
    validate_spec(spec)

    # Generate script
    script_content = generate_sbatch_script(spec)

    # Submit job (or print if dry_run)
    submit_job(script_content, spec, dry_run=dry_run)


@main.command()
@click.argument('job_id')
@click.option('--json', 'as_json', is_flag=True, help="Output status securely in JSON format")
@click.option('--detailed', '-d', is_flag=True, help="Show detailed job information (scontrol & sacct).")
def status(job_id, as_json, detailed):
    """
    Check the queue and runtime status of a scheduled SLURM job.

    Uses `sacct` (for comprehensive history) and falls back to `squeue`
    for nascent jobs. Can lookup both active and completed jobs.
    """
    check_status(job_id, as_json=as_json, detailed=detailed)


@main.command()
@click.argument('job_id')
@click.option(
    '--error',
    '-e',
    is_flag=True,
    help="View error logs instead of output logs.",
)
@click.option(
    '--output',
    '-o',
    is_flag=True,
    help="View output logs (default).",
)
@click.option(
    '--follow',
    '-f',
    is_flag=True,
    help="Follow the log contents live.",
)
def logs(job_id, error, output, follow):
    """
    Tail or view the live standard logs of a SLURM job.

    Dynamically finds the output file SLURM is writing to using `scontrol`.
    By default it cats the standard output to the console. Use `-e` for standard error,
    and `-f` to follow the stream live (like tail -f).
    """
    log_type = 'error' if error else 'output'
    fetch_logs(job_id, log_type, follow=follow)


@main.command(name="generate")
@click.option(
    '--name',
    '-n',
    prompt='Enter output filename',
    default='template.yaml',
    help="Output filename for the generated template.",
)
def generate_cmd(name):
    """
    Generate a working YAML template for a BrainForge SLURM job.

    Creates a boilerplate .yaml file pre-filled with all required
    variables (`SINGULARITY_IMAGE`, `HOST_INPUT_DIR`, etc.) to run
    an array job over one or more `participants`.
    """
    generate_yaml_template(name)


@main.group()
def ingest():
    """
    Ingest data into the BrainForge database via the backend API.

    Use this group to load raw BIDS datasets or pipeline derivative
    outputs into the BrainForge platform.
    """
    pass


@ingest.command(name="raw")
@click.argument("bids_root", type=click.Path())
@click.option(
    "--dataset-label",
    "-d",
    default=None,
    help="Override the dataset label (defaults to BIDS root folder name).",
)
@click.option(
    "--workers",
    "-w",
    type=int,
    default=None,
    help="Number of parallel worker processes on the server (server default used if omitted).",
)
@click.option(
    "--storage-type",
    type=click.Choice(["qumulo", "filesystem"]),
    default=None,
    help="Explicitly set the storage type. Auto-detected by the server if omitted.",
)
@click.option(
    "--log",
    "log",
    is_flag=True,
    default=False,
    help="Wait for the task to start and print the log output to the console.",
)
@click.option(
    "--follow",
    "-f",
    is_flag=True,
    default=False,
    help="Stream the log output live as the task runs (implies --log).",
)
@click.option(
    "--subject",
    "-s",
    "subjects",
    multiple=True,
    metavar="SUBJECT_LABEL",
    help=(
        "Restrict ingestion to this subject (repeatable). "
        "E.g. -s 01 -s 02"
    ),
)
@click.option(
    "--session",
    "-e",
    "sessions",
    multiple=True,
    metavar="SESSION_LABEL",
    help=(
        "Restrict ingestion to this session (repeatable). "
        "E.g. -e baseline -e followup"
    ),
)
@click.option(
    "--base-url",
    default="http://localhost:8000/api",
    envvar="BRAINFORGE_API_URL",
    show_default=True,
    help="BrainForge backend API base URL.",
)
def ingest_raw(bids_root, dataset_label, workers, storage_type, log, follow, subjects, sessions, base_url):
    """
    Ingest a raw BIDS dataset into the BrainForge database.

    BIDS_ROOT is the absolute path to the root of the BIDS dataset on the
    server's filesystem. The server will index the dataset using pybids
    and populate the Subject, Session, and RawImage tables in parallel.

    Use --subject / --session to restrict ingestion to specific subjects
    or sessions (can be repeated):

        brainforge ingest raw /data/datasets/my_study -s 01 -s 02 -e baseline

    Use --follow to stream the ingestion log live:

        brainforge ingest raw /data/datasets/my_study --follow
    """
    _ingest_raw_data(
        bids_root=bids_root,
        dataset_label=dataset_label,
        workers=workers,
        storage_type=storage_type,
        base_url=base_url,
        log=log,
        follow=follow,
        subjects=list(subjects) if subjects else None,
        sessions=list(sessions) if sessions else None,
    )


@ingest.command(name="derivatives")
@click.option(
    "--derivatives-dir",
    "-p",
    required=True,
    help="Absolute path to the specific pipeline output directory.",
)
@click.option(
    "--dataset-label",
    "-d",
    required=True,
    help="BIDS dataset label to associate the derivatives with.",
)
@click.option(
    "--container-name",
    "-c",
    required=True,
    help="Container/pipeline name (e.g., 'anatprep').",
)
@click.option(
    "--container-version",
    "-V",
    required=True,
    help="Container version string (e.g., '2.0.0').",
)
@click.option(
    "--analysis-instance",
    "-i",
    type=int,
    default=1,
    show_default=True,
    help="Run instance number (used to distinguish multiple runs of the same container).",
)
@click.option(
    "--processing",
    is_flag=True,
    default=False,
    help="Ingest into ProcessingAnalysis table instead of PreProcessingAnalysis.",
)
@click.option(
    "--log",
    "log",
    is_flag=True,
    default=False,
    help="Wait for the task to start and print the log output to the console.",
)
@click.option(
    "--follow",
    "-f",
    is_flag=True,
    default=False,
    help="Stream the log output live as the task runs (implies --log).",
)
@click.option(
    "--base-url",
    default="http://localhost:8000/api",
    envvar="BRAINFORGE_API_URL",
    show_default=True,
    help="BrainForge backend API base URL.",
)
def ingest_derivs(
    derivatives_dir,
    dataset_label,
    container_name,
    container_version,
    analysis_instance,
    processing,
    log,
    follow,
    base_url,
):
    """
    Ingest BIDS derivative outputs into the BrainForge database.

    Links pipeline output files and SLURM job metadata with the
    corresponding Subject and Session records. Supports both
    PreProcessingAnalysis (default) and ProcessingAnalysis (--processing).

    Use --follow to stream the ingestion log live:

        brainforge ingest derivatives \\
            --derivatives-dir /data/datasets/my_study/derivatives/anatprep-2.0.0-1 \\
            --dataset-label my_study \\
            --container-name anatprep \\
            --container-version 2.0.0 \\
            --follow
    """
    _ingest_derivatives(
        derivatives_dir=derivatives_dir,
        dataset_label=dataset_label,
        container_name=container_name,
        container_version=container_version,
        analysis_instance=analysis_instance,
        processing=processing,
        base_url=base_url,
        log=log,
        follow=follow,
    )


if __name__ == "__main__":
    main()
