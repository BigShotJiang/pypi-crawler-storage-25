import sqlite3
import json
import pickle
import faiss
import numpy as np
import os

from ..utils.logger import logger

class IngestionUtility:
    def __init__(self, storage_config):
        self.cfg = storage_config
        self.db_path = self.cfg['db_path']
        self.index_path = self.cfg['index_path']
        self.dim = self.cfg['vector_dimension']

        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self.conn = sqlite3.connect(self.db_path)
        self._prepare_db()

        # FAISS Index Initialization
        self.vector_buffer = []
        self.id_buffer = []

        self._is_closed = False

        if os.path.exists(self.index_path):
            self.index = faiss.read_index(self.index_path)
            with open(self.index_path + ".ids", "rb") as f:
                self.doc_ids = pickle.load(f)
        else:
            self.index = faiss.IndexFlatIP(self.dim)
            self.doc_ids = []

    def _prepare_db(self):
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS corpus (
                id TEXT PRIMARY KEY,
                raw_text_json TEXT,
                collections_json TEXT,
                embeddings_blob BLOB
            )
        """)
        self.conn.commit()

    def ingest_buffered(self, doc_id, text_fields, collections, full_embs):
        """
        Buffers vectors in memory and writes SQL rows to the open transaction.
        """
        if self._is_closed:
            raise RuntimeError("Cannot ingest records into a closed IngestionUtility interface.")

        primary_field = list(text_fields.keys())[0]
        indexing_vector = full_embs[primary_field]
        
        vec_np = np.array(indexing_vector).astype('float32')
        faiss.normalize_L2(vec_np.reshape(1, -1))
        
        self.vector_buffer.append(vec_np)
        self.id_buffer.append(doc_id)

        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO corpus VALUES (?, ?, ?, ?)",
            (doc_id, json.dumps(text_fields), json.dumps(collections), pickle.dumps(full_embs))
        )

    def flush_buffers(self):
        """
        Adds all accumulated vectors to FAISS at once.
        """
        if not self.vector_buffer:
            return

        logger.info(f"Flushing {len(self.vector_buffer)} vectors directly to FAISS Index...")
        
        matrix = np.vstack(self.vector_buffer)
        
        self.index.add(matrix)
        self.doc_ids.extend(self.id_buffer)
        
        self.vector_buffer.clear()
        self.id_buffer.clear()

    def search_vectors(self, query_emb, limit=100):
        """FAISS Search to get candidates for the Orchestrator."""
        if self._is_closed:
            raise RuntimeError("Cannot search vectors using a closed IngestionUtility instance.")

        vector = np.array(query_emb).astype('float32').reshape(1, -1)
        faiss.normalize_L2(vector)
        
        actual_limit = min(limit, len(self.doc_ids))
        if actual_limit == 0:
            return []
            
        distances, indices = self.index.search(vector, actual_limit)
        
        candidates = []
        cursor = self.conn.cursor()
        for dist, idx in zip(distances[0], indices[0]):
            if idx == -1: continue 
            doc_id = self.doc_ids[idx]
            
            cursor.execute("SELECT raw_text_json, collections_json, embeddings_blob FROM corpus WHERE id=?", (doc_id,))
            row = cursor.fetchone()
            if row:
                candidates.append({
                    "id": doc_id,
                    "score": float(dist),
                    "text_fields": json.loads(row[0]),
                    "collections": json.loads(row[1]),
                    "embeddings": pickle.loads(row[2]) 
                })
        return candidates
    
    def save_index(self):
        self.flush_buffers()
        faiss.write_index(self.index, self.index_path)
        with open(self.index_path + ".ids", "wb") as f:
            pickle.dump(self.doc_ids, f)

    def fetch_metadata(self, doc_id):
        """
        Retrieves fully hydrated metadata structures directly from the SQLite 
        corpus table using a unique document identifier key.
        """
        if self._is_closed:
            self.conn = sqlite3.connect(self.db_path)
            self._is_closed = False

        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT raw_text_json, collections_json FROM corpus WHERE id = ?", (doc_id,))
            row = cursor.fetchone()
            
            if not row:
                logger.warning(f"Metadata lookup miss: Document ID '{doc_id}' not found in active SQLite corpus table.")
                return {"text_fields": {}, "collections": {}}
                
            return {
                "text_fields": json.loads(row[0]) if row[0] else {},
                "collections": json.loads(row[1]) if row[1] else {}
            }
        except Exception as e:
            logger.error(f"Metadata retrieval operation failure for ID '{doc_id}': {str(e)}")
            return {"text_fields": {}, "collections": {}}

    def close(self):
        """Final flush and connection closure."""
        if self._is_closed:
            return
            
        try:
            self.save_index()
            
            if self.conn:
                self.conn.commit()
                self.conn.close()
            
            self._is_closed = True
            logger.info("Database transactions and FAISS structures closed cleanly.")
        except Exception as e:
            logger.error(f"Error during ingestor pipeline shutdown: {e}")

    def __del__(self):
        try:
            if not self._is_closed:
                self.close()
        except:
            pass