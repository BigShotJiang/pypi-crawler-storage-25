import numpy as np
import faiss
from sentence_transformers import CrossEncoder
from ..utils.logger import logger

class DocumentMatcher:
    def __init__(self, semantic_enc, syntactic_enc, structured_enc, config):
        logger.info("Loading Stage 1 Encoders...")
        self.sem = semantic_enc
        self.syn = syntactic_enc
        self.str = structured_enc
        
        self.weights = config['orchestrator']['weights']
        if 'schema' in config:
            self.schema = config['schema']
        else:
            self.schema = config

        logger.info("Loading Stage 2 Cross-Encoder Reranker...")
        self.reranker = CrossEncoder("BAAI/bge-reranker-v2-m3", max_length=256) # hard-coded for now

        logger.info("DocumentMatcher initialization complete.")

    def match_1_to_1(self, doc_a, doc_b):
        """
        Detailed comparison between two specific documents.
        Returns a dictionary with broken-down scores.
        """
        # ssemantic score
        emb_a = self.sem.encode_document(doc_a['text_fields'])
        emb_b = self.sem.encode_document(doc_b['text_fields'])

        text_field_weights = {f['name']: f['semantic_weight'] for f in self.schema['text_fields']}
        sem_score = self.sem.calculate_similarity(emb_a, emb_b, text_field_weights)

        # syntactic score
        syn_score = self.syn.calculate_similarity_1to1(doc_a['text_fields'], doc_b['text_fields'])

        # structured score
        str_score = self.str.calculate_similarity(
            self.str.encode(doc_a['collections']),
            self.str.encode(doc_b['collections'])
        )

        # fusion
        total_score = (
            (sem_score * self.weights['semantic']) +
            (syn_score * self.weights['syntactic']) +
            (str_score * self.weights['structured'])
        )

        return {
            "total_score": round(float(total_score), 4),
            "breakdown": {
                "semantic": round(float(sem_score), 4),
                "syntactic": round(float(syn_score), 4),
                "structured": round(float(str_score), 4)
            }
        }

    def search(self, query_doc, candidates, top_k=10):
        """
        Executes multi-channel re-ranking over pre-filtered candidate buckets using deep Cross-Encoder attention calculations.
        """
        if not candidates:
            return []
        
        primary_field = self.schema['text_fields'][0]['name']
        query_text = query_doc['text_fields'][primary_field]
        
        rerank_pairs = []
        for cand in candidates:
            cand_text = cand['text_fields'].get(primary_field, "")
            rerank_pairs.append([query_text, cand_text])
            
        logger.debug(f"Executing Cross-Encoder reranking for {len(candidates)} candidate pairs.")
        cross_scores = self.reranker.predict(rerank_pairs)

        logger.debug("Generating batch statistical BM25 metrics over candidates...")
        batch_syntactic_scores = self.syn.calculate_batch_bm25_scores(query_doc, candidates)

        scored_results = []
        for idx, cand in enumerate(candidates):
            ce_score = float(cross_scores[idx])
            syn_score = float(batch_syntactic_scores[idx]) # Pull pre-calculated statistical weight
            
            str_score = self.str.calculate_similarity(
                self.str.encode(query_doc['collections']),
                self.str.encode(cand['collections'])
            )
            
            scored_results.append({
                "id": cand['id'],
                "raw_sem": ce_score, 
                "raw_syn": syn_score,
                "raw_str": str_score
            })

        logger.debug("Fusing results...")
        return self._fuse_results(scored_results, top_k)
    
    def _fuse_results(self, results, top_k):
        """Applies contextual pool min-max adjustments and returns sorted targets."""
        syn_vals = [r['raw_syn'] for r in results]
        min_s, max_s = min(syn_vals), max(syn_vals)
        syn_range = (max_s - min_s) if max_s > min_s else 1.0

        final_list = []
        for r in results:
            #norm_syn = (r['raw_syn'] - min_s) / syn_range
            
            total = (
                (r['raw_sem'] * self.weights['semantic']) +
                (r['raw_syn'] * self.weights['syntactic']) +
                (r['raw_str'] * self.weights['structured'])
            )
            
            final_list.append({
                "id": r['id'],
                "total_score": round(float(total), 4),
                "breakdown": {
                    "semantic": round(float(r['raw_sem']), 4),
                    "syntactic": round(float(r['raw_syn']), 4),
                    "structured": round(float(r['raw_str']), 4)
                }
            })

        # Sort descending and filter by requested top_k boundary
        sorted_results = sorted(final_list, key=lambda x: x['total_score'], reverse=True)
        return sorted_results[:top_k]
    
    def _get_candidates(self, query_embeddings, limit=1000):
        """
        Uses FAISS to find the top neighborhood of documents.
        """
        query_vec = np.array(list(query_embeddings.values())[0]).astype('float32').reshape(1, -1)
        faiss.normalize_L2(query_vec)

        scores, indices = self.index.search(query_vec, limit)

        candidates = []
        for score, idx in zip(scores[0], indices[0]):
            doc_id = self.doc_ids[idx]
            meta = self.db.fetch_metadata(doc_id) 
            candidates.append({
                "id": doc_id,
                "score": float(score),
                "text_fields": meta['text_fields'],
                "collections": meta['collections']
            })
        return candidates