import asyncio
import contextlib
import sys
from typing import Generator, List, Optional, Tuple

import click

import ghstack
import ghstack.action
import ghstack.checkout
import ghstack.cherry_pick
import ghstack.circleci_real
import ghstack.config
import ghstack.github_real
import ghstack.land
import ghstack.log
import ghstack.logs
import ghstack.rage
import ghstack.status
import ghstack.submit
import ghstack.unlink

EXIT_STACK = contextlib.ExitStack()

GhstackContext = Tuple[
    ghstack.shell.Shell,
    ghstack.config.Config,
    ghstack.github_real.RealGitHubEndpoint,
]


@contextlib.contextmanager
def cli_context(
    *,
    request_circle_token: bool = False,
    request_github_token: bool = True,
) -> Generator[GhstackContext, None, None]:
    with EXIT_STACK:
        shell = ghstack.shell.Shell()
        config = ghstack.config.read_config(
            request_circle_token=request_circle_token,
            request_github_token=request_github_token,
        )
        github = ghstack.github_real.RealGitHubEndpoint(
            oauth_token=config.github_oauth,
            proxy=config.proxy,
            github_url=config.github_url,
        )
        yield shell, config, github


@click.group(
    invoke_without_command=True,
    epilog="Running ghstack with no subcommand is equivalent to ghstack submit.",
)
@click.pass_context
@click.version_option(ghstack.__version__, "--version", "-V")
@click.option("--debug", is_flag=True, help="Log debug information to stderr")
# These options are forwarded to the submit command when no subcommand is given.
@click.option(
    "--message",
    "-m",
    default="Update",
    help="Description of change you made",
)
@click.option(
    "--update-fields",
    "-u",
    is_flag=True,
    help="Update GitHub pull request summary from the local commit",
)
@click.option(
    "--short", is_flag=True, help="Print only the URL of the latest opened PR to stdout"
)
@click.option(
    "--force",
    is_flag=True,
    help="force push the branch even if your local branch is stale",
)
@click.option(
    "--no-skip",
    is_flag=True,
    help="Never skip pushing commits, even if the contents didn't change",
)
@click.option(
    "--draft",
    is_flag=True,
    help="Create the pull request in draft mode (only if it has not already been created)",
)
@click.option(
    "--direct/--no-direct",
    "direct_opt",
    is_flag=True,
    default=None,
    help="Create stack that directly merges into master",
)
@click.option(
    "--base",
    "-B",
    default=None,
    help="Branch to base the stack off of",
)
@click.option(
    "--stack/--no-stack",
    "-s/-S",
    is_flag=True,
    default=True,
    help="Submit the entire stack of commits reachable from HEAD",
)
@click.option(
    "--reviewer",
    default=None,
    help="Comma-separated list of GitHub usernames to add as reviewers",
)
@click.option(
    "--label",
    default=None,
    help="Comma-separated list of labels to add to new PRs",
)
def main(
    ctx: click.Context,
    debug: bool,
    message: str,
    update_fields: bool,
    short: bool,
    force: bool,
    direct_opt: Optional[bool],
    no_skip: bool,
    draft: bool,
    base: Optional[str],
    stack: bool,
    reviewer: Optional[str],
    label: Optional[str],
) -> None:
    """
    Submit stacks of diffs to Github
    """
    if sys.version_info >= (3, 14):
        # Create new event loop as asyncio.get_event_loop() throws runtime error in 3.14
        import asyncio as _asyncio

        _asyncio.set_event_loop(_asyncio.new_event_loop())

    EXIT_STACK.enter_context(ghstack.logs.manager(debug=debug))

    if not ctx.invoked_subcommand:
        ctx.invoke(
            submit,
            message=message,
            update_fields=update_fields,
            short=short,
            force=force,
            no_skip=no_skip,
            draft=draft,
            base=base,
            stack=stack,
            direct_opt=direct_opt,
            reviewer=reviewer,
            label=label,
        )


@main.command("auth")
def auth() -> None:
    """
    Set up GitHub authentication if not already configured.
    """
    with EXIT_STACK:
        ghstack.config.read_config()


@main.command("action")
@click.option("--close", is_flag=True, help="Close the specified pull request")
@click.argument("pull_request", metavar="PR")
def action(close: bool, pull_request: str) -> None:
    """
    Perform actions on a PR
    """
    with cli_context() as (shell, _, github):
        ghstack.action.main(
            pull_request=pull_request,
            github=github,
            sh=shell,
            close=close,
        )


@main.command("checkout")
@click.option(
    "--same-base",
    is_flag=True,
    help="Only checkout if merge-base with main branch would remain the same",
)
@click.argument("pull_request", metavar="PR")
def checkout(same_base: bool, pull_request: str) -> None:
    """
    Checkout a PR
    """
    with cli_context(request_github_token=False) as (shell, config, github):
        ghstack.checkout.main(
            pull_request=pull_request,
            github=github,
            sh=shell,
            remote_name=config.remote_name,
            same_base=same_base,
        )


@main.command("cherry-pick")
@click.option(
    "--stack",
    "-s",
    is_flag=True,
    help="Cherry-pick all commits from the commit to the merge-base with main branch",
)
@click.option(
    "--no-fetch",
    is_flag=True,
    help="Skip fetching from the remote before cherry-picking",
)
@click.argument("pull_request", metavar="PR")
def cherry_pick(stack: bool, no_fetch: bool, pull_request: str) -> None:
    """
    Cherry-pick a PR
    """
    with cli_context(request_github_token=False) as (shell, config, github):
        ghstack.cherry_pick.main(
            pull_request=pull_request,
            github=github,
            sh=shell,
            remote_name=config.remote_name,
            stack=stack,
            no_fetch=no_fetch,
        )


@main.command("land")
@click.option("--force", is_flag=True, help="force land even if the PR is closed")
@click.argument("pull_request", metavar="PR")
def land(force: bool, pull_request: str) -> None:
    """
    Land a PR stack
    """
    with cli_context() as (shell, config, github):
        ghstack.land.main(
            pull_request=pull_request,
            github=github,
            sh=shell,
            github_url=config.github_url,
            remote_name=config.remote_name,
            force=force,
        )


@main.command(
    "log",
    context_settings={"ignore_unknown_options": True, "allow_extra_args": True},
)
@click.option(
    "--pr",
    "pull_request",
    default=None,
    help="Explicit PR (URL or number) to log.  If omitted, the PR is inferred "
    "from HEAD's Pull-Request trailer, and local pending changes are shown "
    "on top as a synthesized commit.",
)
@click.argument("git_log_args", nargs=-1, type=click.UNPROCESSED)
def log(pull_request: Optional[str], git_log_args: Tuple[str, ...]) -> None:
    """
    Show git log for a PR, restricted to that PR's commits.
    Extra arguments are forwarded to git log (e.g. -p).
    """
    with cli_context(request_github_token=False) as (shell, config, github):
        ghstack.log.main(
            github=github,
            sh=shell,
            remote_name=config.remote_name,
            github_url=config.github_url,
            args=list(git_log_args),
            pull_request=pull_request,
        )


@main.command("rage")
@click.option(
    "--latest",
    is_flag=True,
    help="Select the last command (not including rage commands) to report",
)
def rage(latest: bool) -> None:
    with cli_context(request_github_token=False):
        ghstack.rage.main(latest)


@main.command("status")
@click.argument("pull_request", metavar="PR")
def status(pull_request: str) -> None:
    """
    Check status of a PR
    """
    with cli_context(request_circle_token=True) as (shell, config, github):
        circleci = ghstack.circleci_real.RealCircleCIEndpoint(
            circle_token=config.circle_token
        )

        fut = ghstack.status.main(
            pull_request=pull_request,
            github=github,
            circleci=circleci,
        )
        loop = asyncio.get_event_loop()
        loop.run_until_complete(fut)
        loop.close()


@main.command("submit")
@click.option(
    "--message",
    "-m",
    default="Update",
    help="Description of change you made",
)
@click.option(
    "--update-fields",
    "-u",
    is_flag=True,
    help="Update GitHub pull request summary from the local commit",
)
@click.option(
    "--short", is_flag=True, help="Print only the URL of the latest opened PR to stdout"
)
@click.option(
    "--force",
    is_flag=True,
    help="force push the branch even if your local branch is stale",
)
@click.option(
    "--no-skip",
    is_flag=True,
    help="Never skip pushing commits, even if the contents didn't change "
    "(use this if you've only updated the commit message).",
)
@click.option(
    "--draft",
    is_flag=True,
    help="Create the pull request in draft mode (only if it has not already been created)",
)
@click.option(
    "--base",
    "-B",
    default=None,
    help="Branch to base the stack off of; "
    "defaults to the default branch of a repository",
)
@click.option(
    "--stack/--no-stack",
    "-s/-S",
    is_flag=True,
    default=True,
    help="Submit the entire of stack of commits reachable from HEAD, versus only single commits.  "
    "This affects the meaning of REVS.  With --stack, we submit all commits that "
    "are reachable from REVS, excluding commits already on the base branch.  Revision ranges "
    "supported by git rev-list are also supported.  "
    "With --no-stack, we support only non-range identifiers, and will submit each commit "
    "listed in the command line.",
)
@click.option(
    "--reviewer",
    default=None,
    help="Comma-separated list of GitHub usernames to add as reviewers to new PRs "
    "(overrides .ghstackrc setting)",
)
@click.option(
    "--label",
    default=None,
    help="Comma-separated list of labels to add to new PRs "
    "(overrides .ghstackrc setting)",
)
@click.option(
    "--direct/--no-direct",
    "direct_opt",
    default=None,
    is_flag=True,
    help="Create stack that directly merges into master",
)
@click.argument(
    "revs",
    nargs=-1,
    metavar="REVS",
)
def submit(
    message: str,
    update_fields: bool,
    short: bool,
    force: bool,
    no_skip: bool,
    draft: bool,
    direct_opt: Optional[bool],
    base: Optional[str],
    revs: Tuple[str, ...],
    stack: bool,
    reviewer: Optional[str],
    label: Optional[str],
) -> None:
    """
    Submit or update a PR stack
    """
    with cli_context() as (shell, config, github):
        ghstack.submit.main(
            msg=message,
            username=config.github_username,
            sh=shell,
            github=github,
            update_fields=update_fields,
            short=short,
            force=force,
            no_skip=no_skip,
            draft=draft,
            github_url=config.github_url,
            remote_name=config.remote_name,
            base_opt=base,
            revs=revs,
            stack=stack,
            direct_opt=direct_opt,
            reviewer=reviewer if reviewer is not None else config.reviewer,
            label=label if label is not None else config.label,
        )


@main.command("unlink")
@click.argument("commits", nargs=-1, metavar="COMMIT")
def unlink(commits: List[str]) -> None:
    """
    Unlink commits from PRs
    """
    with cli_context() as (shell, config, github):
        ghstack.unlink.main(
            commits=commits,
            github=github,
            sh=shell,
            github_url=config.github_url,
            remote_name=config.remote_name,
        )
