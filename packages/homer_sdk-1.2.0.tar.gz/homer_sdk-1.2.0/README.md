# Homer SDK (Thin Client)

Homer SDK is a thin client. All governance, policy checks, and intelligence run on Homer Server.

## Highlights
- Multi-provider wrappers (`openai`, `anthropic`, `azure_openai`, generic broker)
- Policy enforcement for input/output checks
- Content enrichment (classification, norm extraction, confidence, modality)
- Immutable-style decision ledger and telemetry helpers
- Context store utilities

## Quick Start

```python
from homer_sdk import Homer

homer = Homer(server_url="https://your-homer-server", api_key="hk-...")
client = homer.openai()

resp = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Summarize this policy."}],
)

print(resp.raw_response.choices[0].message.content)
print(resp.homer.classification)
```

## Install

```bash
pip install homer-sdk
```

Provider SDK extras:

```bash
pip install "homer-sdk[all]"
pip install "homer-sdk[postgres]"         # source build of psycopg2
pip install "homer-sdk[postgres-binary]"  # convenience binary wheel
```

## Security Note (Broker/Gateway Mode)

If you pass `api_key` in `homer.broker(...)`, that key is sent to Homer Server in the `/v1/invoke` payload.

- SDK now refuses to send `broker_api_key` unless `HOMER_SERVER_URL` is HTTPS.
- Exception: local development on `http://localhost` or `http://127.0.0.1`.
- Recommended production pattern: keep downstream provider keys server-side and do not send them from clients.
