"""
Pipeline Guard - Constitutional invariant enforcement for AI outputs.

Enforces 9 invariants that prevent invalid artifacts from leaking through.
Invalid content is DROPPED, not downgraded.

Invariants:
1. No unresolved subject may exit the pipeline
2. split_required is internal signal, never output
3. Norms must be atomic before binding
4. Hard norms may not be inferred
5. Non-normative fragments must not become norms
6. Post-split norms must be re-typed
7. Duplicate canonical roles are forbidden
8. Confidence collapse is terminal
9. Document publishability is structural
"""

import re
import logging
from typing import List, Set, Optional, Tuple, Any, Dict
from homer_sdk.types import Norm, NormType, Violation

logger = logging.getLogger(__name__)


class InvariantViolation(Exception):
    def __init__(self, invariant_id: int, message: str, artifact_id: str = ""):
        self.invariant_id = invariant_id
        self.artifact_id = artifact_id
        super().__init__(f"Invariant {invariant_id} violated: {message}")


class PipelineGuard:
    HARD_NORMS = {"obligation", "prohibition", "constraint"}

    VALID_MODALS = (
        "must", "shall", "may", "should", "expected",
        "required", "prohibited", "forbidden", "allowed", "permitted"
    )

    INTERNAL_SIGNALS = {"split_required", "role_unspecified", None, ""}

    NON_NORMATIVE_PATTERNS = [
        r'^recent\s+research',
        r'^studies\s+show',
        r'give\s+rise\s+to\s+(?:legitimate\s+)?concerns',
        r'^for\s+example',
        r'^in\s+other\s+words',
        r'^this\s+means',
        r'\b(?:may|could)\s+(?:give\s+rise|result|lead)\s+to\b',
    ]

    def __init__(self, strict: bool = True):
        self.strict = strict
        self.violations: List[Violation] = []
        self.dropped_count = 0
        self.passed_count = 0

    def validate_content(self, content: str, context: Optional[Dict[str, Any]] = None) -> Tuple[bool, List[Violation]]:
        """
        Validate arbitrary text content against guard invariants.
        Returns (is_valid, violations).
        """
        violations = []

        if not self._has_modal(content):
            v = Violation(5, "content", "Non-normative fragment (no modal verb)", "flagged")
            violations.append(v)

        if self._is_non_normative_content(content):
            v = Violation(5, "content", "Non-normative content pattern detected", "flagged")
            violations.append(v)

        self.violations.extend(violations)
        return len(violations) == 0, violations

    def validate_norm(self, norm: Norm, role_ids: Set[str] = None) -> bool:
        role_ids = role_ids or set()
        norm_type = norm.norm_type.value if isinstance(norm.norm_type, NormType) else str(norm.norm_type)
        norm_id = norm.norm_id
        source = norm.source_sentence or ""

        if norm.subject_role_id in self.INTERNAL_SIGNALS:
            self._record(1, norm_id, f"Unresolved role '{norm.subject_role_id}' leaked", "dropped")
            self.dropped_count += 1
            return False

        if norm.subject_role_id == "split_required":
            self._record(2, norm_id, "split_required signal leaked to output", "dropped")
            self.dropped_count += 1
            return False

        if norm.confidence and norm.confidence.atomicity < 1.0:
            if norm_type in self.HARD_NORMS:
                self._record(3, norm_id, f"Non-atomic hard norm (atomicity={norm.confidence.atomicity})", "dropped")
                self.dropped_count += 1
                return False

        if norm_type in self.HARD_NORMS:
            if norm.confidence and norm.confidence.actor_binding < 1.0:
                self._record(4, norm_id, f"Hard norm with weak binding (actor_binding={norm.confidence.actor_binding})", "dropped")
                self.dropped_count += 1
                return False

        if not self._has_modal(source):
            self._record(5, norm_id, "Non-normative fragment (no modal verb)", "dropped")
            self.dropped_count += 1
            return False

        if self._is_non_normative_content(source):
            self._record(5, norm_id, "Non-normative content pattern detected", "dropped")
            self.dropped_count += 1
            return False

        if norm.confidence and norm.confidence.composite < 0.5:
            self._record(8, norm_id, f"Confidence collapse (composite={norm.confidence.composite})", "dropped")
            self.dropped_count += 1
            return False

        self.passed_count += 1
        return True

    def filter_norms(self, norms: List[Norm], role_ids: Set[str] = None) -> List[Norm]:
        return [n for n in norms if self.validate_norm(n, role_ids)]

    def validate_response(self, text: str) -> Tuple[bool, List[Violation]]:
        """
        Validate an AI response for policy compliance issues.
        Checks for safety, normative content, and structural quality.
        """
        violations = []

        if not text or len(text.strip()) < 3:
            v = Violation(8, "response", "Empty or trivially short response", "flagged")
            violations.append(v)

        if re.search(r'_{3,}', text):
            v = Violation(9, "response", "Placeholder/incomplete content detected", "flagged")
            violations.append(v)

        words = text.strip().split()
        if words and words[-1].lower() in ('the', 'a', 'an', 'with', 'for', 'in', 'on', 'to', 'of', 'by'):
            v = Violation(9, "response", "Response appears truncated", "flagged")
            violations.append(v)

        self.violations.extend(violations)
        return len(violations) == 0, violations

    def _has_modal(self, sentence: str) -> bool:
        sent_lower = sentence.lower()
        return any(modal in sent_lower for modal in self.VALID_MODALS)

    def _is_non_normative_content(self, sentence: str) -> bool:
        sent_lower = sentence.lower()
        return any(re.search(p, sent_lower) for p in self.NON_NORMATIVE_PATTERNS)

    def _record(self, invariant_id: int, artifact_id: str, message: str, action: str):
        v = Violation(invariant_id, artifact_id, message, action)
        self.violations.append(v)
        logger.warning(f"Invariant {invariant_id} violated for {artifact_id}: {message} -> {action}")

    def get_stats(self) -> dict:
        return {
            "passed": self.passed_count,
            "dropped": self.dropped_count,
            "violations": len(self.violations),
            "violation_details": [
                {"invariant": v.invariant_id, "artifact": v.artifact_id, "reason": v.message}
                for v in self.violations
            ]
        }

    def reset(self):
        self.violations = []
        self.dropped_count = 0
        self.passed_count = 0
