"""
Policy Engine - Configurable policy enforcement for AI interactions.

Define policies as rules that govern what AI can/cannot do.
Policies are checked before (input) and after (output) each AI call.

Usage:
    engine = PolicyEngine()
    engine.add_rule(PolicyRule(
        name="no_pii",
        description="Block PII in outputs",
        check=lambda text: not re.search(r'\b\d{3}-\d{2}-\d{4}\b', text),
        phase="output"
    ))
"""

import re
import logging
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Dict, Any, Tuple

logger = logging.getLogger(__name__)


@dataclass
class PolicyRule:
    name: str
    description: str
    check: Callable[[str], bool]
    phase: str = "both"
    severity: str = "error"
    enabled: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PolicyViolation:
    rule_name: str
    description: str
    phase: str
    severity: str
    content_snippet: str = ""


class PolicyEngine:
    """
    Configurable policy enforcement engine.
    Rules are applied to input (pre-call) and output (post-call) content.
    """

    PII_PATTERNS = {
        "ssn": re.compile(r'\b\d{3}-\d{2}-\d{4}\b'),
        "credit_card": re.compile(r'\b(?:\d{4}[- ]?){3}\d{4}\b'),
        "email": re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
        "phone": re.compile(r'\b(?:\+1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b'),
    }

    PROMPT_INJECTION_PATTERNS = [
        re.compile(r'ignore\s+(?:all\s+)?(?:previous|prior|above)\s+instructions', re.IGNORECASE),
        re.compile(r'you\s+are\s+now\s+(?:a|an)\s+', re.IGNORECASE),
        re.compile(r'forget\s+(?:all\s+)?(?:your|previous)\s+', re.IGNORECASE),
        re.compile(r'system\s*:\s*', re.IGNORECASE),
        re.compile(r'<\|(?:im_start|im_end|system|endoftext)\|>', re.IGNORECASE),
    ]

    def __init__(self):
        self.rules: List[PolicyRule] = []
        self._built_in_loaded = False

    def add_rule(self, rule: PolicyRule):
        self.rules.append(rule)

    def remove_rule(self, name: str):
        self.rules = [r for r in self.rules if r.name != name]

    def load_built_in_rules(self):
        if self._built_in_loaded:
            return
        self._built_in_loaded = True

        self.add_rule(PolicyRule(
            name="no_pii_output",
            description="Block PII (SSN, credit cards) in AI outputs",
            check=lambda text: not any(p.search(text) for p in self.PII_PATTERNS.values()),
            phase="output",
            severity="error",
        ))

        self.add_rule(PolicyRule(
            name="no_prompt_injection",
            description="Block prompt injection attempts in inputs",
            check=lambda text: not any(p.search(text) for p in self.PROMPT_INJECTION_PATTERNS),
            phase="input",
            severity="error",
        ))

        self.add_rule(PolicyRule(
            name="max_input_length",
            description="Reject excessively long inputs (>100k chars)",
            check=lambda text: len(text) <= 100_000,
            phase="input",
            severity="error",
        ))

        self.add_rule(PolicyRule(
            name="non_empty_output",
            description="Flag empty or trivially short outputs",
            check=lambda text: len(text.strip()) >= 5,
            phase="output",
            severity="warning",
        ))

    def enforce(self, content: str, phase: str) -> Tuple[bool, List[PolicyViolation]]:
        """
        Check content against all rules for the given phase.

        Args:
            content: Text to check
            phase: "input" or "output"

        Returns:
            (passed, violations) tuple
        """
        violations = []

        for rule in self.rules:
            if not rule.enabled:
                continue
            if rule.phase not in (phase, "both"):
                continue

            try:
                passed = rule.check(content)
                if not passed:
                    snippet = content[:100] + "..." if len(content) > 100 else content
                    violations.append(PolicyViolation(
                        rule_name=rule.name,
                        description=rule.description,
                        phase=phase,
                        severity=rule.severity,
                        content_snippet=snippet,
                    ))
            except Exception as e:
                logger.error(f"Policy rule '{rule.name}' raised exception: {e}")

        has_errors = any(v.severity == "error" for v in violations)
        return not has_errors, violations

    def enforce_input(self, content: str) -> Tuple[bool, List[PolicyViolation]]:
        return self.enforce(content, "input")

    def enforce_output(self, content: str) -> Tuple[bool, List[PolicyViolation]]:
        return self.enforce(content, "output")
