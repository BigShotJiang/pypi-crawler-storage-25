"""
Temporal Store - Time-series storage with point-in-time queries.

Every state change is recorded with temporal coordinates (valid_from, valid_to),
enabling point-in-time reconstruction and temporal context queries.

Temporal dimensions:
- Transaction time: when the fact was recorded (system time)
- Valid time: when the fact was true in the real world (business time)

Features:
- Bi-temporal records: transaction time + valid time
- Point-in-time queries: "what did we know at time T?"
- Temporal context: retrieve the state as it was at any moment
- Spatial context support: optional geo-coordinates
- No updates: new versions create new records, old ones get valid_to set

Usage:
    store = TemporalStore()
    store.record("model_config", {"model": "gpt-4", "temperature": 0.7})
    store.record("model_config", {"model": "gpt-4o", "temperature": 0.5})

    # Point-in-time query
    config = store.at_time("model_config", "2024-06-01T00:00:00Z")

    # History
    history = store.history("model_config")
"""

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class SpatialContext:
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    region: Optional[str] = None
    jurisdiction: Optional[str] = None


@dataclass
class TemporalRecord:
    record_id: str
    entity_type: str
    entity_id: str
    data: Dict[str, Any]
    valid_from: str
    valid_to: Optional[str] = None
    transaction_time: str = ""
    version: int = 1
    spatial: Optional[SpatialContext] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        return d

    @property
    def is_current(self) -> bool:
        return self.valid_to is None


def _validate_table_name(name: str) -> str:
    import re
    if not re.match(r'^[a-z_][a-z0-9_]{0,62}$', name):
        raise ValueError(f"Invalid table name '{name}': must be lowercase alphanumeric/underscore, max 63 chars")
    return name


class TemporalStore:

    INFINITY = "9999-12-31T23:59:59+00:00"

    def __init__(self, database_url: Optional[str] = None, table_name: str = "homer_temporal"):
        self._records: Dict[str, List[TemporalRecord]] = {}
        self._table_name = _validate_table_name(table_name)
        self._db_url = database_url or os.environ.get("DATABASE_URL")
        self._db_initialized = False

        if self._db_url:
            try:
                self._init_db()
            except Exception as e:
                logger.warning(f"Temporal DB init failed, using in-memory: {e}")
                self._db_url = None

    def _init_db(self):
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute(f"""
                    CREATE TABLE IF NOT EXISTS {self._table_name} (
                        record_id VARCHAR(64) PRIMARY KEY,
                        entity_type VARCHAR(128) NOT NULL,
                        entity_id VARCHAR(256) NOT NULL,
                        data JSONB NOT NULL,
                        valid_from TIMESTAMPTZ NOT NULL,
                        valid_to TIMESTAMPTZ,
                        transaction_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        version INTEGER NOT NULL DEFAULT 1,
                        spatial_lat FLOAT,
                        spatial_lon FLOAT,
                        spatial_region VARCHAR(128),
                        spatial_jurisdiction VARCHAR(128),
                        metadata JSONB DEFAULT '{{}}'::jsonb
                    );
                    CREATE INDEX IF NOT EXISTS idx_{self._table_name}_entity
                        ON {self._table_name} (entity_type, entity_id);
                    CREATE INDEX IF NOT EXISTS idx_{self._table_name}_valid
                        ON {self._table_name} (valid_from, valid_to);
                    CREATE INDEX IF NOT EXISTS idx_{self._table_name}_current
                        ON {self._table_name} (entity_type, entity_id) WHERE valid_to IS NULL;
                """)
            conn.commit()
            self._db_initialized = True
        finally:
            conn.close()

    def record(
        self,
        entity_type: str,
        data: Dict[str, Any],
        entity_id: Optional[str] = None,
        valid_from: Optional[str] = None,
        spatial: Optional[SpatialContext] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> TemporalRecord:
        entity_id = entity_id or "default"
        now = datetime.now(timezone.utc).isoformat()
        valid_from = valid_from or now

        key = f"{entity_type}:{entity_id}"
        version = 1

        if self._db_initialized:
            version = self._close_current_db(entity_type, entity_id, valid_from)
        else:
            existing = self._records.get(key, [])
            for r in existing:
                if r.is_current:
                    r.valid_to = valid_from
            version = len(existing) + 1

        rec = TemporalRecord(
            record_id=f"tr_{uuid.uuid4().hex[:16]}",
            entity_type=entity_type,
            entity_id=entity_id,
            data=data,
            valid_from=valid_from,
            valid_to=None,
            transaction_time=now,
            version=version,
            spatial=spatial,
            metadata=metadata or {},
        )

        if self._db_initialized:
            self._persist_temporal(rec)
        else:
            self._records.setdefault(key, []).append(rec)

        return rec

    def _close_current_db(self, entity_type: str, entity_id: str, valid_to: str) -> int:
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    f"SELECT MAX(version) FROM {self._table_name} "
                    f"WHERE entity_type = %s AND entity_id = %s",
                    (entity_type, entity_id),
                )
                row = cur.fetchone()
                version = (row[0] or 0) + 1

                cur.execute(
                    f"UPDATE {self._table_name} SET valid_to = %s "
                    f"WHERE entity_type = %s AND entity_id = %s AND valid_to IS NULL",
                    (valid_to, entity_type, entity_id),
                )
            conn.commit()
            return version
        finally:
            conn.close()

    def _persist_temporal(self, rec: TemporalRecord):
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    f"""INSERT INTO {self._table_name}
                    (record_id, entity_type, entity_id, data, valid_from, valid_to,
                     transaction_time, version, spatial_lat, spatial_lon,
                     spatial_region, spatial_jurisdiction, metadata)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    (
                        rec.record_id, rec.entity_type, rec.entity_id,
                        json.dumps(rec.data, default=str),
                        rec.valid_from, rec.valid_to,
                        rec.transaction_time, rec.version,
                        rec.spatial.latitude if rec.spatial else None,
                        rec.spatial.longitude if rec.spatial else None,
                        rec.spatial.region if rec.spatial else None,
                        rec.spatial.jurisdiction if rec.spatial else None,
                        json.dumps(rec.metadata, default=str),
                    ),
                )
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Failed to persist temporal record: {e}")
        finally:
            conn.close()

    def at_time(
        self,
        entity_type: str,
        point_in_time: str,
        entity_id: str = "default",
    ) -> Optional[TemporalRecord]:
        if self._db_initialized:
            return self._at_time_db(entity_type, entity_id, point_in_time)

        key = f"{entity_type}:{entity_id}"
        records = self._records.get(key, [])
        for r in reversed(records):
            if r.valid_from <= point_in_time:
                if r.valid_to is None or r.valid_to > point_in_time:
                    return r
        return None

    def _at_time_db(self, entity_type: str, entity_id: str, pit: str) -> Optional[TemporalRecord]:
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    f"""SELECT record_id, entity_type, entity_id, data, valid_from,
                        valid_to, transaction_time, version, spatial_lat, spatial_lon,
                        spatial_region, spatial_jurisdiction, metadata
                    FROM {self._table_name}
                    WHERE entity_type = %s AND entity_id = %s
                      AND valid_from <= %s
                      AND (valid_to IS NULL OR valid_to > %s)
                    ORDER BY version DESC LIMIT 1""",
                    (entity_type, entity_id, pit, pit),
                )
                row = cur.fetchone()
                if row:
                    spatial = None
                    if row[8] is not None or row[10] is not None:
                        spatial = SpatialContext(
                            latitude=row[8], longitude=row[9],
                            region=row[10], jurisdiction=row[11],
                        )
                    return TemporalRecord(
                        record_id=row[0], entity_type=row[1], entity_id=row[2],
                        data=row[3], valid_from=row[4].isoformat() if hasattr(row[4], 'isoformat') else str(row[4]),
                        valid_to=row[5].isoformat() if row[5] and hasattr(row[5], 'isoformat') else (str(row[5]) if row[5] else None),
                        transaction_time=row[6].isoformat() if hasattr(row[6], 'isoformat') else str(row[6]),
                        version=row[7], spatial=spatial, metadata=row[12] or {},
                    )
        finally:
            conn.close()
        return None

    def current(self, entity_type: str, entity_id: str = "default") -> Optional[TemporalRecord]:
        return self.at_time(entity_type, datetime.now(timezone.utc).isoformat(), entity_id)

    def history(
        self,
        entity_type: str,
        entity_id: str = "default",
        limit: int = 100,
    ) -> List[TemporalRecord]:
        if self._db_initialized:
            return self._history_db(entity_type, entity_id, limit)

        key = f"{entity_type}:{entity_id}"
        records = self._records.get(key, [])
        return list(records[-limit:])

    def _history_db(self, entity_type: str, entity_id: str, limit: int) -> List[TemporalRecord]:
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    f"""SELECT record_id, entity_type, entity_id, data, valid_from,
                        valid_to, transaction_time, version, spatial_lat, spatial_lon,
                        spatial_region, spatial_jurisdiction, metadata
                    FROM {self._table_name}
                    WHERE entity_type = %s AND entity_id = %s
                    ORDER BY version ASC LIMIT %s""",
                    (entity_type, entity_id, limit),
                )
                results = []
                for row in cur.fetchall():
                    spatial = None
                    if row[8] is not None or row[10] is not None:
                        spatial = SpatialContext(
                            latitude=row[8], longitude=row[9],
                            region=row[10], jurisdiction=row[11],
                        )
                    results.append(TemporalRecord(
                        record_id=row[0], entity_type=row[1], entity_id=row[2],
                        data=row[3], valid_from=row[4].isoformat() if hasattr(row[4], 'isoformat') else str(row[4]),
                        valid_to=row[5].isoformat() if row[5] and hasattr(row[5], 'isoformat') else (str(row[5]) if row[5] else None),
                        transaction_time=row[6].isoformat() if hasattr(row[6], 'isoformat') else str(row[6]),
                        version=row[7], spatial=spatial, metadata=row[12] or {},
                    ))
                return results
        finally:
            conn.close()
