"""
Decision Ledger - Immutable, append-only decision capture.

Every AI decision is recorded with a content hash, creating
an unchangeable audit trail. Decisions are chained via prev_hash
forming a tamper-evident linked list (similar to a blockchain).

Features:
- Append-only: no updates, no deletes
- Content-addressed: SHA-256 hash of decision content
- Chain integrity: each decision references previous hash
- Point-in-time queries via temporal store
- PostgreSQL persistence with in-memory fallback

Usage:
    ledger = DecisionLedger()
    decision = ledger.record(
        decision_type="policy_evaluation",
        input_data={"prompt": "..."},
        output_data={"response": "..."},
        model="gpt-4",
        context={"session_id": "abc123"}
    )
    print(decision.decision_id)  # Unique ID
    print(decision.content_hash) # SHA-256
    print(decision.prev_hash)    # Chain link

    # Verify integrity
    valid = ledger.verify_chain()

    # Query history
    decisions = ledger.query(
        decision_type="policy_evaluation",
        after="2024-01-01T00:00:00Z",
        before="2024-12-31T23:59:59Z"
    )
"""

import hashlib
import json
import logging
import os
import threading
import time
import uuid
from collections import deque
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

MAX_IN_MEMORY_DECISIONS = 10000


@dataclass
class Decision:
    decision_id: str
    decision_type: str
    timestamp: str
    input_hash: str
    output_hash: str
    content_hash: str
    prev_hash: str
    model: str = ""
    input_data: Dict[str, Any] = field(default_factory=dict)
    output_data: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)
    policies_evaluated: List[str] = field(default_factory=list)
    violations: List[Dict[str, Any]] = field(default_factory=list)
    confidence: Optional[float] = None
    latency_ms: Optional[int] = None
    sealed: bool = True

    def to_dict(self) -> dict:
        return asdict(self)


def _hash(data: Any) -> str:
    serialized = json.dumps(data, sort_keys=True, default=str)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _validate_table_name(name: str) -> str:
    import re
    if not re.match(r'^[a-z_][a-z0-9_]{0,62}$', name):
        raise ValueError(f"Invalid table name '{name}': must be lowercase alphanumeric/underscore, max 63 chars")
    return name


class DecisionLedger:

    GENESIS_HASH = "0" * 64

    def __init__(self, database_url: Optional[str] = None, table_name: str = "homer_decisions"):
        self._decisions: deque = deque(maxlen=MAX_IN_MEMORY_DECISIONS)
        self._last_hash: str = self.GENESIS_HASH
        self._table_name = _validate_table_name(table_name)
        self._db_url = database_url or os.environ.get("DATABASE_URL")
        self._db_initialized = False
        self._chain_lock = threading.Lock()

        if self._db_url:
            try:
                self._init_db()
                self._load_chain_state()
            except Exception as e:
                logger.warning(f"Database init failed, using in-memory ledger: {e}")
                self._db_url = None

    def _init_db(self):
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute(f"""
                    CREATE TABLE IF NOT EXISTS {self._table_name} (
                        decision_id VARCHAR(64) PRIMARY KEY,
                        decision_type VARCHAR(128) NOT NULL,
                        timestamp TIMESTAMPTZ NOT NULL,
                        input_hash VARCHAR(64) NOT NULL,
                        output_hash VARCHAR(64) NOT NULL,
                        content_hash VARCHAR(64) NOT NULL,
                        prev_hash VARCHAR(64) NOT NULL,
                        model VARCHAR(128) DEFAULT '',
                        input_data JSONB DEFAULT '{{}}'::jsonb,
                        output_data JSONB DEFAULT '{{}}'::jsonb,
                        context JSONB DEFAULT '{{}}'::jsonb,
                        policies_evaluated JSONB DEFAULT '[]'::jsonb,
                        violations JSONB DEFAULT '[]'::jsonb,
                        confidence FLOAT,
                        latency_ms INTEGER,
                        sealed BOOLEAN DEFAULT TRUE,
                        created_at TIMESTAMPTZ DEFAULT NOW()
                    );
                    CREATE INDEX IF NOT EXISTS idx_{self._table_name}_type
                        ON {self._table_name} (decision_type);
                    CREATE INDEX IF NOT EXISTS idx_{self._table_name}_timestamp
                        ON {self._table_name} (timestamp);
                    CREATE INDEX IF NOT EXISTS idx_{self._table_name}_content_hash
                        ON {self._table_name} (content_hash);
                    CREATE INDEX IF NOT EXISTS idx_{self._table_name}_model
                        ON {self._table_name} (model);
                """)
            conn.commit()
            self._db_initialized = True
            logger.info(f"Decision ledger table '{self._table_name}' initialized")
        finally:
            conn.close()

    def _load_chain_state(self):
        if not self._db_initialized:
            return
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    f"SELECT content_hash FROM {self._table_name} ORDER BY timestamp DESC LIMIT 1"
                )
                row = cur.fetchone()
                if row:
                    self._last_hash = row[0]
        finally:
            conn.close()

    def record(
        self,
        decision_type: str,
        input_data: Optional[Dict[str, Any]] = None,
        output_data: Optional[Dict[str, Any]] = None,
        model: str = "",
        context: Optional[Dict[str, Any]] = None,
        policies_evaluated: Optional[List[str]] = None,
        violations: Optional[List[Dict[str, Any]]] = None,
        confidence: Optional[float] = None,
        latency_ms: Optional[int] = None,
    ) -> Decision:
        input_data = input_data or {}
        output_data = output_data or {}
        context = context or {}

        with self._chain_lock:
            now = datetime.now(timezone.utc).isoformat()
            input_hash = _hash(input_data)
            output_hash = _hash(output_data)

            content_payload = {
                "decision_type": decision_type,
                "timestamp": now,
                "input_hash": input_hash,
                "output_hash": output_hash,
                "prev_hash": self._last_hash,
                "model": model,
            }
            content_hash = _hash(content_payload)

            decision = Decision(
                decision_id=f"dec_{uuid.uuid4().hex[:16]}",
                decision_type=decision_type,
                timestamp=now,
                input_hash=input_hash,
                output_hash=output_hash,
                content_hash=content_hash,
                prev_hash=self._last_hash,
                model=model,
                input_data=input_data,
                output_data=output_data,
                context=context,
                policies_evaluated=policies_evaluated or [],
                violations=violations or [],
                confidence=confidence,
                latency_ms=latency_ms,
                sealed=True,
            )

            self._decisions.append(decision)
            self._last_hash = content_hash

        if self._db_initialized:
            self._persist(decision)

        return decision

    def _persist(self, decision: Decision):
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    f"""INSERT INTO {self._table_name}
                    (decision_id, decision_type, timestamp, input_hash, output_hash,
                     content_hash, prev_hash, model, input_data, output_data,
                     context, policies_evaluated, violations, confidence, latency_ms, sealed)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    (
                        decision.decision_id,
                        decision.decision_type,
                        decision.timestamp,
                        decision.input_hash,
                        decision.output_hash,
                        decision.content_hash,
                        decision.prev_hash,
                        decision.model,
                        json.dumps(decision.input_data, default=str),
                        json.dumps(decision.output_data, default=str),
                        json.dumps(decision.context, default=str),
                        json.dumps(decision.policies_evaluated),
                        json.dumps(decision.violations, default=str),
                        decision.confidence,
                        decision.latency_ms,
                        decision.sealed,
                    ),
                )
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Failed to persist decision {decision.decision_id}: {e}")
        finally:
            conn.close()

    def verify_chain(self, decisions: Optional[List[Decision]] = None) -> bool:
        chain = decisions or self._get_full_chain()
        if not chain:
            return True

        expected_prev = self.GENESIS_HASH
        for d in chain:
            if d.prev_hash != expected_prev:
                logger.error(
                    f"Chain broken at {d.decision_id}: "
                    f"expected prev_hash={expected_prev}, got {d.prev_hash}"
                )
                return False

            payload = {
                "decision_type": d.decision_type,
                "timestamp": d.timestamp,
                "input_hash": d.input_hash,
                "output_hash": d.output_hash,
                "prev_hash": d.prev_hash,
                "model": d.model,
            }
            recomputed = _hash(payload)
            if recomputed != d.content_hash:
                logger.error(
                    f"Content tampered at {d.decision_id}: "
                    f"expected hash={recomputed}, got {d.content_hash}"
                )
                return False

            expected_prev = d.content_hash

        return True

    def _get_full_chain(self) -> List[Decision]:
        if self._db_initialized:
            return self._query_db()
        return list(self._decisions)

    def query(
        self,
        decision_type: Optional[str] = None,
        model: Optional[str] = None,
        after: Optional[str] = None,
        before: Optional[str] = None,
        limit: int = 100,
    ) -> List[Decision]:
        if self._db_initialized:
            return self._query_db(
                decision_type=decision_type, model=model,
                after=after, before=before, limit=limit
            )

        results = list(self._decisions)
        if decision_type:
            results = [d for d in results if d.decision_type == decision_type]
        if model:
            results = [d for d in results if d.model == model]
        if after:
            results = [d for d in results if d.timestamp >= after]
        if before:
            results = [d for d in results if d.timestamp <= before]
        return results[-limit:]

    def _query_db(
        self,
        decision_type: Optional[str] = None,
        model: Optional[str] = None,
        after: Optional[str] = None,
        before: Optional[str] = None,
        limit: int = 100,
    ) -> List[Decision]:
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                conditions = []
                params = []

                if decision_type:
                    conditions.append("decision_type = %s")
                    params.append(decision_type)
                if model:
                    conditions.append("model = %s")
                    params.append(model)
                if after:
                    conditions.append("timestamp >= %s")
                    params.append(after)
                if before:
                    conditions.append("timestamp <= %s")
                    params.append(before)

                where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
                params.append(limit)

                cur.execute(
                    f"""SELECT decision_id, decision_type, timestamp, input_hash,
                        output_hash, content_hash, prev_hash, model, input_data,
                        output_data, context, policies_evaluated, violations,
                        confidence, latency_ms, sealed
                    FROM {self._table_name} {where}
                    ORDER BY timestamp ASC LIMIT %s""",
                    params,
                )

                decisions = []
                for row in cur.fetchall():
                    decisions.append(Decision(
                        decision_id=row[0], decision_type=row[1],
                        timestamp=row[2].isoformat() if hasattr(row[2], 'isoformat') else str(row[2]),
                        input_hash=row[3], output_hash=row[4],
                        content_hash=row[5], prev_hash=row[6],
                        model=row[7], input_data=row[8] or {},
                        output_data=row[9] or {}, context=row[10] or {},
                        policies_evaluated=row[11] or [], violations=row[12] or [],
                        confidence=row[13], latency_ms=row[14], sealed=row[15],
                    ))
                return decisions
        finally:
            conn.close()

    def get_decision(self, decision_id: str) -> Optional[Decision]:
        if self._db_initialized:
            import psycopg2
            conn = psycopg2.connect(self._db_url)
            try:
                with conn.cursor() as cur:
                    cur.execute(
                        f"""SELECT decision_id, decision_type, timestamp, input_hash,
                            output_hash, content_hash, prev_hash, model, input_data,
                            output_data, context, policies_evaluated, violations,
                            confidence, latency_ms, sealed
                        FROM {self._table_name} WHERE decision_id = %s""",
                        (decision_id,),
                    )
                    row = cur.fetchone()
                    if row:
                        return Decision(
                            decision_id=row[0], decision_type=row[1],
                            timestamp=row[2].isoformat() if hasattr(row[2], 'isoformat') else str(row[2]),
                            input_hash=row[3], output_hash=row[4],
                            content_hash=row[5], prev_hash=row[6],
                            model=row[7], input_data=row[8] or {},
                            output_data=row[9] or {}, context=row[10] or {},
                            policies_evaluated=row[11] or [], violations=row[12] or [],
                            confidence=row[13], latency_ms=row[14], sealed=row[15],
                        )
            finally:
                conn.close()
        else:
            for d in self._decisions:
                if d.decision_id == decision_id:
                    return d
        return None

    @property
    def chain_length(self) -> int:
        if self._db_initialized:
            import psycopg2
            conn = psycopg2.connect(self._db_url)
            try:
                with conn.cursor() as cur:
                    cur.execute(f"SELECT COUNT(*) FROM {self._table_name}")
                    return cur.fetchone()[0]
            finally:
                conn.close()
        return len(self._decisions)

    @property
    def last_hash(self) -> str:
        return self._last_hash
