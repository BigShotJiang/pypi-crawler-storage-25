"""
Homer SDK (thin client).

All policy enforcement and intelligence run on Homer Server.
Set `HOMER_SERVER_URL` and `HOMER_API_KEY` or pass them to `Homer(...)`.
"""

from homer_sdk.client import Homer
from homer_sdk.config import (
    HomerConfig,
    ReliabilityConfig,
    RetryConfig,
    CircuitBreakerConfig,
    ContextStoreConfig,
    TelemetryConfig,
)
from homer_sdk.types import (
    SCHEMA_VERSION,
    HomerResponse,
    HomerEnrichment,
    ContentClassification,
    ConfidenceResult,
    Norm,
    NormType,
    Violation,
    PolicyDecision,
    AuditRecord,
    TraceInfo,
)

__version__ = "1.2.0"

__all__ = [
    "Homer",
    "HomerConfig",
    "ReliabilityConfig",
    "RetryConfig",
    "CircuitBreakerConfig",
    "ContextStoreConfig",
    "TelemetryConfig",
    "SCHEMA_VERSION",
    "HomerResponse",
    "HomerEnrichment",
    "ContentClassification",
    "ConfidenceResult",
    "Norm",
    "NormType",
    "Violation",
    "PolicyDecision",
    "AuditRecord",
    "TraceInfo",
]
