"""
Tracing - Distributed tracing support for Homer SDK.

Provides span-based tracing compatible with OpenTelemetry concepts.
Every Homer call gets a trace_id and request_id for end-to-end observability.
"""

import logging
import time
import uuid
import threading
from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

MAX_SPANS = 10000
ORPHAN_SPAN_TIMEOUT_SECONDS = 300


@dataclass
class Span:
    span_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    trace_id: str = ""
    parent_span_id: Optional[str] = None
    operation: str = ""
    provider: str = ""
    model: str = ""
    tenant_id: str = ""
    start_time: float = field(default_factory=time.time)
    end_time: Optional[float] = None
    duration_ms: Optional[float] = None
    status: str = "ok"
    error: Optional[str] = None
    attributes: Dict[str, Any] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)

    def finish(self, status: str = "ok", error: Optional[str] = None):
        self.end_time = time.time()
        self.duration_ms = round((self.end_time - self.start_time) * 1000, 2)
        self.status = status
        if error:
            self.error = error

    def add_event(self, name: str, attributes: Optional[Dict[str, Any]] = None):
        self.events.append({
            "name": name,
            "timestamp": time.time(),
            "attributes": attributes or {},
        })

    def to_dict(self) -> Dict[str, Any]:
        return {
            "span_id": self.span_id,
            "trace_id": self.trace_id,
            "parent_span_id": self.parent_span_id,
            "operation": self.operation,
            "provider": self.provider,
            "model": self.model,
            "tenant_id": self.tenant_id,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "status": self.status,
            "error": self.error,
            "attributes": self.attributes,
            "events": self.events,
        }


class Tracer:
    def __init__(self, enabled: bool = True, max_spans: int = MAX_SPANS):
        self._enabled = enabled
        self._spans: deque = deque(maxlen=max_spans)
        self._active_spans: Dict[str, Span] = {}
        self._lock = threading.Lock()

    def start_trace(self) -> str:
        return uuid.uuid4().hex

    def start_span(
        self,
        operation: str,
        trace_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        provider: str = "",
        model: str = "",
        tenant_id: str = "",
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Span:
        span = Span(
            trace_id=trace_id or self.start_trace(),
            parent_span_id=parent_span_id,
            operation=operation,
            provider=provider,
            model=model,
            tenant_id=tenant_id,
            attributes=attributes or {},
        )
        if self._enabled:
            with self._lock:
                self._active_spans[span.span_id] = span
                self._reap_orphaned_spans()
        return span

    def finish_span(self, span: Span, status: str = "ok", error: Optional[str] = None):
        span.finish(status=status, error=error)
        if self._enabled:
            with self._lock:
                self._active_spans.pop(span.span_id, None)
                self._spans.append(span)
                self._reap_orphaned_spans()

    @contextmanager
    def span(
        self,
        operation: str,
        trace_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        **kwargs,
    ):
        s = self.start_span(operation, trace_id=trace_id, parent_span_id=parent_span_id, **kwargs)
        try:
            yield s
            self.finish_span(s, status="ok")
        except Exception as e:
            self.finish_span(s, status="error", error=str(e))
            raise

    def get_traces(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            spans = list(self._spans)
        return [s.to_dict() for s in spans[-limit:]]

    def get_trace(self, trace_id: str) -> List[Dict[str, Any]]:
        with self._lock:
            spans = list(self._spans)
        return [s.to_dict() for s in spans if s.trace_id == trace_id]

    def _reap_orphaned_spans(self):
        now = time.time()
        orphaned = [
            sid for sid, span in self._active_spans.items()
            if now - span.start_time > ORPHAN_SPAN_TIMEOUT_SECONDS
        ]
        for sid in orphaned:
            span = self._active_spans.pop(sid, None)
            if span:
                span.finish(status="error", error="orphaned_span_timeout")
                self._spans.append(span)
                logger.warning(f"Reaped orphaned span {sid} for operation '{span.operation}'")

    def reset(self):
        with self._lock:
            self._spans.clear()
            self._active_spans.clear()
