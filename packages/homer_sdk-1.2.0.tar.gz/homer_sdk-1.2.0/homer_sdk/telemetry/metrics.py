"""
Metrics Collector - Standard metrics for Homer SDK.

Collects counters, histograms, and gauges for observability.
Compatible with OpenTelemetry export patterns.

Standard metrics:
- homer_calls_total (counter)
- homer_policy_blocks_total (counter)
- homer_provider_errors_total (counter)
- homer_context_store_latency_ms (histogram)
- homer_call_latency_ms (histogram)
- homer_enrichment_latency_ms (histogram)
"""

import logging
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

MAX_HISTOGRAM_WINDOW = 10000


@dataclass
class MetricPoint:
    name: str
    value: float
    labels: Dict[str, str] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class MetricsCollector:
    def __init__(self, prefix: str = "homer", max_histogram_size: int = MAX_HISTOGRAM_WINDOW):
        self._prefix = prefix
        self._counters: Dict[str, float] = defaultdict(float)
        self._histograms: Dict[str, deque] = {}
        self._max_histogram_size = max_histogram_size
        self._lock = threading.Lock()

    def _key(self, name: str, labels: Optional[Dict[str, str]] = None) -> str:
        full = f"{self._prefix}_{name}"
        if labels:
            tag_str = ",".join(f"{k}={v}" for k, v in sorted(labels.items()))
            full = f"{full}{{{tag_str}}}"
        return full

    def increment(self, name: str, value: float = 1.0, labels: Optional[Dict[str, str]] = None):
        with self._lock:
            self._counters[self._key(name, labels)] += value

    def observe(self, name: str, value: float, labels: Optional[Dict[str, str]] = None):
        with self._lock:
            key = self._key(name, labels)
            if key not in self._histograms:
                self._histograms[key] = deque(maxlen=self._max_histogram_size)
            self._histograms[key].append(value)

    def get_counter(self, name: str, labels: Optional[Dict[str, str]] = None) -> float:
        with self._lock:
            return self._counters.get(self._key(name, labels), 0.0)

    def get_histogram_stats(self, name: str, labels: Optional[Dict[str, str]] = None) -> Dict[str, float]:
        with self._lock:
            key = self._key(name, labels)
            buf = self._histograms.get(key)
            if not buf:
                return {"count": 0, "min": 0, "max": 0, "avg": 0, "p50": 0, "p95": 0, "p99": 0}
            values = sorted(buf)
            n = len(values)
            return {
                "count": n,
                "min": values[0],
                "max": values[-1],
                "avg": sum(values) / n,
                "p50": values[int(n * 0.5)],
                "p95": values[min(int(n * 0.95), n - 1)],
                "p99": values[min(int(n * 0.99), n - 1)],
            }

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "counters": dict(self._counters),
                "histograms": {
                    k: {
                        "count": len(v),
                        "avg": sum(v) / len(v) if v else 0,
                    }
                    for k, v in self._histograms.items()
                },
            }

    def reset(self):
        with self._lock:
            self._counters.clear()
            self._histograms.clear()
