"""
Reliability Layer - Retry, circuit breaker, timeout, and fallback.

Provides production-grade reliability for AI provider calls:
- Exponential backoff with jitter
- Circuit breaker (closed -> open -> half-open -> closed)
- Per-provider timeout enforcement
- Fallback provider chain
- Idempotency key support
"""

import logging
import random
import time
import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class RetryPolicy:
    def __init__(
        self,
        max_retries: int = 3,
        base_delay_ms: int = 500,
        max_delay_ms: int = 10000,
        exponential_base: float = 2.0,
        jitter: bool = True,
        retryable_exceptions: Optional[List[type]] = None,
    ):
        self.max_retries = max_retries
        self.base_delay_ms = base_delay_ms
        self.max_delay_ms = max_delay_ms
        self.exponential_base = exponential_base
        self.jitter = jitter
        self.retryable_exceptions = retryable_exceptions or [
            ConnectionError, TimeoutError, OSError
        ]

    def should_retry(self, error: Exception, attempt: int) -> bool:
        if attempt >= self.max_retries:
            return False

        for exc_type in self.retryable_exceptions:
            if isinstance(error, exc_type):
                return True

        error_str = str(error).lower()
        if any(code in error_str for code in ["429", "500", "502", "503", "504", "rate_limit"]):
            return True

        return False

    def get_delay_seconds(self, attempt: int) -> float:
        delay_ms = self.base_delay_ms * (self.exponential_base ** attempt)
        delay_ms = min(delay_ms, self.max_delay_ms)
        if self.jitter:
            delay_ms *= random.uniform(0.5, 1.5)
        return delay_ms / 1000.0


class CircuitBreaker:
    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout_seconds: int = 30,
        half_open_max_calls: int = 1,
    ):
        self._failure_threshold = failure_threshold
        self._recovery_timeout = recovery_timeout_seconds
        self._half_open_max = half_open_max_calls

        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._last_failure_time = 0.0
        self._half_open_calls = 0
        self._lock = threading.Lock()

    @property
    def state(self) -> CircuitState:
        with self._lock:
            if self._state == CircuitState.OPEN:
                if time.time() - self._last_failure_time >= self._recovery_timeout:
                    self._state = CircuitState.HALF_OPEN
                    self._half_open_calls = 0
            return self._state

    def allow_request(self) -> bool:
        state = self.state
        if state == CircuitState.CLOSED:
            return True
        if state == CircuitState.HALF_OPEN:
            with self._lock:
                if self._half_open_calls < self._half_open_max:
                    self._half_open_calls += 1
                    return True
                return False
        return False

    def record_success(self):
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.CLOSED
            self._failure_count = 0

    def record_failure(self):
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.time()
            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.OPEN
            elif self._failure_count >= self._failure_threshold:
                self._state = CircuitState.OPEN
                logger.warning(
                    f"Circuit breaker opened after {self._failure_count} failures"
                )

    def reset(self):
        with self._lock:
            self._state = CircuitState.CLOSED
            self._failure_count = 0
            self._half_open_calls = 0


class ReliabilityLayer:
    def __init__(
        self,
        retry_policy: Optional[RetryPolicy] = None,
        circuit_breaker: Optional[CircuitBreaker] = None,
        timeout_seconds: int = 120,
    ):
        self.retry = retry_policy or RetryPolicy()
        self.circuit_breaker = circuit_breaker or CircuitBreaker()
        self.timeout_seconds = timeout_seconds
        self._metrics = {
            "total_calls": 0,
            "successful_calls": 0,
            "failed_calls": 0,
            "retries": 0,
            "circuit_breaks": 0,
            "timeouts": 0,
        }
        self._lock = threading.Lock()

    def execute(self, fn: Callable[..., T], *args, **kwargs) -> T:
        with self._lock:
            self._metrics["total_calls"] += 1

        if not self.circuit_breaker.allow_request():
            with self._lock:
                self._metrics["circuit_breaks"] += 1
            raise ConnectionError(
                f"Circuit breaker is {self.circuit_breaker.state.value}. "
                f"Request blocked to protect downstream service."
            )

        last_error = None
        for attempt in range(self.retry.max_retries + 1):
            try:
                result = fn(*args, **kwargs)
                self.circuit_breaker.record_success()
                with self._lock:
                    self._metrics["successful_calls"] += 1
                return result
            except Exception as e:
                last_error = e
                if not self.retry.should_retry(e, attempt):
                    self.circuit_breaker.record_failure()
                    with self._lock:
                        self._metrics["failed_calls"] += 1
                    raise

                with self._lock:
                    self._metrics["retries"] += 1

                delay = self.retry.get_delay_seconds(attempt)
                logger.info(
                    f"Retry {attempt + 1}/{self.retry.max_retries} "
                    f"after {delay:.1f}s: {e}"
                )
                time.sleep(delay)

        self.circuit_breaker.record_failure()
        with self._lock:
            self._metrics["failed_calls"] += 1
        raise last_error

    @property
    def metrics(self) -> Dict[str, int]:
        with self._lock:
            return dict(self._metrics)

    def reset_metrics(self):
        with self._lock:
            for k in self._metrics:
                self._metrics[k] = 0
