"""
Homer thin client.

This SDK is intentionally thin: all intelligence and policy enforcement run on Homer Server.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import requests
from urllib.parse import urlparse

from homer_sdk.config import HomerConfig
from homer_sdk.types import (
    AuditRecord,
    ConfidenceResult,
    ContentClassification,
    HomerEnrichment,
    HomerResponse,
    Norm,
    NormConfidence,
    NormType,
    PolicyDecision,
    TraceInfo,
    Violation,
)


class _ServerClient:
    def __init__(self, config: HomerConfig):
        self._base_url = config.server_url.rstrip("/")
        self._timeout = config.request_timeout_seconds
        self._verify_ssl = config.verify_ssl
        self._session = requests.Session()
        self._session.headers.update({"Content-Type": "application/json"})
        if config.api_key:
            self._session.headers["Authorization"] = f"Bearer {config.api_key}"

    @staticmethod
    def _is_secure_url(url: str) -> bool:
        parsed = urlparse(url)
        if parsed.scheme == "https":
            return True
        if parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1", "::1"}:
            return True
        return False

    def is_transport_secure(self) -> bool:
        return self._is_secure_url(self._base_url)

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        resp = self._session.request(
            method=method,
            url=f"{self._base_url}{path}",
            json=json,
            params=params,
            headers=headers,
            timeout=self._timeout,
            verify=self._verify_ssl,
        )
        resp.raise_for_status()
        if not resp.content:
            return {}
        return resp.json()


@dataclass
class _OpenAIMessage:
    role: str
    content: str


@dataclass
class _OpenAIChoice:
    index: int
    message: _OpenAIMessage
    finish_reason: str = "stop"


@dataclass
class _OpenAIRawResponse:
    id: str = ""
    model: str = ""
    choices: List[_OpenAIChoice] = field(default_factory=list)
    usage: Dict[str, Any] = field(default_factory=dict)


@dataclass
class _AnthropicTextBlock:
    type: str
    text: str


@dataclass
class _AnthropicRawResponse:
    id: str = ""
    model: str = ""
    content: List[_AnthropicTextBlock] = field(default_factory=list)
    stop_reason: Optional[str] = None
    usage: Dict[str, Any] = field(default_factory=dict)


class _CompletionsProxy:
    def __init__(self, homer: "Homer", provider: str, provider_defaults: Optional[Dict[str, Any]] = None):
        self._homer = homer
        self._provider = provider
        self._provider_defaults = provider_defaults or {}

    def create(self, **kwargs) -> HomerResponse:
        model = kwargs.get("model") or self._provider_defaults.get("default_model") or "default"
        messages = kwargs.get("messages", [])
        payload: Dict[str, Any] = {
            "provider": self._provider,
            "model": model,
            "messages": messages,
            "temperature": kwargs.get("temperature"),
            "max_tokens": kwargs.get("max_tokens"),
        }

        # broker-specific routing inputs
        if self._provider == "broker":
            payload["broker_base_url"] = self._provider_defaults.get("base_url")
            broker_api_key = self._provider_defaults.get("api_key")
            # Never send downstream provider credentials over insecure transport,
            # except local development (localhost/127.0.0.1).
            if broker_api_key and not self._homer._server.is_transport_secure():
                raise ValueError(
                    "Refusing to send broker_api_key over insecure Homer Server transport. "
                    "Use HTTPS for HOMER_SERVER_URL or omit broker_api_key."
                )
            payload["broker_api_key"] = broker_api_key
            payload["broker_headers"] = self._provider_defaults.get("headers")

        data = self._homer._server.request("POST", "/v1/invoke", json=payload)
        enrichment = self._homer._parse_enrichment(data.get("enrichment", {}), envelope=data)

        content = data.get("content", "")
        raw = _OpenAIRawResponse(
            id=data.get("raw_response", {}).get("id", "") if isinstance(data.get("raw_response"), dict) else "",
            model=data.get("model", model),
            choices=[_OpenAIChoice(index=0, message=_OpenAIMessage(role="assistant", content=content))],
            usage=data.get("raw_response", {}).get("usage", {}) if isinstance(data.get("raw_response"), dict) else {},
        )

        return HomerResponse(raw_response=raw, homer=enrichment)


class _ChatProxy:
    def __init__(self, completions_proxy: _CompletionsProxy):
        self.completions = completions_proxy


class _OpenAIThinClient:
    def __init__(self, completions_proxy: _CompletionsProxy):
        self.chat = _ChatProxy(completions_proxy)


class _AnthropicMessagesProxy:
    def __init__(self, homer: "Homer", provider: str):
        self._homer = homer
        self._provider = provider

    def create(self, **kwargs) -> HomerResponse:
        model = kwargs.get("model") or "default"
        payload: Dict[str, Any] = {
            "provider": self._provider,
            "model": model,
            "messages": kwargs.get("messages", []),
            "temperature": kwargs.get("temperature"),
            "max_tokens": kwargs.get("max_tokens"),
        }
        data = self._homer._server.request("POST", "/v1/invoke", json=payload)
        enrichment = self._homer._parse_enrichment(data.get("enrichment", {}), envelope=data)

        content = data.get("content", "")
        raw = _AnthropicRawResponse(
            id=data.get("raw_response", {}).get("id", "") if isinstance(data.get("raw_response"), dict) else "",
            model=data.get("model", model),
            content=[_AnthropicTextBlock(type="text", text=content)],
            stop_reason="end_turn",
            usage=data.get("raw_response", {}).get("usage", {}) if isinstance(data.get("raw_response"), dict) else {},
        )

        return HomerResponse(raw_response=raw, homer=enrichment)


class _AnthropicThinClient:
    def __init__(self, messages_proxy: _AnthropicMessagesProxy):
        self.messages = messages_proxy


class _ContextProxy:
    def __init__(self, server: _ServerClient):
        self._server = server

    def put(self, tenant_id: str, key: str, value: Dict[str, Any], ttl_seconds: Optional[int] = None):
        return self._server.request(
            "POST",
            "/v1/context",
            json={"key": key, "value": value, "ttl_seconds": ttl_seconds},
            headers={"X-Homer-Tenant-ID": tenant_id},
        )

    def get(self, tenant_id: str, key: str):
        return self._server.request("GET", f"/v1/context/{key}", headers={"X-Homer-Tenant-ID": tenant_id})

    def list_keys(self, tenant_id: str):
        data = self._server.request("GET", "/v1/context", headers={"X-Homer-Tenant-ID": tenant_id})
        return data.get("keys", [])

    def append_event(self, tenant_id: str, key: str, event: Dict[str, Any]):
        return self._server.request(
            "POST",
            f"/v1/context/{key}/events",
            json={"event": event},
            headers={"X-Homer-Tenant-ID": tenant_id},
        )

    def list_events(self, tenant_id: str, key: str):
        data = self._server.request("GET", f"/v1/context/{key}/events", headers={"X-Homer-Tenant-ID": tenant_id})
        return data.get("events", [])

    def delete(self, tenant_id: str, key: str):
        return self._server.request("DELETE", f"/v1/context/{key}", headers={"X-Homer-Tenant-ID": tenant_id})


class Homer:
    """Thin SDK client. All intelligence runs on Homer Server."""

    def __init__(
        self,
        config: Optional[HomerConfig] = None,
        server_url: Optional[str] = None,
        api_key: Optional[str] = None,
        request_timeout_seconds: Optional[int] = None,
        **_: Any,
    ):
        self._config = config or HomerConfig()
        if server_url:
            self._config.server_url = server_url
        if api_key:
            self._config.api_key = api_key
        if request_timeout_seconds is not None:
            self._config.request_timeout_seconds = request_timeout_seconds

        self._server = _ServerClient(self._config)
        self._context = _ContextProxy(self._server)

    def health(self) -> Dict[str, Any]:
        return self._server.request("GET", "/v1/health")

    def openai(self, **kwargs) -> _OpenAIThinClient:
        return _OpenAIThinClient(_CompletionsProxy(self, provider="openai", provider_defaults=kwargs))

    def anthropic(self, **kwargs) -> _AnthropicThinClient:
        return _AnthropicThinClient(_AnthropicMessagesProxy(self, provider="anthropic"))

    def azure_openai(self, **kwargs) -> _OpenAIThinClient:
        return _OpenAIThinClient(_CompletionsProxy(self, provider="azure_openai", provider_defaults=kwargs))

    def broker(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        default_model: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        **_: Any,
    ) -> _OpenAIThinClient:
        return _OpenAIThinClient(
            _CompletionsProxy(
                self,
                provider="broker",
                provider_defaults={
                    "base_url": base_url,
                    "api_key": api_key,
                    "default_model": default_model,
                    "headers": headers,
                },
            )
        )

    def gateway(self, *args, **kwargs) -> _OpenAIThinClient:
        return self.broker(*args, **kwargs)

    def invoke(
        self,
        provider: str = "openai",
        model: str = "gpt-4o-mini",
        messages: Optional[List[Dict[str, Any]]] = None,
        tenant_id: Optional[str] = None,
        context_key: Optional[str] = None,
        **kwargs,
    ) -> HomerResponse:
        payload: Dict[str, Any] = {
            "provider": provider,
            "model": model,
            "messages": messages or [],
            "tenant_id": tenant_id,
            "context_key": context_key,
            "temperature": kwargs.get("temperature"),
            "max_tokens": kwargs.get("max_tokens"),
        }
        if kwargs.get("policies") is not None:
            payload["policies"] = kwargs.get("policies")
        if kwargs.get("execution") is not None:
            payload["execution"] = kwargs.get("execution")
        if kwargs.get("broker_base_url") is not None:
            payload["broker_base_url"] = kwargs.get("broker_base_url")
        if kwargs.get("broker_api_key") is not None:
            broker_api_key = kwargs.get("broker_api_key")
            if broker_api_key and not self._server.is_transport_secure():
                raise ValueError(
                    "Refusing to send broker_api_key over insecure Homer Server transport. "
                    "Use HTTPS for HOMER_SERVER_URL or omit broker_api_key."
                )
            payload["broker_api_key"] = broker_api_key
        if kwargs.get("broker_headers") is not None:
            payload["broker_headers"] = kwargs.get("broker_headers")
        data = self._server.request("POST", "/v1/invoke", json=payload)
        enrichment = self._parse_enrichment(data.get("enrichment", {}), envelope=data)
        return HomerResponse(raw_response=data, homer=enrichment)

    def classify(self, text: str) -> Dict[str, Any]:
        return self._server.request("POST", "/v1/classify", json={"text": text})

    def extract_norms(self, text: str) -> List[Dict[str, Any]]:
        data = self._server.request("POST", "/v1/extract-norms", json={"text": text})
        return data.get("norms", [])

    def score_confidence(self, text: str) -> Dict[str, Any]:
        return self._server.request("POST", "/v1/score-confidence", json={"text": text})

    def detect_modality(self, text: str) -> Dict[str, Any]:
        return self._server.request("POST", "/v1/detect-modality", json={"text": text})

    def analyze(self, text: str) -> HomerEnrichment:
        data = self._server.request("POST", "/v1/analyze", json={"text": text})
        return self._parse_enrichment(data)

    # Semantic management + reasoning APIs
    def get_glossary(self) -> Dict[str, Any]:
        return self._server.request("GET", "/v1/semantic/glossary")

    def list_glossary_versions(self) -> Dict[str, Any]:
        return self._server.request("GET", "/v1/semantic/glossary/versions")

    def create_glossary_version(
        self,
        terms: List[Dict[str, Any]],
        version_id: Optional[str] = None,
        description: str = "",
        activate: bool = True,
    ) -> Dict[str, Any]:
        return self._server.request(
            "POST",
            "/v1/semantic/glossary/versions",
            json={
                "terms": terms,
                "version_id": version_id,
                "description": description,
                "activate": activate,
            },
        )

    def activate_glossary(self, version_id: str) -> Dict[str, Any]:
        return self._server.request("POST", "/v1/semantic/glossary/activate", json={"version_id": version_id})

    def get_ontology(self) -> Dict[str, Any]:
        return self._server.request("GET", "/v1/semantic/ontology")

    def set_ontology(
        self,
        model: Dict[str, Any],
        model_id: Optional[str] = None,
        source: str = "api",
        activate: bool = True,
    ) -> Dict[str, Any]:
        return self._server.request(
            "POST",
            "/v1/semantic/ontology",
            json={
                "model": model,
                "model_id": model_id,
                "source": source,
                "activate": activate,
            },
        )

    def load_ontology_file(
        self,
        path: str,
        model_id: Optional[str] = None,
        source: str = "file",
        activate: bool = True,
    ) -> Dict[str, Any]:
        return self._server.request(
            "POST",
            "/v1/semantic/ontology/load-file",
            json={
                "path": path,
                "model_id": model_id,
                "source": source,
                "activate": activate,
            },
        )

    def activate_ontology(self, model_id: str) -> Dict[str, Any]:
        return self._server.request("POST", "/v1/semantic/ontology/activate", json={"model_id": model_id})

    def graph_path(self, source_id: str, target_id: str, max_depth: int = 4) -> Dict[str, Any]:
        return self._server.request(
            "GET",
            "/v1/semantic/graph/path",
            params={"source_id": source_id, "target_id": target_id, "max_depth": max_depth},
        )

    def graph_conflicts(self, limit: int = 500) -> Dict[str, Any]:
        return self._server.request("GET", "/v1/semantic/graph/conflicts", params={"limit": limit})

    def graph_propagate(self, seed_term_id: str, depth: int = 2) -> Dict[str, Any]:
        return self._server.request(
            "GET",
            "/v1/semantic/graph/propagate",
            params={"seed_term_id": seed_term_id, "depth": depth},
        )

    def graph_blast_radius(
        self,
        node_id: str,
        depth: int = 3,
        direction: str = "outgoing",
        relation: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "node_id": node_id,
            "depth": depth,
            "direction": direction,
        }
        if relation:
            params["relation"] = relation
        return self._server.request("GET", "/v1/semantic/graph/blast-radius", params=params)

    @property
    def context(self) -> _ContextProxy:
        return self._context

    @property
    def finintel(self):
        raise NotImplementedError(
            "FinIntel is not included in the generic homer-sdk package. "
            "Use the dedicated FinIntel SDK/server package."
        )

    def _parse_enrichment(self, data: Dict[str, Any], envelope: Optional[Dict[str, Any]] = None) -> HomerEnrichment:
        cls = data.get("classification") or {}
        conf = data.get("confidence") or {}

        norms: List[Norm] = []
        for n in data.get("norms", []):
            norm_type = n.get("norm_type", "guidance")
            try:
                nt = NormType(norm_type)
            except ValueError:
                nt = NormType.GUIDANCE

            c = n.get("confidence") or {}
            norm_conf = None
            if c:
                norm_conf = NormConfidence(
                    deontic=float(c.get("deontic", 0.0)),
                    atomicity=float(c.get("atomicity", 1.0)),
                    composite=float(c.get("composite", 0.0)),
                )

            norms.append(
                Norm(
                    norm_id=n.get("norm_id", ""),
                    norm_type=nt,
                    source_sentence=n.get("source_sentence", ""),
                    subject_role_id=n.get("subject_role_id"),
                    extracted_subject_phrase=n.get("extracted_subject_phrase"),
                    action=n.get("action"),
                    confidence=norm_conf,
                )
            )

        violations = [
            Violation(
                invariant_id=int(v.get("invariant_id", 0)),
                artifact_id=v.get("artifact_id", ""),
                message=v.get("message", ""),
                action_taken=v.get("action_taken", "logged"),
            )
            for v in data.get("violations", [])
        ]

        enrichment = HomerEnrichment(
            classification=ContentClassification(
                purpose=cls.get("purpose", "unknown"),
                structure=cls.get("structure", "unknown"),
                domain=cls.get("domain", "unknown"),
            ) if cls else None,
            norms=norms,
            confidence=ConfidenceResult(
                structural_quality=float(conf.get("structural_quality", 0.0)),
                semantic_validity=float(conf.get("semantic_validity", 0.0)),
                aggregate=float(conf.get("aggregate", 0.0)),
                breakdown=conf.get("breakdown", {}),
                quality_flags=conf.get("quality_flags", []),
            ) if conf else None,
            violations=violations,
            modality=data.get("modality"),
            schema_version=int(data.get("schema_version", 1)),
        )
        if "semantic" in data:
            enrichment.metadata["semantic"] = data.get("semantic")

        env = envelope or {}
        trace = env.get("trace") or {}
        if trace:
            enrichment.trace = TraceInfo(
                trace_id=trace.get("trace_id", ""),
                request_id=trace.get("request_id", ""),
                tenant_id=trace.get("tenant_id", ""),
                provider=env.get("provider", ""),
                model=env.get("model", ""),
                latency_ms=int(round(trace.get("latency_ms", 0))),
            )

        pol = env.get("policy") or {}
        if pol:
            enrichment.policy = PolicyDecision(
                phase="output",
                decision=pol.get("decision", "pass"),
                violations=violations,
                tenant_id=trace.get("tenant_id", "") if trace else "",
                trace_id=trace.get("trace_id", "") if trace else "",
            )

        audit = env.get("audit") or {}
        if audit:
            enrichment.audit = AuditRecord(
                tenant_id=audit.get("tenant_id", ""),
                provider=audit.get("provider", ""),
                model=audit.get("model", ""),
                timestamp=float(audit.get("timestamp", 0.0)),
                policy_decision=pol.get("decision", "pass") if pol else "pass",
                trace_id=trace.get("trace_id", "") if trace else "",
                request_id=trace.get("request_id", "") if trace else "",
                latency_ms=int(round(trace.get("latency_ms", 0))) if trace else 0,
            )

        return enrichment
