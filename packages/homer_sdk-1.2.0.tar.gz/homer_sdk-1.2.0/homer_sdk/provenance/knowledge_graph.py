"""
Knowledge Graph - Complete provenance tracking for AI decisions.

Connects data, features, models, prompts, decisions, and outcomes
in a directed graph that enables full lineage tracing.

Node types:
- data: Raw input data (documents, datasets)
- feature: Extracted features (embeddings, classifications)
- model: AI models used (gpt-4, claude, etc.)
- prompt: Prompts/instructions sent to models
- decision: Decisions made by AI
- outcome: Results and their impact
- policy: Governance rules applied
- context: Temporal/spatial context

Edge types:
- derived_from: B was derived from A
- input_to: A was input to B
- produced_by: A was produced by model B
- governed_by: A was governed by policy B
- led_to: decision A led to outcome B
- version_of: B is a new version of A

Usage:
    graph = KnowledgeGraph()

    data_node = graph.add_node("data", {"source": "trade_blotter.csv"})
    prompt_node = graph.add_node("prompt", {"text": "Analyze compliance..."})
    model_node = graph.add_node("model", {"name": "gpt-4", "version": "0613"})
    decision_node = graph.add_node("decision", {"result": "non_compliant"})

    graph.add_edge(data_node, prompt_node, "input_to")
    graph.add_edge(prompt_node, model_node, "input_to")
    graph.add_edge(model_node, decision_node, "produced_by")

    # Trace full lineage
    lineage = graph.trace_lineage(decision_node)
"""

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


VALID_NODE_TYPES = {"data", "feature", "model", "prompt", "decision", "outcome", "policy", "context"}
VALID_EDGE_TYPES = {"derived_from", "input_to", "produced_by", "governed_by", "led_to", "version_of", "evaluated_by", "triggered"}


@dataclass
class ProvenanceNode:
    node_id: str
    node_type: str
    properties: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ProvenanceEdge:
    edge_id: str
    source_id: str
    target_id: str
    edge_type: str
    properties: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class KnowledgeGraph:

    def __init__(self, database_url: Optional[str] = None):
        self._nodes: Dict[str, ProvenanceNode] = {}
        self._edges: List[ProvenanceEdge] = []
        self._adjacency: Dict[str, List[str]] = {}
        self._reverse_adjacency: Dict[str, List[str]] = {}
        self._db_url = database_url or os.environ.get("DATABASE_URL")
        self._db_initialized = False

        if self._db_url:
            try:
                self._init_db()
                self._load_from_db()
            except Exception as e:
                logger.warning(f"Provenance DB init failed, using in-memory: {e}")
                self._db_url = None

    def _init_db(self):
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS homer_provenance_nodes (
                        node_id VARCHAR(64) PRIMARY KEY,
                        node_type VARCHAR(32) NOT NULL,
                        properties JSONB NOT NULL DEFAULT '{}'::jsonb,
                        timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        metadata JSONB DEFAULT '{}'::jsonb
                    );
                    CREATE INDEX IF NOT EXISTS idx_prov_nodes_type
                        ON homer_provenance_nodes (node_type);

                    CREATE TABLE IF NOT EXISTS homer_provenance_edges (
                        edge_id VARCHAR(64) PRIMARY KEY,
                        source_id VARCHAR(64) NOT NULL REFERENCES homer_provenance_nodes(node_id),
                        target_id VARCHAR(64) NOT NULL REFERENCES homer_provenance_nodes(node_id),
                        edge_type VARCHAR(32) NOT NULL,
                        properties JSONB NOT NULL DEFAULT '{}'::jsonb,
                        timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
                    );
                    CREATE INDEX IF NOT EXISTS idx_prov_edges_source
                        ON homer_provenance_edges (source_id);
                    CREATE INDEX IF NOT EXISTS idx_prov_edges_target
                        ON homer_provenance_edges (target_id);
                    CREATE INDEX IF NOT EXISTS idx_prov_edges_type
                        ON homer_provenance_edges (edge_type);
                """)
            conn.commit()
            self._db_initialized = True
        finally:
            conn.close()

    def _load_from_db(self):
        if not self._db_initialized:
            return
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT node_id, node_type, properties, timestamp, metadata "
                    "FROM homer_provenance_nodes ORDER BY timestamp ASC"
                )
                for row in cur.fetchall():
                    node = ProvenanceNode(
                        node_id=row[0], node_type=row[1],
                        properties=row[2] or {},
                        timestamp=row[3].isoformat() if hasattr(row[3], 'isoformat') else str(row[3]),
                        metadata=row[4] or {},
                    )
                    self._nodes[node.node_id] = node
                    self._adjacency.setdefault(node.node_id, [])
                    self._reverse_adjacency.setdefault(node.node_id, [])

                cur.execute(
                    "SELECT edge_id, source_id, target_id, edge_type, properties, timestamp "
                    "FROM homer_provenance_edges ORDER BY timestamp ASC"
                )
                for row in cur.fetchall():
                    edge = ProvenanceEdge(
                        edge_id=row[0], source_id=row[1], target_id=row[2],
                        edge_type=row[3], properties=row[4] or {},
                        timestamp=row[5].isoformat() if hasattr(row[5], 'isoformat') else str(row[5]),
                    )
                    self._edges.append(edge)
                    self._adjacency.setdefault(edge.source_id, []).append(edge.target_id)
                    self._reverse_adjacency.setdefault(edge.target_id, []).append(edge.source_id)

            logger.info(f"Loaded {len(self._nodes)} nodes and {len(self._edges)} edges from DB")
        finally:
            conn.close()

    def add_node(
        self,
        node_type: str,
        properties: Optional[Dict[str, Any]] = None,
        node_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        if node_type not in VALID_NODE_TYPES:
            raise ValueError(f"Invalid node type '{node_type}'. Must be one of: {VALID_NODE_TYPES}")

        node_id = node_id or f"pn_{uuid.uuid4().hex[:12]}"
        now = datetime.now(timezone.utc).isoformat()

        node = ProvenanceNode(
            node_id=node_id,
            node_type=node_type,
            properties=properties or {},
            timestamp=now,
            metadata=metadata or {},
        )

        self._nodes[node_id] = node
        self._adjacency.setdefault(node_id, [])
        self._reverse_adjacency.setdefault(node_id, [])

        if self._db_initialized:
            self._persist_node(node)

        return node_id

    def add_edge(
        self,
        source_id: str,
        target_id: str,
        edge_type: str,
        properties: Optional[Dict[str, Any]] = None,
    ) -> str:
        if edge_type not in VALID_EDGE_TYPES:
            raise ValueError(f"Invalid edge type '{edge_type}'. Must be one of: {VALID_EDGE_TYPES}")

        edge_id = f"pe_{uuid.uuid4().hex[:12]}"
        now = datetime.now(timezone.utc).isoformat()

        edge = ProvenanceEdge(
            edge_id=edge_id,
            source_id=source_id,
            target_id=target_id,
            edge_type=edge_type,
            properties=properties or {},
            timestamp=now,
        )

        self._edges.append(edge)
        self._adjacency.setdefault(source_id, []).append(target_id)
        self._reverse_adjacency.setdefault(target_id, []).append(source_id)

        if self._db_initialized:
            self._persist_edge(edge)

        return edge_id

    def _persist_node(self, node: ProvenanceNode):
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO homer_provenance_nodes
                    (node_id, node_type, properties, timestamp, metadata)
                    VALUES (%s,%s,%s,%s,%s)
                    ON CONFLICT (node_id) DO UPDATE SET
                        properties = EXCLUDED.properties,
                        metadata = EXCLUDED.metadata""",
                    (node.node_id, node.node_type,
                     json.dumps(node.properties, default=str),
                     node.timestamp,
                     json.dumps(node.metadata, default=str)),
                )
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Failed to persist node {node.node_id}: {e}")
        finally:
            conn.close()

    def _persist_edge(self, edge: ProvenanceEdge):
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO homer_provenance_edges
                    (edge_id, source_id, target_id, edge_type, properties, timestamp)
                    VALUES (%s,%s,%s,%s,%s,%s)""",
                    (edge.edge_id, edge.source_id, edge.target_id,
                     edge.edge_type,
                     json.dumps(edge.properties, default=str),
                     edge.timestamp),
                )
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Failed to persist edge {edge.edge_id}: {e}")
        finally:
            conn.close()

    def trace_lineage(self, node_id: str, direction: str = "upstream") -> List[ProvenanceNode]:
        visited: Set[str] = set()
        result: List[ProvenanceNode] = []

        def _traverse(nid: str):
            if nid in visited:
                return
            visited.add(nid)

            node = self._nodes.get(nid)
            if node:
                result.append(node)

            adj = self._reverse_adjacency if direction == "upstream" else self._adjacency
            for neighbor in adj.get(nid, []):
                _traverse(neighbor)

        _traverse(node_id)
        return result

    def trace_downstream(self, node_id: str) -> List[ProvenanceNode]:
        return self.trace_lineage(node_id, direction="downstream")

    def get_node(self, node_id: str) -> Optional[ProvenanceNode]:
        return self._nodes.get(node_id)

    def get_edges(self, node_id: str, direction: str = "outgoing") -> List[ProvenanceEdge]:
        if direction == "outgoing":
            return [e for e in self._edges if e.source_id == node_id]
        else:
            return [e for e in self._edges if e.target_id == node_id]

    def find_nodes(self, node_type: Optional[str] = None, **property_filters) -> List[ProvenanceNode]:
        results = []
        for node in self._nodes.values():
            if node_type and node.node_type != node_type:
                continue
            match = True
            for key, value in property_filters.items():
                if node.properties.get(key) != value:
                    match = False
                    break
            if match:
                results.append(node)
        return results

    def get_full_provenance(self, decision_node_id: str) -> Dict[str, Any]:
        upstream = self.trace_lineage(decision_node_id, "upstream")
        downstream = self.trace_lineage(decision_node_id, "downstream")

        by_type: Dict[str, List[dict]] = {}
        all_nodes = {n.node_id: n for n in upstream + downstream}
        for node in all_nodes.values():
            by_type.setdefault(node.node_type, []).append(node.to_dict())

        relevant_edges = [
            e.to_dict() for e in self._edges
            if e.source_id in all_nodes or e.target_id in all_nodes
        ]

        return {
            "decision_node": decision_node_id,
            "nodes_by_type": by_type,
            "total_nodes": len(all_nodes),
            "edges": relevant_edges,
            "total_edges": len(relevant_edges),
        }

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": [n.to_dict() for n in self._nodes.values()],
            "edges": [e.to_dict() for e in self._edges],
        }

    @property
    def node_count(self) -> int:
        return len(self._nodes)

    @property
    def edge_count(self) -> int:
        return len(self._edges)
