"""
Homer SDK Configuration.

Centralized configuration with environment variable support.
"""

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class RetryConfig:
    max_retries: int = 3
    base_delay_ms: int = 500
    max_delay_ms: int = 10000
    exponential_base: float = 2.0
    jitter: bool = True
    retryable_status_codes: List[int] = field(default_factory=lambda: [429, 500, 502, 503, 504])


@dataclass
class CircuitBreakerConfig:
    failure_threshold: int = 5
    recovery_timeout_seconds: int = 30
    half_open_max_calls: int = 1


@dataclass
class ReliabilityConfig:
    timeout_seconds: int = 120
    retry: RetryConfig = field(default_factory=RetryConfig)
    circuit_breaker: CircuitBreakerConfig = field(default_factory=CircuitBreakerConfig)
    fallback_providers: List[str] = field(default_factory=list)
    idempotency_key_header: str = "X-Homer-Idempotency-Key"


@dataclass
class ContextStoreConfig:
    backend: str = "memory"
    redis_url: Optional[str] = None
    database_url: Optional[str] = None
    default_ttl_seconds: Optional[int] = None


@dataclass
class TelemetryConfig:
    enabled: bool = True
    trace_all_calls: bool = True
    metrics_prefix: str = "homer"
    log_level: str = "INFO"


@dataclass
class HomerConfig:
    schema_version: int = 1
    tenant_mode: str = "optional"
    policy_strict: bool = True

    database_url: Optional[str] = None

    reliability: ReliabilityConfig = field(default_factory=ReliabilityConfig)
    context_store: ContextStoreConfig = field(default_factory=ContextStoreConfig)
    telemetry: TelemetryConfig = field(default_factory=TelemetryConfig)

    enable_ledger: bool = False
    enable_temporal: bool = False
    enable_provenance: bool = False

    integrity_level: str = "L1"

    policy_files: List[str] = field(default_factory=list)
    policies: List[str] = field(default_factory=list)
    server_url: str = "http://localhost:8000"
    api_key: Optional[str] = None
    request_timeout_seconds: int = 60
    verify_ssl: bool = True

    def __post_init__(self):
        self.tenant_mode = os.environ.get("HOMER_DEFAULT_TENANT_MODE", self.tenant_mode)
        self.policy_strict = os.environ.get("HOMER_POLICY_STRICT", str(self.policy_strict)).lower() == "true"
        sv = os.environ.get("HOMER_SCHEMA_VERSION")
        if sv:
            self.schema_version = int(sv)
        if not self.database_url:
            self.database_url = os.environ.get("DATABASE_URL")
        if not self.context_store.redis_url:
            self.context_store.redis_url = os.environ.get("HOMER_CONTEXT_REDIS_URL")
        if not self.context_store.database_url:
            self.context_store.database_url = self.database_url
        self.server_url = os.environ.get("HOMER_SERVER_URL", self.server_url)
        if not self.api_key:
            self.api_key = os.environ.get("HOMER_API_KEY")
        rt = os.environ.get("HOMER_REQUEST_TIMEOUT_SECONDS")
        if rt:
            self.request_timeout_seconds = int(rt)
        verify_ssl = os.environ.get("HOMER_VERIFY_SSL")
        if verify_ssl is not None:
            self.verify_ssl = verify_ssl.lower() in ("1", "true", "yes")

    @classmethod
    def from_env(cls) -> "HomerConfig":
        return cls()
