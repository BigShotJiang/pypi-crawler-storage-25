"""
Middleware system for Homer SDK.

Middleware intercepts AI calls at three phases:
- before_call: Process/validate input before sending to AI
- after_call: Process/validate output after receiving from AI
- on_error: Handle errors during AI calls

Usage:
    class LoggingMiddleware(Middleware):
        def before_call(self, messages, context):
            print(f"Sending {len(messages)} messages")
            return messages

        def after_call(self, response, context):
            print(f"Received response")
            return response

    homer = Homer(middleware=[LoggingMiddleware()])
"""

import logging
import time
from typing import Any, Dict, List, Optional, Callable
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class CallContext:
    provider: str = ""
    model: str = ""
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timings: Dict[str, float] = field(default_factory=dict)


class Middleware:
    def before_call(self, messages: Any, context: CallContext) -> Any:
        return messages

    def after_call(self, response: Any, context: CallContext) -> Any:
        return response

    def on_error(self, error: Exception, context: CallContext) -> Optional[Any]:
        return None


class MiddlewareChain:
    def __init__(self, middlewares: Optional[List[Middleware]] = None):
        self.middlewares = middlewares or []

    def add(self, middleware: Middleware):
        self.middlewares.append(middleware)

    def run_before(self, messages: Any, context: CallContext) -> Any:
        for mw in self.middlewares:
            try:
                result = mw.before_call(messages, context)
                if result is not None:
                    messages = result
            except Exception as e:
                logger.error(f"Middleware {mw.__class__.__name__}.before_call failed: {e}")
                raise
        return messages

    def run_after(self, response: Any, context: CallContext) -> Any:
        for mw in reversed(self.middlewares):
            try:
                result = mw.after_call(response, context)
                if result is not None:
                    response = result
            except Exception as e:
                logger.error(f"Middleware {mw.__class__.__name__}.after_call failed: {e}")
                raise
        return response

    def run_error(self, error: Exception, context: CallContext) -> Optional[Any]:
        for mw in reversed(self.middlewares):
            try:
                result = mw.on_error(error, context)
                if result is not None:
                    return result
            except Exception:
                pass
        return None


class AuditMiddleware(Middleware):
    MAX_LOG_SIZE = 5000

    def __init__(self, max_log_size: int = MAX_LOG_SIZE):
        from collections import deque
        self.log: deque = deque(maxlen=max_log_size)

    def before_call(self, messages: Any, context: CallContext) -> Any:
        context.timings["start"] = time.time()
        self.log.append({
            "phase": "before",
            "provider": context.provider,
            "model": context.model,
            "timestamp": context.timestamp,
        })
        return messages

    def after_call(self, response: Any, context: CallContext) -> Any:
        elapsed = time.time() - context.timings.get("start", time.time())
        context.timings["duration"] = elapsed
        self.log.append({
            "phase": "after",
            "provider": context.provider,
            "model": context.model,
            "duration_ms": round(elapsed * 1000),
        })
        return response


class PolicyMiddleware(Middleware):
    """
    Middleware that enforces policy rules on inputs (before_call).
    Output enforcement is handled by the provider's enrichment pipeline,
    ensuring a single authoritative enforcement path.
    """

    def __init__(self, policy_engine):
        self.policy_engine = policy_engine

    def before_call(self, messages: Any, context: CallContext) -> Any:
        if isinstance(messages, list):
            for msg in messages:
                if not isinstance(msg, dict):
                    continue
                content = msg.get("content", "")
                if content and msg.get("role") != "system":
                    passed, violations = self.policy_engine.enforce_input(content)
                    if not passed:
                        error_violations = [v for v in violations if v.severity == "error"]
                        if error_violations:
                            raise ValueError(
                                f"Homer policy violation (input): "
                                f"{error_violations[0].rule_name} - {error_violations[0].description}"
                            )
        return messages
