"""
Base provider interface for Homer SDK.

All AI provider wrappers inherit from this.
Includes shared enrichment pipeline used by all providers.
"""

from typing import Any, Dict, List, Optional
from homer_sdk.middleware.base import MiddlewareChain, CallContext
from homer_sdk.types import HomerEnrichment, Violation


class BaseProvider:
    def __init__(
        self,
        provider_name: str,
        middleware_chain: Optional[MiddlewareChain] = None,
        intelligence=None,
        guards=None,
    ):
        self.provider_name = provider_name
        self.middleware_chain = middleware_chain or MiddlewareChain()
        self._intelligence = intelligence
        self._guards = guards

    SENSITIVE_KEYS = {"api_key", "api_secret", "token", "password", "secret", "authorization"}

    def _create_context(self, model: str = "", **kwargs) -> CallContext:
        safe_metadata = {
            k: v for k, v in kwargs.items()
            if k.lower() not in self.SENSITIVE_KEYS
        }
        return CallContext(
            provider=self.provider_name,
            model=model,
            metadata=safe_metadata,
        )

    def _enrich(self, response_text: str, input_text: str, context: CallContext) -> HomerEnrichment:
        import logging
        _logger = logging.getLogger(__name__)
        enrichment = HomerEnrichment()
        combined_text = input_text + "\n" + response_text

        if self._intelligence:
            try:
                classifier = self._intelligence.get("classifier")
                if classifier:
                    enrichment.classification = classifier.classify(combined_text)
            except Exception as e:
                _logger.warning(f"Classification failed (non-fatal): {e}")

            try:
                norm_extractor = self._intelligence.get("norm_extractor")
                if norm_extractor and response_text:
                    norms = norm_extractor.extract(response_text)

                    role_resolver = self._intelligence.get("role_resolver")
                    if role_resolver:
                        for norm in norms:
                            if norm.extracted_subject_phrase:
                                try:
                                    binding = role_resolver.resolve(
                                        norm.extracted_subject_phrase,
                                        norm_type=norm.norm_type.value,
                                    )
                                    if binding.status == "bound":
                                        norm.subject_role_id = binding.role_id
                                        if norm.confidence:
                                            norm.confidence.actor_binding = binding.confidence
                                except Exception as e:
                                    _logger.warning(f"Role binding failed for norm {norm.norm_id}: {e}")

                        enrichment.roles_detected = list(set(
                            n.subject_role_id for n in norms
                            if n.subject_role_id and n.subject_role_id not in (None, "", "split_required", "role_unspecified")
                        ))

                    pipeline_guard = self._guards.get("pipeline_guard") if self._guards else None
                    if pipeline_guard:
                        pipeline_guard.reset()
                        role_ids = set(enrichment.roles_detected)
                        valid_norms = pipeline_guard.filter_norms(norms, role_ids)
                        enrichment.guard_stats = pipeline_guard.get_stats()
                        enrichment.violations.extend(pipeline_guard.violations)
                        enrichment.norms = valid_norms
                    else:
                        enrichment.norms = norms
            except Exception as e:
                _logger.warning(f"Norm extraction failed (non-fatal): {e}")

            try:
                confidence_scorer = self._intelligence.get("confidence_scorer")
                if confidence_scorer and response_text:
                    enrichment.confidence = confidence_scorer.score(response_text)
            except Exception as e:
                _logger.warning(f"Confidence scoring failed (non-fatal): {e}")

            try:
                modality_analyzer = self._intelligence.get("modality_analyzer")
                if modality_analyzer and response_text:
                    enrichment.modality = modality_analyzer.detect(response_text).value
            except Exception as e:
                _logger.warning(f"Modality analysis failed (non-fatal): {e}")

        if self._guards:
            try:
                pipeline_guard = self._guards.get("pipeline_guard")
                if pipeline_guard and response_text:
                    pipeline_guard.reset()
                    is_valid, response_violations = pipeline_guard.validate_response(response_text)
                    enrichment.violations.extend(response_violations)
            except Exception as e:
                _logger.warning(f"Response validation failed (non-fatal): {e}")

            try:
                policy_engine = self._guards.get("policy_engine")
                if policy_engine and response_text:
                    passed, policy_violations = policy_engine.enforce_output(response_text)
                    enrichment.policy_enforced = True
                    if policy_violations:
                        for pv in policy_violations:
                            enrichment.violations.append(Violation(
                                invariant_id=0,
                                artifact_id="policy",
                                message=f"{pv.rule_name}: {pv.description}",
                                action_taken="blocked" if pv.severity == "error" else "flagged",
                            ))
            except Exception as e:
                _logger.warning(f"Policy enforcement failed (non-fatal): {e}")

        enrichment.metadata["provider"] = self.provider_name

        return enrichment

    @staticmethod
    def _extract_user_text(messages) -> str:
        input_text = ""
        for msg in messages:
            if isinstance(msg, dict) and msg.get("role") == "user":
                content = msg.get("content", "")
                if isinstance(content, str):
                    input_text += content + "\n"
                elif isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "text":
                            input_text += block.get("text", "") + "\n"
        return input_text
