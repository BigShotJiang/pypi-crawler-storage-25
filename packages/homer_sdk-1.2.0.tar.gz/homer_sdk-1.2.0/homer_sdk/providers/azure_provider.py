"""
Azure OpenAI Provider - Wraps the Azure OpenAI SDK with Homer intelligence.

Usage:
    from homer_sdk import Homer

    homer = Homer()
    client = homer.azure_openai(
        api_key="...",
        azure_endpoint="https://my-resource.openai.azure.com",
        api_version="2024-02-01"
    )

    response = client.chat.completions.create(
        model="gpt-4",  # deployment name
        messages=[{"role": "user", "content": "..."}]
    )

    print(response.choices[0].message.content)
    print(response.homer.classification)
"""

import logging
from typing import Optional

from homer_sdk.providers.openai_provider import OpenAIProvider, HomerChat
from homer_sdk.providers.base import BaseProvider
from homer_sdk.middleware.base import MiddlewareChain

logger = logging.getLogger(__name__)


class AzureOpenAIProvider(OpenAIProvider):
    def __init__(
        self,
        api_key: Optional[str] = None,
        azure_endpoint: Optional[str] = None,
        api_version: str = "2024-02-01",
        middleware_chain: Optional[MiddlewareChain] = None,
        intelligence=None,
        guards=None,
        **azure_kwargs,
    ):
        BaseProvider.__init__(self, "azure_openai", middleware_chain, intelligence, guards)

        try:
            from openai import AzureOpenAI
            client_kwargs = {}
            if api_key:
                client_kwargs["api_key"] = api_key
            if azure_endpoint:
                client_kwargs["azure_endpoint"] = azure_endpoint
            client_kwargs["api_version"] = api_version
            client_kwargs.update(azure_kwargs)
            self._client = AzureOpenAI(**client_kwargs)
        except ImportError:
            raise ImportError(
                "OpenAI package not installed. Install it with: pip install openai"
            )

        self._azure_endpoint = azure_endpoint
        self.chat = HomerChat(self)
