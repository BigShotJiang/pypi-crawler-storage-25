"""
Broker Provider - Generic HTTP broker for any LLM API.

Works with any OpenAI-compatible API endpoint (vLLM, Ollama, LiteLLM,
Together AI, Groq, Fireworks, local models, etc.).

Homer sits between your application and ANY LLM endpoint, applying
the full intelligence pipeline regardless of provider.

Usage:
    from homer_sdk import Homer

    homer = Homer(policies=["no_pii"])

    # Local Ollama
    client = homer.broker(base_url="http://localhost:11434/v1")

    # Together AI
    client = homer.broker(
        base_url="https://api.together.xyz/v1",
        api_key="...",
        default_model="meta-llama/Llama-3-70b-chat-hf"
    )

    response = client.chat.completions.create(
        model="llama3",
        messages=[{"role": "user", "content": "..."}]
    )

    print(response.choices[0].message.content)
    print(response.homer.classification)
"""

import logging
import time
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

import requests

from homer_sdk.providers.base import BaseProvider
from homer_sdk.middleware.base import MiddlewareChain, CallContext
from homer_sdk.types import HomerResponse

logger = logging.getLogger(__name__)


@dataclass
class BrokerMessage:
    role: str = ""
    content: str = ""


@dataclass
class BrokerChoice:
    index: int = 0
    message: BrokerMessage = field(default_factory=BrokerMessage)
    finish_reason: str = "stop"


@dataclass
class BrokerRawResponse:
    id: str = ""
    model: str = ""
    choices: List[BrokerChoice] = field(default_factory=list)
    usage: Dict[str, int] = field(default_factory=dict)
    _raw: Dict[str, Any] = field(default_factory=dict)


class BrokerCompletions:
    def __init__(self, provider: "BrokerProvider"):
        self._provider = provider

    def create(self, **kwargs) -> HomerResponse:
        return self._provider._completions_create(**kwargs)


class BrokerChat:
    def __init__(self, provider: "BrokerProvider"):
        self.completions = BrokerCompletions(provider)


class BrokerProvider(BaseProvider):
    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        default_model: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 120,
        middleware_chain: Optional[MiddlewareChain] = None,
        intelligence=None,
        guards=None,
    ):
        super().__init__("broker", middleware_chain, intelligence, guards)
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._default_model = default_model
        self._timeout = timeout

        self._session = requests.Session()
        self._session.headers.update({"Content-Type": "application/json"})
        if api_key:
            self._session.headers["Authorization"] = f"Bearer {api_key}"
        if headers:
            self._session.headers.update(headers)

        self.chat = BrokerChat(self)

    def _completions_create(self, **kwargs) -> HomerResponse:
        model = kwargs.get("model") or self._default_model or "default"
        messages = kwargs.get("messages", [])
        context = self._create_context(model=model)

        messages = self.middleware_chain.run_before(messages, context)
        kwargs["messages"] = messages

        if "model" not in kwargs and self._default_model:
            kwargs["model"] = self._default_model

        url = f"{self._base_url}/chat/completions"

        start_time = time.time()
        try:
            resp = self._session.post(
                url,
                json=kwargs,
                timeout=self._timeout,
            )
            resp.raise_for_status()
            raw_json = resp.json()
        except Exception as e:
            recovery = self.middleware_chain.run_error(e, context)
            if recovery is not None:
                raw_json = recovery if isinstance(recovery, dict) else {"choices": []}
            else:
                raise
        elapsed = time.time() - start_time

        raw_response = self._parse_response(raw_json)

        raw_response = self.middleware_chain.run_after(raw_response, context)

        response_text = ""
        if raw_response.choices:
            response_text = raw_response.choices[0].message.content or ""

        input_text = self._extract_user_text(messages)
        enrichment = self._enrich(response_text, input_text, context)
        enrichment.metadata["latency_ms"] = round(elapsed * 1000)
        enrichment.metadata["model"] = model
        enrichment.metadata["endpoint"] = self._base_url

        error_violations = [v for v in enrichment.violations if v.action_taken == "blocked"]
        if error_violations:
            raise ValueError(
                f"Homer policy violation (output): {error_violations[0].message}"
            )

        return HomerResponse(
            raw_response=raw_response,
            homer=enrichment,
        )

    def _parse_response(self, raw_json: Dict[str, Any]) -> BrokerRawResponse:
        choices = []
        for c in raw_json.get("choices", []):
            msg = c.get("message", {})
            choices.append(BrokerChoice(
                index=c.get("index", 0),
                message=BrokerMessage(
                    role=msg.get("role", "assistant"),
                    content=msg.get("content", ""),
                ),
                finish_reason=c.get("finish_reason", "stop"),
            ))

        return BrokerRawResponse(
            id=raw_json.get("id", ""),
            model=raw_json.get("model", ""),
            choices=choices,
            usage=raw_json.get("usage", {}),
            _raw=raw_json,
        )


GatewayMessage = BrokerMessage
GatewayChoice = BrokerChoice
GatewayRawResponse = BrokerRawResponse
GatewayProvider = BrokerProvider
