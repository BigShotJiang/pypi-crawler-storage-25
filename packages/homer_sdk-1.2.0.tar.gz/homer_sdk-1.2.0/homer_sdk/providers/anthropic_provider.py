"""
Anthropic Provider - Wraps the Anthropic Python SDK with Homer intelligence.

Usage:
    from homer_sdk import Homer

    homer = Homer()
    client = homer.anthropic(api_key="sk-ant-...")

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[{"role": "user", "content": "..."}]
    )

    print(response.content[0].text)        # Standard Anthropic response
    print(response.homer.classification)    # Homer enrichment
    print(response.homer.norms)
"""

import logging
import time
from typing import Any, Dict, List, Optional

from homer_sdk.providers.base import BaseProvider
from homer_sdk.middleware.base import MiddlewareChain, CallContext
from homer_sdk.types import HomerResponse

logger = logging.getLogger(__name__)


class HomerAnthropicMessages:
    def __init__(self, provider: "AnthropicProvider"):
        self._provider = provider

    def create(self, **kwargs) -> HomerResponse:
        return self._provider._messages_create(**kwargs)


class AnthropicProvider(BaseProvider):
    def __init__(
        self,
        api_key: Optional[str] = None,
        middleware_chain: Optional[MiddlewareChain] = None,
        intelligence=None,
        guards=None,
        **anthropic_kwargs,
    ):
        super().__init__("anthropic", middleware_chain, intelligence, guards)

        try:
            import anthropic
            client_kwargs = {}
            if api_key:
                client_kwargs["api_key"] = api_key
            client_kwargs.update(anthropic_kwargs)
            self._client = anthropic.Anthropic(**client_kwargs)
        except ImportError:
            raise ImportError(
                "Anthropic package not installed. Install it with: pip install anthropic"
            )

        self.messages = HomerAnthropicMessages(self)

    def _messages_create(self, **kwargs) -> HomerResponse:
        model = kwargs.get("model", "")
        messages = kwargs.get("messages", [])
        context = self._create_context(model=model)

        messages = self.middleware_chain.run_before(messages, context)
        kwargs["messages"] = messages

        start_time = time.time()
        try:
            raw_response = self._client.messages.create(**kwargs)
        except Exception as e:
            recovery = self.middleware_chain.run_error(e, context)
            if recovery is not None:
                raw_response = recovery
            else:
                raise
        elapsed = time.time() - start_time

        raw_response = self.middleware_chain.run_after(raw_response, context)

        response_text = ""
        if hasattr(raw_response, "content") and raw_response.content:
            for block in raw_response.content:
                if hasattr(block, "text"):
                    response_text += block.text
        elif isinstance(raw_response, dict):
            for block in raw_response.get("content", []):
                if isinstance(block, dict) and block.get("type") == "text":
                    response_text += block.get("text", "")

        input_text = self._extract_user_text(messages)
        enrichment = self._enrich(response_text, input_text, context)
        enrichment.metadata["latency_ms"] = round(elapsed * 1000)
        enrichment.metadata["model"] = model

        error_violations = [v for v in enrichment.violations if v.action_taken == "blocked"]
        if error_violations:
            raise ValueError(
                f"Homer policy violation (output): {error_violations[0].message}"
            )

        return HomerResponse(
            raw_response=raw_response,
            homer=enrichment,
        )
