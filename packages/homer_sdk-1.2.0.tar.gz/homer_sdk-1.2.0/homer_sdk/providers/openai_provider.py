"""
OpenAI Provider - Wraps the OpenAI Python SDK with Homer intelligence.

Usage:
    from homer_sdk import Homer

    homer = Homer()
    client = homer.openai(api_key="sk-...")

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "..."}]
    )

    print(response.choices[0].message.content)
    print(response.homer.classification)
    print(response.homer.norms)
    print(response.homer.confidence)
    print(response.homer.violations)
"""

import logging
import time
from typing import Any, Dict, List, Optional

from homer_sdk.providers.base import BaseProvider
from homer_sdk.middleware.base import MiddlewareChain, CallContext
from homer_sdk.types import HomerEnrichment, HomerResponse, Violation

logger = logging.getLogger(__name__)


class HomerCompletions:
    def __init__(self, provider: "OpenAIProvider"):
        self._provider = provider

    def create(self, **kwargs) -> HomerResponse:
        return self._provider._completions_create(**kwargs)


class HomerChat:
    def __init__(self, provider: "OpenAIProvider"):
        self.completions = HomerCompletions(provider)


class OpenAIProvider(BaseProvider):
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        middleware_chain: Optional[MiddlewareChain] = None,
        intelligence=None,
        guards=None,
        **openai_kwargs,
    ):
        super().__init__("openai", middleware_chain, intelligence, guards)
        self._openai_kwargs = openai_kwargs

        try:
            import openai
            client_kwargs = {}
            if api_key:
                client_kwargs["api_key"] = api_key
            if base_url:
                client_kwargs["base_url"] = base_url
            client_kwargs.update(openai_kwargs)
            self._client = openai.OpenAI(**client_kwargs)
        except ImportError:
            raise ImportError(
                "OpenAI package not installed. Install it with: pip install openai"
            )

        self.chat = HomerChat(self)

    def _completions_create(self, **kwargs) -> HomerResponse:
        model = kwargs.get("model", "")
        messages = kwargs.get("messages", [])
        context = self._create_context(model=model)

        messages = self.middleware_chain.run_before(messages, context)
        kwargs["messages"] = messages

        start_time = time.time()
        try:
            raw_response = self._client.chat.completions.create(**kwargs)
        except Exception as e:
            recovery = self.middleware_chain.run_error(e, context)
            if recovery is not None:
                raw_response = recovery
            else:
                raise
        elapsed = time.time() - start_time

        raw_response = self.middleware_chain.run_after(raw_response, context)

        response_text = ""
        if hasattr(raw_response, "choices") and raw_response.choices:
            response_text = raw_response.choices[0].message.content or ""

        input_text = self._extract_user_text(messages)
        enrichment = self._enrich(response_text, input_text, context)
        enrichment.metadata["latency_ms"] = round(elapsed * 1000)
        enrichment.metadata["model"] = model

        error_violations = [v for v in enrichment.violations if v.action_taken == "blocked"]
        if error_violations:
            raise ValueError(
                f"Homer policy violation (output): {error_violations[0].message}"
            )

        return HomerResponse(
            raw_response=raw_response,
            homer=enrichment,
        )

    @property
    def models(self):
        return self._client.models

    @property
    def embeddings(self):
        return self._client.embeddings

    @property
    def images(self):
        return self._client.images

    @property
    def audio(self):
        return self._client.audio

    @property
    def files(self):
        return self._client.files
