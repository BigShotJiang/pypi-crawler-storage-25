"""
PostgreSQL Context Store - Production backend for context storage.

Supports tenant isolation, TTL, event append, and optimistic concurrency.
"""

import json
import logging
import os
import time
import uuid
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class PostgresContextStore:
    def __init__(self, database_url: Optional[str] = None):
        self._db_url = database_url or os.environ.get("HOMER_CONTEXT_DATABASE_URL") or os.environ.get("DATABASE_URL")
        self._initialized = False
        if self._db_url:
            try:
                self._init_db()
            except Exception as e:
                logger.warning(f"Context store DB init failed: {e}")
                self._db_url = None

    def _init_db(self):
        import psycopg2
        conn = psycopg2.connect(self._db_url)
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS homer_context (
                        tenant_id VARCHAR(128) NOT NULL,
                        context_key VARCHAR(256) NOT NULL,
                        state JSONB NOT NULL DEFAULT '{}'::jsonb,
                        version INTEGER NOT NULL DEFAULT 1,
                        etag VARCHAR(32) NOT NULL,
                        ttl_seconds INTEGER,
                        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        PRIMARY KEY (tenant_id, context_key)
                    );

                    CREATE TABLE IF NOT EXISTS homer_context_events (
                        id SERIAL PRIMARY KEY,
                        tenant_id VARCHAR(128) NOT NULL,
                        context_key VARCHAR(256) NOT NULL,
                        event_id VARCHAR(64) NOT NULL,
                        event_data JSONB NOT NULL,
                        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                    );
                    CREATE INDEX IF NOT EXISTS idx_ctx_events_tenant_key
                        ON homer_context_events (tenant_id, context_key);
                """)
            conn.commit()
            self._initialized = True
        finally:
            conn.close()

    def _conn(self):
        import psycopg2
        return psycopg2.connect(self._db_url)

    def get(self, tenant_id: str, key: str) -> Optional[Dict[str, Any]]:
        if not self._initialized:
            return None
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT state, version, etag, created_at, updated_at, ttl_seconds "
                    "FROM homer_context WHERE tenant_id = %s AND context_key = %s",
                    (tenant_id, key)
                )
                row = cur.fetchone()
                if not row:
                    return None

                if row[5] is not None:
                    updated = row[4].timestamp() if hasattr(row[4], 'timestamp') else time.time()
                    if time.time() - updated > row[5]:
                        cur.execute(
                            "DELETE FROM homer_context WHERE tenant_id = %s AND context_key = %s",
                            (tenant_id, key)
                        )
                        conn.commit()
                        return None

                cur.execute(
                    "SELECT COUNT(*) FROM homer_context_events WHERE tenant_id = %s AND context_key = %s",
                    (tenant_id, key)
                )
                event_count = cur.fetchone()[0]

                return {
                    "state": row[0],
                    "version": row[1],
                    "etag": row[2],
                    "created_at": row[3].isoformat() if hasattr(row[3], 'isoformat') else str(row[3]),
                    "updated_at": row[4].isoformat() if hasattr(row[4], 'isoformat') else str(row[4]),
                    "event_count": event_count,
                }
        finally:
            conn.close()

    def put(self, tenant_id: str, key: str, value: Dict[str, Any], ttl_seconds: Optional[int] = None) -> None:
        if not self._initialized:
            return
        etag = uuid.uuid4().hex[:16]
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO homer_context (tenant_id, context_key, state, version, etag, ttl_seconds)
                    VALUES (%s, %s, %s, 1, %s, %s)
                    ON CONFLICT (tenant_id, context_key) DO UPDATE SET
                        state = EXCLUDED.state,
                        version = homer_context.version + 1,
                        etag = EXCLUDED.etag,
                        ttl_seconds = EXCLUDED.ttl_seconds,
                        updated_at = NOW()""",
                    (tenant_id, key, json.dumps(value, default=str), etag, ttl_seconds)
                )
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Context put failed: {e}")
        finally:
            conn.close()

    def append_event(self, tenant_id: str, key: str, event: Dict[str, Any]) -> None:
        if not self._initialized:
            return
        event_id = event.get("event_id", uuid.uuid4().hex[:16])
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO homer_context (tenant_id, context_key, state, version, etag)
                    VALUES (%s, %s, '{}'::jsonb, 1, %s)
                    ON CONFLICT (tenant_id, context_key) DO UPDATE SET
                        version = homer_context.version + 1,
                        updated_at = NOW()""",
                    (tenant_id, key, uuid.uuid4().hex[:16])
                )
                cur.execute(
                    "INSERT INTO homer_context_events (tenant_id, context_key, event_id, event_data) VALUES (%s, %s, %s, %s)",
                    (tenant_id, key, event_id, json.dumps(event, default=str))
                )
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Context append_event failed: {e}")
        finally:
            conn.close()

    def list_events(self, tenant_id: str, key: str, limit: int = 100) -> List[Dict[str, Any]]:
        if not self._initialized:
            return []
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT event_id, event_data, created_at FROM homer_context_events "
                    "WHERE tenant_id = %s AND context_key = %s ORDER BY id DESC LIMIT %s",
                    (tenant_id, key, limit)
                )
                return [
                    {"event_id": row[0], "timestamp": row[2].isoformat() if hasattr(row[2], 'isoformat') else str(row[2]), **row[1]}
                    for row in cur.fetchall()
                ]
        finally:
            conn.close()

    def delete(self, tenant_id: str, key: str) -> bool:
        if not self._initialized:
            return False
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM homer_context_events WHERE tenant_id = %s AND context_key = %s", (tenant_id, key))
                cur.execute("DELETE FROM homer_context WHERE tenant_id = %s AND context_key = %s", (tenant_id, key))
                deleted = cur.rowcount > 0
            conn.commit()
            return deleted
        except Exception as e:
            conn.rollback()
            logger.error(f"Context delete failed: {e}")
            return False
        finally:
            conn.close()

    def list_keys(self, tenant_id: str, prefix: Optional[str] = None) -> List[str]:
        if not self._initialized:
            return []
        conn = self._conn()
        try:
            with conn.cursor() as cur:
                if prefix:
                    cur.execute(
                        "SELECT context_key FROM homer_context WHERE tenant_id = %s AND context_key LIKE %s",
                        (tenant_id, f"{prefix}%")
                    )
                else:
                    cur.execute(
                        "SELECT context_key FROM homer_context WHERE tenant_id = %s",
                        (tenant_id,)
                    )
                return [row[0] for row in cur.fetchall()]
        finally:
            conn.close()
