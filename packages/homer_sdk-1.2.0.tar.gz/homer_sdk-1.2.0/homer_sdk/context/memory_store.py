"""
In-Memory Context Store - Default backend for development and testing.

Thread-safe with optimistic concurrency via version/etag.
"""

import logging
import threading
import time
import uuid
from typing import Any, Dict, List, Optional

from homer_sdk.context.base import ContextEntry

logger = logging.getLogger(__name__)


class MemoryContextStore:
    CLEANUP_INTERVAL = 100

    def __init__(self, default_ttl_seconds: Optional[int] = None):
        self._store: Dict[str, ContextEntry] = {}
        self._lock = threading.Lock()
        self._default_ttl = default_ttl_seconds
        self._op_count = 0

    def _make_key(self, tenant_id: str, key: str) -> str:
        return f"{tenant_id}:{key}"

    def _maybe_cleanup(self):
        self._op_count += 1
        if self._op_count >= self.CLEANUP_INTERVAL:
            self._op_count = 0
            expired = [k for k, v in self._store.items() if v.is_expired]
            for k in expired:
                del self._store[k]

    def get(self, tenant_id: str, key: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            self._maybe_cleanup()
            compound = self._make_key(tenant_id, key)
            entry = self._store.get(compound)
            if entry is None:
                return None
            if entry.is_expired:
                del self._store[compound]
                return None
            return {
                "state": entry.state,
                "version": entry.version,
                "etag": entry.etag,
                "created_at": entry.created_at,
                "updated_at": entry.updated_at,
                "event_count": len(entry.events),
            }

    def put(self, tenant_id: str, key: str, value: Dict[str, Any], ttl_seconds: Optional[int] = None) -> None:
        with self._lock:
            self._maybe_cleanup()
            compound = self._make_key(tenant_id, key)
            existing = self._store.get(compound)
            now = time.time()
            ttl = ttl_seconds or self._default_ttl

            if existing and not existing.is_expired:
                existing.state = value
                existing.version += 1
                existing.updated_at = now
                existing.etag = uuid.uuid4().hex[:16]
                if ttl is not None:
                    existing.ttl_seconds = ttl
            else:
                self._store[compound] = ContextEntry(
                    tenant_id=tenant_id,
                    key=key,
                    state=value,
                    created_at=now,
                    updated_at=now,
                    ttl_seconds=ttl,
                )

    def append_event(self, tenant_id: str, key: str, event: Dict[str, Any]) -> None:
        with self._lock:
            self._maybe_cleanup()
            compound = self._make_key(tenant_id, key)
            entry = self._store.get(compound)
            if entry is None:
                entry = ContextEntry(tenant_id=tenant_id, key=key, ttl_seconds=self._default_ttl)
                self._store[compound] = entry

            if entry.is_expired:
                entry = ContextEntry(tenant_id=tenant_id, key=key, ttl_seconds=self._default_ttl)
                self._store[compound] = entry

            event_record = {
                "event_id": event.get("event_id", uuid.uuid4().hex[:16]),
                "timestamp": time.time(),
                **event,
            }
            entry.events.append(event_record)
            entry.version += 1
            entry.updated_at = time.time()
            entry.etag = uuid.uuid4().hex[:16]

    def list_events(self, tenant_id: str, key: str, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            compound = self._make_key(tenant_id, key)
            entry = self._store.get(compound)
            if entry is None or entry.is_expired:
                return []
            return entry.events[-limit:]

    def delete(self, tenant_id: str, key: str) -> bool:
        with self._lock:
            compound = self._make_key(tenant_id, key)
            if compound in self._store:
                del self._store[compound]
                return True
            return False

    def list_keys(self, tenant_id: str, prefix: Optional[str] = None) -> List[str]:
        with self._lock:
            result = []
            tenant_prefix = f"{tenant_id}:"
            for compound, entry in self._store.items():
                if not compound.startswith(tenant_prefix):
                    continue
                if entry.is_expired:
                    continue
                key = compound[len(tenant_prefix):]
                if prefix is None or key.startswith(prefix):
                    result.append(key)
            return result

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._store)
