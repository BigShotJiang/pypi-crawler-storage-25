"""
Context Store - Abstract interface for session/task memory.

Provides tenant-scoped, append-only event storage with materialized state.
Supports pluggable backends (memory, redis, postgres, cosmos).
"""

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol, runtime_checkable


@dataclass
class ContextEntry:
    tenant_id: str
    key: str
    state: Dict[str, Any] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)
    version: int = 1
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    ttl_seconds: Optional[int] = None
    etag: str = field(default_factory=lambda: uuid.uuid4().hex[:16])

    @property
    def is_expired(self) -> bool:
        if self.ttl_seconds is None:
            return False
        return time.time() - self.updated_at > self.ttl_seconds


@runtime_checkable
class ContextStore(Protocol):
    def get(self, tenant_id: str, key: str) -> Optional[Dict[str, Any]]: ...
    def put(self, tenant_id: str, key: str, value: Dict[str, Any], ttl_seconds: Optional[int] = None) -> None: ...
    def append_event(self, tenant_id: str, key: str, event: Dict[str, Any]) -> None: ...
    def list_events(self, tenant_id: str, key: str, limit: int = 100) -> List[Dict[str, Any]]: ...
    def delete(self, tenant_id: str, key: str) -> bool: ...
    def list_keys(self, tenant_id: str, prefix: Optional[str] = None) -> List[str]: ...
