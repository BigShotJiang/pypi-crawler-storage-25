"""
Homer SDK type definitions.
"""

import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from enum import Enum

SCHEMA_VERSION = 1


class NormType(str, Enum):
    OBLIGATION = "obligation"
    PROHIBITION = "prohibition"
    ALLOWANCE = "allowance"
    CONSTRAINT = "constraint"
    ETHICAL_EXPECTATION = "ethical_expectation"
    GUIDANCE = "guidance"


class Modality(str, Enum):
    PROHIBITION = "prohibition"
    WARNING = "warning"
    MANDATORY = "mandatory"
    CONDITION = "condition"
    OPTIONAL = "optional"
    INSTRUCTION = "instruction"
    STATEMENT = "statement"


class ClassificationPurpose(str, Enum):
    INSTRUCTIONAL = "instructional"
    REGULATORY = "regulatory"
    EDUCATIONAL = "educational"
    REFERENCE = "reference"
    CONVERSATIONAL = "conversational"


class ClassificationStructure(str, Enum):
    PROCEDURAL = "procedural"
    HIERARCHICAL = "hierarchical"
    NARRATIVE = "narrative"
    QA = "qa"
    LIST = "list"


class PolicyDecisionType(str, Enum):
    PASS = "pass"
    WARN = "warn"
    BLOCK = "block"


class IntegrityLevel(str, Enum):
    L1 = "L1"
    L2 = "L2"
    L3 = "L3"


@dataclass
class Norm:
    norm_id: str
    norm_type: NormType
    source_sentence: str
    subject_role_id: Optional[str] = None
    extracted_subject_phrase: Optional[str] = None
    action: Optional[str] = None
    confidence: Optional["NormConfidence"] = None


@dataclass
class NormConfidence:
    structural: float = 0.0
    deontic: float = 0.0
    actor_binding: float = 0.0
    atomicity: float = 1.0
    authority: float = 0.0
    composite: float = 0.0


@dataclass
class ContentClassification:
    purpose: str = "unknown"
    structure: str = "unknown"
    domain: str = "unknown"
    purpose_scores: Dict[str, float] = field(default_factory=dict)
    structure_scores: Dict[str, float] = field(default_factory=dict)
    domain_scores: Dict[str, float] = field(default_factory=dict)


@dataclass
class ConfidenceResult:
    structural_quality: float = 0.0
    semantic_validity: float = 0.0
    aggregate: float = 0.0
    breakdown: Dict[str, float] = field(default_factory=dict)
    quality_flags: List[str] = field(default_factory=list)


@dataclass
class Violation:
    invariant_id: int
    artifact_id: str
    message: str
    action_taken: str


@dataclass
class PolicyDecision:
    schema_version: int = SCHEMA_VERSION
    phase: str = "output"
    decision: str = "pass"
    violations: List[Violation] = field(default_factory=list)
    trace_id: str = ""
    tenant_id: str = ""


@dataclass
class AuditRecord:
    trace_id: str = ""
    request_id: str = ""
    tenant_id: str = ""
    decision_id: Optional[str] = None
    provider: str = ""
    model: str = ""
    latency_ms: int = 0
    policy_decision: str = "pass"
    timestamp: float = 0.0


@dataclass
class TraceInfo:
    trace_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    request_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    span_id: str = ""
    tenant_id: str = ""
    provider: str = ""
    model: str = ""
    latency_ms: int = 0


@dataclass
class HomerEnrichment:
    schema_version: int = SCHEMA_VERSION
    classification: Optional[ContentClassification] = None
    norms: List[Norm] = field(default_factory=list)
    confidence: Optional[ConfidenceResult] = None
    violations: List[Violation] = field(default_factory=list)
    modality: Optional[str] = None
    roles_detected: List[str] = field(default_factory=list)
    guard_stats: Dict[str, Any] = field(default_factory=dict)
    policy_enforced: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    trace: Optional[TraceInfo] = None
    policy: Optional[PolicyDecision] = None
    audit: Optional[AuditRecord] = None


@dataclass
class HomerResponse:
    raw_response: Any = None
    homer: HomerEnrichment = field(default_factory=HomerEnrichment)

    def __getattr__(self, name):
        if name in ("raw_response", "homer"):
            raise AttributeError(name)
        if self.raw_response is None:
            raise AttributeError(f"'HomerResponse' has no attribute '{name}' (raw_response is None)")
        if isinstance(self.raw_response, dict):
            try:
                return self.raw_response[name]
            except KeyError:
                raise AttributeError(f"'HomerResponse' has no attribute '{name}'")
        return getattr(self.raw_response, name)
