"""
Content Classifier - Multi-dimensional content classification.

Classifies text along three axes:
- Purpose: instructional, regulatory, educational, reference, conversational
- Structure: procedural, hierarchical, narrative, qa, list
- Domain: technical, business, legal, operational, medical, financial
"""

import re
from typing import Dict
from homer_sdk.types import ContentClassification


class ContentClassifier:

    PURPOSE_SIGNALS = {
        "instructional": [
            r'\b(step\s+\d+|procedure|how\s+to|instructions?|follow\s+these)\b',
            r'\b(perform|execute|carry\s+out|complete|conduct)\b',
        ],
        "regulatory": [
            r'\b(shall|must|required|prohibited|forbidden|compliance)\b',
            r'\b(regulation|statute|rule|law|ordinance|mandate)\b',
            r'\b(enforce|penalty|violation|sanction)\b',
        ],
        "educational": [
            r'\b(learn|understand|concept|theory|example|explain)\b',
            r'\b(introduction|overview|background|fundamentals)\b',
        ],
        "reference": [
            r'\b(glossary|appendix|index|reference|table\s+of\s+contents)\b',
            r'\b(see\s+also|refer\s+to|as\s+defined\s+in)\b',
        ],
        "conversational": [
            r'\b(hey|hi|hello|please|thanks|could\s+you|can\s+you)\b',
            r'\?$',
        ],
    }

    STRUCTURE_SIGNALS = {
        "procedural": [
            r'^\s*\d+[\.\)]\s',
            r'\b(step|phase|stage)\s+\d+',
            r'\b(first|then|next|finally|after\s+that)\b',
        ],
        "hierarchical": [
            r'^\s*\d+\.\d+',
            r'^#+\s',
            r'\b(section|chapter|article|part)\s+\d+',
        ],
        "narrative": [
            r'\b(however|therefore|consequently|furthermore|moreover)\b',
            r'\b(in\s+conclusion|to\s+summarize|in\s+summary)\b',
        ],
        "qa": [
            r'^Q[:\.]',
            r'^A[:\.]',
            r'\bFAQ\b',
            r'^(?:Question|Answer)[:\s]',
        ],
        "list": [
            r'^\s*[-•●◦]\s',
            r'^\s*[a-z]\)\s',
        ],
    }

    DOMAIN_SIGNALS = {
        "technical": [
            r'\b(API|SDK|database|server|deploy|config|code|software)\b',
            r'\b(algorithm|function|module|parameter|protocol)\b',
        ],
        "business": [
            r'\b(revenue|stakeholder|ROI|KPI|workflow|process)\b',
            r'\b(department|organization|management|strategy)\b',
        ],
        "legal": [
            r'\b(statute|jurisdiction|liability|tort|plaintiff|defendant)\b',
            r'\b(clause|provision|amendment|contract|agreement)\b',
        ],
        "operational": [
            r'\b(SOP|procedure|checklist|maintenance|equipment)\b',
            r'\b(safety|incident|audit|inspection|report)\b',
        ],
        "medical": [
            r'\b(patient|diagnosis|treatment|clinical|medication)\b',
            r'\b(HIPAA|PHI|healthcare|physician|nurse)\b',
        ],
        "financial": [
            r'\b(FINRA|SEC|trade|broker|compliance|fiduciary)\b',
            r'\b(portfolio|investment|securities|audit|regulatory)\b',
        ],
    }

    def classify(self, text: str) -> ContentClassification:
        purpose_scores = self._score_axis(text, self.PURPOSE_SIGNALS)
        structure_scores = self._score_axis(text, self.STRUCTURE_SIGNALS)
        domain_scores = self._score_axis(text, self.DOMAIN_SIGNALS)

        return ContentClassification(
            purpose=max(purpose_scores, key=purpose_scores.get) if purpose_scores else "unknown",
            structure=max(structure_scores, key=structure_scores.get) if structure_scores else "unknown",
            domain=max(domain_scores, key=domain_scores.get) if domain_scores else "unknown",
            purpose_scores=purpose_scores,
            structure_scores=structure_scores,
            domain_scores=domain_scores,
        )

    def _score_axis(self, text: str, signals: Dict[str, list]) -> Dict[str, float]:
        scores = {}
        for category, patterns in signals.items():
            match_count = 0
            for pattern in patterns:
                matches = re.findall(pattern, text, re.IGNORECASE | re.MULTILINE)
                match_count += len(matches)
            total = len(patterns)
            scores[category] = min(1.0, match_count / max(total, 1) * 0.3)
        return scores
