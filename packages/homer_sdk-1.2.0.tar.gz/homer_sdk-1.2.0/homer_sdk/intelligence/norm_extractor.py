"""
Norm Extractor - Extracts deontic norms from text.

Identifies obligations, prohibitions, allowances, and constraints
from natural language. Splits compound norms into atomic units.
"""

import re
import uuid
from typing import List, Optional
from homer_sdk.types import Norm, NormType, NormConfidence


MODAL_PATTERN = re.compile(
    r"\b(must|shall|may|may\s+not|must\s+not|shall\s+not|should|"
    r"are\s+expected\s+to|is\s+expected\s+to|is\s+required|are\s+required|"
    r"is\s+prohibited|are\s+prohibited|cannot|can\s+not)\b",
    re.IGNORECASE
)

CONJUNCTION_PATTERN = re.compile(r"\b(and|or|but)\b", re.IGNORECASE)

COMPOUND_ACTOR_PATTERN = re.compile(
    r"\b(\w+(?:\s+\w+)*)\s+(and|or)\s+(\w+(?:\s+\w+)*)\s+"
    r"(must|shall|may|should|are\s+required|is\s+required)",
    re.IGNORECASE
)

ACTOR_PHRASE_PATTERN = re.compile(
    r"\b(employees?|vendors?|officers?|staff|personnel|"
    r"managers?|directors?|supervisors?|analysts?|"
    r"individuals?|entities?|organizations?|contractors?)\b",
    re.IGNORECASE
)


def _infer_norm_type(sentence: str) -> Optional[NormType]:
    sent_lower = sentence.lower()

    prohibition_patterns = [
        r'\b(shall\s+not|must\s+not|may\s+not)\b',
        r'\b(is\s+prohibited|are\s+prohibited|forbidden)\b',
        r'\b(not\s+allowed|not\s+permitted|cannot)\b',
    ]
    for pattern in prohibition_patterns:
        if re.search(pattern, sent_lower):
            return NormType.PROHIBITION

    obligation_patterns = [
        r'\b(must|shall)\b(?!\s+not)',
        r'\b(is\s+required|are\s+required)\b',
        r'\b(will\s+ensure|will\s+provide|will\s+maintain)\b',
    ]
    for pattern in obligation_patterns:
        if re.search(pattern, sent_lower):
            return NormType.OBLIGATION

    constraint_patterns = [
        r'\b(only\s+if|only\s+when|provided\s+that|subject\s+to)\b',
        r'\bmay\s+(?:in\s+some\s+circumstances\s+)?violate\b',
        r'\bcould\s+result\s+in\b',
        r'\brisk\s+of\b',
    ]
    for pattern in constraint_patterns:
        if re.search(pattern, sent_lower):
            return NormType.CONSTRAINT

    allowance_patterns = [
        r'\b(may|can)\b(?!\s+not)',
        r'\b(is\s+allowed|are\s+allowed)\b',
        r'\b(is\s+permitted|are\s+permitted|authorized)\b',
    ]
    for pattern in allowance_patterns:
        if re.search(pattern, sent_lower):
            return NormType.ALLOWANCE

    if 'expected' in sent_lower or 'should' in sent_lower:
        return NormType.ETHICAL_EXPECTATION

    return None


class NormExtractor:

    def __init__(self):
        self.split_count = 0
        self.preserved_count = 0

    def extract(self, text: str) -> List[Norm]:
        sentences = re.split(r'(?<=[.!?])\s+', text)
        norms = []

        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence or len(sentence) < 10:
                continue

            if not MODAL_PATTERN.search(sentence):
                continue

            norm_type = _infer_norm_type(sentence)
            if norm_type is None:
                continue

            compound = COMPOUND_ACTOR_PATTERN.search(sentence)
            if compound:
                split_norms = self._split_compound(sentence, norm_type, compound)
                norms.extend(split_norms)
            else:
                actor = self._extract_actor(sentence)
                norm = Norm(
                    norm_id=f"norm_{uuid.uuid4().hex[:8]}",
                    norm_type=norm_type,
                    source_sentence=sentence,
                    extracted_subject_phrase=actor,
                    confidence=NormConfidence(
                        deontic=1.0 if norm_type in (NormType.OBLIGATION, NormType.PROHIBITION) else 0.8,
                        atomicity=1.0,
                        composite=0.8,
                    ),
                )
                self.preserved_count += 1
                norms.append(norm)

        return norms

    def _split_compound(self, sentence: str, norm_type: NormType, match) -> List[Norm]:
        actor1 = match.group(1).strip()
        actor2 = match.group(3).strip()
        norms = []

        for actor in (actor1, actor2):
            norm = Norm(
                norm_id=f"norm_{uuid.uuid4().hex[:8]}",
                norm_type=norm_type,
                source_sentence=sentence,
                extracted_subject_phrase=actor,
                confidence=NormConfidence(
                    deontic=1.0 if norm_type in (NormType.OBLIGATION, NormType.PROHIBITION) else 0.8,
                    atomicity=1.0,
                    composite=0.8,
                ),
            )
            norms.append(norm)

        self.split_count += 1
        return norms

    def _extract_actor(self, sentence: str) -> Optional[str]:
        match = ACTOR_PHRASE_PATTERN.search(sentence)
        return match.group(0) if match else None

    def get_stats(self) -> dict:
        return {
            "split_count": self.split_count,
            "preserved_count": self.preserved_count,
            "total": self.split_count + self.preserved_count,
        }
