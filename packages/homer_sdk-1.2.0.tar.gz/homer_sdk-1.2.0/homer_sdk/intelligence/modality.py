"""
Modality Analyzer - Detects obligation levels and safety modality in text.

Priority order (highest to lowest):
1. PROHIBITION - do not, never, forbidden
2. WARNING - caution, warning, danger
3. MANDATORY - must, shall, required
4. CONDITION - if/when/unless logic
5. OPTIONAL - may, can, could
6. INSTRUCTION - imperative verbs
7. STATEMENT - fallback
"""

import re
from typing import Optional, Dict, List
from homer_sdk.types import Modality


NEGATION_PATTERNS = [
    r"\bdo\s+not\b", r"\bdon'?t\b", r"\bnever\b",
    r"\bprohibited\b", r"\bforbidden\b", r"\bcannot\b", r"\bcan'?t\b",
    r"\bshall\s+not\b", r"\bmust\s+not\b",
    r"\bnot\s+permitted\b", r"\bnot\s+allowed\b",
    r"\billegal\b", r"\bunsafe\b", r"\bavoid\b", r"\brefrain\s+from\b",
]

WARNING_PATTERNS = [
    r"\bwarning\b", r"\bcaution\b", r"\bdanger\b",
    r"\bhazard(?:ous)?\b", r"\bdangerous\b",
    r"\btoxic\b", r"\bflammable\b", r"\bexplosive\b", r"\bcorrosive\b",
    r"\balert\b", r"\bnotice\b",
]

MANDATORY_PATTERNS = [
    r"\bmust\b(?!\s+not)", r"\bshall\b(?!\s+not)",
    r"\brequired\b", r"\bmandatory\b", r"\bobligat(?:ed|ory|ion)\b",
]

CONDITION_PATTERNS = [
    r"\bif\b", r"\bwhen\b", r"\bunless\b",
    r"\bprovided\s+that\b", r"\bonly\s+(?:if|when)\b",
    r"\bin\s+the\s+event\b", r"\bsubject\s+to\b",
]

OPTIONAL_PATTERNS = [
    r"\bmay\b(?!\s+not)", r"\bcan\b(?!\s+not)", r"\bcould\b",
    r"\boptional\b", r"\bpermitted\b", r"\ballowed\b",
]

IMPERATIVE_STARTERS = [
    r"^(ensure|verify|check|confirm|review|submit|complete|perform|"
    r"execute|prepare|document|record|report|update|maintain|"
    r"monitor|evaluate|assess|implement|deploy|configure|install)\b",
]


class ModalityAnalyzer:

    def detect(self, text: str) -> Modality:
        text_lower = text.lower().strip()

        for pattern in NEGATION_PATTERNS:
            if re.search(pattern, text_lower):
                return Modality.PROHIBITION

        for pattern in WARNING_PATTERNS:
            if re.search(pattern, text_lower):
                return Modality.WARNING

        for pattern in MANDATORY_PATTERNS:
            if re.search(pattern, text_lower):
                return Modality.MANDATORY

        for pattern in CONDITION_PATTERNS:
            if re.search(pattern, text_lower):
                return Modality.CONDITION

        for pattern in OPTIONAL_PATTERNS:
            if re.search(pattern, text_lower):
                return Modality.OPTIONAL

        for pattern in IMPERATIVE_STARTERS:
            if re.search(pattern, text_lower, re.IGNORECASE):
                return Modality.INSTRUCTION

        return Modality.STATEMENT

    def analyze_batch(self, texts: List[str]) -> Dict[str, int]:
        counts: Dict[str, int] = {}
        for text in texts:
            modality = self.detect(text)
            counts[modality.value] = counts.get(modality.value, 0) + 1
        return counts
