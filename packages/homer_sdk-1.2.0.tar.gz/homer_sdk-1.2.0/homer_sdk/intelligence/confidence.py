"""
Confidence Scorer - Dual-metric confidence framework.

Separates structural quality from semantic validity:
- Structural: Is the content well-formed? (grammar, completeness, format)
- Semantic: Is it plausible? (coherence, domain fit, contradictions)
- Aggregate: Conservative combination of both
"""

import re
from typing import List, Dict
from homer_sdk.types import ConfidenceResult


class ConfidenceScorer:

    TRUNCATION_ENDINGS = {'the', 'a', 'an', 'with', 'for', 'in', 'on', 'to', 'of', 'by', 'at'}

    def score(self, text: str) -> ConfidenceResult:
        structural = self._score_structural(text)
        semantic = self._score_semantic(text)

        aggregate = self._weighted_harmonic_mean(structural, semantic)

        flags = self._detect_quality_flags(text, structural, semantic)

        return ConfidenceResult(
            structural_quality=round(structural, 3),
            semantic_validity=round(semantic, 3),
            aggregate=round(aggregate, 3),
            breakdown={
                "text_quality": round(self._score_text_quality(text), 3),
                "completeness": round(self._score_completeness(text), 3),
                "coherence": round(self._score_coherence(text), 3),
            },
            quality_flags=flags,
        )

    def _score_structural(self, text: str) -> float:
        text_quality = self._score_text_quality(text)
        completeness = self._score_completeness(text)
        return (text_quality * 0.6 + completeness * 0.4)

    def _score_semantic(self, text: str) -> float:
        coherence = self._score_coherence(text)
        return coherence

    def _score_text_quality(self, text: str) -> float:
        if not text or len(text.strip()) < 3:
            return 0.1

        text = text.strip()

        truncation_penalty = 0.0
        words = text.lower().split()
        if words and words[-1] in self.TRUNCATION_ENDINGS:
            truncation_penalty = 0.3

        placeholder_penalty = 0.0
        if re.search(r'_{3,}', text):
            placeholder_penalty = 0.4
        elif re.search(r'_{1,2}$', text):
            placeholder_penalty = 0.2

        length = len(text)
        if length < 10:
            length_score = length / 10
        elif length <= 100:
            length_score = 1.0
        else:
            length_score = max(0.5, 1.0 - (length - 100) / 200)

        punct_count = text.count("..") + text.count("??") + text.count("!!")
        punct_score = max(0.5, 1.0 - (punct_count * 0.1))

        has_structure = bool(re.search(r'[.!?]\s+[A-Z]', text))
        struct_score = 1.0 if has_structure or length < 50 else 0.7

        raw = (length_score * 0.4 + punct_score * 0.3 + struct_score * 0.3)
        return max(0.1, raw - truncation_penalty - placeholder_penalty)

    def _score_completeness(self, text: str) -> float:
        if not text:
            return 0.0

        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if s.strip()]
        if not sentences:
            return 0.3

        complete = sum(1 for s in sentences if len(s) > 10)
        return min(1.0, complete / max(len(sentences), 1))

    def _score_coherence(self, text: str) -> float:
        if not text:
            return 0.0

        words = text.split()
        if len(words) < 5:
            return 0.5

        unique_ratio = len(set(w.lower() for w in words)) / len(words)
        vocab_score = min(1.0, unique_ratio * 1.5)

        connectives = len(re.findall(
            r'\b(however|therefore|because|furthermore|additionally|'
            r'consequently|moreover|thus|hence|also|then|next)\b',
            text, re.IGNORECASE
        ))
        conn_score = min(1.0, connectives * 0.2)

        return (vocab_score * 0.7 + conn_score * 0.3)

    def _weighted_harmonic_mean(self, structural: float, semantic: float) -> float:
        if structural <= 0 or semantic <= 0:
            return 0.0
        w_s, w_sem = 0.6, 0.4
        return (w_s + w_sem) / (w_s / structural + w_sem / semantic)

    def _detect_quality_flags(self, text: str, structural: float, semantic: float) -> List[str]:
        flags = []
        if structural < 0.5:
            flags.append("low_structural_quality")
        if semantic < 0.5:
            flags.append("semantic_review_needed")
        if re.search(r'_{3,}', text):
            flags.append("placeholder_content")
        words = text.strip().split()
        if words and words[-1].lower() in self.TRUNCATION_ENDINGS:
            flags.append("possible_truncation")
        if structural > 0.8 and semantic < 0.4:
            flags.append("false_assurance_risk")
        return flags
