"""
Role Resolver - Deterministic role binding for content.

Maps subject phrases to canonical roles using a 6-step resolution pipeline:
1. Direct lexical binding (exact match)
2. Definition-anchored binding
3. Compound subject splitting
4. Organizational proxy resolution
5. Soft inference (allowances only)
6. Fail fast (hard norms)
"""

import re
import logging
from dataclasses import dataclass, field
from typing import List, Optional, Dict

logger = logging.getLogger(__name__)


@dataclass
class Role:
    role_id: str
    canonical_name: str
    aliases: List[str] = field(default_factory=list)


@dataclass
class BindingResult:
    status: str
    role_id: Optional[str] = None
    confidence: float = 0.0
    reason: Optional[str] = None
    split_subjects: List[str] = field(default_factory=list)


CONJUNCTION_PATTERN = re.compile(r"\b(and|or)\b", re.IGNORECASE)
HARD_NORM_TYPES = {"obligation", "prohibition", "constraint"}
SOFT_NORM_TYPES = {"allowance", "ethical_expectation", "guidance"}


class RoleResolver:

    def __init__(
        self,
        roles: Optional[List[Role]] = None,
        organizational_proxies: Optional[Dict[str, str]] = None,
    ):
        self.roles = roles or []
        self.organizational_proxies = organizational_proxies or {}
        self._index = self._build_index()

    def _build_index(self) -> Dict[str, Role]:
        index = {}
        for role in self.roles:
            index[role.canonical_name.lower()] = role
            for alias in role.aliases:
                index[alias.lower()] = role
        return index

    def add_role(self, role: Role):
        self.roles.append(role)
        self._index[role.canonical_name.lower()] = role
        for alias in role.aliases:
            self._index[alias.lower()] = role

    def resolve(self, subject_phrase: str, norm_type: str = "allowance") -> BindingResult:
        if not subject_phrase or not subject_phrase.strip():
            return BindingResult(status="unresolved", reason="Empty subject phrase")

        phrase_lower = subject_phrase.strip().lower()

        role = self._index.get(phrase_lower)
        if role:
            return BindingResult(
                status="bound",
                role_id=role.role_id,
                confidence=1.0,
                reason="direct_lexical_match",
            )

        for key, role in self._index.items():
            if key in phrase_lower or phrase_lower in key:
                return BindingResult(
                    status="bound",
                    role_id=role.role_id,
                    confidence=0.9,
                    reason="partial_lexical_match",
                )

        if CONJUNCTION_PATTERN.search(subject_phrase):
            parts = CONJUNCTION_PATTERN.split(subject_phrase)
            subjects = [p.strip() for p in parts if p.strip() and p.strip().lower() not in ('and', 'or')]
            if len(subjects) > 1:
                return BindingResult(
                    status="split_required",
                    split_subjects=subjects,
                    reason="compound_subject_detected",
                )

        proxy_role_id = self.organizational_proxies.get(phrase_lower)
        if proxy_role_id:
            if norm_type in SOFT_NORM_TYPES:
                return BindingResult(
                    status="bound",
                    role_id=proxy_role_id,
                    confidence=0.7,
                    reason="organizational_proxy",
                )
            else:
                return BindingResult(
                    status="unresolved",
                    reason=f"Proxy binding not allowed for hard norm type '{norm_type}'",
                )

        if norm_type in SOFT_NORM_TYPES:
            return BindingResult(
                status="bound",
                role_id=f"inferred_{phrase_lower.replace(' ', '_')}",
                confidence=0.5,
                reason="soft_inference",
            )

        return BindingResult(
            status="unresolved",
            reason=f"No binding found for '{subject_phrase}' (hard norm type '{norm_type}')",
        )

    def resolve_all_in_text(self, text: str) -> List[BindingResult]:
        actor_pattern = re.compile(
            r"\b(employees?|vendors?|officers?|staff|personnel|"
            r"managers?|directors?|supervisors?|analysts?|"
            r"individuals?|entities?|organizations?|contractors?)\b",
            re.IGNORECASE
        )
        results = []
        seen = set()
        for match in actor_pattern.finditer(text):
            phrase = match.group(0)
            if phrase.lower() not in seen:
                seen.add(phrase.lower())
                results.append(self.resolve(phrase))
        return results
