"""
Code-Level Policy Engine for AI governance.

Define governance rules directly in Python code, providing continuous,
always-on compliance before execution.

Code-Level Policy Definition:
    from homer_sdk.policies import Policy, PolicyCondition

    no_pii = Policy(
        name="no_pii",
        phase="output",
        severity="error",
        conditions=[
            PolicyCondition(type="regex_absent", value=r'\\b\\d{3}-\\d{2}-\\d{4}\\b', message="SSN detected"),
            PolicyCondition(type="regex_absent", value=r'\\b(?:\\d{4}[- ]?){3}\\d{4}\\b', message="Credit card number detected"),
        ]
    )

    homer = Homer(policies=[no_pii])

Legacy YAML loading is still supported:
    engine = PolicyEngine()
    engine.load_yaml_file("policies.yaml")

Condition types:
  - contains: text must contain value
  - not_contains: text must not contain value
  - regex_match: text must match regex pattern
  - regex_absent: text must NOT match regex pattern
  - min_length: text must be at least N chars
  - max_length: text must be at most N chars
  - min_words: text must have at least N words
  - max_words: text must have at most N words
  - sentiment_positive: text must not contain negative language (basic)
  - custom: evaluate a callable returning bool

Usage:
    from homer_sdk.policies import Policy, PolicyCondition, PolicyEngine

    policy = Policy(
        name="no_pii",
        phase="output",
        severity="error",
        conditions=[
            PolicyCondition(type="regex_absent", value=r'\\b\\d{3}-\\d{2}-\\d{4}\\b', message="SSN detected")
        ]
    )

    engine = PolicyEngine()
    engine.add_policy(policy)

    passed, violations = engine.evaluate("Some AI output text", phase="output")
    for v in violations:
        print(f"[{v.severity}] {v.policy_name}: {v.message}")
"""

import re
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False


@dataclass
class PolicyCondition:
    type: str = ""
    value: Any = None
    pattern: Optional[str] = None
    message: str = ""
    check: Optional[Callable[[str], bool]] = field(default=None, repr=False)
    _compiled_pattern: Optional[re.Pattern] = field(default=None, repr=False, init=False)

    condition_type: str = field(default="", repr=False)

    def __post_init__(self):
        if self.type and not self.condition_type:
            self.condition_type = self.type
        elif self.condition_type and not self.type:
            self.type = self.condition_type

        if not self.type and not self.condition_type:
            raise ValueError("PolicyCondition requires 'type' parameter")

        if self.type in ("regex_absent", "regex_match") and self.value and not self.pattern:
            self.pattern = str(self.value)

        if self.pattern:
            try:
                self._compiled_pattern = re.compile(self.pattern, re.IGNORECASE)
            except re.error as e:
                logger.error(f"Invalid regex pattern '{self.pattern}': {e}")
                self._compiled_pattern = None


@dataclass
class Policy:
    name: str
    description: str = ""
    phase: str = "both"
    severity: str = "error"
    enabled: bool = True
    conditions: List[PolicyCondition] = field(default_factory=list)
    when: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)


@dataclass
class PolicyViolation:
    policy_name: str
    condition_type: str
    message: str
    severity: str
    phase: str


@dataclass
class PolicySet:
    name: str = "default"
    version: str = "1.0"
    policies: List[Policy] = field(default_factory=list)


BUILT_IN_POLICIES = {
    "no_pii": Policy(
        name="no_pii",
        description="Prevent PII from appearing in AI outputs",
        phase="output",
        severity="error",
        conditions=[
            PolicyCondition(type="regex_absent", value=r'\b\d{3}-\d{2}-\d{4}\b', message="SSN detected in output"),
            PolicyCondition(type="regex_absent", value=r'\b(?:\d{4}[- ]?){3}\d{4}\b', message="Credit card number detected"),
        ],
    ),
    "no_prompt_injection": Policy(
        name="no_prompt_injection",
        description="Block prompt injection attempts in inputs",
        phase="input",
        severity="error",
        conditions=[
            PolicyCondition(type="regex_absent", value=r'ignore\s+(?:all\s+)?(?:previous|prior)\s+instructions', message="Prompt injection attempt detected"),
        ],
    ),
    "max_input_length": Policy(
        name="max_input_length",
        description="Limit input size to prevent abuse",
        phase="input",
        severity="error",
        conditions=[
            PolicyCondition(type="max_length", value=50000, message="Input exceeds maximum length"),
        ],
    ),
    "non_empty_output": Policy(
        name="non_empty_output",
        description="Ensure AI outputs are not empty",
        phase="output",
        severity="warning",
        conditions=[
            PolicyCondition(type="min_length", value=1, message="Output is empty"),
        ],
    ),
    "mandatory_disclaimer": Policy(
        name="mandatory_disclaimer",
        description="Financial content must include disclaimer",
        phase="output",
        severity="warning",
        when={"domain": "financial"},
        conditions=[
            PolicyCondition(type="contains", value="not financial advice", message="Missing disclaimer for financial content"),
        ],
    ),
}


class PolicyEngine:

    def __init__(self):
        self._policy_sets: List[PolicySet] = []
        self._all_policies: List[Policy] = []
        self._context: Dict[str, Any] = {}

    def add_policy(self, policy: Policy):
        self._all_policies.append(policy)

    def add_policies(self, policies: List[Policy]):
        self._all_policies.extend(policies)

    def add_built_in(self, name: str) -> Policy:
        policy = BUILT_IN_POLICIES.get(name)
        if not policy:
            raise ValueError(f"Unknown built-in policy: '{name}'. Available: {list(BUILT_IN_POLICIES.keys())}")
        self._all_policies.append(policy)
        return policy

    def load_yaml_file(self, path: str) -> PolicySet:
        if not YAML_AVAILABLE:
            raise ImportError("PyYAML required: pip install pyyaml")

        with open(path, "r") as f:
            content = f.read()
        return self.load_yaml_string(content)

    def load_yaml_string(self, yaml_content: str) -> PolicySet:
        if not YAML_AVAILABLE:
            raise ImportError("PyYAML required: pip install pyyaml")

        data = yaml.safe_load(yaml_content)
        if not data:
            raise ValueError("Empty YAML policy document")

        policy_set = PolicySet(
            name=data.get("name", "default"),
            version=data.get("version", "1.0"),
        )

        raw_policies = data.get("policies", [])
        for raw in raw_policies:
            conditions = []
            for cond in raw.get("conditions", []):
                conditions.append(PolicyCondition(
                    type=cond.get("type", ""),
                    value=cond.get("value"),
                    pattern=cond.get("pattern"),
                    message=cond.get("message", "Policy condition failed"),
                ))

            policy = Policy(
                name=raw.get("name", "unnamed"),
                description=raw.get("description", ""),
                phase=raw.get("phase", "both"),
                severity=raw.get("severity", "error"),
                enabled=raw.get("enabled", True),
                conditions=conditions,
                when=raw.get("when", {}),
                tags=raw.get("tags", []),
            )
            policy_set.policies.append(policy)

        self._policy_sets.append(policy_set)
        self._all_policies.extend(policy_set.policies)

        logger.info(f"Loaded policy set '{policy_set.name}' with {len(policy_set.policies)} policies")
        return policy_set

    def load_yaml_directory(self, dir_path: str) -> List[PolicySet]:
        sets = []
        for fname in sorted(os.listdir(dir_path)):
            if fname.endswith((".yaml", ".yml")):
                ps = self.load_yaml_file(os.path.join(dir_path, fname))
                sets.append(ps)
        return sets

    def set_context(self, **kwargs):
        self._context.update(kwargs)

    def evaluate(
        self,
        content: str,
        phase: str = "output",
        context: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, List[PolicyViolation]]:
        merged_context = {**self._context, **(context or {})}
        violations: List[PolicyViolation] = []

        for policy in self._all_policies:
            if not policy.enabled:
                continue
            if policy.phase not in (phase, "both"):
                continue

            if policy.when and not self._check_when(policy.when, merged_context):
                continue

            for condition in policy.conditions:
                passed = self._evaluate_condition(condition, content)
                if not passed:
                    violations.append(PolicyViolation(
                        policy_name=policy.name,
                        condition_type=condition.type,
                        message=condition.message,
                        severity=policy.severity,
                        phase=phase,
                    ))

        has_errors = any(v.severity == "error" for v in violations)
        return not has_errors, violations

    def evaluate_input(self, content: str, context: Optional[Dict[str, Any]] = None) -> Tuple[bool, List[PolicyViolation]]:
        return self.evaluate(content, "input", context)

    def evaluate_output(self, content: str, context: Optional[Dict[str, Any]] = None) -> Tuple[bool, List[PolicyViolation]]:
        return self.evaluate(content, "output", context)

    def _check_when(self, when: Dict[str, Any], context: Dict[str, Any]) -> bool:
        for key, expected in when.items():
            actual = context.get(key)
            if actual is None:
                return False
            if isinstance(expected, list):
                if actual not in expected:
                    return False
            elif actual != expected:
                return False
        return True

    def _evaluate_condition(self, condition: PolicyCondition, content: str) -> bool:
        ct = condition.type

        if ct == "contains":
            return str(condition.value).lower() in content.lower()

        elif ct == "not_contains":
            return str(condition.value).lower() not in content.lower()

        elif ct == "regex_match":
            if condition._compiled_pattern:
                return bool(condition._compiled_pattern.search(content))
            return True

        elif ct == "regex_absent":
            if condition._compiled_pattern:
                return not bool(condition._compiled_pattern.search(content))
            return True

        elif ct == "min_length":
            return len(content) >= int(condition.value)

        elif ct == "max_length":
            return len(content) <= int(condition.value)

        elif ct == "min_words":
            return len(content.split()) >= int(condition.value)

        elif ct == "max_words":
            return len(content.split()) <= int(condition.value)

        elif ct == "sentiment_positive":
            negative_words = {"terrible", "awful", "horrible", "worst", "hate", "disgusting", "failure"}
            words = set(content.lower().split())
            return not words.intersection(negative_words)

        elif ct == "custom":
            if condition.check and callable(condition.check):
                return condition.check(content)
            return True

        else:
            raise ValueError(f"Unknown condition type: '{ct}'. Supported: contains, not_contains, regex_match, regex_absent, min_length, max_length, min_words, max_words, sentiment_positive, custom")

    @property
    def policy_count(self) -> int:
        return len(self._all_policies)

    def list_policies(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": p.name,
                "description": p.description,
                "phase": p.phase,
                "severity": p.severity,
                "enabled": p.enabled,
                "conditions": len(p.conditions),
                "tags": p.tags,
            }
            for p in self._all_policies
        ]


class YAMLPolicyEngine(PolicyEngine):

    def load_file(self, path: str) -> PolicySet:
        return self.load_yaml_file(path)

    def load_string(self, yaml_content: str) -> PolicySet:
        return self.load_yaml_string(yaml_content)

    def load_directory(self, dir_path: str) -> List[PolicySet]:
        return self.load_yaml_directory(dir_path)
