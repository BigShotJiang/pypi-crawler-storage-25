"""Rich terminal reporter."""
from __future__ import annotations
from rich.console import Console
from rich.table import Table
from rich import box
from ..models import ScanResult

console = Console()

RISK_COLORS = {
    "HIGH":   "red",
    "MEDIUM": "yellow",
    "LOW":    "cyan",
    "SAFE":   "green",
}


def print_scan_result(result: ScanResult) -> None:
    dead = sorted(result.dead_symbols, key=lambda s: s.confidence_score or 0, reverse=True)

    console.print(f"\n[bold]deadrift[/bold] scanned [cyan]{result.path}[/cyan]")
    console.print(f"  {result.total_scanned} files · {len(result.symbols)} symbols · "
                  f"[red]{len(dead)} dead[/red]\n")

    if not dead:
        console.print("[green]✅ No dead code found above threshold.[/green]\n")
        return

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold")
    table.add_column("Risk",       width=8)
    table.add_column("Score",      width=7)
    table.add_column("Symbol",     width=30)
    table.add_column("File",       width=35)
    table.add_column("Signals",    width=40)

    for sym in dead:
        score = sym.confidence_score or 0
        label = sym.risk_label
        color = RISK_COLORS.get(label, "white")

        signals = []
        if not sym.callers:
            signals.append("no callers")
        if sym.traffic_calls == 0:
            signals.append("zero traffic")
        if sym.last_modified_days and sym.last_modified_days > 180:
            signals.append(f"untouched {sym.last_modified_days}d")
        if sym.tickets_open is False:
            signals.append("ticket closed")
        elif not sym.ticket_refs:
            signals.append("no ticket ref")

        short_file = sym.file.split("/src/")[-1] if "/src/" in sym.file else sym.file

        table.add_row(
            f"[{color}]{label}[/{color}]",
            f"[{color}]{score:.0f}%[/{color}]",
            sym.name,
            short_file,
            ", ".join(signals) or "—",
        )

    console.print(table)
    console.print()