from __future__ import annotations
from pathlib import Path
from datetime import datetime
from ..models import ScanResult

RISK_COLORS = {"HIGH": "red", "MEDIUM": "yellow", "LOW": "cyan", "SAFE": "green"}


def generate_html_report(result: ScanResult, output_path: str = "deadrift-report.html") -> str:
    flagged = sorted(
        [s for s in result.symbols if not s.suppressed and (s.confidence_score or 0) >= 1],
        key=lambda s: s.confidence_score or 0, reverse=True,
    )
    high   = sum(1 for s in flagged if s.risk_label == "HIGH")
    medium = sum(1 for s in flagged if s.risk_label == "MEDIUM")
    low    = sum(1 for s in flagged if s.risk_label == "LOW")

    rows = []
    for sym in flagged:
        score  = sym.confidence_score or 0
        label  = sym.risk_label
        color  = RISK_COLORS.get(label, "white")
        signals = []
        if not sym.callers:          signals.append("no callers")
        if sym.traffic_calls == 0:   signals.append("zero traffic")
        elif sym.traffic_calls is None: signals.append("no traffic data")
        if sym.last_modified_days and sym.last_modified_days > 180:
            signals.append(f"untouched {sym.last_modified_days}d")
        if sym.tickets_open is False:  signals.append("ticket closed")
        elif not sym.ticket_refs:      signals.append("no ticket ref")
        short_file = sym.file.split("/src/")[-1] if "/src/" in sym.file else sym.file
        signals_str = ", ".join(signals) or "-"
        rows.append(
            f'    <tr data-risk="{label}">'
            f'<td><span class="badge badge-{label}">{label}</span></td>'
            f'<td><span class="score {color}">{score:.0f}%</span></td>'
            f'<td><strong>{sym.name}</strong></td>'
            f'<td class="file">{short_file}:{sym.line}</td>'
            f'<td class="signals">{signals_str}</td></tr>'
        )

    rows_html = "\n".join(rows)
    dt = datetime.now().strftime("%Y-%m-%d %H:%M")

    css = """
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
           background: #0d1117; color: #e6edf3; padding: 32px; }
    h1 { font-size: 28px; font-weight: 700; margin-bottom: 4px; }
    h1 span { color: #f85149; }
    .meta { color: #8b949e; font-size: 14px; margin-bottom: 32px; }
    .stats { display: flex; gap: 24px; margin-bottom: 32px; }
    .stat { background: #161b22; border: 1px solid #30363d; border-radius: 8px;
            padding: 16px 24px; min-width: 120px; }
    .stat-num { font-size: 32px; font-weight: 700; }
    .stat-label { font-size: 12px; color: #8b949e; margin-top: 4px; }
    .red { color: #f85149; } .yellow { color: #d29922; }
    .cyan { color: #58a6ff; } .green { color: #3fb950; }
    table { width: 100%; border-collapse: collapse; background: #161b22;
            border: 1px solid #30363d; border-radius: 8px; overflow: hidden; }
    th { background: #21262d; padding: 12px 16px; text-align: left;
         font-size: 12px; color: #8b949e; text-transform: uppercase;
         border-bottom: 1px solid #30363d; }
    td { padding: 12px 16px; border-bottom: 1px solid #21262d; font-size: 14px; }
    tr:hover td { background: #1c2128; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 12px;
             font-size: 11px; font-weight: 600; }
    .badge-HIGH   { background: #3d1a1a; color: #f85149; border: 1px solid #f85149; }
    .badge-MEDIUM { background: #2d2207; color: #d29922; border: 1px solid #d29922; }
    .badge-LOW    { background: #0d2344; color: #58a6ff; border: 1px solid #58a6ff; }
    .badge-SAFE   { background: #0d2f1e; color: #3fb950; border: 1px solid #3fb950; }
    .score { font-weight: 700; font-size: 16px; }
    .signals { font-size: 12px; color: #8b949e; }
    .file { font-family: monospace; font-size: 12px; color: #8b949e; }
    .footer { margin-top: 32px; font-size: 12px; color: #484f58; text-align: center; }
    .filter-bar { display: flex; gap: 12px; margin-bottom: 20px; }
    .filter-btn { padding: 6px 16px; border-radius: 6px; border: 1px solid #30363d;
                  background: #21262d; color: #e6edf3; cursor: pointer; font-size: 13px; }
    .filter-btn.active { border-color: #58a6ff; color: #58a6ff; }
    """

    html = f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>deadrift report</title>
<style>{css}</style></head>
<body>
<h1>&#128128; dead<span>rift</span></h1>
<p class="meta">Generated {dt} &middot; {result.path}</p>
<div class="stats">
  <div class="stat"><div class="stat-num">{result.total_scanned}</div><div class="stat-label">Files Scanned</div></div>
  <div class="stat"><div class="stat-num">{len(result.symbols)}</div><div class="stat-label">Symbols Found</div></div>
  <div class="stat"><div class="stat-num red">{high}</div><div class="stat-label">High Confidence</div></div>
  <div class="stat"><div class="stat-num yellow">{medium}</div><div class="stat-label">Medium Confidence</div></div>
  <div class="stat"><div class="stat-num cyan">{low}</div><div class="stat-label">Low Confidence</div></div>
</div>
<div class="filter-bar">
  <button class="filter-btn active" onclick="filterTable('ALL', this)">All</button>
  <button class="filter-btn" onclick="filterTable('HIGH', this)">High</button>
  <button class="filter-btn" onclick="filterTable('MEDIUM', this)">Medium</button>
  <button class="filter-btn" onclick="filterTable('LOW', this)">Low</button>
</div>
<table id="rt">
<thead><tr><th>Risk</th><th>Score</th><th>Symbol</th><th>File</th><th>Signals</th></tr></thead>
<tbody>
{rows_html}
</tbody></table>
<div class="footer">Generated by <strong>deadrift</strong></div>
<script>
function filterTable(level, btn) {{
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('#rt tbody tr').forEach(row => {{
    row.style.display = (level === 'ALL' || row.dataset.risk === level) ? '' : 'none';
  }});
}}
</script>
</body></html>"""

    Path(output_path).write_text(html, encoding="utf-8")
    return output_path
