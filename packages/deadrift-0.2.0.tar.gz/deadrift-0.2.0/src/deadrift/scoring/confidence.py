from __future__ import annotations
from ..models import Symbol

# ── Scoring weights ───────────────────────────────────────────────────────────
# These are carefully tuned to avoid false positives while catching real dead code.
# Every weight has a reason. Change with care.

W_NO_CALLERS      = 30   # biggest static signal — no one calls this
W_NO_TRAFFIC      = 20   # confirmed zero production traffic
W_NO_TRAFFIC_DATA = 8    # no traffic data (partial signal, not same as zero)
W_OLD_1YEAR       = 20   # file not touched in 12+ months
W_OLD_6MONTHS     = 10   # file not touched in 6+ months
W_TICKET_CLOSED   = 20   # the business reason for this code no longer exists
W_NO_TICKET       = 5    # minor — no ticket found, suspicious but common
W_SINGLE_AUTHOR   = 5    # only one person ever touched it — low team awareness
W_LOW_COMMITS     = 5    # committed only once — possibly forgotten immediately

P_HAS_CALLERS     = 40   # has callers — strong signal it is alive
P_MANY_CALLERS    = 55   # 3+ callers — widely used, almost certainly alive
P_HIGH_TRAFFIC    = 60   # real production traffic — overrides almost everything
P_TICKET_OPEN     = 25   # open ticket means active business requirement
P_IS_ENDPOINT     = 15   # HTTP endpoints have external callers we cannot see
P_FRAMEWORK_DEC   = 15   # framework decorators (pytest, celery) = framework calls it
P_RECENT_CHANGE   = 10   # changed in last 30 days — probably being worked on

FRAMEWORK_DECORATORS = {
    "fixture", "pytest.fixture",
    "task", "shared_task", "celery.task",
    "property", "staticmethod", "classmethod", "abstractmethod",
    "contextmanager", "lru_cache", "cache",
    "click.command", "command",
}

ENDPOINT_KINDS = {"endpoint"}

# Name patterns that suggest the symbol is intentionally kept
SAFE_NAME_PATTERNS = [
    "fallback", "backup", "emergency", "recovery",
    "migration", "seed", "fixture",
]


def score_symbol(symbol: Symbol) -> float:
    """
    Score a symbol 0-100.
    0   = definitely alive, do not touch
    100 = definitely dead, safe to delete
    """
    # Suppressed symbols always score 0
    if symbol.suppressed:
        return 0.0

    # Safe name heuristic — lower score for known-safe patterns
    name_lower = symbol.name.lower()
    has_safe_name = any(p in name_lower for p in SAFE_NAME_PATTERNS)

    score = 0.0

    # ── TRAFFIC ───────────────────────────────────────────────────────────────
    if symbol.traffic_calls is not None:
        if symbol.traffic_calls > 100:
            # High traffic = definitely alive, return immediately
            return max(0.0, score - P_HIGH_TRAFFIC)
        elif symbol.traffic_calls > 0:
            # Some traffic — alive but low
            score -= 30
        else:
            # Explicitly zero traffic
            score += W_NO_TRAFFIC
    else:
        # No data — partial signal
        score += W_NO_TRAFFIC_DATA

    # ── STATIC CALLERS ────────────────────────────────────────────────────────
    n_callers = len(symbol.callers)
    if n_callers == 0:
        score += W_NO_CALLERS
    elif n_callers <= 2:
        score -= P_HAS_CALLERS
    else:
        score -= P_MANY_CALLERS

    # ── ENDPOINT / FRAMEWORK ─────────────────────────────────────────────────
    if symbol.kind in ENDPOINT_KINDS or (hasattr(symbol, "kind") and str(symbol.kind) == "endpoint"):
        score -= P_IS_ENDPOINT

    if symbol.suppressed:
        return 0.0

    framework_decs = [d for d in (symbol.decorator_names if hasattr(symbol, "decorator_names") else [])
                      if d in FRAMEWORK_DECORATORS]
    if framework_decs:
        score -= P_FRAMEWORK_DEC

    # ── GIT AGE ───────────────────────────────────────────────────────────────
    if symbol.last_modified_days is not None:
        d = symbol.last_modified_days
        if d >= 365:
            score += W_OLD_1YEAR
        elif d >= 180:
            score += W_OLD_6MONTHS
        elif d <= 30:
            score -= P_RECENT_CHANGE

    # ── COMMIT SIGNALS ────────────────────────────────────────────────────────
    if hasattr(symbol, "commit_count"):
        if symbol.commit_count == 1:
            score += W_LOW_COMMITS

    if hasattr(symbol, "author_count"):
        if symbol.author_count == 1:
            score += W_SINGLE_AUTHOR

    # ── TICKET ────────────────────────────────────────────────────────────────
    if symbol.tickets_open is False:
        score += W_TICKET_CLOSED
    elif symbol.tickets_open is True:
        score -= P_TICKET_OPEN
    elif not symbol.ticket_refs:
        score += W_NO_TICKET

    # ── SAFE NAME PENALTY ─────────────────────────────────────────────────────
    if has_safe_name:
        score -= 15  # fallback/emergency/recovery patterns are risky to delete

    return round(min(max(score, 0.0), 100.0), 1)


def score_all(symbols: list[Symbol]) -> list[Symbol]:
    for sym in symbols:
        sym.confidence_score = score_symbol(sym)
    return symbols
