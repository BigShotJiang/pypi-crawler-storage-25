"""Core data models for deadrift."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class SymbolKind(str, Enum):
    FUNCTION = "function"
    CLASS = "class"
    METHOD = "method"
    ENDPOINT = "endpoint"


class Language(str, Enum):
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    GO = "go"
    UNKNOWN = "unknown"


@dataclass
class Symbol:
    name: str
    kind: SymbolKind
    file: str
    line: int
    language: Language = Language.PYTHON
    callers: list[str] = field(default_factory=list)
    calls: list[str] = field(default_factory=list)
    last_modified_days: Optional[int] = None
    ticket_refs: list[str] = field(default_factory=list)
    tickets_open: Optional[bool] = None
    traffic_calls: Optional[int] = None
    suppressed: bool = False
    confidence_score: Optional[float] = None

    @property
    def is_dead(self) -> bool:
        return (self.confidence_score or 0) >= 80

    @property
    def risk_label(self) -> str:
        s = self.confidence_score or 0
        if s >= 90: return "HIGH"
        if s >= 70: return "MEDIUM"
        if s >= 50: return "LOW"
        return "SAFE"


@dataclass
class ScanResult:
    path: str
    symbols: list[Symbol] = field(default_factory=list)
    total_scanned: int = 0
    errors: list[str] = field(default_factory=list)

    @property
    def dead_symbols(self) -> list[Symbol]:
        return [s for s in self.symbols if s.is_dead and not s.suppressed]

    @property
    def high_confidence(self) -> list[Symbol]:
        return [s for s in self.dead_symbols if (s.confidence_score or 0) >= 90]