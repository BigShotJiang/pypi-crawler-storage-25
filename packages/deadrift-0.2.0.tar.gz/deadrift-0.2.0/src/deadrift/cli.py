from __future__ import annotations
import json
import sys
from pathlib import Path
from typing import Optional
import typer
from rich.console import Console
from rich.table import Table
from rich import box
from .core.ast_parser import PythonASTParser
from .core.git_analyzer import GitAnalyzer
from .connectors.github_connector import GitHubConnector
from .connectors.traffic_analyzer import TrafficAnalyzer
from .scoring.confidence import score_all
from .reporters.terminal import print_scan_result
from .reporters.html_reporter import generate_html_report

app = typer.Typer(
    name="deadrift",
    help="Find every piece of code your team is afraid to delete.",
    add_completion=False,
)
console = Console()


def _run_pipeline(path, no_git, github_repo, github_token, traffic_log, threshold):
    target = str(Path(path).resolve())
    parser = PythonASTParser()
    result = parser.parse_directory(target)
    console.print("[dim]Found " + str(len(result.symbols)) + " symbols in "
                  + str(result.total_scanned) + " files[/dim]")

    if not no_git:
        analyzer = GitAnalyzer(target)
        if analyzer.available:
            result.symbols = analyzer.enrich_all(result.symbols)

    if github_repo:
        gh = GitHubConnector(repo=github_repo, token=github_token)
        result.symbols = gh.enrich_all(result.symbols)

    if traffic_log:
        ta = TrafficAnalyzer(log_path=traffic_log)
        result.symbols = ta.enrich_all(result.symbols)

    result.symbols = score_all(result.symbols)
    result.symbols = [s for s in result.symbols if (s.confidence_score or 0) >= threshold]
    return result, target


@app.command()
def scan(
    path: str = typer.Argument(".", help="Path to scan"),
    no_git: bool = typer.Option(False, "--no-git"),
    threshold: int = typer.Option(30, "--threshold", "-t"),
    github_repo: Optional[str] = typer.Option(None, "--github-repo"),
    github_token: Optional[str] = typer.Option(None, "--github-token"),
    traffic_log: Optional[str] = typer.Option(None, "--traffic-log"),
    html: bool = typer.Option(False, "--html"),
    html_out: str = typer.Option("deadrift-report.html", "--html-out"),
    output_json: bool = typer.Option(False, "--json"),
):
    """Scan a codebase for dead code."""
    console.print("[dim]Scanning " + str(Path(path).resolve()) + "...[/dim]")
    result, _ = _run_pipeline(path, no_git, github_repo, github_token, traffic_log, threshold)

    if output_json:
        print(json.dumps([
            {"name": s.name, "score": s.confidence_score, "file": s.file,
             "line": s.line, "callers": s.callers}
            for s in result.symbols
        ], indent=2))
        return

    print_scan_result(result)

    if html:
        out = generate_html_report(result, html_out)
        console.print("[green]HTML report:[/green] " + out)


@app.command()
def prune(
    path: str = typer.Argument(".", help="Path to scan and prune"),
    no_git: bool = typer.Option(False, "--no-git"),
    threshold: int = typer.Option(30, "--threshold", "-t",
                                  help="Min confidence score to show (default 30)"),
    github_repo: Optional[str] = typer.Option(None, "--github-repo"),
    github_token: Optional[str] = typer.Option(None, "--github-token"),
    traffic_log: Optional[str] = typer.Option(None, "--traffic-log"),
    dry_run: bool = typer.Option(False, "--dry-run",
                                 help="Preview what would happen without changing files"),
):
    """
    Interactively review and remove dead code.

    For each flagged symbol you choose:
      d = delete it permanently
      c = comment it out (safer, reversible)
      s = skip it for now
      k = suppress forever (adds # deadrift: keep)
    """
    console.print("[dim]Scanning " + str(Path(path).resolve()) + "...[/dim]")
    result, target = _run_pipeline(path, no_git, github_repo, github_token,
                                   traffic_log, threshold)

    candidates = [s for s in result.symbols if not s.suppressed]
    if not candidates:
        console.print("[green]Nothing to prune above " + str(threshold) + "% threshold.[/green]")
        return

    console.print("")
    console.print("[bold]Found " + str(len(candidates)) + " symbol(s) above "
                  + str(threshold) + "% confidence.[/bold]")

    if dry_run:
        console.print("[dim]DRY RUN — no files will be changed[/dim]")
    else:
        console.print("[dim]For each symbol choose:[/dim]  "
                      "[bold red]d[/bold red]=delete  "
                      "[bold yellow]c[/bold yellow]=comment out  "
                      "[bold cyan]k[/bold cyan]=keep (suppress)  "
                      "[dim]s[/dim]=skip")
    console.print("")

    deleted   = []
    commented = []
    kept      = []
    skipped   = []

    for i, sym in enumerate(sorted(candidates,
                                   key=lambda s: s.confidence_score or 0,
                                   reverse=True), start=1):
        score = sym.confidence_score or 0
        color = "red" if score >= 80 else "yellow" if score >= 60 else "cyan"

        # Show symbol header
        console.print(
            "[dim](" + str(i) + "/" + str(len(candidates)) + ")[/dim]  "
            "[" + color + "][bold]" + str(int(score)) + "% confidence dead[/bold][/" + color + "]"
        )
        console.print("  [bold white]" + sym.name + "[/bold white]"
                      + "  [dim]" + sym.file + ":" + str(sym.line) + "[/dim]")

        # Show evidence
        signals = []
        if not sym.callers:            signals.append("no callers")
        if sym.traffic_calls == 0:     signals.append("zero traffic")
        if sym.tickets_open is False:  signals.append("ticket closed")
        elif not sym.ticket_refs:      signals.append("no ticket ref")
        if sym.last_modified_days and sym.last_modified_days > 180:
            signals.append("untouched " + str(sym.last_modified_days) + "d")
        if signals:
            console.print("  [dim]Evidence: " + ", ".join(signals) + "[/dim]")

        if dry_run:
            console.print("  [dim]-> Would prompt: [d]elete / [c]omment / [k]eep / [s]kip[/dim]")
            console.print("")
            continue

        # Interactive prompt
        while True:
            try:
                raw = input("  Action [d/c/k/s] (default=s): ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                console.print("\n[yellow]Interrupted — stopping prune.[/yellow]")
                _print_prune_summary(deleted, commented, kept, skipped)
                return

            if raw == "":
                raw = "s"

            if raw in ("d", "c", "k", "s"):
                break
            console.print("  [red]Invalid choice. Enter d, c, k, or s.[/red]")

        if raw == "d":
            success = _delete_symbol(sym)
            if success:
                deleted.append(sym.name)
                console.print("  [red]Deleted[/red] " + sym.name)
            else:
                console.print("  [yellow]Could not delete (file path issue) — skipped[/yellow]")
                skipped.append(sym.name)

        elif raw == "c":
            success = _comment_symbol(sym)
            if success:
                commented.append(sym.name)
                console.print("  [yellow]Commented out[/yellow] " + sym.name)
            else:
                console.print("  [yellow]Could not comment (file path issue) — skipped[/yellow]")
                skipped.append(sym.name)

        elif raw == "k":
            _suppress_symbol(sym)
            kept.append(sym.name)
            console.print("  [cyan]Suppressed[/cyan] " + sym.name
                          + " [dim](added # deadrift: keep)[/dim]")

        else:
            skipped.append(sym.name)
            console.print("  [dim]Skipped[/dim]")

        console.print("")

    _print_prune_summary(deleted, commented, kept, skipped)


def _print_prune_summary(deleted, commented, kept, skipped):
    console.print("[bold]Summary[/bold]")
    if deleted:
        console.print("  [red]Deleted (" + str(len(deleted)) + "):[/red]   "
                      + ", ".join(deleted))
    if commented:
        console.print("  [yellow]Commented (" + str(len(commented)) + "):[/yellow] "
                      + ", ".join(commented))
    if kept:
        console.print("  [cyan]Kept (" + str(len(kept)) + "):[/cyan]      "
                      + ", ".join(kept))
    if skipped:
        console.print("  [dim]Skipped (" + str(len(skipped)) + "):[/dim]    "
                      + ", ".join(skipped))


@app.command()
def clean_comments(
    path: str = typer.Argument(".", help="Path to clean"),
    dry_run: bool = typer.Option(False, "--dry-run"),
):
    """
    Remove AI-generated garbage comments from source files.

    Detects and removes lines like:
      # This is 100% working and fully tested!
      # AI generated this perfectly
      # LGTM emoji
      # Auto-generated by AI assistant
      # Perfect implementation below
    """
    import re

    GARBAGE_PATTERNS = [
        re.compile(r"#.*\b(100%|perfect|perfectly|lgtm|working fine|fully tested)\b.*", re.I),
        re.compile(r"#.*\b(ai generated|auto.generated|do not modify|don.t modify)\b.*", re.I),
        re.compile(r"#.*\b(best way|best implementation|optimized for maximum)\b.*", re.I),
        re.compile(r"#.*\b(works great|works perfectly|no changes needed)\b.*", re.I),
        re.compile(r"#.*[🚀🎉✨💯🔥👍🤖⚡🌟💪🎯✅].*"),
        re.compile(r"#.*\b(ai reviewed|gpt|copilot|claude generated)\b.*", re.I),
        re.compile(r".*#\s*(Works great|Perfect|LGTM|100%)[!.]*\s*[🚀🎉✨💯��👍🤖✅]?.*", re.I),
    ]

    target = Path(path).resolve()
    py_files = [f for f in target.rglob("*.py") if ".venv" not in str(f)]

    total_removed = 0
    files_changed = 0

    for filepath in py_files:
        try:
            lines = filepath.read_text(encoding="utf-8", errors="ignore").splitlines(keepends=True)
        except Exception:
            continue

        clean_lines = []
        removed_in_file = []

        for i, line in enumerate(lines, start=1):
            stripped = line.strip()
            is_garbage = any(p.search(stripped) for p in GARBAGE_PATTERNS)
            if is_garbage:
                removed_in_file.append((i, stripped))
            else:
                clean_lines.append(line)

        if removed_in_file:
            files_changed += 1
            total_removed += len(removed_in_file)
            short = filepath.name
            console.print("[yellow]" + short + "[/yellow]  ("
                          + str(len(removed_in_file)) + " lines)")
            for lineno, content in removed_in_file:
                console.print("  [dim]line " + str(lineno) + ":[/dim] " + content)
            if not dry_run:
                filepath.write_text("".join(clean_lines), encoding="utf-8")
        console.print("")

    if total_removed == 0:
        console.print("[green]No garbage comments found.[/green]")
    elif dry_run:
        console.print("[dim][DRY RUN] Would remove " + str(total_removed)
                      + " lines from " + str(files_changed) + " file(s)[/dim]")
    else:
        console.print("[green]Removed " + str(total_removed) + " lines from "
                      + str(files_changed) + " file(s)[/green]")


@app.command()
def score(
    symbol_name: str = typer.Argument(..., help="Symbol name to inspect"),
    path: str = typer.Option(".", "--path", "-p"),
):
    """Show full confidence breakdown for a specific symbol."""
    result, _ = _run_pipeline(path, no_git=True, github_repo=None,
                               github_token=None, traffic_log=None, threshold=0)
    found = [s for s in result.symbols if s.name == symbol_name]
    if not found:
        names = [s.name for s in result.symbols[:8]]
        console.print("[red]Symbol not found: " + symbol_name + "[/red]")
        console.print("[dim]Available: " + ", ".join(names) + "...[/dim]")
        raise typer.Exit(1)

    sym = found[0]
    score_val = sym.confidence_score or 0
    color = "red" if score_val >= 60 else "yellow" if score_val >= 30 else "green"

    console.print("")
    console.print("[bold]" + sym.name + "[/bold]  ["
                  + color + "]" + str(int(score_val)) + "% confidence dead[/" + color + "]")
    console.print("  File:        " + sym.file + ":" + str(sym.line))
    console.print("  Kind:        " + str(sym.kind.value if hasattr(sym.kind, "value") else sym.kind))
    console.print("  Callers:     " + str(sym.callers or "none"))
    console.print("  Calls:       " + str(sym.calls or "none"))
    console.print("  Tickets:     " + str(sym.ticket_refs or "none"))
    console.print("  Suppressed:  " + str(sym.suppressed))
    traffic = str(sym.traffic_calls) if sym.traffic_calls is not None else "no data"
    console.print("  Traffic:     " + traffic)
    modified = (str(sym.last_modified_days) + "d ago") if sym.last_modified_days else "unknown"
    console.print("  Last git:    " + modified)
    console.print("")


@app.command()
def annotate(
    path: str = typer.Argument(".", help="Path to annotate"),
    threshold: int = typer.Option(30, "--threshold", "-t"),
    dry_run: bool = typer.Option(False, "--dry-run"),
):
    """Add # deadrift warning comments above dead code (non-destructive)."""
    result, _ = _run_pipeline(path, no_git=True, github_repo=None,
                               github_token=None, traffic_log=None, threshold=threshold)
    candidates = [s for s in result.symbols if not s.suppressed]
    if not candidates:
        console.print("[green]Nothing to annotate.[/green]")
        return

    for sym in candidates:
        comment = ("# deadrift: " + str(int(sym.confidence_score or 0))
                   + "% confidence dead | callers: " + str(sym.callers or "none") + "\n")
        if dry_run:
            console.print("[dim]Would annotate:[/dim] " + sym.name
                          + " (" + sym.file + ":" + str(sym.line) + ")")
        else:
            try:
                filepath = Path(sym.file)
                if not filepath.is_absolute():
                    continue
                lines = filepath.read_text().splitlines(keepends=True)
                lines.insert(sym.line - 1, comment)
                filepath.write_text("".join(lines))
                console.print("[green]Annotated[/green] " + sym.name)
            except Exception as e:
                console.print("[yellow]Warning: " + str(e) + "[/yellow]")


def _delete_symbol(sym) -> bool:
    """Delete a symbol's entire definition. Returns True on success."""
    try:
        filepath = Path(sym.file)
        if not filepath.is_absolute():
            return False
        lines = filepath.read_text(encoding="utf-8").splitlines(keepends=True)
        start = sym.line - 1
        if start >= len(lines):
            return False
        end = start + 1
        while end < len(lines):
            line = lines[end]
            if line.strip() and not line[0].isspace():
                break
            end += 1
        del lines[start:end]
        filepath.write_text("".join(lines), encoding="utf-8")
        return True
    except Exception as e:
        console.print("[yellow]Delete error: " + str(e) + "[/yellow]")
        return False


def _comment_symbol(sym) -> bool:
    """Comment out a symbol's definition. Returns True on success."""
    try:
        filepath = Path(sym.file)
        if not filepath.is_absolute():
            return False
        lines = filepath.read_text(encoding="utf-8").splitlines(keepends=True)
        start = sym.line - 1
        if start >= len(lines):
            return False
        end = start + 1
        while end < len(lines):
            line = lines[end]
            if line.strip() and not line[0].isspace():
                break
            end += 1
        # Add header comment, then comment each line
        header = "# deadrift: commented out — " + str(int(sym.confidence_score or 0)) + "% dead\n"
        lines.insert(start, header)
        end += 1  # account for inserted header
        for i in range(start + 1, end):
            if not lines[i].startswith("#"):
                lines[i] = "# " + lines[i]
        filepath.write_text("".join(lines), encoding="utf-8")
        return True
    except Exception as e:
        console.print("[yellow]Comment error: " + str(e) + "[/yellow]")
        return False


def _suppress_symbol(sym) -> None:
    """Add # deadrift: keep above the symbol definition."""
    try:
        filepath = Path(sym.file)
        if not filepath.is_absolute():
            return
        lines = filepath.read_text(encoding="utf-8").splitlines(keepends=True)
        insert_at = sym.line - 1
        lines.insert(insert_at, "# deadrift: keep\n")
        filepath.write_text("".join(lines), encoding="utf-8")
    except Exception as e:
        console.print("[yellow]Suppress error: " + str(e) + "[/yellow]")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
