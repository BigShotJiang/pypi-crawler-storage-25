from __future__ import annotations
import ast
import os
from pathlib import Path
from ..models import Symbol, SymbolKind, Language, ScanResult

DEADRIFT_KEEP = "deadrift: keep"
ROUTE_DECORATORS = {"route", "get", "post", "put", "delete", "patch"}


def _is_suppressed(node: ast.AST, source_lines: list[str]) -> bool:
    lineno = getattr(node, "lineno", 1)
    if lineno >= 2:
        prev = source_lines[lineno - 2].strip()
        if DEADRIFT_KEEP in prev:
            return True
    return False


def _get_decorator_names(node) -> list[str]:
    names = []
    for d in node.decorator_list:
        if isinstance(d, ast.Name):
            names.append(d.id)
        elif isinstance(d, ast.Attribute):
            names.append(d.attr)
        elif isinstance(d, ast.Call):
            if isinstance(d.func, ast.Attribute):
                names.append(d.func.attr)
            elif isinstance(d.func, ast.Name):
                names.append(d.func.id)
    return names


class CallCollector(ast.NodeVisitor):
    def __init__(self):
        self.calls: list[str] = []

    def visit_Call(self, node: ast.Call):
        if isinstance(node.func, ast.Name):
            self.calls.append(node.func.id)
        elif isinstance(node.func, ast.Attribute):
            self.calls.append(node.func.attr)
        self.generic_visit(node)


class PythonASTParser:
    def parse_file(self, filepath: str) -> list[Symbol]:
        path = Path(filepath)
        try:
            source = path.read_text(encoding="utf-8")
        except Exception:
            return []
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return []

        source_lines = source.splitlines()
        symbols: list[Symbol] = []

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                dec_names = _get_decorator_names(node)
                kind = SymbolKind.ENDPOINT if any(
                    d in ROUTE_DECORATORS for d in dec_names
                ) else SymbolKind.FUNCTION
                collector = CallCollector()
                collector.visit(node)
                sym = Symbol(
                    name=node.name,
                    kind=kind,
                    file=str(filepath),
                    line=node.lineno,
                    language=Language.PYTHON,
                    calls=list(set(collector.calls)),
                    suppressed=_is_suppressed(node, source_lines),
                )
                symbols.append(sym)
            elif isinstance(node, ast.ClassDef):
                sym = Symbol(
                    name=node.name,
                    kind=SymbolKind.CLASS,
                    file=str(filepath),
                    line=node.lineno,
                    language=Language.PYTHON,
                    suppressed=_is_suppressed(node, source_lines),
                )
                symbols.append(sym)

        return symbols

    def parse_directory(self, dirpath: str) -> ScanResult:
        result = ScanResult(path=dirpath)
        all_symbols: list[Symbol] = []

        for root, _, files in os.walk(dirpath):
            for fname in files:
                if fname.endswith(".py"):
                    fpath = os.path.join(root, fname)
                    syms = self.parse_file(fpath)
                    all_symbols.extend(syms)
                    result.total_scanned += 1

        name_to_sym = {s.name: s for s in all_symbols}
        for sym in all_symbols:
            for called in sym.calls:
                if called in name_to_sym:
                    target = name_to_sym[called]
                    if sym.name not in target.callers:
                        target.callers.append(sym.name)

        result.symbols = all_symbols
        return result
