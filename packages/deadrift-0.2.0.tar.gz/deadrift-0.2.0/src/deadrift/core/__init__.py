"""Core analysis modules."""
