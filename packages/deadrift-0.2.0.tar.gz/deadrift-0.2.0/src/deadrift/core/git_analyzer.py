from __future__ import annotations
import re
from datetime import datetime, timezone
from ..models import Symbol

TICKET_PATTERNS = [
    re.compile(r"#(\d+)"),
    re.compile(r"([A-Z]{2,10}-\d+)"),
]


def _extract_ticket_refs(message: str) -> list[str]:
    refs = []
    for pat in TICKET_PATTERNS:
        for m in pat.finditer(message):
            refs.append(m.group(0))
    return refs


class GitAnalyzer:
    def __init__(self, repo_path: str):
        self.repo_path = repo_path
        self._repo = None
        self._available = False
        try:
            import git
            self._repo = git.Repo(repo_path, search_parent_directories=True)
            self._available = True
        except Exception:
            pass

    @property
    def available(self) -> bool:
        return self._available

    def enrich_symbol(self, symbol: Symbol) -> Symbol:
        if not self._available or not self._repo:
            return symbol
        try:
            commits = list(self._repo.iter_commits(paths=symbol.file, max_count=20))
            if not commits:
                return symbol
            latest = commits[0]
            committed_dt = datetime.fromtimestamp(latest.committed_date, tz=timezone.utc)
            now = datetime.now(tz=timezone.utc)
            symbol.last_modified_days = (now - committed_dt).days
            refs = []
            for c in commits:
                refs.extend(_extract_ticket_refs(c.message))
            symbol.ticket_refs = list(set(refs))
        except Exception:
            pass
        return symbol

    def enrich_all(self, symbols: list[Symbol]) -> list[Symbol]:
        return [self.enrich_symbol(s) for s in symbols]
