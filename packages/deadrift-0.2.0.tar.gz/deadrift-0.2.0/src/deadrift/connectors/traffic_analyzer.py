from __future__ import annotations
import re
from collections import defaultdict
from pathlib import Path
from ..models import Symbol

# Matches nginx/Apache combined log format
LOG_RE = re.compile(
    r'\S+ \S+ \S+ \[.*?\] "'
    r'(?P<method>\w+) (?P<path>/\S*) HTTP/\d\.\d"'
    r' (?P<status>\d+)'
)


def _normalize(name: str) -> list[str]:
    """Generate URL variants from a function/endpoint name."""
    slug = name.replace("_", "-").lower()
    return [
        f"/{name.lower()}",
        f"/{slug}",
        f"/api/{slug}",
        f"/api/v1/{slug}",
        f"/api/v2/{slug}",
    ]


class TrafficAnalyzer:
    """Parses nginx/Apache access logs and maps traffic counts onto symbols."""

    def __init__(self, log_path: str):
        self.log_path = log_path
        self._counts: dict[str, int] = defaultdict(int)
        self._parsed = False

    def parse_log(self) -> None:
        path = Path(self.log_path)
        if not path.exists():
            return
        with open(path, encoding="utf-8", errors="ignore") as f:
            for line in f:
                m = LOG_RE.match(line)
                if m:
                    endpoint = m.group("path").split("?")[0]
                    self._counts[endpoint] += 1
        self._parsed = True

    def get_traffic(self, symbol: Symbol) -> int | None:
        if not self._parsed:
            return None
        for variant in _normalize(symbol.name):
            if variant in self._counts:
                return self._counts[variant]
        return 0

    def enrich_symbol(self, symbol: Symbol) -> Symbol:
        symbol.traffic_calls = self.get_traffic(symbol)
        return symbol

    def enrich_all(self, symbols: list[Symbol]) -> list[Symbol]:
        self.parse_log()
        return [self.enrich_symbol(s) for s in symbols]
