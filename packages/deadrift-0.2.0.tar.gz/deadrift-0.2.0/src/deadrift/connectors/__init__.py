"""Ticket and traffic connectors."""
