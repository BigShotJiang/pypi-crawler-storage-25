from __future__ import annotations
import re
import requests
from ..models import Symbol

TICKET_RE = re.compile(r"#(\d+)")


class GitHubConnector:
    """
    Connects to GitHub Issues API.
    Checks if ticket refs found in git history are open or closed.
    """

    def __init__(self, repo: str, token: str | None = None):
        """
        repo: "owner/repo" e.g. "zeeshankhan/deadrift"
        token: GitHub personal access token (optional but recommended)
        """
        self.repo = repo
        self.headers = {"Accept": "application/vnd.github+json"}
        if token:
            self.headers["Authorization"] = f"Bearer {token}"
        self._cache: dict[str, bool] = {}  # issue_number -> is_open

    def _fetch_issue(self, number: str) -> bool | None:
        """Returns True if open, False if closed, None if not found."""
        if number in self._cache:
            return self._cache[number]
        try:
            url = f"https://api.github.com/repos/{self.repo}/issues/{number}"
            resp = requests.get(url, headers=self.headers, timeout=10)
            if resp.status_code == 404:
                return None
            if resp.status_code != 200:
                return None
            data = resp.json()
            is_open = data.get("state") == "open"
            self._cache[number] = is_open
            return is_open
        except Exception:
            return None

    def enrich_symbol(self, symbol: Symbol) -> Symbol:
        """Check ticket refs in symbol and set tickets_open."""
        if not symbol.ticket_refs:
            return symbol

        open_count = 0
        closed_count = 0

        for ref in symbol.ticket_refs:
            m = TICKET_RE.search(ref)
            if not m:
                continue
            number = m.group(1)
            is_open = self._fetch_issue(number)
            if is_open is True:
                open_count += 1
            elif is_open is False:
                closed_count += 1

        if closed_count > 0 and open_count == 0:
            symbol.tickets_open = False
        elif open_count > 0:
            symbol.tickets_open = True
        # If none found, leave as None

        return symbol

    def enrich_all(self, symbols: list[Symbol]) -> list[Symbol]:
        return [self.enrich_symbol(s) for s in symbols]
