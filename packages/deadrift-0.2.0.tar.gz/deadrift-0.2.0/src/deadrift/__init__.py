"""deadrift — find every piece of code your team is afraid to delete."""
__version__ = "0.2.0"
