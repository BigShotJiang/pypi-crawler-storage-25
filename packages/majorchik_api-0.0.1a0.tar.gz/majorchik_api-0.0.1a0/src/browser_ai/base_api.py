from abc import ABC, abstractmethod
from playwright.sync_api import sync_playwright
import os
from .exceptions import ProfileNotFoundError

class BaseWebAPI(ABC):
    """
    Базовый класс для всех Web API моделей.
    Инкапсулирует логику запуска браузера, маскировки и управления ресурсами.
    """
    def __init__(self, profile_dir: str, url: str, headless: bool = True, disable_images: bool = True, setup_mode: bool = False):
        self.profile_dir = os.path.abspath(profile_dir)
        self.url = url
        self.headless = headless
        
        if not setup_mode:
            if not os.path.exists(self.profile_dir) or not os.listdir(self.profile_dir):
                raise ProfileNotFoundError(f"Профиль не найден: {self.profile_dir}. Сначала создайте его через режим setup.")
        else:
            os.makedirs(self.profile_dir, exist_ok=True)
            
        self.playwright = sync_playwright().start()
        
        args =[
            "--disable-blink-features=AutomationControlled",
            "--no-sandbox",
            "--disable-infobars"
        ]
        
        if disable_images:
            args.append("--blink-settings=imagesEnabled=false")
            
        self.browser = self.playwright.chromium.launch_persistent_context(
            user_data_dir=self.profile_dir,
            headless=headless,
            channel="chrome",
            ignore_default_args=["--enable-automation"],
            args=args,
            viewport={'width': 1280, 'height': 800},
            permissions=["clipboard-read", "clipboard-write"]
        )
        self.page = self.browser.new_page()
        self.page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        
        self.page.goto(self.url, wait_until="domcontentloaded")
        
        if not setup_mode:
            self.wait_for_ready()

    @abstractmethod
    def wait_for_ready(self):
        pass

    @abstractmethod
    def ask(self, prompt: str, files: list = None) -> str:
        pass

    def close(self):
        if hasattr(self, 'browser') and self.browser:
            self.browser.close()
        if hasattr(self, 'playwright') and self.playwright:
            self.playwright.stop()
