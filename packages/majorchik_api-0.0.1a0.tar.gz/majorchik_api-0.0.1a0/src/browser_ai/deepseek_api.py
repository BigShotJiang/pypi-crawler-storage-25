from .base_api import BaseWebAPI
import time
import re

def _clean_text(text: str) -> str:
    return re.sub(r'\n{3,}', '\n\n', text).strip()

class DeepSeekAPI(BaseWebAPI):
    def __init__(self, profile_dir: str, headless: bool = True, setup_mode: bool = False):
        super().__init__(
            profile_dir=profile_dir,
            url="https://chat.deepseek.com/",
            headless=headless,
            disable_images=False,
            setup_mode=setup_mode
        )

    def wait_for_ready(self):
        self._handle_cloudflare()
        self.page.wait_for_selector("textarea, #chat-input", timeout=30000)

    def _handle_cloudflare(self):
        time.sleep(3)
        try:
            for frame in self.page.frames:
                if "cloudflare" in frame.url or "turnstile" in frame.url:
                    print("Обнаружен Cloudflare, пытаюсь пройти проверку...")
                    box = frame.locator("input[type='checkbox'], .cb-c, body")
                    if box.count() > 0:
                        box.first.click()
                        time.sleep(5)
        except Exception as e:
            print(f"Ошибка при прохождении Cloudflare: {e}")

    def ask(self, prompt: str, files: list = None) -> str:
        self.page.evaluate("navigator.clipboard.writeText('').catch(() => {})")

        if files:
            try:
                file_input = self.page.locator('input[type="file"]')
                file_input.set_input_files(files)
                time.sleep(1.5)
                loading_texts =["обработка", "Uploading", "Parsing", "processing", "В ожидании", "Загрузка"]
                for text in loading_texts:
                    try:
                        for el in self.page.get_by_text(text).all():
                            if el.is_visible():
                                el.wait_for(state="hidden", timeout=30000)
                    except:
                        pass
                time.sleep(2)
            except Exception as e:
                print(f"Не удалось прикрепить файлы: {e}")

        md_selector = ".ds-markdown, .markdown-body, div[class*='markdown'], div[class*='prose']"
        
        try:
            initial_md_count = self.page.locator(md_selector).count()
            initial_texts = self.page.locator(md_selector).all_inner_texts()
            initial_last_text = initial_texts[-1].strip() if initial_texts else ""
        except:
            initial_md_count = 0
            initial_last_text = ""

        chat_input = self.page.locator("textarea, #chat-input").first
        chat_input.fill(prompt)
        time.sleep(0.5)
        chat_input.press("Enter")

        last_text = ""
        stable_count = 0
        max_wait_sec = 120

        js_find_and_click = """
        () => {
            const mds = document.querySelectorAll('.ds-markdown, .markdown-body, div[class*="markdown"], div[class*="prose"]');
            if (mds.length === 0) return false;
            const lastMd = mds[mds.length - 1];
            let curr = lastMd;
            for (let i = 0; i < 5; i++) {
                if (!curr) break;
                let sibling = curr.nextElementSibling;
                while (sibling) {
                    const isInputBlock = (sibling.matches && sibling.matches('textarea, #chat-input, form, [contenteditable="true"]')) || 
                                         (sibling.querySelector && sibling.querySelector('textarea, #chat-input, form, [contenteditable="true"]'));
                    if (isInputBlock) {
                        sibling = sibling.nextElementSibling;
                        continue;
                    }
                    const btns = sibling.querySelectorAll('div.ds-icon-button[role="button"]');
                    if (btns.length >= 2) {
                        btns[0].click();
                        return true;
                    }
                    sibling = sibling.nextElementSibling;
                }
                curr = curr.parentElement;
            }
            return false;
        }
        """

        for _ in range(max_wait_sec):
            time.sleep(1)
            try:
                current_md_count = self.page.locator(md_selector).count()
                texts = self.page.locator(md_selector).all_inner_texts()
                texts =[t.strip() for t in texts if t.strip()]
                current_text = texts[-1] if texts else ""
            except:
                current_md_count = 0
                current_text = ""

            has_new_message = False
            if current_md_count > initial_md_count:
                has_new_message = True
            elif current_text and current_text != initial_last_text:
                has_new_message = True

            if has_new_message:
                clicked = self.page.evaluate(js_find_and_click)
                if clicked:
                    time.sleep(0.5)
                    clip_val = self.page.evaluate("navigator.clipboard.readText().catch(() => '')")
                    if clip_val:
                        return clip_val
                
                if current_text and current_text == last_text:
                    stable_count += 1
                else:
                    stable_count = 0

                last_text = current_text

                if stable_count >= 15:
                    break

        if last_text:
            return _clean_text(last_text)
        else:
            return "Не удалось найти ответ в DOM. Возможно, изменилась верстка."
