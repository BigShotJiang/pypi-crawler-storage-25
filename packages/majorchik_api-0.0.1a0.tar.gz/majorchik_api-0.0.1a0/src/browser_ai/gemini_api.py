from .base_api import BaseWebAPI
import time
import re

def _clean_text(text: str) -> str:
    return re.sub(r'\n{3,}', '\n\n', text).strip()

class GeminiAPI(BaseWebAPI):
    def __init__(self, profile_dir: str, headless: bool = True, setup_mode: bool = False):
        super().__init__(
            profile_dir=profile_dir,
            url="https://aistudio.google.com/app/prompts/new_chat",
            headless=headless,
            disable_images=True,
            setup_mode=setup_mode
        )

    def wait_for_ready(self):
        self.page.wait_for_selector("textarea, [contenteditable='true']", timeout=15000)

    def ask(self, prompt: str, files: list = None) -> str:
        self.page.evaluate("navigator.clipboard.writeText('').catch(() => {})")

        if files:
            try:
                self.page.locator('[data-test-id="add-media-button"], button[aria-label*="Insert"]').first.click()
                file_input = self.page.locator('input[type="file"]')
                file_input.wait_for(state="attached", timeout=5000)
                file_input.set_input_files(files)
                
                time.sleep(1.5)
                loading_texts =["Loading", "В ожидании", "Загрузка", "Uploading"]
                for text in loading_texts:
                    try:
                        for el in self.page.get_by_text(text).all():
                            if el.is_visible():
                                el.wait_for(state="hidden", timeout=30000)
                    except:
                        pass
                time.sleep(1)
            except Exception as e:
                print(f"Не удалось прикрепить файлы: {e}")

        try:
            initial_thumb_count = self.page.locator('button[aria-label="Good response"], .turn-footer button, button:has(.material-symbols-outlined:has-text("thumb_up"))').count()
        except:
            initial_thumb_count = 0

        self.page.keyboard.press("Escape")
        self.page.wait_for_timeout(300)

        chat_input = self.page.locator("textarea,[contenteditable='true'],[role='textbox']").first
        chat_input.click(force=True)
        chat_input.fill(prompt)
        self.page.wait_for_timeout(500)

        chat_input.press("Control+Enter")

        max_wait_sec = 120
        start_time = time.time()
        completed = False

        while time.time() - start_time < max_wait_sec:
            try:
                current_thumb_count = self.page.locator('button[aria-label="Good response"], .turn-footer button, button:has(.material-symbols-outlined:has-text("thumb_up"))').count()
                if current_thumb_count > initial_thumb_count:
                    completed = True
                    break
            except:
                pass
            self.page.wait_for_timeout(1000)

        if not completed:
            return "Не удалось дождаться завершения генерации (кнопка thumb_up не появилась)."

        self.page.wait_for_timeout(1000)

        try:
            last_turn = self.page.locator('ms-chat-turn, div[data-turn-role="Model"], div.chat-turn-container.model').last
            
            copy_success = False
            try:
                options_btn = last_turn.locator('button[aria-label="Open options"], button:has(.material-symbols-outlined:has-text("more_vert"))').last
                if options_btn.count() > 0 and options_btn.is_visible():
                    options_btn.click(timeout=3000, force=True)
                    self.page.wait_for_timeout(500)
                    
                    copy_btn = self.page.locator('button[role="menuitem"]:has-text("Copy as markdown"), button[role="menuitem"]:has-text("Copy")').first
                    if copy_btn.count() > 0 and copy_btn.is_visible():
                        copy_btn.click(timeout=3000, force=True)
                        self.page.wait_for_timeout(1000)
                        copy_success = True
            except:
                pass

            if copy_success:
                clip_val = self.page.evaluate("navigator.clipboard.readText().catch(() => '')")
                if clip_val:
                    return clip_val
            
            try:
                last_turn.evaluate("""(el) => {
                    const footers = el.querySelectorAll('.turn-footer, .actions-container');
                    footers.forEach(f => f.style.display = 'none');
                }""")
            except:
                pass
                
            text = last_turn.inner_text()
            if text.strip():
                return _clean_text(text)
                
        except Exception as e:
            return f"Ошибка при извлечении текста: {e}"

        return "Не удалось получить текст ответа."
