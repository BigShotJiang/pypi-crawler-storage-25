import sys
import argparse
import os
from .gemini_api import GeminiAPI
from .deepseek_api import DeepSeekAPI
from .exceptions import ProfileNotFoundError

def cmd_setup(args):
    print(f"\n[Настройка профиля {args.model.upper()} | Директория: {args.profile_dir}]")
    print("Открываем браузер...")
    
    try:
        if args.model == "gemini":
            api = GeminiAPI(profile_dir=args.profile_dir, headless=False, setup_mode=True)
        else:
            api = DeepSeekAPI(profile_dir=args.profile_dir, headless=False, setup_mode=True)
            
        print("\nПожалуйста, авторизуйтесь и пройдите все проверки (включая Cloudflare).")
        print("Убедитесь, что интерфейс чата полностью загружен.")
        input("\nНажми Enter в этой консоли для сохранения профиля и выхода...")
        
        api.close()
        print(f"Профиль {args.model} успешно сохранен в: {args.profile_dir}")
    except Exception as e:
        print(f"Ошибка при настройке: {e}")


def cmd_chat(args):
    print(f"\nИнициализация {args.model.upper()} (профиль: {args.profile_dir}, headless: {args.headless})...")
    ai = None
    try:
        if args.model == "gemini":
            ai = GeminiAPI(profile_dir=args.profile_dir, headless=args.headless)
        else:
            ai = DeepSeekAPI(profile_dir=args.profile_dir, headless=args.headless)

        print("Браузер готов. Вводите промпты (для выхода введите 'exit' или 'quit').")
        print("-" * 50)

        current_files = [os.path.abspath(f) for f in args.files] if args.files else None

        while True:
            prompt = input("\nПромпт: ").strip()
            if prompt.lower() in ("exit", "quit"):
                print("Завершение работы.")
                break
            if not prompt:
                print("Промпт не может быть пустым.")
                continue

            print("\n[Ответ]:")
            response = ai.ask(prompt, files=current_files)
            print(response)
            current_files = None

    except ProfileNotFoundError as e:
        print(f"\n[ОШИБКА] {e}")
        print(f"Для создания профиля выполните команду:")
        print(f"  browser-ai setup {args.model} --profile-dir \"{args.profile_dir}\"")
    except KeyboardInterrupt:
        print("\n\nПрерывание пользователя.")
    except Exception as e:
        print(f"\nПроизошла ошибка: {e}")
    finally:
        if ai:
            ai.close()


def main():
    parser = argparse.ArgumentParser(description="Browser AI - Пакет для работы с Gemini и DeepSeek.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Команда setup
    parser_setup = subparsers.add_parser("setup", help="Создать и настроить профиль браузера (авторизация)")
    parser_setup.add_argument("model", choices=["gemini", "deepseek"], help="Модель для настройки")
    parser_setup.add_argument("--profile-dir", required=True, help="Путь к директории для сохранения профиля")

    # Команда chat
    parser_chat = subparsers.add_parser("chat", help="Запустить интерактивный чат с нейросетью")
    parser_chat.add_argument("model", choices=["gemini", "deepseek"], help="Модель для использования")
    parser_chat.add_argument("--profile-dir", required=True, help="Путь к директории сохраненного профиля")
    parser_chat.add_argument("--headless", action="store_true", help="Скрыть визуально браузер (тихий режим)")
    parser_chat.add_argument("--files", nargs="*", help="Пути к файлам для прикрепления к первому промпту")

    args = parser.parse_args()

    if args.command == "setup":
        cmd_setup(args)
    elif args.command == "chat":
        cmd_chat(args)

if __name__ == "__main__":
    main()
