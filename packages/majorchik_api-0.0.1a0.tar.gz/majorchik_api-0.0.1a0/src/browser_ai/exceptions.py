class ProfileNotFoundError(Exception):
    """Возникает, когда указанная директория профиля не существует или пуста."""
    pass
