"""
SoftLand — Your code lands. Every time.
Built on Integer Descent Logic (IDL).

Author: Abdiwasa Musse Mahdi
Version: 0.0.1
"""

import sys
import functools
import time
import os
import json
import threading

# ─────────────────────────────────────────────
# GLOBAL CONFIGURATION
# ─────────────────────────────────────────────

_config = {
    "api_key": os.environ.get("SOFTLAND_API_KEY"),
    "api_url": "https://soft-land-safe.base44.app/api/ingestEvent",
    "threshold": 300,
    "verbose": False,
}


def configure(api_key=None, threshold=None, verbose=None, api_url=None):
    """
    Configure SoftLand globally.

    Call this once at the top of your application.

    Example:
        softland.configure(
            api_key="sk_live_your_key_here",
            threshold=400,
            verbose=True
        )
    """
    if api_key is not None:
        _config["api_key"] = api_key
    if threshold is not None:
        _config["threshold"] = threshold
    if verbose is not None:
        _config["verbose"] = verbose
    if api_url is not None:
        _config["api_url"] = api_url


# ─────────────────────────────────────────────
# INTERNAL SIGNAL — NOT AN ERROR
# ─────────────────────────────────────────────

class _DescentSignal(BaseException):
    """
    Internal IDL signal. Raised when stack pressure hits the threshold.
    Carries the mid-flight state so execution can resume iteratively.
    This is NOT an error. It is a controlled descent trigger.
    """
    def __init__(self, saved_args, saved_kwargs, depth):
        self.saved_args = saved_args
        self.saved_kwargs = saved_kwargs
        self.depth = depth


# ─────────────────────────────────────────────
# NON-BLOCKING EVENT REPORTER
# ─────────────────────────────────────────────

def _report_event(func_name, depth, mode, duration_ms):
    """
    Send a descent event to the SoftLand dashboard.

    - Runs in a daemon thread — never blocks your app.
    - Hard 1-second timeout. If our backend is slow, we disappear silently.
    - If no API key is set, this is a complete no-op.
    """
    if not _config.get("api_key"):
        return

    def _send():
        try:
            import urllib.request
            payload = json.dumps({
                "function": func_name,
                "depth_at_descent": depth,
                "mode": mode,
                "duration_ms": round(duration_ms, 2),
                "timestamp": time.time(),
            }).encode("utf-8")

            req = urllib.request.Request(
                _config["api_url"],
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {_config['api_key']}",
                },
                method="POST",
            )
            urllib.request.urlopen(req, timeout=1)
        except Exception:
            # Intentional silence.
            # We never let reporting interrupt the user's app.
            pass

    t = threading.Thread(target=_send, daemon=True)
    t.start()


# ─────────────────────────────────────────────
# THE WATCH DECORATOR — IDL CORE
# ─────────────────────────────────────────────

def watch(func=None, *, threshold=None, verbose=None):
    """
    SoftLand's core decorator.

    Wraps any recursive Python function with IDL pressure monitoring.
    When stack depth approaches the threshold, it triggers a controlled
    descent into iterative execution — mid-flight, with zero data loss.

    Usage:
        @softland.watch
        def my_recursive_function(n, acc=0):
            if n == 0: return acc
            return my_recursive_function(n - 1, acc + n)

    With options:
        @softland.watch(threshold=500, verbose=True)
        def my_function(n):
            ...

    Custom iterative fallback:
        def _my_iterative(n, acc=0):
            while n > 0:
                acc += n
                n -= 1
            return acc

        @softland.watch
        def my_recursive_function(n, acc=0):
            if n == 0: return acc
            return my_recursive_function(n - 1, acc + n)

        my_recursive_function.__softland_iterate__ = _my_iterative
    """
    # Support both @watch and @watch(threshold=N) forms
    if func is None:
        def decorator(f):
            return watch(f, threshold=threshold, verbose=verbose)
        return decorator

    # Resolve config — decorator-level overrides global
    stack_threshold = threshold if threshold is not None else _config["threshold"]
    be_verbose = verbose if verbose is not None else _config["verbose"]

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.perf_counter()
        depth_counter = [0]
        descent_triggered = [False]
        descent_depth = [0]

        # Build a tracked version of the function that
        # monitors depth and fires _DescentSignal when needed
        def _tracked_call(*a, **kw):
            depth_counter[0] += 1

            if depth_counter[0] >= stack_threshold:
                # DESCENT TRIGGER — IDL pressure threshold hit
                descent_triggered[0] = True
                descent_depth[0] = depth_counter[0]
                raise _DescentSignal(a, kw, depth_counter[0])

            try:
                return func(*a, **kw)
            except _DescentSignal:
                raise  # bubble up unmodified
            finally:
                depth_counter[0] -= 1

        # Patch the function into its own module namespace
        # so recursive self-calls use _tracked_call
        module = sys.modules.get(func.__module__)
        original_ref = getattr(module, func.__name__, None) if module else None

        try:
            if module and original_ref is not None:
                setattr(module, func.__name__, _tracked_call)

            result = _tracked_call(*args, **kwargs)

            elapsed_ms = (time.perf_counter() - start_time) * 1000

            if be_verbose:
                print(f"[SOFTLAND] {func.__name__} — completed normally "
                      f"({elapsed_ms:.1f}ms)")

            return result

        except _DescentSignal as signal:
            # ─────────────────────────────────────────
            # MID-FLIGHT DESCENT CAUGHT
            # Restore original before iterative phase
            # ─────────────────────────────────────────
            if module and original_ref is not None:
                setattr(module, func.__name__, original_ref)

            if be_verbose:
                print(f"[SOFTLAND] {func.__name__} — pressure at depth "
                      f"{signal.depth}. Descending...")

            # Check for a custom iterative fallback first
            iterate_fn = getattr(func, "__softland_iterate__", None)

            try:
                if iterate_fn is not None:
                    # USER-DEFINED iterative path — maximum precision
                    result = iterate_fn(*signal.saved_args, **signal.saved_kwargs)
                    mode = "custom_iterative_descent"
                else:
                    # SAFE-MODE: temporarily raise the recursion ceiling
                    # and re-run the remaining tail from the saved state
                    old_limit = sys.getrecursionlimit()
                    extended = old_limit + stack_threshold + 500
                    sys.setrecursionlimit(extended)
                    try:
                        result = func(*signal.saved_args, **signal.saved_kwargs)
                        mode = "safe_mode_descent"
                    finally:
                        sys.setrecursionlimit(old_limit)

                elapsed_ms = (time.perf_counter() - start_time) * 1000
                _report_event(func.__name__, signal.depth, mode, elapsed_ms)

                if be_verbose:
                    print(f"[SOFTLAND] {func.__name__} — landed clean. "
                          f"Mode: {mode} ({elapsed_ms:.1f}ms)")

                return result

            except Exception as landing_error:
                elapsed_ms = (time.perf_counter() - start_time) * 1000
                _report_event(
                    func.__name__, signal.depth, "failed_landing", elapsed_ms
                )
                if be_verbose:
                    print(f"[SOFTLAND] {func.__name__} — hard landing. "
                          f"Original error surfaced.")
                raise landing_error

        except Exception:
            # Non-descent exception — pass through untouched
            raise

        finally:
            # Always restore the original function reference
            if module and original_ref is not None:
                setattr(module, func.__name__, original_ref)

    return wrapper


# ─────────────────────────────────────────────
# PACKAGE METADATA
# ─────────────────────────────────────────────

__version__ = "0.0.1"
__author__ = "Abdiwasa Musse Mahdi"
__all__ = ["watch", "configure"]
