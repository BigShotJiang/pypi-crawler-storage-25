# Depicta CLI (Python)

[Depicta](https://depicta.ai) lets any AI assistant or app create and edit visuals — images, icons, diagrams, stories, and more. This is the Python CLI.

## Installation

```bash
pip install depicta
```

Or with [uv](https://docs.astral.sh/uv/):

```bash
uv tool install depicta
```

Requires Python 3.10+.

## Setup

Get your API key from [depicta.ai](https://depicta.ai), then:

```bash
depicta auth login
```

Or set the `DEPICTA_API_KEY` environment variable:

```bash
export DEPICTA_API_KEY=dpct_...
```

## Usage

```bash
# Generate an image
depicta image "a sunset over the Aegean Sea"

# Edit an existing image
depicta edit photo.png "remove the background"

# Process images
depicta process resize photo.png --width 800
depicta process remove-bg photo.png
depicta process denoise photo.png --strength 20

# Pipe commands together
depicta image "a cat" | depicta process resize - --width 512 | depicta process optimize -

# Check your balance
depicta balance

# List available models
depicta models
```

Use `depicta --help` or `depicta <command> --help` for full command reference.

## License

Proprietary. Copyright 30ohm L.P. (E.E.)
