"""Tests for errors module."""

from __future__ import annotations

from depicta.errors import (
    EXIT_AUTH,
    EXIT_CREDITS,
    EXIT_GENERAL,
    EXIT_REJECTED,
    EXIT_RATE_LIMITED,
    error_from_response,
)


def test_401_maps_to_auth_error() -> None:
    err = error_from_response(401, {"error": "authentication_error", "message": "bad key"})
    assert err.exit_code == EXIT_AUTH
    assert err.error_code == "authentication_error"


def test_402_maps_to_credits_error() -> None:
    err = error_from_response(402, {"error": "insufficient_credits", "message": "low", "balance_eur": "0.42"})
    assert err.exit_code == EXIT_CREDITS
    assert err.extra["balance_eur"] == "0.42"


def test_403_maps_to_rejected() -> None:
    err = error_from_response(403, {"error": "content_rejected", "message": "blocked"})
    assert err.exit_code == EXIT_REJECTED


def test_429_maps_to_rate_limited() -> None:
    err = error_from_response(429, {"error": "rate_limited", "message": "slow down"})
    assert err.exit_code == EXIT_RATE_LIMITED


def test_500_maps_to_general() -> None:
    err = error_from_response(500, {"error": "internal", "message": "oops"})
    assert err.exit_code == EXIT_GENERAL


def test_error_to_dict() -> None:
    err = error_from_response(402, {"error": "insufficient_credits", "message": "low", "balance_eur": "0.42"})
    d = err.to_dict()
    assert d["error"] == "insufficient_credits"
    assert d["message"] == "low"
    assert d["balance_eur"] == "0.42"
