"""Docs command: output full CLI reference for LLMs and humans."""

from __future__ import annotations

import json

import typer

from depicta import __version__
from depicta.flags import HumanFlag, JsonFlag, QuietFlag
from depicta.output import OutputMode, detect_mode, stderr_console

# Complete command reference — embedded so it works offline.
CLI_REFERENCE: dict = {
    "name": "depicta",
    "version": __version__,
    "description": "Depicta CLI — AI image generation and processing from the terminal",
    "api_base_url": "https://api.depicta.ai",
    "auth": {
        "env_var": "DEPICTA_API_KEY",
        "config_file": "~/.config/depicta/config.json",
        "precedence": ["--api-key flag", "DEPICTA_API_KEY env var", "config file"],
    },
    "output_modes": {
        "human": "TTY detected or --human: Rich output to stderr, file path to stdout",
        "json": "--json flag: full JSON object to stdout",
        "pipe": "non-TTY without --json: file path only to stdout (for piping)",
    },
    "global_flags": {
        "--json": "Force JSON output",
        "--human": "Force human-readable output",
        "--api-key <key>": "Override API key for this call",
        "--quiet / -q": "Suppress informational output on stderr",
    },
    "commands": {
        "image <prompt>": {
            "description": "Generate image from text",
            "flags": "--model/-m, --size/-s, --image-size, --output/-o, --output-dir/-d, --format/-f, --quality, --strictness",
            "output": "JSON: {file, cost_eur, balance_eur, image_hash, model, ai_generated}",
        },
        "edit <input> <prompt>": {
            "description": "Edit an existing image with a text prompt",
            "flags": "same as image",
            "note": "Input can be a file path, - (stdin), or URL",
        },
        "graphic <prompt>": {
            "description": "Generate icon, logo, or clipart",
            "flags": "same as image",
        },
        "diagram <prompt>": {
            "description": "Generate a diagram",
            "flags": "same as image + --type/-t (flowchart|sequence|architecture|mindmap|er|class|timeline|org-chart)",
        },
        "combine <images...>": {
            "description": "Combine 2-5 images into one composition",
            "flags": "same as image + --prompt/-p",
        },
        "story run <storyboard.json>": {
            "description": "Generate multi-scene story from storyboard JSON (async, polls until complete)",
            "flags": "--output-dir/-d, --format/-f, --quality, --timeout",
            "output": "JSON: {job_id, title, scenes: [{file}], cost_eur, balance_eur}",
        },
        "story status <job_id>": {
            "description": "Poll status of an async story job",
        },
        "process crop <input>": {"description": "Crop image", "flags": "--x, --y, --width, --height, --output/-o, --output-dir/-d"},
        "process resize <input>": {"description": "Resize image", "flags": "--width, --height"},
        "process convert <input>": {"description": "Convert format", "flags": "--format/-f (png|jpg|webp)"},
        "process optimize <input>": {"description": "Optimize compression", "flags": "--colors, --min-psnr"},
        "process remove-bg <input>": {"description": "Remove background"},
        "process blur <input>": {"description": "Apply Gaussian blur", "flags": "--radius"},
        "process sharpen <input>": {"description": "Sharpen image", "flags": "--amount, --threshold"},
        "process adjust <input>": {"description": "Adjust brightness/contrast/saturation", "flags": "--brightness, --contrast, --saturation"},
        "process grayscale <input>": {"description": "Convert to grayscale"},
        "process invert <input>": {"description": "Invert colors"},
        "process flip <input>": {"description": "Flip image", "flags": "--direction (horizontal|vertical)"},
        "process auto-orient <input>": {"description": "Auto-orient from EXIF"},
        "process alpha-to-color <input>": {"description": "Replace transparency with color", "flags": "--color (#RRGGBB)"},
        "process color-to-alpha <input>": {"description": "Make color transparent", "flags": "--color, --tolerance"},
        "process rotate <input>": {"description": "Rotate by angle", "flags": "--angle, --expand, --fill-color"},
        "process trim <input>": {"description": "Auto-trim borders", "flags": "--tolerance"},
        "process pad <input>": {"description": "Add padding", "flags": "--width, --height, --color, --gravity"},
        "process metadata-strip <input>": {"description": "Strip metadata", "flags": "--keep-icc"},
        "process overlay <input>": {"description": "Overlay image", "flags": "--overlay, --x, --y, --opacity"},
        "auth login": {"description": "Configure API key (interactive or piped)"},
        "auth logout": {"description": "Remove stored credentials"},
        "auth status": {"description": "Show current auth state"},
        "guidelines search <query>": {"description": "Search content guidelines by keyword"},
        "jobs list": {"description": "List recent generation jobs"},
        "jobs get <job_id>": {"description": "Get a specific job by ID"},
        "models": {"description": "List available models"},
        "balance": {"description": "Show credit balance (balance_eur, held_eur)"},
        "version": {"description": "Show CLI version (no auth required)"},
        "docs": {"description": "Show this command reference"},
    },
    "piping": {
        "convention": "stdout = file path (pipe mode) or JSON (--json). stderr = display output.",
        "stdin": "Use - as input argument to read file path from stdin",
        "example": "depicta image 'a cat' | depicta process remove-bg - | depicta process resize - --width 1200",
    },
    "exit_codes": {
        "0": "success",
        "1": "general error",
        "2": "authentication error",
        "3": "insufficient credits",
        "4": "content rejected",
        "5": "rate limited",
    },
}


def register(app: typer.Typer) -> None:
    """Register the docs command."""

    @app.command("docs")
    def docs_cmd(
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        quiet: QuietFlag = False,
    ) -> None:
        """Show complete CLI command reference."""
        mode = detect_mode(force_json=json_output, force_human=human_output)

        if mode == OutputMode.JSON or mode == OutputMode.PIPE:
            print(json.dumps(CLI_REFERENCE, indent=2))
        else:
            _print_human_docs()

    def _print_human_docs() -> None:
        stderr_console.print(f"[bold]Depicta CLI v{__version__}[/]\n")
        stderr_console.print("[bold]Commands:[/]\n")
        for cmd, info in CLI_REFERENCE["commands"].items():
            desc = info["description"] if isinstance(info, dict) else info
            stderr_console.print(f"  [cyan]depicta {cmd}[/]")
            stderr_console.print(f"    {desc}")
            if isinstance(info, dict):
                if "flags" in info:
                    stderr_console.print(f"    Flags: {info['flags']}")
            stderr_console.print()

        stderr_console.print("[bold]Piping:[/]")
        stderr_console.print(f"  {CLI_REFERENCE['piping']['example']}\n")

        stderr_console.print("[bold]Exit codes:[/]")
        for code, meaning in CLI_REFERENCE["exit_codes"].items():
            stderr_console.print(f"  {code}: {meaning}")
