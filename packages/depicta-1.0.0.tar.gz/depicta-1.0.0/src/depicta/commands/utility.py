"""Utility commands: models, balance, version."""

from __future__ import annotations

import json
from typing import Annotated

import typer
from rich.table import Table

from depicta import __version__
from depicta.client import DepictaClient
from depicta import config as config_module
from depicta.config import resolve_api_key, resolve_api_url
from depicta.errors import DepictaError, EXIT_AUTH
from depicta.flags import ApiKeyOpt, ApiUrlOpt, HumanFlag, JsonFlag, QuietFlag
from depicta.output import (
    OutputMode,
    detect_mode,
    format_balance_json,
    format_version_json,
    stderr_console,
    warn_api_key_flag,
)


def _make_client(api_key: str | None, api_url: str | None, mode: OutputMode, quiet: bool) -> DepictaClient:
    key = resolve_api_key(api_key)
    if not key:
        raise DepictaError("No API key configured.", "authentication_error", EXIT_AUTH)
    if api_key:
        warn_api_key_flag(mode, quiet)
    return DepictaClient(key, resolve_api_url(api_url))


def register(app: typer.Typer) -> None:
    """Register utility commands on the Typer app."""

    @app.command("models")
    def models_cmd(
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """List available image generation models."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        raw = client.get("/v1/models")
        client.close()
        # API may return bare array or {"models": [...]}.
        models = raw["models"] if isinstance(raw, dict) and "models" in raw else raw

        if mode == OutputMode.JSON:
            print(json.dumps(models))
        elif mode == OutputMode.HUMAN and not quiet:
            table = Table(title="Available Models")
            table.add_column("ID", style="cyan")
            table.add_column("Name")
            table.add_column("Gen", justify="center")
            table.add_column("Edit", justify="center")
            table.add_column("Sizes")
            table.add_column("Cost")
            for m in models:
                table.add_row(
                    m["id"],
                    m["name"],
                    "✓" if m.get("can_generate") else "✗",
                    "✓" if m.get("can_edit") else "✗",
                    ", ".join(m.get("image_sizes", [])) or "—",
                    f"~EUR {m['approximate_cost_eur']}" if m.get("approximate_cost_eur") else "—",
                )
            stderr_console.print(table)

    @app.command("balance")
    def balance_cmd(
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Show credit balance."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        profile = client.get("/v1/account/profile")
        client.close()

        user = profile.get("user", {})
        balance_eur = user.get("balance_eur", "0")
        held_eur = user.get("held_eur", "0")

        if mode == OutputMode.JSON:
            print(format_balance_json(balance_eur=balance_eur, held_eur=held_eur))
        elif mode == OutputMode.HUMAN and not quiet:
            bal = float(balance_eur)
            style = "green" if bal > 5 else "yellow" if bal > 1 else "red"
            stderr_console.print(f"  Balance:  [{style}]EUR {balance_eur}[/{style}]")
            stderr_console.print(f"  Held:     EUR {held_eur}")
            available = bal - float(held_eur)
            stderr_console.print(f"  Available: EUR {available:.6f}")

    @app.command("version")
    def version_cmd(
        skill: Annotated[bool, typer.Option("--skill", help="Check skill file version against remote")] = False,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Show CLI version. With --skill, check if the skill file is up to date."""
        mode = detect_mode(force_json=json_output, force_human=human_output)

        if not skill:
            if mode == OutputMode.JSON:
                print(format_version_json(version=__version__))
            elif not quiet:
                stderr_console.print(f"depicta {__version__}")
            return

        # --skill: check remote skill version (no auth required)
        import httpx
        url = config_module.resolve_api_url(api_url)
        try:
            resp = httpx.get(f"{url}/v1/skill-version", timeout=10.0)
            resp.raise_for_status()
            remote = resp.json().get("version", "unknown")
        except Exception as e:
            if mode == OutputMode.JSON:
                print(json.dumps({"error": "general_error", "message": f"Failed to check skill version: {e}"}))
            elif not quiet:
                stderr_console.print(f"[red]Failed to check skill version:[/] {e}")
            raise SystemExit(1)

        if mode == OutputMode.JSON:
            print(json.dumps({"cli_version": __version__, "skill_version": remote}))
        elif not quiet:
            stderr_console.print(f"depicta {__version__}")
            stderr_console.print(f"Skill version: {remote}")
