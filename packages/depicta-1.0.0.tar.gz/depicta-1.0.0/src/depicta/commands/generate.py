"""Generation commands: image, edit, graphic, diagram, combine."""

from __future__ import annotations

import sys
from typing import Annotated, Any, Optional

import typer

from depicta.client import DepictaClient
from depicta.config import resolve_api_key, resolve_api_url
from depicta.download import save_bytes
from depicta.errors import DepictaError, EXIT_AUTH
from depicta.flags import (
    ApiKeyOpt,
    ApiUrlOpt,
    DiagramTypeOpt,
    FormatOpt,
    HumanFlag,
    ImageSizeOpt,
    JsonFlag,
    ModelOpt,
    OutputDirOpt,
    OutputOpt,
    QualityOpt,
    QuietFlag,
    SizeOpt,
    StrictnessOpt,
)
from depicta.output import OutputMode, detect_mode, print_generation, warn_api_key_flag


def _resolve_input(path: str) -> str:
    """Resolve input: file path, stdin (-), or URL."""
    if path == "-":
        line = sys.stdin.readline().strip()
        if not line:
            raise typer.Exit(1)
        return line
    return path


def _pick_format_url(resp: dict[str, Any], fmt: str) -> tuple[str, str]:
    """Pick the download URL and hash for the requested format.

    The API returns three variants in resp["formats"]. Falls back to
    resp["image_url"] (PNG) if formats map is absent.
    Returns (url, hash).
    """
    formats = resp.get("formats", {})
    api_fmt = "jpeg" if fmt in ("jpg", "jpeg") else fmt
    variant = formats.get(api_fmt)
    if variant:
        return variant["url"], variant.get("hash", resp.get("image_hash", ""))
    return resp["image_url"], resp.get("image_hash", "")


def _save_last_job_id(job_id: str) -> None:
    """Store last job ID in config dir for recovery via 'depicta jobs list'."""
    from depicta.config import _config_dir
    path = _config_dir() / "last_job_id"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(job_id)


def _recover_from_job(client: DepictaClient, job_id: str, fmt: str) -> tuple[str, str] | None:
    """Try to recover download URL from a job ID via GET /v1/jobs/{id}."""
    try:
        job = client.get(f"/v1/jobs/{job_id}")
        # Job response may have formats map or image_url
        return _pick_format_url(job, fmt)
    except Exception:
        return None


def _run_generation(
    *,
    client: DepictaClient,
    endpoint: str,
    body: dict[str, Any],
    mode: OutputMode,
    quiet: bool,
    command: str,
    output: str | None,
    output_dir: str | None,
    fmt: str | None,
) -> None:
    """Shared generation flow: POST, pick format variant, download with retry, print."""
    try:
        resp, _, headers = client.post_json(endpoint, body)
    except Exception as e:
        err_str = str(e).lower()
        if any(token in err_str for token in ("connect", "timeout", "network")):
            from depicta.output import stderr_console
            stderr_console.print(
                "[yellow]Generation may have completed. Check recent jobs with: depicta jobs list[/]"
            )
        raise
    job_id = headers.get("x-depicta-job-id", "")
    if job_id:
        _save_last_job_id(job_id)
    ext = fmt or "png"
    download_url, image_hash = _pick_format_url(resp, ext)

    # Download with retry via job recovery
    import time
    image_data = None
    last_err = None
    for attempt in range(3):
        try:
            image_data = client.download_bytes(download_url)
            break
        except Exception as e:
            last_err = e
            if attempt < 2 and job_id:
                if not quiet:
                    from depicta.output import stderr_console
                    stderr_console.print(
                        f"[yellow]Download failed (attempt {attempt + 1}/3), retrying via job recovery...[/]"
                    )
                time.sleep(1)
                recovered = _recover_from_job(client, job_id, ext)
                if recovered:
                    download_url, image_hash = recovered

    if image_data is None:
        raise last_err  # type: ignore[misc]

    path = save_bytes(image_data, command, ext=ext, output=output, output_dir=output_dir)
    resp_for_output = {**resp, "image_hash": image_hash}
    print_generation(str(path.resolve()), resp_for_output, mode, quiet)
    client.close()


def _make_client(api_key: str | None, api_url: str | None, mode: OutputMode, quiet: bool) -> DepictaClient:
    """Resolve auth, warn if flag used, create client."""
    key = resolve_api_key(api_key)
    if not key:
        raise DepictaError(
            "No API key configured. Run 'depicta auth login' or set DEPICTA_API_KEY.",
            "authentication_error",
            EXIT_AUTH,
        )
    if api_key:
        warn_api_key_flag(mode, quiet)
    url = resolve_api_url(api_url)
    return DepictaClient(key, url)


def _add_optional(body: dict[str, Any], key: str, value: Any) -> None:
    """Add a key to the body if the value is not None."""
    if value is not None:
        body[key] = value


def register(app: typer.Typer) -> None:
    """Register all generation commands on the Typer app."""

    @app.command("image")
    def image_cmd(
        prompt: Annotated[str, typer.Argument(help="Text prompt")],
        model: ModelOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Generate image from text."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        body: dict[str, Any] = {"prompt": prompt}
        _add_optional(body, "model", model)
        _add_optional(body, "aspect_ratio", size)
        _add_optional(body, "image_size", image_size)
        _add_optional(body, "strictness", strictness)
        _run_generation(
            client=client,
            endpoint="/v1/generate/image",
            body=body,
            mode=mode,
            quiet=quiet,
            command="image",
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    @app.command("edit")
    def edit_cmd(
        input_path: Annotated[str, typer.Argument(help="Input image (or - for stdin)")],
        prompt: Annotated[str, typer.Argument(help="Edit instructions")],
        model: ModelOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Edit an existing image with a text prompt."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        resolved = _resolve_input(input_path)
        upload_resp = client.upload_file("/v1/upload", resolved)
        body: dict[str, Any] = {
            "prompt": prompt,
            "input_image_url": upload_resp["upload_url"],
        }
        _add_optional(body, "model", model)
        _add_optional(body, "aspect_ratio", size)
        _add_optional(body, "image_size", image_size)
        _add_optional(body, "strictness", strictness)
        _run_generation(
            client=client,
            endpoint="/v1/generate/edit",
            body=body,
            mode=mode,
            quiet=quiet,
            command="edit",
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    @app.command("graphic")
    def graphic_cmd(
        prompt: Annotated[str, typer.Argument(help="Graphic description")],
        model: ModelOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Generate icon, logo, or clipart."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        body: dict[str, Any] = {"prompt": prompt}
        _add_optional(body, "model", model)
        _add_optional(body, "aspect_ratio", size)
        _add_optional(body, "image_size", image_size)
        _add_optional(body, "strictness", strictness)
        _run_generation(
            client=client,
            endpoint="/v1/generate/graphic",
            body=body,
            mode=mode,
            quiet=quiet,
            command="graphic",
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    @app.command("diagram")
    def diagram_cmd(
        prompt: Annotated[str, typer.Argument(help="Diagram description")],
        model: ModelOpt = None,
        diagram_type: DiagramTypeOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Generate a diagram."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        body: dict[str, Any] = {"prompt": prompt}
        _add_optional(body, "model", model)
        _add_optional(body, "diagram_type", diagram_type)
        _add_optional(body, "aspect_ratio", size)
        _add_optional(body, "image_size", image_size)
        _add_optional(body, "strictness", strictness)
        _run_generation(
            client=client,
            endpoint="/v1/generate/diagram",
            body=body,
            mode=mode,
            quiet=quiet,
            command="diagram",
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )

    @app.command("combine")
    def combine_cmd(
        images: Annotated[list[str], typer.Argument(help="Image paths (2-5)")],
        prompt: Annotated[Optional[str], typer.Option("--prompt", "-p", help="Composition instructions")] = None,
        model: ModelOpt = None,
        size: SizeOpt = None,
        image_size: ImageSizeOpt = None,
        output: OutputOpt = None,
        output_dir: OutputDirOpt = None,
        fmt: FormatOpt = None,
        quality: QualityOpt = 85,
        strictness: StrictnessOpt = None,
        json_output: JsonFlag = False,
        human_output: HumanFlag = False,
        api_key: ApiKeyOpt = None,
        api_url: ApiUrlOpt = None,
        quiet: QuietFlag = False,
    ) -> None:
        """Combine 2-5 images into one composition."""
        mode = detect_mode(force_json=json_output, force_human=human_output)
        client = _make_client(api_key, api_url, mode, quiet)
        urls = []
        for img in images:
            resolved = _resolve_input(img)
            resp = client.upload_file("/v1/upload", resolved)
            urls.append(resp["upload_url"])
        body: dict[str, Any] = {
            "input_image_urls": urls,
            "prompt": prompt or "Combine these images naturally",
        }
        _add_optional(body, "model", model)
        _add_optional(body, "aspect_ratio", size)
        _add_optional(body, "image_size", image_size)
        _add_optional(body, "strictness", strictness)
        _run_generation(
            client=client,
            endpoint="/v1/generate/combine",
            body=body,
            mode=mode,
            quiet=quiet,
            command="combine",
            output=output,
            output_dir=output_dir,
            fmt=fmt,
        )
