"""Depicta CLI — AI image generation from the terminal."""

__version__ = "1.0.0"
