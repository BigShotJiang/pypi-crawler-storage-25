"""Depicta CLI — entry point, subcommand registration."""

from __future__ import annotations

import sys

import typer

from depicta import __version__
from depicta.commands import auth, docs, generate, guidelines, jobs, process, story, utility
from depicta.errors import DepictaError
from depicta.output import OutputMode, detect_mode, print_error

app = typer.Typer(
    name="depicta",
    no_args_is_help=True,
    add_completion=False,
    pretty_exceptions_enable=False,
)

# Register grouped subcommands.
app.add_typer(auth.app, name="auth", help="Manage authentication")
app.add_typer(guidelines.app, name="guidelines", help="Content guidelines")
app.add_typer(jobs.app, name="jobs", help="Generation jobs")
app.add_typer(process.app, name="process", help="Image processing commands")

# Register top-level commands from each module.
docs.register(app)
generate.register(app)
story.register(app)
utility.register(app)


def app_main() -> None:
    """CLI entry point. Wraps Typer with global error handling."""
    try:
        app()
    except DepictaError as e:
        mode = detect_mode()
        print_error(e.to_dict(), mode)
        sys.exit(e.exit_code)
    except SystemExit:
        raise
    except KeyboardInterrupt:
        sys.exit(1)
    except Exception as e:
        mode = detect_mode()
        print_error({"error": "general_error", "message": str(e)}, mode)
        sys.exit(1)
