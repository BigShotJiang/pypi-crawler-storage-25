# ACL Python SDK (acl-layer-py)

Official Python client for the **Adaptive Context Layer (ACL)**. Stop silent LLM failures, optimize context delivery, and ensure long-session reliability with a single, plug-and-play interface.

---

## 🚀 Installation

```bash
# Recommended: Install via pip
pip install acl-layer-py
```

---

## 🛠️ Configuration & Setup

ACL is designed to be developer-friendly. You can initialize the client in multiple ways:

### 1. Direct Initialization (Plug-and-Play)
Ideal for quick standalone scripts and rapid prototyping.
```python
from acl import ACLClient

client = ACLClient(api_key="sk-acl-...")
```

### 2. Context Manager (Best Practice)
Automatically handles session cleanup and resource management.
```python
with ACLClient(api_key="sk-acl-...") as client:
    # Your code here
    pass
```

### 3. Environment Variables
ACL automatically looks for `ACL_BASE_URL` if no URL is provided.
```python
# System Environment: ACL_BASE_URL="https://your-private-instance.com"
client = ACLClient(api_key="sk-acl-...")
```

---

## 🧠 Core Use Cases

### A. Smart Multi-Provider Completion
Provide multiple keys, and let ACL handle the routing, retries, and window optimization automatically.

```python
with ACLClient(api_key="sk-acl-...") as client:
    result = client.complete(
        prompt="Analyze these 50 log files for patterns...",
        # ACL picks the best provider/model based on the task
        keys={
            "openai": "sk-proj-...",
            "anthropic": "sk-ant-...",
            "google": "AIza..."
        },
        session_id="log_analysis_001",
        max_retries=3
    )
    
    if result["success"]:
        print(f"Outcome: {result['response']}")
        print(f"Optimized via: {result['provider']}")
```

### B. Manual Context Optimization
Use ACL to get the "Diagnostic Baseline" before calling your own LLM logic.

```python
with ACLClient(api_key="sk-acl-...") as client:
    sync = client.adaptive_window(
        text="A very long document...",
        model="gpt-4o"
    )
    
    # Get the precise token budget for your direct call
    budget = sync["window"]["final_token_budget"]
    print(f"Optimal Window: {budget} tokens")
```

---

## 🛡️ Reliability & Safety

The SDK is pre-configured with enterprise-grade reliability:
- **Automatic Retries**: Handles 429 (Rate Limit) and 5xx errors with exponential backoff.
- **Silent Failure Detection**: Automatically retries if an LLM returns empty/broken text.
- **Loop Breaking**: Detects recursive agent behavior and attempts "Prompt Surgery" to break the cycle.

---

## 📊 Telemetry & Insights
Track exactly how much context you're saving and the health of your sessions.

```python
telemetry = client.get_telemetry(result)
print(f"Processing Time: {telemetry['processing_time_ms']}ms")
print(f"Context Health: {result['context_health']['status']}")
```

---

## 🔒 Security & Privacy
- **Direct Execution**: All calls to OpenAI/Anthropic are made **directly from your machine**. 
- **Key Safety**: Your LLM keys are used locally and are **never transmitted** to ACL servers.
- **Privacy-First**: Only prompt metadata (size, domain) is used for optimization.

---

## 📄 License
MIT License. Copyright (c) 2026 ACL Team.