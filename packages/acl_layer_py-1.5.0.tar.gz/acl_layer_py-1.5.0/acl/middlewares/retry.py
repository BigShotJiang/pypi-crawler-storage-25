import time
from typing import Any, Dict, Callable
from acl.middlewares.base import ACLMiddleware
from acl.exceptions import ACLSilentFailure


class RetryMiddleware(ACLMiddleware):
    """
    Standardizes retry logic across providers.
    Includes detection of silent failures (empty responses).
    """

    def __call__(self, params: Dict[str, Any], next_call: Callable) -> Dict[str, Any]:
        max_retries = params.get("max_retries", 3)
        last_error = None

        for attempt in range(max_retries):
            params["_attempt"] = attempt + 1
            try:
                # Execute next in chain (LoopDetection -> Normalization -> Provider)
                result = next_call(params)

                # Detect Silent Failure (Phase 1/2)
                # If NormalizationMiddleware is in chain, it returns a dict with 'text'
                if isinstance(result, dict) and not result.get("text", "").strip():
                    # We only treat it as a failure if it's supposed to have text
                    # (Filtering out potential valid empty responses if any)
                    raise ACLSilentFailure(
                        "LLM returned an empty response. Triggering retry."
                    )

                return result

            except Exception as e:
                last_error = e
                # Exponential backoff
                if attempt < max_retries - 1:
                    wait_time = 2**attempt
                    time.sleep(wait_time)

        raise last_error or Exception("All retries exhausted")
