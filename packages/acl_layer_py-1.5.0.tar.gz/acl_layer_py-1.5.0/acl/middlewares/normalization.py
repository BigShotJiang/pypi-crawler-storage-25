import time
from typing import Any, Dict, Callable
from acl.middlewares.base import ACLMiddleware


class NormalizationMiddleware(ACLMiddleware):
    """
    Standardizes and enriches the final response object.
    Phase 4: Response completeness (finish_reason).
    Phase 8: Future metrics placeholders.
    """

    def __call__(self, params: Dict[str, Any], next_call: Callable) -> Dict[str, Any]:
        start_time = time.time()

        # 1. Execute next in chain (Provider)
        response = next_call(params)

        # 2. Enrich and Normalize
        latency_ms = int((time.time() - start_time) * 1000)

        # Ensure parity with ACLUniversalSchema/ACLResponse v1.1
        final_response = {
            "text": response.get("text", ""),
            "response": response.get("text", ""),  # Alias for README parity
            "success": response.get("success", True),
            "provider": params.get("provider", "unknown"),
            "model": params.get("model", "unknown"),
            "finish_reason": response.get("finish_reason", "unknown"),
            "tokens_input": response.get("tokens_input", 0),
            "tokens_output": response.get("tokens_output", 0),
            "total_tokens": response.get("total_tokens", 0),
            "latency_ms": latency_ms,
            "retries": params.get("_attempt", 1) - 1,
            "attempts_made": params.get("_attempt", 1),  # Explicit SDK field
            "context_health": params.get("_context_health", {}),
            "loop_detected": response.get("loop_detected", False),
            "error_code": response.get("error_code", None),
            "error_message": response.get("error_message", None),
            "budget_fallback_used": params.get("budget_fallback_used", False),
            "raw_response": response.get("raw_response", None),
        }

        return final_response
