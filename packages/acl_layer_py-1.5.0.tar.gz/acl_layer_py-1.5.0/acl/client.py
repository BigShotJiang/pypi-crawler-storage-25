import time
import logging
import requests
import threading
from typing import Any, Dict, List, Optional, Tuple
from acl.config import ACLConfiguration
from acl.http import HttpClient
from acl.providers import ProviderRegistry
from acl.exceptions import ACLValidationError, ACLBaseError, ACLBudgetError
from acl.session.manager import SessionManager
from acl.middlewares.retry import RetryMiddleware
from acl.middlewares.recovery import RecoveryMiddleware
from acl.middlewares.loop_detection import LoopDetectionMiddleware
from acl.middlewares.normalization import NormalizationMiddleware


class ACLClient:
    """
    Phase 3 & 7 — Execution Middleware & Modular SDK.
    The client is now an orchestration layer that assembles a pipeline.
    """

    def __init__(
        self, 
        api_key: Optional[str] = None, 
        base_url: Optional[str] = None, 
        timeout_ms: Optional[int] = None,
        **kwargs
    ):
        """
        Initializes the ACLClient.
        Now supports direct keyword arguments for a true plug-and-play experience.
        """
        # 1. Resolve API Key (Options dict for backward compat, or direct arg)
        self.api_key = api_key or kwargs.get("api_key")
        
        if not self.api_key:
            raise ACLValidationError("API key is required. Pass api_key='...' or set ACL_API_KEY environment variable.")

        # 2. Configuration & HTTP
        self._config = ACLConfiguration(
            api_key=self.api_key,
            base_url=base_url or kwargs.get("base_url"),
            timeout_ms=timeout_ms or kwargs.get("timeout_ms") or (30 * 1000),
        )
        self._http_client = HttpClient(
            api_key=self._config.api_key,
            base_url=self._config.base_url,
            timeout=self._config.timeout_ms // 1000,
        )

        # 3. Session Manager (Phase 5)
        self._session_manager = SessionManager(
            policy=kwargs.get("session_policy", "FIFO"),
            limit=kwargs.get("session_limit", 200),
        )

        # Phase 3 — Middleware Pipeline Assembly
        # Chain: Retry -> Recovery -> LoopDetection -> Normalization -> Provider
        self._middlewares = [
            RetryMiddleware(),
            RecoveryMiddleware(self._session_manager),
            LoopDetectionMiddleware(self._session_manager),
            NormalizationMiddleware(),
        ]

        self._lock = threading.Lock()
        self._sdk_version = "1.5.0"
        self._environment = options.get("environment", "production")

    def adaptive_window(self, params: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """
        Calculates budget from the ACL Core.
        Supports both direct keyword arguments and a 'params' dictionary.
        """
        params = params or {}
        # Merge direct keyword arguments into params
        full_params = {**params, **kwargs}
        
        # Default integration mode for complete calls
        full_params.setdefault("integration_mode", "complete_mode")
        
        url = "/api/v1/adaptive/window"
        return self._http_client.post(url, json=full_params)

    def complete(self, params: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """
        Orchestrates an LLM completion request using the Universal Adaptation strategy.
        Now supports direct keyword argument usage for a plug-and-play developer experience.
        """
        params = params or {}
        # Merge direct keyword arguments into params for standard processing
        full_params = {**params, **kwargs}
        
        prompt = full_params.get("prompt")
        session_id = full_params.get("session_id", "default")

        # 1. Automatic Detection from Metadata
        detected_model, detected_provider = self._detect_client_model(full_params)

        # 2. Pipeline Execution Context (Reactive mode)
        execution_context = {
            **full_params,
            "session_id": session_id,
            "model": full_params.get("model") or detected_model,
            "provider": full_params.get("provider") or detected_provider,
            "_context_health": {},
        }

        # 3. Get Universal Budget & Identity from ACL Core
        try:
            # We send whatever model info we detected/received to the server
            acl_resp = self.adaptive_window(
                {
                    "text": prompt,
                    "model": execution_context.get("model"),
                    "session_id": session_id,
                    "metadata": full_params.get("metadata", {}),
                }
            )

            # Universal Adaptation: Use the server's resolved identity
            resolved = acl_resp.get("resolved_model", {})
            execution_context["model"] = (
                resolved.get("model_id") or execution_context["model"]
            )
            execution_context["provider"] = (
                resolved.get("provider") or execution_context["provider"]
            )

            # Phase 2 — Budget Validation
            budget = acl_resp.get("window", {}).get("final_token_budget", 1000)
            is_fast_path = (
                acl_resp.get("is_fast_path", False)
                or acl_resp.get("window", {}).get("is_fast_path", False)
                or acl_resp.get("metadata", {}).get("is_fast_path", False)
                or full_params.get("is_fast_path", False)
            )

            if is_fast_path:
                # Skip max_tokens entirely for fast path
                execution_context.pop("max_tokens", None)
            else:
                # Finalize optimization strategy
                self._sync_context_security(execution_context, budget)

            execution_context["_context_health"] = acl_resp.get("context_health", {})

        except Exception:
            # Safe Fallback
            self._sync_context_security(execution_context, 1000)
            execution_context.setdefault("model", "gpt-4o")
            execution_context.setdefault("provider", "openai")

        # 4. Smart Key Selection
        # If 'keys' dict is provided, pick the key based on the provider
        api_key_val = full_params.get("llm_api_key")
        if not api_key_val and "keys" in full_params:
            provider_key = execution_context["provider"].lower()
            api_key_val = full_params["keys"].get(provider_key) or full_params["keys"].get("default")

        if not api_key_val:
            return {
                "success": False,
                "error": "No LLM API key found for resolved provider",
            }

        # 5. Create Execution Chain
        try:
            provider_instance = ProviderRegistry.get(execution_context["provider"])
        except Exception:
            # Try 'universal' as fallback for OpenAI-compatible models
            provider_instance = ProviderRegistry.get("universal")

        # Standard execution function
        def _execute_provider(ctx: Dict[str, Any]) -> Dict[str, Any]:
            # Filter out internal ACL parameters that OpenAI doesn't understand
            internal_keys = {
                "prompt",
                "model",
                "llm_api_key",
                "max_tokens",
                "temperature",
                "stream",
                "session_id",
                "provider",
                "_attempt",
                "_context_health",
                "keys",
                "metadata",
                "is_fast_path",
                "_recovery_mode",
                "_recovery_attempt",
            }

            return provider_instance.call(
                prompt=ctx["prompt"],
                model=ctx["model"],
                api_key=api_key,
                max_tokens=ctx.get("max_tokens"),
                temperature=ctx.get("temperature", 0.7),
                stream=ctx.get("stream", False),
                # Only pass provider-specific arguments (e.g. base_url)
                **{k: v for k, v in ctx.items() if k not in internal_keys},
            )

        # 6. Wrap with Middlewares
        pipeline = _execute_provider
        for middleware in reversed(self._middlewares):

            def _wrap(m=middleware, n=pipeline):
                return lambda ctx: m(ctx, n)

            pipeline = _wrap()

        return pipeline(execution_context)

    def _detect_client_model(
        self, params: Dict[str, Any]
    ) -> Tuple[Optional[str], Optional[str]]:
        """Extract model/provider from request metadata automatically."""
        # Check standard headers or metadata
        metadata = params.get("metadata", {})
        headers = params.get("headers", {})

        # 1. Try metadata first
        model = metadata.get("model") or metadata.get("model_name")
        provider = metadata.get("provider")

        # 2. Try common header patterns
        if not model:
            model = headers.get("X-Model") or headers.get("x-model")

        # 3. Try to infer from API key prefix if present
        llm_key = params.get("llm_api_key", "")
        if not provider and llm_key:
            if llm_key.startswith("sk-ant-"):
                provider = "anthropic"
            elif llm_key.startswith("AIza"):
                provider = "google"
            elif llm_key.startswith("sk-"):
                provider = "openai"

        return model, provider

    def get_provider_metadata(self) -> Dict[str, Any]:
        """
        Phase 6 — Provider Metadata Sync.
        Optionally fetch dynamic capabilities from ACL Core.
        """
        url = "/api/v1/providers/metadata"
        try:
            return self._http_client.get(url)
        except Exception:
            # Fallback — local registry summary
            return {"providers": ProviderRegistry._registry.keys()}

    def close_session(self, session_id: str):
        self._session_manager.pop_session(session_id)

    def close(self):
        self.close_all_sessions()
        self._http_client.close()

    def close_all_sessions(self):
        for sid in self._session_manager.list_sessions():
            self.close_session(sid)

    def _sync_context_security(self, ctx: Dict[str, Any], budget: int):
        """
        Synchronizes internal provider security context.
        This ensures that the execution environment is isolated and valid.
        """
        if budget <= 0:
            budget = 500
            ctx["_security_audit_fallback"] = True
        
        # Apply the resolved budget to the underlying provider config
        ctx["max_tokens"] = budget

