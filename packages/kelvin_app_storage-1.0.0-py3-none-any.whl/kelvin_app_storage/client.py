"""Redis-backed storage client for Kelvin applications."""

import os
from typing import Any

import redis

from kelvin_app_storage.constants import (
    DEFAULT_REDIS_HOST,
    DEFAULT_REDIS_PORT,
    ENV_KELVIN_APP_STORAGE_HOST,
    ENV_KELVIN_APP_STORAGE_PORT,
    ENV_KELVIN_APP_STORAGE_PREFIX,
)
from kelvin_app_storage.logger import logger
from kelvin_app_storage.utils import (
    deserialize_value,
    get_prefix,
    resolve_key,
    serialize_value,
)


class StorageClient:
    """Client for reading and writing values to a Redis-backed application storage.

    Keys are automatically prefixed with an application identifier unless
    ``no_prefix`` is set to ``True``.
    """

    def __init__(self, no_prefix: bool = False) -> None:
        """Initialize the storage client.

        Args:
            no_prefix: If True, keys are stored without an application prefix.

        Raises:
            ValueError: If KELVIN_APP_STORAGE_PORT is not a valid integer.
            redis.ConnectionError: If the Redis connection cannot be established.
        """
        self.host = os.getenv(ENV_KELVIN_APP_STORAGE_HOST, DEFAULT_REDIS_HOST)
        port_str = os.getenv(ENV_KELVIN_APP_STORAGE_PORT, str(DEFAULT_REDIS_PORT))
        try:
            self.port: int = int(port_str)
        except ValueError:
            logger.exception("Invalid port value, must be an integer", port=port_str)
            raise ValueError(f"Invalid KELVIN_APP_STORAGE_PORT: {port_str!r} is not a valid integer")

        self.no_prefix: bool = no_prefix
        prefix = os.getenv(ENV_KELVIN_APP_STORAGE_PREFIX, None)
        if not no_prefix and prefix is None:
            prefix = get_prefix()
        self.prefix: str | None = prefix

        try:
            self.client = redis.Redis(host=self.host, port=self.port, decode_responses=True)
            self.client.ping()
            logger.info("Connected to Redis", host=self.host, port=self.port)
        except redis.ConnectionError as e:
            logger.exception("Failed to connect to Redis", host=self.host, port=self.port)
            raise e

    def __repr__(self) -> str:
        """Return a developer-friendly representation of the client."""
        return (
            f"StorageClient(host={self.host!r}, port={self.port}, prefix={self.prefix!r}, no_prefix={self.no_prefix})"
        )

    def __str__(self) -> str:
        """Return a human-readable summary of stored key-value pairs."""
        keys = self.list_keys()
        if not keys:
            return "(empty storage)"

        max_key_len = max(len(str(k)) for k in keys)
        header = f"{'Key':<{max_key_len}}  Value"
        separator = f"{'---':<{max_key_len}}  -----"
        lines = [header, separator]
        for key in sorted(keys):
            value = self.client.get(key)
            lines.append(f"{key:<{max_key_len}}  {value}")
        return "\n".join(lines)

    def get(self, key: str) -> Any:
        """Retrieve a value from storage by key.

        Args:
            key: The storage key to look up.

        Returns:
            The deserialized value (str, int, float, bool, list, or dict),
            or None if the key does not exist.

        Raises:
            redis.RedisError: If a Redis error occurs.
        """
        resolved = resolve_key(key, self.prefix, self.no_prefix)
        try:
            raw = self.client.get(resolved)
            if raw is None:
                return None
            return deserialize_value(str(raw))
        except redis.RedisError:
            logger.exception("Failed to get key from storage", key=resolved)
            raise

    def set(self, key: str, value: Any) -> bool | None:
        """Store a value in storage under the given key.

        Args:
            key: The storage key.
            value: The value to store. Supported types are str, int, float,
                bool, list, and dict.

        Returns:
            True if the key was set, None if it was not set due to
            Redis conditional flags.

        Raises:
            TypeError: If the value type is not supported.
            redis.RedisError: If a Redis error occurs.
        """
        resolved = resolve_key(key, self.prefix, self.no_prefix)
        try:
            value = serialize_value(value)
        except TypeError:
            logger.exception("Failed to parse value", key=resolved)
            raise
        try:
            resp = self.client.set(resolved, value)
            logger.debug("Set key in storage", key=resolved, response=resp)
            return bool(resp)
        except redis.RedisError:
            logger.exception("Failed to set key in storage", key=resolved)
            raise

    def list_keys(self) -> Any:
        """Return all keys currently stored in Redis.

        Returns:
            A list of keys.

        Raises:
            redis.RedisError: If a Redis error occurs.
        """
        try:
            return self.client.keys()
        except redis.RedisError:
            logger.exception("Failed to list keys from storage")
            raise
