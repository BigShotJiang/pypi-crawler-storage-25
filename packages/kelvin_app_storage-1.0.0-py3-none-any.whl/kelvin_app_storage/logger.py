"""Logging configuration for the kelvin-app-storage library."""

import logging
import os

import structlog

kelvin_app_storage_logger = logging.getLogger("kelvin_app_storage")
kelvin_app_storage_logger.setLevel(
    logging.DEBUG if os.getenv("KELVIN_APP_STORAGE_LOG_LEVEL", "INFO") == "DEBUG" else logging.INFO
)

logger = structlog.wrap_logger(
    kelvin_app_storage_logger,
    processors=[
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.JSONRenderer(),
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    context_class=dict,
)
