"""Utility functions for key prefix generation and value serialization."""

import json
from typing import Any
from uuid import uuid4

import yaml

from kelvin_app_storage.constants import APP_YAML
from kelvin_app_storage.logger import logger


def get_prefix() -> str:
    """Return a storage key prefix derived from app.yaml, or a random UUID if unavailable."""
    if not APP_YAML.exists():
        fallback = str(uuid4())
        logger.warning("app.yaml not found, using generated prefix", prefix=fallback)
        return fallback

    try:
        with APP_YAML.open("r") as f:
            data: dict[str, Any] = yaml.safe_load(f)
            if "info" in data:
                app_version = data.get("info", {}).get("version", "")
                app_name = data.get("info", {}).get("name", "")
            else:
                app_version = data.get("version", "")
                app_name = data.get("name", "")
            return f"{app_name}_{app_version}"
    except (yaml.YAMLError, OSError):
        fallback = str(uuid4())
        logger.exception("Failed to read app.yaml, using generated prefix", prefix=fallback)
        return fallback


def serialize_value(value: Any) -> str:
    """Serialize a value to a string suitable for Redis storage.

    Args:
        value: The value to serialize. Supported types are str, int, float,
            bool, list, and dict.

    Returns:
        A string representation of the value.

    Raises:
        TypeError: If the value type is not supported.
    """
    if isinstance(value, bool):
        return str(value).lower()
    elif isinstance(value, str):
        return value
    elif isinstance(value, int):
        return str(value)
    elif isinstance(value, float):
        return str(value)
    elif isinstance(value, list):
        return json.dumps(value)
    elif isinstance(value, dict):
        return json.dumps(value)
    else:
        raise TypeError(f"Unsupported type: {type(value)}")


def deserialize_value(value: str) -> Any:
    """Deserialize a Redis string back to its original Python type.

    Attempts JSON parsing first (for lists and dicts), then boolean,
    numeric types, and falls back to returning the raw string.

    Args:
        value: The string value retrieved from Redis.

    Returns:
        The deserialized Python value.
    """
    try:
        parsed = json.loads(value)
        if isinstance(parsed, (list, dict)):
            return parsed
    except (json.JSONDecodeError, TypeError):
        pass

    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False

    try:
        return int(value)
    except ValueError:
        pass

    try:
        return float(value)
    except ValueError:
        pass

    return value


def resolve_key(key: str, prefix: str | None, no_prefix: bool) -> str:
    """Return the full storage key, applying the prefix if enabled.

    Args:
        key: The raw storage key.
        prefix: The prefix to prepend, or None if no prefix is configured.
        no_prefix: If True and prefix is None, the key is returned as-is.

    Returns:
        The resolved key with or without prefix.
    """
    if no_prefix and prefix is None:
        return key
    return f"{prefix}_{key}"
