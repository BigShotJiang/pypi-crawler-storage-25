"""Version information for the Reduct package."""

__version__ = "1.19.0"
