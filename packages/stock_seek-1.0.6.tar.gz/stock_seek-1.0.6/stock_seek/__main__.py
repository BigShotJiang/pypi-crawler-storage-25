"""
Stock Seek - 支持 python -m stock_seek 调用
"""
from stock_seek.cli.main import main

if __name__ == "__main__":
    main()
