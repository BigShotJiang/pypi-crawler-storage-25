"""
百度财经API配置
Cookie和acs-token需要从浏览器获取，会定期过期
"""
import json
from pathlib import Path
from typing import Optional, Tuple

# Token存储文件路径
_TOKEN_FILE = Path.home() / ".stock_cache" / "baidu_token.json"


def set_token_file_path(path: Path):
    """
    设置全局Token文件路径

    Args:
        path: 新的Token文件路径
    """
    global _TOKEN_FILE
    _TOKEN_FILE = Path(path)


def get_token_file_path() -> Path:
    """获取Token文件路径"""
    return _TOKEN_FILE


def get_baidu_credentials(token_path: Optional[Path] = None) -> Tuple[str, str]:
    """
    获取百度财经认证信息

    从本地JSON文件读取，文件格式：
    {
        "cookie": "完整的Cookie字符串",
        "acs_token": "acs-token值"
    }

    Args:
        token_path: 可选的自定义Token文件路径

    Returns:
        (cookie, acs_token) 元组
    """
    file_path = token_path or _TOKEN_FILE
    if file_path.exists():
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                cookie = data.get('cookie', '')
                acs_token = data.get('acs_token', '')
                return cookie, acs_token
        except Exception as e:
            print(f"读取Token文件失败: {e}")

    return "", ""


def get_token_help_message(token_path: Optional[Path] = None) -> str:
    """
    获取Token配置帮助信息

    Args:
        token_path: 可选的自定义Token文件路径

    Returns:
        帮助信息字符串
    """
    file_path = token_path or _TOKEN_FILE
    return f"""
百度财经Token配置说明
====================

Token文件路径: {file_path}

请按以下步骤获取Token：

1. 打开浏览器访问 https://gushitong.baidu.com/

2. 按F12打开开发者工具，切换到Network（网络）标签

3. 在页面中搜索一只股票（如：600519）

4. 在Network标签中找到名为 "getquotation" 的请求

5. 点击该请求，在Headers（请求头）中找到：
   - Cookie: 复制完整的Cookie值
   - acs-token: 复制acs-token值

6. 创建或编辑Token文件 {file_path}
   内容格式如下：

   {{
       "cookie": "这里粘贴完整的Cookie值",
       "acs_token": "这里粘贴acs-token值"
   }}

7. 保存文件后重新运行命令

注意：Token会定期过期，如果请求失败请重新获取。
"""
