"""
中国A股数据获取器
支持新浪(xl)和百度(bd)两个数据源
"""
from typing import Tuple, Optional
import pandas as pd
import akshare
from datetime import datetime
import requests
from urllib.parse import quote
import time
import random

from stock_seek.fetchers.base_fetcher import BaseDataFetcher
from stock_seek.core.exceptions import DataFetchError
from stock_seek.core.config import Config, DataSource


class ChinaStockFetcher(BaseDataFetcher):
    """中国A股数据获取器"""

    # 百度财经API配置
    BAIDU_API_URL = "https://finance.pae.baidu.com/vapi/v1/getquotation"

    # 请求头模板
    BAIDU_HEADERS_TEMPLATE = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',
        'Accept': 'application/vnd.finance-web.v1+json',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Referer': 'https://gushitong.baidu.com/',
        'Origin': 'https://gushitong.baidu.com',
        'sec-ch-ua': '"Not:A-Brand";v="99", "Microsoft Edge";v="145", "Chromium";v="145"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-site': 'same-site',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'priority': 'u=1, i',
    }

    def __init__(self, source: DataSource = "xl"):
        """
        初始化A股数据获取器

        Args:
            source: 数据源, "xl"(新浪) 或 "bd"(百度)
        """
        self.source = source
        self._stock_list_cache = None
        self._session = requests.Session()

        # 百度认证信息
        self._baidu_cookie = ""
        self._baidu_acs_token = ""
        if source == "bd":
            self._load_baidu_credentials()

    def _load_baidu_credentials(self):
        """加载百度认证信息"""
        try:
            from stock_seek.fetchers.baidu_config import get_baidu_credentials
            self._baidu_cookie, self._baidu_acs_token = get_baidu_credentials()
        except ImportError:
            pass

    def _update_baidu_headers(self) -> dict:
        """更新百度请求头"""
        headers = self.BAIDU_HEADERS_TEMPLATE.copy()
        if self._baidu_cookie:
            headers['Cookie'] = self._baidu_cookie
        if self._baidu_acs_token:
            headers['acs-token'] = self._baidu_acs_token
        return headers

    def _is_kc_stock(self, stock_code: str) -> bool:
        """判断是否为科创板股票"""
        return stock_code.startswith('688')

    def _build_baidu_url(self, stock_code: str, stock_name: str) -> str:
        """构建百度API请求URL"""
        encoded_name = quote(stock_name, safe='')
        is_kc = 1 if self._is_kc_stock(stock_code) else 0
        params = {
            'srcid': '5353',
            'pointType': 'string',
            'group': 'quotation_kline_ab',
            'query': stock_code,
            'code': stock_code,
            'market_type': 'ab',
            'newFormat': '1',
            'name': encoded_name,
            'is_kc': str(is_kc),
            'ktype': 'day',
            'finClientType': 'pc'
        }
        param_str = '&'.join([f"{k}={v}" for k, v in params.items()])
        return f"{self.BAIDU_API_URL}?{param_str}"

    def _parse_baidu_response(self, response_data: dict, stock_code: str) -> pd.DataFrame:
        """解析百度财经API响应"""
        try:
            if 'ResultCode' in response_data and response_data['ResultCode'] != 0:
                error_msg = response_data.get('ErrorMsg', '未知错误')
                raise DataFetchError(f"API返回错误: {error_msg}")

            result = response_data.get('Result', {})
            market_data = result.get('newMarketData', {})

            if not market_data:
                raise DataFetchError(f"股票 {stock_code} K线数据为空")

            market_data_str = market_data.get('marketData', '')
            if not market_data_str:
                raise DataFetchError(f"股票 {stock_code} marketData为空")

            records = []
            for day_data in market_data_str.split(';'):
                if not day_data.strip():
                    continue

                fields = day_data.split(',')
                if len(fields) < 12:
                    continue

                def safe_float(value, default=0.0):
                    if value in ['--', '', None] or (isinstance(value, str) and value.strip() == ''):
                        return default
                    try:
                        return float(value)
                    except (ValueError, TypeError):
                        return default

                def safe_int(value, default=0):
                    if value in ['--', '', None] or (isinstance(value, str) and value.strip() == ''):
                        return default
                    try:
                        return int(float(value))
                    except (ValueError, TypeError):
                        return default

                record = {
                    '日期': fields[1],
                    '开盘': safe_float(fields[2]),
                    '收盘': safe_float(fields[3]),
                    '成交量': safe_int(fields[4]),
                    '最高': safe_float(fields[5]),
                    '最低': safe_float(fields[6]),
                    '成交额': safe_float(fields[7]),
                    '涨跌额': safe_float(fields[8]),
                    '涨跌幅': safe_float(fields[9]),
                    '换手率': safe_float(fields[10]),
                    '昨收': safe_float(fields[11]),
                }

                if record['开盘'] == 0 and record['收盘'] == 0 and record['最高'] == 0 and record['最低'] == 0:
                    continue

                records.append(record)

            if not records:
                raise DataFetchError(f"股票 {stock_code} 无有效K线数据")

            df = pd.DataFrame(records)
            df['日期'] = pd.to_datetime(df['日期'])
            df = df.sort_values('日期').reset_index(drop=True)

            df['振幅'] = df.apply(
                lambda row: ((row['最高'] - row['最低']) / row['昨收'] * 100) if row['昨收'] > 0 else 0,
                axis=1
            ).round(2)

            return df

        except DataFetchError:
            raise
        except Exception as e:
            raise DataFetchError(f"解析响应数据失败: {str(e)}")

    def fetch_stock_data(
        self,
        stock_code: str,
        stock_name: str,
        start_date: str,
        end_date: Optional[str] = None
    ) -> Tuple[str, pd.DataFrame]:
        """获取A股历史数据"""
        try:
            if self.source == "xl":
                return self._fetch_from_xl(stock_code, stock_name, start_date, end_date)
            elif self.source == "bd":
                return self._fetch_from_bd(stock_code, stock_name, start_date, end_date)
            else:
                return self._fetch_from_xl(stock_code, stock_name, start_date, end_date)
        except Exception as e:
            raise DataFetchError(f"获取股票 {stock_code} 数据失败: {str(e)}")

    def _fetch_from_xl(
        self,
        stock_code: str,
        stock_name: str,
        start_date: str,
        end_date: Optional[str]
    ) -> Tuple[str, pd.DataFrame]:
        """从新浪获取数据"""
        try:
            df = akshare.stock_zh_a_hist(
                symbol=stock_code,
                period="daily",
                start_date=start_date,
                end_date=end_date,
                adjust=""
            )

            if df.empty:
                raise DataFetchError(f"股票 {stock_code} 数据为空")

            df['成交量'] = (df['成交量'] * 100)  # 手转为股

            # 计算衍生指标
            df = self.calculate_derived_metrics(df)

            return stock_code, df

        except Exception as e:
            raise DataFetchError(f"从新浪获取 {stock_code} 失败: {str(e)}")

    def _fetch_from_bd(
        self,
        stock_code: str,
        stock_name: str,
        start_date: str,
        end_date: Optional[str]
    ) -> Tuple[str, pd.DataFrame]:
        """从百度获取数据"""
        if not self._baidu_cookie or not self._baidu_acs_token:
            from stock_seek.fetchers.baidu_config import get_token_help_message
            raise DataFetchError(get_token_help_message())

        try:
            url = self._build_baidu_url(stock_code, stock_name)
            time.sleep(random.uniform(0.1, 0.3))

            response = self._session.get(url, headers=self._update_baidu_headers(), timeout=30)

            if response.status_code == 403:
                from stock_seek.fetchers.baidu_config import get_token_help_message, get_token_file_path
                raise DataFetchError(
                    f"请求被拒绝(403)，Cookie或acs-token可能已过期。\n"
                    f"股票代码: {stock_code}\n"
                    f"请更新Token: stock-seek config --baidu-show\n"
                    f"{get_token_help_message()}"
                )

            response.raise_for_status()
            data = response.json()

            df = self._parse_baidu_response(data, stock_code)

            if df.empty:
                raise DataFetchError(f"股票 {stock_code} 数据为空")

            if '日期' in df.columns:
                start_dt = pd.to_datetime(start_date, format='%Y%m%d')
                df = df[df['日期'] >= start_dt]

                if end_date:
                    end_dt = pd.to_datetime(end_date, format='%Y%m%d')
                    df = df[df['日期'] <= end_dt]

            df = self.calculate_derived_metrics(df)

            return stock_code, df

        except DataFetchError:
            raise
        except requests.RequestException as e:
            raise DataFetchError(f"请求百度财经API失败: {str(e)}")
        except Exception as e:
            raise DataFetchError(f"从百度获取 {stock_code} 失败: {str(e)}")

    def get_stock_list(self) -> dict:
        """获取A股股票列表"""
        if self._stock_list_cache is not None:
            return self._stock_list_cache

        try:
            # 从stock_spots_lp获取所有股票实时行情
            from stock_seek.utils.data_api import stock_spots_lp
            spots = stock_spots_lp(us=False)

            if not spots:
                raise DataFetchError("获取股票实时行情失败")

            stock_list = {}
            for code, data in spots.items():
                # spots字典的key已经是去除后缀的代码
                name = data.get('name', '')

                # 过滤掉ST股票和退市股票
                if 'ST' in name or '退' in name:
                    continue

                stock_list[code] = {
                    'code': code,
                    'name': name
                }

            self._stock_list_cache = stock_list
            return stock_list

        except Exception as e:
            raise DataFetchError(f"获取A股股票列表失败: {str(e)}")
