"""
数据获取器工厂
根据股票类型创建对应的数据获取器
"""
from stock_seek.fetchers.base_fetcher import BaseDataFetcher
from stock_seek.fetchers.china_fetcher import ChinaStockFetcher
from stock_seek.fetchers.us_fetcher import USStockFetcher
from stock_seek.fetchers.baidu_fetcher import BaiduStockFetcher
from stock_seek.core.config import DataSource


class DataFetcherFactory:
    """数据获取器工厂类"""

    @staticmethod
    def create_fetcher(us: bool = False, source: DataSource = "xl") -> BaseDataFetcher:
        """
        创建数据获取器

        Args:
            us: 是否为美股
            source: 数据源: xl=新浪, bd=百度财经

        Returns:
            数据获取器实例
        """
        if us:
            # 美股
            if source == "bd":
                # 百度财经支持美股
                return BaiduStockFetcher(us=True)
            else:
                # 美股默认使用新浪源
                return USStockFetcher()
        else:
            # A股
            if source == "bd":
                # 百度财经A股
                return ChinaStockFetcher(source="bd")
            else:
                # A股默认使用新浪源
                return ChinaStockFetcher(source="xl")


# 为了向后兼容,提供统一的DataFetcher类
class DataFetcher:
    """数据获取器统一接口(向后兼容)"""
    
    def __init__(self, us: bool = False, source: DataSource = "xl"):
        """
        初始化数据获取器
        
        Args:
            us: 是否为美股
            source: 数据源
        """
        self.fetcher = DataFetcherFactory.create_fetcher(us=us, source=source)
    
    def fetch_stock_data(self, stock_code: str, stock_name: str, 
                        start_date: str, end_date: str = None):
        """获取股票数据"""
        return self.fetcher.fetch_stock_data(stock_code, stock_name, start_date, end_date)
    
    def get_stock_list(self) -> dict:
        """获取股票列表"""
        return self.fetcher.get_stock_list()
