"""
数据获取器基类
使用抽象基类定义统一接口,支持不同数据源
"""
from abc import ABC, abstractmethod
from typing import Tuple, Optional
import pandas as pd

from stock_seek.core.exceptions import DataFetchError


class BaseDataFetcher(ABC):
    """数据获取器抽象基类"""
    
    @abstractmethod
    def fetch_stock_data(
        self, 
        stock_code: str, 
        stock_name: str,
        start_date: str, 
        end_date: Optional[str] = None
    ) -> Tuple[str, pd.DataFrame]:
        """
        获取单只股票的历史数据
        
        Args:
            stock_code: 股票代码
            stock_name: 股票名称
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD),可选
            
        Returns:
            (股票代码, DataFrame) 元组
            
        Raises:
            DataFetchError: 数据获取失败
        """
        pass
    
    @abstractmethod
    def get_stock_list(self) -> dict:
        """
        获取股票列表
        
        Returns:
            股票代码到股票信息的映射字典
            
        Raises:
            DataFetchError: 获取股票列表失败
        """
        pass
    
    def validate_data(self, df: pd.DataFrame) -> bool:
        """
        验证数据有效性
        
        Args:
            df: 股票数据DataFrame
            
        Returns:
            数据是否有效
        """
        if df is None or df.empty:
            return False
            
        required_columns = ['开盘', '最高', '最低', '收盘', '成交量']
        return all(col in df.columns for col in required_columns)
    
    def calculate_derived_metrics(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        计算衍生指标
        
        Args:
            df: 原始股票数据
            
        Returns:
            添加了衍生指标的数据
        """
        df = df.copy()

        # 计算振幅
        df['振幅'] = ((df['最高'] - df['最低']) / df['收盘'].shift(1) * 100).round(2)

            
        return df
