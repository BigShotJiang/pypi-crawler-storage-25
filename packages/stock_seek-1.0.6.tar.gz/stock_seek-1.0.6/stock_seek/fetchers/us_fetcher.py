"""
美股数据获取器
"""
from typing import Tuple, Optional
import pandas as pd
import akshare
import pytz
from datetime import datetime
from pathlib import Path
import json

from stock_seek.fetchers.base_fetcher import BaseDataFetcher
from stock_seek.core.exceptions import DataFetchError
from stock_seek.core.config import Config


class USStockFetcher(BaseDataFetcher):
    """美股数据获取器"""
    
    def __init__(self):
        """初始化美股数据获取器"""
        self._stock_list_cache = None
        self._spot_dict = {}
    
    def fetch_stock_data(
        self, 
        stock_code: str, 
        stock_name: str,
        start_date: str, 
        end_date: Optional[str] = None
    ) -> Tuple[str, pd.DataFrame]:
        """获取美股历史数据"""
        try:
            # akshare的美股数据接口
            df = akshare.stock_us_daily(symbol=stock_code, adjust="qfq")
            
            if df is None or df.empty:
                raise DataFetchError(f"美股 {stock_code} 数据为空")
            
            # 过滤日期范围
            df['date'] = pd.to_datetime(df['date'])
            start_dt = datetime.strptime(start_date, "%Y%m%d")
            df = df[df['date'] >= start_dt]
            
            if end_date:
                end_dt = datetime.strptime(end_date, "%Y%m%d")
                df = df[df['date'] <= end_dt]
            
            # 重命名列
            df = df.rename(columns={
                'date': '日期',
                'open': '开盘',
                'high': '最高',
                'low': '最低',
                'close': '收盘',
                'volume': '成交量'
            })
            
            # 计算成交额(美股没有直接提供,用收盘价*成交量估算)
            df['成交额'] = df['收盘'] * df['成交量']
            
            # 计算衍生指标
            df = self.calculate_derived_metrics(df)
            
            return stock_code, df
            
        except Exception as e:
            raise DataFetchError(f"获取美股 {stock_code} 数据失败: {str(e)}")
    
    def get_stock_list(self) -> dict:
        """获取美股股票列表"""
        if self._stock_list_cache is not None:
            return self._stock_list_cache
        
        try:
            # 从本地缓存或API获取
            # 这里使用data_api获取实时行情作为股票列表来源
            from stock_seek.utils.data_api import stock_spots_lp
            
            spots = stock_spots_lp(us=True)
            stock_list = {}
            
            for s in spots.values():
                code = s['symbol'].split(".")[0]
                name = s['name']
                stock_list[code] = {
                    'code': code,
                    'name': name
                }
                self._spot_dict[code] = s
            
            self._stock_list_cache = stock_list
            return stock_list
            
        except Exception as e:
            raise DataFetchError(f"获取美股股票列表失败: {str(e)}")
    
    def get_spot_dict(self) -> dict:
        """获取美股实时行情字典"""
        if not self._spot_dict:
            self.get_stock_list()
        return self._spot_dict
