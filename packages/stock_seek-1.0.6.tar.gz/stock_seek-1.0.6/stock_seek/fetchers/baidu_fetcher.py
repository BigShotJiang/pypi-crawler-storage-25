"""
百度财经数据获取器
从百度财经API获取A股和美股日K线数据
"""
from typing import Tuple, Optional
import pandas as pd
import requests
from datetime import datetime
from urllib.parse import quote
import time
import random

from stock_seek.fetchers.base_fetcher import BaseDataFetcher
from stock_seek.core.exceptions import DataFetchError
from stock_seek.core.config import Config


class BaiduStockFetcher(BaseDataFetcher):
    """百度财经数据获取器（支持A股和美股）"""
    
    # 百度财经API配置
    BAIDU_API_URL = "https://finance.pae.baidu.com/vapi/v1/getquotation"
    
    # 请求头模板
    HEADERS_TEMPLATE = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',
        'Accept': 'application/vnd.finance-web.v1+json',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Referer': 'https://gushitong.baidu.com/',
        'Origin': 'https://gushitong.baidu.com',
        'sec-ch-ua': '"Not:A-Brand";v="99", "Microsoft Edge";v="145", "Chromium";v="145"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-site': 'same-site',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'priority': 'u=1, i',
    }
    
    # Cookie和acs-token需要定期更新
    # 这些值会过期，需要从浏览器获取新的值
    COOKIE = ""
    ACS_TOKEN = ""
    
    def __init__(self, us: bool = False):
        """
        初始化百度财经数据获取器
        
        Args:
            us: 是否为美股
        """
        self.us = us
        self._stock_list_cache = None
        self._session = requests.Session()
        # 从配置文件加载认证信息
        try:
            from stock_seek.fetchers.baidu_config import get_baidu_credentials
            cookie, acs_token = get_baidu_credentials()
            if cookie and acs_token:
                self.COOKIE = cookie
                self.ACS_TOKEN = acs_token
        except ImportError:
            pass
        self._update_headers()
    
    def _update_headers(self):
        """更新请求头"""
        self.HEADERS = self.HEADERS_TEMPLATE.copy()
        if self.COOKIE:
            self.HEADERS['Cookie'] = self.COOKIE
        if self.ACS_TOKEN:
            self.HEADERS['acs-token'] = self.ACS_TOKEN
    
    def set_credentials(self, cookie: str, acs_token: str):
        """
        设置认证信息
        
        Args:
            cookie: 浏览器Cookie
            acs_token: acs-token值
        """
        self.COOKIE = cookie
        self.ACS_TOKEN = acs_token
        self._update_headers()
    
    def _is_kc_stock(self, stock_code: str) -> bool:
        """判断是否为科创板股票"""
        return stock_code.startswith('688')
    
    def _build_request_url(self, stock_code: str, stock_name: str) -> str:
        """
        构建请求URL
        
        Args:
            stock_code: 股票代码
            stock_name: 股票名称
            
        Returns:
            完整的请求URL
        """
        # URL编码股票名称
        encoded_name = quote(stock_name, safe='')
        
        if self.us:
            # 美股参数
            params = {
                'srcid': '5353',
                'pointType': 'string',
                'group': 'quotation_kline_us',
                'query': stock_code,
                'code': stock_code,
                'market_type': 'us',
                'newFormat': '1',
                'name': encoded_name,
                'is_kc': '0',
                'ktype': 'day',
                'finClientType': 'pc'
            }
        else:
            # A股参数
            is_kc = 1 if self._is_kc_stock(stock_code) else 0
            params = {
                'srcid': '5353',
                'pointType': 'string',
                'group': 'quotation_kline_ab',
                'query': stock_code,
                'code': stock_code,
                'market_type': 'ab',
                'newFormat': '1',
                'name': encoded_name,
                'is_kc': str(is_kc),
                'ktype': 'day',
                'finClientType': 'pc'
            }
        
        # 构建URL
        param_str = '&'.join([f"{k}={v}" for k, v in params.items()])
        return f"{self.BAIDU_API_URL}?{param_str}"
    
    def _parse_response(self, response_data: dict, stock_code: str) -> pd.DataFrame:
        """
        解析百度财经API响应
        
        数据格式：
        - marketData: 逗号分隔的字符串，每天数据用分号分隔
        - 字段顺序: timestamp, time, open, close, volume, high, low, amount, range, ratio, turnoverratio, preClose, ma5avgprice, ma5volume, ma10avgprice, ma10volume, ma20avgprice, ma20volume
        - 停牌股票的数据可能是 '--' 占位符
        
        Args:
            response_data: API响应数据
            stock_code: 股票代码
            
        Returns:
            股票数据DataFrame
        """
        try:
            # 检查响应状态
            if 'ResultCode' in response_data and response_data['ResultCode'] != 0:
                error_msg = response_data.get('ErrorMsg', '未知错误')
                raise DataFetchError(f"API返回错误: {error_msg}")
            
            # 获取K线数据
            result = response_data.get('Result', {})
            market_data = result.get('newMarketData', {})
            
            if not market_data:
                raise DataFetchError(f"股票 {stock_code} K线数据为空")
            
            # 获取marketData字符串
            market_data_str = market_data.get('marketData', '')
            if not market_data_str:
                raise DataFetchError(f"股票 {stock_code} marketData为空")
            
            # 解析数据：按分号分割每天，按逗号分割字段
            records = []
            for day_data in market_data_str.split(';'):
                if not day_data.strip():
                    continue
                
                fields = day_data.split(',')
                if len(fields) < 12:
                    continue
                
                # 辅助函数：安全转换为float，处理 '--' 和空值
                def safe_float(value, default=0.0):
                    if value in ['--', '', None] or (isinstance(value, str) and value.strip() == ''):
                        return default
                    try:
                        return float(value)
                    except (ValueError, TypeError):
                        return default
                
                # 辅助函数：安全转换为int
                def safe_int(value, default=0):
                    if value in ['--', '', None] or (isinstance(value, str) and value.strip() == ''):
                        return default
                    try:
                        return int(float(value))
                    except (ValueError, TypeError):
                        return default
                
                # 字段顺序: timestamp, time, open, close, volume, high, low, amount, range, ratio, turnoverratio, preClose, ...
                record = {
                    '日期': fields[1],
                    '开盘': safe_float(fields[2]),
                    '收盘': safe_float(fields[3]),
                    '成交量': safe_int(fields[4]),
                    '最高': safe_float(fields[5]),
                    '最低': safe_float(fields[6]),
                    '成交额': safe_float(fields[7]),
                    '涨跌额': safe_float(fields[8]),
                    '涨跌幅': safe_float(fields[9]),
                    '换手率': safe_float(fields[10]),
                    '昨收': safe_float(fields[11]),
                }
                
                # 跳过无效数据（开盘、收盘、最高、最低都为0的情况）
                if record['开盘'] == 0 and record['收盘'] == 0 and record['最高'] == 0 and record['最低'] == 0:
                    continue
                
                records.append(record)
            
            if not records:
                raise DataFetchError(f"股票 {stock_code} 无有效K线数据")
            
            # 转换为DataFrame
            df = pd.DataFrame(records)
            
            # 确保日期格式正确
            df['日期'] = pd.to_datetime(df['日期'])
            df = df.sort_values('日期').reset_index(drop=True)
            
            # 计算振幅
            df['振幅'] = df.apply(
                lambda row: ((row['最高'] - row['最低']) / row['昨收'] * 100) if row['昨收'] > 0 else 0,
                axis=1
            ).round(2)
            
            return df
            
        except DataFetchError:
            raise
        except Exception as e:
            raise DataFetchError(f"解析响应数据失败: {str(e)}")
    
    def fetch_stock_data(
        self,
        stock_code: str,
        stock_name: str,
        start_date: str,
        end_date: Optional[str] = None
    ) -> Tuple[str, pd.DataFrame]:
        """
        获取单只股票的历史数据
        
        Args:
            stock_code: 股票代码
            stock_name: 股票名称
            start_date: 开始日期 (YYYYMMDD)
            end_date: 结束日期 (YYYYMMDD),可选
            
        Returns:
            (股票代码, DataFrame) 元组
        """
        # 检查是否设置了认证信息
        if not self.COOKIE or not self.ACS_TOKEN:
            from stock_seek.fetchers.baidu_config import get_token_help_message
            raise DataFetchError(get_token_help_message())
        
        try:
            # 构建请求URL
            url = self._build_request_url(stock_code, stock_name)
            
            # 添加随机延迟，避免请求过快
            time.sleep(random.uniform(0.1, 0.3))
            
            # 发送请求
            response = self._session.get(url, headers=self.HEADERS, timeout=30)
            
            # 检查响应状态
            if response.status_code == 403:
                from stock_seek.fetchers.baidu_config import get_token_help_message, get_token_file_path
                raise DataFetchError(
                    f"请求被拒绝(403)，Cookie或acs-token可能已过期。\n"
                    f"股票代码: {stock_code}\n"
                    f"请更新Token文件: {get_token_file_path()}\n"
                    f"{get_token_help_message()}"
                )
            
            response.raise_for_status()
            
            # 解析响应
            data = response.json()
            
            # 解析K线数据
            df = self._parse_response(data, stock_code)
            
            if df.empty:
                raise DataFetchError(f"股票 {stock_code} 数据为空")
            
            # 日期过滤
            if '日期' in df.columns:
                start_dt = pd.to_datetime(start_date, format='%Y%m%d')
                df = df[df['日期'] >= start_dt]
                
                if end_date:
                    end_dt = pd.to_datetime(end_date, format='%Y%m%d')
                    df = df[df['日期'] <= end_dt]
            
            # 计算衍生指标
            df = self.calculate_derived_metrics(df)
            
            return stock_code, df
            
        except DataFetchError:
            raise
        except requests.RequestException as e:
            raise DataFetchError(f"请求百度财经API失败: {str(e)}")
        except Exception as e:
            raise DataFetchError(f"从百度财经获取 {stock_code} 失败: {str(e)}")
    
    def get_stock_list(self) -> dict:
        """获取股票列表（A股或美股）"""
        if self._stock_list_cache is not None:
            return self._stock_list_cache
        
        try:
            # 从stock_spots_lp获取所有股票实时行情
            from stock_seek.utils.data_api import stock_spots_lp
            spots = stock_spots_lp(us=self.us)
            
            if not spots:
                raise DataFetchError("获取股票实时行情失败")
            
            stock_list = {}
            
            if self.us:
                # 美股
                for s in spots.values():
                    code = s['symbol'].split(".")[0]
                    name = s.get('name', '')
                    stock_list[code] = {
                        'code': code,
                        'name': name
                    }
            else:
                # A股
                for code, data in spots.items():
                    name = data.get('name', '')
                    
                    # 过滤掉ST股票和退市股票
                    if 'ST' in name or '退' in name:
                        continue
                    
                    stock_list[code] = {
                        'code': code,
                        'name': name
                    }
            
            self._stock_list_cache = stock_list
            return stock_list
            
        except Exception as e:
            raise DataFetchError(f"获取{'美股' if self.us else 'A股'}股票列表失败: {str(e)}")
