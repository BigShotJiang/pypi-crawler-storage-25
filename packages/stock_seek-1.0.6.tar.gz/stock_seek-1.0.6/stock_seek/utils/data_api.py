"""
外部数据 API 接口
从远程服务器获取股票实时行情数据
"""
from typing import Optional

import requests

from stock_seek.core.config import Config
from stock_seek.utils.logger import get_logger

logger = get_logger(__name__)


def stock_spots_lp(us: bool = False) -> Optional[dict[str, dict]]:
    """
    获取股票实时行情数据

    Args:
        us: 是否为美股

    Returns:
        股票行情字典，key 为股票代码，value 为行情数据
    """
    url = f"http://{Config.DATA_API_HOST}:{Config.DATA_API_PORT}/stock_zh_a_spot_lp" if not us else f"http://{Config.DATA_API_HOST}:{Config.DATA_API_PORT}/stock_us_spot_lp"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            response_data = response.json()
            if response_data.get('code') == 200:
                spot_list = response_data['data']['spots']
                spots_dict = {}
                for s in spot_list:
                    if s["circulating_shares"] <= 0:
                        continue
                    spots_dict[s["symbol"].split(".")[0]] = s
                return spots_dict
            else:
                logger.error(f"API返回错误: {response_data.get('msg')}")
                return None
        else:
            logger.error(f"请求失败，状态码: {response.status_code}")
            return None
    except Exception as e:
        logger.error(f"请求异常: {e}")
        return None
