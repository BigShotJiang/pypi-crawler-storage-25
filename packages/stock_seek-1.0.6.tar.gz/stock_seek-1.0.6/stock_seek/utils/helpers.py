"""
辅助工具函数
"""
import pandas as pd
from typing import Optional

from stock_seek.cache.cache_manager import CacheManager


def print_cache(symbol: str, us: bool = False) -> None:
    """
    打印单只股票的缓存数据
    
    Args:
        symbol: 股票代码
        us: 是否为美股
    """
    cache_manager = CacheManager(us=us)
    df = cache_manager.load_stock_data(symbol)
    
    if df is None:
        print(f"股票 {symbol} 缓存数据不存在")
        return
    
    print(f"\n股票 {symbol} 缓存数据:")
    print(f"数据行数: {len(df)}")
    print(f"日期范围: {df['日期'].iloc[0]} 至 {df['日期'].iloc[-1]}")
    print("\n最近5天数据:")
    print(df.tail().to_string())
