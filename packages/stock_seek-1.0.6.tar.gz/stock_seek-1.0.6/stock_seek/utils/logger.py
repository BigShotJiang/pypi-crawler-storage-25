"""
统一日志配置模块
提供日志记录器创建和管理功能
"""
import logging
import logging.handlers
from pathlib import Path
from typing import Optional

from stock_seek.core.config import Config


# 日志格式
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# 日志文件配置
LOG_FILE_NAME = "stock_seek.log"
LOG_MAX_BYTES = 10 * 1024 * 1024  # 10MB
LOG_BACKUP_COUNT = 5

# 日志级别
LOG_LEVEL = logging.INFO

# 全局日志是否已初始化
_log_initialized = False


def get_log_file_path() -> Path:
    """获取日志文件路径"""
    return Config.CACHE_DIR / LOG_FILE_NAME


def setup_logger(name: Optional[str] = None) -> logging.Logger:
    """
    设置并返回日志记录器

    Args:
        name: 日志记录器名称，None则返回root logger

    Returns:
        配置好的日志记录器
    """
    global _log_initialized

    if name is None:
        logger = logging.getLogger()
    else:
        logger = logging.getLogger(name)

    # 避免重复添加handler
    if logger.handlers:
        return logger

    # 确保目录存在
    Config.ensure_cache_dirs()

    # 创建formatter
    formatter = logging.Formatter(LOG_FORMAT, LOG_DATE_FORMAT)

    # 文件handler - 使用RotatingFileHandler
    log_file = get_log_file_path()
    file_handler = logging.handlers.RotatingFileHandler(
        filename=log_file,
        maxBytes=LOG_MAX_BYTES,
        backupCount=LOG_BACKUP_COUNT,
        encoding="utf-8"
    )
    file_handler.setLevel(LOG_LEVEL)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    # 控制台handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(LOG_LEVEL)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    logger.setLevel(LOG_LEVEL)
    _log_initialized = True

    return logger


def get_logger(name: str) -> logging.Logger:
    """
    获取指定名称的日志记录器

    Args:
        name: 模块名称，通常使用 __name__

    Returns:
        日志记录器
    """
    return setup_logger(name)


def init_logging() -> None:
    """初始化全局日志配置"""
    setup_logger()
