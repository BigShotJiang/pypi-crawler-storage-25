"""
Stock Seek - 重构后的主入口
提供命令行接口,支持股票搜索、缓存更新等功能
"""
import argparse
import os
import sys
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)

from stock_seek.core.config import Config
from stock_seek.core.searcher import StockSearcher
from stock_seek.cache.cache_manager import CacheManager
from stock_seek.cache.update_log_manager import UpdateLogManager
from stock_seek.utils.helpers import print_cache
from stock_seek.core.exceptions import StockFinderError


# os.environ['HTTP_PROXY'] = 'socks5://119.7.239.207:24388'
# os.environ['HTTPS_PROXY'] = 'socks5://119.7.239.207:24388'


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="Stock Seek - 股票搜索工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 更新A股缓存
  stock-seek update -t 8 -s xl
  # 更新美股缓存
  stock-seek update_us -t 6
  # 使用百度财经更新美股缓存
  stock-seek update_us -t 6 -s bd
  # 增量更新
  stock-seek update_inc
  stock-seek update_us_inc

  # 搜索最高价为15.8的股票(2天前)
  stock-seek find -p 15.8 -pos 2 -t high
  # 搜索最低价为12.5的股票(5天前),进入交互模式
  stock-seek find -p 12.5 -pos 5 -t low -i

  # 查询股票历史数据
  stock-seek query -c 600519 -s 20240101
  stock-seek query -c 600519 -s 20240101 -e 20240301
  stock-seek query -c AAPL -s 20240101 --us

  # 查看更新历史
  stock-seek history
  stock-seek history -n 5
  stock-seek history --last
  stock-seek history --us

  # 定时调度器管理
  stock-seek scheduler start
  stock-seek scheduler start -d
  stock-seek scheduler stop
  stock-seek scheduler status
  stock-seek scheduler trigger
  stock-seek scheduler trigger --us
  stock-seek scheduler config --china-time "16:30"

  # 配置管理
  stock-seek config --baidu-cookie "xxx" --baidu-acs-token "xxx"
  stock-seek config --baidu-show
        """
    )

    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    # find 命令 - A股搜索
    find_parser = subparsers.add_parser("find", help="搜索A股")
    find_parser.add_argument("-p", "--price", type=float, required=True, help="目标价格")
    find_parser.add_argument("-pos", "--position", type=int, required=True, help="历史位置(从后往前,1=昨天)")
    find_parser.add_argument("-t", "--type", type=str, choices=Config.SEARCH_TYPES, required=True, help="价格类型")
    find_parser.add_argument("-i", "--interactive", action="store_true", help="交互模式")

    # find_us 命令 - 美股搜索
    find_us_parser = subparsers.add_parser("find_us", help="搜索美股")
    find_us_parser.add_argument("-p", "--price", type=float, required=True, help="目标价格")
    find_us_parser.add_argument("-pos", "--position", type=int, required=True, help="历史位置")
    find_us_parser.add_argument("-t", "--type", type=str, choices=Config.SEARCH_TYPES, required=True, help="价格类型")
    find_us_parser.add_argument("-i", "--interactive", action="store_true", help="交互模式")

    # update 命令 - A股全量更新
    update_parser = subparsers.add_parser("update", help="全量更新A股缓存")
    update_parser.add_argument("-t", "--threads", type=int, default=Config.DEFAULT_UPDATE_WORKERS, help="线程数")
    update_parser.add_argument("-s", "--source", type=str, choices=Config.DATA_SOURCES, default="bd", help="数据源")

    # update_us 命令 - 美股全量更新
    update_us_parser = subparsers.add_parser("update_us", help="全量更新美股缓存")
    update_us_parser.add_argument("-t", "--threads", type=int, default=Config.DEFAULT_UPDATE_WORKERS, help="线程数")
    update_us_parser.add_argument("-s", "--source", type=str, choices=Config.DATA_SOURCES, default="bd", help="数据源(xl=新浪, bd=百度财经)")

    # update_inc 命令 - A股增量更新
    subparsers.add_parser("update_inc", help="增量更新A股缓存")

    # update_us_inc 命令 - 美股增量更新
    subparsers.add_parser("update_us_inc", help="增量更新美股缓存")

    # print_cache 命令 - 打印A股缓存
    print_cache_parser = subparsers.add_parser("print_cache", help="打印A股缓存数据")
    print_cache_parser.add_argument("-s", "--symbol", type=str, required=True, help="股票代码")

    # print_cache_us 命令 - 打印美股缓存
    print_cache_us_parser = subparsers.add_parser("print_cache_us", help="打印美股缓存数据")
    print_cache_us_parser.add_argument("-s", "--symbol", type=str, required=True, help="股票代码")

    # query 命令 - 查询股票历史数据
    query_parser = subparsers.add_parser("query", help="查询股票历史数据")
    query_parser.add_argument("-c", "--code", type=str, required=True, help="股票代码")
    query_parser.add_argument("-s", "--start", type=str, help="开始日期 (YYYYMMDD)，默认为最近N天")
    query_parser.add_argument("-e", "--end", type=str, help="结束日期 (YYYYMMDD)，默认为今天")
    query_parser.add_argument("--us", action="store_true", help="查询美股")

    # history 命令 - 查看更新历史
    history_parser = subparsers.add_parser("history", help="查看数据更新历史记录")
    history_parser.add_argument("-n", "--number", type=int, default=0, help="显示最近N条记录(0表示全部)")
    history_parser.add_argument("--last", action="store_true", help="只显示最后一条记录")
    history_parser.add_argument("--us", action="store_true", help="查看美股更新历史")

    # export 命令 - 导出缓存数据
    export_parser = subparsers.add_parser("export", help="导出缓存数据到zip文件")
    export_parser.add_argument("-o", "--output", type=str, help="输出文件路径 (默认为 stock_seek_backup.zip)")
    export_parser.add_argument("--no-token", action="store_true", help="不包含百度Token配置")

    # import 命令 - 导入缓存数据
    import_parser = subparsers.add_parser("import", help="从zip文件导入缓存数据")
    import_parser.add_argument("-i", "--input", type=str, required=True, help="输入文件路径")

    # scheduler 命令 - 定时调度器管理
    scheduler_parser = subparsers.add_parser("scheduler", help="定时调度器管理")
    scheduler_subparsers = scheduler_parser.add_subparsers(dest="scheduler_command", help="调度器子命令")

    # scheduler start
    scheduler_start_parser = scheduler_subparsers.add_parser("start", help="启动调度器")
    scheduler_start_parser.add_argument("-d", "--daemon", action="store_true", help="后台运行模式")

    # scheduler stop
    scheduler_subparsers.add_parser("stop", help="停止调度器")

    # scheduler status
    scheduler_subparsers.add_parser("status", help="查看调度器状态")

    # scheduler trigger
    scheduler_trigger_parser = scheduler_subparsers.add_parser("trigger", help="手动触发一次更新")
    scheduler_trigger_parser.add_argument("--us", action="store_true", help="触发美股更新")

    # scheduler config
    scheduler_config_parser = scheduler_subparsers.add_parser("config", help="修改调度配置")
    scheduler_config_parser.add_argument("--enable", type=str, help="启用/禁用调度器 (true/false)")
    scheduler_config_parser.add_argument("--china-time", type=str, help="A股调度时间 (HH:MM)")
    scheduler_config_parser.add_argument("--us-time", type=str, help="美股调度时间 (HH:MM)")
    scheduler_config_parser.add_argument("--smart", type=str, help="启用/禁用智能判断 (true/false)")
    scheduler_config_parser.add_argument("--source", type=str, help="数据源")
    scheduler_config_parser.add_argument("--workers", type=int, help="线程数")

    # config 命令 - 通用配置管理
    config_parser = subparsers.add_parser("config", help="通用配置管理")
    config_parser.add_argument("--baidu-cookie", type=str, dest="baidu_cookie", help="设置百度Cookie")
    config_parser.add_argument("--baidu-acs-token", type=str, dest="baidu_acs_token", help="设置百度acs-token")
    config_parser.add_argument("--baidu-show", action="store_true", help="显示百度Token配置状态")
    config_parser.add_argument("--china-years", type=int, dest="china_years", help="A股历史数据年数")
    config_parser.add_argument("--us-years", type=int, dest="us_years", help="美股历史数据年数")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    try:
        # 确保缓存目录存在
        Config.ensure_cache_dirs()

        # 处理不同命令
        if args.command == "find":
            searcher = StockSearcher(us=False)
            results = searcher.search(args.price, args.position, args.type)

            if results:
                searcher.print_results(results)
                if args.interactive:
                    searcher.interactive_browse(results)
                else:
                    print("\n提示: 使用 -i 参数进入交互模式")
            else:
                print("未找到匹配的股票")

        elif args.command == "find_us":
            searcher = StockSearcher(us=True)
            results = searcher.search(args.price, args.position, args.type)

            if results:
                searcher.print_results(results)
                if args.interactive:
                    searcher.interactive_browse(results)
                else:
                    print("\n提示: 使用 -i 参数进入交互模式")
            else:
                print("未找到匹配的股票")

        elif args.command == "update":
            cache_manager = CacheManager(us=False, source=args.source)
            cache_manager.update_cache(max_workers=args.threads)

        elif args.command == "update_us":
            cache_manager = CacheManager(us=True, source=args.source)
            cache_manager.update_cache(max_workers=args.threads)

        elif args.command == "update_inc":
            cache_manager = CacheManager(us=False)
            cache_manager.update_cache_incrementally()

        elif args.command == "update_us_inc":
            cache_manager = CacheManager(us=True)
            cache_manager.update_cache_incrementally()

        elif args.command == "print_cache":
            print_cache(symbol=args.symbol, us=False)

        elif args.command == "print_cache_us":
            print_cache(symbol=args.symbol, us=True)

        elif args.command == "query":
            from stock_seek.api.simple import query_stock_data

            start_date = args.start
            end_date = args.end

            # 构建日期范围描述
            if start_date and end_date:
                date_range = f" ({start_date} - {end_date})"
            elif start_date:
                date_range = f" ({start_date} 至今)"
            elif end_date:
                date_range = f" (至 {end_date})"
            else:
                date_range = ""

            df = query_stock_data(args.code, start_date, end_date, us=args.us)
            if df is not None and not df.empty:
                print(f"\n{args.code} 本地缓存数据 (共 {len(df)} 条{date_range}):")
                print(df.to_string(index=False))
            else:
                print("本地缓存中无此股票数据")

        elif args.command == "history":
            log_manager = UpdateLogManager(us=args.us)
            if args.last:
                # 显示最后一条记录
                record = log_manager.get_last_record()
                if record:
                    log_manager.print_records([record])
                else:
                    print("暂无更新记录")
            elif args.number > 0:
                # 显示最近N条记录
                records = log_manager.get_recent_records(args.number)
                log_manager.print_records(records)
            else:
                # 显示全部记录
                records = log_manager.get_all_records()
                log_manager.print_records(records)

        elif args.command == "export":
            import zipfile
            import os
            from pathlib import Path

            output_path = args.output or "stock_seek_backup.zip"
            cache_dir = Config.CACHE_DIR

            # 要导出的文件/目录
            export_items = [
                "parquet",
                "parquet_us",
                "stock_code_name.json",
                "trade_calendar_china.json",
                "update_log.json",
            ]
            if not args.no_token:
                export_items.append("baidu_token.json")

            # 检查哪些文件存在
            existing_items = [item for item in export_items if (cache_dir / item).exists()]
            if not existing_items:
                print("没有找到可导出的缓存数据")
                sys.exit(1)

            # 创建zip文件
            with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for item in existing_items:
                    item_path = cache_dir / item
                    if item_path.is_dir():
                        for file in item_path.rglob('*'):
                            if file.is_file():
                                arcname = file.relative_to(cache_dir)
                                zipf.write(file, arcname)
                                print(f"  添加: {arcname}")
                    else:
                        arcname = item
                        zipf.write(item_path, arcname)
                        print(f"  添加: {arcname}")

            print(f"\n导出完成: {output_path}")
            print(f"共导出 {len(existing_items)} 个项目")

        elif args.command == "import":
            import zipfile
            from pathlib import Path

            input_path = args.input
            cache_dir = Config.CACHE_DIR

            if not Path(input_path).exists():
                print(f"文件不存在: {input_path}")
                sys.exit(1)

            # 解压zip文件
            with zipfile.ZipFile(input_path, 'r') as zipf:
                # 列出要解压的文件
                valid_names = [
                    "parquet", "parquet_us",
                    "stock_code_name.json",
                    "trade_calendar_china.json",
                    "update_log.json",
                    "baidu_token.json",
                ]

                extracted_count = 0
                for file in zipf.namelist():
                    # 检查文件是否是有效的导出项
                    is_valid = any(file == name or file.startswith(name + '/') for name in valid_names)
                    if not is_valid:
                        print(f"  跳过无效文件: {file}")
                        continue

                    # 解压到缓存目录
                    dest_path = cache_dir / file
                    dest_path.parent.mkdir(parents=True, exist_ok=True)

                    if not file.endswith('/'):
                        with zipf.open(file) as source:
                            with open(dest_path, 'wb') as target:
                                target.write(source.read())
                                print(f"  解压: {file}")
                                extracted_count += 1

            print(f"\n导入完成: {input_path}")
            print(f"共导入 {extracted_count} 个文件")

        elif args.command == "scheduler":
            from stock_seek.scheduler.scheduler_manager import SchedulerManager

            manager = SchedulerManager.get_instance()

            if args.scheduler_command == "start":
                manager.start(daemon=args.daemon)
                print("调度器已启动")
                if args.daemon:
                    print("后台运行中...")
                else:
                    # 保持前台运行
                    import time
                    try:
                        while manager.scheduler and manager.scheduler.running:
                            time.sleep(1)
                    except KeyboardInterrupt:
                        manager.stop()
                        print("\n调度器已停止")

            elif args.scheduler_command == "stop":
                manager.stop()
                print("调度器已停止")

            elif args.scheduler_command == "status":
                status = manager.get_status()
                print("\n调度器状态:")
                print(f"  运行中: {'是' if status['running'] else '否'}")
                print(f"  智能更新: {'是' if status['config']['smart_update'] else '否'}")
                print(f"  A股调度时间: {status['config']['china_schedule_time']}")
                print(f"  美股调度时间: {status['config']['us_schedule_time']}")
                print(f"  数据源: {status['config']['source']}")
                print(f"  线程数: {status['config']['max_workers']}")
                if status["jobs"]:
                    print("\n定时任务:")
                    for job in status["jobs"]:
                        print(f"  - {job['name']}: 下次执行 {job['next_run']}")

            elif args.scheduler_command == "trigger":
                manager.trigger_now(us=args.us)
                print("触发完成")

            elif args.scheduler_command == "config":
                updates = {}
                if args.enable is not None:
                    updates["enabled"] = args.enable.lower() == "true"
                if args.china_time is not None:
                    h, m = map(int, args.china_time.split(":"))
                    from datetime import time
                    updates["china_schedule_time"] = time(h, m)
                if args.us_time is not None:
                    h, m = map(int, args.us_time.split(":"))
                    from datetime import time
                    updates["us_schedule_time"] = time(h, m)
                if args.smart is not None:
                    updates["smart_update"] = args.smart.lower() == "true"
                if args.source is not None:
                    updates["source"] = args.source
                if args.workers is not None:
                    updates["max_workers"] = args.workers

                if updates:
                    manager.update_config(**updates)
                    print("配置已更新:")
                    for k, v in updates.items():
                        print(f"  {k}: {v}")
                else:
                    print("未提供任何配置更新")

        elif args.command == "config":
            from stock_seek.fetchers.baidu_config import get_baidu_credentials, get_token_file_path
            token_file = get_token_file_path()

            if args.baidu_show:
                cookie, acs_token = get_baidu_credentials()
                print(f"\n百度财经Token配置状态:")
                print(f"  Token文件: {token_file}")
                print(f"  文件存在: {'是' if token_file.exists() else '否'}")
                print(f"  Cookie: {'已设置' if cookie else '未设置'} ({len(cookie)} 字符)" if cookie else "  Cookie: 未设置")
                print(f"  acs_token: {'已设置' if acs_token else '未设置'} ({len(acs_token)} 字符)" if acs_token else "  acs_token: 未设置")
                if not cookie or not acs_token:
                    print("\n提示: 使用 --baidu-cookie 和 --baidu-acs-token 参数设置Token")
            elif args.baidu_cookie is not None or args.baidu_acs_token is not None:
                import json
                data = {}
                if token_file.exists():
                    try:
                        with open(token_file, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                    except Exception:
                        pass

                if args.baidu_cookie is not None:
                    data['cookie'] = args.baidu_cookie
                if args.baidu_acs_token is not None:
                    data['acs_token'] = args.baidu_acs_token

                token_file.parent.mkdir(parents=True, exist_ok=True)
                with open(token_file, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)

                print(f"百度Token已保存到: {token_file}")
                print(f"  Cookie: {'已设置' if data.get('cookie') else '未设置'}")
                print(f"  acs_token: {'已设置' if data.get('acs_token') else '未设置'}")

            # 处理历史数据年数配置
            if args.china_years is not None or args.us_years is not None:
                from stock_seek.core.app_config import AppConfig
                app_config = AppConfig.load()

                if args.china_years is not None:
                    app_config.a_share_history_years = args.china_years
                if args.us_years is not None:
                    app_config.us_stock_history_years = args.us_years

                app_config.save()
                print(f"\n历史数据配置已保存:")
                print(f"  A股历史年数: {app_config.a_share_history_years}")
                print(f"  美股历史年数: {app_config.us_stock_history_years}")
                print(f"\n提示: 修改历史数据年数后，需要执行全量更新才能生效:")
                print(f"  stock-seek update      # A股全量更新")
                print(f"  stock-seek update_us   # 美股全量更新")

            # 如果只是查看配置（无任何参数）
            if not any([args.baidu_show, args.baidu_cookie, args.baidu_acs_token, args.china_years, args.us_years]):
                from stock_seek.core.app_config import AppConfig
                app_config = AppConfig.load()
                print(f"\n历史数据配置:")
                print(f"  A股历史年数: {app_config.a_share_history_years}")
                print(f"  美股历史年数: {app_config.us_stock_history_years}")

        else:
            print(f"未知命令: {args.command}")
            parser.print_help()
            sys.exit(1)

    except StockFinderError as e:
        print(f"错误: {str(e)}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n操作已取消")
        sys.exit(0)
    except Exception as e:
        print(f"未预期的错误: {str(e)}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
