"""
Stock Seek CLI 模块
"""
