"""
Stock Seek 简化 API
提供易于使用的高级函数接口
"""
from pathlib import Path
from typing import List, Dict, Optional, Any
import pandas as pd

from stock_seek.core.config import Config, SearchType, DataSource
from stock_seek.core.searcher import StockSearcher
from stock_seek.cache.cache_manager import CacheManager
from stock_seek.core.exceptions import StockFinderError


def set_cache_dir(cache_dir: Path | str) -> None:
    """
    设置全局缓存目录

    Args:
        cache_dir: 缓存目录路径
    """
    Config.set_global_cache_dir(Path(cache_dir))


def get_config() -> Config:
    """
    获取当前配置对象

    Returns:
        Config 类对象
    """
    return Config


def search_stock(
    price: float,
    position: int,
    search_type: SearchType = "high",
    max_workers: Optional[int] = None
) -> List[Dict[str, Any]]:
    """
    搜索 A 股

    Args:
        price: 目标价格
        position: 历史位置 (从后往前数，1 表示昨天)
        search_type: 价格类型 (high/low/close/open)
        max_workers: 最大线程数

    Returns:
        匹配的股票列表，每个元素包含代码、名称、价格、日期、URL 等信息
    """
    searcher = StockSearcher(us=False)
    if max_workers is None:
        return searcher.search(price, position, search_type)
    else:
        return searcher.search(price, position, search_type, max_workers=max_workers)


def search_us_stock(
    price: float,
    position: int,
    search_type: SearchType = "high",
    max_workers: Optional[int] = None
) -> List[Dict[str, Any]]:
    """
    搜索美股

    Args:
        price: 目标价格
        position: 历史位置 (从后往前数，1 表示昨天)
        search_type: 价格类型 (high/low/close/open)
        max_workers: 最大线程数

    Returns:
        匹配的股票列表，每个元素包含代码、名称、价格、日期、URL 等信息
    """
    searcher = StockSearcher(us=True)
    if max_workers is None:
        return searcher.search(price, position, search_type)
    else:
        return searcher.search(price, position, search_type, max_workers=max_workers)


def update_cache(
    source: DataSource = "bd",
    max_workers: Optional[int] = None
) -> None:
    """
    更新 A 股缓存

    Args:
        source: 数据源 (xl=新浪, em=东方财富, bd=百度财经)
        max_workers: 最大线程数
    """
    cache_manager = CacheManager(us=False, source=source)
    cache_manager.update_cache(max_workers=max_workers)


def update_us_cache(
    source: DataSource = "bd",
    max_workers: Optional[int] = None
) -> None:
    """
    更新美股缓存

    Args:
        source: 数据源 (xl=新浪, bd=百度财经)
        max_workers: 最大线程数
    """
    cache_manager = CacheManager(us=True, source=source)
    cache_manager.update_cache(max_workers=max_workers)


def update_cache_incrementally() -> None:
    """
    增量更新 A 股缓存
    """
    cache_manager = CacheManager(us=False)
    cache_manager.update_cache_incrementally()


def update_us_cache_incrementally() -> None:
    """
    增量更新美股缓存
    """
    cache_manager = CacheManager(us=True)
    cache_manager.update_cache_incrementally()


def get_stock_data(
    stock_code: str,
    us: bool = False
) -> Optional[pd.DataFrame]:
    """
    获取单只股票的缓存数据

    Args:
        stock_code: 股票代码
        us: 是否为美股

    Returns:
        股票数据 DataFrame，如果不存在则返回 None
    """
    cache_manager = CacheManager(us=us)
    return cache_manager.load_stock_data(stock_code)


def get_cache_data(code: str) -> Optional[pd.DataFrame]:
    """
    获取 A 股缓存数据（简化版）

    Args:
        code: 股票代码

    Returns:
        股票数据 DataFrame，如果不存在则返回 None
    """
    return get_stock_data(code, us=False)


def get_all_cached_stocks(us: bool = False) -> List[str]:
    """
    获取所有已缓存的股票代码

    Args:
        us: 是否为美股

    Returns:
        股票代码列表
    """
    cache_manager = CacheManager(us=us)
    return cache_manager.get_all_cached_stocks()


def query_stock_data(
    code: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    us: bool = False
) -> Optional[pd.DataFrame]:
    """
    查询股票历史数据（从本地缓存获取）

    Args:
        code: 股票代码
        start_date: 开始日期 (YYYYMMDD)，不指定则不限制起点
        end_date: 结束日期 (YYYYMMDD)，不指定则不限制终点
        us: 是否为美股

    Returns:
        股票数据 DataFrame
    """
    # 从本地缓存获取全部数据
    df = get_stock_data(code, us=us)
    if df is None or df.empty:
        return None

    # 如果start和end都不指定，返回全部数据
    if start_date is None and end_date is None:
        return df

    # 获取日期列（第一列通常是日期）
    df = df.copy()
    date_col = df.columns[0]

    # 转换日期列为字符串以便比较
    df[date_col] = df[date_col].astype(str).str.replace('-', '')

    # 按日期范围过滤
    if start_date is not None:
        df = df[df[date_col] >= start_date]
    if end_date is not None:
        df = df[df[date_col] <= end_date]

    return df
