"""
更新记录管理器
负责记录数据更新的历史,包括命令、时间、结果等信息
"""
import json
from pathlib import Path
from typing import List, Dict, Optional, Literal
from datetime import datetime
from dataclasses import dataclass, asdict

from stock_seek.core.config import Config
from stock_seek.utils.logger import get_logger

logger = get_logger(__name__)


# 更新结果状态
UpdateStatus = Literal["success", "failed", "cancelled"]


@dataclass
class UpdateRecord:
    """更新记录数据类"""
    command: str  # 执行的具体命令
    timestamp: str  # 执行时间 ISO格式
    status: UpdateStatus  # 结果状态
    message: str = ""  # 附加信息
    details: Dict = None  # 详细信息(如成功数量、失败数量等)

    def __post_init__(self):
        if self.details is None:
            self.details = {}

    def to_dict(self) -> Dict:
        """转换为字典"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict) -> 'UpdateRecord':
        """从字典创建"""
        return cls(**data)


class UpdateLogManager:
    """更新记录管理器"""

    def __init__(self, us: bool = False):
        """
        初始化更新记录管理器

        Args:
            us: 是否为美股数据
        """
        self.us = us
        self.log_file = self._get_log_file()

    def _get_log_file(self) -> Path:
        """获取日志文件路径"""
        filename = "update_log_us.json" if self.us else "update_log.json"
        return Config.CACHE_DIR / filename

    def _load_records(self) -> List[UpdateRecord]:
        """加载所有记录"""
        if not self.log_file.exists():
            return []

        try:
            with open(self.log_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return [UpdateRecord.from_dict(record) for record in data]
        except Exception as e:
            logger.error(f"加载更新记录失败: {str(e)}")
            return []

    def _save_records(self, records: List[UpdateRecord]) -> None:
        """保存所有记录"""
        Config.ensure_cache_dirs()

        try:
            data = [record.to_dict() for record in records]
            with open(self.log_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存更新记录失败: {str(e)}")

    def add_record(
        self,
        command: str,
        status: UpdateStatus,
        message: str = "",
        details: Dict = None
    ) -> None:
        """
        添加一条更新记录

        Args:
            command: 执行的命令
            status: 结果状态
            message: 附加信息
            details: 详细信息
        """
        records = self._load_records()

        new_record = UpdateRecord(
            command=command,
            timestamp=datetime.now().isoformat(),
            status=status,
            message=message,
            details=details or {}
        )

        records.append(new_record)
        self._save_records(records)

    def get_all_records(self) -> List[UpdateRecord]:
        """获取所有记录"""
        return self._load_records()

    def get_recent_records(self, count: int = 5) -> List[UpdateRecord]:
        """
        获取最近的N条记录

        Args:
            count: 记录数量

        Returns:
            最近的记录列表(按时间倒序)
        """
        records = self._load_records()
        return records[-count:][::-1] if records else []

    def get_last_record(self) -> Optional[UpdateRecord]:
        """获取最后一条记录"""
        records = self._load_records()
        return records[-1] if records else None

    def get_last_successful_record(self) -> Optional[UpdateRecord]:
        """获取最后一条成功的记录"""
        records = self._load_records()
        for record in reversed(records):
            if record.status == "success":
                return record
        return None

    def clear_records(self) -> None:
        """清空所有记录"""
        self._save_records([])

    def print_records(self, records: List[UpdateRecord]) -> None:
        """打印记录列表"""
        if not records:
            print("暂无更新记录")
            return

        print(f"\n{'='*80}")
        print(f"更新记录 (共 {len(records)} 条)")
        print(f"{'='*80}")

        for i, record in enumerate(records, 1):
            # 解析时间
            try:
                dt = datetime.fromisoformat(record.timestamp)
                time_str = dt.strftime("%Y-%m-%d %H:%M:%S")
            except:
                time_str = record.timestamp

            # 状态显示
            status_display = {
                "success": "✓ 成功",
                "failed": "✗ 失败",
                "cancelled": "○ 取消"
            }.get(record.status, record.status)

            print(f"\n[{i}] {time_str}")
            print(f"    命令: {record.command}")
            print(f"    状态: {status_display}")

            if record.message:
                print(f"    信息: {record.message}")

            if record.details:
                details_str = " | ".join([f"{k}: {v}" for k, v in record.details.items()])
                print(f"    详情: {details_str}")

        print(f"\n{'='*80}\n")

    def check_data_continuity(self) -> tuple:
        """
        检查数据更新的连续性

        Returns:
            (是否连续, 错误信息)
        """
        last_record = self.get_last_record()

        if not last_record:
            # 没有记录,说明是首次更新,允许继续
            return True, None

        if last_record.status == "success":
            # 上次更新成功,可以继续
            return True, None

        if last_record.status == "cancelled":
            # 上次取消,需要检查是否有中断
            last_success = self.get_last_successful_record()
            if last_success:
                try:
                    last_success_time = datetime.fromisoformat(last_success.timestamp)
                    now = datetime.now()
                    days_gap = (now - last_success_time).days

                    if days_gap > 1:
                        return False, (
                            f"数据可能不完整: 上次成功更新在 {days_gap} 天前 "
                            f"({last_success_time.strftime('%Y-%m-%d')}), "
                            f"建议执行全量更新 (update 或 update_us)"
                        )
                except:
                    pass

        if last_record.status == "failed":
            # 上次失败,提示用户
            return False, (
                f"上次更新失败: {last_record.message}. "
                f"建议先解决错误,或执行全量更新"
            )

        return True, None
