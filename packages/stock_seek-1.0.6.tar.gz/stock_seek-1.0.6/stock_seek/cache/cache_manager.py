"""
缓存管理器
负责股票数据的缓存、更新和读取
"""
import json
from pathlib import Path
from typing import Dict, Optional, List
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import pandas as pd
from tqdm import tqdm

from stock_seek.core.config import Config
from stock_seek.core.app_config import AppConfig
from stock_seek.core.exceptions import CacheError, DataFetchError
from stock_seek.fetchers.data_fetcher import DataFetcher, DataFetcherFactory
from stock_seek.cache.update_log_manager import UpdateLogManager
from stock_seek.utils.logger import get_logger

logger = get_logger(__name__)


class CacheManager:
    """缓存管理器类"""
    
    def __init__(self, us: bool = False, source: str = "xl"):
        """
        初始化缓存管理器
        
        Args:
            us: 是否为美股
            source: 数据源(仅对A股有效)
        """
        self.us = us
        self.source = source
        self.fetcher = DataFetcherFactory.create_fetcher(us=us, source=source)
        self.parquet_dir = Config.get_parquet_dir(us=us)
        self.code_name_file = Config.get_code_name_file(us=us)
        self.log_manager = UpdateLogManager(us=us)
        
        # 确保目录存在
        Config.ensure_cache_dirs()
    
    def update_cache(self, max_workers: int = None) -> None:
        """
        全量更新缓存

        Args:
            max_workers: 最大线程数
        """
        if max_workers is None:
            max_workers = Config.DEFAULT_UPDATE_WORKERS

        # 记录命令
        command = f"update{'_us' if self.us else ''}"
        if not self.us:
            command += f" --source {self.source}"

        logger.info(f"开始{'美股' if self.us else 'A股'}全量更新...")
        
        # 获取股票列表
        stock_list = self.fetcher.get_stock_list()
        logger.info(f"共获取到 {len(stock_list)} 只股票")
        
        # 设置日期范围
        today = datetime.now()
        today_str = today.strftime("%Y%m%d")

        # 从配置读取历史数据年数
        app_config = AppConfig.load()

        if self.us:
            start_date = (today - timedelta(days=365 * app_config.us_stock_history_years)).strftime("%Y%m%d")
        else:
            start_date = (today - timedelta(days=365 * app_config.a_share_history_years)).strftime("%Y%m%d")
        
        # 多线程获取数据
        code_name_dict = {}
        success_count = 0
        failed_count = 0
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {}
            
            for code, info in stock_list.items():
                future = executor.submit(
                    self.fetcher.fetch_stock_data,
                    code,
                    info['name'],
                    start_date,
                    today_str
                )
                futures[future] = (code, info['name'])
            
            # 使用进度条
            with tqdm(total=len(futures), desc="更新进度", bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}] 当前: {postfix}") as pbar:
                for future in as_completed(futures):
                    code, name = futures[future]
                    try:
                        result_code, df = future.result()
                        
                        if df is not None and not df.empty:
                            # 保存到Parquet文件
                            parquet_path = self.parquet_dir / f"{code}.parquet"
                            df.to_parquet(parquet_path, index=False)
                            code_name_dict[code] = name
                            success_count += 1
                            pbar.set_postfix_str(code)
                            tqdm.write(f"✓ 更新: {code} {name}")
                            logger.debug(f"更新成功: {code} {name}")
                        else:
                            failed_count += 1
                            
                    except Exception as e:
                        logger.warning(f"更新失败: {code}, 原因: {str(e)}")
                        failed_count += 1
                    
                    pbar.update(1)
        
        # 保存代码-名称映射
        with open(self.code_name_file, 'w', encoding='utf-8') as f:
            json.dump(code_name_dict, f, ensure_ascii=False, indent=2)

        logger.info(f"全量更新完成, 成功: {success_count}, 失败: {failed_count}")

        # 记录更新结果
        self.log_manager.add_record(
            command=command,
            status="success",
            message=f"全量更新完成",
            details={
                "成功数量": success_count,
                "失败数量": failed_count,
                "总数量": len(stock_list)
            }
        )
    
    def update_cache_incrementally(self) -> None:
        """增量更新缓存"""
        # 记录命令
        command = f"update{'_us' if self.us else ''}_inc"

        # 检查缓存目录是否为空
        if not self.parquet_dir.exists():
            logger.info("缓存目录不存在，执行全量更新...")
            self.update_cache()
            return

        # 检查是否有 parquet 文件
        parquet_files = list(self.parquet_dir.glob("*.parquet"))
        if not parquet_files:
            logger.info("缓存目录为空，执行全量更新...")
            self.update_cache()
            return

        # 检查数据连续性
        is_continuous, error_msg = self.log_manager.check_data_continuity()
        if not is_continuous:
            logger.error(f"数据连续性检查失败: {error_msg}")
            self.log_manager.add_record(
                command=command,
                status="failed",
                message=error_msg
            )
            return

        logger.info(f"开始{'美股' if self.us else 'A股'}增量更新...")
        
        # 获取实时行情
        from stock_seek.utils.data_api import stock_spots_lp
        spots = stock_spots_lp(us=self.us)
        
        if not spots:
            logger.error("获取实时行情失败!")
            return
        
        # 获取参考时间
        if self.us:
            # 美股使用AAPL作为参考
            spot_ref = spots.get("AAPL.OQ")
        else:
            # A股使用第一个股票作为参考
            spot_ref = next(iter(spots.values()), None)
        
        if not spot_ref:
            logger.error("获取参考行情失败!")
            return
        
        # 解析日期
        spot_dt = datetime.fromisoformat(spot_ref["timestamp"])
        if spot_dt.tzinfo is None:
            import pytz
            spot_dt = pytz.utc.localize(spot_dt)
        
        if self.us:
            import pytz
            eastern = pytz.timezone("US/Eastern")
            spot_dt = spot_dt.astimezone(eastern)
        
        spot_date = spot_dt.date()
        
        # 更新每只股票
        success_count = 0
        skip_count = 0
        
        for code, q in tqdm(spots.items(), desc="增量更新", bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}] 当前: {postfix}"):
            if self.us:
                code = code.split(".")[0]
            
            parquet_path = self.parquet_dir / f"{code}.parquet"
            
            try:
                if not parquet_path.exists():
                    continue
                
                old_df = pd.read_parquet(parquet_path)
                last_date = pd.to_datetime(old_df['日期'].iloc[-1]).date()
                
                if last_date == spot_date:
                    skip_count += 1
                    continue
                
                # 计算衍生数据
                change = q['last_done'] - q['prev_close']
                pct_change = change / q['prev_close'] * 100
                pct_move = (q['high'] - q['low']) / q['prev_close'] * 100
                volume_final = q['volume']
                if not self.us:
                    volume_final = volume_final * 100
                turnover_ratio = volume_final / q['circulating_shares'] * 100 if q.get('circulating_shares', 0) > 0 else 0

                
                # 创建新行
                new_row = pd.DataFrame({
                    '日期': [spot_dt],
                    '开盘': [q['open']],
                    '最高': [q['high']],
                    '最低': [q['low']],
                    '收盘': [q['last_done']],
                    '成交量': [volume_final],
                    '涨跌幅': [pct_change],
                    '涨跌额': [change],
                    '振幅': [pct_move],
                    '换手率': [turnover_ratio],
                    '成交额': [q.get('turnover', 0)],
                    '昨收': [q['prev_close']]  # 添加昨收字段
                })
                
                # 合并数据
                new_df = pd.concat([old_df, new_row], ignore_index=True)
                new_df.to_parquet(parquet_path, index=False)
                success_count += 1
                tqdm.write(f"✓ 更新: {code}")
                logger.debug(f"增量更新成功: {code}")

            except Exception as e:
                logger.warning(f"增量更新失败: {code}, 原因: {str(e)}")

        logger.info(f"增量更新完成, 成功: {success_count}, 跳过: {skip_count}")

        # 记录更新结果
        self.log_manager.add_record(
            command=command,
            status="success",
            message="增量更新完成",
            details={
                "成功数量": success_count,
                "跳过数量": skip_count,
                "总数量": len(spots)
            }
        )
    
    def load_code_name_mapping(self) -> Dict[str, str]:
        """加载股票代码-名称映射"""
        if not self.code_name_file.exists():
            raise CacheError(f"缓存文件不存在: {self.code_name_file}")
        
        with open(self.code_name_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def load_stock_data(self, stock_code: str) -> Optional[pd.DataFrame]:
        """加载单只股票的缓存数据"""
        parquet_path = self.parquet_dir / f"{stock_code}.parquet"
        
        if not parquet_path.exists():
            return None
        
        try:
            return pd.read_parquet(parquet_path)
        except Exception as e:
            raise CacheError(f"读取股票 {stock_code} 缓存失败: {str(e)}")
    
    def get_all_cached_stocks(self) -> List[str]:
        """获取所有已缓存的股票代码"""
        parquet_files = list(self.parquet_dir.glob("*.parquet"))
        return [f.stem for f in parquet_files]
    
    def clear_cache(self) -> None:
        """清空缓存"""
        import shutil
        
        if self.parquet_dir.exists():
            shutil.rmtree(self.parquet_dir)
        
        if self.code_name_file.exists():
            self.code_name_file.unlink()
        
        logger.info("缓存已清空")
