"""
Stock Seek - 股票搜索工具

支持中国A股和美股的搜索，具有本地缓存和增量更新功能。

示例:
    import stock_seek

    # 设置自定义缓存目录
    stock_seek.set_cache_dir("/path/to/custom/cache")

    # 更新缓存
    stock_seek.update_cache(source="bd", max_workers=8)

    # 搜索股票
    results = stock_seek.search_stock(price=15.8, position=2, search_type="high")

    # 获取单只股票数据
    df = stock_seek.get_stock_data("600519")
"""

__version__ = "1.0.6"
__author__ = "Stock Seek Team@garen"

# 核心配置和类型
from stock_seek.core.config import Config, DataSource, SearchType

# 异常类
from stock_seek.core.exceptions import (
    StockFinderError,
    DataFetchError,
    CacheError,
    InvalidParameterError,
    StockNotFoundError,
    DataValidationError,
)

# 核心类
from stock_seek.core.searcher import StockSearcher

# 缓存管理
from stock_seek.cache.cache_manager import CacheManager
from stock_seek.cache.update_log_manager import UpdateLogManager

# 数据获取器
from stock_seek.fetchers.base_fetcher import BaseDataFetcher
from stock_seek.fetchers.china_fetcher import ChinaStockFetcher
from stock_seek.fetchers.us_fetcher import USStockFetcher
from stock_seek.fetchers.baidu_fetcher import BaiduStockFetcher
from stock_seek.fetchers.data_fetcher import DataFetcher, DataFetcherFactory

# 简化 API
from stock_seek.api.simple import (
    set_cache_dir,
    get_config,
    search_stock,
    search_us_stock,
    update_cache,
    update_us_cache,
    update_cache_incrementally,
    update_us_cache_incrementally,
    get_stock_data,
    get_cache_data,
    get_all_cached_stocks,
    query_stock_data,
)

# 调度器
from stock_seek.scheduler.scheduler_manager import SchedulerManager
from stock_seek.scheduler.cache_watcher import CacheWatcher
from stock_seek.scheduler.config_store import SchedulerConfig

__all__ = [
    # 版本信息
    "__version__",
    "__author__",
    # 配置和类型
    "Config",
    "DataSource",
    "SearchType",
    # 异常类
    "StockFinderError",
    "DataFetchError",
    "CacheError",
    "InvalidParameterError",
    "StockNotFoundError",
    "DataValidationError",
    # 核心类
    "StockSearcher",
    # 缓存管理
    "CacheManager",
    "UpdateLogManager",
    # 数据获取器
    "BaseDataFetcher",
    "ChinaStockFetcher",
    "USStockFetcher",
    "BaiduStockFetcher",
    "DataFetcher",
    "DataFetcherFactory",
    # 简化 API
    "set_cache_dir",
    "get_config",
    "search_stock",
    "search_us_stock",
    "update_cache",
    "update_us_cache",
    "update_cache_incrementally",
    "update_us_cache_incrementally",
    "get_stock_data",
    "get_cache_data",
    "get_all_cached_stocks",
    "query_stock_data",
    # 调度器
    "SchedulerManager",
    "CacheWatcher",
    "SchedulerConfig",
]
