"""
定时任务调度管理器
"""
import threading
from datetime import datetime
from typing import Optional

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.executors.pool import ThreadPoolExecutor

from stock_seek.core.config import Config
from stock_seek.scheduler.config_store import SchedulerConfig
from stock_seek.scheduler.cache_watcher import CacheWatcher
from stock_seek.cache.cache_manager import CacheManager
from stock_seek.utils.logger import get_logger

logger = get_logger(__name__)


class SchedulerManager:
    """定时任务调度管理器"""

    _instance: Optional["SchedulerManager"] = None
    _lock = threading.Lock()

    def __init__(self):
        self.config = SchedulerConfig.load()
        self.scheduler: Optional[BackgroundScheduler] = None
        self._jobs = {}

    @classmethod
    def get_instance(cls) -> "SchedulerManager":
        """单例获取实例"""
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

    def _create_scheduler(self) -> BackgroundScheduler:
        """创建调度器"""
        executors = {
            "default": ThreadPoolExecutor(10)
        }
        job_defaults = {
            "coalesce": True,
            "max_instances": 1,
            "misfire_grace_time": 60 * 60,
        }

        scheduler = BackgroundScheduler(
            executors=executors,
            job_defaults=job_defaults,
            timezone="Asia/Shanghai",
        )
        return scheduler

    def _execute_update(self, us: bool = False) -> None:
        """
        执行更新任务

        Args:
            us: 是否为美股
        """
        market = "美股" if us else "A股"
        logger.info(f"开始执行{market}定时更新任务...")

        try:
            # 检查是否是交易日
            if self.config.trading_days_only and not CacheWatcher.is_trading_day(us):
                logger.info(f"今天不是{market}交易日，跳过更新")
                return

            # 智能判断：检查缓存状态
            if self.config.smart_update:
                needs_full, reason = CacheWatcher.check_cache_status(us)
                logger.info(f"缓存状态检查结果: needs_full={needs_full}, reason={reason}")

                if needs_full:
                    logger.info(f"执行全量更新: {reason}")
                    cache_manager = CacheManager(us=us, source=self.config.source)
                    cache_manager.update_cache(max_workers=self.config.max_workers)
                else:
                    logger.info("执行增量更新")
                    cache_manager = CacheManager(us=us)
                    cache_manager.update_cache_incrementally()
            else:
                # 直接执行增量更新
                cache_manager = CacheManager(us=us)
                cache_manager.update_cache_incrementally()

        except Exception as e:
            logger.error(f"定时更新任务执行失败: {e}", exc_info=True)

    def start(self, daemon: bool = False) -> None:
        """
        启动调度器

        Args:
            daemon: 是否以守护进程模式运行
        """
        if self.scheduler is not None and self.scheduler.running:
            logger.warning("调度器已在运行中")
            return

        self.scheduler = self._create_scheduler()

        # 添加 A 股定时任务
        china_trigger = CronTrigger(
            hour=self.config.china_schedule_time.hour,
            minute=self.config.china_schedule_time.minute,
            timezone="Asia/Shanghai",
        )
        self.scheduler.add_job(
            func=lambda: self._execute_update(us=False),
            trigger=china_trigger,
            id="china_inc_update",
            name="A股增量更新",
            replace_existing=True,
        )

        # 添加美股定时任务
        us_trigger = CronTrigger(
            hour=self.config.us_schedule_time.hour,
            minute=self.config.us_schedule_time.minute,
            timezone="Asia/Shanghai",
        )
        self.scheduler.add_job(
            func=lambda: self._execute_update(us=True),
            trigger=us_trigger,
            id="us_inc_update",
            name="美股增量更新",
            replace_existing=True,
        )

        self.scheduler.start()
        logger.info("调度器已启动")
        logger.info(f"A股更新计划: {self.config.china_schedule_time.strftime('%H:%M')}")
        logger.info(f"美股更新计划: {self.config.us_schedule_time.strftime('%H:%M')}")
        logger.info(f"智能更新: {self.config.smart_update}")

        # 检查日历到期情况（自动升级）
        expiry_info = CacheWatcher.check_calendar_expiry(auto_upgrade=True)
        if expiry_info.get("us", {}).get("warning"):
            info = expiry_info["us"]
            if info.get("auto_upgraded"):
                logger.info(f"exchange-calendars 已自动升级成功")
            else:
                pm = info.get("pm", "pip")
                upgrade_cmd = f"{pm} install --upgrade exchange-calendars"
                logger.warning(
                    f"美股日历即将在 {info['days_until_expiry']} 天后({info['last_session']})到期, "
                    f"请手动执行: {upgrade_cmd}"
                )

    def stop(self) -> None:
        """停止调度器"""
        if self.scheduler is not None and self.scheduler.running:
            self.scheduler.shutdown(wait=False)
            self.scheduler = None
            logger.info("调度器已停止")

    def trigger_now(self, us: bool = False) -> None:
        """
        立即触发一次更新

        Args:
            us: 是否为美股
        """
        market = "美股" if us else "A股"
        logger.info(f"手动触发{market}更新...")
        self._execute_update(us=us)

    def get_status(self) -> dict:
        """获取调度器状态"""
        if self.scheduler is None or not self.scheduler.running:
            return {
                "running": False,
                "jobs": [],
                "config": self.config.to_dict(),
            }

        jobs = []
        for job in self.scheduler.get_jobs():
            jobs.append(
                {
                    "id": job.id,
                    "name": job.name,
                    "next_run": job.next_run_time.isoformat() if job.next_run_time else None,
                }
            )

        return {
            "running": True,
            "jobs": jobs,
            "config": self.config.to_dict(),
        }

    def update_config(self, **kwargs) -> None:
        """更新配置并重启任务"""
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)

        self.config.save()

        # 如果调度器在运行，重启任务
        if self.scheduler is not None and self.scheduler.running:
            self.stop()
            self.start()
