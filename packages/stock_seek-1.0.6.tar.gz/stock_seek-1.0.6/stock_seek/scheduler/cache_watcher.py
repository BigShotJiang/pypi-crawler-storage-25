"""
缓存状态检测器
"""
import logging
import subprocess
import sys
from datetime import date, datetime, timedelta
from typing import Tuple

from stock_seek.cache.cache_manager import CacheManager
from stock_seek.cache.update_log_manager import UpdateLogManager

logger = logging.getLogger(__name__)

# 提前提醒天数
EXPIRY_WARNING_DAYS = 30


def get_package_manager() -> str:
    """
    检测当前使用的包管理器

    Returns:
        'conda' 或 'pip'
    """
    # 检查是否在 conda 环境中
    if "CONDA_PREFIX" in __import__("os").environ:
        return "conda"

    # 检查 conda 命令是否可用
    try:
        subprocess.run(
            ["conda", "--version"],
            capture_output=True,
            check=True,
        )
        return "conda"
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    return "pip"


def get_upgrade_command(package: str) -> list:
    """
    获取升级命令

    Args:
        package: 包名

    Returns:
        命令列表
    """
    pm = get_package_manager()
    if pm == "conda":
        return [pm, "install", "-y", package]
    else:
        return [pm, "install", "--upgrade", package]


def upgrade_package(package: str) -> bool:
    """
    尝试升级包

    Args:
        package: 包名

    Returns:
        是否成功
    """
    try:
        cmd = get_upgrade_command(package)
        logger.info(f"执行升级命令: {' '.join(cmd)}")
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            logger.info(f"{package} 升级成功")
            return True
        else:
            logger.error(f"{package} 升级失败: {result.stderr}")
            return False
    except Exception as e:
        logger.error(f"升级命令执行失败: {e}")
        return False


class CacheWatcher:
    """缓存状态检测器"""

    @staticmethod
    def check_cache_status(us: bool = False) -> Tuple[bool, str]:
        """
        检查缓存状态

        Returns:
            (needs_full_update: bool, reason: str)
            - needs_full_update: 是否需要全量更新
            - reason: 原因描述
        """
        cache_manager = CacheManager(us=us)
        log_manager = UpdateLogManager(us=us)

        # 1. 检查缓存目录是否存在
        if not cache_manager.parquet_dir.exists():
            return True, "缓存目录不存在，需要全量更新"

        # 2. 检查是否有 parquet 文件
        parquet_files = list(cache_manager.parquet_dir.glob("*.parquet"))
        if not parquet_files:
            return True, "缓存目录为空，需要全量更新"

        # 3. 检查数据连续性
        is_continuous, error_msg = log_manager.check_data_continuity()
        if not is_continuous:
            return True, f"数据连续性检查失败: {error_msg}"

        # 4. 检查是否有最新数据
        last_success = log_manager.get_last_successful_record()
        if not last_success:
            return True, "没有成功的更新记录，需要全量更新"

        # 检查最后更新时间是否是今天
        try:
            last_time = datetime.fromisoformat(last_success.timestamp)
            if last_time.date() < date.today():
                return True, f"数据已过期(最后更新: {last_time.date()})，需要增量更新"
        except Exception:
            pass

        return False, "缓存状态正常"

    @staticmethod
    def is_trading_day(us: bool = False) -> bool:
        """
        判断今天是否是交易日

        Args:
            us: 是否为美股

        Returns:
            是否是交易日
        """
        if us:
            # 美股：使用美国东部时间判断
            import pytz
            eastern = pytz.timezone("US/Eastern")
            now_eastern = datetime.now(pytz.utc).astimezone(eastern)
            today = now_eastern.date()
        else:
            # A股：使用本地时间（北京时间）
            today = date.today()

        try:
            if us:
                # 美股：使用 exchange_calendars（节假日数据准确）
                import exchange_calendars as ecals

                calendar = ecals.get_calendar("XNYS")
                return calendar.is_session(today)
            else:
                # A股：使用 TradeCalendarCache（基于 akshare，本地缓存）
                from stock_seek.scheduler.trade_calendar import TradeCalendarCache

                trade_dates = TradeCalendarCache.get_china_calendar()
                return today in trade_dates

        except Exception as e:
            logger.warning(f"交易日判断异常: {e}")

            # 回退到保守判断：周末休市，工作日可能交易
            return today.weekday() < 5

    @staticmethod
    def check_calendar_expiry(auto_upgrade: bool = False) -> dict:
        """
        检查日历数据到期情况

        Args:
            auto_upgrade: 是否自动升级（默认 False，仅提醒）

        Returns:
            dict: 包含各日历到期信息的字典
        """
        result = {}

        try:
            import exchange_calendars as ecals

            # 检查美股
            xnys = ecals.get_calendar("XNYS")
            last_session = xnys.last_session.date()
            days_until_expiry = (last_session - datetime.now().date()).days

            result["us"] = {
                "last_session": str(last_session),
                "days_until_expiry": days_until_expiry,
                "warning": days_until_expiry <= EXPIRY_WARNING_DAYS,
                "package": "exchange-calendars",
                "pm": get_package_manager(),
            }

            # 记录警告日志
            if days_until_expiry <= EXPIRY_WARNING_DAYS:
                pm = get_package_manager()
                upgrade_cmd = " ".join(get_upgrade_command("exchange-calendars"))

                if auto_upgrade:
                    # 自动升级
                    success = upgrade_package("exchange-calendars")
                    result["us"]["auto_upgraded"] = success
                else:
                    # 仅提醒
                    logger.warning(
                        f"美股(XNYS)日历即将到期: {days_until_expiry}天后({last_session}), "
                        f"建议执行: {upgrade_cmd}"
                    )

        except Exception as e:
            logger.warning(f"检查日历到期时出错: {e}")

        return result
