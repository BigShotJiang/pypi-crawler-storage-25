"""
定时调度服务入口
用于后台运行和系统服务
"""
import sys
from stock_seek.scheduler.scheduler_manager import SchedulerManager
from stock_seek.utils.logger import init_logging, get_logger

# 初始化日志
init_logging()


def main():
    """服务入口"""
    logger = get_logger(__name__)
    logger.info("启动 Stock Seek 定时调度服务...")

    manager = SchedulerManager.get_instance()

    try:
        manager.start()

        # 保持进程运行
        import time

        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("收到停止信号...")
        manager.stop()
    except Exception as e:
        logger.error(f"服务异常退出: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
