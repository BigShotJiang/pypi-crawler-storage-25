"""
交易日历缓存管理器
从 akshare 获取并缓存 A 股和美股交易日历
"""
import json
from datetime import date, datetime
from pathlib import Path
from typing import Set, Optional

from stock_seek.core.config import Config


class TradeCalendarCache:
    """交易日历缓存管理器"""

    # 缓存有效期（天）
    CACHE_EXPIRY_DAYS = 7

    # 缓存文件名
    CHINA_CAL_FILE = "trade_calendar_china.json"
    US_CAL_FILE = "trade_calendar_us.json"

    @classmethod
    def _get_cache_path(cls, us: bool) -> Path:
        """获取缓存文件路径"""
        return Config.CACHE_DIR / (cls.US_CAL_FILE if us else cls.CHINA_CAL_FILE)

    @classmethod
    def _is_cache_valid(cls, cache_path: Path) -> bool:
        """检查缓存是否有效"""
        if not cache_path.exists():
            return False

        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            # 检查缓存时间
            cached_time = datetime.fromisoformat(data.get("cached_at", ""))
            days_since_cache = (datetime.now() - cached_time).days
            return days_since_cache < cls.CACHE_EXPIRY_DAYS
        except Exception:
            return False

    @classmethod
    def get_china_calendar(cls) -> Set[date]:
        """
        获取中国 A 股日历

        优先使用本地缓存，缓存过期或不存在时从 akshare 获取

        Returns:
            交易日集合
        """
        cache_path = cls._get_cache_path(us=False)

        # 检查缓存是否有效
        if cls._is_cache_valid(cache_path):
            try:
                with open(cache_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                dates = [date.fromisoformat(d) for d in data["trade_dates"]]
                print(f"使用缓存的A股日历，共 {len(dates)} 个交易日")
                return set(dates)
            except Exception:
                pass

        # 缓存无效，从 akshare 获取
        print("从 akshare 获取 A 股日历...")
        try:
            import akshare as ak

            df = ak.tool_trade_date_hist_sina()
            trade_dates = set(pd.to_datetime(df["trade_date"]).dt.date.tolist())

            # 缓存到本地
            cls._save_cache(cache_path, trade_dates)

            print(f"已缓存 A 股日历，共 {len(trade_dates)} 个交易日")
            return trade_dates

        except Exception as e:
            print(f"从 akshare 获取日历失败: {e}")

            # 尝试读取过期缓存
            if cache_path.exists():
                try:
                    with open(cache_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    dates = [date.fromisoformat(d) for d in data["trade_dates"]]
                    print(f"使用过期缓存的A股日历，共 {len(dates)} 个交易日")
                    return set(dates)
                except Exception:
                    pass

            raise

    @classmethod
    def _save_cache(cls, cache_path: Path, trade_dates: Set[date]) -> None:
        """保存日历到缓存"""
        Config.ensure_cache_dirs()

        data = {
            "trade_dates": [d.isoformat() for d in sorted(trade_dates)],
            "cached_at": datetime.now().isoformat(),
        }

        with open(cache_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


# 需要 pandas
import pandas as pd
