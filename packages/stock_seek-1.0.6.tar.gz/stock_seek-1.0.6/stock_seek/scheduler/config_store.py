"""
调度器配置管理
"""
import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from datetime import time
from typing import Optional, Literal

from stock_seek.core.config import Config


@dataclass
class SchedulerConfig:
    """调度器配置"""

    enabled: bool = False
    china_schedule_time: time = field(default_factory=lambda: time(16, 0))
    us_schedule_time: time = field(default_factory=lambda: time(5, 0))
    schedule_type: Literal["cron", "interval"] = "cron"
    check_interval_minutes: int = 60
    smart_update: bool = True
    source: str = "bd"
    max_workers: int = 8
    trading_days_only: bool = True

    _config_file: Optional[Path] = field(default=None, repr=False)

    def __post_init__(self):
        if self._config_file is None:
            self._config_file = Config.CACHE_DIR / "scheduler_config.json"

    @classmethod
    def load(cls) -> "SchedulerConfig":
        """从配置文件加载"""
        config_file = Config.CACHE_DIR / "scheduler_config.json"

        if config_file.exists():
            try:
                with open(config_file, "r", encoding="utf-8") as f:
                    data = json.load(f)

                # 解析时间
                china_time = data.get("china_schedule_time", "16:00")
                us_time = data.get("us_schedule_time", "05:00")

                if isinstance(china_time, str):
                    h, m = map(int, china_time.split(":"))
                    china_time = time(h, m)
                if isinstance(us_time, str):
                    h, m = map(int, us_time.split(":"))
                    us_time = time(h, m)

                return cls(
                    enabled=data.get("enabled", False),
                    china_schedule_time=china_time,
                    us_schedule_time=us_time,
                    schedule_type=data.get("schedule_type", "cron"),
                    check_interval_minutes=data.get("check_interval_minutes", 60),
                    smart_update=data.get("smart_update", True),
                    source=data.get("source", "bd"),
                    max_workers=data.get("max_workers", 8),
                    trading_days_only=data.get("trading_days_only", True),
                    _config_file=config_file,
                )
            except Exception:
                pass

        return cls()

    def save(self) -> None:
        """保存配置到文件"""
        Config.ensure_cache_dirs()

        data = {
            "enabled": self.enabled,
            "china_schedule_time": self.china_schedule_time.strftime("%H:%M"),
            "us_schedule_time": self.us_schedule_time.strftime("%H:%M"),
            "schedule_type": self.schedule_type,
            "check_interval_minutes": self.check_interval_minutes,
            "smart_update": self.smart_update,
            "source": self.source,
            "max_workers": self.max_workers,
            "trading_days_only": self.trading_days_only,
        }

        with open(self._config_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "enabled": self.enabled,
            "china_schedule_time": self.china_schedule_time.strftime("%H:%M"),
            "us_schedule_time": self.us_schedule_time.strftime("%H:%M"),
            "schedule_type": self.schedule_type,
            "check_interval_minutes": self.check_interval_minutes,
            "smart_update": self.smart_update,
            "source": self.source,
            "max_workers": self.max_workers,
            "trading_days_only": self.trading_days_only,
        }
