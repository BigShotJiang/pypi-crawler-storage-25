"""
通用应用配置管理
"""
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from stock_seek.core.config import Config


@dataclass
class AppConfig:
    """应用配置"""

    a_share_history_years: int = 2
    us_stock_history_years: int = 2

    _config_file: Optional[Path] = field(default=None, repr=False)

    def __post_init__(self):
        if self._config_file is None:
            self._config_file = Config.CACHE_DIR / "app_config.json"

    @classmethod
    def load(cls) -> "AppConfig":
        """从配置文件加载"""
        config_file = Config.CACHE_DIR / "app_config.json"

        if config_file.exists():
            try:
                with open(config_file, "r", encoding="utf-8") as f:
                    data = json.load(f)

                return cls(
                    a_share_history_years=data.get("a_share_history_years", 2),
                    us_stock_history_years=data.get("us_stock_history_years", 2),
                    _config_file=config_file,
                )
            except Exception:
                pass

        return cls()

    def save(self) -> None:
        """保存配置到文件"""
        Config.ensure_cache_dirs()

        data = {
            "a_share_history_years": self.a_share_history_years,
            "us_stock_history_years": self.us_stock_history_years,
        }

        with open(self._config_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "a_share_history_years": self.a_share_history_years,
            "us_stock_history_years": self.us_stock_history_years,
        }