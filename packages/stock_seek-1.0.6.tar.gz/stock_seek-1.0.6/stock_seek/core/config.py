"""
配置管理模块
集中管理所有配置项,避免硬编码
"""
from pathlib import Path
from typing import Literal, Optional

# 数据源类型
DataSource = Literal["xl", "bd"]
SearchType = Literal["high", "low", "close", "open"]


class Config:
    """全局配置类"""

    # 缓存配置
    CACHE_DIR = Path.home() / ".stock_cache"
    PARQUET_DIR = CACHE_DIR / "parquet"
    PARQUET_US_DIR = CACHE_DIR / "parquet_us"
    STOCK_CODE_NAME_FILE = CACHE_DIR / "stock_code_name.json"
    STOCK_CODE_NAME_US_FILE = CACHE_DIR / "stock_code_name_us.json"

    # 线程配置
    DEFAULT_UPDATE_WORKERS = 8
    DEFAULT_SEARCH_WORKERS = 12

    # 数据配置
    A_SHARE_HISTORY_DAYS = 150
    US_STOCK_HISTORY_YEARS = 2

    # 数据源配置
    DATA_SOURCES = ["xl", "bd"]
    SEARCH_TYPES = ["high", "low", "close", "open"]

    # API配置
    DATA_API_HOST = "111.229.114.73"
    DATA_API_PORT = 8089

    @classmethod
    def set_global_cache_dir(cls, cache_dir: Path):
        """
        设置全局缓存目录

        Args:
            cache_dir: 新的缓存目录路径
        """
        cls.CACHE_DIR = Path(cache_dir)
        cls.PARQUET_DIR = cls.CACHE_DIR / "parquet"
        cls.PARQUET_US_DIR = cls.CACHE_DIR / "parquet_us"
        cls.STOCK_CODE_NAME_FILE = cls.CACHE_DIR / "stock_code_name.json"
        cls.STOCK_CODE_NAME_US_FILE = cls.CACHE_DIR / "stock_code_name_us.json"

    @classmethod
    def ensure_cache_dirs(cls):
        """确保缓存目录存在"""
        cls.CACHE_DIR.mkdir(parents=True, exist_ok=True)
        cls.PARQUET_DIR.mkdir(parents=True, exist_ok=True)
        cls.PARQUET_US_DIR.mkdir(parents=True, exist_ok=True)

    @classmethod
    def get_parquet_dir(cls, us: bool = False) -> Path:
        """获取Parquet缓存目录"""
        return cls.PARQUET_US_DIR if us else cls.PARQUET_DIR

    @classmethod
    def get_code_name_file(cls, us: bool = False) -> Path:
        """获取股票代码名称映射文件路径"""
        return cls.STOCK_CODE_NAME_US_FILE if us else cls.STOCK_CODE_NAME_FILE
