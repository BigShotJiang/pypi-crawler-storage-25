"""
自定义异常类
提供统一的异常处理机制
"""


class StockFinderError(Exception):
    """Stock Seek基础异常类"""
    pass


class DataFetchError(StockFinderError):
    """数据获取异常"""
    pass


class CacheError(StockFinderError):
    """缓存操作异常"""
    pass


class InvalidParameterError(StockFinderError):
    """参数验证异常"""
    pass


class StockNotFoundError(StockFinderError):
    """股票未找到异常"""
    pass


class DataValidationError(StockFinderError):
    """数据验证异常"""
    pass
