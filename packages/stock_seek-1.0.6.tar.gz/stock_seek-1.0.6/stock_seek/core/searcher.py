"""
股票搜索引擎
支持多线程搜索和结果展示
"""
from typing import List, Dict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
import pandas as pd
from tqdm import tqdm

from stock_seek.core.config import Config, SearchType
from stock_seek.core.exceptions import InvalidParameterError, CacheError
from stock_seek.cache.cache_manager import CacheManager
from stock_seek.utils.logger import get_logger

logger = get_logger(__name__)


class StockSearcher:
    """股票搜索引擎"""
    
    def __init__(self, us: bool = False):
        """
        初始化搜索引擎
        
        Args:
            us: 是否为美股
        """
        self.us = us
        self.cache_manager = CacheManager(us=us)
    
    def search(
        self, 
        price: float, 
        position: int, 
        search_type: SearchType,
        max_workers: int = None
    ) -> List[Dict]:
        """
        搜索符合条件的股票
        
        Args:
            price: 目标价格
            position: 历史位置(从后往前数,1表示昨天)
            search_type: 搜索类型(high/low/close/open)
            max_workers: 最大线程数
            
        Returns:
            匹配的股票列表,每个元素包含代码、名称、URL等信息
        """
        # 参数验证
        if price <= 0:
            raise InvalidParameterError("价格必须大于0")
        
        if position <= 0:
            raise InvalidParameterError("位置必须大于0")
        
        if search_type not in Config.SEARCH_TYPES:
            raise InvalidParameterError(f"搜索类型必须是: {Config.SEARCH_TYPES}")
        
        if max_workers is None:
            max_workers = Config.DEFAULT_SEARCH_WORKERS
        
        # 加载股票代码-名称映射
        try:
            code_name_map = self.cache_manager.load_code_name_mapping()
        except CacheError:
            logger.warning("缓存文件不存在，请先运行 update 命令更新缓存")
            return []
        
        # 获取所有缓存的股票
        cached_stocks = self.cache_manager.get_all_cached_stocks()
        
        if not cached_stocks:
            logger.warning("缓存为空，请先运行 update 命令更新缓存")
            return []
        
        logger.info(f"开始搜索 {len(cached_stocks)} 只股票...")
        
        # 多线程搜索
        results = []
        chunk_size = len(cached_stocks) // max_workers + 1
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = []
            
            for i in range(0, len(cached_stocks), chunk_size):
                chunk = cached_stocks[i:i + chunk_size]
                future = executor.submit(
                    self._search_chunk,
                    chunk,
                    code_name_map,
                    price,
                    position,
                    search_type
                )
                futures.append(future)
            
            # 收集结果
            for future in as_completed(futures):
                try:
                    chunk_results = future.result()
                    results.extend(chunk_results)
                except Exception as e:
                    logger.error(f"搜索出错: {str(e)}")
        
        return results
    
    def _search_chunk(
        self,
        stock_codes: List[str],
        code_name_map: Dict[str, str],
        price: float,
        position: int,
        search_type: SearchType
    ) -> List[Dict]:
        """搜索单个股票块"""
        results = []
        
        for code in stock_codes:
            try:
                df = self.cache_manager.load_stock_data(code)
                
                if df is None or df.empty:
                    continue
                
                # 获取指定位置的数据(从后往前数)
                if len(df) < position:
                    continue
                
                row = df.iloc[-position]
                
                # 检查价格是否匹配
                actual_price = row[search_type]
                
                # 允许一定的误差(0.01)
                if abs(actual_price - price) < 0.01:
                    name = code_name_map.get(code, "未知")
                    url = self._generate_url(code)
                    
                    results.append({
                        'code': code,
                        'name': name,
                        'price': actual_price,
                        'date': row['日期'],
                        'url': url,
                        'type': search_type
                    })
                    
            except Exception as e:
                # 单个股票失败不影响整体搜索
                continue
        
        return results
    
    def _generate_url(self, stock_code: str) -> str:
        """生成股票详情页URL"""
        if self.us:
            return f"https://quote.eastmoney.com/us/{stock_code}.html"
        else:
            # 判断是沪市还是深市
            if stock_code.startswith('6'):
                return f"https://quote.eastmoney.com/sh{stock_code}.html"
            else:
                return f"https://quote.eastmoney.com/sz{stock_code}.html"
    
    def print_results(self, results: List[Dict]) -> None:
        """打印搜索结果"""
        if not results:
            print("未找到匹配的股票")
            return
        
        print(f"\n找到 {len(results)} 只匹配的股票:\n")
        print(f"{'代码':<10} {'名称':<15} {'价格':<10} {'日期':<15} {'链接'}")
        print("-" * 100)
        
        for result in results:
            print(f"{result['code']:<10} {result['name']:<15} {result['price']:<10.2f} {str(result['date']):<15} {result['url']}")
    
    def interactive_browse(self, results: List[Dict]) -> None:
        """交互式浏览结果"""
        import webbrowser
        
        if not results:
            print("没有可浏览的结果")
            return
        
        print("\n交互模式:")
        print("输入序号打开对应股票页面,输入 'q' 退出\n")
        
        for idx, result in enumerate(results, 1):
            print(f"{idx}. {result['code']} - {result['name']}")
        
        while True:
            user_input = input("\n请输入序号(1-{}): ".format(len(results)))
            
            if user_input.lower() == 'q':
                break
            
            try:
                idx = int(user_input)
                if 1 <= idx <= len(results):
                    url = results[idx - 1]['url']
                    print(f"正在打开: {url}")
                    webbrowser.open(url)
                else:
                    print("序号超出范围")
            except ValueError:
                print("请输入有效的数字或 'q' 退出")
