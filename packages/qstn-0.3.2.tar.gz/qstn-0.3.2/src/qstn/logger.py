# TODO Implement a logger that gets used throughout the project.
