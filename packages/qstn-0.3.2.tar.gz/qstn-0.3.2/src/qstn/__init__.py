"""Public exports for main modules"""

from importlib.metadata import PackageNotFoundError, version as package_version

from . import persona_creator, prompt_builder, survey_manager

try:
    __version__ = package_version("qstn")
except PackageNotFoundError:
    try:
        from ._version import __version__
    except Exception:
        __version__ = "0+unknown"

__all__ = ["prompt_builder", "survey_manager", "persona_creator", "__version__"]
