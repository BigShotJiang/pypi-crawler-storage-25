# Foundations

This section explains QSTN's core building blocks before the full workflow tutorials.

```{toctree}
:maxdepth: 1

llm_prompt_tutorial
answer_options_tutorial
response_generation_parsing_tutorial
inference_batching_tutorial
```
