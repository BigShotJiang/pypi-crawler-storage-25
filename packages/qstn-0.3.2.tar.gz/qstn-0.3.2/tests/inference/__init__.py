"""Inference-related test package."""
