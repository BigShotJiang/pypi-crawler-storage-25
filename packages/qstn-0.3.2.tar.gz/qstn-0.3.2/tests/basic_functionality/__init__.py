"""Basic functionality integration tests."""
