# Vade

Production-grade fixed income quant library. Rust core for performance, Python API via PyO3.

Rates, credit, FX, and financing instruments with automatic differentiation, curve calibration, and risk analytics.

## Installation

### From PyPI

```
pip install vade
```

### From Source

Requires Python 3.10+ and the Rust toolchain.

```bash
git clone https://github.com/satalik/vade.git
cd vade
pip install maturin
maturin develop --release
```

Or using [uv](https://docs.astral.sh/uv/):

```bash
git clone https://github.com/satalik/vade.git
cd vade
uv sync
```

### Dependencies

- numpy >= 2.0
- pandas >= 2.2
- polars >= 1.39
- pyarrow >= 18.0

### Verify Installation

```python
from vade import DiscountCurve
import datetime

curve = DiscountCurve(
    {datetime.date(2024, 1, 1): 1.0, datetime.date(2025, 1, 1): 0.96},
)
print(float(curve.discount_factor(datetime.date(2024, 7, 1))))
```

## Quick Start

### Build and Calibrate a Discount Curve

```python
import datetime
from vade import DiscountCurve, IRS, FRA, Solver

effective = datetime.date(2025, 6, 16)

# Initial curve with flat discount factors -- Solver will calibrate these
curve = DiscountCurve(
    {
        effective: 1.0,
        datetime.date(2025, 9, 16): 1.0,
        datetime.date(2025, 12, 16): 1.0,
        datetime.date(2026, 6, 16): 1.0,
        datetime.date(2027, 6, 16): 1.0,
        datetime.date(2028, 6, 16): 1.0,
        datetime.date(2030, 6, 16): 1.0,
        datetime.date(2035, 6, 16): 1.0,
    },
    interpolation="log_linear",
    convention="act360",
    id="sofr",
)

# Market instruments with target rates
instruments = [
    (FRA(effective=effective, termination="3M", fixed_rate=4.25, convention="act360"),
     0.0425, 0, "3M_FRA", "USD"),
    (FRA(effective=effective, termination="6M", fixed_rate=4.15, convention="act360"),
     0.0415, 0, "6M_FRA", "USD"),
    (IRS(effective=effective, termination="1Y", frequency="a", fixed_rate=4.0,
         convention="act360", float_convention="act360"),
     4.00, 0, "1Y_IRS", "USD"),
    (IRS(effective=effective, termination="2Y", frequency="a", fixed_rate=3.85,
         convention="act360", float_convention="act360"),
     3.85, 0, "2Y_IRS", "USD"),
    (IRS(effective=effective, termination="5Y", frequency="a", fixed_rate=3.70,
         convention="act360", float_convention="act360"),
     3.70, 0, "5Y_IRS", "USD"),
    (IRS(effective=effective, termination="10Y", frequency="a", fixed_rate=3.85,
         convention="act360", float_convention="act360"),
     3.85, 0, "10Y_IRS", "USD"),
]

solver = Solver(curves=[curve], instruments=instruments)
result = solver.iterate()
print(f"Converged: {result.converged}")  # True

calibrated = solver.get_curve(0)
print(f"1Y DF: {float(calibrated.discount_factor(datetime.date(2026, 6, 16))):.6f}")
print(f"1Y zero rate: {float(calibrated.zero_rate(effective, datetime.date(2026, 6, 16))):.4%}")
```

### Price an Interest Rate Swap

```python
# Off-market 5Y swap at 3.80% (market is 3.70%)
swap = IRS(
    effective=effective,
    termination="5Y",
    frequency="a",
    fixed_rate=3.80,
    convention="act360",
    float_convention="act360",
)

print(f"Par rate: {float(swap.rate(calibrated)):.4f}%")
print(f"NPV: {float(swap.npv(calibrated)):,.2f}")
```

### Compute Risk Sensitivities

```python
# Delta: first-order sensitivities to each calibrating instrument
delta = solver.delta(swap, result)
print(delta)

# Gamma: second-order (convexity) risk
gamma = solver.gamma(swap, result)
```

### Fixed Rate Bonds

```python
from vade import FixedRateBond, DiscountCurve
import datetime

bond = FixedRateBond(
    effective=datetime.date(2024, 6, 15),
    termination="5Y",
    fixed_rate=4.5,
    frequency="s",
)

curve = DiscountCurve(
    {datetime.date(2024, 6, 15): 1.0, datetime.date(2029, 6, 15): 0.82},
    interpolation="log_linear",
)

print(f"Price: {float(bond.price(curve)):.4f}")
print(f"YTM: {float(bond.ytm(curve)):.4%}")
print(f"Duration: {float(bond.duration(curve)):.4f}")
```

### Credit Default Swaps

```python
from vade import CDS, DiscountCurve
import datetime

cds = CDS(
    effective=datetime.date(2024, 6, 20),
    termination="5Y",
    frequency="q",
    fixed_rate=100,  # 100bp spread
)

disc_curve = DiscountCurve(
    {datetime.date(2024, 6, 20): 1.0, datetime.date(2029, 6, 20): 0.85},
    interpolation="log_linear",
    id="usd",
)
credit_curve = DiscountCurve(
    {datetime.date(2024, 6, 20): 1.0, datetime.date(2029, 6, 20): 0.95},
    interpolation="log_linear",
    id="credit",
)

print(f"NPV: {float(cds.npv(disc_curve, credit_curve)):,.2f}")
```

## Documentation

Full documentation is in the [docs/](docs/) directory:

- [Quick Start](docs/guides/quick-start.md) -- end-to-end curve building and pricing workflow
- [API Reference](docs/api/) -- complete API for curves, instruments, solver, and more
- [Rates](docs/guides/rates/) -- curve building, pricing, risk, and caps/floors
- [Credit](docs/guides/credit/) -- bonds, CDS, fitted curves, spread analytics
- [FX](docs/guides/fx/) -- FX rates, forwards, cross-currency swaps, NDFs
- [Calibration](docs/guides/calibration.md) -- multi-curve frameworks and solver algorithms
- [Market Context](docs/guides/market-context.md) -- bundling curves, fixings, and FX data
- [Serialization](docs/guides/serialization.md) -- JSON round-tripping for curves and contexts

## License

See [LICENSE](LICENSE) for details.
