"""
Jubbio Voice API
~~~~~~~~~~~~~~~~
Jubbio.py için LiveKit tabanlı ses (voice) bağlantı arayüzü.
"""

import asyncio
import logging
from typing import Optional, Dict, Any

try:
    from livekit import rtc
    has_livekit = True
except ImportError:
    has_livekit = False

log = logging.getLogger(__name__)

class VoiceConnectionStatus:
    CONNECTING = "Connecting"
    SIGNALLING = "Signalling"
    READY = "Ready"
    DISCONNECTED = "Disconnected"
    DESTROYED = "Destroyed"

class AudioPlayerStatus:
    IDLE = "Idle"
    BUFFERING = "Buffering"
    PLAYING = "Playing"
    PAUSED = "Paused"

class VoiceConnection:
    """Ses kanalı bağlantısını (LiveKit Room) temsil eder."""
    
    def __init__(self, client, guild_id: str, channel_id: str):
        if not has_livekit:
            raise RuntimeError("Ses desteği (voice) için 'livekit' paketi yüklenmelidir. Lütfen `pip install livekit` komutunu çalıştırın.")
        
        self.client = client
        self.guild_id = guild_id
        self.channel_id = channel_id
        self.room: Optional[rtc.Room] = None
        self.status = VoiceConnectionStatus.CONNECTING
        self._player = None
        self.connected_event = asyncio.Event()

    async def _connect_livekit(self, endpoint: str, token: str):
        """Gateway'den VOICE_SERVER_UPDATE geldiğinde bu fonksiyon tetiklenir."""
        self.status = VoiceConnectionStatus.SIGNALLING
        
        # Endpoint formati genelde wss:// ile başlar. Jubbio/LiveKit server URL
        url = endpoint if endpoint.startswith("ws") else f"wss://{endpoint}"
        
        self.room = rtc.Room()
        
        # Livekit eventlerini bağlayabiliriz
        @self.room.on("disconnected")
        def on_disconnected():
            log.info(f"Ses bağlantısı kesildi: {self.guild_id}")
            self.status = VoiceConnectionStatus.DISCONNECTED

        try:
            log.info(f"LiveKit'e bağlanılıyor: {url}")
            await self.room.connect(url, token)
            self.status = VoiceConnectionStatus.READY
            log.info(f"Ses kanalına başarıyla bağlanıldı: {self.guild_id}")
            self.connected_event.set()
        except Exception as e:
            log.error(f"LiveKit bağlantı hatası: {e}")
            self.status = VoiceConnectionStatus.DISCONNECTED
            self.connected_event.set()

    async def disconnect(self):
        """Bağlantıyı keser."""
        if self.room:
            await self.room.disconnect()
        self.status = VoiceConnectionStatus.DISCONNECTED

    async def destroy(self):
        """Bağlantıyı ve player'ı yok eder."""
        await self.disconnect()
        self.status = VoiceConnectionStatus.DESTROYED
        if self.guild_id in self.client.voice_clients:
            del self.client.voice_clients[self.guild_id]


class AudioPlayer:
    """LiveKit üzerinden PCM ses akışı (FFmpeg) yapmak için basit bir taslak oynatıcı."""
    
    def __init__(self):
        self.status = AudioPlayerStatus.IDLE
        # Not: Gerçek FFmpeg subprocess yönetimi ve Livekit RTC AudioSource
        # yayını (publish_track) gibi özellikler ileri sürümlerde (v2.0) eklenecektir.
        
    def play(self, resource):
        pass

    def stop(self):
        pass

async def join_voice_channel(client, guild_id: str, channel_id: str, self_mute: bool = False, self_deaf: bool = False, timeout: float = 10.0) -> VoiceConnection:
    """Bir ses kanalına katılır ve LiveKit bağlantısı kurulana kadar bekler."""
    if guild_id in client.voice_clients:
        existing = client.voice_clients[guild_id]
        await existing.destroy()
        
    vc = VoiceConnection(client, guild_id, channel_id)
    client.voice_clients[guild_id] = vc
    
    # Gateway üzerinden isteği gönder
    await client._gateway.update_voice_state(guild_id, channel_id, self_mute, self_deaf)
    
    try:
        await asyncio.wait_for(vc.connected_event.wait(), timeout=timeout)
        if vc.status != VoiceConnectionStatus.READY:
            raise RuntimeError("LiveKit sunucusuna bağlanılamadı.")
    except asyncio.TimeoutError:
        await vc.destroy()
        raise TimeoutError("Ses kanalına bağlanırken zaman aşımı (Gateway yanıt vermedi). Kanal ID'si yanlış olabilir veya yetkiniz yok.")
    
    return vc
