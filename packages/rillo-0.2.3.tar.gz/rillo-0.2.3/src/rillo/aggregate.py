from abc import ABC, abstractmethod
from typing import Generic, Sequence, TypeVar, get_args, get_origin

from pydantic import JsonValue, TypeAdapter

S = TypeVar("S")
E = TypeVar("E")
C = TypeVar("C")


class Aggregate(ABC, Generic[S, E, C]):
    _state_adapter: TypeAdapter[S]
    _event_adapter: TypeAdapter[E]
    _command_adapter: TypeAdapter[C]

    def __init_subclass__(cls, **kwargs) -> None:
        super().__init_subclass__(**kwargs)
        for base in getattr(cls, "__orig_bases__", ()):
            if get_origin(base) is Aggregate:
                state_type, event_type, command_type = get_args(base)
                cls._state_adapter = TypeAdapter(state_type)
                cls._event_adapter = TypeAdapter(event_type)
                cls._command_adapter = TypeAdapter(command_type)
                return

    def __init__(self, id: str) -> None:
        self._id: str = id
        self._state: S | None = None
        self._pending_events: list[E] = []
        self._version: int = 0

    @abstractmethod
    def apply(self, event: E) -> None: ...

    @abstractmethod
    def execute(self, command: C) -> None: ...

    def _emit(self, event: E) -> None:
        self.apply(event)
        self._pending_events.append(event)

    @property
    def id(self) -> str:
        return self._id

    @property
    def version(self) -> int:
        return self._version

    @property
    def pending_events(self) -> list[JsonValue]:
        return [
            self._event_adapter.dump_python(event, mode="json")
            for event in self._pending_events
        ]

    def rehydrate(self, events: Sequence[JsonValue], version: int) -> None:
        original_state = None
        if self._state is not None:
            original_state = self._state_adapter.validate_python(
                self._state_adapter.dump_python(self._state)
            )
        original_version = self._version
        try:
            for event in events:
                parsed_event = self._event_adapter.validate_python(event)
                self.apply(parsed_event)
            self._version = version
            self._pending_events.clear()
        except Exception:
            self._state = original_state
            self._version = original_version
            raise

    def dump_state(self) -> JsonValue | None:
        if self._state is None:
            return None
        return self._state_adapter.dump_python(self._state, mode="json")

    def load_state(self, state: JsonValue, version: int) -> None:
        value = self._state_adapter.validate_python(state)
        self._state = value
        self._version = version
        self._pending_events.clear()

    def commit(self, version: int) -> None:
        self._pending_events.clear()
        self._version = version


__all__ = ["Aggregate"]
