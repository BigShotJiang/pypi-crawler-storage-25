from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import HumanDelta


@dataclass
class Document:
    doc_id: str
    doc_name: str
    category: str | None
    mime_type: str | None
    created_at: str | None


class DocumentClient:
    """Upload and manage org documents (PDFs, audio, images, CSV)."""

    def __init__(self, hd: HumanDelta) -> None:
        self._hd = hd

    def upload(self, file_path: str, category: str | None = None, doc_name: str | None = None) -> Document:
        """Upload a file to the Document Library.

        Supported types: PDF, audio (mp3/wav/m4a), image (png/jpg), CSV.
        Content is extracted and indexed into Memory automatically.

        Args:
            file_path: Local path to the file.
            category: Optional category label.
            doc_name: Display name (defaults to filename).

        Returns:
            Document object with the new doc_id.
        """
        path = Path(file_path)
        name = doc_name or path.name
        import mimetypes
        mime = mimetypes.guess_type(str(path))[0] or "application/octet-stream"

        fields: dict[str, str] = {}
        if category:
            fields["category"] = category
        if doc_name:
            fields["doc_name"] = doc_name

        with open(path, "rb") as f:
            r = self._hd._session.post(
                f"{self._hd._base}/v1/documents",
                files={"file": (name, f, mime)},
                data=fields,
            )
        r.raise_for_status()
        raw = r.json()
        return Document(
            doc_id=raw.get("doc_id", ""),
            doc_name=raw.get("doc_name", name),
            category=raw.get("category"),
            mime_type=mime,
            created_at=raw.get("created_at"),
        )

    def list(self, category: str | None = None) -> list[Document]:
        """List uploaded documents, optionally filtered by category."""
        params = {}
        if category:
            params["category"] = category
        raw = self._hd._get("/v1/documents", params)
        if not isinstance(raw, list):
            return []
        return [
            Document(
                doc_id=r.get("doc_id", ""),
                doc_name=r.get("doc_name", ""),
                category=r.get("category"),
                mime_type=r.get("mime_type"),
                created_at=r.get("created_at"),
            )
            for r in raw
        ]

    def delete(self, doc_id: str) -> None:
        """Permanently delete a document."""
        r = self._hd._session.delete(f"{self._hd._base}/v1/documents/{doc_id}")
        r.raise_for_status()
