from __future__ import annotations
from dataclasses import dataclass, field
from typing import Literal


@dataclass
class SearchResult:
    chunk_id: str
    score: float
    raw_score: float
    text: str
    source_url: str
    source_type: Literal["web", "document"]
    match_type: str
    score_kind: str
    page_title: str | None = None
    doc_id: str | None = None

    def __str__(self) -> str:
        title = self.page_title or self.source_url
        return f"[{self.score:.2f}] {title}\n{self.text[:200]}"
