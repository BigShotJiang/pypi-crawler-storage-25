from __future__ import annotations
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from .client import HumanDelta

IndexStatus = Literal["queued", "running", "done", "completed", "failed", "cancelled"]
TERMINAL_STATUSES = {"done", "completed", "failed", "cancelled"}


@dataclass
class IndexJob:
    id: str
    status: IndexStatus
    name: str
    source_type: str
    _hd: HumanDelta

    def refresh(self) -> IndexJob:
        """Fetch latest status from the API."""
        raw = self._hd._get(f"/v1/indexes/{self.id}")
        self.status = raw.get("status", self.status)
        return self

    def wait(self, interval: int = 3, timeout: int = 600) -> IndexJob:
        """Block until the index job reaches a terminal state.

        Args:
            interval: Polling interval in seconds (default 3).
            timeout: Max wait time in seconds (default 600).

        Returns:
            This IndexJob with updated status.

        Raises:
            TimeoutError: If job does not finish within timeout.
            RuntimeError: If job status is "failed".
        """
        deadline = time.time() + timeout
        while self.status not in TERMINAL_STATUSES:
            if time.time() > deadline:
                raise TimeoutError(f"Index job {self.id} timed out after {timeout}s")
            time.sleep(interval)
            self.refresh()
        if self.status == "failed":
            raise RuntimeError(f"Index job {self.id} failed")
        return self

    def cancel(self) -> None:
        """Cancel a running index job."""
        self._hd._post(f"/v1/indexes/{self.id}/cancel", {})


class IndexClient:
    """Manage website crawl / index jobs."""

    def __init__(self, hd: HumanDelta) -> None:
        self._hd = hd

    def create(self, url: str, max_pages: int = 100, name: str = "Website index") -> IndexJob:
        """Start a new website crawl.

        Args:
            url: Seed URL to crawl, e.g. "https://support.yoursite.com"
            max_pages: Max pages to crawl (1-500, default 100).
            name: Human readable label for this index job.

        Returns:
            IndexJob you can call .wait() on.
        """
        raw = self._hd._post("/v1/indexes", {
            "source_type": "website",
            "name": name,
            "website": {"url": url, "max_pages": max_pages},
        })
        return IndexJob(
            id=raw["id"],
            status=raw.get("status", "queued"),
            name=raw.get("name", name),
            source_type="website",
            _hd=self._hd,
        )

    def get(self, job_id: str) -> IndexJob:
        """Fetch a single index job by ID."""
        raw = self._hd._get(f"/v1/indexes/{job_id}")
        return IndexJob(
            id=raw["id"],
            status=raw.get("status", "unknown"),
            name=raw.get("name", ""),
            source_type=raw.get("source_type", "website"),
            _hd=self._hd,
        )

    def list(self, limit: int = 20, offset: int = 0) -> list[IndexJob]:
        """List recent index jobs."""
        raw = self._hd._get("/v1/indexes", {"limit": str(limit), "offset": str(offset)})
        if not isinstance(raw, list):
            return []
        return [
            IndexJob(
                id=r["id"],
                status=r.get("status", "unknown"),
                name=r.get("name", ""),
                source_type=r.get("source_type", "website"),
                _hd=self._hd,
            )
            for r in raw
        ]
