from __future__ import annotations
import requests
from .fs import FsClient
from .indexes import IndexClient
from .documents import DocumentClient
from .search import SearchResult


class HumanDelta:
    """Human Delta dev platform client.

    Usage::

        from humandelta import HumanDelta

        hd = HumanDelta(api_key="hd_live_...")
        results = hd.search("refund policy")
        content = hd.fs.read("/memory/SOURCES.md")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.humandelta.ai",
    ) -> None:
        if not api_key.startswith("hd_live_"):
            raise ValueError("api_key must start with hd_live_")
        self._base = base_url.rstrip("/")
        self._session = requests.Session()
        self._session.headers.update({"Authorization": f"Bearer {api_key}"})
        self.fs = FsClient(self)
        self.indexes = IndexClient(self)
        self.documents = DocumentClient(self)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _post(self, path: str, body: dict) -> dict:
        r = self._session.post(f"{self._base}{path}", json=body)
        r.raise_for_status()
        return r.json()

    def _get(self, path: str, params: dict | None = None) -> dict | list:
        r = self._session.get(f"{self._base}{path}", params=params or {})
        r.raise_for_status()
        return r.json()

    # ------------------------------------------------------------------
    # Top-level search
    # ------------------------------------------------------------------

    def search(self, query: str, top_k: int = 10) -> list[SearchResult]:
        """Semantic search over all ingested sources.

        Args:
            query: Natural language question or phrase.
            top_k: Maximum number of results (default 10, max 32).

        Returns:
            List of SearchResult objects sorted by relevance score.
        """
        raw = self._post("/v1/search", {"query": query, "top_k": top_k})
        if isinstance(raw, list):
            items = raw
        elif isinstance(raw, dict):
            items = raw.get("results") or raw.get("data") or []
        else:
            items = []
        return [SearchResult(**r) for r in items]
