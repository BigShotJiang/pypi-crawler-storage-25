from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import HumanDelta


@dataclass
class FsEntry:
    name: str
    path: str
    is_dir: bool
    size: int | None = None
    mtime: str | None = None


class FsClient:
    """Virtual filesystem access over ingested Memory."""

    def __init__(self, hd: HumanDelta) -> None:
        self._hd = hd

    def read(self, path: str) -> str:
        """Read a file from Memory by path.

        Args:
            path: Absolute path, e.g. "/source/zendesk2/billing.md"

        Returns:
            File content as a string (markdown for .md files).
        """
        res = self._hd._post("/v1/fs", {"op": "read", "path": path})
        return res.get("content") or res.get("stdout") or ""

    def list(self, path: str) -> list[FsEntry]:
        """List directory contents.

        Args:
            path: Absolute directory path, e.g. "/source/website"

        Returns:
            List of FsEntry objects.
        """
        res = self._hd._post("/v1/fs", {"op": "list", "path": path})
        entries = res.get("entries") or []
        return [
            FsEntry(
                name=e.get("name", ""),
                path=e.get("path", ""),
                is_dir=e.get("is_dir", False),
                size=e.get("size"),
                mtime=e.get("mtime"),
            )
            for e in entries
        ]

    def shell(self, cmd: str) -> str:
        """Run a shell command against Memory (bash, grep, find, etc.).

        Args:
            cmd: Shell command string, e.g. "tree -L 3 /memory"

        Returns:
            stdout as a string.
        """
        res = self._hd._post("/v1/fs", {"op": "shell", "cmd": cmd})
        return res.get("stdout", "")

    def write(self, path: str, content: str) -> None:
        """Write a file to the agent or user memory namespace.

        Requires fs:write scope on your API key.

        Args:
            path: Must be under /agent/ or /me/
            content: File content (markdown recommended).
        """
        self._hd._post("/v1/fs", {"op": "write", "path": path, "content": content})

    def delete(self, path: str) -> None:
        """Delete a file from the agent or user memory namespace.

        Requires fs:write scope on your API key.
        """
        self._hd._post("/v1/fs", {"op": "delete", "path": path})
