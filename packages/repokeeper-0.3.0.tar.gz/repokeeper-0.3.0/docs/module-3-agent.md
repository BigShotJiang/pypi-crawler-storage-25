# Module 3: Implementation Agent 🤖

The Implementation Agent reads GitHub issues, understands your codebase,
generates an implementation plan using AI, and opens a pull request for your
review.

## How to Trigger

There are two ways to invoke the agent:

### Method 1: Label

Add the `agent-todo` label to any issue:

```
Issue → Labels → agent-todo
```

### Method 2: Comment

Comment `@repokeeper go` on an issue (must be a repo collaborator):

```
@repokeeper go
```

The agent responds immediately with an acknowledgment comment and begins
working.

## Architecture

```
┌──────────────────────────────────────────────────────┐
│              Implementation Agent                     │
├──────────┬──────────┬──────────┬─────────────────────┤
│  Trigger │  Context │  LLM     │  Git + PR           │
│          │          │          │                     │
│  label:  │  Read    │  Read    │  Create branch      │
│  agent-  │  repo    │  issue   │  Apply changes      │
│  todo    │  files   │  + code  │  Push to remote     │
│          │  (40 max)│  + style │  Open PR            │
│  comment:│          │  → JSON  │  Post comment       │
│  @repo-  │          │  plan    │  with PR link       │
│  keeper  │          │          │                     │
│  go      │          │          │                     │
└──────────┴──────────┴──────────┴─────────────────────┘
```

## What Happens Step by Step

### Step 1: Trigger Detection

The GitHub Action listens for:
- Issue labeled `agent-todo`
- Comment `@repokeeper go` from a collaborator

The workflow also checks access: only `OWNER`, `MEMBER`, or `COLLABORATOR` can
trigger via comment.

For PR creation, the default `GITHUB_TOKEN` needs repository Actions permission
to create pull requests. If your repository or organization disables that
permission, set `REPOKEEPER_GITHUB_TOKEN` to a token with contents and pull
request write access.

### Step 2: Skip Checks

Before doing anything expensive, the agent checks:

1. **Profile `agent.implement`**: If `false`, skips immediately.
2. **Skip keywords**: If the issue contains any phrase from `agent.skip_keywords`,
   the agent skips with an explanation.

Example skip keyword match:

```yaml
agent:
  skip_keywords:
    - "needs design"
    - "breaking change"
    - "RFC required"
```

If the issue title is *"RFC: New event system"*, the agent skips because
`"RFC"` implies design work.

### Step 3: Codebase Context Collection

The agent walks the repository and collects up to `agent.max_context_files`
source files (default: 40), prioritizing:

1. Config files (`.yml`, `.toml`, `.cfg`, `.ini`)
2. Documentation files (`README.*`, `*.md`)
3. Source files

Files are skipped if:
- In excluded directories (`.git`, `node_modules`, `venv`, `dist`, etc.)
- Larger than 40KB (likely minified / generated)
- Not a recognized source extension

### Step 4: LLM Plan Generation

The context (issue + comments + codebase + maintainer style preferences) is
sent to the LLM with a system prompt that instructs:

- Follow existing code style exactly
- Make minimal changes only
- No unrequested features, refactors, or comments
- Respect tech stack preferences (preferred/avoid lists)
- Skip if unclear or unsafe

The LLM responds with a structured JSON plan:

```json
{
  "skip": false,
  "reason": "",
  "summary": "Add file size validation to upload endpoint with 10MB default limit",
  "branch_name": "repokeeper/issue-42-upload-size-validation",
  "commit_message": "feat: add upload size validation (10MB limit)",
  "changes": {
    "src/api/upload.py": "<complete new file content>",
    "src/config.py": "<complete new file content>"
  },
  "new_files": {
    "tests/test_upload_validation.py": "<complete new file content>"
  }
}
```

### Step 5: Validation

The plan is validated against profile constraints:

- **`pr.max_files_per_pr`**: Reject if too many files changed
- **`pr.min_tests`**: Warn if no test files changed
- **Branch naming**: Must start with `repokeeper/`

### Step 6: Verification

Before committing, the agent runs verification commands. If any command fails,
RepoKeeper stops, comments on the issue with the command output, and does not
open a PR.

Verification command selection:

1. If `agent.verify_commands` is set, those commands are used exactly.
2. Otherwise RepoKeeper conservatively discovers available project checks, such
   as `ruff check .` for Python projects and `pytest tests` when pytest is
   installed and a `tests/` directory exists.
3. Set `agent.verify_commands: false` to disable pre-PR verification.

### Step 7: Git Operations

After validation and verification pass, the agent:

1. Creates a new branch (`repokeeper/issue-42-upload-size-validation`)
2. Writes modified files and new files
3. Commits with the planned commit message
4. Pushes to the remote

### Step 8: PR Creation

A pull request is opened with:

```markdown
## 🤖 RepoKeeper Implementation

Closes #42

### Summary
Add file size validation to upload endpoint with 10MB default limit

### Changed files
- `src/api/upload.py`
- `src/config.py`
- `tests/test_upload_validation.py`

---
*Generated by RepoKeeper · Please review carefully before merging.*
```

### Step 9: Issue Update

The agent comments on the issue with the PR link and summary:

```
🤖 **RepoKeeper** finished implementation.

**PR:** https://github.com/owner/repo/pull/143

**Summary:** Add file size validation to upload endpoint with 10MB default limit

Please review the changes before merging.
```

## Configuration

### Profile Settings

```yaml
agent:
  model: deepseek-chat
  implement: true
  max_context_files: 40
  temperature: 0.1
  skip_keywords:
    - "needs design"
    - "breaking change"
    - "RFC required"
  verify_commands:
    - ruff check .
    - pytest tests

style:
  code_style: |
    Follow existing code style exactly.
    Use type hints in Python.
    Keep functions small and focused.

tech:
  preferred:
    - python
    - fastapi
  avoid:
    - jquery

pr:
  max_files_per_pr: 15
  min_tests: true
  review_required: true
```

| Setting | Default | Description |
|---------|---------|-------------|
| `agent.model` | `deepseek-chat` | LLM model to use |
| `agent.implement` | `true` | Enable automatic implementation |
| `agent.max_context_files` | `40` | Max files to include in LLM context |
| `agent.temperature` | `0.1` | LLM temperature (lower = more deterministic) |
| `agent.skip_keywords` | `[]` | Phrases that trigger auto-skip |
| `agent.verify_commands` | auto-detect | Commands that must pass before PR creation; set `false` to disable |
| `style.code_style` | — | Code style instructions for the LLM |
| `tech.preferred` | `[]` | Preferred tech stack (LLM prioritizes) |
| `tech.avoid` | `[]` | Tech to avoid (LLM will not use) |
| `pr.max_files_per_pr` | `15` | Reject PRs exceeding this many files |
| `pr.min_tests` | `true` | Warn when no test files are changed |

## When the Agent Skips

The agent will skip and explain why in these cases:

| Reason | Example |
|--------|---------|
| Issue is unclear | "Cannot determine what needs to be changed from the description." |
| Too many files | "Implementation would touch 22 files (max: 15). Reduce scope." |
| Skip keyword matched | "Issue contains 'breaking change' — requires design discussion." |
| Unsafe change | "Modifying authentication logic requires manual review." |
| Requires external info | "Need API documentation for the third-party service." |

## Workflow Trigger Details

```yaml
# Triggered by comment "@repokeeper go"
if: |
  github.event_name == 'issue_comment' &&
  !github.event.issue.pull_request &&
  contains(github.event.comment.body, '@repokeeper go') &&
  github.event.comment.author_association in ('OWNER', 'MEMBER', 'COLLABORATOR')

# Triggered by label "agent-todo"
if: |
  github.event_name == 'issues' &&
  github.event.label.name == 'agent-todo'
```

## API Reference

### `run_agent(gh_token, repository, issue_number, llm_api_key, llm_base_url) → dict`

Run the implementation agent end-to-end.

**Returns:** `{"skip": bool, "reason": str, "pr_url": str | None}`

### `collect_repo_files(max_files=40) → dict[str, str]`

Collect source files from the repository.

### `get_issue_data(repo, number) → dict`

Extract structured data from a GitHub issue.

### `call_llm(issue_data, context_str, profile, llm_client) → dict`

Call the LLM to generate an implementation plan.

### `validate_implementation(implementation, profile) → list[str]`

Validate an implementation against profile constraints.

### `check_skip_keywords(issue_data, profile) → str | None`

Check if the issue matches any skip keywords.

## Best Practices

1. **Start small.** First issues should be well-scoped, single-file changes.
2. **Review thoroughly.** The agent is fast but not infallible. Always review.
3. **Use skip keywords.** Add phrases like `security`, `auth`, `breaking` to
   prevent the agent from touching sensitive areas.
4. **Provide clear issues.** The more specific the issue description, the
   better the implementation.
5. **Iterate on style.** Update `style.code_style` in your profile as you
   discover what the agent gets wrong.
