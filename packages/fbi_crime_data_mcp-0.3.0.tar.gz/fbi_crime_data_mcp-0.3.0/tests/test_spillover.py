"""Tests for ResponseSpilloverMiddleware."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from fastmcp.server.middleware.middleware import MiddlewareContext
from fastmcp.tools.base import ToolResult
from mcp.types import TextContent

from fbi_crime_data_mcp.spillover import ResponseSpilloverMiddleware


class _FakeParams:
    """Minimal stand-in for CallToolRequestParams."""

    def __init__(self, name: str):
        self.name = name


def _make_context(tool_name: str = "get_nibrs_data") -> MiddlewareContext:
    return MiddlewareContext(
        message=_FakeParams(tool_name),
        method="tools/call",
    )


def _make_result(text: str) -> ToolResult:
    return ToolResult(content=[TextContent(type="text", text=text)])


class TestSpilloverMiddleware:
    async def test_small_response_passes_through(self, tmp_path, monkeypatch):
        import fbi_crime_data_mcp.spillover as mod

        monkeypatch.setattr(mod, "SPILLOVER_DIR", tmp_path / "spillover")

        mw = ResponseSpilloverMiddleware(max_chars=1000)
        small = _make_result('{"data": "small"}')
        call_next = AsyncMock(return_value=small)

        result = await mw.on_call_tool(_make_context(), call_next)

        assert result is small
        assert not (tmp_path / "spillover").exists()

    async def test_large_response_spills_to_file(self, tmp_path, monkeypatch):
        import fbi_crime_data_mcp.spillover as mod

        monkeypatch.setattr(mod, "SPILLOVER_DIR", tmp_path / "spillover")

        mw = ResponseSpilloverMiddleware(max_chars=100, preview_chars=50)
        big_text = "x" * 200
        call_next = AsyncMock(return_value=_make_result(big_text))

        result = await mw.on_call_tool(_make_context(), call_next)

        # Response is truncated with metadata
        text = result.content[0].text
        assert "200 characters" in text
        assert "PREVIEW" in text
        assert str(tmp_path / "spillover") in text

        # Full content is on disk
        spillover_files = list((tmp_path / "spillover").glob("*.json"))
        assert len(spillover_files) == 1
        assert spillover_files[0].read_text() == big_text

    async def test_duplicate_response_reuses_file(self, tmp_path, monkeypatch):
        import fbi_crime_data_mcp.spillover as mod

        monkeypatch.setattr(mod, "SPILLOVER_DIR", tmp_path / "spillover")

        mw = ResponseSpilloverMiddleware(max_chars=100, preview_chars=50)
        big_text = "y" * 200
        call_next = AsyncMock(return_value=_make_result(big_text))

        await mw.on_call_tool(_make_context(), call_next)
        await mw.on_call_tool(_make_context(), call_next)

        # Only one file despite two calls
        spillover_files = list((tmp_path / "spillover").glob("*.json"))
        assert len(spillover_files) == 1

    async def test_excluded_tool_not_spilled(self, tmp_path, monkeypatch):
        import fbi_crime_data_mcp.spillover as mod

        monkeypatch.setattr(mod, "SPILLOVER_DIR", tmp_path / "spillover")

        mw = ResponseSpilloverMiddleware(max_chars=100, excluded_tools={"manage_cache"})
        big = _make_result("z" * 200)
        call_next = AsyncMock(return_value=big)

        result = await mw.on_call_tool(_make_context("manage_cache"), call_next)

        assert result is big
        assert not (tmp_path / "spillover").exists()

    async def test_max_chars_zero_raises(self):
        with pytest.raises(ValueError, match="max_chars must be positive"):
            ResponseSpilloverMiddleware(max_chars=0)

    async def test_non_text_content_passes_through(self, tmp_path, monkeypatch):
        from mcp.types import ImageContent

        import fbi_crime_data_mcp.spillover as mod

        monkeypatch.setattr(mod, "SPILLOVER_DIR", tmp_path / "spillover")

        mw = ResponseSpilloverMiddleware(max_chars=100)
        # Result with non-TextContent only
        image_content = ImageContent(type="image", data="base64data", mimeType="image/png")
        result = ToolResult(content=[image_content])
        call_next = AsyncMock(return_value=result)

        out = await mw.on_call_tool(_make_context(), call_next)
        assert out is result  # passed through unchanged

    async def test_write_failure_returns_preview(self, tmp_path, monkeypatch):
        import asyncio
        from unittest.mock import patch

        import fbi_crime_data_mcp.spillover as mod

        spillover_dir = tmp_path / "spillover"
        monkeypatch.setattr(mod, "SPILLOVER_DIR", spillover_dir)

        mw = ResponseSpilloverMiddleware(max_chars=100, preview_chars=50)
        call_next = AsyncMock(return_value=_make_result("w" * 200))

        # Mock asyncio.to_thread to raise OSError, simulating write failure
        with patch.object(asyncio, "to_thread", side_effect=OSError("disk full")):
            result = await mw.on_call_tool(_make_context(), call_next)
            text = result.content[0].text
            assert "filesystem error" in text
            assert "PREVIEW" in text

    async def test_filename_contains_tool_name(self, tmp_path, monkeypatch):
        import fbi_crime_data_mcp.spillover as mod

        monkeypatch.setattr(mod, "SPILLOVER_DIR", tmp_path / "spillover")

        mw = ResponseSpilloverMiddleware(max_chars=100, preview_chars=50)
        call_next = AsyncMock(return_value=_make_result("a" * 200))

        await mw.on_call_tool(_make_context("lookup_agency"), call_next)

        spillover_files = list((tmp_path / "spillover").glob("*.json"))
        assert len(spillover_files) == 1
        assert spillover_files[0].name.startswith("lookup_agency_")

    async def test_file_exists_error_returns_false(self, tmp_path, monkeypatch):
        """When spillover file already exists on disk, _write_spillover returns False."""
        import fbi_crime_data_mcp.spillover as mod

        spillover_dir = tmp_path / "spillover"
        spillover_dir.mkdir()
        monkeypatch.setattr(mod, "SPILLOVER_DIR", spillover_dir)

        mw = ResponseSpilloverMiddleware(max_chars=100, preview_chars=50)
        big_text = "q" * 200
        call_next = AsyncMock(return_value=_make_result(big_text))

        # First call creates the file
        await mw.on_call_tool(_make_context(), call_next)
        files = list(spillover_dir.glob("*.json"))
        assert len(files) == 1

        # Remove the file but leave the path check pass by writing it back manually
        # Actually, to hit FileExistsError in _write_spillover, we need the exists()
        # check to return False but the file to exist by the time open("x") runs.
        # Simpler: pre-create the file, remove it from exists cache, call again.
        # The duplicate test already covers the exists() fast path.
        # Instead, let's mock exists() to return False so _write_spillover is called,
        # but the file is already there → FileExistsError.
        import pathlib
        from unittest.mock import patch

        original_exists = pathlib.Path.exists

        def patched_exists(self, *args, **kwargs):
            if self.parent == spillover_dir and self.suffix == ".json":
                return False  # force _write_spillover to be called
            return original_exists(self, *args, **kwargs)

        with patch.object(pathlib.Path, "exists", patched_exists):
            result = await mw.on_call_tool(_make_context(), call_next)
            # Should succeed (file exists, FileExistsError caught, returns preview)
            text = result.content[0].text
            assert "saved to" in text or "PREVIEW" in text

        # Still only one file
        assert len(list(spillover_dir.glob("*.json"))) == 1
