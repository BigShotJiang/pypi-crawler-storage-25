"""Hate crime data tool."""

from fastmcp import Context

from ..api_client import AppContext
from ..constants import BIAS_CODES
from ..response_utils import process_crime_response
from ..server import mcp
from ..validators import build_geo_path, effective_aggregate, validate_crime_data_params


@mcp.tool()
async def get_hate_crime_data(
    level: str,
    from_date: str,
    to_date: str,
    bias: str | None = None,
    data_type: str = "counts",
    state: str | None = None,
    ori: str | None = None,
    aggregate: str = "yearly",
    ctx: Context | None = None,
) -> str:
    """Get hate crime statistics, optionally filtered by bias motivation. Returns incident counts, victim types, offense types, offender demographics, and locations.

    Args:
        level: Geographic level — "national", "state", or "agency"
        from_date: Start date in mm-yyyy format (e.g., "01-2020")
        to_date: End date in mm-yyyy format (e.g., "12-2022")
        bias: Bias code to filter by (e.g., "12" for Anti-Black, "21" for Anti-Jewish, "24" for Anti-Islamic). Use get_reference_data with offense_type="hate-crime" for full list. If omitted, returns all biases.
        data_type: "counts" for time series or "totals" for aggregate data (default: "counts")
        state: Two-letter state abbreviation (required when level is "state")
        ori: Agency ORI code (required when level is "agency")
        aggregate: Aggregation level — "yearly" (default, sums monthly into yearly) or "monthly" (monthly granularity). Only applies when data_type is "counts".
    """
    if bias and bias not in BIAS_CODES:
        return f"Invalid bias code '{bias}'. Use get_reference_data(data_type='offenses', offense_type='hate-crime') to see valid codes."

    err = validate_crime_data_params(
        level=level,
        from_date=from_date,
        to_date=to_date,
        state=state,
        ori=ori,
        data_type=data_type,
        aggregate=aggregate,
    )
    if err:
        return err

    path = build_geo_path("/hate-crime", level, state=state, ori=ori)
    if bias:
        path += f"/{bias}"

    app_ctx: AppContext = ctx.lifespan_context
    raw = await app_ctx.api_get(path, {"type": data_type, "from": from_date, "to": to_date})
    return process_crime_response(raw, aggregate=effective_aggregate(data_type, aggregate))
