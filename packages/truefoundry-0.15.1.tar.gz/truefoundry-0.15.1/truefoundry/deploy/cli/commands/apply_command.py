from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import rich_click as click
import yaml

from truefoundry.cli.console import console
from truefoundry.cli.const import GROUP_CLS
from truefoundry.cli.util import handle_exception_wrapper
from truefoundry.deploy.lib.clients.servicefoundry_client import (
    ServiceFoundryServiceClient,
)
from truefoundry.deploy.lib.dao import apply as apply_lib
from truefoundry.deploy.lib.dao import delete as delete_lib
from truefoundry.deploy.lib.model.entity import (
    File,
    ManifestLike,
    ResolvedDirectoryFiles,
    ResolvedDirectoryResources,
    Resource,
)


def _validate_options(
    files: Tuple[str, ...],
    directory: Optional[str],
    diffs_only: bool,
    ref: Optional[str],
    show_diff: bool,
    dry_run: bool,
    sync: bool,
) -> None:
    if show_diff and not dry_run:
        raise click.ClickException("--show-diff requires --dry-run")

    if ref is not None and not diffs_only:
        raise click.ClickException("--ref requires --diffs-only")

    if diffs_only and not directory:
        raise click.ClickException("--diffs-only requires -d/--directory")

    if files and directory:
        raise click.ClickException(
            "-f/--file and -d/--directory are mutually exclusive"
        )

    if not files and not directory:
        raise click.ClickException("Either -f/--file or -d/--directory is required")

    if sync and (not directory or not diffs_only):
        raise click.ClickException("--sync requires -d/--directory and --diffs-only")


def _log_git_deleted_files_info(
    sync: bool, resources_to_delete: List[Resource], dry_run: bool
) -> None:
    if not sync or not resources_to_delete:
        return

    suffix = ""
    if dry_run:
        suffix = "No changes will be made right now."
    else:
        suffix = "Resources from these YAML files will be deleted from TrueFoundry."
    console.print(f"[cyan]The following files were deleted from Git. {suffix}[/]")
    for resource in resources_to_delete:
        console.print(
            f"  [dim]{resource.file_path}[/] [cyan](type: {resource.type}, name: {resource.name})[/]"
        )
    console.print()


def _resolve_directory_files(
    directory: str, diffs_only: bool, ref: Optional[str]
) -> Optional[ResolvedDirectoryFiles]:
    deleted_files: List[File] = []
    if diffs_only:
        git_changed_yaml_files = apply_lib.get_git_changed_yaml_files(directory, ref)
        resolved_files = git_changed_yaml_files.modified
        deleted_files = git_changed_yaml_files.deleted

        ref_label = ref or "HEAD"
        if not resolved_files and not deleted_files:
            console.print(
                f"[yellow]No changed yaml files found compared to {ref_label}[/]"
            )
            return None
        console.print(
            f"[cyan]Found {len(resolved_files)} changed yaml file(s) and {len(deleted_files)} deleted yaml file(s) compared to {ref_label}[/]"
        )
    else:
        resolved_file_paths = apply_lib.collect_yaml_files(directory)
        resolved_files = [File(path=file_path) for file_path in resolved_file_paths]
        if not resolved_files:
            console.print("[yellow]No yaml files found in the directory[/]")
            return None
        console.print(f"[cyan]Found {len(resolved_files)} yaml file(s) in directory[/]")

    return ResolvedDirectoryFiles(
        modified=resolved_files,
        deleted=deleted_files,
    )


def _resolve_resources_from_deleted_files(
    deleted_files: List[File], dry_run: bool
) -> List[Resource]:
    if not deleted_files:
        return []

    resources_to_delete = []
    for deleted_file in deleted_files:
        try:
            manifests = list(yaml.safe_load_all(deleted_file.content))
        except Exception as ex:
            message = f"Failed to read deleted file {deleted_file.path} from git diff results as a valid YAML file. Error: {ex}"
            raise Exception(message) from None
        resources_to_delete.extend(
            _resolve_resources_from_file(manifests, deleted_file.path, dry_run)
        )
    return resources_to_delete


def _resolve_resources_in_directory(
    directory: str, diffs_only: bool, dry_run: bool, sync: bool, ref: Optional[str]
) -> Optional[ResolvedDirectoryResources]:
    resolved_directory_files = _resolve_directory_files(directory, diffs_only, ref)
    if resolved_directory_files is None:
        return None

    modified_file_paths = [file.path for file in resolved_directory_files.modified]
    resources_to_update = _resolve_resources_from_files(modified_file_paths, dry_run)

    resources_to_delete = []

    if sync:
        resources_to_delete = _resolve_resources_from_deleted_files(
            resolved_directory_files.deleted, dry_run
        )

    return ResolvedDirectoryResources(
        to_update=resources_to_update, to_delete=resources_to_delete
    )


def _resolve_resources_from_file(
    manifests: List[Dict[str, Any]], filepath: str, dry_run: bool
) -> List[Resource]:
    resolved_resources: List[Resource] = []
    filename = Path(filepath).name
    prefix = "[Dry Run] " if dry_run else ""
    for index, manifest in enumerate(manifests):
        file_metadata_message = (
            f"{prefix}Failed to read manifest at index {index} from file {filename}."
        )
        if not isinstance(manifest, dict):
            message = f"{file_metadata_message} Error: A manifest must be a dict, got type {type(manifest)}"
            raise Exception(message) from None

        try:
            parsed_manifest = ManifestLike.parse_obj(manifest)
        except Exception as ex:
            message = f"{file_metadata_message} Error: {ex}"
            raise Exception(message) from None

        # Fallback to type if name is not present in the manifest
        type_str = parsed_manifest.type or "unknown"
        name_str = parsed_manifest.name or type_str
        resolved_resources.append(
            Resource(
                file_path=filepath,
                manifest=manifest,
                type=type_str,
                name=name_str,
            )
        )

    return resolved_resources


def _resolve_resources_from_files(
    filepaths: List[str], dry_run: bool
) -> List[Resource]:
    resolved_resources: List[Resource] = []
    for filepath in filepaths:
        try:
            with open(filepath, "r") as f:
                manifests = list(yaml.safe_load_all(f))
        except Exception as ex:
            message = (
                f"Failed to read file {filepath} as a valid YAML file. Error: {ex}"
            )
            raise Exception(message) from None
        resolved_resources.extend(
            _resolve_resources_from_file(manifests, filepath, dry_run)
        )
    return resolved_resources


def _apply_and_delete_resources(
    sorted_resources_to_apply: List[Resource],
    sorted_resources_to_delete: List[Resource],
    sf_server_client: ServiceFoundryServiceClient,
    dry_run: bool,
    show_diff: bool,
    sync: bool,
) -> None:
    error_message = None

    # Attempt to delete resources if sync is enabled
    if sync and sorted_resources_to_delete and not dry_run:
        delete_results = delete_lib.delete_manifest_resources(
            resources=sorted_resources_to_delete,
            sf_server_client=sf_server_client,
        )

        if not all(delete_result.success for delete_result in delete_results):
            error_message = "Failed to delete one or more resource manifests."

    if sorted_resources_to_apply:
        if error_message:
            error_message += "\nSkipping apply of resources because some resources failed to delete successfully."
        else:
            apply_results = apply_lib.apply_manifest_resources(
                sorted_resources_to_apply,
                sf_server_client,
                dry_run=dry_run,
                show_diff=show_diff,
            )

            if not all(apply_result.success for apply_result in apply_results):
                error_message = "Failed to apply one or more resource manifests."

    if error_message:
        raise Exception(error_message)


@click.group(
    name="apply",
    cls=GROUP_CLS,
    invoke_without_command=True,
    help="""Create resources by applying manifest locally from TrueFoundry spec.

\b
Examples:
  tfy apply -f manifest.yaml                        Apply a single manifest file
  tfy apply -f team.yaml -f cluster.yaml            Apply multiple files
  tfy apply -d ./manifests                          Apply all yamls in a directory (sorted by dependency order)
  tfy apply -d ./manifests --diffs-only             Apply only git-changed yamls compared to HEAD
  tfy apply -d ./manifests --diffs-only --ref main  Apply only git-changed yamls compared to a branch/tag/commit
  tfy apply -d ./manifests --dry-run                Dry run (simulate without applying)
  tfy apply -d ./manifests --dry-run --show-diff    Dry run with diff output
  tfy apply -d ./manifests --diffs-only --sync      Sync resources by deleting those not present in the manifests
""",
    context_settings={"ignore_unknown_options": True, "allow_interspersed_args": True},
)
@click.option(
    "-f",
    "--file",
    "files",
    type=click.Path(exists=True, dir_okay=False, resolve_path=True),
    help="Path to yaml manifest file (You can apply multiple files at once by providing multiple -f options)",
    show_default=True,
    multiple=True,
)
@click.option(
    "-d",
    "--dir",
    "--directory",
    "directory",
    type=click.Path(exists=True, file_okay=False, resolve_path=True),
    help="Path to a directory containing yaml manifest files. All yamls will be collected and applied in dependency order.",
)
@click.option(
    "--diffs-only",
    "--diffs_only",
    is_flag=True,
    show_default=True,
    help="Only apply yaml files that have changed in git (requires -d)",
)
@click.option(
    "--ref",
    type=str,
    default=None,
    help="Git ref (branch, tag, or commit) to compare against when using --diffs-only (default: HEAD)",
)
@click.option(
    "--dry-run",
    "--dry_run",
    is_flag=True,
    show_default=True,
    help="Simulate the process without actually applying the manifest",
)
@click.option(
    "--show-diff",
    "--show_diff",
    is_flag=True,
    show_default=True,
    help="Print manifest differences when using --dry-run",
)
@click.option(
    "--sync",
    is_flag=True,
    show_default=True,
    help="Sync resources by deleting those not present in the manifests (requires -d/--directory and --diffs-only)",
)
@handle_exception_wrapper
def apply_command(
    files: Tuple[str, ...] = (),
    directory: Optional[str] = None,
    diffs_only: bool = False,
    ref: Optional[str] = None,
    dry_run: bool = False,
    show_diff: bool = False,
    sync: bool = False,
):
    _validate_options(files, directory, diffs_only, ref, show_diff, dry_run, sync)

    resolved_resources_to_apply: List[Resource] = []
    resolved_resources_to_delete: List[Resource] = []

    if directory:
        resolved_directory_resources = _resolve_resources_in_directory(
            directory, diffs_only, dry_run, sync, ref
        )
        if not resolved_directory_resources:
            return
        resolved_resources_to_apply = resolved_directory_resources.to_update
        resolved_resources_to_delete = resolved_directory_resources.to_delete

        _log_git_deleted_files_info(sync, resolved_resources_to_delete, dry_run)
    else:
        resolved_resources_to_apply = _resolve_resources_from_files(
            list(files), dry_run
        )
        if not resolved_resources_to_apply:
            return

    sf_server_client = ServiceFoundryServiceClient()

    resolved_resources_to_apply = apply_lib.resolve_resources_from_dependencies(
        resolved_resources_to_apply, sf_server_client
    )
    sorted_resources_to_apply = apply_lib.sort_resources(resolved_resources_to_apply)

    if resolved_resources_to_delete:
        resolved_resources_to_delete = apply_lib.resolve_resources_from_dependencies(
            resolved_resources_to_delete, sf_server_client
        )
    sorted_resources_to_delete = list(
        reversed(apply_lib.sort_resources(resolved_resources_to_delete))
    )

    _apply_and_delete_resources(
        sorted_resources_to_apply,
        sorted_resources_to_delete,
        sf_server_client,
        dry_run,
        show_diff,
        sync,
    )


def get_apply_command():
    return apply_command
