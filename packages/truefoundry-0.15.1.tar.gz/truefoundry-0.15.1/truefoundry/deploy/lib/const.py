from truefoundry.deploy.io.rich_output_callback import RichOutputCallBack

ENTITY_JSON_DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ"
RICH_OUTPUT_CALLBACK = RichOutputCallBack()
MCP_SERVER_INLINE_SPEC_SOURCE_TYPE = "inline"
MCP_SERVER_UPLOAD_SPEC_SOURCE_TYPE = "upload"
