"""Local ``agent_skill`` ``SKILL.md`` validation before apply. Align with
``mlfoundry-server`` ``mlflow.server.mlfoundry_artifacts.agent_skill_utils``."""

import re
from dataclasses import dataclass
from pathlib import Path

import yaml

from truefoundry.pydantic_v1 import BaseModel, ValidationError, constr

AGENT_SKILL_MD_FILENAME = "SKILL.md"
AGENT_SKILL_FM_DESCRIPTION_MAX_LENGTH = 1024
AGENT_SKILL_FM_NAME_MAX_LENGTH = 64

_SKILL_MD_FRONTMATTER = re.compile(
    r"^\ufeff?---\s*(?:\r\n|\n|\r)(.*?)(?:^|\r?\n)---\s*(?:\r?\n|$)(.*)\Z",
    re.DOTALL | re.MULTILINE,
)


class _AgentSkillMdFrontMatter(BaseModel):
    class Config:
        extra = "allow"

    name: constr(
        strip_whitespace=True,
        min_length=1,
        max_length=AGENT_SKILL_FM_NAME_MAX_LENGTH,
    )
    description: constr(
        strip_whitespace=True,
        min_length=1,
        max_length=AGENT_SKILL_FM_DESCRIPTION_MAX_LENGTH,
    )


@dataclass(frozen=True)
class AgentSkillMDContent:
    """Parsed ``SKILL.md``: file body and front-matter ``description``."""

    skill_md_text: str
    description: str


def validate_and_read_local_agent_skill(
    skill_dir: Path, skill_name: str
) -> AgentSkillMDContent:
    if not skill_dir.is_dir():
        raise ValueError(
            f"skill_dir '{skill_dir}' is not a directory for agent_skill manifest."
        )
    path = skill_dir / AGENT_SKILL_MD_FILENAME
    if not path.is_file():
        raise ValueError(
            f"Did not find '{AGENT_SKILL_MD_FILENAME}' in {skill_dir}. "
            f"Filename must be exactly '{AGENT_SKILL_MD_FILENAME}'."
        )

    text = path.read_text(encoding="utf-8").lstrip("\ufeff")
    m = _SKILL_MD_FRONTMATTER.match(text)
    if not m:
        raise ValueError(
            "SKILL.md must start with YAML front matter (a line `---`, then fields, then a closing `---`)."
        )
    try:
        loaded = yaml.safe_load(m.group(1))
    except yaml.YAMLError as exc:
        raise ValueError(f"Invalid YAML in SKILL.md front matter: {exc}") from exc
    try:
        fm = _AgentSkillMdFrontMatter.parse_obj(loaded)
    except ValidationError as exc:
        raise ValueError(f"Invalid SKILL.md front matter: {exc}") from exc
    if fm.name != skill_name:
        raise ValueError(
            f"SKILL.md front matter name {fm.name!r} must match manifest name {skill_name!r}."
        )
    return AgentSkillMDContent(skill_md_text=text, description=fm.description)
