import json
from collections import defaultdict, deque
from copy import deepcopy
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple, Union

import git as gitpython
import yaml

from truefoundry.cli.console import console
from truefoundry.deploy.lib.clients.servicefoundry_client import (
    ServiceFoundryServiceClient,
)
from truefoundry.deploy.lib.const import (
    MCP_SERVER_INLINE_SPEC_SOURCE_TYPE,
    MCP_SERVER_UPLOAD_SPEC_SOURCE_TYPE,
)
from truefoundry.deploy.lib.dao.agent_skill import handle_agent_skill_local_source
from truefoundry.deploy.lib.diff_utils import print_manifest_diff
from truefoundry.deploy.lib.messages import (
    PROMPT_APPLYING_MANIFEST_FOR_FILE,
    PROMPT_APPLYING_MANIFEST_FOR_RESOURCE,
)
from truefoundry.deploy.lib.model.entity import (
    ApplyResult,
    DependencyTreeResponse,
    File,
    GitChangedFiles,
    GitChangedYamlFiles,
    ManifestLike,
    Resource,
    ResourceIdentifier,
)
from truefoundry.deploy.v2.lib.deploy import (
    handle_if_local_source,
    is_component_with_local_source,
)
from truefoundry.deploy.v2.lib.deployable_patched_models import Application
from truefoundry.pydantic_v1 import ValidationError


class BaseManifestType(str, Enum):
    TEAM = "team"
    PROVIDER_ACCOUNT = "provider-account"
    ENVIRONMENT = "environment"
    CLUSTER = "cluster"
    ML_REPO = "ml-repo"
    WORKSPACE = "workspace"
    SERVICE = "service"
    JOB = "job"
    HELM = "helm"
    NOTEBOOK = "notebook"
    RSTUDIO = "rstudio"
    VOLUME = "volume"
    WORKFLOW = "workflow"
    ASYNC_SERVICE = "async-service"
    APPLICATION_SET = "application-set"
    SSH_SERVER = "ssh-server"
    SPARK_JOB = "spark-job"
    SECRET_GROUP = "secret-group"
    TRACING_PROJECT = "tracing-project"
    MCP_SERVER = "mcp-server"
    AGENT = "agent"
    AGENT_SKILL = "agent-skill"
    POLICY = "policy"
    ROLE = "role"
    VIRTUAL_ACCOUNT = "virtual-account"
    GATEWAY_GUARDRAILS_CONFIG = "gateway-guardrails-config"
    GATEWAY_RATE_LIMITING_CONFIG = "gateway-rate-limiting-config"
    GATEWAY_GLOBAL_SETTINGS = "gateway-global-settings"
    GATEWAY_FALLBACK_CONFIG = "gateway-fallback-config"
    GATEWAY_LOAD_BALANCING_CONFIG = "gateway-load-balancing-config"
    GATEWAY_BUDGET_CONFIG = "gateway-budget-config"
    GATEWAY_DATA_ACCESS_CONFIG = "gateway-data-access-config"
    GATEWAY_OTEL_CONFIG = "gateway-otel-config"
    GATEWAY_DATA_ROUTING_CONFIG = "gateway-data-routing-config"
    GATEWAY_INSTALLATION = "gateway-installation"
    SETTINGS = "settings"
    ALERT_CONFIG = "alert-config"


BASE_MANIFEST_TYPE_ORDER = [
    BaseManifestType.TEAM,
    BaseManifestType.PROVIDER_ACCOUNT,
    BaseManifestType.ENVIRONMENT,
    BaseManifestType.CLUSTER,
    BaseManifestType.ML_REPO,
    BaseManifestType.WORKSPACE,
    BaseManifestType.SERVICE,
    BaseManifestType.JOB,
    BaseManifestType.HELM,
    BaseManifestType.NOTEBOOK,
    BaseManifestType.RSTUDIO,
    BaseManifestType.VOLUME,
    BaseManifestType.WORKFLOW,
    BaseManifestType.ASYNC_SERVICE,
    BaseManifestType.APPLICATION_SET,
    BaseManifestType.SSH_SERVER,
    BaseManifestType.SPARK_JOB,
    BaseManifestType.SECRET_GROUP,
    BaseManifestType.TRACING_PROJECT,
    BaseManifestType.MCP_SERVER,
    BaseManifestType.AGENT_SKILL,
    BaseManifestType.AGENT,
    BaseManifestType.POLICY,
    BaseManifestType.ROLE,
    BaseManifestType.VIRTUAL_ACCOUNT,
    BaseManifestType.GATEWAY_GUARDRAILS_CONFIG,
    BaseManifestType.GATEWAY_RATE_LIMITING_CONFIG,
    BaseManifestType.GATEWAY_GLOBAL_SETTINGS,
    BaseManifestType.GATEWAY_FALLBACK_CONFIG,
    BaseManifestType.GATEWAY_LOAD_BALANCING_CONFIG,
    BaseManifestType.GATEWAY_BUDGET_CONFIG,
    BaseManifestType.GATEWAY_DATA_ACCESS_CONFIG,
    BaseManifestType.GATEWAY_OTEL_CONFIG,
    BaseManifestType.GATEWAY_DATA_ROUTING_CONFIG,
    BaseManifestType.GATEWAY_INSTALLATION,
    BaseManifestType.SETTINGS,
    BaseManifestType.ALERT_CONFIG,
]


class ManifestType(str, Enum):
    SERVICE = "service"
    ASYNC_SERVICE = "async-service"
    JOB = "job"
    MCP_SERVER_OPENAPI = "mcp-server/openapi"


VALID_MANIFEST_TYPES_FOR_LOCAL_SOURCE = [
    ManifestType.SERVICE,
    ManifestType.ASYNC_SERVICE,
    ManifestType.JOB,
]

_UNKNOWN_TYPE_PRIORITY = len(BASE_MANIFEST_TYPE_ORDER)


def _get_base_type(type_str: str) -> str:
    """Extract base type, e.g. 'provider-account/gcp' -> 'provider-account'."""
    return type_str.split("/")[0]


def _get_type_priority(type_str: str) -> int:
    base_type = _get_base_type(type_str)
    try:
        return BASE_MANIFEST_TYPE_ORDER.index(base_type)
    except ValueError:
        return _UNKNOWN_TYPE_PRIORITY


def get_type_and_name_from_manifest(
    manifest: Dict[str, Any],
) -> Optional[ManifestLike]:
    if manifest and isinstance(manifest.get("type"), str):
        type_str = manifest.get("type")
        # Fallback to type if name is not present in the manifest
        name_str = manifest.get("name") or type_str
        return ManifestLike(type=type_str, name=name_str)
    return None


def read_manifest_type_and_name(filepath: str) -> Optional[ManifestLike]:
    """Read the type and name fields from a manifest file."""
    try:
        manifest = get_manifest_from_file(filepath)
        return get_type_and_name_from_manifest(manifest)
    except Exception:
        pass
    return None


def collect_yaml_files(directory: str) -> List[str]:
    """Collect all .yaml and .yml files from a directory recursively."""
    dir_path = Path(directory).resolve()
    yaml_files: List[str] = []
    for ext in ("*.yaml", "*.yml"):
        yaml_files.extend(str(p) for p in dir_path.rglob(ext))
    return yaml_files


def sort_files_by_manifest_type(files: List[str]) -> List[str]:
    """Sort files by their manifest type according to dependency order."""

    def sort_key(filepath: str) -> Tuple[int, str]:
        manifest_type_and_name = read_manifest_type_and_name(filepath)
        if manifest_type_and_name is None:
            return (_UNKNOWN_TYPE_PRIORITY + 1, filepath)
        return (_get_type_priority(manifest_type_and_name.type), filepath)

    return sorted(files, key=sort_key)


def _sort_resources_by_dependency_order(
    resources: List[Resource],
) -> List[List[Resource]]:
    """
    Sort resources by their dependency order.
    We will perform a topological sort on the resources based on their dependencies.
    Each resource is processed only after all its dependencies are processed.
    Returns a list of waves, where each wave can be processed in parallel.
    """
    resource_map: Dict[Tuple[str, str], Resource] = {
        (r.type, r.name): r for r in resources
    }

    children: Dict[Tuple[str, str], List[Resource]] = defaultdict(list)
    in_degree: Dict[Tuple[str, str], int] = {(r.type, r.name): 0 for r in resources}

    for r in resources:
        r_key = (r.type, r.name)
        for dep in r.dependencies:
            dep_key = (dep.type, dep.name)
            if dep_key not in resource_map:
                continue
            children[dep_key].append(r)
            in_degree[r_key] += 1

    queue: deque[Tuple[str, str]] = deque(
        (r.type, r.name) for r in resources if in_degree[(r.type, r.name)] == 0
    )
    waves: List[List[Resource]] = []

    while queue:
        wave_keys = list(queue)
        waves.append([resource_map[k] for k in wave_keys])
        queue.clear()
        for k in wave_keys:
            for child in children[k]:
                child_key = (child.type, child.name)
                in_degree[child_key] -= 1
                if in_degree[child_key] == 0:
                    queue.append(child_key)

    return waves


def sort_resources(resources: List[Resource]) -> List[Resource]:
    if not resources:
        return []

    resources_by_dependency_order: List[List[Resource]] = (
        _sort_resources_by_dependency_order(resources)
    )

    sorted_resources: List[Resource] = []
    for wave in resources_by_dependency_order:
        sorted_wave = sorted(wave, key=lambda r: _get_type_priority(r.type))
        sorted_resources.extend(sorted_wave)

    return sorted_resources


def _open_git_repo(directory: str) -> gitpython.Repo:
    """Open a git repository, raising clear errors for common failure cases."""
    try:
        repo = gitpython.Repo(directory, search_parent_directories=True)
    except gitpython.InvalidGitRepositoryError:
        raise Exception(f"{directory} is not inside a git repository") from None
    except gitpython.NoSuchPathError:
        raise Exception(f"Directory {directory} does not exist") from None
    except gitpython.GitCommandNotFound:
        raise Exception("git is not installed or not found in PATH") from None

    if repo.working_tree_dir is None:
        raise Exception("Bare git repositories are not supported")
    return repo


def _get_changed_files(repo: gitpython.Repo, ref: str) -> GitChangedFiles:
    """Get all modified file paths (tracked + untracked), deleted file paths compared to a ref."""
    modified_files: List[File] = []
    deleted_files: List[File] = []

    try:
        for diff_item in repo.commit(ref).diff(None):
            file_path = diff_item.a_path or diff_item.b_path
            if diff_item.change_type == "D":
                blob_text = ""
                if file_path and diff_item.a_blob:
                    try:
                        blob_text = diff_item.a_blob.data_stream.read().decode(
                            "utf-8", errors="replace"
                        )
                    except Exception:
                        pass
                deleted_files.append(File(path=file_path, content=blob_text))
            else:
                modified_files.append(File(path=file_path))
    except Exception as e:
        raise Exception(f"Failed to compute diff against '{ref}': {e}") from None

    for untracked_file in repo.untracked_files:
        modified_files.append(File(path=untracked_file))
    return GitChangedFiles(modified=modified_files, deleted=deleted_files)


def _get_git_changed_yaml_file_path_if_valid(
    f: str, repo_root: Path, dir_path: Path
) -> Union[Path, None]:
    if not f.endswith((".yaml", ".yml")):
        return None
    abs_path = (repo_root / f).resolve()
    try:
        abs_path.relative_to(dir_path)
    except ValueError:
        return None
    return abs_path


def get_git_changed_yaml_files(
    directory: str, ref: Optional[str] = None
) -> GitChangedYamlFiles:
    """Get YAML files changed in git compared to ref (default: HEAD).

    Includes both tracked changes and untracked (new) files, filtered to
    only those within the given directory.
    """
    dir_path = Path(directory).resolve()
    ref = ref or "HEAD"

    repo = _open_git_repo(str(dir_path))
    repo_root = Path(repo.working_tree_dir)
    changed_files_info = _get_changed_files(repo, ref)

    git_modified_yaml_files: List[File] = []
    for modified_file in changed_files_info.modified:
        abs_path = _get_git_changed_yaml_file_path_if_valid(
            modified_file.path, repo_root, dir_path
        )
        if abs_path and abs_path.is_file():
            git_modified_yaml_files.append(File(path=str(abs_path), content=None))

    git_deleted_yaml_files: List[File] = []
    for deleted_file in changed_files_info.deleted:
        abs_path = _get_git_changed_yaml_file_path_if_valid(
            deleted_file.path, repo_root, dir_path
        )
        if abs_path:
            git_deleted_yaml_files.append(
                File(path=str(abs_path), content=deleted_file.content)
            )

    return GitChangedYamlFiles(
        modified=git_modified_yaml_files,
        deleted=git_deleted_yaml_files,
    )


def _apply_manifest(
    manifest: Dict[str, Any],
    client: Optional[ServiceFoundryServiceClient] = None,
    filename: Optional[str] = None,
    index: Optional[int] = None,
    dry_run: bool = False,
    show_diff: bool = False,
) -> ApplyResult:
    client = client or ServiceFoundryServiceClient()

    file_metadata = ""
    if index is not None:
        file_metadata += f" at index {index}"
    if filename:
        file_metadata += f" from file {filename}"

    try:
        parsed_manifest = ManifestLike.parse_obj(manifest)
    except ValidationError as ex:
        return ApplyResult(
            success=False,
            message=f"Failed to apply manifest{file_metadata}. Error: {ex}",
        )

    prefix = "[Dry Run] " if dry_run else ""
    suffix = " (No changes were applied)" if dry_run else ""

    manifest_name = ""
    if parsed_manifest.name:
        manifest_name = f" {parsed_manifest.name}"

    try:
        api_response = client.apply(
            parsed_manifest.dict(exclude_unset=True, exclude_none=True), dry_run
        )

        # Show diff for dry runs only when show_diff is enabled
        if dry_run and show_diff and api_response.existing_manifest:
            if parsed_manifest.name:
                diff_manifest_name = f"{parsed_manifest.name} ({parsed_manifest.type})"
            else:
                diff_manifest_name = f"manifest ({parsed_manifest.type})"
            print_manifest_diff(
                existing_manifest=api_response.existing_manifest,
                new_manifest=parsed_manifest.dict(
                    exclude_unset=True, exclude_none=True
                ),
                manifest_name=diff_manifest_name,
                console=console,
            )

        return ApplyResult(
            success=True,
            message=(
                f"{prefix}Successfully configured manifest{manifest_name} of type {parsed_manifest.type}.{suffix}"
            ),
        )
    except Exception as ex:
        return ApplyResult(
            success=False,
            message=(
                f"{prefix}Failed to apply manifest{manifest_name} of type {parsed_manifest.type}. Error: {ex}.{suffix}"
            ),
        )


def apply_manifest(
    manifest: Dict[str, Any],
    client: Optional[ServiceFoundryServiceClient] = None,
    dry_run: bool = False,
    show_diff: bool = False,
) -> ApplyResult:
    return _apply_manifest(
        manifest=manifest, client=client, dry_run=dry_run, show_diff=show_diff
    )


def get_manifest_from_file(filepath: str) -> Optional[Dict[str, Any]]:
    try:
        with open(filepath, "r") as f:
            manifest = yaml.safe_load(f)
            if isinstance(manifest, dict):
                return manifest
    except Exception:
        pass
    return None


def apply_manifest_file(
    filepath: str,
    client: Optional[ServiceFoundryServiceClient] = None,
    dry_run: bool = False,
    show_diff: bool = False,
) -> Iterator[ApplyResult]:
    client = client or ServiceFoundryServiceClient()
    filename = Path(filepath).name
    try:
        with open(filepath, "r") as f:
            manifests_it = list(yaml.safe_load_all(f))
    except Exception as ex:
        yield ApplyResult(
            success=False,
            message=f"Failed to read file {filepath} as a valid YAML file. Error: {ex}",
        )
    else:
        prefix = "[Dry Run] " if dry_run else ""
        for index, manifest in enumerate(manifests_it):
            if not isinstance(manifest, dict):
                yield ApplyResult(
                    success=False,
                    message=f"{prefix}Failed to apply manifest at index {index} from file {filename}. Error: A manifest must be a dict, got type {type(manifest)}",
                )
                continue

            yield _apply_manifest(
                manifest=manifest,
                client=client,
                filename=filename,
                index=index,
                dry_run=dry_run,
                show_diff=show_diff,
            )


def apply_manifest_files(
    files: List[str],
    sf_server_client: Optional[ServiceFoundryServiceClient] = None,
    dry_run: bool = False,
    show_diff: bool = False,
) -> List[ApplyResult]:
    apply_results: List[ApplyResult] = []
    for file in files:
        with console.status(
            PROMPT_APPLYING_MANIFEST_FOR_FILE.format(file), spinner="dots"
        ):
            for apply_result in apply_manifest_file(
                file, sf_server_client, dry_run, show_diff
            ):
                if apply_result.success:
                    console.print(f"[green]\u2714 {apply_result.message}[/]")
                else:
                    console.print(f"[red]\u2718 {apply_result.message}[/]")

                apply_results.append(apply_result)
    return apply_results


def _handle_resource_with_dependencies(resource: Resource, dry_run: bool) -> Resource:
    if resource.error_message or resource.skipped_message:
        return resource

    if not dry_run:
        return resource

    if not resource.dependencies:
        return resource

    return Resource(
        type=resource.type,
        name=resource.name,
        manifest=resource.manifest,
        file_path=resource.file_path,
        dependencies=resource.dependencies,
        error_message=resource.error_message,
        skipped_message=f"[Dry Run] Skipped manifest {resource.name} of type {resource.type} because it has dependencies.",
    )


def apply_manifest_resources(
    resources: List[Resource],
    sf_server_client: ServiceFoundryServiceClient,
    dry_run: bool = False,
    show_diff: bool = False,
) -> List[ApplyResult]:
    apply_results: List[ApplyResult] = []
    for resource in resources:
        updated_resource = _handle_resource_with_dependencies(resource, dry_run)
        updated_resource = _handle_application_if_local_source(
            updated_resource, dry_run
        )
        updated_resource = _handle_mcp_server_openapi_spec(
            updated_resource, dry_run, sf_server_client
        )
        updated_resource = handle_agent_skill_local_source(updated_resource, dry_run)

        if updated_resource.error_message:
            message = updated_resource.error_message
            console.print(f"[red]\u2718 {message}[/]")
            apply_results.append(
                ApplyResult(
                    success=False,
                    message=message,
                )
            )
            continue

        if updated_resource.skipped_message:
            message = updated_resource.skipped_message
            console.print(f"[yellow]\u26a0 {message}[/]")
            apply_results.append(
                ApplyResult(
                    success=True,
                    message=message,
                )
            )
            continue

        filename = Path(updated_resource.file_path).name
        with console.status(
            PROMPT_APPLYING_MANIFEST_FOR_RESOURCE.format(
                updated_resource.type, updated_resource.name, updated_resource.file_path
            ),
            spinner="dots",
        ):
            apply_result = _apply_manifest(
                manifest=dict(updated_resource.manifest),
                client=sf_server_client,
                filename=filename,
                dry_run=dry_run,
                show_diff=show_diff,
            )
            if apply_result.success:
                console.print(f"[green]\u2714 {apply_result.message}[/]")
            else:
                console.print(f"[red]\u2718 {apply_result.message}[/]")
            apply_results.append(apply_result)
    return apply_results


def _get_type_name_key(type: str, name: str) -> str:
    return f"{type}:{name}"


def _get_resolved_dependencies(
    dependencies: List[ResourceIdentifier],
    type_prefix_and_name_to_resource: Dict[str, Resource],
) -> List[ResourceIdentifier]:
    resolved_dependencies: List[ResourceIdentifier] = []
    for dependency in dependencies:
        # dependencies is assumed to have type prefix
        type_prefix = _get_base_type(dependency.type)
        type_prefix_and_name_key = _get_type_name_key(type_prefix, dependency.name)
        if type_prefix_and_name_key in type_prefix_and_name_to_resource:
            resource = type_prefix_and_name_to_resource[type_prefix_and_name_key]
            resolved_dependencies.append(
                ResourceIdentifier(type=resource.type, name=resource.name)
            )
    return resolved_dependencies


def _is_inline_openapi_spec(manifest: Dict[str, Any]) -> bool:
    openapi_spec_source = manifest.get("openapi_spec_source", {})
    if not openapi_spec_source:
        return False

    return openapi_spec_source.get("type") == MCP_SERVER_INLINE_SPEC_SOURCE_TYPE


def _get_sanitized_manifests(given_resources: List[Resource]) -> List[Dict[str, Any]]:
    sanitized_manifests: List[Dict[str, Any]] = []

    for resource in given_resources:
        updated_manifest_dict: Dict[str, Any] = deepcopy(dict(resource.manifest))
        if resource.type == ManifestType.MCP_SERVER_OPENAPI and _is_inline_openapi_spec(
            updated_manifest_dict
        ):
            updated_manifest_dict.pop("openapi_spec_source", None)

        sanitized_manifests.append(updated_manifest_dict)

    return sanitized_manifests


def resolve_resources_from_dependencies(
    given_resources: List[Resource], client: ServiceFoundryServiceClient
) -> List[Resource]:
    # On the server side, we use (manifest_type_prefix, name) pair to unique identify a resource
    # This data is stored in the dependencies list

    # Map each <type_prefix:name> pair to the given resource
    type_prefix_and_name_to_resource: Dict[str, Resource] = {}
    # Map each <type:name> pair to the given resource
    type_and_name_to_resource: Dict[str, Resource] = {}

    for resource in given_resources:
        type_prefix = _get_base_type(resource.type)
        type_prefix_and_name_to_resource[
            _get_type_name_key(type_prefix, resource.name)
        ] = resource

        type_and_name_to_resource[_get_type_name_key(resource.type, resource.name)] = (
            resource
        )

    resolved_resources: List[Resource] = []

    sanitized_manifests = _get_sanitized_manifests(given_resources)

    dependency_tree_response: Optional[DependencyTreeResponse] = None
    try:
        dependency_tree_response = client.resolve_dependency_tree(sanitized_manifests)
    except Exception:
        dependency_tree_response = None

    if dependency_tree_response is not None:
        for resource in dependency_tree_response.data:
            type_name_key = _get_type_name_key(resource.type, resource.name)
            given_resource = type_and_name_to_resource.get(type_name_key)

            if given_resource is None:
                continue

            resolved_dependencies = _get_resolved_dependencies(
                resource.dependencies, type_prefix_and_name_to_resource
            )

            resolved_resource = Resource(
                type=given_resource.type,
                name=given_resource.name,
                manifest=given_resource.manifest,
                file_path=given_resource.file_path,
                dependencies=resolved_dependencies,
            )
            resolved_resources.append(resolved_resource)
    else:
        resolved_resources = given_resources

    return resolved_resources


def _handle_application_if_local_source(resource: Resource, dry_run: bool) -> Resource:
    if resource.type not in VALID_MANIFEST_TYPES_FOR_LOCAL_SOURCE:
        return resource

    if resource.error_message or resource.skipped_message:
        return resource

    resource_metadata_str = f"manifest {resource.name} of type {resource.type}"

    try:
        application = Application.parse_obj(dict(resource.manifest))
    except ValidationError as ex:
        return Resource(
            type=resource.type,
            name=resource.name,
            manifest=resource.manifest,
            file_path=resource.file_path,
            dependencies=resource.dependencies,
            error_message=(f"Failed to parse {resource_metadata_str}: {ex}"),
        )

    component = application.__root__

    if not is_component_with_local_source(component):
        return resource

    if dry_run:
        skipped_message = (
            f"Skipped {resource_metadata_str} because it has a local build source."
        )
        return Resource(
            type=resource.type,
            name=resource.name,
            manifest=resource.manifest,
            file_path=resource.file_path,
            dependencies=resource.dependencies,
            skipped_message=skipped_message,
        )

    message = f"Processing local build for {resource_metadata_str}"
    console.print(f"[yellow]\u2139 {message}[/]")

    error_message = None
    workspace_fqn = getattr(component, "workspace_fqn", None)
    if workspace_fqn is None:
        error_message = (
            f"Failed to apply {resource_metadata_str} because workspace_fqn is missing"
        )
        updated_component = component
    else:
        try:
            updated_component = handle_if_local_source(
                component=component, workspace_fqn=workspace_fqn
            )
        except Exception as ex:
            error_message = (
                f"Failed to process local build for {resource_metadata_str}: {ex}"
            )
            updated_component = component

    return Resource(
        type=resource.type,
        name=resource.name,
        manifest=updated_component.dict(exclude_none=True),
        file_path=resource.file_path,
        dependencies=resource.dependencies,
        error_message=error_message,
    )


def _openapi_inline_spec_to_bytes(spec: Any) -> bytes:
    if isinstance(spec, dict):
        return json.dumps(spec, separators=(",", ":"), ensure_ascii=False).encode(
            "utf-8"
        )
    if isinstance(spec, str):
        return spec.encode("utf-8")
    if isinstance(spec, (bytes, bytearray)):
        return bytes(spec)
    raise TypeError(f"Unsupported openapi_spec type: {type(spec)!r}")


def _is_json(input_val: Any) -> bool:
    if isinstance(input_val, (dict, list)):
        return True
    if isinstance(input_val, str):
        try:
            json.loads(input_val)
            return True
        except Exception:
            return False
    return False


def _handle_mcp_server_openapi_spec(
    resource: Resource, dry_run: bool, client: ServiceFoundryServiceClient
) -> Resource:
    if resource.type != ManifestType.MCP_SERVER_OPENAPI:
        return resource

    if resource.error_message or resource.skipped_message:
        return resource

    manifest_dict = dict(resource.manifest)
    if not _is_inline_openapi_spec(manifest_dict):
        return resource

    resource_metadata_str = f"manifest {resource.name} of type {resource.type}"

    openapi_spec = manifest_dict.get("openapi_spec_source", {}).get("openapi_spec")
    if openapi_spec is None:
        return Resource(
            type=resource.type,
            name=resource.name,
            manifest=resource.manifest,
            file_path=resource.file_path,
            dependencies=resource.dependencies,
            error_message=(f"{resource_metadata_str} has no openapi_spec"),
        )

    if dry_run:
        return Resource(
            type=resource.type,
            name=resource.name,
            manifest=resource.manifest,
            file_path=resource.file_path,
            dependencies=resource.dependencies,
            skipped_message=(
                f"[Dry Run] Skipped {resource_metadata_str} because it has inline OpenAPI spec."
            ),
        )

    try:
        payload = _openapi_inline_spec_to_bytes(openapi_spec)
        document_extension = "json" if _is_json(openapi_spec) else "yaml"
        mcp_server_name = resource.name
        spec_uri = client.upload_openapi_spec_via_store(
            payload, document_extension, mcp_server_name
        )
    except Exception as ex:
        return Resource(
            type=resource.type,
            name=resource.name,
            manifest=resource.manifest,
            file_path=resource.file_path,
            dependencies=resource.dependencies,
            error_message=(
                f"Failed to upload OpenAPI spec for {resource_metadata_str}: {ex}"
            ),
        )

    manifest_dict["openapi_spec_source"] = {
        "type": MCP_SERVER_UPLOAD_SPEC_SOURCE_TYPE,
        "url": spec_uri,
    }

    return Resource(
        type=resource.type,
        name=resource.name,
        manifest=manifest_dict,
        file_path=resource.file_path,
        dependencies=resource.dependencies,
    )
