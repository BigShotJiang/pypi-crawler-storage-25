"""Download committed agent-skill blobs by artifact version FQN (ML Foundry client)."""

from pathlib import Path
from typing import Optional

from truefoundry.ml import get_client


def run_skill_download(
    fqn: str,
    skill_dir: Path,
    overwrite: bool,
    progress: Optional[bool],
) -> str:
    """Download artifact files under ``skill_dir`` (mkdir if missing)."""
    skill_dir.mkdir(parents=True, exist_ok=True)
    client = get_client()
    artifact_version = client.get_artifact_version_by_fqn(fqn=fqn)
    return artifact_version.download(
        path=str(skill_dir), overwrite=overwrite, progress=progress
    )
