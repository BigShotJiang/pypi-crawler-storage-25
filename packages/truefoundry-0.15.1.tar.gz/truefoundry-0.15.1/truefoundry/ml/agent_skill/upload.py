from pathlib import Path

from truefoundry.deploy.lib.dao.agent_skill_upload import upload_agent_skill


def run_skill_upload(name: str, repository: str, skill_dir: Path) -> None:
    """Run agent-skill upload via deploy apply."""
    upload_agent_skill(name=name, repository=repository, skill_dir=skill_dir)
