# This file is copied from mlflow/exceptions.py
# This file needs to be independent of mlflow/exceptions.py to be used in openapi-client-autogen
import enum


class ErrorCode(enum.IntEnum):
    INTERNAL_ERROR = 1
    TEMPORARILY_UNAVAILABLE = 2
    IO_ERROR = 3
    BAD_REQUEST = 4
    INVALID_PARAMETER_VALUE = 1000
    ENDPOINT_NOT_FOUND = 1001
    MALFORMED_REQUEST = 1002
    INVALID_STATE = 1003
    PERMISSION_DENIED = 1004
    FEATURE_DISABLED = 1005
    CUSTOMER_UNAUTHORIZED = 1006
    REQUEST_LIMIT_EXCEEDED = 1007
    UNAUTHORIZED = 1008
    FAILED_DEPENDENCY = 1009
    INVALID_STATE_TRANSITION = 2001
    COULD_NOT_ACQUIRE_LOCK = 2002
    RESOURCE_ALREADY_EXISTS = 3001
    RESOURCE_DOES_NOT_EXIST = 3002
    QUOTA_EXCEEDED = 4001
    MAX_BLOCK_SIZE_EXCEEDED = 4002
    MAX_READ_SIZE_EXCEEDED = 4003
    DRY_RUN_FAILED = 5001
    RESOURCE_LIMIT_EXCEEDED = 5002
    DIRECTORY_NOT_EMPTY = 6001
    DIRECTORY_PROTECTED = 6002
    MAX_NOTEBOOK_SIZE_EXCEEDED = 6003


class MlflowException(Exception):
    """
    Generic exception thrown to surface failure information about external-facing operations.
    The error message associated with this exception may be exposed to clients in HTTP responses
    for debugging purposes. If the error text is sensitive, raise a generic `Exception` object
    instead.
    """

    def __init__(
        self,
        message: str,
        *,
        error_code: ErrorCode = ErrorCode.INTERNAL_ERROR,
        **kwargs,
    ) -> None:
        """
        :param message: The message describing the error that occured. This will be included in the
                        exception's serialized JSON representation.
        :param error_code: An appropriate error code for the error that occured; it will be included
                           in the exception's serialized JSON representation. This should be one of
                           the codes listed in the `ErrorCode` enum.
        :param kwargs: Additional key-value pairs to include in the serialized JSON representation
                       of the MlflowException.
        """
        try:
            self.error_code = ErrorCode(error_code)
        except (ValueError, TypeError):
            self.error_code = ErrorCode.INTERNAL_ERROR
        self.message = str(message)
        self.json_kwargs = kwargs
        super().__init__(message)
