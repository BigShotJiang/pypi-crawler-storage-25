"""Top-level Click group for ``tfy upload`` (e.g. ``upload skill``)."""

from pathlib import Path

import rich_click as click

from truefoundry.cli.const import COMMAND_CLS, GROUP_CLS
from truefoundry.cli.util import handle_exception_wrapper
from truefoundry.ml.agent_skill import run_skill_upload


@click.group(
    name="upload",
    cls=GROUP_CLS,
    help="Upload local agent skills to TrueFoundry.",
)
def upload_cli(): ...


@click.command(
    name="skill",
    cls=COMMAND_CLS,
    short_help="Upload a local skill directory as a new agent skill version",
)
@click.option(
    "--name",
    required=True,
    type=str,
    help="Name for the skill (must match the name in SKILL.md front matter)",
)
@click.option(
    "--repository",
    required=True,
    type=str,
    help="Repository where the skill version will be logged",
)
@click.option(
    "--dir",
    "-d",
    "directory",
    type=click.Path(file_okay=False, dir_okay=True, exists=True),
    default=".",
    show_default=True,
    help="Local skill root directory (must contain SKILL.md)",
)
@handle_exception_wrapper
def upload_skill(name: str, repository: str, directory: str):
    """Create a new agent skill version from skill directory."""
    dest = Path(directory).expanduser().resolve()
    try:
        run_skill_upload(name=name, repository=repository, skill_dir=dest)
    except (RuntimeError, ValueError) as exc:
        raise click.ClickException(str(exc)) from None
    click.echo("Uploaded skill version successfully.")


def get_upload_command():
    """Return the Click group bound to the ``upload`` command name."""
    upload_cli.add_command(upload_skill)
    return upload_cli
