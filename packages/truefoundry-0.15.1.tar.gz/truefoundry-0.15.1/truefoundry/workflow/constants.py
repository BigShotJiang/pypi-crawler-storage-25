"""Constants used by workflow tasks (e.g. Databricks OIDC and run-now)."""

from pathlib import Path

# Kubernetes default mount path for the service account token (OIDC).
SERVICE_ACCOUNT_TOKEN_PATH = Path("/var/run/secrets/kubernetes.io/serviceaccount/token")

# Databricks run-now API: idempotency_token max length; use only safe characters.
IDEMPOTENCY_TOKEN_MAX_LEN = 64
IDEMPOTENCY_TOKEN_ALLOWED_CHARS = set(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-"
)
