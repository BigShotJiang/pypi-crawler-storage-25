"""Configuration file parser for mcpfang.yaml."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class ProviderConfig:
    name: str = "anthropic"
    model: str = "claude-sonnet-4-20250514"
    api_key: str | None = None
    base_url: str | None = None
    max_tokens: int = 4096
    temperature: float = 0.4
    timeout: int = 120


@dataclass
class TargetConfig:
    endpoint: str = ""
    transport: str = "sse"


@dataclass
class ContextConfig:
    domain: str = ""
    sensitive_data: list[str] = field(default_factory=list)
    business_rules: list[str] = field(default_factory=list)
    compliance: list[str] = field(default_factory=list)


@dataclass
class ScanConfig:
    playbooks: list[str] = field(default_factory=lambda: [
        "command_injection",
        "path_traversal",
        "tool_poisoning",
        "auth_bypass",
        "input_validation",
        "resource_probing",
    ])
    max_steps_per_playbook: int = 10
    timeout_seconds: int = 300
    llm_delay_ms: int = 500       # delay between LLM API calls (ms)
    mcp_delay_ms: int = 100       # delay between MCP tool calls (ms)
    max_retries: int = 3          # max retries on 429/5xx
    retry_base_delay_ms: int = 2000  # base delay for exponential backoff (ms)


@dataclass
class OutputConfig:
    format: str = "table"
    file: str | None = None
    severity_threshold: str = "low"
    ci_exit_code: bool = True


@dataclass
class McpFangConfig:
    provider: ProviderConfig = field(default_factory=ProviderConfig)
    target: TargetConfig = field(default_factory=TargetConfig)
    context: ContextConfig = field(default_factory=ContextConfig)
    scan: ScanConfig = field(default_factory=ScanConfig)
    output: OutputConfig = field(default_factory=OutputConfig)


def load_config(path: Path | None = None) -> McpFangConfig:
    """Load config from mcpfang.yaml, falling back to defaults."""
    if path is None:
        path = Path("mcpfang.yaml")

    if not path.exists():
        return McpFangConfig()

    with open(path) as f:
        raw = yaml.safe_load(f) or {}

    cfg = McpFangConfig()

    if provider := raw.get("provider"):
        cfg.provider = ProviderConfig(
            name=provider.get("name", cfg.provider.name),
            model=provider.get("model", cfg.provider.model),
            api_key=provider.get("api_key"),
            base_url=provider.get("base_url"),
            max_tokens=provider.get("max_tokens", cfg.provider.max_tokens),
            temperature=provider.get("temperature", cfg.provider.temperature),
            timeout=provider.get("timeout", cfg.provider.timeout),
        )

    if target := raw.get("target"):
        cfg.target = TargetConfig(
            endpoint=target.get("endpoint", ""),
            transport=target.get("transport", "sse"),
        )

    if context := raw.get("context"):
        cfg.context = ContextConfig(
            domain=context.get("domain", ""),
            sensitive_data=context.get("sensitive_data", []),
            business_rules=context.get("business_rules", []),
            compliance=context.get("compliance", []),
        )

    if scan := raw.get("scan"):
        cfg.scan = ScanConfig(
            playbooks=scan.get("playbooks", cfg.scan.playbooks),
            max_steps_per_playbook=scan.get("max_steps_per_playbook", cfg.scan.max_steps_per_playbook),
            timeout_seconds=scan.get("timeout_seconds", cfg.scan.timeout_seconds),
            llm_delay_ms=scan.get("llm_delay_ms", cfg.scan.llm_delay_ms),
            mcp_delay_ms=scan.get("mcp_delay_ms", cfg.scan.mcp_delay_ms),
            max_retries=scan.get("max_retries", cfg.scan.max_retries),
            retry_base_delay_ms=scan.get("retry_base_delay_ms", cfg.scan.retry_base_delay_ms),
        )

    if output := raw.get("output"):
        cfg.output = OutputConfig(
            format=output.get("format", cfg.output.format),
            file=output.get("file"),
            severity_threshold=output.get("severity_threshold", cfg.output.severity_threshold),
            ci_exit_code=output.get("ci_exit_code", cfg.output.ci_exit_code),
        )

    return cfg
