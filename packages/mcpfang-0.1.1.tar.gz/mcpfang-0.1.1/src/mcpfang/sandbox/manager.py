"""Docker sandbox manager for isolated MCP server execution.

Provides an isolated container environment so adversarial testing
doesn't affect the host system.
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import AsyncIterator

from rich.console import Console

console = Console()


@dataclass
class SandboxConfig:
    """Configuration for sandbox container."""

    image: str = "python:3.12-slim"
    network: str = "none"  # Isolated by default
    memory_limit: str = "512m"
    cpu_limit: float = 1.0
    timeout_seconds: int = 300
    read_only_root: bool = True


class SandboxManager:
    """Manages Docker containers for isolated MCP server testing.

    Requires Docker SDK: pip install docker
    """

    def __init__(self, config: SandboxConfig | None = None) -> None:
        self.config = config or SandboxConfig()
        self._client = None

    def _get_client(self):
        """Lazy-load Docker client."""
        if self._client is None:
            try:
                import docker
                self._client = docker.from_env()
            except ImportError:
                raise RuntimeError(
                    "Docker SDK not installed. Run: pip install docker\n"
                    "Or disable sandbox with --no-sandbox"
                )
            except Exception as e:
                raise RuntimeError(
                    f"Cannot connect to Docker daemon: {e}\n"
                    "Ensure Docker is running, or disable sandbox with --no-sandbox"
                )
        return self._client

    @asynccontextmanager
    async def create_sandbox(self) -> AsyncIterator[str]:
        """Create and manage an isolated Docker container.

        Yields the container ID. Container is automatically cleaned up on exit.
        """
        client = self._get_client()

        container = await asyncio.to_thread(
            client.containers.run,
            image=self.config.image,
            detach=True,
            network_mode=self.config.network,
            mem_limit=self.config.memory_limit,
            nano_cpus=int(self.config.cpu_limit * 1e9),
            read_only=self.config.read_only_root,
            tmpfs={"/tmp": "size=100m"},
            remove=False,
            command="sleep infinity",
        )

        try:
            console.print(f"  ▸ Sandbox created ({container.short_id})", end="")
            console.print("               [green]✓[/green]")
            yield container.id
        finally:
            try:
                await asyncio.to_thread(container.stop, timeout=5)
                await asyncio.to_thread(container.remove, force=True)
                console.print(f"  ▸ Sandbox cleaned up ({container.short_id})")
            except Exception:
                pass  # Best effort cleanup

    async def exec_in_sandbox(self, container_id: str, command: str) -> str:
        """Execute a command in the sandbox container."""
        client = self._get_client()
        container = client.containers.get(container_id)

        result = await asyncio.to_thread(
            container.exec_run, command, demux=True
        )

        stdout = result.output[0].decode() if result.output[0] else ""
        stderr = result.output[1].decode() if result.output[1] else ""

        if result.exit_code != 0:
            return f"[EXIT {result.exit_code}] {stderr or stdout}"
        return stdout

    async def is_available(self) -> bool:
        """Check if Docker is available and running."""
        try:
            client = self._get_client()
            await asyncio.to_thread(client.ping)
            return True
        except Exception:
            return False
