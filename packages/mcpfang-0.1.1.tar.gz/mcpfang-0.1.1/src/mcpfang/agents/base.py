"""Base class for adversarial agents."""

from __future__ import annotations

import json
from abc import ABC, abstractmethod

from mcpfang.agents.context import AttackContext
from mcpfang.providers.base import LLMProvider
from mcpfang.reporting.models import Finding


class BasePlaybook(ABC):
    """Abstract base for attack playbooks.

    Each playbook defines a specific attack strategy (e.g., command injection)
    with its own system prompt, attack steps, and finding parser.
    """

    name: str
    category: str
    severity_default: str
    cwe_ids: list[str] = []
    description: str = ""

    @abstractmethod
    def get_system_prompt(self, context: AttackContext) -> str:
        """Build the system prompt for the adversarial agent."""
        ...

    @abstractmethod
    def get_initial_message(self, context: AttackContext) -> str:
        """Build the initial user message to start the attack."""
        ...

    @abstractmethod
    def parse_findings(self, agent_output: str) -> list[Finding]:
        """Parse structured findings from agent output."""
        ...

    def get_finding_id_prefix(self) -> str:
        """Return the prefix for finding IDs (e.g., 'INJ' for injection)."""
        return self.name[:3].upper()
