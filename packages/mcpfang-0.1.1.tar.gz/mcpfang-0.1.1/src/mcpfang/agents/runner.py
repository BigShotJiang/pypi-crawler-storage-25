"""Playbook execution engine — runs adversarial agents against MCP servers."""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any

from mcp import ClientSession
from rich.console import Console
from rich.panel import Panel

from mcpfang.agents.base import BasePlaybook
from mcpfang.agents.context import AttackContext
from mcpfang.discovery.client import MCPClient
from mcpfang.providers.base import LLMProvider
from mcpfang.reporting.models import Finding, PlaybookResult, TokenUsage, ToolInteraction, DiscoveryResult

console = Console()

TOOL_CALL_INSTRUCTION = """
When you want to call an MCP tool, respond with a JSON block:
```tool_call
{"tool": "tool_name", "arguments": {"param": "value"}}
```

When you want to read an MCP resource, respond with:
```resource_read
{"uri": "resource://path"}
```

You may include MULTIPLE tool_call and resource_read blocks in one response.
After receiving the results, analyze them and decide your next action.

## Critical Rule: Test EVERY Tool

You MUST test every tool available on the server at least once. Do not skip any tool, \
especially write, delete, modify, or administrative operations. Use safe test data \
(e.g. write to /tmp, delete a test file you created) but DO test them.

If a tool accepts file paths, try path traversal. If it writes files, test it. \
If it deletes files, test it. Many critical vulnerabilities are in write/delete tools \
that scanners skip because they only test read operations.

## Creative Attack Strategy

The attack patterns in your system prompt are EXAMPLES, not an exhaustive list.
You are an expert security researcher — think creatively:
- Analyze each tool's parameters and PURPOSE to identify unique attack vectors
- Chain tools together: use one tool's output as another's input
- Try unexpected input types: very long strings, special chars, format strings, null bytes
- Look for information in error messages — they often leak internal paths, versions, configs
- If a tool mentions files/paths, try traversal. If it mentions users, try IDOR.
- Consider the server's DOMAIN: what data would be most valuable to exfiltrate?
- After each response, ask yourself: "What did I learn? How can I use this for the next attack?"

Do NOT just run through a checklist. Adapt your strategy based on what each response reveals.

## Reporting

When you have completed your analysis, provide your findings in this format:
```findings
[
  {
    "title": "Short vulnerability title",
    "description": "Detailed description of the vulnerability, what you observed, and its security impact",
    "severity": "critical|high|medium|low|info",
    "tool_name": "which tool was affected",
    "proof_of_concept": "exact input that triggered the issue and what the tool returned",
    "remediation": "how to fix it",
    "cwe_ids": ["CWE-XX"]
  }
]
```

If you find no vulnerabilities, respond with:
```findings
[]
```
"""


async def run_playbook(
    playbook: BasePlaybook,
    context: AttackContext,
    provider: LLMProvider,
    mcp_client: MCPClient,
    verbose: bool = False,
) -> PlaybookResult:
    """Execute a single playbook against the target MCP server.

    The agent iterates: LLM generates tool calls → we execute them on the MCP
    server → feed results back → LLM analyzes and continues or reports findings.
    """
    start = time.monotonic()
    result = PlaybookResult(playbook_name=playbook.name)

    system_prompt = playbook.get_system_prompt(context) + "\n\n" + TOOL_CALL_INSTRUCTION
    initial_message = playbook.get_initial_message(context)

    messages: list[dict[str, str]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": initial_message},
    ]

    # Verbose: show tools + system prompt at start
    if verbose:
        console.print()
        # Show domain context if available
        domain_section = ""
        if context.domain_report:
            domain_section = (
                f"\n\n[bold]Domain context:[/bold] {context.domain_report.server_type} — "
                f"{context.domain_report.server_purpose}\n"
            )
        console.print(Panel(
            f"[bold]Target tools:[/bold]\n"
            + "\n".join(f"  • {t.name}: {t.description[:80]}" for t in context.discovery.tools)
            + domain_section
            + f"\n\n[bold]System prompt[/bold] ({len(system_prompt)} chars):\n"
            + f"[dim]{system_prompt[:1500]}{'...' if len(system_prompt) > 1500 else ''}[/dim]",
            title=f"{playbook.name.replace('_', ' ').title()} — {', '.join(playbook.cwe_ids)}",
            border_style="cyan",
        ))

    # Per-playbook timeout: 60s per max_step, capped at 10 minutes
    playbook_timeout = min(context.max_steps * 60, 600)

    # Collect all tool interactions during this playbook run
    all_interactions: list[ToolInteraction] = []
    playbook_tokens = TokenUsage()

    try:
        async with asyncio.timeout(playbook_timeout):
            async with mcp_client.connect() as session:
                for step in range(context.max_steps):
                    if verbose:
                        console.print(f"\n      [dim]── Step {step + 1}/{context.max_steps} ──[/dim]")
                        console.print(f"      [dim]Waiting for LLM...[/dim]")

                    response = await provider.complete(messages)
                    playbook_tokens += provider.last_usage
                    messages.append({"role": "assistant", "content": response})

                    if verbose:
                        console.print(f"      [bold cyan]LLM:[/bold cyan]")
                        display = response if len(response) < 3000 else response[:3000] + "\n      [dim]... (truncated)[/dim]"
                        for line in display.split("\n"):
                            console.print(f"      {line}")

                    # Extract ALL tool calls AND resource reads
                    tool_calls = _extract_all_tool_calls(response)
                    resource_reads = _extract_all_resource_reads(response)

                    all_actions = []

                    if tool_calls:
                        tool_results: list[str] = []
                        for tc in tool_calls:
                            tool_name = tc["tool"]
                            arguments = tc.get("arguments", {})

                            if verbose:
                                console.print(f"      [yellow]→ CALL[/yellow] {tool_name}({json.dumps(arguments, ensure_ascii=False)[:200]})")

                            try:
                                tool_result = await mcp_client.call_tool(
                                    session, tool_name, arguments
                                )
                                tool_results.append(f"Tool `{tool_name}` returned:\n{tool_result}")
                                all_interactions.append(ToolInteraction(
                                    tool_name=tool_name,
                                    arguments=arguments,
                                    response=tool_result[:2000],
                                ))
                                if verbose:
                                    display = tool_result if len(tool_result) < 500 else tool_result[:500] + "... (truncated)"
                                    console.print(f"      [green]← RESULT[/green] {display}")
                            except Exception as e:
                                tool_results.append(f"Tool `{tool_name}` error: {e}")
                                all_interactions.append(ToolInteraction(
                                    tool_name=tool_name,
                                    arguments=arguments,
                                    response=str(e)[:2000],
                                    is_error=True,
                                ))
                                if verbose:
                                    console.print(f"      [red]← ERROR[/red] {e}")

                        all_actions.extend(tool_results)

                        if verbose:
                            console.print(f"      [dim]({len(tool_calls)} tool call(s) executed)[/dim]")

                    if resource_reads:
                        for rr in resource_reads:
                            uri = rr.get("uri", "")
                            if verbose:
                                console.print(f"      [yellow]→ READ[/yellow] {uri}")
                            try:
                                res_result = await session.read_resource(uri)
                                text = ""
                                if hasattr(res_result, "contents"):
                                    for item in res_result.contents:
                                        if hasattr(item, "text"):
                                            text += item.text
                                elif hasattr(res_result, "content"):
                                    for block in res_result.content:
                                        if hasattr(block, "text"):
                                            text += block.text
                                else:
                                    text = str(res_result)
                                all_actions.append(f"Resource `{uri}` returned:\n{text[:2000]}")
                                all_interactions.append(ToolInteraction(
                                    tool_name=f"(resource:{uri})",
                                    arguments={"uri": uri},
                                    response=text[:2000],
                                ))
                                if verbose:
                                    display = text[:500] if len(text) < 500 else text[:500] + "... (truncated)"
                                    console.print(f"      [green]← RESULT[/green] {display}")
                            except Exception as e:
                                all_actions.append(f"Resource `{uri}` error: {e}")
                                all_interactions.append(ToolInteraction(
                                    tool_name=f"(resource:{uri})",
                                    arguments={"uri": uri},
                                    response=str(e)[:2000],
                                    is_error=True,
                                ))
                                if verbose:
                                    console.print(f"      [red]← ERROR[/red] {e}")

                    # Feed all results back as a single message
                    if all_actions:
                        combined = "\n\n---\n\n".join(all_actions)
                        messages.append({"role": "user", "content": combined})

                    # Check for findings block (after tool calls so both can coexist)
                    if "```findings" in response:
                        findings = _extract_findings(response, playbook)
                        # Attach attack context to each finding
                        for f in findings:
                            f.attack_prompt = system_prompt
                            f.tool_interactions = list(all_interactions)
                            f.raw_output = response
                        result.findings = findings
                        if verbose:
                            console.print(f"      [green]→ Agent reported {len(findings)} finding(s)[/green]")
                        break

                    if not tool_calls and not resource_reads:
                        # No action and no findings — ask agent to continue
                        messages.append({
                            "role": "user",
                            "content": "Continue your analysis. Call a tool, read a resource, or report your findings.",
                        })
                        if verbose:
                            console.print(f"      [dim]→ No tool call, nudging agent...[/dim]")
                else:
                    # Loop completed without break — max steps reached
                    result.error = (
                        f"Max steps ({context.max_steps}) reached without completing analysis. "
                        f"Increase --max-steps for deeper testing."
                    )

    except TimeoutError:
        result.error = f"Playbook timed out after {playbook_timeout}s"
    except BaseException as e:
        # Catch ExceptionGroup from asyncio TaskGroup and other base exceptions
        if isinstance(e, KeyboardInterrupt):
            raise
        error_type = type(e).__name__
        if isinstance(e, ExceptionGroup):
            sub_errors = "; ".join(str(sub) for sub in e.exceptions)
            result.error = f"{error_type}: {sub_errors}"
        else:
            result.error = f"{error_type}: {e}"

    result.duration_seconds = time.monotonic() - start
    result.token_usage = playbook_tokens
    return result


def _extract_json_blocks(response: str, marker: str) -> list[dict]:
    """Extract all JSON blocks with the given marker from agent response."""
    blocks: list[dict] = []
    search_from = 0

    while True:
        idx = response.find(marker, search_from)
        if idx == -1:
            break

        try:
            start = idx + len(marker)
            end = response.index("```", start)
            raw = response[start:end].strip()
            parsed = json.loads(raw)
            blocks.append(parsed)
            search_from = end + 3
        except (ValueError, json.JSONDecodeError):
            search_from = idx + len(marker)

    return blocks


def _extract_all_tool_calls(response: str) -> list[dict]:
    """Extract ALL tool_call JSON blocks from agent response."""
    return _extract_json_blocks(response, "```tool_call")


def _extract_all_resource_reads(response: str) -> list[dict]:
    """Extract ALL resource_read JSON blocks from agent response."""
    return _extract_json_blocks(response, "```resource_read")


def _extract_findings(response: str, playbook: BasePlaybook) -> list[Finding]:
    """Extract findings JSON block from agent response."""
    marker = "```findings"
    if marker not in response:
        return []

    try:
        start = response.index(marker) + len(marker)
        end = response.index("```", start)
        raw = response[start:end].strip()
        data = json.loads(raw)
    except (ValueError, json.JSONDecodeError):
        # Fall back to playbook's own parser
        return playbook.parse_findings(response)

    findings = []
    prefix = playbook.get_finding_id_prefix()

    for i, item in enumerate(data, 1):
        from mcpfang.reporting.models import Severity, FindingCategory

        sev_str = item.get("severity", playbook.severity_default).lower()
        try:
            severity = Severity(sev_str)
        except ValueError:
            severity = Severity.MEDIUM

        try:
            category = FindingCategory(playbook.category)
        except ValueError:
            category = FindingCategory.OTHER

        findings.append(Finding(
            id=f"{prefix}-{i:03d}",
            title=item.get("title", "Untitled finding"),
            description=item.get("description", ""),
            severity=severity,
            category=category,
            tool_name=item.get("tool_name", ""),
            playbook=playbook.name,
            cwe_ids=item.get("cwe_ids", playbook.cwe_ids),
            proof_of_concept=item.get("proof_of_concept", ""),
            remediation=item.get("remediation", ""),
            raw_output=response,
        ))

    return findings


def findings_to_candidates(
    findings: list[Finding],
    discovery: DiscoveryResult,
) -> list:
    """Convert playbook findings into EvaluationCandidate objects for the unified evaluator."""
    from mcpfang.reporting.models import EvaluationCandidate

    # Build tool lookup: name -> (description, schema)
    tool_lookup: dict[str, tuple[str, dict]] = {}
    for t in discovery.tools:
        tool_lookup[t.name.lower()] = (t.description, t.input_schema)

    candidates = []
    for f in findings:
        tool_desc, tool_schema = tool_lookup.get(f.tool_name.lower(), ("", {}))

        # For playbook findings, the agent's OWN description and PoC are the primary evidence.
        # The agent has full conversation context — it saw every tool response.
        # We trust its analysis and provide it verbatim to the evaluator.
        response_parts = []

        # 1. Agent's description IS the evidence
        if f.description:
            response_parts.append(f"Agent finding: {f.description[:800]}")

        # 2. Proof of concept shows what was tried
        if f.proof_of_concept:
            response_parts.append(f"Proof of concept: {f.proof_of_concept[:500]}")

        # 3. Remediation shows the agent understood the impact
        if f.remediation:
            response_parts.append(f"Suggested fix: {f.remediation[:300]}")

        combined_response = "\n".join(response_parts) if response_parts else f.title

        candidates.append(EvaluationCandidate(
            source=f.playbook,
            tool_name=f.tool_name,
            tool_description=tool_desc,
            tool_schema=tool_schema,
            action=f.proof_of_concept or f.title,
            arguments={},
            response=combined_response,
            claimed_severity=f.severity.value,
            claimed_title=f.title,
            original_finding=f,
        ))

    return candidates
