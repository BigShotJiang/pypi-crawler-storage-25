"""Attack context builder for adversarial agents."""

from __future__ import annotations

from dataclasses import dataclass, field

from mcpfang.analysis.domain import DomainReport
from mcpfang.reporting.models import DiscoveryResult, ToolInfo


@dataclass
class AttackContext:
    """Rich context provided to adversarial agents for attack planning."""

    discovery: DiscoveryResult
    domain: str = ""
    sensitive_data: list[str] = field(default_factory=list)
    business_rules: list[str] = field(default_factory=list)
    max_steps: int = 10
    domain_report: DomainReport | None = None

    @property
    def tools_summary(self) -> str:
        """Human-readable summary of available tools."""
        lines = []
        for tool in self.discovery.tools:
            schema_str = ""
            if tool.input_schema:
                params = tool.input_schema.get("properties", {})
                required = tool.input_schema.get("required", [])
                param_parts = []
                for name, info in params.items():
                    req = "*" if name in required else ""
                    ptype = info.get("type", "any")
                    param_parts.append(f"{name}{req}: {ptype}")
                schema_str = f" ({', '.join(param_parts)})"

            lines.append(f"- {tool.name}{schema_str}: {tool.description}")
        return "\n".join(lines)

    @property
    def resources_summary(self) -> str:
        """Human-readable summary of available resources."""
        lines = []
        for res in self.discovery.resources:
            lines.append(f"- {res.uri} ({res.name}): {res.description}")
        return "\n".join(lines)

    @property
    def domain_context(self) -> str:
        """Domain-specific context string for system prompts.

        If LLM domain analysis ran, use its structured report.
        Falls back to user-provided YAML context.
        """
        if self.domain_report:
            return self.domain_report.format_for_prompt()

        # Fallback: user-provided context only
        parts = []
        if self.domain:
            parts.append(f"Domain: {self.domain}")
        if self.sensitive_data:
            parts.append(f"Sensitive data types: {', '.join(self.sensitive_data)}")
        if self.business_rules:
            parts.append("Business rules:")
            for rule in self.business_rules:
                parts.append(f"  - {rule}")
        return "\n".join(parts)


def build_attack_context(
    discovery: DiscoveryResult,
    domain: str = "",
    sensitive_data: list[str] | None = None,
    business_rules: list[str] | None = None,
    max_steps: int = 10,
    domain_report: DomainReport | None = None,
) -> AttackContext:
    """Build an attack context from discovery results and user-provided info."""
    return AttackContext(
        discovery=discovery,
        domain=domain,
        sensitive_data=sensitive_data or [],
        business_rules=business_rules or [],
        max_steps=max_steps,
        domain_report=domain_report,
    )
