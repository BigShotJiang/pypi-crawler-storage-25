"""API key management — env var > config file > system keychain.

Implements the 4-layer trust architecture from the strategy doc.
"""

from __future__ import annotations

import os
from pathlib import Path

import yaml
from rich.console import Console

console = Console()

# Known provider → env var mappings
PROVIDER_ENV_VARS = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "google": "GOOGLE_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "mistral": "MISTRAL_API_KEY",
    "groq": "GROQ_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "together": "TOGETHER_API_KEY",
}

CREDENTIALS_DIR = Path.home() / ".mcpfang"
CREDENTIALS_FILE = CREDENTIALS_DIR / "credentials.yaml"


def get_api_key(provider: str, explicit_key: str | None = None) -> str | None:
    """Resolve API key using the priority chain:

    1. Explicitly provided key (--api-key flag)
    2. Environment variable (ANTHROPIC_API_KEY, OPENAI_API_KEY, etc.)
    3. Config file (~/.mcpfang/credentials.yaml)
    4. System keychain (if keyring available)

    Returns None if no key found.
    """
    # Layer 1: Explicit key
    if explicit_key:
        return explicit_key

    # Layer 2: Environment variable
    env_var = PROVIDER_ENV_VARS.get(provider)
    if env_var:
        key = os.environ.get(env_var)
        if key:
            return key

    # Also check generic LLM env var
    generic_key = os.environ.get("LLM_API_KEY")
    if generic_key:
        return generic_key

    # Layer 3: Config file
    key = _read_from_config(provider)
    if key:
        return key

    # Layer 4: System keychain
    key = _read_from_keychain(provider)
    if key:
        return key

    return None


def store_api_key(provider: str, api_key: str, method: str = "config") -> None:
    """Store an API key using the specified method.

    Args:
        provider: Provider name (anthropic, openai, etc.)
        api_key: The API key to store
        method: Storage method — "config" or "keychain"
    """
    if method == "config":
        _write_to_config(provider, api_key)
    elif method == "keychain":
        _write_to_keychain(provider, api_key)
    else:
        raise ValueError(f"Unknown storage method: {method}")


def _read_from_config(provider: str) -> str | None:
    """Read API key from ~/.mcpfang/credentials.yaml."""
    if not CREDENTIALS_FILE.exists():
        return None

    try:
        with open(CREDENTIALS_FILE) as f:
            data = yaml.safe_load(f) or {}

        providers = data.get("providers", {})
        provider_data = providers.get(provider, {})
        return provider_data.get("api_key")
    except Exception:
        return None


def _write_to_config(provider: str, api_key: str) -> None:
    """Write API key to ~/.mcpfang/credentials.yaml."""
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)

    data: dict = {}
    if CREDENTIALS_FILE.exists():
        with open(CREDENTIALS_FILE) as f:
            data = yaml.safe_load(f) or {}

    if "providers" not in data:
        data["providers"] = {}

    data["providers"][provider] = {"api_key": api_key}

    with open(CREDENTIALS_FILE, "w") as f:
        yaml.dump(data, f, default_flow_style=False)

    # Set restrictive permissions on Unix
    try:
        CREDENTIALS_FILE.chmod(0o600)
    except OSError:
        pass  # Windows doesn't support Unix permissions

    console.print(f"[green]✓[/green] API key stored in {CREDENTIALS_FILE}")


def _read_from_keychain(provider: str) -> str | None:
    """Read API key from system keychain."""
    try:
        import keyring
        return keyring.get_password("mcpfang", provider)
    except ImportError:
        return None
    except Exception:
        return None


def _write_to_keychain(provider: str, api_key: str) -> None:
    """Write API key to system keychain."""
    try:
        import keyring
        keyring.set_password("mcpfang", provider, api_key)
        console.print(f"[green]✓[/green] API key stored in system keychain")
    except ImportError:
        raise RuntimeError(
            "keyring package not installed. Run: pip install keyring\n"
            "Or use --method config to store in config file."
        )
