"""Direct httpx-based LLM providers — zero third-party LLM dependencies.

Supports:
  - Anthropic Messages API (Claude models)
  - OpenAI-compatible API (OpenAI, Ollama, OpenRouter, vLLM, LM Studio, etc.)
"""

from __future__ import annotations

import asyncio
import json
import random
from dataclasses import dataclass, field
from typing import AsyncIterator

import httpx

from mcpfang.reporting.models import TokenUsage


@dataclass
class ProviderError:
    """A non-200 response from the LLM API."""
    status_code: int
    message: str
    retried: bool = False
    exhausted: bool = False  # all retries used up

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"


class AnthropicProvider:
    """Anthropic Messages API provider via httpx."""

    def __init__(
        self,
        model: str = "claude-sonnet-4-20250514",
        api_key: str | None = None,
        base_url: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        delay_ms: int = 500,
        max_retries: int = 3,
        retry_base_delay_ms: int = 2000,
    ) -> None:
        self._model = model
        self._api_key = api_key or ""
        self._base_url = (base_url or ANTHROPIC_API_URL).rstrip("/")
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._delay_ms = delay_ms
        self._max_retries = max_retries
        self._retry_base_delay_ms = retry_base_delay_ms
        self.errors: list[ProviderError] = []
        self.last_usage: TokenUsage = TokenUsage()

    @property
    def provider_name(self) -> str:
        return "anthropic"

    @property
    def model_name(self) -> str:
        return self._model

    def _headers(self) -> dict[str, str]:
        return {
            "x-api-key": self._api_key,
            "anthropic-version": ANTHROPIC_VERSION,
            "content-type": "application/json",
        }

    @staticmethod
    def _split_system(messages: list[dict]) -> tuple[str, list[dict]]:
        """Anthropic API takes system as top-level param, not in messages."""
        system = ""
        conversation: list[dict] = []
        for msg in messages:
            if msg["role"] == "system":
                system = msg["content"]
            else:
                conversation.append({"role": msg["role"], "content": msg["content"]})
        return system, conversation

    async def complete(self, messages: list[dict]) -> str:
        system, conversation = self._split_system(messages)
        payload: dict = {
            "model": self._model,
            "max_tokens": self._max_tokens,
            "temperature": self._temperature,
            "messages": conversation,
        }
        if system:
            payload["system"] = system

        # Delay between calls
        if self._delay_ms > 0:
            await asyncio.sleep(self._delay_ms / 1000)

        last_error: httpx.HTTPStatusError | None = None
        for attempt in range(self._max_retries + 1):
            try:
                async with httpx.AsyncClient(timeout=120.0) as client:
                    resp = await client.post(
                        self._base_url,
                        headers=self._headers(),
                        json=payload,
                    )
                    resp.raise_for_status()
                    data = resp.json()

                # Extract token usage from Anthropic response
                usage = data.get("usage", {})
                self.last_usage = TokenUsage(
                    input_tokens=usage.get("input_tokens", 0),
                    output_tokens=usage.get("output_tokens", 0),
                )

                return "".join(
                    block["text"] for block in data.get("content", []) if block.get("type") == "text"
                )
            except httpx.HTTPStatusError as e:
                last_error = e
                status = e.response.status_code
                retryable = status in (429, 500, 502, 503, 529)

                self.errors.append(ProviderError(
                    status_code=status,
                    message=str(e)[:200],
                    retried=retryable and attempt < self._max_retries,
                ))

                if retryable and attempt < self._max_retries:
                    base_wait = (self._retry_base_delay_ms / 1000) * (2 ** attempt)
                    jitter = random.uniform(0, base_wait * 0.25)
                    await asyncio.sleep(base_wait + jitter)
                    continue

                # Mark last error as exhausted
                self.errors[-1].exhausted = True
                raise

        raise last_error  # type: ignore[misc]  # safety net

    async def stream(self, messages: list[dict]) -> AsyncIterator[str]:
        system, conversation = self._split_system(messages)
        payload: dict = {
            "model": self._model,
            "max_tokens": self._max_tokens,
            "temperature": self._temperature,
            "messages": conversation,
            "stream": True,
        }
        if system:
            payload["system"] = system

        async with httpx.AsyncClient(timeout=120.0) as client:
            async with client.stream(
                "POST",
                self._base_url,
                headers=self._headers(),
                json=payload,
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    chunk_str = line[6:]
                    if chunk_str.strip() == "[DONE]":
                        break
                    chunk = json.loads(chunk_str)
                    if chunk.get("type") == "content_block_delta":
                        if text := chunk.get("delta", {}).get("text"):
                            yield text


# --- OpenAI-compatible provider ---

OPENAI_API_URL = "https://api.openai.com/v1/chat/completions"

PROVIDER_BASE_URLS: dict[str, str] = {
    "openai": "https://api.openai.com/v1/chat/completions",
    "openrouter": "https://openrouter.ai/api/v1/chat/completions",
    "ollama": "http://localhost:11434/v1/chat/completions",
    "lmstudio": "http://localhost:1234/v1/chat/completions",
}


class OpenAICompatibleProvider:
    """OpenAI-compatible API provider via httpx.

    Works with: OpenAI, Ollama, OpenRouter, vLLM, LM Studio,
    and any endpoint that speaks the OpenAI chat completions format.
    """

    def __init__(
        self,
        provider: str = "openai",
        model: str = "gpt-4o",
        api_key: str | None = None,
        base_url: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        delay_ms: int = 500,
        max_retries: int = 3,
        retry_base_delay_ms: int = 2000,
    ) -> None:
        self._provider = provider
        self._model = model
        self._api_key = api_key or ""
        self._base_url = (base_url or PROVIDER_BASE_URLS.get(provider, OPENAI_API_URL)).rstrip("/")
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._delay_ms = delay_ms
        self._max_retries = max_retries
        self._retry_base_delay_ms = retry_base_delay_ms
        self.errors: list[ProviderError] = []
        self.last_usage: TokenUsage = TokenUsage()

    @property
    def provider_name(self) -> str:
        return self._provider

    @property
    def model_name(self) -> str:
        return self._model

    def _headers(self) -> dict[str, str]:
        headers = {"content-type": "application/json"}
        if self._api_key:
            headers["authorization"] = f"Bearer {self._api_key}"
        return headers

    async def complete(self, messages: list[dict]) -> str:
        payload = {
            "model": self._model,
            "max_tokens": self._max_tokens,
            "temperature": self._temperature,
            "messages": messages,
        }

        # Delay between calls
        if self._delay_ms > 0:
            await asyncio.sleep(self._delay_ms / 1000)

        last_error: httpx.HTTPStatusError | None = None
        for attempt in range(self._max_retries + 1):
            try:
                async with httpx.AsyncClient(timeout=120.0) as client:
                    resp = await client.post(
                        self._base_url,
                        headers=self._headers(),
                        json=payload,
                    )
                    resp.raise_for_status()
                    data = resp.json()

                # Extract token usage from OpenAI-compatible response
                usage = data.get("usage", {})
                self.last_usage = TokenUsage(
                    input_tokens=usage.get("prompt_tokens", 0),
                    output_tokens=usage.get("completion_tokens", 0),
                )

                return data["choices"][0]["message"]["content"] or ""
            except httpx.HTTPStatusError as e:
                last_error = e
                status = e.response.status_code
                retryable = status in (429, 500, 502, 503, 529)

                self.errors.append(ProviderError(
                    status_code=status,
                    message=str(e)[:200],
                    retried=retryable and attempt < self._max_retries,
                ))

                if retryable and attempt < self._max_retries:
                    base_wait = (self._retry_base_delay_ms / 1000) * (2 ** attempt)
                    jitter = random.uniform(0, base_wait * 0.25)
                    await asyncio.sleep(base_wait + jitter)
                    continue

                # Mark last error as exhausted
                self.errors[-1].exhausted = True
                raise

        raise last_error  # type: ignore[misc]  # safety net

    async def stream(self, messages: list[dict]) -> AsyncIterator[str]:
        payload = {
            "model": self._model,
            "max_tokens": self._max_tokens,
            "temperature": self._temperature,
            "messages": messages,
            "stream": True,
        }

        async with httpx.AsyncClient(timeout=120.0) as client:
            async with client.stream(
                "POST",
                self._base_url,
                headers=self._headers(),
                json=payload,
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    chunk_str = line[6:]
                    if chunk_str.strip() == "[DONE]":
                        break
                    chunk = json.loads(chunk_str)
                    delta = chunk["choices"][0].get("delta", {})
                    if text := delta.get("content"):
                        yield text


def create_provider(
    provider: str,
    model: str,
    api_key: str | None = None,
    base_url: str | None = None,
    max_tokens: int = 4096,
    temperature: float = 0.7,
    delay_ms: int = 500,
    max_retries: int = 3,
    retry_base_delay_ms: int = 2000,
) -> AnthropicProvider | OpenAICompatibleProvider:
    """Factory: pick the right provider based on name."""
    if provider == "anthropic":
        return AnthropicProvider(
            model=model,
            api_key=api_key,
            base_url=base_url,
            max_tokens=max_tokens,
            temperature=temperature,
            delay_ms=delay_ms,
            max_retries=max_retries,
            retry_base_delay_ms=retry_base_delay_ms,
        )
    return OpenAICompatibleProvider(
        provider=provider,
        model=model,
        api_key=api_key,
        base_url=base_url,
        max_tokens=max_tokens,
        temperature=temperature,
        delay_ms=delay_ms,
        max_retries=max_retries,
        retry_base_delay_ms=retry_base_delay_ms,
    )
