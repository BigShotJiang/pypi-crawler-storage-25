"""LLM provider protocol definition."""

from __future__ import annotations

from typing import AsyncIterator, Protocol, runtime_checkable

from mcpfang.reporting.models import TokenUsage


@runtime_checkable
class LLMProvider(Protocol):
    """Interface that all LLM providers must implement."""

    last_usage: TokenUsage

    @property
    def provider_name(self) -> str: ...

    @property
    def model_name(self) -> str: ...

    async def complete(self, messages: list[dict]) -> str:
        """Send messages and return the complete response text."""
        ...

    async def stream(self, messages: list[dict]) -> AsyncIterator[str]:
        """Send messages and yield response chunks."""
        ...
