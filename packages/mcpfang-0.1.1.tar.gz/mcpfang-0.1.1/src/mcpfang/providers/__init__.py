"""LLM provider abstraction layer."""
