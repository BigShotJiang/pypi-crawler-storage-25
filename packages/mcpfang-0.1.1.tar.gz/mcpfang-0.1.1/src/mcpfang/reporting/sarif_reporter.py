"""SARIF 2.1.0 report output for GitHub Security tab integration."""

from __future__ import annotations

import json
from pathlib import Path

from mcpfang import __version__
from mcpfang.reporting.models import ScanResult, Severity

# SARIF severity mapping
SARIF_LEVELS = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
    Severity.INFO: "note",
}


def write_sarif_report(result: ScanResult, output_path: Path | str | None = None) -> str:
    """Generate SARIF 2.1.0 report.

    Returns the SARIF JSON string and optionally writes to file.
    """
    rules = []
    results = []
    rule_ids_seen: set[str] = set()

    for finding in result.all_findings:
        # Build rule if not already added
        rule_id = f"mcpfang/{finding.playbook}/{finding.id}"
        if rule_id not in rule_ids_seen:
            rule_ids_seen.add(rule_id)

            rule: dict = {
                "id": rule_id,
                "name": finding.id,
                "shortDescription": {"text": finding.title},
                "fullDescription": {"text": finding.description},
                "defaultConfiguration": {
                    "level": SARIF_LEVELS.get(finding.severity, "warning"),
                },
                "properties": {
                    "tags": [finding.category.value, finding.playbook],
                },
            }

            if finding.cwe_ids:
                rule["relationships"] = [
                    {
                        "target": {
                            "id": cwe_id,
                            "guid": cwe_id,
                            "toolComponent": {"name": "CWE"},
                        },
                        "kinds": ["superset"],
                    }
                    for cwe_id in finding.cwe_ids
                ]

            rules.append(rule)

        # Build result
        sarif_result: dict = {
            "ruleId": rule_id,
            "level": SARIF_LEVELS.get(finding.severity, "warning"),
            "message": {"text": finding.description},
            "locations": [
                {
                    "logicalLocations": [
                        {
                            "name": finding.tool_name or "unknown",
                            "kind": "function",
                            "fullyQualifiedName": f"mcp://{result.target}/{finding.tool_name}",
                        }
                    ]
                }
            ],
        }

        if finding.proof_of_concept:
            sarif_result["attachments"] = [
                {
                    "description": {"text": "Proof of concept"},
                    "contents": {"text": finding.proof_of_concept},
                }
            ]

        if finding.remediation:
            sarif_result["fixes"] = [
                {
                    "description": {"text": finding.remediation},
                }
            ]

        results.append(sarif_result)

    sarif = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "MCPFang",
                        "version": __version__,
                        "informationUri": "https://github.com/mcpfang/mcpfang",
                        "rules": rules,
                    }
                },
                "results": results,
                "invocations": [
                    {
                        "executionSuccessful": True,
                        "commandLine": f"mcpfang scan {result.target}",
                    }
                ],
            }
        ],
    }

    json_str = json.dumps(sarif, indent=2, ensure_ascii=False)

    if output_path:
        Path(output_path).write_text(json_str, encoding="utf-8")

    return json_str
