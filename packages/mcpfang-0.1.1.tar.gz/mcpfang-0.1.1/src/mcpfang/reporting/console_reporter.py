"""Rich-based terminal output for scan results."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from mcpfang.reporting.models import ScanResult, Severity, PlaybookResult

console = Console()

SEVERITY_STYLES = {
    Severity.CRITICAL: "bold red",
    Severity.HIGH: "red",
    Severity.MEDIUM: "yellow",
    Severity.LOW: "cyan",
    Severity.INFO: "dim",
}

SEVERITY_ICONS = {
    Severity.CRITICAL: "✗",
    Severity.HIGH: "⚠",
    Severity.MEDIUM: "⚠",
    Severity.LOW: "·",
    Severity.INFO: "·",
}


def print_banner(target: str, provider: str, model: str) -> None:
    """Print the MCPFang scan banner."""
    from mcpfang import __version__

    banner = Text()
    banner.append(f"  MCPFang v{__version__}", style="bold cyan")
    banner.append(" — MCP Security Scanner\n")
    banner.append(f"  Target: {target}\n", style="white")
    banner.append(f"  Provider: {provider} ({model})", style="dim")

    console.print(Panel(banner, border_style="cyan"))


def print_discovery(result: ScanResult) -> None:
    """Print discovery phase results."""
    if not result.discovery:
        return

    d = result.discovery
    console.print(f"  ▸ Connecting to MCP server...                    [green]✓[/green]")
    console.print(
        f"  ▸ Discovering tools ({len(d.tools)} found)"
        f"                    [green]✓[/green]"
    )
    console.print(
        f"  ▸ Discovering resources ({len(d.resources)} found)"
        f"               [green]✓[/green]"
    )


def print_playbook_progress(pr: PlaybookResult) -> None:
    """Print a single playbook result line."""
    name = pr.playbook_name.replace("_", " ").title()
    count = len(pr.findings)

    if pr.error:
        status = "[red]✗ ERROR[/red]"
    elif count == 0:
        status = "[green]✓[/green]"
    else:
        max_sev = max(pr.findings, key=lambda f: f.severity.rank).severity
        style = SEVERITY_STYLES.get(max_sev, "yellow")
        icon = SEVERITY_ICONS.get(max_sev, "⚠")
        status = f"[{style}]{icon}[/{style}]"

    console.print(f"    {name:<35} {count} findings   {status}")


def print_summary(result: ScanResult) -> None:
    """Print the findings summary box."""
    by_sev = result.findings_by_severity

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("severity", width=12)
    table.add_column("count", justify="right", width=5)

    for sev in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]:
        count = len(by_sev.get(sev, []))
        if count > 0:
            style = SEVERITY_STYLES[sev]
            table.add_row(f"[{style}]{sev.value.title()}[/{style}]", str(count))

    total = len(result.all_findings)
    table.add_row("", "")
    table.add_row("[bold]Total[/bold]", f"[bold]{total}[/bold]")

    console.print()
    console.print(Panel(table, title="Results", border_style="cyan"))


def print_findings_detail(result: ScanResult) -> None:
    """Print detailed findings."""
    console.print()

    for finding in result.all_findings:
        style = SEVERITY_STYLES.get(finding.severity, "white")
        sev_label = finding.severity.value.upper()

        console.print(f"  [{style}]{sev_label:<9}[/{style}] ┃ [bold]{finding.id}[/bold]: {finding.title}")
        console.print(f"           ┃ {finding.description}")

        if finding.cwe_ids:
            cwe_str = ", ".join(finding.cwe_ids)
            console.print(f"           ┃ {cwe_str} │ Tool: {finding.tool_name}")

        if finding.proof_of_concept:
            console.print(f"           ┃ PoC: {finding.proof_of_concept}")

        if finding.remediation:
            console.print(f"           ┃ Fix: {finding.remediation}")

        console.print(f"           ┃")


def _fmt_tokens(n: int) -> str:
    """Format token count with K suffix for readability."""
    if n >= 1000:
        return f"{n / 1000:.1f}K"
    return str(n)


def print_token_usage(result: ScanResult) -> None:
    """Print token usage breakdown table."""
    total = result.total_token_usage
    if total.total_tokens == 0:
        return

    console.print()
    table = Table(title="Token Usage", show_header=True, box=None, padding=(0, 2))
    table.add_column("Phase", style="bold")
    table.add_column("Input", justify="right")
    table.add_column("Output", justify="right")
    table.add_column("Total", justify="right", style="bold")

    # Domain analysis
    da = result.domain_analysis_tokens
    if da.total_tokens > 0:
        table.add_row("Domain Analysis", _fmt_tokens(da.input_tokens), _fmt_tokens(da.output_tokens), _fmt_tokens(da.total_tokens))

    # Per-playbook
    for pr in result.playbook_results:
        t = pr.token_usage
        if t.total_tokens > 0:
            name = pr.playbook_name.replace("_", " ").title()
            table.add_row(f"  {name}", _fmt_tokens(t.input_tokens), _fmt_tokens(t.output_tokens), _fmt_tokens(t.total_tokens))

    # Evaluation
    ev = result.evaluation_tokens
    if ev.total_tokens > 0:
        table.add_row("Evaluation + Dedup", _fmt_tokens(ev.input_tokens), _fmt_tokens(ev.output_tokens), _fmt_tokens(ev.total_tokens))

    # Total
    table.add_row("", "", "", "")
    table.add_row("[bold cyan]Total[/bold cyan]", f"[bold cyan]{_fmt_tokens(total.input_tokens)}[/bold cyan]", f"[bold cyan]{_fmt_tokens(total.output_tokens)}[/bold cyan]", f"[bold cyan]{_fmt_tokens(total.total_tokens)}[/bold cyan]")

    console.print(Panel(table, border_style="dim"))


def print_report(result: ScanResult) -> None:
    """Print the complete scan report to terminal."""
    print_banner(result.target, result.provider_name, result.model_name)
    console.print()

    print_discovery(result)
    console.print()

    if result.playbook_results:
        console.print("  ▸ Running playbooks...")
        for i, pr in enumerate(result.playbook_results, 1):
            total = len(result.playbook_results)
            console.print(f"    [{i}/{total}] ", end="")
            print_playbook_progress(pr)

    print_summary(result)
    print_findings_detail(result)

    if result.all_findings:
        console.print("  [dim]▸ Run with --verbose for detailed proof-of-concept[/dim]")
        console.print("  [dim]▸ Run with --output sarif for GitHub Security tab integration[/dim]")
    else:
        console.print("  [green]No findings — target appears secure against tested playbooks.[/green]")

    print_token_usage(result)
    console.print()
