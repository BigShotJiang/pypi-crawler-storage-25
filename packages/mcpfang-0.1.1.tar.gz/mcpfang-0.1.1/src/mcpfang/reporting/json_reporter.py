"""JSON report output."""

from __future__ import annotations

import json
from pathlib import Path

from mcpfang.reporting.models import ScanResult


def write_json_report(result: ScanResult, output_path: Path | str | None = None) -> str:
    """Generate JSON report and optionally write to file.

    Returns the JSON string.
    """
    data = result.to_dict()
    json_str = json.dumps(data, indent=2, ensure_ascii=False)

    if output_path:
        Path(output_path).write_text(json_str, encoding="utf-8")

    return json_str
