"""Data models for scan findings and reports."""

from __future__ import annotations

import enum
from datetime import datetime, timezone
from dataclasses import dataclass, field


class Severity(str, enum.Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"

    @property
    def rank(self) -> int:
        return {
            Severity.CRITICAL: 4,
            Severity.HIGH: 3,
            Severity.MEDIUM: 2,
            Severity.LOW: 1,
            Severity.INFO: 0,
        }[self]

    def __lt__(self, other: Severity) -> bool:
        return self.rank < other.rank


class FindingCategory(str, enum.Enum):
    INJECTION = "injection"
    PATH_TRAVERSAL = "path_traversal"
    TOOL_POISONING = "tool_poisoning"
    AUTH_BYPASS = "auth_bypass"
    INPUT_VALIDATION = "input_validation"
    DATA_EXFILTRATION = "data_exfiltration"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    HIDDEN_SURFACE = "hidden_surface"
    OTHER = "other"


@dataclass
class TokenUsage:
    """Token usage for a single LLM call or accumulated phase."""

    input_tokens: int = 0
    output_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def __iadd__(self, other: TokenUsage) -> TokenUsage:
        self.input_tokens += other.input_tokens
        self.output_tokens += other.output_tokens
        return self

    def to_dict(self) -> dict:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
        }


@dataclass
class ToolInteraction:
    """A single tool call and its response during an attack."""

    tool_name: str
    arguments: dict = field(default_factory=dict)
    response: str = ""
    is_error: bool = False

    def to_dict(self) -> dict:
        d: dict = {
            "tool_name": self.tool_name,
            "arguments": self.arguments,
            "response": self.response,
        }
        if self.is_error:
            d["is_error"] = True
        return d


@dataclass
class Finding:
    """A single security finding from a scan."""

    id: str
    title: str
    description: str
    severity: Severity
    category: FindingCategory
    tool_name: str
    playbook: str
    cwe_ids: list[str] = field(default_factory=list)
    proof_of_concept: str = ""
    remediation: str = ""
    raw_output: str = ""
    attack_prompt: str = ""
    tool_interactions: list[ToolInteraction] = field(default_factory=list)

    def to_dict(self) -> dict:
        d: dict = {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "severity": self.severity.value,
            "category": self.category.value,
            "tool_name": self.tool_name,
            "playbook": self.playbook,
            "cwe_ids": self.cwe_ids,
            "proof_of_concept": self.proof_of_concept,
            "remediation": self.remediation,
        }
        if self.attack_prompt:
            d["attack_prompt"] = self.attack_prompt
        if self.tool_interactions:
            d["tool_interactions"] = [t.to_dict() for t in self.tool_interactions]
        if self.raw_output:
            d["raw_output"] = self.raw_output
        return d


@dataclass
class EvaluationCandidate:
    """A candidate finding awaiting LLM evaluation."""

    source: str  # "fuzzer" or playbook name like "command_injection"
    tool_name: str
    tool_description: str  # from discovery
    tool_schema: dict = field(default_factory=dict)  # tool's input_schema from discovery
    action: str = ""  # what was attempted
    arguments: dict = field(default_factory=dict)
    response: str = ""  # what the tool returned
    claimed_severity: str = "medium"
    claimed_title: str = ""
    # Original finding data to preserve if confirmed
    original_finding: Finding | None = None

    def to_prompt_block(self) -> str:
        """Format this candidate for the evaluator LLM prompt."""
        import json as _json
        lines = [
            f"TOOL: {self.tool_name}",
            f"TOOL PURPOSE: {self.tool_description[:200]}",
        ]
        if self.tool_schema:
            schema_str = _json.dumps(self.tool_schema, ensure_ascii=False)[:400]
            lines.append(f"TOOL SCHEMA: {schema_str}")
        lines.append(f"ATTACK: {self.action}")
        if self.arguments:
            lines.append(f"ARGUMENTS: {_json.dumps(self.arguments, ensure_ascii=False)[:300]}")
        lines.append(f"RESPONSE: {self.response[:500]}")
        lines.append(f"CLAIMED: [{self.claimed_severity}] {self.claimed_title}")
        return "\n".join(lines)


@dataclass
class EvaluationVerdict:
    """LLM's verdict on a candidate finding."""

    verdict: str  # "confirmed", "false_positive", "needs_review"
    severity: str = "medium"
    reasoning: str = ""
    refined_title: str = ""


@dataclass
class ToolInfo:
    """Information about a discovered MCP tool."""

    name: str
    description: str
    input_schema: dict = field(default_factory=dict)


@dataclass
class ResourceInfo:
    """Information about a discovered MCP resource."""

    uri: str
    name: str
    description: str = ""
    mime_type: str = ""


@dataclass
class DiscoveryResult:
    """Result of MCP server discovery phase."""

    endpoint: str
    server_name: str = ""
    server_version: str = ""
    tools: list[ToolInfo] = field(default_factory=list)
    resources: list[ResourceInfo] = field(default_factory=list)
    prompts: list[dict] = field(default_factory=list)


@dataclass
class PlaybookResult:
    """Result of running a single playbook."""

    playbook_name: str
    findings: list[Finding] = field(default_factory=list)
    error: str | None = None
    duration_seconds: float = 0.0
    token_usage: TokenUsage = field(default_factory=TokenUsage)


@dataclass
class ScanResult:
    """Complete scan result."""

    target: str
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: datetime | None = None
    discovery: DiscoveryResult | None = None
    playbook_results: list[PlaybookResult] = field(default_factory=list)
    provider_name: str = ""
    model_name: str = ""
    # Token usage per phase
    domain_analysis_tokens: TokenUsage = field(default_factory=TokenUsage)
    evaluation_tokens: TokenUsage = field(default_factory=TokenUsage)

    @property
    def all_findings(self) -> list[Finding]:
        findings = []
        for pr in self.playbook_results:
            findings.extend(pr.findings)
        return sorted(findings, key=lambda f: f.severity.rank, reverse=True)

    @property
    def findings_by_severity(self) -> dict[Severity, list[Finding]]:
        result: dict[Severity, list[Finding]] = {}
        for f in self.all_findings:
            result.setdefault(f.severity, []).append(f)
        return result

    @property
    def duration_seconds(self) -> float:
        if self.finished_at and self.started_at:
            return (self.finished_at - self.started_at).total_seconds()
        return 0.0

    @property
    def total_token_usage(self) -> TokenUsage:
        """Aggregate token usage across all phases."""
        total = TokenUsage()
        total += self.domain_analysis_tokens
        for pr in self.playbook_results:
            total += pr.token_usage
        total += self.evaluation_tokens
        return total

    def to_dict(self) -> dict:
        # Per-playbook token breakdown
        playbook_tokens = {}
        for pr in self.playbook_results:
            if pr.token_usage.total_tokens > 0:
                playbook_tokens[pr.playbook_name] = pr.token_usage.to_dict()

        return {
            "target": self.target,
            "started_at": self.started_at.isoformat(),
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "duration_seconds": self.duration_seconds,
            "provider": self.provider_name,
            "model": self.model_name,
            "summary": {
                sev.value: len(findings)
                for sev, findings in self.findings_by_severity.items()
            },
            "total_findings": len(self.all_findings),
            "token_usage": {
                "total": self.total_token_usage.to_dict(),
                "domain_analysis": self.domain_analysis_tokens.to_dict(),
                "playbooks": playbook_tokens,
                "evaluation": self.evaluation_tokens.to_dict(),
            },
            "findings": [f.to_dict() for f in self.all_findings],
        }
