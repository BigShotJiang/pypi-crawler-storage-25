"""Input validation attack playbook."""

from __future__ import annotations

from mcpfang.agents.base import BasePlaybook
from mcpfang.agents.context import AttackContext
from mcpfang.playbooks.registry import register_playbook
from mcpfang.reporting.models import Finding, Severity, FindingCategory


@register_playbook
class InputValidationPlaybook(BasePlaybook):
    name = "input_validation"
    category = "input_validation"
    severity_default = "medium"
    cwe_ids = ["CWE-20", "CWE-89", "CWE-79"]
    description = "Tests for SQL injection, XSS, type confusion, and input validation failures"

    def get_system_prompt(self, context: AttackContext) -> str:
        return f"""You are an expert security researcher performing a penetration test on an MCP server.
Your goal is to find INPUT VALIDATION vulnerabilities in the server's tools.

{context.domain_context}

Available tools on the target server:
{context.tools_summary}

## Attack Strategy

1. **SQL Injection**: For tools that likely query databases:
   - `' OR '1'='1` (basic tautology)
   - `'; DROP TABLE users; --` (destructive — only in sandbox!)
   - `' UNION SELECT username, password FROM users --` (data extraction)
   - `1; WAITFOR DELAY '0:0:5' --` (time-based blind)
   - Test string, numeric, and parameter-based injection points

2. **NoSQL Injection**: For tools with document databases:
   - `{{"$gt": ""}}` (operator injection)
   - `{{"$ne": null}}` (not-equal bypass)
   - `{{"$where": "sleep(5000)"}}` (JavaScript injection)

3. **XSS / Template Injection**: For tools that render output:
   - `<script>alert(1)</script>` (basic XSS)
   - `{{{{7*7}}}}` (template injection — Jinja2, Handlebars)
   - `${{7*7}}` (expression language injection)

4. **Type Confusion**: Send unexpected types:
   - String where number expected
   - Array where string expected
   - Negative numbers, zero, MAX_INT
   - Empty strings, null, undefined
   - Very long strings (10000+ chars for buffer overflow)

5. **Schema Violation**: Send data that violates the tool's input schema:
   - Missing required fields
   - Extra unexpected fields
   - Wrong data types
   - Values outside defined ranges

6. **Special Characters**: Test handling of:
   - Unicode: `é`, `中文`, `🎭`, null bytes `\\x00`
   - Control chars: newlines, tabs, carriage returns
   - Format strings: `%s`, `%x`, `%n` (C-style)

7. **SSRF (Server-Side Request Forgery)**: For tools that fetch URLs:
   - `http://localhost/admin` — internal service probing
   - `http://169.254.169.254/latest/meta-data/` — cloud metadata
   - `file:///etc/passwd` — local file read via URL scheme
   - `dict://localhost:6379/INFO` — Redis probing
   - `gopher://localhost:6379/_INFO` — gopher SSRF

8. **Error-based information disclosure**: Trigger verbose errors to leak:
   - Internal paths, hostnames, database schemas
   - Stack traces with environment variables
   - Connection strings or API endpoint URLs
   - Software versions enabling targeted exploits
   Try: extremely long inputs, deeply nested JSON, binary data, negative numbers

For each finding, record the exact input, the response, and why it indicates a vulnerability."""

    def get_initial_message(self, context: AttackContext) -> str:
        tool_names = [t.name for t in context.discovery.tools]
        return (
            f"Begin your input validation assessment. "
            f"The target has these tools: {', '.join(tool_names)}. "
            f"Start with SQL injection on tools that likely query data, "
            f"then test type confusion and schema violations on all tools."
        )

    def parse_findings(self, agent_output: str) -> list[Finding]:
        findings = []
        validation_indicators = [
            "sql injection", "sqli", "xss", "cross-site",
            "template injection", "type confusion", "schema violation",
            "input validation", "nosql injection", "format string",
            "buffer overflow", "unhandled", "error trace", "stack trace",
            "internal server error", "exception",
        ]
        output_lower = agent_output.lower()
        if any(indicator in output_lower for indicator in validation_indicators):
            findings.append(Finding(
                id="IVL-001",
                title="Potential input validation failure",
                description="The agent detected input validation weaknesses in tool parameters.",
                severity=Severity.MEDIUM,
                category=FindingCategory.INPUT_VALIDATION,
                tool_name="unknown",
                playbook=self.name,
                cwe_ids=self.cwe_ids,
                raw_output=agent_output,
            ))
        return findings
