"""Attack playbook library."""
