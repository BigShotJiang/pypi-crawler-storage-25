"""Resource probing playbook — tests MCP resource endpoints for unauthorized access."""

from __future__ import annotations

from mcpfang.agents.base import BasePlaybook
from mcpfang.agents.context import AttackContext
from mcpfang.playbooks.registry import register_playbook
from mcpfang.reporting.models import Finding, Severity, FindingCategory


@register_playbook
class ResourceProbingPlaybook(BasePlaybook):
    name = "resource_probing"
    category = "auth_bypass"
    severity_default = "high"
    cwe_ids = ["CWE-200", "CWE-862", "CWE-22"]
    description = "Tests MCP resource endpoints for unauthorized access, path traversal, and data leakage"

    def get_system_prompt(self, context: AttackContext) -> str:
        resources_block = context.resources_summary or "No resources listed in discovery."

        return f"""You are an expert security researcher testing MCP RESOURCE ENDPOINTS for vulnerabilities.

MCP servers expose resources via URI schemes (e.g. file://, internal://, notes://). \
These resources may contain sensitive data, lack access controls, or be vulnerable to \
path traversal and injection attacks.

{context.domain_context}

## Available Resources (from discovery)
{resources_block}

## Available Tools (for comparison/chaining)
{context.tools_summary}

## Attack Strategy

### Phase 1: Read all listed resources
Read every resource listed above. Look for:
- Sensitive data (credentials, API keys, PII, internal configs)
- Hidden instructions or injection content
- References to OTHER resources not in the list

### Phase 2: Probe for hidden resources
Try resource URIs that weren't listed:
- internal://credentials, internal://config, internal://secrets
- admin://settings, admin://users, debug://state, debug://logs
- file:///etc/passwd, file:///.env, file:///proc/self/environ

### Phase 3: Template fuzzing
If any resource uses templates like notes://{{user_id}}, try:
- Common IDs: admin, root, system, test, user1
- Path traversal: ../../../etc/passwd
- Injection: ' OR 1=1 --, {{{{7*7}}}}, <script>

### Phase 4: Cross-reference with tools
Use tool results to discover more resources:
- If a tool returns file paths, try reading them as resources
- If a tool mentions users, try user-specific resource URIs
- Chain: tool output → resource URI → sensitive data

You can read resources using:
```resource_read
{{"uri": "resource://path"}}
```
"""

    def get_initial_message(self, context: AttackContext) -> str:
        n_resources = len(context.discovery.resources)
        n_tools = len(context.discovery.tools)
        return (
            f"The MCP server has {n_resources} listed resource(s) and {n_tools} tool(s). "
            f"Begin your resource security assessment. Start by reading all listed resources, "
            f"then probe for hidden ones."
        )

    def parse_findings(self, agent_output: str) -> list[Finding]:
        return []

    def get_finding_id_prefix(self) -> str:
        return "RSC"
