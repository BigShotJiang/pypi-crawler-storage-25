"""Playbook discovery and registry."""

from __future__ import annotations

from mcpfang.agents.base import BasePlaybook

_REGISTRY: dict[str, type[BasePlaybook]] = {}


def register_playbook(cls: type[BasePlaybook]) -> type[BasePlaybook]:
    """Decorator to register a playbook class."""
    _REGISTRY[cls.name] = cls
    return cls


def get_playbook(name: str) -> BasePlaybook:
    """Get a playbook instance by name."""
    if name not in _REGISTRY:
        available = ", ".join(sorted(_REGISTRY.keys()))
        raise KeyError(f"Unknown playbook '{name}'. Available: {available}")
    return _REGISTRY[name]()


def get_all_playbooks() -> list[BasePlaybook]:
    """Return instances of all registered playbooks."""
    return [cls() for cls in _REGISTRY.values()]


def list_playbook_names() -> list[str]:
    """Return sorted list of registered playbook names."""
    return sorted(_REGISTRY.keys())


def _ensure_loaded() -> None:
    """Import all playbook modules to trigger registration."""
    from mcpfang.playbooks import command_injection  # noqa: F401
    from mcpfang.playbooks import path_traversal  # noqa: F401
    from mcpfang.playbooks import tool_poisoning  # noqa: F401
    from mcpfang.playbooks import auth_bypass  # noqa: F401
    from mcpfang.playbooks import input_validation  # noqa: F401
    from mcpfang.playbooks import context_injection  # noqa: F401
    from mcpfang.playbooks import intent_flow_subversion  # noqa: F401
    from mcpfang.playbooks import resource_probing  # noqa: F401
