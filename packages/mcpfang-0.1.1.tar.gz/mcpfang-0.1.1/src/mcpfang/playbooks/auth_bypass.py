"""Authentication and authorization bypass playbook."""

from __future__ import annotations

from mcpfang.agents.base import BasePlaybook
from mcpfang.agents.context import AttackContext
from mcpfang.playbooks.registry import register_playbook
from mcpfang.reporting.models import Finding, Severity, FindingCategory


@register_playbook
class AuthBypassPlaybook(BasePlaybook):
    name = "auth_bypass"
    category = "auth_bypass"
    severity_default = "critical"
    cwe_ids = ["CWE-306", "CWE-862", "CWE-863"]
    description = "Tests for missing authentication and authorization bypass in tools"

    def get_system_prompt(self, context: AttackContext) -> str:
        return f"""You are an expert security researcher performing a penetration test on an MCP server.
Your goal is to find AUTHENTICATION and AUTHORIZATION BYPASS vulnerabilities.

{context.domain_context}

Available tools on the target server:
{context.tools_summary}

## Attack Strategy (OWASP MCP07:2025)

### Phase 1: Test missing authentication
Call tools that should require authentication without providing any credentials:
- Tools that return sensitive data without auth tokens
- Tools that perform privileged actions without identity verification
- Admin/management tools accessible without elevated privileges
- MCP servers often have NO default authentication — test every tool

### Phase 2: Test IDOR (Insecure Direct Object Reference)
Try accessing resources belonging to other users:
- Change user IDs, order IDs, or other identifiers
- Try sequential/predictable IDs: id=1, id=2, id=3
- Try UUID manipulation if applicable
- Access resources by changing owner references

### Phase 3: Test privilege escalation
- Call admin tools as a regular user
- Modify role/permission parameters in requests
- Try to access management/config endpoints
- Add "admin=true", "role=admin", "privilege=root" to tool parameters
- Remove auth-related parameters to see if they're optional
- Try empty strings, null values for auth fields

### Phase 4: Test token/credential weaknesses (OWASP MCP01 overlap)
- Check if tools expose API keys, tokens, or credentials in responses
- Look for tokens in error messages or debug output
- Test if tools accept and process expired or malformed tokens
- Check for hard-coded shared secrets in tool responses
- Try "Authorization: Bearer invalid" style headers in parameters

### Phase 5: Test cross-agent impersonation (MCP07 specific)
In MCP ecosystems with multiple agents:
- Try to call tools using different agent identifiers
- Test if caller identity metadata is validated server-side
- Check if one agent can inherit another agent's credentials via shared context
- Look for spoofable identity fields in tool parameters

### Phase 6: Test cross-user data access
- Read other users' data (profiles, orders, messages)
- Modify other users' resources
- Delete other users' resources
- Access data with different session/tenant identifiers

Verify each finding by attempting the action and observing the response.
A tool returning data without authentication is a CRITICAL finding."""

    def get_initial_message(self, context: AttackContext) -> str:
        tool_names = [t.name for t in context.discovery.tools]
        return (
            f"Begin your authentication and authorization assessment. "
            f"The target has these tools: {', '.join(tool_names)}. "
            f"Start by calling tools without any authentication to test for missing auth, "
            f"then test IDOR and privilege escalation."
        )

    def parse_findings(self, agent_output: str) -> list[Finding]:
        findings = []
        auth_indicators = [
            "without authentication", "no auth", "unauthorized access",
            "idor", "insecure direct", "privilege escalation",
            "missing authentication", "bypass", "access control",
            "other user", "admin access", "no authorization",
        ]
        output_lower = agent_output.lower()
        if any(indicator in output_lower for indicator in auth_indicators):
            findings.append(Finding(
                id="AUT-001",
                title="Potential authentication/authorization bypass",
                description="The agent detected missing or bypassable authentication controls.",
                severity=Severity.CRITICAL,
                category=FindingCategory.AUTH_BYPASS,
                tool_name="unknown",
                playbook=self.name,
                cwe_ids=self.cwe_ids,
                raw_output=agent_output,
            ))
        return findings
