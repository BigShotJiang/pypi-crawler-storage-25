"""Hidden surface discovery — probes MCP servers for undeclared capabilities.

Runs after standard discovery, before playbooks. Finds:
- Hidden tools not listed in tools/list
- Undocumented parameters on known tools
- Unlisted resources
- Non-standard JSON-RPC methods

Collects raw probe responses only. Evaluation is done by the unified
ResponseEvaluator (see analysis/evaluator.py).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from mcp import ClientSession

from mcpfang.reporting.models import (
    DiscoveryResult,
    Finding,
    FindingCategory,
    Severity,
    ToolInfo,
)

# Common tool names to brute-force
COMMON_TOOL_NAMES = [
    # Dangerous operations
    "exec", "execute", "run", "shell", "bash", "sh", "cmd", "command",
    "eval", "evaluate", "system", "spawn", "popen",
    # Admin/debug
    "admin", "debug", "internal", "config", "configure", "settings",
    "manage", "management", "setup", "reset", "restart",
    # File operations
    "read_file", "write_file", "delete_file", "list_files",
    "read", "write", "delete", "remove", "mkdir", "rmdir",
    "upload", "download", "copy", "move",
    # Database
    "query", "sql", "execute_query", "raw_query", "db",
    "select", "insert", "update", "drop", "create_table",
    # Network
    "fetch", "request", "http", "curl", "wget", "connect",
    "send", "post", "get", "proxy",
    # Auth
    "login", "authenticate", "auth", "token", "api_key",
    "grant", "revoke", "impersonate", "sudo", "elevate",
    # Info leakage
    "env", "environment", "whoami", "info", "status",
    "version", "health", "metrics", "logs", "log",
    "list_tools", "list_users", "list_resources",
]


@dataclass
class RawProbe:
    """A single probe result before LLM evaluation."""

    probe_type: str  # "tool", "param", "resource", "method"
    name: str  # tool name, param name, URI, or method
    target_tool: str  # for param probes: the tool being tested; else same as name
    response_text: str
    param_value: str | None = None  # for param probes
    baseline_text: str | None = None  # for param probes: response without the param


@dataclass
class FuzzerResult:
    """Results from hidden surface discovery."""

    hidden_tools: list[ToolInfo] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)
    raw_probes: list[RawProbe] = field(default_factory=list)
    probes_sent: int = 0
    probes_responded: int = 0
    errors: list[str] = field(default_factory=list)  # logged exceptions


def _is_error_response(response: object) -> bool:
    """Check if an MCP response has the protocol-level isError flag set."""
    return getattr(response, "isError", False) is True


def _extract_response_text(response: object) -> str:
    """Extract text content from an MCP response object."""
    if hasattr(response, "content"):
        parts = []
        for block in response.content:
            if hasattr(block, "text"):
                parts.append(block.text)
        return "".join(parts)
    if hasattr(response, "contents"):
        parts = []
        for item in response.contents:
            if hasattr(item, "text"):
                parts.append(item.text)
        return "".join(parts)
    return str(response)


def _next_finding_id(result: FuzzerResult) -> str:
    """Generate the next sequential finding ID."""
    return f"FUZ-{len(result.findings) + 1:03d}"


async def _probe_tool_names(
    session: ClientSession,
    discovery: DiscoveryResult,
    result: FuzzerResult,
) -> None:
    """Try calling common tool names that weren't in tools/list."""
    known_names = {t.name.lower() for t in discovery.tools}

    for tool_name in COMMON_TOOL_NAMES:
        if tool_name.lower() in known_names:
            continue

        result.probes_sent += 1
        try:
            response = await session.call_tool(tool_name, {})

            # Skip error responses — "Tool not found", "Unknown tool" etc.
            # These are normal rejections, not hidden capabilities.
            if _is_error_response(response):
                continue

            result.probes_responded += 1
            response_text = _extract_response_text(response)

            # Store raw probe for later LLM evaluation
            result.raw_probes.append(RawProbe(
                probe_type="tool",
                name=tool_name,
                target_tool=tool_name,
                response_text=response_text[:500],
            ))

            # Still track as potential hidden tool (will be filtered after eval)
            result.hidden_tools.append(ToolInfo(
                name=tool_name,
                description=f"[HIDDEN] Responded to probe: {response_text[:200]}",
                input_schema={},
            ))
        except Exception as e:
            result.errors.append(f"tool_probe({tool_name}): {type(e).__name__}: {e}")


# Suspicious parameter names to inject into known tools
PROBE_PARAMS = [
    ("__debug", True),
    ("__admin", True),
    ("debug", True),
    ("admin", True),
    ("verbose", True),
    ("raw", True),
    ("unsafe", True),
    ("no_validate", True),
    ("skip_auth", True),
    ("internal", True),
    ("sudo", True),
    ("role", "admin"),
    ("privilege", "root"),
    ("mode", "debug"),
]


async def _probe_undocumented_params(
    session: ClientSession,
    discovery: DiscoveryResult,
    result: FuzzerResult,
) -> None:
    """Send undocumented parameters to known tools and check if they're accepted."""
    for tool in discovery.tools:
        schema_props = set(tool.input_schema.get("properties", {}).keys())
        required = tool.input_schema.get("required", [])

        # Build a minimal valid call with required params
        base_args: dict = {}
        for req_param in required:
            prop_info = tool.input_schema.get("properties", {}).get(req_param, {})
            ptype = prop_info.get("type", "string")
            if ptype == "string":
                base_args[req_param] = "test"
            elif ptype == "integer":
                base_args[req_param] = 1
            elif ptype == "boolean":
                base_args[req_param] = True
            elif ptype == "number":
                base_args[req_param] = 1.0
            else:
                base_args[req_param] = "test"

        # First, get a baseline response with just the required params
        try:
            baseline = await session.call_tool(tool.name, base_args)
            if _is_error_response(baseline):
                continue
            baseline_text = _extract_response_text(baseline)
        except Exception as e:
            result.errors.append(f"param_baseline({tool.name}): {type(e).__name__}: {e}")
            continue

        # Now try each probe param
        for param_name, param_value in PROBE_PARAMS:
            if param_name in schema_props:
                continue

            probe_args = {**base_args, param_name: param_value}
            result.probes_sent += 1

            try:
                response = await session.call_tool(tool.name, probe_args)
                if _is_error_response(response):
                    continue
                response_text = _extract_response_text(response)

                if response_text != baseline_text:
                    result.probes_responded += 1
                    result.raw_probes.append(RawProbe(
                        probe_type="param",
                        name=param_name,
                        target_tool=tool.name,
                        response_text=response_text[:500],
                        param_value=str(param_value),
                        baseline_text=baseline_text[:500] if baseline_text else None,
                    ))
            except Exception as e:
                result.errors.append(f"param_probe({tool.name}/{param_name}): {type(e).__name__}: {e}")


# Resource URIs to probe for unauthorized access
PROBE_RESOURCE_URIS = [
    # Filesystem
    "file:///etc/passwd",
    "file:///etc/shadow",
    "file:///etc/hosts",
    "file:///.env",
    "file:///proc/self/environ",
    "file:///proc/self/cmdline",
    # Internal
    "internal://config",
    "internal://secrets",
    "internal://credentials",
    "internal://env",
    "internal://users",
    "internal://admin",
    "internal://keys",
    "internal://tokens",
    # Admin
    "admin://settings",
    "admin://config",
    "admin://credentials",
    "admin://users",
    # Debug
    "debug://state",
    "debug://logs",
    "debug://config",
    # Config
    "config://database",
    "config://credentials",
    "config://secrets",
    "config://api-keys",
    # Private / secret
    "secret://keys",
    "secret://credentials",
    "private://data",
    "private://config",
]

# Non-standard JSON-RPC methods to probe
PROBE_METHODS = [
    "admin/list",
    "admin/config",
    "admin/users",
    "debug/tools",
    "debug/state",
    "debug/config",
    "internal/config",
    "internal/tools",
    "internal/env",
    "system/info",
    "system/env",
    "system/exec",
    "tools/hidden",
    "tools/all",
    "tools/internal",
    "resources/all",
    "resources/internal",
    "server/config",
    "server/restart",
    "server/debug",
]


# URIs whose response content may contain credentials or secrets —
# redact the response body in proof-of-concept output.
_SENSITIVE_URIS = {
    "file:///etc/shadow", "file:///.env", "file:///proc/self/environ",
    "internal://secrets", "internal://credentials", "internal://keys",
    "config://credentials", "config://database", "config://secrets",
    "secret://keys", "secret://credentials", "admin://credentials",
}


def _generate_dynamic_resource_probes(discovery: DiscoveryResult) -> list[str]:
    """Generate extra resource URIs based on discovered resource patterns.

    If the server has templated resources like notes://{user_id}, we try
    common values like admin, root, test, etc.
    """
    import re

    extra_uris: list[str] = []
    common_ids = ["admin", "root", "test", "user1", "system", "internal", "debug", "config"]

    for res in discovery.resources:
        uri = res.uri
        # Look for template patterns like {param}
        templates = re.findall(r"\{([^}]+)\}", uri)
        if templates:
            for value in common_ids:
                filled = uri
                for t in templates:
                    filled = filled.replace(f"{{{t}}}", value)
                extra_uris.append(filled)

    return extra_uris


async def _probe_resource_paths(
    session: ClientSession,
    discovery: DiscoveryResult,
    result: FuzzerResult,
) -> None:
    """Try reading resource URIs that weren't listed in resources/list."""
    known_uris = {r.uri.lower() for r in discovery.resources}

    # Combine static probes with dynamically generated ones
    all_uris = list(PROBE_RESOURCE_URIS) + _generate_dynamic_resource_probes(discovery)

    for uri in all_uris:
        if uri.lower() in known_uris:
            continue

        result.probes_sent += 1
        try:
            response = await session.read_resource(uri)
            result.probes_responded += 1

            response_text = _extract_response_text(response)

            # Redact response from sensitive URIs
            if uri in _SENSITIVE_URIS:
                stored_text = f"[REDACTED: {len(response_text)} bytes]"
            else:
                stored_text = response_text[:500]

            result.raw_probes.append(RawProbe(
                probe_type="resource",
                name=uri,
                target_tool="(resource)",
                response_text=stored_text,
            ))
        except Exception as e:
            result.errors.append(f"resource_probe({uri}): {type(e).__name__}: {e}")


async def _probe_methods(
    session: ClientSession,
    discovery: DiscoveryResult,
    result: FuzzerResult,
) -> None:
    """Try invoking non-standard JSON-RPC methods."""
    for method in PROBE_METHODS:
        result.probes_sent += 1
        try:
            response = await session.send_request(method, {})
            result.probes_responded += 1

            response_text = str(response)[:500]

            result.raw_probes.append(RawProbe(
                probe_type="method",
                name=method,
                target_tool="(method)",
                response_text=response_text,
            ))
        except Exception as e:
            result.errors.append(f"method_probe({method}): {type(e).__name__}: {e}")


def materialize_findings_without_llm(result: FuzzerResult) -> None:
    """Convert raw probes into findings without LLM evaluation (legacy behavior).

    Every probe that got a response becomes a finding.
    """
    for probe in result.raw_probes:
        fid = _next_finding_id(result)

        if probe.probe_type == "tool":
            result.findings.append(Finding(
                id=fid,
                title=f"Hidden tool discovered: '{probe.name}'",
                description=(
                    f"Tool '{probe.name}' is not listed in tools/list but responded "
                    f"to a direct call. This indicates the server has undeclared "
                    f"capabilities that bypass the tool discovery mechanism."
                ),
                severity=Severity.HIGH,
                category=FindingCategory.HIDDEN_SURFACE,
                tool_name=probe.name,
                playbook="fuzzer",
                cwe_ids=["CWE-912"],
                proof_of_concept=f"call_tool('{probe.name}', {{}}) -> {probe.response_text[:300]}",
                remediation=(
                    "Either list this tool in tools/list for transparency, "
                    "or remove its handler to prevent unauthorized access."
                ),
            ))
        elif probe.probe_type == "param":
            result.findings.append(Finding(
                id=fid,
                title=f"Undocumented parameter accepted: '{probe.name}' on '{probe.target_tool}'",
                description=(
                    f"Tool '{probe.target_tool}' accepted parameter '{probe.name}={probe.param_value}' "
                    f"which is not in its declared schema. The response differed from "
                    f"the baseline, indicating the parameter affects behavior."
                ),
                severity=Severity.MEDIUM,
                category=FindingCategory.HIDDEN_SURFACE,
                tool_name=probe.target_tool,
                playbook="fuzzer",
                cwe_ids=["CWE-912"],
                proof_of_concept=f"call_tool('{probe.target_tool}', {{{probe.name}: {probe.param_value}}}) -> {probe.response_text[:200]}",
                remediation=(
                    f"Document parameter '{probe.name}' in the tool schema, "
                    f"or reject unknown parameters with strict schema validation."
                ),
            ))
        elif probe.probe_type == "resource":
            result.findings.append(Finding(
                id=fid,
                title=f"Hidden resource accessible: '{probe.name}'",
                description=(
                    f"Resource '{probe.name}' is not listed in resources/list but returned "
                    f"content when accessed directly. This may expose sensitive data "
                    f"or internal configuration."
                ),
                severity=Severity.HIGH,
                category=FindingCategory.HIDDEN_SURFACE,
                tool_name="(resource)",
                playbook="fuzzer",
                cwe_ids=["CWE-200", "CWE-912"],
                proof_of_concept=f"read_resource('{probe.name}') -> {probe.response_text[:300]}",
                remediation=(
                    "Either list this resource in resources/list for transparency, "
                    "or restrict access to prevent unauthorized reading."
                ),
            ))
        elif probe.probe_type == "method":
            result.findings.append(Finding(
                id=fid,
                title=f"Non-standard method responded: '{probe.name}'",
                description=(
                    f"JSON-RPC method '{probe.name}' is not part of the MCP specification "
                    f"but returned a response. This indicates the server exposes "
                    f"undocumented functionality."
                ),
                severity=Severity.MEDIUM,
                category=FindingCategory.HIDDEN_SURFACE,
                tool_name="(method)",
                playbook="fuzzer",
                cwe_ids=["CWE-912"],
                proof_of_concept=f"send_request('{probe.name}', {{}}) -> {probe.response_text[:300]}",
                remediation=(
                    "Remove non-standard method handlers, or document them as "
                    "official server extensions."
                ),
            ))


def probes_to_candidates(
    result: FuzzerResult,
    discovery: DiscoveryResult,
) -> list:
    """Convert raw probes into EvaluationCandidate objects for the unified evaluator."""
    from mcpfang.reporting.models import EvaluationCandidate

    # Build tool lookup
    tool_lookup: dict[str, tuple[str, dict]] = {}
    for t in discovery.tools:
        tool_lookup[t.name.lower()] = (t.description, t.input_schema)

    candidates = []
    for probe in result.raw_probes:
        tool_desc, tool_schema = tool_lookup.get(probe.target_tool.lower(), ("", {}))

        if probe.probe_type == "tool":
            candidates.append(EvaluationCandidate(
                source="fuzzer",
                tool_name=probe.name,
                tool_description=tool_desc or "(undeclared tool — not in tools/list)",
                action=f"Called undeclared tool '{probe.name}' with empty arguments",
                arguments={},
                response=probe.response_text,
                claimed_severity="high",
                claimed_title=f"Hidden tool discovered: '{probe.name}'",
            ))
        elif probe.probe_type == "param":
            candidates.append(EvaluationCandidate(
                source="fuzzer",
                tool_name=probe.target_tool,
                tool_description=tool_desc,
                tool_schema=tool_schema,
                action=f"Injected undocumented parameter '{probe.name}={probe.param_value}' into tool '{probe.target_tool}'",
                arguments={probe.name: probe.param_value},
                response=probe.response_text,
                claimed_severity="medium",
                claimed_title=f"Undocumented parameter accepted: '{probe.name}' on '{probe.target_tool}'",
            ))
        elif probe.probe_type == "resource":
            candidates.append(EvaluationCandidate(
                source="fuzzer",
                tool_name="(resource)",
                tool_description="(unlisted resource URI)",
                action=f"Read unlisted resource URI '{probe.name}'",
                arguments={},
                response=probe.response_text,
                claimed_severity="high",
                claimed_title=f"Hidden resource accessible: '{probe.name}'",
            ))
        elif probe.probe_type == "method":
            candidates.append(EvaluationCandidate(
                source="fuzzer",
                tool_name="(method)",
                tool_description="(non-standard JSON-RPC method)",
                action=f"Called non-standard method '{probe.name}'",
                arguments={},
                response=probe.response_text,
                claimed_severity="medium",
                claimed_title=f"Non-standard method responded: '{probe.name}'",
            ))

    return candidates


async def run_fuzzer(
    session: ClientSession,
    discovery: DiscoveryResult,
) -> FuzzerResult:
    """Run all hidden surface probes against the MCP server.

    Collects raw probe responses. Evaluation is done later by the
    unified ResponseEvaluator (see analysis/evaluator.py).

    Only filters out protocol-level errors (isError=True).
    All other responses are stored as raw_probes for LLM evaluation.
    """
    result = FuzzerResult()

    await _probe_tool_names(session, discovery, result)
    await _probe_undocumented_params(session, discovery, result)
    await _probe_resource_paths(session, discovery, result)
    await _probe_methods(session, discovery, result)

    return result
