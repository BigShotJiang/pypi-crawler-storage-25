"""MCP server discovery and tool enumeration."""
