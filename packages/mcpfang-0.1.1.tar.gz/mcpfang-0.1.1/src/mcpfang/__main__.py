"""Allow running mcpfang as `python -m mcpfang`."""

from mcpfang.cli import app

app()
