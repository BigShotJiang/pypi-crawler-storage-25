"""LLM-based domain analysis — understands what the target MCP server does."""

from __future__ import annotations

import json
from dataclasses import dataclass, field

from mcpfang.providers.base import LLMProvider
from mcpfang.reporting.models import DiscoveryResult


@dataclass
class ToolAnalysis:
    """Per-tool understanding from domain analysis."""

    name: str
    purpose: str
    expected_behaviors: list[str] = field(default_factory=list)
    risk_surface: list[str] = field(default_factory=list)


@dataclass
class DomainReport:
    """Structured understanding of what the target MCP server does."""

    server_type: str = ""
    server_purpose: str = ""
    expected_behaviors: list[str] = field(default_factory=list)
    attack_surface: list[str] = field(default_factory=list)
    tool_analyses: list[ToolAnalysis] = field(default_factory=list)

    def format_for_prompt(self) -> str:
        """Format the full report for injection into playbook system prompts."""
        lines = [
            "## Target Server Context",
            f"Server Type: {self.server_type}",
            f"Purpose: {self.server_purpose}",
            "",
            "IMPORTANT — Expected Behaviors (DO NOT flag as vulnerability):",
        ]
        for b in self.expected_behaviors:
            lines.append(f"  - {b}")

        lines.append("")
        lines.append("Actual Attack Surface (focus your testing here):")
        for a in self.attack_surface:
            lines.append(f"  - {a}")

        lines.append("")
        lines.append("## Tool-Level Analysis")
        for ta in self.tool_analyses:
            expected = "; ".join(ta.expected_behaviors) if ta.expected_behaviors else "none noted"
            risk = "; ".join(ta.risk_surface) if ta.risk_surface else "none beyond intended purpose"
            lines.append(
                f"- {ta.name}: Purpose: {ta.purpose}. "
                f"Expected: {expected}. "
                f"Risk: {risk}."
            )

        return "\n".join(lines)

    def format_summary(self) -> str:
        """One-line summary for normal CLI output."""
        n_tools = len(self.tool_analyses)
        n_expected = sum(len(ta.expected_behaviors) for ta in self.tool_analyses) + len(self.expected_behaviors)
        n_risks = sum(len(ta.risk_surface) for ta in self.tool_analyses) + len(self.attack_surface)
        return f"{self.server_type} ({n_tools} tools, {n_expected} expected behaviors, {n_risks} risk surfaces)"


DOMAIN_ANALYSIS_PROMPT = """\
You are a security analyst preparing to test an MCP server. Before testing, \
you need to understand what this server does so you can distinguish between \
intended functionality and actual vulnerabilities.

Analyze the following MCP server tools and produce a structured assessment.

Tools discovered:
{tools_block}

{user_context_block}

Respond with ONLY valid JSON matching this structure (no markdown, no explanation):
{{
  "server_type": "short category, e.g. browser automation, database client, file manager, API gateway",
  "server_purpose": "one sentence describing what this server is for",
  "expected_behaviors": ["behavior that is INTENDED and should NOT be flagged as vulnerability", ...],
  "attack_surface": ["genuine security risk beyond the tool's intended purpose", ...],
  "tool_analyses": [
    {{
      "name": "tool_name",
      "purpose": "what this tool is designed to do",
      "expected_behaviors": ["behavior that is this tool's core job and NOT a vulnerability"],
      "risk_surface": ["actual security risk for this specific tool, if any"]
    }}
  ]
}}

Guidelines:
- server_type: short category (browser automation, database client, file manager, etc.)
- expected_behaviors: things the server is DESIGNED to do — NOT vulnerabilities
- attack_surface: genuine risks BEYOND the tool's intended purpose (e.g. unsanitized filename params, path traversal, SSRF via server-side fetch)
- For each tool, clearly separate "what it's supposed to do" from "what could be exploited"
- A browser automation tool executing JavaScript is expected. That same tool writing to arbitrary filesystem paths via a filename param is a risk.
- Include ALL tools in tool_analyses, even if they have no risk surface
"""


async def run_domain_analysis(
    discovery: DiscoveryResult,
    provider: LLMProvider,
    user_domain: str = "",
    user_sensitive_data: list[str] | None = None,
    user_business_rules: list[str] | None = None,
) -> DomainReport:
    """Run LLM-based domain analysis on discovered tools.

    Returns a DomainReport with server-level and per-tool understanding.
    """
    # Build tools block with full schemas
    tool_lines = []
    for tool in discovery.tools:
        schema_str = json.dumps(tool.input_schema, indent=2) if tool.input_schema else "{}"
        tool_lines.append(
            f"Tool: {tool.name}\n"
            f"Description: {tool.description}\n"
            f"Schema: {schema_str}\n---"
        )
    tools_block = "\n".join(tool_lines)

    # Build user context hints
    user_parts = []
    if user_domain:
        user_parts.append(f"User says this server's domain is: {user_domain}")
    if user_sensitive_data:
        user_parts.append(f"Sensitive data types to protect: {', '.join(user_sensitive_data)}")
    if user_business_rules:
        user_parts.append("Business rules:")
        for rule in user_business_rules:
            user_parts.append(f"  - {rule}")

    user_context_block = ""
    if user_parts:
        user_context_block = "User-provided context (use as hints):\n" + "\n".join(user_parts)

    prompt = DOMAIN_ANALYSIS_PROMPT.format(
        tools_block=tools_block,
        user_context_block=user_context_block,
    )

    messages = [
        {"role": "user", "content": prompt},
    ]

    raw = await provider.complete(messages)
    return _parse_domain_report(raw)


def _parse_domain_report(raw: str) -> DomainReport:
    """Parse LLM response into DomainReport. Handles JSON in markdown fences."""
    # Strip markdown code fences if present
    text = raw.strip()
    if text.startswith("```"):
        # Remove first line (```json or ```)
        first_newline = text.index("\n")
        text = text[first_newline + 1:]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        # Fallback: return a minimal report
        return DomainReport(
            server_type="unknown",
            server_purpose="Could not determine server purpose from tool analysis",
            attack_surface=["All tools should be tested — domain analysis failed"],
        )

    tool_analyses = []
    for ta in data.get("tool_analyses", []):
        tool_analyses.append(ToolAnalysis(
            name=ta.get("name", ""),
            purpose=ta.get("purpose", ""),
            expected_behaviors=ta.get("expected_behaviors", []),
            risk_surface=ta.get("risk_surface", []),
        ))

    return DomainReport(
        server_type=data.get("server_type", "unknown"),
        server_purpose=data.get("server_purpose", ""),
        expected_behaviors=data.get("expected_behaviors", []),
        attack_surface=data.get("attack_surface", []),
        tool_analyses=tool_analyses,
    )
