"""Unified Response Evaluator — LLM-based validation of all candidate findings.

Receives candidates from both fuzzer probes and playbook attacks.
Uses domain context + tool descriptions + actual response data to
determine if each candidate is a real finding, false positive, or needs review.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field

from mcpfang.analysis.domain import DomainReport
from mcpfang.providers.base import LLMProvider
from mcpfang.reporting.models import (
    DiscoveryResult,
    EvaluationCandidate,
    EvaluationVerdict,
    TokenUsage,
)

_BATCH_SIZE = 15  # candidates per LLM call — smaller for better reasoning quality

_EVALUATOR_SYSTEM_PROMPT = """\
You are a senior security analyst performing the final validation step of an MCP server security scan.

You will receive candidate findings from automated probes and AI-driven attack playbooks. \
Your job is to determine which candidates represent REAL security vulnerabilities \
and which are false positives, using the server context provided.

## Server Context
{domain_context}

CRITICAL: The "Expected Behaviors" above describe what the tool IS DESIGNED TO DO (e.g. "retrieves documents"). \
They do NOT mean the content returned is safe. A document retrieval tool is expected to return documents — \
but if the document content contains injection attacks, hidden instructions, or leaked secrets, \
that IS a vulnerability in the content/data, not in the tool's behavior. \
Expected behaviors describe the FUNCTION, not the CONTENT.

## Candidate Sources

Candidates come from two sources:
1. **Fuzzer probes** (source="fuzzer"): Automated probes that called undeclared tools, injected params, etc. \
   The RESPONSE field shows what the server returned. Judge based on the response content.
2. **Playbook attacks** (source=playbook name): An AI security researcher tested the tool through \
   multi-step interactions and reported a finding with evidence. The RESPONSE field contains: \
   the agent's detailed finding description, proof-of-concept, and remediation suggestion. \
   \
   CRITICAL RULE FOR PLAYBOOK FINDINGS: \
   The attack agent ran a full multi-step conversation with the MCP server. It saw every tool response, \
   tried multiple payloads, and formed its assessment based on ALL evidence — not just what you see here. \
   You are seeing a SUMMARY. Treat the agent's analysis as expert testimony. \
   \
   → If the agent describes finding injection markers, hidden instructions, credential exposure, \
     or any specific vulnerability evidence: verdict = "confirmed". The agent SAW it happen. \
   → Only use "false_positive" for playbook findings if the agent's own description is \
     self-contradictory or clearly describes normal tool behavior (e.g. "tool returned a document" \
     with no mention of malicious content). \
   → When in doubt: "confirmed" or "needs_review", NEVER "false_positive".

## Evaluation Criteria

For each candidate, reason through these questions:
1. What is this tool SUPPOSED to do? (from TOOL PURPOSE, TOOL SCHEMA, and server context)
2. What was attempted? (the ATTACK action)
3. What did the tool respond? (the RESPONSE)
4. Does the TOOL SCHEMA support the claimed vulnerability? \
   Example: if agent claims "SQL injection" but the tool schema shows no database-related parameters \
   and the description mentions no database, the claim is likely a false positive.
5. For playbook findings: does the agent's analysis make sense given the evidence?
6. Does the response indicate the attack SUCCEEDED, or did the server handle it correctly?

### Verdict Definitions

**confirmed** — The response proves a real security vulnerability:
- The tool executed something it should not have (command injection, file read outside scope)
- Sensitive data was exposed that should not be accessible
- Authentication/authorization was bypassed
- The tool accepted input that violated its declared schema in a dangerous way
- A hidden capability was discovered that returns real data (not an error)
- A playbook agent provided coherent evidence of a vulnerability (e.g. prompt injection markers found in content, embedded instructions in tool output)

**false_positive** — The response does NOT indicate a vulnerability:
- The server returned an error message rejecting the probe ("Unknown tool", "not found", "invalid", "error")
- The tool correctly validated and rejected malicious input
- A parameter was accepted but the response shows no behavioral change or security impact
- For fuzzer probes: the server just echoed an error, didn't execute anything

IMPORTANT: Do NOT classify as false_positive just because a tool "returned content as expected." \
The vulnerability may be IN the content (e.g. prompt injection markers, embedded instructions, \
sensitive data in responses). A document retrieval tool returning documents is expected — but if \
those documents contain injection attacks or leak secrets, that IS a real finding.

**needs_review** — Ambiguous, cannot determine with certainty:
- The response is unusual but not clearly exploitable
- Partial success that may or may not have security implications
- Use this sparingly — prefer confirmed or false_positive when possible

### Severity Assessment (for confirmed/needs_review)
- critical: RCE, credential exposure, full system access, arbitrary file write
- high: significant data exposure, privilege escalation, hidden dangerous tool that works
- medium: information disclosure, parameter injection with behavioral change
- low: minor info leak, cosmetic issue
- info: worth noting but minimal impact

## Response Format

Respond with ONLY a JSON array. Each element:
```json
{{
  "index": 0,
  "verdict": "confirmed|false_positive|needs_review",
  "severity": "critical|high|medium|low|info",
  "reasoning": "2-3 sentences explaining WHY this verdict, referencing the tool's purpose and the actual response",
  "refined_title": "improved title if the original was inaccurate (or empty string to keep original)"
}}
```

You may batch false_positives with a range:
```json
{{"index": -1, "verdict": "false_positive", "range": [0, 5], "reasoning": "All returned error messages.", "severity": "info", "refined_title": ""}}
```

Be precise. A finding with high precision is worth more than many noisy findings. \
But do not dismiss real vulnerabilities — recall matters too.\
"""


def _build_domain_context(domain_report: DomainReport | None) -> str:
    """Build domain context string for the evaluator prompt."""
    if domain_report:
        return domain_report.format_for_prompt()
    return (
        "No domain analysis available. Evaluate each candidate on its own merits.\n"
        "Be conservative — when unsure, lean toward needs_review rather than false_positive."
    )


def _build_candidates_block(candidates: list[EvaluationCandidate], offset: int) -> str:
    """Format candidates for the evaluator prompt."""
    blocks = []
    for i, c in enumerate(candidates):
        blocks.append(f"[{i + offset}] {c.to_prompt_block()}")
    return "\n\n---\n\n".join(blocks)


def _parse_verdicts(raw_response: str) -> list[dict]:
    """Parse LLM evaluation response, expanding range shortcuts."""
    text = raw_response.strip()
    if text.startswith("```"):
        first_newline = text.index("\n")
        last_fence = text.rindex("```")
        text = text[first_newline + 1:last_fence].strip()

    raw_verdicts = json.loads(text)
    expanded: list[dict] = []

    for v in raw_verdicts:
        if "range" in v:
            r = v["range"]
            if isinstance(r, list) and len(r) == 2:
                for i in range(r[0], r[1] + 1):
                    expanded.append({**v, "index": i})
                continue
        expanded.append(v)

    return expanded


async def _evaluate_batch(
    candidates: list[EvaluationCandidate],
    offset: int,
    domain_context: str,
    provider: LLMProvider,
) -> list[EvaluationVerdict]:
    """Evaluate a single batch of candidates. Returns one verdict per candidate."""
    candidates_block = _build_candidates_block(candidates, offset)
    system_prompt = _EVALUATOR_SYSTEM_PROMPT.format(domain_context=domain_context)

    messages = [
        {"role": "system", "content": system_prompt},
        {
            "role": "user",
            "content": (
                f"Evaluate these {len(candidates)} candidate findings:\n\n"
                f"{candidates_block}"
            ),
        },
    ]

    raw_response = await provider.complete(messages)
    raw_verdicts = _parse_verdicts(raw_response)

    # Build verdict map indexed by global position
    verdict_map: dict[int, dict] = {}
    for v in raw_verdicts:
        idx = v.get("index", -1)
        if idx >= 0:
            verdict_map[idx] = v

    # Convert to EvaluationVerdict objects, one per candidate
    results: list[EvaluationVerdict] = []
    for i, _candidate in enumerate(candidates):
        global_idx = i + offset
        if global_idx in verdict_map:
            v = verdict_map[global_idx]
            results.append(EvaluationVerdict(
                verdict=v.get("verdict", "needs_review"),
                severity=v.get("severity", "medium"),
                reasoning=v.get("reasoning", ""),
                refined_title=v.get("refined_title", ""),
            ))
        else:
            # No verdict from LLM — default to needs_review (don't drop, don't auto-confirm)
            results.append(EvaluationVerdict(
                verdict="needs_review",
                severity="info",
                reasoning="No verdict returned by evaluator — flagged for manual review.",
            ))

    return results


async def evaluate_candidates(
    candidates: list[EvaluationCandidate],
    provider: LLMProvider,
    domain_report: DomainReport | None = None,
) -> tuple[list[EvaluationVerdict], TokenUsage]:
    """Evaluate all candidate findings using LLM reasoning with domain context.

    Returns (verdicts, token_usage) — verdicts in same order as input.
    """
    if not candidates:
        return [], TokenUsage()

    domain_context = _build_domain_context(domain_report)
    tokens = TokenUsage()

    all_verdicts: list[EvaluationVerdict] = []
    for batch_start in range(0, len(candidates), _BATCH_SIZE):
        batch = candidates[batch_start:batch_start + _BATCH_SIZE]
        verdicts = await _evaluate_batch(batch, batch_start, domain_context, provider)
        tokens += provider.last_usage
        all_verdicts.extend(verdicts)

    return all_verdicts, tokens


_DEDUP_SYSTEM_PROMPT = """\
You are deduplicating security scan findings for a SINGLE MCP tool.

These findings were produced by multiple independent scan modules that ran different \
attack strategies against the same tool. Many findings describe the same underlying \
vulnerability with different wording.

Your job: identify the UNIQUE vulnerabilities and discard duplicates.

Two findings are duplicates if they describe the same root cause, even if:
- The wording or title is slightly different
- The severity differs (keep the highest)
- They were found by different scan modules
- One describes it as "no auth" and another as "missing access control" (same thing)
- One says "enumeration" and another says "information disclosure" for the same behavior

Two findings are NOT duplicates if:
- They describe fundamentally different vulnerability types (e.g. injection vs auth bypass)
- They exploit different parameters or behaviors of the tool

For each unique vulnerability, output one JSON object with:
- "keep": index of the best representative finding
- "duplicates": list of indices that are duplicates of this one
- "merged_title": a clear, concise title for this vulnerability
- "severity": highest severity in the group

Respond with a JSON array. Every index must appear exactly once. \
Respond ONLY with the JSON array (no markdown fences, no explanation).\
"""


async def _dedup_tool_group(
    findings: list,
    tool_name: str,
    tool_description: str,
    provider: LLMProvider,
) -> tuple[list, TokenUsage]:
    """Deduplicate findings for a single tool using LLM reasoning."""
    from mcpfang.reporting.models import Severity

    if len(findings) <= 1:
        return list(findings), TokenUsage()

    lines = []
    for i, f in enumerate(findings):
        lines.append(
            f"[{i}] [{f.severity.value}] {f.title}\n"
            f"    {f.description[:300]}"
        )
    findings_block = "\n\n".join(lines)

    tool_context = f"Tool: {tool_name}"
    if tool_description:
        tool_context += f"\nPurpose: {tool_description}"

    messages = [
        {"role": "system", "content": _DEDUP_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                f"{tool_context}\n\n"
                f"Deduplicate these {len(findings)} findings:\n\n"
                f"{findings_block}"
            ),
        },
    ]

    try:
        raw = await provider.complete(messages)
        tokens = TokenUsage(provider.last_usage.input_tokens, provider.last_usage.output_tokens)

        text = raw.strip()
        if text.startswith("```"):
            first_nl = text.index("\n")
            last_fence = text.rindex("```")
            text = text[first_nl + 1:last_fence].strip()

        groups = json.loads(text)

        result = []
        for group in groups:
            keep_idx = group.get("keep", -1)
            if keep_idx < 0 or keep_idx >= len(findings):
                continue
            kept = findings[keep_idx]
            if group.get("merged_title"):
                kept.title = group["merged_title"]
            sev_str = group.get("severity", kept.severity.value)
            try:
                kept.severity = Severity(sev_str)
            except ValueError:
                pass
            result.append(kept)

        return (result if result else list(findings)), tokens

    except Exception:
        return list(findings), TokenUsage()


async def deduplicate_findings(
    findings: list,
    provider: LLMProvider,
    discovery: DiscoveryResult | None = None,
) -> tuple[list, TokenUsage]:
    """Deduplicate findings by running LLM dedup per-tool, then cross-tool.

    Splitting by tool gives the LLM smaller, focused batches and better context.
    Returns (deduplicated_findings, token_usage).
    """
    if len(findings) <= 1:
        return list(findings), TokenUsage()

    # Build tool description lookup
    tool_descs: dict[str, str] = {}
    if discovery:
        for t in discovery.tools:
            tool_descs[t.name] = t.description

    # Group findings by tool
    by_tool: dict[str, list] = {}
    for f in findings:
        by_tool.setdefault(f.tool_name, []).append(f)

    total_tokens = TokenUsage()
    deduped: list = []

    for tool_name, tool_findings in by_tool.items():
        result, tokens = await _dedup_tool_group(
            tool_findings,
            tool_name,
            tool_descs.get(tool_name, ""),
            provider,
        )
        total_tokens += tokens
        deduped.extend(result)

    # Cross-tool dedup pass if we still have many findings
    if len(deduped) > 15:
        result, tokens = await _dedup_tool_group(
            deduped, "(all tools)", "Cross-tool dedup pass", provider,
        )
        total_tokens += tokens
        deduped = result

    return deduped, total_tokens
