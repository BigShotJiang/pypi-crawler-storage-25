"""Static and semantic analysis modules."""
