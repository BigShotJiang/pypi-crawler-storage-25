"""Static analysis — pattern-based detection without LLM calls.

Detects tool poisoning, hidden unicode characters, schema issues,
and suspicious patterns in tool definitions.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

from mcpfang.reporting.models import (
    DiscoveryResult,
    Finding,
    FindingCategory,
    Severity,
    ToolInfo,
)

# Suspicious instruction patterns in tool descriptions
INSTRUCTION_PATTERNS = [
    (r"(?i)send\s+(the\s+)?(user'?s?|api|auth|secret|token|key|password|credential)", "Data exfiltration instruction"),
    (r"(?i)always\s+(include|add|append|send|forward)", "Hidden mandatory instruction"),
    (r"(?i)before\s+(using|calling|running)\s+this\s+tool", "Pre-execution instruction"),
    (r"(?i)after\s+(using|calling|running)\s+this\s+tool", "Post-execution instruction"),
    (r"(?i)(ignore|disregard|override)\s+(previous|prior|other|all)\s+(instructions?|rules?|prompts?)", "Prompt injection attempt"),
    (r"(?i)do\s+not\s+(tell|inform|show|reveal|mention)", "Concealment instruction"),
    (r"(?i)(secretly|silently|quietly|without\s+(the\s+)?user)", "Stealth action instruction"),
    (r"(?i)call\s+(the\s+)?tool\s+[\w]+\s+(with|using)", "Cross-tool manipulation"),
    (r"(?i)(admin|root|sudo|superuser|elevated)\s+(access|privilege|permission)", "Privilege escalation hint"),
    (r"(?i)base64\s*(encode|decode|encoded)", "Encoding obfuscation"),
    # Context injection patterns (OWASP MCP10)
    (r"(?i)(include|add|append|attach)\s+.*(context|history|conversation|session|previous)", "Context data exfiltration instruction"),
    (r"(?i)(remember|store|save|persist)\s+(this|these|the)\s+(instruction|directive|rule)", "Persistent context manipulation"),
    (r"(?i)(previous|prior|earlier)\s+(tool|response|result|output)", "Cross-tool context reference"),
    # Authority impersonation (Invariant Labs research)
    (r"(?i)(compliance|regulation|audit|security\s+requirement)\s+.*(require|demand|mandate)", "False authority impersonation"),
    (r"(?i)\[SYSTEM\s*(OVERRIDE|UPDATE|DIRECTIVE)\]", "System authority impersonation"),
    (r"(?i)UPDATED\s+INSTRUCTIONS|NEW\s+(PROTOCOL|DIRECTIVE|POLICY)", "Instruction override attempt"),
    # Real-world attack patterns (Invariant Labs / Trail of Bits)
    (r"<IMPORTANT>", "Hidden instruction block (Invariant Labs pattern)"),
    (r"(?i)read\s+.*\.(env|ssh|key|pem|credentials)", "Credential file access instruction"),
    (r"(?i)(must|should)\s+not\s+be\s+(skipped|mentioned|disclosed)", "Anti-detection concealment"),
]

# Dangerous Unicode categories and specific codepoints
SUSPICIOUS_UNICODE = {
    "\u200b": "Zero-width space",
    "\u200c": "Zero-width non-joiner",
    "\u200d": "Zero-width joiner",
    "\u200e": "Left-to-right mark",
    "\u200f": "Right-to-left mark",
    "\u202a": "Left-to-right embedding",
    "\u202b": "Right-to-left embedding",
    "\u202c": "Pop directional formatting",
    "\u202d": "Left-to-right override",
    "\u202e": "Right-to-left override",
    "\u2060": "Word joiner",
    "\u2061": "Function application",
    "\u2062": "Invisible times",
    "\u2063": "Invisible separator",
    "\u2064": "Invisible plus",
    "\ufeff": "BOM / Zero-width no-break space",
    "\ufff9": "Interlinear annotation anchor",
    "\ufffa": "Interlinear annotation separator",
    "\ufffb": "Interlinear annotation terminator",
}

# Homoglyph pairs (Latin vs Cyrillic, etc.)
HOMOGLYPHS = {
    "\u0410": ("A", "Cyrillic A"),
    "\u0412": ("B", "Cyrillic Ve"),
    "\u0421": ("C", "Cyrillic Es"),
    "\u0415": ("E", "Cyrillic Ie"),
    "\u041d": ("H", "Cyrillic En"),
    "\u041a": ("K", "Cyrillic Ka"),
    "\u041c": ("M", "Cyrillic Em"),
    "\u041e": ("O", "Cyrillic O"),
    "\u0420": ("P", "Cyrillic Er"),
    "\u0422": ("T", "Cyrillic Te"),
    "\u0425": ("X", "Cyrillic Kha"),
    "\u0430": ("a", "Cyrillic a"),
    "\u0435": ("e", "Cyrillic ie"),
    "\u043e": ("o", "Cyrillic o"),
    "\u0440": ("p", "Cyrillic er"),
    "\u0441": ("c", "Cyrillic es"),
    "\u0443": ("y", "Cyrillic u"),
    "\u0445": ("x", "Cyrillic kha"),
}


@dataclass
class StaticAnalysisResult:
    """Results from static analysis of MCP server definitions."""

    findings: list[Finding] = field(default_factory=list)
    tools_analyzed: int = 0


def run_static_analysis(discovery: DiscoveryResult) -> StaticAnalysisResult:
    """Run all static analysis checks on discovered tools and resources."""
    result = StaticAnalysisResult(tools_analyzed=len(discovery.tools))
    finding_counter = 0

    for tool in discovery.tools:
        # Check tool description for hidden instructions
        for pattern, description in INSTRUCTION_PATTERNS:
            if re.search(pattern, tool.description):
                finding_counter += 1
                result.findings.append(Finding(
                    id=f"STA-{finding_counter:03d}",
                    title=f"Suspicious pattern: {description}",
                    description=(
                        f"Tool '{tool.name}' description contains a pattern matching "
                        f"'{description}'. This may indicate tool poisoning or "
                        f"hidden instructions targeting AI agents."
                    ),
                    severity=Severity.HIGH,
                    category=FindingCategory.TOOL_POISONING,
                    tool_name=tool.name,
                    playbook="static_analysis",
                    cwe_ids=["CWE-94"],
                    proof_of_concept=f"Pattern: {pattern}",
                    remediation="Review and sanitize tool description. Remove any instructions targeting AI models.",
                ))

        # Check for hidden unicode characters
        hidden_chars = _find_hidden_unicode(tool.description)
        if hidden_chars:
            finding_counter += 1
            chars_detail = ", ".join(
                f"U+{ord(c):04X} ({name})" for c, name in hidden_chars
            )
            result.findings.append(Finding(
                id=f"STA-{finding_counter:03d}",
                title=f"Hidden Unicode characters in tool description",
                description=(
                    f"Tool '{tool.name}' description contains invisible/control "
                    f"Unicode characters: {chars_detail}. These can hide text from "
                    f"human reviewers while being processed by AI models."
                ),
                severity=Severity.CRITICAL,
                category=FindingCategory.TOOL_POISONING,
                tool_name=tool.name,
                playbook="static_analysis",
                cwe_ids=["CWE-116"],
                remediation="Remove all invisible Unicode characters from tool descriptions.",
            ))

        # Check for homoglyphs
        homoglyphs = _find_homoglyphs(tool.name)
        if homoglyphs:
            finding_counter += 1
            detail = ", ".join(
                f"'{c}' looks like '{latin}' but is {name}"
                for c, latin, name in homoglyphs
            )
            result.findings.append(Finding(
                id=f"STA-{finding_counter:03d}",
                title=f"Homoglyph characters in tool name",
                description=(
                    f"Tool name '{tool.name}' contains characters that look like "
                    f"Latin letters but aren't: {detail}. This may be a shadowing "
                    f"attack to impersonate a legitimate tool."
                ),
                severity=Severity.CRITICAL,
                category=FindingCategory.TOOL_POISONING,
                tool_name=tool.name,
                playbook="static_analysis",
                cwe_ids=["CWE-1007"],
                remediation="Use only ASCII characters in tool names.",
            ))

        # Schema validation checks
        schema_findings = _check_schema(tool, finding_counter)
        for f in schema_findings:
            finding_counter += 1
            f.id = f"STA-{finding_counter:03d}"
        result.findings.extend(schema_findings)

    return result


def _find_hidden_unicode(text: str) -> list[tuple[str, str]]:
    """Find invisible/control Unicode characters in text."""
    found = []
    for char in text:
        if char in SUSPICIOUS_UNICODE:
            found.append((char, SUSPICIOUS_UNICODE[char]))
        elif unicodedata.category(char) in ("Cf", "Cc", "Co") and char not in ("\n", "\r", "\t"):
            found.append((char, f"Control character ({unicodedata.category(char)})"))
    return found


def _find_homoglyphs(text: str) -> list[tuple[str, str, str]]:
    """Find homoglyph characters that look like Latin but aren't."""
    found = []
    for char in text:
        if char in HOMOGLYPHS:
            latin, name = HOMOGLYPHS[char]
            found.append((char, latin, name))
    return found


def _check_schema(tool: ToolInfo, counter_start: int) -> list[Finding]:
    """Check tool input schema for suspicious patterns."""
    findings = []
    schema = tool.input_schema

    if not schema:
        return findings

    properties = schema.get("properties", {})
    required = schema.get("required", [])

    for param_name, param_info in properties.items():
        # Check for suspicious default values
        if "default" in param_info:
            default = str(param_info["default"])
            for pattern, desc in INSTRUCTION_PATTERNS:
                if re.search(pattern, default):
                    findings.append(Finding(
                        id="",  # Will be set by caller
                        title=f"Suspicious default value in '{param_name}'",
                        description=(
                            f"Tool '{tool.name}' parameter '{param_name}' has a "
                            f"default value containing a suspicious pattern: {desc}"
                        ),
                        severity=Severity.HIGH,
                        category=FindingCategory.TOOL_POISONING,
                        tool_name=tool.name,
                        playbook="static_analysis",
                        cwe_ids=["CWE-1188"],
                        proof_of_concept=f"Default value: {default[:200]}",
                        remediation="Review parameter defaults for hidden instructions.",
                    ))

        # Check for suspiciously described parameters
        param_desc = param_info.get("description", "")
        if param_desc:
            for pattern, desc in INSTRUCTION_PATTERNS:
                if re.search(pattern, param_desc):
                    findings.append(Finding(
                        id="",
                        title=f"Suspicious parameter description in '{param_name}'",
                        description=(
                            f"Tool '{tool.name}' parameter '{param_name}' description "
                            f"contains a suspicious pattern: {desc}"
                        ),
                        severity=Severity.HIGH,
                        category=FindingCategory.TOOL_POISONING,
                        tool_name=tool.name,
                        playbook="static_analysis",
                        cwe_ids=["CWE-94"],
                        remediation="Review and sanitize parameter descriptions.",
                    ))

    return findings
