#!/usr/bin/env bash
# Benchmark all vulnerable servers with Claude Opus 4.6
# Usage: bash scripts/benchmark_opus.sh

set -euo pipefail

MODEL="claude-opus-4-6"
OUTDIR="benchmarks/opus46"
COMMON="--provider anthropic --model $MODEL --max-steps 10 --output json"

mkdir -p "$OUTDIR"

DVMCP="C:/Users/pc/PycharmProjects/damn-vulnerable-MCP-server"
APPSECCO="C:/Users/pc/PycharmProjects/vulnerable-mcp-servers-lab"

echo "=== MCPFang Benchmark: Claude Opus 4.6 ==="
echo ""

# --- Start DVMCP SSE servers in background ---
echo "Starting DVMCP SSE servers..."
python "$DVMCP/challenges/easy/challenge1/server_sse.py" &>/dev/null &
PID_CH1=$!
python "$DVMCP/challenges/easy/challenge2/server_sse.py" &>/dev/null &
PID_CH2=$!
python "$DVMCP/challenges/easy/challenge3/server_sse.py" &>/dev/null &
PID_CH3=$!
sleep 5

cleanup() {
  kill $PID_CH1 $PID_CH2 $PID_CH3 2>/dev/null || true
}
trap cleanup EXIT

echo "DVMCP servers started (ports 9001-9003)"
echo ""

# 1. DVMCP Ch1 — Prompt Injection (SSE port 9001)
echo "[1/7] DVMCP Ch1 (Prompt Injection)..."
python -m mcpfang scan "http://localhost:9001/sse" \
  -t sse $COMMON --file "$OUTDIR/dvmcp-ch1.json" 2>&1 || true
echo "  Done."

# 2. DVMCP Ch2 — Tool Poisoning (SSE port 9002)
echo "[2/7] DVMCP Ch2 (Tool Poisoning)..."
python -m mcpfang scan "http://localhost:9002/sse" \
  -t sse $COMMON --file "$OUTDIR/dvmcp-ch2.json" 2>&1 || true
echo "  Done."

# 3. DVMCP Ch3 — Excessive Permissions (SSE port 9003)
echo "[3/7] DVMCP Ch3 (Excessive Permissions)..."
python -m mcpfang scan "http://localhost:9003/sse" \
  -t sse $COMMON --file "$OUTDIR/dvmcp-ch3.json" 2>&1 || true
echo "  Done."

# Kill DVMCP servers
kill $PID_CH1 $PID_CH2 $PID_CH3 2>/dev/null || true

# 4. Appsecco Malicious Tools (stdio)
echo "[4/7] Appsecco Malicious Tools..."
python -m mcpfang scan "node $APPSECCO/vulnerable-mcp-server-malicious-tools/index.js" \
  -t stdio $COMMON --file "$OUTDIR/appsecco-malicious.json" 2>&1 || true
echo "  Done."

# 5. Appsecco Prompt Injection (stdio)
echo "[5/7] Appsecco Prompt Injection..."
python -m mcpfang scan "node $APPSECCO/vulnerable-mcp-server-indirect-prompt-injection/index.js" \
  -t stdio $COMMON --file "$OUTDIR/appsecco-prompt.json" 2>&1 || true
echo "  Done."

# 6. Appsecco Secrets/PII (stdio)
echo "[6/7] Appsecco Secrets/PII..."
python -m mcpfang scan "node $APPSECCO/vulnerable-mcp-server-secrets-pii/index.js" \
  -t stdio $COMMON --file "$OUTDIR/appsecco-secrets.json" 2>&1 || true
echo "  Done."

# 7. server-everything (stdio)
echo "[7/7] server-everything..."
python -m mcpfang scan "npx -y @modelcontextprotocol/server-everything" \
  -t stdio $COMMON --file "$OUTDIR/server-everything.json" 2>&1 || true
echo "  Done."

echo ""
echo "=== All scans complete ==="
echo "Results in: $OUTDIR/"

# Summary
echo ""
echo "=== Results Summary ==="
python -c "
import json, os, glob

outdir = 'benchmarks/opus46'
for path in sorted(glob.glob(os.path.join(outdir, '*.json'))):
    if '.raw.' in path:
        continue
    name = os.path.basename(path).replace('.json', '')
    try:
        with open(path) as f:
            data = json.load(f)
        findings = data.get('total_findings', 0)
        tokens = data.get('token_usage', {}).get('total', {})
        inp = tokens.get('input_tokens', 0)
        out = tokens.get('output_tokens', 0)
        total = tokens.get('total_tokens', 0)
        print(f'{name:30s} | {findings:2d} findings | {inp:6d} in / {out:5d} out = {total:6d} tokens')
    except Exception as e:
        print(f'{name:30s} | ERROR: {e}')

# Raw counts
print()
for path in sorted(glob.glob(os.path.join(outdir, '*.raw.json'))):
    name = os.path.basename(path).replace('.raw.json', '')
    try:
        with open(path) as f:
            data = json.load(f)
        raw = data.get('total_findings', 0)
        print(f'{name:30s} | {raw:3d} raw findings')
    except Exception as e:
        print(f'{name:30s} | ERROR: {e}')
"
