"""Tests for hidden surface discovery fuzzer."""

from __future__ import annotations

import pytest

from mcpfang.discovery.fuzzer import (
    COMMON_TOOL_NAMES,
    FuzzerResult,
    PROBE_RESOURCE_URIS,
    _probe_tool_names,
    _probe_undocumented_params,
    _probe_resource_paths,
    _probe_methods,
    materialize_findings_without_llm,
    run_fuzzer,
)
from mcpfang.reporting.models import (
    DiscoveryResult,
    FindingCategory,
    Severity,
    ToolInfo,
)


class FakeSession:
    """Mock MCP session that responds to specific tool names."""

    def __init__(self, hidden_tools: set[str] | None = None) -> None:
        self.hidden_tools = hidden_tools or set()
        self.calls: list[tuple[str, dict]] = []

    async def call_tool(self, name: str, arguments: dict | None = None):
        self.calls.append((name, arguments or {}))
        if name in self.hidden_tools:
            return _make_result(f"executed {name}")
        raise Exception(f"Tool not found: {name}")


class _TextBlock:
    def __init__(self, text: str) -> None:
        self.text = text


class _CallResult:
    def __init__(self, content: list) -> None:
        self.content = content


def _make_result(text: str) -> _CallResult:
    return _CallResult([_TextBlock(text)])


@pytest.mark.asyncio
async def test_probe_tool_names_finds_hidden_tool():
    """Probe discovers a hidden tool not in the discovery result."""
    discovery = DiscoveryResult(
        endpoint="test://server",
        tools=[ToolInfo(name="read_file", description="Reads files", input_schema={})],
    )
    session = FakeSession(hidden_tools={"exec", "debug"})

    result = FuzzerResult()
    await _probe_tool_names(session, discovery, result)

    hidden_names = [t.name for t in result.hidden_tools]
    assert "exec" in hidden_names
    assert "debug" in hidden_names
    assert "read_file" not in hidden_names

    materialize_findings_without_llm(result)
    assert len(result.findings) >= 2
    for f in result.findings:
        assert f.category == FindingCategory.HIDDEN_SURFACE
        assert f.severity == Severity.HIGH


@pytest.mark.asyncio
async def test_probe_tool_names_skips_known_tools():
    """Already-discovered tools are not probed."""
    discovery = DiscoveryResult(
        endpoint="test://server",
        tools=[ToolInfo(name="exec", description="Execute", input_schema={})],
    )
    session = FakeSession(hidden_tools={"exec"})

    result = FuzzerResult()
    await _probe_tool_names(session, discovery, result)

    hidden_names = [t.name for t in result.hidden_tools]
    assert "exec" not in hidden_names


@pytest.mark.asyncio
async def test_probe_tool_names_no_false_positives():
    """When no hidden tools exist, result is empty."""
    discovery = DiscoveryResult(endpoint="test://server", tools=[])
    session = FakeSession(hidden_tools=set())

    result = FuzzerResult()
    await _probe_tool_names(session, discovery, result)

    assert len(result.hidden_tools) == 0
    assert len(result.findings) == 0


@pytest.mark.asyncio
async def test_probe_undocumented_params_finds_hidden_param():
    """Server accepts a parameter not in the schema."""
    discovery = DiscoveryResult(
        endpoint="test://server",
        tools=[ToolInfo(
            name="search",
            description="Search files",
            input_schema={
                "type": "object",
                "properties": {"query": {"type": "string"}},
                "required": ["query"],
            },
        )],
    )

    class ParamSession:
        async def call_tool(self, name, arguments=None):
            # Accepts __debug param without error
            if arguments and "__debug" in arguments:
                return _make_result("debug mode enabled")
            return _make_result("ok")

    session = ParamSession()
    result = FuzzerResult()
    await _probe_undocumented_params(session, discovery, result)

    materialize_findings_without_llm(result)
    # Should find at least one hidden param finding
    param_findings = [f for f in result.findings if "undocumented" in f.title.lower() or "parameter" in f.title.lower()]
    assert len(param_findings) >= 1


@pytest.mark.asyncio
async def test_probe_undocumented_params_no_false_positive():
    """Server rejects all unknown params — no findings."""
    discovery = DiscoveryResult(
        endpoint="test://server",
        tools=[ToolInfo(
            name="search",
            description="Search files",
            input_schema={
                "type": "object",
                "properties": {"query": {"type": "string"}},
            },
        )],
    )

    class StrictSession:
        async def call_tool(self, name, arguments=None):
            if arguments:
                known = {"query"}
                extra = set(arguments.keys()) - known
                if extra:
                    raise Exception(f"Unknown params: {extra}")
            return _make_result("ok")

    session = StrictSession()
    result = FuzzerResult()
    await _probe_undocumented_params(session, discovery, result)

    param_findings = [f for f in result.findings if "parameter" in f.title.lower()]
    assert len(param_findings) == 0


@pytest.mark.asyncio
async def test_probe_resource_paths_finds_hidden_resource():
    """Server responds to an unlisted resource URI."""
    discovery = DiscoveryResult(endpoint="test://server", tools=[])

    class ResourceSession:
        async def read_resource(self, uri):
            if str(uri) == "file:///etc/passwd":
                return _make_result("root:x:0:0:root:/root:/bin/bash")
            raise Exception("Not found")

    session = ResourceSession()
    result = FuzzerResult()
    await _probe_resource_paths(session, discovery, result)

    materialize_findings_without_llm(result)
    assert len(result.findings) >= 1
    assert any("etc/passwd" in f.proof_of_concept for f in result.findings)


@pytest.mark.asyncio
async def test_probe_resource_paths_no_false_positive():
    """Server rejects all probe URIs — no findings."""
    discovery = DiscoveryResult(endpoint="test://server", tools=[])

    class StrictResourceSession:
        async def read_resource(self, uri):
            raise Exception("Not found")

    session = StrictResourceSession()
    result = FuzzerResult()
    await _probe_resource_paths(session, discovery, result)

    assert len(result.findings) == 0


@pytest.mark.asyncio
async def test_probe_methods_finds_hidden_method():
    """Server responds to a non-standard JSON-RPC method."""
    discovery = DiscoveryResult(endpoint="test://server", tools=[])

    class MethodSession:
        async def send_request(self, method, params=None):
            if method == "admin/list":
                return {"users": ["admin"]}
            raise Exception("Method not found")

    session = MethodSession()
    result = FuzzerResult()
    await _probe_methods(session, discovery, result)

    materialize_findings_without_llm(result)
    assert len(result.findings) >= 1
    assert any("admin/list" in f.title for f in result.findings)


@pytest.mark.asyncio
async def test_probe_methods_no_false_positive():
    """Server rejects all non-standard methods."""
    discovery = DiscoveryResult(endpoint="test://server", tools=[])

    class StrictMethodSession:
        async def send_request(self, method, params=None):
            raise Exception("Method not found")

    session = StrictMethodSession()
    result = FuzzerResult()
    await _probe_methods(session, discovery, result)

    assert len(result.findings) == 0


@pytest.mark.asyncio
async def test_run_fuzzer_integrates_all_probes():
    """run_fuzzer calls all probe functions and returns combined results."""
    discovery = DiscoveryResult(
        endpoint="test://server",
        tools=[ToolInfo(name="search", description="Search", input_schema={})],
    )

    class IntegrationSession:
        async def call_tool(self, name, arguments=None):
            if name == "exec":
                return _make_result("hidden exec output")
            raise Exception("Not found")

        async def read_resource(self, uri):
            raise Exception("Not found")

        async def send_request(self, method, params=None):
            raise Exception("Not found")

    session = IntegrationSession()
    result = await run_fuzzer(session, discovery)

    assert isinstance(result, FuzzerResult)
    assert result.probes_sent > 0
    hidden_names = [t.name for t in result.hidden_tools]
    assert "exec" in hidden_names


@pytest.mark.asyncio
async def test_run_fuzzer_does_not_mutate_discovery():
    """run_fuzzer does not modify the original discovery result."""
    discovery = DiscoveryResult(
        endpoint="test://server",
        tools=[ToolInfo(name="read_file", description="Read", input_schema={})],
    )
    original_tool_count = len(discovery.tools)

    class HiddenToolSession:
        async def call_tool(self, name, arguments=None):
            if name == "shell":
                return _make_result("shell access")
            raise Exception("Not found")

        async def read_resource(self, uri):
            raise Exception("Not found")

        async def send_request(self, method, params=None):
            raise Exception("Not found")

    session = HiddenToolSession()
    result = await run_fuzzer(session, discovery)

    # Original discovery should NOT be mutated
    assert len(discovery.tools) == original_tool_count
    # But hidden_tools should contain the discovered tool
    assert any(t.name == "shell" for t in result.hidden_tools)
