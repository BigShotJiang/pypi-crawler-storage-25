"""
pymargins._adapters.lifelines_cox_timevarying

Concrete adapter for lifelines CoxTimeVaryingFitter on the survival-probability
scale.

Predicts survival probability at a fixed time using the fitted baseline
survival function:
    S(t|x) = S_0(t) ^ exp((X - X_mean) @ beta)

Uses WrappedFDAdapter because the baseline survival is a nonparametric
step function — no closed-form JAX expression. Finite-difference gradients
are hidden inside the JVP wrapper.

Delta-method SEs are INVALID for survival-probability estimands because they
ignore uncertainty in the estimated baseline hazard. Only bootstrap inference
is supported.
"""

from __future__ import annotations
from typing import Optional, Any
import jax.numpy as jnp
import numpy as np
import pandas as pd

from .._adapter import WrappedFDAdapter, VariableInfo
from ._common import (
    extract_training_data,
    design_matrix_from_df,
    column_index_of_variable,
    build_variable_metadata,
    validate_vcov_spec,
)


class LifelinesCoxTimeVaryingSurvivalAdapter(WrappedFDAdapter):
    """Adapter for lifelines CoxTimeVaryingFitter on the survival-probability scale.

    Predicts survival probability at a fixed time using the nonparametric
    baseline survival function:
        S(t|x) = S_0(t) ^ PH(x)

    Parameters
    ----------
    results : fitted lifelines CoxTimeVaryingFitter

    training_data : pd.DataFrame, optional
        The data the model was fit on.

    prediction_time : float, optional
        The time at which to evaluate survival probabilities.
        Defaults to the median observed event time.
    """

    def __init__(
        self,
        results,
        training_data: Optional[pd.DataFrame] = None,
        prediction_time: Optional[float] = None,
    ):
        self.results = results
        self._training_data = extract_training_data(results, training_data)
        self._exog_names = list(results.params_.index)
        self._x_mean = getattr(results, "_norm_mean", None)
        if self._x_mean is not None:
            self._x_mean = np.asarray(self._x_mean.values)

        self._id_col = getattr(results, "id_col", None)
        self._start_col = getattr(results, "start_col", None)
        self._stop_col = getattr(results, "stop_col", None)
        self._event_col = getattr(results, "event_col", None)

        if prediction_time is not None:
            self._prediction_time = float(prediction_time)
        else:
            self._prediction_time = self._compute_default_time(results)

        self._fd_step = 1e-6

    def _compute_default_time(self, results) -> float:
        """Use median observed event time as default."""
        # CoxTimeVaryingFitter stores durations via the stop times
        # We use the stop column from training data if available
        if self._training_data is not None and self._stop_col is not None:
            durations = self._training_data[self._stop_col]
        else:
            # Fallback: use baseline survival index
            bs = getattr(results, "baseline_survival_", None)
            if bs is not None and not bs.empty:
                return float(bs.index[len(bs) // 2])
            return 1.0

        events = results.event_observed
        observed_durations = durations[events]
        if len(observed_durations) == 0:
            return float(durations.median())
        return float(np.median(observed_durations))

    @property
    def training_data(self):
        return self._training_data

    @property
    def supported_inference_methods(self) -> set[str]:
        return {"bootstrap"}

    def attach(self, session) -> None:
        vcov = getattr(session, "vcov_spec", None)
        validate_vcov_spec(vcov, adapter_name="LifelinesCoxTimeVaryingSurvivalAdapter")
        super().attach(session)

    # -----------------------------------------------------------------------
    # Core data access
    # -----------------------------------------------------------------------

    def coefficients(self) -> jnp.ndarray:
        return jnp.asarray(self.results.params_.values)

    def covariance(self, vcov_spec: Optional[Any] = None) -> jnp.ndarray:
        if vcov_spec is None:
            return jnp.asarray(self.results.variance_matrix_.values)

        if isinstance(vcov_spec, (np.ndarray, jnp.ndarray)):
            return jnp.asarray(vcov_spec)

        raise ValueError(
            f"LifelinesCoxTimeVaryingSurvivalAdapter only supports vcov=None or ndarray. "
            f"Got {vcov_spec!r}"
        )

    # -----------------------------------------------------------------------
    # Prediction (via WrappedFDAdapter)
    # -----------------------------------------------------------------------

    def native_predict(self, beta_np: np.ndarray, X) -> np.ndarray:
        """Compute survival probability at prediction_time."""
        X_np = np.asarray(X)
        if self._x_mean is not None:
            X_np = X_np - self._x_mean
        ph = np.exp(X_np @ beta_np)
        S0_t = self._baseline_survival_at(self._prediction_time)
        return S0_t ** ph

    def _baseline_survival_at(self, t: float) -> float:
        """Look up baseline survival at time t.

        The baseline survival is a step function (piecewise constant).
        We return the survival value at the most recent observed event time
        <= t, which is the correct behavior for a Kaplan-Meier-style estimate.
        """
        S0_df = self.results.baseline_survival_
        if S0_df is None or S0_df.empty:
            raise ValueError("Baseline survival function not available on the fitted model.")
        col = S0_df.columns[0]
        times = S0_df.index.values
        surv = S0_df[col].values
        if times[0] > times[-1]:
            times = times[::-1]
            surv = surv[::-1]
        # Step function: find rightmost time <= t
        idx = np.searchsorted(times, t, side="right") - 1
        if idx < 0:
            return float(surv[0])
        return float(surv[idx])

    # -----------------------------------------------------------------------
    # Design matrix construction
    # -----------------------------------------------------------------------

    def design_matrix_from_df(self, df: pd.DataFrame) -> jnp.ndarray:
        missing_cols = [col for col in self._exog_names if col not in df.columns and col not in ("const", "Intercept")]
        if missing_cols:
            raise ValueError(
                f"Missing columns required by the model's exog_names: {missing_cols}. "
                f"Available columns: {list(df.columns)}."
            )
        aligned = df.reindex(columns=self._exog_names)
        return jnp.asarray(aligned.values)

    def column_index_of_variable(self, variable_name: str) -> int:
        return column_index_of_variable(
            self._exog_names, self.variable_metadata(), variable_name,
        )

    def variable_metadata(self) -> dict[str, VariableInfo]:
        if not hasattr(self, "_variable_metadata"):
            self._variable_metadata = build_variable_metadata(self.training_data)
        return self._variable_metadata

    # -----------------------------------------------------------------------
    # Bootstrap support
    # -----------------------------------------------------------------------

    def refit(self, resampled_data: pd.DataFrame, *, index=None) -> "LifelinesCoxTimeVaryingSurvivalAdapter":
        from lifelines import CoxTimeVaryingFitter

        df = resampled_data.reset_index(drop=True)
        kwargs = {
            "id_col": self._id_col,
            "start_col": self._start_col,
            "stop_col": self._stop_col,
            "event_col": self._event_col,
        }
        # Remove None values
        kwargs = {k: v for k, v in kwargs.items() if v is not None}

        ctor_kwargs = {}
        if hasattr(self.results, "penalizer") and self.results.penalizer is not None:
            ctor_kwargs["penalizer"] = self.results.penalizer
        new_fitter = CoxTimeVaryingFitter(**ctor_kwargs)
        new_fitter.fit(df, **kwargs)
        return LifelinesCoxTimeVaryingSurvivalAdapter(
            new_fitter,
            training_data=df,
            prediction_time=self._prediction_time,
        )
