"""
Claude Agent SDK fix adapter — uses native additionalContext injection.

The Claude Agent SDK's hook system supports:
- PreToolUse: modify tool inputs via updatedInput
- PostToolUse: inject additionalContext (additive, not replacement)

Model responses CANNOT be directly rewritten. The native approach is
injecting corrective context that guides the agent on the next turn.
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)


class ClaudeAgentSDKFixAdapter:
    """Applies fixes using Claude Agent SDK's native context injection.

    The SDK does not support response replacement. Instead, we inject
    corrective context via the additionalContext mechanism, which appends
    guidance to the conversation for the next model turn.

    For PostToolUse hooks, return:
        {"additionalContext": "correction guidance here"}
    """

    def apply_fix(self, fix_payload: dict[str, Any], context: Any) -> bool:
        fixed_output = fix_payload.get("fixed_output")
        guidance = fix_payload.get("guidance")

        if not context:
            return False

        correction = guidance or (
            f"Previous output needs correction: {fixed_output}" if fixed_output else None
        )
        if not correction:
            return False

        try:
            # Pattern 1: Hook response dict — add additionalContext (native API)
            if isinstance(context, dict):
                context["additionalContext"] = correction
                return True

            # Pattern 2: Message object — append to content blocks
            # Cannot replace content blocks, but can append guidance
            # This works when the SDK wrapper intercepts before the agent loop
            if hasattr(context, "content") and isinstance(context.content, list):
                for block in context.content:
                    if hasattr(block, "text"):
                        if fixed_output:
                            block.text = fixed_output
                        elif guidance:
                            block.text = f"{block.text}\n\n[Aigie: {guidance}]"
                        return True
        except Exception as e:
            logger.warning(f"Claude Agent SDK fix failed: {e}")
        return False


try:
    from ...realtime.fix_applicator import register_fix_adapter

    register_fix_adapter("claude_agent_sdk", ClaudeAgentSDKFixAdapter())
except ImportError:
    pass
