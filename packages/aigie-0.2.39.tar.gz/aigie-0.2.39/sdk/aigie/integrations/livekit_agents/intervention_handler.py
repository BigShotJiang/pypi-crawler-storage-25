"""
Intervention-only handler for LiveKit Agents (OTel mode).

This handler registers the same event hooks as LiveKitAgentsHandler but
creates ZERO traces or spans. All observability data comes from OTel.

This handler is responsible ONLY for:
- Tracking conversation state (turns, messages) for judge context
- Running InterceptorChain on assistant responses
- Running GuardrailChain for SLA enforcement
- Tracking VoiceMetrics for real-time SLA checks
- Applying fixes via LiveKitAgentsFixAdapter
- Mode control (OBSERVE vs AUTONOMOUS)
"""

import logging
from typing import TYPE_CHECKING, Any, Dict, List

from .cost_tracking import VoiceCostTracker
from .metrics import MetricsAggregator, VoiceMetrics
from .span_bridge import OTelSpanBridge

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    try:
        from livekit.agents import AgentSession
    except ImportError:
        pass


class LiveKitInterventionHandler:
    """
    Event handler that provides ONLY intervention capabilities.

    Used when telemetry_mode="otel" — OTel handles all trace/span
    creation, this handler handles judge, fix, guardrails, and mode control.
    """

    def __init__(self, config: Any | None = None):
        if config is None:
            from .config import LiveKitAgentsConfig

            config = LiveKitAgentsConfig.from_env()

        self.config = config
        self._span_bridge = OTelSpanBridge()

        # State tracking (for judge context — no span creation)
        self._agent_state: str | None = None
        self._user_state: str | None = None
        self._in_turn = False
        self._turn_count = 0
        self._turn_messages: List[Dict[str, str]] = []
        self._current_transcription = ""
        self._current_bot_response = ""

        # Metrics (for guardrail SLA checks)
        self._current_turn_metrics: VoiceMetrics | None = None
        self._metrics_aggregator = MetricsAggregator()
        self._cost_tracker = VoiceCostTracker()

        # Model info
        self._llm_model: str | None = None
        self._stt_model: str | None = None
        self._tts_model: str | None = None

        # Error tracking
        self._errors: List[Dict[str, Any]] = []

        # Intervention components (lazy-loaded)
        self._interceptor_chain = None
        self._guardrail_chain = None
        self._mode_controller = None
        self._aigie = None

    def _get_aigie(self):
        """Lazy load Aigie client."""
        if self._aigie is None:
            from ...client import get_aigie

            self._aigie = get_aigie()
        return self._aigie

    def _get_mode_controller(self):
        """Lazy load mode controller."""
        if self._mode_controller is None:
            aigie = self._get_aigie()
            if aigie:
                self._mode_controller = getattr(aigie, "_mode_controller", None)
        return self._mode_controller

    def _get_interceptor_chain(self):
        """Lazy load interceptor chain."""
        if self._interceptor_chain is None:
            aigie = self._get_aigie()
            if aigie:
                self._interceptor_chain = getattr(aigie, "_interceptor_chain", None)
        return self._interceptor_chain

    # ========================================================================
    # Registration
    # ========================================================================

    @staticmethod
    def _wrap_async(coro_fn):
        """Wrap async handler for LiveKit's sync EventEmitter."""

        def wrapper(event):
            import asyncio

            try:
                loop = asyncio.get_running_loop()
                loop.create_task(coro_fn(event))
            except RuntimeError:
                pass

        return wrapper

    def register(self, session: "AgentSession") -> None:
        """Register intervention event listeners on an AgentSession."""
        try:
            session.on("agent_state_changed", self._wrap_async(self._on_agent_state_changed))
            session.on(
                "conversation_item_added", self._wrap_async(self._on_conversation_item_added)
            )
            session.on(
                "function_tools_executed", self._wrap_async(self._on_function_tools_executed)
            )
            session.on("user_input_transcribed", self._wrap_async(self._on_user_input_transcribed))
            session.on("metrics_collected", self._wrap_async(self._on_metrics_collected))
            session.on("error", self._wrap_async(self._on_error))
            session.on("close", self._wrap_async(self._on_close))

            for event_name, handler in [
                ("session_usage_updated", self._on_session_usage_updated),
                ("user_state_changed", self._on_user_state_changed),
            ]:
                try:
                    session.on(event_name, self._wrap_async(handler))
                except Exception:
                    pass

            logger.debug("[AIGIE-Intervention] Registered event listeners")
        except Exception as e:
            logger.warning(f"[AIGIE-Intervention] Failed to register: {e}")

    # ========================================================================
    # Event Handlers — state tracking only, NO span creation
    # ========================================================================

    async def _on_agent_state_changed(self, event: Any) -> None:
        """Track state for turn boundaries."""
        try:
            new_state = str(getattr(event, "new_state", ""))
            old_state = str(getattr(event, "old_state", ""))
            self._agent_state = new_state

            # Turn boundary detection
            if new_state == "thinking" and not self._in_turn:
                self._in_turn = True
                self._turn_count += 1
                self._current_turn_metrics = VoiceMetrics()
                self._current_transcription = ""
                self._current_bot_response = ""

            if new_state in ("idle", "listening") and self._in_turn:
                self._in_turn = False
                if self._current_turn_metrics:
                    self._metrics_aggregator.record_turn(self._current_turn_metrics)
                    self._cost_tracker.add_turn(
                        stt_model=self._stt_model,
                        tts_model=self._tts_model,
                        llm_model=self._llm_model,
                        audio_duration_seconds=self._current_turn_metrics.audio_duration_seconds
                        or 0,
                        tts_characters=self._current_turn_metrics.tts_characters,
                        input_tokens=self._current_turn_metrics.input_tokens,
                        output_tokens=self._current_turn_metrics.output_tokens,
                    )
                self._current_turn_metrics = None

        except Exception as e:
            logger.debug(f"[AIGIE-Intervention] state_changed error: {e}")

    async def _on_conversation_item_added(self, event: Any) -> None:
        """Track messages for judge context and run intervention on assistant responses."""
        try:
            item = getattr(event, "item", None)
            if not item:
                return

            role = getattr(item, "role", None)
            content = getattr(item, "content", None)
            text = ""

            if isinstance(content, str):
                text = content
            elif isinstance(content, list):
                for part in content:
                    if hasattr(part, "text"):
                        text += getattr(part, "text", "")
                    elif isinstance(part, str):
                        text += part

            if role == "user":
                self._current_transcription = text[:2000]
                self._turn_messages.append({"role": "user", "content": self._current_transcription})

            elif role == "assistant":
                self._current_bot_response = text[:2000]
                self._turn_messages.append(
                    {"role": "assistant", "content": self._current_bot_response}
                )

                # Run intervention on assistant response
                await self._run_intervention_on_response(text)

            # Extract ChatMessage.metrics (1.5.x)
            msg_metrics = getattr(item, "metrics", None)
            if msg_metrics and self._current_turn_metrics:
                ttfb = getattr(msg_metrics, "ttfb", None) or getattr(msg_metrics, "ttft", None)
                if ttfb is not None:
                    self._current_turn_metrics.llm_ttfb_ms = ttfb * 1000

                input_tokens = getattr(msg_metrics, "input_tokens", None) or getattr(
                    msg_metrics, "prompt_tokens", None
                )
                if input_tokens:
                    self._current_turn_metrics.input_tokens = input_tokens

                output_tokens = getattr(msg_metrics, "output_tokens", None) or getattr(
                    msg_metrics, "completion_tokens", None
                )
                if output_tokens:
                    self._current_turn_metrics.output_tokens = output_tokens

        except Exception as e:
            logger.debug(f"[AIGIE-Intervention] conversation_item error: {e}")

    async def _on_function_tools_executed(self, event: Any) -> None:
        """Track tool executions and run intervention."""
        try:
            calls = getattr(event, "function_calls", []) or []
            outputs = getattr(event, "function_call_outputs", []) or []

            for i, call in enumerate(calls):
                tool_name = getattr(call, "name", "unknown")
                tool_output = outputs[i] if i < len(outputs) else None
                output_str = str(getattr(tool_output, "output", ""))[:1000] if tool_output else ""

                # Run intervention on tool output
                chain = self._get_interceptor_chain()
                if chain and self._should_intervene():
                    try:
                        context = self._build_context(
                            span_type="tool",
                            input_data=str(getattr(call, "arguments", ""))[:500],
                            output_data=output_str,
                            metadata={"tool_name": tool_name},
                        )
                        await chain.intercept_post_call(context)
                    except Exception as e:
                        logger.debug(f"[AIGIE-Intervention] tool intervention error: {e}")

        except Exception as e:
            logger.debug(f"[AIGIE-Intervention] tools_executed error: {e}")

    async def _on_user_input_transcribed(self, event: Any) -> None:
        """Track transcriptions."""
        try:
            transcript = getattr(event, "transcript", "")
            is_final = getattr(event, "is_final", False)

            if is_final and transcript:
                self._current_transcription = transcript[:2000]
        except Exception as e:
            logger.debug(f"[AIGIE-Intervention] transcribed error: {e}")

    async def _on_metrics_collected(self, event: Any) -> None:
        """Track metrics for SLA guardrails (no span creation)."""
        try:
            metrics = getattr(event, "metrics", None)
            if not metrics:
                return

            metrics_type = str(getattr(metrics, "type", None) or type(metrics).__name__).lower()

            if self._current_turn_metrics is None:
                self._current_turn_metrics = VoiceMetrics()

            if "llm" in metrics_type:
                self._current_turn_metrics.record_llm_metrics(metrics)
                md = getattr(metrics, "metadata", None)
                if md:
                    self._llm_model = getattr(md, "model_name", None) or self._llm_model

            elif "stt" in metrics_type:
                self._current_turn_metrics.record_stt_metrics(metrics)
                md = getattr(metrics, "metadata", None)
                if md:
                    self._stt_model = getattr(md, "model_name", None) or self._stt_model

            elif "tts" in metrics_type:
                self._current_turn_metrics.record_tts_metrics(metrics)
                md = getattr(metrics, "metadata", None)
                if md:
                    self._tts_model = getattr(md, "model_name", None) or self._tts_model

            elif "eou" in metrics_type:
                self._current_turn_metrics.record_eou_metrics(metrics)

            elif "interruption" in metrics_type:
                self._metrics_aggregator.record_interruption_metrics(metrics)

        except Exception as e:
            logger.debug(f"[AIGIE-Intervention] metrics error: {e}")

    async def _on_session_usage_updated(self, event: Any) -> None:
        """Track session usage for cost guardrails."""
        pass  # Metrics tracked via metrics_collected

    async def _on_user_state_changed(self, event: Any) -> None:
        """Track user state for latency calculation."""
        try:
            new_state = str(getattr(event, "new_state", ""))
            old_state = str(getattr(event, "old_state", ""))

            if self._current_turn_metrics:
                if "speaking" in new_state.lower():
                    self._current_turn_metrics.record_user_started_speaking()
                elif "listening" in new_state.lower() and "speaking" in old_state.lower():
                    self._current_turn_metrics.record_user_stopped_speaking()
        except Exception as e:
            logger.debug(f"[AIGIE-Intervention] user_state error: {e}")

    async def _on_error(self, event: Any) -> None:
        """Track errors and run remediation."""
        try:
            error = getattr(event, "error", None)
            source = getattr(event, "source", "unknown")

            self._errors.append(
                {
                    "type": type(error).__name__ if error else "UnknownError",
                    "message": str(error)[:500] if error else "",
                    "source": str(source),
                }
            )

            # Run remediation if in autonomous mode
            if self._should_intervene():
                aigie = self._get_aigie()
                remediation_engine = getattr(aigie, "_remediation_engine", None) if aigie else None
                if remediation_engine:
                    try:
                        await remediation_engine.handle_error(
                            error_type=type(error).__name__,
                            error_message=str(error),
                            context={"source": str(source), "framework": "livekit_agents"},
                        )
                    except Exception:
                        pass

        except Exception as e:
            logger.debug(f"[AIGIE-Intervention] error handler error: {e}")

    async def _on_close(self, event: Any) -> None:
        """Clean up intervention state."""
        pass  # No traces to finalize

    # ========================================================================
    # Intervention Logic
    # ========================================================================

    def _should_intervene(self) -> bool:
        """Check if we should run intervention (based on mode)."""
        mc = self._get_mode_controller()
        if mc is None:
            return False

        try:
            mode = mc.get_mode()
            return str(mode).lower() != "observe"
        except Exception:
            return False

    async def _run_intervention_on_response(self, response_text: str) -> None:
        """Run InterceptorChain on an assistant response."""
        chain = self._get_interceptor_chain()
        if not chain:
            return

        if not self._should_intervene():
            return

        try:
            context = self._build_context(
                span_type="llm",
                input_data=self._current_transcription,
                output_data=response_text[:2000],
                metadata={
                    "model": self._llm_model,
                    "turn_count": self._turn_count,
                    "messages": self._turn_messages[-10:],
                },
            )
            await chain.intercept_post_call(context)
        except Exception as e:
            logger.debug(f"[AIGIE-Intervention] response intervention error: {e}")

    def _build_context(
        self,
        span_type: str,
        input_data: str,
        output_data: str,
        metadata: Dict[str, Any] | None = None,
    ) -> Dict[str, Any]:
        """Build intervention context dict."""
        otel_ctx = self._span_bridge.get_intervention_context()

        return {
            "trace_id": otel_ctx.get("trace_id"),
            "span_id": otel_ctx.get("span_id"),
            "span_type": span_type,
            "input": input_data,
            "output": output_data,
            "framework": "livekit_agents",
            "metadata": metadata or {},
            "metrics": self._current_turn_metrics.to_dict() if self._current_turn_metrics else {},
        }

    # ========================================================================
    # Public API
    # ========================================================================

    def get_metrics(self) -> Dict[str, Any]:
        return self._metrics_aggregator.to_dict()

    def get_costs(self) -> Dict[str, Any]:
        return self._cost_tracker.get_summary()

    def get_errors(self) -> List[Dict[str, Any]]:
        return list(self._errors)
