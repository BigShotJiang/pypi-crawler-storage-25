"""
Retry and timeout utilities for LiveKit Agents integration.

Provides retry context management for voice service operations
with configurable per-service settings appropriate for real-time voice.
"""

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


class VoiceServiceError(Exception):
    """Error from a voice service (STT, TTS, LLM)."""

    def __init__(self, service: str, message: str, retryable: bool = True):
        self.service = service
        self.retryable = retryable
        super().__init__(f"[{service}] {message}")


class RetryExhaustedError(VoiceServiceError):
    """All retry attempts exhausted."""

    def __init__(self, service: str, attempts: int, last_error: Exception | None = None):
        self.attempts = attempts
        self.last_error = last_error
        super().__init__(service, f"Exhausted {attempts} retry attempts", retryable=False)


class TimeoutExceededError(VoiceServiceError):
    """Operation timed out."""

    def __init__(self, service: str, timeout_seconds: float):
        self.timeout_seconds = timeout_seconds
        super().__init__(service, f"Timed out after {timeout_seconds}s", retryable=True)


@dataclass
class LiveKitRetryContext:
    """
    Tracks retry state for a voice service operation.

    Designed for real-time voice where latency matters:
    - Short initial delays (50-200ms)
    - Fast exponential backoff (max 2s for voice)
    - Per-service retry counts
    """

    service: str  # "stt", "tts", "llm"
    max_retries: int = 3
    initial_delay_ms: float = 100.0
    max_delay_ms: float = 2000.0
    backoff_factor: float = 2.0

    # State
    _attempt: int = field(default=0, init=False, repr=False)
    _start_time: float | None = field(default=None, init=False, repr=False)
    _errors: list[dict[str, Any]] = field(default_factory=list, init=False, repr=False)

    def start(self) -> None:
        """Mark the start of a retriable operation."""
        self._start_time = time.monotonic()
        self._attempt = 0
        self._errors = []

    def should_retry(self, error: Exception) -> bool:
        """Check if we should retry after an error."""
        self._attempt += 1
        self._errors.append(
            {
                "attempt": self._attempt,
                "error": str(error)[:200],
                "type": type(error).__name__,
                "timestamp": time.monotonic() - (self._start_time or time.monotonic()),
            }
        )

        if self._attempt >= self.max_retries:
            return False

        # Check if error is retryable
        if isinstance(error, VoiceServiceError) and not error.retryable:
            return False

        return True

    def get_delay_seconds(self) -> float:
        """Get the delay before the next retry attempt."""
        delay_ms = self.initial_delay_ms * (self.backoff_factor ** (self._attempt - 1))
        delay_ms = min(delay_ms, self.max_delay_ms)
        return delay_ms / 1000.0

    @property
    def attempt(self) -> int:
        return self._attempt

    @property
    def elapsed_seconds(self) -> float:
        if self._start_time is None:
            return 0.0
        return time.monotonic() - self._start_time

    def get_summary(self) -> Dict[str, Any]:
        """Get retry attempt summary."""
        return {
            "service": self.service,
            "total_attempts": self._attempt,
            "max_retries": self.max_retries,
            "elapsed_seconds": self.elapsed_seconds,
            "errors": self._errors or [],
        }


def create_retry_contexts() -> Dict[str, LiveKitRetryContext]:
    """Create default retry contexts for all voice services."""
    return {
        "stt": LiveKitRetryContext(
            service="stt",
            max_retries=2,
            initial_delay_ms=50.0,
            max_delay_ms=500.0,
        ),
        "llm": LiveKitRetryContext(
            service="llm",
            max_retries=3,
            initial_delay_ms=100.0,
            max_delay_ms=2000.0,
        ),
        "tts": LiveKitRetryContext(
            service="tts",
            max_retries=2,
            initial_delay_ms=50.0,
            max_delay_ms=500.0,
        ),
    }
