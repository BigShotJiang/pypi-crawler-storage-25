"""
OpenTelemetry integration for Aigie SDK.

This module provides OpenTelemetry exporter and span processor integration,
allowing Aigie to work with standard observability tools like Datadog, New Relic, Jaeger, etc.
"""

from typing import Any, Dict, List

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SpanExporter, SpanExportResult
from opentelemetry.trace import StatusCode


class AigieSpanExporter(SpanExporter):
    """
    OpenTelemetry span exporter that sends spans to Aigie backend.

    Usage:
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from aigie.opentelemetry import AigieSpanExporter

        provider = TracerProvider()
        exporter = AigieSpanExporter(aigie_client)
        provider.add_span_processor(BatchSpanProcessor(exporter))
        trace.set_tracer_provider(provider)
    """

    def __init__(self, aigie_client):
        """
        Initialize Aigie span exporter.

        Args:
            aigie_client: Aigie client instance
        """
        self.aigie = aigie_client
        self._trace_map: Dict[str, str] = {}  # Map OTel trace_id to Aigie trace_id

    def export(self, spans) -> SpanExportResult:
        """
        Export spans to Aigie backend.

        Args:
            spans: List of OpenTelemetry spans

        Returns:
            SpanExportResult indicating success or failure
        """
        try:
            # Group spans by trace
            traces: Dict[str, List[Any]] = {}

            for span in spans:
                trace_id = format(span.context.trace_id, "032x")

                if trace_id not in traces:
                    traces[trace_id] = []
                traces[trace_id].append(span)

            # Create/update traces and spans
            for trace_id, span_list in traces.items():
                # Get or create Aigie trace ID
                aigie_trace_id = self._trace_map.get(trace_id)

                if not aigie_trace_id:
                    # Create new trace
                    # Use the first span's name as trace name
                    trace_name = span_list[0].name if span_list else "otel_trace"

                    # Create trace (this would need async handling in real implementation)
                    # For now, we'll use the buffer if available
                    if self.aigie._buffer:
                        import asyncio

                        from .buffer import EventType

                        # Create trace
                        trace_payload = {
                            "name": trace_name,
                            "status": "running",
                            "metadata": {"otel_trace_id": trace_id, "source": "opentelemetry"},
                        }

                        from .utils.safe import schedule_async

                        schedule_async(
                            self.aigie._buffer.add(EventType.TRACE_CREATE, trace_payload)
                        )

                # Export spans
                for span in span_list:
                    self._export_span(span, aigie_trace_id or trace_id)

            return SpanExportResult.SUCCESS
        except Exception as e:
            print(f"⚠️  Failed to export spans to Aigie: {e}")
            return SpanExportResult.FAILURE

    def _export_span(self, span: Any, trace_id: str) -> None:
        """Export a single span to Aigie."""
        try:
            # Convert OTel span to Aigie span format
            span_payload = {
                "trace_id": trace_id,
                "name": span.name,
                "type": self._get_span_type(span),
                "input": self._extract_input(span),
                "output": self._extract_output(span),
                "metadata": self._extract_metadata(span),
                "status": "success" if span.status.status_code == StatusCode.OK else "failure",
            }

            # Add error information if present
            if span.status.status_code == StatusCode.ERROR and span.status.description:
                span_payload["error_message"] = span.status.description

            # Add timing information
            if span.start_time and span.end_time:
                duration_ns = span.end_time - span.start_time
                span_payload["duration_ns"] = int(duration_ns)

            # Use buffer if available
            if self.aigie._buffer:
                import asyncio

                from .buffer import EventType
                from .utils.safe import schedule_async

                schedule_async(self.aigie._buffer.add(EventType.SPAN_CREATE, span_payload))
        except Exception as e:
            print(f"⚠️  Failed to export span {span.name}: {e}")

    def _get_span_type(self, span: Any) -> str:
        """Determine span type from OTel span attributes."""
        attrs = span.attributes or {}

        # gen_ai.* semantic conventions take precedence over name-based detection
        operation = attrs.get("gen_ai.operation.name", "")
        if operation in ("embedding", "embeddings"):
            return "embedding"

        # Any gen_ai.* attribute signals an LLM span
        if any(k.startswith("gen_ai.") for k in attrs):
            return "llm"

        # Name-based fallback
        # LLM spans
        if "llm" in span.name.lower() or "openai" in span.name.lower():
            return "llm"

        # Tool spans
        if "tool" in span.name.lower() or "function" in span.name.lower():
            return "tool"

        # Agent spans
        if "agent" in span.name.lower():
            return "agent"

        # Chain spans
        if "chain" in span.name.lower():
            return "chain"

        # Default
        return "tool"

    def _extract_input(self, span: Any) -> Dict[str, Any]:
        """Extract input data from OTel span."""
        attrs = span.attributes or {}
        input_data = {}

        # gen_ai.* semantic conventions (OpenLLMetry / OTEL gen_ai spec)
        if "gen_ai.request.model" in attrs:
            input_data["model"] = attrs["gen_ai.request.model"]
        if "gen_ai.input.messages" in attrs:
            input_data["messages"] = attrs["gen_ai.input.messages"]

        # Common OTel attributes
        if "input" in attrs:
            input_data["input"] = attrs["input"]
        if "prompt" in attrs:
            input_data["prompt"] = attrs["prompt"]
        if "query" in attrs:
            input_data["query"] = attrs["query"]

        return input_data

    def _extract_output(self, span: Any) -> Dict[str, Any]:
        """Extract output data from OTel span."""
        attrs = span.attributes or {}
        output_data = {}

        # gen_ai.* semantic conventions (OpenLLMetry / OTEL gen_ai spec)
        if "gen_ai.output.messages" in attrs:
            output_data["completion"] = attrs["gen_ai.output.messages"]
        if "gen_ai.response.finish_reasons" in attrs:
            output_data["finish_reason"] = attrs["gen_ai.response.finish_reasons"]

        # Common OTel attributes
        if "output" in attrs:
            output_data["output"] = attrs["output"]
        if "response" in attrs:
            output_data["response"] = attrs["response"]
        if "result" in attrs:
            output_data["result"] = attrs["result"]

        return output_data

    def _extract_metadata(self, span: Any) -> Dict[str, Any]:
        """Extract metadata from OTel span."""
        attrs = span.attributes or {}
        metadata = {}

        # gen_ai.* semantic conventions — provider / model identity
        if "gen_ai.system" in attrs:
            metadata["provider"] = attrs["gen_ai.system"]
        if "gen_ai.request.model" in attrs:
            metadata["model"] = attrs["gen_ai.request.model"]
        if "gen_ai.response.model" in attrs:
            metadata["model_version"] = attrs["gen_ai.response.model"]

        # Token usage — normalise across naming variants
        input_tokens = attrs.get("gen_ai.usage.input_tokens") or attrs.get(
            "gen_ai.usage.prompt_tokens"
        )
        output_tokens = attrs.get("gen_ai.usage.output_tokens") or attrs.get(
            "gen_ai.usage.completion_tokens"
        )
        if input_tokens is not None or output_tokens is not None:
            token_usage: Dict[str, Any] = {}
            if input_tokens is not None:
                token_usage["input_tokens"] = input_tokens
            if output_tokens is not None:
                token_usage["output_tokens"] = output_tokens
            metadata["token_usage"] = token_usage

        # Extended / provider-specific usage details
        usage_details: Dict[str, Any] = {}
        if "gen_ai.usage.cache_read.input_tokens" in attrs:
            usage_details["cache_read_input_tokens"] = attrs["gen_ai.usage.cache_read.input_tokens"]
        if "gen_ai.usage.cache_creation.input_tokens" in attrs:
            usage_details["cache_creation_input_tokens"] = attrs[
                "gen_ai.usage.cache_creation.input_tokens"
            ]
        if "gen_ai.usage.reasoning_tokens" in attrs:
            usage_details["reasoning_tokens"] = attrs["gen_ai.usage.reasoning_tokens"]
        if usage_details:
            metadata["usage_details"] = usage_details

        # Model parameters
        model_parameters: Dict[str, Any] = {}
        if "gen_ai.request.temperature" in attrs:
            model_parameters["temperature"] = attrs["gen_ai.request.temperature"]
        if "gen_ai.request.top_p" in attrs:
            model_parameters["top_p"] = attrs["gen_ai.request.top_p"]
        if "gen_ai.request.max_tokens" in attrs:
            model_parameters["max_tokens"] = attrs["gen_ai.request.max_tokens"]
        if model_parameters:
            metadata["model_parameters"] = model_parameters

        # Remaining non-gen_ai, non-generic attributes
        _skip_prefixes = ("gen_ai.",)
        _skip_exact = {"input", "output", "prompt", "query", "response", "result"}
        for key, value in attrs.items():
            if key in _skip_exact:
                continue
            if any(key.startswith(p) for p in _skip_prefixes):
                continue
            metadata[key] = value

        return metadata

    def shutdown(self) -> None:
        """Shutdown the exporter."""
        # Flush any remaining events
        if self.aigie._buffer:
            from .utils.safe import schedule_async

            schedule_async(self.aigie.flush())


def setup_opentelemetry(aigie_client, service_name: str | None = None) -> None:
    """
    Setup OpenTelemetry with Aigie exporter.

    Usage:
        from aigie import Aigie
        from aigie.opentelemetry import setup_opentelemetry

        aigie = Aigie()
        await aigie.initialize()

        setup_opentelemetry(aigie, service_name="my-service")

        # Now all OTel spans will be exported to Aigie
        from opentelemetry import trace
        tracer = trace.get_tracer(__name__)

        with tracer.start_as_current_span("my_operation"):
            # Your code here
            pass

    Args:
        aigie_client: Aigie client instance
        service_name: Optional service name for OTel
    """
    from opentelemetry.sdk.resources import Resource

    # Create resource with service name
    resource = Resource.create({"service.name": service_name or "aigie-service"})

    # Create tracer provider
    provider = TracerProvider(resource=resource)

    # Create Aigie exporter
    exporter = AigieSpanExporter(aigie_client)

    # Add batch span processor
    provider.add_span_processor(BatchSpanProcessor(exporter))

    # Set as global tracer provider
    trace.set_tracer_provider(provider)
