"""
Redis-based transport for SDK-Platform intervention communication.

Uses:
- Redis Streams for request-reply (VALIDATE, CONSULTATION)
- Redis Pub/Sub for server-push (INTERVENTION, PATTERN_UPDATE, MODE_CHANGE)
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from typing import Any, Awaitable, Callable, Dict, List

logger = logging.getLogger(__name__)


class RedisInterventionTransport:
    """Redis implementation of the InterventionTransport protocol."""

    def __init__(self, redis_url: str, agent_id: str) -> None:
        self._redis_url = redis_url
        self._agent_id = agent_id

        # Stream / channel names
        self._request_stream = f"kytte:validate:{agent_id}"
        self._response_stream_prefix = "kytte:response"
        self._push_channel = f"kytte:push:{agent_id}"
        self._broadcast_channel = "kytte:broadcast"

        # State
        self._connected = False
        self._stream_client = None  # redis.asyncio client for Streams
        self._pubsub_client = None  # redis.asyncio client for Pub/Sub
        self._pubsub = None
        self._listen_task: asyncio.Task | None = None
        self._push_callbacks: Dict[str, List[Callable[[Dict[str, Any]], Awaitable[None]]]] = {}

    # ------------------------------------------------------------------
    # Protocol implementation
    # ------------------------------------------------------------------

    async def connect(self) -> bool:
        """Connect to Redis. Returns True on success, False on failure."""
        try:
            import redis.asyncio as aioredis
        except ImportError:
            logger.error("redis package not installed — run: pip install redis")
            return False

        try:
            self._stream_client = aioredis.from_url(self._redis_url, decode_responses=True)
            self._pubsub_client = aioredis.from_url(self._redis_url, decode_responses=True)

            # Verify connectivity
            await self._stream_client.ping()

            # Subscribe to push and broadcast channels
            self._pubsub = self._pubsub_client.pubsub()
            await self._pubsub.subscribe(self._push_channel, self._broadcast_channel)

            # Start background listener
            self._listen_task = asyncio.create_task(self._listen_loop())

            self._connected = True
            logger.info(
                "RedisInterventionTransport connected to %s (agent=%s)",
                self._redis_url,
                self._agent_id,
            )
            return True

        except Exception as exc:
            logger.warning("RedisInterventionTransport failed to connect: %s", exc)
            await self._cleanup()
            return False

    async def disconnect(self) -> None:
        """Disconnect and release resources."""
        self._connected = False

        if self._listen_task and not self._listen_task.done():
            self._listen_task.cancel()
            try:
                await self._listen_task
            except asyncio.CancelledError:
                pass

        await self._cleanup()
        logger.info("RedisInterventionTransport disconnected (agent=%s)", self._agent_id)

    async def request_reply(
        self,
        message_type: str,
        payload: Dict[str, Any],
        timeout: float = 2.0,
    ) -> Dict[str, Any] | None:
        """
        XADD a request to the validate stream and XREAD the correlated response.
        Returns the response payload or None on timeout / error.
        """
        if not self._connected or self._stream_client is None:
            logger.warning("request_reply called while not connected")
            return None

        request_id = str(uuid.uuid4())
        response_stream = f"{self._response_stream_prefix}:{request_id}"

        try:
            await self._stream_client.xadd(
                self._request_stream,
                {
                    "type": message_type,
                    "request_id": request_id,
                    "agent_id": self._agent_id,
                    "payload": json.dumps(payload),
                    "ts": str(asyncio.get_event_loop().time()),
                },
            )

            # Block-read the response stream (timeout in milliseconds)
            block_ms = int(timeout * 1000)
            result = await self._stream_client.xread(
                {response_stream: "0-0"},
                block=block_ms,
                count=1,
            )

            if not result:
                logger.warning(
                    "request_reply timed out after %.1fs (type=%s, request_id=%s)",
                    timeout,
                    message_type,
                    request_id,
                )
                return None

            # result shape: [(stream_name, [(msg_id, fields), ...])]
            _stream_name, messages = result[0]
            _msg_id, fields = messages[0]

            raw_payload = fields.get("payload", "{}")
            return json.loads(raw_payload)

        except Exception as exc:
            logger.error(
                "request_reply error (type=%s, request_id=%s): %s",
                message_type,
                request_id,
                exc,
            )
            return None
        finally:
            # Clean up the ephemeral response stream
            if self._stream_client is not None:
                try:
                    await self._stream_client.delete(response_stream)
                except Exception:
                    pass

    def on_push(
        self,
        message_type: str,
        callback: Callable[[Dict[str, Any]], Awaitable[None]],
    ) -> None:
        """Register a callback for server-push messages of the given type."""
        self._push_callbacks.setdefault(message_type, []).append(callback)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def transport_type(self) -> str:
        return "redis"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _listen_loop(self) -> None:
        """Background coroutine: dispatch Pub/Sub messages to callbacks."""
        try:
            async for message in self._pubsub.listen():
                if message["type"] != "message":
                    continue
                try:
                    data = json.loads(message["data"])
                    msg_type = data.get("type", "")
                    callbacks = self._push_callbacks.get(msg_type, [])
                    for cb in callbacks:
                        try:
                            await cb(data)
                        except Exception as exc:
                            logger.error("Push callback error (type=%s): %s", msg_type, exc)
                except json.JSONDecodeError as exc:
                    logger.warning("Failed to decode push message: %s", exc)
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            logger.error("_listen_loop crashed: %s", exc)
            self._connected = False

    async def _cleanup(self) -> None:
        """Close Redis clients."""
        if self._pubsub is not None:
            try:
                await self._pubsub.unsubscribe(self._push_channel, self._broadcast_channel)
                await self._pubsub.close()
            except Exception:
                pass
            self._pubsub = None

        if self._pubsub_client is not None:
            try:
                await self._pubsub_client.aclose()
            except Exception:
                pass
            self._pubsub_client = None

        if self._stream_client is not None:
            try:
                await self._stream_client.aclose()
            except Exception:
                pass
            self._stream_client = None
