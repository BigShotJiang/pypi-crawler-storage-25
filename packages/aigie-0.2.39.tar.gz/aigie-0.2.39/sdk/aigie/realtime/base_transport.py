"""
Transport protocol for SDK-Platform intervention communication.

Both WebSocket and Redis implement this interface. The SDK chooses
the best available transport at init time.
"""

from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable, Dict, Protocol, runtime_checkable


@runtime_checkable
class InterventionTransport(Protocol):
    """Protocol for intervention transport backends."""

    async def connect(self) -> bool:
        """Connect to the transport. Returns True if successful."""
        ...

    async def disconnect(self) -> None:
        """Disconnect and clean up resources."""
        ...

    async def request_reply(
        self,
        message_type: str,
        payload: Dict[str, Any],
        timeout: float = 2.0,
    ) -> Dict[str, Any] | None:
        """
        Send a request and wait for a correlated response.
        Used for VALIDATE and CONSULTATION patterns.
        Returns the response payload, or None on timeout/error.
        """
        ...

    def on_push(
        self,
        message_type: str,
        callback: Callable[[Dict[str, Any]], Awaitable[None]],
    ) -> None:
        """
        Register a callback for server-push messages.
        Used for INTERVENTION, PATTERN_UPDATE, MODE_CHANGE, ALERT.
        """
        ...

    @property
    def is_connected(self) -> bool:
        """Whether the transport is currently connected."""
        ...

    @property
    def transport_type(self) -> str:
        """Transport identifier: 'websocket' or 'redis'."""
        ...
