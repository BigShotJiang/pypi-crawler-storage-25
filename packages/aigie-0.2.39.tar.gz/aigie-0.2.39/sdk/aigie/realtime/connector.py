"""
BackendConnector - WebSocket connection for real-time backend consultation.

Provides bidirectional communication with the Aigie backend for:
- Real-time interception decisions
- Leveraging historical data and patterns
- Receiving proactive fixes and recommendations

Built on BaseWebSocketClient for shared connection management.
"""

import asyncio
import json
import logging
import time
import uuid
from collections.abc import Awaitable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

from .base_ws import BaseWebSocketClient

if TYPE_CHECKING:
    from ..interceptor.protocols import (
        InterceptionContext,
        PostCallResult,
        PreCallResult,
    )

logger = logging.getLogger("aigie.realtime")


@dataclass
class ConsultationRequest:
    """Request for backend consultation."""

    request_id: str
    """Unique request ID for correlation."""

    consultation_type: str
    """Type: 'pre_call', 'post_call', 'drift_check', 'fix_request'."""

    context: Dict[str, Any]
    """Serialized interception context."""

    urgency: str = "normal"
    """Urgency level: 'low', 'normal', 'high', 'critical'."""

    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class ConsultationResponse:
    """Response from backend consultation."""

    request_id: str
    """Correlated request ID."""

    decision: str
    """Decision: 'allow', 'block', 'modify', 'retry'."""

    reason: str | None = None
    """Reason for the decision."""

    fixes: List[Dict[str, Any]] = field(default_factory=list)
    """List of fix actions to apply."""

    modified_request: Dict[str, Any] | None = None
    """Modified request parameters."""

    modified_response: Dict[str, Any] | None = None
    """Modified response content."""

    confidence: float = 0.0
    """Confidence score for this decision."""

    latency_ms: float = 0.0
    """Backend processing latency."""

    metadata: Dict[str, Any] = field(default_factory=dict)
    """Additional metadata from backend."""


class BackendConnector(BaseWebSocketClient):
    """
    WebSocket connector for real-time backend communication.

    Extends BaseWebSocketClient with consultation-specific logic:
    - Pre/post call consultation with request/response correlation
    - Push-based fix and alert callbacks
    - Event type subscriptions
    """

    def __init__(
        self,
        kytte_url: str,
        kytte_token: str,
        auto_reconnect: bool = True,
        reconnect_interval: float = 5.0,
        max_reconnect_attempts: int = 10,
        ping_interval: float = 30.0,
        request_timeout: float = 2.0,  # 2000ms default
    ):
        super().__init__(
            kytte_url=kytte_url,
            kytte_token=kytte_token,
            ws_path="/v1/gateway/ws",
            auto_reconnect=auto_reconnect,
            reconnect_interval=reconnect_interval,
            max_reconnect_attempts=max_reconnect_attempts,
            ping_interval=ping_interval,
        )
        self._request_timeout = request_timeout
        self._transport = None  # RedisInterventionTransport (set by client.py)

        # Callbacks for push events
        self._fix_callbacks: List[Callable[[Dict[str, Any]], Awaitable[None]]] = []
        self._alert_callbacks: List[Callable[[Dict[str, Any]], Awaitable[None]]] = []
        self._pattern_update_callbacks: List[Callable[[Dict[str, Any]], Awaitable[None]]] = []

        # Consultation-specific stats
        self._stats["consultations"] = 0
        self._stats["successful_responses"] = 0
        self._stats["total_latency_ms"] = 0.0

    async def _on_connected(self) -> None:
        """Read welcome message and subscribe to relevant event types."""
        # Read welcome message from gateway
        if self._websocket:
            try:
                import json as _json

                welcome_msg = await asyncio.wait_for(self._websocket.recv(), timeout=5.0)
                welcome_data = _json.loads(welcome_msg)
                logger.info(
                    f"Connected to gateway (connection_id: {welcome_data.get('connection_id')})"
                )
            except Exception as e:
                logger.debug(f"Failed to read welcome message: {e}")

    async def _on_message(self, data: Dict[str, Any]) -> None:
        """Handle incoming WebSocket messages."""
        msg_type = data.get("type")

        if msg_type == "consultation_response":
            request_id = data.get("request_id")
            if request_id:
                self._resolve_request(request_id, data)

        elif msg_type in ("fix_push", "intervention"):
            payload = data.get("payload", data.get("data", data))
            for callback in self._fix_callbacks:
                asyncio.create_task(callback(payload))

        elif msg_type == "alert":
            for callback in self._alert_callbacks:
                asyncio.create_task(callback(data))

        elif msg_type == "pattern_updated":
            # Backend promoted new patterns — trigger cache refresh
            for callback in self._pattern_update_callbacks:
                asyncio.create_task(callback(data.get("payload", data)))

        elif msg_type == "judge_result":
            payload = data.get("payload", data)
            for callback in self._fix_callbacks:
                asyncio.create_task(callback(payload))

        elif msg_type in ("pong", "ping"):
            pass  # Keepalive response

    async def consult_pre_call(
        self,
        ctx: "InterceptionContext",
        timeout: float | None = None,
    ) -> Optional["PreCallResult"]:
        """
        Consult backend for pre-call decision.

        Args:
            ctx: Interception context
            timeout: Request timeout (default: self._request_timeout)

        Returns:
            PreCallResult if successful, None on timeout/error
        """
        from ..interceptor.protocols import InterceptionDecision, PreCallResult

        # Try Redis transport first (3-5ms vs 20ms WebSocket)
        if self._transport and self._transport.is_connected:
            result = await self._transport.request_reply(
                "consultation",
                {
                    "consultation_type": "pre_call",
                    "request_id": str(uuid.uuid4()),
                    **self._serialize_context(ctx),
                },
                timeout=timeout if timeout else self._request_timeout,
            )
            if result is not None:
                self._stats["consultations"] += 1
                self._stats["successful_responses"] += 1
                return result
        # Fall through to WebSocket...

        if not self.is_connected:
            return None

        request = ConsultationRequest(
            request_id=str(uuid.uuid4()),
            consultation_type="pre_call",
            context=self._serialize_context(ctx),
        )

        response = await self._send_consultation(request, timeout or self._request_timeout)

        if response is None:
            return None

        # Convert response to PreCallResult
        decision_map = {
            "allow": InterceptionDecision.ALLOW,
            "block": InterceptionDecision.BLOCK,
            "modify": InterceptionDecision.MODIFY,
        }

        decision = decision_map.get(response.decision, InterceptionDecision.ALLOW)

        if decision == InterceptionDecision.BLOCK:
            return PreCallResult.block(
                reason=response.reason or "Blocked by backend",
                hook_name="backend",
                latency_ms=response.latency_ms,
            )

        if decision == InterceptionDecision.MODIFY and response.modified_request:
            return PreCallResult.modify(
                messages=response.modified_request.get("messages"),
                kwargs=response.modified_request.get("kwargs"),
                reason=response.reason,
                hook_name="backend",
                latency_ms=response.latency_ms,
            )

        return PreCallResult.allow(hook_name="backend", latency_ms=response.latency_ms)

    async def consult_post_call(
        self,
        ctx: "InterceptionContext",
        timeout: float | None = None,
    ) -> Optional["PostCallResult"]:
        """
        Consult backend for post-call decision and fixes.

        Args:
            ctx: Interception context with response
            timeout: Request timeout

        Returns:
            PostCallResult if successful, None on timeout/error
        """
        from ..interceptor.protocols import (
            FixAction,
            FixActionType,
            PostCallResult,
        )

        # --- Sync inline eval via judge-worker (SmolLM2 → SLM judges) ---
        # When FastDetector signals need for deep evaluation, send to kytte:eval:*
        # for synchronous judge assessment with fix payloads.
        signal_hints = getattr(ctx, "_signal_hints", None) or []
        needs_deep = getattr(ctx, "_needs_deep_eval", False) or bool(signal_hints)

        if needs_deep and self._transport and self._transport.is_connected:
            # Extract system prompt from messages
            system_prompt = None
            messages = getattr(ctx, "messages", []) or []
            for msg in messages:
                if isinstance(msg, dict) and msg.get("role") == "system":
                    system_prompt = msg.get("content")
                    break

            # Extract conversation history (last 5 non-system messages)
            conversation_history = None
            if messages:
                conv = [
                    {"role": msg.get("role", ""), "content": str(msg.get("content", ""))[:500]}
                    for msg in messages
                    if isinstance(msg, dict) and msg.get("role") != "system"
                ]
                if conv:
                    conversation_history = conv[-5:]

            # Extract tool calls from response if present
            tool_calls_data = None
            response = getattr(ctx, "response", None)
            if response:
                try:
                    if hasattr(response, "choices"):
                        for choice in response.choices:
                            if hasattr(choice, "message") and hasattr(choice.message, "tool_calls"):
                                if choice.message.tool_calls:
                                    tool_calls_data = [
                                        {
                                            "name": tc.function.name,
                                            "arguments": tc.function.arguments[:200],
                                        }
                                        for tc in choice.message.tool_calls[:5]
                                    ]
                except Exception:
                    pass  # Fail-open: tool_calls is optional enrichment

            eval_response = await self.request_sync_judgment(
                agent_id=self._agent_id or "unknown",
                trace_id=getattr(ctx, "trace_id", "") or "",
                span_id=getattr(ctx, "span_id", "") or "",
                span_type=getattr(ctx, "span_type", "llm") or "llm",
                output_content=str(getattr(ctx, "response_content", "") or "")[:2000],
                input_content=str(getattr(ctx, "input_content", "") or "")[:500],
                signal_hints=signal_hints,
                error_type=getattr(ctx, "error_type", None),
                error_message=str(getattr(ctx, "error", ""))[:500]
                if getattr(ctx, "error", None)
                else None,
                workflow_id=getattr(self, "_workflow_id", None),
                timeout=timeout or 15.0,
                # New context fields
                system_prompt=system_prompt,
                conversation_history=conversation_history,
                tool_calls=tool_calls_data,
            )
            if eval_response and eval_response.get("verdict") == "FIX":
                fix_payload = eval_response.get("fix_payload") or {}
                strategy = fix_payload.get("strategy", "REPLACE")
                action_type = FixActionType.MODIFY_RESPONSE
                if strategy in ("RETRY_REQUEST", "RETRY"):
                    action_type = FixActionType.RETRY
                elif strategy in ("INJECT", "INJECT_INSTRUCTION"):
                    action_type = FixActionType.INJECT_INSTRUCTION

                fixes = [
                    FixAction(
                        action_type=action_type,
                        parameters=fix_payload,
                        confidence=eval_response.get("confidence", 0.0),
                        source="sync_eval",
                        reason=eval_response.get("root_cause"),
                    )
                ]
                return PostCallResult.modify(
                    response=None,
                    content=fix_payload.get("fixed_output") or fix_payload.get("guidance"),
                    reason=eval_response.get("root_cause"),
                    fixes=fixes,
                    hook_name="sync_eval",
                    latency_ms=eval_response.get("latency_ms", 0.0),
                )
            # If eval returned PASS or no response, fall through to normal flow

        # --- Standard consultation via Redis transport or WebSocket ---
        if self._transport and self._transport.is_connected:
            result = await self._transport.request_reply(
                "consultation",
                {
                    "consultation_type": "post_call",
                    "request_id": str(uuid.uuid4()),
                    **self._serialize_context(ctx),
                },
                timeout=timeout if timeout else self._request_timeout,
            )
            if result is not None:
                self._stats["consultations"] += 1
                self._stats["successful_responses"] += 1
                return result
        # Fall through to WebSocket...

        if not self.is_connected:
            return None

        request = ConsultationRequest(
            request_id=str(uuid.uuid4()),
            consultation_type="post_call",
            context=self._serialize_context(ctx),
            urgency="high" if ctx.error else "normal",
        )

        response = await self._send_consultation(request, timeout or self._request_timeout)

        if response is None:
            return None

        # Convert fixes
        fixes = []
        for fix_data in response.fixes:
            action_type = FixActionType.MODIFY_RESPONSE
            if fix_data.get("action_type") == "retry":
                action_type = FixActionType.RETRY
            elif fix_data.get("action_type") == "fallback":
                action_type = FixActionType.FALLBACK

            fixes.append(
                FixAction(
                    action_type=action_type,
                    parameters=fix_data.get("parameters", {}),
                    confidence=fix_data.get("confidence", 0.8),
                    source="backend",
                    reason=fix_data.get("reason"),
                )
            )

        # Check if retry is needed
        if response.decision == "retry":
            return PostCallResult.retry(
                reason=response.reason or "Backend requested retry",
                retry_kwargs=response.modified_request,
                hook_name="backend",
                latency_ms=response.latency_ms,
            )

        # Return modification result
        if response.modified_response or fixes:
            return PostCallResult.modify(
                response=response.modified_response,
                content=response.modified_response.get("content")
                if response.modified_response
                else None,
                reason=response.reason,
                fixes=fixes,
                hook_name="backend",
                latency_ms=response.latency_ms,
            )

        return PostCallResult.allow(hook_name="backend", latency_ms=response.latency_ms)

    async def request_sync_judgment(
        self,
        agent_id: str,
        trace_id: str,
        span_id: str,
        span_type: str,
        output_content: str,
        input_content: str | None = None,
        signal_hints: list[str] | None = None,
        error_type: str | None = None,
        error_message: str | None = None,
        workflow_id: str | None = None,
        timeout: float | None = None,
        # --- New context fields ---
        system_prompt: str | None = None,
        conversation_history: list[dict] | None = None,
        tool_calls: list[dict] | None = None,
        retrieved_context: str | None = None,
    ) -> Dict[str, Any] | None:
        """Send synchronous inline judgment request to judge-worker via Redis Streams.

        Sends to kytte:eval:{agent_id} stream. Judge-worker's SyncJudgeHandler
        picks it up, runs SmolLM2 -> SLM judges -> remediation, and writes
        the response to kytte:response:{request_id}.

        Returns the judgment response dict with verdict, score, fix_payload, etc.
        Returns None if transport unavailable or request fails (fail-open).
        """
        if self._transport is None or not hasattr(self._transport, "_stream_client"):
            return None

        if not self._transport.is_connected or self._transport._stream_client is None:
            return None

        request_id = str(uuid.uuid4())
        judgment_stream = f"kytte:eval:{agent_id}"
        response_stream = f"kytte:response:{request_id}"

        request_data = {
            "request_id": request_id,
            "agent_id": agent_id,
            "trace_id": trace_id,
            "span_id": span_id,
            "span_type": span_type,
            "output_content": output_content,
            "input_content": input_content,
            "signal_hints": signal_hints or [],
            "error_type": error_type,
            "error_message": error_message,
            "workflow_id": workflow_id,
        }
        # Add context fields only when present (keep payload small for backward compat)
        if system_prompt:
            request_data["system_prompt"] = system_prompt[:1000]
        if conversation_history:
            request_data["conversation_history"] = conversation_history[-5:]
        if tool_calls:
            request_data["tool_calls"] = tool_calls[-5:]
        if retrieved_context:
            request_data["retrieved_context"] = retrieved_context[:2000]

        try:
            client = self._transport._stream_client
            await client.xadd(
                judgment_stream,
                {
                    "data": json.dumps(request_data),
                },
            )

            block_ms = int((timeout or 5.0) * 1000)
            result = await client.xread(
                {response_stream: "0-0"},
                block=block_ms,
                count=1,
            )

            if not result:
                logger.warning(
                    "request_sync_judgment timed out after %.1fs (agent=%s, request_id=%s)",
                    timeout or 5.0,
                    agent_id,
                    request_id,
                )
                return None

            _stream_name, messages = result[0]
            _msg_id, fields = messages[0]

            raw_payload = fields.get("data") or fields.get("payload", "{}")
            return json.loads(raw_payload)

        except Exception as exc:
            logger.error(
                "request_sync_judgment error (agent=%s, request_id=%s): %s",
                agent_id,
                request_id,
                exc,
            )
            return None
        finally:
            try:
                if self._transport._stream_client is not None:
                    await self._transport._stream_client.delete(response_stream)
            except Exception:
                pass

    # Alias for consistency with task spec naming convention
    request_sync_eval = request_sync_judgment

    def on_fix_push(self, callback: Callable[[Dict[str, Any]], Awaitable[None]]) -> None:
        """Register callback for backend-pushed fixes."""
        self._fix_callbacks.append(callback)

    def on_alert(self, callback: Callable[[Dict[str, Any]], Awaitable[None]]) -> None:
        """Register callback for backend alerts."""
        self._alert_callbacks.append(callback)

    def on_pattern_update(self, callback: Callable[[Dict[str, Any]], Awaitable[None]]) -> None:
        """Register callback for pattern cache refresh notifications."""
        self._pattern_update_callbacks.append(callback)

    def set_transport(self, transport) -> None:
        """Set the intervention transport (Redis or other)."""
        self._transport = transport
        # Register push callbacks on the transport too
        if transport:
            for cb in self._fix_callbacks:
                transport.on_push("fix", cb)
            for cb in self._alert_callbacks:
                transport.on_push("alert", cb)
            for cb in self._pattern_update_callbacks:
                transport.on_push("pattern_update", cb)

    async def _send_consultation(
        self,
        request: ConsultationRequest,
        timeout: float,
    ) -> ConsultationResponse | None:
        """Send consultation request and wait for response."""
        self._stats["consultations"] += 1
        start_time = time.perf_counter()

        message = {
            "type": "consultation",
            "timestamp": request.timestamp.isoformat(),
            "payload": {
                "request_id": request.request_id,
                "consultation_type": request.consultation_type,
                "context": request.context,
                "urgency": request.urgency,
            },
        }

        response_data = await self._send_and_wait(request.request_id, message, timeout)

        if response_data is None:
            return None

        latency = (time.perf_counter() - start_time) * 1000
        self._stats["successful_responses"] += 1
        self._stats["total_latency_ms"] += latency

        return ConsultationResponse(
            request_id=request.request_id,
            decision=response_data.get("decision", "allow"),
            reason=response_data.get("reason"),
            fixes=response_data.get("fixes", []),
            modified_request=response_data.get("modified_request"),
            modified_response=response_data.get("modified_response"),
            confidence=response_data.get("confidence", 0.0),
            latency_ms=latency,
            metadata=response_data.get("metadata", {}),
        )

    def _serialize_context(self, ctx: "InterceptionContext") -> Dict[str, Any]:
        """Serialize interception context for transmission."""
        return {
            "provider": ctx.provider,
            "model": ctx.model,
            "messages": ctx.messages[-5:] if ctx.messages else [],  # Last 5 messages
            "trace_id": ctx.trace_id,
            "span_id": ctx.span_id,
            "estimated_cost": ctx.estimated_cost,
            "accumulated_cost": ctx.accumulated_cost,
            "drift_score": ctx.drift_score,
            "context_hash": ctx.context_hash,
            "error": str(ctx.error) if ctx.error else None,
            "error_type": ctx.error_type,
            "user_id": ctx.user_id,
            "session_id": ctx.session_id,
            "response_content": ctx.response_content[:1000] if ctx.response_content else None,
            "actual_cost": ctx.actual_cost,
            "response_time_ms": ctx.response_time_ms,
        }

    async def send_deep_eval(
        self,
        trace_id: str,
        span_id: str,
        span_type: str,
        output_content: str,
        input_messages: list,
        signal_hints: List[str],
        metadata: Dict[str, Any] | None = None,
    ) -> None:
        """Fire-and-forget deep evaluation request. Non-blocking."""
        if not self.is_connected:
            return

        message = {
            "type": "consultation",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "payload": {
                "request_id": str(uuid.uuid4()),
                "consultation_type": "deep_eval",
                "context": {
                    "trace_id": trace_id,
                    "span_id": span_id,
                    "span_type": span_type,
                    "output_content": output_content[:2000],
                    "input_messages": input_messages[-5:] if input_messages else [],
                    "signal_hints": signal_hints,
                    "metadata": metadata or {},
                },
                "urgency": "normal",
            },
        }

        try:
            await self._send(message)
            self._stats["consultations"] += 1
        except Exception as e:
            logger.debug(f"send_deep_eval failed: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Get connector statistics."""
        stats = super().get_stats()
        stats["avg_latency_ms"] = self._stats["total_latency_ms"] / max(
            self._stats["successful_responses"], 1
        )
        return stats
