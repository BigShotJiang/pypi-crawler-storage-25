"""
Per-framework fix application dispatcher.

Routes fix payloads from SyncEvaluator to the correct framework adapter.
Each adapter knows how to modify the agent's state for its framework.
"""

import logging
from typing import Any, Protocol

logger = logging.getLogger(__name__)


class FrameworkFixAdapter(Protocol):
    """Protocol for per-framework fix application."""

    def apply_fix(self, fix_payload: dict[str, Any], context: Any) -> bool:
        """Apply a fix to the current agent step.

        Args:
            fix_payload: Dict with strategy, fixed_output, guidance, etc.
            context: Framework-specific context (event, state, message, etc.)

        Returns:
            True if fix was applied successfully.
        """
        ...


# Global registry of framework adapters
_adapters: dict[str, FrameworkFixAdapter] = {}


def register_fix_adapter(framework: str, adapter: FrameworkFixAdapter) -> None:
    """Register a fix adapter for a framework."""
    _adapters[framework] = adapter
    logger.debug(f"Registered fix adapter for {framework}")


def apply_framework_fix(
    framework: str,
    fix_payload: dict[str, Any],
    context: Any,
) -> bool:
    """Apply a fix using the registered adapter for the framework.

    Returns True if applied, False if no adapter or application failed.
    """
    adapter = _adapters.get(framework)
    if not adapter:
        logger.debug(f"No fix adapter registered for {framework}")
        return False

    try:
        return adapter.apply_fix(fix_payload, context)
    except Exception as e:
        logger.warning(f"Fix application failed for {framework}: {e}")
        return False


def get_registered_frameworks() -> list[str]:
    """Return list of frameworks with registered fix adapters."""
    return list(_adapters.keys())
