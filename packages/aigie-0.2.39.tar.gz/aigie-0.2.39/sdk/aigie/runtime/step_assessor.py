"""
Step Assessor — Shared core quality assessment for all framework integrations.

Runs the 3-tier assessment pipeline on every LLM/tool step:
  Tier 1: FastDetector (sync, <5ms, zero network)
  Tier 2: BackendConnector.send_deep_judge (async, fire-and-forget via WebSocket)
  Tier 3: AsyncJudgeRunner.fire_and_forget (async fallback, local/REST)

Never blocks. Never raises. Called by every integration handler after each step.
"""

from __future__ import annotations

import asyncio
import logging
import threading
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("aigie.runtime.step_assessor")


@dataclass(slots=True)
class StepAssessmentResult:
    """Result from the step assessment pipeline."""

    signal_hints: list[str] = field(default_factory=list)
    needs_deep_check: bool = False
    deep_check_sent: bool = False
    intervention: Any = None  # Pending InterventionSignal if found


def assess_step(
    aigie: Any,
    *,
    trace_id: str,
    span_id: str,
    span_type: str = "llm",
    output_content: str | None = None,
    input_messages: list | None = None,
    error: str | None = None,
    error_type_name: str | None = None,
    status_code: int | None = None,
    model: str | None = None,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cost: float = 0.0,
    metadata: dict[str, Any] | None = None,
    intervention_dispatcher: Any = None,
) -> StepAssessmentResult:
    """
    Core assessment pipeline. Called by every integration after each LLM/tool step.

    0. Check for pending interventions (pre-step, optional)
    1. Run FastDetector (sync, <5ms)
    2. If needs_deep_check or error: send via WebSocket (async, fire-and-forget)
    3. Fallback: async judge (local/REST) if WebSocket unavailable

    Never blocks. Never raises.
    """
    result = StepAssessmentResult()

    # Pre-step: check for pending interventions
    pending_intervention = None
    if intervention_dispatcher is not None:
        try:
            pending_intervention = intervention_dispatcher.pop_pending(trace_id)
        except Exception:
            pass  # Never block
    result.intervention = pending_intervention

    if aigie is None or not getattr(aigie, "_initialized", False):
        return result

    try:
        # -- Tier 1: Fast detection (sync, <5ms) --
        detection = None
        fast_detector = getattr(aigie, "_fast_detector", None)
        if fast_detector:
            try:
                detection = fast_detector.detect(
                    trace_id=trace_id,
                    span_id=span_id,
                    output_content=output_content,
                    error=error,
                    error_type_name=error_type_name,
                    status_code=status_code,
                    model=model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    cost=cost,
                )
                result.signal_hints = getattr(detection, "signal_hints", [])
                _needs_deep = getattr(detection, "needs_deep_eval", False)
                result.needs_deep_check = _needs_deep
            except Exception as e:
                logger.debug(f"Fast detection skipped: {e}")

        # Only proceed to Tier 2/3 if deep check needed or error present
        should_deep_check = result.needs_deep_check or bool(error)
        if not should_deep_check:
            return result

        # -- Tier 2: WebSocket deep judge (async, fire-and-forget) --
        connector = getattr(aigie, "_backend_connector", None)
        if connector and getattr(connector, "is_connected", False):
            try:
                _send = connector.send_deep_eval
                coro = _send(
                    trace_id=trace_id,
                    span_id=span_id,
                    span_type=span_type,
                    output_content=output_content or "",
                    input_messages=input_messages or [],
                    signal_hints=result.signal_hints,
                    metadata=metadata,
                )
                _schedule_async(coro)
                result.deep_check_sent = True
                logger.debug(
                    f"Deep check sent via WebSocket for {span_id} (signals={result.signal_hints})"
                )
                return result
            except Exception as e:
                logger.debug(f"WebSocket deep check failed: {e}")

        # -- Tier 3: Async judge fallback (local/REST) --
        async_judge = getattr(aigie, "_async_judge_runner", None)
        if async_judge:
            try:
                async_judge.fire_and_forget(
                    trace_id=trace_id,
                    span_id=span_id,
                    span_type=span_type,
                    output_content=output_content or "",
                    input_messages=input_messages or [],
                    error=error,
                    signal_hints=result.signal_hints,
                    metadata=metadata,
                )
                result.deep_check_sent = True
                logger.debug(
                    f"Deep check sent via async judge for {span_id} (signals={result.signal_hints})"
                )
            except Exception as e:
                logger.debug(f"Async judge fallback failed: {e}")

    except Exception as e:
        logger.debug(f"assess_step failed (non-fatal): {e}")

    return result


def _schedule_async(coro: Any) -> None:
    """Schedule a coroutine without blocking. Never raises."""
    from ..utils.safe import schedule_async

    schedule_async(coro)
