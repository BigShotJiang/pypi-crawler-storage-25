"""
OTel Bridge Exporter for Aigie SDK.

Converts OpenTelemetry spans from library instrumentors (psycopg2, redis, httpx, etc.)
into Aigie SPAN_CREATE + SPAN_UPDATE events via the shared EventBuffer.

Architecture:
    OTel Instrumentor -> TracerProvider -> AigieContextProcessor (on_start: captures
                                          Aigie parent from ContextVars)
                                       -> BatchSpanProcessor -> AigieBridgeExporter
                                                                       |
                                                               Convert OTel span
                                                               to Aigie events
                                                                       |
                                                               EventBuffer -> Backend

Threading model:
    - on_start() runs in the CALLER thread (where ContextVars are set)
    - export()  runs in BatchSpanProcessor's BACKGROUND thread
    - We capture Aigie parent info in on_start() as span attributes,
      then read them back in export() — no ContextVar access needed at export time.
"""

from __future__ import annotations

import logging
import threading
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Mapping, Sequence
from uuid import uuid4

if TYPE_CHECKING:
    from ..buffer import EventBuffer

logger = logging.getLogger(__name__)

# Thread-safe state
_bridge_lock = threading.Lock()
_bridge_buffer: EventBuffer | None = None
_bridge_initialized: bool = False

# Thread-keyed fallback context for frameworks that dispatch to thread pools.
# Keyed by thread ID so concurrent agents in different threads don't collide.
# Each thread sees its own trace/span context.
_thread_traces: dict[int, str] = {}  # thread_id -> trace_id
_thread_spans: dict[int, str] = {}  # thread_id -> span_id
_thread_ctx_lock = threading.Lock()

# Internal attribute keys for Aigie context (stripped before sending to backend)
_AIGIE_TRACE_ID = "aigie.trace_id"
_AIGIE_PARENT_ID = "aigie.parent_id"

# OTel semantic convention attribute keys
_DB_SYSTEM = "db.system"
_DB_STATEMENT = "db.statement"
_DB_NAME = "db.name"
_DB_OPERATION = "db.operation"
_HTTP_METHOD = "http.method"
_HTTP_URL = "http.url"
_HTTP_STATUS_CODE = "http.status_code"
_HTTP_TARGET = "http.target"
_NET_PEER_NAME = "net.peer.name"
_NET_PEER_PORT = "net.peer.port"

# Redis-like systems categorized as "cache"
_CACHE_SYSTEMS = frozenset({"redis", "memcached", "valkey"})

# SQL statement truncation limit
_MAX_DB_STATEMENT_LEN = 2000

# Map OTel db.system values to friendly display names
_DB_SYSTEM_NAMES: dict[str, str] = {
    "postgresql": "PostgreSQL",
    "mysql": "MySQL",
    "sqlite": "SQLite",
    "mongodb": "MongoDB",
    "redis": "Redis",
    "memcached": "Memcached",
    "elasticsearch": "Elasticsearch",
    "mssql": "SQL Server",
    "oracle": "Oracle",
    "cassandra": "Cassandra",
}


def _friendly_db_name(db_system: str) -> str:
    """Get a human-friendly name for a database system."""
    return _DB_SYSTEM_NAMES.get(db_system, db_system)


def _infer_span_type(attributes: Mapping[str, Any]) -> str:
    """Map OTel span attributes to an Aigie span type."""
    db_system = attributes.get(_DB_SYSTEM)
    if db_system:
        if db_system in _CACHE_SYSTEMS:
            return "cache"
        return "database"

    # Check both old (http.method) and new (http.request.method) OTel conventions
    if (
        attributes.get(_HTTP_METHOD)
        or attributes.get(_HTTP_URL)
        or attributes.get("http.request.method")
        or attributes.get("url.full")
    ):
        return "http"

    return "tool"


def _extract_metadata(attributes: Mapping[str, Any]) -> dict[str, Any]:
    """Extract relevant OTel attributes into Aigie metadata format.

    Handles both old (http.method) and new (http.request.method) OTel conventions.
    """
    metadata: dict[str, Any] = {"span_source": "otel_bridge"}

    db_system = attributes.get(_DB_SYSTEM)
    if db_system:
        metadata["db.system"] = db_system
        metadata["db.system_name"] = _friendly_db_name(db_system)
        if _DB_STATEMENT in attributes:
            stmt = str(attributes[_DB_STATEMENT])
            metadata["db.statement"] = (
                stmt[:_MAX_DB_STATEMENT_LEN] if len(stmt) > _MAX_DB_STATEMENT_LEN else stmt
            )
        if _DB_NAME in attributes:
            metadata["db.name"] = attributes[_DB_NAME]
        if _DB_OPERATION in attributes:
            metadata["db.operation"] = attributes[_DB_OPERATION]

    # Handle both old and new OTel HTTP conventions
    http_method = attributes.get(_HTTP_METHOD) or attributes.get("http.request.method")
    if http_method:
        metadata["http.method"] = http_method
    http_url = attributes.get(_HTTP_URL) or attributes.get("url.full")
    if http_url:
        metadata["http.url"] = str(http_url)
    if _HTTP_TARGET in attributes:
        metadata["http.target"] = str(attributes[_HTTP_TARGET])
    http_status = attributes.get(_HTTP_STATUS_CODE) or attributes.get("http.response.status_code")
    if http_status:
        metadata["http.status_code"] = http_status
    http_host = attributes.get(_NET_PEER_NAME) or attributes.get("server.address")
    if http_host:
        metadata["http.host"] = http_host

    peer_name = attributes.get(_NET_PEER_NAME) or attributes.get("server.address")
    if peer_name and "http.host" not in metadata:
        metadata["net.peer.name"] = peer_name
    peer_port = attributes.get(_NET_PEER_PORT) or attributes.get("server.port")
    if peer_port:
        metadata["net.peer.port"] = peer_port

    return metadata


_INTERNAL_PATHS = (
    "/api/v1/ingestion",
    "/api/v1/spans",
    "/api/v1/traces",
    "/api/v1/gateway",
    "/api/v1/health",
    "/api/v1/mode",
)


def _is_internal_sdk_call(attributes: Mapping[str, Any]) -> bool:
    """Check if this HTTP span is an internal Aigie SDK call.

    Internal calls are dropped — customers should never see SDK internals.
    SDK latency monitoring can be added as a separate telemetry channel later.
    """
    url = str(attributes.get(_HTTP_URL, "") or attributes.get("url.full", ""))
    if not url:
        return False
    return any(path in url for path in _INTERNAL_PATHS)


def _derive_span_name(otel_name: str, attributes: Mapping[str, Any]) -> str:
    """Create a human-readable span name from OTel data."""
    db_system = attributes.get(_DB_SYSTEM)
    if db_system:
        friendly = _friendly_db_name(db_system)
        operation = attributes.get(_DB_OPERATION, "")
        db_name = attributes.get(_DB_NAME, "")
        if operation and db_name:
            return f"{friendly}: {operation} {db_name}"
        if operation:
            return f"{friendly}: {operation}"
        return f"{friendly}: {otel_name}"

    http_method = attributes.get(_HTTP_METHOD)
    if http_method:
        url = attributes.get(_HTTP_URL, attributes.get(_HTTP_TARGET, ""))
        if url:
            return f"HTTP {http_method} {url}"
        return f"HTTP {http_method}"

    return otel_name


def _get_buffer() -> EventBuffer | None:
    """Lazily get the shared event buffer from the global Aigie instance."""
    global _bridge_buffer
    with _bridge_lock:
        if _bridge_buffer is not None:
            return _bridge_buffer

        try:
            from ..client import _global_aigie

            if _global_aigie and hasattr(_global_aigie, "_buffer") and _global_aigie._buffer:
                _bridge_buffer = _global_aigie._buffer
                return _bridge_buffer
        except ImportError:
            pass

    return None


def _export_otel_spans(otel_spans: Sequence[Any]) -> None:
    """
    Enrich parent Aigie spans with infrastructure metadata from OTel spans.

    Instead of creating separate child spans (which clutter the UI), we merge
    the infrastructure details (db.system, http.url, etc.) into the parent
    span's metadata. This makes the timeline clean while still capturing
    all the infrastructure data.

    Called by AigieBridgeExporter.export() from BatchSpanProcessor's background thread.
    """
    buffer = _get_buffer()
    if not buffer:
        return

    from ..buffer import EventType
    from ..utils.safe import schedule_async

    # Group OTel spans by parent (Aigie span ID) to merge multiple infra calls
    enrichments: dict[str, dict[str, Any]] = {}

    for otel_span in otel_spans:
        try:
            attrs = dict(otel_span.attributes) if otel_span.attributes else {}

            # Read Aigie context captured at span creation time by AigieContextProcessor
            trace_id = attrs.pop(_AIGIE_TRACE_ID, None)
            parent_id = attrs.pop(_AIGIE_PARENT_ID, None)

            if not trace_id or not parent_id:
                continue

            # Skip when parent is the trace itself — we can only enrich real spans.
            # When parent_id == trace_id, there's no span to attach metadata to.
            if parent_id == trace_id:
                continue

            metadata = _extract_metadata(attrs)

            # Tag internal SDK calls so platform can filter them from the UI
            if _is_internal_sdk_call(attrs):
                metadata["internal_sdk_call"] = True
            span_type = _infer_span_type(attrs)

            # Determine status
            is_error = False
            if hasattr(otel_span, "status") and otel_span.status:
                try:
                    from opentelemetry.trace import StatusCode

                    if otel_span.status.status_code == StatusCode.ERROR:
                        is_error = True
                        if otel_span.status.description:
                            metadata["error.message"] = otel_span.status.description
                except ImportError:
                    pass

            # Calculate duration
            duration_ms = None
            if otel_span.start_time and otel_span.end_time:
                duration_ms = round((otel_span.end_time - otel_span.start_time) / 1e6, 1)

            is_internal = _is_internal_sdk_call(attrs)
            if is_internal:
                metadata["internal_sdk_call"] = True

            # Build enrichment key
            key = f"{parent_id}:{trace_id}"
            if key not in enrichments:
                enrichments[key] = {
                    "trace_id": trace_id,
                    "parent_id": parent_id,
                    "infra_calls": [],
                    "sdk_calls": [],
                    "metadata": {},
                }

            # Build call info
            call_info: dict[str, Any] = {"type": span_type}
            if span_type == "database":
                call_info["db_system"] = metadata.get("db.system", "")
                call_info["db_name"] = metadata.get("db.system_name", "")
                if "db.operation" in metadata:
                    call_info["operation"] = metadata["db.operation"]
            elif span_type == "http":
                call_info["method"] = metadata.get("http.method", "")
                call_info["url"] = metadata.get("http.url", "")
                call_info["status"] = metadata.get("http.status_code", "")
                call_info["host"] = metadata.get("http.host", "")
            elif span_type == "cache":
                call_info["system"] = metadata.get("db.system", "")

            if duration_ms is not None:
                call_info["duration_ms"] = duration_ms
            if is_error:
                call_info["error"] = True

            # Separate internal SDK calls from real infrastructure calls
            if is_internal:
                enrichments[key]["sdk_calls"].append(call_info)
            else:
                enrichments[key]["infra_calls"].append(call_info)
                # Only merge external call metadata into parent
                for k, v in metadata.items():
                    if k not in enrichments[key]["metadata"]:
                        enrichments[key]["metadata"][k] = v

        except Exception:
            logger.debug(
                "Failed to process OTel span: %s",
                getattr(otel_span, "name", "<unknown>"),
                exc_info=True,
            )

    # Aggregate by trace and store via TRACE_UPDATE (traces always exist,
    # no timing race). Include per-span breakdown keyed by parent span ID.
    trace_data: dict[str, dict[str, Any]] = {}

    for key, enrichment in enrichments.items():
        try:
            trace_id = enrichment["trace_id"]
            parent_id = enrichment["parent_id"]
            infra_calls = enrichment["infra_calls"]
            sdk_calls = enrichment["sdk_calls"]

            if trace_id not in trace_data:
                trace_data[trace_id] = {"infra_by_span": {}, "all_infra": [], "all_sdk": []}

            trace_data[trace_id]["all_infra"].extend(infra_calls)
            trace_data[trace_id]["all_sdk"].extend(sdk_calls)

            # Per-span breakdown
            if infra_calls and parent_id != trace_id:
                span_summary: dict[str, Any] = {"call_count": len(infra_calls)}
                http_calls = [c for c in infra_calls if c["type"] == "http"]
                db_calls = [c for c in infra_calls if c["type"] == "database"]
                if http_calls:
                    url_counts: dict[str, int] = {}
                    for c in http_calls:
                        method = c.get("method", "")
                        url = c.get("url", "")
                        if url:
                            try:
                                from urllib.parse import urlparse

                                parsed = urlparse(url)
                                short = f"{parsed.netloc}{'/'.join(parsed.path.split('/')[:3])}"
                            except Exception:
                                short = url[:80]
                            label = f"{method} {short}" if method else short
                            url_counts[label] = url_counts.get(label, 0) + 1
                    span_summary["http_urls"] = [
                        f"{u} (x{n})" if n > 1 else u
                        for u, n in sorted(url_counts.items(), key=lambda x: -x[1])
                    ]
                if db_calls:
                    op_counts: dict[str, int] = {}
                    for c in db_calls:
                        op = c.get("operation", "")
                        db_name = c.get("db_name", "")
                        label = f"{op} {db_name}".strip() if op else db_name
                        if label:
                            op_counts[label] = op_counts.get(label, 0) + 1
                    span_summary["db_operations"] = [
                        f"{o} (x{n})" if n > 1 else o
                        for o, n in sorted(op_counts.items(), key=lambda x: -x[1])
                    ]
                dur = sum(c.get("duration_ms", 0) for c in infra_calls if c.get("duration_ms"))
                if dur:
                    span_summary["duration_ms"] = round(dur, 1)
                trace_data[trace_id]["infra_by_span"][parent_id[:8]] = span_summary
        except Exception:
            logger.debug("Failed to aggregate enrichment for %s", key, exc_info=True)

    for trace_id, data in trace_data.items():
        try:
            infra_calls = data["all_infra"]
            sdk_calls = data["all_sdk"]

            trace_meta: dict[str, Any] = {}

            if infra_calls:
                db_calls = [c for c in infra_calls if c["type"] == "database"]
                http_calls = [c for c in infra_calls if c["type"] == "http"]
                cache_calls = [c for c in infra_calls if c["type"] == "cache"]

                trace_meta["infra_call_count"] = len(infra_calls)
                if db_calls:
                    trace_meta["infra_db_calls"] = len(db_calls)
                    trace_meta["infra_db_systems"] = list(
                        {c.get("db_name", "") for c in db_calls if c.get("db_name")}
                    )
                if http_calls:
                    trace_meta["infra_http_calls"] = len(http_calls)
                    hosts = list({c.get("host", "") for c in http_calls if c.get("host")})
                    if hosts:
                        trace_meta["infra_http_hosts"] = hosts
                if cache_calls:
                    trace_meta["infra_cache_calls"] = len(cache_calls)
                infra_total_ms = sum(
                    c.get("duration_ms", 0) for c in infra_calls if c.get("duration_ms")
                )
                if infra_total_ms:
                    trace_meta["infra_duration_ms"] = round(infra_total_ms, 1)
                infra_errors = sum(1 for c in infra_calls if c.get("error"))
                if infra_errors:
                    trace_meta["infra_error_count"] = infra_errors

            # --- Internal SDK calls ---
            if sdk_calls:
                sdk_durations = [c["duration_ms"] for c in sdk_calls if c.get("duration_ms")]
                trace_meta["sdk_call_count"] = len(sdk_calls)
                if sdk_durations:
                    trace_meta["sdk_total_latency_ms"] = round(sum(sdk_durations), 1)
                    trace_meta["sdk_avg_latency_ms"] = round(
                        sum(sdk_durations) / len(sdk_durations), 1
                    )
                    trace_meta["sdk_max_latency_ms"] = round(max(sdk_durations), 1)
                sdk_errors = sum(1 for c in sdk_calls if c.get("error"))
                if sdk_errors:
                    trace_meta["sdk_error_count"] = sdk_errors

            # Include per-span breakdown
            if data["infra_by_span"]:
                trace_meta["infra_by_span"] = data["infra_by_span"]

            # Store on trace via TRACE_UPDATE — traces always exist, no timing race.
            # Trace metadata uses || (JSONB merge) in SQL, so existing keys preserved.
            if trace_meta:
                schedule_async(
                    buffer.add(
                        EventType.TRACE_UPDATE,
                        {
                            "id": trace_id,
                            "trace_id": trace_id,
                            "metadata": trace_meta,
                        },
                    )
                )

        except Exception:
            logger.debug("Failed to send trace enrichment for %s", trace_id, exc_info=True)


def set_process_trace_id(trace_id: str | None, span_id: str | None = None) -> None:
    """Set the trace/span IDs for the current thread.

    Thread-keyed: concurrent agents in different threads won't collide.
    Called by framework auto-instruments when a trace starts.
    """
    tid = threading.get_ident()
    with _thread_ctx_lock:
        if trace_id:
            _thread_traces[tid] = trace_id
        else:
            _thread_traces.pop(tid, None)
        if span_id:
            _thread_spans[tid] = span_id
        else:
            _thread_spans.pop(tid, None)


def set_process_span_id(span_id: str | None) -> None:
    """Update the current span ID for the current thread.

    Called by framework callbacks when entering/exiting spans.
    """
    tid = threading.get_ident()
    with _thread_ctx_lock:
        if span_id:
            _thread_spans[tid] = span_id
        else:
            _thread_spans.pop(tid, None)


def _setup_otel_bridge() -> bool:
    """
    Set up the OTel TracerProvider with the Aigie bridge.

    Installs two components:
    1. AigieContextProcessor — captures Aigie parent context at span start (caller thread)
    2. AigieBridgeExporter — converts OTel spans to Aigie events at export time (bg thread)

    Returns True if setup succeeded.
    """
    global _bridge_initialized

    with _bridge_lock:
        if _bridge_initialized:
            return True

        try:
            from opentelemetry.context import Context
            from opentelemetry.sdk.trace import SpanProcessor, TracerProvider
            from opentelemetry.sdk.trace.export import (
                BatchSpanProcessor,
                SpanExporter,
                SpanExportResult,
            )
        except ImportError:
            logger.debug("opentelemetry-sdk not installed, skipping OTel bridge setup")
            return False

        class AigieContextProcessor(SpanProcessor):
            """Captures Aigie trace/span context at span creation time.

            on_start() runs in the CALLER's thread where ContextVars are set,
            so we can read the current Aigie trace/span and attach the IDs as
            span attributes. The exporter reads these back later from the
            background thread where ContextVars are NOT available.
            """

            def on_start(self, span: Any, parent_context: Context | None = None) -> None:
                try:
                    trace_id = None
                    parent_id = None

                    # Step 1: Find trace_id from ContextVars or process-level fallback
                    try:
                        from ..context_manager import (
                            get_current_span_context,
                            get_current_trace_context,
                        )

                        span_ctx = get_current_span_context()
                        trace_ctx = get_current_trace_context()

                        if span_ctx:
                            parent_id = span_ctx.id
                            trace_id = span_ctx.metadata.get("trace_id") or (
                                trace_ctx.id if trace_ctx else None
                            )
                        elif trace_ctx:
                            trace_id = trace_ctx.id
                    except Exception:
                        pass

                    if not trace_id:
                        try:
                            from .trace import get_current_trace

                            auto_trace = get_current_trace()
                            if auto_trace:
                                trace_id = getattr(auto_trace, "id", None)
                        except Exception:
                            pass

                    if not trace_id:
                        tid = threading.get_ident()
                        with _thread_ctx_lock:
                            trace_id = _thread_traces.get(tid)

                    if not trace_id:
                        return  # No active trace — skip

                    # Step 2: Find best parent span ID.
                    # Check thread-keyed span context (set synchronously by callbacks).
                    if not parent_id:
                        tid = threading.get_ident()
                        with _thread_ctx_lock:
                            parent_id = _thread_spans.get(tid) or trace_id

                    logger.debug(
                        "otel_bridge on_start: span=%s trace=%s parent=%s (parent==trace: %s)",
                        getattr(span, "name", "?"),
                        trace_id[:8] if trace_id else "None",
                        parent_id[:8] if parent_id else "None",
                        parent_id == trace_id,
                    )

                    if hasattr(span, "set_attribute"):
                        span.set_attribute(_AIGIE_TRACE_ID, trace_id)
                        span.set_attribute(_AIGIE_PARENT_ID, parent_id)
                except Exception:
                    pass  # Never crash the caller's code path

            def on_end(self, span: Any) -> None:
                pass

            def shutdown(self) -> None:
                pass

            def force_flush(self, timeout_millis: int = 30000) -> bool:
                return True

        class AigieBridgeExporter(SpanExporter):
            """Exports OTel spans by converting them to Aigie span events."""

            def export(self, spans: Sequence[Any]) -> SpanExportResult:
                try:
                    _export_otel_spans(spans)
                    return SpanExportResult.SUCCESS
                except Exception:
                    logger.debug("AigieBridgeExporter.export failed", exc_info=True)
                    return SpanExportResult.FAILURE

            def shutdown(self) -> None:
                logger.debug("AigieBridgeExporter shutting down")

            def force_flush(self, timeout_millis: int = 30000) -> bool:
                buf = _get_buffer()
                if buf is not None and hasattr(buf, "flush"):
                    from ..utils.safe import schedule_async

                    schedule_async(buf.flush())
                return True

        # Create TracerProvider with both processors
        provider = TracerProvider()

        # 1. Context capture processor (runs on_start in caller thread)
        context_processor = AigieContextProcessor()
        provider.add_span_processor(context_processor)

        # 2. Batch export processor (exports from background thread)
        exporter = AigieBridgeExporter()
        batch_processor = BatchSpanProcessor(
            exporter,
            max_queue_size=512,
            max_export_batch_size=64,
            schedule_delay_millis=5000,
        )
        provider.add_span_processor(batch_processor)

        # Set as the global TracerProvider ONLY if none is set yet
        from opentelemetry import trace as otel_trace

        current_provider = otel_trace.get_tracer_provider()
        provider_type = type(current_provider).__name__

        if provider_type in ("ProxyTracerProvider", "_DefaultTracerProvider"):
            otel_trace.set_tracer_provider(provider)
        else:
            # User already has their own OTel setup — add our processors to it
            if hasattr(current_provider, "add_span_processor"):
                current_provider.add_span_processor(context_processor)
                current_provider.add_span_processor(batch_processor)
            else:
                logger.debug(
                    "Cannot add bridge processors to existing OTel provider (type=%s), skipping",
                    provider_type,
                )
                return False

        _bridge_initialized = True
        logger.debug("OTel bridge exporter initialized")
        return True


def _teardown_otel_bridge() -> None:
    """Reset bridge state so it can be re-initialized after disable_all()."""
    global _bridge_initialized, _bridge_buffer
    with _bridge_lock:
        _bridge_initialized = False
        _bridge_buffer = None
    with _thread_ctx_lock:
        _thread_traces.clear()
        _thread_spans.clear()
