"""Test that send_deep_eval calls _send (not _send_message)."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from aigie.realtime.base_ws import ConnectionState
from aigie.realtime.connector import BackendConnector


@pytest.mark.asyncio
async def test_send_deep_eval_calls_send():
    """send_deep_eval should call _send(), not _send_message()."""
    connector = BackendConnector.__new__(BackendConnector)
    connector._state = ConnectionState.CONNECTED
    connector._websocket = MagicMock()
    connector._send = AsyncMock(return_value=True)
    connector._stats = {"consultations": 0}

    await connector.send_deep_eval(
        trace_id="trace-1",
        span_id="span-1",
        span_type="llm",
        output_content="test output",
        input_messages=[],
        signal_hints=[],
    )

    connector._send.assert_called_once()
    msg = connector._send.call_args[0][0]
    assert msg["type"] == "consultation"
    assert msg["payload"]["context"]["trace_id"] == "trace-1"


@pytest.mark.asyncio
async def test_send_deep_eval_not_called_when_disconnected():
    """_send should NOT be called when connector is disconnected."""
    connector = BackendConnector.__new__(BackendConnector)
    connector._state = ConnectionState.DISCONNECTED
    connector._websocket = None
    connector._send = AsyncMock(return_value=True)
    connector._stats = {"consultations": 0}

    await connector.send_deep_eval(
        trace_id="t1",
        span_id="s1",
        span_type="llm",
        output_content="x",
        input_messages=[],
        signal_hints=[],
    )

    connector._send.assert_not_called()
