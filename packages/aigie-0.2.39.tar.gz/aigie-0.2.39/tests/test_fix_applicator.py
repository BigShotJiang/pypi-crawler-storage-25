"""Tests for fix applicator dispatcher."""

import pytest

from aigie.realtime.fix_applicator import (
    _adapters,
    apply_framework_fix,
    get_registered_frameworks,
    register_fix_adapter,
)


class MockAdapter:
    def __init__(self, return_value=True):
        self._return_value = return_value
        self.last_payload = None
        self.last_context = None

    def apply_fix(self, fix_payload, context):
        self.last_payload = fix_payload
        self.last_context = context
        return self._return_value


@pytest.fixture(autouse=True)
def clear_registry():
    _adapters.clear()
    yield
    _adapters.clear()


def test_register_and_apply():
    adapter = MockAdapter()
    register_fix_adapter("test_framework", adapter)
    result = apply_framework_fix("test_framework", {"strategy": "REPLACE"}, "ctx")
    assert result is True
    assert adapter.last_payload == {"strategy": "REPLACE"}
    assert adapter.last_context == "ctx"


def test_apply_unknown_framework():
    result = apply_framework_fix("unknown", {"strategy": "REPLACE"}, "ctx")
    assert result is False


def test_apply_adapter_exception():
    class BadAdapter:
        def apply_fix(self, fix_payload, context):
            raise RuntimeError("boom")

    register_fix_adapter("bad", BadAdapter())
    result = apply_framework_fix("bad", {"strategy": "REPLACE"}, "ctx")
    assert result is False


def test_get_registered_frameworks():
    register_fix_adapter("a", MockAdapter())
    register_fix_adapter("b", MockAdapter())
    assert sorted(get_registered_frameworks()) == ["a", "b"]


def test_adapter_returning_false():
    adapter = MockAdapter(return_value=False)
    register_fix_adapter("failing", adapter)
    result = apply_framework_fix("failing", {"strategy": "REPLACE"}, "ctx")
    assert result is False
