"""Test that send_deep_eval produces the correct message format."""

from unittest.mock import MagicMock

import pytest

from aigie.realtime.base_ws import ConnectionState


@pytest.mark.asyncio
async def test_send_deep_eval_wraps_in_payload():
    """send_deep_eval must wrap fields in a payload dict matching _send_consultation format."""
    from aigie.realtime.connector import BackendConnector

    connector = BackendConnector.__new__(BackendConnector)
    connector._state = ConnectionState.CONNECTED
    connector._websocket = MagicMock()
    connector._stats = {"consultations": 0}

    sent_messages = []

    async def fake_send(msg):
        sent_messages.append(msg)

    connector._send = fake_send

    await connector.send_deep_eval(
        trace_id="trace-001",
        span_id="span-001",
        span_type="llm",
        output_content="test output",
        input_messages=[{"role": "user", "content": "hello"}],
        signal_hints=["hallucination_marker"],
        metadata={"model": "gpt-4"},
    )

    assert len(sent_messages) == 1
    msg = sent_messages[0]

    # Must have top-level type and payload
    assert msg["type"] == "consultation"
    assert "payload" in msg, "Message must have 'payload' wrapper"
    assert "timestamp" in msg

    payload = msg["payload"]
    assert payload["consultation_type"] == "deep_eval"
    assert "request_id" in payload
    assert payload["urgency"] == "normal"

    ctx = payload["context"]
    assert ctx["trace_id"] == "trace-001"
    assert ctx["span_type"] == "llm"
    assert ctx["output_content"] == "test output"
    assert ctx["signal_hints"] == ["hallucination_marker"]


@pytest.mark.asyncio
async def test_send_deep_eval_truncates_output():
    """Output content must be truncated to 2000 chars."""
    from aigie.realtime.connector import BackendConnector

    connector = BackendConnector.__new__(BackendConnector)
    connector._state = ConnectionState.CONNECTED
    connector._websocket = MagicMock()
    connector._stats = {"consultations": 0}

    sent_messages = []

    async def fake_send(msg):
        sent_messages.append(msg)

    connector._send = fake_send

    long_output = "x" * 5000
    await connector.send_deep_eval(
        trace_id="t",
        span_id="s",
        span_type="llm",
        output_content=long_output,
        input_messages=[],
        signal_hints=[],
    )

    ctx = sent_messages[0]["payload"]["context"]
    assert len(ctx["output_content"]) == 2000


@pytest.mark.asyncio
async def test_send_deep_eval_limits_input_messages():
    """Input messages must be limited to last 5."""
    from aigie.realtime.connector import BackendConnector

    connector = BackendConnector.__new__(BackendConnector)
    connector._state = ConnectionState.CONNECTED
    connector._websocket = MagicMock()
    connector._stats = {"consultations": 0}

    sent_messages = []

    async def fake_send(msg):
        sent_messages.append(msg)

    connector._send = fake_send

    messages = [{"role": "user", "content": f"msg-{i}"} for i in range(10)]
    await connector.send_deep_eval(
        trace_id="t",
        span_id="s",
        span_type="llm",
        output_content="out",
        input_messages=messages,
        signal_hints=[],
    )

    ctx = sent_messages[0]["payload"]["context"]
    assert len(ctx["input_messages"]) == 5
    assert ctx["input_messages"][0]["content"] == "msg-5"
