"""Test that _handle_fix_push routes fixes to InterventionDispatcher."""

import threading
from unittest.mock import MagicMock


def test_handle_fix_push_queues_intervention():
    """Fix push data should be converted to InterventionSignal and queued."""
    from aigie.client import Aigie

    client = Aigie.__new__(Aigie)

    mock_dispatcher = MagicMock()
    pending = {}
    lock = threading.Lock()
    mock_dispatcher._pending = pending
    mock_dispatcher._sync_lock = lock

    client._intervention_dispatcher = mock_dispatcher

    fix_data = {
        "trace_id": "trace-fix-001",
        "intervention_type": "trace_fix",
        "fix_action": "RETRY",
        "strategy": "RETRY",
        "confidence": 0.85,
        "reason": "Hallucination detected, retry with grounding",
        "guidance_text": "Kytte detected hallucination and recommends: RETRY",
    }

    client._handle_fix_push(fix_data)

    assert "trace-fix-001" in pending
    assert len(pending["trace-fix-001"]) == 1
    signal = pending["trace-fix-001"][0]
    assert signal.trace_id == "trace-fix-001"
    assert signal.intervention_type == "trace_fix"
    assert signal.confidence == 0.85
    assert signal.payload["fix_action"] == "RETRY"


def test_handle_fix_push_no_dispatcher_no_crash():
    """If no InterventionDispatcher, should log and return without crashing."""
    from aigie.client import Aigie

    client = Aigie.__new__(Aigie)
    client._intervention_dispatcher = None

    fix_data = {
        "trace_id": "trace-fix-002",
        "fix_action": "FALLBACK_MODEL",
        "confidence": 0.7,
    }

    client._handle_fix_push(fix_data)


def test_handle_fix_push_missing_trace_id():
    """If fix_data has no trace_id, should skip without crashing."""
    from aigie.client import Aigie

    client = Aigie.__new__(Aigie)
    mock_dispatcher = MagicMock()
    mock_dispatcher._pending = {}
    mock_dispatcher._sync_lock = threading.Lock()
    client._intervention_dispatcher = mock_dispatcher

    fix_data = {"fix_action": "RETRY", "confidence": 0.8}

    client._handle_fix_push(fix_data)
    assert len(mock_dispatcher._pending) == 0


def test_handle_fix_push_high_confidence_gets_higher_priority():
    """Fixes with confidence >= 0.8 should get priority 3, otherwise 5."""
    from aigie.client import Aigie

    client = Aigie.__new__(Aigie)
    mock_dispatcher = MagicMock()
    pending = {}
    mock_dispatcher._pending = pending
    mock_dispatcher._sync_lock = threading.Lock()
    client._intervention_dispatcher = mock_dispatcher

    client._handle_fix_push(
        {
            "trace_id": "trace-hi",
            "fix_action": "RETRY",
            "confidence": 0.9,
        }
    )

    client._handle_fix_push(
        {
            "trace_id": "trace-lo",
            "fix_action": "RETRY",
            "confidence": 0.5,
        }
    )

    assert pending["trace-hi"][0].priority == 3
    assert pending["trace-lo"][0].priority == 5
