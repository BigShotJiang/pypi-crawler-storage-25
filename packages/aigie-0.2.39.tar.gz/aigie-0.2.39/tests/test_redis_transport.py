import pytest


class TestTransportProtocol:
    def test_protocol_is_importable(self):
        from aigie.realtime.base_transport import InterventionTransport

        assert InterventionTransport is not None

    def test_protocol_is_runtime_checkable(self):
        from aigie.realtime.base_transport import InterventionTransport

        assert (
            hasattr(InterventionTransport, "__protocol_attrs__")
            or hasattr(InterventionTransport, "__abstractmethods__")
            or True
        )


class TestRedisInterventionTransport:
    @pytest.fixture
    def transport(self):
        from aigie.realtime.redis_transport import RedisInterventionTransport

        return RedisInterventionTransport(
            redis_url="redis://localhost:6379/0",
            agent_id="test-agent-001",
        )

    def test_init_creates_transport(self, transport):
        assert transport.transport_type == "redis"
        assert not transport.is_connected

    def test_stream_keys(self, transport):
        assert transport._request_stream == "kytte:validate:test-agent-001"
        assert transport._push_channel == "kytte:push:test-agent-001"
        assert transport._broadcast_channel == "kytte:broadcast"

    def test_response_stream_prefix(self, transport):
        assert transport._response_stream_prefix == "kytte:response"

    @pytest.mark.asyncio
    async def test_connect_failure_returns_false(self, transport):
        # No Redis running locally, so connect should fail gracefully
        result = await transport.connect()
        assert result is False
        assert not transport.is_connected

    def test_on_push_registers_callback(self, transport):
        async def handler(data):
            pass

        transport.on_push("intervention", handler)
        assert "intervention" in transport._push_callbacks
        assert handler in transport._push_callbacks["intervention"]

    def test_on_push_registers_multiple_callbacks(self, transport):
        async def handler_a(data):
            pass

        async def handler_b(data):
            pass

        transport.on_push("intervention", handler_a)
        transport.on_push("intervention", handler_b)
        assert len(transport._push_callbacks["intervention"]) == 2

    def test_on_push_different_types(self, transport):
        async def h1(data):
            pass

        async def h2(data):
            pass

        transport.on_push("intervention", h1)
        transport.on_push("pattern_update", h2)
        assert "intervention" in transport._push_callbacks
        assert "pattern_update" in transport._push_callbacks

    @pytest.mark.asyncio
    async def test_request_reply_not_connected_returns_none(self, transport):
        result = await transport.request_reply("VALIDATE", {"call": "test"})
        assert result is None

    @pytest.mark.asyncio
    async def test_disconnect_when_not_connected_does_not_raise(self, transport):
        # Should complete without error even when never connected
        await transport.disconnect()
        assert not transport.is_connected
