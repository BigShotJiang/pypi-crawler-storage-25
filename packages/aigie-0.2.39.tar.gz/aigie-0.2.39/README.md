# Aigie Python SDK

[![PyPI Version](https://img.shields.io/pypi/v/aigie)](https://pypi.org/project/aigie/)
[![Python Version](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![CI](https://github.com/Kytte-AI/kytte-python-sdk/actions/workflows/ci.yaml/badge.svg)](https://github.com/Kytte-AI/kytte-python-sdk/actions/workflows/ci.yaml)

Official Python SDK for **Aigie** -- AI agent monitoring, tracing, and autonomous remediation.

95% of AI agents never reach production due to context drift, tool errors, and runtime instability.
Aigie provides the infrastructure that makes autonomous AI reliable and production-grade:

- **Detects** context drift and errors before they impact users
- **Fixes** issues automatically through self-healing workflows
- **Prevents** failures with predictive intervention

## Installation

```bash
pip install aigie
```

### With optional integrations

```bash
# Compression (recommended for production -- 50-90% bandwidth savings)
pip install aigie[compression]

# LLM providers
pip install aigie[openai]              # OpenAI
pip install aigie[anthropic]           # Anthropic Claude
pip install aigie[gemini]              # Google Gemini

# Agent frameworks
pip install aigie[langchain]           # LangChain
pip install aigie[langgraph]           # LangGraph
pip install aigie[openai-agents]       # OpenAI Agents SDK
pip install aigie[claude-agent-sdk]    # Anthropic Claude Agent SDK
pip install aigie[strands]             # Strands Agents (AWS/Anthropic)
pip install aigie[google-adk]          # Google Agent Development Kit
pip install aigie[crewai]              # CrewAI multi-agent
pip install aigie[autogen]             # AutoGen/AG2
pip install aigie[llamaindex]          # LlamaIndex RAG
pip install aigie[dspy]                # DSPy
pip install aigie[instructor]          # Instructor structured outputs
pip install aigie[semantic-kernel]     # Microsoft Semantic Kernel
pip install aigie[browser-use]         # Browser-Use automation
pip install aigie[livekit-agents]      # LiveKit real-time voice AI
pip install aigie[agno]                # Agno (formerly Phidata)
pip install aigie[pipecat]             # Pipecat

# Vector databases
pip install aigie[pinecone]            # Pinecone
pip install aigie[qdrant]              # Qdrant
pip install aigie[chromadb]            # ChromaDB
pip install aigie[weaviate]            # Weaviate
pip install aigie[vectordbs]           # All vector DBs

# Observability
pip install aigie[opentelemetry]       # OpenTelemetry inbound
pip install aigie[otlp]                # OTLP export

# Everything
pip install aigie[all]
```

## Quick start

### Decorator-based tracing (recommended)

```python
from aigie import traceable

@traceable(run_type="agent")
async def my_agent(query: str):
    result = await process_query(query)
    return result

result = await my_agent("What is the weather?")
```

### Auto-instrument LLM providers

```python
from aigie import wrap_openai, wrap_anthropic
from openai import AsyncOpenAI
from anthropic import AsyncAnthropic

# OpenAI -- all calls automatically traced with model, tokens, cost, latency
client = wrap_openai(AsyncOpenAI())
response = await client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}],
)

# Anthropic
client = wrap_anthropic(AsyncAnthropic())
```

### Context manager

```python
from aigie import Aigie, Config

config = Config(
    api_url="https://api.aigie.com",
    api_key="your-key",
    batch_size=100,
    flush_interval=5.0,
)

aigie = Aigie(config=config)
await aigie.initialize()

async with aigie.trace("My Workflow") as trace:
    async with trace.span("operation", type="llm") as span:
        result = await do_work()
        span.set_output({"result": result})
```

## Integrations

### Agent frameworks

| Framework | Install extra | Auto-instrument |
|-----------|--------------|-----------------|
| LangChain | `langchain` | `AigieCallbackHandler` |
| LangGraph | `langgraph` | `wrap_langgraph()` |
| OpenAI Agents SDK | `openai-agents` | `patch_openai_agents()` |
| Claude Agent SDK | `claude-agent-sdk` | `patch_claude_agent_sdk()` |
| Strands Agents | `strands` | `patch_strands()` |
| Google ADK | `google-adk` | `patch_google_adk()` |
| CrewAI | `crewai` | `patch_crewai()` |
| AutoGen/AG2 | `autogen` | `patch_autogen()` |
| LlamaIndex | `llamaindex` | `patch_llamaindex()` |
| DSPy | `dspy` | `patch_dspy()` |
| Instructor | `instructor` | `patch_instructor()` |
| Semantic Kernel | `semantic-kernel` | `patch_semantic_kernel()` |
| Browser-Use | `browser-use` | `patch_browser_use()` |
| LiveKit Agents | `livekit-agents` | `patch_livekit_agents()` |
| Pipecat | `pipecat` | `patch_pipecat()` |
| Agno | `agno` | `patch_agno()` |

### LLM providers

| Provider | Wrapper |
|----------|---------|
| OpenAI | `wrap_openai()` |
| Anthropic | `wrap_anthropic()` |
| Google Gemini | `wrap_gemini()` |
| AWS Bedrock | `wrap_bedrock()` |

Each integration lives in `sdk/aigie/integrations/<framework>/` and follows a
consistent pattern with auto-instrumentation, cost tracking, drift detection,
error detection, retry logic, and session management. See
[CONTRIBUTING.md](CONTRIBUTING.md) for details on adding new integrations.

## Configuration

### Environment variables

```bash
export AIGIE_API_URL=https://your-instance.aigie.io/api
export AIGIE_API_KEY=your-api-key
export AIGIE_BATCH_SIZE=100
export AIGIE_FLUSH_INTERVAL=5.0
```

### Config object

```python
from aigie import Config

config = Config(
    api_url="https://api.aigie.com",   # Aigie API endpoint
    api_key="your-key",                # API key
    batch_size=100,                    # Events per batch (default: 10)
    flush_interval=5.0,               # Flush interval in seconds
    enable_buffering=True,            # Enable event buffering (default: True)
    max_retries=3,                    # Retry count on failure
)
```

## Advanced features

### OpenTelemetry integration

```python
from aigie import Aigie
from aigie.opentelemetry import setup_opentelemetry

aigie = Aigie()
await aigie.initialize()
setup_opentelemetry(aigie, service_name="my-service")

# All OTel spans now flow to Aigie
from opentelemetry import trace
tracer = trace.get_tracer(__name__)
with tracer.start_as_current_span("operation"):
    pass
```

### Evaluation and scoring

```python
from aigie import score, feedback

await score(trace_id, "accuracy", 0.95)
await feedback(trace_id, "user_feedback", "Great response!")
```

### Prompt management

```python
from aigie import Prompt

prompt = Prompt.chat(
    name="customer_support",
    messages=[{"role": "system", "content": "You are a helpful assistant."}],
    version="1.0",
)
```

### Synchronous API

```python
from aigie import AigieSync

aigie = AigieSync()
aigie.initialize()

with aigie.trace("workflow") as trace:
    with trace.span("operation") as span:
        result = do_work()
        span.set_output({"result": result})
```

## API reference

Full API documentation is available at [docs.aigie.io/sdk/python](https://docs.aigie.io/sdk/python).

## Development

```bash
# Clone and set up
git clone https://github.com/Kytte-AI/kytte-python-sdk.git
cd kytte-python-sdk
python -m venv .venv
source .venv/bin/activate
pip install -e "sdk/[dev]"
```

### Common commands

```bash
make lint        # Run ruff linter
make format      # Format code with ruff
make test        # Run unit tests
make test-all    # Run all tests including integration
make coverage    # Run tests with coverage report
make typecheck   # Run mypy type checking
make check       # Run all checks (lint + test)
make build       # Build distribution packages
```

### Running tests

```bash
# Unit tests
pytest tests/unit/ -v

# Integration tests (requires API keys)
pytest tests/integration/ -v

# Coverage report
pytest tests/unit/ --cov=sdk/aigie --cov-report=html --cov-report=term-missing
```

## Publishing

Releases are published to [PyPI](https://pypi.org/project/aigie/) automatically
when a GitHub release is created, via the `publish.yaml` workflow.

Manual publishing is also supported:

```bash
./scripts/publish-sdk.sh <version>
# e.g. ./scripts/publish-sdk.sh 0.2.39
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for development setup and guidelines.

## License

MIT -- see [LICENSE](LICENSE) for details.

## Documentation

- [API Reference](https://docs.aigie.io/sdk/python)
- [Integration Guides](https://docs.aigie.io/integrations)
- [Changelog](./CHANGELOG.md)

## Related

| Repository | Description |
|-----------|-------------|
| [kytte-js-sdk](https://github.com/Kytte-AI/kytte-js-sdk) | Aigie TypeScript/JavaScript SDK |
| [docs-site](https://github.com/Kytte-AI/docs-site) | Documentation site |
