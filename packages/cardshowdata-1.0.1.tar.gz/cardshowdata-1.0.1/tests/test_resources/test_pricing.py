"""Tests for the Pricing resource."""

import httpx
import pytest

from cardshowdata import AsyncCardShowData


PRICING_RESPONSE = {
    "product_id": "aaaa-bbbb-cccc",
    "as_of_date": "2026-04-12",
    "market_price_cents": 12500,
    "direct_low_price_cents": 11000,
    "loose_price_cents": None,
    "retail_loose_sell_cents": None,
    "fair_value_cents": 12000,
    "spread_cents": 500,
    "recommended_list_price_cents": 15000,
    "lifecycle_state": "declining",
    "confidence": 0.95,
}


class TestPricing:
    def test_get(self, mock_api, client):
        mock_api.get("/v1/pricing/aaaa-bbbb-cccc").mock(
            return_value=httpx.Response(200, json=PRICING_RESPONSE)
        )
        price = client.pricing.get("aaaa-bbbb-cccc")
        assert price.product_id == "aaaa-bbbb-cccc"
        assert price.market_price_cents == 12500
        assert price.fair_value_cents == 12000
        assert price.confidence == 0.95
        assert price.lifecycle_state == "declining"

    def test_bulk(self, mock_api, client):
        route = mock_api.post("/v1/pricing/bulk").mock(
            return_value=httpx.Response(200, json=[PRICING_RESPONSE, PRICING_RESPONSE])
        )
        results = client.pricing.bulk(["uuid1", "uuid2"])
        assert len(results) == 2
        body = route.calls[0].request.read()
        assert b'"product_ids"' in body

    def test_bulk_with_date(self, mock_api, client):
        route = mock_api.post("/v1/pricing/bulk").mock(
            return_value=httpx.Response(200, json=[PRICING_RESPONSE])
        )
        client.pricing.bulk(["uuid1"], date="2026-01-01")
        body = route.calls[0].request.read()
        assert b'"date"' in body
        assert b'"2026-01-01"' in body

    def test_history(self, mock_api, client):
        route = mock_api.get("/v1/pricing/history/abc").mock(
            return_value=httpx.Response(200, json=[PRICING_RESPONSE, PRICING_RESPONSE])
        )
        results = client.pricing.history("abc", days=90)
        assert len(results) == 2
        assert "days=90" in str(route.calls[0].request.url)

    def test_changes(self, mock_api, client):
        mock_api.get("/v1/pricing/changes").mock(
            return_value=httpx.Response(200, json={
                "items": [{"csd_product_id": "abc", "pretty_id": "pk_bs_004", "tcg_slug": "pk", "old_price_cents": 100, "new_price_cents": 200, "pct_change": 100.0, "snapshot_date": "2026-04-12"}],
                "next_cursor": "cursor_xyz",
                "count": 1,
            })
        )
        page = client.pricing.changes(since="2026-04-07T00:00:00Z")
        assert page.has_next() is True
        assert page.items[0].pct_change == 100.0

    def test_changes_all_auto_pages(self, mock_api, client):
        route = mock_api.get("/v1/pricing/changes")
        route.side_effect = [
            httpx.Response(200, json={
                "items": [{"csd_product_id": "a", "pct_change": 10}],
                "next_cursor": "c1", "count": 2,
            }),
            httpx.Response(200, json={
                "items": [{"csd_product_id": "b", "pct_change": 20}],
                "next_cursor": None, "count": 2,
            }),
        ]
        ids = [c.csd_product_id for c in client.pricing.changes_all(since="2026-04-07T00:00:00Z")]
        assert ids == ["a", "b"]
        assert route.call_count == 2

    @pytest.mark.asyncio
    async def test_async_get(self, mock_api):
        mock_api.get("/v1/pricing/abc").mock(
            return_value=httpx.Response(200, json=PRICING_RESPONSE)
        )
        async with AsyncCardShowData(api_key="test_key_123") as c:
            price = await c.pricing.get("abc")
            assert price.market_price_cents == 12500
