print("knowledge_matters")
