"""Reusable UI automation actions."""
