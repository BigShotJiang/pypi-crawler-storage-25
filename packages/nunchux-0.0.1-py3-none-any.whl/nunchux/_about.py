"""Anchor module for the ``nunchux`` PEP 420 namespace package.

The ``nunchux`` distribution on PyPI is a placeholder that reserves the
top-level ``nunchux`` namespace. The implementation is closed-source
software distributed privately through https://github.com/nunchaku-ai.
"""

__version__ = "0.0.1"
__all__ = ["__version__"]
