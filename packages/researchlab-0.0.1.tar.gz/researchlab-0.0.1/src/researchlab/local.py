"""Local, in-process runner implementation."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Mapping

from .artifacts import ArtifactRepository, LocalArtifactRepository
from .runner import BaseRunner, Dataset, DatasetPayload, EvaluationResult, Model

Evaluator = Callable[[DatasetPayload, Any], EvaluationResult]
"""A pure function that evaluates ``estimator`` on ``dataset`` and returns results."""


class LocalRunner(BaseRunner):
    """Run experiments in the current process.

    Two ways to use it:
      * subclass and implement ``_run_one`` directly, or
      * instantiate with an ``evaluator`` callable — convenient for the common
        case where the evaluation logic is a plain function.
    """

    def __init__(
        self,
        dataset_collection: Mapping[str, Dataset],
        model_collection: Mapping[str, Model],
        artifact_repository: ArtifactRepository | str | Path,
        *,
        evaluator: Evaluator | None = None,
    ) -> None:
        if not isinstance(artifact_repository, ArtifactRepository):
            artifact_repository = LocalArtifactRepository(artifact_repository)
        super().__init__(
            dataset_collection=dataset_collection,
            model_collection=model_collection,
            artifact_repository=artifact_repository,
        )
        self._evaluator = evaluator

    def _run_one(
        self,
        *,
        dataset: DatasetPayload,
        estimator: Any,
    ) -> EvaluationResult:
        if self._evaluator is None:
            raise NotImplementedError(
                "LocalRunner requires either an `evaluator` argument or a subclass "
                "that overrides `_run_one`."
            )
        return self._evaluator(dataset, estimator)
