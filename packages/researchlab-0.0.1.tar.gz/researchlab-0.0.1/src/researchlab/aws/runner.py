"""AWS-aware runner mixin: adds ``aws batch`` and ``aws ecs`` CLI subcommands."""

from __future__ import annotations

from typing import Any, Sequence

import click


class AWSRunner:
    """Mixin that extends any ``BaseRunner`` subclass with AWS submission CLI commands.

    Combine with a concrete runner class to gain an ``aws`` subgroup in its CLI
    with ``batch`` and ``ecs`` sub-commands — no separate submission script needed.

    Usage::

        from researchlab import SklearnClassificationRunner
        from researchlab.aws import AWSRunner, S3ArtifactRepository

        class MyRunner(AWSRunner, SklearnClassificationRunner):
            pass

        runner = MyRunner(
            dataset_collection={...},
            model_collection={...},
            artifact_repository=S3ArtifactRepository("s3://bucket/prefix"),
            cv=StratifiedKFold(n_splits=5),
            metrics={"accuracy": get_scorer("accuracy")},
            container_command=["python", "/app/experiment.py"],
        )

        if __name__ == "__main__":
            runner.cli()

    Then invoke locally::

        # submit every pair as a Batch job
        python experiment.py aws batch \\
            --job-queue my-queue --job-definition my-jobdef

        # submit every pair as an ECS RunTask
        python experiment.py aws ecs \\
            --cluster my-cluster --task-definition my-task \\
            --container-name my-container --subnet subnet-abc

    ``AWSRunner`` must appear **before** the concrete runner in the class bases
    so that its ``_build_cli`` override runs first in the MRO.
    """

    def __init__(
        self,
        *args: Any,
        container_command: Sequence[str],
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)  # type: ignore[call-arg]
        self.container_command: list[str] = list(container_command)

    def _build_cli(self) -> click.Group:
        group: click.Group = super()._build_cli()  # type: ignore[misc]
        runner = self

        @group.group("aws", help="Submit (dataset, model) pairs to AWS Batch or ECS.")
        def aws() -> None:
            pass

        @aws.command("batch")
        @click.option(
            "--job-queue",
            required=True,
            help="Batch job queue name or ARN.",
        )
        @click.option(
            "--job-definition",
            required=True,
            help="Batch job definition name or ARN.",
        )
        @click.option(
            "--job-name-prefix",
            default="researchlab",
            show_default=True,
            help="Prefix prepended to every submitted job name.",
        )
        @click.option(
            "--overwrite",
            is_flag=True,
            default=False,
            help="Pass --overwrite to each container run (re-evaluate already stored pairs).",
        )
        @click.option(
            "--env",
            "-e",
            "environment",
            multiple=True,
            metavar="KEY=VALUE",
            help="Extra environment variable forwarded to every job. May be repeated.",
        )
        def batch_submit(
            job_queue: str,
            job_definition: str,
            job_name_prefix: str,
            overwrite: bool,
            environment: tuple[str, ...],
        ) -> None:
            """Submit one AWS Batch job per (dataset, model) pair."""
            from .batch import submit_jobs

            env = _parse_env(environment)
            submitted = submit_jobs(
                runner,  # type: ignore[arg-type]
                job_queue=job_queue,
                job_definition=job_definition,
                container_command=runner.container_command,
                job_name_prefix=job_name_prefix,
                overwrite=overwrite,
                environment=env or None,
            )
            click.echo(f"Submitted {len(submitted)} Batch job(s).")
            for entry in submitted:
                click.echo(f"  {entry['job_name']}  ->  {entry['job_id']}")

        @aws.command("ecs")
        @click.option("--cluster", required=True, help="ECS cluster name or ARN.")
        @click.option(
            "--task-definition",
            required=True,
            help="ECS task definition family or ARN.",
        )
        @click.option(
            "--container-name",
            required=True,
            help="Name of the container inside the task definition to override.",
        )
        @click.option(
            "--subnet",
            "subnets",
            multiple=True,
            required=True,
            help="VPC subnet ID. May be repeated.",
        )
        @click.option(
            "--security-group",
            "security_groups",
            multiple=True,
            default=(),
            help="Security group ID. May be repeated.",
        )
        @click.option(
            "--assign-public-ip/--no-public-ip",
            default=True,
            show_default=True,
            help="Assign a public IP to the Fargate task.",
        )
        @click.option(
            "--launch-type",
            default="FARGATE",
            show_default=True,
            type=click.Choice(["FARGATE", "EC2"], case_sensitive=False),
            help="ECS launch type.",
        )
        @click.option(
            "--overwrite",
            is_flag=True,
            default=False,
            help="Pass --overwrite to each container run.",
        )
        @click.option(
            "--env",
            "-e",
            "environment",
            multiple=True,
            metavar="KEY=VALUE",
            help="Extra environment variable forwarded to every task. May be repeated.",
        )
        def ecs_submit(
            cluster: str,
            task_definition: str,
            container_name: str,
            subnets: tuple[str, ...],
            security_groups: tuple[str, ...],
            assign_public_ip: bool,
            launch_type: str,
            overwrite: bool,
            environment: tuple[str, ...],
        ) -> None:
            """Submit one ECS RunTask per (dataset, model) pair."""
            from .ecs import submit_run_tasks

            env = _parse_env(environment)
            network = {
                "awsvpcConfiguration": {
                    "subnets": list(subnets),
                    "securityGroups": list(security_groups),
                    "assignPublicIp": "ENABLED" if assign_public_ip else "DISABLED",
                }
            }
            submitted = submit_run_tasks(
                runner,  # type: ignore[arg-type]
                cluster=cluster,
                task_definition=task_definition,
                container_name=container_name,
                container_command=runner.container_command,
                launch_type=launch_type,
                network_configuration=network,
                overwrite=overwrite,
                environment=env or None,
            )
            click.echo(f"Submitted {len(submitted)} ECS task(s).")
            for entry in submitted:
                click.echo(
                    f"  {entry['dataset']}/{entry['model']}  ->  {entry['task_arn']}"
                )

        return group


def _parse_env(env_strings: tuple[str, ...]) -> dict[str, str]:
    """Parse ``KEY=VALUE`` strings into a dict, raising a user-friendly error on bad input."""
    result: dict[str, str] = {}
    for item in env_strings:
        if "=" not in item:
            raise click.BadParameter(
                f"Expected KEY=VALUE, got: {item!r}", param_hint="--env"
            )
        key, _, value = item.partition("=")
        result[key] = value
    return result
