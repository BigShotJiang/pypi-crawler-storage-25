"""S3-backed artifact repository."""

from __future__ import annotations

from typing import Any

import boto3
from botocore.exceptions import ClientError

from ..artifacts import ArtifactRepository


class S3ArtifactRepository(ArtifactRepository):
    """Persist researchlab results to an S3 prefix.

    The repository treats ``s3://{bucket}/{prefix}/`` as the root.
    Everything else (metrics, extras, path layout) is inherited from the
    base class, so switching between local and S3 storage only requires
    swapping the repository instance on the runner.

    Parameters
    ----------
    uri_or_bucket:
        Either an ``s3://bucket[/prefix]`` URI or just a bucket name. When
        a URI is passed, ``prefix`` is derived from it (and any explicit
        ``prefix`` kwarg is joined onto the end).
    prefix:
        Optional additional prefix appended to ``uri_or_bucket``.
    client:
        Optional pre-built boto3 S3 client. If omitted one is created on
        demand (picking up the ambient AWS configuration).
    """

    def __init__(
        self,
        uri_or_bucket: str,
        prefix: str = "",
        *,
        client: Any = None,
    ) -> None:
        bucket, uri_prefix = _parse_s3_location(uri_or_bucket)
        joined = "/".join(p.strip("/") for p in (uri_prefix, prefix) if p.strip("/"))
        self.bucket = bucket
        self.prefix = joined
        self._client = client or boto3.client("s3")

    @property
    def root_uri(self) -> str:
        return f"s3://{self.bucket}/{self.prefix}".rstrip("/")

    def describe(self, path: str) -> str:
        return f"s3://{self.bucket}/{self._key(path)}"

    def _key(self, path: str) -> str:
        return f"{self.prefix}/{path}" if self.prefix else path

    def _write_bytes(self, path: str, payload: bytes) -> None:
        self._client.put_object(Bucket=self.bucket, Key=self._key(path), Body=payload)

    def _read_bytes(self, path: str) -> bytes:
        response = self._client.get_object(Bucket=self.bucket, Key=self._key(path))
        return response["Body"].read()

    def _exists(self, path: str) -> bool:
        try:
            self._client.head_object(Bucket=self.bucket, Key=self._key(path))
        except ClientError as exc:
            if exc.response.get("Error", {}).get("Code") in {
                "404",
                "NoSuchKey",
                "NotFound",
            }:
                return False
            raise
        return True

    def _delete(self, path: str) -> bool:
        if not self._exists(path):
            return False
        self._client.delete_object(Bucket=self.bucket, Key=self._key(path))
        return True

    def _list(self) -> list[str]:
        paginator = self._client.get_paginator("list_objects_v2")
        list_prefix = f"{self.prefix}/" if self.prefix else ""
        keys: list[str] = []
        for page in paginator.paginate(Bucket=self.bucket, Prefix=list_prefix):
            for item in page.get("Contents", []) or []:
                key = item["Key"]
                if list_prefix and key.startswith(list_prefix):
                    key = key[len(list_prefix) :]
                keys.append(key)
        keys.sort()
        return keys


def _parse_s3_location(value: str) -> tuple[str, str]:
    if value.startswith("s3://"):
        remainder = value[len("s3://") :]
        bucket, _, prefix = remainder.partition("/")
    else:
        bucket, _, prefix = value.partition("/")
    if not bucket:
        raise ValueError(f"Invalid S3 location: {value!r}")
    return bucket, prefix.strip("/")
