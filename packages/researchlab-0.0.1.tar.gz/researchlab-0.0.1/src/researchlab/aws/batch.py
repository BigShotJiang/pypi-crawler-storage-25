"""Submit a researchlab runner as AWS Batch jobs — one job per (dataset, model) pair."""

from __future__ import annotations

from typing import Any, Mapping, Sequence

import boto3

from ..runner import BaseRunner


def submit_jobs(
    runner: BaseRunner,
    *,
    job_queue: str,
    job_definition: str,
    container_command: Sequence[str],
    job_name_prefix: str = "researchlab",
    overwrite: bool = False,
    environment: Mapping[str, str] | None = None,
    client: Any = None,
) -> list[dict[str, str]]:
    """Submit one Batch job per ``(dataset, model)`` pair.

    Each job runs ``<container_command> run -d <dataset> -m <model>`` inside
    the container. Submit this from your laptop; the docker image referenced
    by ``job_definition`` is expected to contain your experiment script and
    researchlab's dependencies.

    Parameters
    ----------
    runner:
        The configured runner whose pairs to submit.
    job_queue, job_definition:
        Existing Batch queue and job definition.
    container_command:
        Command prefix, e.g. ``["python", "/app/experiment.py"]``.
    job_name_prefix:
        Jobs are named ``{prefix}-{dataset}-{model}``.
    overwrite:
        Forward ``--overwrite`` to the remote run.
    environment:
        Extra environment variables forwarded to every job.
    client:
        Optional pre-built boto3 Batch client.
    """

    pairs = runner.pairs()
    if not pairs:
        raise ValueError("runner has no (dataset, model) pairs to submit.")

    env_overrides = [
        {"name": k, "value": str(v)} for k, v in sorted((environment or {}).items())
    ]

    batch = client or boto3.client("batch")
    submitted: list[dict[str, str]] = []
    for dataset_name, model_name in pairs:
        command = [*container_command, "run", "-d", dataset_name, "-m", model_name]
        if overwrite:
            command.append("--overwrite")

        overrides: dict[str, Any] = {"command": command}
        if env_overrides:
            overrides["environment"] = env_overrides

        job_name = _job_name(job_name_prefix, dataset_name, model_name)
        response = batch.submit_job(
            jobName=job_name,
            jobQueue=job_queue,
            jobDefinition=job_definition,
            containerOverrides=overrides,
        )
        submitted.append(
            {
                "job_id": str(response["jobId"]),
                "job_name": job_name,
                "dataset": dataset_name,
                "model": model_name,
            }
        )
    return submitted


def _job_name(prefix: str, dataset_name: str, model_name: str) -> str:
    """Batch requires ``[A-Za-z0-9_-]`` names up to 128 chars."""

    raw = f"{prefix}-{dataset_name}-{model_name}"
    sanitized = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in raw)
    return sanitized[:128]
