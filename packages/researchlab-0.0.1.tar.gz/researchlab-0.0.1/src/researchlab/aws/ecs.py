"""Submit a researchlab runner as ECS ``RunTask`` calls — one task per pair."""

from __future__ import annotations

from typing import Any, Mapping, Sequence

import boto3

from ..runner import BaseRunner


def submit_run_tasks(
    runner: BaseRunner,
    *,
    cluster: str,
    task_definition: str,
    container_name: str,
    container_command: Sequence[str],
    launch_type: str = "FARGATE",
    network_configuration: Mapping[str, Any] | None = None,
    overwrite: bool = False,
    environment: Mapping[str, str] | None = None,
    client: Any = None,
) -> list[dict[str, str]]:
    """Submit one ``ecs.run_task`` per ``(dataset, model)`` pair.

    Each task runs ``<container_command> run -d <dataset> -m <model>``.

    Parameters
    ----------
    runner:
        Runner whose pairs should be submitted.
    cluster, task_definition, container_name:
        Existing ECS cluster, task definition ARN/family, and the name of
        the container inside that task definition to override.
    container_command:
        Command prefix, e.g. ``["python", "/app/experiment.py"]``.
    launch_type:
        ``"FARGATE"`` or ``"EC2"``. Defaults to Fargate.
    network_configuration:
        ``networkConfiguration`` dict (required for awsvpc networking).
    overwrite:
        Forward ``--overwrite`` to every remote run.
    environment:
        Extra environment variables applied to every task's container.
    client:
        Optional pre-built boto3 ECS client.
    """

    pairs = runner.pairs()
    if not pairs:
        raise ValueError("runner has no (dataset, model) pairs to submit.")

    env_overrides = [
        {"name": k, "value": str(v)} for k, v in sorted((environment or {}).items())
    ]

    ecs = client or boto3.client("ecs")
    submitted: list[dict[str, str]] = []
    for dataset_name, model_name in pairs:
        command = [*container_command, "run", "-d", dataset_name, "-m", model_name]
        if overwrite:
            command.append("--overwrite")

        override: dict[str, Any] = {"name": container_name, "command": command}
        if env_overrides:
            override["environment"] = env_overrides

        kwargs: dict[str, Any] = {
            "cluster": cluster,
            "taskDefinition": task_definition,
            "launchType": launch_type,
            "overrides": {"containerOverrides": [override]},
        }
        if network_configuration is not None:
            kwargs["networkConfiguration"] = dict(network_configuration)

        response = ecs.run_task(**kwargs)
        for task in response.get("tasks", []) or []:
            submitted.append(
                {
                    "task_arn": str(task["taskArn"]),
                    "dataset": dataset_name,
                    "model": model_name,
                }
            )
    return submitted
