"""Core researchlab API: datasets, models, results, and the base runner."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

import click
import pandas as pd

from .artifacts import ArtifactRepository

logger = logging.getLogger("researchlab")


@dataclass(frozen=True)
class DatasetPayload:
    """Concrete data returned by ``Dataset.load``.

    ``data`` is whatever the evaluator knows how to consume (typically an
    ``(X, y)`` tuple). ``metadata`` is forwarded to ``Model.instantiate`` so
    models can adapt to dataset characteristics — number of features, task
    type, group column, etc. — without the runner needing to know the shape.
    """

    data: Any
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class EvaluationResult:
    """Output of evaluating one ``(dataset, model)`` pair.

    ``metrics`` is a tabular frame persisted as CSV; one row per fold is the
    common shape. ``extra`` is optional auxiliary data (predictions, fitted
    estimator, timings…) pickled alongside the metrics when present.
    """

    metrics: pd.DataFrame
    extra: Any | None = None


class Dataset(ABC):
    """Lazy, named reference to a dataset."""

    @property
    def name(self) -> str:
        return self.__class__.__name__

    def load(self) -> DatasetPayload:
        payload = self._load()
        if isinstance(payload, DatasetPayload):
            return payload
        return DatasetPayload(data=payload)

    @abstractmethod
    def _load(self) -> DatasetPayload | Any:
        """Return either a ``DatasetPayload`` or raw data."""


class Model(ABC):
    """Lazy, named factory for estimators.

    ``instantiate`` takes dataset metadata so a single model entry can adapt
    per-dataset (e.g. set ``n_features`` or choose a task-appropriate head).
    """

    @property
    def name(self) -> str:
        return self.__class__.__name__

    def instantiate(self, metadata: Mapping[str, Any] | None = None) -> Any:
        return self._instantiate(dict(metadata or {}))

    @abstractmethod
    def _instantiate(self, metadata: Mapping[str, Any]) -> Any:
        """Build a fresh estimator instance for this dataset."""


class BaseRunner(ABC):
    """Coordinates ``(dataset, model)`` pair evaluation and persistence.

    Responsibilities:
      * resolve the dataset/model selection
      * skip already-evaluated pairs unless overwrite is requested
      * delegate the actual evaluation to ``_run_one``
      * persist results via the artifact repository
      * expose a CLI for ``run`` / ``erase`` / ``concatenate`` / ``count``
    """

    def __init__(
        self,
        dataset_collection: Mapping[str, Dataset],
        model_collection: Mapping[str, Model],
        artifact_repository: ArtifactRepository,
    ) -> None:
        self.dataset_collection = dict(dataset_collection)
        self.model_collection = dict(model_collection)
        self.artifact_repository = artifact_repository

    @abstractmethod
    def _run_one(
        self,
        *,
        dataset: DatasetPayload,
        estimator: Any,
    ) -> EvaluationResult:
        """Evaluate one pair. Called after dataset load and model instantiation."""

    def run_one(
        self,
        dataset_name: str,
        model_name: str,
        *,
        overwrite: bool = False,
    ) -> EvaluationResult | None:
        self._check_names([dataset_name], self.dataset_collection, "dataset")
        self._check_names([model_name], self.model_collection, "model")

        if not overwrite and self.artifact_repository.exists(dataset_name, model_name):
            logger.info("Skipping %s/%s — already evaluated.", dataset_name, model_name)
            return None

        payload = self.dataset_collection[dataset_name].load()
        estimator = self.model_collection[model_name].instantiate(payload.metadata)

        result = self._run_one(dataset=payload, estimator=estimator)
        if not isinstance(result, EvaluationResult):
            raise TypeError(
                "_run_one must return an EvaluationResult instance, got "
                f"{type(result).__name__}."
            )

        self.artifact_repository.save(dataset_name, model_name, result)
        logger.info("Saved %s/%s.", dataset_name, model_name)
        return result

    def run(
        self,
        *,
        dataset_names: Sequence[str] | None = None,
        model_names: Sequence[str] | None = None,
        overwrite: bool = False,
        stop_on_error: bool = False,
    ) -> list[tuple[str, str]]:
        datasets = self._resolve(dataset_names, self.dataset_collection, "dataset")
        models = self._resolve(model_names, self.model_collection, "model")

        evaluated: list[tuple[str, str]] = []
        for dataset_name in datasets:
            payload: DatasetPayload | None = None
            for model_name in models:
                if not overwrite and self.artifact_repository.exists(
                    dataset_name, model_name
                ):
                    logger.info(
                        "Skipping %s/%s — already evaluated.",
                        dataset_name,
                        model_name,
                    )
                    continue

                if payload is None:
                    payload = self.dataset_collection[dataset_name].load()
                estimator = self.model_collection[model_name].instantiate(
                    payload.metadata
                )
                try:
                    result = self._run_one(dataset=payload, estimator=estimator)
                except Exception:
                    logger.exception(
                        "Evaluation of %s/%s raised.", dataset_name, model_name
                    )
                    if stop_on_error:
                        raise
                    continue

                self.artifact_repository.save(dataset_name, model_name, result)
                evaluated.append((dataset_name, model_name))
                logger.info("Saved %s/%s.", dataset_name, model_name)
        return evaluated

    def count(
        self,
        *,
        dataset_names: Sequence[str] | None = None,
        model_names: Sequence[str] | None = None,
    ) -> dict[str, int]:
        datasets = self._resolve(dataset_names, self.dataset_collection, "dataset")
        models = self._resolve(model_names, self.model_collection, "model")
        total = len(datasets) * len(models)
        done = sum(
            1
            for ds in datasets
            for m in models
            if self.artifact_repository.exists(ds, m)
        )
        return {"total": total, "evaluated": done, "remaining": total - done}

    def erase(
        self,
        *,
        model_names: Sequence[str] | None = None,
        dataset_names: Sequence[str] | None = None,
    ) -> list[str]:
        models = self._resolve(model_names, self.model_collection, "model")
        datasets = self._resolve(dataset_names, self.dataset_collection, "dataset")
        removed: list[str] = []
        for model_name in models:
            removed.extend(
                self.artifact_repository.delete_model_records(model_name, datasets)
            )
        return removed

    def concatenate(self) -> pd.DataFrame:
        return self.artifact_repository.load_all_metrics()

    def pairs(self) -> list[tuple[str, str]]:
        """Deterministic ``(dataset, model)`` enumeration."""

        return [
            (dataset_name, model_name)
            for dataset_name in self.dataset_collection
            for model_name in self.model_collection
        ]

    def cli(self, argv: Sequence[str] | None = None) -> int:
        """Dispatch the Click CLI.

        Examples:
            python myexperiment.py run                     # run everything, skip done
            python myexperiment.py run --overwrite
            python myexperiment.py run -d a -d b -m m1
            python myexperiment.py run --count
            python myexperiment.py erase -m m1
            python myexperiment.py concatenate --output results.csv
        """

        logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
        group = self._build_cli()
        return (
            group.main(
                args=list(argv) if argv is not None else None,
                standalone_mode=False,
            )
            or 0
        )

    def _build_cli(self) -> click.Group:
        runner = self

        @click.group(
            invoke_without_command=True,
            help="Run researchlab experiments from the command line.",
            context_settings={"help_option_names": ["-h", "--help"]},
        )
        @click.pass_context
        def group(ctx: click.Context) -> None:
            if ctx.invoked_subcommand is None:
                ctx.invoke(run)

        @group.command(help="Run experiments (default).")
        @click.option(
            "--dataset-names",
            "-d",
            "dataset_names",
            multiple=True,
            help="Subset of datasets to run. May be repeated.",
        )
        @click.option(
            "--model-names",
            "-m",
            "model_names",
            multiple=True,
            help="Subset of models to run. May be repeated.",
        )
        @click.option(
            "--overwrite",
            is_flag=True,
            default=False,
            help="Re-evaluate pairs that already have stored results.",
        )
        @click.option(
            "--count",
            "count_only",
            is_flag=True,
            default=False,
            help="Report how many pairs are done/remaining without running.",
        )
        def run(
            dataset_names: tuple[str, ...],
            model_names: tuple[str, ...],
            overwrite: bool,
            count_only: bool,
        ) -> None:
            if count_only:
                counts = runner.count(
                    dataset_names=list(dataset_names) or None,
                    model_names=list(model_names) or None,
                )
                for key, value in counts.items():
                    click.echo(f"{key}: {value}")
                return
            evaluated = runner.run(
                dataset_names=list(dataset_names) or None,
                model_names=list(model_names) or None,
                overwrite=overwrite,
            )
            click.echo(f"Completed {len(evaluated)} (dataset, model) pair(s).")

        @group.command(
            help="Delete stored artifacts for the selected model/dataset pairs.",
        )
        @click.option("--model-names", "-m", "model_names", multiple=True)
        @click.option("--dataset-names", "-d", "dataset_names", multiple=True)
        def erase(
            model_names: tuple[str, ...],
            dataset_names: tuple[str, ...],
        ) -> None:
            removed = runner.erase(
                model_names=list(model_names) or None,
                dataset_names=list(dataset_names) or None,
            )
            click.echo(f"Removed {len(removed)} artifact(s).")
            for path in removed:
                click.echo(f"  - {path}")

        @group.command(
            help="Concatenate all stored per-pair metrics into one frame.",
        )
        @click.option(
            "--output",
            "-o",
            default=None,
            type=click.Path(dir_okay=False, writable=True),
            help="If given, write the concatenated CSV here. Otherwise print to stdout.",
        )
        def concatenate(output: str | None) -> None:
            frame = runner.concatenate()
            if output:
                frame.to_csv(output, index=False)
                click.echo(f"Wrote {len(frame)} rows to {output}.")
            else:
                click.echo(frame.to_csv(index=False), nl=False)

        return group

    @staticmethod
    def _resolve(
        requested: Sequence[str] | None,
        collection: Mapping[str, Any],
        label: str,
    ) -> list[str]:
        if not requested:
            return list(collection)
        BaseRunner._check_names(requested, collection, label)
        return list(requested)

    @staticmethod
    def _check_names(
        names: Sequence[str],
        collection: Mapping[str, Any],
        label: str,
    ) -> None:
        missing = [name for name in names if name not in collection]
        if missing:
            available = sorted(collection)
            raise KeyError(
                f"Unknown {label} name(s): {missing}. Available: {available}."
            )
