"""Sklearn-based local runners shipped with researchlab."""

from __future__ import annotations

import time
from typing import Any, Callable, Mapping, Sequence

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.model_selection import BaseCrossValidator

from .local import LocalRunner
from .runner import DatasetPayload, EvaluationResult

Scorer = Callable[[Any, Any, Any], float]
MetricsSpec = Mapping[str, Scorer] | Sequence[Scorer]


def _scorer_name(scorer: Scorer, index: int) -> str:
    """Best-effort name for an sklearn scorer object."""

    score_func = getattr(scorer, "_score_func", None)
    raw = getattr(score_func, "__name__", None) or getattr(scorer, "__name__", None)
    if not raw:
        return f"metric_{index}"
    for suffix in ("_score", "_error", "_loss"):
        if raw.endswith(suffix):
            return raw[: -len(suffix)]
    return raw


def _normalize_metrics(metrics: MetricsSpec) -> dict[str, Scorer]:
    if isinstance(metrics, Mapping):
        return dict(metrics)
    normalized: dict[str, Scorer] = {}
    for index, scorer in enumerate(metrics):
        name = _scorer_name(scorer, index)
        original = name
        counter = 2
        while name in normalized:
            name = f"{original}_{counter}"
            counter += 1
        normalized[name] = scorer
    return normalized


def _as_1d(y: Any) -> Any:
    """Return ``y`` as a 1-D array/Series when possible (expected by classifiers)."""

    if isinstance(y, pd.DataFrame) and y.shape[1] == 1:
        return y.iloc[:, 0]
    if hasattr(y, "ndim") and getattr(y, "ndim", 1) == 2 and y.shape[1] == 1:
        return np.asarray(y).ravel()
    return y


def _index_rows(obj: Any, idx: np.ndarray) -> Any:
    if hasattr(obj, "iloc"):
        return obj.iloc[idx]
    return obj[idx]


class SklearnClassificationRunner(LocalRunner):
    """Run sklearn classifiers across ``(dataset, model)`` pairs with K-fold CV.

    The dataset payload's ``data`` must be a ``(X, y)`` pair. For each fold
    the runner clones the estimator, fits it, times training and prediction,
    computes each configured scorer, and stores the fitted fold estimators
    as extras (so downstream analysis can inspect the exact models).

    Metrics output columns: ``fold``, ``n_train``, ``n_test``, ``train_time``,
    ``predict_time``, and one column per configured metric.
    """

    def __init__(
        self,
        dataset_collection,
        model_collection,
        artifact_repository,
        *,
        cv: BaseCrossValidator,
        metrics: MetricsSpec,
    ) -> None:
        super().__init__(
            dataset_collection=dataset_collection,
            model_collection=model_collection,
            artifact_repository=artifact_repository,
        )
        self.cv = cv
        self.metrics = _normalize_metrics(metrics)
        if not self.metrics:
            raise ValueError(
                "SklearnClassificationRunner requires at least one metric."
            )

    def _run_one(
        self,
        *,
        dataset: DatasetPayload,
        estimator: Any,
    ) -> EvaluationResult:
        try:
            X, y = dataset.data
        except (TypeError, ValueError) as exc:
            raise TypeError(
                "SklearnClassificationRunner expects dataset.data to be an (X, y) pair."
            ) from exc

        y_1d = _as_1d(y)
        rows: list[dict[str, Any]] = []
        fitted_per_fold: list[Any] = []
        fold_indices: list[tuple[np.ndarray, np.ndarray]] = []

        splitter = self.cv
        for fold_idx, (train_idx, test_idx) in enumerate(splitter.split(X, y_1d)):
            train_idx = np.asarray(train_idx)
            test_idx = np.asarray(test_idx)

            X_train = _index_rows(X, train_idx)
            X_test = _index_rows(X, test_idx)
            y_train = _index_rows(y_1d, train_idx)
            y_test = _index_rows(y_1d, test_idx)

            fold_model = clone(estimator)

            start = time.perf_counter()
            fold_model.fit(X_train, y_train)
            train_time = time.perf_counter() - start

            start = time.perf_counter()
            fold_model.predict(X_test)
            predict_time = time.perf_counter() - start

            row: dict[str, Any] = {
                "fold": fold_idx,
                "n_train": int(len(train_idx)),
                "n_test": int(len(test_idx)),
                "train_time": train_time,
                "predict_time": predict_time,
            }
            for metric_name, scorer in self.metrics.items():
                row[metric_name] = float(scorer(fold_model, X_test, y_test))

            rows.append(row)
            fitted_per_fold.append(fold_model)
            fold_indices.append((train_idx, test_idx))

        metrics_frame = pd.DataFrame(rows)
        column_order = [
            "fold",
            "n_train",
            "n_test",
            "train_time",
            "predict_time",
            *self.metrics.keys(),
        ]
        metrics_frame = metrics_frame[column_order]

        extra = {
            "fitted_models": fitted_per_fold,
            "fold_indices": fold_indices,
            "metric_names": list(self.metrics.keys()),
        }
        return EvaluationResult(metrics=metrics_frame, extra=extra)
