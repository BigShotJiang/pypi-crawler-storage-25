"""Artifact repositories used by researchlab runners to persist results."""

from __future__ import annotations

import io
import pickle
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Iterable

import pandas as pd

if TYPE_CHECKING:
    from .runner import EvaluationResult


class ArtifactRepository(ABC):
    """Persist ``EvaluationResult`` instances keyed by ``(dataset, model)``.

    A repository maps every pair to two storage keys — one for the metrics
    CSV and one for the optional extras pickle. Backends only need to
    implement the bytes-level primitives (``_write_bytes``/``_read_bytes``/
    ``_exists``/``_delete``/``_list``); the higher-level API is provided here.
    """

    metrics_suffix = ".csv"
    extras_suffix = "_extra.pkl"

    # ---- path helpers (safe to override) --------------------------------
    def metrics_path(self, dataset_name: str, model_name: str) -> str:
        return f"{dataset_name}/{model_name}{self.metrics_suffix}"

    def extras_path(self, dataset_name: str, model_name: str) -> str:
        return f"{dataset_name}/{model_name}{self.extras_suffix}"

    def describe(self, path: str) -> str:
        """Human-readable location for a stored path. Override for S3 etc."""
        return path

    # ---- public API ------------------------------------------------------
    def save(
        self,
        dataset_name: str,
        model_name: str,
        result: "EvaluationResult",
    ) -> None:
        metrics_bytes = result.metrics.to_csv(index=False).encode("utf-8")
        self._write_bytes(self.metrics_path(dataset_name, model_name), metrics_bytes)
        if result.extra is not None:
            self._write_bytes(
                self.extras_path(dataset_name, model_name),
                pickle.dumps(result.extra, protocol=pickle.HIGHEST_PROTOCOL),
            )

    def exists(self, dataset_name: str, model_name: str) -> bool:
        return self._exists(self.metrics_path(dataset_name, model_name))

    def load_metrics(self, dataset_name: str, model_name: str) -> pd.DataFrame:
        payload = self._read_bytes(self.metrics_path(dataset_name, model_name))
        return pd.read_csv(io.BytesIO(payload))

    def load_extras(self, dataset_name: str, model_name: str):
        payload = self._read_bytes(self.extras_path(dataset_name, model_name))
        return pickle.loads(payload)

    def has_extras(self, dataset_name: str, model_name: str) -> bool:
        return self._exists(self.extras_path(dataset_name, model_name))

    def delete(self, dataset_name: str, model_name: str) -> list[str]:
        """Remove metrics and extras for one pair. Returns the paths deleted."""

        removed: list[str] = []
        for path in (
            self.metrics_path(dataset_name, model_name),
            self.extras_path(dataset_name, model_name),
        ):
            if self._delete(path):
                removed.append(self.describe(path))
        return removed

    def delete_model_records(
        self,
        model_name: str,
        dataset_names: Iterable[str],
    ) -> list[str]:
        removed: list[str] = []
        for dataset_name in dataset_names:
            removed.extend(self.delete(dataset_name, model_name))
        return removed

    def load_all_metrics(self) -> pd.DataFrame:
        """Concatenate every stored metrics CSV into one frame."""

        frames: list[pd.DataFrame] = []
        for key in self._list():
            if not key.endswith(self.metrics_suffix):
                continue
            dataset_name, _, file_name = key.partition("/")
            if not dataset_name or not file_name:
                continue
            model_name = file_name[: -len(self.metrics_suffix)]
            frame = self.load_metrics(dataset_name, model_name)
            if "dataset" not in frame.columns:
                frame.insert(0, "dataset", dataset_name)
            if "model" not in frame.columns:
                frame.insert(1, "model", model_name)
            frames.append(frame)
        if not frames:
            return pd.DataFrame(columns=["dataset", "model"])
        return pd.concat(frames, ignore_index=True, sort=False)

    def list_pairs(self) -> list[tuple[str, str]]:
        pairs: list[tuple[str, str]] = []
        for key in self._list():
            if not key.endswith(self.metrics_suffix):
                continue
            dataset_name, _, file_name = key.partition("/")
            if not dataset_name or not file_name:
                continue
            pairs.append((dataset_name, file_name[: -len(self.metrics_suffix)]))
        return pairs

    # ---- backend primitives ---------------------------------------------
    @abstractmethod
    def _write_bytes(self, path: str, payload: bytes) -> None: ...

    @abstractmethod
    def _read_bytes(self, path: str) -> bytes: ...

    @abstractmethod
    def _exists(self, path: str) -> bool: ...

    @abstractmethod
    def _delete(self, path: str) -> bool:
        """Remove ``path`` if present. Return True iff something was removed."""

    @abstractmethod
    def _list(self) -> list[str]: ...


class LocalArtifactRepository(ArtifactRepository):
    """Filesystem-backed artifact repository rooted at ``root``."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def describe(self, path: str) -> str:
        return str(self._full(path))

    def _full(self, path: str) -> Path:
        return self.root / path

    def _write_bytes(self, path: str, payload: bytes) -> None:
        full = self._full(path)
        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_bytes(payload)

    def _read_bytes(self, path: str) -> bytes:
        return self._full(path).read_bytes()

    def _exists(self, path: str) -> bool:
        return self._full(path).is_file()

    def _delete(self, path: str) -> bool:
        full = self._full(path)
        if not full.is_file():
            return False
        full.unlink()
        return True

    def _list(self) -> list[str]:
        if not self.root.exists():
            return []
        return sorted(
            str(p.relative_to(self.root)).replace("\\", "/")
            for p in self.root.rglob("*")
            if p.is_file()
        )
