"""skpro-based probabilistic regression runner for researchlab."""

from __future__ import annotations

from typing import Any, Mapping, Sequence

import pandas as pd

from .local import LocalRunner
from .runner import DatasetPayload, EvaluationResult


def _coerce_metric(metric: Any) -> Any:
    """Coerce a metric argument into an instantiated skpro metric object."""

    import inspect

    from skpro.metrics.base import BaseProbaMetric

    if isinstance(metric, BaseProbaMetric):
        return metric
    if inspect.isclass(metric) and issubclass(metric, BaseProbaMetric):
        return metric()
    if isinstance(metric, str):
        import skpro.metrics as skpro_metrics

        lookup = {
            name.lower(): getattr(skpro_metrics, name)
            for name in getattr(skpro_metrics, "__all__", [])
        }
        cls = lookup.get(metric.strip().lower())
        if cls is None:
            raise ValueError(
                f"Unknown skpro metric '{metric}'. "
                "Pass a metric instance, class, or one of: "
                f"{sorted(lookup)}"
            )
        return cls()
    raise TypeError(
        f"Unsupported metric type {type(metric).__name__}. "
        "Expected an skpro metric instance, class, or registered name."
    )


def _normalize_metrics(
    metrics: Any,
) -> list[Any]:
    if isinstance(metrics, (list, tuple)):
        return [_coerce_metric(m) for m in metrics]
    return [_coerce_metric(metrics)]


class SkproRegressionRunner(LocalRunner):
    """Evaluate skpro probabilistic regressors across ``(dataset, model)`` pairs.

    Uses ``skpro.benchmarking.evaluate`` under the hood, producing one fold
    row per cross-validation split with columns:

    * ``test_{metric.name}`` — one column per configured scoring metric
    * ``fit_time`` — seconds to fit on the train fold
    * ``pred_time`` — seconds to predict on the test fold

    Dataset payloads must supply ``data`` as an ``(X, y)`` pair where both
    ``X`` and ``y`` are ``pd.DataFrame`` instances (skpro convention).

    Parameters
    ----------
    dataset_collection:
        Mapping of dataset name → ``Dataset`` instance.
    model_collection:
        Mapping of model name → ``Model`` instance.
    artifact_repository:
        ``ArtifactRepository`` (or a local path / S3 URI string for
        ``LocalArtifactRepository`` / ``S3ArtifactRepository``).
    cv:
        Any sklearn-compatible cross-validator (e.g. ``KFold``).
    metrics:
        One or more skpro ``BaseMetric`` instances/classes, or their string
        names (e.g. ``"CRPS"``, ``"MeanAbsoluteError"``). The first metric
        is treated as the primary one for logging purposes.

    Examples
    --------
    >>> from sklearn.model_selection import KFold
    >>> from skpro.metrics import CRPS
    >>> runner = SkproRegressionRunner(
    ...     dataset_collection={"my_data": MyDataset()},
    ...     model_collection={"my_model": MyModel()},
    ...     artifact_repository="results/",
    ...     cv=KFold(n_splits=5),
    ...     metrics=[CRPS(), "MeanAbsoluteError"],
    ... )
    >>> runner.cli()
    """

    def __init__(
        self,
        dataset_collection: Mapping[str, Any],
        model_collection: Mapping[str, Any],
        artifact_repository: Any,
        *,
        cv: Any,
        metrics: Any,
    ) -> None:
        super().__init__(
            dataset_collection=dataset_collection,
            model_collection=model_collection,
            artifact_repository=artifact_repository,
        )
        self.cv = cv
        self.metrics = _normalize_metrics(metrics)
        if not self.metrics:
            raise ValueError("SkproRegressionRunner requires at least one metric.")

    def _run_one(
        self,
        *,
        dataset: DatasetPayload,
        estimator: Any,
    ) -> EvaluationResult:
        try:
            X, y = dataset.data
        except (TypeError, ValueError) as exc:
            raise TypeError(
                "SkproRegressionRunner expects dataset.data to be an (X, y) pair."
            ) from exc

        if not isinstance(X, pd.DataFrame):
            X = pd.DataFrame(X)
        if not isinstance(y, pd.DataFrame):
            y = pd.DataFrame(y) if not isinstance(y, pd.Series) else y.to_frame()

        from skpro.benchmarking.evaluate import evaluate

        result_frame: pd.DataFrame = evaluate(
            estimator,
            self.cv,
            X,
            y,
            scoring=self.metrics,
            return_data=False,
        )

        primary_name = (
            getattr(self.metrics[0], "name", None) or type(self.metrics[0]).__name__
        )
        if primary_name:
            col = f"test_{primary_name}"
            if col in result_frame.columns:
                import logging

                logger = logging.getLogger("researchlab")
                mean_score = result_frame[col].mean()
                logger.debug("  %s mean=%.4f", col, mean_score)

        return EvaluationResult(metrics=result_frame, extra=None)
