---
name: install-helm
description: >
  Install, update, and verify the Helm CLI.
  Use when the user says /install-helm, 'install helm', 'setup helm',
  'configurer helm', or needs the helm CLI configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install, verify, and update the Helm CLI.

## Step 1 — Check current state

```bash
pysae-ai-tools tools helm check --json
```

The script returns a JSON line with `binary` (installed, version), `latest` (from `helm/helm` GitHub releases), `needs_install`, `needs_update`.

| `needs_install` | `needs_update` | Action |
|---|---|---|
| `true` | — | Step 2 (install) |
| `false` | `true` | Step 2 (update) |
| `false` | `false` | **Done** — tell the user everything is OK |

## Step 2 — Install or update Helm

```bash
pysae-ai-tools tools helm install --json
```

Downloads the matching archive from `get.helm.sh`, extracts the binary, and installs it:
- **Linux/macOS** → `/usr/local/bin/helm` via `sudo install` (`.tar.gz` archive).
- **Windows** → `%LOCALAPPDATA%\Programs\pysae\bin\helm.exe` (`.zip` archive, no admin required).

Returns `{"version": "...", "path": "..."}` on success or `{"error": "..."}` on failure.

> **macOS alternative:** `brew install helm` if the user prefers Homebrew (handles updates automatically).
>
> **Windows alternative:** `choco install kubernetes-helm` or `winget install Helm.Helm`.

## Step 3 — Final verification

```bash
helm version --short
```

Confirm to the user that Helm is installed and up to date.

## Gotchas

- **Version compatibility with the cluster.** Helm 3.x is generally backward-compatible, but check the cluster's Kubernetes version before upgrading Helm if the cluster is old (< 1.20).
- **Same kubeconfig as kubectl.** Helm uses `~/.kube/config` — if `kubectl` works, Helm works. No extra setup needed.
- **No external chart repos at Pysae.** Charts are colocated in each repo's `helm/` directory. No `helm repo add` required for most workflows.
- **Windows PATH.** When installing on Windows, the binary lands in `%LOCALAPPDATA%\Programs\pysae\bin`. Add it to `%PATH%` if `helm` is not found after install.

## Notes

- The `helm-diff` plugin enables `helm diff upgrade` for change previews. Optional install:
  ```bash
  helm plugin install https://github.com/databus23/helm-diff
  ```
- `/install-kubectl` is a soft prerequisite (Helm reuses kubeconfig).

$ARGUMENTS
