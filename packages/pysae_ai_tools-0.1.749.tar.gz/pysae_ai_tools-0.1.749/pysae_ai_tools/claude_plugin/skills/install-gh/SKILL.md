---
name: install-gh
description: >
  Install, update, and verify the GitHub CLI (gh) and authenticate to github.com.
  Use when the user says /install-gh, 'install gh', 'install github cli',
  'setup gh', 'configurer gh', or needs the gh CLI configured or checked.
allowed-tools:
  - Bash
  - AskUserQuestion
---

Install, verify, and update the GitHub CLI, then authenticate to GitHub.

## Step 1 — Check current state

```bash
pysae-ai-tools tools gh check --json
```

Returns JSON with `binary`, `latest` (from `cli/cli` GitHub releases), `auth_ok`, `auth_message`, `has_gh_token_env`, `needs_install`, `needs_update`.

| `needs_install` | `auth_ok` | Action |
|---|---|---|
| `true` | — | Step 2 (install) then Step 3 (auth) |
| `false` | `false` | Step 3 (auth) |
| `false` | `true` | **Done** — tell the user everything is OK |

## Step 2 — Install or update the CLI

```bash
pysae-ai-tools tools gh install --json
```

Downloads the binary release tarball/zip from `cli/cli` and installs it:
- **Linux/macOS** → `/usr/local/bin/gh` via `sudo install` (binary tarball, no APT/Homebrew dependency).
- **Windows** → `%LOCALAPPDATA%\Programs\pysae\bin\gh.exe`.

> **macOS alternative:** `brew install gh` (handles updates).
>
> **Windows alternative:** `winget install GitHub.cli` or `choco install gh`.
>
> **Debian/Ubuntu APT alternative:** GitHub's official APT repo. Only use if the user wants automatic OS-level updates.

## Step 3 — Authenticate

The recommended approach is a Personal Access Token (PAT) via the `GH_TOKEN` env var.

### Create a GitHub PAT

> Crée un token GitHub (Fine-grained) :
> 1. Va sur https://github.com/settings/personal-access-tokens
> 2. **Generate new token** — nom : `claude-code` — expiration : 90 jours minimum
> 3. Repository access : **All repositories** (ou sélectionne)
> 4. Permissions : Contents Read+Write, Pull requests Read+Write, Issues Read+Write, Metadata Read-only (auto)
> 5. **Generate token** et copie la valeur

### Persist the token

```
/update-config set GH_TOKEN=<TOKEN>
```

`GH_TOKEN` is read automatically by `gh` — no `gh auth login` needed.

### Alternative — Browser device-code login

If the user prefers a browser flow, launch in background (`run_in_background: true`):

```bash
echo "" | gh auth login --web --git-protocol https
```

Read the output within ~5s to extract the one-time code and URL, then display:

> Ouvre https://github.com/login/device et entre le code : **XXXX-XXXX**

Wait for the background task to complete, then verify with `gh auth status`.

### Configure git credential helper

```bash
gh auth setup-git
```

This makes `git clone/push/pull` over HTTPS use `gh` for auth on `github.com`.

## Step 4 — Configure (optional)

```bash
gh config set editor "code --wait"
gh config set git_protocol https
```

## Gotchas

- **`GH_TOKEN` overrides `gh auth login`.** When the env var is set, `gh auth status` shows the token and ignores the local `hosts.yml`. This is intentional — but means `gh auth logout` does nothing. To revoke, unset `GH_TOKEN` via `/update-config unset GH_TOKEN`.
- **PAT permissions matter.** Missing `Contents` write means `gh pr create` fails silently with "must have write access". Re-create the PAT with the full permission set above.
- **Device-code flow needs `echo "" |`.** Without piping an empty line, `gh auth login --web` blocks waiting for an interactive enter key.
- **Windows PATH.** Add `%LOCALAPPDATA%\Programs\pysae\bin` to `%PATH%` if `gh` is not found after install.

## Notes

- Tokens from `gh auth login` are stored in `~/.config/gh/hosts.yml` (Linux/macOS) or `%APPDATA%\GitHub CLI\hosts.yml` (Windows).
- `/install-gh` is required before any `gh`-using skill (PR/issue/release).

$ARGUMENTS
