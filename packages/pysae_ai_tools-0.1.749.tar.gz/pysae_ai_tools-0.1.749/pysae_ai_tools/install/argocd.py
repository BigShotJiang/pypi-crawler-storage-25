"""Install or update the ArgoCD CLI.

Source of truth for the version is the Pysae dev server (/api/version).
Download is attempted from the Pysae dev mirror first, then GitHub releases.
"""

import json
import subprocess
from typing import Any

import httpx
import typer

from .common import binary, platform
from .common.base import BinaryTool, InstallReport, ToolState

DEV_SERVER = "argocd.dev.pysae.com"
GH_RELEASES = "https://github.com/argoproj/argo-cd/releases/download"


class ArgocdTool(BinaryTool):
    name = "argocd"
    binary_name = "argocd"
    version_arg = "version"
    cli_help = "Install/update the ArgoCD CLI and authenticate to dev/prod"

    def fetch_latest_version(self) -> str:
        r = httpx.get(f"https://{DEV_SERVER}/api/version", timeout=5.0, follow_redirects=True)
        r.raise_for_status()
        version = r.json().get("Version", "")
        return version.split("+")[0] if isinstance(version, str) else ""

    def get_state(self) -> ToolState:
        bin_status = binary.status(self.binary_name, version_arg=self.version_arg)
        # argocd version outputs to stderr; use json client mode
        if bin_status.installed:
            try:
                r = subprocess.run(
                    [self.binary_name, "version", "--client", "-o", "json"],
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=5,
                )
                data = json.loads(r.stdout) if r.stdout else {}
                client_v = data.get("client", {}).get("Version", "")
                if isinstance(client_v, str) and client_v:
                    bin_status.version = binary.extract_version(client_v) or client_v.lstrip("v").split("+")[0]
            except (json.JSONDecodeError, OSError, subprocess.TimeoutExpired):
                pass

        try:
            srv = self.fetch_latest_version()
        except Exception:  # noqa: BLE001
            srv = ""

        contexts: dict[str, dict[str, Any]] = {}
        for ctx in ("dev", "prod"):
            if bin_status.installed:
                ok, err = self._context_status(ctx)
                contexts[ctx] = {"ok": ok, "error": err}
            else:
                contexts[ctx] = {"ok": False, "error": "binary not installed"}

        return ToolState(
            needs_install=not bin_status.installed,
            needs_update=bin_status.installed and bool(srv) and binary.needs_update(bin_status.version, srv),
            extra={
                "binary": bin_status.to_dict(),
                "latest": srv,
                "server_version": srv,
                "contexts": contexts,
            },
        )

    def _context_status(self, context: str) -> tuple[bool, str]:
        sw = subprocess.run(
            [self.binary_name, "context", context],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        if sw.returncode != 0:
            err = sw.stderr.strip().split("\n")[-1] if sw.stderr.strip() else "context not configured"
            return False, err
        check = subprocess.run(
            [self.binary_name, "account", "get-user-info", "--grpc-web"],
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
        if check.returncode != 0:
            raw = check.stderr.strip().split("\n")[-1] if check.stderr.strip() else "auth failed"
            try:
                log = json.loads(raw)
                err = str(log.get("msg", raw))
            except (json.JSONDecodeError, TypeError):
                err = raw
            return False, err
        return True, ""

    def install_binary(self) -> InstallReport:
        try:
            plat = platform.detect()
        except ValueError as exc:
            return InstallReport(error=str(exc))
        try:
            version = self.fetch_latest_version()
        except Exception as exc:  # noqa: BLE001
            return InstallReport(error=f"could not fetch server version: {exc}")

        arch = "amd64" if plat.arch.value == "x86_64" else plat.arch.value
        suffix = ".exe" if plat.is_windows else ""
        filename = f"argocd-{plat.os.value}-{arch}{suffix}"

        sources: list[tuple[str, str]] = []
        if plat.is_linux and plat.arch.value == "x86_64":
            sources.append(("pysae-dev", f"https://{DEV_SERVER}/download/{filename}"))
        sources.append(("github", f"{GH_RELEASES}/v{version.lstrip('v')}/{filename}"))

        from .common.download import download_and_install_binary

        last_error = ""
        for source, url in sources:
            try:
                path = download_and_install_binary(url, self.binary_name)
                installed_v = binary.get_version(self.binary_name, version_arg=self.version_arg)
                return InstallReport(version=installed_v or version, path=str(path), method=source)
            except Exception as exc:  # noqa: BLE001
                last_error = f"{source}: {exc}"
        return InstallReport(error=f"download failed: {last_error}")

    def extract_identity(self, state: dict[str, Any]) -> list[tuple[str, str | None]]:
        lines: list[tuple[str, str | None]] = []
        version = state.get("server_version", "")
        if version:
            lines.append((f"server {version}", typer.colors.BRIGHT_BLACK))
        contexts = state.get("contexts", {})
        for ctx_name, ctx_data in contexts.items():
            if isinstance(ctx_data, dict):
                ctx_ok = ctx_data.get("ok", False)
                ctx_err = ctx_data.get("error", "")
            else:
                ctx_ok = bool(ctx_data)
                ctx_err = ""
            icon = "✓" if ctx_ok else "✗"
            suffix = f" — {ctx_err}" if ctx_err else ""
            lines.append((f"{icon} {ctx_name}{suffix}", typer.colors.GREEN if ctx_ok else typer.colors.RED))
        return lines


_tool = ArgocdTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()

if __name__ == "__main__":
    cli()
