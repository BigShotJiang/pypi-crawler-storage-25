"""Install the MongoDB MCP servers (dev read/write + prod read-only)."""

import os
from typing import Any

from .common import mcp
from .common.base import BaseTool, EnvVar, InstallReport, ToolState

DEV_NAME = "mongodb-dev"
PROD_NAME = "mongodb-prod"


def _build(server: str, uri: str, read_only: bool) -> dict[str, Any]:
    args = ["-y", "mongodb-mcp-server@latest"]
    if read_only:
        args.append("--readOnly")
    return {"type": "stdio", "command": "npx", "args": args, "env": {"MDB_MCP_CONNECTION_STRING": uri}}


class MongoMcpTool(BaseTool):
    name = "mongo-mcp"
    cli_help = "Install/configure the MongoDB MCP servers (dev + prod)"

    @property
    def env_vars(self) -> list[EnvVar]:
        return [
            EnvVar(
                "MONGO_URI_DEV",
                help="MongoDB URI de dev",
                auto_resolve="pysae-ai-tools aws secret-env get pysae/dev/secrets api-mongo-uri --show-value",
            ),
            EnvVar(
                "MONGO_URI_PROD",
                help="MongoDB URI de prod",
                auto_resolve="pysae-ai-tools aws secret-env get pysae/prod/secrets api-mongo-uri --show-value",
            ),
        ]

    def get_state(self) -> ToolState:
        dev = mcp.get_server(DEV_NAME)
        prod = mcp.get_server(PROD_NAME)
        dev_ok = dev is not None and bool((dev.get("env") or {}).get("MDB_MCP_CONNECTION_STRING"))
        prod_ok = prod is not None and bool((prod.get("env") or {}).get("MDB_MCP_CONNECTION_STRING"))
        prod_ro = prod is not None and "--readOnly" in (prod.get("args") or [])
        return ToolState(
            needs_install=not (dev_ok and prod_ok and prod_ro),
            extra={
                DEV_NAME: {"configured": dev is not None, "has_uri": dev_ok},
                PROD_NAME: {"configured": prod is not None, "has_uri": prod_ok, "read_only": prod_ro},
            },
        )

    def do_install(self) -> InstallReport:
        dev_uri = os.environ.get("MONGO_URI_DEV", "").strip()
        prod_uri = os.environ.get("MONGO_URI_PROD", "").strip()
        if not dev_uri or not prod_uri:
            return InstallReport(error="MONGO_URI_DEV and MONGO_URI_PROD are required")
        dev_changed = mcp.upsert_server(DEV_NAME, _build(DEV_NAME, dev_uri, read_only=False))
        prod_changed = mcp.upsert_server(PROD_NAME, _build(PROD_NAME, prod_uri, read_only=True))
        return InstallReport(
            extra={DEV_NAME: {"changed": dev_changed}, PROD_NAME: {"changed": prod_changed}},
        )

    def format_check(self, state: ToolState) -> None:
        for name in (DEV_NAME, PROD_NAME):
            info = state.extra.get(name, {})
            if info.get("configured"):
                ro = " (readOnly)" if info.get("read_only") else ""
                typer.echo(f"{name}: configured{ro}")
            else:
                typer.echo(f"{name}: missing")

    def format_install(self, report: InstallReport) -> None:
        if report.error:
            typer.echo(f"FAILED: {report.error}", err=True)
            return
        for name in (DEV_NAME, PROD_NAME):
            info = report.extra.get(name, {})
            changed = info.get("changed", False)
            ro = " (--readOnly)" if name == PROD_NAME else ""
            typer.echo(f"{name}: {'updated' if changed else 'unchanged'}{ro}")


import typer  # noqa: E402 — needed for format methods above

_tool = MongoMcpTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()

if __name__ == "__main__":
    cli()
