"""Interactive env var prompting for install commands.

Env vars can be auto-resolved via shell commands (e.g. reading from AWS
Secrets Manager) or prompted interactively.
"""

import os
import subprocess
import sys

import typer

# Centralized help and auto-resolve commands for env vars
ENV_CONFIG: dict[str, dict[str, str]] = {
    "DD_API_KEY": {"help": "Datadog → Organization Settings → API Keys → New Key"},
    "DD_APP_KEY": {"help": "Datadog → Organization Settings → Application Keys → New Key"},
    "POSTMAN_API_KEY": {"help": "Postman → Settings → API Keys → Generate API Key"},
    "MONGO_URI_DEV": {
        "help": "MongoDB URI de dev (AWS Secrets Manager: pysae/dev/secrets → api-mongo-uri)",
        "auto": "pysae-ai-tools aws secret-env get pysae/dev/secrets api-mongo-uri --show-value",
    },
    "MONGO_URI_PROD": {
        "help": "MongoDB URI de prod (AWS Secrets Manager: pysae/prod/secrets → api-mongo-uri)",
        "auto": "pysae-ai-tools aws secret-env get pysae/prod/secrets api-mongo-uri --show-value",
    },
}


def _try_auto_resolve(var: str) -> str | None:
    """Try to resolve an env var automatically via a shell command."""
    config = ENV_CONFIG.get(var, {})
    cmd = config.get("auto")
    if not cmd:
        return None
    try:
        result = subprocess.run(cmd.split(), capture_output=True, text=True, timeout=15)
        if result.returncode == 0 and result.stdout.strip():
            value = result.stdout.strip()
            os.environ[var] = value
            print(f"  ✓ ${var} resolved automatically", file=sys.stderr)
            return value
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def prompt_env_var(var: str, tool_name: str = "", help_text: str = "") -> str | None:
    """Prompt the user for a missing env var. Returns the value or None if skipped."""
    resolved_help = help_text or ENV_CONFIG.get(var, {}).get("help", "")

    typer.echo("")
    typer.secho(f"  ${var} is required{f' for {tool_name}' if tool_name else ''}", fg=typer.colors.YELLOW)
    if resolved_help:
        typer.secho(f"  → {resolved_help}", fg=typer.colors.BRIGHT_BLACK)

    value: str = typer.prompt(f"  ${var}", default="", show_default=False)
    if not value.strip():
        return None

    os.environ[var] = value.strip()
    return value.strip()


def ensure_env_vars(
    vars_required: tuple[str, ...],
    tool_name: str = "",
    env_help: dict[str, str] | None = None,
    interactive: bool = True,
) -> bool:
    """Resolve missing env vars: auto-resolve first, then prompt if interactive.

    Returns True if all vars are resolved.
    """
    for var in vars_required:
        if os.environ.get(var):
            continue

        # Try auto-resolve (works in both interactive and non-interactive mode)
        if _try_auto_resolve(var) is not None:
            continue

        # Prompt only in interactive mode
        if interactive:
            help_text = (env_help or {}).get(var, "")
            if prompt_env_var(var, tool_name, help_text) is not None:
                continue

        typer.secho(f"  ✗ ${var} not set — {tool_name or 'tool'} will not be installed.", fg=typer.colors.RED)
        return False
    return True
