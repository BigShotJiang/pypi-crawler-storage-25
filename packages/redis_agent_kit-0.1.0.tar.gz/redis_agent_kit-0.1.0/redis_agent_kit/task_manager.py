"""Task manager for Redis Agent Kit."""

from __future__ import annotations

import json
from collections.abc import Awaitable
from datetime import UTC, datetime
from typing import Any, TypeVar, cast

import jsonschema  # type: ignore[import-untyped]
import redis.asyncio as redis
from ulid import ULID

from redis_agent_kit.keys import RedisKeys
from redis_agent_kit.models import (
    Caller,
    InputRequest,
    TaskState,
    TaskStatus,
    TaskUpdate,
)
from redis_agent_kit.streaming import ChannelScope, StreamConfig

T = TypeVar("T")


def _redis_await(result: Awaitable[T] | T) -> Awaitable[T]:
    return cast(Awaitable[T], result)


class TaskManager:
    """Manages task state in Redis.

    Tasks represent individual units of work (e.g., one agent turn).
    Each task belongs to a thread and tracks status, progress updates,
    results, and errors.
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        prefix: str | None = None,
        enable_sse: bool = False,
        enable_streaming: bool = False,
        stream_config: StreamConfig | None = None,
    ):
        """Initialize TaskManager.

        Args:
            redis_client: Async Redis client
            prefix: Optional custom key prefix (default: 'rak')
            enable_sse: Enable Pub/Sub publishing for SSE streaming (default: False).
                Deprecated – use ``stream_config`` instead.
            enable_streaming: Enable lightweight Pub/Sub publishing for
                token-by-token streaming via publish() (default: False).
                Deprecated – use ``stream_config`` instead.
            stream_config: Structured streaming configuration. When provided,
                ``enable_sse`` and ``enable_streaming`` are ignored.
        """
        self._redis = redis_client
        self._prefix = prefix

        # StreamConfig takes precedence; fall back to legacy booleans
        if stream_config is not None:
            self._stream_config = stream_config
        else:
            self._stream_config = StreamConfig.from_booleans(enable_sse, enable_streaming)

        # Keep legacy accessors for backward compat in tests / API layer
        self._enable_sse = self._stream_config.enabled
        self._enable_streaming = self._stream_config.enabled

    async def create_task(
        self,
        session_id: str | None = None,
        message: str | None = None,
        context: dict[str, Any] | None = None,
        caller: Caller | None = None,
    ) -> TaskState:
        """Create a new task.

        Args:
            session_id: Optional memory session ID
            message: The initial message/query for this task
            context: Optional context metadata
            caller: Optional caller identity (who created this task)

        Returns:
            The created TaskState
        """
        task_id = str(ULID())
        now = datetime.now(UTC)

        metadata: dict[str, Any] = {}
        if message:
            metadata["message"] = message
        if context:
            metadata["context"] = context

        task = TaskState(
            task_id=task_id,
            session_id=session_id,
            status=TaskStatus.QUEUED,
            caller=caller,
            metadata=metadata,
            created_at=now,
            updated_at=now,
        )

        # Store task state
        key = RedisKeys.task(task_id, self._prefix)
        await self._redis.set(key, task.model_dump_json())

        # Add to indices
        await _redis_await(self._redis.sadd(RedisKeys.all_tasks(self._prefix), task_id))
        if session_id:
            await self._redis.zadd(
                RedisKeys.session_tasks(session_id, self._prefix),
                {task_id: now.timestamp()},
            )
        await _redis_await(
            self._redis.sadd(
                RedisKeys.tasks_by_status(task.status.value, self._prefix),
                task_id,
            )
        )

        return task

    async def get_task(self, task_id: str) -> TaskState | None:
        """Get a task by ID.

        Args:
            task_id: The task ID

        Returns:
            TaskState if found, None otherwise
        """
        key = RedisKeys.task(task_id, self._prefix)
        data = await self._redis.get(key)
        if data is None:
            return None
        return TaskState.model_validate_json(data)

    async def update(
        self,
        task_id: str,
        status: TaskStatus | str | None = None,
        message: str | None = None,
        result: Any = None,
        error: str | None = None,
        update_type: str = "info",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Update a task's status, add a message, set result, or set error.

        This is the primary method for updating tasks. All parameters are optional
        and can be combined in a single call.

        Args:
            task_id: The task ID
            status: New status (TaskStatus enum or string like "in_progress")
            message: Progress message to add to updates list
            result: Result data (typically used with status="done")
            error: Error message (typically used with status="failed")
            update_type: Type of update for message (info, tool_call, reflection, error)
            metadata: Optional metadata for the update message

        Examples:
            # Start processing
            await tm.update(task_id, status="in_progress", message="Starting...")

            # Add progress update
            await tm.update(task_id, message="Processing step 2...")

            # Complete with result
            await tm.update(task_id, status="done", result={"answer": "..."})

            # Fail with error
            await tm.update(task_id, status="failed", error="Something went wrong")
        """
        task = await self.get_task(task_id)
        if task is None:
            return

        old_status = task.status

        # Handle status (accept string or enum)
        if status is not None:
            if isinstance(status, str):
                status = TaskStatus(status)
            task.status = status

        # Add progress message
        if message is not None:
            update = TaskUpdate(
                message=message,
                update_type=update_type,
                metadata=metadata or {},
            )
            task.updates.append(update)

        # Set result
        if result is not None:
            task.result = result

        # Set error
        if error is not None:
            task.error_message = error

        task.updated_at = datetime.now(UTC)

        # Update stored state
        key = RedisKeys.task(task_id, self._prefix)
        await self._redis.set(key, task.model_dump_json())

        # Update status index if status changed
        if status is not None and old_status != task.status:
            await _redis_await(
                self._redis.srem(
                    RedisKeys.tasks_by_status(old_status.value, self._prefix),
                    task_id,
                )
            )
            await _redis_await(
                self._redis.sadd(
                    RedisKeys.tasks_by_status(task.status.value, self._prefix),
                    task_id,
                )
            )

        # Determine event type for filtering
        if status is not None and task.status.value in {"done", "failed", "cancelled"}:
            event_type_label = task.status.value
        else:
            event_type_label = "update"

        # Publish update event to Pub/Sub for SSE streaming (when enabled)
        if self._stream_config.should_publish(event_type_label):
            event: dict[str, Any] = {"task_id": task_id}
            if status is not None:
                event["status"] = task.status.value
            if message is not None:
                event["message"] = message
                event["update_type"] = update_type
                if metadata:
                    event["metadata"] = metadata
            if result is not None:
                event["result"] = result
            if error is not None:
                event["error"] = error
            event["updated_at"] = task.updated_at.isoformat()

            await self._fan_out(event, task_id, session_id=task.session_id)

    async def update_status(self, task_id: str, status: TaskStatus) -> None:
        """Update task status.

        Convenience method. Prefer update() for new code.

        Args:
            task_id: The task ID
            status: The new status
        """
        await self.update(task_id, status=status)

    async def add_update(
        self,
        task_id: str,
        message: str,
        update_type: str = "info",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Add a progress update to a task.

        Convenience method. Prefer update() for new code.

        Args:
            task_id: The task ID
            message: The update message
            update_type: Type of update (info, tool_call, reflection, error)
            metadata: Optional additional metadata
        """
        await self.update(task_id, message=message, update_type=update_type, metadata=metadata)

    async def set_result(self, task_id: str, result: Any) -> None:
        """Set the task result and mark as done.

        Convenience method. Prefer update() for new code.

        Args:
            task_id: The task ID
            result: The result data (will be JSON serialized)
        """
        await self.update(task_id, status=TaskStatus.DONE, result=result)

    async def set_error(self, task_id: str, error: str) -> None:
        """Set an error message and mark as failed.

        Convenience method. Prefer update() for new code.

        Args:
            task_id: The task ID
            error: The error message
        """
        await self.update(task_id, status=TaskStatus.FAILED, error=error)

    async def publish(
        self,
        task_id: str,
        message: str,
        event_type: str = "token",
        metadata: dict[str, Any] | None = None,
        session_id: str | None = None,
    ) -> None:
        """Publish an event to Pub/Sub without persisting to task state.

        This is a lightweight, publish-only path intended for high-frequency
        events like token-by-token streaming. Unlike update(), it does NOT
        read or write the task object in Redis — it only publishes to the
        Pub/Sub channel.

        Args:
            task_id: The task ID
            message: The event payload (e.g. a single token)
            event_type: Event type label (default: "token")
            metadata: Optional metadata dict
            session_id: Optional session ID for session-scoped fan-out

        Example:
            # Stream tokens without persisting each one
            for token in llm_stream:
                await tm.publish(task_id, token)
        """
        if not self._stream_config.should_publish(event_type):
            return

        event: dict[str, Any] = {
            "task_id": task_id,
            "message": message,
            "event_type": event_type,
        }
        if metadata:
            event["metadata"] = metadata

        # If no session_id provided, try to look it up (lazy, optional)
        if session_id is None and ChannelScope.SESSION in self._stream_config.channels:
            task = await self.get_task(task_id)
            if task:
                session_id = task.session_id

        await self._fan_out(event, task_id, session_id=session_id)

    async def _fan_out(
        self,
        event: dict[str, Any],
        task_id: str,
        session_id: str | None = None,
    ) -> None:
        """Publish an event to all configured Pub/Sub channels.

        Args:
            event: The event payload dict (will be JSON-serialized)
            task_id: The task ID (used for per-task channel)
            session_id: Optional session ID (used for per-session channel)
        """
        payload = json.dumps(event, default=str)
        channels = self._stream_config.channels

        if ChannelScope.TASK in channels:
            channel = RedisKeys.task_updates_channel(task_id, self._prefix)
            await self._redis.publish(channel, payload)

        if ChannelScope.SESSION in channels and session_id:
            channel = RedisKeys.session_updates_channel(session_id, self._prefix)
            await self._redis.publish(channel, payload)

        if ChannelScope.GLOBAL in channels:
            channel = RedisKeys.global_updates_channel(self._prefix)
            await self._redis.publish(channel, payload)

    async def list_tasks(
        self,
        session_id: str | None = None,
        status: TaskStatus | None = None,
    ) -> list[TaskState]:
        """List tasks with optional filtering.

        Args:
            session_id: Filter by session ID
            status: Filter by status

        Returns:
            List of TaskState objects
        """
        # Determine which set to use
        if session_id:
            # Get task IDs from session's sorted set
            task_ids = await self._redis.zrange(
                RedisKeys.session_tasks(session_id, self._prefix), 0, -1
            )
        elif status:
            # Get task IDs from status set
            task_ids = await _redis_await(
                self._redis.smembers(RedisKeys.tasks_by_status(status.value, self._prefix))
            )
        else:
            # Get all task IDs
            task_ids = await _redis_await(self._redis.smembers(RedisKeys.all_tasks(self._prefix)))

        if not task_ids:
            return []

        # Fetch all tasks
        tasks = []
        for task_id in task_ids:
            task = await self.get_task(task_id)
            if task:
                # Apply status filter if listing by thread
                if status and task.status != status:
                    continue
                tasks.append(task)

        return tasks

    async def delete_task(self, task_id: str) -> None:
        """Delete a task.

        Args:
            task_id: The task ID to delete
        """
        task = await self.get_task(task_id)
        if task is None:
            return

        # Remove from all indices
        await _redis_await(self._redis.srem(RedisKeys.all_tasks(self._prefix), task_id))
        if task.session_id:
            await self._redis.zrem(RedisKeys.session_tasks(task.session_id, self._prefix), task_id)
        await _redis_await(
            self._redis.srem(RedisKeys.tasks_by_status(task.status.value, self._prefix), task_id)
        )

        # Remove the task data
        key = RedisKeys.task(task_id, self._prefix)
        await self._redis.delete(key)

    async def request_input(
        self,
        task_id: str,
        prompt: str,
        json_schema: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Request input from the user, pausing the task.

        This transitions the task to AWAITING_INPUT status and stores
        the input request schema. The task will remain paused until
        submit_input() is called with the user's response.

        Args:
            task_id: The task ID
            prompt: Human-readable prompt explaining what input is needed
            json_schema: Optional JSON Schema defining the expected input.
                         If not provided, uses empty object schema.
            metadata: Optional metadata for the input request
        """
        task = await self.get_task(task_id)
        if task is None:
            return

        # Create input request with JSON Schema
        request_kwargs: dict[str, Any] = {
            "prompt": prompt,
            "metadata": metadata or {},
        }
        if json_schema is not None:
            request_kwargs["json_schema"] = json_schema
        input_request = InputRequest(**request_kwargs)

        old_status = task.status
        task.status = TaskStatus.AWAITING_INPUT
        task.input_request = input_request
        task.input_response = None  # Clear any previous response
        task.updated_at = datetime.now(UTC)

        # Update stored state
        key = RedisKeys.task(task_id, self._prefix)
        await self._redis.set(key, task.model_dump_json())

        # Update status index
        await _redis_await(
            self._redis.srem(
                RedisKeys.tasks_by_status(old_status.value, self._prefix),
                task_id,
            )
        )
        await _redis_await(
            self._redis.sadd(
                RedisKeys.tasks_by_status(TaskStatus.AWAITING_INPUT.value, self._prefix),
                task_id,
            )
        )

    async def submit_input(
        self,
        task_id: str,
        response: dict[str, Any],
    ) -> bool:
        """Submit user input to a task that is awaiting input.

        This stores the user's response and transitions the task back to
        QUEUED status so it can be resumed by a worker.

        Args:
            task_id: The task ID
            response: Dictionary mapping field names to values.
                      For simple prompts without fields, use {"response": "..."}

        Returns:
            True if input was submitted successfully, False if task not found
            or not in AWAITING_INPUT status.

        Raises:
            ValueError: If the response doesn't match the input request's JSON schema.
        """
        task = await self.get_task(task_id)
        if task is None:
            return False

        if task.status != TaskStatus.AWAITING_INPUT:
            return False

        # Validate response against JSON schema if present
        if task.input_request and task.input_request.json_schema:
            try:
                jsonschema.validate(response, task.input_request.json_schema)
            except jsonschema.ValidationError as e:
                raise ValueError(str(e.message)) from e

        # Store the response and transition back to queued
        task.input_response = response
        task.status = TaskStatus.QUEUED
        task.updated_at = datetime.now(UTC)

        # Update stored state
        key = RedisKeys.task(task_id, self._prefix)
        await self._redis.set(key, task.model_dump_json())

        # Update status index
        await _redis_await(
            self._redis.srem(
                RedisKeys.tasks_by_status(TaskStatus.AWAITING_INPUT.value, self._prefix),
                task_id,
            )
        )
        await _redis_await(
            self._redis.sadd(
                RedisKeys.tasks_by_status(TaskStatus.QUEUED.value, self._prefix),
                task_id,
            )
        )

        return True

    async def get_input_request(self, task_id: str) -> InputRequest | None:
        """Get the pending input request for a task.

        Args:
            task_id: The task ID

        Returns:
            InputRequest if task is awaiting input, None otherwise
        """
        task = await self.get_task(task_id)
        if task is None:
            return None

        if task.status != TaskStatus.AWAITING_INPUT:
            return None

        return task.input_request

    async def clear_input(self, task_id: str) -> None:
        """Clear input request and response from a task.

        Call this after the task has processed the user's input.

        Args:
            task_id: The task ID
        """
        task = await self.get_task(task_id)
        if task is None:
            return

        task.input_request = None
        task.input_response = None
        task.updated_at = datetime.now(UTC)

        key = RedisKeys.task(task_id, self._prefix)
        await self._redis.set(key, task.model_dump_json())
