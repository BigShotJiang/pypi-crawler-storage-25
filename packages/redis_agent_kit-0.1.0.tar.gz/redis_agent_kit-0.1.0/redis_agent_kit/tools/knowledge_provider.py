"""Built-in knowledge tool provider."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .models import ToolCapability, ToolDefinition
from .provider import ToolProvider

if TYPE_CHECKING:
    from redis_agent_kit.knowledge import KnowledgeStore


class KnowledgeProvider(ToolProvider):
    """Tool provider for knowledge base operations.

    Exposes search as a tool that agents can use to query the knowledge base.
    """

    capabilities = {ToolCapability.KNOWLEDGE}

    def __init__(self, knowledge_store: KnowledgeStore):
        """Initialize knowledge provider.

        Args:
            knowledge_store: KnowledgeStore instance to query.
        """
        self._ks = knowledge_store

    @property
    def provider_name(self) -> str:
        return "knowledge"

    def create_tool_schemas(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="search_knowledge",
                description="Search the knowledge base for relevant information. "
                "Use this to find documentation, guides, or previously ingested content.",
                capability=ToolCapability.KNOWLEDGE,
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query to find relevant content",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum results (default: 5)",
                            "default": 5,
                        },
                    },
                    "required": ["query"],
                },
            ),
        ]

    async def search_knowledge(self, query: str, limit: int = 5) -> dict[str, Any]:
        """Search the knowledge base.

        Args:
            query: Search query text.
            limit: Maximum results.

        Returns:
            Dict with search results.
        """
        results = await self._ks.search(query, limit=limit)
        return {
            "query": query,
            "results": [
                {
                    "content": r.content,
                    "score": r.score,
                    "doc_id": r.doc_id,
                    "metadata": r.metadata,
                }
                for r in results
            ],
            "count": len(results),
        }
