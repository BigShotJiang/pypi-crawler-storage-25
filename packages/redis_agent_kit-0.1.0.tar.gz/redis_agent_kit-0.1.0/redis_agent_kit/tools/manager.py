"""Tool manager for routing and executing tools."""

from __future__ import annotations

import logging
from typing import Any

from .models import Tool, ToolCapability
from .provider import ToolProvider

logger = logging.getLogger(__name__)


class ToolManager:
    """Manages tool providers and routes tool calls.

    Example:
        manager = ToolManager()
        manager.add_provider(WeatherProvider())
        manager.add_provider(KnowledgeProvider(knowledge_store))

        # Get all tools in OpenAI format
        tools = manager.get_openai_tools()

        # Execute a tool call
        result = await manager.execute("get_weather", {"location": "NYC"})
    """

    def __init__(self) -> None:
        """Initialize tool manager."""
        self._providers: dict[str, ToolProvider] = {}
        self._routing_table: dict[str, tuple[ToolProvider, Tool]] = {}
        self._tools: list[Tool] = []

    def add_provider(self, provider: ToolProvider) -> None:
        """Add a tool provider.

        Args:
            provider: ToolProvider instance to add.
        """
        name = provider.provider_name
        if name in self._providers:
            logger.warning(f"Replacing existing provider: {name}")

        self._providers[name] = provider

        # Register all tools from this provider
        for tool in provider.tools():
            self._routing_table[tool.metadata.name] = (provider, tool)
            self._tools.append(tool)

    def remove_provider(self, name: str) -> bool:
        """Remove a provider by name.

        Args:
            name: Provider name to remove.

        Returns:
            True if removed, False if not found.
        """
        if name not in self._providers:
            return False

        self._providers.pop(name)

        # Remove all tools from this provider
        tools_to_remove = [t for t in self._tools if t.metadata.provider_name == name]
        for tool in tools_to_remove:
            self._routing_table.pop(tool.metadata.name, None)
            self._tools.remove(tool)

        return True

    def get_tools(
        self,
        capabilities: set[ToolCapability] | None = None,
        exclude_capabilities: set[ToolCapability] | None = None,
    ) -> list[Tool]:
        """Get tools, optionally filtered by capability.

        Args:
            capabilities: If set, only include tools with these capabilities.
            exclude_capabilities: If set, exclude tools with these capabilities.

        Returns:
            List of Tool objects.
        """
        result = self._tools

        if capabilities:
            result = [t for t in result if t.metadata.capability in capabilities]

        if exclude_capabilities:
            result = [t for t in result if t.metadata.capability not in exclude_capabilities]

        return result

    def get_openai_tools(
        self,
        capabilities: set[ToolCapability] | None = None,
        exclude_capabilities: set[ToolCapability] | None = None,
    ) -> list[dict[str, Any]]:
        """Get tools in OpenAI function calling format.

        Args:
            capabilities: If set, only include tools with these capabilities.
            exclude_capabilities: If set, exclude tools with these capabilities.

        Returns:
            List of OpenAI tool schemas.
        """
        tools = self.get_tools(capabilities, exclude_capabilities)
        return [t.to_openai_schema() for t in tools]

    async def execute(self, tool_name: str, args: dict[str, Any]) -> Any:
        """Execute a tool by name.

        Args:
            tool_name: Name of the tool to execute.
            args: Arguments to pass to the tool.

        Returns:
            Tool execution result.

        Raises:
            KeyError: If tool not found.
        """
        if tool_name not in self._routing_table:
            raise KeyError(f"Tool not found: {tool_name}")

        _, tool = self._routing_table[tool_name]
        return await tool.invoke(args)

    def has_tool(self, tool_name: str) -> bool:
        """Check if a tool exists."""
        return tool_name in self._routing_table

    @property
    def providers(self) -> dict[str, ToolProvider]:
        """Get all registered providers."""
        return self._providers.copy()
