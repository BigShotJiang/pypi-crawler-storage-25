"""Data models for the tool system."""

from collections.abc import Awaitable, Callable
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ToolCapability(StrEnum):
    """Capabilities that tools can provide."""

    KNOWLEDGE = "knowledge"  # Knowledge base search/retrieval
    UTILITIES = "utilities"  # General utility functions
    CUSTOM = "custom"  # User-defined tools


class ToolDefinition(BaseModel):
    """Definition of a tool that the LLM can call.

    This describes the tool schema in OpenAI function calling format.
    """

    name: str = Field(..., description="Unique tool name")
    description: str = Field(..., description="Description for the LLM")
    parameters: dict[str, Any] = Field(
        default_factory=lambda: {"type": "object", "properties": {}, "required": []},
        description="JSON schema for parameters (OpenAI format)",
    )
    capability: ToolCapability = Field(
        default=ToolCapability.CUSTOM,
        description="Category for filtering",
    )

    def to_openai_schema(self) -> dict[str, Any]:
        """Convert to OpenAI function calling format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


class ToolMetadata(BaseModel):
    """Metadata about a tool implementation."""

    name: str
    description: str
    capability: ToolCapability
    provider_name: str


class Tool(BaseModel):
    """Concrete tool combining definition, metadata, and executor."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    metadata: ToolMetadata
    definition: ToolDefinition
    invoke: Callable[[dict[str, Any]], Awaitable[Any]]

    def to_openai_schema(self) -> dict[str, Any]:
        """Convert to OpenAI function calling format."""
        return self.definition.to_openai_schema()
