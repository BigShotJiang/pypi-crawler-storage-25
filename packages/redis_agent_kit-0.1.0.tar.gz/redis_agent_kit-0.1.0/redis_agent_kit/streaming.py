"""Streaming configuration for Redis Agent Kit.

StreamConfig replaces the boolean ``enable_sse`` / ``enable_streaming``
flags with a structured object that controls:

* **Channel scoping** – which Pub/Sub channels an event fans out to
  (per-task, per-session, global).
* **Event filtering** – which event types are published (e.g. only
  ``token`` and terminal statuses, not every milestone update).
* **Persistence policy** – which event types are persisted to the task's
  update history vs. only broadcast ephemerally.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum


class ChannelScope(StrEnum):
    """Which Pub/Sub channels an event is published to."""

    TASK = "task"
    """Per-task channel: ``rak:task:{task_id}:updates``"""

    SESSION = "session"
    """Per-session channel: ``rak:session:{session_id}:updates``"""

    GLOBAL = "global"
    """Global channel: ``rak:updates``"""


# Well-known event type constants
EVENT_UPDATE = "update"
EVENT_TOKEN = "token"
EVENT_DONE = "done"
EVENT_FAILED = "failed"
EVENT_CANCELLED = "cancelled"
EVENT_INPUT_REQUIRED = "input_required"

# All event types (for convenience)
ALL_EVENTS = frozenset(
    {
        EVENT_UPDATE,
        EVENT_TOKEN,
        EVENT_DONE,
        EVENT_FAILED,
        EVENT_CANCELLED,
        EVENT_INPUT_REQUIRED,
    }
)

# Terminal event types
TERMINAL_EVENTS = frozenset({EVENT_DONE, EVENT_FAILED, EVENT_CANCELLED})


@dataclass
class StreamConfig:
    """Configuration for real-time streaming behaviour.

    Controls how events are published via Redis Pub/Sub and which events
    are persisted to the task state.

    Examples:
        # Minimal – per-task SSE only (equivalent to old enable_sse=True)
        StreamConfig(enabled=True)

        # Token streaming without milestone updates over SSE
        StreamConfig(enabled=True, publish_events={"token", "done", "failed", "cancelled"})

        # Session-scoped streaming (single SSE connection per chat session)
        StreamConfig(
            enabled=True,
            channels={ChannelScope.TASK, ChannelScope.SESSION},
        )

        # Global dashboard – all events from every task
        StreamConfig(
            enabled=True,
            channels={ChannelScope.TASK, ChannelScope.SESSION, ChannelScope.GLOBAL},
        )

        # Ephemeral tokens, persisted milestones
        StreamConfig(
            enabled=True,
            persist_events={"update", "done", "failed"},   # tokens NOT persisted
        )
    """

    enabled: bool = False
    """Master switch.  When ``False``, no Pub/Sub publishing happens at all."""

    channels: set[ChannelScope] = field(
        default_factory=lambda: {ChannelScope.TASK},
    )
    """Which Pub/Sub channel scopes to publish to.

    Defaults to per-task only.  Add ``ChannelScope.SESSION`` or
    ``ChannelScope.GLOBAL`` to fan out more broadly.
    """

    publish_events: set[str] | None = None
    """If set, only these event types are published to Pub/Sub.

    ``None`` means *all* event types are published (the default).
    Example: ``{"token", "done", "failed", "cancelled"}`` to suppress
    milestone ``update`` events.
    """

    persist_events: set[str] | None = None
    """If set, only these event types are persisted to the task's update list.

    ``None`` means the default persistence behaviour (milestone updates
    are persisted, tokens are not).  Explicitly listing event types
    overrides the default.
    """

    def should_publish(self, event_type: str) -> bool:
        """Return ``True`` if this event type should be published to Pub/Sub."""
        if not self.enabled:
            return False
        if self.publish_events is None:
            return True
        return event_type in self.publish_events

    def should_persist(self, event_type: str) -> bool:
        """Return ``True`` if this event type should be persisted to task state.

        When ``persist_events`` is ``None``, falls back to the default:
        everything except ``token`` is persisted.
        """
        if self.persist_events is None:
            # Default: persist everything except tokens
            return event_type != EVENT_TOKEN
        return event_type in self.persist_events

    @classmethod
    def from_booleans(
        cls, enable_sse: bool = False, enable_streaming: bool = False
    ) -> StreamConfig:
        """Create a StreamConfig from the legacy boolean flags.

        This bridges old-style ``enable_sse`` / ``enable_streaming``
        parameters to the new config object.
        """
        if not enable_sse and not enable_streaming:
            return cls(enabled=False)
        return cls(enabled=True)
