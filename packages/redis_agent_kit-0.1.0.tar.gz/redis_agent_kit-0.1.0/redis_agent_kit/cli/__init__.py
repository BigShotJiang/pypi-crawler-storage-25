"""Redis Agent Kit CLI."""

from redis_agent_kit.cli.main import cli

__all__ = ["cli"]
