"""Redis Agent Kit CLI main entry point."""

import click

from redis_agent_kit import __version__


class Context:
    """CLI context object passed between commands."""

    def __init__(
        self,
        redis_url: str = "redis://localhost:6379",
        api_base: str | None = None,
        token: str | None = None,
        project: str | None = None,
        agent: str | None = None,
    ):
        self.redis_url = redis_url
        self.api_base = api_base
        self.token = token
        self.project = project
        self.agent = agent


pass_context = click.make_pass_decorator(Context, ensure=True)


@click.group()
@click.version_option(version=__version__, prog_name="rak")
@click.option(
    "--redis-url",
    envvar="REDIS_URL",
    default="redis://localhost:6379",
    help="Redis connection URL",
)
@click.option(
    "--api-base",
    envvar="RAK_API_BASE_URL",
    default=None,
    help="API base URL for operator commands",
)
@click.option(
    "--token",
    envvar="RAK_API_TOKEN",
    default=None,
    help="API token for operator commands",
)
@click.option(
    "--project",
    envvar="RAK_PROJECT",
    default=None,
    help="Default project ID for operator commands",
)
@click.option(
    "--agent",
    envvar="RAK_AGENT",
    default=None,
    help="Default agent ID for operator commands",
)
@click.pass_context
def cli(
    ctx: click.Context,
    redis_url: str,
    api_base: str | None,
    token: str | None,
    project: str | None,
    agent: str | None,
) -> None:
    """Redis Agent Kit CLI.

    Manage tasks, threads, and data pipelines for AI agents.
    """
    ctx.ensure_object(Context)
    ctx.obj.redis_url = redis_url
    ctx.obj.api_base = api_base
    ctx.obj.token = token
    ctx.obj.project = project
    ctx.obj.agent = agent


@cli.group("task")
@pass_context
def task(ctx: Context) -> None:
    """Task lifecycle commands."""


# Import and register API-backed task subcommands
from redis_agent_kit.cli.task import (
    cancel_task,
    get_task,
    list_tasks,
    run_task,
    submit_task_input,
    task_logs,
    task_result,
    task_status,
)

task.add_command(run_task)
task.add_command(list_tasks)
task.add_command(get_task)
task.add_command(task_status)
task.add_command(task_result)
task.add_command(task_logs)
task.add_command(cancel_task)
task.add_command(submit_task_input)

# Alias: tasks -> task
cli.add_command(task, name="tasks")
cli.add_command(task_status, name="status")
cli.add_command(task_logs, name="logs")
cli.add_command(run_task, name="run")


@cli.group("agent")
@pass_context
def agent(ctx: Context) -> None:
    """Agent discovery commands."""


from redis_agent_kit.cli.agent import get_agent, list_agents
from redis_agent_kit.cli.chat import chat_cmd

agent.add_command(list_agents)
agent.add_command(get_agent)


@cli.group()
@pass_context
def pipelines(ctx: Context) -> None:
    """Pipeline commands.

    Run and manage data ingestion pipelines.
    """
    pass


# Import and register pipeline subcommands
from redis_agent_kit.cli.pipelines import (
    add_cmd,
    batches_cmd,
    clear_cmd,
    ingest_cmd,
    prepare_cmd,
    run_cmd,
    status_cmd,
)

pipelines.add_command(run_cmd)
pipelines.add_command(status_cmd)
pipelines.add_command(clear_cmd)
pipelines.add_command(prepare_cmd)
pipelines.add_command(ingest_cmd)
pipelines.add_command(batches_cmd)
pipelines.add_command(add_cmd)

# Import and register worker command
from redis_agent_kit.cli.worker import worker

cli.add_command(worker)
cli.add_command(chat_cmd, name="chat")

# Operator commands
from redis_agent_kit.cli.health import health_cmd
from redis_agent_kit.cli.up import up_cmd

cli.add_command(health_cmd, name="health")
cli.add_command(up_cmd, name="up")


if __name__ == "__main__":  # pragma: no cover
    cli()
