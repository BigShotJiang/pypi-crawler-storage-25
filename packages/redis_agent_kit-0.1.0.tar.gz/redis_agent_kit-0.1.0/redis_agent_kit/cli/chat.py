"""CLI chat command for A2A-backed conversations."""

from __future__ import annotations

import uuid
from time import sleep
from typing import Any

import click

from redis_agent_kit.cli.api_common import (
    call_api,
    echo_json,
    maybe_project,
    require_agent,
    require_api_base,
)
from redis_agent_kit.cli.task import _extract_agent_output_from_logs

TERMINAL_TASK_STATES = {"succeeded", "failed", "cancelled", "timed_out"}
TERMINAL_A2A_STATES = {"completed", "failed", "canceled"}


def _resolve_scope(
    ctx: click.Context,
    *,
    project: str | None,
    agent: str | None,
) -> tuple[str, str, str]:
    base = require_api_base(ctx.obj.api_base)
    project_id = maybe_project(project, ctx.obj.project)
    if not project_id:
        raise click.ClickException("Project ID is required. Set --project or default project.")
    agent_id = require_agent(agent, ctx.obj.agent)
    return base, project_id, agent_id


def _extract_task_id(payload: dict[str, Any]) -> str:
    data = payload.get("data")
    if isinstance(data, dict):
        task = data.get("task")
        if isinstance(task, dict):
            for key in ("id", "taskId"):
                value = task.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()
        a2a = data.get("a2a")
        if isinstance(a2a, dict):
            value = a2a.get("taskId")
            if isinstance(value, str) and value.strip():
                return value.strip()
        value = data.get("taskId")
        if isinstance(value, str) and value.strip():
            return value.strip()
    raise click.ClickException("Chat response missing task identifier.")


def _extract_context_id(payload: dict[str, Any]) -> str | None:
    data = payload.get("data")
    if not isinstance(data, dict):
        return None
    for container_name in ("a2a", "task"):
        container = data.get(container_name)
        if isinstance(container, dict):
            value = container.get("contextId")
            if isinstance(value, str) and value.strip():
                return value.strip()
    value = data.get("contextId")
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _extract_status_state(payload: dict[str, Any]) -> str | None:
    data = payload.get("data")
    if not isinstance(data, dict):
        return None
    status = data.get("status")
    if isinstance(status, dict):
        state = status.get("state")
        if isinstance(state, str) and state.strip():
            return state.strip().lower()
    task = data.get("task")
    if isinstance(task, dict):
        task_status = task.get("status")
        if isinstance(task_status, dict):
            state = task_status.get("state")
            if isinstance(state, str) and state.strip():
                return state.strip().lower()
    return None


def _is_terminal(payload: dict[str, Any]) -> bool:
    data = payload.get("data")
    if isinstance(data, dict):
        status = data.get("status")
        if isinstance(status, dict):
            terminal = status.get("terminal")
            if isinstance(terminal, bool):
                return terminal
    state = _extract_status_state(payload)
    return state in TERMINAL_TASK_STATES or state in TERMINAL_A2A_STATES


def _result_available(payload: dict[str, Any]) -> bool:
    data = payload.get("data")
    if not isinstance(data, dict):
        return False
    status = data.get("status")
    if isinstance(status, dict):
        value = status.get("resultAvailable")
        if isinstance(value, bool):
            return value
    return _is_terminal(payload)


def _hydrate_result_output(
    *,
    base: str,
    token: str | None,
    project_id: str,
    agent_id: str,
    task_id: str,
    result_payload: dict[str, Any],
) -> dict[str, Any]:
    data = result_payload.get("data")
    if not isinstance(data, dict):
        return result_payload
    task_result = data.get("taskResult")
    if not isinstance(task_result, dict):
        return result_payload
    result = task_result.get("result")
    if not isinstance(result, dict) or "output" in result or "reply" in result:
        return result_payload
    logs_response = call_api(
        api_base=base,
        token=token,
        method="GET",
        path=f"/v1/projects/{project_id}/agents/{agent_id}/tasks/{task_id}/logs",
        params={"limit": 500},
    )
    logs = logs_response.get("data", {}).get("logs")
    if isinstance(logs, list):
        output = _extract_agent_output_from_logs(logs)
        if output is not None:
            result["output"] = output
    return result_payload


def _extract_reply(payload: dict[str, Any]) -> str | None:
    data = payload.get("data")
    if not isinstance(data, dict):
        return None
    task_result = data.get("taskResult")
    if isinstance(task_result, dict):
        result = task_result.get("result")
        if isinstance(result, dict):
            output = result.get("output")
            if isinstance(output, dict):
                reply = output.get("reply")
                if isinstance(reply, str) and reply.strip():
                    return reply.strip()
            reply = result.get("reply")
            if isinstance(reply, str) and reply.strip():
                return reply.strip()
    return None


def _build_create_payload(
    *,
    message: str,
    context_id: str | None,
    deployment: str | None,
    version: str | None,
    trace_tool_calls: str,
) -> dict[str, Any]:
    request_input: dict[str, Any] = {"message": message}
    if context_id:
        request_input["contextId"] = context_id
    payload: dict[str, Any] = {
        "request": {"protocol": "a2a", "input": request_input},
    }
    if deployment:
        payload["deploymentId"] = deployment
    if version:
        payload["requestedVersionId"] = version
    if trace_tool_calls != "off":
        payload["options"] = {"trace": {"toolCalls": trace_tool_calls}}
    return payload


def _poll_status(
    *,
    base: str,
    token: str | None,
    project_id: str,
    agent_id: str,
    task_id: str,
    poll_interval_ms: int,
    max_polls: int,
) -> dict[str, Any]:
    for attempt in range(max_polls):
        status_payload = call_api(
            api_base=base,
            token=token,
            method="GET",
            path=f"/v1/projects/{project_id}/agents/{agent_id}/tasks/{task_id}",
        )
        if _is_terminal(status_payload):
            return status_payload
        if attempt < max_polls - 1:
            sleep(poll_interval_ms / 1000.0)
    raise click.ClickException(
        f"Task {task_id} did not reach a terminal state within polling limits."
    )


def _chat_once(
    *,
    base: str,
    token: str | None,
    project_id: str,
    agent_id: str,
    message: str,
    context_id: str | None,
    deployment: str | None,
    version: str | None,
    trace_tool_calls: str,
    poll: bool,
    poll_interval_ms: int,
    max_polls: int,
) -> tuple[dict[str, Any], str | None]:
    create_payload = call_api(
        api_base=base,
        token=token,
        method="POST",
        path=f"/v1/projects/{project_id}/agents/{agent_id}/a2a",
        payload=_build_create_payload(
            message=message,
            context_id=context_id,
            deployment=deployment,
            version=version,
            trace_tool_calls=trace_tool_calls,
        ),
    )
    resolved_context_id = _extract_context_id(create_payload) or context_id
    envelope: dict[str, Any] = {"mode": "a2a", "create": create_payload}
    if not poll:
        return envelope, resolved_context_id

    task_id = _extract_task_id(create_payload)
    status_payload = _poll_status(
        base=base,
        token=token,
        project_id=project_id,
        agent_id=agent_id,
        task_id=task_id,
        poll_interval_ms=poll_interval_ms,
        max_polls=max_polls,
    )
    envelope["status"] = status_payload
    if _result_available(status_payload):
        result_payload = call_api(
            api_base=base,
            token=token,
            method="GET",
            path=f"/v1/projects/{project_id}/agents/{agent_id}/tasks/{task_id}/result",
        )
        envelope["result"] = _hydrate_result_output(
            base=base,
            token=token,
            project_id=project_id,
            agent_id=agent_id,
            task_id=task_id,
            result_payload=result_payload,
        )
    if trace_tool_calls != "off":
        envelope["trace"] = call_api(
            api_base=base,
            token=token,
            method="GET",
            path=f"/v1/projects/{project_id}/agents/{agent_id}/tasks/{task_id}/trace",
        )
    return envelope, resolved_context_id


def _render_chat_output(envelope: dict[str, Any], *, json_output: bool) -> None:
    if json_output:
        echo_json(envelope)
        return
    create_payload = envelope.get("create", {})
    status_payload = envelope.get("status", {})
    result_payload = envelope.get("result", {})
    task_id = _extract_task_id(create_payload)
    context_id = _extract_context_id(create_payload)
    if task_id:
        click.echo(f"Task ID: {task_id}")
    if context_id:
        click.echo(f"Context ID: {context_id}")
    state = _extract_status_state(status_payload)
    if state:
        click.echo(f"State: {state}")
    reply = _extract_reply(result_payload)
    if reply:
        click.echo("")
        click.echo(reply)
        return
    if result_payload:
        click.echo("")
        echo_json(result_payload)


@click.command("chat")
@click.argument("message", required=False)
@click.option("--message", "message_flag", default=None, help="Chat message to send.")
@click.option("--project", default=None, help="Project ID override")
@click.option("--agent", "agent_id", default=None, help="Agent ID override")
@click.option("--deployment", default=None, help="Deployment ID override")
@click.option("--version", default=None, help="Requested version ID override")
@click.option("--context-id", default=None, help="A2A context ID for conversation continuity")
@click.option(
    "--trace-tool-calls",
    default="off",
    show_default=True,
    type=click.Choice(["off", "summary", "full"], case_sensitive=False),
    help="Tool-call trace mode.",
)
@click.option("--poll/--no-poll", default=True, show_default=True, help="Poll until completion.")
@click.option(
    "--poll-interval-ms",
    default=1000,
    show_default=True,
    type=int,
    help="Polling interval in milliseconds.",
)
@click.option(
    "--max-polls", default=120, show_default=True, type=int, help="Maximum poll attempts."
)
@click.option(
    "--interactive/--no-interactive",
    default=False,
    show_default=True,
    help="Keep sending turns on one shared context ID.",
)
@click.option(
    "--json-output/--pretty",
    default=False,
    show_default=True,
    help="Print full JSON envelopes instead of concise chat output.",
)
@click.pass_context
def chat_cmd(
    ctx: click.Context,
    message: str | None,
    message_flag: str | None,
    project: str | None,
    agent_id: str | None,
    deployment: str | None,
    version: str | None,
    context_id: str | None,
    trace_tool_calls: str,
    poll: bool,
    poll_interval_ms: int,
    max_polls: int,
    interactive: bool,
    json_output: bool,
) -> None:
    """Send chat turns through the agent A2A ingress."""
    if poll_interval_ms < 0:
        raise click.ClickException("--poll-interval-ms must be >= 0.")
    if max_polls < 1:
        raise click.ClickException("--max-polls must be >= 1.")

    resolved_message = (message_flag or message or "").strip()
    if not interactive and not resolved_message:
        raise click.ClickException("Provide MESSAGE or --message, or use --interactive.")

    base, project_id, resolved_agent_id = _resolve_scope(ctx, project=project, agent=agent_id)
    current_context_id = (context_id or "").strip() or None

    if interactive:
        if current_context_id is None:
            current_context_id = f"ctx_{uuid.uuid4().hex[:12]}"
        click.echo(f"Context ID: {current_context_id}")
        click.echo("Type /exit to finish the conversation.")

        pending_first_turn = resolved_message
        while True:
            try:
                user_message = (
                    pending_first_turn
                    or click.prompt("you", prompt_suffix="> ", show_default=False).strip()
                )
            except (EOFError, KeyboardInterrupt):
                click.echo("")
                break
            pending_first_turn = ""
            if not user_message:
                continue
            if user_message in {"/exit", "/quit"}:
                break
            envelope, current_context_id = _chat_once(
                base=base,
                token=ctx.obj.token,
                project_id=project_id,
                agent_id=resolved_agent_id,
                message=user_message,
                context_id=current_context_id,
                deployment=deployment,
                version=version,
                trace_tool_calls=trace_tool_calls.lower(),
                poll=poll,
                poll_interval_ms=poll_interval_ms,
                max_polls=max_polls,
            )
            _render_chat_output(envelope, json_output=json_output)
            click.echo("")
        return

    envelope, _ = _chat_once(
        base=base,
        token=ctx.obj.token,
        project_id=project_id,
        agent_id=resolved_agent_id,
        message=resolved_message,
        context_id=current_context_id,
        deployment=deployment,
        version=version,
        trace_tool_calls=trace_tool_calls.lower(),
        poll=poll,
        poll_interval_ms=poll_interval_ms,
        max_polls=max_polls,
    )
    _render_chat_output(envelope, json_output=json_output)
