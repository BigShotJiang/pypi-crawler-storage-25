"""Shared HTTP helpers for API-backed CLI commands."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

import click
import httpx


@dataclass(slots=True)
class ApiContext:
    """Connection settings for API-backed commands."""

    api_base: str | None
    token: str | None
    project: str | None
    agent: str | None


def require_api_base(api_base: str | None) -> str:
    """Return normalized api base or exit with a clear message."""
    base = (api_base or "").strip()
    if base:
        return base
    raise click.ClickException("API base URL is required. Set --api-base or RAK_API_BASE_URL.")


def maybe_project(project: str | None, default: str | None) -> str | None:
    """Resolve project flag with context fallback."""
    value = (project or "").strip()
    if value:
        return value
    fallback = (default or "").strip()
    return fallback or None


def require_agent(agent: str | None, default: str | None) -> str:
    """Resolve agent flag with context fallback or fail."""
    value = (agent or "").strip()
    if value:
        return value
    fallback = (default or "").strip()
    if fallback:
        return fallback
    raise click.ClickException("Agent ID is required. Set --agent or a default agent.")


def build_headers(token: str | None) -> dict[str, str]:
    """Build request headers."""
    headers = {"Accept": "application/json"}
    auth = (token or "").strip()
    if auth:
        headers["Authorization"] = f"Bearer {auth}"
    return headers


def call_api(
    *,
    api_base: str,
    token: str | None,
    method: str,
    path: str,
    params: dict[str, Any] | None = None,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Call a JSON endpoint and return decoded payload."""
    base = api_base.rstrip("/") + "/"
    target = path.lstrip("/")
    url = urljoin(base, target)
    headers = build_headers(token)
    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.request(
                method.upper(),
                url,
                headers=headers,
                params=params,
                json=payload,
            )
    except Exception as exc:  # pragma: no cover - network failures
        raise click.ClickException(f"Request failed: {exc}") from exc

    body: dict[str, Any]
    if response.content:
        try:
            body = response.json()
        except Exception as exc:
            raise click.ClickException(
                f"Invalid JSON response ({response.status_code}): {response.text}"
            ) from exc
    else:
        body = {}

    if response.status_code >= 400:
        message = body.get("error", {}).get("message")
        if not message:
            message = body.get("detail") or response.text or response.reason_phrase
        raise click.ClickException(f"{response.status_code}: {message}")

    return body


def echo_json(payload: dict[str, Any]) -> None:
    """Pretty-print JSON payload."""
    click.echo(json.dumps(payload, indent=2, default=str))


def parse_json_object(raw: str) -> dict[str, Any]:
    """Parse inline JSON object."""
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise click.ClickException(f"Invalid JSON: {exc}") from exc
    if not isinstance(parsed, dict):
        raise click.ClickException("JSON input must be an object.")
    return parsed


def parse_json_file(path: str) -> dict[str, Any]:
    """Parse JSON object from a file."""
    file_path = Path(path)
    if not file_path.exists():
        raise click.ClickException(f"File not found: {path}")
    raw = file_path.read_text(encoding="utf-8")
    return parse_json_object(raw)
