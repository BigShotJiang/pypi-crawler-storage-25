"""CLI pipeline commands."""

import asyncio
import shutil
from pathlib import Path
from typing import Any

import click
import nest_asyncio
import redis.asyncio as redis_lib

from redis_agent_kit.pipelines import (
    ArtifactStorage,
    FileScraper,
    Pipeline,
    PipelineConfig,
    ProcessorConfig,
    SourceConfig,
    VectorStore,
)
from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator
from redis_agent_kit.vectorizer import Vectorizer


def get_vector_store(redis_url: str, prefix: str = "rak") -> Any:
    """Get an async VectorStore for the given Redis URL."""
    client = redis_lib.from_url(redis_url)  # type: ignore[no-untyped-call]
    return VectorStore(client, prefix=prefix)


def run_async(coro: Any) -> Any:
    """Run an async coroutine synchronously."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # We're inside an async context, use nest_asyncio
        nest_asyncio.apply()
        return loop.run_until_complete(coro)
    else:
        return asyncio.run(coro)


async def run_pipeline(
    redis_url: str,
    source_path: Path,
    patterns: list[str],
    chunk_size: int,
    chunk_overlap: int,
    embedding_model: str,
    prefix: str,
) -> dict[str, Any]:
    """Run the pipeline asynchronously."""
    client = redis_lib.from_url(redis_url)  # type: ignore[no-untyped-call]

    config = ProcessorConfig(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )

    pipeline = Pipeline(
        client,
        processor_config=config,
        embedding_model=embedding_model,
        store_prefix=prefix,
    )

    scraper = FileScraper(source_path, patterns=patterns, recursive=True)
    result = await pipeline.run(scraper)

    return {
        "status": result.status,
        "documents_processed": result.documents_processed,
        "chunks_created": result.chunks_created,
        "errors": result.errors,
    }


@click.command("run")
@click.argument("source", type=click.Path(exists=True, path_type=Path))
@click.option(
    "-p",
    "--pattern",
    "patterns",
    multiple=True,
    default=["*.md", "*.txt"],
    help="File patterns to match (can be repeated)",
)
@click.option("--chunk-size", type=int, default=1000, help="Chunk size in characters")
@click.option("--chunk-overlap", type=int, default=200, help="Chunk overlap in characters")
@click.option(
    "--model",
    "embedding_model",
    default="text-embedding-3-small",
    help="Embedding model",
)
@click.option("--prefix", default="rak", help="Redis key prefix")
@click.pass_context
def run_cmd(
    ctx: click.Context,
    source: Path,
    patterns: tuple[str, ...],
    chunk_size: int,
    chunk_overlap: int,
    embedding_model: str,
    prefix: str,
) -> None:
    """Run a pipeline on a source directory.

    Ingests documents, chunks them, generates embeddings, and stores in Redis.
    """
    redis_url = ctx.obj.redis_url
    pattern_list = list(patterns) if patterns else ["*.md", "*.txt"]

    click.echo(f"Running pipeline on {source}...")
    click.echo(f"  Patterns: {pattern_list}")
    click.echo(f"  Chunk size: {chunk_size}")

    result = run_async(
        run_pipeline(
            redis_url=redis_url,
            source_path=source,
            patterns=pattern_list,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            embedding_model=embedding_model,
            prefix=prefix,
        )
    )

    click.echo(f"\nStatus: {result['status']}")
    click.echo(f"Documents processed: {result['documents_processed']}")
    click.echo(f"Chunks created: {result['chunks_created']}")

    if result["errors"]:
        click.echo("\nErrors:")
        for error in result["errors"]:
            click.echo(f"  - {error}")


@click.command("status")
@click.option("--prefix", default="rak", help="Redis key prefix")
@click.pass_context
def status_cmd(ctx: click.Context, prefix: str) -> None:
    """Show pipeline status.

    Displays count of stored chunks.
    """
    redis_url = ctx.obj.redis_url
    vs = get_vector_store(redis_url, prefix)

    count = run_async(vs.count())
    click.echo(f"Chunks stored: {count}")


@click.command("clear")
@click.option("--prefix", default="rak", help="Redis key prefix")
@click.option("--yes", is_flag=True, help="Skip confirmation")
@click.pass_context
def clear_cmd(ctx: click.Context, prefix: str, yes: bool) -> None:
    """Clear all pipeline data.

    Removes all stored chunks from Redis.
    """
    if not yes and not click.confirm("Clear all pipeline data?"):
        click.echo("Cancelled.")
        return

    redis_url = ctx.obj.redis_url
    vs = get_vector_store(redis_url, prefix)

    run_async(vs.clear())
    click.echo("Pipeline data cleared.")


@click.command("prepare")
@click.argument("source", type=click.Path(exists=True, path_type=Path))
@click.option(
    "-p",
    "--pattern",
    "patterns",
    multiple=True,
    default=["*.md"],
    help="File patterns to match (can be repeated)",
)
@click.option("--chunk-size", type=int, default=1000, help="Chunk size in characters")
@click.option("--chunk-overlap", type=int, default=200, help="Chunk overlap in characters")
@click.option(
    "--artifacts-dir",
    type=click.Path(path_type=Path),
    default=None,
    help="Directory for artifacts (default: ./artifacts)",
)
def prepare_cmd(
    source: Path,
    patterns: tuple[str, ...],
    chunk_size: int,
    chunk_overlap: int,
    artifacts_dir: Path | None,
) -> None:
    """Prepare documents for ingestion (Stage 1).

    Scrapes documents, parses frontmatter, chunks, and saves to artifacts folder.
    """
    artifacts_path = artifacts_dir or Path("./artifacts")
    pattern_list = list(patterns) if patterns else ["*.md"]

    sources = [
        SourceConfig(
            name="source",
            path_pattern=p,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )
        for p in pattern_list
    ]

    config = PipelineConfig(artifacts_dir=artifacts_path, sources=sources)
    orchestrator = PipelineOrchestrator(config=config, base_path=source)

    click.echo(f"Preparing documents from {source}...")
    batch_id = orchestrator.prepare()
    click.echo(f"Prepared batch: {batch_id}")


@click.command("ingest")
@click.argument("batch_id")
@click.option(
    "--artifacts-dir",
    type=click.Path(path_type=Path),
    default=None,
    help="Directory for artifacts (default: ./artifacts)",
)
@click.option(
    "--model",
    "embedding_model",
    default="text-embedding-3-small",
    help="Embedding model",
)
@click.option("--prefix", default="rak", help="Redis key prefix")
@click.pass_context
def ingest_cmd(
    ctx: click.Context,
    batch_id: str,
    artifacts_dir: Path | None,
    embedding_model: str,
    prefix: str,
) -> None:
    """Ingest a prepared batch (Stage 2).

    Loads documents from artifacts, generates embeddings, stores in Redis.
    """
    redis_url = ctx.obj.redis_url
    artifacts_path = artifacts_dir or Path("./artifacts")

    client = redis_lib.from_url(redis_url)  # type: ignore[no-untyped-call]
    vectorizer = Vectorizer(model=embedding_model)
    vector_store = VectorStore(client, prefix=prefix)

    config = PipelineConfig(artifacts_dir=artifacts_path, sources=[])
    orchestrator = PipelineOrchestrator(
        config=config,
        base_path=Path("."),
        vectorizer=vectorizer,
        vector_store=vector_store,
    )

    click.echo(f"Ingesting batch {batch_id}...")
    manifest = orchestrator.ingest(batch_id)
    click.echo(
        f"Ingested: {manifest.documents_ingested} documents, {manifest.chunks_embedded} chunks"
    )


@click.command("batches")
@click.option(
    "--artifacts-dir",
    type=click.Path(path_type=Path),
    default=None,
    help="Directory for artifacts (default: ./artifacts)",
)
def batches_cmd(artifacts_dir: Path | None) -> None:
    """List available batches.

    Shows all prepared batches in the artifacts directory.
    """
    artifacts_path = artifacts_dir or Path("./artifacts")
    storage = ArtifactStorage(artifacts_dir=artifacts_path)

    batches = storage.list_batches()
    if not batches:
        click.echo("No batches found.")
        return

    click.echo("Available batches:")
    for batch_id in batches:
        manifest = storage.load_batch_manifest(batch_id)
        if manifest:
            click.echo(
                f"  {batch_id}: {manifest.documents_prepared} docs, {manifest.chunks_created} chunks"
            )
        else:
            click.echo(f"  {batch_id}: (no manifest)")


@click.command("add")
@click.argument("file", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--artifacts-dir",
    type=click.Path(path_type=Path),
    default=None,
    help="Directory for artifacts (default: ./artifacts)",
)
def add_cmd(file: Path, artifacts_dir: Path | None) -> None:
    """Add a document to the custom docs folder.

    Copies the document to the custom_docs folder for ingestion.
    """
    artifacts_path = artifacts_dir or Path("./artifacts")
    storage = ArtifactStorage(artifacts_dir=artifacts_path)

    custom_dir = storage.get_custom_docs_dir()
    dest = custom_dir / file.name
    shutil.copy(file, dest)
    click.echo(f"Added {file.name} to custom docs.")
