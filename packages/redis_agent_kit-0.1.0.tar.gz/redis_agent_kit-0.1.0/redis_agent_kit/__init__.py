"""Redis Agent Kit - Reusable infrastructure for building AI agents with Redis."""

__version__ = "0.1.0"

# Core (AgentKit handles background processing internally)
# Pipelines (import submodule for namespaced access)
# Tools
from redis_agent_kit import pipelines, tools

# Agent and Knowledge
from redis_agent_kit.agent import Agent, AgentConfig

# API Auth (optional – requires the [api] extra for FastAPI)
try:
    from redis_agent_kit.api.auth import (
        create_api_key_dependency,
        create_optional_api_key_dependency,
    )
except ImportError:  # pragma: no cover - exercised only without [api]
    create_api_key_dependency = None  # type: ignore[assignment]
    create_optional_api_key_dependency = None  # type: ignore[assignment]

# Attachments
from redis_agent_kit.attachments import (
    AttachmentStore,
    InlineAttachmentStore,
    RedisAttachmentStore,
    get_attachment_data,
)

# Config
from redis_agent_kit.config import (
    MemorySettings,
    ModelSettings,
    Settings,
    SideEffectSettings,
    TaskSettings,
    get_settings,
    reset_settings,
    set_settings,
)
from redis_agent_kit.core import (
    AgentCallable,
    AgentKit,
    ConcurrencyConfig,
    ContextAgentCallable,
    RetryConfig,
    create_task_with_session,
)

# Emitter
from redis_agent_kit.emitter import TaskEmitter

# Keys
from redis_agent_kit.keys import RedisKeys
from redis_agent_kit.knowledge import KnowledgeStore

# Memory
from redis_agent_kit.memory import Memory, MemorySearchResults, MessageList, NoOpMemory

# Task Middleware
# Pipeline Middleware
from redis_agent_kit.middleware import (
    EmitterMiddleware,
    MemoryMiddleware,
    MiddlewareChain,
    PipelineContext,
    PipelineLoggingMiddleware,
    PipelineMiddleware,
    PipelineMiddlewareChain,
    PipelineTimingMiddleware,
    PipelineValidationMiddleware,
    RAGMiddleware,
    ResultMiddleware,
    TaskContext,
    TaskMiddleware,
)

# Models
from redis_agent_kit.models import (
    AgentCard,
    AgentManifest,
    AgentMetadata,
    AgentStatus,
    Attachment,
    AttachmentType,
    Caller,
    CallerType,
    Capability,
    InputRequest,
    Message,
    Skill,
    TaskState,
    TaskStatus,
    TaskUpdate,
)

# Side Effects (reentrant tasks)
from redis_agent_kit.side_effects import (
    DEFAULT_KEY_POLICY,
    FUNCTION_NAME,
    FUNCTION_SOURCE,
    INPUTS,
    clear_side_effects,
    side_effect,
)

# Streaming
from redis_agent_kit.streaming import ChannelScope, StreamConfig

# Managers
from redis_agent_kit.task_manager import TaskManager
from redis_agent_kit.thread_manager import ThreadManager
from redis_agent_kit.tools import (
    Tool,
    ToolCapability,
    ToolDefinition,
    ToolManager,
    ToolMetadata,
    ToolProvider,
)

# Vectorizer
from redis_agent_kit.vectorizer import LiteLLMVectorizerAdapter, Vectorizer

__all__ = [
    # Core
    "AgentKit",
    "AgentCallable",
    "ContextAgentCallable",
    "create_task_with_session",
    # Task configuration helpers
    "RetryConfig",
    "ConcurrencyConfig",
    # Config
    "Settings",
    "MemorySettings",
    "TaskSettings",
    "ModelSettings",
    "SideEffectSettings",
    "get_settings",
    "set_settings",
    "reset_settings",
    # Side Effects (reentrant tasks)
    "side_effect",
    "clear_side_effects",
    "FUNCTION_SOURCE",
    "FUNCTION_NAME",
    "INPUTS",
    "DEFAULT_KEY_POLICY",
    # Memory
    "Memory",
    "MessageList",
    "MemorySearchResults",
    "NoOpMemory",
    # Managers
    "TaskManager",
    "ThreadManager",
    # Emitter
    "TaskEmitter",
    # Task Middleware
    "TaskMiddleware",
    "TaskContext",
    "MiddlewareChain",
    "EmitterMiddleware",
    "RAGMiddleware",
    "MemoryMiddleware",
    "ResultMiddleware",
    # Pipeline Middleware
    "PipelineMiddleware",
    "PipelineContext",
    "PipelineMiddlewareChain",
    "PipelineLoggingMiddleware",
    "PipelineTimingMiddleware",
    "PipelineValidationMiddleware",
    # Models
    "AgentCard",
    "AgentManifest",
    "AgentMetadata",
    "AgentStatus",
    "Attachment",
    "AttachmentType",
    "Caller",
    "CallerType",
    "Capability",
    "InputRequest",
    "Message",
    "Skill",
    "TaskState",
    "TaskStatus",
    # Attachment Storage
    "AttachmentStore",
    "RedisAttachmentStore",
    "InlineAttachmentStore",
    "get_attachment_data",
    "TaskUpdate",
    # Keys
    "RedisKeys",
    # API Auth
    "create_api_key_dependency",
    "create_optional_api_key_dependency",
    # Pipelines submodule
    "pipelines",
    # Agent and Knowledge
    "Agent",
    "AgentConfig",
    "KnowledgeStore",
    # Vectorizer
    "Vectorizer",
    "LiteLLMVectorizerAdapter",
    # Tools
    "tools",
    "Tool",
    "ToolCapability",
    "ToolDefinition",
    "ToolManager",
    "ToolMetadata",
    "ToolProvider",
    # Streaming
    "StreamConfig",
    "ChannelScope",
]
