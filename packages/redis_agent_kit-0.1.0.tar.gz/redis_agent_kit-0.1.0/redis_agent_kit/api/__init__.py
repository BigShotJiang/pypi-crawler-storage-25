"""Redis Agent Kit REST API.

The REST API requires the ``[api]`` extra (FastAPI + Uvicorn). ``create_app``
is loaded lazily so that importing :mod:`redis_agent_kit.api` on a bare
install does not eagerly fail when FastAPI is not installed.
"""

from typing import TYPE_CHECKING, Any

__all__ = ["create_app"]

if TYPE_CHECKING:  # pragma: no cover
    from redis_agent_kit.api.app import create_app


def __getattr__(name: str) -> Any:
    if name == "create_app":
        from redis_agent_kit.api.app import create_app as _create_app

        return _create_app
    raise AttributeError(f"module 'redis_agent_kit.api' has no attribute {name!r}")
