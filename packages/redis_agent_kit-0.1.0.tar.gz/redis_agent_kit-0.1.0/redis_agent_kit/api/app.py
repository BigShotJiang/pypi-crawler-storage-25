"""Redis Agent Kit REST API application."""

from __future__ import annotations

from typing import Any

from fastapi import Depends, FastAPI

from redis_agent_kit import __version__
from redis_agent_kit.api.auth import create_optional_api_key_dependency
from redis_agent_kit.api.pipelines import router as pipelines_router
from redis_agent_kit.api.tasks import router as tasks_router
from redis_agent_kit.api.v1 import router as v1_router
from redis_agent_kit.config import get_settings
from redis_agent_kit.models import AgentCard, AgentManifest
from redis_agent_kit.protocols.a2a import create_a2a_router
from redis_agent_kit.protocols.acp import create_acp_router
from redis_agent_kit.streaming import StreamConfig


def create_app(
    redis_url: str | None = None,
    prefix: str = "rak",
    queue_name: str | None = None,
    enable_a2a: bool = False,
    enable_acp: bool = False,
    enable_sse: bool = False,
    enable_streaming: bool = False,
    stream_config: StreamConfig | None = None,
    agent_card: AgentCard | None = None,
    agent_manifest: AgentManifest | None = None,
    kit: Any = None,
    api_keys: list[str] | None = None,
    **kwargs: Any,
) -> FastAPI:
    """Create and configure the FastAPI application.

    Args:
        redis_url: Redis connection URL (defaults to settings).
        prefix: Redis key prefix.
        queue_name: Background worker queue name (defaults to settings).
        enable_a2a: Enable A2A protocol endpoints.
        enable_acp: Enable ACP protocol endpoints.
        enable_sse: Enable Server-Sent Events streaming endpoint for tasks.
            Deprecated – use ``stream_config`` instead.
        enable_streaming: Enable lightweight Pub/Sub token streaming.
            Deprecated – use ``stream_config`` instead.
        stream_config: Structured streaming configuration. When provided,
            ``enable_sse`` and ``enable_streaming`` are ignored.
        agent_card: Agent card for A2A discovery (required if enable_a2a=True).
        agent_manifest: Agent manifest for ACP discovery (required if enable_acp=True).
        kit: AgentKit instance for protocol handlers (required if protocols enabled).
        api_keys: Optional list of valid API keys. If provided, all endpoints
            (except /, /health, /docs) require authentication via X-API-Key
            header or Authorization: Bearer token.
        **kwargs: Additional arguments passed to FastAPI constructor.
            Common options include:
            - title: API title (default: "Redis Agent Kit API")
            - description: API description
            - version: API version (default: package version)
            - docs_url: URL for Swagger docs (default: "/docs")
            - redoc_url: URL for ReDoc (default: "/redoc")
            - openapi_url: URL for OpenAPI schema (default: "/openapi.json")
            - middleware: List of middleware to add
            - dependencies: Global dependencies
            - lifespan: Lifespan context manager

    Returns:
        Configured FastAPI application.

    Raises:
        ValueError: If protocol is enabled but required config is missing.
    """
    # Validate protocol configuration
    if enable_a2a and agent_card is None:
        raise ValueError("agent_card is required when A2A is enabled")
    if enable_acp and agent_manifest is None:
        raise ValueError("agent_manifest is required when ACP is enabled")
    if (enable_a2a or enable_acp) and kit is None:
        raise ValueError("kit is required when protocols are enabled")

    settings = get_settings()
    resolved_redis_url = redis_url or settings.redis_url
    resolved_queue_name = queue_name or settings.task.queue_name

    # Create API key dependency if keys provided
    auth_dependency = create_optional_api_key_dependency(api_keys)

    # Set defaults that can be overridden by kwargs
    fastapi_kwargs: dict[str, Any] = {
        "title": "Redis Agent Kit API",
        "description": "REST API for managing agent tasks and data pipelines",
        "version": __version__,
    }
    fastapi_kwargs.update(kwargs)

    app = FastAPI(**fastapi_kwargs)

    # Resolve StreamConfig
    if stream_config is not None:
        resolved_stream_config = stream_config
    else:
        resolved_stream_config = StreamConfig.from_booleans(enable_sse, enable_streaming)

    # Store config in app state
    app.state.redis_url = resolved_redis_url
    app.state.prefix = prefix
    app.state.queue_name = resolved_queue_name
    app.state.kit = kit
    app.state.api_keys = api_keys
    app.state.enable_a2a = enable_a2a
    app.state.enable_acp = enable_acp
    app.state.enable_mcp = bool(kwargs.get("enable_mcp", False))
    app.state.default_agent_id = kwargs.get("default_agent_id", "default")
    app.state.stream_config = resolved_stream_config
    app.state.enable_sse = enable_sse
    app.state.enable_streaming = enable_streaming

    # Register routes (public - no auth required)
    @app.get("/")
    async def root() -> dict[str, str]:
        """Get API information."""
        return {
            "name": "Redis Agent Kit API",
            "version": __version__,
            "docs": "/docs",
        }

    @app.get("/health")
    async def health() -> dict[str, str]:
        """Health check endpoint."""
        return {"status": "healthy"}

    # Build dependencies list for protected routers
    router_dependencies = [Depends(auth_dependency)] if auth_dependency else []

    # Register routers (protected if api_keys provided)
    app.include_router(
        tasks_router, prefix="/tasks", tags=["tasks"], dependencies=router_dependencies
    )
    app.include_router(
        pipelines_router,
        prefix="/pipelines",
        tags=["pipelines"],
        dependencies=router_dependencies,
    )
    app.include_router(
        v1_router,
        tags=["v1"],
        dependencies=router_dependencies,
    )

    # Mount A2A router if enabled (protected if api_keys provided)
    if enable_a2a and agent_card is not None and kit is not None:
        a2a_router = create_a2a_router(agent_card=agent_card, kit=kit)
        app.include_router(a2a_router, tags=["A2A"], dependencies=router_dependencies)

    # Mount ACP router if enabled (protected if api_keys provided)
    if enable_acp and agent_manifest is not None and kit is not None:
        acp_router = create_acp_router(agent_manifest=agent_manifest, kit=kit)
        app.include_router(acp_router, tags=["ACP"], dependencies=router_dependencies)

    return app
