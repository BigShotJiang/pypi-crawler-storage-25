"""Attachment storage backends for multi-modal input.

Provides pluggable storage for large attachments (images, audio, video, files).
Small attachments can be stored inline (base64), but large ones need external storage.

Example:
    from redis_agent_kit import AgentKit, RedisAttachmentStore

    store = RedisAttachmentStore(redis_url="redis://localhost:6379")
    kit = AgentKit(redis_url, attachment_store=store)

    # Store attachment
    attachment = await store.store(data=image_bytes, mime_type="image/png")

    # Retrieve attachment
    data = await store.retrieve(attachment.url)
"""

import base64
import uuid
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from redis.asyncio import Redis

from redis_agent_kit.models import Attachment, AttachmentType


def _mime_to_type(mime_type: str) -> AttachmentType:
    """Convert MIME type to AttachmentType."""
    if mime_type.startswith("image/"):
        return AttachmentType.IMAGE
    elif mime_type.startswith("audio/"):
        return AttachmentType.AUDIO
    elif mime_type.startswith("video/"):
        return AttachmentType.VIDEO
    return AttachmentType.FILE


class AttachmentStore(ABC):
    """Abstract base class for attachment storage backends."""

    @abstractmethod
    async def store(
        self,
        data: bytes,
        mime_type: str,
        filename: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Attachment:
        """Store attachment data and return an Attachment with a URL reference.

        Args:
            data: Raw binary data
            mime_type: MIME type (e.g., "image/png")
            filename: Optional original filename
            metadata: Optional metadata dict

        Returns:
            Attachment with url field set to storage location
        """
        pass  # pragma: no cover

    @abstractmethod
    async def retrieve(self, url: str) -> bytes:
        """Retrieve attachment data by URL.

        Args:
            url: Storage URL returned from store()

        Returns:
            Raw binary data

        Raises:
            KeyError: If attachment not found
        """
        pass  # pragma: no cover

    @abstractmethod
    async def delete(self, url: str) -> bool:
        """Delete attachment by URL.

        Args:
            url: Storage URL

        Returns:
            True if deleted, False if not found
        """
        pass  # pragma: no cover


class RedisAttachmentStore(AttachmentStore):
    """Store attachments in Redis.

    Uses Redis strings with a configurable prefix and TTL.
    URLs are in format: redis://attachments:{uuid}
    """

    def __init__(
        self,
        redis_client: "Redis | None" = None,
        redis_url: str | None = None,
        prefix: str = "attachments",
        ttl_seconds: int | None = 86400,  # 24 hours default
    ):
        """Initialize Redis attachment store.

        Args:
            redis_client: Existing Redis client (preferred)
            redis_url: Redis URL (creates new client if redis_client not provided)
            prefix: Key prefix for attachments
            ttl_seconds: TTL for attachments (None for no expiry)
        """
        self._client = redis_client
        self._redis_url = redis_url
        self._prefix = prefix
        self._ttl = ttl_seconds
        self._owns_client = False

    async def _get_client(self) -> "Redis":
        """Get or create Redis client."""
        if self._client is None:
            if self._redis_url is None:
                raise ValueError("Either redis_client or redis_url must be provided")
            import redis.asyncio as redis_lib

            self._client = redis_lib.from_url(self._redis_url)  # type: ignore[no-untyped-call]
            self._owns_client = True
        return self._client

    async def store(
        self,
        data: bytes,
        mime_type: str,
        filename: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Attachment:
        """Store attachment in Redis."""
        client = await self._get_client()
        attachment_id = str(uuid.uuid4())
        key = f"{self._prefix}:{attachment_id}"

        # Store raw bytes
        if self._ttl:
            await client.setex(key, self._ttl, data)
        else:
            await client.set(key, data)

        return Attachment(
            type=_mime_to_type(mime_type),
            mime_type=mime_type,
            url=f"redis://{key}",
            filename=filename,
            size_bytes=len(data),
            metadata=metadata or {},
        )

    async def retrieve(self, url: str) -> bytes:
        """Retrieve attachment from Redis."""
        client = await self._get_client()
        # Parse redis://prefix:uuid -> prefix:uuid
        key = url.replace("redis://", "")
        data = await client.get(key)
        if data is None:
            raise KeyError(f"Attachment not found: {url}")
        return data if isinstance(data, bytes) else data.encode()

    async def delete(self, url: str) -> bool:
        """Delete attachment from Redis."""
        client = await self._get_client()
        key = url.replace("redis://", "")
        return bool(await client.delete(key))


class InlineAttachmentStore(AttachmentStore):
    """Store attachments inline as base64 (no external storage).

    Useful for small attachments that can be passed directly through the task context.
    The 'url' field is set to 'inline' and data is stored in the Attachment.data field.
    """

    async def store(
        self,
        data: bytes,
        mime_type: str,
        filename: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Attachment:
        """Store attachment inline as base64."""
        return Attachment(
            type=_mime_to_type(mime_type),
            mime_type=mime_type,
            data=base64.b64encode(data).decode("utf-8"),
            url=None,  # Inline - no external URL
            filename=filename,
            size_bytes=len(data),
            metadata=metadata or {},
        )

    async def retrieve(self, url: str) -> bytes:
        """Not applicable for inline storage - data is in Attachment.data."""
        raise NotImplementedError("Inline attachments have data in Attachment.data field")

    async def delete(self, url: str) -> bool:
        """Not applicable for inline storage."""
        return False  # Nothing to delete


def get_attachment_data(attachment: Attachment) -> bytes:
    """Helper to get raw bytes from an Attachment, regardless of storage type.

    Args:
        attachment: Attachment object (may have inline data or URL)

    Returns:
        Raw binary data

    Note:
        For URL-based attachments, you need to use the appropriate store's retrieve().
        This helper only works for inline (base64) attachments.
    """
    if attachment.data:
        return base64.b64decode(attachment.data)
    raise ValueError(f"Attachment has no inline data. Use store.retrieve('{attachment.url}')")
