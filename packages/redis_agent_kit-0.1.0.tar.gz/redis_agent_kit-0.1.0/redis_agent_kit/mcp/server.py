"""MCP server implementation using FastMCP."""

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import redis.asyncio as redis_lib
from docket import Docket
from fastmcp import FastMCP

from redis_agent_kit import TaskManager
from redis_agent_kit.config import get_settings
from redis_agent_kit.models import TaskStatus
from redis_agent_kit.pipelines import VectorStore
from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
from redis_agent_kit.pipelines.models import PipelineConfig
from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator


@dataclass
class _CompatTool:
    """Compatibility wrapper exposing `.fn` for legacy tests/callers."""

    fn: Any


class _CompatToolManager:
    """Compatibility container exposing `_tools` map for legacy access."""

    def __init__(self) -> None:
        self._tools: dict[str, _CompatTool] = {}


def create_server(
    redis_url: str | None = None,
    prefix: str = "rak",
    queue_name: str | None = None,
    **kwargs: Any,
) -> FastMCP:
    """Create and configure the MCP server.

    Args:
        redis_url: Redis connection URL (defaults to settings).
        prefix: Redis key prefix.
        queue_name: Background worker queue name (defaults to settings).
        **kwargs: Additional arguments passed to FastMCP constructor.
            Common options include:
            - name: Server name (default: "redis-agent-kit")
            - instructions: Server instructions
            - dependencies: List of dependencies
            - lifespan: Lifespan context manager

    Returns:
        Configured FastMCP server.
    """
    settings = get_settings()
    resolved_redis_url = redis_url or settings.redis_url
    resolved_queue_name = queue_name or settings.task.queue_name

    # Set defaults that can be overridden by kwargs
    fastmcp_kwargs = {
        "name": "redis-agent-kit",
        "instructions": "Redis Agent Kit MCP server for managing agent tasks and data pipelines.",
    }
    fastmcp_kwargs.update(kwargs)

    server = FastMCP(**fastmcp_kwargs)  # type: ignore[arg-type]

    # Store config on server for tools to access
    # FastMCP doesn't declare these attrs; use cast to avoid attr-defined errors
    _server: Any = server
    _server._redis_url = resolved_redis_url
    _server._prefix = prefix
    _server._queue_name = resolved_queue_name

    # FastMCP 3.x no longer exposes `_tool_manager._tools`; keep a compatibility
    # view so existing integrations/tests can access registered callables.
    compat_manager = _CompatToolManager()
    _server._tool_manager = compat_manager

    def _register_tool(fn: Any) -> Any:
        compat_manager._tools[fn.__name__] = _CompatTool(fn=fn)
        return fn

    # Register task tools
    @server.tool()
    @_register_tool
    async def list_tasks(
        status: str | None = None,
        session_id: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        """List all tasks with optional filtering.

        Args:
            status: Filter by status (queued, in_progress, done, failed, cancelled).
            session_id: Filter by session ID.
            limit: Maximum number of tasks to return.

        Returns:
            Dictionary with tasks list and total count.
        """
        client = redis_lib.from_url(_server._redis_url, decode_responses=True)  # type: ignore[no-untyped-call]
        tm = TaskManager(client, prefix=_server._prefix)
        status_filter = TaskStatus(status) if status else None
        tasks = await tm.list_tasks(status=status_filter, session_id=session_id)
        tasks = tasks[:limit]  # Apply limit after fetching

        return {
            "tasks": [task.model_dump() for task in tasks],
            "total": len(tasks),
        }

    @server.tool()
    @_register_tool
    async def get_task(task_id: str) -> dict[str, Any]:
        """Get task details by ID.

        Args:
            task_id: The task ID to retrieve.

        Returns:
            Task details or error message.
        """
        client = redis_lib.from_url(_server._redis_url, decode_responses=True)  # type: ignore[no-untyped-call]
        tm = TaskManager(client, prefix=_server._prefix)
        task = await tm.get_task(task_id)

        if not task:
            return {"error": f"Task {task_id} not found"}

        return task.model_dump()

    @server.tool()
    @_register_tool
    async def delete_task(task_id: str) -> dict[str, Any]:
        """Delete a task by ID.

        Args:
            task_id: The task ID to delete.

        Returns:
            Success status or error message.
        """
        client = redis_lib.from_url(_server._redis_url, decode_responses=True)  # type: ignore[no-untyped-call]
        tm = TaskManager(client, prefix=_server._prefix)
        task = await tm.get_task(task_id)

        if not task:
            return {"error": f"Task {task_id} not found", "deleted": False}

        await tm.delete_task(task_id)
        return {"deleted": True, "task_id": task_id}

    @server.tool()
    @_register_tool
    async def pipeline_status() -> dict[str, Any]:
        """Get pipeline status including chunk count.

        Returns:
            Dictionary with chunk count and status info.
        """
        client = redis_lib.from_url(_server._redis_url, decode_responses=True)  # type: ignore[no-untyped-call]
        vs = VectorStore(client, prefix=_server._prefix)
        count = await vs.count()

        return {"chunks": count, "status": "ready"}

    @server.tool()
    @_register_tool
    async def pipeline_clear() -> dict[str, Any]:
        """Clear all pipeline data.

        Returns:
            Success status.
        """
        client = redis_lib.from_url(_server._redis_url, decode_responses=True)  # type: ignore[no-untyped-call]
        vs = VectorStore(client, prefix=_server._prefix)
        await vs.clear()

        return {"cleared": True}

    @server.tool()
    @_register_tool
    async def pipeline_search(query: str, limit: int = 10) -> dict[str, Any]:
        """Search the pipeline for relevant chunks using semantic similarity.

        Args:
            query: Search query text.
            limit: Maximum number of results to return.

        Returns:
            Dictionary with search results.
        """
        from redis_agent_kit.knowledge import KnowledgeStore

        client = redis_lib.from_url(_server._redis_url, decode_responses=True)  # type: ignore[no-untyped-call]
        ks = KnowledgeStore(client, prefix=_server._prefix)

        results = await ks.search(query, limit=limit)

        return {
            "query": query,
            "limit": limit,
            "results": [
                {
                    "chunk_id": r.chunk_id,
                    "doc_id": r.doc_id,
                    "content": r.content,
                    "score": r.score,
                    "metadata": r.metadata,
                }
                for r in results
            ],
            "count": len(results),
        }

    @server.tool()
    @_register_tool
    async def pipeline_prepare(source_path: str) -> dict[str, Any]:
        """Submit a prepare stage task for the two-stage pipeline.

        Args:
            source_path: Path to the source documents directory.

        Returns:
            Dictionary with task_id for tracking.
        """
        config = PipelineConfig(sources=[])
        async with Docket(url=_server._redis_url, name=_server._queue_name) as docket:
            orchestrator = PipelineOrchestrator(
                config=config,
                base_path=Path(source_path),
                docket=docket,
            )
            task_id = await orchestrator.submit_prepare()

        return {"task_id": task_id}

    @server.tool()
    @_register_tool
    async def pipeline_ingest(batch_id: str) -> dict[str, Any]:
        """Submit an ingest stage task for the two-stage pipeline.

        Args:
            batch_id: The batch ID to ingest.

        Returns:
            Dictionary with task_id for tracking.
        """
        artifacts_dir = Path(getattr(_server, "_artifacts_dir", "artifacts"))
        config = PipelineConfig(sources=[])
        async with Docket(url=_server._redis_url, name=_server._queue_name) as docket:
            orchestrator = PipelineOrchestrator(
                config=config,
                base_path=artifacts_dir,
                docket=docket,
            )
            task_id = await orchestrator.submit_ingest(batch_id)

        return {"task_id": task_id}

    @server.tool()
    @_register_tool
    async def pipeline_run(source_path: str) -> dict[str, Any]:
        """Submit a full pipeline run (prepare + ingest).

        Args:
            source_path: Path to the source documents directory.

        Returns:
            Dictionary with task_id for tracking.
        """
        config = PipelineConfig(sources=[])
        async with Docket(url=_server._redis_url, name=_server._queue_name) as docket:
            orchestrator = PipelineOrchestrator(
                config=config,
                base_path=Path(source_path),
                docket=docket,
            )
            task_id = await orchestrator.submit_full()

        return {"task_id": task_id}

    @server.tool()
    @_register_tool
    async def pipeline_add_document(content: str, filename: str) -> dict[str, Any]:
        """Submit a document for ingestion.

        Args:
            content: The document content (Markdown with optional YAML frontmatter).
            filename: The filename for the document.

        Returns:
            Dictionary with task_id for tracking.
        """
        artifacts_dir = Path(getattr(_server, "_artifacts_dir", "artifacts"))
        config = PipelineConfig(sources=[])
        async with Docket(url=_server._redis_url, name=_server._queue_name) as docket:
            orchestrator = PipelineOrchestrator(
                config=config,
                base_path=artifacts_dir,
                docket=docket,
            )
            task_id = await orchestrator.submit_document(content, filename)

        return {"task_id": task_id}

    @server.tool()
    @_register_tool
    async def pipeline_batches() -> dict[str, Any]:
        """List available batches.

        Returns:
            Dictionary with list of batch IDs.
        """
        artifacts_dir = Path(getattr(_server, "_artifacts_dir", "artifacts"))
        storage = ArtifactStorage(artifacts_dir)
        batches = storage.list_batches()

        return {"batches": batches}

    @server.tool()
    @_register_tool
    async def pipeline_delete_batch(batch_id: str) -> dict[str, Any]:
        """Delete a batch.

        Args:
            batch_id: The batch ID to delete.

        Returns:
            Dictionary with deletion status.
        """
        artifacts_dir = Path(getattr(_server, "_artifacts_dir", "artifacts"))
        storage = ArtifactStorage(artifacts_dir)
        storage.delete_batch(batch_id)

        return {"deleted": True, "batch_id": batch_id}

    return server
