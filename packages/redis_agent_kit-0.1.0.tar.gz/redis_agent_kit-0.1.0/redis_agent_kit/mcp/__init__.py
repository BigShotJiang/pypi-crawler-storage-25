"""Redis Agent Kit MCP Server."""

from redis_agent_kit.mcp.server import create_server

__all__ = ["create_server"]
