"""Base class for protocol adapters."""

from abc import ABC, abstractmethod
from typing import Any

from redis_agent_kit.models import Message, TaskState, TaskStatus


class ProtocolAdapter(ABC):
    """Abstract base class for protocol adapters.

    Protocol adapters translate between RAK primitives (TaskState, Message, Thread)
    and protocol-specific types (A2A Task, ACP Run, etc.).

    Subclasses must implement:
    - to_protocol_task: Convert RAK TaskState to protocol task
    - from_protocol_message: Convert protocol message to RAK Message
    - to_protocol_message: Convert RAK Message to protocol message
    - get_discovery_document: Return protocol discovery document

    Example:
        ```python
        class A2AAdapter(ProtocolAdapter):
            def to_protocol_task(self, task: TaskState) -> A2ATask:
                return A2ATask(
                    id=task.task_id,
                    status=TaskState(state=self.map_status_to_protocol(
                        task.status, A2A_STATUS_MAP
                    )),
                )
        ```
    """

    # Default status mapping (RAK status value -> protocol status)
    _DEFAULT_STATUS_MAP: dict[TaskStatus, str] = {
        TaskStatus.QUEUED: "queued",
        TaskStatus.IN_PROGRESS: "in_progress",
        TaskStatus.AWAITING_INPUT: "awaiting_input",
        TaskStatus.DONE: "done",
        TaskStatus.FAILED: "failed",
        TaskStatus.CANCELLED: "cancelled",
    }

    # Reverse mapping (protocol status -> RAK TaskStatus)
    _DEFAULT_REVERSE_STATUS_MAP: dict[str, TaskStatus] = {
        v: k for k, v in _DEFAULT_STATUS_MAP.items()
    }

    @abstractmethod
    def to_protocol_task(self, task: TaskState) -> Any:
        """Convert RAK TaskState to protocol-specific task.

        Args:
            task: The RAK TaskState to convert.

        Returns:
            Protocol-specific task representation.
        """
        pass  # pragma: no cover

    @abstractmethod
    def from_protocol_message(self, message: Any) -> Message:
        """Convert protocol-specific message to RAK Message.

        Args:
            message: Protocol-specific message.

        Returns:
            RAK Message.
        """
        pass  # pragma: no cover

    @abstractmethod
    def to_protocol_message(self, message: Message) -> Any:
        """Convert RAK Message to protocol-specific message.

        Args:
            message: RAK Message to convert.

        Returns:
            Protocol-specific message representation.
        """
        pass  # pragma: no cover

    @abstractmethod
    def get_discovery_document(self) -> dict[str, Any]:
        """Return the protocol's discovery document.

        For A2A, this is the Agent Card served at /.well-known/agent.json.
        For ACP, this is the Agent Manifest served at /agents.

        Returns:
            Dictionary representing the discovery document.
        """
        pass  # pragma: no cover

    def map_status_to_protocol(
        self,
        status: TaskStatus,
        status_map: dict[TaskStatus, str] | None = None,
    ) -> str:
        """Map RAK TaskStatus to protocol-specific status string.

        Args:
            status: RAK TaskStatus to map.
            status_map: Optional custom mapping. Uses default if not provided.

        Returns:
            Protocol-specific status string.
        """
        mapping = status_map or self._DEFAULT_STATUS_MAP
        return mapping.get(status, status.value)

    def map_status_from_protocol(
        self,
        protocol_status: str,
        status_map: dict[str, TaskStatus] | None = None,
    ) -> TaskStatus:
        """Map protocol-specific status string to RAK TaskStatus.

        Args:
            protocol_status: Protocol-specific status string.
            status_map: Optional custom mapping. Uses default if not provided.

        Returns:
            RAK TaskStatus.

        Raises:
            ValueError: If the protocol status is not recognized.
        """
        mapping = status_map or self._DEFAULT_REVERSE_STATUS_MAP
        if protocol_status not in mapping:
            raise ValueError(f"Unknown protocol status: {protocol_status}")
        return mapping[protocol_status]
