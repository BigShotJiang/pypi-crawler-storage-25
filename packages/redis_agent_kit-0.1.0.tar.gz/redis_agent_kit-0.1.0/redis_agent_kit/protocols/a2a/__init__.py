"""A2A (Agent-to-Agent) protocol adapter.

This module provides an adapter for the A2A protocol, which enables
agent-to-agent communication using JSON-RPC over HTTP.

See: https://a2a-protocol.org/
"""

from redis_agent_kit.protocols.a2a.adapter import A2AAdapter
from redis_agent_kit.protocols.a2a.models import (
    A2AArtifact,
    A2AMessage,
    A2APart,
    A2ATask,
    A2ATaskState,
    A2ATaskStatus,
    DataPart,
    FilePart,
    TextPart,
)
from redis_agent_kit.protocols.a2a.router import create_a2a_router

__all__ = [
    "A2AAdapter",
    "A2AArtifact",
    "A2AMessage",
    "A2APart",
    "A2ATask",
    "A2ATaskState",
    "A2ATaskStatus",
    "DataPart",
    "FilePart",
    "TextPart",
    "create_a2a_router",
]
