"""Side effect management for reentrant task execution.

The `side_effect` decorator makes functions idempotent by caching their
completion status (and optionally results) in Redis. This is essential for
reentrant task handlers that may re-run from the beginning when resuming
from AWAITING_INPUT status.

Example:
    @side_effect(store_result=True)
    async def call_llm(query: str) -> str:
        return await expensive_llm_call(query)

    async def my_handler(ctx):
        # First run: calls LLM, caches result
        # Resume: returns cached result immediately
        response = await call_llm(ctx.message)

        if ctx.task.input_response:
            return {"response": response}
        else:
            await ctx.kit.task_manager.request_input(...)
            return None
"""

from __future__ import annotations

import functools
import hashlib
import inspect
import json
import logging
from collections.abc import Awaitable, Callable
from datetime import timedelta
from typing import Any, TypeVar, cast, overload

from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)

# Key policy flags - can be combined with bitwise OR
FUNCTION_SOURCE = 1  # Include function source code hash
FUNCTION_NAME = 2  # Include function name
INPUTS = 4  # Include function inputs (args/kwargs)

# Default key policy
DEFAULT_KEY_POLICY = FUNCTION_SOURCE | FUNCTION_NAME | INPUTS

# Sentinel value to distinguish between "not specified" and "explicitly None"
_UNSPECIFIED = object()

# Type variable for preserving function signature
F = TypeVar("F", bound=Callable[..., Awaitable[Any]])


class SideEffectSettings(BaseSettings):
    """Configuration for side effect behavior."""

    model_config = SettingsConfigDict(env_prefix="RAK_SIDE_EFFECT_")

    # Default TTL for side effects (None = persist until manually cleared)
    default_ttl_hours: float | None = 1.0

    # Environment variable to trigger clearing of side effects
    # Examples: "all", "my_function", "my_function:*", "pattern:*"
    clear_pattern: str | None = None

    # Redis key prefix for side effects
    key_prefix: str = "rak:side_effect"


def _stable_hash(text: str) -> str:
    """Generate a stable hash for cache keys."""
    return hashlib.sha256(text.encode()).hexdigest()[:16]


@overload
def side_effect(func: F) -> F: ...


@overload
def side_effect(
    func: None = None,
    *,
    key: str | Callable[..., str] | None = None,
    key_policy: int = DEFAULT_KEY_POLICY,
    ttl: timedelta | None | object = _UNSPECIFIED,
    store_result: bool = False,
    redis_client: Any = None,
    settings: SideEffectSettings | None = None,
) -> Callable[[F], F]: ...


def side_effect(
    func: F | None = None,
    *,
    key: str | Callable[..., str] | None = None,
    key_policy: int = DEFAULT_KEY_POLICY,
    ttl: timedelta | None | object = _UNSPECIFIED,
    store_result: bool = False,
    redis_client: Any = None,
    settings: SideEffectSettings | None = None,
) -> F | Callable[[F], F]:
    """Decorator for reentrant task execution with automatic key generation.

    Ensures that decorated functions only execute once per unique key,
    making task execution idempotent and safe for retries.

    Args:
        key: Manual key (string or callable). If callable, receives (func, *args, **kwargs).
        key_policy: Flags for automatic key generation (FUNCTION_SOURCE | FUNCTION_NAME | INPUTS).
        ttl: Time-to-live for the cache. Default uses settings, None = persist forever.
        store_result: If True, cache the return value for reuse.
        redis_client: Redis client to use. If None, uses the global client.
        settings: SideEffectSettings instance. If None, creates from environment.

    Examples:
        # Auto key generation (default)
        @side_effect
        async def expensive_operation(user_id: str):
            return await call_api(user_id)

        # Cache results for reuse
        @side_effect(store_result=True)
        async def get_llm_response(query: str):
            return await llm.invoke(query)

        # Custom TTL
        @side_effect(ttl=timedelta(hours=2), store_result=True)
        async def daily_report():
            return generate_report()

        # Manual key
        @side_effect(key="singleton-setup")
        async def one_time_setup():
            return setup_system()
    """
    if key is not None and key_policy != DEFAULT_KEY_POLICY:
        raise ValueError("Cannot specify both 'key' and 'key_policy'")

    decorator = _SideEffectDecorator(
        key=key,
        key_policy=key_policy,
        ttl=ttl,
        store_result=store_result,
        redis_client=redis_client,
        settings=settings or SideEffectSettings(),
    )

    if func is None:
        return cast(Callable[[F], F], decorator)
    else:
        return decorator(func)


class _SideEffectDecorator:
    """Internal decorator implementation."""

    def __init__(
        self,
        key: str | Callable[..., str] | None = None,
        key_policy: int = DEFAULT_KEY_POLICY,
        ttl: timedelta | None | object = _UNSPECIFIED,
        store_result: bool = False,
        redis_client: Any = None,
        settings: SideEffectSettings | None = None,
    ):
        self.key = key
        self.key_policy = key_policy
        self.ttl = ttl
        self.store_result = store_result
        self._redis_client = redis_client
        self.settings = settings or SideEffectSettings()

    def _generate_key(
        self, func: Callable[..., Any], args: tuple[Any, ...], kwargs: dict[str, Any]
    ) -> str:
        """Generate key based on policy or manual key."""
        if self.key is not None:
            if callable(self.key):
                return self.key(func, *args, **kwargs)
            return self.key

        key_parts = []

        if self.key_policy & FUNCTION_SOURCE:
            try:
                source = inspect.getsource(func)
                source_hash = _stable_hash(source)
                key_parts.append(f"src:{source_hash}")
            except (OSError, TypeError):
                key_parts.append("src:unavailable")

        if self.key_policy & FUNCTION_NAME:
            key_parts.append(func.__name__)

        if self.key_policy & INPUTS:
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()
            args_hash = _stable_hash(str(bound_args.arguments))
            key_parts.append(f"inputs:{args_hash}")

        if not key_parts:
            raise ValueError("At least one key policy flag must be set")

        return ":".join(key_parts)

    def _get_ttl_seconds(self) -> int | None:
        """Get TTL in seconds."""
        if self.ttl is _UNSPECIFIED:
            if self.settings.default_ttl_hours is None:
                return None
            return int(self.settings.default_ttl_hours * 3600)
        elif self.ttl is None or self.ttl == timedelta(0):
            return None
        else:
            assert isinstance(self.ttl, timedelta)
            return int(self.ttl.total_seconds())

    async def _set_with_optional_ttl(
        self, redis_client: Any, key: str, value: str, ttl_seconds: int | None
    ) -> None:
        """Set a key with optional TTL."""
        if ttl_seconds is not None:
            await redis_client.set(key, value, ex=ttl_seconds)
        else:
            await redis_client.set(key, value)

    async def _retrieve_cached_result(
        self, redis_client: Any, result_key: str, operation_key: str
    ) -> Any | None:
        """Retrieve and deserialize a cached result."""
        stored = await redis_client.get(result_key)
        if stored:
            try:
                return json.loads(stored)
            except (json.JSONDecodeError, TypeError):
                logger.warning(f"Could not deserialize result: {operation_key}")
        return None

    async def _store_result(
        self,
        redis_client: Any,
        result_key: str,
        result: Any,
        ttl_seconds: int | None,
        operation_key: str,
    ) -> None:
        """Serialize and store a result."""
        try:
            serialized = json.dumps(result)
            await self._set_with_optional_ttl(redis_client, result_key, serialized, ttl_seconds)
        except (TypeError, ValueError) as e:
            logger.warning(f"Could not serialize result: {operation_key} - {e}")

    def __call__(self, func: F) -> F:
        """Apply the decorator to a function."""
        decorator = self

        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Get Redis client
            redis_client = decorator._redis_client
            if redis_client is None:
                raise ValueError(
                    "No redis_client provided. Pass redis_client to @side_effect() "
                    "or use side_effect_with_client()."
                )

            operation_key = decorator._generate_key(func, args, kwargs)
            prefix = decorator.settings.key_prefix
            completion_key = f"{prefix}:completed:{operation_key}"
            result_key = f"{prefix}:result:{operation_key}" if decorator.store_result else None
            ttl_seconds = decorator._get_ttl_seconds()

            # Check for manual clearing
            await decorator._check_and_clear(redis_client, operation_key, func.__name__)

            # Check if already completed
            already_completed = await redis_client.get(completion_key)
            if already_completed:
                logger.debug(f"Side effect already completed, skipping: {operation_key}")
                if decorator.store_result and result_key:
                    return await decorator._retrieve_cached_result(
                        redis_client, result_key, operation_key
                    )
                return None

            # Execute the function
            logger.debug(f"Executing side effect: {operation_key}")
            try:
                result = await func(*args, **kwargs)

                # Mark as completed
                await decorator._set_with_optional_ttl(
                    redis_client, completion_key, "1", ttl_seconds
                )

                # Store result if requested
                if decorator.store_result and result_key and result is not None:
                    await decorator._store_result(
                        redis_client, result_key, result, ttl_seconds, operation_key
                    )

                return result

            except Exception:
                logger.error(f"Side effect failed, not marking complete: {operation_key}")
                raise

        return cast(F, wrapper)

    async def _check_and_clear(self, redis_client: Any, operation_key: str, func_name: str) -> None:
        """Check if clearing was requested via settings."""
        pattern = self.settings.clear_pattern
        if not pattern:
            return

        should_clear = False
        if (
            pattern == "all"
            or pattern == func_name
            or pattern.startswith(f"{func_name}:")
            or pattern.endswith("*")
            and operation_key.startswith(pattern[:-1])
        ):
            should_clear = True

        if should_clear:
            prefix = self.settings.key_prefix
            await redis_client.delete(f"{prefix}:completed:{operation_key}")
            if self.store_result:
                await redis_client.delete(f"{prefix}:result:{operation_key}")
            logger.info(f"Cleared side effect: {operation_key}")


async def clear_side_effects(
    redis_client: Any,
    pattern: str = "all",
    settings: SideEffectSettings | None = None,
) -> int:
    """Clear side effects matching a pattern.

    Args:
        redis_client: Redis client instance.
        pattern: Pattern to match ("all", "function_name", or Redis pattern).
        settings: SideEffectSettings instance.

    Returns:
        Number of keys cleared.
    """
    settings = settings or SideEffectSettings()
    prefix = settings.key_prefix

    if pattern == "all":
        search_pattern = f"{prefix}:*"
    elif ":" not in pattern:
        search_pattern = f"{prefix}:*:{pattern}:*"
    else:
        search_pattern = f"{prefix}:*{pattern}*"

    keys_to_delete = []
    async for key in redis_client.scan_iter(match=search_pattern):
        keys_to_delete.append(key)

    if keys_to_delete:
        deleted = await redis_client.delete(*keys_to_delete)
        logger.info(f"Cleared {deleted} side effect keys matching: {pattern}")
        return int(deleted)
    return 0


__all__ = [
    "side_effect",
    "clear_side_effects",
    "SideEffectSettings",
    "FUNCTION_SOURCE",
    "FUNCTION_NAME",
    "INPUTS",
    "DEFAULT_KEY_POLICY",
]
