"""Data models for Redis Agent Kit."""

import re
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field, field_validator


def _utc_now() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(UTC)


class TaskStatus(StrEnum):
    """Status of a task in its lifecycle."""

    QUEUED = "queued"
    IN_PROGRESS = "in_progress"
    AWAITING_INPUT = "awaiting_input"
    DONE = "done"
    FAILED = "failed"
    CANCELLED = "cancelled"


class InputRequest(BaseModel):
    """A request for user input during task execution.

    Uses standard JSON Schema for defining expected input structure.
    Clients can use this schema with form generators, validators, etc.

    Example:
        ```python
        request = InputRequest(
            prompt="Which database should I configure?",
            json_schema={
                "type": "object",
                "properties": {
                    "database": {
                        "type": "string",
                        "title": "Database",
                        "enum": ["PostgreSQL", "MySQL", "Redis"],
                    },
                    "port": {
                        "type": "integer",
                        "title": "Port",
                        "minimum": 1,
                        "maximum": 65535,
                        "default": 6379,
                    },
                },
                "required": ["database"],
            },
        )
        ```
    """

    prompt: str  # Human-readable question
    json_schema: dict[str, Any] = Field(
        default_factory=lambda: {"type": "object", "properties": {}, "required": []}
    )
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=_utc_now)


class TaskUpdate(BaseModel):
    """A progress update emitted during task execution."""

    timestamp: datetime = Field(default_factory=_utc_now)
    message: str
    update_type: str = "info"  # info, tool_call, reflection, error
    metadata: dict[str, Any] = Field(default_factory=dict)


class CallerType(StrEnum):
    """Type of caller that created a task."""

    HUMAN = "human"  # Human user via UI/CLI/API
    AGENT = "agent"  # Another agent via A2A/ACP


class Caller(BaseModel):
    """Identity of who created a task.

    Tracks whether a task was created by a human or another agent,
    enabling audit trails and agent-to-agent communication patterns.
    """

    type: CallerType = CallerType.HUMAN
    id: str | None = None  # User ID, agent name, or API key identifier
    name: str | None = None  # Human-readable name
    metadata: dict[str, Any] = Field(default_factory=dict)


class TaskState(BaseModel):
    """State of a task (a single unit of agent work)."""

    task_id: str
    session_id: str | None = None  # Memory session ID (optional)
    status: TaskStatus = TaskStatus.QUEUED
    updates: list[TaskUpdate] = Field(default_factory=list)
    result: Any = None
    error_message: str | None = None
    input_request: InputRequest | None = None  # Pending input request
    input_response: dict[str, Any] | None = None  # User's input response
    caller: Caller | None = None  # Who created this task
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=_utc_now)
    updated_at: datetime = Field(default_factory=_utc_now)


class AttachmentType(StrEnum):
    """Type of attachment."""

    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    FILE = "file"


class Attachment(BaseModel):
    """An attachment (image, audio, video, file) for multi-modal input.

    Attachments can be stored inline (base64) for small files or referenced
    by URL/key for larger files stored externally (Redis, S3, filesystem).

    Example:
        ```python
        # Inline image (small, base64)
        attachment = Attachment(
            type=AttachmentType.IMAGE,
            mime_type="image/png",
            data="iVBORw0KGgo...",  # base64 encoded
            filename="screenshot.png",
        )

        # External reference (large file)
        attachment = Attachment(
            type=AttachmentType.AUDIO,
            mime_type="audio/wav",
            url="redis://attachments:task123:audio1",  # or s3://, file://
            filename="recording.wav",
            size_bytes=1024000,
        )
        ```
    """

    type: AttachmentType
    mime_type: str  # e.g., "image/png", "audio/wav"
    filename: str | None = None
    # Inline data (base64 encoded) - for small attachments
    data: str | None = None
    # External reference - for large attachments
    url: str | None = None  # redis://, s3://, file://, https://
    size_bytes: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class Message(BaseModel):
    """A message in a conversation thread."""

    role: str  # user, assistant, system, tool
    content: str
    attachments: list[Attachment] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=_utc_now)


class Thread(BaseModel):
    """A conversation thread containing messages and context."""

    thread_id: str
    messages: list[Message] = Field(default_factory=list)
    context: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=_utc_now)
    updated_at: datetime = Field(default_factory=_utc_now)


# =============================================================================
# A2A Protocol Models (Agent-to-Agent)
# =============================================================================

# RFC 1123 DNS label pattern: lowercase alphanumeric, hyphens allowed (not at start/end)
_DNS_LABEL_PATTERN = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$")


class Skill(BaseModel):
    """A capability/skill the agent can perform (A2A).

    Skills describe what an agent can do and are advertised in the Agent Card.

    Example:
        ```python
        skill = Skill(
            id="code-review",
            name="Code Review",
            description="Reviews code for bugs and style issues",
            tags=["development", "review"],
            examples=["Review this Python code", "Check for security issues"],
        )
        ```
    """

    id: str
    name: str
    description: str
    tags: list[str] = Field(default_factory=list)
    examples: list[str] = Field(default_factory=list)
    input_modes: list[str] = Field(default_factory=lambda: ["text"])
    output_modes: list[str] = Field(default_factory=lambda: ["text"])


class AgentCard(BaseModel):
    """A2A Agent Card for discovery at /.well-known/agent.json.

    The Agent Card describes an agent's capabilities, skills, and how to
    interact with it. It's served at a well-known URL for discovery.

    Example:
        ```python
        card = AgentCard(
            name="My Agent",
            description="A helpful assistant",
            url="https://agent.example.com",
            skills=[
                Skill(id="chat", name="Chat", description="General conversation"),
            ],
            capabilities={"streaming": True},
        )
        ```
    """

    name: str
    description: str
    url: str  # Base URL of the agent
    version: str = "1.0.0"
    protocol_version: str = "1.0"
    skills: list[Skill] = Field(default_factory=list)
    default_input_modes: list[str] = Field(default_factory=lambda: ["text"])
    default_output_modes: list[str] = Field(default_factory=lambda: ["text"])
    capabilities: dict[str, bool] = Field(default_factory=dict)
    authentication: dict[str, Any] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


# =============================================================================
# ACP Protocol Models (Agent Communication Protocol)
# =============================================================================


class Capability(BaseModel):
    """An ACP capability describing what an agent can do.

    Example:
        ```python
        cap = Capability(
            name="Conversational AI",
            description="Handles multi-turn conversations with memory",
        )
        ```
    """

    name: str
    description: str


class AgentMetadata(BaseModel):
    """Static metadata about an agent (ACP).

    Contains information for discovery, classification, and cataloging.
    """

    documentation: str | None = None
    license: str | None = None
    programming_language: str | None = None
    natural_languages: list[str] = Field(default_factory=list)
    framework: str | None = None
    capabilities: list[Capability] = Field(default_factory=list)
    domains: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    author: dict[str, str] | None = None
    links: list[dict[str, str]] = Field(default_factory=list)


class AgentStatus(BaseModel):
    """Real-time dynamic metrics and state for an agent (ACP)."""

    avg_run_tokens: int | None = None
    avg_run_time_seconds: float | None = None
    success_rate: float | None = None  # 0-100 percentage


class AgentManifest(BaseModel):
    """ACP Agent Manifest for discovery at /agents.

    Describes essential properties of an agent including identity,
    capabilities, metadata, and runtime status.

    Example:
        ```python
        manifest = AgentManifest(
            name="my-agent",
            description="A helpful assistant",
            input_content_types=["text/plain", "application/json"],
            output_content_types=["text/plain"],
        )
        ```
    """

    name: str  # RFC 1123 DNS label format
    description: str
    input_content_types: list[str] = Field(default_factory=lambda: ["*/*"])
    output_content_types: list[str] = Field(default_factory=lambda: ["*/*"])
    metadata: AgentMetadata | None = None
    status: AgentStatus | None = None

    @field_validator("name")
    @classmethod
    def validate_dns_label(cls, v: str) -> str:
        """Validate name follows RFC 1123 DNS label format."""
        if not _DNS_LABEL_PATTERN.match(v):
            raise ValueError(
                f"Name '{v}' must be a valid RFC 1123 DNS label: "
                "lowercase alphanumeric, may contain hyphens (not at start/end), "
                "max 63 characters"
            )
        return v
