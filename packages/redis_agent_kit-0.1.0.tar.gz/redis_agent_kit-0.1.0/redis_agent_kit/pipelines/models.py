"""Pipeline data models."""

import hashlib
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, model_validator


class DocumentType(StrEnum):
    """Type of document being processed."""

    DOCUMENTATION = "documentation"
    BLOG_POST = "blog_post"
    RUNBOOK = "runbook"
    TUTORIAL = "tutorial"
    REFERENCE = "reference"
    API_DOC = "api_doc"
    OTHER = "other"


class Document(BaseModel):
    """A document to be processed by the pipeline."""

    doc_id: str | None = None
    title: str
    content: str
    source: str
    doc_type: DocumentType = DocumentType.OTHER
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @model_validator(mode="after")
    def set_doc_id_from_content_hash(self) -> "Document":
        """Auto-generate doc_id from content hash if not provided."""
        if self.doc_id is None:
            content_hash = hashlib.sha256(self.content.encode()).hexdigest()[:16]
            object.__setattr__(self, "doc_id", content_hash)
        return self


class Chunk(BaseModel):
    """A chunk of a document ready for vectorization."""

    chunk_id: str
    doc_id: str
    content: str
    chunk_index: int
    metadata: dict[str, Any] = Field(default_factory=dict)


class SearchResult(BaseModel):
    """Result from a vector similarity search."""

    chunk_id: str
    doc_id: str
    content: str
    score: float
    metadata: dict[str, Any] = Field(default_factory=dict)


class ProcessorConfig(BaseModel):
    """Configuration for document processing."""

    chunk_size: int = 1000
    chunk_overlap: int = 200
    min_chunk_size: int = 100
    max_chunks_per_doc: int = 50
    strip_front_matter: bool = True

    @model_validator(mode="after")
    def validate_overlap_less_than_size(self) -> "ProcessorConfig":
        """Validate that overlap is less than chunk size."""
        if self.chunk_overlap >= self.chunk_size:
            raise ValueError(
                f"chunk_overlap ({self.chunk_overlap}) must be less than "
                f"chunk_size ({self.chunk_size})"
            )
        return self


class PipelineResult(BaseModel):
    """Result of a pipeline run."""

    pipeline_id: str
    started_at: datetime
    completed_at: datetime | None = None
    documents_processed: int = 0
    chunks_created: int = 0
    errors: list[str] = Field(default_factory=list)
    status: str = "running"


# =============================================================================
# Phase 6: Two-Stage Pipeline Models
# =============================================================================


class SourceConfig(BaseModel):
    """Configuration for a specific source or pattern."""

    name: str
    path_pattern: str
    chunk_size: int = 1000
    chunk_overlap: int = 200
    min_chunk_size: int = 100
    max_chunks_per_doc: int = 50
    doc_type: DocumentType = DocumentType.OTHER
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_overlap_less_than_size(self) -> "SourceConfig":
        """Validate that overlap is less than chunk size."""
        if self.chunk_overlap >= self.chunk_size:
            raise ValueError(
                f"chunk_overlap ({self.chunk_overlap}) must be less than "
                f"chunk_size ({self.chunk_size})"
            )
        return self

    def to_processor_config(self) -> "ProcessorConfig":
        """Convert to ProcessorConfig for document processing."""
        return ProcessorConfig(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            min_chunk_size=self.min_chunk_size,
            max_chunks_per_doc=self.max_chunks_per_doc,
        )


class ChunkingDefaults(BaseModel):
    """Default chunking configuration."""

    chunk_size: int = 1000
    chunk_overlap: int = 200
    min_chunk_size: int = 100
    max_chunks_per_doc: int = 50


class PipelineConfig(BaseModel):
    """Full pipeline configuration."""

    sources: list[SourceConfig] = Field(default_factory=list)
    defaults: ChunkingDefaults = Field(default_factory=ChunkingDefaults)
    default_chunk_size: int = 1000
    default_chunk_overlap: int = 200
    embedding_model: str = "text-embedding-3-small"
    artifacts_dir: Path = Path("artifacts")
    custom_docs_dir: Path = Path("artifacts/custom")

    def get_source(self, name: str) -> SourceConfig | None:
        """Find source configuration by name."""
        for source in self.sources:
            if source.name == name:
                return source
        return None


class DocumentFrontmatter(BaseModel):
    """YAML frontmatter options for documents."""

    title: str | None = None
    pin: bool = False
    chunk_size: int | None = None
    chunk_overlap: int | None = None
    min_chunk_size: int | None = None
    max_chunks_per_doc: int | None = None
    category: str | None = None
    doc_type: DocumentType | None = None
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class PreparedDocument(BaseModel):
    """Document with chunks ready for ingestion."""

    doc_id: str
    title: str
    source: str
    chunks: list["Chunk"]
    frontmatter: DocumentFrontmatter | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class BatchManifest(BaseModel):
    """Manifest for prepare stage (Stage 1)."""

    batch_id: str
    batch_date: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    source_configs: list[SourceConfig] = Field(default_factory=list)
    documents_prepared: int = 0
    chunks_created: int = 0
    status: str = "preparing"  # preparing, ready, ingesting, ingested, failed


class IngestionManifest(BaseModel):
    """Manifest for ingest stage (Stage 2)."""

    batch_id: str
    ingestion_started_at: datetime | None = None
    ingestion_completed_at: datetime | None = None
    documents_ingested: int = 0
    chunks_embedded: int = 0
    status: str = "pending"  # pending, in_progress, completed, failed
    errors: list[str] = Field(default_factory=list)
