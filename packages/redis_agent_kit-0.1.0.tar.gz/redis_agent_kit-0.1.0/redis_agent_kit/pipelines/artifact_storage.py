"""Artifact storage for two-stage pipeline."""

import shutil
import uuid
from pathlib import Path

from .models import BatchManifest, IngestionManifest, PreparedDocument


class ArtifactStorage:
    """Manages artifact storage for the two-stage pipeline."""

    BATCH_MANIFEST_FILE = "manifest.json"
    INGESTION_MANIFEST_FILE = "ingestion_manifest.json"
    DOCUMENTS_DIR = "documents"

    def __init__(
        self,
        artifacts_dir: Path,
        custom_docs_dir: Path | None = None,
    ):
        """Initialize artifact storage.

        Args:
            artifacts_dir: Base directory for artifacts.
            custom_docs_dir: Directory for custom user documents.
        """
        self.artifacts_dir = Path(artifacts_dir)
        self.custom_docs_dir = (
            Path(custom_docs_dir) if custom_docs_dir else self.artifacts_dir / "custom"
        )
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)

    def create_batch(self) -> tuple[Path, str]:
        """Create a new batch directory.

        Returns:
            Tuple of (batch_dir, batch_id).
        """
        batch_id = str(uuid.uuid4())[:8]  # Short unique ID
        batch_dir = self.artifacts_dir / batch_id
        batch_dir.mkdir(parents=True, exist_ok=True)
        (batch_dir / self.DOCUMENTS_DIR).mkdir(exist_ok=True)
        return batch_dir, batch_id

    def get_batch_dir(self, batch_id: str) -> Path | None:
        """Get batch directory by ID.

        Args:
            batch_id: The batch ID.

        Returns:
            Path to batch directory or None if not found.
        """
        batch_dir = self.artifacts_dir / batch_id
        if batch_dir.exists() and batch_dir.is_dir():
            return batch_dir
        return None

    def list_batches(self) -> list[str]:
        """List all batch IDs.

        Returns:
            List of batch IDs.
        """
        if not self.artifacts_dir.exists():
            return []
        return [d.name for d in self.artifacts_dir.iterdir() if d.is_dir() and d.name != "custom"]

    def delete_batch(self, batch_id: str) -> None:
        """Delete a batch directory.

        Args:
            batch_id: The batch ID to delete.
        """
        batch_dir = self.get_batch_dir(batch_id)
        if batch_dir:
            shutil.rmtree(batch_dir)

    def save_batch_manifest(self, batch_id: str, manifest: BatchManifest) -> None:
        """Save batch manifest to disk.

        Args:
            batch_id: The batch ID.
            manifest: The manifest to save.
        """
        batch_dir = self.get_batch_dir(batch_id)
        if batch_dir:
            manifest_path = batch_dir / self.BATCH_MANIFEST_FILE
            manifest_path.write_text(manifest.model_dump_json(indent=2))

    def load_batch_manifest(self, batch_id: str) -> BatchManifest | None:
        """Load batch manifest from disk.

        Args:
            batch_id: The batch ID.

        Returns:
            BatchManifest or None if not found.
        """
        batch_dir = self.get_batch_dir(batch_id)
        if not batch_dir:
            return None
        manifest_path = batch_dir / self.BATCH_MANIFEST_FILE
        if not manifest_path.exists():
            return None
        return BatchManifest.model_validate_json(manifest_path.read_text())

    def save_ingestion_manifest(self, batch_id: str, manifest: IngestionManifest) -> None:
        """Save ingestion manifest to disk.

        Args:
            batch_id: The batch ID.
            manifest: The manifest to save.
        """
        batch_dir = self.get_batch_dir(batch_id)
        if batch_dir:
            manifest_path = batch_dir / self.INGESTION_MANIFEST_FILE
            manifest_path.write_text(manifest.model_dump_json(indent=2))

    def load_ingestion_manifest(self, batch_id: str) -> IngestionManifest | None:
        """Load ingestion manifest from disk.

        Args:
            batch_id: The batch ID.

        Returns:
            IngestionManifest or None if not found.
        """
        batch_dir = self.get_batch_dir(batch_id)
        if not batch_dir:
            return None
        manifest_path = batch_dir / self.INGESTION_MANIFEST_FILE
        if not manifest_path.exists():
            return None
        return IngestionManifest.model_validate_json(manifest_path.read_text())

    def save_document(self, batch_id: str, document: PreparedDocument) -> None:
        """Save a prepared document to disk.

        Args:
            batch_id: The batch ID.
            document: The document to save.
        """
        batch_dir = self.get_batch_dir(batch_id)
        if batch_dir:
            docs_dir = batch_dir / self.DOCUMENTS_DIR
            docs_dir.mkdir(exist_ok=True)
            doc_path = docs_dir / f"{document.doc_id}.json"
            doc_path.write_text(document.model_dump_json(indent=2))

    def load_documents(self, batch_id: str) -> list[PreparedDocument]:
        """Load all prepared documents from a batch.

        Args:
            batch_id: The batch ID.

        Returns:
            List of PreparedDocument objects.
        """
        batch_dir = self.get_batch_dir(batch_id)
        if not batch_dir:
            return []
        docs_dir = batch_dir / self.DOCUMENTS_DIR
        if not docs_dir.exists():
            return []
        documents = []
        for doc_path in docs_dir.glob("*.json"):
            documents.append(PreparedDocument.model_validate_json(doc_path.read_text()))
        return documents

    def get_custom_docs_dir(self) -> Path:
        """Get the custom documents directory.

        Returns:
            Path to custom documents directory.
        """
        self.custom_docs_dir.mkdir(parents=True, exist_ok=True)
        return self.custom_docs_dir

    def list_custom_docs(self) -> list[Path]:
        """List markdown files in custom docs directory.

        Returns:
            List of paths to markdown files.
        """
        if not self.custom_docs_dir.exists():
            return []
        return list(self.custom_docs_dir.glob("*.md"))
