"""Ingest stage for two-stage pipeline (Stage 2)."""

from datetime import UTC, datetime

from redis_agent_kit.vectorizer import Vectorizer

from .artifact_storage import ArtifactStorage
from .models import IngestionManifest
from .vector_store import VectorStore


class IngestStage:
    """Stage 2: Load documents from artifacts, embed, and store in Redis.

    This stage reads prepared documents from the artifacts folder,
    generates embeddings for each chunk, and stores them in the
    Redis vector store.
    """

    def __init__(
        self,
        storage: ArtifactStorage,
        vectorizer: Vectorizer,
        vector_store: VectorStore,
    ):
        """Initialize the ingest stage.

        Args:
            storage: Artifact storage for reading prepared documents.
            vectorizer: Vectorizer for generating embeddings.
            vector_store: Vector store for storing embedded chunks.
        """
        self.storage = storage
        self.vectorizer = vectorizer
        self.vector_store = vector_store

    def ingest(self, batch_id: str) -> IngestionManifest:
        """Ingest all documents from a prepared batch.

        Args:
            batch_id: The batch ID to ingest.

        Returns:
            IngestionManifest with ingestion statistics.

        Raises:
            ValueError: If the batch does not exist.
        """
        # Verify batch exists
        batch_dir = self.storage.get_batch_dir(batch_id)
        if batch_dir is None or not batch_dir.exists():
            raise ValueError(f"Batch {batch_id} not found")

        # Load batch manifest
        batch_manifest = self.storage.load_batch_manifest(batch_id)
        if batch_manifest is None:
            raise ValueError(f"Batch manifest for {batch_id} not found")

        # Load all prepared documents
        documents = self.storage.load_documents(batch_id)

        documents_ingested = 0
        chunks_embedded = 0

        for doc in documents:
            for chunk in doc.chunks:
                # Generate embedding
                embedding = self.vectorizer.embed_sync(chunk.content)

                # Store in vector store
                self.vector_store.store_chunk_sync(
                    chunk_id=chunk.chunk_id,
                    doc_id=chunk.doc_id,
                    content=chunk.content,
                    embedding=embedding,
                    metadata={
                        "title": doc.title,
                        "source": doc.source,
                        "chunk_index": chunk.chunk_index,
                        "pinned": doc.frontmatter.pin if doc.frontmatter else False,
                        "category": (doc.frontmatter.category if doc.frontmatter else None),
                        "doc_type": (doc.frontmatter.doc_type if doc.frontmatter else None),
                        "tags": doc.frontmatter.tags if doc.frontmatter else [],
                    },
                )
                chunks_embedded += 1

            documents_ingested += 1

        # Create and save ingestion manifest
        ingestion_manifest = IngestionManifest(
            batch_id=batch_id,
            ingestion_completed_at=datetime.now(UTC),
            documents_ingested=documents_ingested,
            chunks_embedded=chunks_embedded,
            status="completed",
        )
        self.storage.save_ingestion_manifest(batch_id, ingestion_manifest)

        return ingestion_manifest
