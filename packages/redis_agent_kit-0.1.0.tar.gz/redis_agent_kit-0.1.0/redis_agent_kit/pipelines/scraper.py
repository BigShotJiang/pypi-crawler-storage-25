"""Base scraper and implementations for document ingestion."""

from abc import ABC, abstractmethod
from pathlib import Path

from .models import Document, DocumentType


class BaseScraper(ABC):
    """Abstract base class for document scrapers.

    Scrapers fetch documents from various sources (files, websites, APIs)
    and return them as Document objects for processing.
    """

    @abstractmethod
    async def scrape(self) -> list[Document]:
        """Scrape documents from the source.

        Returns:
            List of scraped documents.
        """
        ...

    @abstractmethod
    def get_source_name(self) -> str:
        """Get the name of this scraper's source.

        Returns:
            Source name (e.g., 'file', 'web', 'api').
        """
        ...


class FileScraper(BaseScraper):
    """Scraper that reads documents from local files."""

    def __init__(
        self,
        directory: Path,
        patterns: list[str] | None = None,
        recursive: bool = False,
        doc_type: DocumentType = DocumentType.OTHER,
    ):
        """Initialize file scraper.

        Args:
            directory: Directory to scrape files from.
            patterns: File patterns to match (e.g., ['*.md', '*.txt']).
            recursive: Whether to scrape subdirectories.
            doc_type: Document type to assign to scraped documents.
        """
        self.directory = directory
        self.patterns = patterns or ["*"]
        self.recursive = recursive
        self.doc_type = doc_type

    def get_source_name(self) -> str:
        """Get source name."""
        return "file"

    async def scrape(self) -> list[Document]:
        """Scrape files from directory.

        Returns:
            List of documents from matching files.
        """
        documents: list[Document] = []

        for pattern in self.patterns:
            if self.recursive:
                files = self.directory.rglob(pattern)
            else:
                files = self.directory.glob(pattern)

            for file_path in files:
                if file_path.is_file():
                    try:
                        content = file_path.read_text(encoding="utf-8")
                        doc = Document(
                            title=file_path.name,
                            content=content,
                            source=str(file_path.absolute()),
                            doc_type=self.doc_type,
                            metadata={
                                "file_path": str(file_path),
                                "file_name": file_path.name,
                                "file_extension": file_path.suffix,
                            },
                        )
                        documents.append(doc)
                    except (OSError, UnicodeDecodeError):
                        # Skip files that can't be read
                        pass

        return documents
