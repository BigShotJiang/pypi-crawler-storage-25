"""Document deduplication with content hashing."""

import hashlib
import json
from pathlib import Path


class DocumentDeduplicator:
    """Deduplicates documents based on content hash.

    Tracks content hashes to detect duplicate documents and supports
    document replacement by updating the hash mapping.
    """

    def __init__(self, hash_store_path: Path):
        """Initialize the deduplicator.

        Args:
            hash_store_path: Path to the JSON file for persisting hashes.
        """
        self.hash_store_path = hash_store_path
        self._hashes: dict[str, str | None] = {}  # hash -> doc_id
        self._doc_hashes: dict[str, str] = {}  # doc_id -> hash
        self._load()

    def _load(self) -> None:
        """Load hashes from file if it exists."""
        if self.hash_store_path.exists():
            data = json.loads(self.hash_store_path.read_text())
            self._hashes = data.get("hashes", {})
            self._doc_hashes = data.get("doc_hashes", {})

    def save(self) -> None:
        """Save hashes to file."""
        self.hash_store_path.parent.mkdir(parents=True, exist_ok=True)
        data = {"hashes": self._hashes, "doc_hashes": self._doc_hashes}
        self.hash_store_path.write_text(json.dumps(data, indent=2))

    def get_content_hash(self, content: str) -> str:
        """Compute SHA-256 hash of content.

        Args:
            content: The content to hash.

        Returns:
            Hex digest of the SHA-256 hash.
        """
        return hashlib.sha256(content.encode()).hexdigest()

    def is_duplicate(self, content: str) -> bool:
        """Check if content has been seen before.

        Args:
            content: The content to check.

        Returns:
            True if content hash exists in store, False otherwise.
        """
        content_hash = self.get_content_hash(content)
        return content_hash in self._hashes

    def mark_seen(self, content: str, doc_id: str | None = None) -> str:
        """Mark content as seen.

        Args:
            content: The content to mark.
            doc_id: Optional document ID to associate with the content.

        Returns:
            The content hash.
        """
        content_hash = self.get_content_hash(content)
        self._hashes[content_hash] = doc_id
        if doc_id:
            self._doc_hashes[doc_id] = content_hash
        return content_hash

    def get_doc_id_for_content(self, content: str) -> str | None:
        """Get the document ID associated with content.

        Args:
            content: The content to look up.

        Returns:
            The document ID if found, None otherwise.
        """
        content_hash = self.get_content_hash(content)
        return self._hashes.get(content_hash)

    def replace_document(self, doc_id: str, new_content: str) -> str:
        """Replace a document's content hash.

        Removes the old hash and adds the new one.

        Args:
            doc_id: The document ID to update.
            new_content: The new content.

        Returns:
            The new content hash.
        """
        # Remove old hash if exists
        if doc_id in self._doc_hashes:
            old_hash = self._doc_hashes[doc_id]
            if old_hash in self._hashes:
                del self._hashes[old_hash]

        # Add new hash
        return self.mark_seen(new_content, doc_id=doc_id)

    def clear(self) -> None:
        """Clear all stored hashes."""
        self._hashes.clear()
        self._doc_hashes.clear()
