"""Pipeline for orchestrating document ingestion.

Pipelines can run synchronously or be submitted for background processing via Docket.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import redis.asyncio as redis
from docket import Docket
from ulid import ULID

from redis_agent_kit.config import get_settings
from redis_agent_kit.emitter import TaskEmitter
from redis_agent_kit.models import TaskStatus
from redis_agent_kit.task_manager import TaskManager
from redis_agent_kit.vectorizer import Vectorizer

from .models import Document, PipelineResult, ProcessorConfig
from .processor import DocumentProcessor
from .scraper import BaseScraper
from .vector_store import VectorStore


class Pipeline:
    """Orchestrates document ingestion: scrape -> process -> embed -> store.

    Pipelines can run in two modes:
    1. **Synchronous**: Call `run()` or `run_documents()` directly
    2. **Background (Docket)**: Call `submit()` to queue for background processing

    Example synchronous usage:
        pipeline = Pipeline(redis_client)
        scraper = FileScraper(Path("./docs"), patterns=["*.md"])
        result = await pipeline.run(scraper)

    Example background usage:
        pipeline = Pipeline(redis_client, redis_url="redis://localhost:6379")
        result = await pipeline.submit(documents)
        # Returns: {"task_id": "...", "status": "queued"}
        # Poll task status via TaskManager
    """

    def __init__(
        self,
        client: redis.Redis,
        processor_config: ProcessorConfig | None = None,
        embedding_model: str = "text-embedding-3-small",
        embedding_dimensions: int | None = None,
        store_prefix: str = "rak",
        redis_url: str | None = None,
        queue_name: str | None = None,
    ):
        """Initialize pipeline.

        Args:
            client: Async Redis client.
            processor_config: Document processor configuration.
            embedding_model: LiteLLM embedding model name.
            embedding_dimensions: Embedding dimensions (if supported).
            store_prefix: Prefix for Redis keys.
            redis_url: Redis URL for background workers (default from settings).
            queue_name: Background worker queue name (default from settings).
        """
        settings = get_settings()
        self.client = client
        self.processor = DocumentProcessor(processor_config)
        self.vectorizer = Vectorizer(model=embedding_model)
        self.vector_store = VectorStore(
            client, prefix=store_prefix, dimensions=embedding_dimensions
        )
        self._redis_url = redis_url or settings.redis_url
        self._queue_name = queue_name or settings.task.queue_name
        self._prefix = store_prefix
        self._task_manager = TaskManager(client, prefix=store_prefix)
        self._processor_config = processor_config
        self._embedding_model = embedding_model
        self._embedding_dimensions = embedding_dimensions

    @property
    def task_manager(self) -> TaskManager:
        """Get the TaskManager for tracking pipeline tasks."""
        return self._task_manager

    async def run(self, scraper: BaseScraper) -> PipelineResult:
        """Run the pipeline synchronously with a scraper.

        Args:
            scraper: Scraper to fetch documents from.

        Returns:
            Pipeline result with statistics.
        """
        # Scrape documents
        documents = await scraper.scrape()
        return await self.run_documents(documents)

    async def run_documents(
        self,
        documents: list[Document],
        emitter: TaskEmitter | None = None,
    ) -> PipelineResult:
        """Run the pipeline synchronously with pre-fetched documents.

        Args:
            documents: List of documents to process.
            emitter: Optional TaskEmitter for progress updates.

        Returns:
            Pipeline result with statistics.
        """
        pipeline_id = str(ULID())
        started_at = datetime.now(UTC)
        errors: list[str] = []
        total_chunks = 0

        if emitter:
            await emitter.emit_async(
                f"Starting pipeline {pipeline_id} with {len(documents)} documents"
            )

        # Process each document
        all_chunks = []
        for i, doc in enumerate(documents):
            try:
                if emitter:
                    await emitter.emit_async(
                        f"Processing document {i + 1}/{len(documents)}: {doc.title}"
                    )
                chunks = self.processor.chunk_document(doc)
                all_chunks.extend(chunks)
            except Exception as e:
                errors.append(f"Error processing {doc.doc_id}: {e}")
                if emitter:
                    await emitter.emit_async(
                        f"Error processing {doc.doc_id}: {e}",
                        update_type="error",
                    )

        # Generate embeddings for all chunks
        if all_chunks:
            try:
                if emitter:
                    await emitter.emit_async(f"Generating embeddings for {len(all_chunks)} chunks")
                contents = [chunk.content for chunk in all_chunks]
                embeddings = await self.vectorizer.embed_many(contents)

                if emitter:
                    await emitter.emit_async("Storing chunks in vector store")
                # Store chunks with embeddings
                await self.vector_store.store_chunks(all_chunks, embeddings)
                total_chunks = len(all_chunks)
            except Exception as e:
                errors.append(f"Error embedding/storing chunks: {e}")
                if emitter:
                    await emitter.emit_async(
                        f"Error embedding/storing chunks: {e}",
                        update_type="error",
                    )

        completed_at = datetime.now(UTC)
        status = "completed" if not errors else "completed_with_errors"

        if emitter:
            await emitter.emit_async(
                f"Pipeline {status}: {len(documents)} docs, {total_chunks} chunks"
            )

        return PipelineResult(
            pipeline_id=pipeline_id,
            started_at=started_at,
            completed_at=completed_at,
            documents_processed=len(documents),
            chunks_created=total_chunks,
            errors=errors,
            status=status,
        )

    async def submit(
        self,
        documents: list[Document],
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Submit documents for background processing via Docket.

        Creates a Task to track progress and submits the pipeline work
        to Docket for background execution.

        Args:
            documents: List of documents to process.
            context: Optional context data for the task.

        Returns:
            Dict with task_id and status.
        """
        # Create a task to track the pipeline run
        task = await self._task_manager.create_task(
            session_id="pipeline",  # Use "pipeline" as a pseudo-session
            message=f"Pipeline run with {len(documents)} documents",
            context=context,
        )

        # Serialize documents for background processing
        docs_data = [doc.model_dump() for doc in documents]

        # Submit to background worker queue for processing
        async with Docket(url=self._redis_url, name=self._queue_name) as docket:
            queued_func = docket.add(_run_pipeline_task, key=task.task_id)
            await queued_func(
                task_id=task.task_id,
                documents_data=docs_data,
                redis_url=self._redis_url,
                prefix=self._prefix,
                processor_config=(
                    self._processor_config.model_dump() if self._processor_config else None
                ),
                embedding_model=self._embedding_model,
                embedding_dimensions=self._embedding_dimensions,
            )

        return {
            "task_id": task.task_id,
            "status": "queued",
            "message": f"Pipeline queued with {len(documents)} documents",
        }


async def _run_pipeline_task(
    task_id: str,
    documents_data: list[dict[str, Any]],
    redis_url: str,
    prefix: str,
    processor_config: dict[str, Any] | None,
    embedding_model: str,
    embedding_dimensions: int | None,
) -> dict[str, Any]:
    """Docket task handler for pipeline execution.

    This function is called by Docket workers to process pipeline tasks.
    It reconstructs the Pipeline and runs it with progress updates.

    Args:
        task_id: The task ID for tracking.
        documents_data: Serialized document data.
        redis_url: Redis URL for connection.
        prefix: Key prefix for Redis.
        processor_config: Processor configuration dict.
        embedding_model: Embedding model name.
        embedding_dimensions: Embedding dimensions.

    Returns:
        Pipeline result as dict.
    """
    # Create Redis client
    client: Any = redis.from_url(  # type: ignore[no-untyped-call]
        redis_url, decode_responses=True
    )

    try:
        # Create task manager and emitter
        task_manager = TaskManager(client, prefix=prefix)
        emitter = TaskEmitter(task_manager, task_id)

        # Update task status to in_progress
        await task_manager.update_status(task_id, TaskStatus.IN_PROGRESS)

        # Reconstruct processor config
        config = ProcessorConfig(**processor_config) if processor_config else None

        # Create pipeline
        pipeline = Pipeline(
            client=client,
            processor_config=config,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
            store_prefix=prefix,
            redis_url=redis_url,
        )

        # Reconstruct documents
        documents = [Document(**doc_data) for doc_data in documents_data]

        # Run the pipeline with emitter
        result = await pipeline.run_documents(documents, emitter=emitter)

        # Set result and update status
        result_dict = result.model_dump()
        # Convert datetime objects to ISO strings for JSON serialization
        result_dict["started_at"] = result.started_at.isoformat()
        result_dict["completed_at"] = (
            result.completed_at.isoformat() if result.completed_at else None
        )

        await task_manager.set_result(task_id, result_dict)
        await task_manager.update_status(task_id, TaskStatus.DONE)

        return result_dict

    except Exception as e:
        # Handle errors
        task_manager = TaskManager(client, prefix=prefix)
        await task_manager.set_error(task_id, str(e))
        await task_manager.update_status(task_id, TaskStatus.FAILED)
        raise

    finally:
        await client.aclose()
