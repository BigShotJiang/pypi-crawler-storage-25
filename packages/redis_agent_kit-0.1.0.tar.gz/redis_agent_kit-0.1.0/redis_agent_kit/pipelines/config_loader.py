"""Pipeline configuration file loader."""

from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from .models import ChunkingDefaults, PipelineConfig, SourceConfig


def load_config(config_path: Path) -> PipelineConfig:
    """Load pipeline configuration from a YAML file.

    Args:
        config_path: Path to the pipeline.yaml configuration file.

    Returns:
        PipelineConfig instance.

    Raises:
        FileNotFoundError: If the config file doesn't exist.
        ValueError: If the YAML is invalid.
    """
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    try:
        with open(config_path) as f:
            data = yaml.safe_load(f) or {}
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in {config_path}: {e}") from e

    return _parse_config(data)


def _parse_config(data: dict[str, Any]) -> PipelineConfig:
    """Parse configuration dictionary into PipelineConfig.

    Args:
        data: Raw configuration dictionary from YAML.

    Returns:
        PipelineConfig instance.
    """
    # Parse defaults
    defaults_data = data.get("defaults", {})
    defaults = ChunkingDefaults(**defaults_data)

    # Parse sources
    sources_data = data.get("sources", [])
    sources = [_parse_source(s) for s in sources_data]

    # Parse paths
    artifacts_dir = Path(data.get("artifacts_dir", "artifacts"))
    custom_docs_dir_str = data.get("custom_docs_dir")
    custom_docs_dir = Path(custom_docs_dir_str) if custom_docs_dir_str else artifacts_dir / "custom"

    return PipelineConfig(
        sources=sources,
        defaults=defaults,
        default_chunk_size=defaults.chunk_size,
        default_chunk_overlap=defaults.chunk_overlap,
        embedding_model=data.get("embedding_model", "text-embedding-3-small"),
        artifacts_dir=artifacts_dir,
        custom_docs_dir=custom_docs_dir,
    )


def _parse_source(data: dict[str, Any]) -> SourceConfig:
    """Parse source configuration dictionary.

    Args:
        data: Raw source configuration dictionary.

    Returns:
        SourceConfig instance.
    """
    return SourceConfig(
        name=data["name"],
        path_pattern=data["path_pattern"],
        chunk_size=data.get("chunk_size", 1000),
        chunk_overlap=data.get("chunk_overlap", 200),
        min_chunk_size=data.get("min_chunk_size", 100),
        max_chunks_per_doc=data.get("max_chunks_per_doc", 50),
        doc_type=data.get("doc_type", "other"),
        metadata=data.get("metadata", {}),
    )


def find_config_file(start_dir: Path) -> Path | None:
    """Find pipeline.yaml in directory hierarchy.

    Searches from start_dir upward through parent directories
    until a pipeline.yaml file is found.

    Args:
        start_dir: Directory to start searching from.

    Returns:
        Path to pipeline.yaml if found, None otherwise.
    """
    current = start_dir.resolve()

    while True:
        config_path = current / "pipeline.yaml"
        if config_path.exists():
            return config_path

        parent = current.parent
        if parent == current:
            # Reached filesystem root
            return None
        current = parent
