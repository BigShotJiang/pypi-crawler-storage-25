"""Framework-agnostic Agent base class using LiteLLM."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any

import litellm
import redis.asyncio as redis

from redis_agent_kit.knowledge import KnowledgeStore
from redis_agent_kit.tools import ToolManager, ToolProvider
from redis_agent_kit.tools.knowledge_provider import KnowledgeProvider

logger = logging.getLogger(__name__)


@dataclass
class Message:
    """A message in the conversation."""

    role: str  # "system", "user", "assistant", "tool"
    content: str | None = None
    tool_calls: list[Any] | None = None
    tool_call_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict for LiteLLM."""
        d: dict[str, Any] = {"role": self.role}
        if self.content is not None:
            d["content"] = self.content
        if self.tool_calls:
            d["tool_calls"] = self.tool_calls
        if self.tool_call_id:
            d["tool_call_id"] = self.tool_call_id
        return d


@dataclass
class AgentConfig:
    """Configuration for Agent."""

    model: str = "gpt-4o-mini"
    system_prompt: str | None = None
    temperature: float = 0.7
    max_tokens: int | None = None
    max_tool_iterations: int = 10
    use_knowledge: bool = True
    use_tools: bool = True
    knowledge_context_limit: int = 5


class Agent:
    """Framework-agnostic agent with LiteLLM backend.

    Example:
        agent = Agent(
            model="gpt-4o-mini",  # Or "anthropic/claude-3-5-sonnet"
            redis_url="redis://localhost:6379",
        )

        # Ingest knowledge
        await agent.knowledge.ingest("Redis uses RDB for persistence...")

        # Add custom tools
        agent.tools.add_provider(MyProvider())

        # Chat
        response = await agent.chat("How does Redis persistence work?")
    """

    def __init__(
        self,
        model: str = "gpt-4o-mini",
        system_prompt: str | None = None,
        redis_url: str = "redis://localhost:6379",
        redis_client: redis.Redis | None = None,
        config: AgentConfig | None = None,
    ):
        """Initialize agent.

        Args:
            model: LiteLLM model name (e.g., "gpt-4o-mini", "anthropic/claude-3-5-sonnet").
            system_prompt: Optional system prompt.
            redis_url: Redis connection URL.
            redis_client: Optional existing Redis client.
            config: Optional full configuration.
        """
        self._config = config or AgentConfig(model=model, system_prompt=system_prompt)
        self._client = redis_client or redis.from_url(redis_url, decode_responses=True)  # type: ignore[no-untyped-call]

        # Core components
        self.knowledge = KnowledgeStore(self._client)
        self.tools = ToolManager()

        # Register built-in knowledge tool
        self._knowledge_provider = KnowledgeProvider(self.knowledge)
        self.tools.add_provider(self._knowledge_provider)

        # Conversation history
        self._history: list[Message] = []

    @property
    def model(self) -> str:
        """Get the model name."""
        return self._config.model

    @property
    def config(self) -> AgentConfig:
        """Get agent configuration."""
        return self._config

    def add_provider(self, provider: ToolProvider) -> None:
        """Add a tool provider.

        Args:
            provider: ToolProvider instance.
        """
        self.tools.add_provider(provider)

    def clear_history(self) -> None:
        """Clear conversation history."""
        self._history.clear()

    async def chat(
        self,
        message: str,
        use_knowledge: bool | None = None,
        use_tools: bool | None = None,
    ) -> str:
        """Send a message and get a response.

        Args:
            message: User message.
            use_knowledge: Override config to enable/disable knowledge context.
            use_tools: Override config to enable/disable tools.

        Returns:
            Assistant response.
        """
        use_knowledge = use_knowledge if use_knowledge is not None else self._config.use_knowledge
        use_tools = use_tools if use_tools is not None else self._config.use_tools

        messages = self._build_messages(message, use_knowledge=use_knowledge)

        # Get tools
        tools = None
        if use_tools and self.tools._tools:
            tools = self.tools.get_openai_tools()

        # Call LLM
        response = await self._call_llm(messages, tools)

        # Handle tool calls
        iterations = 0
        while (
            response.choices[0].message.tool_calls and iterations < self._config.max_tool_iterations
        ):
            response = await self._handle_tool_calls(response, messages)
            iterations += 1

        # Extract response
        assistant_content = response.choices[0].message.content or ""

        # Store in history
        self._history.append(Message(role="user", content=message))
        self._history.append(Message(role="assistant", content=assistant_content))

        return assistant_content

    def _build_messages(
        self,
        user_message: str,
        use_knowledge: bool = True,
    ) -> list[dict[str, Any]]:
        """Build message list for LLM call."""
        messages: list[dict[str, Any]] = []

        # System prompt
        if self._config.system_prompt:
            messages.append({"role": "system", "content": self._config.system_prompt})

        # History
        for msg in self._history:
            messages.append(msg.to_dict())

        # User message
        messages.append({"role": "user", "content": user_message})

        return messages

    async def _call_llm(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> Any:
        """Call LLM via LiteLLM."""
        kwargs: dict[str, Any] = {
            "model": self._config.model,
            "messages": messages,
            "temperature": self._config.temperature,
        }

        if self._config.max_tokens:
            kwargs["max_tokens"] = self._config.max_tokens

        if tools:
            kwargs["tools"] = tools

        return await litellm.acompletion(**kwargs)

    async def _handle_tool_calls(
        self,
        response: Any,
        messages: list[dict[str, Any]],
    ) -> Any:
        """Execute tool calls and continue conversation."""
        assistant_msg = response.choices[0].message

        # Add assistant message with tool calls
        messages.append(
            {
                "role": "assistant",
                "content": assistant_msg.content,
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments,
                        },
                    }
                    for tc in assistant_msg.tool_calls
                ],
            }
        )

        # Execute each tool call
        for tool_call in assistant_msg.tool_calls:
            tool_name = tool_call.function.name
            try:
                args = json.loads(tool_call.function.arguments)
            except json.JSONDecodeError:
                args = {}

            try:
                result = await self.tools.execute(tool_name, args)
                result_str = json.dumps(result) if not isinstance(result, str) else result
            except Exception as e:
                logger.warning(f"Tool {tool_name} failed: {e}")
                result_str = json.dumps({"error": str(e)})

            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": result_str,
                }
            )

        # Continue conversation with tool results
        return await self._call_llm(messages, self.tools.get_openai_tools())
