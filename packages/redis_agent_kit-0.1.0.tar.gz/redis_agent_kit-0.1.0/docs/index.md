# Redis Agent Kit

Redis Agent Kit provides infrastructure primitives for building AI agents. It handles the operational complexity—task tracking, conversation state, background processing, and protocol support—so you can focus on agent logic.

## Why Redis Agent Kit?

Building production agents requires more than just LLM calls:

- **Task State** – Track what your agent is doing, show progress, handle failures
- **Conversation History** – Maintain context across turns
- **Background Processing** – Don't block on long-running agent work
- **Real-time Streaming** – Push progress and LLM tokens to clients over SSE
- **Interoperability** – Connect agents via standard protocols (A2A, ACP, MCP)

Redis Agent Kit provides these primitives with Redis as the backbone.

## Installation

```bash
pip install redis-agent-kit[all]
```

Or install specific features:
```bash
pip install redis-agent-kit[api]       # REST API
pip install redis-agent-kit[mcp]       # MCP Server
pip install redis-agent-kit[pipelines] # Data pipelines
```

## Quickstart

### 1. Start Redis

```bash
docker run -d -p 6379:6379 redis:8
```

### 2. Create and Track a Task

```python
import asyncio
import redis.asyncio as redis
from redis_agent_kit import TaskManager, ThreadManager, TaskStatus

async def main():
    client = redis.from_url("redis://localhost:6379", decode_responses=True)
    task_manager = TaskManager(client)
    thread_manager = ThreadManager(client)

    # Create a conversation thread
    thread = await thread_manager.create_thread(context={"user_id": "user_123"})
    print(f"Thread: {thread.thread_id}")

    # Create a task
    task = await task_manager.create_task(thread.thread_id, "What is Redis?")
    print(f"Task: {task.task_id}, Status: {task.status}")

    # Simulate agent work
    await task_manager.update_status(task.task_id, TaskStatus.IN_PROGRESS)
    await task_manager.add_update(task.task_id, "Searching knowledge base...")
    await task_manager.add_update(task.task_id, "Found 3 relevant documents")

    # Complete the task
    await task_manager.set_result(task.task_id, {
        "answer": "Redis is an in-memory data store used as a database, cache, and message broker."
    })
    await task_manager.update_status(task.task_id, TaskStatus.DONE)

    # Check final state
    task = await task_manager.get_task(task.task_id)
    print(f"Final status: {task.status}")
    print(f"Result: {task.result}")

asyncio.run(main())
```

### 3. Add a REST API

```python
# server.py
from redis_agent_kit.api import create_app

app = create_app(redis_url="redis://localhost:6379")
```

```bash
uvicorn server:app --reload
# Visit http://localhost:8000/docs for API documentation
```

### 4. Use the CLI

```bash
# List tasks
rak tasks list

# Get task details
rak tasks get <task_id>

# Start a background worker
rak worker --name my_agent
```

## What's Next?

- **[Tutorial](tutorial.md)** – Build a complete agent from scratch with multi-protocol support
- **Developer Guide:**
  - [Tasks](guide/tasks.md) – Task lifecycle, status updates, error handling
  - [Threads](guide/threads.md) – Conversation management
  - [Streaming](guide/streaming.md) – Real-time SSE and token streaming
  - [Pipelines](guide/pipelines.md) – Ingest and vectorize content for RAG
  - [Protocols](guide/protocols.md) – A2A, ACP, and MCP integration
  - [Input Handling](guide/input.md) – Pause tasks for user input
  - [Middleware](guide/middleware.md) – Compose reusable behaviors
  - [CLI](guide/cli.md) – Command reference
  - [API](guide/api.md) – REST endpoint reference

