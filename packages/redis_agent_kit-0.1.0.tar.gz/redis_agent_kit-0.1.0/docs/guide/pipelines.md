# Pipelines

Pipelines ingest content, chunk it, generate embeddings, and store vectors in Redis for RAG applications.

## Basic Usage

```python
from redis_agent_kit import pipelines
from pathlib import Path
import redis.asyncio as redis

client = redis.from_url("redis://localhost:6379", decode_responses=True)

# Create pipeline
pipeline = pipelines.Pipeline(
    client,
    processor_config=pipelines.ProcessorConfig(chunk_size=500),
    embedding_model="text-embedding-3-small",
)

# Scrape files
scraper = pipelines.FileScraper(
    Path("./docs"),
    patterns=["*.md"],
    recursive=True,
)

# Run
result = await pipeline.run(scraper)
print(f"Processed {result.documents_processed} docs, {result.chunks_created} chunks")
```

## Processor Configuration

```python
from redis_agent_kit.pipelines import ProcessorConfig

config = ProcessorConfig(
    chunk_size=1000,       # Target characters per chunk
    chunk_overlap=200,     # Overlap between chunks
    min_chunk_size=100,    # Minimum chunk size
    max_chunks_per_doc=50, # Limit chunks per document
)
```

## Scrapers

### FileScraper

```python
scraper = pipelines.FileScraper(
    Path("./docs"),
    patterns=["*.md", "*.txt"],
    recursive=True,
)
```

### Custom Scraper

```python
from redis_agent_kit.pipelines import BaseScraper, Document

class APIScraper(BaseScraper):
    def __init__(self, api_url: str):
        self.api_url = api_url

    async def scrape(self) -> list[Document]:
        response = await httpx.get(self.api_url)
        return [
            Document(
                doc_id=item["id"],
                title=item["title"],
                content=item["body"],
                source=self.api_url,
            )
            for item in response.json()
        ]

    def get_source_name(self) -> str:
        return "my-api"
```

## Vector Search

```python
from redis_agent_kit.pipelines import VectorStore, Vectorizer

vectorizer = Vectorizer(model="text-embedding-3-small")
vector_store = VectorStore(client, prefix="rak")

# Search
embedding = await vectorizer.embed("How do I configure Redis?")
results = await vector_store.search(embedding, limit=5)

for chunk in results:
    print(f"Score: {chunk['score']:.2f}")
    print(f"Content: {chunk['content'][:100]}...")
```

## Two-Stage Pipeline

For large ingestion jobs, separate preparation from ingestion. Stage 1 scans and chunks files without network calls; Stage 2 vectorizes and stores. This allows inspecting the batch before committing resources to embedding API calls.

```python
from redis_agent_kit.pipelines import PipelineOrchestrator, PipelineConfig, SourceConfig

config = PipelineConfig(
    sources=[
        SourceConfig(name="docs", path_pattern="**/*.md"),
    ],
    chunk_size=500,
)

orchestrator = PipelineOrchestrator(
    config=config,
    base_path=Path("./docs"),
)

# Stage 1: Prepare (scan, parse, chunk)
batch_id = orchestrator.prepare()

# Stage 2: Ingest (vectorize, store)
manifest = await orchestrator.ingest(batch_id)
print(f"Ingested {manifest.chunks_created} chunks")
```

## Background Processing

```python
pipeline = pipelines.Pipeline(
    client,
    redis_url="redis://localhost:6379",
    queue_name="pipeline_worker",
)

# Submit for background processing
result = await pipeline.submit(documents)
# Returns: {"task_id": "...", "status": "queued"}

# Poll for completion
task = await pipeline.task_manager.get_task(result["task_id"])
```

Run a worker:
```bash
rak worker --name pipeline_worker
```

## CLI

```bash
# Run pipeline
rak pipelines run ./docs -p "*.md" --chunk-size 500

# Check status
rak pipelines status

# Clear all data
rak pipelines clear
```

