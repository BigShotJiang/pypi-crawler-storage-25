# Tasks

A **Task** represents a unit of agent work—typically one turn in a conversation. Tasks track status, progress updates, results, and errors.

## Creating Tasks

```python
from redis_agent_kit import TaskManager
import redis.asyncio as redis

client = redis.from_url("redis://localhost:6379", decode_responses=True)
task_manager = TaskManager(client)

# Create a task linked to a thread
task = await task_manager.create_task(
    thread_id="thread_123",
    message="What is Redis?",
)
print(task.task_id)              # "01HXYZ..."
print(task.status)               # TaskStatus.QUEUED
print(task.metadata["message"])  # "What is Redis?"
```

## Task Lifecycle

Tasks progress through these statuses:

```
QUEUED → IN_PROGRESS → DONE
                     → FAILED
                     → CANCELLED
         ↓
    AWAITING_INPUT → IN_PROGRESS (resumed)
```

## Updating Tasks

Use `update()` to change status, add messages, set results, or set errors—in one call:

```python
# Start processing with a message
await task_manager.update(task.task_id, status="in_progress", message="Starting...")

# Add progress updates
await task_manager.update(task.task_id, message="Found 5 documents")
await task_manager.update(task.task_id, message="Calling API", update_type="tool_call")

# Complete with result
await task_manager.update(task.task_id, status="done", result={"answer": "Redis is..."})

# Or fail with error
await task_manager.update(task.task_id, status="failed", error="API timeout")
```

Update types: `info` (default), `tool_call`, `reflection`, `error`

You can also use the individual convenience methods:

```python
await task_manager.update_status(task.task_id, TaskStatus.IN_PROGRESS)
await task_manager.add_update(task.task_id, "Processing...")
await task_manager.set_result(task.task_id, {"answer": "..."})
await task_manager.set_error(task.task_id, "Something went wrong")
```

## Retrieving Tasks

```python
from redis_agent_kit import TaskStatus

# Get a single task
task = await task_manager.get_task(task_id)
print(task.status, task.result, task.updates)

# List tasks by status
tasks = await task_manager.list_tasks(status=TaskStatus.IN_PROGRESS)
for t in tasks:
    print(f"{t.task_id}: {t.metadata.get('message')}")

# List tasks for a thread
tasks = await task_manager.list_tasks(thread_id=thread_id)
```

## TaskEmitter

For convenience, use `TaskEmitter` to emit updates without passing `task_id` everywhere:

```python
from redis_agent_kit import TaskEmitter

emitter = TaskEmitter(task_manager, task.task_id)

# Fire-and-forget (sync)
emitter.emit("Processing query...")

# Awaitable
await emitter.emit_async("Analysis complete", metadata={"tokens": 150})

# Stream a single LLM token (ephemeral, not persisted)
await emitter.emit_token("Hello")
```

## Watching Progress

Updates are persisted to the task and can be polled via `get_task()` or streamed live via Server-Sent Events when streaming is enabled:

```python
from redis_agent_kit import AgentKit, StreamConfig

kit = AgentKit(agent_callable=my_handler, stream_config=StreamConfig(enabled=True))
```

Clients then connect to `GET /tasks/{task_id}/stream` to receive `update`, `token`, `done`, `failed`, and `cancelled` events in real time. See the [Streaming guide](streaming.md) for channel scopes, event filtering, and token streaming.

## Deleting Tasks

```python
await task_manager.delete_task(task_id)
```

## Custom Prefix

All keys use `rak:` by default. Use a custom prefix:

```python
task_manager = TaskManager(client, prefix="myapp")
# Keys: myapp:task:{id}, myapp:tasks:status:{status}
```

## Task Fields

| Field | Type | Description |
|-------|------|-------------|
| `task_id` | str | Unique ID (ULID) |
| `thread_id` | str | Parent thread ID |
| `status` | TaskStatus | Current status |
| `result` | dict | Result data |
| `error_message` | str | Error message |
| `updates` | list[TaskUpdate] | Progress updates |
| `metadata` | dict | Arbitrary metadata (includes `message`) |
| `input_request` | InputRequest | Pending input request |
| `input_response` | dict | User's input response |
| `created_at` | datetime | Creation time |
| `updated_at` | datetime | Last update time |

