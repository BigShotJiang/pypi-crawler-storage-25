# Multi-Protocol Support

Expose your agent via multiple protocols: A2A, ACP, REST, and MCP.

## Overview

| Protocol | Type | Discovery | Use Case |
|----------|------|-----------|----------|
| **A2A** | JSON-RPC 2.0 | `/.well-known/agent.json` | Google agent ecosystem |
| **ACP** | REST | `/agents` | BeeAI agent ecosystem |
| **REST** | REST | `/docs` (OpenAPI) | Standard HTTP clients |
| **MCP** | JSON-RPC | Via FastMCP | AI assistant tools |

## Enabling Protocols

```python
from redis_agent_kit.api import create_app
from redis_agent_kit import AgentKit, AgentCard, AgentManifest, Skill

kit = AgentKit(client, agent_callable=my_handler)

# A2A Agent Card
agent_card = AgentCard(
    name="My Agent",
    description="A helpful assistant",
    url="http://localhost:8000",
    skills=[Skill(id="chat", name="Chat", description="General conversation")],
)

# ACP Agent Manifest
agent_manifest = AgentManifest(
    name="my-agent",  # RFC 1123 DNS label format
    description="A helpful assistant",
)

app = create_app(
    redis_url="redis://localhost:6379",
    kit=kit,
    enable_a2a=True,
    enable_acp=True,
    agent_card=agent_card,
    agent_manifest=agent_manifest,
)
```

## A2A Protocol

[A2A](https://github.com/google/A2A) is Google's Agent-to-Agent protocol.

### Agent Card

```python
from redis_agent_kit import AgentCard, Skill

agent_card = AgentCard(
    name="Research Agent",
    description="Researches topics",
    url="http://localhost:8000",
    skills=[
        Skill(
            id="research",
            name="Research",
            description="Research any topic",
            input_schema={"type": "object", "properties": {"topic": {"type": "string"}}},
        ),
    ],
)
```

### Endpoints

- `GET /.well-known/agent.json` – Agent discovery
- `POST /` – JSON-RPC (`message/send`, `tasks/get`, `tasks/cancel`)

### Example Request

```bash
curl -X POST http://localhost:8000 \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "message/send",
    "params": {"message": {"role": "user", "parts": [{"type": "text", "text": "Hello"}]}},
    "id": 1
  }'
```

## ACP Protocol

[ACP](https://github.com/i-am-bee/acp) is BeeAI's Agent Communication Protocol.

### Agent Manifest

```python
from redis_agent_kit import AgentManifest, AgentMetadata

agent_manifest = AgentManifest(
    name="research-agent",  # Must be RFC 1123 format
    description="Researches topics",
    metadata=AgentMetadata(
        documentation="https://example.com/docs",
        framework="redis-agent-kit",
    ),
)
```

### Endpoints

- `GET /agents` – List agents
- `POST /runs` – Create run
- `GET /runs/{id}` – Get run status
- `POST /runs/{id}/cancel` – Cancel run

### Example Request

```bash
curl -X POST http://localhost:8000/runs \
  -H "Content-Type: application/json" \
  -d '{"input": [{"role": "user", "content": "Hello"}]}'
```

## MCP Server

```python
from redis_agent_kit.mcp import create_server

server = create_server(redis_url="redis://localhost:6379", name="my-agent")
# fastmcp run server.py
```

Tools: `list_tasks`, `get_task`, `delete_task`, `pipeline_status`, `pipeline_search`

## Protocol Mapping

| RAK | A2A | ACP |
|-----|-----|-----|
| Task | Task | Run |
| queued | submitted | created |
| in_progress | working | in_progress |
| awaiting_input | input-required | awaiting |
| done | completed | completed |
| failed | failed | failed |

## Unified Server

For full control:

```python
from redis_agent_kit.protocols.unified import create_multi_protocol_app, ProtocolConfig

app = create_multi_protocol_app(
    kit=kit,
    config=ProtocolConfig(enable_a2a=True, enable_acp=True, enable_rest=True),
    agent_card=agent_card,
    agent_manifest=agent_manifest,
)
```

