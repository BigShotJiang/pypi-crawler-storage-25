# REST API Reference

The REST API exposes tasks and document pipelines via HTTP.

## Starting the Server

```python
# app.py
from redis_agent_kit.api import create_app

app = create_app(redis_url="redis://localhost:6379")
```

```bash
uvicorn app:app --reload
# Docs at http://localhost:8000/docs
```

## Customization

```python
app = create_app(
    redis_url="redis://localhost:6379",
    title="My Agent API",
    docs_url="/api/docs",
)
```

## Endpoints

### Health

```
GET /        → {"name": "Redis Agent Kit", "version": "..."}
GET /health  → {"status": "healthy", "redis": "connected"}
```

### Tasks

**List tasks:**
```
GET /tasks
GET /tasks?status=in_progress&limit=10
```

Response:
```json
{
  "tasks": [
    {"task_id": "01HXYZ...", "status": "in_progress", "message": "..."}
  ],
  "count": 1
}
```

**Get task:**
```
GET /tasks/{task_id}
```

Response:
```json
{
  "task_id": "01HXYZ...",
  "thread_id": "01HABC...",
  "status": "done",
  "message": "What is Redis?",
  "result": {"answer": "..."},
  "updates": [{"message": "Searching...", "type": "info"}]
}
```

**Delete task:**
```
DELETE /tasks/{task_id}
```

### Streaming

Server-Sent Events (SSE) endpoints push task progress and LLM tokens to clients in real time. Enable streaming by passing `stream_config=StreamConfig(enabled=True)` to both `AgentKit` and `create_app`.

```python
from redis_agent_kit import AgentKit, ChannelScope, StreamConfig
from redis_agent_kit.api import create_app

stream_config = StreamConfig(
    enabled=True,
    channels={ChannelScope.TASK, ChannelScope.SESSION},
)
kit = AgentKit(agent_callable=my_handler, stream_config=stream_config)
app = create_app(kit=kit, stream_config=stream_config)
```

**Stream a task:**
```
GET /tasks/{task_id}/stream
GET /tasks/{task_id}/stream?replay=false
GET /tasks/{task_id}/stream?events=token,done,failed
```
Emits buffered updates on connect (`?replay=true`, default) and then new events as they happen. Returns `404` if streaming is not enabled.

**Stream all tasks in a session** (requires `ChannelScope.SESSION`):
```
GET /sessions/{session_id}/stream
GET /sessions/{session_id}/stream?events=token,done
```

**Stream all events globally** (requires `ChannelScope.GLOBAL`, useful for dashboards):
```
GET /stream/global
GET /stream/global?events=done,failed
```

Event types: `update`, `token`, `done`, `failed`, `cancelled`, `input_required`.

JavaScript client:
```js
const es = new EventSource(`/tasks/${taskId}/stream`);
es.addEventListener('update', (e) => console.log(JSON.parse(e.data).message));
es.addEventListener('token',  (e) => process.stdout.write(JSON.parse(e.data).message));
es.addEventListener('done',   (e) => { console.log(JSON.parse(e.data).result); es.close(); });
es.addEventListener('failed', (e) => { console.error(JSON.parse(e.data).error); es.close(); });
```

See the [Streaming guide](streaming.md) for the full configuration reference.

### Pipelines

**Prepare (Stage 1):**
```
POST /pipelines/prepare
{
  "base_path": "./docs",
  "sources": [{"name": "docs", "path_pattern": "**/*.md"}]
}
```

Response:
```json
{"batch_id": "01HXYZ...", "status": "prepared", "document_count": 10}
```

**Ingest (Stage 2):**
```
POST /pipelines/ingest
{"batch_id": "01HXYZ..."}
```

Response:
```json
{"status": "ingested", "chunks_created": 42}
```

**Full pipeline:**
```
POST /pipelines/full
{
  "base_path": "./docs",
  "sources": [{"name": "docs", "path_pattern": "**/*.md"}]
}
```

**Add document:**
```
POST /pipelines/documents
{"title": "My Doc", "content": "...", "source": "api"}
```

**Run on inline documents:**
```
POST /pipelines/run
{
  "documents": [{"title": "Doc 1", "content": "...", "source": "api"}],
  "chunk_size": 500
}
```

**Status:**
```
GET /pipelines/status
```

Response:
```json
{"chunks": 142, "index": "rak:pipeline:chunks"}
```

**Clear:**
```
DELETE /pipelines
```

## Example Client

```python
import httpx

async with httpx.AsyncClient(base_url="http://localhost:8000") as client:
    # List tasks
    response = await client.get("/tasks", params={"status": "done"})
    tasks = response.json()["tasks"]

    # Get pipeline status
    response = await client.get("/pipelines/status")
    print(f"Chunks: {response.json()['chunks']}")
```

## Error Responses

```json
{"detail": "Task not found"}
```

Status codes:
- `200` – Success
- `201` – Created
- `404` – Not found
- `422` – Validation error
- `500` – Server error

