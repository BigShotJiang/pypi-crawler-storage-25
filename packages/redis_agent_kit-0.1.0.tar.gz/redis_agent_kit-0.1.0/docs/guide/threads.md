# Threads

A **Thread** represents a conversation session. It stores messages, context, and links to associated tasks.

## Creating Threads

```python
from redis_agent_kit import ThreadManager
import redis.asyncio as redis

client = redis.from_url("redis://localhost:6379", decode_responses=True)
thread_manager = ThreadManager(client)

# Create a thread
thread = await thread_manager.create_thread()
print(thread.thread_id)  # "01HXYZ..."

# Create with context
thread = await thread_manager.create_thread(context={
    "user_id": "user_123",
    "session_type": "support",
})
```

## Adding Messages

```python
# Add user message
await thread_manager.add_message(
    thread.thread_id,
    role="user",
    content="What is Redis?",
)

# Add assistant response
await thread_manager.add_message(
    thread.thread_id,
    role="assistant",
    content="Redis is an in-memory data store...",
)
```

## Retrieving Messages

```python
messages = await thread_manager.get_messages(thread.thread_id)
for msg in messages:
    print(f"{msg.role}: {msg.content}")
```

## Context

Store arbitrary data with the thread:

```python
# Set context at creation
thread = await thread_manager.create_thread(context={"user_id": "123"})

# Update context later
await thread_manager.update_context(thread.thread_id, {
    "user_id": "123",
    "premium": True,
    "last_topic": "databases",
})

# Get thread with context
thread = await thread_manager.get_thread(thread.thread_id)
print(thread.context)  # {"user_id": "123", "premium": True, ...}
```

## Thread and Tasks

Threads contain multiple tasks (one per agent turn):

```python
from redis_agent_kit import TaskManager

task_manager = TaskManager(client)

# Create tasks in a thread
task1 = await task_manager.create_task(thread.thread_id, "What is Redis?")
task2 = await task_manager.create_task(thread.thread_id, "How do I install it?")

# Get all tasks for a thread
tasks = await task_manager.get_thread_tasks(thread.thread_id)
```

## Deleting Threads

```python
await thread_manager.delete_thread(thread.thread_id)
```

## Custom Prefix

```python
thread_manager = ThreadManager(client, prefix="myapp")
# Keys: myapp:thread:{id}
```

## Thread Fields

| Field | Type | Description |
|-------|------|-------------|
| `thread_id` | str | Unique ID (ULID) |
| `context` | dict | Arbitrary context data |
| `created_at` | datetime | Creation time |
| `updated_at` | datetime | Last update time |

