# Memory

RAK provides conversation history and long-term recall. Memory is enabled by default.

## Disabling Memory

```bash
export RAK_MEMORY__ENABLED=false
```

## Working Memory (Conversation)

Working memory stores the current conversation:

```python
async def my_agent(ctx):
    # Get recent messages
    messages = await ctx.memory.get_messages(limit=10)
    
    # Add assistant response (usually done by middleware)
    await ctx.memory.add_message(role="assistant", content="Hello!")
    
    # Store arbitrary session data
    await ctx.memory.set_data("user_preference", "dark_mode")
    pref = await ctx.memory.get_data("user_preference")
```

## Long-Term Memory

Search and create persistent memories:

```python
async def my_agent(ctx):
    # Search memories by semantic similarity
    results = await ctx.memory.search(
        "user preferences",
        limit=5,
        memory_type="semantic",
    )
    
    # Create a memory explicitly
    memory_id = await ctx.memory.create_memory(
        "User prefers dark mode",
        memory_type="semantic",
        topics=["preferences"],
    )
```

## Memory as Tools

For agentic control over memory, expose operations as tools. Use the `@tool` decorator for automatic schema generation:

```python
from typing import Annotated
from redis_agent_kit.tools import tool, Param, get_openai_tools

@tool
async def remember(fact: Annotated[str, "What to remember"]) -> dict:
    """Store important information for later."""
    await ctx.memory.create_memory(fact)
    return {"stored": True}

@tool
async def recall(
    query: Annotated[str, "What to search for"],
    limit: Annotated[int, Param(description="Max results", ge=1, le=50)] = 5,
) -> dict:
    """Search for relevant memories."""
    results = await ctx.memory.search(query, limit=limit)
    return {"memories": results}

# Get OpenAI-compatible tool schemas automatically
tools = get_openai_tools(remember, recall)

# Use with OpenAI
response = client.chat.completions.create(
    model="gpt-4",
    messages=messages,
    tools=tools,
)

# Handle tool calls
async def handle_tool_call(name: str, args: dict):
    if name == "remember":
        return await remember.invoke(args)
    elif name == "recall":
        return await recall.invoke(args)
```

The `@tool` decorator automatically generates JSON schemas from:
- `Annotated[type, "description"]` - parameter descriptions inline
- `Annotated[type, Param(...)]` - descriptions plus constraints (`ge`, `le`, `min_length`, `enum`, etc.)
- Docstring - tool description (and fallback for parameter descriptions)
- Type hints - parameter types
- Default values - optional parameters

This lets the LLM decide when to store and recall information.

## MemoryMiddleware

Auto-inject memory context:

```python
from redis_agent_kit import MemoryMiddleware

kit = AgentKit(
    client,
    agent_callable=my_agent,
    middleware=[MemoryMiddleware()],
)
```

Your handler receives `ctx.memory` bound to the session.

## Configuration

```bash
# Enable memory
RAK_MEMORY__ENABLED=true

# Long-term memory settings
RAK_MEMORY__LONG_TERM_ENABLED=true
RAK_MEMORY__SUMMARIZATION_THRESHOLD=10
RAK_MEMORY__ENABLE_EXTRACTION=true

# Forgetting (automatic cleanup)
RAK_MEMORY__FORGETTING_ENABLED=false
RAK_MEMORY__FORGETTING_MAX_AGE_DAYS=90
```

## NoOpMemory

When memory is disabled, `ctx.memory` is a `NoOpMemory` that returns empty results:

```python
memory = NoOpMemory()
await memory.get_messages()  # Returns []
await memory.search("query")  # Returns []
```

This lets you write code that works whether memory is enabled or not.

