# Tutorial: Build a Complete Agent

This tutorial walks through building a production-ready agent from scratch. You'll progressively add features: task management, background processing, a REST API, and multi-protocol support (A2A, ACP, MCP).

**What you'll build:** A research agent that answers questions, tracks its work, and exposes itself via multiple protocols.

**Time:** ~30 minutes

## Prerequisites

- Python 3.10+
- Docker (for Redis)
- An OpenAI API key (for embeddings in later sections)

## Setup

Create a project directory and virtual environment:

```bash
mkdir research-agent && cd research-agent
python -m venv .venv
source .venv/bin/activate
pip install redis-agent-kit[all]
```

Start Redis:
```bash
docker run -d -p 6379:6379 --name redis redis:8
```

## Part 1: Define Your Agent

An agent is just an async function. It receives task context and returns a result:

Create `agent.py`:

```python
async def research_agent(task_id: str, thread_id: str, message: str, context: dict):
    """Your agent: receives a message, returns a result."""
    import asyncio
    await asyncio.sleep(1)  # Simulate work (call LLM, search, etc.)
    return {"answer": f"Research results for: {message}"}
```

That's it. RAK handles everything else: task creation, status tracking, threading, and delivery.

## Part 2: Run Your Agent

Now let's wire it up. You need two things:
1. A **worker** that runs your agent when tasks arrive
2. A **server** that accepts requests and creates tasks

Create `worker.py`:

```python
import redis.asyncio as redis
from redis_agent_kit import AgentKit
from agent import research_agent

client = redis.from_url("redis://localhost:6379", decode_responses=True)
kit = AgentKit(
    client,
    agent_callable=research_agent,
    redis_url="redis://localhost:6379",
    queue_name="research",
)
```

Create `server.py`:

```python
from redis_agent_kit.api import create_app
from worker import kit

app = create_app(kit=kit, redis_url="redis://localhost:6379")
```

Run both in separate terminals:

```bash
# Terminal 1: Start the worker (executes your agent)
rak worker --name research --tasks agent:research_agent

# Terminal 2: Start the API server (accepts requests)
uvicorn server:app --reload
```

Now invoke your agent:

```bash
# Submit a task
curl -X POST http://localhost:8000/tasks \
  -H "Content-Type: application/json" \
  -d '{"message": "What is Redis?"}'
# {"task_id": "01J...", "thread_id": "01J...", "status": "queued"}

# Check status (poll until done)
curl http://localhost:8000/tasks/01J...
# {"task_id": "01J...", "status": "done", "result": {"answer": "Research results for: What is Redis?"}}
```

## Part 3: Add A2A Protocol Support

[A2A](https://github.com/google/A2A) (Agent-to-Agent) is Google's protocol for agent interoperability. Let's expose your agent via A2A so other agents (or any A2A client) can invoke it.

Update `server.py`:

```python
from redis_agent_kit.api import create_app
from redis_agent_kit import AgentCard, Skill
from worker import kit

# A2A Agent Card - describes your agent to other agents
agent_card = AgentCard(
    name="Research Agent",
    description="An agent that researches topics",
    url="http://localhost:8000",
    skills=[
        Skill(id="research", name="Research", description="Research any topic"),
    ],
)

app = create_app(
    kit=kit,
    redis_url="redis://localhost:6379",
    enable_a2a=True,
    agent_card=agent_card,
)
```

Restart the server and test A2A:

```bash
# Discover agent
curl http://localhost:8000/.well-known/agent.json
```

Response:
```json
{
  "name": "Research Agent",
  "description": "An agent that researches topics",
  "url": "http://localhost:8000",
  "skills": [{"id": "research", "name": "Research", "description": "Research any topic"}]
}
```

Send an A2A message (JSON-RPC):
```bash
curl -X POST http://localhost:8000 \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "message/send",
    "params": {"message": {"role": "user", "parts": [{"type": "text", "text": "What is Redis?"}]}},
    "id": 1
  }'
```

## Part 5: Add ACP Protocol Support

[ACP](https://github.com/i-am-bee/acp) (Agent Communication Protocol) is BeeAI's REST-based protocol. Add it alongside A2A so clients can invoke your agent using either protocol.

Update `server.py`:

```python
from redis_agent_kit.api import create_app
from redis_agent_kit import AgentCard, AgentManifest, Skill
from worker import kit

# A2A Agent Card
agent_card = AgentCard(
    name="Research Agent",
    description="An agent that researches topics",
    url="http://localhost:8000",
    skills=[Skill(id="research", name="Research", description="Research any topic")],
)

# ACP Agent Manifest
agent_manifest = AgentManifest(
    name="research-agent",  # RFC 1123 DNS label format
    description="An agent that researches topics",
)

app = create_app(
    kit=kit,
    redis_url="redis://localhost:6379",
    enable_a2a=True,
    enable_acp=True,
    agent_card=agent_card,
    agent_manifest=agent_manifest,
)
```

Test ACP:

```bash
# Discover agents
curl http://localhost:8000/agents

# Create a run
curl -X POST http://localhost:8000/runs \
  -H "Content-Type: application/json" \
  -d '{"input": [{"role": "user", "content": "What is Redis?"}]}'

# Check run status (replace {run_id})
curl http://localhost:8000/runs/{run_id}
```

## Part 6: Add MCP Server

[MCP](https://modelcontextprotocol.io) (Model Context Protocol) lets AI assistants use your agent as a tool.

Create `mcp_server.py`:

```python
from redis_agent_kit.mcp import create_server

server = create_server(
    redis_url="redis://localhost:6379",
    name="research-agent",
)
```

Run:
```bash
fastmcp run mcp_server.py
```

The MCP server exposes tools like `list_tasks`, `get_task`, and `pipeline_search`.

## Part 7: Observe the Worker

Let's see everything working together. You should have:

1. **Terminal 1 - Worker** (runs your agent):
```bash
rak worker --name research --tasks agent:research_agent
```

2. **Terminal 2 - Server** (exposes your agent via HTTP):
```bash
uvicorn server:app --reload
```

3. **Terminal 3 - Client** (invokes your agent):

```bash
# Invoke the agent via A2A
curl -X POST http://localhost:8000 \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "method": "message/send",
    "params": {"message": {"role": "user", "parts": [{"type": "text", "text": "What is Redis?"}]}},
    "id": 1
  }'
```

In Terminal 1 (worker), you'll see your agent process the task:
```
Processing task 01HXYZ...
Task completed: {'answer': 'Research results for: What is Redis?'}
```

Check task status:
```bash
curl http://localhost:8000/tasks | jq
```

## Summary

You've built an agent that:
- ✅ Runs in a background worker
- ✅ Is invoked via tasks submitted by clients
- ✅ Exposes a REST API
- ✅ Supports A2A and ACP protocols (so other agents can invoke it)
- ✅ Provides an MCP server (so AI assistants can use it as a tool)

## Next Steps

- Add [RAG pipelines](guide/pipelines.md) for knowledge base search
- Use [middleware](guide/middleware.md) for cross-cutting concerns
- Implement [input handling](guide/input.md) to pause for user decisions
- See the [CLI reference](guide/cli.md) for all commands

