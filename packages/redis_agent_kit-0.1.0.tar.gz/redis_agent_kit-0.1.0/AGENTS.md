# AI Agent Guidelines for Redis Agent Kit

This file helps AI assistants understand the redis-agent-kit codebase structure.

## ⚠️ Experimental Status

**This repository is experimental and under active development.**

- **No backwards compatibility required** - break things freely
- **No deprecation warnings needed** - just remove/replace code
- **Move fast** - refactor aggressively without leaving legacy cruft
- **Delete freely** - if something is wrong, remove it entirely

When refactoring:
- Don't add deprecation warnings or shims
- Don't preserve old APIs "for compatibility"
- Just make the change and update all call sites
- Delete obsolete code, tests, and docs

## Quick Reference

### Where to Find Things

| Feature | Location | Notes |
|---------|----------|-------|
| Task/Thread management | `redis_agent_kit/core.py` | TaskManager, ThreadManager, AgentKit |
| Task Middleware | `redis_agent_kit/middleware.py` | TaskContext, EmitterMiddleware, RAGMiddleware, etc. |
| Pipeline Middleware | `redis_agent_kit/middleware.py` | PipelineContext, PipelineLoggingMiddleware, etc. |
| Protocol Adapters | `redis_agent_kit/protocols/` | A2A, ACP adapters and routers |
| Pipeline API endpoints | `redis_agent_kit/api/pipelines.py` | `/pipelines/*` routes |
| Streaming config | `redis_agent_kit/streaming.py` | StreamConfig, ChannelScope |
| Task API endpoints | `redis_agent_kit/api/tasks.py` | `/tasks/*`, `/sessions/*/stream`, `/stream/global` |
| CLI commands | `redis_agent_kit/cli/` | `rak` command |
| MCP tools | `redis_agent_kit/mcp/` | Model Context Protocol server |
| Data pipelines | `redis_agent_kit/pipelines/` | Ingestion, chunking, vectorization |
| Examples | `examples/` | OpenAI Agents SDK, LangGraph |

## Streaming & SSE Configuration

Real-time streaming is controlled by `StreamConfig` (replaces the old `enable_sse` / `enable_streaming` booleans):

```python
from redis_agent_kit import AgentKit, StreamConfig, ChannelScope

# Minimal – per-task SSE only
kit = AgentKit("redis://localhost:6379", stream_config=StreamConfig(enabled=True))

# Session-scoped (one EventSource per chat session)
kit = AgentKit(
    "redis://localhost:6379",
    stream_config=StreamConfig(
        enabled=True,
        channels={ChannelScope.TASK, ChannelScope.SESSION},
    ),
)

# Global dashboard + event filtering (only tokens and terminal events)
kit = AgentKit(
    "redis://localhost:6379",
    stream_config=StreamConfig(
        enabled=True,
        channels={ChannelScope.TASK, ChannelScope.SESSION, ChannelScope.GLOBAL},
        publish_events={"token", "done", "failed", "cancelled"},
    ),
)
```

**SSE Endpoints (when streaming is enabled):**

| Endpoint | Description |
|----------|-------------|
| `GET /tasks/{task_id}/stream` | Per-task updates (supports `?replay=true` and `?events=token,done`) |
| `GET /sessions/{session_id}/stream` | All tasks in a session (`?events=` filter supported) |
| `GET /stream/global` | All events globally (`?events=` filter supported) |

**StreamConfig options:**
- `enabled` – master switch (default: `False`)
- `channels` – set of `ChannelScope` values controlling fan-out (default: `{TASK}`)
- `publish_events` – set of event types to publish; `None` = all (default: `None`)
- `persist_events` – set of event types to persist to task state; `None` = default behaviour where tokens are ephemeral

Legacy `enable_sse=True` / `enable_streaming=True` still work and map to `StreamConfig(enabled=True)`.

## Non-Obvious Features

### 1. Pipeline API Already Exists

The REST API includes full pipeline endpoints - no need to duplicate:

```bash
POST /pipelines/prepare   # Stage 1: Scan, parse, chunk
POST /pipelines/ingest    # Stage 2: Vectorize, store
POST /pipelines/full      # Both stages at once
POST /pipelines/documents # Add single document
GET  /pipelines/status    # Get chunk count
```

See `redis_agent_kit/api/pipelines.py` for implementation.

### 2. Middleware Reduces Boilerplate

Instead of manually handling emitters, RAG context, threads, and results:

```python
from redis_agent_kit import (
    AgentKit, TaskContext,
    EmitterMiddleware, RAGMiddleware, ThreadMiddleware, ResultMiddleware,
)

async def my_handler(ctx: TaskContext) -> dict:
    # ctx.rag_context is already populated by RAGMiddleware
    # ctx.emitter is ready to use
    return {"response": "..."}  # ThreadMiddleware saves, ResultMiddleware sets status

kit = AgentKit(
    client,
    agent_callable=my_handler,
    middleware=[ResultMiddleware(), EmitterMiddleware(), RAGMiddleware(), ThreadMiddleware()],
)
```

### 3. AgentKit Bundles Everything

`AgentKit` provides access to all managers:

```python
kit = AgentKit(client)
kit.task_manager    # TaskManager instance
kit.thread_manager  # ThreadManager instance
kit.get_emitter(task_id)  # TaskEmitter for progress updates
```

### 4. Two-Stage Pipeline Architecture

The pipeline has two stages for flexibility:

1. **Prepare Stage** (`PipelineOrchestrator.prepare()`)
   - Scans files, parses frontmatter, chunks documents
   - Stores artifacts to disk (JSON files)
   - Returns `batch_id` for later ingestion

2. **Ingest Stage** (`PipelineOrchestrator.ingest(batch_id)`)
   - Loads artifacts from disk
   - Vectorizes chunks, stores in Redis
   - Handles deduplication

This allows review/modification between stages.

### 5. Pipeline Middleware

Pipelines support middleware for cross-cutting concerns:

```python
from redis_agent_kit import (
    PipelineLoggingMiddleware,
    PipelineTimingMiddleware,
    PipelineValidationMiddleware,
)
from redis_agent_kit.pipelines import PipelineOrchestrator

orchestrator = PipelineOrchestrator(
    config=config,
    base_path=docs_path,
    middleware=[PipelineLoggingMiddleware(), PipelineTimingMiddleware()],
)

# Use async methods with middleware
batch_id = await orchestrator.prepare_async()
manifest = await orchestrator.ingest_async(batch_id)
```

### 6. API/MCP Customization via kwargs

Both `create_app()` and `create_server()` pass kwargs to their underlying frameworks:

```python
# FastAPI customization
app = create_app(title="Custom API", docs_url="/api/docs")

# FastMCP customization
server = create_server(name="custom-server", instructions="...")
```

### 7. Vector Store Search

```python
from redis_agent_kit.pipelines import VectorStore, Vectorizer

vectorizer = Vectorizer()
vector_store = VectorStore(client, vectorizer)
results = await vector_store.search("query", limit=5)
# Returns list of SearchResult with content, metadata, score
```

### 8. Multi-Protocol Support (A2A, ACP, REST)

Redis Agent Kit supports multiple agent communication protocols:

```python
from redis_agent_kit import AgentKit, AgentCard, AgentManifest, Skill
from redis_agent_kit.protocols import (
    create_multi_protocol_app,
    ProtocolConfig,
)

kit = AgentKit(client)

# A2A Agent Card (for /.well-known/agent.json)
agent_card = AgentCard(
    name="My Agent",
    description="A helpful assistant",
    url="http://localhost:8000",
    skills=[Skill(id="chat", name="Chat", description="General chat")],
)

# ACP Agent Manifest (for /agents)
agent_manifest = AgentManifest(
    name="my-agent",  # RFC 1123 DNS label format
    description="A helpful assistant",
)

# Create unified server with all protocols
config = ProtocolConfig(enable_a2a=True, enable_acp=True, enable_rest=True)
app = create_multi_protocol_app(
    kit=kit,
    config=config,
    agent_card=agent_card,
    agent_manifest=agent_manifest,
)
```

Or add protocols to existing `create_app()`:

```python
from redis_agent_kit.api import create_app

app = create_app(
    enable_a2a=True,
    enable_acp=True,
    agent_card=agent_card,
    agent_manifest=agent_manifest,
    kit=kit,
)
```

**Protocol Endpoints:**
- A2A: `/.well-known/agent.json` (discovery), `/` (JSON-RPC)
- ACP: `/agents` (discovery), `/runs` (REST)
- REST: `/tasks/*`, `/pipelines/*`

## Testing Patterns

- All tests use `pytest` with `pytest-asyncio`
- Redis is mocked with `fakeredis`
- Coverage requirement: 99%+
- Run tests: `pytest tests/ --cov=redis_agent_kit`

## Key Models

```python
from redis_agent_kit import (
    Task, TaskStatus, TaskUpdate,  # Task models
    Thread, Message,               # Thread models
    TaskContext,                   # Middleware context
    AgentCard, AgentManifest,      # Protocol discovery
    Skill, Capability,             # Agent capabilities
    StreamConfig, ChannelScope,    # Streaming configuration
)

from redis_agent_kit.pipelines import (
    Document, Chunk, SearchResult,  # Pipeline models
    PipelineConfig, SourceConfig,   # Configuration
)

from redis_agent_kit.protocols import (
    A2AAdapter, ACPAdapter,         # Protocol adapters
    ProtocolConfig,                 # Protocol configuration
    create_multi_protocol_app,      # Unified server factory
)
```

## Common Patterns

### Creating a Task Handler with Middleware

```python
async def handler(ctx: TaskContext) -> dict:
    await ctx.emitter.emit("Working...")
    # Use ctx.message, ctx.rag_context, ctx.context
    return {"response": "..."}
```

### Extending the API

```python
from redis_agent_kit.api import create_app

app = create_app(redis_url="redis://localhost:6379")

@app.post("/my-endpoint")
async def my_endpoint():
    # Access kit via app.state after setup
    pass
```

### Running Background Tasks

```python
kit = AgentKit(client, agent_callable=handler, redis_url="redis://...")
result = await kit.create_and_submit_task(message="Hello")
# Start worker: rak worker --name my_queue
```

