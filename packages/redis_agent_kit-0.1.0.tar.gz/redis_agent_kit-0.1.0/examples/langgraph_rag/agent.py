"""Example 3: LangGraph RAG Agent.

A RAG agent using LangGraph for structured workflow. Demonstrates:
- LangGraph StateGraph with retrieve/generate nodes
- Integration with RAK middleware
- Typed state management

Usage:
    export OPENAI_API_KEY=sk-...
    python -m examples.rag_agent.agent ingest   # Index documents first
    python -m examples.langgraph_rag.agent serve

    curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
        -d '{"message": "What is vector search?"}'
"""

import sys
from pathlib import Path
from typing import Any, TypedDict

import uvicorn
from dotenv import load_dotenv
from fastapi import Request
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph
from pydantic import BaseModel

from redis_agent_kit import AgentKit, EmitterMiddleware, RAGMiddleware
from redis_agent_kit.api import create_app

load_dotenv(Path(__file__).parent.parent.parent / ".env")


class AgentState(TypedDict):
    """State for the LangGraph agent."""

    question: str
    context: str
    response: str


llm = ChatOpenAI(model="gpt-4o-mini")


async def generate(state: AgentState) -> AgentState:
    """Generate response using LLM."""
    prompt = f"""Answer the question based on the context.

Context:
{state['context']}

Question: {state['question']}"""

    response = await llm.ainvoke(prompt)
    return {
        "question": state["question"],
        "context": state["context"],
        "response": response.content,
    }


def _build_graph():
    """Build and compile the graph."""
    graph = StateGraph(AgentState)
    graph.add_node("generate", generate)
    graph.set_entry_point("generate")
    graph.add_edge("generate", END)
    return graph.compile()


_compiled_graph = _build_graph()


async def run_agent(ctx) -> dict[str, Any]:
    """LangGraph agent handler.

    RAG context is injected by RAGMiddleware and passed via state.
    """
    await ctx.emitter.emit("Running LangGraph workflow...")

    result = await _compiled_graph.ainvoke({
        "question": ctx.message,
        "context": ctx.rag_context,
        "response": "",
    })

    return {"response": result["response"]}


def _create_kit():
    """Create AgentKit for worker and server."""
    return AgentKit(
        agent_callable=run_agent,
        middleware=[EmitterMiddleware(), RAGMiddleware(limit=3)],
        queue_name="langgraph_rag",
    )


_kit = _create_kit()
tasks = [_kit.worker_task]


def serve():
    """Start the API server."""

    class ChatRequest(BaseModel):
        message: str
        session_id: str | None = None

    kit = _create_kit()
    app = create_app(kit=kit)

    @app.post("/chat")
    async def chat(request: Request, body: ChatRequest):
        return await kit.create_and_submit_task(
            message=body.message, session_id=body.session_id
        )

    print("Starting LangGraph RAG server on http://localhost:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m examples.langgraph_rag.agent serve")
        sys.exit(1)

    if sys.argv[1] == "serve":
        serve()
    else:
        print(f"Unknown command: {sys.argv[1]}")
        sys.exit(1)


if __name__ == "__main__":
    main()

