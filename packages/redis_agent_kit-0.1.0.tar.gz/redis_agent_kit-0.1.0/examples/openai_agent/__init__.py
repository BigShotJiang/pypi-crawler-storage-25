"""OpenAI Agents SDK example with Redis Agent Kit."""
