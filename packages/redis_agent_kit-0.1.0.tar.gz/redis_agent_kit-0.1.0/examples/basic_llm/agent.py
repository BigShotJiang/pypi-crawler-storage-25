"""Example 1: Basic LLM Agent with Redis Agent Kit.

A minimal agent that responds using an LLM. Demonstrates:
- AgentKit setup with task handlers
- Middleware for task lifecycle management
- Async task execution via Docket

Usage:
    export OPENAI_API_KEY=sk-...
    python -m examples.basic_llm.agent serve

    # In another terminal, start the worker:
    rak worker --name basic_llm --tasks examples.basic_llm.agent:tasks

    # Then send a request:
    curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
        -d '{"message": "What is Redis?"}'
"""

import sys
from pathlib import Path
from typing import Any

import uvicorn
from dotenv import load_dotenv
from fastapi import Request
from openai import AsyncOpenAI
from pydantic import BaseModel

from redis_agent_kit import AgentKit, EmitterMiddleware
from redis_agent_kit.api import create_app

load_dotenv(Path(__file__).parent.parent.parent / ".env")


async def run_agent(ctx) -> dict[str, Any]:
    """Simple LLM agent handler.

    Args:
        ctx: TaskContext with task_id, session_id, message, emitter, memory
    """
    client = AsyncOpenAI()

    await ctx.emitter.emit("Generating response...")

    response = await client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": ctx.message},
        ],
    )

    return {"response": response.choices[0].message.content}


def _create_kit():
    """Create AgentKit for worker and server."""
    return AgentKit(
        agent_callable=run_agent,
        middleware=[EmitterMiddleware(start_message="Processing...")],
        queue_name="basic_llm",
    )


# Task collection for Docket worker
_kit = _create_kit()
tasks = [_kit.worker_task]


def serve():
    """Start the API server."""

    class ChatRequest(BaseModel):
        message: str
        session_id: str | None = None

    kit = _create_kit()
    app = create_app(kit=kit)

    @app.post("/chat")
    async def chat(request: Request, body: ChatRequest):
        """Create a chat task."""
        return await kit.create_and_submit_task(
            message=body.message, session_id=body.session_id
        )

    print("Starting server on http://localhost:8000")
    print("POST /chat - Send a message")
    print("GET /tasks/{task_id} - Check task status")
    uvicorn.run(app, host="0.0.0.0", port=8000)


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m examples.basic_llm.agent serve")
        sys.exit(1)

    if sys.argv[1] == "serve":
        serve()
    else:
        print(f"Unknown command: {sys.argv[1]}")
        sys.exit(1)


if __name__ == "__main__":
    main()

