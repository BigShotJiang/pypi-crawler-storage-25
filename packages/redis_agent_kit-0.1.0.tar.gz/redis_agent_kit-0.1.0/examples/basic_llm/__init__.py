"""Basic LLM agent example."""

