"""Multi-tool agent example with MCP, REST, and ACP exposure."""

