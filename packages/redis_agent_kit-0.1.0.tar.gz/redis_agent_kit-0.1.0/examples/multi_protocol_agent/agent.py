"""Example: Multi-Protocol Agent with REST, A2A, and ACP.

A simple agent exposed through multiple protocol interfaces.
Demonstrates:
- REST API endpoint
- A2A protocol for agent discovery
- ACP protocol for agent-to-agent communication

Usage:
    export OPENAI_API_KEY=sk-...
    python -m examples.multi_protocol_agent.agent serve

Endpoints:
    REST:
        POST /chat - Chat with the agent
        GET /tasks/{task_id} - Check task status

    A2A:
        GET /.well-known/agent.json - Agent discovery
        POST / - JSON-RPC (message/send, tasks/get)

    ACP:
        GET /agents - Agent manifest
        POST /runs - Create run
        GET /runs/{run_id} - Get run status
"""

import sys
from pathlib import Path
from typing import Any

import uvicorn
from dotenv import load_dotenv
from fastapi import Request
from openai import AsyncOpenAI
from pydantic import BaseModel

from redis_agent_kit import (
    AgentCard,
    AgentKit,
    AgentManifest,
    EmitterMiddleware,
    Skill,
)
from redis_agent_kit.api import create_app

load_dotenv(Path(__file__).parent.parent.parent / ".env")


async def run_agent(ctx) -> dict[str, Any]:
    """Simple chat agent."""
    client = AsyncOpenAI()

    await ctx.emitter.emit("Generating response...")

    response = await client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": ctx.message},
        ],
    )

    return {"response": response.choices[0].message.content}


def _create_kit():
    """Create AgentKit for worker and server."""
    return AgentKit(
        agent_callable=run_agent,
        middleware=[EmitterMiddleware()],
        queue_name="multi_protocol",
    )


# Export for worker: rak worker --tasks examples.multi_protocol_agent.agent:tasks
_kit = _create_kit()
tasks = [_kit.worker_task]


def serve():
    """Start the multi-protocol API server."""

    class ChatRequest(BaseModel):
        message: str
        session_id: str | None = None

    agent_card = AgentCard(
        name="Multi-Protocol Agent",
        description="A simple agent accessible via multiple protocols",
        url="http://localhost:8000",
        skills=[Skill(id="chat", name="Chat", description="General chat")],
    )

    agent_manifest = AgentManifest(
        name="multi-protocol-agent",
        description="A simple agent accessible via multiple protocols",
    )

    kit = _create_kit()
    app = create_app(
        kit=kit,
        enable_a2a=True,
        enable_acp=True,
        agent_card=agent_card,
        agent_manifest=agent_manifest,
    )

    @app.post("/chat")
    async def chat(request: Request, body: ChatRequest):
        return await kit.create_and_submit_task(message=body.message, session_id=body.session_id)

    print("Starting Multi-Protocol Agent on http://localhost:8000")
    print("\nEndpoints:")
    print("  REST: POST /chat")
    print("  A2A:  GET /.well-known/agent.json, POST /")
    print("  ACP:  GET /agents, POST /runs")
    uvicorn.run(app, host="0.0.0.0", port=8000)


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m examples.multi_protocol_agent.agent serve")
        sys.exit(1)

    if sys.argv[1] == "serve":
        serve()


if __name__ == "__main__":
    main()

