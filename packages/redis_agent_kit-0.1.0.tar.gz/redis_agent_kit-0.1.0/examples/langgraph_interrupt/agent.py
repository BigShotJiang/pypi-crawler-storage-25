"""Example 4: LangGraph Interrupt with Pause/Resume.

An agent that uses LangGraph's interrupt feature combined with RAK's
pause/resume input mechanism. Demonstrates:
- LangGraph interrupt_before for human-in-the-loop
- RAK's await_input/submit_input for task pausing
- Resumable workflows with user confirmation
- @side_effect decorator for caching expensive operations across re-runs

When a task pauses for input and resumes, the handler runs from the beginning.
The @side_effect decorator caches the LLM analysis so it's not repeated.

Usage:
    export OPENAI_API_KEY=sk-...
    python -m examples.langgraph_interrupt.agent serve

    # Create a task
    curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
        -d '{"message": "Delete all user data"}'

    # Check status - will be AWAITING_INPUT
    curl http://localhost:8000/tasks/{task_id}

    # Submit confirmation
    curl -X POST http://localhost:8000/tasks/{task_id}/input \
        -H "Content-Type: application/json" \
        -d '{"response": {"confirm": true}}'
"""

import sys
from pathlib import Path
from typing import Any, Literal, TypedDict

import redis.asyncio as redis_lib
import uvicorn
from dotenv import load_dotenv
from fastapi import Request
from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph
from pydantic import BaseModel

from redis_agent_kit import AgentKit, EmitterMiddleware, side_effect
from redis_agent_kit.api import create_app

load_dotenv(Path(__file__).parent.parent.parent / ".env")


class AgentState(TypedDict):
    """State for the interrupt agent."""

    request: str
    action: str
    confirmed: bool | None
    result: str


llm = ChatOpenAI(model="gpt-4o-mini")

# Redis client for side effects - initialized at startup
_redis_client: redis_lib.Redis | None = None


async def _analyze_request(request: str) -> str:
    """Analyze a request with the LLM. Cached via @side_effect.

    This function is decorated with @side_effect(store_result=True) so that
    when the task resumes after user input, the LLM call is not repeated.
    The cached result is returned instead.
    """
    prompt = f"""Analyze this request and determine if it's a dangerous action.
Request: {request}

Respond with just the action type: 'safe' or 'dangerous'"""

    response = await llm.ainvoke(prompt)
    return response.content.strip().lower()


async def analyze(state: AgentState) -> AgentState:
    """Analyze the request and determine action."""
    # Use side_effect to cache the LLM call across task re-runs
    if _redis_client is not None:
        # Create a side_effect-wrapped version with the current redis client
        cached_analyze = side_effect(
            store_result=True, redis_client=_redis_client
        )(_analyze_request)
        action = await cached_analyze(state["request"])
    else:
        # Fallback if redis client not available
        action = await _analyze_request(state["request"])

    return {**state, "action": action}


async def confirm(state: AgentState) -> AgentState:
    """Confirmation node - this is where we pause for user input."""
    # This node is interrupted before execution
    # The actual confirmation happens via RAK's submit_input
    return state


async def execute(state: AgentState) -> AgentState:
    """Execute the action."""
    if state.get("confirmed"):
        result = f"Executed: {state['request']}"
    else:
        result = "Action cancelled by user."
    return {**state, "result": result}


def route_action(state: AgentState) -> Literal["confirm", "execute"]:
    """Route based on action type."""
    if state["action"] == "dangerous":
        return "confirm"
    return "execute"


def _build_graph():
    """Build and compile the graph."""
    graph = StateGraph(AgentState)
    graph.add_node("analyze", analyze)
    graph.add_node("confirm", confirm)
    graph.add_node("execute", execute)

    graph.set_entry_point("analyze")
    graph.add_conditional_edges("analyze", route_action)
    graph.add_edge("confirm", "execute")
    graph.add_edge("execute", END)

    return graph.compile(interrupt_before=["confirm"])


_compiled_graph = _build_graph()


async def run_agent(ctx) -> dict[str, Any]:
    """LangGraph interrupt agent handler."""
    await ctx.emitter.emit("Analyzing request...")

    task = await ctx.kit.task_manager.get_task(ctx.task_id)

    # Check if we're resuming from an interrupt
    if task.input_response and task.input_response.get("confirm") is not None:
        # Resume with user's confirmation - skip the graph and execute directly
        confirmed = task.input_response.get("confirm", False)
        result = f"Executed: {ctx.message}" if confirmed else "Action cancelled by user."
        return {"response": result}

    # First run - analyze and potentially interrupt
    state = {"request": ctx.message, "action": "", "confirmed": None, "result": ""}
    result = await _compiled_graph.ainvoke(
        state, config={"configurable": {"thread_id": ctx.task_id}}
    )

    # Check if we hit the interrupt (no result means interrupted)
    if not result.get("result") and result.get("action") == "dangerous":
        # Request user confirmation via RAK's pause mechanism
        await ctx.kit.task_manager.request_input(
            task_id=ctx.task_id,
            prompt=f"This action appears dangerous: '{ctx.message}'. Do you want to proceed?",
            json_schema={
                "type": "object",
                "properties": {"confirm": {"type": "boolean"}},
                "required": ["confirm"],
            },
        )
        return {"response": "Awaiting user confirmation..."}

    return {"response": result.get("result", "Action completed.")}


def _create_kit(redis_client: redis_lib.Redis | None = None):
    """Create AgentKit for worker and server."""
    return AgentKit(
        redis_client=redis_client,
        agent_callable=run_agent,
        middleware=[EmitterMiddleware()],
        queue_name="langgraph_interrupt",
    )


_kit = _create_kit()
tasks = [_kit.worker_task]


def serve():
    """Start the API server."""
    global _redis_client

    class ChatRequest(BaseModel):
        message: str
        session_id: str | None = None

    # Create client for side_effect caching
    _redis_client = redis_lib.from_url("redis://localhost:6379")
    kit = _create_kit(redis_client=_redis_client)
    app = create_app(kit=kit)

    @app.post("/chat")
    async def chat(request: Request, body: ChatRequest):
        return await kit.create_and_submit_task(
            message=body.message, session_id=body.session_id
        )

    print("Starting LangGraph Interrupt server on http://localhost:8000")
    print("POST /chat - Send a message")
    print("GET /tasks/{task_id} - Check status")
    print("POST /tasks/{task_id}/input - Submit confirmation")
    uvicorn.run(app, host="0.0.0.0", port=8000)


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m examples.langgraph_interrupt.agent serve")
        sys.exit(1)

    if sys.argv[1] == "serve":
        serve()


if __name__ == "__main__":
    main()

