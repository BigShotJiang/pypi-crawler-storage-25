"""Example 5: RAG Agent with Long-Term Memory.

An agent that combines knowledge search with long-term memory. Demonstrates:
- RAGMiddleware for document context
- MemoryMiddleware for conversation history
- Memory.search() for semantic memory retrieval
- Personalized responses based on past interactions

Usage:
    export OPENAI_API_KEY=sk-...
    export RAK_MEMORY__ENABLED=true
    python -m examples.rag_agent.agent ingest   # Index documents first
    python -m examples.rag_with_memory.agent serve

    # First conversation
    curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
        -d '{"message": "My name is Alice and I work on Redis caching", "session_id": "alice-123"}'

    # Later conversation - agent remembers
    curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
        -d '{"message": "What caching patterns would help my work?", "session_id": "alice-123"}'
"""

import sys
from pathlib import Path
from typing import Any

import uvicorn
from dotenv import load_dotenv
from fastapi import Request
from openai import AsyncOpenAI
from pydantic import BaseModel

from redis_agent_kit import (
    AgentKit,
    EmitterMiddleware,
    MemoryMiddleware,
    RAGMiddleware,
)
from redis_agent_kit.api import create_app

load_dotenv(Path(__file__).parent.parent.parent / ".env")


async def run_agent(ctx) -> dict[str, Any]:
    """RAG + Memory agent handler.

    Args:
        ctx: TaskContext with:
            - rag_context: Document context from RAGMiddleware
            - memory: Bound Memory instance for this session
    """
    client = AsyncOpenAI()

    await ctx.emitter.emit("Retrieving conversation history...")

    # Get recent conversation history
    messages = await ctx.memory.get_messages(limit=10)
    history = "\n".join([f"{m['role']}: {m['content']}" for m in messages])

    # Search memory for relevant past context
    await ctx.emitter.emit("Searching long-term memory...")
    memory_results = await ctx.memory.search(ctx.message, limit=3)
    memory_context = "\n".join([r.get("content", "") for r in memory_results])

    await ctx.emitter.emit("Generating response...")

    system_prompt = f"""You are a helpful assistant with access to:
1. A knowledge base about Redis
2. The user's conversation history
3. Long-term memory of past interactions

Knowledge Base Context:
{ctx.rag_context}

Conversation History:
{history}

Relevant Past Memories:
{memory_context}

Use all available context to provide personalized, relevant responses.
Remember details the user has shared about themselves."""

    response = await client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": ctx.message},
        ],
    )

    answer = response.choices[0].message.content

    # Store the interaction in memory
    await ctx.memory.add_message(role="assistant", content=answer)

    return {"response": answer}


def _create_kit():
    """Create AgentKit for worker and server."""
    return AgentKit(
        agent_callable=run_agent,
        middleware=[
            EmitterMiddleware(start_message="Processing..."),
            RAGMiddleware(),
            MemoryMiddleware(),
        ],
        queue_name="rag_memory",
    )


# Export for worker: rak worker --tasks examples.rag_with_memory.agent:tasks
_kit = _create_kit()
tasks = [_kit.worker_task]


def serve():
    """Start the API server."""

    class ChatRequest(BaseModel):
        message: str
        session_id: str | None = None
        user_id: str | None = None

    kit = _create_kit()
    app = create_app(kit=kit)

    @app.post("/chat")
    async def chat(request: Request, body: ChatRequest):
        return await kit.create_and_submit_task(
            message=body.message,
            session_id=body.session_id,
            user_id=body.user_id,
        )

    print("Starting RAG + Memory server on http://localhost:8000")
    print("Note: Set RAK_MEMORY__ENABLED=true for memory features")
    uvicorn.run(app, host="0.0.0.0", port=8000)


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m examples.rag_with_memory.agent serve")
        sys.exit(1)

    if sys.argv[1] == "serve":
        serve()


if __name__ == "__main__":
    main()

