"""LangGraph example with Redis Agent Kit."""
