"""Tests for Redis Agent Kit data models."""

from datetime import UTC, datetime

import pytest
from pydantic import ValidationError

from redis_agent_kit.models import (
    AgentCard,
    AgentManifest,
    AgentMetadata,
    Caller,
    CallerType,
    Capability,
    InputRequest,
    Message,
    Skill,
    TaskState,
    TaskStatus,
    TaskUpdate,
    Thread,
)


class TestTaskStatus:
    """Tests for TaskStatus enum."""

    def test_all_statuses_exist(self):
        """Verify all expected statuses are defined."""
        assert TaskStatus.QUEUED == "queued"
        assert TaskStatus.IN_PROGRESS == "in_progress"
        assert TaskStatus.AWAITING_INPUT == "awaiting_input"
        assert TaskStatus.DONE == "done"
        assert TaskStatus.FAILED == "failed"
        assert TaskStatus.CANCELLED == "cancelled"

    def test_status_values_are_strings(self):
        """Status values should be lowercase strings."""
        for status in TaskStatus:
            assert isinstance(status.value, str)
            assert status.value == status.value.lower()


class TestCallerType:
    """Tests for CallerType enum."""

    def test_all_types_exist(self):
        """Verify all expected caller types are defined."""
        assert CallerType.HUMAN == "human"
        assert CallerType.AGENT == "agent"


class TestCaller:
    """Tests for Caller model."""

    def test_create_with_defaults(self):
        """Create Caller with default values."""
        caller = Caller()
        assert caller.type == CallerType.HUMAN
        assert caller.id is None
        assert caller.name is None
        assert caller.metadata == {}

    def test_create_human_caller(self):
        """Create a human caller with all fields."""
        caller = Caller(
            type=CallerType.HUMAN,
            id="user-123",
            name="John Doe",
            metadata={"source": "web"},
        )
        assert caller.type == CallerType.HUMAN
        assert caller.id == "user-123"
        assert caller.name == "John Doe"
        assert caller.metadata == {"source": "web"}

    def test_create_agent_caller(self):
        """Create an agent caller."""
        caller = Caller(
            type=CallerType.AGENT,
            id="research-agent",
            name="Research Agent",
            metadata={"protocol": "a2a"},
        )
        assert caller.type == CallerType.AGENT
        assert caller.id == "research-agent"
        assert caller.name == "Research Agent"
        assert caller.metadata == {"protocol": "a2a"}


class TestTaskUpdate:
    """Tests for TaskUpdate model."""

    def test_create_with_required_fields(self):
        """Create TaskUpdate with only required fields."""
        update = TaskUpdate(message="Processing...")
        assert update.message == "Processing..."
        assert update.update_type == "info"
        assert update.metadata == {}
        assert isinstance(update.timestamp, datetime)

    def test_create_with_all_fields(self):
        """Create TaskUpdate with all fields."""
        ts = datetime.now(UTC)
        update = TaskUpdate(
            timestamp=ts,
            message="Found 5 results",
            update_type="tool_call",
            metadata={"tool": "search", "count": 5},
        )
        assert update.timestamp == ts
        assert update.message == "Found 5 results"
        assert update.update_type == "tool_call"
        assert update.metadata == {"tool": "search", "count": 5}

    def test_timestamp_auto_generated(self):
        """Timestamp should be auto-generated if not provided."""
        before = datetime.now(UTC)
        update = TaskUpdate(message="Test")
        after = datetime.now(UTC)
        assert before <= update.timestamp <= after


class TestTaskState:
    """Tests for TaskState model."""

    def test_create_with_required_fields(self):
        """Create TaskState with required fields only."""
        state = TaskState(
            task_id="01ARZ3NDEKTSV4RRFFQ69G5FAV",
            session_id="01ARZ3NDEKTSV4RRFFQ69G5FAW",
        )
        assert state.task_id == "01ARZ3NDEKTSV4RRFFQ69G5FAV"
        assert state.session_id == "01ARZ3NDEKTSV4RRFFQ69G5FAW"
        assert state.status == TaskStatus.QUEUED
        assert state.updates == []
        assert state.result is None
        assert state.error_message is None
        assert state.metadata == {}

    def test_create_with_all_fields(self):
        """Create TaskState with all fields."""
        ts = datetime.now(UTC)
        state = TaskState(
            task_id="task123",
            session_id="session456",
            status=TaskStatus.DONE,
            updates=[TaskUpdate(message="Done")],
            result={"answer": "42"},
            error_message=None,
            metadata={"user_id": "user789"},
            created_at=ts,
            updated_at=ts,
        )
        assert state.status == TaskStatus.DONE
        assert len(state.updates) == 1
        assert state.result == {"answer": "42"}

    def test_timestamps_auto_generated(self):
        """created_at and updated_at should auto-generate."""
        state = TaskState(task_id="t1", session_id="s1")
        assert isinstance(state.created_at, datetime)
        assert isinstance(state.updated_at, datetime)

    def test_task_id_required(self):
        """task_id is required."""
        with pytest.raises(ValidationError):
            TaskState(session_id="session1")

    def test_session_id_optional(self):
        """session_id is optional (can be None)."""
        state = TaskState(task_id="task1")
        assert state.session_id is None


class TestMessage:
    """Tests for Message model."""

    def test_create_with_required_fields(self):
        """Create Message with required fields only."""
        msg = Message(role="user", content="Hello!")
        assert msg.role == "user"
        assert msg.content == "Hello!"
        assert msg.metadata == {}
        assert isinstance(msg.timestamp, datetime)

    def test_create_with_all_fields(self):
        """Create Message with all fields."""
        ts = datetime.now(UTC)
        msg = Message(
            role="assistant",
            content="Hi there!",
            metadata={"tokens": 5},
            timestamp=ts,
        )
        assert msg.role == "assistant"
        assert msg.content == "Hi there!"
        assert msg.metadata == {"tokens": 5}
        assert msg.timestamp == ts

    def test_valid_roles(self):
        """Common roles should work."""
        for role in ["user", "assistant", "system", "tool"]:
            msg = Message(role=role, content="test")
            assert msg.role == role


class TestThread:
    """Tests for Thread model."""

    def test_create_with_required_fields(self):
        """Create Thread with required fields only."""
        thread = Thread(thread_id="01ARZ3NDEKTSV4RRFFQ69G5FAV")
        assert thread.thread_id == "01ARZ3NDEKTSV4RRFFQ69G5FAV"
        assert thread.messages == []
        assert thread.context == {}
        assert thread.metadata == {}

    def test_create_with_all_fields(self):
        """Create Thread with all fields."""
        ts = datetime.now(UTC)
        thread = Thread(
            thread_id="thread123",
            messages=[Message(role="user", content="Hi")],
            context={"instance_id": "redis-1"},
            metadata={"source": "api"},
            created_at=ts,
            updated_at=ts,
        )
        assert len(thread.messages) == 1
        assert thread.context == {"instance_id": "redis-1"}
        assert thread.metadata == {"source": "api"}

    def test_timestamps_auto_generated(self):
        """created_at and updated_at should auto-generate."""
        thread = Thread(thread_id="t1")
        assert isinstance(thread.created_at, datetime)
        assert isinstance(thread.updated_at, datetime)

    def test_thread_id_required(self):
        """thread_id is required."""
        with pytest.raises(ValidationError):
            Thread()


class TestInputRequest:
    """Tests for InputRequest model."""

    def test_create_simple_request(self):
        """Create a simple input request with just a prompt."""
        request = InputRequest(prompt="What database should I use?")
        assert request.prompt == "What database should I use?"
        assert request.json_schema == {"type": "object", "properties": {}, "required": []}
        assert request.created_at is not None

    def test_create_request_with_json_schema(self):
        """Create an input request with JSON Schema."""
        schema = {
            "type": "object",
            "properties": {
                "database": {
                    "type": "string",
                    "enum": ["PostgreSQL", "MySQL", "Redis"],
                },
                "port": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 65535,
                    "default": 6379,
                },
            },
            "required": ["database"],
        }
        request = InputRequest(
            prompt="Please configure the connection",
            json_schema=schema,
            metadata={"step": "database_config"},
        )
        assert request.json_schema == schema
        assert request.metadata == {"step": "database_config"}

    def test_model_dump_includes_json_schema(self):
        """model_dump() should include json_schema in output."""
        schema = {
            "type": "object",
            "properties": {
                "choice": {"type": "string"},
            },
            "required": ["choice"],
        }
        request = InputRequest(prompt="Choose", json_schema=schema)
        data = request.model_dump()
        assert "json_schema" in data
        assert data["json_schema"]["type"] == "object"
        assert "choice" in data["json_schema"]["properties"]

    def test_default_json_schema(self):
        """Default json_schema should be empty object schema."""
        request = InputRequest(prompt="Just a prompt")
        assert request.json_schema == {"type": "object", "properties": {}, "required": []}


class TestTaskStateWithInput:
    """Tests for TaskState input-related fields."""

    def test_task_state_default_no_input(self):
        """TaskState should have no input by default."""
        task = TaskState(task_id="t1", session_id="s1")
        assert task.input_request is None
        assert task.input_response is None

    def test_task_state_with_input_request(self):
        """TaskState can store an input request."""
        request = InputRequest(prompt="Choose one")
        task = TaskState(
            task_id="t1",
            session_id="s1",
            status=TaskStatus.AWAITING_INPUT,
            input_request=request,
        )
        assert task.status == TaskStatus.AWAITING_INPUT
        assert task.input_request.prompt == "Choose one"

    def test_task_state_with_input_response(self):
        """TaskState can store an input response."""
        task = TaskState(
            task_id="t1",
            session_id="s1",
            input_response={"database": "Redis", "confirm": True},
        )
        assert task.input_response == {"database": "Redis", "confirm": True}


class TestTaskStateWithCaller:
    """Tests for TaskState caller field."""

    def test_task_state_default_no_caller(self):
        """TaskState should have no caller by default."""
        task = TaskState(task_id="t1", session_id="s1")
        assert task.caller is None

    def test_task_state_with_human_caller(self):
        """TaskState can store a human caller."""
        caller = Caller(type=CallerType.HUMAN, id="user-123", name="John")
        task = TaskState(task_id="t1", session_id="s1", caller=caller)
        assert task.caller is not None
        assert task.caller.type == CallerType.HUMAN
        assert task.caller.id == "user-123"
        assert task.caller.name == "John"

    def test_task_state_with_agent_caller(self):
        """TaskState can store an agent caller."""
        caller = Caller(
            type=CallerType.AGENT,
            id="research-agent",
            metadata={"protocol": "a2a"},
        )
        task = TaskState(task_id="t1", session_id="s1", caller=caller)
        assert task.caller is not None
        assert task.caller.type == CallerType.AGENT
        assert task.caller.id == "research-agent"
        assert task.caller.metadata == {"protocol": "a2a"}


class TestSkill:
    """Tests for Skill model (A2A)."""

    def test_create_with_required_fields(self):
        """Create Skill with required fields only."""
        skill = Skill(id="chat", name="Chat", description="General conversation")
        assert skill.id == "chat"
        assert skill.name == "Chat"
        assert skill.description == "General conversation"
        assert skill.tags == []
        assert skill.examples == []
        assert skill.input_modes == ["text"]
        assert skill.output_modes == ["text"]

    def test_create_with_all_fields(self):
        """Create Skill with all fields."""
        skill = Skill(
            id="code-review",
            name="Code Review",
            description="Reviews code for issues",
            tags=["development", "review"],
            examples=["Review this Python code", "Check for bugs"],
            input_modes=["text", "file"],
            output_modes=["text"],
        )
        assert skill.id == "code-review"
        assert skill.tags == ["development", "review"]
        assert skill.examples == ["Review this Python code", "Check for bugs"]
        assert skill.input_modes == ["text", "file"]


class TestAgentCard:
    """Tests for AgentCard model (A2A discovery)."""

    def test_create_with_required_fields(self):
        """Create AgentCard with required fields only."""
        card = AgentCard(
            name="My Agent",
            description="A helpful assistant",
            url="https://agent.example.com",
        )
        assert card.name == "My Agent"
        assert card.description == "A helpful assistant"
        assert card.url == "https://agent.example.com"
        assert card.version == "1.0.0"
        assert card.protocol_version == "1.0"
        assert card.skills == []
        assert card.default_input_modes == ["text"]
        assert card.default_output_modes == ["text"]
        assert card.capabilities == {}
        assert card.authentication is None
        assert card.metadata == {}

    def test_create_with_skills(self):
        """Create AgentCard with skills."""
        card = AgentCard(
            name="Multi-Skill Agent",
            description="Agent with multiple skills",
            url="https://agent.example.com",
            skills=[
                Skill(id="chat", name="Chat", description="General chat"),
                Skill(id="search", name="Search", description="Web search"),
            ],
        )
        assert len(card.skills) == 2
        assert card.skills[0].id == "chat"
        assert card.skills[1].id == "search"

    def test_create_with_capabilities(self):
        """Create AgentCard with capabilities."""
        card = AgentCard(
            name="Streaming Agent",
            description="Agent with streaming",
            url="https://agent.example.com",
            capabilities={"streaming": True, "pushNotifications": False},
        )
        assert card.capabilities["streaming"] is True
        assert card.capabilities["pushNotifications"] is False

    def test_create_with_authentication(self):
        """Create AgentCard with authentication config."""
        card = AgentCard(
            name="Secure Agent",
            description="Agent with auth",
            url="https://agent.example.com",
            authentication={
                "schemes": ["bearer"],
                "credentials": "required",
            },
        )
        assert card.authentication["schemes"] == ["bearer"]


class TestCapability:
    """Tests for Capability model (ACP)."""

    def test_create_capability(self):
        """Create Capability with required fields."""
        cap = Capability(name="Conversational AI", description="Handles multi-turn conversations")
        assert cap.name == "Conversational AI"
        assert cap.description == "Handles multi-turn conversations"


class TestAgentMetadata:
    """Tests for AgentMetadata model (ACP)."""

    def test_create_with_defaults(self):
        """Create AgentMetadata with defaults."""
        meta = AgentMetadata()
        assert meta.documentation is None
        assert meta.license is None
        assert meta.programming_language is None
        assert meta.natural_languages == []
        assert meta.framework is None
        assert meta.capabilities == []
        assert meta.domains == []
        assert meta.tags == []
        assert meta.author is None
        assert meta.links == []

    def test_create_with_all_fields(self):
        """Create AgentMetadata with all fields."""
        meta = AgentMetadata(
            documentation="https://docs.example.com",
            license="Apache-2.0",
            programming_language="Python",
            natural_languages=["en", "es"],
            framework="Redis Agent Kit",
            capabilities=[
                Capability(name="Chat", description="Conversational AI"),
            ],
            domains=["finance", "healthcare"],
            tags=["production", "enterprise"],
            author={"name": "John Doe", "email": "john@example.com"},
            links=[{"type": "homepage", "url": "https://example.com"}],
        )
        assert meta.license == "Apache-2.0"
        assert meta.natural_languages == ["en", "es"]
        assert len(meta.capabilities) == 1
        assert meta.domains == ["finance", "healthcare"]


class TestAgentManifest:
    """Tests for AgentManifest model (ACP discovery)."""

    def test_create_with_required_fields(self):
        """Create AgentManifest with required fields only."""
        manifest = AgentManifest(
            name="my-agent",
            description="A helpful assistant",
        )
        assert manifest.name == "my-agent"
        assert manifest.description == "A helpful assistant"
        assert manifest.input_content_types == ["*/*"]
        assert manifest.output_content_types == ["*/*"]
        assert manifest.metadata is None
        assert manifest.status is None

    def test_create_with_content_types(self):
        """Create AgentManifest with specific content types."""
        manifest = AgentManifest(
            name="image-analyzer",
            description="Analyzes images",
            input_content_types=["image/png", "image/jpeg"],
            output_content_types=["text/plain", "application/json"],
        )
        assert manifest.input_content_types == ["image/png", "image/jpeg"]
        assert manifest.output_content_types == ["text/plain", "application/json"]

    def test_create_with_metadata(self):
        """Create AgentManifest with metadata."""
        manifest = AgentManifest(
            name="documented-agent",
            description="Well documented agent",
            metadata=AgentMetadata(
                documentation="https://docs.example.com",
                license="MIT",
                tags=["production"],
            ),
        )
        assert manifest.metadata is not None
        assert manifest.metadata.license == "MIT"
        assert manifest.metadata.tags == ["production"]

    def test_name_validation_dns_label(self):
        """Name should follow RFC 1123 DNS label format."""
        # Valid names
        AgentManifest(name="my-agent", description="test")
        AgentManifest(name="agent123", description="test")
        AgentManifest(name="a", description="test")

        # Invalid names (should raise validation error)
        with pytest.raises(ValidationError):
            AgentManifest(name="My Agent", description="test")  # spaces not allowed
        with pytest.raises(ValidationError):
            AgentManifest(name="UPPERCASE", description="test")  # uppercase not allowed
        with pytest.raises(ValidationError):
            AgentManifest(name="-invalid", description="test")  # can't start with hyphen
