"""Tests for Tool system."""

import pytest


class TestToolModels:
    """Tests for tool models."""

    def test_tool_capability_enum(self):
        """ToolCapability should have expected values."""
        from redis_agent_kit.tools import ToolCapability

        assert ToolCapability.KNOWLEDGE.value == "knowledge"
        assert ToolCapability.UTILITIES.value == "utilities"
        assert ToolCapability.CUSTOM.value == "custom"

    def test_tool_definition_creation(self):
        """ToolDefinition should be created with required fields."""
        from redis_agent_kit.tools import ToolDefinition

        tool_def = ToolDefinition(
            name="test_tool",
            description="A test tool",
            parameters={
                "type": "object",
                "properties": {"query": {"type": "string"}},
            },
        )

        assert tool_def.name == "test_tool"
        assert tool_def.description == "A test tool"

    def test_tool_definition_to_openai_schema(self):
        """ToolDefinition should convert to OpenAI schema."""
        from redis_agent_kit.tools import ToolDefinition

        tool_def = ToolDefinition(
            name="search",
            description="Search for documents",
            parameters={
                "type": "object",
                "properties": {"query": {"type": "string"}},
                "required": ["query"],
            },
        )

        schema = tool_def.to_openai_schema()

        assert schema["type"] == "function"
        assert schema["function"]["name"] == "search"
        assert schema["function"]["description"] == "Search for documents"
        assert "parameters" in schema["function"]

    def test_tool_metadata_creation(self):
        """ToolMetadata should be created with required fields."""
        from redis_agent_kit.tools.models import ToolCapability, ToolMetadata

        metadata = ToolMetadata(
            name="test_tool",
            description="A test tool",
            capability=ToolCapability.KNOWLEDGE,
            provider_name="test_provider",
        )

        assert metadata.name == "test_tool"
        assert metadata.capability == ToolCapability.KNOWLEDGE


class TestToolProvider:
    """Tests for ToolProvider base class."""

    def test_tool_provider_abstract(self):
        """ToolProvider should be abstract."""
        from redis_agent_kit.tools import ToolProvider

        with pytest.raises(TypeError):
            ToolProvider()

    def test_tool_provider_implementation(self):
        """ToolProvider subclass should implement required methods."""
        from redis_agent_kit.tools import ToolCapability, ToolDefinition, ToolProvider

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="echo",
                        description="Echo input",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    )
                ]

            async def echo(self, **kwargs):
                return kwargs

        provider = TestProvider()
        assert provider.provider_name == "test"
        assert len(provider.create_tool_schemas()) == 1
        assert len(provider.tools()) == 1


class TestToolManager:
    """Tests for ToolManager."""

    def test_tool_manager_creation(self):
        """ToolManager should be created empty."""
        from redis_agent_kit.tools import ToolManager

        manager = ToolManager()
        assert len(manager.get_openai_tools()) == 0

    def test_tool_manager_add_provider(self):
        """ToolManager should add providers."""
        from redis_agent_kit.tools import (
            ToolCapability,
            ToolDefinition,
            ToolManager,
            ToolProvider,
        )

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="echo",
                        description="Echo input",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    )
                ]

            async def echo(self, **kwargs):
                return kwargs

        manager = ToolManager()
        manager.add_provider(TestProvider())

        tools = manager.get_openai_tools()
        assert len(tools) == 1
        assert tools[0]["function"]["name"] == "echo"

    @pytest.mark.asyncio
    async def test_tool_manager_execute(self):
        """ToolManager should execute tools."""
        from redis_agent_kit.tools import (
            ToolCapability,
            ToolDefinition,
            ToolManager,
            ToolProvider,
        )

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="echo",
                        description="Echo input",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    )
                ]

            async def echo(self, message: str = ""):
                return {"echoed": message}

        manager = ToolManager()
        manager.add_provider(TestProvider())

        result = await manager.execute("echo", {"message": "hello"})
        assert result == {"echoed": "hello"}

    def test_tool_manager_replace_provider_warning(self, caplog):
        """ToolManager should warn when replacing a provider."""
        import logging

        from redis_agent_kit.tools import (
            ToolCapability,
            ToolDefinition,
            ToolManager,
            ToolProvider,
        )

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="echo",
                        description="Echo input",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    )
                ]

            async def echo(self):
                return {}

        manager = ToolManager()
        manager.add_provider(TestProvider())

        with caplog.at_level(logging.WARNING):
            manager.add_provider(TestProvider())  # Add same provider again

        assert "Replacing existing provider" in caplog.text

    def test_tool_manager_remove_provider(self):
        """ToolManager should remove providers."""
        from redis_agent_kit.tools import (
            ToolCapability,
            ToolDefinition,
            ToolManager,
            ToolProvider,
        )

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="echo",
                        description="Echo input",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    )
                ]

            async def echo(self):
                return {}

        manager = ToolManager()
        manager.add_provider(TestProvider())
        assert len(manager.get_tools()) == 1

        result = manager.remove_provider("test")
        assert result is True
        assert len(manager.get_tools()) == 0

    def test_tool_manager_remove_provider_not_found(self):
        """ToolManager should return False when removing non-existent provider."""
        from redis_agent_kit.tools import ToolManager

        manager = ToolManager()
        result = manager.remove_provider("nonexistent")
        assert result is False

    def test_tool_manager_get_tools_with_capabilities(self):
        """ToolManager should filter tools by capability."""
        from redis_agent_kit.tools import (
            ToolCapability,
            ToolDefinition,
            ToolManager,
            ToolProvider,
        )

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="knowledge_tool",
                        description="Knowledge tool",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.KNOWLEDGE,
                    ),
                    ToolDefinition(
                        name="utility_tool",
                        description="Utility tool",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    ),
                ]

            async def knowledge_tool(self):
                return {}

            async def utility_tool(self):
                return {}

        manager = ToolManager()
        manager.add_provider(TestProvider())

        # Filter by capability
        knowledge_tools = manager.get_tools(capabilities={ToolCapability.KNOWLEDGE})
        assert len(knowledge_tools) == 1
        assert knowledge_tools[0].metadata.name == "knowledge_tool"

    def test_tool_manager_get_tools_exclude_capabilities(self):
        """ToolManager should exclude tools by capability."""
        from redis_agent_kit.tools import (
            ToolCapability,
            ToolDefinition,
            ToolManager,
            ToolProvider,
        )

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="knowledge_tool",
                        description="Knowledge tool",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.KNOWLEDGE,
                    ),
                    ToolDefinition(
                        name="utility_tool",
                        description="Utility tool",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    ),
                ]

            async def knowledge_tool(self):
                return {}

            async def utility_tool(self):
                return {}

        manager = ToolManager()
        manager.add_provider(TestProvider())

        # Exclude knowledge tools
        tools = manager.get_tools(exclude_capabilities={ToolCapability.KNOWLEDGE})
        assert len(tools) == 1
        assert tools[0].metadata.name == "utility_tool"

    @pytest.mark.asyncio
    async def test_tool_manager_execute_not_found(self):
        """ToolManager should raise KeyError for unknown tool."""
        from redis_agent_kit.tools import ToolManager

        manager = ToolManager()

        with pytest.raises(KeyError, match="Tool not found"):
            await manager.execute("nonexistent", {})

    def test_tool_manager_has_tool(self):
        """ToolManager should check if tool exists."""
        from redis_agent_kit.tools import (
            ToolCapability,
            ToolDefinition,
            ToolManager,
            ToolProvider,
        )

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="echo",
                        description="Echo input",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    )
                ]

            async def echo(self):
                return {}

        manager = ToolManager()
        manager.add_provider(TestProvider())

        assert manager.has_tool("echo") is True
        assert manager.has_tool("nonexistent") is False

    def test_tool_manager_providers_property(self):
        """ToolManager providers property should return copy of providers."""
        from redis_agent_kit.tools import ToolDefinition, ToolManager, ToolProvider

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return []

        manager = ToolManager()
        provider = TestProvider()
        manager.add_provider(provider)

        providers = manager.providers
        assert "test" in providers
        # Should be a copy
        providers["test"] = None
        assert manager.providers["test"] is provider


class TestToolProviderContextManager:
    """Tests for ToolProvider async context manager."""

    @pytest.mark.asyncio
    async def test_provider_context_manager(self):
        """ToolProvider should work as async context manager."""
        from redis_agent_kit.tools import ToolDefinition, ToolProvider

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return []

        async with TestProvider() as provider:
            assert provider.provider_name == "test"

    def test_provider_missing_method_raises(self):
        """ToolProvider should raise if tool method is missing."""
        from redis_agent_kit.tools import ToolCapability, ToolDefinition, ToolProvider

        class BadProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "bad"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="missing_method",
                        description="Tool with no method",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    )
                ]

        provider = BadProvider()
        with pytest.raises(RuntimeError, match="has no method"):
            provider.tools()


class TestKnowledgeProvider:
    """Tests for KnowledgeProvider."""

    @pytest.mark.asyncio
    async def test_knowledge_provider_search(self, redis_client, mock_openai_vectorizer):
        """KnowledgeProvider should search knowledge store."""
        from redis_agent_kit.knowledge import KnowledgeStore
        from redis_agent_kit.tools.knowledge_provider import KnowledgeProvider

        ks = KnowledgeStore(redis_client)
        provider = KnowledgeProvider(ks)

        # Add some test data using ingest method
        await ks.ingest("Test content about Redis", title="Redis Doc")

        # Search
        result = await provider.search_knowledge(query="Redis", limit=5)

        assert "query" in result
        assert "results" in result
        assert result["query"] == "Redis"


class TestToolDecorator:
    """Tests for @tool decorator and utilities."""

    def test_tool_decorator_basic(self):
        """@tool decorator should create ToolWrapper."""
        from redis_agent_kit.tools import tool

        @tool
        async def my_tool(query: str) -> dict:
            """Search for something."""
            return {"query": query}

        assert hasattr(my_tool, "tool_definition")
        assert hasattr(my_tool, "to_openai_schema")
        assert my_tool.tool_definition.name == "my_tool"

    def test_tool_decorator_extracts_description(self):
        """@tool should extract description from docstring."""
        from redis_agent_kit.tools import tool

        @tool
        async def search(query: str) -> dict:
            """Search the database for matching records."""
            return {}

        assert "Search the database" in search.tool_definition.description

    def test_tool_decorator_with_custom_name(self):
        """@tool should allow custom name."""
        from redis_agent_kit.tools import tool

        @tool(name="custom_search")
        async def search(query: str) -> dict:
            """Search for items."""
            return {}

        assert search.tool_definition.name == "custom_search"

    def test_tool_decorator_generates_parameters(self):
        """@tool should generate parameters schema from type hints."""
        from redis_agent_kit.tools import tool

        @tool
        async def search(query: str, limit: int = 10, include_meta: bool = False) -> dict:
            """Search for items.

            Args:
                query: The search query
                limit: Max results
                include_meta: Include metadata
            """
            return {}

        params = search.tool_definition.parameters
        assert params["type"] == "object"
        assert "query" in params["properties"]
        assert "limit" in params["properties"]
        assert "include_meta" in params["properties"]
        assert params["properties"]["query"]["type"] == "string"
        assert params["properties"]["limit"]["type"] == "integer"
        assert params["properties"]["include_meta"]["type"] == "boolean"
        assert "query" in params["required"]
        assert "limit" not in params["required"]  # Has default

    def test_tool_decorator_parses_docstring_args(self):
        """@tool should extract parameter descriptions from docstring."""
        from redis_agent_kit.tools import tool

        @tool
        async def search(query: str, limit: int = 5) -> dict:
            """Search the knowledge base.

            Args:
                query: The search query to find relevant content
                limit: Maximum number of results to return
            """
            return {}

        props = search.tool_definition.parameters["properties"]
        assert "description" in props["query"]
        assert "search query" in props["query"]["description"].lower()

    def test_tool_to_openai_schema(self):
        """@tool should produce valid OpenAI schema."""
        from redis_agent_kit.tools import tool

        @tool
        async def echo(message: str) -> dict:
            """Echo a message back."""
            return {"message": message}

        schema = echo.to_openai_schema()
        assert schema["type"] == "function"
        assert schema["function"]["name"] == "echo"
        assert "description" in schema["function"]
        assert "parameters" in schema["function"]

    @pytest.mark.asyncio
    async def test_tool_invoke(self):
        """@tool should allow invoking with args dict."""
        from redis_agent_kit.tools import tool

        @tool
        async def add(a: int, b: int) -> dict:
            """Add two numbers."""
            return {"result": a + b}

        result = await add.invoke({"a": 2, "b": 3})
        assert result == {"result": 5}

    @pytest.mark.asyncio
    async def test_tool_callable(self):
        """@tool decorated function should still be callable."""
        from redis_agent_kit.tools import tool

        @tool
        async def greet(name: str) -> dict:
            """Greet someone."""
            return {"greeting": f"Hello, {name}!"}

        result = await greet(name="World")
        assert result == {"greeting": "Hello, World!"}

    def test_get_openai_tools(self):
        """get_openai_tools should collect schemas from multiple tools."""
        from redis_agent_kit.tools import get_openai_tools, tool

        @tool
        async def tool_a(x: str) -> dict:
            """Tool A."""
            return {}

        @tool
        async def tool_b(y: int) -> dict:
            """Tool B."""
            return {}

        schemas = get_openai_tools(tool_a, tool_b)
        assert len(schemas) == 2
        names = {s["function"]["name"] for s in schemas}
        assert names == {"tool_a", "tool_b"}

    def test_collect_tools(self):
        """collect_tools should gather Tool objects."""
        from redis_agent_kit.tools import Tool, collect_tools, tool

        @tool
        async def my_tool(x: str) -> dict:
            """A tool."""
            return {}

        tools = collect_tools(my_tool)
        assert len(tools) == 1
        assert isinstance(tools[0], Tool)
        assert tools[0].metadata.name == "my_tool"


class TestAnnotatedSupport:
    """Tests for Annotated type hint support."""

    def test_annotated_string_description(self):
        """Annotated[type, 'description'] should set parameter description."""
        from typing import Annotated

        from redis_agent_kit.tools import tool

        @tool
        async def remember(fact: Annotated[str, "What to remember"]) -> dict:
            """Store info."""
            return {}

        props = remember.tool_definition.parameters["properties"]
        assert props["fact"]["description"] == "What to remember"
        assert props["fact"]["type"] == "string"

    def test_annotated_param_description(self):
        """Annotated[type, Param(description=...)] should set description."""
        from typing import Annotated

        from redis_agent_kit.tools import Param, tool

        @tool
        async def search(
            query: Annotated[str, Param(description="Search query")],
        ) -> dict:
            """Search."""
            return {}

        props = search.tool_definition.parameters["properties"]
        assert props["query"]["description"] == "Search query"

    def test_annotated_param_constraints(self):
        """Param should add JSON Schema constraints."""
        from typing import Annotated

        from redis_agent_kit.tools import Param, tool

        @tool
        async def fetch(
            query: Annotated[str, Param(description="Query", min_length=1, max_length=100)],
            limit: Annotated[int, Param(description="Limit", ge=1, le=50)] = 10,
        ) -> dict:
            """Fetch."""
            return {}

        props = fetch.tool_definition.parameters["properties"]
        assert props["query"]["minLength"] == 1
        assert props["query"]["maxLength"] == 100
        assert props["limit"]["minimum"] == 1
        assert props["limit"]["maximum"] == 50

    def test_annotated_param_enum(self):
        """Param should support enum constraint."""
        from typing import Annotated

        from redis_agent_kit.tools import Param, tool

        @tool
        async def set_mode(
            mode: Annotated[str, Param(description="Mode", enum=["fast", "slow"])],
        ) -> dict:
            """Set mode."""
            return {}

        props = set_mode.tool_definition.parameters["properties"]
        assert props["mode"]["enum"] == ["fast", "slow"]

    def test_annotated_priority_over_docstring(self):
        """Annotated description should take priority over docstring."""
        from typing import Annotated

        from redis_agent_kit.tools import tool

        @tool
        async def test_func(param: Annotated[str, "Annotated wins"]) -> dict:
            """Test.

            Args:
                param: Docstring description
            """
            return {}

        props = test_func.tool_definition.parameters["properties"]
        assert props["param"]["description"] == "Annotated wins"


class TestToolFromFunction:
    """Tests for tool_from_function utility."""

    def test_tool_from_function_basic(self):
        """tool_from_function should create Tool from async function."""
        from redis_agent_kit.tools import tool_from_function

        async def my_func(query: str) -> dict:
            """Search for items."""
            return {"query": query}

        tool_obj = tool_from_function(my_func)
        assert tool_obj.metadata.name == "my_func"
        assert "Search for items" in tool_obj.definition.description

    def test_tool_from_function_custom_options(self):
        """tool_from_function should accept custom options."""
        from redis_agent_kit.tools import ToolCapability, tool_from_function

        async def search(q: str) -> dict:
            """Original description."""
            return {}

        tool_obj = tool_from_function(
            search,
            name="custom_search",
            description="Custom description",
            capability=ToolCapability.KNOWLEDGE,
        )
        assert tool_obj.metadata.name == "custom_search"
        assert tool_obj.definition.description == "Custom description"
        assert tool_obj.metadata.capability == ToolCapability.KNOWLEDGE

    @pytest.mark.asyncio
    async def test_tool_from_function_invoke(self):
        """tool_from_function Tool should be invocable."""
        from redis_agent_kit.tools import tool_from_function

        async def multiply(x: int, y: int) -> dict:
            """Multiply two numbers."""
            return {"result": x * y}

        tool_obj = tool_from_function(multiply)
        result = await tool_obj.invoke({"x": 3, "y": 4})
        assert result == {"result": 12}

    def test_tool_from_function_optional_params(self):
        """tool_from_function should handle optional parameters."""
        from redis_agent_kit.tools import tool_from_function

        async def search(query: str, limit: int = 10, fuzzy: bool = False) -> dict:
            """Search with options."""
            return {}

        tool_obj = tool_from_function(search)
        params = tool_obj.definition.parameters
        assert "query" in params["required"]
        assert "limit" not in params["required"]
        assert "fuzzy" not in params["required"]
        assert params["properties"]["limit"].get("default") == 10
        assert params["properties"]["fuzzy"].get("default") is False


class TestToolDecoratorInternals:
    """Tests for internal tool decorator helpers."""

    def test_param_to_schema_constraints_full_mapping(self):
        """Param should map all supported constraints."""
        from redis_agent_kit.tools.decorator import Param

        constraints = Param(
            ge=1,
            gt=0,
            le=10,
            lt=11,
            min_length=2,
            max_length=8,
            pattern="^x+$",
            enum=["x", "xx"],
        ).to_schema_constraints()

        assert constraints == {
            "minimum": 1,
            "exclusiveMinimum": 0,
            "maximum": 10,
            "exclusiveMaximum": 11,
            "minLength": 2,
            "maxLength": 8,
            "pattern": "^x+$",
            "enum": ["x", "xx"],
        }

    def test_extract_annotated_metadata_prefers_param_description(self):
        """Param(description=...) should override Annotated string metadata."""
        from typing import Annotated

        from redis_agent_kit.tools.decorator import Param, _extract_annotated_metadata

        base_type, description, constraints = _extract_annotated_metadata(
            Annotated[str, "first", Param(description="second", min_length=1)]
        )
        assert base_type is str
        assert description == "second"
        assert constraints["minLength"] == 1

    def test_extract_annotated_metadata_without_param_description(self):
        """Annotated string description should remain when Param has no description."""
        from typing import Annotated

        from redis_agent_kit.tools.decorator import Param, _extract_annotated_metadata

        base_type, description, constraints = _extract_annotated_metadata(
            Annotated[int, "count", Param(ge=1)]
        )
        assert base_type is int
        assert description == "count"
        assert constraints["minimum"] == 1

    def test_python_type_to_json_schema_variants(self):
        """Type conversion should support unions, containers, models, and fallbacks."""
        from pydantic import BaseModel

        from redis_agent_kit.tools.decorator import _python_type_to_json_schema

        class SampleModel(BaseModel):
            value: int

        assert _python_type_to_json_schema(type(None)) == {"type": "null"}
        assert _python_type_to_json_schema(str | None) == {"type": "string"}
        union_schema = _python_type_to_json_schema(str | int | None)
        assert "anyOf" in union_schema
        assert _python_type_to_json_schema(list[int]) == {
            "type": "array",
            "items": {"type": "integer"},
        }
        assert _python_type_to_json_schema(dict[str, int]) == {"type": "object"}
        assert _python_type_to_json_schema(SampleModel)["type"] == "object"
        assert _python_type_to_json_schema("int") == {"type": "integer"}
        assert _python_type_to_json_schema(object) == {"type": "string"}

    def test_python_type_to_json_schema_origin_edge_cases(self):
        """Type conversion should handle custom origin values used by typing internals."""
        from redis_agent_kit.tools.decorator import _python_type_to_json_schema

        class NoneOriginType:
            __origin__ = type(None)
            __args__ = ()

        class ListOriginNoArgs:
            __origin__ = list
            __args__ = ()

        assert _python_type_to_json_schema(NoneOriginType) == {"type": "null"}
        assert _python_type_to_json_schema(ListOriginNoArgs) == {"type": "array"}

    def test_parse_docstring_edge_formats(self):
        """Docstring parser should handle empty, sections, numpy headers, and continuations."""
        from redis_agent_kit.tools.decorator import _parse_docstring

        assert _parse_docstring(None) == ("", {})

        desc, params = _parse_docstring(
            """Do work.

            Args:
                query: first line
                  second line
            Returns:
                value
            """
        )
        assert desc == "Do work."
        assert params["query"] == "first line second line"

        numpy_desc, numpy_params = _parse_docstring(
            """Numpy format.
            -----
            """
        )
        assert numpy_desc == "Numpy format."
        assert numpy_params == {}

    def test_tool_from_function_handles_type_hint_failures_and_skips(self):
        """tool_from_function should recover from bad type-hint resolution and skip internals."""
        from unittest.mock import patch

        from redis_agent_kit.tools import tool_from_function
        from redis_agent_kit.tools.decorator import inspect as decorator_inspect

        class ToolHost:
            async def method(self, value, *args, **kwargs):
                """Method tool.

                Args:
                    value: payload
                """
                return {"value": value, "args": args, "kwargs": kwargs}

        with patch(
            "redis_agent_kit.tools.decorator.get_type_hints",
            side_effect=RuntimeError("boom"),
        ):
            tool_obj = tool_from_function(ToolHost.method)
        assert "self" not in tool_obj.definition.parameters["properties"]
        assert "args" not in tool_obj.definition.parameters["properties"]
        assert "kwargs" not in tool_obj.definition.parameters["properties"]
        assert "value" in tool_obj.definition.parameters["properties"]

        async def fallback_type(value):
            """Fallback type."""
            return {"value": value}

        with patch(
            "redis_agent_kit.tools.decorator.get_type_hints",
            return_value={"value": decorator_inspect.Parameter.empty},
        ):
            fallback_tool = tool_from_function(fallback_type)
        assert fallback_tool.definition.parameters["properties"]["value"]["type"] == "string"
        """tool_from_function should recover from bad type-hint resolution and skip internals."""
        from unittest.mock import patch

        from redis_agent_kit.tools import tool_from_function
        from redis_agent_kit.tools.decorator import inspect as decorator_inspect

        class ToolHost:
            async def method(self, value, *args, **kwargs):
                """Method tool.

                Args:
                    value: payload
                """
                return {"value": value, "args": args, "kwargs": kwargs}

        with patch(
            "redis_agent_kit.tools.decorator.get_type_hints",
            side_effect=RuntimeError("boom"),
        ):
            tool_obj = tool_from_function(ToolHost.method)
        assert "self" not in tool_obj.definition.parameters["properties"]
        assert "args" not in tool_obj.definition.parameters["properties"]
        assert "kwargs" not in tool_obj.definition.parameters["properties"]
        assert "value" in tool_obj.definition.parameters["properties"]

        async def fallback_type(value):
            """Fallback type."""
            return {"value": value}

        with patch(
            "redis_agent_kit.tools.decorator.get_type_hints",
            return_value={"value": decorator_inspect.Parameter.empty},
        ):
            fallback_tool = tool_from_function(fallback_type)
        assert fallback_tool.definition.parameters["properties"]["value"]["type"] == "string"
        """tool_from_function should recover from bad type-hint resolution and skip internals."""
        from unittest.mock import patch

        from redis_agent_kit.tools import tool_from_function
        from redis_agent_kit.tools.decorator import inspect as decorator_inspect

        class ToolHost:
            async def method(self, value, *args, **kwargs):
                """Method tool.

                Args:
                    value: payload
                """
                return {"value": value, "args": args, "kwargs": kwargs}

        with patch(
            "redis_agent_kit.tools.decorator.get_type_hints",
            side_effect=RuntimeError("boom"),
        ):
            tool_obj = tool_from_function(ToolHost.method)
        assert "self" not in tool_obj.definition.parameters["properties"]
        assert "args" not in tool_obj.definition.parameters["properties"]
        assert "kwargs" not in tool_obj.definition.parameters["properties"]
        assert "value" in tool_obj.definition.parameters["properties"]

        async def fallback_type(value):
            """Fallback type."""
            return {"value": value}

        with patch(
            "redis_agent_kit.tools.decorator.get_type_hints",
            return_value={"value": decorator_inspect.Parameter.empty},
        ):
            fallback_tool = tool_from_function(fallback_type)
        assert fallback_tool.definition.parameters["properties"]["value"]["type"] == "string"
