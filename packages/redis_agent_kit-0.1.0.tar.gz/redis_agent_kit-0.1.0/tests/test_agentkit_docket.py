"""Tests for internal Docket integration in AgentKit.

Docket is an implementation detail - users interact with tasks/threads only.
The kit handles Docket submission internally when create_and_submit_task is called.
"""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from redis_agent_kit.middleware import TaskContext, TaskMiddleware


class TestAgentKitWithAgentCallable:
    """Tests for AgentKit with agent_callable (Docket integration)."""

    def test_agentkit_accepts_agent_callable(self, redis_url, redis_client):
        """AgentKit should accept an agent_callable function."""
        from redis_agent_kit import AgentKit

        async def my_handler(task_id: str, session_id: str, message: str, context: dict):
            pass

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=my_handler)
        assert kit._agent_callable is my_handler

    def test_agentkit_accepts_queue_config(self, redis_url, redis_client):
        """AgentKit should accept queue configuration."""
        from redis_agent_kit import AgentKit

        kit = AgentKit(redis_url, redis_client=redis_client, queue_name="my_queue")
        assert kit._queue_name == "my_queue"

    def test_agentkit_has_create_and_submit_task(self, redis_url, redis_client):
        """AgentKit should have create_and_submit_task method."""
        from redis_agent_kit import AgentKit

        kit = AgentKit(redis_url, redis_client=redis_client)
        assert hasattr(kit, "create_and_submit_task")

    def test_agentkit_creates_redis_client_from_url(self, redis_url):
        """AgentKit should create Redis client when redis_client is omitted."""
        from redis_agent_kit import AgentKit

        with patch(
            "redis_agent_kit.core.redis_lib.from_url", return_value=MagicMock()
        ) as mock_from_url:
            kit = AgentKit(redis_url, redis_client=None)

        assert kit.redis_url == redis_url
        mock_from_url.assert_called_once_with(redis_url)

    def test_agentkit_requires_redis_url(self):
        """AgentKit should fail when redis_url cannot be resolved."""
        from redis_agent_kit import AgentKit

        mock_settings = MagicMock()
        mock_settings.redis_url = ""
        mock_settings.namespace = "rak"
        mock_settings.task.queue_name = "redis-agent-kit"
        mock_settings.memory.enabled = False

        with (
            patch("redis_agent_kit.core.get_settings", return_value=mock_settings),
            pytest.raises(ValueError, match="Redis URL required"),
        ):
            AgentKit(redis_url=None, redis_client=MagicMock(), settings=None)


class TestCreateAndSubmitTask:
    """Tests for AgentKit.create_and_submit_task."""

    async def test_create_and_submit_creates_task(self, redis_url, redis_client):
        """create_and_submit_task should create a task and thread."""
        from redis_agent_kit import AgentKit

        async def handler(task_id: str, session_id: str, message: str, context: dict):
            pass

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)

        with patch("redis_agent_kit.core.Docket") as mock_docket:
            mock_instance = MagicMock()
            mock_docket.return_value.__aenter__.return_value = mock_instance
            # add() returns a regular callable, calling it returns a coroutine
            mock_instance.add.return_value = AsyncMock(return_value=None)

            result = await kit.create_and_submit_task(
                message="What is Redis?",
                context={"user_id": "u1"},
            )

        assert "task_id" in result
        assert "session_id" in result
        assert result["status"] == "queued"

    async def test_create_and_submit_submits_to_docket(self, redis_url, redis_client):
        """create_and_submit_task should submit to Docket internally."""
        from redis_agent_kit import AgentKit

        async def handler(task_id: str, session_id: str, message: str, context: dict):
            pass

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)

        with patch("redis_agent_kit.core.Docket") as mock_docket:
            mock_instance = MagicMock()
            mock_docket.return_value.__aenter__.return_value = mock_instance
            mock_instance.add.return_value = AsyncMock(return_value=None)

            result = await kit.create_and_submit_task(message="Test query")

            # Verify Docket was called with handler and task_id as key
            mock_instance.add.assert_called_once()
            call_args = mock_instance.add.call_args
            assert call_args.kwargs.get("key") == result["task_id"]

    async def test_create_and_submit_uses_existing_session(self, redis_url, redis_client):
        """create_and_submit_task should use existing session if provided."""
        from redis_agent_kit import AgentKit

        async def handler(task_id: str, session_id: str, message: str, context: dict):
            pass

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)

        with patch("redis_agent_kit.core.Docket") as mock_docket:
            mock_instance = MagicMock()
            mock_docket.return_value.__aenter__.return_value = mock_instance
            mock_instance.add.return_value = AsyncMock(return_value=None)

            result = await kit.create_and_submit_task(
                message="Follow-up",
                session_id="existing-session-123",
            )

        assert result["session_id"] == "existing-session-123"

    async def test_create_and_submit_raises_without_handler(self, redis_url, redis_client):
        """create_and_submit_task should raise if no agent_callable configured."""
        from redis_agent_kit import AgentKit

        kit = AgentKit(redis_url, redis_client=redis_client)  # No handler

        with pytest.raises(ValueError, match="agent_callable"):
            await kit.create_and_submit_task(message="Test")

    async def test_create_and_submit_uses_provided_session_id(self, redis_url, redis_client):
        """create_and_submit_task should use provided session_id."""
        from redis_agent_kit import AgentKit

        async def handler(task_id: str, session_id: str, message: str, context: dict):
            pass

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)

        with patch("redis_agent_kit.core.Docket") as mock_docket:
            mock_instance = MagicMock()
            mock_docket.return_value.__aenter__.return_value = mock_instance
            mock_instance.add.return_value = AsyncMock(return_value=None)

            # Use a session_id
            result = await kit.create_and_submit_task(
                message="Test",
                session_id="my_session_id",
            )

        # Should use the provided session_id
        assert "session_id" in result
        assert result["session_id"] == "my_session_id"

    async def test_create_and_submit_serializes_attachments(self, redis_url, redis_client):
        """create_and_submit_task should serialize attachment payload in context."""
        from redis_agent_kit import AgentKit, Attachment, AttachmentType

        async def handler(task_id: str, session_id: str, message: str, context: dict):
            return {"ok": True}

        attachment = Attachment(
            type=AttachmentType.FILE,
            mime_type="text/plain",
            url="redis://attachments:test",
            size_bytes=4,
        )
        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)

        with patch("redis_agent_kit.core.Docket") as mock_docket:
            mock_instance = MagicMock()
            mock_docket.return_value.__aenter__.return_value = mock_instance
            queued = AsyncMock(return_value=None)
            mock_instance.add.return_value = queued

            await kit.create_and_submit_task(message="Test", attachments=[attachment])

            queued_kwargs = queued.call_args.kwargs
            assert queued_kwargs["context"]["_attachments"][0]["mime_type"] == "text/plain"
            assert queued_kwargs["context"]["_attachments"][0]["url"] == "redis://attachments:test"


class TestAgentKitMemory:
    """Tests for AgentKit memory integration."""

    def test_agentkit_memory_property(self, redis_url, redis_client):
        """AgentKit should expose memory property."""
        from redis_agent_kit import AgentKit
        from redis_agent_kit.memory import Memory

        kit = AgentKit(redis_url, redis_client=redis_client)
        assert isinstance(kit.memory, Memory)

    def test_agentkit_memory_disabled(self, redis_url, redis_client):
        """AgentKit should use NoOpMemory when memory disabled."""
        from redis_agent_kit import AgentKit
        from redis_agent_kit.config import MemorySettings, Settings
        from redis_agent_kit.memory import NoOpMemory

        settings = Settings(memory=MemorySettings(enabled=False))
        kit = AgentKit(redis_url, redis_client=redis_client, settings=settings)
        assert isinstance(kit.memory, NoOpMemory)

    async def test_agentkit_create_task(self, redis_url, redis_client):
        """AgentKit.create_task should create task with memory session."""
        from redis_agent_kit import AgentKit

        kit = AgentKit(redis_url, redis_client=redis_client)
        task, session_id = await kit.create_task(
            message="Hello",
            context={"key": "value"},
        )

        assert task is not None
        assert session_id is not None
        assert task.session_id == session_id

    async def test_agentkit_create_task_with_session_id(self, redis_url, redis_client):
        """AgentKit.create_task should use provided session_id."""
        from redis_agent_kit import AgentKit

        kit = AgentKit(redis_url, redis_client=redis_client)
        task, session_id = await kit.create_task(
            message="Hello",
            session_id="my-session-123",
        )

        assert session_id == "my-session-123"
        assert task.session_id == "my-session-123"


class TestAgentKitQueueProperties:
    """Tests for AgentKit queue-related properties."""

    def test_agentkit_has_queue_name(self, redis_url, redis_client):
        """AgentKit should expose queue_name."""
        from redis_agent_kit import AgentKit

        kit = AgentKit(redis_url, redis_client=redis_client, queue_name="my_agent")
        assert kit.queue_name == "my_agent"

    def test_agentkit_default_queue_name(self, redis_url, redis_client):
        """AgentKit should have default queue_name."""
        from redis_agent_kit import AgentKit

        kit = AgentKit(redis_url, redis_client=redis_client)
        assert kit.queue_name == "redis-agent-kit"

    def test_agentkit_has_redis_url(self, redis_url, redis_client):
        """AgentKit should expose redis_url."""
        from redis_agent_kit import AgentKit

        kit = AgentKit("redis://myhost:6379", redis_client=redis_client)
        assert kit.redis_url == "redis://myhost:6379"

    def test_worker_task_property_returns_wrapped_handler(self, redis_url, redis_client):
        """worker_task should expose wrapped callable."""
        from redis_agent_kit import AgentKit

        async def handler(task_id: str, session_id: str, message: str, context: dict):
            return {"response": message}

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)
        wrapped = kit.worker_task
        assert callable(wrapped)


class TestAgentKitSubmitInput:
    """Tests for AgentKit.submit_input convenience method."""

    async def test_submit_input_delegates_to_task_manager(self, redis_url, redis_client):
        """submit_input should delegate to task_manager.submit_input and re-queue."""
        from unittest.mock import AsyncMock, patch

        from redis_agent_kit import AgentKit

        async def dummy_handler(ctx):
            return {"response": "done"}

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=dummy_handler)

        # Create a task and request input
        task = await kit.task_manager.create_task(session_id="s1", message="Hello")
        await kit.task_manager.request_input(task.task_id, prompt="Choose one")

        # Mock Docket to avoid actual queueing
        with patch("redis_agent_kit.core.Docket") as mock_docket_class:
            mock_docket = AsyncMock()
            mock_docket.__aenter__ = AsyncMock(return_value=mock_docket)
            mock_docket.__aexit__ = AsyncMock(return_value=None)
            mock_docket.add = lambda handler, key: AsyncMock()
            mock_docket_class.return_value = mock_docket

            # Submit input via AgentKit convenience method
            result = await kit.submit_input(task.task_id, {"response": "Option A"})

        assert result is True
        updated = await kit.task_manager.get_task(task.task_id)
        assert updated.input_response == {"response": "Option A"}

    async def test_submit_input_returns_false_for_wrong_status(self, redis_url, redis_client):
        """submit_input should return False if task not awaiting input."""
        from redis_agent_kit import AgentKit

        async def dummy_handler(ctx):
            return {"response": "done"}

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=dummy_handler)
        task = await kit.task_manager.create_task(session_id="s1", message="Hello")

        result = await kit.submit_input(task.task_id, {"response": "test"})

        assert result is False

    async def test_submit_input_returns_true_when_task_missing_after_update(
        self, redis_url, redis_client
    ):
        """submit_input should still succeed if task disappears before requeue."""
        from redis_agent_kit import AgentKit

        async def dummy_handler(ctx):
            return {"response": "done"}

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=dummy_handler)
        kit.task_manager.submit_input = AsyncMock(return_value=True)
        kit.task_manager.get_task = AsyncMock(return_value=None)

        with patch("redis_agent_kit.core.Docket") as mock_docket:
            result = await kit.submit_input("task-123", {"response": "ok"})

        assert result is True
        mock_docket.assert_not_called()


class TestAgentKitMiddleware:
    """Tests for AgentKit middleware support."""

    def test_agentkit_accepts_middleware(self, redis_url, redis_client):
        """AgentKit should accept middleware list."""
        from redis_agent_kit import AgentKit
        from redis_agent_kit.middleware import ResultMiddleware

        class TestMiddleware(TaskMiddleware):
            async def __call__(self, ctx, next):
                return await next(ctx)

        kit = AgentKit(redis_url, redis_client=redis_client, middleware=[TestMiddleware()])
        # Auto-includes ResultMiddleware + user middleware
        assert len(kit._middleware) == 2
        assert isinstance(kit._middleware[0], ResultMiddleware)
        assert isinstance(kit._middleware[1], TestMiddleware)

    def test_agentkit_auto_result_middleware_disabled(self, redis_url, redis_client):
        """AgentKit should not auto-add ResultMiddleware when disabled."""
        from redis_agent_kit import AgentKit

        class TestMiddleware(TaskMiddleware):
            async def __call__(self, ctx, next):
                return await next(ctx)

        kit = AgentKit(
            redis_url,
            redis_client=redis_client,
            middleware=[TestMiddleware()],
            auto_result_middleware=False,
        )
        assert len(kit._middleware) == 1
        assert isinstance(kit._middleware[0], TestMiddleware)

    def test_agentkit_no_duplicate_result_middleware(self, redis_url, redis_client):
        """AgentKit should not duplicate ResultMiddleware if user provides it."""
        from redis_agent_kit import AgentKit
        from redis_agent_kit.middleware import ResultMiddleware

        kit = AgentKit(redis_url, redis_client=redis_client, middleware=[ResultMiddleware()])
        assert len(kit._middleware) == 1
        assert isinstance(kit._middleware[0], ResultMiddleware)

    async def test_agentkit_applies_middleware_to_context_handler(self, redis_url, redis_client):
        """AgentKit should apply middleware to context-based handlers."""
        from redis_agent_kit import AgentKit

        call_order = []

        class TrackingMiddleware(TaskMiddleware):
            async def __call__(self, ctx, next):
                call_order.append("middleware")
                return await next(ctx)

        async def handler(ctx: TaskContext) -> dict:
            call_order.append("handler")
            return {"response": ctx.message}

        kit = AgentKit(
            redis_url,
            redis_client=redis_client,
            agent_callable=handler,
            middleware=[TrackingMiddleware()],
        )

        with patch("redis_agent_kit.core.Docket") as mock_docket:
            mock_instance = MagicMock()
            mock_docket.return_value.__aenter__.return_value = mock_instance

            # Capture the wrapped handler
            captured_handler = None

            def capture_add(handler, **kwargs):
                nonlocal captured_handler
                captured_handler = handler
                return AsyncMock(return_value=None)

            mock_instance.add.side_effect = capture_add

            result = await kit.create_and_submit_task(message="Test")

            # Now call the captured handler directly to test middleware
            call_order.clear()
            await captured_handler(
                task_id=result["task_id"],
                session_id=result["session_id"],
                message="Test",
                context={},
            )

        assert call_order == ["middleware", "handler"]

    async def test_agentkit_applies_middleware_to_legacy_handler(self, redis_url, redis_client):
        """AgentKit should apply middleware to legacy 4-arg handlers."""
        from redis_agent_kit import AgentKit

        call_order = []

        class TrackingMiddleware(TaskMiddleware):
            async def __call__(self, ctx, next):
                call_order.append("middleware")
                return await next(ctx)

        async def legacy_handler(
            task_id: str, session_id: str, message: str, context: dict
        ) -> dict:
            call_order.append("handler")
            return {"response": message}

        kit = AgentKit(
            redis_url,
            redis_client=redis_client,
            agent_callable=legacy_handler,
            middleware=[TrackingMiddleware()],
        )

        with patch("redis_agent_kit.core.Docket") as mock_docket:
            mock_instance = MagicMock()
            mock_docket.return_value.__aenter__.return_value = mock_instance

            captured_handler = None

            def capture_add(handler, **kwargs):
                nonlocal captured_handler
                captured_handler = handler
                return AsyncMock(return_value=None)

            mock_instance.add.side_effect = capture_add

            result = await kit.create_and_submit_task(message="Test")

            call_order.clear()
            await captured_handler(
                task_id=result["task_id"],
                session_id=result["session_id"],
                message="Test",
                context={},
            )

        assert call_order == ["middleware", "handler"]

    async def test_agentkit_no_middleware_calls_handler_directly(self, redis_url, redis_client):
        """AgentKit without middleware should call handler directly."""
        from redis_agent_kit import AgentKit

        handler_called = False

        async def handler(ctx: TaskContext) -> dict:
            nonlocal handler_called
            handler_called = True
            return {"response": "done"}

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)

        with patch("redis_agent_kit.core.Docket") as mock_docket:
            mock_instance = MagicMock()
            mock_docket.return_value.__aenter__.return_value = mock_instance

            captured_handler = None

            def capture_add(handler, **kwargs):
                nonlocal captured_handler
                captured_handler = handler
                return AsyncMock(return_value=None)

            mock_instance.add.side_effect = capture_add

            result = await kit.create_and_submit_task(message="Test")

            await captured_handler(
                task_id=result["task_id"],
                session_id=result["session_id"],
                message="Test",
                context={},
            )

        assert handler_called


class TestAgentKitCreateWrappedHandler:
    """Tests for AgentKit._create_wrapped_handler edge cases."""

    async def test_create_wrapped_handler_raises_without_agent_callable(
        self, redis_url, redis_client
    ):
        """_create_wrapped_handler should raise if no agent_callable configured."""
        from redis_agent_kit import AgentKit

        kit = AgentKit(redis_url, redis_client=redis_client)  # No agent_callable

        with pytest.raises(ValueError, match="No agent_callable configured"):
            kit._create_wrapped_handler()

    async def test_legacy_handler_without_middleware(self, redis_url, redis_client):
        """Legacy handler (4 args) should work without middleware."""
        from redis_agent_kit import AgentKit

        call_log = []

        # Legacy handlers use session_id (was thread_id)
        async def legacy_handler(task_id: str, session_id: str, message: str, context: dict):
            call_log.append((task_id, session_id, message, context))
            return {"response": "done"}

        kit = AgentKit(
            redis_url,
            redis_client=redis_client,
            agent_callable=legacy_handler,
            # No middleware
        )

        wrapped = kit._create_wrapped_handler()

        # Call the wrapped handler directly
        result = await wrapped(
            task_id="t1",
            session_id="s1",
            message="hello",
            context={"key": "value"},
        )

        assert result == {"response": "done"}
        assert len(call_log) == 1
        assert call_log[0] == ("t1", "s1", "hello", {"key": "value"})

    async def test_legacy_handler_without_any_middleware(self, redis_url, redis_client):
        """Legacy handler should execute direct-call path when middleware is disabled."""
        from redis_agent_kit import AgentKit

        call_log = []

        async def legacy_handler(task_id: str, session_id: str, message: str, context: dict):
            call_log.append((task_id, session_id, message, context))
            return {"response": "ok"}

        kit = AgentKit(
            redis_url,
            redis_client=redis_client,
            agent_callable=legacy_handler,
            auto_result_middleware=False,
        )
        wrapped = kit._create_wrapped_handler()
        result = await wrapped("t-legacy", "s-legacy", "hello", {"k": "v"})

        assert result == {"response": "ok"}
        assert call_log == [("t-legacy", "s-legacy", "hello", {"k": "v"})]

    async def test_context_handler_without_middleware(self, redis_url, redis_client):
        """Context handler should execute directly when no middleware configured."""
        from redis_agent_kit import AgentKit

        async def context_handler(ctx: TaskContext) -> dict:
            return {"echo": ctx.message}

        kit = AgentKit(
            redis_url,
            redis_client=redis_client,
            agent_callable=context_handler,
            auto_result_middleware=False,
        )
        wrapped = kit._create_wrapped_handler()

        result = await wrapped(
            task_id="t1",
            session_id="s1",
            message="hello",
            context={},
        )
        assert result == {"echo": "hello"}


class TestWebhookCallback:
    """Tests for webhook callback functionality."""

    async def test_callback_sent_on_success(self, redis_url, redis_client):
        """Webhook callback should be sent when task completes successfully."""
        from redis_agent_kit import AgentKit

        async def handler(task_id: str, session_id: str, message: str, context: dict):
            return {"status": "success"}

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)
        wrapped = kit._create_wrapped_handler()

        with patch("redis_agent_kit.core.httpx.AsyncClient") as mock_client:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_post = AsyncMock(return_value=mock_response)
            mock_client.return_value.__aenter__.return_value.post = mock_post

            result = await wrapped(
                task_id="t1",
                session_id="s1",
                message="hello",
                context={"callback_url": "https://example.com/webhook"},
            )

            assert result == {"status": "success"}
            mock_post.assert_called_once()
            call_args = mock_post.call_args
            assert call_args[0][0] == "https://example.com/webhook"
            payload = call_args[1]["json"]
            assert payload["task_id"] == "t1"
            assert payload["session_id"] == "s1"
            assert payload["status"] == "completed"
            assert payload["result"] == {"status": "success"}
            assert payload["error"] is None

    async def test_callback_sent_on_error(self, redis_url, redis_client):
        """Webhook callback should be sent when task fails."""
        from redis_agent_kit import AgentKit

        async def handler(task_id: str, session_id: str, message: str, context: dict):
            raise ValueError("Something went wrong")

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)
        wrapped = kit._create_wrapped_handler()

        with patch("redis_agent_kit.core.httpx.AsyncClient") as mock_client:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_post = AsyncMock(return_value=mock_response)
            mock_client.return_value.__aenter__.return_value.post = mock_post

            with pytest.raises(ValueError, match="Something went wrong"):
                await wrapped(
                    task_id="t1",
                    session_id="s1",
                    message="hello",
                    context={"callback_url": "https://example.com/webhook"},
                )

            mock_post.assert_called_once()
            payload = mock_post.call_args[1]["json"]
            assert payload["status"] == "failed"
            assert payload["error"] == "Something went wrong"

    async def test_no_callback_without_url(self, redis_url, redis_client):
        """No webhook callback should be sent if callback_url not in context."""
        from redis_agent_kit import AgentKit

        async def handler(task_id: str, session_id: str, message: str, context: dict):
            return {"status": "success"}

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)
        wrapped = kit._create_wrapped_handler()

        with patch("redis_agent_kit.core.httpx.AsyncClient") as mock_client:
            result = await wrapped(
                task_id="t1",
                session_id="s1",
                message="hello",
                context={},  # No callback_url
            )

            assert result == {"status": "success"}
            mock_client.assert_not_called()

    async def test_callback_failure_does_not_fail_task(self, redis_url, redis_client):
        """Webhook callback failure should not fail the task."""
        from redis_agent_kit import AgentKit

        async def handler(task_id: str, session_id: str, message: str, context: dict):
            return {"status": "success"}

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)
        wrapped = kit._create_wrapped_handler()

        with patch("redis_agent_kit.core.httpx.AsyncClient") as mock_client:
            mock_client.return_value.__aenter__.return_value.post = AsyncMock(
                side_effect=Exception("Network error")
            )

            # Task should still succeed even if callback fails
            result = await wrapped(
                task_id="t1",
                session_id="s1",
                message="hello",
                context={"callback_url": "https://example.com/webhook"},
            )

            assert result == {"status": "success"}

    async def test_callback_logs_warning_on_http_error(self, redis_url, redis_client):
        """Webhook callback should log warning on HTTP error response."""
        from redis_agent_kit import AgentKit

        async def handler(task_id: str, session_id: str, message: str, context: dict):
            return {"status": "success"}

        kit = AgentKit(redis_url, redis_client=redis_client, agent_callable=handler)
        wrapped = kit._create_wrapped_handler()

        with patch("redis_agent_kit.core.httpx.AsyncClient") as mock_client:
            mock_response = MagicMock()
            mock_response.status_code = 500
            mock_response.text = "Internal Server Error"
            mock_client.return_value.__aenter__.return_value.post = AsyncMock(
                return_value=mock_response
            )

            with patch("redis_agent_kit.core.logger") as mock_logger:
                result = await wrapped(
                    task_id="t1",
                    session_id="s1",
                    message="hello",
                    context={"callback_url": "https://example.com/webhook"},
                )

                assert result == {"status": "success"}
                mock_logger.warning.assert_called_once()
                assert "500" in str(mock_logger.warning.call_args)
