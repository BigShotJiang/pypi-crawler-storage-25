"""Tests for Docket configuration helpers.

Docket itself is an internal implementation detail of AgentKit.
These tests cover the RetryConfig and ConcurrencyConfig helpers.
"""

from datetime import timedelta


class TestRetryConfig:
    """Tests for RetryConfig helper class."""

    def test_retry_config_importable_from_core(self):
        """RetryConfig should be importable from core."""
        from redis_agent_kit.core import RetryConfig

        assert RetryConfig is not None

    def test_retry_config_importable_from_main(self):
        """RetryConfig should be importable from main package."""
        from redis_agent_kit import RetryConfig

        assert RetryConfig is not None

    def test_retry_config_defaults(self):
        """RetryConfig should have sensible defaults."""
        from redis_agent_kit import RetryConfig

        config = RetryConfig()
        assert config.attempts == 3
        assert config.delay == timedelta(seconds=5)

    def test_retry_config_custom_values(self):
        """RetryConfig should accept custom values."""
        from redis_agent_kit import RetryConfig

        config = RetryConfig(attempts=5, delay=timedelta(seconds=10))
        assert config.attempts == 5
        assert config.delay == timedelta(seconds=10)


class TestConcurrencyConfig:
    """Tests for ConcurrencyConfig helper class."""

    def test_concurrency_config_importable_from_core(self):
        """ConcurrencyConfig should be importable from core."""
        from redis_agent_kit.core import ConcurrencyConfig

        assert ConcurrencyConfig is not None

    def test_concurrency_config_importable_from_main(self):
        """ConcurrencyConfig should be importable from main package."""
        from redis_agent_kit import ConcurrencyConfig

        assert ConcurrencyConfig is not None

    def test_concurrency_config_required_key(self):
        """ConcurrencyConfig should require a key."""
        from redis_agent_kit import ConcurrencyConfig

        config = ConcurrencyConfig(key="thread_id")
        assert config.key == "thread_id"

    def test_concurrency_config_defaults(self):
        """ConcurrencyConfig should have sensible defaults."""
        from redis_agent_kit import ConcurrencyConfig

        config = ConcurrencyConfig(key="user_id")
        assert config.max_concurrent == 1
        assert config.scope == "default"

    def test_concurrency_config_custom_values(self):
        """ConcurrencyConfig should accept custom values."""
        from redis_agent_kit import ConcurrencyConfig

        config = ConcurrencyConfig(key="user_id", max_concurrent=5, scope="global")
        assert config.key == "user_id"
        assert config.max_concurrent == 5
        assert config.scope == "global"
