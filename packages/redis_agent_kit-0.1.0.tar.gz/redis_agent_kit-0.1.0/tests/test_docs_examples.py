"""Tests that verify documentation examples work correctly."""

import pytest

from redis_agent_kit import (
    AgentCard,
    AgentKit,
    AgentManifest,
    Skill,
    TaskEmitter,
    TaskManager,
    TaskStatus,
)


class TestReadmeExamples:
    """Verify README.md examples work."""

    @pytest.fixture
    async def client(self, redis_client):
        return redis_client

    @pytest.fixture
    async def task_manager(self, client):
        return TaskManager(client)

    async def test_quickstart_example(self, task_manager):
        """README quickstart example."""
        # Create a task for agent work (session created automatically)
        task = await task_manager.create_task(
            session_id="session-123",
            message="What is Redis?",
            context={"user_id": "123"},
        )

        # Track progress
        await task_manager.add_update(task.task_id, "Searching knowledge base...")
        await task_manager.set_result(task.task_id, {"answer": "Redis is..."})

        # Verify
        task = await task_manager.get_task(task.task_id)
        assert task.result == {"answer": "Redis is..."}
        assert len(task.updates) == 1


class TestTasksGuideExamples:
    """Verify docs/guide/tasks.md examples work."""

    @pytest.fixture
    async def task_manager(self, redis_client):
        return TaskManager(redis_client)

    async def test_create_task(self, task_manager):
        """Creating tasks example."""
        task = await task_manager.create_task(
            session_id="test-session",
            message="What is Redis?",
        )
        assert task.task_id is not None
        assert task.status == TaskStatus.QUEUED
        # Message is stored in metadata
        assert task.metadata.get("message") == "What is Redis?"

    async def test_task_lifecycle(self, task_manager):
        """Task status updates example."""
        task = await task_manager.create_task(session_id="s1", message="Test")

        await task_manager.update_status(task.task_id, TaskStatus.IN_PROGRESS)
        task = await task_manager.get_task(task.task_id)
        assert task.status == TaskStatus.IN_PROGRESS

        await task_manager.update_status(task.task_id, TaskStatus.DONE)
        task = await task_manager.get_task(task.task_id)
        assert task.status == TaskStatus.DONE

    async def test_progress_updates(self, task_manager):
        """Progress updates example."""
        task = await task_manager.create_task(session_id="s1", message="Test")

        await task_manager.add_update(task.task_id, "Searching knowledge base...")
        await task_manager.add_update(task.task_id, "Found 5 documents")
        await task_manager.add_update(task.task_id, "Calling OpenAI API", update_type="tool_call")

        task = await task_manager.get_task(task.task_id)
        assert len(task.updates) == 3
        assert task.updates[2].update_type == "tool_call"

    async def test_results_and_errors(self, task_manager):
        """Results and errors example."""
        # Success case
        task = await task_manager.create_task(session_id="s1", message="Test success")
        await task_manager.set_result(
            task.task_id,
            {"answer": "Redis is an in-memory data store.", "sources": ["doc1", "doc2"]},
        )
        await task_manager.update_status(task.task_id, TaskStatus.DONE)
        task = await task_manager.get_task(task.task_id)
        assert task.result["answer"] == "Redis is an in-memory data store."

        # Error case
        task2 = await task_manager.create_task(session_id="s1", message="Test error")
        await task_manager.set_error(task2.task_id, "API timeout after 30s")
        await task_manager.update_status(task2.task_id, TaskStatus.FAILED)
        task2 = await task_manager.get_task(task2.task_id)
        assert task2.error_message == "API timeout after 30s"

    async def test_task_emitter(self, task_manager):
        """TaskEmitter example."""
        task = await task_manager.create_task(session_id="s1", message="Test")

        emitter = TaskEmitter(task_manager, task.task_id)
        await emitter.emit("Processing query...")
        await emitter.emit("Analysis complete", metadata={"tokens": 150})

        task = await task_manager.get_task(task.task_id)
        assert len(task.updates) == 2

    async def test_list_tasks(self, task_manager):
        """List tasks example."""
        task = await task_manager.create_task(session_id="s1", message="Test")
        await task_manager.update_status(task.task_id, TaskStatus.IN_PROGRESS)

        tasks = await task_manager.list_tasks(status=TaskStatus.IN_PROGRESS)
        assert len(tasks) >= 1

    async def test_custom_prefix(self, redis_client):
        """Custom prefix example."""
        task_manager = TaskManager(redis_client, prefix="myapp")
        task = await task_manager.create_task(session_id="s1", message="Test")

        # Verify key uses custom prefix
        key = f"myapp:task:{task.task_id}"
        exists = await redis_client.exists(key)
        assert exists == 1


class TestInputGuideExamples:
    """Verify docs/guide/input.md examples work."""

    @pytest.fixture
    async def task_manager(self, redis_client):
        return TaskManager(redis_client)

    @pytest.fixture
    async def kit(self, redis_client):
        return AgentKit(redis_client, redis_url="redis://localhost:6379")

    async def test_request_input(self, task_manager):
        """Request input example."""
        task = await task_manager.create_task(session_id="s1", message="Configure database")

        await task_manager.request_input(
            task.task_id,
            prompt="Which database should I configure?",
            json_schema={
                "type": "object",
                "properties": {
                    "database": {"type": "string", "enum": ["PostgreSQL", "MySQL", "Redis"]},
                    "port": {"type": "integer", "minimum": 1, "maximum": 65535, "default": 5432},
                },
                "required": ["database"],
            },
        )

        task = await task_manager.get_task(task.task_id)
        assert task.status == TaskStatus.AWAITING_INPUT
        assert task.input_request is not None
        assert task.input_request.prompt == "Which database should I configure?"
        assert "database" in task.input_request.json_schema["properties"]

    async def test_submit_valid_input(self, task_manager):
        """Submit valid input example."""
        task = await task_manager.create_task(session_id="s1", message="Configure database")

        await task_manager.request_input(
            task.task_id,
            prompt="Which database?",
            json_schema={
                "type": "object",
                "properties": {
                    "database": {"type": "string", "enum": ["PostgreSQL", "MySQL", "Redis"]},
                    "port": {"type": "integer", "minimum": 1, "maximum": 65535},
                },
                "required": ["database"],
            },
        )

        await task_manager.submit_input(task.task_id, {"database": "Redis", "port": 6379})

        task = await task_manager.get_task(task.task_id)
        assert task.status == TaskStatus.QUEUED
        assert task.input_response["database"] == "Redis"

    async def test_validation_missing_required(self, task_manager):
        """Validation: missing required field."""
        task = await task_manager.create_task(session_id="s1", message="Test")

        await task_manager.request_input(
            task.task_id,
            prompt="Test",
            json_schema={
                "type": "object",
                "properties": {"database": {"type": "string"}},
                "required": ["database"],
            },
        )

        with pytest.raises(ValueError) as exc:
            await task_manager.submit_input(task.task_id, {"port": 6379})
        assert "database" in str(exc.value).lower() or "required" in str(exc.value).lower()

    async def test_validation_invalid_type(self, task_manager):
        """Validation: invalid type."""
        task = await task_manager.create_task(session_id="s1", message="Test")

        await task_manager.request_input(
            task.task_id,
            prompt="Test",
            json_schema={
                "type": "object",
                "properties": {"port": {"type": "integer"}},
            },
        )

        with pytest.raises(ValueError) as exc:
            await task_manager.submit_input(task.task_id, {"port": "not-a-number"})
        assert "integer" in str(exc.value).lower() or "type" in str(exc.value).lower()

    async def test_validation_out_of_range(self, task_manager):
        """Validation: value out of range."""
        task = await task_manager.create_task(session_id="s1", message="Test")

        await task_manager.request_input(
            task.task_id,
            prompt="Test",
            json_schema={
                "type": "object",
                "properties": {"port": {"type": "integer", "maximum": 65535}},
            },
        )

        with pytest.raises(ValueError) as exc:
            await task_manager.submit_input(task.task_id, {"port": 99999})
        assert "maximum" in str(exc.value).lower() or "65535" in str(exc.value)

    async def test_validation_invalid_enum(self, task_manager):
        """Validation: invalid enum value."""
        task = await task_manager.create_task(session_id="s1", message="Test")

        await task_manager.request_input(
            task.task_id,
            prompt="Test",
            json_schema={
                "type": "object",
                "properties": {"db": {"type": "string", "enum": ["PostgreSQL", "MySQL", "Redis"]}},
            },
        )

        with pytest.raises(ValueError) as exc:
            await task_manager.submit_input(task.task_id, {"db": "MongoDB"})
        assert "MongoDB" in str(exc.value) or "enum" in str(exc.value).lower()

    async def test_clear_input(self, task_manager):
        """Clear input example."""
        task = await task_manager.create_task(session_id="s1", message="Test")

        await task_manager.request_input(
            task.task_id,
            prompt="Test",
            json_schema={"type": "object", "properties": {"name": {"type": "string"}}},
        )
        await task_manager.submit_input(task.task_id, {"name": "test"})

        await task_manager.clear_input(task.task_id)

        task = await task_manager.get_task(task.task_id)
        assert task.input_request is None
        assert task.input_response is None


class TestProtocolsGuideExamples:
    """Verify docs/guide/protocols.md examples work."""

    def test_agent_card_creation(self):
        """AgentCard creation example."""
        agent_card = AgentCard(
            name="Research Agent",
            description="Researches topics",
            url="http://localhost:8000",
            skills=[
                Skill(
                    id="research",
                    name="Research",
                    description="Research any topic",
                    input_schema={"type": "object", "properties": {"topic": {"type": "string"}}},
                ),
            ],
        )

        assert agent_card.name == "Research Agent"
        assert len(agent_card.skills) == 1

    def test_agent_manifest_creation(self):
        """AgentManifest creation example."""
        from redis_agent_kit import AgentMetadata

        agent_manifest = AgentManifest(
            name="research-agent",
            description="Researches topics",
            metadata=AgentMetadata(
                documentation="https://example.com/docs",
                framework="redis-agent-kit",
            ),
        )

        assert agent_manifest.name == "research-agent"
        assert agent_manifest.metadata.framework == "redis-agent-kit"

    def test_agent_manifest_validation(self):
        """AgentManifest RFC 1123 validation."""
        # Valid name
        manifest = AgentManifest(name="my-agent", description="Test")
        assert manifest.name == "my-agent"

        # Invalid name (uppercase not allowed)
        with pytest.raises(ValueError):
            AgentManifest(name="My-Agent", description="Test")

        # Invalid name (underscore not allowed)
        with pytest.raises(ValueError):
            AgentManifest(name="my_agent", description="Test")
