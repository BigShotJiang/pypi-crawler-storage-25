"""Tests for redis_agent_kit.config module."""

import json
import os
import tempfile
from pathlib import Path

import pytest

from redis_agent_kit.config import (
    MemorySettings,
    ModelSettings,
    Settings,
    TaskSettings,
    _load_config_file,
    get_settings,
    load_settings,
    reset_settings,
    set_settings,
)


class TestMemorySettings:
    """Tests for MemorySettings."""

    def test_defaults(self):
        """MemorySettings should have sensible defaults."""
        settings = MemorySettings()
        assert settings.enabled is True
        assert settings.long_term_enabled is True
        assert settings.auto_summarization is True
        assert settings.extraction_strategy == "discrete"
        assert settings.forgetting_enabled is False

    def test_custom_values(self):
        """MemorySettings should accept custom values."""
        settings = MemorySettings(
            enabled=False,
            long_term_enabled=False,
            auto_summarization=False,
            extraction_strategy="summary",
            forgetting_enabled=True,
        )
        assert settings.enabled is False
        assert settings.long_term_enabled is False
        assert settings.auto_summarization is False
        assert settings.extraction_strategy == "summary"
        assert settings.forgetting_enabled is True


class TestTaskSettings:
    """Tests for TaskSettings."""

    def test_defaults(self):
        """TaskSettings should have sensible defaults."""
        settings = TaskSettings()
        assert settings.queue_name == "redis-agent-kit"
        assert settings.default_timeout_seconds == 300
        assert settings.max_retries == 3

    def test_custom_values(self):
        """TaskSettings should accept custom values."""
        settings = TaskSettings(
            queue_name="custom_queue",
            default_timeout_seconds=600,
            max_retries=5,
        )
        assert settings.queue_name == "custom_queue"
        assert settings.default_timeout_seconds == 600
        assert settings.max_retries == 5


class TestModelSettings:
    """Tests for ModelSettings."""

    def test_defaults(self):
        """ModelSettings should have sensible defaults."""
        settings = ModelSettings()
        assert settings.default_model == "gpt-4o"
        assert settings.fast_model == "gpt-4o-mini"
        assert settings.embedding_model == "text-embedding-3-small"

    def test_custom_values(self):
        """ModelSettings should accept custom values."""
        settings = ModelSettings(
            default_model="claude-3-opus",
            fast_model="claude-3-haiku",
            embedding_model="custom-embedding",
        )
        assert settings.default_model == "claude-3-opus"
        assert settings.fast_model == "claude-3-haiku"
        assert settings.embedding_model == "custom-embedding"


class TestSettings:
    """Tests for main Settings class."""

    def test_defaults(self):
        """Settings should have sensible defaults."""
        settings = Settings()
        assert settings.redis_url == "redis://localhost:6379"
        assert settings.namespace is None
        assert settings.log_level == "INFO"
        assert isinstance(settings.memory, MemorySettings)
        assert isinstance(settings.task, TaskSettings)
        assert isinstance(settings.model, ModelSettings)

    def test_custom_values(self):
        """Settings should accept custom values."""
        settings = Settings(
            redis_url="redis://custom:6380",
            namespace="myapp",
            log_level="DEBUG",
        )
        assert settings.redis_url == "redis://custom:6380"
        assert settings.namespace == "myapp"
        assert settings.log_level == "DEBUG"

    def test_nested_settings(self):
        """Settings should accept nested settings."""
        settings = Settings(
            memory=MemorySettings(enabled=False),
            task=TaskSettings(queue_name="custom"),
            model=ModelSettings(default_model="custom"),
        )
        assert settings.memory.enabled is False
        assert settings.task.queue_name == "custom"
        assert settings.model.default_model == "custom"


class TestLoadConfigFile:
    """Tests for _load_config_file function."""

    def test_load_yaml_file(self):
        """Should load YAML config file."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write("redis_url: redis://test:6379\nnamespace: test\n")
            f.flush()
            try:
                config = _load_config_file(Path(f.name))
                assert config["redis_url"] == "redis://test:6379"
                assert config["namespace"] == "test"
            finally:
                os.unlink(f.name)

    def test_load_json_file(self):
        """Should load JSON config file."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"redis_url": "redis://test:6379", "namespace": "test"}, f)
            f.flush()
            try:
                config = _load_config_file(Path(f.name))
                assert config["redis_url"] == "redis://test:6379"
                assert config["namespace"] == "test"
            finally:
                os.unlink(f.name)

    def test_file_not_found(self):
        """Should raise FileNotFoundError for missing file."""
        with pytest.raises(FileNotFoundError):
            _load_config_file(Path("/nonexistent/config.yaml"))


class TestGetSettings:
    """Tests for get_settings function."""

    def setup_method(self):
        """Reset settings before each test."""
        reset_settings()

    def teardown_method(self):
        """Reset settings after each test."""
        reset_settings()
        # Clean up env var if set
        if "RAK_CONFIG" in os.environ:
            del os.environ["RAK_CONFIG"]

    def test_returns_default_settings(self):
        """get_settings should return default Settings."""
        settings = get_settings()
        assert isinstance(settings, Settings)
        assert settings.redis_url == "redis://localhost:6379"

    def test_caches_settings(self):
        """get_settings should cache and return same instance."""
        settings1 = get_settings()
        settings2 = get_settings()
        assert settings1 is settings2

    def test_load_settings_from_config_path(self):
        """load_settings should load from config_path."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write("redis_url: redis://custom:6379\n")
            f.flush()
            try:
                settings = load_settings(config_path=f.name)
                assert settings.redis_url == "redis://custom:6379"
            finally:
                os.unlink(f.name)

    def test_loads_from_env_var(self):
        """get_settings should load from RAK_CONFIG env var."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write("redis_url: redis://env:6379\n")
            f.flush()
            try:
                os.environ["RAK_CONFIG"] = f.name
                settings = get_settings()
                assert settings.redis_url == "redis://env:6379"
            finally:
                os.unlink(f.name)


class TestSetSettings:
    """Tests for set_settings function."""

    def setup_method(self):
        """Reset settings before each test."""
        reset_settings()

    def teardown_method(self):
        """Reset settings after each test."""
        reset_settings()

    def test_set_settings(self):
        """set_settings should set the global settings."""
        custom = Settings(redis_url="redis://custom:6379")
        set_settings(custom)
        assert get_settings() is custom


class TestResetSettings:
    """Tests for reset_settings function."""

    def test_reset_settings(self):
        """reset_settings should clear cached settings."""
        settings1 = get_settings()
        reset_settings()
        settings2 = get_settings()
        # After reset, should get a new instance
        assert settings1 is not settings2
