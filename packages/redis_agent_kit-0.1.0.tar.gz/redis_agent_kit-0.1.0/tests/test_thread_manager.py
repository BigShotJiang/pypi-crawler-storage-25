"""Tests for ThreadManager."""

from redis_agent_kit.thread_manager import ThreadManager


class TestThreadManagerCreate:
    """Tests for thread creation."""

    async def test_create_thread(self, redis_client):
        """Create a thread with default parameters."""
        manager = ThreadManager(redis_client)
        thread = await manager.create_thread()

        assert thread.thread_id is not None
        assert len(thread.thread_id) == 26  # ULID length
        assert thread.messages == []
        assert thread.context == {}
        assert thread.metadata == {}

    async def test_create_thread_with_context(self, redis_client):
        """Create a thread with context."""
        manager = ThreadManager(redis_client)
        thread = await manager.create_thread(
            context={"user_id": "user123", "instance_id": "redis-prod"}
        )

        assert thread.context == {"user_id": "user123", "instance_id": "redis-prod"}

    async def test_create_thread_with_metadata(self, redis_client):
        """Create a thread with metadata."""
        manager = ThreadManager(redis_client)
        thread = await manager.create_thread(metadata={"source": "api", "version": "1.0"})

        assert thread.metadata == {"source": "api", "version": "1.0"}


class TestThreadManagerGet:
    """Tests for thread retrieval."""

    async def test_get_thread(self, redis_client):
        """Get an existing thread."""
        manager = ThreadManager(redis_client)
        created = await manager.create_thread()

        retrieved = await manager.get_thread(created.thread_id)

        assert retrieved is not None
        assert retrieved.thread_id == created.thread_id

    async def test_get_nonexistent_thread(self, redis_client):
        """Get a thread that doesn't exist."""
        manager = ThreadManager(redis_client)

        result = await manager.get_thread("nonexistent")

        assert result is None


class TestThreadManagerMessages:
    """Tests for message management."""

    async def test_add_message(self, redis_client):
        """Add a message to a thread."""
        manager = ThreadManager(redis_client)
        thread = await manager.create_thread()

        await manager.add_message(thread.thread_id, role="user", content="Hello!")

        updated = await manager.get_thread(thread.thread_id)
        assert len(updated.messages) == 1
        assert updated.messages[0].role == "user"
        assert updated.messages[0].content == "Hello!"

    async def test_add_multiple_messages(self, redis_client):
        """Add multiple messages in order."""
        manager = ThreadManager(redis_client)
        thread = await manager.create_thread()

        await manager.add_message(thread.thread_id, role="user", content="Hi")
        await manager.add_message(thread.thread_id, role="assistant", content="Hello!")
        await manager.add_message(thread.thread_id, role="user", content="How are you?")

        updated = await manager.get_thread(thread.thread_id)
        assert len(updated.messages) == 3
        assert [m.role for m in updated.messages] == ["user", "assistant", "user"]

    async def test_add_message_with_metadata(self, redis_client):
        """Add a message with metadata."""
        manager = ThreadManager(redis_client)
        thread = await manager.create_thread()

        await manager.add_message(
            thread.thread_id,
            role="assistant",
            content="Response",
            metadata={"tokens": 50, "model": "gpt-4"},
        )

        updated = await manager.get_thread(thread.thread_id)
        assert updated.messages[0].metadata == {"tokens": 50, "model": "gpt-4"}

    async def test_get_messages(self, redis_client):
        """Get messages from a thread."""
        manager = ThreadManager(redis_client)
        thread = await manager.create_thread()
        await manager.add_message(thread.thread_id, role="user", content="M1")
        await manager.add_message(thread.thread_id, role="assistant", content="M2")
        await manager.add_message(thread.thread_id, role="user", content="M3")

        messages = await manager.get_messages(thread.thread_id)

        assert len(messages) == 3
        assert [m.content for m in messages] == ["M1", "M2", "M3"]

    async def test_get_messages_with_limit(self, redis_client):
        """Get limited messages from a thread."""
        manager = ThreadManager(redis_client)
        thread = await manager.create_thread()
        for i in range(10):
            await manager.add_message(thread.thread_id, role="user", content=f"M{i}")

        messages = await manager.get_messages(thread.thread_id, limit=3)

        assert len(messages) == 3


class TestThreadManagerContext:
    """Tests for context updates."""

    async def test_update_context(self, redis_client):
        """Update thread context."""
        manager = ThreadManager(redis_client)
        thread = await manager.create_thread(context={"key1": "value1"})

        await manager.update_context(thread.thread_id, {"key2": "value2"})

        updated = await manager.get_thread(thread.thread_id)
        assert updated.context == {"key1": "value1", "key2": "value2"}

    async def test_update_context_overwrites_existing(self, redis_client):
        """Updating context should merge/overwrite existing keys."""
        manager = ThreadManager(redis_client)
        thread = await manager.create_thread(context={"key": "old"})

        await manager.update_context(thread.thread_id, {"key": "new"})

        updated = await manager.get_thread(thread.thread_id)
        assert updated.context == {"key": "new"}


class TestThreadManagerDelete:
    """Tests for thread deletion."""

    async def test_delete_thread(self, redis_client):
        """Delete a thread."""
        manager = ThreadManager(redis_client)
        thread = await manager.create_thread()

        await manager.delete_thread(thread.thread_id)

        result = await manager.get_thread(thread.thread_id)
        assert result is None


class TestThreadManagerNonexistentThread:
    """Tests for operations on non-existent threads."""

    async def test_add_message_nonexistent_thread(self, redis_client):
        """add_message should silently return for non-existent thread."""
        manager = ThreadManager(redis_client)
        # Should not raise
        await manager.add_message("nonexistent", role="user", content="Hello")

    async def test_get_messages_nonexistent_thread(self, redis_client):
        """get_messages should return empty list for non-existent thread."""
        manager = ThreadManager(redis_client)
        messages = await manager.get_messages("nonexistent")
        assert messages == []

    async def test_update_context_nonexistent_thread(self, redis_client):
        """update_context should silently return for non-existent thread."""
        manager = ThreadManager(redis_client)
        # Should not raise
        await manager.update_context("nonexistent", {"key": "value"})
