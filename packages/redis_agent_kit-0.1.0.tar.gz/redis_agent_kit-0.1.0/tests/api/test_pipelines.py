"""TDD tests for REST API pipeline endpoints - written BEFORE implementation."""

from unittest.mock import AsyncMock, patch

import pytest
from httpx import ASGITransport, AsyncClient


class TestPipelinesStatusEndpoint:
    """Tests for GET /pipelines/status endpoint."""

    @pytest.mark.asyncio
    async def test_get_status(self):
        """GET /pipelines/status should return chunk count."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.pipelines.get_vector_store") as mock_get_vs:
                mock_vs = AsyncMock()
                mock_vs.count.return_value = 100
                mock_get_vs.return_value = mock_vs

                response = await client.get("/pipelines/status")
                assert response.status_code == 200
                assert response.json()["chunks"] == 100


class TestPipelinesClearEndpoint:
    """Tests for DELETE /pipelines endpoint."""

    @pytest.mark.asyncio
    async def test_clear_pipeline(self):
        """DELETE /pipelines should clear all data."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.pipelines.get_vector_store") as mock_get_vs:
                mock_vs = AsyncMock()
                mock_vs.clear.return_value = None
                mock_get_vs.return_value = mock_vs

                response = await client.delete("/pipelines")
                assert response.status_code == 200
                assert response.json()["cleared"] is True


class TestPipelinesRunEndpoint:
    """Tests for POST /pipelines/run endpoint."""

    @pytest.mark.asyncio
    async def test_run_pipeline(self):
        """POST /pipelines/run should run pipeline on documents."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.pipelines.run_pipeline_on_documents") as mock_run:
                mock_run.return_value = {
                    "status": "completed",
                    "documents_processed": 2,
                    "chunks_created": 10,
                    "errors": [],
                }

                response = await client.post(
                    "/pipelines/run",
                    json={
                        "documents": [
                            {"title": "Doc1", "content": "Content 1", "source": "test"},
                            {"title": "Doc2", "content": "Content 2", "source": "test"},
                        ]
                    },
                )
                assert response.status_code == 200
                assert response.json()["status"] == "completed"
                assert response.json()["documents_processed"] == 2


class TestPipelinesRunIntegration:
    """Integration tests for run_pipeline_on_documents."""

    @pytest.mark.asyncio
    async def test_run_pipeline_on_documents_integration(self, redis_client):
        """run_pipeline_on_documents should process documents end-to-end."""
        from unittest.mock import MagicMock

        from redis_agent_kit.api.pipelines import DocumentInput, run_pipeline_on_documents

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]

        # Mock request with app state
        mock_request = MagicMock()
        mock_request.app.state.redis_url = f"redis://{host}:{port}"
        mock_request.app.state.prefix = "test"

        documents = [
            DocumentInput(title="Doc1", content="Short content", source="test1"),
            DocumentInput(title="Doc2", content="Another short doc", source="test2"),
        ]

        result = await run_pipeline_on_documents(
            mock_request, documents, chunk_size=1000, chunk_overlap=200
        )

        assert result["status"] == "completed"
        assert result["documents_processed"] == 2
        assert result["chunks_created"] >= 2
        assert result["errors"] == []

    @pytest.mark.asyncio
    async def test_run_pipeline_handles_errors(self, redis_client):
        """run_pipeline_on_documents should capture errors gracefully."""
        from unittest.mock import MagicMock

        from redis_agent_kit.api.pipelines import DocumentInput, run_pipeline_on_documents
        from redis_agent_kit.pipelines import DocumentProcessor

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]

        mock_request = MagicMock()
        mock_request.app.state.redis_url = f"redis://{host}:{port}"
        mock_request.app.state.prefix = "test"

        documents = [
            DocumentInput(title="Doc1", content="Valid content", source="test"),
        ]

        # Patch the processor to raise an error
        with patch.object(
            DocumentProcessor, "chunk_document", side_effect=Exception("Processing failed")
        ):
            result = await run_pipeline_on_documents(
                mock_request, documents, chunk_size=1000, chunk_overlap=200
            )

            assert result["status"] == "completed"
            assert result["documents_processed"] == 1
            assert len(result["errors"]) == 1
            assert "Processing failed" in result["errors"][0]
            assert len(result["errors"]) == 1
            assert "Processing failed" in result["errors"][0]


class TestGetVectorStore:
    """Tests for get_vector_store helper."""

    def test_get_vector_store_creates_store(self):
        """get_vector_store should create VectorStore from request."""
        from unittest.mock import MagicMock

        from redis_agent_kit.api.pipelines import get_vector_store

        mock_request = MagicMock()
        mock_request.app.state.redis_url = "redis://localhost:6379"
        mock_request.app.state.prefix = "test"

        vs = get_vector_store(mock_request)
        assert vs is not None
        assert vs.prefix == "test"


class TestGetArtifactStorage:
    """Tests for get_artifact_storage helper."""

    def test_get_artifact_storage_creates_storage(self, tmp_path):
        """get_artifact_storage should create ArtifactStorage from request."""
        from unittest.mock import MagicMock

        from redis_agent_kit.api.pipelines import get_artifact_storage

        mock_request = MagicMock()
        mock_request.app.state.artifacts_dir = tmp_path

        storage = get_artifact_storage(mock_request)
        assert storage is not None
        assert storage.artifacts_dir == tmp_path

    def test_get_artifact_storage_uses_default(self):
        """get_artifact_storage should use default artifacts dir."""
        from pathlib import Path
        from unittest.mock import MagicMock

        from redis_agent_kit.api.pipelines import get_artifact_storage

        mock_request = MagicMock()
        # Remove artifacts_dir attribute to test default
        del mock_request.app.state.artifacts_dir

        storage = get_artifact_storage(mock_request)
        assert storage is not None
        assert storage.artifacts_dir == Path("artifacts")


class TestGetOrchestrator:
    """Tests for get_orchestrator helper."""

    def test_get_orchestrator_creates_orchestrator(self, tmp_path):
        """get_orchestrator should create PipelineOrchestrator from request."""
        from unittest.mock import MagicMock

        from redis_agent_kit.api.pipelines import get_orchestrator

        mock_request = MagicMock()
        mock_request.app.state.artifacts_dir = tmp_path

        orchestrator = get_orchestrator(mock_request)
        assert orchestrator is not None
        assert orchestrator.base_path == tmp_path


class TestPipelinesPrepareEndpoint:
    """Tests for POST /pipelines/prepare endpoint."""

    @pytest.mark.asyncio
    async def test_prepare_pipeline(self, tmp_path):
        """POST /pipelines/prepare should submit prepare task."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with (
                patch("redis_agent_kit.api.pipelines.Docket") as mock_docket,
                patch("redis_agent_kit.api.pipelines.get_orchestrator") as mock_get_orch,
            ):
                mock_docket_instance = AsyncMock()
                mock_docket.return_value.__aenter__.return_value = mock_docket_instance
                mock_docket.return_value.__aexit__.return_value = None
                mock_orch = AsyncMock()
                mock_orch.submit_prepare.return_value = "task-123"
                mock_get_orch.return_value = mock_orch

                response = await client.post(
                    "/pipelines/prepare",
                    json={"source_path": str(tmp_path)},
                )
                assert response.status_code == 200
                assert response.json()["task_id"] == "task-123"


class TestPipelinesIngestEndpoint:
    """Tests for POST /pipelines/ingest endpoint."""

    @pytest.mark.asyncio
    async def test_ingest_pipeline(self):
        """POST /pipelines/ingest should submit ingest task."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with (
                patch("redis_agent_kit.api.pipelines.Docket") as mock_docket,
                patch("redis_agent_kit.api.pipelines.get_orchestrator") as mock_get_orch,
            ):
                mock_docket_instance = AsyncMock()
                mock_docket.return_value.__aenter__.return_value = mock_docket_instance
                mock_docket.return_value.__aexit__.return_value = None
                mock_orch = AsyncMock()
                mock_orch.submit_ingest.return_value = "task-456"
                mock_get_orch.return_value = mock_orch

                response = await client.post(
                    "/pipelines/ingest",
                    json={"batch_id": "2025-01-14"},
                )
                assert response.status_code == 200
                assert response.json()["task_id"] == "task-456"


class TestPipelinesFullRunEndpoint:
    """Tests for POST /pipelines/full endpoint."""

    @pytest.mark.asyncio
    async def test_full_pipeline(self, tmp_path):
        """POST /pipelines/full should submit full pipeline task."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with (
                patch("redis_agent_kit.api.pipelines.Docket") as mock_docket,
                patch("redis_agent_kit.api.pipelines.get_orchestrator") as mock_get_orch,
            ):
                mock_docket_instance = AsyncMock()
                mock_docket.return_value.__aenter__.return_value = mock_docket_instance
                mock_docket.return_value.__aexit__.return_value = None
                mock_orch = AsyncMock()
                mock_orch.submit_full.return_value = "task-789"
                mock_get_orch.return_value = mock_orch

                response = await client.post(
                    "/pipelines/full",
                    json={"source_path": str(tmp_path)},
                )
                assert response.status_code == 200
                assert response.json()["task_id"] == "task-789"


class TestPipelinesDocumentsEndpoint:
    """Tests for POST /pipelines/documents endpoint."""

    @pytest.mark.asyncio
    async def test_add_document(self, tmp_path):
        """POST /pipelines/documents should submit document ingestion task."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with (
                patch("redis_agent_kit.api.pipelines.Docket") as mock_docket,
                patch("redis_agent_kit.api.pipelines.get_orchestrator") as mock_get_orch,
            ):
                mock_docket_instance = AsyncMock()
                mock_docket.return_value.__aenter__.return_value = mock_docket_instance
                mock_docket.return_value.__aexit__.return_value = None
                mock_orch = AsyncMock()
                mock_orch.submit_document.return_value = "task-doc-1"
                mock_get_orch.return_value = mock_orch

                response = await client.post(
                    "/pipelines/documents",
                    json={
                        "content": "# Test Document\n\nThis is test content.",
                        "filename": "test.md",
                    },
                )
                assert response.status_code == 200
                assert response.json()["task_id"] == "task-doc-1"


class TestPipelinesBatchesEndpoint:
    """Tests for GET/DELETE /pipelines/batches endpoint."""

    @pytest.mark.asyncio
    async def test_list_batches(self, tmp_path):
        """GET /pipelines/batches should list available batches."""
        from unittest.mock import MagicMock

        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.pipelines.get_artifact_storage") as mock_get_storage:
                mock_storage = MagicMock()
                mock_storage.list_batches.return_value = ["2025-01-14", "2025-01-13"]
                mock_get_storage.return_value = mock_storage

                response = await client.get("/pipelines/batches")
                assert response.status_code == 200
                assert response.json()["batches"] == ["2025-01-14", "2025-01-13"]

    @pytest.mark.asyncio
    async def test_delete_batch(self, tmp_path):
        """DELETE /pipelines/batches/{batch_id} should delete a batch."""
        from unittest.mock import MagicMock

        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.pipelines.get_artifact_storage") as mock_get_storage:
                mock_storage = MagicMock()
                mock_storage.delete_batch.return_value = True
                mock_get_storage.return_value = mock_storage

                response = await client.delete("/pipelines/batches/2025-01-14")
                assert response.status_code == 200
                assert response.json()["deleted"] is True
