"""TDD tests for REST API app - written BEFORE implementation."""

import pytest
from httpx import ASGITransport, AsyncClient


class TestAPIApp:
    """Tests for FastAPI app setup."""

    def test_create_app_exists(self):
        """create_app function should exist."""
        from redis_agent_kit.api.app import create_app

        assert create_app is not None

    def test_create_app_returns_fastapi(self):
        """create_app should return FastAPI instance."""
        from fastapi import FastAPI

        from redis_agent_kit.api.app import create_app

        app = create_app()
        assert isinstance(app, FastAPI)

    @pytest.mark.asyncio
    async def test_health_endpoint(self):
        """API should have /health endpoint."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/health")
            assert response.status_code == 200
            assert response.json()["status"] == "healthy"

    @pytest.mark.asyncio
    async def test_root_endpoint(self):
        """API should have root endpoint with info."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/")
            assert response.status_code == 200
            assert "redis agent kit" in response.json()["name"].lower()

    @pytest.mark.asyncio
    async def test_docs_endpoint(self):
        """API should have OpenAPI docs."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/docs")
            assert response.status_code == 200


class TestAPIRouters:
    """Tests for API router registration."""

    def test_tasks_router_registered(self):
        """Tasks router should be registered."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        routes = [route.path for route in app.routes]
        assert any("/tasks" in route for route in routes)

    def test_pipelines_router_registered(self):
        """Pipelines router should be registered."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        routes = [route.path for route in app.routes]
        assert any("/pipelines" in route for route in routes)


class TestAPIKwargsPassthrough:
    """Tests for kwargs passthrough to FastAPI."""

    def test_create_app_accepts_kwargs(self):
        """create_app should accept kwargs."""
        from redis_agent_kit.api.app import create_app

        app = create_app(title="Custom Title")
        assert app.title == "Custom Title"

    def test_create_app_custom_description(self):
        """create_app should pass description to FastAPI."""
        from redis_agent_kit.api.app import create_app

        app = create_app(description="Custom description")
        assert app.description == "Custom description"

    def test_create_app_custom_version(self):
        """create_app should pass version to FastAPI."""
        from redis_agent_kit.api.app import create_app

        app = create_app(version="2.0.0")
        assert app.version == "2.0.0"

    def test_create_app_disable_docs(self):
        """create_app should allow disabling docs."""
        from redis_agent_kit.api.app import create_app

        app = create_app(docs_url=None, redoc_url=None)
        assert app.docs_url is None
        assert app.redoc_url is None

    def test_create_app_preserves_defaults(self):
        """create_app should preserve defaults when not overridden."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        assert app.title == "Redis Agent Kit API"
        assert "REST API" in app.description


class TestAPIProtocolSupport:
    """Tests for protocol support in create_app."""

    def test_a2a_requires_agent_card(self):
        """A2A requires agent_card when enabled."""
        from redis_agent_kit.api.app import create_app

        with pytest.raises(ValueError, match="agent_card"):
            create_app(enable_a2a=True)

    def test_acp_requires_agent_manifest(self):
        """ACP requires agent_manifest when enabled."""
        from redis_agent_kit.api.app import create_app

        with pytest.raises(ValueError, match="agent_manifest"):
            create_app(enable_acp=True)

    def test_protocols_require_kit(self):
        """Protocols require kit when enabled."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import AgentCard

        agent_card = AgentCard(name="Test", description="Test", url="http://localhost")
        with pytest.raises(ValueError, match="kit"):
            create_app(enable_a2a=True, agent_card=agent_card)

    def test_a2a_endpoints_when_enabled(self):
        """A2A endpoints are available when enabled."""
        from unittest.mock import MagicMock

        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import AgentCard, Skill

        mock_kit = MagicMock()
        agent_card = AgentCard(
            name="Test Agent",
            description="A test agent",
            url="http://localhost:8000",
            skills=[Skill(id="chat", name="Chat", description="General chat")],
        )
        app = create_app(enable_a2a=True, agent_card=agent_card, kit=mock_kit)
        routes = [route.path for route in app.routes]
        assert "/.well-known/agent.json" in routes

    def test_acp_endpoints_when_enabled(self):
        """ACP endpoints are available when enabled."""
        from unittest.mock import MagicMock

        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import AgentManifest

        mock_kit = MagicMock()
        agent_manifest = AgentManifest(name="test-agent", description="A test agent")
        app = create_app(enable_acp=True, agent_manifest=agent_manifest, kit=mock_kit)
        routes = [route.path for route in app.routes]
        assert "/agents" in routes
        assert "/runs" in routes
