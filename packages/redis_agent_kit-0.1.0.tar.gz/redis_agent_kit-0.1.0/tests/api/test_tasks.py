"""TDD tests for REST API task endpoints - written BEFORE implementation."""

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from httpx import ASGITransport, AsyncClient


class TestTasksListEndpoint:
    """Tests for GET /tasks endpoint."""

    @pytest.mark.asyncio
    async def test_list_tasks_empty(self):
        """GET /tasks should return empty list when no tasks."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.list_tasks.return_value = []
                mock_get_tm.return_value = mock_tm

                response = await client.get("/tasks")
                assert response.status_code == 200
                assert response.json()["tasks"] == []
                assert response.json()["total"] == 0

    @pytest.mark.asyncio
    async def test_list_tasks_returns_tasks(self):
        """GET /tasks should return tasks."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.list_tasks.return_value = [
                    TaskState(
                        task_id="task123",
                        session_id="thread456",
                        status=TaskStatus.IN_PROGRESS,
                    )
                ]
                mock_get_tm.return_value = mock_tm

                response = await client.get("/tasks")
                assert response.status_code == 200
                assert len(response.json()["tasks"]) == 1
                assert response.json()["tasks"][0]["task_id"] == "task123"


class TestTasksGetEndpoint:
    """Tests for GET /tasks/{task_id} endpoint."""

    @pytest.mark.asyncio
    async def test_get_task_success(self):
        """GET /tasks/{task_id} should return task details."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.DONE,
                )
                mock_get_tm.return_value = mock_tm

                response = await client.get("/tasks/task123")
                assert response.status_code == 200
                assert response.json()["task_id"] == "task123"

    @pytest.mark.asyncio
    async def test_get_task_not_found(self):
        """GET /tasks/{task_id} should return 404 when not found."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.get("/tasks/nonexistent")
                assert response.status_code == 404


class TestTasksDeleteEndpoint:
    """Tests for DELETE /tasks/{task_id} endpoint."""

    @pytest.mark.asyncio
    async def test_delete_task_success(self):
        """DELETE /tasks/{task_id} should delete task."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                # get_task returns the task (exists)
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.DONE,
                )
                mock_tm.delete_task.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.delete("/tasks/task123")
                assert response.status_code == 200
                assert response.json()["deleted"] is True

    @pytest.mark.asyncio
    async def test_delete_task_not_found(self):
        """DELETE /tasks/{task_id} should return 404 when not found."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                # get_task returns None (doesn't exist)
                mock_tm.get_task.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.delete("/tasks/nonexistent")
                assert response.status_code == 404


class TestGetTaskManager:
    """Tests for get_task_manager helper."""

    def test_get_task_manager_creates_manager(self):
        """get_task_manager should create TaskManager from request."""
        from unittest.mock import MagicMock

        from redis_agent_kit.api.tasks import get_task_manager

        mock_request = MagicMock()
        mock_request.app.state.redis_url = "redis://localhost:6379"
        mock_request.app.state.prefix = "test"

        tm = get_task_manager(mock_request)
        assert tm is not None
        assert tm._prefix == "test"


class TestCreateTaskEndpoint:
    """Tests for POST /tasks endpoint."""

    @pytest.mark.asyncio
    async def test_create_task_success(self):
        """POST /tasks should create and submit a task."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        mock_kit.create_and_submit_task.return_value = {
            "task_id": "task123",
            "session_id": "thread456",
            "status": "queued",
        }

        app = create_app(kit=mock_kit)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks",
                json={"message": "What is Redis?"},
            )
            assert response.status_code == 200
            data = response.json()
            assert data["task_id"] == "task123"
            assert data["session_id"] == "thread456"
            assert data["status"] == "queued"

            mock_kit.create_and_submit_task.assert_called_once_with(
                message="What is Redis?",
                context={},
                session_id=None,
                caller=None,
            )

    @pytest.mark.asyncio
    async def test_create_task_with_session_id(self):
        """POST /tasks with session_id should use existing session."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        mock_kit.create_and_submit_task.return_value = {
            "task_id": "task123",
            "session_id": "existing-thread",
            "status": "queued",
        }

        app = create_app(kit=mock_kit)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks",
                json={"message": "Follow up", "session_id": "existing-thread"},
            )
            assert response.status_code == 200

            mock_kit.create_and_submit_task.assert_called_once_with(
                message="Follow up",
                context={},
                session_id="existing-thread",
                caller=None,
            )

    @pytest.mark.asyncio
    async def test_create_task_with_context(self):
        """POST /tasks with context should pass context."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        mock_kit.create_and_submit_task.return_value = {
            "task_id": "task123",
            "session_id": "thread456",
            "status": "queued",
        }

        app = create_app(kit=mock_kit)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks",
                json={
                    "message": "Query",
                    "context": {"user_id": "u123", "instance_id": "i456"},
                },
            )
            assert response.status_code == 200

            mock_kit.create_and_submit_task.assert_called_once_with(
                message="Query",
                context={"user_id": "u123", "instance_id": "i456"},
                session_id=None,
                caller=None,
            )

    @pytest.mark.asyncio
    async def test_create_task_no_kit_configured(self):
        """POST /tasks without kit configured should return 500."""
        from redis_agent_kit.api.app import create_app

        # Create app without kit
        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks",
                json={"message": "What is Redis?"},
            )
            assert response.status_code == 500
            assert "AgentKit not configured" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_create_task_missing_message(self):
        """POST /tasks without message should return 422."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        app = create_app(kit=mock_kit)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks",
                json={},  # Missing required message
            )
            assert response.status_code == 422

    @pytest.mark.asyncio
    async def test_create_task_no_agent_callable_raises_value_error(self):
        """POST /tasks when kit raises ValueError should return 400."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        mock_kit.create_and_submit_task.side_effect = ValueError("No agent_callable configured")

        app = create_app(kit=mock_kit)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks",
                json={"message": "What is Redis?"},
            )
            assert response.status_code == 400
            assert "No agent_callable configured" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_create_task_with_caller_body(self):
        """POST /tasks with caller in body should pass caller info."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import CallerType

        mock_kit = AsyncMock()
        mock_kit.create_and_submit_task.return_value = {
            "task_id": "task123",
            "session_id": "thread456",
            "status": "queued",
        }

        app = create_app(kit=mock_kit)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks",
                json={
                    "message": "Query",
                    "caller": {
                        "type": "agent",
                        "id": "research-agent",
                        "name": "Research Agent",
                    },
                },
            )
            assert response.status_code == 200

            # Check caller was passed
            call_args = mock_kit.create_and_submit_task.call_args
            caller = call_args.kwargs["caller"]
            assert caller is not None
            assert caller.type == CallerType.AGENT
            assert caller.id == "research-agent"
            assert caller.name == "Research Agent"

    @pytest.mark.asyncio
    async def test_create_task_with_caller_headers(self):
        """POST /tasks with caller headers should pass caller info."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import CallerType

        mock_kit = AsyncMock()
        mock_kit.create_and_submit_task.return_value = {
            "task_id": "task123",
            "session_id": "thread456",
            "status": "queued",
        }

        app = create_app(kit=mock_kit)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks",
                json={"message": "Query"},
                headers={
                    "X-Caller-Type": "agent",
                    "X-Caller-ID": "data-agent",
                    "X-Caller-Name": "Data Agent",
                },
            )
            assert response.status_code == 200

            # Check caller was passed
            call_args = mock_kit.create_and_submit_task.call_args
            caller = call_args.kwargs["caller"]
            assert caller is not None
            assert caller.type == CallerType.AGENT
            assert caller.id == "data-agent"
            assert caller.name == "Data Agent"


class TestSubmitInputEndpoint:
    """Tests for POST /tasks/{task_id}/input endpoint."""

    @pytest.mark.asyncio
    async def test_submit_input_success(self):
        """POST /tasks/{task_id}/input should submit response."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        mock_kit.submit_input.return_value = True

        app = create_app(kit=mock_kit)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks/task-123/input",
                json={"response": {"choice": "yes"}},
            )
            assert response.status_code == 200
            assert response.json() == {"success": True, "task_id": "task-123"}
            mock_kit.submit_input.assert_called_once_with("task-123", {"choice": "yes"})

    @pytest.mark.asyncio
    async def test_submit_input_returns_400_for_invalid_task_state(self):
        """POST /tasks/{task_id}/input should fail for invalid status."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        mock_kit.submit_input.return_value = False

        app = create_app(kit=mock_kit)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks/task-123/input",
                json={"response": {"choice": "yes"}},
            )
            assert response.status_code == 400
            assert "AWAITING_INPUT" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_submit_input_without_kit_returns_500(self):
        """POST /tasks/{task_id}/input should require configured kit."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks/task-123/input",
                json={"response": {"choice": "yes"}},
            )
            assert response.status_code == 500
            assert "AgentKit not configured" in response.json()["detail"]


class TestCancelTaskEndpoint:
    """Tests for POST /tasks/{task_id}/cancel endpoint."""

    @pytest.mark.asyncio
    async def test_cancel_task_success(self):
        """POST /tasks/{task_id}/cancel should cancel a task."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                # Task exists and is in progress
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.IN_PROGRESS,
                )
                mock_tm.update_status.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/cancel")
                assert response.status_code == 200
                assert response.json()["cancelled"] is True
                assert response.json()["task_id"] == "task123"

                # Verify update_status was called with CANCELLED
                mock_tm.update_status.assert_called_once_with("task123", TaskStatus.CANCELLED)

    @pytest.mark.asyncio
    async def test_cancel_task_not_found(self):
        """POST /tasks/{task_id}/cancel should return 404 when task not found."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/nonexistent/cancel")
                assert response.status_code == 404
                assert "not found" in response.json()["detail"]


class TestStreamTaskEndpoint:
    """Tests for GET /tasks/{task_id}/stream SSE endpoint."""

    @pytest.mark.asyncio
    async def test_stream_task_disabled_by_default(self):
        """GET /tasks/{task_id}/stream should 404 when SSE is not enabled."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/tasks/any-task/stream")
            assert response.status_code == 404
            assert "not enabled" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_stream_task_not_found(self):
        """GET /tasks/{task_id}/stream should 404 when task doesn't exist."""
        from redis_agent_kit.api.app import create_app

        app = create_app(enable_sse=True)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.get("/tasks/nonexistent/stream")
                assert response.status_code == 404
                assert "not found" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_cancel_queued_task(self):
        """POST /tasks/{task_id}/cancel should work on queued tasks."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.QUEUED,
                )
                mock_tm.update_status.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/cancel")
                assert response.status_code == 200
                assert response.json()["cancelled"] is True

    @pytest.mark.asyncio
    async def test_cancel_awaiting_input_task(self):
        """POST /tasks/{task_id}/cancel should work on tasks awaiting input."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.AWAITING_INPUT,
                )
                mock_tm.update_status.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/cancel")
                assert response.status_code == 200
                assert response.json()["cancelled"] is True

    @pytest.mark.asyncio
    async def test_stream_task_already_done_replays_and_closes(self):
        """SSE stream for a completed task should replay updates and close."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus, TaskUpdate

        task = TaskState(
            task_id="task123",
            session_id="session1",
            status=TaskStatus.DONE,
            result={"response": "Hello"},
            updates=[
                TaskUpdate(message="Starting...", update_type="info"),
                TaskUpdate(message="Processing...", update_type="info"),
            ],
        )

        app = create_app(enable_sse=True)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = task
                mock_get_tm.return_value = mock_tm

                # Mock the SSE generator's internal Redis to avoid real connection
                with patch("redis_agent_kit.api.tasks.redis_lib") as mock_redis_lib:
                    mock_client = AsyncMock()
                    mock_redis_lib.from_url.return_value = mock_client

                    # Mock TaskManager inside the generator
                    with patch("redis_agent_kit.api.tasks.TaskManager") as mock_tm_class:
                        mock_tm_inner = AsyncMock()
                        mock_tm_inner.get_task.return_value = task
                        mock_tm_class.return_value = mock_tm_inner

                        mock_pubsub = AsyncMock()
                        mock_client.pubsub = MagicMock(return_value=mock_pubsub)

                        response = await client.get("/tasks/task123/stream")
                        assert response.status_code == 200
                        assert (
                            response.headers["content-type"] == "text/event-stream; charset=utf-8"
                        )

                        # Parse SSE events from the body
                        body = response.text
                        events = [
                            e.strip()
                            for e in body.split("\n\n")
                            if e.strip() and not e.strip().startswith(":")
                        ]

                        # Should have 2 update events + 1 done event
                        assert len(events) == 3

                        # First two are update events
                        assert events[0].startswith("event: update")
                        assert events[1].startswith("event: update")

                        # Last is the done event
                        assert events[2].startswith("event: done")
                        done_data = json.loads(events[2].split("data: ")[1])
                        assert done_data["status"] == "done"
                        assert done_data["result"] == {"response": "Hello"}

    @pytest.mark.asyncio
    async def test_stream_task_no_replay(self):
        """SSE stream with replay=false should not replay existing updates."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus, TaskUpdate

        task = TaskState(
            task_id="task123",
            session_id="session1",
            status=TaskStatus.IN_PROGRESS,
            updates=[
                TaskUpdate(message="Starting...", update_type="info"),
            ],
        )

        app = create_app(enable_sse=True)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = task
                mock_get_tm.return_value = mock_tm

                with patch("redis_agent_kit.api.tasks.redis_lib") as mock_redis_lib:
                    mock_client = AsyncMock()
                    mock_redis_lib.from_url.return_value = mock_client

                    mock_pubsub = AsyncMock()
                    mock_client.pubsub = MagicMock(return_value=mock_pubsub)

                    # Simulate a done event after one keepalive
                    done_event = json.dumps(
                        {
                            "task_id": "task123",
                            "status": "done",
                            "result": {"response": "Done"},
                        }
                    )
                    mock_pubsub.get_message = AsyncMock(
                        side_effect=[
                            None,  # First call: keepalive
                            {"data": done_event},  # Second call: done
                        ]
                    )

                    # Mock is_disconnected
                    response = await client.get(
                        "/tasks/task123/stream",
                        params={"replay": "false"},
                    )
                    assert response.status_code == 200

                    body = response.text
                    # Should not contain replay updates, just keepalive + done
                    events = [
                        e.strip()
                        for e in body.split("\n\n")
                        if e.strip() and not e.strip().startswith(":")
                    ]

                    # Should have only the done event (no replay)
                    assert len(events) == 1
                    assert events[0].startswith("event: done")

    @pytest.mark.asyncio
    async def test_stream_returns_correct_headers(self):
        """SSE stream should include correct SSE headers."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        task = TaskState(
            task_id="task123",
            status=TaskStatus.DONE,
            result={"response": "Hello"},
        )

        app = create_app(enable_sse=True)
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = task
                mock_get_tm.return_value = mock_tm

                with patch("redis_agent_kit.api.tasks.redis_lib") as mock_redis_lib:
                    mock_client = AsyncMock()
                    mock_redis_lib.from_url.return_value = mock_client

                    with patch("redis_agent_kit.api.tasks.TaskManager") as mock_tm_class:
                        mock_tm_inner = AsyncMock()
                        mock_tm_inner.get_task.return_value = task
                        mock_tm_class.return_value = mock_tm_inner

                        mock_pubsub = AsyncMock()
                        mock_client.pubsub = MagicMock(return_value=mock_pubsub)

                        response = await client.get("/tasks/task123/stream")
                        assert response.headers["cache-control"] == "no-cache"
                        assert response.headers["x-accel-buffering"] == "no"

    @pytest.mark.asyncio
    async def test_cancel_already_cancelled_task(self):
        """POST /tasks/{task_id}/cancel should work on already cancelled tasks (idempotent)."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.CANCELLED,
                )
                mock_tm.update_status.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/cancel")
                assert response.status_code == 200
                assert response.json()["cancelled"] is True

    @pytest.mark.asyncio
    async def test_cancel_done_task(self):
        """POST /tasks/{task_id}/cancel should work on completed tasks."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.DONE,
                )
                mock_tm.update_status.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/cancel")
                assert response.status_code == 200
                assert response.json()["cancelled"] is True

    @pytest.mark.asyncio
    async def test_cancel_failed_task(self):
        """POST /tasks/{task_id}/cancel should work on failed tasks."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.FAILED,
                )
                mock_tm.update_status.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/cancel")
                assert response.status_code == 200
                assert response.json()["cancelled"] is True


class TestRestartTaskEndpoint:
    """Tests for POST /tasks/{task_id}/restart endpoint."""

    @pytest.mark.asyncio
    async def test_restart_task_success(self):
        """POST /tasks/{task_id}/restart should restart a cancelled task."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                # Task exists and is cancelled
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.CANCELLED,
                )
                mock_tm.update_status.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/restart")
                assert response.status_code == 200
                assert response.json()["restarted"] is True
                assert response.json()["task_id"] == "task123"

                # Verify update_status was called with QUEUED
                mock_tm.update_status.assert_called_once_with("task123", TaskStatus.QUEUED)

    @pytest.mark.asyncio
    async def test_restart_task_not_found(self):
        """POST /tasks/{task_id}/restart should return 404 when task not found."""
        from redis_agent_kit.api.app import create_app

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = None
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/nonexistent/restart")
                assert response.status_code == 404
                assert "not found" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_restart_task_not_cancelled(self):
        """POST /tasks/{task_id}/restart should return 400 if task is not cancelled."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                # Task is in progress, not cancelled
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.IN_PROGRESS,
                )
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/restart")
                assert response.status_code == 400
                assert "not cancelled" in response.json()["detail"]
                assert "in_progress" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_restart_done_task_fails(self):
        """POST /tasks/{task_id}/restart should fail for completed tasks."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.DONE,
                )
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/restart")
                assert response.status_code == 400
                assert "not cancelled" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_restart_queued_task_fails(self):
        """POST /tasks/{task_id}/restart should fail for already queued tasks."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.QUEUED,
                )
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/restart")
                assert response.status_code == 400
                assert "not cancelled" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_restart_failed_task_fails(self):
        """POST /tasks/{task_id}/restart should fail for failed tasks."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.FAILED,
                )
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/restart")
                assert response.status_code == 400
                assert "not cancelled" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_restart_awaiting_input_task_fails(self):
        """POST /tasks/{task_id}/restart should fail for tasks awaiting input."""
        from redis_agent_kit.api.app import create_app
        from redis_agent_kit.models import TaskState, TaskStatus

        app = create_app()
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with patch("redis_agent_kit.api.tasks.get_task_manager") as mock_get_tm:
                mock_tm = AsyncMock()
                mock_tm.get_task.return_value = TaskState(
                    task_id="task123",
                    session_id="thread456",
                    status=TaskStatus.AWAITING_INPUT,
                )
                mock_get_tm.return_value = mock_tm

                response = await client.post("/tasks/task123/restart")
                assert response.status_code == 400
                assert "not cancelled" in response.json()["detail"]
