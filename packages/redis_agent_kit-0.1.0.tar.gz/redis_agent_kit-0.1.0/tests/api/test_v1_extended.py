"""Additional coverage tests for unified v1 API endpoints."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from redis_agent_kit.models import TaskState, TaskStatus, TaskUpdate


@pytest.mark.asyncio
async def test_v1_capabilities_includes_enabled_protocols() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app(
        enable_a2a=True,
        enable_acp=True,
        enable_mcp=True,
        kit=MagicMock(),
        agent_card=MagicMock(),
        agent_manifest=MagicMock(),
    )
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/v1/capabilities")
    payload = response.json()["data"]
    assert set(payload["protocols"]) == {"rest", "a2a", "acp", "mcp"}


@pytest.mark.asyncio
async def test_v1_get_agent_not_found() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app(default_agent_id="default")
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/v1/projects/p1/agents/not-default")
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_v1_get_agent_success() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app(default_agent_id="default")
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/v1/projects/p1/agents/default")
    assert response.status_code == 200
    assert response.json()["data"]["agent"]["agentId"] == "default"


@pytest.mark.asyncio
async def test_v1_create_task_without_kit_returns_500() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app()
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/v1/projects/p1/agents/default/tasks",
            json={"request": {"protocol": "rest", "input": {"message": "hello"}}},
        )
    assert response.status_code == 500


@pytest.mark.asyncio
async def test_v1_create_task_uses_text_fallback_and_caller_metadata_sanitization() -> None:
    from redis_agent_kit.api.app import create_app

    mock_kit = AsyncMock()
    mock_kit.create_and_submit_task.return_value = {"task_id": "t1", "session_id": "s1"}
    app = create_app(kit=mock_kit)

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/v1/projects/p1/agents/default/tasks",
            json={
                "request": {"protocol": "rest", "input": {"text": "hello-text"}},
                "caller": {"type": "human", "id": 42, "name": "u1", "metadata": "bad"},
            },
        )

    assert response.status_code == 200
    kwargs = mock_kit.create_and_submit_task.call_args.kwargs
    assert kwargs["message"] == "hello-text"
    assert kwargs["caller"].metadata == {}
    assert kwargs["caller"].id is None


@pytest.mark.asyncio
async def test_v1_create_task_defaults_message_when_request_input_not_dict() -> None:
    from redis_agent_kit.api.app import create_app

    mock_kit = AsyncMock()
    mock_kit.create_and_submit_task.return_value = {"task_id": "t1", "session_id": "s1"}
    app = create_app(kit=mock_kit)

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/v1/projects/p1/agents/default/tasks",
            json={"request": {"input": "not-an-object"}},
        )

    assert response.status_code == 200
    assert mock_kit.create_and_submit_task.call_args.kwargs["message"] == "Task request"


@pytest.mark.asyncio
async def test_v1_list_tasks_passes_status_filter() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app()
    mock_manager = AsyncMock()
    mock_manager.list_tasks.return_value = []
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        with patch("redis_agent_kit.api.v1._task_manager", return_value=mock_manager):
            response = await client.get("/v1/projects/p1/agents/default/tasks?status=in_progress")
    assert response.status_code == 200
    assert mock_manager.list_tasks.call_args.kwargs["status"] == TaskStatus.IN_PROGRESS


@pytest.mark.asyncio
async def test_v1_get_task_result_logs_and_cancel_not_found_paths() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app()
    mock_manager = AsyncMock()
    mock_manager.get_task.return_value = None

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        with patch("redis_agent_kit.api.v1._task_manager", return_value=mock_manager):
            response_get = await client.get("/v1/projects/p1/agents/default/tasks/missing")
            response_result = await client.get(
                "/v1/projects/p1/agents/default/tasks/missing/result"
            )
            response_logs = await client.get("/v1/projects/p1/agents/default/tasks/missing/logs")
            response_cancel = await client.post(
                "/v1/projects/p1/agents/default/tasks/missing/cancel"
            )

    assert response_get.status_code == 404
    assert response_result.status_code == 404
    assert response_logs.status_code == 404
    assert response_cancel.status_code == 404


@pytest.mark.asyncio
async def test_v1_get_task_and_result_success_paths() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app()
    task = TaskState(task_id="t1", session_id="s1", status=TaskStatus.DONE, result={"ok": True})
    mock_manager = AsyncMock()
    mock_manager.get_task.return_value = task

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        with patch("redis_agent_kit.api.v1._task_manager", return_value=mock_manager):
            response_get = await client.get("/v1/projects/p1/agents/default/tasks/t1")
            response_result = await client.get("/v1/projects/p1/agents/default/tasks/t1/result")

    assert response_get.status_code == 200
    assert response_get.json()["data"]["task"]["taskId"] == "t1"
    assert response_result.status_code == 200
    assert response_result.json()["data"]["taskId"] == "t1"


@pytest.mark.asyncio
async def test_v1_logs_limit_and_cancel_success() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app()
    task = TaskState(
        task_id="t1",
        session_id="s1",
        status=TaskStatus.IN_PROGRESS,
        updates=[
            TaskUpdate(message="first", update_type="info"),
            TaskUpdate(message="second", update_type="info"),
        ],
    )
    mock_manager = AsyncMock()
    mock_manager.get_task.return_value = task

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        with patch("redis_agent_kit.api.v1._task_manager", return_value=mock_manager):
            logs_response = await client.get("/v1/projects/p1/agents/default/tasks/t1/logs?limit=1")
            cancel_response = await client.post("/v1/projects/p1/agents/default/tasks/t1/cancel")

    assert logs_response.status_code == 200
    logs = logs_response.json()["data"]["logs"]
    assert len(logs) == 1
    assert logs[0]["message"] == "second"
    assert cancel_response.status_code == 200
    mock_manager.update_status.assert_awaited_once_with("t1", TaskStatus.CANCELLED)


@pytest.mark.asyncio
async def test_v1_submit_task_input_error_and_success_paths() -> None:
    from redis_agent_kit.api.app import create_app

    app_without_kit = create_app()
    async with AsyncClient(
        transport=ASGITransport(app=app_without_kit), base_url="http://test"
    ) as client:
        response = await client.post(
            "/v1/projects/p1/agents/default/tasks/t1/input",
            json={"response": {"value": 1}},
        )
    assert response.status_code == 500

    mock_kit = AsyncMock()
    mock_kit.submit_input.return_value = False
    app_with_kit = create_app(kit=mock_kit)
    async with AsyncClient(
        transport=ASGITransport(app=app_with_kit), base_url="http://test"
    ) as client:
        failure_response = await client.post(
            "/v1/projects/p1/agents/default/tasks/t1/input",
            json={"response": {"value": 1}},
        )
    assert failure_response.status_code == 400

    mock_kit.submit_input.return_value = True
    async with AsyncClient(
        transport=ASGITransport(app=app_with_kit), base_url="http://test"
    ) as client:
        success_response = await client.post(
            "/v1/projects/p1/agents/default/tasks/t1/input",
            json={"response": {"value": 1}},
        )
    assert success_response.status_code == 200


def test_v1_task_manager_uses_request_state() -> None:
    from redis_agent_kit.api.v1 import _task_manager

    request = SimpleNamespace(
        app=SimpleNamespace(state=SimpleNamespace(redis_url="redis://localhost:6379", prefix="rak"))
    )
    with (
        patch("redis_agent_kit.api.v1.redis_lib.from_url", return_value="client") as from_url,
        patch("redis_agent_kit.api.v1.TaskManager") as task_manager_cls,
    ):
        manager = _task_manager(request)
    from_url.assert_called_once_with("redis://localhost:6379")
    task_manager_cls.assert_called_once_with("client", prefix="rak")
    assert manager == task_manager_cls.return_value


def test_v1_extract_message_with_non_dict_request_payload() -> None:
    from redis_agent_kit.api.v1 import _extract_message

    payload = SimpleNamespace(request="not-a-dict")
    assert _extract_message(payload) == ""
