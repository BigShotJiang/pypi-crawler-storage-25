"""Tests for protocol adapters."""
