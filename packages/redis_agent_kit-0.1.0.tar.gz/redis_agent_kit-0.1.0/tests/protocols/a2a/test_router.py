"""Tests for A2A protocol router."""

from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from redis_agent_kit.models import AgentCard, Skill, TaskState, TaskStatus
from redis_agent_kit.protocols.a2a.router import create_a2a_router


@pytest.fixture
def agent_card():
    """Create a test agent card."""
    return AgentCard(
        name="Test Agent",
        description="A test agent",
        url="http://localhost:8000",
        skills=[Skill(id="chat", name="Chat", description="General chat")],
        capabilities={"streaming": False},
    )


@pytest.fixture
def mock_kit():
    """Create a mock AgentKit."""
    kit = MagicMock()
    kit.task_manager = MagicMock()
    kit.thread_manager = MagicMock()

    # Set up async create_and_submit_task
    kit.create_and_submit_task = AsyncMock(
        return_value={
            "task_id": "task-123",
            "thread_id": "thread-456",
            "status": "queued",
        }
    )

    # Set up async get_task for retrieving created task
    kit.task_manager.get_task = AsyncMock(
        return_value=TaskState(
            task_id="task-123",
            thread_id="thread-456",
            status=TaskStatus.QUEUED,
        )
    )

    return kit


@pytest.fixture
def app(agent_card, mock_kit):
    """Create a FastAPI app with A2A router."""
    app = FastAPI()
    router = create_a2a_router(agent_card=agent_card, kit=mock_kit)
    app.include_router(router)
    # Store mock_kit on app for test access
    app.state.mock_kit = mock_kit
    return app


@pytest.fixture
def client(app):
    """Create a test client."""
    return TestClient(app)


class TestAgentCardEndpoint:
    """Tests for agent card discovery endpoint."""

    def test_get_agent_card(self, client, agent_card):
        """GET /.well-known/agent.json returns agent card."""
        response = client.get("/.well-known/agent.json")
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Test Agent"
        assert data["description"] == "A test agent"
        assert data["url"] == "http://localhost:8000"
        assert len(data["skills"]) == 1
        assert data["skills"][0]["id"] == "chat"


class TestMessageSendEndpoint:
    """Tests for message/send JSON-RPC endpoint."""

    def test_send_message_creates_task(self, client, app):
        """POST / with message/send creates a task."""
        request = {
            "jsonrpc": "2.0",
            "method": "message/send",
            "params": {
                "message": {
                    "role": "user",
                    "parts": [{"type": "text", "text": "Hello!"}],
                }
            },
            "id": "req-1",
        }
        response = client.post("/", json=request)
        assert response.status_code == 200
        data = response.json()
        assert data["jsonrpc"] == "2.0"
        assert data["id"] == "req-1"
        assert "result" in data
        assert data["result"]["id"] == "task-123"

    def test_send_message_with_context_id(self, client, app):
        """POST / with message/send uses provided contextId."""
        mock_kit = app.state.mock_kit
        mock_kit.create_and_submit_task = AsyncMock(
            return_value={
                "task_id": "task-123",
                "thread_id": "existing-thread",
                "status": "queued",
            }
        )
        mock_kit.task_manager.get_task = AsyncMock(
            return_value=TaskState(
                task_id="task-123",
                thread_id="existing-thread",
                status=TaskStatus.QUEUED,
            )
        )

        request = {
            "jsonrpc": "2.0",
            "method": "message/send",
            "params": {
                "message": {
                    "role": "user",
                    "parts": [{"type": "text", "text": "Hello!"}],
                },
                "contextId": "existing-thread",
            },
            "id": "req-2",
        }
        response = client.post("/", json=request)
        assert response.status_code == 200
        # Verify create_and_submit_task was called with the context_id as session_id
        mock_kit.create_and_submit_task.assert_called_once()
        call_kwargs = mock_kit.create_and_submit_task.call_args.kwargs
        assert call_kwargs["session_id"] == "existing-thread"

    def test_send_message_with_callback_url(self, client, app):
        """POST / with message/send passes callbackUrl in context."""
        mock_kit = app.state.mock_kit

        request = {
            "jsonrpc": "2.0",
            "method": "message/send",
            "params": {
                "message": {
                    "role": "user",
                    "parts": [{"type": "text", "text": "Hello!"}],
                },
                "callbackUrl": "https://example.com/webhook",
            },
            "id": "req-callback",
        }
        response = client.post("/", json=request)
        assert response.status_code == 200

        # Verify callback_url was passed in context
        mock_kit.create_and_submit_task.assert_called_once()
        call_kwargs = mock_kit.create_and_submit_task.call_args.kwargs
        assert call_kwargs["context"]["callback_url"] == "https://example.com/webhook"


class TestTasksGetEndpoint:
    """Tests for tasks/get JSON-RPC endpoint."""

    def test_get_task(self, client, app):
        """POST / with tasks/get returns task."""
        mock_kit = app.state.mock_kit
        mock_kit.task_manager.get_task = AsyncMock(
            return_value=TaskState(
                task_id="task-123",
                thread_id="thread-456",
                status=TaskStatus.IN_PROGRESS,
            )
        )

        request = {
            "jsonrpc": "2.0",
            "method": "tasks/get",
            "params": {"id": "task-123"},
            "id": "req-3",
        }
        response = client.post("/", json=request)
        assert response.status_code == 200
        data = response.json()
        assert data["result"]["id"] == "task-123"
        assert data["result"]["status"]["state"] == "working"

    def test_get_task_not_found(self, client, app):
        """POST / with tasks/get returns error for missing task."""
        mock_kit = app.state.mock_kit
        mock_kit.task_manager.get_task = AsyncMock(return_value=None)

        request = {
            "jsonrpc": "2.0",
            "method": "tasks/get",
            "params": {"id": "nonexistent"},
            "id": "req-4",
        }
        response = client.post("/", json=request)
        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert data["error"]["code"] == -32001


class TestTasksCancelEndpoint:
    """Tests for tasks/cancel JSON-RPC endpoint."""

    def test_cancel_task(self, client, app):
        """POST / with tasks/cancel cancels task."""
        mock_kit = app.state.mock_kit
        mock_kit.task_manager.get_task = AsyncMock(
            return_value=TaskState(
                task_id="task-123",
                thread_id="thread-456",
                status=TaskStatus.CANCELLED,
            )
        )
        mock_kit.task_manager.update_status = AsyncMock()

        request = {
            "jsonrpc": "2.0",
            "method": "tasks/cancel",
            "params": {"id": "task-123"},
            "id": "req-5",
        }
        response = client.post("/", json=request)
        assert response.status_code == 200
        data = response.json()
        assert data["result"]["id"] == "task-123"
        assert data["result"]["status"]["state"] == "canceled"

    def test_cancel_task_not_found(self, client, app):
        """POST / with tasks/cancel returns error for missing task."""
        mock_kit = app.state.mock_kit
        mock_kit.task_manager.get_task = AsyncMock(return_value=None)

        request = {
            "jsonrpc": "2.0",
            "method": "tasks/cancel",
            "params": {"id": "nonexistent"},
            "id": "req-6",
        }
        response = client.post("/", json=request)
        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert data["error"]["code"] == -32001


class TestMethodNotFound:
    """Tests for method not found error."""

    def test_unknown_method(self, client):
        """POST / with unknown method returns error."""
        request = {
            "jsonrpc": "2.0",
            "method": "unknown/method",
            "params": {},
            "id": "req-7",
        }
        response = client.post("/", json=request)
        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert data["error"]["code"] == -32601
        assert "unknown/method" in data["error"]["message"]


class TestInternalError:
    """Tests for internal error handling."""

    def test_internal_error(self, client, app):
        """POST / returns internal error on exception."""
        mock_kit = app.state.mock_kit
        mock_kit.create_and_submit_task = AsyncMock(
            side_effect=Exception("Database connection failed")
        )

        request = {
            "jsonrpc": "2.0",
            "method": "message/send",
            "params": {
                "message": {
                    "role": "user",
                    "parts": [{"type": "text", "text": "Hello!"}],
                }
            },
            "id": "req-8",
        }
        response = client.post("/", json=request)
        assert response.status_code == 200
        data = response.json()
        assert "error" in data
        assert data["error"]["code"] == -32603
        assert "Database connection failed" in data["error"]["message"]
