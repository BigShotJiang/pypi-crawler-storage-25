"""Tests for unified multi-protocol server factory."""

from unittest.mock import MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from redis_agent_kit.models import AgentCard, AgentManifest, Skill, TaskState, TaskStatus
from redis_agent_kit.protocols.unified import ProtocolConfig, create_multi_protocol_app


@pytest.fixture
def agent_card():
    """Create a test agent card."""
    return AgentCard(
        name="Test Agent",
        description="A test agent",
        url="http://localhost:8000",
        skills=[Skill(id="chat", name="Chat", description="General chat")],
        capabilities={"streaming": False},
    )


@pytest.fixture
def agent_manifest():
    """Create a test agent manifest."""
    return AgentManifest(
        name="test-agent",
        description="A test agent",
    )


@pytest.fixture
def mock_kit():
    """Create a mock AgentKit."""
    kit = MagicMock()
    kit.task_manager = MagicMock()
    kit.thread_manager = MagicMock()
    kit.task_manager.create_task = MagicMock(
        return_value=TaskState(
            task_id="task-123",
            thread_id="thread-456",
            status=TaskStatus.QUEUED,
        )
    )
    kit.thread_manager.get_or_create_thread = MagicMock(
        return_value=MagicMock(thread_id="thread-456")
    )
    return kit


class TestProtocolConfig:
    """Tests for ProtocolConfig."""

    def test_default_config(self):
        """Default config has all protocols disabled."""
        config = ProtocolConfig()
        assert config.enable_a2a is False
        assert config.enable_acp is False
        assert config.enable_rest is True  # REST is default

    def test_enable_all(self):
        """Can enable all protocols."""
        config = ProtocolConfig(enable_a2a=True, enable_acp=True, enable_rest=True)
        assert config.enable_a2a is True
        assert config.enable_acp is True
        assert config.enable_rest is True


class TestCreateMultiProtocolApp:
    """Tests for create_multi_protocol_app."""

    def test_creates_fastapi_app(self, mock_kit):
        """Creates a FastAPI app."""
        app = create_multi_protocol_app(kit=mock_kit)
        assert isinstance(app, FastAPI)

    def test_a2a_endpoints_when_enabled(self, mock_kit, agent_card):
        """A2A endpoints are available when enabled."""
        config = ProtocolConfig(enable_a2a=True)
        app = create_multi_protocol_app(
            kit=mock_kit,
            config=config,
            agent_card=agent_card,
        )
        client = TestClient(app)

        # Agent card endpoint
        response = client.get("/.well-known/agent.json")
        assert response.status_code == 200
        assert response.json()["name"] == "Test Agent"

    def test_acp_endpoints_when_enabled(self, mock_kit, agent_manifest):
        """ACP endpoints are available when enabled."""
        config = ProtocolConfig(enable_acp=True)
        app = create_multi_protocol_app(
            kit=mock_kit,
            config=config,
            agent_manifest=agent_manifest,
        )
        client = TestClient(app)

        # Agents endpoint
        response = client.get("/agents")
        assert response.status_code == 200
        assert response.json()[0]["name"] == "test-agent"

    def test_both_protocols_enabled(self, mock_kit, agent_card, agent_manifest):
        """Both A2A and ACP can be enabled simultaneously."""
        config = ProtocolConfig(enable_a2a=True, enable_acp=True)
        app = create_multi_protocol_app(
            kit=mock_kit,
            config=config,
            agent_card=agent_card,
            agent_manifest=agent_manifest,
        )
        client = TestClient(app)

        # A2A endpoint
        response = client.get("/.well-known/agent.json")
        assert response.status_code == 200

        # ACP endpoint
        response = client.get("/agents")
        assert response.status_code == 200

    def test_a2a_requires_agent_card(self, mock_kit):
        """A2A requires agent_card when enabled."""
        config = ProtocolConfig(enable_a2a=True)
        with pytest.raises(ValueError, match="agent_card"):
            create_multi_protocol_app(kit=mock_kit, config=config)

    def test_acp_requires_agent_manifest(self, mock_kit):
        """ACP requires agent_manifest when enabled."""
        config = ProtocolConfig(enable_acp=True)
        with pytest.raises(ValueError, match="agent_manifest"):
            create_multi_protocol_app(kit=mock_kit, config=config)

    def test_custom_fastapi_kwargs(self, mock_kit):
        """Custom kwargs are passed to FastAPI."""
        app = create_multi_protocol_app(
            kit=mock_kit,
            title="Custom Title",
            version="2.0.0",
        )
        assert app.title == "Custom Title"
        assert app.version == "2.0.0"
