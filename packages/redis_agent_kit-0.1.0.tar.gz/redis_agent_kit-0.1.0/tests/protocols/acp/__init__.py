"""Tests for ACP protocol adapter."""
