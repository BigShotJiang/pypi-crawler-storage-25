"""Tests for ACP protocol router."""

from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from redis_agent_kit.models import AgentManifest, TaskState, TaskStatus
from redis_agent_kit.protocols.acp.router import create_acp_router


@pytest.fixture
def agent_manifest():
    """Create a test agent manifest."""
    return AgentManifest(
        name="test-agent",
        description="A test agent",
    )


@pytest.fixture
def mock_kit():
    """Create a mock AgentKit."""
    kit = MagicMock()
    kit.task_manager = MagicMock()
    kit.thread_manager = MagicMock()

    # Set up async create_and_submit_task
    kit.create_and_submit_task = AsyncMock(
        return_value={
            "task_id": "run-123",
            "thread_id": "session-456",
            "status": "queued",
        }
    )

    # Set up async get_task for retrieving created task
    kit.task_manager.get_task = AsyncMock(
        return_value=TaskState(
            task_id="run-123",
            thread_id="session-456",
            status=TaskStatus.QUEUED,
        )
    )

    # Set up async update_status
    kit.task_manager.update_status = AsyncMock()

    return kit


@pytest.fixture
def app(agent_manifest, mock_kit):
    """Create a FastAPI app with ACP router."""
    app = FastAPI()
    router = create_acp_router(agent_manifest=agent_manifest, kit=mock_kit)
    app.include_router(router)
    app.state.mock_kit = mock_kit
    return app


@pytest.fixture
def client(app):
    """Create a test client."""
    return TestClient(app)


class TestAgentManifestEndpoint:
    """Tests for /agents endpoint."""

    def test_get_agents(self, client, agent_manifest):
        """GET /agents returns agent manifest."""
        response = client.get("/agents")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["name"] == "test-agent"
        assert data[0]["description"] == "A test agent"


class TestRunsEndpoint:
    """Tests for /runs endpoint."""

    def test_create_run(self, client, app):
        """POST /runs creates a run."""
        request = {
            "agent_name": "test-agent",
            "input": [
                {
                    "role": "user",
                    "parts": [{"type": "text", "content": "Hello!"}],
                }
            ],
        }
        response = client.post("/runs", json=request)
        assert response.status_code == 200
        data = response.json()
        assert data["id"] == "run-123"
        assert data["agent_name"] == "test-agent"
        assert data["status"]["state"] == "created"

    def test_create_run_with_session(self, client, app):
        """POST /runs with session_id uses existing session."""
        mock_kit = app.state.mock_kit
        mock_kit.create_and_submit_task = AsyncMock(
            return_value={
                "task_id": "run-123",
                "thread_id": "existing-session",
                "status": "queued",
            }
        )
        mock_kit.task_manager.get_task = AsyncMock(
            return_value=TaskState(
                task_id="run-123",
                thread_id="existing-session",
                status=TaskStatus.QUEUED,
            )
        )

        request = {
            "agent_name": "test-agent",
            "session_id": "existing-session",
            "input": [
                {
                    "role": "user",
                    "parts": [{"type": "text", "content": "Hello!"}],
                }
            ],
        }
        response = client.post("/runs", json=request)
        assert response.status_code == 200
        # Verify create_and_submit_task was called with the session_id
        mock_kit.create_and_submit_task.assert_called_once()
        call_kwargs = mock_kit.create_and_submit_task.call_args.kwargs
        assert call_kwargs["session_id"] == "existing-session"

    def test_create_run_with_callback_url(self, client, app):
        """POST /runs with callback_url passes it in context."""
        mock_kit = app.state.mock_kit

        request = {
            "agent_name": "test-agent",
            "callback_url": "https://example.com/webhook",
            "input": [
                {
                    "role": "user",
                    "parts": [{"type": "text", "content": "Hello!"}],
                }
            ],
        }
        response = client.post("/runs", json=request)
        assert response.status_code == 200

        # Verify callback_url was passed in context
        mock_kit.create_and_submit_task.assert_called_once()
        call_kwargs = mock_kit.create_and_submit_task.call_args.kwargs
        assert call_kwargs["context"]["callback_url"] == "https://example.com/webhook"


class TestRunEndpoint:
    """Tests for /runs/{run_id} endpoint."""

    def test_get_run(self, client, app):
        """GET /runs/{run_id} returns run."""
        mock_kit = app.state.mock_kit
        mock_kit.task_manager.get_task = AsyncMock(
            return_value=TaskState(
                task_id="run-123",
                thread_id="session-456",
                status=TaskStatus.IN_PROGRESS,
            )
        )

        response = client.get("/runs/run-123")
        assert response.status_code == 200
        data = response.json()
        assert data["id"] == "run-123"
        assert data["status"]["state"] == "in_progress"

    def test_get_run_not_found(self, client, app):
        """GET /runs/{run_id} returns 404 for missing run."""
        mock_kit = app.state.mock_kit
        mock_kit.task_manager.get_task = AsyncMock(return_value=None)

        response = client.get("/runs/nonexistent")
        assert response.status_code == 404
        data = response.json()
        assert "not found" in data["detail"].lower()

    def test_cancel_run(self, client, app):
        """POST /runs/{run_id}/cancel cancels run."""
        mock_kit = app.state.mock_kit
        mock_kit.task_manager.get_task = AsyncMock(
            return_value=TaskState(
                task_id="run-123",
                thread_id="session-456",
                status=TaskStatus.CANCELLED,
            )
        )
        mock_kit.task_manager.update_status = AsyncMock()

        response = client.post("/runs/run-123/cancel")
        assert response.status_code == 200
        data = response.json()
        assert data["status"]["state"] == "cancelled"

    def test_cancel_run_not_found(self, client, app):
        """POST /runs/{run_id}/cancel returns 404 for missing run."""
        mock_kit = app.state.mock_kit
        mock_kit.task_manager.get_task = AsyncMock(return_value=None)

        response = client.post("/runs/nonexistent/cancel")
        assert response.status_code == 404
        data = response.json()
        assert "not found" in data["detail"].lower()
