"""Tests for task handler middleware."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from redis_agent_kit.middleware import (
    EmitterMiddleware,
    MemoryMiddleware,
    MiddlewareChain,
    PipelineContext,
    PipelineLoggingMiddleware,
    PipelineMiddleware,
    PipelineMiddlewareChain,
    PipelineTimingMiddleware,
    PipelineValidationMiddleware,
    RAGMiddleware,
    ResultMiddleware,
    TaskContext,
    TaskMiddleware,
)
from redis_agent_kit.models import TaskState, TaskStatus
from redis_agent_kit.pipelines import PipelineConfig, PipelineOrchestrator, SourceConfig


class TestTaskContext:
    """Tests for TaskContext dataclass."""

    def test_task_context_required_fields(self):
        """Test TaskContext with required fields."""

        kit = MagicMock()
        emitter = MagicMock()
        memory = MagicMock()

        ctx = TaskContext(
            task_id="task-123",
            session_id="session-456",
            message="Hello",
            context={"user_id": "u1"},
            kit=kit,
            emitter=emitter,
            memory=memory,
        )

        assert ctx.task_id == "task-123"
        assert ctx.session_id == "session-456"
        assert ctx.message == "Hello"
        assert ctx.context == {"user_id": "u1"}
        assert ctx.kit is kit
        assert ctx.emitter is emitter
        assert ctx.memory is memory
        assert ctx.rag_context == ""
        assert ctx.metadata == {}

    def test_task_context_with_optional_fields(self):
        """Test TaskContext with optional fields."""

        ctx = TaskContext(
            task_id="task-123",
            session_id="session-456",
            message="Hello",
            context={},
            kit=MagicMock(),
            emitter=MagicMock(),
            memory=MagicMock(),
            rag_context="Some context",
            metadata={"key": "value"},
        )

        assert ctx.rag_context == "Some context"
        assert ctx.metadata == {"key": "value"}


class TestMiddlewareChain:
    """Tests for MiddlewareChain."""

    @pytest.mark.asyncio
    async def test_chain_with_no_middleware(self):
        """Test chain calls handler directly when no middleware."""

        async def handler(ctx: TaskContext) -> dict:
            return {"response": f"Got: {ctx.message}"}

        chain = MiddlewareChain(handler, middleware=[])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            memory=MagicMock(),
            message="test",
            context={},
            kit=MagicMock(),
            emitter=MagicMock(),
        )

        result = await chain(ctx)
        assert result == {"response": "Got: test"}

    @pytest.mark.asyncio
    async def test_chain_with_single_middleware(self):
        """Test chain with single middleware."""

        class AddPrefixMiddleware(TaskMiddleware):
            async def __call__(self, ctx, next):
                ctx.message = f"[PREFIX] {ctx.message}"
                return await next(ctx)

        async def handler(ctx: TaskContext) -> dict:
            return {"response": ctx.message}

        chain = MiddlewareChain(handler, middleware=[AddPrefixMiddleware()])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            memory=MagicMock(),
            message="test",
            context={},
            kit=MagicMock(),
            emitter=MagicMock(),
        )

        result = await chain(ctx)
        assert result == {"response": "[PREFIX] test"}

    @pytest.mark.asyncio
    async def test_chain_with_multiple_middleware(self):
        """Test chain with multiple middleware in order."""

        class FirstMiddleware(TaskMiddleware):
            async def __call__(self, ctx, next):
                ctx.metadata["order"] = ctx.metadata.get("order", []) + ["first"]
                return await next(ctx)

        class SecondMiddleware(TaskMiddleware):
            async def __call__(self, ctx, next):
                ctx.metadata["order"] = ctx.metadata.get("order", []) + ["second"]
                return await next(ctx)

        async def handler(ctx: TaskContext) -> dict:
            ctx.metadata["order"] = ctx.metadata.get("order", []) + ["handler"]
            return {"order": ctx.metadata["order"]}

        chain = MiddlewareChain(handler, middleware=[FirstMiddleware(), SecondMiddleware()])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            memory=MagicMock(),
            message="test",
            context={},
            kit=MagicMock(),
            emitter=MagicMock(),
        )

        result = await chain(ctx)
        assert result["order"] == ["first", "second", "handler"]


class TestEmitterMiddleware:
    """Tests for EmitterMiddleware."""

    @pytest.mark.asyncio
    async def test_emitter_middleware_emits_start_message(self):
        """Test EmitterMiddleware emits start message."""

        emitter = MagicMock()
        emitter.emit = AsyncMock()

        async def handler(ctx: TaskContext) -> dict:
            return {"response": "done"}

        middleware = EmitterMiddleware(start_message="Starting task...")
        chain = MiddlewareChain(handler, middleware=[middleware])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            memory=MagicMock(),
            message="test",
            context={},
            kit=MagicMock(),
            emitter=emitter,
        )

        await chain(ctx)
        emitter.emit.assert_called_with("Starting task...")

    @pytest.mark.asyncio
    async def test_emitter_middleware_emits_end_message(self):
        """Test EmitterMiddleware emits end message when configured."""

        emitter = MagicMock()
        emitter.emit = AsyncMock()

        async def handler(ctx: TaskContext) -> dict:
            return {"response": "done"}

        middleware = EmitterMiddleware(start_message="Start", end_message="End")
        chain = MiddlewareChain(handler, middleware=[middleware])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            memory=MagicMock(),
            message="test",
            context={},
            kit=MagicMock(),
            emitter=emitter,
        )

        await chain(ctx)
        assert emitter.emit.call_count == 2
        emitter.emit.assert_any_call("Start")
        emitter.emit.assert_any_call("End")


class TestMemoryMiddleware:
    """Tests for MemoryMiddleware."""

    @pytest.mark.asyncio
    async def test_memory_middleware_saves_response(self):
        """Test MemoryMiddleware saves response to memory."""

        kit = MagicMock()
        memory = MagicMock()
        memory.enabled = True
        memory.add_message = AsyncMock()

        async def handler(ctx: TaskContext) -> dict:
            return {"response": "Hello, user!"}

        middleware = MemoryMiddleware()
        chain = MiddlewareChain(handler, middleware=[middleware])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            message="test",
            context={},
            kit=kit,
            emitter=MagicMock(),
            memory=memory,
        )

        await chain(ctx)
        memory.add_message.assert_called_once_with(role="assistant", content="Hello, user!")

    @pytest.mark.asyncio
    async def test_memory_middleware_custom_response_key(self):
        """Test MemoryMiddleware with custom response key."""

        kit = MagicMock()
        memory = MagicMock()
        memory.enabled = True
        memory.add_message = AsyncMock()

        async def handler(ctx: TaskContext) -> dict:
            return {"answer": "Custom response"}

        middleware = MemoryMiddleware(response_key="answer")
        chain = MiddlewareChain(handler, middleware=[middleware])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            message="test",
            context={},
            kit=kit,
            emitter=MagicMock(),
            memory=memory,
        )

        await chain(ctx)
        memory.add_message.assert_called_once_with(role="assistant", content="Custom response")

    @pytest.mark.asyncio
    async def test_memory_middleware_no_response_key(self):
        """Test MemoryMiddleware does nothing when response key missing."""

        kit = MagicMock()
        memory = MagicMock()
        memory.enabled = True
        memory.add_message = AsyncMock()

        async def handler(ctx: TaskContext) -> dict:
            return {"other_key": "value"}

        middleware = MemoryMiddleware()
        chain = MiddlewareChain(handler, middleware=[middleware])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            message="test",
            context={},
            kit=kit,
            emitter=MagicMock(),
            memory=memory,
        )

        await chain(ctx)
        memory.add_message.assert_not_called()


class TestResultMiddleware:
    """Tests for ResultMiddleware."""

    @pytest.mark.asyncio
    async def test_result_middleware_sets_result_on_success(self):
        """Test ResultMiddleware sets result on success."""

        kit = MagicMock()
        kit.task_manager = MagicMock()
        kit.task_manager.set_result = AsyncMock()
        kit.task_manager.set_error = AsyncMock()
        # Mock get_task to return a task with IN_PROGRESS status
        mock_task = TaskState(task_id="t1", status=TaskStatus.IN_PROGRESS)
        kit.task_manager.get_task = AsyncMock(return_value=mock_task)

        async def handler(ctx: TaskContext) -> dict:
            return {"response": "Success!"}

        middleware = ResultMiddleware()
        chain = MiddlewareChain(handler, middleware=[middleware])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            memory=MagicMock(),
            message="test",
            context={},
            kit=kit,
            emitter=MagicMock(),
        )

        result = await chain(ctx)
        assert result == {"response": "Success!"}
        kit.task_manager.set_result.assert_called_once_with("t1", {"response": "Success!"})
        kit.task_manager.set_error.assert_not_called()

    @pytest.mark.asyncio
    async def test_result_middleware_sets_error_on_exception(self):
        """Test ResultMiddleware sets error on exception."""

        kit = MagicMock()
        kit.task_manager = MagicMock()
        kit.task_manager.set_result = AsyncMock()
        kit.task_manager.set_error = AsyncMock()

        async def handler(ctx: TaskContext) -> dict:
            raise ValueError("Something went wrong")

        middleware = ResultMiddleware()
        chain = MiddlewareChain(handler, middleware=[middleware])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            memory=MagicMock(),
            message="test",
            context={},
            kit=kit,
            emitter=MagicMock(),
        )

        with pytest.raises(ValueError, match="Something went wrong"):
            await chain(ctx)

        kit.task_manager.set_error.assert_called_once_with("t1", "Something went wrong")
        kit.task_manager.set_result.assert_not_called()

    @pytest.mark.asyncio
    async def test_result_middleware_updates_result_when_awaiting_input(self):
        """ResultMiddleware should not move task to done if awaiting user input."""
        kit = MagicMock()
        kit.task_manager = MagicMock()
        kit.task_manager.get_task = AsyncMock(
            return_value=TaskState(task_id="t1", status=TaskStatus.AWAITING_INPUT)
        )
        kit.task_manager.update = AsyncMock()
        kit.task_manager.set_result = AsyncMock()

        async def handler(ctx: TaskContext) -> dict:
            return {"response": "Need input"}

        middleware = ResultMiddleware()
        chain = MiddlewareChain(handler, middleware=[middleware])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            message="test",
            context={},
            kit=kit,
            emitter=MagicMock(),
            memory=MagicMock(),
        )
        result = await chain(ctx)

        assert result == {"response": "Need input"}
        kit.task_manager.update.assert_called_once_with("t1", result={"response": "Need input"})
        kit.task_manager.set_result.assert_not_called()


class TestMiddlewareIntegration:
    """Integration tests for middleware stack."""

    @pytest.mark.asyncio
    async def test_full_middleware_stack(self):
        """Test full middleware stack with multiple middleware."""

        # Set up mocks
        kit = MagicMock()
        kit.task_manager = MagicMock()
        kit.task_manager.set_result = AsyncMock()
        # Mock get_task to return a task with IN_PROGRESS status
        mock_task = TaskState(task_id="t1", status=TaskStatus.IN_PROGRESS)
        kit.task_manager.get_task = AsyncMock(return_value=mock_task)

        memory = MagicMock()
        memory.enabled = True
        memory.add_message = AsyncMock()

        emitter = MagicMock()
        emitter.emit = AsyncMock()

        async def handler(ctx: TaskContext) -> dict:
            return {"response": f"Processed: {ctx.message}"}

        # Stack: Result -> Emitter -> Memory -> Handler
        middleware = [
            ResultMiddleware(),
            EmitterMiddleware(start_message="Starting..."),
            MemoryMiddleware(),
        ]
        chain = MiddlewareChain(handler, middleware=middleware)

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            message="Hello",
            context={},
            kit=kit,
            emitter=emitter,
            memory=memory,
        )

        result = await chain(ctx)

        # Verify all middleware executed
        assert result == {"response": "Processed: Hello"}
        emitter.emit.assert_called_with("Starting...")
        memory.add_message.assert_called_once()
        kit.task_manager.set_result.assert_called_once()


class TestRAGMiddleware:
    """Tests for RAGMiddleware."""

    @pytest.mark.asyncio
    async def test_rag_middleware_injects_context(self):
        """Test RAGMiddleware injects context from knowledge store."""

        # Mock knowledge store results
        mock_result = MagicMock()
        mock_result.content = "Document content"

        kit = MagicMock()
        kit._redis = MagicMock()

        emitter = MagicMock()
        emitter.emit = AsyncMock()

        async def handler(ctx: TaskContext) -> dict:
            return {"response": ctx.rag_context}

        middleware = RAGMiddleware(limit=3)
        chain = MiddlewareChain(handler, middleware=[middleware])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            memory=MagicMock(),
            message="test query",
            context={},
            kit=kit,
            emitter=emitter,
        )

        # Mock the KnowledgeStore at the knowledge module level
        with patch("redis_agent_kit.knowledge.KnowledgeStore") as MockKnowledgeStore:
            mock_ks = MagicMock()
            mock_ks.search = AsyncMock(return_value=[mock_result])
            MockKnowledgeStore.return_value = mock_ks

            result = await chain(ctx)

        assert result == {"response": "Document content"}
        assert ctx.metadata["rag_result_count"] == 1
        emitter.emit.assert_called_with("Searching knowledge base...")

    @pytest.mark.asyncio
    async def test_rag_middleware_empty_results(self):
        """Test RAGMiddleware handles empty results."""

        kit = MagicMock()
        kit._redis = MagicMock()

        emitter = MagicMock()
        emitter.emit = AsyncMock()

        async def handler(ctx: TaskContext) -> dict:
            return {"response": ctx.rag_context, "count": ctx.metadata.get("rag_result_count")}

        middleware = RAGMiddleware()
        chain = MiddlewareChain(handler, middleware=[middleware])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            memory=MagicMock(),
            message="test",
            context={},
            kit=kit,
            emitter=emitter,
        )

        with patch("redis_agent_kit.knowledge.KnowledgeStore") as MockKnowledgeStore:
            mock_ks = MagicMock()
            mock_ks.search = AsyncMock(return_value=[])
            MockKnowledgeStore.return_value = mock_ks

            result = await chain(ctx)

        assert result == {"response": "", "count": 0}

    @pytest.mark.asyncio
    async def test_rag_middleware_no_emit(self):
        """Test RAGMiddleware with emit_status=False."""

        kit = MagicMock()
        kit._redis = MagicMock()

        emitter = MagicMock()
        emitter.emit = AsyncMock()

        async def handler(ctx: TaskContext) -> dict:
            return {"response": "done"}

        middleware = RAGMiddleware(emit_status=False)
        chain = MiddlewareChain(handler, middleware=[middleware])

        ctx = TaskContext(
            task_id="t1",
            session_id="s1",
            memory=MagicMock(),
            message="test",
            context={},
            kit=kit,
            emitter=emitter,
        )

        with patch("redis_agent_kit.knowledge.KnowledgeStore") as MockKnowledgeStore:
            mock_ks = MagicMock()
            mock_ks.search = AsyncMock(return_value=[])
            MockKnowledgeStore.return_value = mock_ks

            await chain(ctx)

        emitter.emit.assert_not_called()


# =============================================================================
# Pipeline Middleware Tests
# =============================================================================


class TestPipelineContext:
    """Tests for PipelineContext dataclass."""

    def test_pipeline_context_creation(self, tmp_path):
        """PipelineContext should be created with required fields."""

        ctx = PipelineContext(
            stage="prepare",
            batch_id=None,
            config=MagicMock(),
            base_path=tmp_path,
            orchestrator=MagicMock(),
        )

        assert ctx.stage == "prepare"
        assert ctx.batch_id is None
        assert ctx.base_path == tmp_path
        assert ctx.metadata == {}

    def test_pipeline_context_with_batch_id(self, tmp_path):
        """PipelineContext should accept batch_id for ingest stage."""

        ctx = PipelineContext(
            stage="ingest",
            batch_id="batch-123",
            config=MagicMock(),
            base_path=tmp_path,
            orchestrator=MagicMock(),
        )

        assert ctx.stage == "ingest"
        assert ctx.batch_id == "batch-123"

    def test_pipeline_context_metadata(self, tmp_path):
        """PipelineContext should allow custom metadata."""

        ctx = PipelineContext(
            stage="prepare",
            batch_id=None,
            config=MagicMock(),
            base_path=tmp_path,
            orchestrator=MagicMock(),
            metadata={"custom": "value"},
        )

        assert ctx.metadata["custom"] == "value"


class TestPipelineMiddlewareChain:
    """Tests for PipelineMiddlewareChain."""

    @pytest.mark.asyncio
    async def test_chain_calls_handler(self, tmp_path):
        """Chain should call the final handler."""

        ctx = PipelineContext(
            stage="prepare",
            batch_id=None,
            config=MagicMock(),
            base_path=tmp_path,
            orchestrator=MagicMock(),
        )

        async def handler(ctx):
            return "batch-123"

        chain = PipelineMiddlewareChain(handler, [])
        result = await chain(ctx)

        assert result == "batch-123"

    @pytest.mark.asyncio
    async def test_chain_executes_middleware_in_order(self, tmp_path):
        """Chain should execute middleware in order."""
        order = []

        class FirstMiddleware(PipelineMiddleware):
            async def __call__(self, ctx, next):
                order.append("first-before")
                result = await next(ctx)
                order.append("first-after")
                return result

        class SecondMiddleware(PipelineMiddleware):
            async def __call__(self, ctx, next):
                order.append("second-before")
                result = await next(ctx)
                order.append("second-after")
                return result

        ctx = PipelineContext(
            stage="prepare",
            batch_id=None,
            config=MagicMock(),
            base_path=tmp_path,
            orchestrator=MagicMock(),
        )

        async def handler(ctx):
            order.append("handler")
            return "result"

        chain = PipelineMiddlewareChain(handler, [FirstMiddleware(), SecondMiddleware()])
        await chain(ctx)

        assert order == ["first-before", "second-before", "handler", "second-after", "first-after"]


class TestPipelineLoggingMiddleware:
    """Tests for PipelineLoggingMiddleware."""

    @pytest.mark.asyncio
    async def test_logs_stage_execution(self, tmp_path):
        """Logging middleware should log stage start and end."""
        logs = []

        ctx = PipelineContext(
            stage="prepare",
            batch_id=None,
            config=MagicMock(),
            base_path=tmp_path,
            orchestrator=MagicMock(),
        )

        async def handler(ctx):
            return "batch-123"

        middleware = PipelineLoggingMiddleware(logger=logs.append)
        chain = PipelineMiddlewareChain(handler, [middleware])
        await chain(ctx)

        assert "Starting pipeline stage: prepare" in logs
        assert "Completed pipeline stage: prepare" in logs

    @pytest.mark.asyncio
    async def test_logs_batch_id_when_present(self, tmp_path):
        """Logging middleware should log batch_id when present."""
        logs = []

        ctx = PipelineContext(
            stage="ingest",
            batch_id="batch-456",
            config=MagicMock(),
            base_path=tmp_path,
            orchestrator=MagicMock(),
        )

        async def handler(ctx):
            return MagicMock()

        middleware = PipelineLoggingMiddleware(logger=logs.append)
        chain = PipelineMiddlewareChain(handler, [middleware])
        await chain(ctx)

        assert any("batch-456" in log for log in logs)


class TestPipelineTimingMiddleware:
    """Tests for PipelineTimingMiddleware."""

    @pytest.mark.asyncio
    async def test_tracks_execution_time(self, tmp_path):
        """Timing middleware should track execution time."""
        ctx = PipelineContext(
            stage="prepare",
            batch_id=None,
            config=MagicMock(),
            base_path=tmp_path,
            orchestrator=MagicMock(),
        )

        async def handler(ctx):
            return "batch-123"

        middleware = PipelineTimingMiddleware()
        chain = PipelineMiddlewareChain(handler, [middleware])
        await chain(ctx)

        assert "timing" in ctx.metadata
        assert "prepare" in ctx.metadata["timing"]
        assert ctx.metadata["timing"]["prepare"] >= 0

    @pytest.mark.asyncio
    async def test_tracks_execution_time_with_existing_timing_map(self, tmp_path):
        """Timing middleware should append to existing timing map."""
        ctx = PipelineContext(
            stage="ingest",
            batch_id="b1",
            config=MagicMock(),
            base_path=tmp_path,
            orchestrator=MagicMock(),
            metadata={"timing": {"prepare": 0.01}},
        )

        async def handler(ctx):
            return "ok"

        middleware = PipelineTimingMiddleware()
        chain = PipelineMiddlewareChain(handler, [middleware])
        await chain(ctx)

        assert "prepare" in ctx.metadata["timing"]
        assert "ingest" in ctx.metadata["timing"]


class TestPipelineValidationMiddleware:
    """Tests for PipelineValidationMiddleware."""

    @pytest.mark.asyncio
    async def test_validates_sources_for_prepare(self, tmp_path):
        """Validation middleware should check sources for prepare stage."""
        config = MagicMock()
        config.sources = []  # Empty sources

        ctx = PipelineContext(
            stage="prepare",
            batch_id=None,
            config=config,
            base_path=tmp_path,
            orchestrator=MagicMock(),
        )

        async def handler(ctx):
            return "batch-123"

        middleware = PipelineValidationMiddleware()
        chain = PipelineMiddlewareChain(handler, [middleware])

        with pytest.raises(ValueError, match="at least one source"):
            await chain(ctx)

    @pytest.mark.asyncio
    async def test_validates_batch_id_for_ingest(self, tmp_path):
        """Validation middleware should check batch_id for ingest stage."""
        ctx = PipelineContext(
            stage="ingest",
            batch_id=None,  # Missing batch_id
            config=MagicMock(),
            base_path=tmp_path,
            orchestrator=MagicMock(),
        )

        async def handler(ctx):
            return MagicMock()

        middleware = PipelineValidationMiddleware()
        chain = PipelineMiddlewareChain(handler, [middleware])

        with pytest.raises(ValueError, match="batch_id is required"):
            await chain(ctx)

    @pytest.mark.asyncio
    async def test_passes_valid_config(self, tmp_path):
        """Validation middleware should pass valid configuration."""
        source = MagicMock()
        source.name = "docs"
        source.path_pattern = "*.md"

        config = MagicMock()
        config.sources = [source]

        ctx = PipelineContext(
            stage="prepare",
            batch_id=None,
            config=config,
            base_path=tmp_path,
            orchestrator=MagicMock(),
        )

        async def handler(ctx):
            return "batch-123"

        middleware = PipelineValidationMiddleware()
        chain = PipelineMiddlewareChain(handler, [middleware])
        result = await chain(ctx)

        assert result == "batch-123"


class TestPipelineOrchestratorMiddleware:
    """Tests for PipelineOrchestrator middleware integration."""

    @pytest.mark.asyncio
    async def test_prepare_async_with_middleware(self, tmp_path):
        """Orchestrator prepare_async should execute middleware."""

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "test.md").write_text("# Test\n\nContent.")

        middleware_called = []

        class TrackingMiddleware(PipelineMiddleware):
            async def __call__(self, ctx, next):
                middleware_called.append(ctx.stage)
                return await next(ctx)

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )
        orchestrator = PipelineOrchestrator(
            config=config,
            base_path=docs_dir,
            middleware=[TrackingMiddleware()],
        )

        batch_id = await orchestrator.prepare_async()

        assert batch_id is not None
        assert "prepare" in middleware_called

    @pytest.mark.asyncio
    async def test_ingest_async_with_middleware(self, tmp_path):
        """Orchestrator ingest_async should execute middleware."""

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "test.md").write_text("# Test\n\nContent.")

        middleware_called = []

        class TrackingMiddleware(PipelineMiddleware):
            async def __call__(self, ctx, next):
                middleware_called.append(ctx.stage)
                return await next(ctx)

        mock_vectorizer = MagicMock()
        mock_vectorizer.embed.return_value = [0.1] * 768
        mock_vector_store = MagicMock()

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )
        orchestrator = PipelineOrchestrator(
            config=config,
            base_path=docs_dir,
            vectorizer=mock_vectorizer,
            vector_store=mock_vector_store,
            middleware=[TrackingMiddleware()],
        )

        # First prepare
        batch_id = orchestrator.prepare()
        # Then ingest with middleware
        manifest = await orchestrator.ingest_async(batch_id)

        assert manifest is not None
        assert "ingest" in middleware_called

    @pytest.mark.asyncio
    async def test_run_async_with_middleware(self, tmp_path):
        """Orchestrator run_async should execute middleware."""

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "test.md").write_text("# Test\n\nContent.")

        middleware_called = []

        class TrackingMiddleware(PipelineMiddleware):
            async def __call__(self, ctx, next):
                middleware_called.append(ctx.stage)
                return await next(ctx)

        mock_vectorizer = MagicMock()
        mock_vectorizer.embed.return_value = [0.1] * 768
        mock_vector_store = MagicMock()

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )
        orchestrator = PipelineOrchestrator(
            config=config,
            base_path=docs_dir,
            vectorizer=mock_vectorizer,
            vector_store=mock_vector_store,
            middleware=[TrackingMiddleware()],
        )

        result = await orchestrator.run_async()

        assert result is not None
        assert result.batch_id is not None
        assert "run" in middleware_called

    @pytest.mark.asyncio
    async def test_prepare_async_without_middleware_still_works(self, tmp_path):
        """Orchestrator prepare_async should work without middleware."""

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "test.md").write_text("# Test\n\nContent.")

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )
        orchestrator = PipelineOrchestrator(config=config, base_path=docs_dir)

        batch_id = await orchestrator.prepare_async()

        assert batch_id is not None


class TestPipelineOrchestratorAsyncWithoutMiddleware:
    """Tests for pipeline orchestrator async methods without middleware."""

    @pytest.mark.asyncio
    async def test_ingest_async_without_middleware(self, tmp_path):
        """ingest_async should fall back to sync ingest when no middleware."""

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "test.md").write_text("# Test\n\nTest content here.")

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )

        # Mock vectorizer and vector_store
        mock_vectorizer = MagicMock()
        mock_vectorizer.embed.return_value = [0.1] * 768
        mock_vector_store = MagicMock()
        mock_vector_store.add_chunks = MagicMock()

        orchestrator = PipelineOrchestrator(
            config=config,
            base_path=docs_dir,
            vectorizer=mock_vectorizer,
            vector_store=mock_vector_store,
        )

        # First prepare
        batch_id = orchestrator.prepare()

        # Then ingest async without middleware
        manifest = await orchestrator.ingest_async(batch_id)

        assert manifest is not None
        assert manifest.batch_id == batch_id

    @pytest.mark.asyncio
    async def test_run_async_without_middleware(self, tmp_path):
        """run_async should fall back to sync run when no middleware."""

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "test.md").write_text("# Test\n\nTest content here.")

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )

        # Mock vectorizer and vector_store
        mock_vectorizer = MagicMock()
        mock_vectorizer.embed.return_value = [0.1] * 768
        mock_vector_store = MagicMock()
        mock_vector_store.add_chunks = MagicMock()

        orchestrator = PipelineOrchestrator(
            config=config,
            base_path=docs_dir,
            vectorizer=mock_vectorizer,
            vector_store=mock_vector_store,
        )

        # Run full pipeline async without middleware
        result = await orchestrator.run_async()

        assert result is not None
        assert result.batch_id is not None
        assert result.ingestion_manifest is not None


class TestPipelineValidationMiddlewareSourcePattern:
    """Test PipelineValidationMiddleware source path_pattern validation."""

    @pytest.mark.asyncio
    async def test_validation_fails_for_source_without_path_pattern(self, tmp_path):
        """PipelineValidationMiddleware should reject sources without path_pattern."""

        # Create a source with empty path_pattern
        source = SourceConfig(name="docs", path_pattern="", chunk_size=100, chunk_overlap=10)
        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[source],
        )

        ctx = PipelineContext(
            stage="prepare",
            batch_id=None,
            config=config,
            base_path=tmp_path,
            orchestrator=MagicMock(),
        )

        middleware = PipelineValidationMiddleware()
        next_handler = AsyncMock(return_value="batch-123")

        with pytest.raises(ValueError, match="must have a path_pattern"):
            await middleware(ctx, next_handler)
