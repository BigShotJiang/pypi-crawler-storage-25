"""TDD tests for CLI main - written BEFORE implementation."""

from click.testing import CliRunner


class TestCLIMain:
    """Tests for main CLI app."""

    def test_cli_exists(self):
        """CLI app should exist."""
        from redis_agent_kit.cli.main import cli

        assert cli is not None

    def test_cli_has_help(self):
        """CLI should show help text."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "Redis Agent Kit CLI" in result.output

    def test_cli_has_version(self):
        """CLI should show version."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_cli_has_task_group(self):
        """CLI should have task command group."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["task", "--help"])
        assert result.exit_code == 0
        assert "Task lifecycle commands" in result.output

    def test_cli_has_agent_group(self):
        """CLI should have agent command group."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["agent", "--help"])
        assert result.exit_code == 0
        assert "Agent discovery commands" in result.output

    def test_cli_has_pipelines_group(self):
        """CLI should have pipelines command group."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "--help"])
        assert result.exit_code == 0
        assert "Pipeline commands" in result.output

    def test_cli_connection_options(self):
        """CLI should accept connection options."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(
            cli,
            [
                "--redis-url",
                "redis://custom:6379",
                "--api-base",
                "http://localhost:8000",
                "--token",
                "test-token",
                "--help",
            ],
        )
        assert result.exit_code == 0


class TestCLIContext:
    """Tests for CLI context passing."""

    def test_context_stores_redis_url(self):
        """Context should store Redis URL."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        # We need a subcommand to test context - using tasks list
        result = runner.invoke(cli, ["--redis-url", "redis://test:6379", "tasks", "--help"])
        assert result.exit_code == 0
