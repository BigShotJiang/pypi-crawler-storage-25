"""Unit tests for shared CLI API helpers."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import click
import pytest
from click.testing import CliRunner

from redis_agent_kit.cli import api_common


def test_require_api_base_and_require_agent_and_project_helpers() -> None:
    assert api_common.require_api_base(" http://x ") == "http://x"
    assert api_common.maybe_project(" p1 ", None) == "p1"
    assert api_common.maybe_project(None, " p2 ") == "p2"
    assert api_common.require_agent(" a1 ", None) == "a1"
    assert api_common.require_agent(None, "a2") == "a2"

    with pytest.raises(click.ClickException):
        api_common.require_api_base(None)
    with pytest.raises(click.ClickException):
        api_common.require_agent(None, None)


def test_build_headers() -> None:
    assert api_common.build_headers(None) == {"Accept": "application/json"}
    assert api_common.build_headers(" t ")["Authorization"] == "Bearer t"


def test_call_api_success_and_error_paths() -> None:
    ok_response = MagicMock()
    ok_response.status_code = 200
    ok_response.content = b'{"ok": true}'
    ok_response.json.return_value = {"ok": True}

    with patch("redis_agent_kit.cli.api_common.httpx.Client") as client_cls:
        client_cls.return_value.__enter__.return_value.request.return_value = ok_response
        payload = api_common.call_api(
            api_base="http://localhost:8000",
            token="token",
            method="GET",
            path="/v1/healthz",
        )
    assert payload["ok"] is True

    bad_json = MagicMock()
    bad_json.status_code = 200
    bad_json.content = b"not-json"
    bad_json.text = "not-json"
    bad_json.json.side_effect = ValueError("bad")
    with patch("redis_agent_kit.cli.api_common.httpx.Client") as client_cls:
        client_cls.return_value.__enter__.return_value.request.return_value = bad_json
        with pytest.raises(click.ClickException, match="Invalid JSON response"):
            api_common.call_api(
                api_base="http://localhost:8000",
                token=None,
                method="GET",
                path="/v1/healthz",
            )

    error_with_message = MagicMock()
    error_with_message.status_code = 400
    error_with_message.content = b'{"error": {"message": "bad request"}}'
    error_with_message.json.return_value = {"error": {"message": "bad request"}}
    error_with_message.text = "bad request"
    error_with_message.reason_phrase = "Bad Request"
    with patch("redis_agent_kit.cli.api_common.httpx.Client") as client_cls:
        client_cls.return_value.__enter__.return_value.request.return_value = error_with_message
        with pytest.raises(click.ClickException, match="400: bad request"):
            api_common.call_api(
                api_base="http://localhost:8000",
                token=None,
                method="GET",
                path="/v1/x",
            )

    empty_body = MagicMock()
    empty_body.status_code = 200
    empty_body.content = b""
    empty_body.text = ""
    with patch("redis_agent_kit.cli.api_common.httpx.Client") as client_cls:
        client_cls.return_value.__enter__.return_value.request.return_value = empty_body
        payload = api_common.call_api(
            api_base="http://localhost:8000",
            token=None,
            method="GET",
            path="/v1/x",
        )
    assert payload == {}

    error_with_detail = MagicMock()
    error_with_detail.status_code = 404
    error_with_detail.content = b'{"detail": "missing"}'
    error_with_detail.json.return_value = {"detail": "missing"}
    error_with_detail.text = "missing"
    error_with_detail.reason_phrase = "Not Found"
    with patch("redis_agent_kit.cli.api_common.httpx.Client") as client_cls:
        client_cls.return_value.__enter__.return_value.request.return_value = error_with_detail
        with pytest.raises(click.ClickException, match="404: missing"):
            api_common.call_api(
                api_base="http://localhost:8000",
                token=None,
                method="GET",
                path="/v1/x",
            )


def test_parse_json_helpers(tmp_path) -> None:
    obj = api_common.parse_json_object('{"k": "v"}')
    assert obj == {"k": "v"}

    with pytest.raises(click.ClickException, match="Invalid JSON"):
        api_common.parse_json_object("{")
    with pytest.raises(click.ClickException, match="JSON input must be an object"):
        api_common.parse_json_object("[]")

    file_path = tmp_path / "payload.json"
    file_path.write_text(json.dumps({"a": 1}), encoding="utf-8")
    assert api_common.parse_json_file(str(file_path)) == {"a": 1}

    with pytest.raises(click.ClickException, match="File not found"):
        api_common.parse_json_file(str(tmp_path / "missing.json"))


def test_echo_json_prints_output() -> None:
    @click.command()
    def cmd() -> None:
        api_common.echo_json({"k": "v"})

    result = CliRunner().invoke(cmd, [])
    assert result.exit_code == 0
    assert '"k": "v"' in result.output
