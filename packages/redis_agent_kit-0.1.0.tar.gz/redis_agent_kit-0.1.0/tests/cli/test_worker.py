"""TDD tests for worker CLI command - written BEFORE implementation."""

from unittest.mock import AsyncMock, MagicMock, patch

from click.testing import CliRunner


class TestWorkerCommandExists:
    """Tests for worker command existence."""

    def test_worker_command_importable(self):
        """worker command should be importable."""
        from redis_agent_kit.cli.worker import worker

        assert worker is not None

    def test_worker_in_main_cli(self):
        """worker command should be registered in main CLI."""
        from redis_agent_kit.cli.main import cli

        # Check that worker is a registered command
        assert "worker" in cli.commands


class TestWorkerCommandOptions:
    """Tests for worker command options."""

    def test_worker_has_concurrency_option(self):
        """worker should have --concurrency option."""
        from redis_agent_kit.cli.worker import worker

        # Check command options
        option_names = [opt.name for opt in worker.params]
        assert "concurrency" in option_names

    def test_worker_has_redis_url_option(self):
        """worker should have --redis-url option."""
        from redis_agent_kit.cli.worker import worker

        option_names = [opt.name for opt in worker.params]
        assert "redis_url" in option_names

    def test_worker_has_name_option(self):
        """worker should have --name option."""
        from redis_agent_kit.cli.worker import worker

        option_names = [opt.name for opt in worker.params]
        assert "name" in option_names


class TestWorkerCommandHelp:
    """Tests for worker command help text."""

    def test_worker_help_displays(self):
        """worker --help should display usage."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["worker", "--help"])
        assert result.exit_code == 0
        assert "Start a background worker" in result.output or "worker" in result.output

    def test_worker_shows_default_concurrency(self):
        """worker --help should show default concurrency."""
        from redis_agent_kit.cli.worker import worker

        # Find concurrency option
        for opt in worker.params:
            if opt.name == "concurrency":
                assert opt.default == 4  # Default should be 4

    def test_worker_name_default_is_none(self):
        """worker --name should resolve via settings when omitted."""
        from redis_agent_kit.cli.worker import worker

        for opt in worker.params:
            if opt.name == "name":
                assert opt.default is None


class TestWorkerExecution:
    """Tests for worker command execution."""

    def test_worker_starts_and_prints_info(self):
        """worker should print startup info and call Worker.run."""
        from redis_agent_kit.cli.worker import worker

        runner = CliRunner()

        with patch("redis_agent_kit.cli.worker.asyncio.run") as mock_run:
            # Simulate KeyboardInterrupt to exit cleanly
            mock_run.side_effect = KeyboardInterrupt()

            result = runner.invoke(
                worker,
                ["--concurrency", "2", "--redis-url", "redis://test:6379", "--name", "test_queue"],
            )

            assert "Worker stopped" in result.output

    def test_worker_loads_tasks_module(self):
        """worker should load tasks from module if provided."""
        from redis_agent_kit.cli.worker import worker

        runner = CliRunner()

        # Create a mock that runs the async function but raises KeyboardInterrupt
        # after the task loading code runs
        def run_and_interrupt(coro):
            # The coro is _run_worker(), which will try to import the module
            # and fail, raising click.Abort
            import asyncio

            loop = asyncio.new_event_loop()
            try:
                return loop.run_until_complete(coro)
            finally:
                loop.close()

        with patch("redis_agent_kit.cli.worker.asyncio.run", side_effect=run_and_interrupt):
            # Use a non-existent module to test error handling
            result = runner.invoke(worker, ["--tasks", "nonexistent.module:tasks"])

            # Should abort due to import error
            assert result.exit_code != 0 or "Error loading tasks" in result.output

    def test_worker_handles_worker_error(self):
        """worker should handle errors from Worker.run."""
        from redis_agent_kit.cli.worker import worker

        runner = CliRunner()

        with patch("redis_agent_kit.cli.worker.asyncio.run") as mock_run:
            mock_run.side_effect = Exception("Connection failed")

            result = runner.invoke(worker, [])

            assert result.exit_code != 0

    def test_worker_runs_with_mocked_docket(self):
        """worker should run Worker.run when Docket is available."""
        from redis_agent_kit.cli.worker import worker

        runner = CliRunner()

        # Mock Worker.run to return immediately - patch where it's imported
        with patch("redis_agent_kit.cli.worker.Worker") as mock_worker_class:
            mock_run = AsyncMock(return_value=None)
            mock_worker_class.run = mock_run

            # Run the worker - it should call Worker.run and exit
            result = runner.invoke(
                worker,
                ["--concurrency", "2", "--redis-url", "redis://test:6379", "--name", "test_queue"],
            )

            # Worker.run should have been called
            mock_run.assert_called_once()
            assert "Worker started" in result.output

    def test_worker_loads_valid_tasks_module(self):
        """worker should successfully load tasks from a valid module."""
        from redis_agent_kit.cli.worker import worker

        runner = CliRunner()

        # Create a mock module with tasks
        mock_module = MagicMock()
        mock_module.tasks = ["task1", "task2"]

        with patch("redis_agent_kit.cli.worker.Worker") as mock_worker_class:
            mock_run = AsyncMock(return_value=None)
            mock_worker_class.run = mock_run

            with patch(
                "redis_agent_kit.cli.worker.importlib.import_module", return_value=mock_module
            ):
                result = runner.invoke(
                    worker,
                    ["--tasks", "myapp.tasks:tasks"],
                )

                assert "Loaded 2 tasks" in result.output

    def test_worker_loads_callable_task_module(self):
        """worker should handle callable task objects in tasks modules."""
        from redis_agent_kit.cli.worker import worker

        runner = CliRunner()

        mock_module = MagicMock()
        mock_module.task = lambda: None

        with patch("redis_agent_kit.cli.worker.Worker") as mock_worker_class:
            mock_run = AsyncMock(return_value=None)
            mock_worker_class.run = mock_run

            with patch(
                "redis_agent_kit.cli.worker.importlib.import_module", return_value=mock_module
            ):
                result = runner.invoke(
                    worker,
                    ["--tasks", "myapp.tasks:task"],
                )

                assert result.exit_code == 0
                assert "Loaded task: myapp.tasks:task" in result.output

    def test_worker_handles_worker_run_error(self):
        """worker should handle errors from Worker.run gracefully."""
        from redis_agent_kit.cli.worker import worker

        runner = CliRunner()

        with patch("redis_agent_kit.cli.worker.Worker") as mock_worker_class:
            mock_run = AsyncMock(side_effect=Exception("Connection refused"))
            mock_worker_class.run = mock_run

            result = runner.invoke(
                worker,
                ["--redis-url", "redis://test:6379"],
            )

            assert result.exit_code != 0
            assert "Worker error" in result.output or "Connection refused" in result.output

    def test_worker_uses_settings_defaults_when_omitted(self):
        """worker should fall back to settings for queue name and redis url."""
        from redis_agent_kit.cli.worker import worker

        runner = CliRunner()

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://settings:6379"
        mock_settings.task.queue_name = "settings-queue"

        with patch("redis_agent_kit.cli.worker.get_settings", return_value=mock_settings):
            with patch("redis_agent_kit.cli.worker.Worker") as mock_worker_class:
                mock_run = AsyncMock(return_value=None)
                mock_worker_class.run = mock_run

                result = runner.invoke(worker, [])

                assert result.exit_code == 0
                assert "queue=settings-queue" in result.output
                assert "redis://settings:6379" in result.output
                mock_run.assert_called_once()
                assert mock_run.call_args.kwargs["docket_name"] == "settings-queue"
                assert mock_run.call_args.kwargs["url"] == "redis://settings:6379"
