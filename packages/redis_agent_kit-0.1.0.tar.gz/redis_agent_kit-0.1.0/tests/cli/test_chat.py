"""Tests for the rak chat command."""

from types import SimpleNamespace
from unittest.mock import patch

from click.testing import CliRunner


def test_chat_command_calls_a2a_and_renders_reply() -> None:
    """chat should create an A2A task, poll it, and print the reply."""
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    with patch("redis_agent_kit.cli.chat.call_api") as call_api:
        call_api.side_effect = [
            {"data": {"task": {"id": "task_chat_1"}, "a2a": {"contextId": "ctx_1"}}},
            {"data": {"status": {"state": "succeeded", "terminal": True, "resultAvailable": True}}},
            {"data": {"taskResult": {"result": {"reply": "Memory looks healthy."}}}},
            {"data": {"taskTrace": {"events": []}}},
        ]
        result = runner.invoke(
            cli,
            [
                "--api-base",
                "http://localhost:8000",
                "--project",
                "proj_1",
                "--agent",
                "agent_1",
                "chat",
                "--message",
                "How is memory?",
                "--context-id",
                "ctx_1",
                "--trace-tool-calls",
                "summary",
            ],
        )

    assert result.exit_code == 0
    assert "Task ID: task_chat_1" in result.output
    assert "Context ID: ctx_1" in result.output
    assert "Memory looks healthy." in result.output

    create_kwargs = call_api.call_args_list[0].kwargs
    assert create_kwargs["method"] == "POST"
    assert create_kwargs["path"] == "/v1/projects/proj_1/agents/agent_1/a2a"
    assert create_kwargs["payload"]["request"]["input"] == {
        "message": "How is memory?",
        "contextId": "ctx_1",
    }
    assert create_kwargs["payload"]["options"]["trace"]["toolCalls"] == "summary"


def test_chat_interactive_reuses_one_context_id() -> None:
    """interactive chat should keep sending turns on the same generated context ID."""
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    with (
        patch("redis_agent_kit.cli.chat.call_api") as call_api,
        patch(
            "redis_agent_kit.cli.chat.uuid.uuid4", return_value=SimpleNamespace(hex="abc123def456")
        ),
    ):
        call_api.side_effect = [
            {"data": {"task": {"id": "task_chat_1"}, "a2a": {"contextId": "ctx_abc123def456"}}},
            {"data": {"status": {"state": "succeeded", "terminal": True, "resultAvailable": True}}},
            {"data": {"taskResult": {"result": {"reply": "Memory looks healthy."}}}},
            {"data": {"task": {"id": "task_chat_2"}, "a2a": {"contextId": "ctx_abc123def456"}}},
            {"data": {"status": {"state": "succeeded", "terminal": True, "resultAvailable": True}}},
            {"data": {"taskResult": {"result": {"reply": "Clients are steady at 17."}}}},
        ]
        result = runner.invoke(
            cli,
            [
                "--api-base",
                "http://localhost:8000",
                "--project",
                "proj_1",
                "--agent",
                "agent_1",
                "chat",
                "--interactive",
            ],
            input="How is memory?\nWhat about clients?\n/exit\n",
        )

    assert result.exit_code == 0
    assert "Context ID: ctx_abc123def456" in result.output
    assert "Memory looks healthy." in result.output
    assert "Clients are steady at 17." in result.output

    first_create = call_api.call_args_list[0].kwargs["payload"]["request"]["input"]
    second_create = call_api.call_args_list[3].kwargs["payload"]["request"]["input"]
    assert first_create["contextId"] == "ctx_abc123def456"
    assert second_create["contextId"] == "ctx_abc123def456"
