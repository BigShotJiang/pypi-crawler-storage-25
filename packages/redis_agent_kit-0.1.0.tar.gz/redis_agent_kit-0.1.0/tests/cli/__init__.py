# CLI tests

