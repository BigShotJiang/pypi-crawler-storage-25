"""Tests for API-backed task CLI commands."""

from unittest.mock import patch

from click.testing import CliRunner


def test_task_group_help() -> None:
    """Task group should be available."""
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    result = runner.invoke(cli, ["task", "--help"])
    assert result.exit_code == 0
    assert "Task lifecycle commands" in result.output


def test_tasks_alias_points_to_task_group() -> None:
    """tasks alias should be wired."""
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    result = runner.invoke(cli, ["tasks", "--help"])
    assert result.exit_code == 0
    assert "Task lifecycle commands" in result.output


def test_task_list_calls_v1_endpoint() -> None:
    """task list should call project/agent v1 endpoint."""
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    with patch("redis_agent_kit.cli.task.call_api") as call_api:
        call_api.return_value = {"ok": True, "data": {"tasks": [], "total": 0}}
        result = runner.invoke(
            cli,
            [
                "--api-base",
                "http://localhost:8000",
                "--project",
                "proj_1",
                "--agent",
                "agent_1",
                "task",
                "list",
            ],
        )
    assert result.exit_code == 0
    assert call_api.called
    kwargs = call_api.call_args.kwargs
    assert kwargs["method"] == "GET"
    assert kwargs["path"] == "/v1/projects/proj_1/agents/agent_1/tasks"


def test_task_run_calls_v1_endpoint() -> None:
    """task run should send create payload to v1 endpoint."""
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    with patch("redis_agent_kit.cli.task.call_api") as call_api:
        call_api.return_value = {"ok": True, "data": {"taskId": "t1"}}
        result = runner.invoke(
            cli,
            [
                "--api-base",
                "http://localhost:8000",
                "--project",
                "proj_1",
                "--agent",
                "agent_1",
                "task",
                "run",
                "--input-json",
                '{"message":"hello"}',
            ],
        )
    assert result.exit_code == 0
    kwargs = call_api.call_args.kwargs
    assert kwargs["method"] == "POST"
    assert kwargs["path"] == "/v1/projects/proj_1/agents/agent_1/tasks"
    payload = kwargs["payload"]
    assert payload["request"]["input"]["message"] == "hello"


def test_status_alias_calls_task_status() -> None:
    """Top-level status alias should call task status endpoint."""
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    with patch("redis_agent_kit.cli.task.call_api") as call_api:
        call_api.return_value = {"ok": True, "data": {"task": {"taskId": "t1"}}}
        result = runner.invoke(
            cli,
            [
                "--api-base",
                "http://localhost:8000",
                "--project",
                "proj_1",
                "--agent",
                "agent_1",
                "status",
                "t1",
            ],
        )
    assert result.exit_code == 0
    kwargs = call_api.call_args.kwargs
    assert kwargs["path"] == "/v1/projects/proj_1/agents/agent_1/tasks/t1"
