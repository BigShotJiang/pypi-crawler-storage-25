"""Tests for Redis key patterns."""

import pytest

from redis_agent_kit.keys import RedisKeys


class TestRedisKeys:
    """Tests for RedisKeys helper class."""

    def test_prefix_is_rak(self):
        """Prefix should be 'rak' for redis-agent-kit."""
        assert RedisKeys.PREFIX == "rak"

    def test_task_key(self):
        """Task key pattern."""
        key = RedisKeys.task("task123")
        assert key == "rak:task:task123"

    def test_thread_key(self):
        """Thread key pattern."""
        key = RedisKeys.thread("thread456")
        assert key == "rak:thread:thread456"

    def test_thread_tasks_key(self):
        """Thread tasks set key pattern."""
        key = RedisKeys.thread_tasks("thread456")
        assert key == "rak:thread:thread456:tasks"

    def test_tasks_by_status_key(self):
        """Tasks by status set key pattern."""
        key = RedisKeys.tasks_by_status("queued")
        assert key == "rak:tasks:status:queued"

    def test_thread_messages_key(self):
        """Thread messages list key pattern."""
        key = RedisKeys.thread_messages("thread456")
        assert key == "rak:thread:thread456:messages"

    def test_all_threads_key(self):
        """All threads set key."""
        key = RedisKeys.all_threads()
        assert key == "rak:threads"

    def test_all_tasks_key(self):
        """All tasks set key."""
        key = RedisKeys.all_tasks()
        assert key == "rak:tasks"

    def test_keys_are_lowercase(self):
        """All keys should be lowercase for consistency."""
        keys = [
            RedisKeys.task("ABC123"),
            RedisKeys.thread("XYZ789"),
            RedisKeys.thread_tasks("DEF456"),
            RedisKeys.tasks_by_status("QUEUED"),
        ]
        for key in keys:
            # The prefix part should be lowercase
            assert key.startswith("rak:")

    def test_custom_prefix(self):
        """RedisKeys should support custom prefix via subclass or param."""
        # Using a custom prefix for namespace isolation
        key = RedisKeys.task("task1", prefix="myapp")
        assert key == "myapp:task:task1"

    def test_parse_task_id_from_key(self):
        """Extract task_id from a task key."""
        key = "rak:task:task123"
        task_id = RedisKeys.parse_task_id(key)
        assert task_id == "task123"

    def test_parse_thread_id_from_key(self):
        """Extract thread_id from a thread key."""
        key = "rak:thread:thread456"
        thread_id = RedisKeys.parse_thread_id(key)
        assert thread_id == "thread456"

    def test_parse_task_id_invalid_key(self):
        """Parsing invalid key should raise ValueError."""
        with pytest.raises(ValueError):
            RedisKeys.parse_task_id("invalid:key:format")

    def test_parse_thread_id_invalid_key(self):
        """Parsing invalid key should raise ValueError."""
        with pytest.raises(ValueError):
            RedisKeys.parse_thread_id("invalid:key:format")

    def test_parse_thread_id_with_subkey(self):
        """Parsing thread key with subkey should return just thread_id."""
        key = "rak:thread:thread456:messages"
        thread_id = RedisKeys.parse_thread_id(key)
        assert thread_id == "thread456"

    def test_task_updates_channel_key(self):
        """Task updates Pub/Sub channel key pattern."""
        key = RedisKeys.task_updates_channel("task123")
        assert key == "rak:task:task123:updates"

    def test_task_updates_channel_custom_prefix(self):
        """Task updates channel should support custom prefix."""
        key = RedisKeys.task_updates_channel("task123", prefix="myapp")
        assert key == "myapp:task:task123:updates"
