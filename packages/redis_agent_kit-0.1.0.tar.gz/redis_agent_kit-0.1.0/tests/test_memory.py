"""Tests for redis_agent_kit.memory module."""

import json
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from redis_agent_kit.memory import (
    Memory,
    MemorySearchResults,
    MessageList,
    NoOpMemory,
    _check_ams,
    _require_ams,
)


class TestMessageList:
    """Tests for MessageList container class."""

    def test_dict_returns_list(self):
        """dict() should return a plain list."""
        messages = MessageList([{"role": "user", "content": "hi"}])
        assert messages.dict() == [{"role": "user", "content": "hi"}]

    def test_json_returns_string(self):
        """json() should return a JSON string."""
        messages = MessageList([{"role": "user", "content": "hi"}])
        result = messages.json()
        assert result == '[{"role": "user", "content": "hi"}]'

    def test_markdown_formats_messages(self):
        """markdown() should format messages."""
        messages = MessageList(
            [
                {"role": "user", "content": "hello"},
                {"role": "assistant", "content": "hi there"},
            ]
        )
        result = messages.markdown()
        assert result == "**user**: hello\n\n**assistant**: hi there"

    def test_markdown_custom_format(self):
        """markdown() should accept custom format."""
        messages = MessageList([{"role": "user", "content": "hello"}])
        result = messages.markdown(format="{role}: {content}", separator="\n")
        assert result == "user: hello"

    def test_markdown_empty_list(self):
        """markdown() should return empty string for empty list."""
        messages = MessageList()
        assert messages.markdown() == ""


class TestMemorySearchResults:
    """Tests for MemorySearchResults container class."""

    def test_dict_returns_list(self):
        """dict() should return a plain list."""
        results = MemorySearchResults([{"text": "hello", "memory_type": "semantic"}])
        assert results.dict() == [{"text": "hello", "memory_type": "semantic"}]

    def test_json_returns_string(self):
        """json() should return a JSON string."""
        results = MemorySearchResults([{"text": "hello"}])
        assert json.loads(results.json()) == [{"text": "hello"}]

    def test_markdown_formats_results(self):
        """markdown() should format results."""
        results = MemorySearchResults(
            [
                {"text": "first memory"},
                {"text": "second memory"},
            ]
        )
        result = results.markdown()
        assert result == "- first memory\n- second memory"

    def test_markdown_with_metadata(self):
        """markdown() with include_metadata should add type/topics."""
        results = MemorySearchResults(
            [
                {"text": "memory", "memory_type": "semantic", "topics": ["redis", "cache"]},
            ]
        )
        result = results.markdown(include_metadata=True)
        assert "type: semantic" in result
        assert "topics: redis, cache" in result

    def test_markdown_empty_list(self):
        """markdown() should return empty string for empty list."""
        results = MemorySearchResults()
        assert results.markdown() == ""


class TestCheckAms:
    """Tests for _check_ams function."""

    def test_check_ams_returns_bool(self):
        """_check_ams should return a boolean."""
        result = _check_ams()
        assert isinstance(result, bool)

    def test_check_ams_when_module_available(self):
        """_check_ams should return True when AMS module is available."""
        import redis_agent_kit.memory as memory_module

        # Reset the cached value
        original_value = memory_module._ams_available
        memory_module._ams_available = None

        # Mock the import to succeed
        mock_ams = MagicMock()
        with patch.dict(sys.modules, {"agent_memory_server": mock_ams}):
            result = _check_ams()
            assert result is True

        # Restore
        memory_module._ams_available = original_value


class TestRequireAms:
    """Tests for _require_ams function."""

    def test_require_ams_when_available(self):
        """_require_ams should not raise when AMS is available."""
        with patch("redis_agent_kit.memory._check_ams", return_value=True):
            _require_ams()  # Should not raise

    def test_require_ams_when_not_available(self):
        """_require_ams should raise ImportError when AMS not available."""
        with patch("redis_agent_kit.memory._check_ams", return_value=False):
            with pytest.raises(ImportError, match="agent-memory-server"):
                _require_ams()


class TestNoOpMemory:
    """Tests for NoOpMemory class."""

    def test_init(self):
        """NoOpMemory should initialize without arguments."""
        memory = NoOpMemory()
        assert memory is not None

    def test_session_id_is_none(self):
        """NoOpMemory.session_id should be None."""
        memory = NoOpMemory()
        assert memory.session_id is None

    def test_with_session_returns_new_memory(self):
        """NoOpMemory.with_session should return a new Memory instance."""
        memory = NoOpMemory()
        bound = memory.with_session("session-123")
        # NoOpMemory inherits from Memory, so with_session returns Memory
        assert isinstance(bound, Memory)
        assert bound.session_id == "session-123"

    @pytest.mark.asyncio
    async def test_add_message_is_noop(self):
        """NoOpMemory.add_message should do nothing."""
        memory = NoOpMemory()
        result = await memory.add_message(role="user", content="Hello")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_messages_returns_empty(self):
        """NoOpMemory.get_messages should return empty list."""
        memory = NoOpMemory()
        messages = await memory.get_messages()
        assert messages == []

    @pytest.mark.asyncio
    async def test_search_returns_empty(self):
        """NoOpMemory.search should return empty list."""
        memory = NoOpMemory()
        results = await memory.search("query")
        assert results == []

    @pytest.mark.asyncio
    async def test_get_context_returns_none(self):
        """NoOpMemory.get_context should return None."""
        memory = NoOpMemory()
        context = await memory.get_context()
        assert context is None

    @pytest.mark.asyncio
    async def test_set_data_is_noop(self):
        """NoOpMemory.set_data should do nothing."""
        memory = NoOpMemory()
        await memory.set_data("key", "value")
        # No error, no effect

    @pytest.mark.asyncio
    async def test_get_data_returns_default(self):
        """NoOpMemory.get_data should return default."""
        memory = NoOpMemory()
        result = await memory.get_data("key", default="default")
        assert result == "default"

    @pytest.mark.asyncio
    async def test_create_memory_returns_none(self):
        """NoOpMemory.create_memory should return None."""
        memory = NoOpMemory()
        result = await memory.create_memory("some text")
        assert result is None

    @pytest.mark.asyncio
    async def test_delete_memories_returns_zero(self):
        """NoOpMemory.delete_memories should return 0."""
        memory = NoOpMemory()
        result = await memory.delete_memories(["id1", "id2"])
        assert result == 0

    @pytest.mark.asyncio
    async def test_delete_session_returns_false(self):
        """NoOpMemory.delete_session should return False."""
        memory = NoOpMemory()
        result = await memory.delete_session()
        assert result is False


class TestMemoryInit:
    """Tests for Memory initialization."""

    def test_init_without_ams(self):
        """Memory should initialize even without AMS."""
        redis_client = MagicMock()
        with patch("redis_agent_kit.memory._check_ams", return_value=False):
            memory = Memory(redis_client, namespace="test")
            assert memory is not None
            assert memory._enabled is False

    def test_init_with_ams(self):
        """Memory should initialize with AMS when available."""
        redis_client = MagicMock()
        with patch("redis_agent_kit.memory._check_ams", return_value=True):
            memory = Memory(redis_client, namespace="test")
            assert memory is not None
            assert memory._enabled is True

    def test_session_id_initially_none(self):
        """Memory.session_id should be None initially."""
        redis_client = MagicMock()
        memory = Memory(redis_client, namespace="test")
        assert memory.session_id is None

    def test_enabled_property(self):
        """Memory.enabled should reflect _enabled."""
        redis_client = MagicMock()
        with patch("redis_agent_kit.memory._check_ams", return_value=True):
            memory = Memory(redis_client, namespace="test", enabled=True)
            assert memory.enabled is True

        with patch("redis_agent_kit.memory._check_ams", return_value=False):
            memory = Memory(redis_client, namespace="test", enabled=True)
            assert memory.enabled is False  # AMS not available


class TestMemoryWithSession:
    """Tests for Memory.with_session method."""

    def test_with_session_creates_bound_memory(self):
        """with_session should return a new Memory bound to session."""
        redis_client = MagicMock()
        memory = Memory(redis_client, namespace="test")

        bound = memory.with_session("session-123")
        assert bound is not memory
        assert bound.session_id == "session-123"

    def test_with_session_generates_id_if_none(self):
        """with_session should generate session_id if None."""
        redis_client = MagicMock()
        memory = Memory(redis_client, namespace="test")

        bound = memory.with_session(None)
        assert bound.session_id is not None
        assert len(bound.session_id) > 0

    def test_with_session_preserves_user_id(self):
        """with_session should preserve user_id."""
        redis_client = MagicMock()
        memory = Memory(redis_client, namespace="test")

        bound = memory.with_session("session-123", user_id="user-456")
        assert bound._user_id == "user-456"

    def test_user_id_property(self):
        """Memory.user_id should return _user_id."""
        redis_client = MagicMock()
        memory = Memory(redis_client, namespace="test")
        bound = memory.with_session("session-123", user_id="user-456")
        assert bound.user_id == "user-456"


class TestMemoryDisabled:
    """Tests for Memory when disabled."""

    @pytest.fixture
    def disabled_memory(self):
        """Create disabled Memory."""
        redis_client = MagicMock()
        memory = Memory(redis_client, namespace="test", enabled=False)
        return memory.with_session("session-123")

    @pytest.mark.asyncio
    async def test_add_message_returns_none_when_disabled(self, disabled_memory):
        """add_message should return None when disabled."""
        result = await disabled_memory.add_message(role="user", content="Hello")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_messages_returns_empty_when_disabled(self, disabled_memory):
        """get_messages should return empty list when disabled."""
        result = await disabled_memory.get_messages()
        assert result == []

    @pytest.mark.asyncio
    async def test_search_returns_empty_when_disabled(self, disabled_memory):
        """search should return empty list when disabled."""
        result = await disabled_memory.search("query")
        assert result == []

    @pytest.mark.asyncio
    async def test_get_data_returns_default_when_disabled(self, disabled_memory):
        """get_data should return default for disabled memory."""
        result = await disabled_memory.get_data("missing", default="fallback")
        assert result == "fallback"

    @pytest.mark.asyncio
    async def test_get_context_returns_none_when_disabled(self, disabled_memory):
        """get_context should return None when disabled."""
        result = await disabled_memory.get_context()
        assert result is None

    @pytest.mark.asyncio
    async def test_delete_session_returns_false_when_disabled(self, disabled_memory):
        """delete_session should return False when disabled."""
        result = await disabled_memory.delete_session()
        assert result is False

    @pytest.mark.asyncio
    async def test_get_session_returns_none_when_disabled(self, disabled_memory):
        """_get_session should return None for disabled memory."""
        result = await disabled_memory._get_session()
        assert result is None

    @pytest.mark.asyncio
    async def test_ensure_session_returns_none_when_disabled(self, disabled_memory):
        """_ensure_session should return None when disabled."""
        result = await disabled_memory._ensure_session()
        assert result is None

    @pytest.mark.asyncio
    async def test_save_session_noop_when_disabled(self, disabled_memory):
        """_save_session should no-op when memory is disabled."""
        session = MagicMock()
        await disabled_memory._save_session(session)
        assert disabled_memory._session_exists is False

    @pytest.mark.asyncio
    async def test_set_data_noop_when_disabled(self, disabled_memory):
        """set_data should no-op when memory is disabled."""
        await disabled_memory.set_data("k", "v")

    @pytest.mark.asyncio
    async def test_create_memory_returns_none_when_disabled(self, disabled_memory):
        """create_memory should return None for disabled memory."""
        result = await disabled_memory.create_memory("fact")
        assert result is None

    @pytest.mark.asyncio
    async def test_delete_memories_returns_zero_for_empty_ids(self, disabled_memory):
        """delete_memories should return 0 for empty input."""
        result = await disabled_memory.delete_memories([])
        assert result == 0


class TestMemoryWithMockedAMS:
    """Tests for Memory with mocked agent-memory-server."""

    @pytest.fixture
    def mock_ams_modules(self):
        """Create mock AMS modules."""
        # Create mock modules
        mock_ams = MagicMock()
        mock_working_memory = MagicMock()
        mock_long_term_memory = MagicMock()
        mock_config = MagicMock()
        mock_models = MagicMock()

        # Configure mock settings
        mock_settings = MagicMock()
        mock_config.settings = mock_settings

        # Configure mock models
        mock_memory_message = MagicMock()
        mock_working_memory_model = MagicMock()
        mock_memory_record = MagicMock()
        mock_models.MemoryMessage = mock_memory_message
        mock_models.WorkingMemory = mock_working_memory_model
        mock_models.MemoryRecord = mock_memory_record

        # Set up module structure
        mock_ams.working_memory = mock_working_memory
        mock_ams.long_term_memory = mock_long_term_memory
        mock_ams.config = mock_config
        mock_ams.models = mock_models

        return {
            "agent_memory_server": mock_ams,
            "agent_memory_server.working_memory": mock_working_memory,
            "agent_memory_server.long_term_memory": mock_long_term_memory,
            "agent_memory_server.config": mock_config,
            "agent_memory_server.models": mock_models,
        }

    @pytest.fixture
    def enabled_memory(self, mock_ams_modules):
        """Create enabled Memory with mocked AMS."""
        redis_client = MagicMock()

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                memory = Memory(redis_client, namespace="test", enabled=True)
                return memory.with_session("session-123")

    @pytest.mark.asyncio
    async def test_configure_ams_sets_settings(self, mock_ams_modules):
        """_configure_ams should set AMS settings from RAK settings."""
        redis_client = MagicMock()

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = True
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = True
        mock_settings.memory.forgetting_enabled = True
        mock_settings.memory.forgetting_max_age_days = 30
        mock_settings.memory.forgetting_max_inactive_days = 7
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    memory._configure_ams()

                    # Verify AMS settings were configured
                    ams_settings = mock_ams_modules["agent_memory_server.config"].settings
                    assert ams_settings.redis_url == "redis://localhost:6379"
                    assert ams_settings.long_term_memory is True
                    assert ams_settings.summarization_threshold == 5
                    assert ams_settings.enable_discrete_memory_extraction is True
                    assert ams_settings.forgetting_enabled is True
                    assert ams_settings.forgetting_max_age_days == 30
                    assert ams_settings.forgetting_max_inactive_days == 7
                    assert ams_settings.generation_model == "gpt-4"
                    assert ams_settings.embedding_model == "text-embedding-3-small"

    @pytest.mark.asyncio
    async def test_configure_ams_skips_optional_forgetting_thresholds(self, mock_ams_modules):
        """_configure_ams should handle forgetting enabled without optional limits."""
        redis_client = MagicMock()

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = True
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = True
        mock_settings.memory.forgetting_enabled = True
        mock_settings.memory.forgetting_max_age_days = None
        mock_settings.memory.forgetting_max_inactive_days = None
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    memory._configure_ams()
                    assert memory._ams_configured is True

    @pytest.mark.asyncio
    async def test_add_message_when_enabled(self, mock_ams_modules):
        """add_message should add message to working memory when enabled."""
        redis_client = MagicMock()

        # Create mock session
        mock_session = MagicMock()
        mock_session.messages = []

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=mock_session)
        mock_working_memory.set_working_memory = AsyncMock()

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    result = await bound.add_message(role="user", content="Hello")

                    assert result == "session-123"
                    assert len(mock_session.messages) == 1
                    mock_working_memory.set_working_memory.assert_called_once()

    @pytest.mark.asyncio
    async def test_add_message_returns_none_when_session_unavailable(self, mock_ams_modules):
        """add_message should return None when _ensure_session yields None."""
        redis_client = MagicMock()

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                memory = Memory(redis_client, namespace="test", enabled=True).with_session(
                    "session-123"
                )
                memory._ensure_session = AsyncMock(return_value=None)
                result = await memory.add_message(role="user", content="Hello")

        assert result is None

    @pytest.mark.asyncio
    async def test_get_messages_when_enabled(self, mock_ams_modules):
        """get_messages should return messages from working memory."""
        redis_client = MagicMock()

        # Create mock session with messages
        mock_message = MagicMock()
        mock_message.role = "user"
        mock_message.content = "Hello"
        mock_session = MagicMock()
        mock_session.messages = [mock_message]

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=mock_session)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    messages = await bound.get_messages()

                    assert len(messages) == 1
                    assert messages[0]["role"] == "user"
                    assert messages[0]["content"] == "Hello"

    @pytest.mark.asyncio
    async def test_get_messages_with_limit(self, mock_ams_modules):
        """get_messages should respect limit parameter."""
        redis_client = MagicMock()

        # Create mock session with multiple messages
        mock_messages = []
        for i in range(5):
            msg = MagicMock()
            msg.role = "user"
            msg.content = f"Message {i}"
            mock_messages.append(msg)

        mock_session = MagicMock()
        mock_session.messages = mock_messages

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=mock_session)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    messages = await bound.get_messages(limit=2)

                    assert len(messages) == 2
                    # Should return last 2 messages
                    assert messages[0]["content"] == "Message 3"
                    assert messages[1]["content"] == "Message 4"

    @pytest.mark.asyncio
    async def test_get_history_formats_messages(self, mock_ams_modules):
        """get_history should format messages as text."""
        redis_client = MagicMock()

        mock_messages = []
        for role, content in [("user", "Hello"), ("assistant", "Hi there!")]:
            msg = MagicMock()
            msg.role = role
            msg.content = content
            mock_messages.append(msg)

        mock_session = MagicMock()
        mock_session.messages = mock_messages

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=mock_session)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    history = await bound.get_history()

                    assert history == "user: Hello\nassistant: Hi there!"

    @pytest.mark.asyncio
    async def test_get_history_custom_format(self, mock_ams_modules):
        """get_history should support custom format strings."""
        redis_client = MagicMock()

        msg = MagicMock()
        msg.role = "user"
        msg.content = "Test"

        mock_session = MagicMock()
        mock_session.messages = [msg]

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=mock_session)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    history = await bound.get_history(format="[{role}] {content}")

                    assert history == "[user] Test"

    @pytest.mark.asyncio
    async def test_get_history_returns_empty_when_disabled(self):
        """get_history should return empty string when disabled."""
        with patch("redis_agent_kit.memory._check_ams", return_value=False):
            memory = Memory(enabled=False)
            history = await memory.get_history()
            assert history == ""

    @pytest.mark.asyncio
    async def test_get_context_when_enabled(self, mock_ams_modules):
        """get_context should return context from working memory."""
        redis_client = MagicMock()

        mock_session = MagicMock()
        mock_session.context = "Previous conversation summary"

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=mock_session)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    context = await bound.get_context()

                    assert context == "Previous conversation summary"

    @pytest.mark.asyncio
    async def test_set_data_when_enabled(self, mock_ams_modules):
        """set_data should store data in working memory."""
        redis_client = MagicMock()

        mock_session = MagicMock()
        mock_session.data = None

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=mock_session)
        mock_working_memory.set_working_memory = AsyncMock()

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    await bound.set_data("key", "value")

                    assert mock_session.data == {"key": "value"}
                    mock_working_memory.set_working_memory.assert_called_once()

    @pytest.mark.asyncio
    async def test_set_data_preserves_existing_data_dict(self, mock_ams_modules):
        """set_data should update existing data without resetting it."""
        redis_client = MagicMock()

        mock_session = MagicMock()
        mock_session.data = {"existing": "value"}

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=mock_session)
        mock_working_memory.set_working_memory = AsyncMock()

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    await bound.set_data("new", "item")

                    assert mock_session.data == {"existing": "value", "new": "item"}
                    mock_working_memory.set_working_memory.assert_called_once()

    @pytest.mark.asyncio
    async def test_set_data_returns_when_session_unavailable(self, mock_ams_modules):
        """set_data should no-op when _ensure_session yields None."""
        redis_client = MagicMock()

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                memory = Memory(redis_client, namespace="test", enabled=True).with_session(
                    "session-123"
                )
                memory._ensure_session = AsyncMock(return_value=None)
                await memory.set_data("key", "value")

    @pytest.mark.asyncio
    async def test_get_data_when_enabled(self, mock_ams_modules):
        """get_data should retrieve data from working memory."""
        redis_client = MagicMock()

        mock_session = MagicMock()
        mock_session.data = {"key": "value"}

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=mock_session)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    result = await bound.get_data("key")

                    assert result == "value"

    @pytest.mark.asyncio
    async def test_get_data_returns_default_when_key_missing(self, mock_ams_modules):
        """get_data should return default when key not found."""
        redis_client = MagicMock()

        mock_session = MagicMock()
        mock_session.data = {}

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=mock_session)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    result = await bound.get_data("missing", default="default_value")

                    assert result == "default_value"

    @pytest.mark.asyncio
    async def test_search_when_enabled(self, mock_ams_modules):
        """search should search long-term memories."""
        redis_client = MagicMock()

        # Create mock search result
        mock_memory = MagicMock()
        mock_memory.id = "mem-123"
        mock_memory.text = "Test memory"
        mock_memory.memory_type = "semantic"
        mock_memory.topics = ["test"]
        mock_memory.entities = ["entity1"]
        mock_memory.dist = 0.1

        mock_result = MagicMock()
        mock_result.memories = [mock_memory]

        mock_long_term = mock_ams_modules["agent_memory_server.long_term_memory"]
        mock_long_term.search_long_term_memories = AsyncMock(return_value=mock_result)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = True
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    results = await bound.search("test query")

                    assert len(results) == 1
                    assert results[0]["id"] == "mem-123"
                    assert results[0]["text"] == "Test memory"
                    assert results[0]["memory_type"] == "semantic"
                    assert results[0]["score"] == 0.1

    @pytest.mark.asyncio
    async def test_search_returns_empty_when_no_results(self, mock_ams_modules):
        """search should return empty list when no results."""
        redis_client = MagicMock()

        mock_long_term = mock_ams_modules["agent_memory_server.long_term_memory"]
        mock_long_term.search_long_term_memories = AsyncMock(return_value=None)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = True
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    results = await bound.search("test query")

                    assert results == []

    @pytest.mark.asyncio
    async def test_search_text_returns_formatted_results(self, mock_ams_modules):
        """search_text should return just the text content."""
        redis_client = MagicMock()

        mock_memories = []
        for i, text in enumerate(["Memory one", "Memory two"]):
            mem = MagicMock()
            mem.id = f"mem-{i}"
            mem.text = text
            mem.memory_type = "semantic"
            mem.topics = []
            mem.entities = []
            mem.dist = 0.1
            mock_memories.append(mem)

        mock_result = MagicMock()
        mock_result.memories = mock_memories

        mock_long_term = mock_ams_modules["agent_memory_server.long_term_memory"]
        mock_long_term.search_long_term_memories = AsyncMock(return_value=mock_result)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = True
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    result = await bound.search_text("query")

                    assert result == "Memory one\nMemory two"

    @pytest.mark.asyncio
    async def test_search_text_custom_separator(self, mock_ams_modules):
        """search_text should support custom separator."""
        redis_client = MagicMock()

        mem = MagicMock()
        mem.id = "mem-1"
        mem.text = "Single memory"
        mem.memory_type = "semantic"
        mem.topics = []
        mem.entities = []
        mem.dist = 0.1

        mock_result = MagicMock()
        mock_result.memories = [mem]

        mock_long_term = mock_ams_modules["agent_memory_server.long_term_memory"]
        mock_long_term.search_long_term_memories = AsyncMock(return_value=mock_result)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = True
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    result = await bound.search_text("query", separator=" | ")

                    assert result == "Single memory"

    @pytest.mark.asyncio
    async def test_search_text_returns_empty_when_disabled(self):
        """search_text should return empty string when disabled."""
        with patch("redis_agent_kit.memory._check_ams", return_value=False):
            memory = Memory(enabled=False)
            result = await memory.search_text("query")
            assert result == ""

    @pytest.mark.asyncio
    async def test_create_memory_when_enabled(self, mock_ams_modules):
        """create_memory should create a long-term memory."""
        redis_client = MagicMock()

        mock_result = MagicMock()
        mock_result.id = "mem-456"

        mock_long_term = mock_ams_modules["agent_memory_server.long_term_memory"]
        mock_long_term.create_long_term_memory = AsyncMock(return_value=mock_result)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = True
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    result = await bound.create_memory("Important fact")

                    assert result == "mem-456"
                    mock_long_term.create_long_term_memory.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_memory_returns_none_when_failed(self, mock_ams_modules):
        """create_memory should return None when creation fails."""
        redis_client = MagicMock()

        mock_long_term = mock_ams_modules["agent_memory_server.long_term_memory"]
        mock_long_term.create_long_term_memory = AsyncMock(return_value=None)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = True
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    result = await bound.create_memory("Important fact")

                    assert result is None

    @pytest.mark.asyncio
    async def test_delete_memories_when_enabled(self, mock_ams_modules):
        """delete_memories should delete long-term memories."""
        redis_client = MagicMock()

        mock_long_term = mock_ams_modules["agent_memory_server.long_term_memory"]
        mock_long_term.delete_long_term_memories = AsyncMock(return_value=2)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = True
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    result = await bound.delete_memories(["mem-1", "mem-2"])

                    assert result == 2
                    mock_long_term.delete_long_term_memories.assert_called_once()

    @pytest.mark.asyncio
    async def test_delete_session_when_enabled(self, mock_ams_modules):
        """delete_session should delete working memory session."""
        redis_client = MagicMock()

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.delete_working_memory = AsyncMock(return_value=True)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    result = await bound.delete_session()

                    assert result is True
                    mock_working_memory.delete_working_memory.assert_called_once()

    @pytest.mark.asyncio
    async def test_ensure_session_creates_new_session(self, mock_ams_modules):
        """_ensure_session should create new session when none exists."""
        redis_client = MagicMock()

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=None)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    await bound._ensure_session()

                    # WorkingMemory constructor should have been called
                    mock_ams_modules[
                        "agent_memory_server.models"
                    ].WorkingMemory.assert_called_once()

    @pytest.mark.asyncio
    async def test_ensure_session_generates_session_id_when_missing(self, mock_ams_modules):
        """_ensure_session should generate session_id when none is bound."""
        redis_client = MagicMock()

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=None)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    session = await memory._ensure_session()

                    assert memory.session_id is not None
                    assert session is not None

    @pytest.mark.asyncio
    async def test_get_session_returns_none_when_no_session_id(self, mock_ams_modules):
        """_get_session should return None when session_id is not bound."""
        redis_client = MagicMock()
        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                memory = Memory(redis_client, namespace="test", enabled=True)
                result = await memory._get_session()

        assert result is None

    @pytest.mark.asyncio
    async def test_delete_memories_returns_zero_when_empty_ids_enabled(self, mock_ams_modules):
        """delete_memories should short-circuit on empty ids even when enabled."""
        redis_client = MagicMock()
        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                memory = Memory(redis_client, namespace="test", enabled=True).with_session(
                    "session-123"
                )
                result = await memory.delete_memories([])

        assert result == 0

    @pytest.mark.asyncio
    async def test_get_messages_returns_empty_when_no_session(self, mock_ams_modules):
        """get_messages should return empty list when no session exists."""
        redis_client = MagicMock()

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=None)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    messages = await bound.get_messages()

                    assert messages == []

    @pytest.mark.asyncio
    async def test_get_context_returns_none_when_no_session(self, mock_ams_modules):
        """get_context should return None when no session exists."""
        redis_client = MagicMock()

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=None)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    context = await bound.get_context()

                    assert context is None

    @pytest.mark.asyncio
    async def test_get_data_returns_default_when_no_session(self, mock_ams_modules):
        """get_data should return default when no session exists."""
        redis_client = MagicMock()

        mock_working_memory = mock_ams_modules["agent_memory_server.working_memory"]
        mock_working_memory.get_working_memory = AsyncMock(return_value=None)

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        mock_settings.memory.long_term_enabled = False
        mock_settings.memory.summarization_threshold = 5
        mock_settings.memory.enable_extraction = False
        mock_settings.memory.forgetting_enabled = False
        mock_settings.model.default_model = "gpt-4"
        mock_settings.model.embedding_model = "text-embedding-3-small"

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    bound = memory.with_session("session-123")

                    result = await bound.get_data("key", default="default")

                    assert result == "default"

    @pytest.mark.asyncio
    async def test_configure_ams_handles_exception(self, mock_ams_modules):
        """_configure_ams should handle exceptions gracefully."""
        redis_client = MagicMock()

        mock_settings = MagicMock()
        mock_settings.redis_url = "redis://localhost:6379"
        # Make accessing memory settings raise an exception
        type(mock_settings).memory = property(
            lambda self: (_ for _ in ()).throw(Exception("Config error"))
        )

        with patch.dict(sys.modules, mock_ams_modules):
            with patch("redis_agent_kit.memory._check_ams", return_value=True):
                with patch("redis_agent_kit.config.get_settings", return_value=mock_settings):
                    memory = Memory(redis_client, namespace="test", enabled=True)
                    # Should not raise, just log warning
                    memory._configure_ams()
                    # _ams_configured should still be False due to exception
                    assert memory._ams_configured is False
