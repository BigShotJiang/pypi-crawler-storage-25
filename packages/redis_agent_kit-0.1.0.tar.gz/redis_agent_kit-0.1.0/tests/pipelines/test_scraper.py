"""TDD tests for BaseScraper - written BEFORE implementation."""

import tempfile
from pathlib import Path

import pytest

from redis_agent_kit.pipelines.models import Document


class TestBaseScraper:
    """Tests for BaseScraper abstract class."""

    def test_base_scraper_is_abstract(self):
        """BaseScraper should not be instantiable directly."""
        from redis_agent_kit.pipelines.scraper import BaseScraper

        with pytest.raises(TypeError):
            BaseScraper()  # type: ignore

    def test_base_scraper_requires_scrape_method(self):
        """Subclass must implement scrape method."""
        from redis_agent_kit.pipelines.scraper import BaseScraper

        class IncompleteScraper(BaseScraper):
            def get_source_name(self) -> str:
                return "incomplete"

        with pytest.raises(TypeError):
            IncompleteScraper()  # type: ignore

    def test_base_scraper_requires_get_source_name(self):
        """Subclass must implement get_source_name method."""
        from redis_agent_kit.pipelines.scraper import BaseScraper

        class IncompleteScraper(BaseScraper):
            async def scrape(self) -> list[Document]:
                return []

        with pytest.raises(TypeError):
            IncompleteScraper()  # type: ignore

    def test_complete_scraper_implementation(self):
        """Complete scraper implementation should be instantiable."""
        from redis_agent_kit.pipelines.scraper import BaseScraper

        class CompleteScraper(BaseScraper):
            async def scrape(self) -> list[Document]:
                return []

            def get_source_name(self) -> str:
                return "complete"

        scraper = CompleteScraper()
        assert scraper.get_source_name() == "complete"


class TestFileScraper:
    """Tests for FileScraper implementation."""

    def test_file_scraper_creation(self):
        """FileScraper should be creatable with a directory path."""
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            scraper = FileScraper(Path(tmpdir))
            assert scraper.get_source_name() == "file"

    def test_file_scraper_with_patterns(self):
        """FileScraper should accept file patterns."""
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            scraper = FileScraper(Path(tmpdir), patterns=["*.md", "*.txt"])
            assert scraper.patterns == ["*.md", "*.txt"]

    @pytest.mark.asyncio
    async def test_file_scraper_scrapes_files(self):
        """FileScraper should scrape files from directory."""
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create test files
            path = Path(tmpdir)
            (path / "doc1.md").write_text("# Document 1\n\nContent here.")
            (path / "doc2.md").write_text("# Document 2\n\nMore content.")

            scraper = FileScraper(path, patterns=["*.md"])
            docs = await scraper.scrape()

            assert len(docs) == 2
            titles = {d.title for d in docs}
            assert "doc1.md" in titles
            assert "doc2.md" in titles

    @pytest.mark.asyncio
    async def test_file_scraper_respects_patterns(self):
        """FileScraper should only scrape files matching patterns."""
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir)
            (path / "doc.md").write_text("Markdown content")
            (path / "doc.txt").write_text("Text content")
            (path / "doc.py").write_text("Python content")

            scraper = FileScraper(path, patterns=["*.md"])
            docs = await scraper.scrape()

            assert len(docs) == 1
            assert docs[0].title == "doc.md"

    @pytest.mark.asyncio
    async def test_file_scraper_recursive(self):
        """FileScraper should scrape recursively when configured."""
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir)
            (path / "doc1.md").write_text("Root doc")
            subdir = path / "subdir"
            subdir.mkdir()
            (subdir / "doc2.md").write_text("Nested doc")

            scraper = FileScraper(path, patterns=["*.md"], recursive=True)
            docs = await scraper.scrape()

            assert len(docs) == 2

    @pytest.mark.asyncio
    async def test_file_scraper_sets_document_source(self):
        """FileScraper should set document source to file path."""
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir)
            (path / "doc.md").write_text("Content")

            scraper = FileScraper(path, patterns=["*.md"])
            docs = await scraper.scrape()

            assert str(path / "doc.md") in docs[0].source

    @pytest.mark.asyncio
    async def test_file_scraper_empty_directory(self):
        """FileScraper should return empty list for empty directory."""
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            scraper = FileScraper(Path(tmpdir), patterns=["*.md"])
            docs = await scraper.scrape()
            assert docs == []

    @pytest.mark.asyncio
    async def test_file_scraper_skips_unreadable_files(self):
        """FileScraper should skip files that can't be read."""
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir)
            # Create a valid file
            (path / "valid.md").write_text("Valid content")
            # Create a binary file that will fail to decode as text
            (path / "binary.md").write_bytes(b"\x80\x81\x82\x83")

            scraper = FileScraper(path, patterns=["*.md"])
            docs = await scraper.scrape()

            # Should only get the valid file
            assert len(docs) == 1
            assert docs[0].title == "valid.md"
