"""TDD tests for DocumentDeduplicator - written BEFORE implementation."""


class TestDocumentDeduplicatorBasic:
    """Tests for DocumentDeduplicator basic functionality."""

    def test_is_duplicate_returns_false_for_new_document(self, tmp_path):
        """Deduplicator should return False for new documents."""
        from redis_agent_kit.pipelines.deduplicator import DocumentDeduplicator

        deduplicator = DocumentDeduplicator(hash_store_path=tmp_path / "hashes.json")
        content = "This is new content"

        assert deduplicator.is_duplicate(content) is False

    def test_is_duplicate_returns_true_for_seen_document(self, tmp_path):
        """Deduplicator should return True for previously seen content."""
        from redis_agent_kit.pipelines.deduplicator import DocumentDeduplicator

        deduplicator = DocumentDeduplicator(hash_store_path=tmp_path / "hashes.json")
        content = "This is duplicate content"

        # First time - not a duplicate
        assert deduplicator.is_duplicate(content) is False
        # Mark as seen
        deduplicator.mark_seen(content)
        # Second time - is a duplicate
        assert deduplicator.is_duplicate(content) is True

    def test_mark_seen_stores_content_hash(self, tmp_path):
        """Deduplicator should store content hash when marked as seen."""
        from redis_agent_kit.pipelines.deduplicator import DocumentDeduplicator

        deduplicator = DocumentDeduplicator(hash_store_path=tmp_path / "hashes.json")
        content = "Content to mark"

        deduplicator.mark_seen(content)
        assert deduplicator.is_duplicate(content) is True

    def test_get_content_hash(self, tmp_path):
        """Deduplicator should compute consistent content hash."""
        from redis_agent_kit.pipelines.deduplicator import DocumentDeduplicator

        deduplicator = DocumentDeduplicator(hash_store_path=tmp_path / "hashes.json")
        content = "Test content"

        hash1 = deduplicator.get_content_hash(content)
        hash2 = deduplicator.get_content_hash(content)

        assert hash1 == hash2
        assert len(hash1) == 64  # SHA-256 hex digest

    def test_different_content_different_hash(self, tmp_path):
        """Deduplicator should produce different hashes for different content."""
        from redis_agent_kit.pipelines.deduplicator import DocumentDeduplicator

        deduplicator = DocumentDeduplicator(hash_store_path=tmp_path / "hashes.json")

        hash1 = deduplicator.get_content_hash("Content A")
        hash2 = deduplicator.get_content_hash("Content B")

        assert hash1 != hash2


class TestDocumentDeduplicatorPersistence:
    """Tests for DocumentDeduplicator persistence."""

    def test_persists_hashes_to_file(self, tmp_path):
        """Deduplicator should persist hashes to file."""
        from redis_agent_kit.pipelines.deduplicator import DocumentDeduplicator

        hash_path = tmp_path / "hashes.json"
        deduplicator = DocumentDeduplicator(hash_store_path=hash_path)
        deduplicator.mark_seen("Content to persist")
        deduplicator.save()

        assert hash_path.exists()

    def test_loads_hashes_from_file(self, tmp_path):
        """Deduplicator should load hashes from existing file."""
        from redis_agent_kit.pipelines.deduplicator import DocumentDeduplicator

        hash_path = tmp_path / "hashes.json"

        # First instance - mark content as seen
        deduplicator1 = DocumentDeduplicator(hash_store_path=hash_path)
        deduplicator1.mark_seen("Persisted content")
        deduplicator1.save()

        # Second instance - should load from file
        deduplicator2 = DocumentDeduplicator(hash_store_path=hash_path)
        assert deduplicator2.is_duplicate("Persisted content") is True

    def test_clear_removes_all_hashes(self, tmp_path):
        """Deduplicator clear should remove all stored hashes."""
        from redis_agent_kit.pipelines.deduplicator import DocumentDeduplicator

        deduplicator = DocumentDeduplicator(hash_store_path=tmp_path / "hashes.json")
        deduplicator.mark_seen("Content 1")
        deduplicator.mark_seen("Content 2")

        deduplicator.clear()

        assert deduplicator.is_duplicate("Content 1") is False
        assert deduplicator.is_duplicate("Content 2") is False


class TestDocumentDeduplicatorReplacement:
    """Tests for DocumentDeduplicator replacement functionality."""

    def test_replace_document_updates_hash(self, tmp_path):
        """Deduplicator should update hash when replacing document."""
        from redis_agent_kit.pipelines.deduplicator import DocumentDeduplicator

        deduplicator = DocumentDeduplicator(hash_store_path=tmp_path / "hashes.json")
        doc_id = "doc1"
        old_content = "Old content"
        new_content = "New content"

        # Mark old content with doc_id
        deduplicator.mark_seen(old_content, doc_id=doc_id)
        assert deduplicator.is_duplicate(old_content) is True

        # Replace with new content
        deduplicator.replace_document(doc_id, new_content)

        # Old content should no longer be tracked
        assert deduplicator.is_duplicate(old_content) is False
        # New content should be tracked
        assert deduplicator.is_duplicate(new_content) is True

    def test_get_doc_id_for_content(self, tmp_path):
        """Deduplicator should return doc_id for content hash."""
        from redis_agent_kit.pipelines.deduplicator import DocumentDeduplicator

        deduplicator = DocumentDeduplicator(hash_store_path=tmp_path / "hashes.json")
        doc_id = "doc123"
        content = "Test content"

        deduplicator.mark_seen(content, doc_id=doc_id)
        assert deduplicator.get_doc_id_for_content(content) == doc_id

    def test_get_doc_id_returns_none_for_unknown(self, tmp_path):
        """Deduplicator should return None for unknown content."""
        from redis_agent_kit.pipelines.deduplicator import DocumentDeduplicator

        deduplicator = DocumentDeduplicator(hash_store_path=tmp_path / "hashes.json")
        assert deduplicator.get_doc_id_for_content("Unknown content") is None
