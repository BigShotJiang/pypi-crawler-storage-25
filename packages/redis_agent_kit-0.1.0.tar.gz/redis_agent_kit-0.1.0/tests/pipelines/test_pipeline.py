"""TDD tests for Pipeline - written BEFORE implementation."""

import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from redis_agent_kit.pipelines.models import Document, ProcessorConfig


class TestPipeline:
    """Tests for Pipeline class."""

    def test_pipeline_creation(self, redis_client, mock_openai_vectorizer):
        """Pipeline should be creatable with Redis client."""
        from redis_agent_kit.pipelines.pipeline import Pipeline

        pipeline = Pipeline(redis_client)
        assert pipeline.client == redis_client

    def test_pipeline_with_custom_config(self, redis_client, mock_openai_vectorizer):
        """Pipeline should accept custom processor config."""
        from redis_agent_kit.pipelines.pipeline import Pipeline

        config = ProcessorConfig(chunk_size=500)
        pipeline = Pipeline(redis_client, processor_config=config)
        assert pipeline.processor.config.chunk_size == 500

    def test_pipeline_with_custom_model(self, redis_client, mock_openai_vectorizer):
        """Pipeline should accept custom embedding model."""
        from redis_agent_kit.pipelines.pipeline import Pipeline

        pipeline = Pipeline(redis_client, embedding_model="custom-model")
        assert pipeline.vectorizer.model == "custom-model"

    @pytest.mark.asyncio
    async def test_pipeline_run_with_scraper(self, redis_client, mock_openai_vectorizer):
        """Pipeline should run with a scraper."""
        from redis_agent_kit.pipelines.pipeline import Pipeline
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir)
            (path / "doc.md").write_text("# Test\n\nThis is test content.")

            scraper = FileScraper(path, patterns=["*.md"])
            pipeline = Pipeline(redis_client)

            result = await pipeline.run(scraper)

            assert result.status == "completed"
            assert result.documents_processed == 1
            assert result.chunks_created >= 1

    @pytest.mark.asyncio
    async def test_pipeline_run_empty_scraper(self, redis_client, mock_openai_vectorizer):
        """Pipeline should handle empty scraper results."""
        from redis_agent_kit.pipelines.pipeline import Pipeline
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            scraper = FileScraper(Path(tmpdir), patterns=["*.md"])
            pipeline = Pipeline(redis_client)

            result = await pipeline.run(scraper)

            assert result.status == "completed"
            assert result.documents_processed == 0
            assert result.chunks_created == 0

    @pytest.mark.asyncio
    async def test_pipeline_stores_chunks(self, redis_client, mock_openai_vectorizer):
        """Pipeline should store chunks in vector store."""
        from redis_agent_kit.pipelines.pipeline import Pipeline
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir)
            (path / "doc.md").write_text("Test content for storage.")

            scraper = FileScraper(path, patterns=["*.md"])
            pipeline = Pipeline(redis_client)

            await pipeline.run(scraper)

            # Verify chunks are stored
            count = await pipeline.vector_store.count()
            assert count >= 1

    @pytest.mark.asyncio
    async def test_pipeline_result_has_pipeline_id(self, redis_client, mock_openai_vectorizer):
        """Pipeline result should have unique pipeline_id."""
        from redis_agent_kit.pipelines.pipeline import Pipeline
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            scraper = FileScraper(Path(tmpdir), patterns=["*.md"])
            pipeline = Pipeline(redis_client)

            result = await pipeline.run(scraper)

            assert result.pipeline_id is not None
            assert len(result.pipeline_id) > 0

    @pytest.mark.asyncio
    async def test_pipeline_result_has_timestamps(self, redis_client, mock_openai_vectorizer):
        """Pipeline result should have start and end timestamps."""
        from redis_agent_kit.pipelines.pipeline import Pipeline
        from redis_agent_kit.pipelines.scraper import FileScraper

        with tempfile.TemporaryDirectory() as tmpdir:
            scraper = FileScraper(Path(tmpdir), patterns=["*.md"])
            pipeline = Pipeline(redis_client)

            result = await pipeline.run(scraper)

            assert result.started_at is not None
            assert result.completed_at is not None
            assert result.completed_at >= result.started_at

    @pytest.mark.asyncio
    async def test_pipeline_run_with_documents(self, redis_client, mock_openai_vectorizer):
        """Pipeline should accept documents directly."""
        from redis_agent_kit.pipelines.pipeline import Pipeline

        docs = [
            Document(title="Doc1", content="Content one.", source="test"),
            Document(title="Doc2", content="Content two.", source="test"),
        ]

        pipeline = Pipeline(redis_client)

        result = await pipeline.run_documents(docs)

        assert result.documents_processed == 2
        assert result.chunks_created == 2

    @pytest.mark.asyncio
    async def test_pipeline_run_handles_processing_error(
        self, redis_client, mock_openai_vectorizer
    ):
        """Pipeline should handle errors during document processing."""
        from redis_agent_kit.pipelines.pipeline import Pipeline

        docs = [
            Document(title="Doc1", content="Content one.", source="test"),
        ]

        pipeline = Pipeline(redis_client)

        # Mock processor to raise an error
        with patch.object(
            pipeline.processor, "chunk_document", side_effect=Exception("Processing error")
        ):
            result = await pipeline.run_documents(docs)

        assert result.status == "completed_with_errors"
        assert len(result.errors) == 1
        assert "Processing error" in result.errors[0]

    @pytest.mark.asyncio
    async def test_pipeline_run_handles_embedding_error(self, redis_client, mock_openai_vectorizer):
        """Pipeline should handle errors during embedding."""
        from redis_agent_kit.pipelines.pipeline import Pipeline

        docs = [
            Document(title="Doc1", content="Content one.", source="test"),
        ]

        pipeline = Pipeline(redis_client)

        # Override the mock to raise an error
        mock_openai_vectorizer.aembed_many.side_effect = Exception("Embedding API error")
        result = await pipeline.run_documents(docs)

        assert result.status == "completed_with_errors"
        assert len(result.errors) == 1
        assert "Embedding API error" in result.errors[0]

    def test_pipeline_has_task_manager(self, redis_client, mock_openai_vectorizer):
        """Pipeline should have a TaskManager for tracking."""
        from redis_agent_kit.pipelines.pipeline import Pipeline
        from redis_agent_kit.task_manager import TaskManager

        pipeline = Pipeline(redis_client)
        assert isinstance(pipeline.task_manager, TaskManager)

    def test_pipeline_with_custom_docket_config(self, redis_client, mock_openai_vectorizer):
        """Pipeline should accept custom Docket configuration."""
        from redis_agent_kit.pipelines.pipeline import Pipeline

        pipeline = Pipeline(
            redis_client,
            redis_url="redis://custom:6379",
            queue_name="custom_pipeline",
        )
        assert pipeline._redis_url == "redis://custom:6379"
        assert pipeline._queue_name == "custom_pipeline"

    @pytest.mark.asyncio
    async def test_pipeline_submit_creates_task(self, redis_client, mock_openai_vectorizer):
        """Pipeline submit should create a task and queue for processing."""
        from redis_agent_kit.pipelines.pipeline import Pipeline

        docs = [
            Document(title="Doc1", content="Content one.", source="test"),
        ]

        pipeline = Pipeline(redis_client)

        # Mock Docket to avoid actual queue submission
        with patch("redis_agent_kit.pipelines.pipeline.Docket") as mock_docket_class:
            mock_instance = MagicMock()
            mock_docket_class.return_value.__aenter__.return_value = mock_instance
            # add() returns a regular callable, calling it returns a coroutine
            mock_instance.add.return_value = AsyncMock(return_value=None)

            result = await pipeline.submit(docs)

        assert "task_id" in result
        assert result["status"] == "queued"
        assert "Pipeline queued" in result["message"]

        # Verify task was created
        task = await pipeline.task_manager.get_task(result["task_id"])
        assert task is not None
        assert task.status.value == "queued"

    @pytest.mark.asyncio
    async def test_pipeline_submit_with_context(self, redis_client, mock_openai_vectorizer):
        """Pipeline submit should accept context data."""
        from redis_agent_kit.pipelines.pipeline import Pipeline

        docs = [
            Document(title="Doc1", content="Content one.", source="test"),
        ]

        pipeline = Pipeline(redis_client)

        with patch("redis_agent_kit.pipelines.pipeline.Docket") as mock_docket_class:
            mock_instance = MagicMock()
            mock_docket_class.return_value.__aenter__.return_value = mock_instance
            mock_instance.add.return_value = AsyncMock(return_value=None)

            result = await pipeline.submit(docs, context={"user_id": "u123"})

        task = await pipeline.task_manager.get_task(result["task_id"])
        # Context is stored in metadata["context"]
        assert task.metadata.get("context") == {"user_id": "u123"}

    @pytest.mark.asyncio
    async def test_pipeline_run_documents_with_emitter(self, redis_client, mock_openai_vectorizer):
        """Pipeline should emit progress updates when emitter is provided."""
        from redis_agent_kit.emitter import TaskEmitter
        from redis_agent_kit.pipelines.pipeline import Pipeline
        from redis_agent_kit.task_manager import TaskManager

        docs = [
            Document(title="Doc1", content="Content one.", source="test"),
        ]

        pipeline = Pipeline(redis_client)
        task_manager = TaskManager(redis_client)

        # Create a task for the emitter
        task = await task_manager.create_task(session_id="test", message="Test pipeline")
        emitter = TaskEmitter(task_manager, task.task_id)

        result = await pipeline.run_documents(docs, emitter=emitter)

        assert result.status == "completed"

        # Verify updates were emitted
        updated_task = await task_manager.get_task(task.task_id)
        assert len(updated_task.updates) > 0
        # Check for expected update messages
        update_messages = [u.message for u in updated_task.updates]
        assert any("Starting pipeline" in m for m in update_messages)
        assert any("Processing document" in m for m in update_messages)

    @pytest.mark.asyncio
    async def test_pipeline_run_documents_emitter_reports_errors(
        self, redis_client, mock_openai_vectorizer
    ):
        """Pipeline should emit error updates when processing fails."""
        from redis_agent_kit.emitter import TaskEmitter
        from redis_agent_kit.pipelines.pipeline import Pipeline
        from redis_agent_kit.task_manager import TaskManager

        docs = [
            Document(title="Doc1", content="Content one.", source="test"),
        ]

        pipeline = Pipeline(redis_client)
        task_manager = TaskManager(redis_client)

        task = await task_manager.create_task(session_id="test", message="Test pipeline")
        emitter = TaskEmitter(task_manager, task.task_id)

        # Mock processor to raise an error
        with patch.object(
            pipeline.processor, "chunk_document", side_effect=Exception("Chunk error")
        ):
            result = await pipeline.run_documents(docs, emitter=emitter)

        assert result.status == "completed_with_errors"

        # Verify error was emitted
        updated_task = await task_manager.get_task(task.task_id)
        update_types = [u.update_type for u in updated_task.updates]
        assert "error" in update_types


class TestPipelineTaskHandler:
    """Tests for the Docket task handler function."""

    @pytest.mark.asyncio
    async def test_run_pipeline_task_success(self, redis_client, redis_url):
        """Pipeline task handler should process documents successfully."""
        from redis_agent_kit.pipelines.pipeline import _run_pipeline_task
        from redis_agent_kit.task_manager import TaskManager

        # Create a task first
        task_manager = TaskManager(redis_client)
        task = await task_manager.create_task(session_id="pipeline", message="Test pipeline")

        docs_data = [
            {
                "doc_id": "test123",
                "title": "Test Doc",
                "content": "Test content for pipeline.",
                "source": "test",
                "doc_type": "other",
                "metadata": {},
                "created_at": "2024-01-01T00:00:00Z",
            }
        ]

        with patch("redis_agent_kit.pipelines.pipeline.Vectorizer") as mock_vectorizer_class:
            mock_vectorizer = AsyncMock()
            mock_vectorizer.embed_many = AsyncMock(return_value=[[0.1, 0.2, 0.3]])
            mock_vectorizer_class.return_value = mock_vectorizer

            result = await _run_pipeline_task(
                task_id=task.task_id,
                documents_data=docs_data,
                redis_url=redis_url,
                prefix="rak",
                processor_config=None,
                embedding_model="test-model",
                embedding_dimensions=None,
            )

        assert result["status"] == "completed"
        assert result["documents_processed"] == 1

        # Verify task was updated
        updated_task = await task_manager.get_task(task.task_id)
        assert updated_task.status.value == "done"
        assert updated_task.result is not None

    @pytest.mark.asyncio
    async def test_run_pipeline_task_with_processor_config(self, redis_client, redis_url):
        """Pipeline task handler should use processor config."""
        from redis_agent_kit.pipelines.pipeline import _run_pipeline_task
        from redis_agent_kit.task_manager import TaskManager

        task_manager = TaskManager(redis_client)
        task = await task_manager.create_task(session_id="pipeline", message="Test pipeline")

        docs_data = [
            {
                "doc_id": "test123",
                "title": "Test Doc",
                "content": "Test content.",
                "source": "test",
                "doc_type": "other",
                "metadata": {},
                "created_at": "2024-01-01T00:00:00Z",
            }
        ]

        processor_config = {"chunk_size": 500, "chunk_overlap": 100}

        with patch("redis_agent_kit.pipelines.pipeline.Vectorizer") as mock_vectorizer_class:
            mock_vectorizer = AsyncMock()
            mock_vectorizer.embed_many = AsyncMock(return_value=[[0.1]])
            mock_vectorizer_class.return_value = mock_vectorizer

            result = await _run_pipeline_task(
                task_id=task.task_id,
                documents_data=docs_data,
                redis_url=redis_url,
                prefix="rak",
                processor_config=processor_config,
                embedding_model="test-model",
                embedding_dimensions=None,
            )

        assert result["status"] == "completed"

    @pytest.mark.asyncio
    async def test_run_pipeline_task_handles_error(self, redis_client, redis_url):
        """Pipeline task handler should handle errors and update task status."""
        from redis_agent_kit.pipelines.pipeline import _run_pipeline_task
        from redis_agent_kit.task_manager import TaskManager

        task_manager = TaskManager(redis_client)
        task = await task_manager.create_task(session_id="pipeline", message="Test pipeline")

        docs_data = [
            {
                "doc_id": "test123",
                "title": "Test Doc",
                "content": "Test content.",
                "source": "test",
                "doc_type": "other",
                "metadata": {},
                "created_at": "2024-01-01T00:00:00Z",
            }
        ]

        with patch("redis_agent_kit.pipelines.pipeline.Vectorizer") as mock_vectorizer_class:
            mock_vectorizer = AsyncMock()
            mock_vectorizer.embed_many = AsyncMock(side_effect=Exception("Embedding failed"))
            mock_vectorizer_class.return_value = mock_vectorizer

            # The task should complete with errors (not raise)
            result = await _run_pipeline_task(
                task_id=task.task_id,
                documents_data=docs_data,
                redis_url=redis_url,
                prefix="rak",
                processor_config=None,
                embedding_model="test-model",
                embedding_dimensions=None,
            )

        # Pipeline completes with errors, doesn't fail the task
        assert result["status"] == "completed_with_errors"

        updated_task = await task_manager.get_task(task.task_id)
        assert updated_task.status.value == "done"

    @pytest.mark.asyncio
    async def test_run_pipeline_task_handles_fatal_error(self, redis_client, redis_url):
        """Pipeline task handler should handle fatal errors and set task to failed."""
        from redis_agent_kit.pipelines.pipeline import _run_pipeline_task
        from redis_agent_kit.task_manager import TaskManager

        task_manager = TaskManager(redis_client)
        task = await task_manager.create_task(session_id="pipeline", message="Test pipeline")

        # Invalid document data that will cause a fatal error during deserialization
        docs_data = [
            {
                # Missing required fields will cause Document validation to fail
                "invalid_field": "value",
            }
        ]

        with pytest.raises(Exception):
            await _run_pipeline_task(
                task_id=task.task_id,
                documents_data=docs_data,
                redis_url=redis_url,
                prefix="rak",
                processor_config=None,
                embedding_model="test-model",
                embedding_dimensions=None,
            )

        # Task should be marked as failed
        updated_task = await task_manager.get_task(task.task_id)
        assert updated_task.status.value == "failed"
        assert updated_task.error_message is not None
