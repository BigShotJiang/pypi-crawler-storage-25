"""TDD tests for VectorStore - written BEFORE implementation."""

import pytest

from redis_agent_kit.pipelines.models import Chunk


@pytest.fixture
def sample_chunks() -> list[Chunk]:
    """Create sample chunks for testing."""
    return [
        Chunk(
            chunk_id="doc1_0",
            doc_id="doc1",
            content="Redis is an in-memory data store.",
            chunk_index=0,
            metadata={"source": "docs", "title": "Redis Intro"},
        ),
        Chunk(
            chunk_id="doc1_1",
            doc_id="doc1",
            content="Redis supports various data structures.",
            chunk_index=1,
            metadata={"source": "docs", "title": "Redis Intro"},
        ),
        Chunk(
            chunk_id="doc2_0",
            doc_id="doc2",
            content="Python is a programming language.",
            chunk_index=0,
            metadata={"source": "docs", "title": "Python Intro"},
        ),
    ]


@pytest.fixture
def sample_embeddings() -> list[list[float]]:
    """Create sample embeddings for testing."""
    return [
        [0.1, 0.2, 0.3, 0.4],
        [0.2, 0.3, 0.4, 0.5],
        [0.5, 0.6, 0.7, 0.8],
    ]


class TestVectorStore:
    """Tests for VectorStore class."""

    def test_vector_store_creation(self, redis_client):
        """VectorStore should be creatable with Redis client."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        assert store.client == redis_client

    def test_vector_store_with_custom_prefix(self, redis_client):
        """VectorStore should accept custom key prefix."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client, prefix="custom")
        assert store.prefix == "custom"

    def test_vector_store_with_index_name(self, redis_client):
        """VectorStore should accept custom index name."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client, index_name="my_index")
        assert store.index_name == "my_index"

    @pytest.mark.asyncio
    async def test_store_chunks(self, redis_client, sample_chunks, sample_embeddings):
        """VectorStore should store chunks with embeddings."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        await store.store_chunks(sample_chunks, sample_embeddings)

        # Verify chunks are stored
        for chunk in sample_chunks:
            key = f"rak:chunk:{chunk.chunk_id}"
            exists = await redis_client.exists(key)
            assert exists

    @pytest.mark.asyncio
    async def test_get_chunk(self, redis_client, sample_chunks, sample_embeddings):
        """VectorStore should retrieve a stored chunk."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        await store.store_chunks(sample_chunks, sample_embeddings)

        chunk = await store.get_chunk("doc1_0")
        assert chunk is not None
        assert chunk.chunk_id == "doc1_0"
        assert chunk.content == "Redis is an in-memory data store."

    @pytest.mark.asyncio
    async def test_get_nonexistent_chunk(self, redis_client):
        """VectorStore should return None for nonexistent chunk."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        chunk = await store.get_chunk("nonexistent")
        assert chunk is None

    @pytest.mark.asyncio
    async def test_delete_by_doc_id(self, redis_client, sample_chunks, sample_embeddings):
        """VectorStore should delete all chunks for a document."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        await store.store_chunks(sample_chunks, sample_embeddings)

        # Delete doc1 chunks
        deleted = await store.delete_by_doc_id("doc1")
        assert deleted == 2  # doc1 has 2 chunks

        # Verify doc1 chunks are gone
        assert await store.get_chunk("doc1_0") is None
        assert await store.get_chunk("doc1_1") is None

        # Verify doc2 chunk still exists
        assert await store.get_chunk("doc2_0") is not None

    @pytest.mark.asyncio
    async def test_count_chunks(self, redis_client, sample_chunks, sample_embeddings):
        """VectorStore should count stored chunks."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        assert await store.count() == 0

        await store.store_chunks(sample_chunks, sample_embeddings)
        assert await store.count() == 3

    @pytest.mark.asyncio
    async def test_clear_all(self, redis_client, sample_chunks, sample_embeddings):
        """VectorStore should clear all chunks."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        await store.store_chunks(sample_chunks, sample_embeddings)
        assert await store.count() == 3

        await store.clear()
        assert await store.count() == 0

    @pytest.mark.asyncio
    async def test_store_chunks_mismatched_lengths(self, redis_client):
        """VectorStore should raise error for mismatched chunks/embeddings."""
        from redis_agent_kit.pipelines.models import Chunk
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        chunks = [Chunk(chunk_id="c1", doc_id="d1", content="test", chunk_index=0)]
        embeddings = [[0.1], [0.2]]  # 2 embeddings for 1 chunk

        with pytest.raises(ValueError, match="must match"):
            await store.store_chunks(chunks, embeddings)

    @pytest.mark.asyncio
    async def test_delete_by_doc_id_nonexistent(self, redis_client):
        """VectorStore should return 0 for deleting non-existent doc."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        deleted = await store.delete_by_doc_id("nonexistent")
        assert deleted == 0


class TestVectorStoreSync:
    """Tests for VectorStore synchronous methods."""

    def test_store_chunk_sync(self, redis_client):
        """VectorStore store_chunk_sync should store a single chunk synchronously."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        store.store_chunk_sync(
            chunk_id="sync_chunk_1",
            doc_id="sync_doc_1",
            content="Sync test content",
            embedding=[0.1, 0.2, 0.3],
            metadata={"chunk_index": 0, "title": "Sync Test"},
        )

        # Verify chunk was stored
        import asyncio

        async def verify():
            count = await store.count()
            return count

        count = asyncio.run(verify())
        assert count == 1

    def test_store_chunk_sync_without_metadata(self, redis_client):
        """VectorStore store_chunk_sync should work without metadata."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        store.store_chunk_sync(
            chunk_id="sync_chunk_2",
            doc_id="sync_doc_2",
            content="Sync test content",
            embedding=[0.1, 0.2, 0.3],
        )

        # Verify chunk was stored
        import asyncio

        async def verify():
            count = await store.count()
            return count

        count = asyncio.run(verify())
        assert count == 1

    @pytest.mark.asyncio
    async def test_store_chunk_sync_in_running_loop(self, redis_client):
        """VectorStore store_chunk_sync should work when called from async context."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        store.store_chunk_sync(
            chunk_id="async_sync_chunk",
            doc_id="async_sync_doc",
            content="Async context sync test",
            embedding=[0.7, 0.8, 0.9],
            metadata={"chunk_index": 0},
        )

        # Verify chunk was stored
        count = await store.count()
        assert count == 1


class TestVectorStoreEdgeCases:
    """Edge case tests for VectorStore."""

    @pytest.mark.asyncio
    async def test_store_empty_chunks(self, redis_client):
        """VectorStore should handle empty chunks list."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        await store.store_chunks([], [])
        assert await store.count() == 0

    @pytest.mark.asyncio
    async def test_ensure_index_already_created(
        self, redis_client, sample_chunks, sample_embeddings
    ):
        """VectorStore should skip index creation if already created."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        await store.store_chunks(sample_chunks, sample_embeddings)

        # Call ensure_index again - should be a no-op
        await store.ensure_index(4)
        assert store._index_created is True

    @pytest.mark.asyncio
    async def test_clear_without_index(self, redis_client):
        """VectorStore clear should work even without index."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        # Clear without ever creating index
        await store.clear()
        assert await store.count() == 0

    @pytest.mark.asyncio
    async def test_search_without_index(self, redis_client):
        """VectorStore search should return empty list if index not initialized."""
        from unittest.mock import patch

        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)

        # Mock ensure_index to not actually create the index
        async def mock_ensure_index(dims=None):
            store._index_created = True
            store._index = None  # Force index to be None

        with patch.object(store, "ensure_index", mock_ensure_index):
            results = await store.search([0.1, 0.2, 0.3, 0.4])
        assert results == []

    @pytest.mark.asyncio
    async def test_search_with_distance_threshold(
        self, redis_client, sample_chunks, sample_embeddings
    ):
        """VectorStore search should filter by distance threshold."""
        from unittest.mock import AsyncMock, patch

        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        await store.store_chunks(sample_chunks, sample_embeddings)

        # Mock the index query to return results with different distances
        mock_results = [
            {"vector_distance": "0.1", "$.chunk_id": "c1", "$.doc_id": "d1", "$.content": "close"},
            {"vector_distance": "0.9", "$.chunk_id": "c2", "$.doc_id": "d2", "$.content": "far"},
        ]

        with patch.object(store._index, "query", new_callable=AsyncMock) as mock_query:
            mock_query.return_value = mock_results
            results = await store.search([0.1, 0.2, 0.3, 0.4], distance_threshold=0.5)

        # Only the close result should be returned
        assert len(results) == 1
        assert results[0].content == "close"

    @pytest.mark.asyncio
    async def test_search_with_metadata_string(
        self, redis_client, sample_chunks, sample_embeddings
    ):
        """VectorStore search should parse metadata from JSON string."""
        from unittest.mock import AsyncMock, patch

        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        await store.store_chunks(sample_chunks, sample_embeddings)

        # Mock the index query to return metadata as JSON string
        mock_results = [
            {
                "vector_distance": "0.1",
                "$.chunk_id": "c1",
                "$.doc_id": "d1",
                "$.content": "test",
                "$.metadata": '{"key": "value"}',
            },
        ]

        with patch.object(store._index, "query", new_callable=AsyncMock) as mock_query:
            mock_query.return_value = mock_results
            results = await store.search([0.1, 0.2, 0.3, 0.4])

        assert len(results) == 1
        assert results[0].metadata == {"key": "value"}

    @pytest.mark.asyncio
    async def test_search_with_invalid_metadata_string(
        self, redis_client, sample_chunks, sample_embeddings
    ):
        """VectorStore search should handle invalid metadata JSON."""
        from unittest.mock import AsyncMock, patch

        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        await store.store_chunks(sample_chunks, sample_embeddings)

        # Mock the index query to return invalid metadata JSON
        mock_results = [
            {
                "vector_distance": "0.1",
                "$.chunk_id": "c1",
                "$.doc_id": "d1",
                "$.content": "test",
                "$.metadata": "invalid json {",
            },
        ]

        with patch.object(store._index, "query", new_callable=AsyncMock) as mock_query:
            mock_query.return_value = mock_results
            results = await store.search([0.1, 0.2, 0.3, 0.4])

        assert len(results) == 1
        assert results[0].metadata == {}

    @pytest.mark.asyncio
    async def test_search_query_exception(self, redis_client, sample_chunks, sample_embeddings):
        """VectorStore search should handle query exceptions gracefully."""
        from unittest.mock import AsyncMock, patch

        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        await store.store_chunks(sample_chunks, sample_embeddings)

        with patch.object(store._index, "query", new_callable=AsyncMock) as mock_query:
            mock_query.side_effect = Exception("Query failed")
            results = await store.search([0.1, 0.2, 0.3, 0.4])

        assert results == []

    @pytest.mark.asyncio
    async def test_clear_with_index_delete(self, redis_client, sample_chunks, sample_embeddings):
        """VectorStore clear should delete index via RedisVL."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        await store.store_chunks(sample_chunks, sample_embeddings)
        assert store._index is not None

        await store.clear()
        assert store._index is None
        assert store._index_created is False

    @pytest.mark.asyncio
    async def test_clear_without_redisvl_index(self, redis_client):
        """VectorStore clear should use raw command when no RedisVL index."""
        from redis_agent_kit.pipelines.vector_store import VectorStore

        store = VectorStore(redis_client)
        # Store some data first to create keys
        store._index = None

        # Should not raise even if index doesn't exist
        await store.clear()
        # _index_created stays as is since we didn't set it
        assert store._index is None
