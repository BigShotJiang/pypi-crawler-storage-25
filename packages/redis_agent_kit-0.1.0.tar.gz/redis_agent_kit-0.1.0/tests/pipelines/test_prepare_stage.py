"""TDD tests for PrepareStage - written BEFORE implementation."""


class TestPrepareStageBasic:
    """Tests for PrepareStage basic functionality."""

    def test_prepare_single_document(self, tmp_path):
        """PrepareStage should prepare a single document."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.models import SourceConfig
        from redis_agent_kit.pipelines.prepare_stage import PrepareStage

        # Create a test document
        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "test.md").write_text("# Test\n\nThis is test content.")

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        source = SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
        stage = PrepareStage(storage=storage, sources=[source], base_path=docs_dir)

        batch_id = stage.prepare()
        assert batch_id is not None
        manifest = storage.load_batch_manifest(batch_id)
        assert manifest is not None
        assert manifest.documents_prepared == 1
        assert manifest.chunks_created >= 1

    def test_prepare_multiple_documents(self, tmp_path):
        """PrepareStage should prepare multiple documents."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.models import SourceConfig
        from redis_agent_kit.pipelines.prepare_stage import PrepareStage

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "doc1.md").write_text("# Doc 1\n\nContent 1.")
        (docs_dir / "doc2.md").write_text("# Doc 2\n\nContent 2.")

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        source = SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
        stage = PrepareStage(storage=storage, sources=[source], base_path=docs_dir)

        batch_id = stage.prepare()
        manifest = storage.load_batch_manifest(batch_id)
        assert manifest.documents_prepared == 2

    def test_prepare_with_frontmatter(self, tmp_path):
        """PrepareStage should parse frontmatter and use it for chunking."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.models import SourceConfig
        from redis_agent_kit.pipelines.prepare_stage import PrepareStage

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        content = """---
chunk_size: 50
pin: true
---
# Test Document

This is a test document with frontmatter.
"""
        (docs_dir / "test.md").write_text(content)

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        source = SourceConfig(name="docs", path_pattern="*.md", chunk_size=200, chunk_overlap=20)
        stage = PrepareStage(storage=storage, sources=[source], base_path=docs_dir)

        batch_id = stage.prepare()
        docs = storage.load_documents(batch_id)
        assert len(docs) == 1
        assert docs[0].frontmatter is not None
        assert docs[0].frontmatter.pin is True

    def test_prepare_no_documents(self, tmp_path):
        """PrepareStage should handle empty source directory."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.models import SourceConfig
        from redis_agent_kit.pipelines.prepare_stage import PrepareStage

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        source = SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
        stage = PrepareStage(storage=storage, sources=[source], base_path=docs_dir)

        batch_id = stage.prepare()
        manifest = storage.load_batch_manifest(batch_id)
        assert manifest.documents_prepared == 0
        assert manifest.chunks_created == 0

    def test_prepare_skips_directories(self, tmp_path):
        """PrepareStage should skip directories matching the pattern."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.models import SourceConfig
        from redis_agent_kit.pipelines.prepare_stage import PrepareStage

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        # Create a directory that matches the pattern
        (docs_dir / "subdir.md").mkdir()
        # Create a real file
        (docs_dir / "real.md").write_text("# Real\n\nContent.")

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        source = SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
        stage = PrepareStage(storage=storage, sources=[source], base_path=docs_dir)

        batch_id = stage.prepare()
        manifest = storage.load_batch_manifest(batch_id)
        # Should only process the file, not the directory
        assert manifest.documents_prepared == 1


class TestPrepareStageMultipleSources:
    """Tests for PrepareStage with multiple sources."""

    def test_prepare_multiple_sources(self, tmp_path):
        """PrepareStage should handle multiple source configurations."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.models import SourceConfig
        from redis_agent_kit.pipelines.prepare_stage import PrepareStage

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "readme.md").write_text("# README\n\nReadme content.")
        (docs_dir / "guide.txt").write_text("Guide content.")

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        sources = [
            SourceConfig(name="markdown", path_pattern="*.md", chunk_size=100, chunk_overlap=10),
            SourceConfig(name="text", path_pattern="*.txt", chunk_size=50, chunk_overlap=5),
        ]
        stage = PrepareStage(storage=storage, sources=sources, base_path=docs_dir)

        batch_id = stage.prepare()
        manifest = storage.load_batch_manifest(batch_id)
        assert manifest.documents_prepared == 2


class TestPrepareStageCustomDocs:
    """Tests for PrepareStage with custom documents."""

    def test_prepare_includes_custom_docs(self, tmp_path):
        """PrepareStage should include custom documents from custom_docs_dir."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.models import SourceConfig
        from redis_agent_kit.pipelines.prepare_stage import PrepareStage

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        custom_dir = tmp_path / "custom"
        custom_dir.mkdir()
        (custom_dir / "custom.md").write_text("# Custom\n\nCustom content.")

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts", custom_docs_dir=custom_dir)
        source = SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
        stage = PrepareStage(storage=storage, sources=[source], base_path=docs_dir)

        batch_id = stage.prepare()
        manifest = storage.load_batch_manifest(batch_id)
        # Should include the custom doc
        assert manifest.documents_prepared >= 1
