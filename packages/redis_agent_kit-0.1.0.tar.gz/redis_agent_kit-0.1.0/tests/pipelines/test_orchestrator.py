"""TDD tests for PipelineOrchestrator - written BEFORE implementation."""

from unittest.mock import AsyncMock, MagicMock

import pytest


class TestPipelineOrchestratorSync:
    """Tests for PipelineOrchestrator synchronous methods."""

    def test_prepare_runs_prepare_stage(self, tmp_path):
        """Orchestrator prepare() should run PrepareStage."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "test.md").write_text("# Test\n\nContent.")

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )
        orchestrator = PipelineOrchestrator(config=config, base_path=docs_dir)

        batch_id = orchestrator.prepare()

        assert batch_id is not None
        assert (tmp_path / "artifacts" / batch_id).exists()

    def test_ingest_raises_without_vectorizer(self, tmp_path):
        """Orchestrator ingest() should raise if vectorizer not configured."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )
        orchestrator = PipelineOrchestrator(config=config, base_path=tmp_path)

        with pytest.raises(ValueError, match="Vectorizer and vector_store required"):
            orchestrator.ingest("batch-123")

    def test_ingest_runs_ingest_stage(self, tmp_path):
        """Orchestrator ingest() should run IngestStage."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "test.md").write_text("# Test\n\nContent.")

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )

        mock_vectorizer = MagicMock()
        mock_vectorizer.embed.return_value = [0.1] * 768
        mock_vector_store = MagicMock()

        orchestrator = PipelineOrchestrator(
            config=config,
            base_path=docs_dir,
            vectorizer=mock_vectorizer,
            vector_store=mock_vector_store,
        )

        # First prepare
        batch_id = orchestrator.prepare()
        # Then ingest
        manifest = orchestrator.ingest(batch_id)

        assert manifest is not None
        assert manifest.status == "completed"

    def test_run_executes_both_stages(self, tmp_path):
        """Orchestrator run() should execute prepare and ingest."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "test.md").write_text("# Test\n\nContent.")

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )

        mock_vectorizer = MagicMock()
        mock_vectorizer.embed.return_value = [0.1] * 768
        mock_vector_store = MagicMock()

        orchestrator = PipelineOrchestrator(
            config=config,
            base_path=docs_dir,
            vectorizer=mock_vectorizer,
            vector_store=mock_vector_store,
        )

        result = orchestrator.run()

        assert result is not None
        assert result.batch_id is not None
        assert result.ingestion_manifest is not None
        assert result.ingestion_manifest.status == "completed"


class TestPipelineOrchestratorAsync:
    """Tests for PipelineOrchestrator async methods using Docket."""

    @pytest.mark.asyncio
    async def test_submit_prepare_returns_task_id(self, tmp_path):
        """Orchestrator submit_prepare() should return task_id."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )

        mock_docket = MagicMock()
        mock_docket.add = AsyncMock(return_value="task-123")

        orchestrator = PipelineOrchestrator(config=config, base_path=tmp_path, docket=mock_docket)

        task_id = await orchestrator.submit_prepare()

        assert task_id == "task-123"
        mock_docket.add.assert_called_once()

    @pytest.mark.asyncio
    async def test_submit_ingest_returns_task_id(self, tmp_path):
        """Orchestrator submit_ingest() should return task_id."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )

        mock_docket = MagicMock()
        mock_docket.add = AsyncMock(return_value="task-456")

        orchestrator = PipelineOrchestrator(config=config, base_path=tmp_path, docket=mock_docket)

        task_id = await orchestrator.submit_ingest("batch-123")

        assert task_id == "task-456"
        mock_docket.add.assert_called_once()

    @pytest.mark.asyncio
    async def test_submit_full_returns_task_id(self, tmp_path):
        """Orchestrator submit_full() should return task_id."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )

        mock_docket = MagicMock()
        mock_docket.add = AsyncMock(return_value="task-789")

        orchestrator = PipelineOrchestrator(config=config, base_path=tmp_path, docket=mock_docket)

        task_id = await orchestrator.submit_full()

        assert task_id == "task-789"
        mock_docket.add.assert_called_once()

    @pytest.mark.asyncio
    async def test_submit_prepare_raises_without_docket(self, tmp_path):
        """Orchestrator submit_prepare() should raise if docket not configured."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )
        orchestrator = PipelineOrchestrator(config=config, base_path=tmp_path)

        with pytest.raises(ValueError, match="Docket required"):
            await orchestrator.submit_prepare()

    @pytest.mark.asyncio
    async def test_submit_ingest_raises_without_docket(self, tmp_path):
        """Orchestrator submit_ingest() should raise if docket not configured."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )
        orchestrator = PipelineOrchestrator(config=config, base_path=tmp_path)

        with pytest.raises(ValueError, match="Docket required"):
            await orchestrator.submit_ingest("batch-123")

    @pytest.mark.asyncio
    async def test_submit_full_raises_without_docket(self, tmp_path):
        """Orchestrator submit_full() should raise if docket not configured."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )
        orchestrator = PipelineOrchestrator(config=config, base_path=tmp_path)

        with pytest.raises(ValueError, match="Docket required"):
            await orchestrator.submit_full()

    @pytest.mark.asyncio
    async def test_submit_document_returns_task_id(self, tmp_path):
        """Orchestrator submit_document() should return task_id."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )

        mock_docket = MagicMock()
        mock_docket.add = AsyncMock(return_value="task-doc-1")

        orchestrator = PipelineOrchestrator(config=config, base_path=tmp_path, docket=mock_docket)

        task_id = await orchestrator.submit_document("# Test\n\nContent.", "test.md")

        assert task_id == "task-doc-1"
        mock_docket.add.assert_called_once()
        call_args = mock_docket.add.call_args
        assert call_args[0][0] == "pipeline_document"
        assert call_args[1]["content"] == "# Test\n\nContent."
        assert call_args[1]["filename"] == "test.md"

    @pytest.mark.asyncio
    async def test_submit_document_raises_without_docket(self, tmp_path):
        """Orchestrator submit_document() should raise if docket not configured."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig
        from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

        config = PipelineConfig(
            artifacts_dir=tmp_path / "artifacts",
            sources=[
                SourceConfig(name="docs", path_pattern="*.md", chunk_size=100, chunk_overlap=10)
            ],
        )
        orchestrator = PipelineOrchestrator(config=config, base_path=tmp_path)

        with pytest.raises(ValueError, match="Docket required"):
            await orchestrator.submit_document("# Test", "test.md")
