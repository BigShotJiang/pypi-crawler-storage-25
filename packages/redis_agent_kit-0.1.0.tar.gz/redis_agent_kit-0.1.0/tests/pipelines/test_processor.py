"""TDD tests for DocumentProcessor - written BEFORE implementation."""

from redis_agent_kit.pipelines.models import Document, DocumentType, ProcessorConfig


class TestDocumentProcessor:
    """Tests for DocumentProcessor."""

    def test_processor_creation_with_default_config(self):
        """Processor should be creatable with default config."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        processor = DocumentProcessor()
        assert processor.config.chunk_size == 1000
        assert processor.config.chunk_overlap == 200

    def test_processor_creation_with_custom_config(self):
        """Processor should accept custom config."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        config = ProcessorConfig(chunk_size=500, chunk_overlap=100)
        processor = DocumentProcessor(config=config)
        assert processor.config.chunk_size == 500
        assert processor.config.chunk_overlap == 100

    def test_chunk_short_document_returns_single_chunk(self):
        """Short document should return single chunk."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        processor = DocumentProcessor()
        doc = Document(
            title="Short Doc",
            content="This is a short document.",
            source="test",
        )
        chunks = processor.chunk_document(doc)
        assert len(chunks) == 1
        assert chunks[0].content == "This is a short document."
        assert chunks[0].doc_id == doc.doc_id
        assert chunks[0].chunk_index == 0

    def test_chunk_long_document_creates_multiple_chunks(self):
        """Long document should be split into multiple chunks."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        config = ProcessorConfig(chunk_size=100, chunk_overlap=20)
        processor = DocumentProcessor(config=config)
        # Create content longer than chunk_size
        content = "Word " * 100  # 500 chars
        doc = Document(title="Long Doc", content=content, source="test")
        chunks = processor.chunk_document(doc)
        assert len(chunks) > 1
        # All chunks should reference the same doc
        for chunk in chunks:
            assert chunk.doc_id == doc.doc_id

    def test_chunk_ids_are_unique(self):
        """Each chunk should have a unique chunk_id."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        config = ProcessorConfig(chunk_size=100, chunk_overlap=20)
        processor = DocumentProcessor(config=config)
        content = "Word " * 100
        doc = Document(title="Test", content=content, source="test")
        chunks = processor.chunk_document(doc)
        chunk_ids = [c.chunk_id for c in chunks]
        assert len(chunk_ids) == len(set(chunk_ids))

    def test_chunk_indices_are_sequential(self):
        """Chunk indices should be sequential starting from 0."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        config = ProcessorConfig(chunk_size=100, chunk_overlap=20)
        processor = DocumentProcessor(config=config)
        content = "Word " * 100
        doc = Document(title="Test", content=content, source="test")
        chunks = processor.chunk_document(doc)
        indices = [c.chunk_index for c in chunks]
        assert indices == list(range(len(chunks)))

    def test_chunks_have_overlap(self):
        """Consecutive chunks should have overlapping content."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        config = ProcessorConfig(chunk_size=100, chunk_overlap=20)
        processor = DocumentProcessor(config=config)
        content = "Word " * 100
        doc = Document(title="Test", content=content, source="test")
        chunks = processor.chunk_document(doc)
        if len(chunks) > 1:
            # Check that end of chunk 0 overlaps with start of chunk 1
            chunk0_end = chunks[0].content[-20:]
            chunk1_start = chunks[1].content[:20]
            # There should be some overlap
            assert any(c in chunk1_start for c in chunk0_end.split())

    def test_strip_yaml_front_matter(self):
        """Processor should strip YAML front matter when configured."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        processor = DocumentProcessor()
        content = """---
title: My Document
author: John
---

This is the actual content."""
        doc = Document(title="Test", content=content, source="test")
        chunks = processor.chunk_document(doc)
        assert "---" not in chunks[0].content
        assert "title: My Document" not in chunks[0].content
        assert "This is the actual content." in chunks[0].content

    def test_preserve_front_matter_when_disabled(self):
        """Processor should preserve front matter when strip_front_matter=False."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        config = ProcessorConfig(strip_front_matter=False)
        processor = DocumentProcessor(config=config)
        content = """---
title: My Document
---

Content here."""
        doc = Document(title="Test", content=content, source="test")
        chunks = processor.chunk_document(doc)
        assert "---" in chunks[0].content

    def test_chunks_inherit_document_metadata(self):
        """Chunks should inherit metadata from parent document."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        processor = DocumentProcessor()
        doc = Document(
            title="Test",
            content="Short content",
            source="https://example.com",
            doc_type=DocumentType.DOCUMENTATION,
            metadata={"author": "John"},
        )
        chunks = processor.chunk_document(doc)
        assert chunks[0].metadata["source"] == "https://example.com"
        assert chunks[0].metadata["title"] == "Test"
        assert chunks[0].metadata["doc_type"] == "documentation"

    def test_max_chunks_per_doc_limit(self):
        """Processor should respect max_chunks_per_doc limit."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        config = ProcessorConfig(chunk_size=10, chunk_overlap=2, max_chunks_per_doc=3)
        processor = DocumentProcessor(config=config)
        content = "Word " * 100  # Would create many chunks
        doc = Document(title="Test", content=content, source="test")
        chunks = processor.chunk_document(doc)
        assert len(chunks) <= 3

    def test_empty_chunk_skipped(self):
        """Processor should skip empty chunks."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        config = ProcessorConfig(chunk_size=100, chunk_overlap=10)
        processor = DocumentProcessor(config=config)
        # Content with lots of whitespace that might create empty chunks
        content = "Hello    \n\n\n    World"
        doc = Document(title="Test", content=content, source="test")
        chunks = processor.chunk_document(doc)
        # All chunks should have non-empty content
        for chunk in chunks:
            assert chunk.content.strip() != ""

    def test_chunk_overlap_forward_progress(self):
        """Processor should ensure forward progress even with large overlap."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        # Overlap larger than chunk size would cause issues without forward progress check
        config = ProcessorConfig(chunk_size=20, chunk_overlap=15, min_chunk_size=5)
        processor = DocumentProcessor(config=config)
        content = "This is a test document with enough content to create multiple chunks."
        doc = Document(title="Test", content=content, source="test")
        chunks = processor.chunk_document(doc)
        # Should create chunks without infinite loop
        assert len(chunks) >= 1

    def test_chunk_document_with_extreme_overlap(self):
        """Chunking should handle extreme overlap that could cause infinite loop."""
        from redis_agent_kit.pipelines.processor import DocumentProcessor

        # Overlap very close to chunk size - tests forward progress check
        config = ProcessorConfig(chunk_size=10, chunk_overlap=9, min_chunk_size=5)
        processor = DocumentProcessor(config=config)
        content = "AAAAAAAAAA BBBBBBBBBB CCCCCCCCCC"  # 33 chars
        doc = Document(title="Test", content=content, source="test")
        chunks = processor.chunk_document(doc)
        # Should still create chunks without infinite loop
        assert len(chunks) >= 1
        # Verify all content is covered
        all_content = " ".join(c.content for c in chunks)
        assert "AAAAAAAAAA" in all_content or "AAAAAAAAAA" in chunks[0].content
