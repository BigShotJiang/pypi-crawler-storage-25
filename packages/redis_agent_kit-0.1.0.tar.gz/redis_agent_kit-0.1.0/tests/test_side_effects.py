"""Tests for side_effect decorator."""

from datetime import timedelta

import pytest

from redis_agent_kit.side_effects import (
    DEFAULT_KEY_POLICY,
    FUNCTION_NAME,
    FUNCTION_SOURCE,
    INPUTS,
    SideEffectSettings,
    clear_side_effects,
    side_effect,
)


class TestSideEffectDecorator:
    """Tests for the @side_effect decorator."""

    @pytest.mark.asyncio
    async def test_basic_execution(self, redis_client):
        """Test that decorated function executes normally."""
        call_count = 0

        @side_effect(redis_client=redis_client)
        async def my_func(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x * 2

        result = await my_func(5)
        assert result == 10
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_idempotent_execution(self, redis_client):
        """Test that function only executes once per unique key."""
        call_count = 0

        @side_effect(redis_client=redis_client)
        async def my_func(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x * 2

        # First call executes
        await my_func(5)
        assert call_count == 1

        # Second call with same args is skipped
        await my_func(5)
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_different_args_execute_separately(self, redis_client):
        """Test that different args create different cache keys."""
        call_count = 0

        @side_effect(redis_client=redis_client)
        async def my_func(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x * 2

        await my_func(5)
        assert call_count == 1

        await my_func(10)  # Different args
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_store_result(self, redis_client):
        """Test that store_result=True caches and returns the result."""
        call_count = 0

        @side_effect(store_result=True, redis_client=redis_client)
        async def my_func(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x * 2

        result1 = await my_func(5)
        assert result1 == 10
        assert call_count == 1

        # Second call returns cached result
        result2 = await my_func(5)
        assert result2 == 10
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_without_store_result_returns_none(self, redis_client):
        """Test that without store_result, second call returns None."""
        call_count = 0

        @side_effect(redis_client=redis_client)
        async def my_func(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x * 2

        result1 = await my_func(5)
        assert result1 == 10

        # Second call returns None (no cached result)
        result2 = await my_func(5)
        assert result2 is None

    @pytest.mark.asyncio
    async def test_manual_key(self, redis_client):
        """Test using a manual key."""
        call_count = 0

        @side_effect(key="my-custom-key", redis_client=redis_client)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await my_func()
        assert call_count == 1

        await my_func()
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_callable_key(self, redis_client):
        """Test using a callable for key generation."""
        call_count = 0

        def make_key(func, user_id: str) -> str:
            return f"user:{user_id}"

        @side_effect(key=make_key, redis_client=redis_client)
        async def my_func(user_id: str) -> str:
            nonlocal call_count
            call_count += 1
            return f"processed {user_id}"

        await my_func("alice")
        assert call_count == 1

        await my_func("alice")
        assert call_count == 1

        await my_func("bob")
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_exception_not_marked_complete(self, redis_client):
        """Test that exceptions don't mark the side effect as complete."""
        call_count = 0

        @side_effect(redis_client=redis_client)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            raise ValueError("oops")

        with pytest.raises(ValueError):
            await my_func()
        assert call_count == 1

        # Should retry since it wasn't marked complete
        with pytest.raises(ValueError):
            await my_func()
        assert call_count == 2


class TestKeyPolicies:
    """Tests for key generation policies."""

    @pytest.mark.asyncio
    async def test_function_name_only(self, redis_client):
        """Test key policy with only function name."""
        call_count = 0

        @side_effect(key_policy=FUNCTION_NAME, redis_client=redis_client)
        async def my_func(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x

        await my_func(1)
        assert call_count == 1

        # Same function name, different args - still skipped
        await my_func(999)
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_inputs_only(self, redis_client):
        """Test key policy with only inputs."""
        call_count = 0

        @side_effect(key_policy=INPUTS, redis_client=redis_client)
        async def my_func(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x

        await my_func(1)
        assert call_count == 1

        await my_func(1)
        assert call_count == 1

        await my_func(2)
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_combined_policies(self, redis_client):
        """Test combining multiple key policies."""
        call_count = 0

        @side_effect(key_policy=FUNCTION_NAME | INPUTS, redis_client=redis_client)
        async def my_func(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x

        await my_func(1)
        assert call_count == 1

        await my_func(1)
        assert call_count == 1

        await my_func(2)
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_default_policy_includes_all(self, redis_client):
        """Test that default policy includes source, name, and inputs."""
        assert DEFAULT_KEY_POLICY == (FUNCTION_SOURCE | FUNCTION_NAME | INPUTS)


class TestClearSideEffects:
    """Tests for clearing side effects."""

    @pytest.mark.asyncio
    async def test_clear_all(self, redis_client):
        """Test clearing all side effects."""
        call_count = 0

        @side_effect(redis_client=redis_client)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await my_func()
        assert call_count == 1

        await my_func()
        assert call_count == 1

        # Clear all
        deleted = await clear_side_effects(redis_client, "all")
        assert deleted >= 1

        # Now it should execute again
        await my_func()
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_clear_by_function_name(self, redis_client):
        """Test clearing by function name pattern."""
        call_count_a = 0
        call_count_b = 0

        @side_effect(redis_client=redis_client)
        async def func_a() -> str:
            nonlocal call_count_a
            call_count_a += 1
            return "a"

        @side_effect(redis_client=redis_client)
        async def func_b() -> str:
            nonlocal call_count_b
            call_count_b += 1
            return "b"

        await func_a()
        await func_b()
        assert call_count_a == 1
        assert call_count_b == 1

        # Clear only func_a
        await clear_side_effects(redis_client, "func_a")

        await func_a()
        await func_b()
        assert call_count_a == 2  # Re-executed
        assert call_count_b == 1  # Still cached


class TestSideEffectSettings:
    """Tests for SideEffectSettings."""

    def test_default_settings(self):
        """Test default settings values."""
        settings = SideEffectSettings()
        assert settings.default_ttl_hours == 1.0
        assert settings.clear_pattern is None
        assert settings.key_prefix == "rak:side_effect"

    def test_custom_settings(self):
        """Test custom settings."""
        settings = SideEffectSettings(
            default_ttl_hours=2.0,
            key_prefix="custom:prefix",
        )
        assert settings.default_ttl_hours == 2.0
        assert settings.key_prefix == "custom:prefix"


class TestDecoratorSyntax:
    """Tests for decorator syntax variations."""

    @pytest.mark.asyncio
    async def test_decorator_with_parens(self, redis_client):
        """Test @side_effect() with parentheses."""
        call_count = 0

        @side_effect(redis_client=redis_client)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await my_func()
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_key_and_key_policy_conflict(self, redis_client):
        """Test that specifying both key and key_policy raises error."""
        with pytest.raises(ValueError, match="Cannot specify both"):

            @side_effect(key="manual", key_policy=FUNCTION_NAME, redis_client=redis_client)
            async def my_func():
                pass

    @pytest.mark.asyncio
    async def test_no_redis_client_raises(self):
        """Test that missing redis_client raises error."""

        @side_effect()
        async def my_func():
            return "done"

        with pytest.raises(ValueError, match="No redis_client"):
            await my_func()


class TestTTLBehavior:
    """Tests for TTL handling."""

    @pytest.mark.asyncio
    async def test_explicit_ttl(self, redis_client):
        """Test setting an explicit TTL."""
        call_count = 0

        @side_effect(ttl=timedelta(hours=2), redis_client=redis_client)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await my_func()
        assert call_count == 1

        # Verify key was set with TTL
        keys = [k async for k in redis_client.scan_iter("rak:side_effect:*")]
        assert len(keys) >= 1

    @pytest.mark.asyncio
    async def test_no_ttl_when_none(self, redis_client):
        """Test that ttl=None means no expiration."""
        settings = SideEffectSettings(default_ttl_hours=None)
        call_count = 0

        @side_effect(redis_client=redis_client, settings=settings)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await my_func()
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_zero_ttl_means_no_expiration(self, redis_client):
        """Test that ttl=timedelta(0) means no expiration."""
        call_count = 0

        @side_effect(ttl=timedelta(0), redis_client=redis_client)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await my_func()
        assert call_count == 1


class TestEdgeCases:
    """Tests for edge cases and error handling."""

    @pytest.mark.asyncio
    async def test_empty_key_policy_raises(self, redis_client):
        """Test that empty key policy raises error."""
        call_count = 0

        @side_effect(key_policy=0, redis_client=redis_client)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        with pytest.raises(ValueError, match="At least one key policy"):
            await my_func()

    @pytest.mark.asyncio
    async def test_unserializable_result(self, redis_client):
        """Test handling of unserializable result with store_result."""
        call_count = 0

        @side_effect(store_result=True, redis_client=redis_client)
        async def my_func():
            nonlocal call_count
            call_count += 1
            # Return a lambda which is not JSON serializable
            return lambda x: x

        result = await my_func()
        assert callable(result)
        assert call_count == 1

        # Second call - function is marked complete but result can't be retrieved
        result2 = await my_func()
        assert result2 is None  # No stored result
        assert call_count == 1  # Not re-executed

    @pytest.mark.asyncio
    async def test_corrupted_stored_result(self, redis_client):
        """Test handling of corrupted stored result."""
        call_count = 0

        @side_effect(store_result=True, key="corrupt-test", redis_client=redis_client)
        async def my_func() -> dict:
            nonlocal call_count
            call_count += 1
            return {"data": "value"}

        await my_func()
        assert call_count == 1

        # Corrupt the stored result
        await redis_client.set("rak:side_effect:result:corrupt-test", "not-valid-json{")

        # Second call should handle corruption gracefully
        result = await my_func()
        assert result is None  # Could not deserialize
        assert call_count == 1  # Not re-executed

    @pytest.mark.asyncio
    async def test_clear_with_colon_pattern(self, redis_client):
        """Test clearing with a pattern containing colon."""
        call_count = 0

        @side_effect(key="prefix:suffix", redis_client=redis_client)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await my_func()
        assert call_count == 1

        # Clear with colon pattern
        deleted = await clear_side_effects(redis_client, "prefix:suffix")
        assert deleted >= 1

        await my_func()
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_clear_no_matching_keys(self, redis_client):
        """Test clearing when no keys match."""
        deleted = await clear_side_effects(redis_client, "nonexistent-pattern-xyz")
        assert deleted == 0


class TestCheckAndClear:
    """Tests for the _check_and_clear functionality via settings."""

    @pytest.mark.asyncio
    async def test_clear_pattern_all(self, redis_client):
        """Test that clear_pattern='all' clears on execution."""
        call_count = 0
        settings = SideEffectSettings(clear_pattern="all")

        @side_effect(redis_client=redis_client, settings=settings)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await my_func()
        assert call_count == 1

        # With clear_pattern=all, execution clears the cache first
        await my_func()
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_clear_pattern_by_function_name(self, redis_client):
        """Test clear_pattern matching function name."""
        call_count = 0
        settings = SideEffectSettings(clear_pattern="target_func")

        @side_effect(redis_client=redis_client, settings=settings)
        async def target_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await target_func()
        assert call_count == 1

        await target_func()
        assert call_count == 2  # Re-executed due to clear

    @pytest.mark.asyncio
    async def test_clear_pattern_with_prefix(self, redis_client):
        """Test clear_pattern matching function name prefix."""
        call_count = 0
        settings = SideEffectSettings(clear_pattern="prefixed_func:")

        @side_effect(redis_client=redis_client, settings=settings)
        async def prefixed_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await prefixed_func()
        assert call_count == 1

        await prefixed_func()
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_clear_pattern_wildcard(self, redis_client):
        """Test clear_pattern with wildcard."""
        call_count = 0
        settings = SideEffectSettings(clear_pattern="wild*")

        @side_effect(key="wildcard_key", redis_client=redis_client, settings=settings)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await my_func()
        assert call_count == 1

        await my_func()
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_clear_pattern_with_store_result(self, redis_client):
        """Test that clear_pattern also clears result keys."""
        call_count = 0
        settings = SideEffectSettings(clear_pattern="all")

        @side_effect(store_result=True, redis_client=redis_client, settings=settings)
        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await my_func()
        assert call_count == 1

        await my_func()
        assert call_count == 2


class TestSourceUnavailable:
    """Tests for functions where source code cannot be retrieved."""

    @pytest.mark.asyncio
    async def test_builtin_function_source_unavailable(self, redis_client):
        """Test that built-in functions handle source unavailable gracefully."""
        # Create a wrapper around a built-in that we can decorate

        call_count = 0

        # Use exec to create a function whose source cannot be retrieved
        local_ns: dict = {}
        exec(
            """
async def dynamic_func():
    return "dynamic"
""",
            {},
            local_ns,
        )
        original_func = local_ns["dynamic_func"]

        @side_effect(redis_client=redis_client)
        async def wrapper():
            nonlocal call_count
            call_count += 1
            # Call a dynamic function - source retrieval will work for wrapper
            # but we're testing the decorator's ability to handle the case
            return await original_func()

        # For true source unavailable, we need to test with a dynamically created func
        # wrapped directly. Let's monkeypatch inspect.getsource to raise OSError.
        import inspect

        original_getsource = inspect.getsource

        def raise_os_error(obj):
            raise OSError("could not get source code")

        inspect.getsource = raise_os_error

        try:

            @side_effect(redis_client=redis_client)
            async def test_func() -> str:
                nonlocal call_count
                call_count += 1
                return "done"

            result = await test_func()
            assert result == "done"
            assert call_count == 1

            # Second call should still be idempotent
            await test_func()
            assert call_count == 1
        finally:
            inspect.getsource = original_getsource


class TestStoreResultWithoutTTL:
    """Tests for store_result behavior without TTL."""

    @pytest.mark.asyncio
    async def test_store_result_no_ttl(self, redis_client):
        """Test store_result works without TTL (no expiration)."""
        settings = SideEffectSettings(default_ttl_hours=None)
        call_count = 0

        @side_effect(store_result=True, redis_client=redis_client, settings=settings)
        async def my_func() -> dict:
            nonlocal call_count
            call_count += 1
            return {"key": "value"}

        result1 = await my_func()
        assert result1 == {"key": "value"}
        assert call_count == 1

        # Verify it's stored without TTL
        result2 = await my_func()
        assert result2 == {"key": "value"}
        assert call_count == 1


class TestDecoratorWithoutParens:
    """Tests for @side_effect without parentheses."""

    @pytest.mark.asyncio
    async def test_decorator_without_parens(self, redis_client):
        """Test side_effect(func) direct call pattern (line 152)."""
        call_count = 0

        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        # Apply decorator directly (simulates @side_effect without parens but with a client)
        # We pass redis_client via functools partial or just call manually
        from redis_agent_kit.side_effects import _SideEffectDecorator

        # Direct instantiation to test the decorator path
        decorated = _SideEffectDecorator(redis_client=redis_client)(my_func)

        result = await decorated()
        assert result == "done"
        assert call_count == 1

        # Test idempotency
        await decorated()
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_side_effect_direct_call_with_func(self, redis_client):
        """Test side_effect(func, redis_client=...) direct call."""
        call_count = 0

        async def my_func() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        # This hits line 152 - func is passed as positional arg
        decorated = side_effect(my_func, redis_client=redis_client)

        result = await decorated()
        assert result == "done"
        assert call_count == 1

        # Test idempotency
        await decorated()
        assert call_count == 1
