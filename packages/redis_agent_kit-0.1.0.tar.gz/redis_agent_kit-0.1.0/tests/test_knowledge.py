"""Tests for KnowledgeStore."""

from unittest.mock import AsyncMock, patch

import pytest


class TestKnowledgeStore:
    """Tests for KnowledgeStore."""

    @pytest.mark.asyncio
    async def test_knowledge_store_creation(self, redis_client):
        """KnowledgeStore should be created with a Redis client."""
        from redis_agent_kit.knowledge import KnowledgeStore

        ks = KnowledgeStore(redis_client)
        assert ks._vector_store is not None
        assert ks._vectorizer is not None

    @pytest.mark.asyncio
    async def test_knowledge_store_from_url(self, redis_url):
        """KnowledgeStore should be created from a URL."""
        from redis_agent_kit.knowledge import KnowledgeStore

        ks = KnowledgeStore.from_url(redis_url)
        assert ks._vector_store is not None

    @pytest.mark.asyncio
    async def test_knowledge_store_search(self, redis_client):
        """KnowledgeStore search should embed query and search vector store."""
        from redis_agent_kit.knowledge import KnowledgeStore
        from redis_agent_kit.pipelines.models import SearchResult

        ks = KnowledgeStore(redis_client)

        # Mock the vectorizer and vector store
        mock_embedding = [0.1, 0.2, 0.3]
        mock_result = SearchResult(
            chunk_id="c1",
            doc_id="d1",
            content="Test content",
            score=0.95,
            metadata={},
        )

        with patch.object(ks._vectorizer, "embed", new_callable=AsyncMock) as mock_embed:
            mock_embed.return_value = mock_embedding
            with patch.object(ks._vector_store, "search", new_callable=AsyncMock) as mock_search:
                mock_search.return_value = [mock_result]

                results = await ks.search("test query", limit=5)

        assert len(results) == 1
        assert results[0].content == "Test content"
        mock_embed.assert_called_once_with("test query")
        # Check that search was called with the embedding
        mock_search.assert_called_once()
        call_args = mock_search.call_args
        assert call_args.args[0] == mock_embedding
        assert call_args.kwargs["limit"] == 5

    @pytest.mark.asyncio
    async def test_knowledge_store_ingest(self, redis_client):
        """KnowledgeStore ingest should embed and store content."""
        from redis_agent_kit.knowledge import KnowledgeStore

        ks = KnowledgeStore(redis_client)

        mock_embedding = [0.1, 0.2, 0.3]

        with patch.object(ks._vectorizer, "embed", new_callable=AsyncMock) as mock_embed:
            mock_embed.return_value = mock_embedding
            with patch.object(
                ks._vector_store, "store_chunk", new_callable=AsyncMock
            ) as mock_store:
                chunk_id = await ks.ingest(
                    content="Test content",
                    doc_id="doc1",
                    metadata={"title": "Test"},
                )

        assert chunk_id is not None
        mock_embed.assert_called_once_with("Test content")
        mock_store.assert_called_once()

    @pytest.mark.asyncio
    async def test_knowledge_store_ingest_many(self, redis_client):
        """KnowledgeStore ingest_many should ingest multiple documents."""
        from redis_agent_kit.knowledge import KnowledgeStore

        ks = KnowledgeStore(redis_client)

        # Mock the ingest method
        with patch.object(ks, "ingest", new_callable=AsyncMock) as mock_ingest:
            mock_ingest.side_effect = ["doc1", "doc2"]

            doc_ids = await ks.ingest_many(
                [
                    ("Content 1", "Title 1", {"key": "val1"}),
                    ("Content 2", "Title 2", {"key": "val2"}),
                ]
            )

        assert len(doc_ids) == 2
        assert doc_ids == ["doc1", "doc2"]
        assert mock_ingest.call_count == 2

    @pytest.mark.asyncio
    async def test_knowledge_store_count(self, redis_client):
        """KnowledgeStore count should return chunk count."""
        from redis_agent_kit.knowledge import KnowledgeStore

        ks = KnowledgeStore(redis_client)

        with patch.object(ks._vector_store, "count", new_callable=AsyncMock) as mock_count:
            mock_count.return_value = 42

            count = await ks.count()

        assert count == 42

    @pytest.mark.asyncio
    async def test_knowledge_store_delete(self, redis_client):
        """KnowledgeStore delete should remove document chunks."""
        from redis_agent_kit.knowledge import KnowledgeStore

        ks = KnowledgeStore(redis_client)

        with patch.object(
            ks._vector_store, "delete_by_doc_id", new_callable=AsyncMock
        ) as mock_delete:
            mock_delete.return_value = 3

            deleted = await ks.delete("doc1")

        assert deleted == 3
        mock_delete.assert_called_once_with("doc1")

    @pytest.mark.asyncio
    async def test_knowledge_store_clear(self, redis_client):
        """KnowledgeStore clear should remove all chunks."""
        from redis_agent_kit.knowledge import KnowledgeStore

        ks = KnowledgeStore(redis_client)

        with patch.object(ks._vector_store, "clear", new_callable=AsyncMock) as mock_clear:
            await ks.clear()

        mock_clear.assert_called_once()
