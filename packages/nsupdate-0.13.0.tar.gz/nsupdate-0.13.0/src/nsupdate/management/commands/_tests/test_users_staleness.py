import datetime
import pytest
from django.utils import timezone
from django.contrib.auth import get_user_model
from nsupdate.management.commands.users import check_staleness, DAY, T_age, NEVER

@pytest.mark.django_db
def test_check_staleness():
    User = get_user_model()
    t_now = timezone.now()

    # 1. New user (no last_login, recent date_joined) -> NOT stale
    u1 = User.objects.create_user(username="u1", email="u1@example.com")
    assert u1.last_login is None
    log_msg = check_staleness(u1)
    assert "kept, was used recently" in log_msg
    assert User.objects.filter(username="u1").exists()

    # 2. Old user (no last_login, old date_joined, no hosts) -> stale, deleted
    u2 = User.objects.create_user(username="u2", email="u2@example.com")
    u2.date_joined = t_now - datetime.timedelta(seconds=T_age + DAY)
    u2.save()
    log_msg = check_staleness(u2)
    assert "deleted user" in log_msg
    assert not User.objects.filter(username="u2").exists()

    # 3. Old user (old last_login, old date_joined, no hosts) -> stale, deleted
    u3 = User.objects.create_user(username="u3", email="u3@example.com")
    u3.date_joined = t_now - datetime.timedelta(seconds=T_age + DAY)
    u3.last_login = t_now - datetime.timedelta(seconds=T_age + DAY)
    u3.save()
    log_msg = check_staleness(u3)
    assert "deleted user" in log_msg
    assert not User.objects.filter(username="u3").exists()

    # 4. Active user (recent last_login, old date_joined) -> NOT stale
    u4 = User.objects.create_user(username="u4", email="u4@example.com")
    u4.date_joined = t_now - datetime.timedelta(seconds=T_age + DAY)
    u4.last_login = t_now - datetime.timedelta(seconds=DAY)
    u4.save()
    log_msg = check_staleness(u4)
    assert "kept, was used recently" in log_msg
    assert User.objects.filter(username="u4").exists()
