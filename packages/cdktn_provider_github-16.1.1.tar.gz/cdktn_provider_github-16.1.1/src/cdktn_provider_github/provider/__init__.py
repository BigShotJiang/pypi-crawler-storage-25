r'''
# `provider`

Refer to the Terraform Registry for docs: [`github`](https://registry.terraform.io/providers/integrations/github/6.12.1/docs).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class GithubProvider(
    _cdktn_78ede62e.TerraformProvider,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.provider.GithubProvider",
):
    '''Represents a {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs github}.'''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        alias: typing.Optional[builtins.str] = None,
        app_auth: typing.Optional[typing.Union["GithubProviderAppAuth", typing.Dict[builtins.str, typing.Any]]] = None,
        base_url: typing.Optional[builtins.str] = None,
        insecure: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        max_per_page: typing.Optional[jsii.Number] = None,
        max_retries: typing.Optional[jsii.Number] = None,
        organization: typing.Optional[builtins.str] = None,
        owner: typing.Optional[builtins.str] = None,
        parallel_requests: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        read_delay_ms: typing.Optional[jsii.Number] = None,
        retryable_errors: typing.Optional[typing.Sequence[jsii.Number]] = None,
        retry_delay_ms: typing.Optional[jsii.Number] = None,
        token: typing.Optional[builtins.str] = None,
        write_delay_ms: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs github} Resource.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param alias: Alias name. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#alias GithubProvider#alias}
        :param app_auth: app_auth block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#app_auth GithubProvider#app_auth}
        :param base_url: The GitHub Base API URL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#base_url GithubProvider#base_url}
        :param insecure: Enable ``insecure`` mode for testing purposes. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#insecure GithubProvider#insecure}
        :param max_per_page: Number of items per page for paginationDefaults to 100. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#max_per_page GithubProvider#max_per_page}
        :param max_retries: Number of times to retry a request after receiving an error status codeDefaults to 3. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#max_retries GithubProvider#max_retries}
        :param organization: The GitHub organization name to manage. Use this field instead of ``owner`` when managing organization accounts. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#organization GithubProvider#organization}
        :param owner: The GitHub owner name to manage. Use this field instead of ``organization`` when managing individual accounts. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#owner GithubProvider#owner}
        :param parallel_requests: Allow the provider to make parallel API calls to GitHub. You may want to set it to true when you have a private Github Enterprise without strict rate limits. While it is possible to enable this setting on github.com, github.com's best practices recommend using serialization to avoid hitting abuse rate limitsDefaults to false if not set Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#parallel_requests GithubProvider#parallel_requests}
        :param read_delay_ms: Amount of time in milliseconds to sleep in between non-write requests to GitHub API. Defaults to 0ms if not set. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#read_delay_ms GithubProvider#read_delay_ms}
        :param retryable_errors: Allow the provider to retry after receiving an error status code, the max_retries should be set for this to workDefaults to [500, 502, 503, 504]. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#retryable_errors GithubProvider#retryable_errors}
        :param retry_delay_ms: Amount of time in milliseconds to sleep in between requests to GitHub API after an error response. Defaults to 1000ms or 1s if not set, the max_retries must be set to greater than zero. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#retry_delay_ms GithubProvider#retry_delay_ms}
        :param token: The OAuth token used to connect to GitHub. Anonymous mode is enabled if both ``token`` and ``app_auth`` are not set. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#token GithubProvider#token}
        :param write_delay_ms: Amount of time in milliseconds to sleep in between writes to GitHub API. Defaults to 1000ms or 1s if not set. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#write_delay_ms GithubProvider#write_delay_ms}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__679aaee2ae6be0ed6e342d3a1783810b3b1b8398ccd140d053e209b8d4f54e66)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        config = GithubProviderConfig(
            alias=alias,
            app_auth=app_auth,
            base_url=base_url,
            insecure=insecure,
            max_per_page=max_per_page,
            max_retries=max_retries,
            organization=organization,
            owner=owner,
            parallel_requests=parallel_requests,
            read_delay_ms=read_delay_ms,
            retryable_errors=retryable_errors,
            retry_delay_ms=retry_delay_ms,
            token=token,
            write_delay_ms=write_delay_ms,
        )

        jsii.create(self.__class__, self, [scope, id, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a GithubProvider resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the GithubProvider to import.
        :param import_from_id: The id of the existing GithubProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the GithubProvider to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__75cb149a2e081e43726f1ee136e46bbebe93de34c39d5f1072e59c899d14e44a)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="resetAlias")
    def reset_alias(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAlias", []))

    @jsii.member(jsii_name="resetAppAuth")
    def reset_app_auth(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAppAuth", []))

    @jsii.member(jsii_name="resetBaseUrl")
    def reset_base_url(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBaseUrl", []))

    @jsii.member(jsii_name="resetInsecure")
    def reset_insecure(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetInsecure", []))

    @jsii.member(jsii_name="resetMaxPerPage")
    def reset_max_per_page(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxPerPage", []))

    @jsii.member(jsii_name="resetMaxRetries")
    def reset_max_retries(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxRetries", []))

    @jsii.member(jsii_name="resetOrganization")
    def reset_organization(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOrganization", []))

    @jsii.member(jsii_name="resetOwner")
    def reset_owner(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOwner", []))

    @jsii.member(jsii_name="resetParallelRequests")
    def reset_parallel_requests(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetParallelRequests", []))

    @jsii.member(jsii_name="resetReadDelayMs")
    def reset_read_delay_ms(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReadDelayMs", []))

    @jsii.member(jsii_name="resetRetryableErrors")
    def reset_retryable_errors(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRetryableErrors", []))

    @jsii.member(jsii_name="resetRetryDelayMs")
    def reset_retry_delay_ms(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRetryDelayMs", []))

    @jsii.member(jsii_name="resetToken")
    def reset_token(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetToken", []))

    @jsii.member(jsii_name="resetWriteDelayMs")
    def reset_write_delay_ms(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWriteDelayMs", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="aliasInput")
    def alias_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "aliasInput"))

    @builtins.property
    @jsii.member(jsii_name="appAuthInput")
    def app_auth_input(self) -> typing.Optional["GithubProviderAppAuth"]:
        return typing.cast(typing.Optional["GithubProviderAppAuth"], jsii.get(self, "appAuthInput"))

    @builtins.property
    @jsii.member(jsii_name="baseUrlInput")
    def base_url_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "baseUrlInput"))

    @builtins.property
    @jsii.member(jsii_name="insecureInput")
    def insecure_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "insecureInput"))

    @builtins.property
    @jsii.member(jsii_name="maxPerPageInput")
    def max_per_page_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxPerPageInput"))

    @builtins.property
    @jsii.member(jsii_name="maxRetriesInput")
    def max_retries_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxRetriesInput"))

    @builtins.property
    @jsii.member(jsii_name="organizationInput")
    def organization_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "organizationInput"))

    @builtins.property
    @jsii.member(jsii_name="ownerInput")
    def owner_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "ownerInput"))

    @builtins.property
    @jsii.member(jsii_name="parallelRequestsInput")
    def parallel_requests_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "parallelRequestsInput"))

    @builtins.property
    @jsii.member(jsii_name="readDelayMsInput")
    def read_delay_ms_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "readDelayMsInput"))

    @builtins.property
    @jsii.member(jsii_name="retryableErrorsInput")
    def retryable_errors_input(self) -> typing.Optional[typing.List[jsii.Number]]:
        return typing.cast(typing.Optional[typing.List[jsii.Number]], jsii.get(self, "retryableErrorsInput"))

    @builtins.property
    @jsii.member(jsii_name="retryDelayMsInput")
    def retry_delay_ms_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "retryDelayMsInput"))

    @builtins.property
    @jsii.member(jsii_name="tokenInput")
    def token_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tokenInput"))

    @builtins.property
    @jsii.member(jsii_name="writeDelayMsInput")
    def write_delay_ms_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "writeDelayMsInput"))

    @builtins.property
    @jsii.member(jsii_name="alias")
    def alias(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "alias"))

    @alias.setter
    def alias(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d8b2c84c1994bc1070e154acfd0143ec245c4c614daa889830a717c30427b1b5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "alias", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="appAuth")
    def app_auth(self) -> typing.Optional["GithubProviderAppAuth"]:
        return typing.cast(typing.Optional["GithubProviderAppAuth"], jsii.get(self, "appAuth"))

    @app_auth.setter
    def app_auth(self, value: typing.Optional["GithubProviderAppAuth"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b999efcc694f3743dd926f00f78252bdece878efcca1e6658d3e17dc708ef867)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "appAuth", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="baseUrl")
    def base_url(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "baseUrl"))

    @base_url.setter
    def base_url(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__73482d80a1337ca7bd5993e75eb04d40d4d0f9506ae9a58e8e4b3b9c3786ac39)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "baseUrl", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="insecure")
    def insecure(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "insecure"))

    @insecure.setter
    def insecure(
        self,
        value: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d524ecd44b71eee8038538083a527e2109dc4933cf7701023dd0c5d932788375)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "insecure", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="maxPerPage")
    def max_per_page(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxPerPage"))

    @max_per_page.setter
    def max_per_page(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__72a95cd42030208b282309edf22269a55a3ca9ab944e166744c4888ba3554827)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxPerPage", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="maxRetries")
    def max_retries(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxRetries"))

    @max_retries.setter
    def max_retries(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cef54eacd168fa015f4b7358207285b6fd93f5cb24df46294d216bc41855d367)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxRetries", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="organization")
    def organization(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "organization"))

    @organization.setter
    def organization(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2696d3bb84611ca78f0c4df069650466eaa21b09e7cc61081f5030c979fa219e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "organization", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="owner")
    def owner(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "owner"))

    @owner.setter
    def owner(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3bc07c9a25c10a3bc3acb12e39a8d26215681cf8121258e5da0cfb7835626525)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "owner", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="parallelRequests")
    def parallel_requests(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "parallelRequests"))

    @parallel_requests.setter
    def parallel_requests(
        self,
        value: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__212dc5a97998542ed52c1ec9bdbe3c6d7a06d17ddd496d887c1adac85300506a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "parallelRequests", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="readDelayMs")
    def read_delay_ms(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "readDelayMs"))

    @read_delay_ms.setter
    def read_delay_ms(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__923dcf88fcb79df0b4a7cf40c2d223c1758ea9c2f89a658dfeee5c59e34e786e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "readDelayMs", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="retryableErrors")
    def retryable_errors(self) -> typing.Optional[typing.List[jsii.Number]]:
        return typing.cast(typing.Optional[typing.List[jsii.Number]], jsii.get(self, "retryableErrors"))

    @retryable_errors.setter
    def retryable_errors(
        self,
        value: typing.Optional[typing.List[jsii.Number]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__22d75938525bdff9e3ae97d1ae5543094aebdf8c7adf39ff198d0e2ffef8d1cd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "retryableErrors", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="retryDelayMs")
    def retry_delay_ms(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "retryDelayMs"))

    @retry_delay_ms.setter
    def retry_delay_ms(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ee04be0dc9ea250a8f02cb4f672e380d803ef73f6b0b7231953eddeb0a5de6a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "retryDelayMs", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="token")
    def token(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "token"))

    @token.setter
    def token(self, value: typing.Optional[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__627fffe176602700c5c2836d7cc88a075124476822cf69950d127348873ae197)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "token", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="writeDelayMs")
    def write_delay_ms(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "writeDelayMs"))

    @write_delay_ms.setter
    def write_delay_ms(self, value: typing.Optional[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__99e859761d250c54a1ff33ea98a76addaada16c5e353602e484df5e848159e60)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "writeDelayMs", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.provider.GithubProviderAppAuth",
    jsii_struct_bases=[],
    name_mapping={
        "id": "id",
        "installation_id": "installationId",
        "pem_file": "pemFile",
    },
)
class GithubProviderAppAuth:
    def __init__(
        self,
        *,
        id: builtins.str,
        installation_id: builtins.str,
        pem_file: builtins.str,
    ) -> None:
        '''
        :param id: The GitHub App ID. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#id GithubProvider#id} Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param installation_id: The GitHub App installation instance ID. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#installation_id GithubProvider#installation_id}
        :param pem_file: The GitHub App PEM file contents. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#pem_file GithubProvider#pem_file}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0c1b1d67b6994df6a65a9319997b7075efd68572008d46c37c732e5290a15b9b)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument installation_id", value=installation_id, expected_type=type_hints["installation_id"])
            check_type(argname="argument pem_file", value=pem_file, expected_type=type_hints["pem_file"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "id": id,
            "installation_id": installation_id,
            "pem_file": pem_file,
        }

    @builtins.property
    def id(self) -> builtins.str:
        '''The GitHub App ID.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#id GithubProvider#id}

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        assert result is not None, "Required property 'id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def installation_id(self) -> builtins.str:
        '''The GitHub App installation instance ID.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#installation_id GithubProvider#installation_id}
        '''
        result = self._values.get("installation_id")
        assert result is not None, "Required property 'installation_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pem_file(self) -> builtins.str:
        '''The GitHub App PEM file contents.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#pem_file GithubProvider#pem_file}
        '''
        result = self._values.get("pem_file")
        assert result is not None, "Required property 'pem_file' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GithubProviderAppAuth(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-github.provider.GithubProviderConfig",
    jsii_struct_bases=[],
    name_mapping={
        "alias": "alias",
        "app_auth": "appAuth",
        "base_url": "baseUrl",
        "insecure": "insecure",
        "max_per_page": "maxPerPage",
        "max_retries": "maxRetries",
        "organization": "organization",
        "owner": "owner",
        "parallel_requests": "parallelRequests",
        "read_delay_ms": "readDelayMs",
        "retryable_errors": "retryableErrors",
        "retry_delay_ms": "retryDelayMs",
        "token": "token",
        "write_delay_ms": "writeDelayMs",
    },
)
class GithubProviderConfig:
    def __init__(
        self,
        *,
        alias: typing.Optional[builtins.str] = None,
        app_auth: typing.Optional[typing.Union["GithubProviderAppAuth", typing.Dict[builtins.str, typing.Any]]] = None,
        base_url: typing.Optional[builtins.str] = None,
        insecure: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        max_per_page: typing.Optional[jsii.Number] = None,
        max_retries: typing.Optional[jsii.Number] = None,
        organization: typing.Optional[builtins.str] = None,
        owner: typing.Optional[builtins.str] = None,
        parallel_requests: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        read_delay_ms: typing.Optional[jsii.Number] = None,
        retryable_errors: typing.Optional[typing.Sequence[jsii.Number]] = None,
        retry_delay_ms: typing.Optional[jsii.Number] = None,
        token: typing.Optional[builtins.str] = None,
        write_delay_ms: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param alias: Alias name. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#alias GithubProvider#alias}
        :param app_auth: app_auth block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#app_auth GithubProvider#app_auth}
        :param base_url: The GitHub Base API URL. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#base_url GithubProvider#base_url}
        :param insecure: Enable ``insecure`` mode for testing purposes. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#insecure GithubProvider#insecure}
        :param max_per_page: Number of items per page for paginationDefaults to 100. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#max_per_page GithubProvider#max_per_page}
        :param max_retries: Number of times to retry a request after receiving an error status codeDefaults to 3. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#max_retries GithubProvider#max_retries}
        :param organization: The GitHub organization name to manage. Use this field instead of ``owner`` when managing organization accounts. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#organization GithubProvider#organization}
        :param owner: The GitHub owner name to manage. Use this field instead of ``organization`` when managing individual accounts. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#owner GithubProvider#owner}
        :param parallel_requests: Allow the provider to make parallel API calls to GitHub. You may want to set it to true when you have a private Github Enterprise without strict rate limits. While it is possible to enable this setting on github.com, github.com's best practices recommend using serialization to avoid hitting abuse rate limitsDefaults to false if not set Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#parallel_requests GithubProvider#parallel_requests}
        :param read_delay_ms: Amount of time in milliseconds to sleep in between non-write requests to GitHub API. Defaults to 0ms if not set. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#read_delay_ms GithubProvider#read_delay_ms}
        :param retryable_errors: Allow the provider to retry after receiving an error status code, the max_retries should be set for this to workDefaults to [500, 502, 503, 504]. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#retryable_errors GithubProvider#retryable_errors}
        :param retry_delay_ms: Amount of time in milliseconds to sleep in between requests to GitHub API after an error response. Defaults to 1000ms or 1s if not set, the max_retries must be set to greater than zero. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#retry_delay_ms GithubProvider#retry_delay_ms}
        :param token: The OAuth token used to connect to GitHub. Anonymous mode is enabled if both ``token`` and ``app_auth`` are not set. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#token GithubProvider#token}
        :param write_delay_ms: Amount of time in milliseconds to sleep in between writes to GitHub API. Defaults to 1000ms or 1s if not set. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#write_delay_ms GithubProvider#write_delay_ms}
        '''
        if isinstance(app_auth, dict):
            app_auth = GithubProviderAppAuth(**app_auth)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__11f12426a37e495553edbf1df32919df79ed352baa72c14274ef4bc1d5cbfbc1)
            check_type(argname="argument alias", value=alias, expected_type=type_hints["alias"])
            check_type(argname="argument app_auth", value=app_auth, expected_type=type_hints["app_auth"])
            check_type(argname="argument base_url", value=base_url, expected_type=type_hints["base_url"])
            check_type(argname="argument insecure", value=insecure, expected_type=type_hints["insecure"])
            check_type(argname="argument max_per_page", value=max_per_page, expected_type=type_hints["max_per_page"])
            check_type(argname="argument max_retries", value=max_retries, expected_type=type_hints["max_retries"])
            check_type(argname="argument organization", value=organization, expected_type=type_hints["organization"])
            check_type(argname="argument owner", value=owner, expected_type=type_hints["owner"])
            check_type(argname="argument parallel_requests", value=parallel_requests, expected_type=type_hints["parallel_requests"])
            check_type(argname="argument read_delay_ms", value=read_delay_ms, expected_type=type_hints["read_delay_ms"])
            check_type(argname="argument retryable_errors", value=retryable_errors, expected_type=type_hints["retryable_errors"])
            check_type(argname="argument retry_delay_ms", value=retry_delay_ms, expected_type=type_hints["retry_delay_ms"])
            check_type(argname="argument token", value=token, expected_type=type_hints["token"])
            check_type(argname="argument write_delay_ms", value=write_delay_ms, expected_type=type_hints["write_delay_ms"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if alias is not None:
            self._values["alias"] = alias
        if app_auth is not None:
            self._values["app_auth"] = app_auth
        if base_url is not None:
            self._values["base_url"] = base_url
        if insecure is not None:
            self._values["insecure"] = insecure
        if max_per_page is not None:
            self._values["max_per_page"] = max_per_page
        if max_retries is not None:
            self._values["max_retries"] = max_retries
        if organization is not None:
            self._values["organization"] = organization
        if owner is not None:
            self._values["owner"] = owner
        if parallel_requests is not None:
            self._values["parallel_requests"] = parallel_requests
        if read_delay_ms is not None:
            self._values["read_delay_ms"] = read_delay_ms
        if retryable_errors is not None:
            self._values["retryable_errors"] = retryable_errors
        if retry_delay_ms is not None:
            self._values["retry_delay_ms"] = retry_delay_ms
        if token is not None:
            self._values["token"] = token
        if write_delay_ms is not None:
            self._values["write_delay_ms"] = write_delay_ms

    @builtins.property
    def alias(self) -> typing.Optional[builtins.str]:
        '''Alias name.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#alias GithubProvider#alias}
        '''
        result = self._values.get("alias")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def app_auth(self) -> typing.Optional["GithubProviderAppAuth"]:
        '''app_auth block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#app_auth GithubProvider#app_auth}
        '''
        result = self._values.get("app_auth")
        return typing.cast(typing.Optional["GithubProviderAppAuth"], result)

    @builtins.property
    def base_url(self) -> typing.Optional[builtins.str]:
        '''The GitHub Base API URL.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#base_url GithubProvider#base_url}
        '''
        result = self._values.get("base_url")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def insecure(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Enable ``insecure`` mode for testing purposes.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#insecure GithubProvider#insecure}
        '''
        result = self._values.get("insecure")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def max_per_page(self) -> typing.Optional[jsii.Number]:
        '''Number of items per page for paginationDefaults to 100.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#max_per_page GithubProvider#max_per_page}
        '''
        result = self._values.get("max_per_page")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def max_retries(self) -> typing.Optional[jsii.Number]:
        '''Number of times to retry a request after receiving an error status codeDefaults to 3.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#max_retries GithubProvider#max_retries}
        '''
        result = self._values.get("max_retries")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def organization(self) -> typing.Optional[builtins.str]:
        '''The GitHub organization name to manage. Use this field instead of ``owner`` when managing organization accounts.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#organization GithubProvider#organization}
        '''
        result = self._values.get("organization")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def owner(self) -> typing.Optional[builtins.str]:
        '''The GitHub owner name to manage. Use this field instead of ``organization`` when managing individual accounts.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#owner GithubProvider#owner}
        '''
        result = self._values.get("owner")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def parallel_requests(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Allow the provider to make parallel API calls to GitHub.

        You may want to set it to true when you have a private Github Enterprise without strict rate limits. While it is possible to enable this setting on github.com, github.com's best practices recommend using serialization to avoid hitting abuse rate limitsDefaults to false if not set

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#parallel_requests GithubProvider#parallel_requests}
        '''
        result = self._values.get("parallel_requests")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def read_delay_ms(self) -> typing.Optional[jsii.Number]:
        '''Amount of time in milliseconds to sleep in between non-write requests to GitHub API.

        Defaults to 0ms if not set.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#read_delay_ms GithubProvider#read_delay_ms}
        '''
        result = self._values.get("read_delay_ms")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def retryable_errors(self) -> typing.Optional[typing.List[jsii.Number]]:
        '''Allow the provider to retry after receiving an error status code, the max_retries should be set for this to workDefaults to [500, 502, 503, 504].

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#retryable_errors GithubProvider#retryable_errors}
        '''
        result = self._values.get("retryable_errors")
        return typing.cast(typing.Optional[typing.List[jsii.Number]], result)

    @builtins.property
    def retry_delay_ms(self) -> typing.Optional[jsii.Number]:
        '''Amount of time in milliseconds to sleep in between requests to GitHub API after an error response.

        Defaults to 1000ms or 1s if not set, the max_retries must be set to greater than zero.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#retry_delay_ms GithubProvider#retry_delay_ms}
        '''
        result = self._values.get("retry_delay_ms")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def token(self) -> typing.Optional[builtins.str]:
        '''The OAuth token used to connect to GitHub.

        Anonymous mode is enabled if both ``token`` and ``app_auth`` are not set.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#token GithubProvider#token}
        '''
        result = self._values.get("token")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def write_delay_ms(self) -> typing.Optional[jsii.Number]:
        '''Amount of time in milliseconds to sleep in between writes to GitHub API.

        Defaults to 1000ms or 1s if not set.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs#write_delay_ms GithubProvider#write_delay_ms}
        '''
        result = self._values.get("write_delay_ms")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GithubProviderConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "GithubProvider",
    "GithubProviderAppAuth",
    "GithubProviderConfig",
]

publication.publish()

def _typecheckingstub__679aaee2ae6be0ed6e342d3a1783810b3b1b8398ccd140d053e209b8d4f54e66(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    alias: typing.Optional[builtins.str] = None,
    app_auth: typing.Optional[typing.Union[GithubProviderAppAuth, typing.Dict[builtins.str, typing.Any]]] = None,
    base_url: typing.Optional[builtins.str] = None,
    insecure: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    max_per_page: typing.Optional[jsii.Number] = None,
    max_retries: typing.Optional[jsii.Number] = None,
    organization: typing.Optional[builtins.str] = None,
    owner: typing.Optional[builtins.str] = None,
    parallel_requests: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    read_delay_ms: typing.Optional[jsii.Number] = None,
    retryable_errors: typing.Optional[typing.Sequence[jsii.Number]] = None,
    retry_delay_ms: typing.Optional[jsii.Number] = None,
    token: typing.Optional[builtins.str] = None,
    write_delay_ms: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__75cb149a2e081e43726f1ee136e46bbebe93de34c39d5f1072e59c899d14e44a(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d8b2c84c1994bc1070e154acfd0143ec245c4c614daa889830a717c30427b1b5(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b999efcc694f3743dd926f00f78252bdece878efcca1e6658d3e17dc708ef867(
    value: typing.Optional[GithubProviderAppAuth],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__73482d80a1337ca7bd5993e75eb04d40d4d0f9506ae9a58e8e4b3b9c3786ac39(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d524ecd44b71eee8038538083a527e2109dc4933cf7701023dd0c5d932788375(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__72a95cd42030208b282309edf22269a55a3ca9ab944e166744c4888ba3554827(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cef54eacd168fa015f4b7358207285b6fd93f5cb24df46294d216bc41855d367(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2696d3bb84611ca78f0c4df069650466eaa21b09e7cc61081f5030c979fa219e(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3bc07c9a25c10a3bc3acb12e39a8d26215681cf8121258e5da0cfb7835626525(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__212dc5a97998542ed52c1ec9bdbe3c6d7a06d17ddd496d887c1adac85300506a(
    value: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__923dcf88fcb79df0b4a7cf40c2d223c1758ea9c2f89a658dfeee5c59e34e786e(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__22d75938525bdff9e3ae97d1ae5543094aebdf8c7adf39ff198d0e2ffef8d1cd(
    value: typing.Optional[typing.List[jsii.Number]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ee04be0dc9ea250a8f02cb4f672e380d803ef73f6b0b7231953eddeb0a5de6a(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__627fffe176602700c5c2836d7cc88a075124476822cf69950d127348873ae197(
    value: typing.Optional[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__99e859761d250c54a1ff33ea98a76addaada16c5e353602e484df5e848159e60(
    value: typing.Optional[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0c1b1d67b6994df6a65a9319997b7075efd68572008d46c37c732e5290a15b9b(
    *,
    id: builtins.str,
    installation_id: builtins.str,
    pem_file: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__11f12426a37e495553edbf1df32919df79ed352baa72c14274ef4bc1d5cbfbc1(
    *,
    alias: typing.Optional[builtins.str] = None,
    app_auth: typing.Optional[typing.Union[GithubProviderAppAuth, typing.Dict[builtins.str, typing.Any]]] = None,
    base_url: typing.Optional[builtins.str] = None,
    insecure: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    max_per_page: typing.Optional[jsii.Number] = None,
    max_retries: typing.Optional[jsii.Number] = None,
    organization: typing.Optional[builtins.str] = None,
    owner: typing.Optional[builtins.str] = None,
    parallel_requests: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    read_delay_ms: typing.Optional[jsii.Number] = None,
    retryable_errors: typing.Optional[typing.Sequence[jsii.Number]] = None,
    retry_delay_ms: typing.Optional[jsii.Number] = None,
    token: typing.Optional[builtins.str] = None,
    write_delay_ms: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass
