r'''
# `github_repository`

Refer to the Terraform Registry for docs: [`github_repository`](https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class Repository(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repository.Repository",
):
    '''Represents a {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository github_repository}.'''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id_: builtins.str,
        *,
        name: builtins.str,
        allow_auto_merge: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        allow_forking: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        allow_merge_commit: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        allow_rebase_merge: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        allow_squash_merge: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        allow_update_branch: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        archived: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        archive_on_destroy: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        auto_init: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        default_branch: typing.Optional[builtins.str] = None,
        delete_branch_on_merge: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        description: typing.Optional[builtins.str] = None,
        etag: typing.Optional[builtins.str] = None,
        fork: typing.Optional[builtins.str] = None,
        gitignore_template: typing.Optional[builtins.str] = None,
        has_discussions: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        has_downloads: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        has_issues: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        has_projects: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        has_wiki: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        homepage_url: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        ignore_vulnerability_alerts_during_read: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        is_template: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        license_template: typing.Optional[builtins.str] = None,
        merge_commit_message: typing.Optional[builtins.str] = None,
        merge_commit_title: typing.Optional[builtins.str] = None,
        pages: typing.Optional[typing.Union["RepositoryPages", typing.Dict[builtins.str, typing.Any]]] = None,
        private: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        security_and_analysis: typing.Optional[typing.Union["RepositorySecurityAndAnalysis", typing.Dict[builtins.str, typing.Any]]] = None,
        source_owner: typing.Optional[builtins.str] = None,
        source_repo: typing.Optional[builtins.str] = None,
        squash_merge_commit_message: typing.Optional[builtins.str] = None,
        squash_merge_commit_title: typing.Optional[builtins.str] = None,
        template: typing.Optional[typing.Union["RepositoryTemplate", typing.Dict[builtins.str, typing.Any]]] = None,
        topics: typing.Optional[typing.Sequence[builtins.str]] = None,
        visibility: typing.Optional[builtins.str] = None,
        vulnerability_alerts: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        web_commit_signoff_required: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository github_repository} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param name: The name of the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#name Repository#name}
        :param allow_auto_merge: Set to 'true' to allow auto-merging pull requests on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_auto_merge Repository#allow_auto_merge}
        :param allow_forking: Set to 'true' to allow private forking on the repository; this is only relevant if the repository is owned by an organization and is private or internal. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_forking Repository#allow_forking}
        :param allow_merge_commit: Set to 'false' to disable merge commits on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_merge_commit Repository#allow_merge_commit}
        :param allow_rebase_merge: Set to 'false' to disable rebase merges on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_rebase_merge Repository#allow_rebase_merge}
        :param allow_squash_merge: Set to 'false' to disable squash merges on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_squash_merge Repository#allow_squash_merge}
        :param allow_update_branch: Set to 'true' to always suggest updating pull request branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_update_branch Repository#allow_update_branch}
        :param archived: Specifies if the repository should be archived. Defaults to 'false'. NOTE Currently, the API does not support unarchiving. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#archived Repository#archived}
        :param archive_on_destroy: Set to 'true' to archive the repository instead of deleting on destroy. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#archive_on_destroy Repository#archive_on_destroy}
        :param auto_init: Set to 'true' to produce an initial commit in the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#auto_init Repository#auto_init}
        :param default_branch: Can only be set after initial repository creation, and only if the target branch exists. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#default_branch Repository#default_branch}
        :param delete_branch_on_merge: Automatically delete head branch after a pull request is merged. Defaults to 'false'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#delete_branch_on_merge Repository#delete_branch_on_merge}
        :param description: A description of the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#description Repository#description}
        :param etag: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#etag Repository#etag}.
        :param fork: Set to 'true' to fork an existing repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#fork Repository#fork}
        :param gitignore_template: Use the name of the template without the extension. For example, 'Haskell'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#gitignore_template Repository#gitignore_template}
        :param has_discussions: Set to 'true' to enable GitHub Discussions on the repository. Defaults to 'false'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_discussions Repository#has_discussions}
        :param has_downloads: Set to 'true' to enable the (deprecated) downloads features on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_downloads Repository#has_downloads}
        :param has_issues: Set to 'true' to enable the GitHub Issues features on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_issues Repository#has_issues}
        :param has_projects: Set to 'true' to enable the GitHub Projects features on the repository. Per the GitHub documentation when in an organization that has disabled repository projects it will default to 'false' and will otherwise default to 'true'. If you specify 'true' when it has been disabled it will return an error. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_projects Repository#has_projects}
        :param has_wiki: Set to 'true' to enable the GitHub Wiki features on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_wiki Repository#has_wiki}
        :param homepage_url: URL of a page describing the project. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#homepage_url Repository#homepage_url}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#id Repository#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param ignore_vulnerability_alerts_during_read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#ignore_vulnerability_alerts_during_read Repository#ignore_vulnerability_alerts_during_read}.
        :param is_template: Set to 'true' to tell GitHub that this is a template repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#is_template Repository#is_template}
        :param license_template: Use the name of the template without the extension. For example, 'mit' or 'mpl-2.0'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#license_template Repository#license_template}
        :param merge_commit_message: Can be 'PR_BODY', 'PR_TITLE', or 'BLANK' for a default merge commit message. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#merge_commit_message Repository#merge_commit_message}
        :param merge_commit_title: Can be 'PR_TITLE' or 'MERGE_MESSAGE' for a default merge commit title. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#merge_commit_title Repository#merge_commit_title}
        :param pages: pages block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#pages Repository#pages}
        :param private: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#private Repository#private}.
        :param security_and_analysis: security_and_analysis block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#security_and_analysis Repository#security_and_analysis}
        :param source_owner: The owner of the source repository to fork from. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#source_owner Repository#source_owner}
        :param source_repo: The name of the source repository to fork from. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#source_repo Repository#source_repo}
        :param squash_merge_commit_message: Can be 'PR_BODY', 'COMMIT_MESSAGES', or 'BLANK' for a default squash merge commit message. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#squash_merge_commit_message Repository#squash_merge_commit_message}
        :param squash_merge_commit_title: Can be 'PR_TITLE' or 'COMMIT_OR_PR_TITLE' for a default squash merge commit title. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#squash_merge_commit_title Repository#squash_merge_commit_title}
        :param template: template block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#template Repository#template}
        :param topics: The list of topics of the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#topics Repository#topics}
        :param visibility: Can be 'public' or 'private'. If your organization is associated with an enterprise account using GitHub Enterprise Cloud or GitHub Enterprise Server 2.20+, visibility can also be 'internal'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#visibility Repository#visibility}
        :param vulnerability_alerts: Set to 'true' to enable security alerts for vulnerable dependencies. Enabling requires alerts to be enabled on the owner level. (Note for importing: GitHub enables the alerts on all repos by default). Note that vulnerability alerts have not been successfully tested on any GitHub Enterprise instance and may be unavailable in those settings. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#vulnerability_alerts Repository#vulnerability_alerts}
        :param web_commit_signoff_required: Require contributors to sign off on web-based commits. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#web_commit_signoff_required Repository#web_commit_signoff_required}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76f88e84cfc2533f645219c270fb40ff03f3890dbe079111fb2093569713f773)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = RepositoryConfig(
            name=name,
            allow_auto_merge=allow_auto_merge,
            allow_forking=allow_forking,
            allow_merge_commit=allow_merge_commit,
            allow_rebase_merge=allow_rebase_merge,
            allow_squash_merge=allow_squash_merge,
            allow_update_branch=allow_update_branch,
            archived=archived,
            archive_on_destroy=archive_on_destroy,
            auto_init=auto_init,
            default_branch=default_branch,
            delete_branch_on_merge=delete_branch_on_merge,
            description=description,
            etag=etag,
            fork=fork,
            gitignore_template=gitignore_template,
            has_discussions=has_discussions,
            has_downloads=has_downloads,
            has_issues=has_issues,
            has_projects=has_projects,
            has_wiki=has_wiki,
            homepage_url=homepage_url,
            id=id,
            ignore_vulnerability_alerts_during_read=ignore_vulnerability_alerts_during_read,
            is_template=is_template,
            license_template=license_template,
            merge_commit_message=merge_commit_message,
            merge_commit_title=merge_commit_title,
            pages=pages,
            private=private,
            security_and_analysis=security_and_analysis,
            source_owner=source_owner,
            source_repo=source_repo,
            squash_merge_commit_message=squash_merge_commit_message,
            squash_merge_commit_title=squash_merge_commit_title,
            template=template,
            topics=topics,
            visibility=visibility,
            vulnerability_alerts=vulnerability_alerts,
            web_commit_signoff_required=web_commit_signoff_required,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a Repository resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the Repository to import.
        :param import_from_id: The id of the existing Repository that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the Repository to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eb3d538a1e37a6d7a13c6778097e9469f207f7c00b3cea2959be4590c5d20d8f)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putPages")
    def put_pages(
        self,
        *,
        build_type: typing.Optional[builtins.str] = None,
        cname: typing.Optional[builtins.str] = None,
        source: typing.Optional[typing.Union["RepositoryPagesSource", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param build_type: The type the page should be sourced. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#build_type Repository#build_type}
        :param cname: The custom domain for the repository. This can only be set after the repository has been created. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#cname Repository#cname}
        :param source: source block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#source Repository#source}
        '''
        value = RepositoryPages(build_type=build_type, cname=cname, source=source)

        return typing.cast(None, jsii.invoke(self, "putPages", [value]))

    @jsii.member(jsii_name="putSecurityAndAnalysis")
    def put_security_and_analysis(
        self,
        *,
        advanced_security: typing.Optional[typing.Union["RepositorySecurityAndAnalysisAdvancedSecurity", typing.Dict[builtins.str, typing.Any]]] = None,
        code_security: typing.Optional[typing.Union["RepositorySecurityAndAnalysisCodeSecurity", typing.Dict[builtins.str, typing.Any]]] = None,
        secret_scanning: typing.Optional[typing.Union["RepositorySecurityAndAnalysisSecretScanning", typing.Dict[builtins.str, typing.Any]]] = None,
        secret_scanning_ai_detection: typing.Optional[typing.Union["RepositorySecurityAndAnalysisSecretScanningAiDetection", typing.Dict[builtins.str, typing.Any]]] = None,
        secret_scanning_non_provider_patterns: typing.Optional[typing.Union["RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns", typing.Dict[builtins.str, typing.Any]]] = None,
        secret_scanning_push_protection: typing.Optional[typing.Union["RepositorySecurityAndAnalysisSecretScanningPushProtection", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param advanced_security: advanced_security block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#advanced_security Repository#advanced_security}
        :param code_security: code_security block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#code_security Repository#code_security}
        :param secret_scanning: secret_scanning block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning Repository#secret_scanning}
        :param secret_scanning_ai_detection: secret_scanning_ai_detection block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning_ai_detection Repository#secret_scanning_ai_detection}
        :param secret_scanning_non_provider_patterns: secret_scanning_non_provider_patterns block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning_non_provider_patterns Repository#secret_scanning_non_provider_patterns}
        :param secret_scanning_push_protection: secret_scanning_push_protection block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning_push_protection Repository#secret_scanning_push_protection}
        '''
        value = RepositorySecurityAndAnalysis(
            advanced_security=advanced_security,
            code_security=code_security,
            secret_scanning=secret_scanning,
            secret_scanning_ai_detection=secret_scanning_ai_detection,
            secret_scanning_non_provider_patterns=secret_scanning_non_provider_patterns,
            secret_scanning_push_protection=secret_scanning_push_protection,
        )

        return typing.cast(None, jsii.invoke(self, "putSecurityAndAnalysis", [value]))

    @jsii.member(jsii_name="putTemplate")
    def put_template(
        self,
        *,
        owner: builtins.str,
        repository: builtins.str,
        include_all_branches: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param owner: The GitHub organization or user the template repository is owned by. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#owner Repository#owner}
        :param repository: The name of the template repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#repository Repository#repository}
        :param include_all_branches: Whether the new repository should include all the branches from the template repository (defaults to 'false', which includes only the default branch from the template). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#include_all_branches Repository#include_all_branches}
        '''
        value = RepositoryTemplate(
            owner=owner,
            repository=repository,
            include_all_branches=include_all_branches,
        )

        return typing.cast(None, jsii.invoke(self, "putTemplate", [value]))

    @jsii.member(jsii_name="resetAllowAutoMerge")
    def reset_allow_auto_merge(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowAutoMerge", []))

    @jsii.member(jsii_name="resetAllowForking")
    def reset_allow_forking(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowForking", []))

    @jsii.member(jsii_name="resetAllowMergeCommit")
    def reset_allow_merge_commit(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowMergeCommit", []))

    @jsii.member(jsii_name="resetAllowRebaseMerge")
    def reset_allow_rebase_merge(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowRebaseMerge", []))

    @jsii.member(jsii_name="resetAllowSquashMerge")
    def reset_allow_squash_merge(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowSquashMerge", []))

    @jsii.member(jsii_name="resetAllowUpdateBranch")
    def reset_allow_update_branch(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowUpdateBranch", []))

    @jsii.member(jsii_name="resetArchived")
    def reset_archived(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetArchived", []))

    @jsii.member(jsii_name="resetArchiveOnDestroy")
    def reset_archive_on_destroy(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetArchiveOnDestroy", []))

    @jsii.member(jsii_name="resetAutoInit")
    def reset_auto_init(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAutoInit", []))

    @jsii.member(jsii_name="resetDefaultBranch")
    def reset_default_branch(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDefaultBranch", []))

    @jsii.member(jsii_name="resetDeleteBranchOnMerge")
    def reset_delete_branch_on_merge(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDeleteBranchOnMerge", []))

    @jsii.member(jsii_name="resetDescription")
    def reset_description(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDescription", []))

    @jsii.member(jsii_name="resetEtag")
    def reset_etag(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEtag", []))

    @jsii.member(jsii_name="resetFork")
    def reset_fork(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFork", []))

    @jsii.member(jsii_name="resetGitignoreTemplate")
    def reset_gitignore_template(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetGitignoreTemplate", []))

    @jsii.member(jsii_name="resetHasDiscussions")
    def reset_has_discussions(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHasDiscussions", []))

    @jsii.member(jsii_name="resetHasDownloads")
    def reset_has_downloads(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHasDownloads", []))

    @jsii.member(jsii_name="resetHasIssues")
    def reset_has_issues(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHasIssues", []))

    @jsii.member(jsii_name="resetHasProjects")
    def reset_has_projects(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHasProjects", []))

    @jsii.member(jsii_name="resetHasWiki")
    def reset_has_wiki(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHasWiki", []))

    @jsii.member(jsii_name="resetHomepageUrl")
    def reset_homepage_url(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHomepageUrl", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetIgnoreVulnerabilityAlertsDuringRead")
    def reset_ignore_vulnerability_alerts_during_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIgnoreVulnerabilityAlertsDuringRead", []))

    @jsii.member(jsii_name="resetIsTemplate")
    def reset_is_template(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIsTemplate", []))

    @jsii.member(jsii_name="resetLicenseTemplate")
    def reset_license_template(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLicenseTemplate", []))

    @jsii.member(jsii_name="resetMergeCommitMessage")
    def reset_merge_commit_message(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMergeCommitMessage", []))

    @jsii.member(jsii_name="resetMergeCommitTitle")
    def reset_merge_commit_title(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMergeCommitTitle", []))

    @jsii.member(jsii_name="resetPages")
    def reset_pages(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPages", []))

    @jsii.member(jsii_name="resetPrivate")
    def reset_private(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPrivate", []))

    @jsii.member(jsii_name="resetSecurityAndAnalysis")
    def reset_security_and_analysis(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSecurityAndAnalysis", []))

    @jsii.member(jsii_name="resetSourceOwner")
    def reset_source_owner(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSourceOwner", []))

    @jsii.member(jsii_name="resetSourceRepo")
    def reset_source_repo(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSourceRepo", []))

    @jsii.member(jsii_name="resetSquashMergeCommitMessage")
    def reset_squash_merge_commit_message(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSquashMergeCommitMessage", []))

    @jsii.member(jsii_name="resetSquashMergeCommitTitle")
    def reset_squash_merge_commit_title(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSquashMergeCommitTitle", []))

    @jsii.member(jsii_name="resetTemplate")
    def reset_template(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTemplate", []))

    @jsii.member(jsii_name="resetTopics")
    def reset_topics(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTopics", []))

    @jsii.member(jsii_name="resetVisibility")
    def reset_visibility(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetVisibility", []))

    @jsii.member(jsii_name="resetVulnerabilityAlerts")
    def reset_vulnerability_alerts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetVulnerabilityAlerts", []))

    @jsii.member(jsii_name="resetWebCommitSignoffRequired")
    def reset_web_commit_signoff_required(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetWebCommitSignoffRequired", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="fullName")
    def full_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fullName"))

    @builtins.property
    @jsii.member(jsii_name="gitCloneUrl")
    def git_clone_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "gitCloneUrl"))

    @builtins.property
    @jsii.member(jsii_name="htmlUrl")
    def html_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "htmlUrl"))

    @builtins.property
    @jsii.member(jsii_name="httpCloneUrl")
    def http_clone_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "httpCloneUrl"))

    @builtins.property
    @jsii.member(jsii_name="nodeId")
    def node_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "nodeId"))

    @builtins.property
    @jsii.member(jsii_name="pages")
    def pages(self) -> "RepositoryPagesOutputReference":
        return typing.cast("RepositoryPagesOutputReference", jsii.get(self, "pages"))

    @builtins.property
    @jsii.member(jsii_name="primaryLanguage")
    def primary_language(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "primaryLanguage"))

    @builtins.property
    @jsii.member(jsii_name="repoId")
    def repo_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "repoId"))

    @builtins.property
    @jsii.member(jsii_name="securityAndAnalysis")
    def security_and_analysis(self) -> "RepositorySecurityAndAnalysisOutputReference":
        return typing.cast("RepositorySecurityAndAnalysisOutputReference", jsii.get(self, "securityAndAnalysis"))

    @builtins.property
    @jsii.member(jsii_name="sshCloneUrl")
    def ssh_clone_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sshCloneUrl"))

    @builtins.property
    @jsii.member(jsii_name="svnUrl")
    def svn_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "svnUrl"))

    @builtins.property
    @jsii.member(jsii_name="template")
    def template(self) -> "RepositoryTemplateOutputReference":
        return typing.cast("RepositoryTemplateOutputReference", jsii.get(self, "template"))

    @builtins.property
    @jsii.member(jsii_name="allowAutoMergeInput")
    def allow_auto_merge_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "allowAutoMergeInput"))

    @builtins.property
    @jsii.member(jsii_name="allowForkingInput")
    def allow_forking_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "allowForkingInput"))

    @builtins.property
    @jsii.member(jsii_name="allowMergeCommitInput")
    def allow_merge_commit_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "allowMergeCommitInput"))

    @builtins.property
    @jsii.member(jsii_name="allowRebaseMergeInput")
    def allow_rebase_merge_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "allowRebaseMergeInput"))

    @builtins.property
    @jsii.member(jsii_name="allowSquashMergeInput")
    def allow_squash_merge_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "allowSquashMergeInput"))

    @builtins.property
    @jsii.member(jsii_name="allowUpdateBranchInput")
    def allow_update_branch_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "allowUpdateBranchInput"))

    @builtins.property
    @jsii.member(jsii_name="archivedInput")
    def archived_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "archivedInput"))

    @builtins.property
    @jsii.member(jsii_name="archiveOnDestroyInput")
    def archive_on_destroy_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "archiveOnDestroyInput"))

    @builtins.property
    @jsii.member(jsii_name="autoInitInput")
    def auto_init_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "autoInitInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultBranchInput")
    def default_branch_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "defaultBranchInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteBranchOnMergeInput")
    def delete_branch_on_merge_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "deleteBranchOnMergeInput"))

    @builtins.property
    @jsii.member(jsii_name="descriptionInput")
    def description_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "descriptionInput"))

    @builtins.property
    @jsii.member(jsii_name="etagInput")
    def etag_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "etagInput"))

    @builtins.property
    @jsii.member(jsii_name="forkInput")
    def fork_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "forkInput"))

    @builtins.property
    @jsii.member(jsii_name="gitignoreTemplateInput")
    def gitignore_template_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "gitignoreTemplateInput"))

    @builtins.property
    @jsii.member(jsii_name="hasDiscussionsInput")
    def has_discussions_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "hasDiscussionsInput"))

    @builtins.property
    @jsii.member(jsii_name="hasDownloadsInput")
    def has_downloads_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "hasDownloadsInput"))

    @builtins.property
    @jsii.member(jsii_name="hasIssuesInput")
    def has_issues_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "hasIssuesInput"))

    @builtins.property
    @jsii.member(jsii_name="hasProjectsInput")
    def has_projects_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "hasProjectsInput"))

    @builtins.property
    @jsii.member(jsii_name="hasWikiInput")
    def has_wiki_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "hasWikiInput"))

    @builtins.property
    @jsii.member(jsii_name="homepageUrlInput")
    def homepage_url_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "homepageUrlInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="ignoreVulnerabilityAlertsDuringReadInput")
    def ignore_vulnerability_alerts_during_read_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "ignoreVulnerabilityAlertsDuringReadInput"))

    @builtins.property
    @jsii.member(jsii_name="isTemplateInput")
    def is_template_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "isTemplateInput"))

    @builtins.property
    @jsii.member(jsii_name="licenseTemplateInput")
    def license_template_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "licenseTemplateInput"))

    @builtins.property
    @jsii.member(jsii_name="mergeCommitMessageInput")
    def merge_commit_message_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "mergeCommitMessageInput"))

    @builtins.property
    @jsii.member(jsii_name="mergeCommitTitleInput")
    def merge_commit_title_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "mergeCommitTitleInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="pagesInput")
    def pages_input(self) -> typing.Optional["RepositoryPages"]:
        return typing.cast(typing.Optional["RepositoryPages"], jsii.get(self, "pagesInput"))

    @builtins.property
    @jsii.member(jsii_name="privateInput")
    def private_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "privateInput"))

    @builtins.property
    @jsii.member(jsii_name="securityAndAnalysisInput")
    def security_and_analysis_input(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysis"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysis"], jsii.get(self, "securityAndAnalysisInput"))

    @builtins.property
    @jsii.member(jsii_name="sourceOwnerInput")
    def source_owner_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sourceOwnerInput"))

    @builtins.property
    @jsii.member(jsii_name="sourceRepoInput")
    def source_repo_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sourceRepoInput"))

    @builtins.property
    @jsii.member(jsii_name="squashMergeCommitMessageInput")
    def squash_merge_commit_message_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "squashMergeCommitMessageInput"))

    @builtins.property
    @jsii.member(jsii_name="squashMergeCommitTitleInput")
    def squash_merge_commit_title_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "squashMergeCommitTitleInput"))

    @builtins.property
    @jsii.member(jsii_name="templateInput")
    def template_input(self) -> typing.Optional["RepositoryTemplate"]:
        return typing.cast(typing.Optional["RepositoryTemplate"], jsii.get(self, "templateInput"))

    @builtins.property
    @jsii.member(jsii_name="topicsInput")
    def topics_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "topicsInput"))

    @builtins.property
    @jsii.member(jsii_name="visibilityInput")
    def visibility_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "visibilityInput"))

    @builtins.property
    @jsii.member(jsii_name="vulnerabilityAlertsInput")
    def vulnerability_alerts_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "vulnerabilityAlertsInput"))

    @builtins.property
    @jsii.member(jsii_name="webCommitSignoffRequiredInput")
    def web_commit_signoff_required_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "webCommitSignoffRequiredInput"))

    @builtins.property
    @jsii.member(jsii_name="allowAutoMerge")
    def allow_auto_merge(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "allowAutoMerge"))

    @allow_auto_merge.setter
    def allow_auto_merge(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a7d7398efc854bf2d8d372daaa069f33e446bb3fe15ba08bcdf6a610ecfefeda)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowAutoMerge", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="allowForking")
    def allow_forking(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "allowForking"))

    @allow_forking.setter
    def allow_forking(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a48334fa3191d169d6849658520707cd42385f72815ca522ca9c43a052944ca8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowForking", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="allowMergeCommit")
    def allow_merge_commit(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "allowMergeCommit"))

    @allow_merge_commit.setter
    def allow_merge_commit(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80e0bf4e0569d7fb07bb4d2d8cd15b882302524b6bd9aaaaabfb59f1ee2b6064)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowMergeCommit", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="allowRebaseMerge")
    def allow_rebase_merge(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "allowRebaseMerge"))

    @allow_rebase_merge.setter
    def allow_rebase_merge(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0376c55de0a13d47a1985727e5ce092b350965f26a1beed902636dee69d5c03c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowRebaseMerge", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="allowSquashMerge")
    def allow_squash_merge(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "allowSquashMerge"))

    @allow_squash_merge.setter
    def allow_squash_merge(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f1de034deaef811f21da20a542adbd8a35571a2942a54840eee0e1b89220fe9f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowSquashMerge", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="allowUpdateBranch")
    def allow_update_branch(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "allowUpdateBranch"))

    @allow_update_branch.setter
    def allow_update_branch(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__196b629f92e4d591d3dfa605a3dff502a77847e9e531497fa87ee0ba39cc6885)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowUpdateBranch", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="archived")
    def archived(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "archived"))

    @archived.setter
    def archived(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98d29ad3de83cfbe1afdc60d67cd005b838bf66668748a506c077643e945706d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "archived", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="archiveOnDestroy")
    def archive_on_destroy(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "archiveOnDestroy"))

    @archive_on_destroy.setter
    def archive_on_destroy(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9dc95dfcbc904df4c568f9d6a78fae185211a698b174b0245b66131d544be733)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "archiveOnDestroy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="autoInit")
    def auto_init(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "autoInit"))

    @auto_init.setter
    def auto_init(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2aace9214669412958b362072ab4eaaa6751eafbc86b56c5e508486ffc0fa409)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "autoInit", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="defaultBranch")
    def default_branch(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "defaultBranch"))

    @default_branch.setter
    def default_branch(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__07874b4530ca734b8d7270ea269b01c7ea817d726a1460772d11e30ad3f8b5b5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultBranch", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="deleteBranchOnMerge")
    def delete_branch_on_merge(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "deleteBranchOnMerge"))

    @delete_branch_on_merge.setter
    def delete_branch_on_merge(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__72be96f57d03b385269f76f990713e23f21556d639e16bdf21b1d02614badc99)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "deleteBranchOnMerge", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="description")
    def description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "description"))

    @description.setter
    def description(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d6e701c0cb81f1f4bfe669614fa272aa6eb0208ce350b9aaf40749f95afee97c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "description", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="etag")
    def etag(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "etag"))

    @etag.setter
    def etag(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__09dc8b3e615e782336d219f3b7b81c2db95eaed1a0693b0a1548834ecb785c2e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "etag", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="fork")
    def fork(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "fork"))

    @fork.setter
    def fork(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89f0c79e77c36b5b7a1fa635202120188a738c3e04a4666e776bb7ac31e78bc0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "fork", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="gitignoreTemplate")
    def gitignore_template(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "gitignoreTemplate"))

    @gitignore_template.setter
    def gitignore_template(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2d2adccfe9c83575dde1bf137784a4605fc8efe12cd648aac545538104ca5474)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "gitignoreTemplate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="hasDiscussions")
    def has_discussions(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "hasDiscussions"))

    @has_discussions.setter
    def has_discussions(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b7069db4ce99ec25d5134c4fb4946dac546278a949c7f709deea54450125a31b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "hasDiscussions", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="hasDownloads")
    def has_downloads(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "hasDownloads"))

    @has_downloads.setter
    def has_downloads(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c9755497fc2c18ae0c6359f306e822d3c7fb8b242009b3b7c7912bc7fd78bf3e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "hasDownloads", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="hasIssues")
    def has_issues(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "hasIssues"))

    @has_issues.setter
    def has_issues(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7bf9644d44476376a8c00620ddac1218ef7a06336bc89c0bfec3261aae7663d6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "hasIssues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="hasProjects")
    def has_projects(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "hasProjects"))

    @has_projects.setter
    def has_projects(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7100e1ad302b22445619d6371fbfa0e3097ac2b6895f210c181c7a6deb5ca5e6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "hasProjects", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="hasWiki")
    def has_wiki(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "hasWiki"))

    @has_wiki.setter
    def has_wiki(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e3a6d67f0a95c17ef0470f5a0c7016d1545f2b6a8541012dbd0cad8a70da0368)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "hasWiki", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="homepageUrl")
    def homepage_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "homepageUrl"))

    @homepage_url.setter
    def homepage_url(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__46a9a215ef9885c2d42f42d5e2b66aa2920fe6d3cf9412cbb70d3234aa0916a2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "homepageUrl", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__870e383f8e8c43e1612b782660850e5af8e9eb63ab0d446cc38f22763980e1ca)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ignoreVulnerabilityAlertsDuringRead")
    def ignore_vulnerability_alerts_during_read(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "ignoreVulnerabilityAlertsDuringRead"))

    @ignore_vulnerability_alerts_during_read.setter
    def ignore_vulnerability_alerts_during_read(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f41da97c8c59e4215747f54b829adc962166e42dcae00848f13ba13ec86fcc0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ignoreVulnerabilityAlertsDuringRead", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="isTemplate")
    def is_template(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "isTemplate"))

    @is_template.setter
    def is_template(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e579e090d61a2481358a1ad26ecfd61f18f65c08d37dc45f372fffa9ccf1cc6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "isTemplate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="licenseTemplate")
    def license_template(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "licenseTemplate"))

    @license_template.setter
    def license_template(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__df5dc20f316fe8cd938cd6e5c71cee6e416a01b04768f82228a4f2ae16d40068)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "licenseTemplate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="mergeCommitMessage")
    def merge_commit_message(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "mergeCommitMessage"))

    @merge_commit_message.setter
    def merge_commit_message(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f1e778efdcf517cc3af108f612918c3a47e7eb1c4c41e78dbb772fe4edfc0b19)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "mergeCommitMessage", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="mergeCommitTitle")
    def merge_commit_title(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "mergeCommitTitle"))

    @merge_commit_title.setter
    def merge_commit_title(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__91e94b80b34b0ea9d795ac72c309b59c519c84796ef0333c62078ce947ff4ccd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "mergeCommitTitle", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__86aa25c87acc28935ab6087f57b1f77924986c6712189128abfee5fab05ea169)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="private")
    def private(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "private"))

    @private.setter
    def private(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08eea670243e22e8f3056cc27a9a6919282f25a917d267c96a43a154481bde76)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "private", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sourceOwner")
    def source_owner(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sourceOwner"))

    @source_owner.setter
    def source_owner(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a3f62c273e3ad8f90edf9ee1f64396d9585368098c0218bef73bbf573827a9a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sourceOwner", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sourceRepo")
    def source_repo(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sourceRepo"))

    @source_repo.setter
    def source_repo(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__23ef7d696796d1a66ec1c07c675bfe07c124a10771a848d03333cc8e36a3058c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sourceRepo", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="squashMergeCommitMessage")
    def squash_merge_commit_message(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "squashMergeCommitMessage"))

    @squash_merge_commit_message.setter
    def squash_merge_commit_message(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ea1e03efa86e71538b0c919aa770477c49c88460127dec2950f0359e41a77e4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "squashMergeCommitMessage", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="squashMergeCommitTitle")
    def squash_merge_commit_title(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "squashMergeCommitTitle"))

    @squash_merge_commit_title.setter
    def squash_merge_commit_title(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__06e71764c86fe3e6bc29abb55625267a7ba1d0d1932018c49c494ef5a63d4466)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "squashMergeCommitTitle", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="topics")
    def topics(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "topics"))

    @topics.setter
    def topics(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9b520c33063162281f1305b4e1e7fed329089436cbdd64777c340c2164eb6ce1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "topics", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="visibility")
    def visibility(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "visibility"))

    @visibility.setter
    def visibility(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6e14f309c1843aae643f67684f75748b3253249497b46da9172f64de2c1cde82)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "visibility", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="vulnerabilityAlerts")
    def vulnerability_alerts(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "vulnerabilityAlerts"))

    @vulnerability_alerts.setter
    def vulnerability_alerts(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a470dd771cef18127034e69d4b4580c38a1331c9ec4270148153f0ca94354159)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "vulnerabilityAlerts", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="webCommitSignoffRequired")
    def web_commit_signoff_required(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "webCommitSignoffRequired"))

    @web_commit_signoff_required.setter
    def web_commit_signoff_required(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__73907108c7ea31316823eab1fb786f12606a0df68de443bdef64643ccccb3b44)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "webCommitSignoffRequired", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repository.RepositoryConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "name": "name",
        "allow_auto_merge": "allowAutoMerge",
        "allow_forking": "allowForking",
        "allow_merge_commit": "allowMergeCommit",
        "allow_rebase_merge": "allowRebaseMerge",
        "allow_squash_merge": "allowSquashMerge",
        "allow_update_branch": "allowUpdateBranch",
        "archived": "archived",
        "archive_on_destroy": "archiveOnDestroy",
        "auto_init": "autoInit",
        "default_branch": "defaultBranch",
        "delete_branch_on_merge": "deleteBranchOnMerge",
        "description": "description",
        "etag": "etag",
        "fork": "fork",
        "gitignore_template": "gitignoreTemplate",
        "has_discussions": "hasDiscussions",
        "has_downloads": "hasDownloads",
        "has_issues": "hasIssues",
        "has_projects": "hasProjects",
        "has_wiki": "hasWiki",
        "homepage_url": "homepageUrl",
        "id": "id",
        "ignore_vulnerability_alerts_during_read": "ignoreVulnerabilityAlertsDuringRead",
        "is_template": "isTemplate",
        "license_template": "licenseTemplate",
        "merge_commit_message": "mergeCommitMessage",
        "merge_commit_title": "mergeCommitTitle",
        "pages": "pages",
        "private": "private",
        "security_and_analysis": "securityAndAnalysis",
        "source_owner": "sourceOwner",
        "source_repo": "sourceRepo",
        "squash_merge_commit_message": "squashMergeCommitMessage",
        "squash_merge_commit_title": "squashMergeCommitTitle",
        "template": "template",
        "topics": "topics",
        "visibility": "visibility",
        "vulnerability_alerts": "vulnerabilityAlerts",
        "web_commit_signoff_required": "webCommitSignoffRequired",
    },
)
class RepositoryConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        name: builtins.str,
        allow_auto_merge: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        allow_forking: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        allow_merge_commit: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        allow_rebase_merge: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        allow_squash_merge: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        allow_update_branch: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        archived: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        archive_on_destroy: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        auto_init: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        default_branch: typing.Optional[builtins.str] = None,
        delete_branch_on_merge: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        description: typing.Optional[builtins.str] = None,
        etag: typing.Optional[builtins.str] = None,
        fork: typing.Optional[builtins.str] = None,
        gitignore_template: typing.Optional[builtins.str] = None,
        has_discussions: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        has_downloads: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        has_issues: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        has_projects: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        has_wiki: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        homepage_url: typing.Optional[builtins.str] = None,
        id: typing.Optional[builtins.str] = None,
        ignore_vulnerability_alerts_during_read: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        is_template: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        license_template: typing.Optional[builtins.str] = None,
        merge_commit_message: typing.Optional[builtins.str] = None,
        merge_commit_title: typing.Optional[builtins.str] = None,
        pages: typing.Optional[typing.Union["RepositoryPages", typing.Dict[builtins.str, typing.Any]]] = None,
        private: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        security_and_analysis: typing.Optional[typing.Union["RepositorySecurityAndAnalysis", typing.Dict[builtins.str, typing.Any]]] = None,
        source_owner: typing.Optional[builtins.str] = None,
        source_repo: typing.Optional[builtins.str] = None,
        squash_merge_commit_message: typing.Optional[builtins.str] = None,
        squash_merge_commit_title: typing.Optional[builtins.str] = None,
        template: typing.Optional[typing.Union["RepositoryTemplate", typing.Dict[builtins.str, typing.Any]]] = None,
        topics: typing.Optional[typing.Sequence[builtins.str]] = None,
        visibility: typing.Optional[builtins.str] = None,
        vulnerability_alerts: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        web_commit_signoff_required: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param name: The name of the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#name Repository#name}
        :param allow_auto_merge: Set to 'true' to allow auto-merging pull requests on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_auto_merge Repository#allow_auto_merge}
        :param allow_forking: Set to 'true' to allow private forking on the repository; this is only relevant if the repository is owned by an organization and is private or internal. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_forking Repository#allow_forking}
        :param allow_merge_commit: Set to 'false' to disable merge commits on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_merge_commit Repository#allow_merge_commit}
        :param allow_rebase_merge: Set to 'false' to disable rebase merges on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_rebase_merge Repository#allow_rebase_merge}
        :param allow_squash_merge: Set to 'false' to disable squash merges on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_squash_merge Repository#allow_squash_merge}
        :param allow_update_branch: Set to 'true' to always suggest updating pull request branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_update_branch Repository#allow_update_branch}
        :param archived: Specifies if the repository should be archived. Defaults to 'false'. NOTE Currently, the API does not support unarchiving. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#archived Repository#archived}
        :param archive_on_destroy: Set to 'true' to archive the repository instead of deleting on destroy. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#archive_on_destroy Repository#archive_on_destroy}
        :param auto_init: Set to 'true' to produce an initial commit in the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#auto_init Repository#auto_init}
        :param default_branch: Can only be set after initial repository creation, and only if the target branch exists. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#default_branch Repository#default_branch}
        :param delete_branch_on_merge: Automatically delete head branch after a pull request is merged. Defaults to 'false'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#delete_branch_on_merge Repository#delete_branch_on_merge}
        :param description: A description of the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#description Repository#description}
        :param etag: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#etag Repository#etag}.
        :param fork: Set to 'true' to fork an existing repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#fork Repository#fork}
        :param gitignore_template: Use the name of the template without the extension. For example, 'Haskell'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#gitignore_template Repository#gitignore_template}
        :param has_discussions: Set to 'true' to enable GitHub Discussions on the repository. Defaults to 'false'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_discussions Repository#has_discussions}
        :param has_downloads: Set to 'true' to enable the (deprecated) downloads features on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_downloads Repository#has_downloads}
        :param has_issues: Set to 'true' to enable the GitHub Issues features on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_issues Repository#has_issues}
        :param has_projects: Set to 'true' to enable the GitHub Projects features on the repository. Per the GitHub documentation when in an organization that has disabled repository projects it will default to 'false' and will otherwise default to 'true'. If you specify 'true' when it has been disabled it will return an error. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_projects Repository#has_projects}
        :param has_wiki: Set to 'true' to enable the GitHub Wiki features on the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_wiki Repository#has_wiki}
        :param homepage_url: URL of a page describing the project. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#homepage_url Repository#homepage_url}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#id Repository#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param ignore_vulnerability_alerts_during_read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#ignore_vulnerability_alerts_during_read Repository#ignore_vulnerability_alerts_during_read}.
        :param is_template: Set to 'true' to tell GitHub that this is a template repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#is_template Repository#is_template}
        :param license_template: Use the name of the template without the extension. For example, 'mit' or 'mpl-2.0'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#license_template Repository#license_template}
        :param merge_commit_message: Can be 'PR_BODY', 'PR_TITLE', or 'BLANK' for a default merge commit message. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#merge_commit_message Repository#merge_commit_message}
        :param merge_commit_title: Can be 'PR_TITLE' or 'MERGE_MESSAGE' for a default merge commit title. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#merge_commit_title Repository#merge_commit_title}
        :param pages: pages block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#pages Repository#pages}
        :param private: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#private Repository#private}.
        :param security_and_analysis: security_and_analysis block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#security_and_analysis Repository#security_and_analysis}
        :param source_owner: The owner of the source repository to fork from. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#source_owner Repository#source_owner}
        :param source_repo: The name of the source repository to fork from. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#source_repo Repository#source_repo}
        :param squash_merge_commit_message: Can be 'PR_BODY', 'COMMIT_MESSAGES', or 'BLANK' for a default squash merge commit message. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#squash_merge_commit_message Repository#squash_merge_commit_message}
        :param squash_merge_commit_title: Can be 'PR_TITLE' or 'COMMIT_OR_PR_TITLE' for a default squash merge commit title. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#squash_merge_commit_title Repository#squash_merge_commit_title}
        :param template: template block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#template Repository#template}
        :param topics: The list of topics of the repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#topics Repository#topics}
        :param visibility: Can be 'public' or 'private'. If your organization is associated with an enterprise account using GitHub Enterprise Cloud or GitHub Enterprise Server 2.20+, visibility can also be 'internal'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#visibility Repository#visibility}
        :param vulnerability_alerts: Set to 'true' to enable security alerts for vulnerable dependencies. Enabling requires alerts to be enabled on the owner level. (Note for importing: GitHub enables the alerts on all repos by default). Note that vulnerability alerts have not been successfully tested on any GitHub Enterprise instance and may be unavailable in those settings. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#vulnerability_alerts Repository#vulnerability_alerts}
        :param web_commit_signoff_required: Require contributors to sign off on web-based commits. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#web_commit_signoff_required Repository#web_commit_signoff_required}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(pages, dict):
            pages = RepositoryPages(**pages)
        if isinstance(security_and_analysis, dict):
            security_and_analysis = RepositorySecurityAndAnalysis(**security_and_analysis)
        if isinstance(template, dict):
            template = RepositoryTemplate(**template)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__af8957bc2cf255f1fce459094cb529fbcd88fa8f40ba76c5d6bbb2c5535b9cc2)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument allow_auto_merge", value=allow_auto_merge, expected_type=type_hints["allow_auto_merge"])
            check_type(argname="argument allow_forking", value=allow_forking, expected_type=type_hints["allow_forking"])
            check_type(argname="argument allow_merge_commit", value=allow_merge_commit, expected_type=type_hints["allow_merge_commit"])
            check_type(argname="argument allow_rebase_merge", value=allow_rebase_merge, expected_type=type_hints["allow_rebase_merge"])
            check_type(argname="argument allow_squash_merge", value=allow_squash_merge, expected_type=type_hints["allow_squash_merge"])
            check_type(argname="argument allow_update_branch", value=allow_update_branch, expected_type=type_hints["allow_update_branch"])
            check_type(argname="argument archived", value=archived, expected_type=type_hints["archived"])
            check_type(argname="argument archive_on_destroy", value=archive_on_destroy, expected_type=type_hints["archive_on_destroy"])
            check_type(argname="argument auto_init", value=auto_init, expected_type=type_hints["auto_init"])
            check_type(argname="argument default_branch", value=default_branch, expected_type=type_hints["default_branch"])
            check_type(argname="argument delete_branch_on_merge", value=delete_branch_on_merge, expected_type=type_hints["delete_branch_on_merge"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument etag", value=etag, expected_type=type_hints["etag"])
            check_type(argname="argument fork", value=fork, expected_type=type_hints["fork"])
            check_type(argname="argument gitignore_template", value=gitignore_template, expected_type=type_hints["gitignore_template"])
            check_type(argname="argument has_discussions", value=has_discussions, expected_type=type_hints["has_discussions"])
            check_type(argname="argument has_downloads", value=has_downloads, expected_type=type_hints["has_downloads"])
            check_type(argname="argument has_issues", value=has_issues, expected_type=type_hints["has_issues"])
            check_type(argname="argument has_projects", value=has_projects, expected_type=type_hints["has_projects"])
            check_type(argname="argument has_wiki", value=has_wiki, expected_type=type_hints["has_wiki"])
            check_type(argname="argument homepage_url", value=homepage_url, expected_type=type_hints["homepage_url"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument ignore_vulnerability_alerts_during_read", value=ignore_vulnerability_alerts_during_read, expected_type=type_hints["ignore_vulnerability_alerts_during_read"])
            check_type(argname="argument is_template", value=is_template, expected_type=type_hints["is_template"])
            check_type(argname="argument license_template", value=license_template, expected_type=type_hints["license_template"])
            check_type(argname="argument merge_commit_message", value=merge_commit_message, expected_type=type_hints["merge_commit_message"])
            check_type(argname="argument merge_commit_title", value=merge_commit_title, expected_type=type_hints["merge_commit_title"])
            check_type(argname="argument pages", value=pages, expected_type=type_hints["pages"])
            check_type(argname="argument private", value=private, expected_type=type_hints["private"])
            check_type(argname="argument security_and_analysis", value=security_and_analysis, expected_type=type_hints["security_and_analysis"])
            check_type(argname="argument source_owner", value=source_owner, expected_type=type_hints["source_owner"])
            check_type(argname="argument source_repo", value=source_repo, expected_type=type_hints["source_repo"])
            check_type(argname="argument squash_merge_commit_message", value=squash_merge_commit_message, expected_type=type_hints["squash_merge_commit_message"])
            check_type(argname="argument squash_merge_commit_title", value=squash_merge_commit_title, expected_type=type_hints["squash_merge_commit_title"])
            check_type(argname="argument template", value=template, expected_type=type_hints["template"])
            check_type(argname="argument topics", value=topics, expected_type=type_hints["topics"])
            check_type(argname="argument visibility", value=visibility, expected_type=type_hints["visibility"])
            check_type(argname="argument vulnerability_alerts", value=vulnerability_alerts, expected_type=type_hints["vulnerability_alerts"])
            check_type(argname="argument web_commit_signoff_required", value=web_commit_signoff_required, expected_type=type_hints["web_commit_signoff_required"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "name": name,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if allow_auto_merge is not None:
            self._values["allow_auto_merge"] = allow_auto_merge
        if allow_forking is not None:
            self._values["allow_forking"] = allow_forking
        if allow_merge_commit is not None:
            self._values["allow_merge_commit"] = allow_merge_commit
        if allow_rebase_merge is not None:
            self._values["allow_rebase_merge"] = allow_rebase_merge
        if allow_squash_merge is not None:
            self._values["allow_squash_merge"] = allow_squash_merge
        if allow_update_branch is not None:
            self._values["allow_update_branch"] = allow_update_branch
        if archived is not None:
            self._values["archived"] = archived
        if archive_on_destroy is not None:
            self._values["archive_on_destroy"] = archive_on_destroy
        if auto_init is not None:
            self._values["auto_init"] = auto_init
        if default_branch is not None:
            self._values["default_branch"] = default_branch
        if delete_branch_on_merge is not None:
            self._values["delete_branch_on_merge"] = delete_branch_on_merge
        if description is not None:
            self._values["description"] = description
        if etag is not None:
            self._values["etag"] = etag
        if fork is not None:
            self._values["fork"] = fork
        if gitignore_template is not None:
            self._values["gitignore_template"] = gitignore_template
        if has_discussions is not None:
            self._values["has_discussions"] = has_discussions
        if has_downloads is not None:
            self._values["has_downloads"] = has_downloads
        if has_issues is not None:
            self._values["has_issues"] = has_issues
        if has_projects is not None:
            self._values["has_projects"] = has_projects
        if has_wiki is not None:
            self._values["has_wiki"] = has_wiki
        if homepage_url is not None:
            self._values["homepage_url"] = homepage_url
        if id is not None:
            self._values["id"] = id
        if ignore_vulnerability_alerts_during_read is not None:
            self._values["ignore_vulnerability_alerts_during_read"] = ignore_vulnerability_alerts_during_read
        if is_template is not None:
            self._values["is_template"] = is_template
        if license_template is not None:
            self._values["license_template"] = license_template
        if merge_commit_message is not None:
            self._values["merge_commit_message"] = merge_commit_message
        if merge_commit_title is not None:
            self._values["merge_commit_title"] = merge_commit_title
        if pages is not None:
            self._values["pages"] = pages
        if private is not None:
            self._values["private"] = private
        if security_and_analysis is not None:
            self._values["security_and_analysis"] = security_and_analysis
        if source_owner is not None:
            self._values["source_owner"] = source_owner
        if source_repo is not None:
            self._values["source_repo"] = source_repo
        if squash_merge_commit_message is not None:
            self._values["squash_merge_commit_message"] = squash_merge_commit_message
        if squash_merge_commit_title is not None:
            self._values["squash_merge_commit_title"] = squash_merge_commit_title
        if template is not None:
            self._values["template"] = template
        if topics is not None:
            self._values["topics"] = topics
        if visibility is not None:
            self._values["visibility"] = visibility
        if vulnerability_alerts is not None:
            self._values["vulnerability_alerts"] = vulnerability_alerts
        if web_commit_signoff_required is not None:
            self._values["web_commit_signoff_required"] = web_commit_signoff_required

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def name(self) -> builtins.str:
        '''The name of the repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#name Repository#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def allow_auto_merge(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to allow auto-merging pull requests on the repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_auto_merge Repository#allow_auto_merge}
        '''
        result = self._values.get("allow_auto_merge")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def allow_forking(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to allow private forking on the repository;

        this is only relevant if the repository is owned by an organization and is private or internal.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_forking Repository#allow_forking}
        '''
        result = self._values.get("allow_forking")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def allow_merge_commit(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'false' to disable merge commits on the repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_merge_commit Repository#allow_merge_commit}
        '''
        result = self._values.get("allow_merge_commit")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def allow_rebase_merge(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'false' to disable rebase merges on the repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_rebase_merge Repository#allow_rebase_merge}
        '''
        result = self._values.get("allow_rebase_merge")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def allow_squash_merge(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'false' to disable squash merges on the repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_squash_merge Repository#allow_squash_merge}
        '''
        result = self._values.get("allow_squash_merge")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def allow_update_branch(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to always suggest updating pull request branches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#allow_update_branch Repository#allow_update_branch}
        '''
        result = self._values.get("allow_update_branch")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def archived(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Specifies if the repository should be archived. Defaults to 'false'. NOTE Currently, the API does not support unarchiving.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#archived Repository#archived}
        '''
        result = self._values.get("archived")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def archive_on_destroy(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to archive the repository instead of deleting on destroy.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#archive_on_destroy Repository#archive_on_destroy}
        '''
        result = self._values.get("archive_on_destroy")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def auto_init(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to produce an initial commit in the repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#auto_init Repository#auto_init}
        '''
        result = self._values.get("auto_init")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def default_branch(self) -> typing.Optional[builtins.str]:
        '''Can only be set after initial repository creation, and only if the target branch exists.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#default_branch Repository#default_branch}
        '''
        result = self._values.get("default_branch")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete_branch_on_merge(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Automatically delete head branch after a pull request is merged. Defaults to 'false'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#delete_branch_on_merge Repository#delete_branch_on_merge}
        '''
        result = self._values.get("delete_branch_on_merge")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''A description of the repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#description Repository#description}
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def etag(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#etag Repository#etag}.'''
        result = self._values.get("etag")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def fork(self) -> typing.Optional[builtins.str]:
        '''Set to 'true' to fork an existing repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#fork Repository#fork}
        '''
        result = self._values.get("fork")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def gitignore_template(self) -> typing.Optional[builtins.str]:
        '''Use the name of the template without the extension. For example, 'Haskell'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#gitignore_template Repository#gitignore_template}
        '''
        result = self._values.get("gitignore_template")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def has_discussions(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to enable GitHub Discussions on the repository. Defaults to 'false'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_discussions Repository#has_discussions}
        '''
        result = self._values.get("has_discussions")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def has_downloads(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to enable the (deprecated) downloads features on the repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_downloads Repository#has_downloads}
        '''
        result = self._values.get("has_downloads")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def has_issues(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to enable the GitHub Issues features on the repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_issues Repository#has_issues}
        '''
        result = self._values.get("has_issues")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def has_projects(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to enable the GitHub Projects features on the repository.

        Per the GitHub documentation when in an organization that has disabled repository projects it will default to 'false' and will otherwise default to 'true'. If you specify 'true' when it has been disabled it will return an error.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_projects Repository#has_projects}
        '''
        result = self._values.get("has_projects")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def has_wiki(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to enable the GitHub Wiki features on the repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#has_wiki Repository#has_wiki}
        '''
        result = self._values.get("has_wiki")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def homepage_url(self) -> typing.Optional[builtins.str]:
        '''URL of a page describing the project.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#homepage_url Repository#homepage_url}
        '''
        result = self._values.get("homepage_url")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#id Repository#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ignore_vulnerability_alerts_during_read(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#ignore_vulnerability_alerts_during_read Repository#ignore_vulnerability_alerts_during_read}.'''
        result = self._values.get("ignore_vulnerability_alerts_during_read")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def is_template(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to tell GitHub that this is a template repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#is_template Repository#is_template}
        '''
        result = self._values.get("is_template")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def license_template(self) -> typing.Optional[builtins.str]:
        '''Use the name of the template without the extension. For example, 'mit' or 'mpl-2.0'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#license_template Repository#license_template}
        '''
        result = self._values.get("license_template")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def merge_commit_message(self) -> typing.Optional[builtins.str]:
        '''Can be 'PR_BODY', 'PR_TITLE', or 'BLANK' for a default merge commit message.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#merge_commit_message Repository#merge_commit_message}
        '''
        result = self._values.get("merge_commit_message")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def merge_commit_title(self) -> typing.Optional[builtins.str]:
        '''Can be 'PR_TITLE' or 'MERGE_MESSAGE' for a default merge commit title.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#merge_commit_title Repository#merge_commit_title}
        '''
        result = self._values.get("merge_commit_title")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def pages(self) -> typing.Optional["RepositoryPages"]:
        '''pages block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#pages Repository#pages}
        '''
        result = self._values.get("pages")
        return typing.cast(typing.Optional["RepositoryPages"], result)

    @builtins.property
    def private(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#private Repository#private}.'''
        result = self._values.get("private")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def security_and_analysis(self) -> typing.Optional["RepositorySecurityAndAnalysis"]:
        '''security_and_analysis block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#security_and_analysis Repository#security_and_analysis}
        '''
        result = self._values.get("security_and_analysis")
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysis"], result)

    @builtins.property
    def source_owner(self) -> typing.Optional[builtins.str]:
        '''The owner of the source repository to fork from.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#source_owner Repository#source_owner}
        '''
        result = self._values.get("source_owner")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def source_repo(self) -> typing.Optional[builtins.str]:
        '''The name of the source repository to fork from.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#source_repo Repository#source_repo}
        '''
        result = self._values.get("source_repo")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def squash_merge_commit_message(self) -> typing.Optional[builtins.str]:
        '''Can be 'PR_BODY', 'COMMIT_MESSAGES', or 'BLANK' for a default squash merge commit message.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#squash_merge_commit_message Repository#squash_merge_commit_message}
        '''
        result = self._values.get("squash_merge_commit_message")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def squash_merge_commit_title(self) -> typing.Optional[builtins.str]:
        '''Can be 'PR_TITLE' or 'COMMIT_OR_PR_TITLE' for a default squash merge commit title.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#squash_merge_commit_title Repository#squash_merge_commit_title}
        '''
        result = self._values.get("squash_merge_commit_title")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def template(self) -> typing.Optional["RepositoryTemplate"]:
        '''template block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#template Repository#template}
        '''
        result = self._values.get("template")
        return typing.cast(typing.Optional["RepositoryTemplate"], result)

    @builtins.property
    def topics(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The list of topics of the repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#topics Repository#topics}
        '''
        result = self._values.get("topics")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def visibility(self) -> typing.Optional[builtins.str]:
        '''Can be 'public' or 'private'.

        If your organization is associated with an enterprise account using GitHub Enterprise Cloud or GitHub Enterprise Server 2.20+, visibility can also be 'internal'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#visibility Repository#visibility}
        '''
        result = self._values.get("visibility")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def vulnerability_alerts(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Set to 'true' to enable security alerts for vulnerable dependencies.

        Enabling requires alerts to be enabled on the owner level. (Note for importing: GitHub enables the alerts on all repos by default). Note that vulnerability alerts have not been successfully tested on any GitHub Enterprise instance and may be unavailable in those settings.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#vulnerability_alerts Repository#vulnerability_alerts}
        '''
        result = self._values.get("vulnerability_alerts")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def web_commit_signoff_required(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Require contributors to sign off on web-based commits.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#web_commit_signoff_required Repository#web_commit_signoff_required}
        '''
        result = self._values.get("web_commit_signoff_required")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repository.RepositoryPages",
    jsii_struct_bases=[],
    name_mapping={"build_type": "buildType", "cname": "cname", "source": "source"},
)
class RepositoryPages:
    def __init__(
        self,
        *,
        build_type: typing.Optional[builtins.str] = None,
        cname: typing.Optional[builtins.str] = None,
        source: typing.Optional[typing.Union["RepositoryPagesSource", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param build_type: The type the page should be sourced. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#build_type Repository#build_type}
        :param cname: The custom domain for the repository. This can only be set after the repository has been created. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#cname Repository#cname}
        :param source: source block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#source Repository#source}
        '''
        if isinstance(source, dict):
            source = RepositoryPagesSource(**source)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a48f884febab484d58d5e1ddd8ea53a53f7f5e8756d05dd757b92c008116fd8d)
            check_type(argname="argument build_type", value=build_type, expected_type=type_hints["build_type"])
            check_type(argname="argument cname", value=cname, expected_type=type_hints["cname"])
            check_type(argname="argument source", value=source, expected_type=type_hints["source"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if build_type is not None:
            self._values["build_type"] = build_type
        if cname is not None:
            self._values["cname"] = cname
        if source is not None:
            self._values["source"] = source

    @builtins.property
    def build_type(self) -> typing.Optional[builtins.str]:
        '''The type the page should be sourced.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#build_type Repository#build_type}
        '''
        result = self._values.get("build_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def cname(self) -> typing.Optional[builtins.str]:
        '''The custom domain for the repository. This can only be set after the repository has been created.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#cname Repository#cname}
        '''
        result = self._values.get("cname")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def source(self) -> typing.Optional["RepositoryPagesSource"]:
        '''source block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#source Repository#source}
        '''
        result = self._values.get("source")
        return typing.cast(typing.Optional["RepositoryPagesSource"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryPages(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryPagesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repository.RepositoryPagesOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__45083b694dd8e188f111fcf0e5d21200815999fa1b623636d6dd2a1ddb394782)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putSource")
    def put_source(
        self,
        *,
        branch: builtins.str,
        path: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param branch: The repository branch used to publish the site's source files. (i.e. 'main' or 'gh-pages'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#branch Repository#branch}
        :param path: The repository directory from which the site publishes (Default: '/'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#path Repository#path}
        '''
        value = RepositoryPagesSource(branch=branch, path=path)

        return typing.cast(None, jsii.invoke(self, "putSource", [value]))

    @jsii.member(jsii_name="resetBuildType")
    def reset_build_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBuildType", []))

    @jsii.member(jsii_name="resetCname")
    def reset_cname(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCname", []))

    @jsii.member(jsii_name="resetSource")
    def reset_source(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSource", []))

    @builtins.property
    @jsii.member(jsii_name="custom404")
    def custom404(self) -> "_cdktn_78ede62e.IResolvable":
        return typing.cast("_cdktn_78ede62e.IResolvable", jsii.get(self, "custom404"))

    @builtins.property
    @jsii.member(jsii_name="htmlUrl")
    def html_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "htmlUrl"))

    @builtins.property
    @jsii.member(jsii_name="source")
    def source(self) -> "RepositoryPagesSourceOutputReference":
        return typing.cast("RepositoryPagesSourceOutputReference", jsii.get(self, "source"))

    @builtins.property
    @jsii.member(jsii_name="status")
    def status(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "status"))

    @builtins.property
    @jsii.member(jsii_name="url")
    def url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "url"))

    @builtins.property
    @jsii.member(jsii_name="buildTypeInput")
    def build_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "buildTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="cnameInput")
    def cname_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "cnameInput"))

    @builtins.property
    @jsii.member(jsii_name="sourceInput")
    def source_input(self) -> typing.Optional["RepositoryPagesSource"]:
        return typing.cast(typing.Optional["RepositoryPagesSource"], jsii.get(self, "sourceInput"))

    @builtins.property
    @jsii.member(jsii_name="buildType")
    def build_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "buildType"))

    @build_type.setter
    def build_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__801ce0707e7c1e0971c389ed735276444bd7b67177b2532b568a45ec8a8e10a9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "buildType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="cname")
    def cname(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "cname"))

    @cname.setter
    def cname(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__17f18246afb7bdbec2b467ec48981c91815974e1c40c3b5928ec8ce66fd11563)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "cname", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["RepositoryPages"]:
        return typing.cast(typing.Optional["RepositoryPages"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional["RepositoryPages"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b9794961427808344d2832c6e994029ae7e7c66e0f424e16b43f7d918a641ea2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repository.RepositoryPagesSource",
    jsii_struct_bases=[],
    name_mapping={"branch": "branch", "path": "path"},
)
class RepositoryPagesSource:
    def __init__(
        self,
        *,
        branch: builtins.str,
        path: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param branch: The repository branch used to publish the site's source files. (i.e. 'main' or 'gh-pages'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#branch Repository#branch}
        :param path: The repository directory from which the site publishes (Default: '/'). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#path Repository#path}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__847359ffa92fdf54e651e9fcc79f974750426d7fad69e04004774d18c90e5425)
            check_type(argname="argument branch", value=branch, expected_type=type_hints["branch"])
            check_type(argname="argument path", value=path, expected_type=type_hints["path"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "branch": branch,
        }
        if path is not None:
            self._values["path"] = path

    @builtins.property
    def branch(self) -> builtins.str:
        '''The repository branch used to publish the site's source files. (i.e. 'main' or 'gh-pages').

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#branch Repository#branch}
        '''
        result = self._values.get("branch")
        assert result is not None, "Required property 'branch' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def path(self) -> typing.Optional[builtins.str]:
        '''The repository directory from which the site publishes (Default: '/').

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#path Repository#path}
        '''
        result = self._values.get("path")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryPagesSource(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryPagesSourceOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repository.RepositoryPagesSourceOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a4fc90bfcfd6494f05c83cc96ea1196451851ca73275d81db741c98e479f3355)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetPath")
    def reset_path(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPath", []))

    @builtins.property
    @jsii.member(jsii_name="branchInput")
    def branch_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "branchInput"))

    @builtins.property
    @jsii.member(jsii_name="pathInput")
    def path_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "pathInput"))

    @builtins.property
    @jsii.member(jsii_name="branch")
    def branch(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "branch"))

    @branch.setter
    def branch(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a558a9ad09f7e76d3913ce83334029a772f58ca56c25344d1cd4b20470240b3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "branch", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="path")
    def path(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "path"))

    @path.setter
    def path(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d0181b9b2b08d67a137dd6237c74b4540c12249909d4d2f6fd2e1d96e5288adb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "path", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["RepositoryPagesSource"]:
        return typing.cast(typing.Optional["RepositoryPagesSource"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional["RepositoryPagesSource"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9846ade5f77dfa0fa85e664046e919277f20bad64b36a0d5d68a040fdfcc1b9d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysis",
    jsii_struct_bases=[],
    name_mapping={
        "advanced_security": "advancedSecurity",
        "code_security": "codeSecurity",
        "secret_scanning": "secretScanning",
        "secret_scanning_ai_detection": "secretScanningAiDetection",
        "secret_scanning_non_provider_patterns": "secretScanningNonProviderPatterns",
        "secret_scanning_push_protection": "secretScanningPushProtection",
    },
)
class RepositorySecurityAndAnalysis:
    def __init__(
        self,
        *,
        advanced_security: typing.Optional[typing.Union["RepositorySecurityAndAnalysisAdvancedSecurity", typing.Dict[builtins.str, typing.Any]]] = None,
        code_security: typing.Optional[typing.Union["RepositorySecurityAndAnalysisCodeSecurity", typing.Dict[builtins.str, typing.Any]]] = None,
        secret_scanning: typing.Optional[typing.Union["RepositorySecurityAndAnalysisSecretScanning", typing.Dict[builtins.str, typing.Any]]] = None,
        secret_scanning_ai_detection: typing.Optional[typing.Union["RepositorySecurityAndAnalysisSecretScanningAiDetection", typing.Dict[builtins.str, typing.Any]]] = None,
        secret_scanning_non_provider_patterns: typing.Optional[typing.Union["RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns", typing.Dict[builtins.str, typing.Any]]] = None,
        secret_scanning_push_protection: typing.Optional[typing.Union["RepositorySecurityAndAnalysisSecretScanningPushProtection", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param advanced_security: advanced_security block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#advanced_security Repository#advanced_security}
        :param code_security: code_security block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#code_security Repository#code_security}
        :param secret_scanning: secret_scanning block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning Repository#secret_scanning}
        :param secret_scanning_ai_detection: secret_scanning_ai_detection block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning_ai_detection Repository#secret_scanning_ai_detection}
        :param secret_scanning_non_provider_patterns: secret_scanning_non_provider_patterns block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning_non_provider_patterns Repository#secret_scanning_non_provider_patterns}
        :param secret_scanning_push_protection: secret_scanning_push_protection block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning_push_protection Repository#secret_scanning_push_protection}
        '''
        if isinstance(advanced_security, dict):
            advanced_security = RepositorySecurityAndAnalysisAdvancedSecurity(**advanced_security)
        if isinstance(code_security, dict):
            code_security = RepositorySecurityAndAnalysisCodeSecurity(**code_security)
        if isinstance(secret_scanning, dict):
            secret_scanning = RepositorySecurityAndAnalysisSecretScanning(**secret_scanning)
        if isinstance(secret_scanning_ai_detection, dict):
            secret_scanning_ai_detection = RepositorySecurityAndAnalysisSecretScanningAiDetection(**secret_scanning_ai_detection)
        if isinstance(secret_scanning_non_provider_patterns, dict):
            secret_scanning_non_provider_patterns = RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns(**secret_scanning_non_provider_patterns)
        if isinstance(secret_scanning_push_protection, dict):
            secret_scanning_push_protection = RepositorySecurityAndAnalysisSecretScanningPushProtection(**secret_scanning_push_protection)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2eb2a1dd372daf0c8493be96bad85bf92b2086f3848738bc351c1ea158d48935)
            check_type(argname="argument advanced_security", value=advanced_security, expected_type=type_hints["advanced_security"])
            check_type(argname="argument code_security", value=code_security, expected_type=type_hints["code_security"])
            check_type(argname="argument secret_scanning", value=secret_scanning, expected_type=type_hints["secret_scanning"])
            check_type(argname="argument secret_scanning_ai_detection", value=secret_scanning_ai_detection, expected_type=type_hints["secret_scanning_ai_detection"])
            check_type(argname="argument secret_scanning_non_provider_patterns", value=secret_scanning_non_provider_patterns, expected_type=type_hints["secret_scanning_non_provider_patterns"])
            check_type(argname="argument secret_scanning_push_protection", value=secret_scanning_push_protection, expected_type=type_hints["secret_scanning_push_protection"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if advanced_security is not None:
            self._values["advanced_security"] = advanced_security
        if code_security is not None:
            self._values["code_security"] = code_security
        if secret_scanning is not None:
            self._values["secret_scanning"] = secret_scanning
        if secret_scanning_ai_detection is not None:
            self._values["secret_scanning_ai_detection"] = secret_scanning_ai_detection
        if secret_scanning_non_provider_patterns is not None:
            self._values["secret_scanning_non_provider_patterns"] = secret_scanning_non_provider_patterns
        if secret_scanning_push_protection is not None:
            self._values["secret_scanning_push_protection"] = secret_scanning_push_protection

    @builtins.property
    def advanced_security(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisAdvancedSecurity"]:
        '''advanced_security block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#advanced_security Repository#advanced_security}
        '''
        result = self._values.get("advanced_security")
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisAdvancedSecurity"], result)

    @builtins.property
    def code_security(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisCodeSecurity"]:
        '''code_security block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#code_security Repository#code_security}
        '''
        result = self._values.get("code_security")
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisCodeSecurity"], result)

    @builtins.property
    def secret_scanning(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanning"]:
        '''secret_scanning block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning Repository#secret_scanning}
        '''
        result = self._values.get("secret_scanning")
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanning"], result)

    @builtins.property
    def secret_scanning_ai_detection(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanningAiDetection"]:
        '''secret_scanning_ai_detection block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning_ai_detection Repository#secret_scanning_ai_detection}
        '''
        result = self._values.get("secret_scanning_ai_detection")
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanningAiDetection"], result)

    @builtins.property
    def secret_scanning_non_provider_patterns(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns"]:
        '''secret_scanning_non_provider_patterns block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning_non_provider_patterns Repository#secret_scanning_non_provider_patterns}
        '''
        result = self._values.get("secret_scanning_non_provider_patterns")
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns"], result)

    @builtins.property
    def secret_scanning_push_protection(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanningPushProtection"]:
        '''secret_scanning_push_protection block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#secret_scanning_push_protection Repository#secret_scanning_push_protection}
        '''
        result = self._values.get("secret_scanning_push_protection")
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanningPushProtection"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositorySecurityAndAnalysis(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisAdvancedSecurity",
    jsii_struct_bases=[],
    name_mapping={"status": "status"},
)
class RepositorySecurityAndAnalysisAdvancedSecurity:
    def __init__(self, *, status: builtins.str) -> None:
        '''
        :param status: Set to 'enabled' to enable advanced security features on the repository. Can be 'enabled' or 'disabled', This value being present when split licensing is enabled will error out. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1ac7bcf7e688f25d72807232b593de3bc3df1bdb10f36cd66b4d3a2c87dd96e1)
            check_type(argname="argument status", value=status, expected_type=type_hints["status"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "status": status,
        }

    @builtins.property
    def status(self) -> builtins.str:
        '''Set to 'enabled' to enable advanced security features on the repository.

        Can be 'enabled' or 'disabled', This value being present when split licensing is enabled will error out.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        result = self._values.get("status")
        assert result is not None, "Required property 'status' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositorySecurityAndAnalysisAdvancedSecurity(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositorySecurityAndAnalysisAdvancedSecurityOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisAdvancedSecurityOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__53ad4bf654ff1c43f21448dec9be75cdb154a16adf2caca1254f9acedac9effb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="statusInput")
    def status_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "statusInput"))

    @builtins.property
    @jsii.member(jsii_name="status")
    def status(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "status"))

    @status.setter
    def status(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8184921460400cd1270af9293d9c15ec16c3e5e8b3c6e0ce7a7e2fa92969a1d9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "status", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisAdvancedSecurity"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisAdvancedSecurity"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositorySecurityAndAnalysisAdvancedSecurity"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__01e988fc8ac2a52efc0b6542d7f582859360360c7ae6d7476c1c9966714a1540)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisCodeSecurity",
    jsii_struct_bases=[],
    name_mapping={"status": "status"},
)
class RepositorySecurityAndAnalysisCodeSecurity:
    def __init__(self, *, status: builtins.str) -> None:
        '''
        :param status: Set to 'enabled' to enable code security on the repository. Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d4b9d84197cef5f516c5550e987d179951b896b435216d878cfe61b3ab762b70)
            check_type(argname="argument status", value=status, expected_type=type_hints["status"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "status": status,
        }

    @builtins.property
    def status(self) -> builtins.str:
        '''Set to 'enabled' to enable code security on the repository.

        Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        result = self._values.get("status")
        assert result is not None, "Required property 'status' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositorySecurityAndAnalysisCodeSecurity(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositorySecurityAndAnalysisCodeSecurityOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisCodeSecurityOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1854d5d8361d46d38db3c9e995bee358a3b953a12db862ee08420c2056d99be6)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="statusInput")
    def status_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "statusInput"))

    @builtins.property
    @jsii.member(jsii_name="status")
    def status(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "status"))

    @status.setter
    def status(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8b94ce906449459d0eebd725e5ae5c60698f0c719185640031cf2f5c61e61999)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "status", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisCodeSecurity"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisCodeSecurity"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositorySecurityAndAnalysisCodeSecurity"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f97b04b11ed8f6d1129a9154f762d4948a20ada8181ba296706bace6b7b359da)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class RepositorySecurityAndAnalysisOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d96911f011a8124593c65bd82a27ec441774ba1c85ef6539c2a41d255e6c40dc)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putAdvancedSecurity")
    def put_advanced_security(self, *, status: builtins.str) -> None:
        '''
        :param status: Set to 'enabled' to enable advanced security features on the repository. Can be 'enabled' or 'disabled', This value being present when split licensing is enabled will error out. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        value = RepositorySecurityAndAnalysisAdvancedSecurity(status=status)

        return typing.cast(None, jsii.invoke(self, "putAdvancedSecurity", [value]))

    @jsii.member(jsii_name="putCodeSecurity")
    def put_code_security(self, *, status: builtins.str) -> None:
        '''
        :param status: Set to 'enabled' to enable code security on the repository. Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        value = RepositorySecurityAndAnalysisCodeSecurity(status=status)

        return typing.cast(None, jsii.invoke(self, "putCodeSecurity", [value]))

    @jsii.member(jsii_name="putSecretScanning")
    def put_secret_scanning(self, *, status: builtins.str) -> None:
        '''
        :param status: Set to 'enabled' to enable secret scanning on the repository. Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        value = RepositorySecurityAndAnalysisSecretScanning(status=status)

        return typing.cast(None, jsii.invoke(self, "putSecretScanning", [value]))

    @jsii.member(jsii_name="putSecretScanningAiDetection")
    def put_secret_scanning_ai_detection(self, *, status: builtins.str) -> None:
        '''
        :param status: Set to 'enabled' to enable secret scanning AI detection on the repository. Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        value = RepositorySecurityAndAnalysisSecretScanningAiDetection(status=status)

        return typing.cast(None, jsii.invoke(self, "putSecretScanningAiDetection", [value]))

    @jsii.member(jsii_name="putSecretScanningNonProviderPatterns")
    def put_secret_scanning_non_provider_patterns(
        self,
        *,
        status: builtins.str,
    ) -> None:
        '''
        :param status: Set to 'enabled' to enable secret scanning non-provider patterns on the repository. Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        value = RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns(
            status=status
        )

        return typing.cast(None, jsii.invoke(self, "putSecretScanningNonProviderPatterns", [value]))

    @jsii.member(jsii_name="putSecretScanningPushProtection")
    def put_secret_scanning_push_protection(self, *, status: builtins.str) -> None:
        '''
        :param status: Set to 'enabled' to enable secret scanning push protection on the repository. Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        value = RepositorySecurityAndAnalysisSecretScanningPushProtection(
            status=status
        )

        return typing.cast(None, jsii.invoke(self, "putSecretScanningPushProtection", [value]))

    @jsii.member(jsii_name="resetAdvancedSecurity")
    def reset_advanced_security(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdvancedSecurity", []))

    @jsii.member(jsii_name="resetCodeSecurity")
    def reset_code_security(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCodeSecurity", []))

    @jsii.member(jsii_name="resetSecretScanning")
    def reset_secret_scanning(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSecretScanning", []))

    @jsii.member(jsii_name="resetSecretScanningAiDetection")
    def reset_secret_scanning_ai_detection(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSecretScanningAiDetection", []))

    @jsii.member(jsii_name="resetSecretScanningNonProviderPatterns")
    def reset_secret_scanning_non_provider_patterns(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSecretScanningNonProviderPatterns", []))

    @jsii.member(jsii_name="resetSecretScanningPushProtection")
    def reset_secret_scanning_push_protection(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSecretScanningPushProtection", []))

    @builtins.property
    @jsii.member(jsii_name="advancedSecurity")
    def advanced_security(
        self,
    ) -> "RepositorySecurityAndAnalysisAdvancedSecurityOutputReference":
        return typing.cast("RepositorySecurityAndAnalysisAdvancedSecurityOutputReference", jsii.get(self, "advancedSecurity"))

    @builtins.property
    @jsii.member(jsii_name="codeSecurity")
    def code_security(
        self,
    ) -> "RepositorySecurityAndAnalysisCodeSecurityOutputReference":
        return typing.cast("RepositorySecurityAndAnalysisCodeSecurityOutputReference", jsii.get(self, "codeSecurity"))

    @builtins.property
    @jsii.member(jsii_name="secretScanning")
    def secret_scanning(
        self,
    ) -> "RepositorySecurityAndAnalysisSecretScanningOutputReference":
        return typing.cast("RepositorySecurityAndAnalysisSecretScanningOutputReference", jsii.get(self, "secretScanning"))

    @builtins.property
    @jsii.member(jsii_name="secretScanningAiDetection")
    def secret_scanning_ai_detection(
        self,
    ) -> "RepositorySecurityAndAnalysisSecretScanningAiDetectionOutputReference":
        return typing.cast("RepositorySecurityAndAnalysisSecretScanningAiDetectionOutputReference", jsii.get(self, "secretScanningAiDetection"))

    @builtins.property
    @jsii.member(jsii_name="secretScanningNonProviderPatterns")
    def secret_scanning_non_provider_patterns(
        self,
    ) -> "RepositorySecurityAndAnalysisSecretScanningNonProviderPatternsOutputReference":
        return typing.cast("RepositorySecurityAndAnalysisSecretScanningNonProviderPatternsOutputReference", jsii.get(self, "secretScanningNonProviderPatterns"))

    @builtins.property
    @jsii.member(jsii_name="secretScanningPushProtection")
    def secret_scanning_push_protection(
        self,
    ) -> "RepositorySecurityAndAnalysisSecretScanningPushProtectionOutputReference":
        return typing.cast("RepositorySecurityAndAnalysisSecretScanningPushProtectionOutputReference", jsii.get(self, "secretScanningPushProtection"))

    @builtins.property
    @jsii.member(jsii_name="advancedSecurityInput")
    def advanced_security_input(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisAdvancedSecurity"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisAdvancedSecurity"], jsii.get(self, "advancedSecurityInput"))

    @builtins.property
    @jsii.member(jsii_name="codeSecurityInput")
    def code_security_input(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisCodeSecurity"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisCodeSecurity"], jsii.get(self, "codeSecurityInput"))

    @builtins.property
    @jsii.member(jsii_name="secretScanningAiDetectionInput")
    def secret_scanning_ai_detection_input(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanningAiDetection"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanningAiDetection"], jsii.get(self, "secretScanningAiDetectionInput"))

    @builtins.property
    @jsii.member(jsii_name="secretScanningInput")
    def secret_scanning_input(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanning"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanning"], jsii.get(self, "secretScanningInput"))

    @builtins.property
    @jsii.member(jsii_name="secretScanningNonProviderPatternsInput")
    def secret_scanning_non_provider_patterns_input(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns"], jsii.get(self, "secretScanningNonProviderPatternsInput"))

    @builtins.property
    @jsii.member(jsii_name="secretScanningPushProtectionInput")
    def secret_scanning_push_protection_input(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanningPushProtection"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanningPushProtection"], jsii.get(self, "secretScanningPushProtectionInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["RepositorySecurityAndAnalysis"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysis"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositorySecurityAndAnalysis"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6aa6fd76430895798bff508728faae2ee61121fed67f5fb54a4cd34446034ca0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisSecretScanning",
    jsii_struct_bases=[],
    name_mapping={"status": "status"},
)
class RepositorySecurityAndAnalysisSecretScanning:
    def __init__(self, *, status: builtins.str) -> None:
        '''
        :param status: Set to 'enabled' to enable secret scanning on the repository. Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a71a3da4893b0b6f9c475b85efe8be15aa013e45978a540763c3d86b23a5b65)
            check_type(argname="argument status", value=status, expected_type=type_hints["status"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "status": status,
        }

    @builtins.property
    def status(self) -> builtins.str:
        '''Set to 'enabled' to enable secret scanning on the repository.

        Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        result = self._values.get("status")
        assert result is not None, "Required property 'status' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositorySecurityAndAnalysisSecretScanning(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisSecretScanningAiDetection",
    jsii_struct_bases=[],
    name_mapping={"status": "status"},
)
class RepositorySecurityAndAnalysisSecretScanningAiDetection:
    def __init__(self, *, status: builtins.str) -> None:
        '''
        :param status: Set to 'enabled' to enable secret scanning AI detection on the repository. Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__162927f66c080711a44e7d076fd42b0dfb7a856ae62785d517da898ec3bdd5c1)
            check_type(argname="argument status", value=status, expected_type=type_hints["status"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "status": status,
        }

    @builtins.property
    def status(self) -> builtins.str:
        '''Set to 'enabled' to enable secret scanning AI detection on the repository.

        Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        result = self._values.get("status")
        assert result is not None, "Required property 'status' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositorySecurityAndAnalysisSecretScanningAiDetection(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositorySecurityAndAnalysisSecretScanningAiDetectionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisSecretScanningAiDetectionOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3aebd3d1785aa5c2c0c69e9066c15c1a759ce8e19f5a8f49f5eb865f43c9e248)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="statusInput")
    def status_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "statusInput"))

    @builtins.property
    @jsii.member(jsii_name="status")
    def status(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "status"))

    @status.setter
    def status(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1dce71226f59d916e5eeea89938d30e644aba835a8b21f332bc81c6599120a4b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "status", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanningAiDetection"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanningAiDetection"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositorySecurityAndAnalysisSecretScanningAiDetection"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5cd254425cac417554946e8f8b4ba1b2491eb3986014bb003c2f17425eba78de)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns",
    jsii_struct_bases=[],
    name_mapping={"status": "status"},
)
class RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns:
    def __init__(self, *, status: builtins.str) -> None:
        '''
        :param status: Set to 'enabled' to enable secret scanning non-provider patterns on the repository. Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3eda12a596573ae2db56e0740a2ecd89dfed921096372a34c2bbadc5c42cfe33)
            check_type(argname="argument status", value=status, expected_type=type_hints["status"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "status": status,
        }

    @builtins.property
    def status(self) -> builtins.str:
        '''Set to 'enabled' to enable secret scanning non-provider patterns on the repository.

        Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        result = self._values.get("status")
        assert result is not None, "Required property 'status' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositorySecurityAndAnalysisSecretScanningNonProviderPatternsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisSecretScanningNonProviderPatternsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__37e562ce5f3033eba79f4a3a8c0cf6ccce24b5a52f4d9237c216217aad8e31fb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="statusInput")
    def status_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "statusInput"))

    @builtins.property
    @jsii.member(jsii_name="status")
    def status(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "status"))

    @status.setter
    def status(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cae11d46bded0822cf6655adcae746c3b39a0a9866f5902d08b5ec46cfbc9a34)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "status", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__351604159d14bb43c7eca59f9d0eeb58f0c2aee4286d9a7e8b1656e22e2775b1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class RepositorySecurityAndAnalysisSecretScanningOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisSecretScanningOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2ab86a2a07962eccbe5bea522a9dd57ea44954c4f5332377fe15f3f7c3917419)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="statusInput")
    def status_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "statusInput"))

    @builtins.property
    @jsii.member(jsii_name="status")
    def status(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "status"))

    @status.setter
    def status(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a0d68871618417dac8934e54e75bdc9292c94b2d0784c9963e401989cd9e628)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "status", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanning"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanning"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositorySecurityAndAnalysisSecretScanning"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__75fcb88b2ba4083290d95ed83d01a669729703e23a10e67ee94a6eff48d173d6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisSecretScanningPushProtection",
    jsii_struct_bases=[],
    name_mapping={"status": "status"},
)
class RepositorySecurityAndAnalysisSecretScanningPushProtection:
    def __init__(self, *, status: builtins.str) -> None:
        '''
        :param status: Set to 'enabled' to enable secret scanning push protection on the repository. Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38e053491afb8d1d1e09866528d9b30f715dbcffbc789a662628726a78ddc7d5)
            check_type(argname="argument status", value=status, expected_type=type_hints["status"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "status": status,
        }

    @builtins.property
    def status(self) -> builtins.str:
        '''Set to 'enabled' to enable secret scanning push protection on the repository.

        Can be 'enabled' or 'disabled'. If set to 'enabled', the repository's visibility must be 'public', 'security_and_analysis[0].advanced_security[0].status' must also be set to 'enabled', or your Organization must have split licensing for Advanced security.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#status Repository#status}
        '''
        result = self._values.get("status")
        assert result is not None, "Required property 'status' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositorySecurityAndAnalysisSecretScanningPushProtection(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositorySecurityAndAnalysisSecretScanningPushProtectionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repository.RepositorySecurityAndAnalysisSecretScanningPushProtectionOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__47989cf21ee1909fda162796e254314ba46b64b535743ea27c4cba854934e9bd)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="statusInput")
    def status_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "statusInput"))

    @builtins.property
    @jsii.member(jsii_name="status")
    def status(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "status"))

    @status.setter
    def status(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8b93a81fed3477b88e23a410562e6c66cd53837911ad696a021fa4c07de9b8c5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "status", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositorySecurityAndAnalysisSecretScanningPushProtection"]:
        return typing.cast(typing.Optional["RepositorySecurityAndAnalysisSecretScanningPushProtection"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositorySecurityAndAnalysisSecretScanningPushProtection"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e50e47dce39417bd4ea6a951312787626501af7a08997262d10bfc63b6be173)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repository.RepositoryTemplate",
    jsii_struct_bases=[],
    name_mapping={
        "owner": "owner",
        "repository": "repository",
        "include_all_branches": "includeAllBranches",
    },
)
class RepositoryTemplate:
    def __init__(
        self,
        *,
        owner: builtins.str,
        repository: builtins.str,
        include_all_branches: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param owner: The GitHub organization or user the template repository is owned by. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#owner Repository#owner}
        :param repository: The name of the template repository. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#repository Repository#repository}
        :param include_all_branches: Whether the new repository should include all the branches from the template repository (defaults to 'false', which includes only the default branch from the template). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#include_all_branches Repository#include_all_branches}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b2e544036c546e06898393dad7a112a0695cc91d10a08c2d95276f396d0731bb)
            check_type(argname="argument owner", value=owner, expected_type=type_hints["owner"])
            check_type(argname="argument repository", value=repository, expected_type=type_hints["repository"])
            check_type(argname="argument include_all_branches", value=include_all_branches, expected_type=type_hints["include_all_branches"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "owner": owner,
            "repository": repository,
        }
        if include_all_branches is not None:
            self._values["include_all_branches"] = include_all_branches

    @builtins.property
    def owner(self) -> builtins.str:
        '''The GitHub organization or user the template repository is owned by.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#owner Repository#owner}
        '''
        result = self._values.get("owner")
        assert result is not None, "Required property 'owner' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def repository(self) -> builtins.str:
        '''The name of the template repository.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#repository Repository#repository}
        '''
        result = self._values.get("repository")
        assert result is not None, "Required property 'repository' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def include_all_branches(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Whether the new repository should include all the branches from the template repository (defaults to 'false', which includes only the default branch from the template).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository#include_all_branches Repository#include_all_branches}
        '''
        result = self._values.get("include_all_branches")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryTemplate(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryTemplateOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repository.RepositoryTemplateOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c13df64048e7519e40e47b85154d08d5b8685a505e2434f9b86daed20a77403e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetIncludeAllBranches")
    def reset_include_all_branches(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIncludeAllBranches", []))

    @builtins.property
    @jsii.member(jsii_name="includeAllBranchesInput")
    def include_all_branches_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "includeAllBranchesInput"))

    @builtins.property
    @jsii.member(jsii_name="ownerInput")
    def owner_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "ownerInput"))

    @builtins.property
    @jsii.member(jsii_name="repositoryInput")
    def repository_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "repositoryInput"))

    @builtins.property
    @jsii.member(jsii_name="includeAllBranches")
    def include_all_branches(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "includeAllBranches"))

    @include_all_branches.setter
    def include_all_branches(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__400daa0534aa282468350be2bc8bf585c091595428b47ee7840df54e0d9abc24)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "includeAllBranches", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="owner")
    def owner(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "owner"))

    @owner.setter
    def owner(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__905c5caba11faae918c91e8a1a9610cce42041f7923fc8b7d9fa7eb9a2739f1e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "owner", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="repository")
    def repository(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "repository"))

    @repository.setter
    def repository(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e35e35d7106c383f2ac7b5053bdd76296947f65af6252863533530d069f078af)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "repository", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["RepositoryTemplate"]:
        return typing.cast(typing.Optional["RepositoryTemplate"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional["RepositoryTemplate"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__07ca95eaa4a3a3ccdb7c1f0adf36dac15bf044b581b06b652469e85d5e8c970b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "Repository",
    "RepositoryConfig",
    "RepositoryPages",
    "RepositoryPagesOutputReference",
    "RepositoryPagesSource",
    "RepositoryPagesSourceOutputReference",
    "RepositorySecurityAndAnalysis",
    "RepositorySecurityAndAnalysisAdvancedSecurity",
    "RepositorySecurityAndAnalysisAdvancedSecurityOutputReference",
    "RepositorySecurityAndAnalysisCodeSecurity",
    "RepositorySecurityAndAnalysisCodeSecurityOutputReference",
    "RepositorySecurityAndAnalysisOutputReference",
    "RepositorySecurityAndAnalysisSecretScanning",
    "RepositorySecurityAndAnalysisSecretScanningAiDetection",
    "RepositorySecurityAndAnalysisSecretScanningAiDetectionOutputReference",
    "RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns",
    "RepositorySecurityAndAnalysisSecretScanningNonProviderPatternsOutputReference",
    "RepositorySecurityAndAnalysisSecretScanningOutputReference",
    "RepositorySecurityAndAnalysisSecretScanningPushProtection",
    "RepositorySecurityAndAnalysisSecretScanningPushProtectionOutputReference",
    "RepositoryTemplate",
    "RepositoryTemplateOutputReference",
]

publication.publish()

def _typecheckingstub__76f88e84cfc2533f645219c270fb40ff03f3890dbe079111fb2093569713f773(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    name: builtins.str,
    allow_auto_merge: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    allow_forking: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    allow_merge_commit: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    allow_rebase_merge: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    allow_squash_merge: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    allow_update_branch: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    archived: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    archive_on_destroy: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    auto_init: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    default_branch: typing.Optional[builtins.str] = None,
    delete_branch_on_merge: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    description: typing.Optional[builtins.str] = None,
    etag: typing.Optional[builtins.str] = None,
    fork: typing.Optional[builtins.str] = None,
    gitignore_template: typing.Optional[builtins.str] = None,
    has_discussions: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    has_downloads: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    has_issues: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    has_projects: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    has_wiki: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    homepage_url: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    ignore_vulnerability_alerts_during_read: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    is_template: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    license_template: typing.Optional[builtins.str] = None,
    merge_commit_message: typing.Optional[builtins.str] = None,
    merge_commit_title: typing.Optional[builtins.str] = None,
    pages: typing.Optional[typing.Union[RepositoryPages, typing.Dict[builtins.str, typing.Any]]] = None,
    private: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    security_and_analysis: typing.Optional[typing.Union[RepositorySecurityAndAnalysis, typing.Dict[builtins.str, typing.Any]]] = None,
    source_owner: typing.Optional[builtins.str] = None,
    source_repo: typing.Optional[builtins.str] = None,
    squash_merge_commit_message: typing.Optional[builtins.str] = None,
    squash_merge_commit_title: typing.Optional[builtins.str] = None,
    template: typing.Optional[typing.Union[RepositoryTemplate, typing.Dict[builtins.str, typing.Any]]] = None,
    topics: typing.Optional[typing.Sequence[builtins.str]] = None,
    visibility: typing.Optional[builtins.str] = None,
    vulnerability_alerts: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    web_commit_signoff_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eb3d538a1e37a6d7a13c6778097e9469f207f7c00b3cea2959be4590c5d20d8f(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a7d7398efc854bf2d8d372daaa069f33e446bb3fe15ba08bcdf6a610ecfefeda(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a48334fa3191d169d6849658520707cd42385f72815ca522ca9c43a052944ca8(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80e0bf4e0569d7fb07bb4d2d8cd15b882302524b6bd9aaaaabfb59f1ee2b6064(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0376c55de0a13d47a1985727e5ce092b350965f26a1beed902636dee69d5c03c(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1de034deaef811f21da20a542adbd8a35571a2942a54840eee0e1b89220fe9f(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__196b629f92e4d591d3dfa605a3dff502a77847e9e531497fa87ee0ba39cc6885(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98d29ad3de83cfbe1afdc60d67cd005b838bf66668748a506c077643e945706d(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9dc95dfcbc904df4c568f9d6a78fae185211a698b174b0245b66131d544be733(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2aace9214669412958b362072ab4eaaa6751eafbc86b56c5e508486ffc0fa409(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__07874b4530ca734b8d7270ea269b01c7ea817d726a1460772d11e30ad3f8b5b5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__72be96f57d03b385269f76f990713e23f21556d639e16bdf21b1d02614badc99(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d6e701c0cb81f1f4bfe669614fa272aa6eb0208ce350b9aaf40749f95afee97c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__09dc8b3e615e782336d219f3b7b81c2db95eaed1a0693b0a1548834ecb785c2e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89f0c79e77c36b5b7a1fa635202120188a738c3e04a4666e776bb7ac31e78bc0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2d2adccfe9c83575dde1bf137784a4605fc8efe12cd648aac545538104ca5474(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b7069db4ce99ec25d5134c4fb4946dac546278a949c7f709deea54450125a31b(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c9755497fc2c18ae0c6359f306e822d3c7fb8b242009b3b7c7912bc7fd78bf3e(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7bf9644d44476376a8c00620ddac1218ef7a06336bc89c0bfec3261aae7663d6(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7100e1ad302b22445619d6371fbfa0e3097ac2b6895f210c181c7a6deb5ca5e6(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e3a6d67f0a95c17ef0470f5a0c7016d1545f2b6a8541012dbd0cad8a70da0368(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__46a9a215ef9885c2d42f42d5e2b66aa2920fe6d3cf9412cbb70d3234aa0916a2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__870e383f8e8c43e1612b782660850e5af8e9eb63ab0d446cc38f22763980e1ca(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f41da97c8c59e4215747f54b829adc962166e42dcae00848f13ba13ec86fcc0(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e579e090d61a2481358a1ad26ecfd61f18f65c08d37dc45f372fffa9ccf1cc6(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__df5dc20f316fe8cd938cd6e5c71cee6e416a01b04768f82228a4f2ae16d40068(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1e778efdcf517cc3af108f612918c3a47e7eb1c4c41e78dbb772fe4edfc0b19(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__91e94b80b34b0ea9d795ac72c309b59c519c84796ef0333c62078ce947ff4ccd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__86aa25c87acc28935ab6087f57b1f77924986c6712189128abfee5fab05ea169(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08eea670243e22e8f3056cc27a9a6919282f25a917d267c96a43a154481bde76(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a3f62c273e3ad8f90edf9ee1f64396d9585368098c0218bef73bbf573827a9a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__23ef7d696796d1a66ec1c07c675bfe07c124a10771a848d03333cc8e36a3058c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ea1e03efa86e71538b0c919aa770477c49c88460127dec2950f0359e41a77e4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__06e71764c86fe3e6bc29abb55625267a7ba1d0d1932018c49c494ef5a63d4466(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9b520c33063162281f1305b4e1e7fed329089436cbdd64777c340c2164eb6ce1(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6e14f309c1843aae643f67684f75748b3253249497b46da9172f64de2c1cde82(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a470dd771cef18127034e69d4b4580c38a1331c9ec4270148153f0ca94354159(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__73907108c7ea31316823eab1fb786f12606a0df68de443bdef64643ccccb3b44(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__af8957bc2cf255f1fce459094cb529fbcd88fa8f40ba76c5d6bbb2c5535b9cc2(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    name: builtins.str,
    allow_auto_merge: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    allow_forking: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    allow_merge_commit: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    allow_rebase_merge: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    allow_squash_merge: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    allow_update_branch: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    archived: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    archive_on_destroy: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    auto_init: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    default_branch: typing.Optional[builtins.str] = None,
    delete_branch_on_merge: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    description: typing.Optional[builtins.str] = None,
    etag: typing.Optional[builtins.str] = None,
    fork: typing.Optional[builtins.str] = None,
    gitignore_template: typing.Optional[builtins.str] = None,
    has_discussions: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    has_downloads: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    has_issues: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    has_projects: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    has_wiki: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    homepage_url: typing.Optional[builtins.str] = None,
    id: typing.Optional[builtins.str] = None,
    ignore_vulnerability_alerts_during_read: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    is_template: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    license_template: typing.Optional[builtins.str] = None,
    merge_commit_message: typing.Optional[builtins.str] = None,
    merge_commit_title: typing.Optional[builtins.str] = None,
    pages: typing.Optional[typing.Union[RepositoryPages, typing.Dict[builtins.str, typing.Any]]] = None,
    private: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    security_and_analysis: typing.Optional[typing.Union[RepositorySecurityAndAnalysis, typing.Dict[builtins.str, typing.Any]]] = None,
    source_owner: typing.Optional[builtins.str] = None,
    source_repo: typing.Optional[builtins.str] = None,
    squash_merge_commit_message: typing.Optional[builtins.str] = None,
    squash_merge_commit_title: typing.Optional[builtins.str] = None,
    template: typing.Optional[typing.Union[RepositoryTemplate, typing.Dict[builtins.str, typing.Any]]] = None,
    topics: typing.Optional[typing.Sequence[builtins.str]] = None,
    visibility: typing.Optional[builtins.str] = None,
    vulnerability_alerts: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    web_commit_signoff_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a48f884febab484d58d5e1ddd8ea53a53f7f5e8756d05dd757b92c008116fd8d(
    *,
    build_type: typing.Optional[builtins.str] = None,
    cname: typing.Optional[builtins.str] = None,
    source: typing.Optional[typing.Union[RepositoryPagesSource, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__45083b694dd8e188f111fcf0e5d21200815999fa1b623636d6dd2a1ddb394782(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__801ce0707e7c1e0971c389ed735276444bd7b67177b2532b568a45ec8a8e10a9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__17f18246afb7bdbec2b467ec48981c91815974e1c40c3b5928ec8ce66fd11563(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b9794961427808344d2832c6e994029ae7e7c66e0f424e16b43f7d918a641ea2(
    value: typing.Optional[RepositoryPages],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__847359ffa92fdf54e651e9fcc79f974750426d7fad69e04004774d18c90e5425(
    *,
    branch: builtins.str,
    path: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a4fc90bfcfd6494f05c83cc96ea1196451851ca73275d81db741c98e479f3355(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a558a9ad09f7e76d3913ce83334029a772f58ca56c25344d1cd4b20470240b3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d0181b9b2b08d67a137dd6237c74b4540c12249909d4d2f6fd2e1d96e5288adb(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9846ade5f77dfa0fa85e664046e919277f20bad64b36a0d5d68a040fdfcc1b9d(
    value: typing.Optional[RepositoryPagesSource],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2eb2a1dd372daf0c8493be96bad85bf92b2086f3848738bc351c1ea158d48935(
    *,
    advanced_security: typing.Optional[typing.Union[RepositorySecurityAndAnalysisAdvancedSecurity, typing.Dict[builtins.str, typing.Any]]] = None,
    code_security: typing.Optional[typing.Union[RepositorySecurityAndAnalysisCodeSecurity, typing.Dict[builtins.str, typing.Any]]] = None,
    secret_scanning: typing.Optional[typing.Union[RepositorySecurityAndAnalysisSecretScanning, typing.Dict[builtins.str, typing.Any]]] = None,
    secret_scanning_ai_detection: typing.Optional[typing.Union[RepositorySecurityAndAnalysisSecretScanningAiDetection, typing.Dict[builtins.str, typing.Any]]] = None,
    secret_scanning_non_provider_patterns: typing.Optional[typing.Union[RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns, typing.Dict[builtins.str, typing.Any]]] = None,
    secret_scanning_push_protection: typing.Optional[typing.Union[RepositorySecurityAndAnalysisSecretScanningPushProtection, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ac7bcf7e688f25d72807232b593de3bc3df1bdb10f36cd66b4d3a2c87dd96e1(
    *,
    status: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__53ad4bf654ff1c43f21448dec9be75cdb154a16adf2caca1254f9acedac9effb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8184921460400cd1270af9293d9c15ec16c3e5e8b3c6e0ce7a7e2fa92969a1d9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__01e988fc8ac2a52efc0b6542d7f582859360360c7ae6d7476c1c9966714a1540(
    value: typing.Optional[RepositorySecurityAndAnalysisAdvancedSecurity],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d4b9d84197cef5f516c5550e987d179951b896b435216d878cfe61b3ab762b70(
    *,
    status: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1854d5d8361d46d38db3c9e995bee358a3b953a12db862ee08420c2056d99be6(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8b94ce906449459d0eebd725e5ae5c60698f0c719185640031cf2f5c61e61999(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f97b04b11ed8f6d1129a9154f762d4948a20ada8181ba296706bace6b7b359da(
    value: typing.Optional[RepositorySecurityAndAnalysisCodeSecurity],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d96911f011a8124593c65bd82a27ec441774ba1c85ef6539c2a41d255e6c40dc(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6aa6fd76430895798bff508728faae2ee61121fed67f5fb54a4cd34446034ca0(
    value: typing.Optional[RepositorySecurityAndAnalysis],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a71a3da4893b0b6f9c475b85efe8be15aa013e45978a540763c3d86b23a5b65(
    *,
    status: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__162927f66c080711a44e7d076fd42b0dfb7a856ae62785d517da898ec3bdd5c1(
    *,
    status: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3aebd3d1785aa5c2c0c69e9066c15c1a759ce8e19f5a8f49f5eb865f43c9e248(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1dce71226f59d916e5eeea89938d30e644aba835a8b21f332bc81c6599120a4b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5cd254425cac417554946e8f8b4ba1b2491eb3986014bb003c2f17425eba78de(
    value: typing.Optional[RepositorySecurityAndAnalysisSecretScanningAiDetection],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3eda12a596573ae2db56e0740a2ecd89dfed921096372a34c2bbadc5c42cfe33(
    *,
    status: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37e562ce5f3033eba79f4a3a8c0cf6ccce24b5a52f4d9237c216217aad8e31fb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cae11d46bded0822cf6655adcae746c3b39a0a9866f5902d08b5ec46cfbc9a34(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__351604159d14bb43c7eca59f9d0eeb58f0c2aee4286d9a7e8b1656e22e2775b1(
    value: typing.Optional[RepositorySecurityAndAnalysisSecretScanningNonProviderPatterns],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2ab86a2a07962eccbe5bea522a9dd57ea44954c4f5332377fe15f3f7c3917419(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a0d68871618417dac8934e54e75bdc9292c94b2d0784c9963e401989cd9e628(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__75fcb88b2ba4083290d95ed83d01a669729703e23a10e67ee94a6eff48d173d6(
    value: typing.Optional[RepositorySecurityAndAnalysisSecretScanning],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__38e053491afb8d1d1e09866528d9b30f715dbcffbc789a662628726a78ddc7d5(
    *,
    status: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__47989cf21ee1909fda162796e254314ba46b64b535743ea27c4cba854934e9bd(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8b93a81fed3477b88e23a410562e6c66cd53837911ad696a021fa4c07de9b8c5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e50e47dce39417bd4ea6a951312787626501af7a08997262d10bfc63b6be173(
    value: typing.Optional[RepositorySecurityAndAnalysisSecretScanningPushProtection],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b2e544036c546e06898393dad7a112a0695cc91d10a08c2d95276f396d0731bb(
    *,
    owner: builtins.str,
    repository: builtins.str,
    include_all_branches: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c13df64048e7519e40e47b85154d08d5b8685a505e2434f9b86daed20a77403e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__400daa0534aa282468350be2bc8bf585c091595428b47ee7840df54e0d9abc24(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__905c5caba11faae918c91e8a1a9610cce42041f7923fc8b7d9fa7eb9a2739f1e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e35e35d7106c383f2ac7b5053bdd76296947f65af6252863533530d069f078af(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__07ca95eaa4a3a3ccdb7c1f0adf36dac15bf044b581b06b652469e85d5e8c970b(
    value: typing.Optional[RepositoryTemplate],
) -> None:
    """Type checking stubs"""
    pass
