r'''
# `github_repository_ruleset`

Refer to the Terraform Registry for docs: [`github_repository_ruleset`](https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class RepositoryRuleset(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRuleset",
):
    '''Represents a {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset github_repository_ruleset}.'''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id_: builtins.str,
        *,
        enforcement: builtins.str,
        name: builtins.str,
        repository: builtins.str,
        rules: typing.Union["RepositoryRulesetRules", typing.Dict[builtins.str, typing.Any]],
        target: builtins.str,
        bypass_actors: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetBypassActors", typing.Dict[builtins.str, typing.Any]]]]] = None,
        conditions: typing.Optional[typing.Union["RepositoryRulesetConditions", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset github_repository_ruleset} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param enforcement: Possible values for Enforcement are ``disabled``, ``active``, ``evaluate``. Note: ``evaluate`` is currently only supported for owners of type ``organization``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#enforcement RepositoryRuleset#enforcement}
        :param name: The name of the ruleset. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param repository: Name of the repository to apply ruleset to. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#repository RepositoryRuleset#repository}
        :param rules: rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#rules RepositoryRuleset#rules}
        :param target: Possible values are branch, push and tag. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#target RepositoryRuleset#target}
        :param bypass_actors: bypass_actors block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#bypass_actors RepositoryRuleset#bypass_actors}
        :param conditions: conditions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#conditions RepositoryRuleset#conditions}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#id RepositoryRuleset#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eb822e129d01ac39a2a54c4ae0a14ccb3e193adf4f7160cac121eaa0b807cb47)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = RepositoryRulesetConfig(
            enforcement=enforcement,
            name=name,
            repository=repository,
            rules=rules,
            target=target,
            bypass_actors=bypass_actors,
            conditions=conditions,
            id=id,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a RepositoryRuleset resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the RepositoryRuleset to import.
        :param import_from_id: The id of the existing RepositoryRuleset that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the RepositoryRuleset to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba03999ed55e971e4528be74bf7c8712ba6dfb9ca7327d704649f164e301248d)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putBypassActors")
    def put_bypass_actors(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetBypassActors", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38eccb1fabe6cbaab18ed5112fadae34d8fb1cdc800d1889d69c9e229724473d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putBypassActors", [value]))

    @jsii.member(jsii_name="putConditions")
    def put_conditions(
        self,
        *,
        ref_name: typing.Union["RepositoryRulesetConditionsRefName", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''
        :param ref_name: ref_name block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#ref_name RepositoryRuleset#ref_name}
        '''
        value = RepositoryRulesetConditions(ref_name=ref_name)

        return typing.cast(None, jsii.invoke(self, "putConditions", [value]))

    @jsii.member(jsii_name="putRules")
    def put_rules(
        self,
        *,
        branch_name_pattern: typing.Optional[typing.Union["RepositoryRulesetRulesBranchNamePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        commit_author_email_pattern: typing.Optional[typing.Union["RepositoryRulesetRulesCommitAuthorEmailPattern", typing.Dict[builtins.str, typing.Any]]] = None,
        commit_message_pattern: typing.Optional[typing.Union["RepositoryRulesetRulesCommitMessagePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        committer_email_pattern: typing.Optional[typing.Union["RepositoryRulesetRulesCommitterEmailPattern", typing.Dict[builtins.str, typing.Any]]] = None,
        copilot_code_review: typing.Optional[typing.Union["RepositoryRulesetRulesCopilotCodeReview", typing.Dict[builtins.str, typing.Any]]] = None,
        creation: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        deletion: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        file_extension_restriction: typing.Optional[typing.Union["RepositoryRulesetRulesFileExtensionRestriction", typing.Dict[builtins.str, typing.Any]]] = None,
        file_path_restriction: typing.Optional[typing.Union["RepositoryRulesetRulesFilePathRestriction", typing.Dict[builtins.str, typing.Any]]] = None,
        max_file_path_length: typing.Optional[typing.Union["RepositoryRulesetRulesMaxFilePathLength", typing.Dict[builtins.str, typing.Any]]] = None,
        max_file_size: typing.Optional[typing.Union["RepositoryRulesetRulesMaxFileSize", typing.Dict[builtins.str, typing.Any]]] = None,
        merge_queue: typing.Optional[typing.Union["RepositoryRulesetRulesMergeQueue", typing.Dict[builtins.str, typing.Any]]] = None,
        non_fast_forward: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        pull_request: typing.Optional[typing.Union["RepositoryRulesetRulesPullRequest", typing.Dict[builtins.str, typing.Any]]] = None,
        required_code_scanning: typing.Optional[typing.Union["RepositoryRulesetRulesRequiredCodeScanning", typing.Dict[builtins.str, typing.Any]]] = None,
        required_deployments: typing.Optional[typing.Union["RepositoryRulesetRulesRequiredDeployments", typing.Dict[builtins.str, typing.Any]]] = None,
        required_linear_history: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_signatures: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_status_checks: typing.Optional[typing.Union["RepositoryRulesetRulesRequiredStatusChecks", typing.Dict[builtins.str, typing.Any]]] = None,
        tag_name_pattern: typing.Optional[typing.Union["RepositoryRulesetRulesTagNamePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        update: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        update_allows_fetch_and_merge: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param branch_name_pattern: branch_name_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#branch_name_pattern RepositoryRuleset#branch_name_pattern}
        :param commit_author_email_pattern: commit_author_email_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#commit_author_email_pattern RepositoryRuleset#commit_author_email_pattern}
        :param commit_message_pattern: commit_message_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#commit_message_pattern RepositoryRuleset#commit_message_pattern}
        :param committer_email_pattern: committer_email_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#committer_email_pattern RepositoryRuleset#committer_email_pattern}
        :param copilot_code_review: copilot_code_review block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#copilot_code_review RepositoryRuleset#copilot_code_review}
        :param creation: Only allow users with bypass permission to create matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#creation RepositoryRuleset#creation}
        :param deletion: Only allow users with bypass permissions to delete matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#deletion RepositoryRuleset#deletion}
        :param file_extension_restriction: file_extension_restriction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#file_extension_restriction RepositoryRuleset#file_extension_restriction}
        :param file_path_restriction: file_path_restriction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#file_path_restriction RepositoryRuleset#file_path_restriction}
        :param max_file_path_length: max_file_path_length block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_path_length RepositoryRuleset#max_file_path_length}
        :param max_file_size: max_file_size block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_size RepositoryRuleset#max_file_size}
        :param merge_queue: merge_queue block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#merge_queue RepositoryRuleset#merge_queue}
        :param non_fast_forward: Prevent users with push access from force pushing to branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#non_fast_forward RepositoryRuleset#non_fast_forward}
        :param pull_request: pull_request block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pull_request RepositoryRuleset#pull_request}
        :param required_code_scanning: required_code_scanning block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_code_scanning RepositoryRuleset#required_code_scanning}
        :param required_deployments: required_deployments block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_deployments RepositoryRuleset#required_deployments}
        :param required_linear_history: Prevent merge commits from being pushed to matching branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_linear_history RepositoryRuleset#required_linear_history}
        :param required_signatures: Commits pushed to matching branches must have verified signatures. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_signatures RepositoryRuleset#required_signatures}
        :param required_status_checks: required_status_checks block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_status_checks RepositoryRuleset#required_status_checks}
        :param tag_name_pattern: tag_name_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#tag_name_pattern RepositoryRuleset#tag_name_pattern}
        :param update: Only allow users with bypass permission to update matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#update RepositoryRuleset#update}
        :param update_allows_fetch_and_merge: Branch can pull changes from its upstream repository. This is only applicable to forked repositories. Requires ``update`` to be set to ``true``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#update_allows_fetch_and_merge RepositoryRuleset#update_allows_fetch_and_merge}
        '''
        value = RepositoryRulesetRules(
            branch_name_pattern=branch_name_pattern,
            commit_author_email_pattern=commit_author_email_pattern,
            commit_message_pattern=commit_message_pattern,
            committer_email_pattern=committer_email_pattern,
            copilot_code_review=copilot_code_review,
            creation=creation,
            deletion=deletion,
            file_extension_restriction=file_extension_restriction,
            file_path_restriction=file_path_restriction,
            max_file_path_length=max_file_path_length,
            max_file_size=max_file_size,
            merge_queue=merge_queue,
            non_fast_forward=non_fast_forward,
            pull_request=pull_request,
            required_code_scanning=required_code_scanning,
            required_deployments=required_deployments,
            required_linear_history=required_linear_history,
            required_signatures=required_signatures,
            required_status_checks=required_status_checks,
            tag_name_pattern=tag_name_pattern,
            update=update,
            update_allows_fetch_and_merge=update_allows_fetch_and_merge,
        )

        return typing.cast(None, jsii.invoke(self, "putRules", [value]))

    @jsii.member(jsii_name="resetBypassActors")
    def reset_bypass_actors(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBypassActors", []))

    @jsii.member(jsii_name="resetConditions")
    def reset_conditions(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetConditions", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="bypassActors")
    def bypass_actors(self) -> "RepositoryRulesetBypassActorsList":
        return typing.cast("RepositoryRulesetBypassActorsList", jsii.get(self, "bypassActors"))

    @builtins.property
    @jsii.member(jsii_name="conditions")
    def conditions(self) -> "RepositoryRulesetConditionsOutputReference":
        return typing.cast("RepositoryRulesetConditionsOutputReference", jsii.get(self, "conditions"))

    @builtins.property
    @jsii.member(jsii_name="etag")
    def etag(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "etag"))

    @builtins.property
    @jsii.member(jsii_name="nodeId")
    def node_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "nodeId"))

    @builtins.property
    @jsii.member(jsii_name="rules")
    def rules(self) -> "RepositoryRulesetRulesOutputReference":
        return typing.cast("RepositoryRulesetRulesOutputReference", jsii.get(self, "rules"))

    @builtins.property
    @jsii.member(jsii_name="rulesetId")
    def ruleset_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "rulesetId"))

    @builtins.property
    @jsii.member(jsii_name="bypassActorsInput")
    def bypass_actors_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetBypassActors"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetBypassActors"]]], jsii.get(self, "bypassActorsInput"))

    @builtins.property
    @jsii.member(jsii_name="conditionsInput")
    def conditions_input(self) -> typing.Optional["RepositoryRulesetConditions"]:
        return typing.cast(typing.Optional["RepositoryRulesetConditions"], jsii.get(self, "conditionsInput"))

    @builtins.property
    @jsii.member(jsii_name="enforcementInput")
    def enforcement_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "enforcementInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="repositoryInput")
    def repository_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "repositoryInput"))

    @builtins.property
    @jsii.member(jsii_name="rulesInput")
    def rules_input(self) -> typing.Optional["RepositoryRulesetRules"]:
        return typing.cast(typing.Optional["RepositoryRulesetRules"], jsii.get(self, "rulesInput"))

    @builtins.property
    @jsii.member(jsii_name="targetInput")
    def target_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "targetInput"))

    @builtins.property
    @jsii.member(jsii_name="enforcement")
    def enforcement(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "enforcement"))

    @enforcement.setter
    def enforcement(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6da98b82d303fc737a68dd9c0c06d86dfca16079cdf6a2a2710f571bc857a5d0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enforcement", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6b6fe62c59d41fd2537c85203c938d2e93d8435f6d46e671bd68e741eb5fbda3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__540cfabeb705510f5feaf912f9ff8e9e157f6e04943cc2ef4cfe94809065558d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="repository")
    def repository(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "repository"))

    @repository.setter
    def repository(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97f273f05eb8111defaed1aa3c62c2b19c8be18db3a9ccc73fc83c6c86781a04)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "repository", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="target")
    def target(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "target"))

    @target.setter
    def target(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__299fb8aaaa1c7d1572a18fa173341c3fee9c02477936b905cbed5c85d8944a9b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "target", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetBypassActors",
    jsii_struct_bases=[],
    name_mapping={
        "actor_type": "actorType",
        "bypass_mode": "bypassMode",
        "actor_id": "actorId",
    },
)
class RepositoryRulesetBypassActors:
    def __init__(
        self,
        *,
        actor_type: builtins.str,
        bypass_mode: builtins.str,
        actor_id: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param actor_type: The type of actor that can bypass a ruleset. See https://docs.github.com/en/rest/repos/rules for more information. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#actor_type RepositoryRuleset#actor_type}
        :param bypass_mode: When the specified actor can bypass the ruleset. pull_request means that an actor can only bypass rules on pull requests. Can be one of: ``always``, ``pull_request``, ``exempt``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#bypass_mode RepositoryRuleset#bypass_mode}
        :param actor_id: The ID of the actor that can bypass a ruleset. When ``actor_type`` is ``OrganizationAdmin``, this should be set to ``1``. Some resources such as DeployKey do not have an ID and this should be omitted. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#actor_id RepositoryRuleset#actor_id}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3358474d69de0ce04a30eeafc3ca9d4a40138d24fa8051cf22141a15af87a06b)
            check_type(argname="argument actor_type", value=actor_type, expected_type=type_hints["actor_type"])
            check_type(argname="argument bypass_mode", value=bypass_mode, expected_type=type_hints["bypass_mode"])
            check_type(argname="argument actor_id", value=actor_id, expected_type=type_hints["actor_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "actor_type": actor_type,
            "bypass_mode": bypass_mode,
        }
        if actor_id is not None:
            self._values["actor_id"] = actor_id

    @builtins.property
    def actor_type(self) -> builtins.str:
        '''The type of actor that can bypass a ruleset. See https://docs.github.com/en/rest/repos/rules for more information.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#actor_type RepositoryRuleset#actor_type}
        '''
        result = self._values.get("actor_type")
        assert result is not None, "Required property 'actor_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def bypass_mode(self) -> builtins.str:
        '''When the specified actor can bypass the ruleset.

        pull_request means that an actor can only bypass rules on pull requests. Can be one of: ``always``, ``pull_request``, ``exempt``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#bypass_mode RepositoryRuleset#bypass_mode}
        '''
        result = self._values.get("bypass_mode")
        assert result is not None, "Required property 'bypass_mode' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def actor_id(self) -> typing.Optional[jsii.Number]:
        '''The ID of the actor that can bypass a ruleset.

        When ``actor_type`` is ``OrganizationAdmin``, this should be set to ``1``. Some resources such as DeployKey do not have an ID and this should be omitted.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#actor_id RepositoryRuleset#actor_id}
        '''
        result = self._values.get("actor_id")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetBypassActors(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetBypassActorsList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetBypassActorsList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__044cf360a17c1765874bc2322d58b3d0ad772777e5e07a1490b2c11300d9f2f1)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "RepositoryRulesetBypassActorsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7bfb271d77f83f10a3d2492f070c2f25720d79ed5e9f4edd288b098386919854)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("RepositoryRulesetBypassActorsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetBypassActors"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetBypassActors"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetBypassActors"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__12fccf8ccda84959b5adfe082e33a04a63007ff451a77e66287bc3543b53f403)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class RepositoryRulesetBypassActorsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetBypassActorsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f8cdb4354f612e4332561a4c288314e6f5da71779856332490aa31a3078e3a7f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetActorId")
    def reset_actor_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetActorId", []))

    @builtins.property
    @jsii.member(jsii_name="actorIdInput")
    def actor_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "actorIdInput"))

    @builtins.property
    @jsii.member(jsii_name="actorTypeInput")
    def actor_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "actorTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="bypassModeInput")
    def bypass_mode_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "bypassModeInput"))

    @builtins.property
    @jsii.member(jsii_name="actorId")
    def actor_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "actorId"))

    @actor_id.setter
    def actor_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b0f29cfa0b9f3866b48aec7c5a5f5de89b1bc87b4280c109d4a944b6e3cf2b57)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "actorId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="actorType")
    def actor_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "actorType"))

    @actor_type.setter
    def actor_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c2aca9c2b7e806cb1da0022f564ef9c8d24ccdf8594a54ce3fd82838556ccdd9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "actorType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="bypassMode")
    def bypass_mode(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "bypassMode"))

    @bypass_mode.setter
    def bypass_mode(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ab07848a2251a8ef31273e6791173572f158d4572dafc8eb7eb65cef123a10c4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "bypassMode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetBypassActors"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetBypassActors"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetBypassActors"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8fbaed0b0af2c2ed2f624733db219ccfc333dd75746e17b1fd7d68396e8fa60b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetConditions",
    jsii_struct_bases=[],
    name_mapping={"ref_name": "refName"},
)
class RepositoryRulesetConditions:
    def __init__(
        self,
        *,
        ref_name: typing.Union["RepositoryRulesetConditionsRefName", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''
        :param ref_name: ref_name block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#ref_name RepositoryRuleset#ref_name}
        '''
        if isinstance(ref_name, dict):
            ref_name = RepositoryRulesetConditionsRefName(**ref_name)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4459967fad647222bb5b3b7c96355e9a4e649936ebecc7247acabcae8f77c4d0)
            check_type(argname="argument ref_name", value=ref_name, expected_type=type_hints["ref_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "ref_name": ref_name,
        }

    @builtins.property
    def ref_name(self) -> "RepositoryRulesetConditionsRefName":
        '''ref_name block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#ref_name RepositoryRuleset#ref_name}
        '''
        result = self._values.get("ref_name")
        assert result is not None, "Required property 'ref_name' is missing"
        return typing.cast("RepositoryRulesetConditionsRefName", result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetConditions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetConditionsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetConditionsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08c5fd43bf9c3bf7ceb31761050faee449784cf94a4955f56d6012227626a612)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRefName")
    def put_ref_name(
        self,
        *,
        exclude: typing.Sequence[builtins.str],
        include: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param exclude: Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#exclude RepositoryRuleset#exclude}
        :param include: Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts ``~DEFAULT_BRANCH`` to include the default branch or ``~ALL`` to include all branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#include RepositoryRuleset#include}
        '''
        value = RepositoryRulesetConditionsRefName(exclude=exclude, include=include)

        return typing.cast(None, jsii.invoke(self, "putRefName", [value]))

    @builtins.property
    @jsii.member(jsii_name="refName")
    def ref_name(self) -> "RepositoryRulesetConditionsRefNameOutputReference":
        return typing.cast("RepositoryRulesetConditionsRefNameOutputReference", jsii.get(self, "refName"))

    @builtins.property
    @jsii.member(jsii_name="refNameInput")
    def ref_name_input(self) -> typing.Optional["RepositoryRulesetConditionsRefName"]:
        return typing.cast(typing.Optional["RepositoryRulesetConditionsRefName"], jsii.get(self, "refNameInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["RepositoryRulesetConditions"]:
        return typing.cast(typing.Optional["RepositoryRulesetConditions"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetConditions"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__26035c016807e7ff97c42ac555ce81ece6c74fd3305c493d151a1a8f59b7c787)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetConditionsRefName",
    jsii_struct_bases=[],
    name_mapping={"exclude": "exclude", "include": "include"},
)
class RepositoryRulesetConditionsRefName:
    def __init__(
        self,
        *,
        exclude: typing.Sequence[builtins.str],
        include: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param exclude: Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#exclude RepositoryRuleset#exclude}
        :param include: Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts ``~DEFAULT_BRANCH`` to include the default branch or ``~ALL`` to include all branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#include RepositoryRuleset#include}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77141029ab2b279256149fdc05878bfc3617277765545be53e69b98c49accf7d)
            check_type(argname="argument exclude", value=exclude, expected_type=type_hints["exclude"])
            check_type(argname="argument include", value=include, expected_type=type_hints["include"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "exclude": exclude,
            "include": include,
        }

    @builtins.property
    def exclude(self) -> typing.List[builtins.str]:
        '''Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#exclude RepositoryRuleset#exclude}
        '''
        result = self._values.get("exclude")
        assert result is not None, "Required property 'exclude' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def include(self) -> typing.List[builtins.str]:
        '''Array of ref names or patterns to include.

        One of these patterns must match for the condition to pass. Also accepts ``~DEFAULT_BRANCH`` to include the default branch or ``~ALL`` to include all branches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#include RepositoryRuleset#include}
        '''
        result = self._values.get("include")
        assert result is not None, "Required property 'include' is missing"
        return typing.cast(typing.List[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetConditionsRefName(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetConditionsRefNameOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetConditionsRefNameOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b53d57e305ce599d9e892b312ef6176aa0d7d7e225a556c17133f09f8e50f510)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="excludeInput")
    def exclude_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "excludeInput"))

    @builtins.property
    @jsii.member(jsii_name="includeInput")
    def include_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "includeInput"))

    @builtins.property
    @jsii.member(jsii_name="exclude")
    def exclude(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "exclude"))

    @exclude.setter
    def exclude(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__88cf4412259ebb0ebb14abf57b7ce709cef22fc2f1938b2214c94a5de41b20ca)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "exclude", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="include")
    def include(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "include"))

    @include.setter
    def include(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bd2d0c748d8e62056da404ea4c6e97a62b56391bd48041169613e81b04929aa6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "include", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["RepositoryRulesetConditionsRefName"]:
        return typing.cast(typing.Optional["RepositoryRulesetConditionsRefName"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetConditionsRefName"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8bb94f8cc29b0899a6023795d910ca11eb33c222e65375098dc02200a34d3554)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "enforcement": "enforcement",
        "name": "name",
        "repository": "repository",
        "rules": "rules",
        "target": "target",
        "bypass_actors": "bypassActors",
        "conditions": "conditions",
        "id": "id",
    },
)
class RepositoryRulesetConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        enforcement: builtins.str,
        name: builtins.str,
        repository: builtins.str,
        rules: typing.Union["RepositoryRulesetRules", typing.Dict[builtins.str, typing.Any]],
        target: builtins.str,
        bypass_actors: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetBypassActors", typing.Dict[builtins.str, typing.Any]]]]] = None,
        conditions: typing.Optional[typing.Union["RepositoryRulesetConditions", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param enforcement: Possible values for Enforcement are ``disabled``, ``active``, ``evaluate``. Note: ``evaluate`` is currently only supported for owners of type ``organization``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#enforcement RepositoryRuleset#enforcement}
        :param name: The name of the ruleset. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param repository: Name of the repository to apply ruleset to. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#repository RepositoryRuleset#repository}
        :param rules: rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#rules RepositoryRuleset#rules}
        :param target: Possible values are branch, push and tag. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#target RepositoryRuleset#target}
        :param bypass_actors: bypass_actors block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#bypass_actors RepositoryRuleset#bypass_actors}
        :param conditions: conditions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#conditions RepositoryRuleset#conditions}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#id RepositoryRuleset#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(rules, dict):
            rules = RepositoryRulesetRules(**rules)
        if isinstance(conditions, dict):
            conditions = RepositoryRulesetConditions(**conditions)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8360b99d395a622ffb13ffae7c5632ff1fafff24c1925873aabc58a630539b20)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument enforcement", value=enforcement, expected_type=type_hints["enforcement"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument repository", value=repository, expected_type=type_hints["repository"])
            check_type(argname="argument rules", value=rules, expected_type=type_hints["rules"])
            check_type(argname="argument target", value=target, expected_type=type_hints["target"])
            check_type(argname="argument bypass_actors", value=bypass_actors, expected_type=type_hints["bypass_actors"])
            check_type(argname="argument conditions", value=conditions, expected_type=type_hints["conditions"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "enforcement": enforcement,
            "name": name,
            "repository": repository,
            "rules": rules,
            "target": target,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if bypass_actors is not None:
            self._values["bypass_actors"] = bypass_actors
        if conditions is not None:
            self._values["conditions"] = conditions
        if id is not None:
            self._values["id"] = id

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def enforcement(self) -> builtins.str:
        '''Possible values for Enforcement are ``disabled``, ``active``, ``evaluate``. Note: ``evaluate`` is currently only supported for owners of type ``organization``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#enforcement RepositoryRuleset#enforcement}
        '''
        result = self._values.get("enforcement")
        assert result is not None, "Required property 'enforcement' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''The name of the ruleset.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def repository(self) -> builtins.str:
        '''Name of the repository to apply ruleset to.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#repository RepositoryRuleset#repository}
        '''
        result = self._values.get("repository")
        assert result is not None, "Required property 'repository' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def rules(self) -> "RepositoryRulesetRules":
        '''rules block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#rules RepositoryRuleset#rules}
        '''
        result = self._values.get("rules")
        assert result is not None, "Required property 'rules' is missing"
        return typing.cast("RepositoryRulesetRules", result)

    @builtins.property
    def target(self) -> builtins.str:
        '''Possible values are branch, push and tag.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#target RepositoryRuleset#target}
        '''
        result = self._values.get("target")
        assert result is not None, "Required property 'target' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def bypass_actors(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetBypassActors"]]]:
        '''bypass_actors block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#bypass_actors RepositoryRuleset#bypass_actors}
        '''
        result = self._values.get("bypass_actors")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetBypassActors"]]], result)

    @builtins.property
    def conditions(self) -> typing.Optional["RepositoryRulesetConditions"]:
        '''conditions block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#conditions RepositoryRuleset#conditions}
        '''
        result = self._values.get("conditions")
        return typing.cast(typing.Optional["RepositoryRulesetConditions"], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#id RepositoryRuleset#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRules",
    jsii_struct_bases=[],
    name_mapping={
        "branch_name_pattern": "branchNamePattern",
        "commit_author_email_pattern": "commitAuthorEmailPattern",
        "commit_message_pattern": "commitMessagePattern",
        "committer_email_pattern": "committerEmailPattern",
        "copilot_code_review": "copilotCodeReview",
        "creation": "creation",
        "deletion": "deletion",
        "file_extension_restriction": "fileExtensionRestriction",
        "file_path_restriction": "filePathRestriction",
        "max_file_path_length": "maxFilePathLength",
        "max_file_size": "maxFileSize",
        "merge_queue": "mergeQueue",
        "non_fast_forward": "nonFastForward",
        "pull_request": "pullRequest",
        "required_code_scanning": "requiredCodeScanning",
        "required_deployments": "requiredDeployments",
        "required_linear_history": "requiredLinearHistory",
        "required_signatures": "requiredSignatures",
        "required_status_checks": "requiredStatusChecks",
        "tag_name_pattern": "tagNamePattern",
        "update": "update",
        "update_allows_fetch_and_merge": "updateAllowsFetchAndMerge",
    },
)
class RepositoryRulesetRules:
    def __init__(
        self,
        *,
        branch_name_pattern: typing.Optional[typing.Union["RepositoryRulesetRulesBranchNamePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        commit_author_email_pattern: typing.Optional[typing.Union["RepositoryRulesetRulesCommitAuthorEmailPattern", typing.Dict[builtins.str, typing.Any]]] = None,
        commit_message_pattern: typing.Optional[typing.Union["RepositoryRulesetRulesCommitMessagePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        committer_email_pattern: typing.Optional[typing.Union["RepositoryRulesetRulesCommitterEmailPattern", typing.Dict[builtins.str, typing.Any]]] = None,
        copilot_code_review: typing.Optional[typing.Union["RepositoryRulesetRulesCopilotCodeReview", typing.Dict[builtins.str, typing.Any]]] = None,
        creation: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        deletion: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        file_extension_restriction: typing.Optional[typing.Union["RepositoryRulesetRulesFileExtensionRestriction", typing.Dict[builtins.str, typing.Any]]] = None,
        file_path_restriction: typing.Optional[typing.Union["RepositoryRulesetRulesFilePathRestriction", typing.Dict[builtins.str, typing.Any]]] = None,
        max_file_path_length: typing.Optional[typing.Union["RepositoryRulesetRulesMaxFilePathLength", typing.Dict[builtins.str, typing.Any]]] = None,
        max_file_size: typing.Optional[typing.Union["RepositoryRulesetRulesMaxFileSize", typing.Dict[builtins.str, typing.Any]]] = None,
        merge_queue: typing.Optional[typing.Union["RepositoryRulesetRulesMergeQueue", typing.Dict[builtins.str, typing.Any]]] = None,
        non_fast_forward: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        pull_request: typing.Optional[typing.Union["RepositoryRulesetRulesPullRequest", typing.Dict[builtins.str, typing.Any]]] = None,
        required_code_scanning: typing.Optional[typing.Union["RepositoryRulesetRulesRequiredCodeScanning", typing.Dict[builtins.str, typing.Any]]] = None,
        required_deployments: typing.Optional[typing.Union["RepositoryRulesetRulesRequiredDeployments", typing.Dict[builtins.str, typing.Any]]] = None,
        required_linear_history: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_signatures: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_status_checks: typing.Optional[typing.Union["RepositoryRulesetRulesRequiredStatusChecks", typing.Dict[builtins.str, typing.Any]]] = None,
        tag_name_pattern: typing.Optional[typing.Union["RepositoryRulesetRulesTagNamePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        update: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        update_allows_fetch_and_merge: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param branch_name_pattern: branch_name_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#branch_name_pattern RepositoryRuleset#branch_name_pattern}
        :param commit_author_email_pattern: commit_author_email_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#commit_author_email_pattern RepositoryRuleset#commit_author_email_pattern}
        :param commit_message_pattern: commit_message_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#commit_message_pattern RepositoryRuleset#commit_message_pattern}
        :param committer_email_pattern: committer_email_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#committer_email_pattern RepositoryRuleset#committer_email_pattern}
        :param copilot_code_review: copilot_code_review block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#copilot_code_review RepositoryRuleset#copilot_code_review}
        :param creation: Only allow users with bypass permission to create matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#creation RepositoryRuleset#creation}
        :param deletion: Only allow users with bypass permissions to delete matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#deletion RepositoryRuleset#deletion}
        :param file_extension_restriction: file_extension_restriction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#file_extension_restriction RepositoryRuleset#file_extension_restriction}
        :param file_path_restriction: file_path_restriction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#file_path_restriction RepositoryRuleset#file_path_restriction}
        :param max_file_path_length: max_file_path_length block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_path_length RepositoryRuleset#max_file_path_length}
        :param max_file_size: max_file_size block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_size RepositoryRuleset#max_file_size}
        :param merge_queue: merge_queue block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#merge_queue RepositoryRuleset#merge_queue}
        :param non_fast_forward: Prevent users with push access from force pushing to branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#non_fast_forward RepositoryRuleset#non_fast_forward}
        :param pull_request: pull_request block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pull_request RepositoryRuleset#pull_request}
        :param required_code_scanning: required_code_scanning block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_code_scanning RepositoryRuleset#required_code_scanning}
        :param required_deployments: required_deployments block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_deployments RepositoryRuleset#required_deployments}
        :param required_linear_history: Prevent merge commits from being pushed to matching branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_linear_history RepositoryRuleset#required_linear_history}
        :param required_signatures: Commits pushed to matching branches must have verified signatures. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_signatures RepositoryRuleset#required_signatures}
        :param required_status_checks: required_status_checks block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_status_checks RepositoryRuleset#required_status_checks}
        :param tag_name_pattern: tag_name_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#tag_name_pattern RepositoryRuleset#tag_name_pattern}
        :param update: Only allow users with bypass permission to update matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#update RepositoryRuleset#update}
        :param update_allows_fetch_and_merge: Branch can pull changes from its upstream repository. This is only applicable to forked repositories. Requires ``update`` to be set to ``true``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#update_allows_fetch_and_merge RepositoryRuleset#update_allows_fetch_and_merge}
        '''
        if isinstance(branch_name_pattern, dict):
            branch_name_pattern = RepositoryRulesetRulesBranchNamePattern(**branch_name_pattern)
        if isinstance(commit_author_email_pattern, dict):
            commit_author_email_pattern = RepositoryRulesetRulesCommitAuthorEmailPattern(**commit_author_email_pattern)
        if isinstance(commit_message_pattern, dict):
            commit_message_pattern = RepositoryRulesetRulesCommitMessagePattern(**commit_message_pattern)
        if isinstance(committer_email_pattern, dict):
            committer_email_pattern = RepositoryRulesetRulesCommitterEmailPattern(**committer_email_pattern)
        if isinstance(copilot_code_review, dict):
            copilot_code_review = RepositoryRulesetRulesCopilotCodeReview(**copilot_code_review)
        if isinstance(file_extension_restriction, dict):
            file_extension_restriction = RepositoryRulesetRulesFileExtensionRestriction(**file_extension_restriction)
        if isinstance(file_path_restriction, dict):
            file_path_restriction = RepositoryRulesetRulesFilePathRestriction(**file_path_restriction)
        if isinstance(max_file_path_length, dict):
            max_file_path_length = RepositoryRulesetRulesMaxFilePathLength(**max_file_path_length)
        if isinstance(max_file_size, dict):
            max_file_size = RepositoryRulesetRulesMaxFileSize(**max_file_size)
        if isinstance(merge_queue, dict):
            merge_queue = RepositoryRulesetRulesMergeQueue(**merge_queue)
        if isinstance(pull_request, dict):
            pull_request = RepositoryRulesetRulesPullRequest(**pull_request)
        if isinstance(required_code_scanning, dict):
            required_code_scanning = RepositoryRulesetRulesRequiredCodeScanning(**required_code_scanning)
        if isinstance(required_deployments, dict):
            required_deployments = RepositoryRulesetRulesRequiredDeployments(**required_deployments)
        if isinstance(required_status_checks, dict):
            required_status_checks = RepositoryRulesetRulesRequiredStatusChecks(**required_status_checks)
        if isinstance(tag_name_pattern, dict):
            tag_name_pattern = RepositoryRulesetRulesTagNamePattern(**tag_name_pattern)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__41cfe0d393f819e1714eafb94eb7bff31d7b879a9efa27a1fb77aed74993c0b3)
            check_type(argname="argument branch_name_pattern", value=branch_name_pattern, expected_type=type_hints["branch_name_pattern"])
            check_type(argname="argument commit_author_email_pattern", value=commit_author_email_pattern, expected_type=type_hints["commit_author_email_pattern"])
            check_type(argname="argument commit_message_pattern", value=commit_message_pattern, expected_type=type_hints["commit_message_pattern"])
            check_type(argname="argument committer_email_pattern", value=committer_email_pattern, expected_type=type_hints["committer_email_pattern"])
            check_type(argname="argument copilot_code_review", value=copilot_code_review, expected_type=type_hints["copilot_code_review"])
            check_type(argname="argument creation", value=creation, expected_type=type_hints["creation"])
            check_type(argname="argument deletion", value=deletion, expected_type=type_hints["deletion"])
            check_type(argname="argument file_extension_restriction", value=file_extension_restriction, expected_type=type_hints["file_extension_restriction"])
            check_type(argname="argument file_path_restriction", value=file_path_restriction, expected_type=type_hints["file_path_restriction"])
            check_type(argname="argument max_file_path_length", value=max_file_path_length, expected_type=type_hints["max_file_path_length"])
            check_type(argname="argument max_file_size", value=max_file_size, expected_type=type_hints["max_file_size"])
            check_type(argname="argument merge_queue", value=merge_queue, expected_type=type_hints["merge_queue"])
            check_type(argname="argument non_fast_forward", value=non_fast_forward, expected_type=type_hints["non_fast_forward"])
            check_type(argname="argument pull_request", value=pull_request, expected_type=type_hints["pull_request"])
            check_type(argname="argument required_code_scanning", value=required_code_scanning, expected_type=type_hints["required_code_scanning"])
            check_type(argname="argument required_deployments", value=required_deployments, expected_type=type_hints["required_deployments"])
            check_type(argname="argument required_linear_history", value=required_linear_history, expected_type=type_hints["required_linear_history"])
            check_type(argname="argument required_signatures", value=required_signatures, expected_type=type_hints["required_signatures"])
            check_type(argname="argument required_status_checks", value=required_status_checks, expected_type=type_hints["required_status_checks"])
            check_type(argname="argument tag_name_pattern", value=tag_name_pattern, expected_type=type_hints["tag_name_pattern"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
            check_type(argname="argument update_allows_fetch_and_merge", value=update_allows_fetch_and_merge, expected_type=type_hints["update_allows_fetch_and_merge"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if branch_name_pattern is not None:
            self._values["branch_name_pattern"] = branch_name_pattern
        if commit_author_email_pattern is not None:
            self._values["commit_author_email_pattern"] = commit_author_email_pattern
        if commit_message_pattern is not None:
            self._values["commit_message_pattern"] = commit_message_pattern
        if committer_email_pattern is not None:
            self._values["committer_email_pattern"] = committer_email_pattern
        if copilot_code_review is not None:
            self._values["copilot_code_review"] = copilot_code_review
        if creation is not None:
            self._values["creation"] = creation
        if deletion is not None:
            self._values["deletion"] = deletion
        if file_extension_restriction is not None:
            self._values["file_extension_restriction"] = file_extension_restriction
        if file_path_restriction is not None:
            self._values["file_path_restriction"] = file_path_restriction
        if max_file_path_length is not None:
            self._values["max_file_path_length"] = max_file_path_length
        if max_file_size is not None:
            self._values["max_file_size"] = max_file_size
        if merge_queue is not None:
            self._values["merge_queue"] = merge_queue
        if non_fast_forward is not None:
            self._values["non_fast_forward"] = non_fast_forward
        if pull_request is not None:
            self._values["pull_request"] = pull_request
        if required_code_scanning is not None:
            self._values["required_code_scanning"] = required_code_scanning
        if required_deployments is not None:
            self._values["required_deployments"] = required_deployments
        if required_linear_history is not None:
            self._values["required_linear_history"] = required_linear_history
        if required_signatures is not None:
            self._values["required_signatures"] = required_signatures
        if required_status_checks is not None:
            self._values["required_status_checks"] = required_status_checks
        if tag_name_pattern is not None:
            self._values["tag_name_pattern"] = tag_name_pattern
        if update is not None:
            self._values["update"] = update
        if update_allows_fetch_and_merge is not None:
            self._values["update_allows_fetch_and_merge"] = update_allows_fetch_and_merge

    @builtins.property
    def branch_name_pattern(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesBranchNamePattern"]:
        '''branch_name_pattern block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#branch_name_pattern RepositoryRuleset#branch_name_pattern}
        '''
        result = self._values.get("branch_name_pattern")
        return typing.cast(typing.Optional["RepositoryRulesetRulesBranchNamePattern"], result)

    @builtins.property
    def commit_author_email_pattern(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCommitAuthorEmailPattern"]:
        '''commit_author_email_pattern block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#commit_author_email_pattern RepositoryRuleset#commit_author_email_pattern}
        '''
        result = self._values.get("commit_author_email_pattern")
        return typing.cast(typing.Optional["RepositoryRulesetRulesCommitAuthorEmailPattern"], result)

    @builtins.property
    def commit_message_pattern(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCommitMessagePattern"]:
        '''commit_message_pattern block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#commit_message_pattern RepositoryRuleset#commit_message_pattern}
        '''
        result = self._values.get("commit_message_pattern")
        return typing.cast(typing.Optional["RepositoryRulesetRulesCommitMessagePattern"], result)

    @builtins.property
    def committer_email_pattern(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCommitterEmailPattern"]:
        '''committer_email_pattern block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#committer_email_pattern RepositoryRuleset#committer_email_pattern}
        '''
        result = self._values.get("committer_email_pattern")
        return typing.cast(typing.Optional["RepositoryRulesetRulesCommitterEmailPattern"], result)

    @builtins.property
    def copilot_code_review(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCopilotCodeReview"]:
        '''copilot_code_review block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#copilot_code_review RepositoryRuleset#copilot_code_review}
        '''
        result = self._values.get("copilot_code_review")
        return typing.cast(typing.Optional["RepositoryRulesetRulesCopilotCodeReview"], result)

    @builtins.property
    def creation(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Only allow users with bypass permission to create matching refs.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#creation RepositoryRuleset#creation}
        '''
        result = self._values.get("creation")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def deletion(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Only allow users with bypass permissions to delete matching refs.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#deletion RepositoryRuleset#deletion}
        '''
        result = self._values.get("deletion")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def file_extension_restriction(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesFileExtensionRestriction"]:
        '''file_extension_restriction block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#file_extension_restriction RepositoryRuleset#file_extension_restriction}
        '''
        result = self._values.get("file_extension_restriction")
        return typing.cast(typing.Optional["RepositoryRulesetRulesFileExtensionRestriction"], result)

    @builtins.property
    def file_path_restriction(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesFilePathRestriction"]:
        '''file_path_restriction block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#file_path_restriction RepositoryRuleset#file_path_restriction}
        '''
        result = self._values.get("file_path_restriction")
        return typing.cast(typing.Optional["RepositoryRulesetRulesFilePathRestriction"], result)

    @builtins.property
    def max_file_path_length(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesMaxFilePathLength"]:
        '''max_file_path_length block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_path_length RepositoryRuleset#max_file_path_length}
        '''
        result = self._values.get("max_file_path_length")
        return typing.cast(typing.Optional["RepositoryRulesetRulesMaxFilePathLength"], result)

    @builtins.property
    def max_file_size(self) -> typing.Optional["RepositoryRulesetRulesMaxFileSize"]:
        '''max_file_size block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_size RepositoryRuleset#max_file_size}
        '''
        result = self._values.get("max_file_size")
        return typing.cast(typing.Optional["RepositoryRulesetRulesMaxFileSize"], result)

    @builtins.property
    def merge_queue(self) -> typing.Optional["RepositoryRulesetRulesMergeQueue"]:
        '''merge_queue block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#merge_queue RepositoryRuleset#merge_queue}
        '''
        result = self._values.get("merge_queue")
        return typing.cast(typing.Optional["RepositoryRulesetRulesMergeQueue"], result)

    @builtins.property
    def non_fast_forward(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Prevent users with push access from force pushing to branches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#non_fast_forward RepositoryRuleset#non_fast_forward}
        '''
        result = self._values.get("non_fast_forward")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def pull_request(self) -> typing.Optional["RepositoryRulesetRulesPullRequest"]:
        '''pull_request block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pull_request RepositoryRuleset#pull_request}
        '''
        result = self._values.get("pull_request")
        return typing.cast(typing.Optional["RepositoryRulesetRulesPullRequest"], result)

    @builtins.property
    def required_code_scanning(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesRequiredCodeScanning"]:
        '''required_code_scanning block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_code_scanning RepositoryRuleset#required_code_scanning}
        '''
        result = self._values.get("required_code_scanning")
        return typing.cast(typing.Optional["RepositoryRulesetRulesRequiredCodeScanning"], result)

    @builtins.property
    def required_deployments(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesRequiredDeployments"]:
        '''required_deployments block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_deployments RepositoryRuleset#required_deployments}
        '''
        result = self._values.get("required_deployments")
        return typing.cast(typing.Optional["RepositoryRulesetRulesRequiredDeployments"], result)

    @builtins.property
    def required_linear_history(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Prevent merge commits from being pushed to matching branches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_linear_history RepositoryRuleset#required_linear_history}
        '''
        result = self._values.get("required_linear_history")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def required_signatures(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Commits pushed to matching branches must have verified signatures.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_signatures RepositoryRuleset#required_signatures}
        '''
        result = self._values.get("required_signatures")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def required_status_checks(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesRequiredStatusChecks"]:
        '''required_status_checks block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_status_checks RepositoryRuleset#required_status_checks}
        '''
        result = self._values.get("required_status_checks")
        return typing.cast(typing.Optional["RepositoryRulesetRulesRequiredStatusChecks"], result)

    @builtins.property
    def tag_name_pattern(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesTagNamePattern"]:
        '''tag_name_pattern block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#tag_name_pattern RepositoryRuleset#tag_name_pattern}
        '''
        result = self._values.get("tag_name_pattern")
        return typing.cast(typing.Optional["RepositoryRulesetRulesTagNamePattern"], result)

    @builtins.property
    def update(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Only allow users with bypass permission to update matching refs.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#update RepositoryRuleset#update}
        '''
        result = self._values.get("update")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def update_allows_fetch_and_merge(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Branch can pull changes from its upstream repository.

        This is only applicable to forked repositories. Requires ``update`` to be set to ``true``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#update_allows_fetch_and_merge RepositoryRuleset#update_allows_fetch_and_merge}
        '''
        result = self._values.get("update_allows_fetch_and_merge")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRules(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesBranchNamePattern",
    jsii_struct_bases=[],
    name_mapping={
        "operator": "operator",
        "pattern": "pattern",
        "name": "name",
        "negate": "negate",
    },
)
class RepositoryRulesetRulesBranchNamePattern:
    def __init__(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a0bd195224fee6e5b5d8f9dc50f63734f7e300fa2e713d86d3e11b3fb688a7e3)
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument negate", value=negate, expected_type=type_hints["negate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "operator": operator,
            "pattern": pattern,
        }
        if name is not None:
            self._values["name"] = name
        if negate is not None:
            self._values["negate"] = negate

    @builtins.property
    def operator(self) -> builtins.str:
        '''The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        '''
        result = self._values.get("operator")
        assert result is not None, "Required property 'operator' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pattern(self) -> builtins.str:
        '''The pattern to match with.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''How this rule will appear to users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def negate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''If true, the rule will fail if the pattern matches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        result = self._values.get("negate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesBranchNamePattern(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesBranchNamePatternOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesBranchNamePatternOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f3c8e6eebe44c77a2a3dd6ffe91a3acb69cc9acd5940f9634d509cf05c092bd)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetNegate")
    def reset_negate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNegate", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="negateInput")
    def negate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "negateInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="patternInput")
    def pattern_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "patternInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f1d0d957e74ef3218d6e13b7b5bd153eb0e33b5944a0c8e4102b7a9ab7c0566f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="negate")
    def negate(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "negate"))

    @negate.setter
    def negate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb8fb2c784aa40c130701f02dcd16c505cf7b0134034a1109d005d37b2a61f0b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "negate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__22c59b1180e905f674e28f9fbb303206833bc0f603192cb904ba871bd157b797)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="pattern")
    def pattern(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "pattern"))

    @pattern.setter
    def pattern(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0cb985c6e531046fce2ffe959d6f0f80bd7df67761c496c157a994d49ba9e076)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "pattern", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesBranchNamePattern"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesBranchNamePattern"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesBranchNamePattern"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__614c41d70afc256689918efb3a5b2770b369ac70dbbe12a3299ad76e67674331)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesCommitAuthorEmailPattern",
    jsii_struct_bases=[],
    name_mapping={
        "operator": "operator",
        "pattern": "pattern",
        "name": "name",
        "negate": "negate",
    },
)
class RepositoryRulesetRulesCommitAuthorEmailPattern:
    def __init__(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a482ebc12f0e8de727c2cbc98b6cd86917668d5c457a9af732b4006490ad38ee)
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument negate", value=negate, expected_type=type_hints["negate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "operator": operator,
            "pattern": pattern,
        }
        if name is not None:
            self._values["name"] = name
        if negate is not None:
            self._values["negate"] = negate

    @builtins.property
    def operator(self) -> builtins.str:
        '''The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        '''
        result = self._values.get("operator")
        assert result is not None, "Required property 'operator' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pattern(self) -> builtins.str:
        '''The pattern to match with.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''How this rule will appear to users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def negate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''If true, the rule will fail if the pattern matches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        result = self._values.get("negate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesCommitAuthorEmailPattern(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesCommitAuthorEmailPatternOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesCommitAuthorEmailPatternOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3cca58c4758c232159f38cb342df0ff33f097c324db59b2cb22237d63e3c75cb)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetNegate")
    def reset_negate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNegate", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="negateInput")
    def negate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "negateInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="patternInput")
    def pattern_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "patternInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5200d1751f1255f664dfc4d80059bdad02a8f57d87a8e6fa06211f7fae38d75b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="negate")
    def negate(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "negate"))

    @negate.setter
    def negate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6b079670eeca2c5d143848bdadaa7aa16f0997460f56221713ef59373c77e879)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "negate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3c66128daf55bb07b50835efa0402cebab9e6ef47f2c06f7b034924d4e6d72d4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="pattern")
    def pattern(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "pattern"))

    @pattern.setter
    def pattern(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__db12df409ecca015f5c330b1646c788dfb1e3553d72a110de141e511c9c90741)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "pattern", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCommitAuthorEmailPattern"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesCommitAuthorEmailPattern"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesCommitAuthorEmailPattern"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b5954dc28397f09d54cf0b355dc2995e3b308c84c76738daa1ed73a039a05df0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesCommitMessagePattern",
    jsii_struct_bases=[],
    name_mapping={
        "operator": "operator",
        "pattern": "pattern",
        "name": "name",
        "negate": "negate",
    },
)
class RepositoryRulesetRulesCommitMessagePattern:
    def __init__(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9cb51220900698b1ff2761e84e72b015266eb9ead30377bd177797beb4d8b810)
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument negate", value=negate, expected_type=type_hints["negate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "operator": operator,
            "pattern": pattern,
        }
        if name is not None:
            self._values["name"] = name
        if negate is not None:
            self._values["negate"] = negate

    @builtins.property
    def operator(self) -> builtins.str:
        '''The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        '''
        result = self._values.get("operator")
        assert result is not None, "Required property 'operator' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pattern(self) -> builtins.str:
        '''The pattern to match with.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''How this rule will appear to users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def negate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''If true, the rule will fail if the pattern matches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        result = self._values.get("negate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesCommitMessagePattern(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesCommitMessagePatternOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesCommitMessagePatternOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b379421b7d15719ebbe408a83a4eee5e6b78078ad455b6119e1ce1841657402)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetNegate")
    def reset_negate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNegate", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="negateInput")
    def negate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "negateInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="patternInput")
    def pattern_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "patternInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b1e22e32dc7eb7d68eda5fedcfaa339d8fb006d248769c8c460e45391bc1d5df)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="negate")
    def negate(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "negate"))

    @negate.setter
    def negate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e405dbfcc33210571c045ec21462d07dfa6207f994e28137059161f4ebed3daf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "negate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8932214aac2b2c1167822929b8e8524d02e593f62014236ca85b3f13c7e93798)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="pattern")
    def pattern(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "pattern"))

    @pattern.setter
    def pattern(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__30e743ac5876b3ae8710aed5337b6e4552976b0fb2c4ade690dcf22f777db234)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "pattern", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCommitMessagePattern"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesCommitMessagePattern"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesCommitMessagePattern"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a259ce0aa7c9d3f495a25fa086d5d68b3115bd9d3d1847522f8a96b0f9292195)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesCommitterEmailPattern",
    jsii_struct_bases=[],
    name_mapping={
        "operator": "operator",
        "pattern": "pattern",
        "name": "name",
        "negate": "negate",
    },
)
class RepositoryRulesetRulesCommitterEmailPattern:
    def __init__(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3d96e9e8bcc0b705759218e11533eb78ae36592e1504228b10d07d6bece3b6db)
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument negate", value=negate, expected_type=type_hints["negate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "operator": operator,
            "pattern": pattern,
        }
        if name is not None:
            self._values["name"] = name
        if negate is not None:
            self._values["negate"] = negate

    @builtins.property
    def operator(self) -> builtins.str:
        '''The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        '''
        result = self._values.get("operator")
        assert result is not None, "Required property 'operator' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pattern(self) -> builtins.str:
        '''The pattern to match with.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''How this rule will appear to users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def negate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''If true, the rule will fail if the pattern matches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        result = self._values.get("negate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesCommitterEmailPattern(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesCommitterEmailPatternOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesCommitterEmailPatternOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__715911b0c2edf4b3f7d03ec7aba2148118bf66e5823f56825763b66a86897838)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetNegate")
    def reset_negate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNegate", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="negateInput")
    def negate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "negateInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="patternInput")
    def pattern_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "patternInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9123eff769e095a9d9d5feff8939ca1494cc51d751588907ec07fc1d0e420332)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="negate")
    def negate(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "negate"))

    @negate.setter
    def negate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a89fc304bc6cf69487c2065b9a08c889f4df0fee42276524e78f476d88cabee2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "negate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__46df13bcf4c08816537c696c46f47d02e44349333b3f5673e32fe3417972117c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="pattern")
    def pattern(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "pattern"))

    @pattern.setter
    def pattern(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1bc99173941398cb72284b11cc265bed7be4e72af6532fd8373a49aed08ec135)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "pattern", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCommitterEmailPattern"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesCommitterEmailPattern"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesCommitterEmailPattern"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__91be953ca25337e211cadea6cf9ee8a1bcaff9829b31795971497d0e1f1c2218)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesCopilotCodeReview",
    jsii_struct_bases=[],
    name_mapping={
        "review_draft_pull_requests": "reviewDraftPullRequests",
        "review_on_push": "reviewOnPush",
    },
)
class RepositoryRulesetRulesCopilotCodeReview:
    def __init__(
        self,
        *,
        review_draft_pull_requests: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        review_on_push: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param review_draft_pull_requests: Copilot automatically reviews draft pull requests before they are marked as ready for review. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#review_draft_pull_requests RepositoryRuleset#review_draft_pull_requests}
        :param review_on_push: Copilot automatically reviews each new push to the pull request. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#review_on_push RepositoryRuleset#review_on_push}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77e8c12edf8ee169531bb808a8e04e48e02c00393bf97c92154433c661264418)
            check_type(argname="argument review_draft_pull_requests", value=review_draft_pull_requests, expected_type=type_hints["review_draft_pull_requests"])
            check_type(argname="argument review_on_push", value=review_on_push, expected_type=type_hints["review_on_push"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if review_draft_pull_requests is not None:
            self._values["review_draft_pull_requests"] = review_draft_pull_requests
        if review_on_push is not None:
            self._values["review_on_push"] = review_on_push

    @builtins.property
    def review_draft_pull_requests(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Copilot automatically reviews draft pull requests before they are marked as ready for review. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#review_draft_pull_requests RepositoryRuleset#review_draft_pull_requests}
        '''
        result = self._values.get("review_draft_pull_requests")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def review_on_push(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Copilot automatically reviews each new push to the pull request. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#review_on_push RepositoryRuleset#review_on_push}
        '''
        result = self._values.get("review_on_push")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesCopilotCodeReview(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesCopilotCodeReviewOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesCopilotCodeReviewOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__04eaeacf632ae2fec128ae42ce245603f7d87ee11b89045f429f125f54035e67)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetReviewDraftPullRequests")
    def reset_review_draft_pull_requests(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReviewDraftPullRequests", []))

    @jsii.member(jsii_name="resetReviewOnPush")
    def reset_review_on_push(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReviewOnPush", []))

    @builtins.property
    @jsii.member(jsii_name="reviewDraftPullRequestsInput")
    def review_draft_pull_requests_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "reviewDraftPullRequestsInput"))

    @builtins.property
    @jsii.member(jsii_name="reviewOnPushInput")
    def review_on_push_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "reviewOnPushInput"))

    @builtins.property
    @jsii.member(jsii_name="reviewDraftPullRequests")
    def review_draft_pull_requests(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "reviewDraftPullRequests"))

    @review_draft_pull_requests.setter
    def review_draft_pull_requests(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97062fdf2165637cdc73352686626fa2d1c6970250d71a6a3cf0e949e399c33b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "reviewDraftPullRequests", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="reviewOnPush")
    def review_on_push(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "reviewOnPush"))

    @review_on_push.setter
    def review_on_push(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d611570e24435a9bd3922531eac393cf0308f1fffc256b69e14a4373b709e858)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "reviewOnPush", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCopilotCodeReview"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesCopilotCodeReview"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesCopilotCodeReview"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b9b31f84907148d208cb556ba6706686593b75a3f587b5c7c4934af9c27e6c05)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesFileExtensionRestriction",
    jsii_struct_bases=[],
    name_mapping={"restricted_file_extensions": "restrictedFileExtensions"},
)
class RepositoryRulesetRulesFileExtensionRestriction:
    def __init__(
        self,
        *,
        restricted_file_extensions: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param restricted_file_extensions: A list of file extensions. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#restricted_file_extensions RepositoryRuleset#restricted_file_extensions}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eb18d274717ccf2dafc3fb05078ac7b13b196658c237aad5766f64a751830d59)
            check_type(argname="argument restricted_file_extensions", value=restricted_file_extensions, expected_type=type_hints["restricted_file_extensions"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "restricted_file_extensions": restricted_file_extensions,
        }

    @builtins.property
    def restricted_file_extensions(self) -> typing.List[builtins.str]:
        '''A list of file extensions.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#restricted_file_extensions RepositoryRuleset#restricted_file_extensions}
        '''
        result = self._values.get("restricted_file_extensions")
        assert result is not None, "Required property 'restricted_file_extensions' is missing"
        return typing.cast(typing.List[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesFileExtensionRestriction(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesFileExtensionRestrictionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesFileExtensionRestrictionOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0710914d59b39d442a399018480e2f2af67dd0cd8bcc12da9b2f3271b879ff4c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="restrictedFileExtensionsInput")
    def restricted_file_extensions_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "restrictedFileExtensionsInput"))

    @builtins.property
    @jsii.member(jsii_name="restrictedFileExtensions")
    def restricted_file_extensions(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "restrictedFileExtensions"))

    @restricted_file_extensions.setter
    def restricted_file_extensions(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1ca2d16c4c76139297b20d5c38d6efe52919573cd62de617c1814599a3d36d63)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "restrictedFileExtensions", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesFileExtensionRestriction"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesFileExtensionRestriction"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesFileExtensionRestriction"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9a5701f8d75c0ddc2c728742a12c9d817a93b09acbbd35010e676b707b87b04c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesFilePathRestriction",
    jsii_struct_bases=[],
    name_mapping={"restricted_file_paths": "restrictedFilePaths"},
)
class RepositoryRulesetRulesFilePathRestriction:
    def __init__(self, *, restricted_file_paths: typing.Sequence[builtins.str]) -> None:
        '''
        :param restricted_file_paths: The file paths that are restricted from being pushed to the commit graph. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#restricted_file_paths RepositoryRuleset#restricted_file_paths}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f6521fb90b50899722a31b1c9034b327bc4d6450ea088a069434d85701b4b687)
            check_type(argname="argument restricted_file_paths", value=restricted_file_paths, expected_type=type_hints["restricted_file_paths"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "restricted_file_paths": restricted_file_paths,
        }

    @builtins.property
    def restricted_file_paths(self) -> typing.List[builtins.str]:
        '''The file paths that are restricted from being pushed to the commit graph.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#restricted_file_paths RepositoryRuleset#restricted_file_paths}
        '''
        result = self._values.get("restricted_file_paths")
        assert result is not None, "Required property 'restricted_file_paths' is missing"
        return typing.cast(typing.List[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesFilePathRestriction(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesFilePathRestrictionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesFilePathRestrictionOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7b701db0d1eb193265bb926c142d24e87e56505db9f77bc7f64cab67d9209900)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="restrictedFilePathsInput")
    def restricted_file_paths_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "restrictedFilePathsInput"))

    @builtins.property
    @jsii.member(jsii_name="restrictedFilePaths")
    def restricted_file_paths(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "restrictedFilePaths"))

    @restricted_file_paths.setter
    def restricted_file_paths(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92f30f66c358105f5915ceaf639dca5d39f5be1e773fe52fd37d9c7fc8756701)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "restrictedFilePaths", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesFilePathRestriction"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesFilePathRestriction"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesFilePathRestriction"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__99276d27a7c830e71669c4b5b5725a5e0ee83f477c7ff017319f6aba5c75bada)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesMaxFilePathLength",
    jsii_struct_bases=[],
    name_mapping={"max_file_path_length": "maxFilePathLength"},
)
class RepositoryRulesetRulesMaxFilePathLength:
    def __init__(self, *, max_file_path_length: jsii.Number) -> None:
        '''
        :param max_file_path_length: The maximum allowed length of a file path. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_path_length RepositoryRuleset#max_file_path_length}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fa059653b72c9523c4213aaf7f6e862d800d4b94a2ad285fdf8f0b46f0e5c26d)
            check_type(argname="argument max_file_path_length", value=max_file_path_length, expected_type=type_hints["max_file_path_length"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "max_file_path_length": max_file_path_length,
        }

    @builtins.property
    def max_file_path_length(self) -> jsii.Number:
        '''The maximum allowed length of a file path.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_path_length RepositoryRuleset#max_file_path_length}
        '''
        result = self._values.get("max_file_path_length")
        assert result is not None, "Required property 'max_file_path_length' is missing"
        return typing.cast(jsii.Number, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesMaxFilePathLength(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesMaxFilePathLengthOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesMaxFilePathLengthOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__21d19dfc771901da172a78809de7184ba536462f5076c1cc311d99d19d9fd444)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="maxFilePathLengthInput")
    def max_file_path_length_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxFilePathLengthInput"))

    @builtins.property
    @jsii.member(jsii_name="maxFilePathLength")
    def max_file_path_length(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "maxFilePathLength"))

    @max_file_path_length.setter
    def max_file_path_length(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__18f039bb81b1b7f9376b294dd11ad5fcb8dbcd98d7b654e7d4f3ded44a339c47)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxFilePathLength", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesMaxFilePathLength"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesMaxFilePathLength"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesMaxFilePathLength"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__16faa98f0fe2b9deb40dffbe693b46f8d93e8b54266bc1ff5d475781038f91c3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesMaxFileSize",
    jsii_struct_bases=[],
    name_mapping={"max_file_size": "maxFileSize"},
)
class RepositoryRulesetRulesMaxFileSize:
    def __init__(self, *, max_file_size: jsii.Number) -> None:
        '''
        :param max_file_size: The maximum allowed size of a file in megabytes (MB). Valid range is 1-100 MB. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_size RepositoryRuleset#max_file_size}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5967d9f3b382caf6530500d026ddc3ab0020fd9986eb2656d462021781e67fe2)
            check_type(argname="argument max_file_size", value=max_file_size, expected_type=type_hints["max_file_size"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "max_file_size": max_file_size,
        }

    @builtins.property
    def max_file_size(self) -> jsii.Number:
        '''The maximum allowed size of a file in megabytes (MB). Valid range is 1-100 MB.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_size RepositoryRuleset#max_file_size}
        '''
        result = self._values.get("max_file_size")
        assert result is not None, "Required property 'max_file_size' is missing"
        return typing.cast(jsii.Number, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesMaxFileSize(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesMaxFileSizeOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesMaxFileSizeOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__94ac6eddc33a0f52a557193869df83c9fa1ae806893f1eaea42f721a5a39dff3)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="maxFileSizeInput")
    def max_file_size_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxFileSizeInput"))

    @builtins.property
    @jsii.member(jsii_name="maxFileSize")
    def max_file_size(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "maxFileSize"))

    @max_file_size.setter
    def max_file_size(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08a0324fccdf3c7e34499955fe02e0f244a907a35bb4419ab80490a7d4bfb0fb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxFileSize", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["RepositoryRulesetRulesMaxFileSize"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesMaxFileSize"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesMaxFileSize"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8f838845f14cd17e269910315c8e2a167a2e37791b35c79a4e13661814e2ed80)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesMergeQueue",
    jsii_struct_bases=[],
    name_mapping={
        "check_response_timeout_minutes": "checkResponseTimeoutMinutes",
        "grouping_strategy": "groupingStrategy",
        "max_entries_to_build": "maxEntriesToBuild",
        "max_entries_to_merge": "maxEntriesToMerge",
        "merge_method": "mergeMethod",
        "min_entries_to_merge": "minEntriesToMerge",
        "min_entries_to_merge_wait_minutes": "minEntriesToMergeWaitMinutes",
    },
)
class RepositoryRulesetRulesMergeQueue:
    def __init__(
        self,
        *,
        check_response_timeout_minutes: typing.Optional[jsii.Number] = None,
        grouping_strategy: typing.Optional[builtins.str] = None,
        max_entries_to_build: typing.Optional[jsii.Number] = None,
        max_entries_to_merge: typing.Optional[jsii.Number] = None,
        merge_method: typing.Optional[builtins.str] = None,
        min_entries_to_merge: typing.Optional[jsii.Number] = None,
        min_entries_to_merge_wait_minutes: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param check_response_timeout_minutes: Maximum time for a required status check to report a conclusion. After this much time has elapsed, checks that have not reported a conclusion will be assumed to have failed. Defaults to ``60``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#check_response_timeout_minutes RepositoryRuleset#check_response_timeout_minutes}
        :param grouping_strategy: When set to ALLGREEN, the merge commit created by merge queue for each PR in the group must pass all required checks to merge. When set to HEADGREEN, only the commit at the head of the merge group, i.e. the commit containing changes from all of the PRs in the group, must pass its required checks to merge. Can be one of: ALLGREEN, HEADGREEN. Defaults to ``ALLGREEN``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#grouping_strategy RepositoryRuleset#grouping_strategy}
        :param max_entries_to_build: Limit the number of queued pull requests requesting checks and workflow runs at the same time. Defaults to ``5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_entries_to_build RepositoryRuleset#max_entries_to_build}
        :param max_entries_to_merge: The maximum number of PRs that will be merged together in a group. Defaults to ``5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_entries_to_merge RepositoryRuleset#max_entries_to_merge}
        :param merge_method: Method to use when merging changes from queued pull requests. Can be one of: MERGE, SQUASH, REBASE. Defaults to ``MERGE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#merge_method RepositoryRuleset#merge_method}
        :param min_entries_to_merge: The minimum number of PRs that will be merged together in a group. Defaults to ``1``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#min_entries_to_merge RepositoryRuleset#min_entries_to_merge}
        :param min_entries_to_merge_wait_minutes: The time merge queue should wait after the first PR is added to the queue for the minimum group size to be met. After this time has elapsed, the minimum group size will be ignored and a smaller group will be merged. Defaults to ``5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#min_entries_to_merge_wait_minutes RepositoryRuleset#min_entries_to_merge_wait_minutes}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__132e2a5f4a1eedfc1c648d5f44a6a3bbc97e069112cdc4193b93256adee02764)
            check_type(argname="argument check_response_timeout_minutes", value=check_response_timeout_minutes, expected_type=type_hints["check_response_timeout_minutes"])
            check_type(argname="argument grouping_strategy", value=grouping_strategy, expected_type=type_hints["grouping_strategy"])
            check_type(argname="argument max_entries_to_build", value=max_entries_to_build, expected_type=type_hints["max_entries_to_build"])
            check_type(argname="argument max_entries_to_merge", value=max_entries_to_merge, expected_type=type_hints["max_entries_to_merge"])
            check_type(argname="argument merge_method", value=merge_method, expected_type=type_hints["merge_method"])
            check_type(argname="argument min_entries_to_merge", value=min_entries_to_merge, expected_type=type_hints["min_entries_to_merge"])
            check_type(argname="argument min_entries_to_merge_wait_minutes", value=min_entries_to_merge_wait_minutes, expected_type=type_hints["min_entries_to_merge_wait_minutes"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if check_response_timeout_minutes is not None:
            self._values["check_response_timeout_minutes"] = check_response_timeout_minutes
        if grouping_strategy is not None:
            self._values["grouping_strategy"] = grouping_strategy
        if max_entries_to_build is not None:
            self._values["max_entries_to_build"] = max_entries_to_build
        if max_entries_to_merge is not None:
            self._values["max_entries_to_merge"] = max_entries_to_merge
        if merge_method is not None:
            self._values["merge_method"] = merge_method
        if min_entries_to_merge is not None:
            self._values["min_entries_to_merge"] = min_entries_to_merge
        if min_entries_to_merge_wait_minutes is not None:
            self._values["min_entries_to_merge_wait_minutes"] = min_entries_to_merge_wait_minutes

    @builtins.property
    def check_response_timeout_minutes(self) -> typing.Optional[jsii.Number]:
        '''Maximum time for a required status check to report a conclusion.

        After this much time has elapsed, checks that have not reported a conclusion will be assumed to have failed. Defaults to ``60``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#check_response_timeout_minutes RepositoryRuleset#check_response_timeout_minutes}
        '''
        result = self._values.get("check_response_timeout_minutes")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def grouping_strategy(self) -> typing.Optional[builtins.str]:
        '''When set to ALLGREEN, the merge commit created by merge queue for each PR in the group must pass all required checks to merge.

        When set to HEADGREEN, only the commit at the head of the merge group, i.e. the commit containing changes from all of the PRs in the group, must pass its required checks to merge. Can be one of: ALLGREEN, HEADGREEN. Defaults to ``ALLGREEN``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#grouping_strategy RepositoryRuleset#grouping_strategy}
        '''
        result = self._values.get("grouping_strategy")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def max_entries_to_build(self) -> typing.Optional[jsii.Number]:
        '''Limit the number of queued pull requests requesting checks and workflow runs at the same time. Defaults to ``5``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_entries_to_build RepositoryRuleset#max_entries_to_build}
        '''
        result = self._values.get("max_entries_to_build")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def max_entries_to_merge(self) -> typing.Optional[jsii.Number]:
        '''The maximum number of PRs that will be merged together in a group. Defaults to ``5``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_entries_to_merge RepositoryRuleset#max_entries_to_merge}
        '''
        result = self._values.get("max_entries_to_merge")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def merge_method(self) -> typing.Optional[builtins.str]:
        '''Method to use when merging changes from queued pull requests.

        Can be one of: MERGE, SQUASH, REBASE. Defaults to ``MERGE``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#merge_method RepositoryRuleset#merge_method}
        '''
        result = self._values.get("merge_method")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def min_entries_to_merge(self) -> typing.Optional[jsii.Number]:
        '''The minimum number of PRs that will be merged together in a group. Defaults to ``1``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#min_entries_to_merge RepositoryRuleset#min_entries_to_merge}
        '''
        result = self._values.get("min_entries_to_merge")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def min_entries_to_merge_wait_minutes(self) -> typing.Optional[jsii.Number]:
        '''The time merge queue should wait after the first PR is added to the queue for the minimum group size to be met.

        After this time has elapsed, the minimum group size will be ignored and a smaller group will be merged. Defaults to ``5``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#min_entries_to_merge_wait_minutes RepositoryRuleset#min_entries_to_merge_wait_minutes}
        '''
        result = self._values.get("min_entries_to_merge_wait_minutes")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesMergeQueue(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesMergeQueueOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesMergeQueueOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a0789fdfae4da34a76d537ab14a1e8e45bd24ca1f7143c407cca1225767509a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCheckResponseTimeoutMinutes")
    def reset_check_response_timeout_minutes(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCheckResponseTimeoutMinutes", []))

    @jsii.member(jsii_name="resetGroupingStrategy")
    def reset_grouping_strategy(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetGroupingStrategy", []))

    @jsii.member(jsii_name="resetMaxEntriesToBuild")
    def reset_max_entries_to_build(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxEntriesToBuild", []))

    @jsii.member(jsii_name="resetMaxEntriesToMerge")
    def reset_max_entries_to_merge(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxEntriesToMerge", []))

    @jsii.member(jsii_name="resetMergeMethod")
    def reset_merge_method(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMergeMethod", []))

    @jsii.member(jsii_name="resetMinEntriesToMerge")
    def reset_min_entries_to_merge(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMinEntriesToMerge", []))

    @jsii.member(jsii_name="resetMinEntriesToMergeWaitMinutes")
    def reset_min_entries_to_merge_wait_minutes(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMinEntriesToMergeWaitMinutes", []))

    @builtins.property
    @jsii.member(jsii_name="checkResponseTimeoutMinutesInput")
    def check_response_timeout_minutes_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "checkResponseTimeoutMinutesInput"))

    @builtins.property
    @jsii.member(jsii_name="groupingStrategyInput")
    def grouping_strategy_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "groupingStrategyInput"))

    @builtins.property
    @jsii.member(jsii_name="maxEntriesToBuildInput")
    def max_entries_to_build_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxEntriesToBuildInput"))

    @builtins.property
    @jsii.member(jsii_name="maxEntriesToMergeInput")
    def max_entries_to_merge_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxEntriesToMergeInput"))

    @builtins.property
    @jsii.member(jsii_name="mergeMethodInput")
    def merge_method_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "mergeMethodInput"))

    @builtins.property
    @jsii.member(jsii_name="minEntriesToMergeInput")
    def min_entries_to_merge_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "minEntriesToMergeInput"))

    @builtins.property
    @jsii.member(jsii_name="minEntriesToMergeWaitMinutesInput")
    def min_entries_to_merge_wait_minutes_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "minEntriesToMergeWaitMinutesInput"))

    @builtins.property
    @jsii.member(jsii_name="checkResponseTimeoutMinutes")
    def check_response_timeout_minutes(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "checkResponseTimeoutMinutes"))

    @check_response_timeout_minutes.setter
    def check_response_timeout_minutes(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__41b28354c938c484a9e5910a969584f5d3330d9aaea2d35715df176fcf6cb87a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "checkResponseTimeoutMinutes", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="groupingStrategy")
    def grouping_strategy(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "groupingStrategy"))

    @grouping_strategy.setter
    def grouping_strategy(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3624baaa31a64ebaa6a629ccbc6668a6a4e10a9e12ea569026b5d9083c1880d4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "groupingStrategy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="maxEntriesToBuild")
    def max_entries_to_build(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "maxEntriesToBuild"))

    @max_entries_to_build.setter
    def max_entries_to_build(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb504dee78105ee060757edfc1ab3fd2d06fe3ea164d0a809f8e2cece899ecec)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxEntriesToBuild", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="maxEntriesToMerge")
    def max_entries_to_merge(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "maxEntriesToMerge"))

    @max_entries_to_merge.setter
    def max_entries_to_merge(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c1816906c2b2ca18edc5cbd721e8ebebd62904f541e7cfe326848624286e8074)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxEntriesToMerge", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="mergeMethod")
    def merge_method(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "mergeMethod"))

    @merge_method.setter
    def merge_method(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a8efb42af770e0d493cb85323782d49635a20949f9241ca968d1dd4b2aa093fd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "mergeMethod", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="minEntriesToMerge")
    def min_entries_to_merge(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "minEntriesToMerge"))

    @min_entries_to_merge.setter
    def min_entries_to_merge(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a1a21a2be53774b02c20b93a297ecbbdf6af1280883c28a47f869c7fef702ae5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "minEntriesToMerge", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="minEntriesToMergeWaitMinutes")
    def min_entries_to_merge_wait_minutes(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "minEntriesToMergeWaitMinutes"))

    @min_entries_to_merge_wait_minutes.setter
    def min_entries_to_merge_wait_minutes(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb7fdd56881a417992330c21969c49cda5b9a6006723f5132fdfeef412a717ff)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "minEntriesToMergeWaitMinutes", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["RepositoryRulesetRulesMergeQueue"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesMergeQueue"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesMergeQueue"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3f4493519314f69ac9c19ad3b149a6fd4f6b7ccf17e86024680f0dcdbbc7808)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class RepositoryRulesetRulesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b98d4b65d139a0785dadda48e081142aa066d55034029ad6bcdffcb9e3f06d03)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putBranchNamePattern")
    def put_branch_name_pattern(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        value = RepositoryRulesetRulesBranchNamePattern(
            operator=operator, pattern=pattern, name=name, negate=negate
        )

        return typing.cast(None, jsii.invoke(self, "putBranchNamePattern", [value]))

    @jsii.member(jsii_name="putCommitAuthorEmailPattern")
    def put_commit_author_email_pattern(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        value = RepositoryRulesetRulesCommitAuthorEmailPattern(
            operator=operator, pattern=pattern, name=name, negate=negate
        )

        return typing.cast(None, jsii.invoke(self, "putCommitAuthorEmailPattern", [value]))

    @jsii.member(jsii_name="putCommitMessagePattern")
    def put_commit_message_pattern(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        value = RepositoryRulesetRulesCommitMessagePattern(
            operator=operator, pattern=pattern, name=name, negate=negate
        )

        return typing.cast(None, jsii.invoke(self, "putCommitMessagePattern", [value]))

    @jsii.member(jsii_name="putCommitterEmailPattern")
    def put_committer_email_pattern(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        value = RepositoryRulesetRulesCommitterEmailPattern(
            operator=operator, pattern=pattern, name=name, negate=negate
        )

        return typing.cast(None, jsii.invoke(self, "putCommitterEmailPattern", [value]))

    @jsii.member(jsii_name="putCopilotCodeReview")
    def put_copilot_code_review(
        self,
        *,
        review_draft_pull_requests: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        review_on_push: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param review_draft_pull_requests: Copilot automatically reviews draft pull requests before they are marked as ready for review. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#review_draft_pull_requests RepositoryRuleset#review_draft_pull_requests}
        :param review_on_push: Copilot automatically reviews each new push to the pull request. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#review_on_push RepositoryRuleset#review_on_push}
        '''
        value = RepositoryRulesetRulesCopilotCodeReview(
            review_draft_pull_requests=review_draft_pull_requests,
            review_on_push=review_on_push,
        )

        return typing.cast(None, jsii.invoke(self, "putCopilotCodeReview", [value]))

    @jsii.member(jsii_name="putFileExtensionRestriction")
    def put_file_extension_restriction(
        self,
        *,
        restricted_file_extensions: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param restricted_file_extensions: A list of file extensions. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#restricted_file_extensions RepositoryRuleset#restricted_file_extensions}
        '''
        value = RepositoryRulesetRulesFileExtensionRestriction(
            restricted_file_extensions=restricted_file_extensions
        )

        return typing.cast(None, jsii.invoke(self, "putFileExtensionRestriction", [value]))

    @jsii.member(jsii_name="putFilePathRestriction")
    def put_file_path_restriction(
        self,
        *,
        restricted_file_paths: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param restricted_file_paths: The file paths that are restricted from being pushed to the commit graph. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#restricted_file_paths RepositoryRuleset#restricted_file_paths}
        '''
        value = RepositoryRulesetRulesFilePathRestriction(
            restricted_file_paths=restricted_file_paths
        )

        return typing.cast(None, jsii.invoke(self, "putFilePathRestriction", [value]))

    @jsii.member(jsii_name="putMaxFilePathLength")
    def put_max_file_path_length(self, *, max_file_path_length: jsii.Number) -> None:
        '''
        :param max_file_path_length: The maximum allowed length of a file path. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_path_length RepositoryRuleset#max_file_path_length}
        '''
        value = RepositoryRulesetRulesMaxFilePathLength(
            max_file_path_length=max_file_path_length
        )

        return typing.cast(None, jsii.invoke(self, "putMaxFilePathLength", [value]))

    @jsii.member(jsii_name="putMaxFileSize")
    def put_max_file_size(self, *, max_file_size: jsii.Number) -> None:
        '''
        :param max_file_size: The maximum allowed size of a file in megabytes (MB). Valid range is 1-100 MB. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_file_size RepositoryRuleset#max_file_size}
        '''
        value = RepositoryRulesetRulesMaxFileSize(max_file_size=max_file_size)

        return typing.cast(None, jsii.invoke(self, "putMaxFileSize", [value]))

    @jsii.member(jsii_name="putMergeQueue")
    def put_merge_queue(
        self,
        *,
        check_response_timeout_minutes: typing.Optional[jsii.Number] = None,
        grouping_strategy: typing.Optional[builtins.str] = None,
        max_entries_to_build: typing.Optional[jsii.Number] = None,
        max_entries_to_merge: typing.Optional[jsii.Number] = None,
        merge_method: typing.Optional[builtins.str] = None,
        min_entries_to_merge: typing.Optional[jsii.Number] = None,
        min_entries_to_merge_wait_minutes: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param check_response_timeout_minutes: Maximum time for a required status check to report a conclusion. After this much time has elapsed, checks that have not reported a conclusion will be assumed to have failed. Defaults to ``60``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#check_response_timeout_minutes RepositoryRuleset#check_response_timeout_minutes}
        :param grouping_strategy: When set to ALLGREEN, the merge commit created by merge queue for each PR in the group must pass all required checks to merge. When set to HEADGREEN, only the commit at the head of the merge group, i.e. the commit containing changes from all of the PRs in the group, must pass its required checks to merge. Can be one of: ALLGREEN, HEADGREEN. Defaults to ``ALLGREEN``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#grouping_strategy RepositoryRuleset#grouping_strategy}
        :param max_entries_to_build: Limit the number of queued pull requests requesting checks and workflow runs at the same time. Defaults to ``5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_entries_to_build RepositoryRuleset#max_entries_to_build}
        :param max_entries_to_merge: The maximum number of PRs that will be merged together in a group. Defaults to ``5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#max_entries_to_merge RepositoryRuleset#max_entries_to_merge}
        :param merge_method: Method to use when merging changes from queued pull requests. Can be one of: MERGE, SQUASH, REBASE. Defaults to ``MERGE``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#merge_method RepositoryRuleset#merge_method}
        :param min_entries_to_merge: The minimum number of PRs that will be merged together in a group. Defaults to ``1``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#min_entries_to_merge RepositoryRuleset#min_entries_to_merge}
        :param min_entries_to_merge_wait_minutes: The time merge queue should wait after the first PR is added to the queue for the minimum group size to be met. After this time has elapsed, the minimum group size will be ignored and a smaller group will be merged. Defaults to ``5``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#min_entries_to_merge_wait_minutes RepositoryRuleset#min_entries_to_merge_wait_minutes}
        '''
        value = RepositoryRulesetRulesMergeQueue(
            check_response_timeout_minutes=check_response_timeout_minutes,
            grouping_strategy=grouping_strategy,
            max_entries_to_build=max_entries_to_build,
            max_entries_to_merge=max_entries_to_merge,
            merge_method=merge_method,
            min_entries_to_merge=min_entries_to_merge,
            min_entries_to_merge_wait_minutes=min_entries_to_merge_wait_minutes,
        )

        return typing.cast(None, jsii.invoke(self, "putMergeQueue", [value]))

    @jsii.member(jsii_name="putPullRequest")
    def put_pull_request(
        self,
        *,
        allowed_merge_methods: typing.Optional[typing.Sequence[builtins.str]] = None,
        dismiss_stale_reviews_on_push: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        require_code_owner_review: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_approving_review_count: typing.Optional[jsii.Number] = None,
        required_reviewers: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetRulesPullRequestRequiredReviewers", typing.Dict[builtins.str, typing.Any]]]]] = None,
        required_review_thread_resolution: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        require_last_push_approval: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param allowed_merge_methods: Array of allowed merge methods. Allowed values include ``merge``, ``squash``, and ``rebase``. At least one option must be enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#allowed_merge_methods RepositoryRuleset#allowed_merge_methods}
        :param dismiss_stale_reviews_on_push: New, reviewable commits pushed will dismiss previous pull request review approvals. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#dismiss_stale_reviews_on_push RepositoryRuleset#dismiss_stale_reviews_on_push}
        :param require_code_owner_review: Require an approving review in pull requests that modify files that have a designated code owner. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#require_code_owner_review RepositoryRuleset#require_code_owner_review}
        :param required_approving_review_count: The number of approving reviews that are required before a pull request can be merged. Defaults to ``0``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_approving_review_count RepositoryRuleset#required_approving_review_count}
        :param required_reviewers: required_reviewers block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_reviewers RepositoryRuleset#required_reviewers}
        :param required_review_thread_resolution: All conversations on code must be resolved before a pull request can be merged. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_review_thread_resolution RepositoryRuleset#required_review_thread_resolution}
        :param require_last_push_approval: Whether the most recent reviewable push must be approved by someone other than the person who pushed it. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#require_last_push_approval RepositoryRuleset#require_last_push_approval}
        '''
        value = RepositoryRulesetRulesPullRequest(
            allowed_merge_methods=allowed_merge_methods,
            dismiss_stale_reviews_on_push=dismiss_stale_reviews_on_push,
            require_code_owner_review=require_code_owner_review,
            required_approving_review_count=required_approving_review_count,
            required_reviewers=required_reviewers,
            required_review_thread_resolution=required_review_thread_resolution,
            require_last_push_approval=require_last_push_approval,
        )

        return typing.cast(None, jsii.invoke(self, "putPullRequest", [value]))

    @jsii.member(jsii_name="putRequiredCodeScanning")
    def put_required_code_scanning(
        self,
        *,
        required_code_scanning_tool: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param required_code_scanning_tool: required_code_scanning_tool block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_code_scanning_tool RepositoryRuleset#required_code_scanning_tool}
        '''
        value = RepositoryRulesetRulesRequiredCodeScanning(
            required_code_scanning_tool=required_code_scanning_tool
        )

        return typing.cast(None, jsii.invoke(self, "putRequiredCodeScanning", [value]))

    @jsii.member(jsii_name="putRequiredDeployments")
    def put_required_deployments(
        self,
        *,
        required_deployment_environments: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param required_deployment_environments: The environments that must be successfully deployed to before branches can be merged. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_deployment_environments RepositoryRuleset#required_deployment_environments}
        '''
        value = RepositoryRulesetRulesRequiredDeployments(
            required_deployment_environments=required_deployment_environments
        )

        return typing.cast(None, jsii.invoke(self, "putRequiredDeployments", [value]))

    @jsii.member(jsii_name="putRequiredStatusChecks")
    def put_required_status_checks(
        self,
        *,
        required_check: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetRulesRequiredStatusChecksRequiredCheck", typing.Dict[builtins.str, typing.Any]]]],
        do_not_enforce_on_create: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        strict_required_status_checks_policy: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param required_check: required_check block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_check RepositoryRuleset#required_check}
        :param do_not_enforce_on_create: Allow repositories and branches to be created if a check would otherwise prohibit it. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#do_not_enforce_on_create RepositoryRuleset#do_not_enforce_on_create}
        :param strict_required_status_checks_policy: Whether pull requests targeting a matching branch must be tested with the latest code. This setting will not take effect unless at least one status check is enabled. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#strict_required_status_checks_policy RepositoryRuleset#strict_required_status_checks_policy}
        '''
        value = RepositoryRulesetRulesRequiredStatusChecks(
            required_check=required_check,
            do_not_enforce_on_create=do_not_enforce_on_create,
            strict_required_status_checks_policy=strict_required_status_checks_policy,
        )

        return typing.cast(None, jsii.invoke(self, "putRequiredStatusChecks", [value]))

    @jsii.member(jsii_name="putTagNamePattern")
    def put_tag_name_pattern(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        value = RepositoryRulesetRulesTagNamePattern(
            operator=operator, pattern=pattern, name=name, negate=negate
        )

        return typing.cast(None, jsii.invoke(self, "putTagNamePattern", [value]))

    @jsii.member(jsii_name="resetBranchNamePattern")
    def reset_branch_name_pattern(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBranchNamePattern", []))

    @jsii.member(jsii_name="resetCommitAuthorEmailPattern")
    def reset_commit_author_email_pattern(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCommitAuthorEmailPattern", []))

    @jsii.member(jsii_name="resetCommitMessagePattern")
    def reset_commit_message_pattern(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCommitMessagePattern", []))

    @jsii.member(jsii_name="resetCommitterEmailPattern")
    def reset_committer_email_pattern(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCommitterEmailPattern", []))

    @jsii.member(jsii_name="resetCopilotCodeReview")
    def reset_copilot_code_review(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCopilotCodeReview", []))

    @jsii.member(jsii_name="resetCreation")
    def reset_creation(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreation", []))

    @jsii.member(jsii_name="resetDeletion")
    def reset_deletion(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDeletion", []))

    @jsii.member(jsii_name="resetFileExtensionRestriction")
    def reset_file_extension_restriction(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFileExtensionRestriction", []))

    @jsii.member(jsii_name="resetFilePathRestriction")
    def reset_file_path_restriction(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFilePathRestriction", []))

    @jsii.member(jsii_name="resetMaxFilePathLength")
    def reset_max_file_path_length(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxFilePathLength", []))

    @jsii.member(jsii_name="resetMaxFileSize")
    def reset_max_file_size(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxFileSize", []))

    @jsii.member(jsii_name="resetMergeQueue")
    def reset_merge_queue(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMergeQueue", []))

    @jsii.member(jsii_name="resetNonFastForward")
    def reset_non_fast_forward(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNonFastForward", []))

    @jsii.member(jsii_name="resetPullRequest")
    def reset_pull_request(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPullRequest", []))

    @jsii.member(jsii_name="resetRequiredCodeScanning")
    def reset_required_code_scanning(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredCodeScanning", []))

    @jsii.member(jsii_name="resetRequiredDeployments")
    def reset_required_deployments(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredDeployments", []))

    @jsii.member(jsii_name="resetRequiredLinearHistory")
    def reset_required_linear_history(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredLinearHistory", []))

    @jsii.member(jsii_name="resetRequiredSignatures")
    def reset_required_signatures(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredSignatures", []))

    @jsii.member(jsii_name="resetRequiredStatusChecks")
    def reset_required_status_checks(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredStatusChecks", []))

    @jsii.member(jsii_name="resetTagNamePattern")
    def reset_tag_name_pattern(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTagNamePattern", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @jsii.member(jsii_name="resetUpdateAllowsFetchAndMerge")
    def reset_update_allows_fetch_and_merge(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdateAllowsFetchAndMerge", []))

    @builtins.property
    @jsii.member(jsii_name="branchNamePattern")
    def branch_name_pattern(
        self,
    ) -> "RepositoryRulesetRulesBranchNamePatternOutputReference":
        return typing.cast("RepositoryRulesetRulesBranchNamePatternOutputReference", jsii.get(self, "branchNamePattern"))

    @builtins.property
    @jsii.member(jsii_name="commitAuthorEmailPattern")
    def commit_author_email_pattern(
        self,
    ) -> "RepositoryRulesetRulesCommitAuthorEmailPatternOutputReference":
        return typing.cast("RepositoryRulesetRulesCommitAuthorEmailPatternOutputReference", jsii.get(self, "commitAuthorEmailPattern"))

    @builtins.property
    @jsii.member(jsii_name="commitMessagePattern")
    def commit_message_pattern(
        self,
    ) -> "RepositoryRulesetRulesCommitMessagePatternOutputReference":
        return typing.cast("RepositoryRulesetRulesCommitMessagePatternOutputReference", jsii.get(self, "commitMessagePattern"))

    @builtins.property
    @jsii.member(jsii_name="committerEmailPattern")
    def committer_email_pattern(
        self,
    ) -> "RepositoryRulesetRulesCommitterEmailPatternOutputReference":
        return typing.cast("RepositoryRulesetRulesCommitterEmailPatternOutputReference", jsii.get(self, "committerEmailPattern"))

    @builtins.property
    @jsii.member(jsii_name="copilotCodeReview")
    def copilot_code_review(
        self,
    ) -> "RepositoryRulesetRulesCopilotCodeReviewOutputReference":
        return typing.cast("RepositoryRulesetRulesCopilotCodeReviewOutputReference", jsii.get(self, "copilotCodeReview"))

    @builtins.property
    @jsii.member(jsii_name="fileExtensionRestriction")
    def file_extension_restriction(
        self,
    ) -> "RepositoryRulesetRulesFileExtensionRestrictionOutputReference":
        return typing.cast("RepositoryRulesetRulesFileExtensionRestrictionOutputReference", jsii.get(self, "fileExtensionRestriction"))

    @builtins.property
    @jsii.member(jsii_name="filePathRestriction")
    def file_path_restriction(
        self,
    ) -> "RepositoryRulesetRulesFilePathRestrictionOutputReference":
        return typing.cast("RepositoryRulesetRulesFilePathRestrictionOutputReference", jsii.get(self, "filePathRestriction"))

    @builtins.property
    @jsii.member(jsii_name="maxFilePathLength")
    def max_file_path_length(
        self,
    ) -> "RepositoryRulesetRulesMaxFilePathLengthOutputReference":
        return typing.cast("RepositoryRulesetRulesMaxFilePathLengthOutputReference", jsii.get(self, "maxFilePathLength"))

    @builtins.property
    @jsii.member(jsii_name="maxFileSize")
    def max_file_size(self) -> "RepositoryRulesetRulesMaxFileSizeOutputReference":
        return typing.cast("RepositoryRulesetRulesMaxFileSizeOutputReference", jsii.get(self, "maxFileSize"))

    @builtins.property
    @jsii.member(jsii_name="mergeQueue")
    def merge_queue(self) -> "RepositoryRulesetRulesMergeQueueOutputReference":
        return typing.cast("RepositoryRulesetRulesMergeQueueOutputReference", jsii.get(self, "mergeQueue"))

    @builtins.property
    @jsii.member(jsii_name="pullRequest")
    def pull_request(self) -> "RepositoryRulesetRulesPullRequestOutputReference":
        return typing.cast("RepositoryRulesetRulesPullRequestOutputReference", jsii.get(self, "pullRequest"))

    @builtins.property
    @jsii.member(jsii_name="requiredCodeScanning")
    def required_code_scanning(
        self,
    ) -> "RepositoryRulesetRulesRequiredCodeScanningOutputReference":
        return typing.cast("RepositoryRulesetRulesRequiredCodeScanningOutputReference", jsii.get(self, "requiredCodeScanning"))

    @builtins.property
    @jsii.member(jsii_name="requiredDeployments")
    def required_deployments(
        self,
    ) -> "RepositoryRulesetRulesRequiredDeploymentsOutputReference":
        return typing.cast("RepositoryRulesetRulesRequiredDeploymentsOutputReference", jsii.get(self, "requiredDeployments"))

    @builtins.property
    @jsii.member(jsii_name="requiredStatusChecks")
    def required_status_checks(
        self,
    ) -> "RepositoryRulesetRulesRequiredStatusChecksOutputReference":
        return typing.cast("RepositoryRulesetRulesRequiredStatusChecksOutputReference", jsii.get(self, "requiredStatusChecks"))

    @builtins.property
    @jsii.member(jsii_name="tagNamePattern")
    def tag_name_pattern(self) -> "RepositoryRulesetRulesTagNamePatternOutputReference":
        return typing.cast("RepositoryRulesetRulesTagNamePatternOutputReference", jsii.get(self, "tagNamePattern"))

    @builtins.property
    @jsii.member(jsii_name="branchNamePatternInput")
    def branch_name_pattern_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesBranchNamePattern"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesBranchNamePattern"], jsii.get(self, "branchNamePatternInput"))

    @builtins.property
    @jsii.member(jsii_name="commitAuthorEmailPatternInput")
    def commit_author_email_pattern_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCommitAuthorEmailPattern"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesCommitAuthorEmailPattern"], jsii.get(self, "commitAuthorEmailPatternInput"))

    @builtins.property
    @jsii.member(jsii_name="commitMessagePatternInput")
    def commit_message_pattern_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCommitMessagePattern"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesCommitMessagePattern"], jsii.get(self, "commitMessagePatternInput"))

    @builtins.property
    @jsii.member(jsii_name="committerEmailPatternInput")
    def committer_email_pattern_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCommitterEmailPattern"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesCommitterEmailPattern"], jsii.get(self, "committerEmailPatternInput"))

    @builtins.property
    @jsii.member(jsii_name="copilotCodeReviewInput")
    def copilot_code_review_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesCopilotCodeReview"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesCopilotCodeReview"], jsii.get(self, "copilotCodeReviewInput"))

    @builtins.property
    @jsii.member(jsii_name="creationInput")
    def creation_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "creationInput"))

    @builtins.property
    @jsii.member(jsii_name="deletionInput")
    def deletion_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "deletionInput"))

    @builtins.property
    @jsii.member(jsii_name="fileExtensionRestrictionInput")
    def file_extension_restriction_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesFileExtensionRestriction"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesFileExtensionRestriction"], jsii.get(self, "fileExtensionRestrictionInput"))

    @builtins.property
    @jsii.member(jsii_name="filePathRestrictionInput")
    def file_path_restriction_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesFilePathRestriction"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesFilePathRestriction"], jsii.get(self, "filePathRestrictionInput"))

    @builtins.property
    @jsii.member(jsii_name="maxFilePathLengthInput")
    def max_file_path_length_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesMaxFilePathLength"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesMaxFilePathLength"], jsii.get(self, "maxFilePathLengthInput"))

    @builtins.property
    @jsii.member(jsii_name="maxFileSizeInput")
    def max_file_size_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesMaxFileSize"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesMaxFileSize"], jsii.get(self, "maxFileSizeInput"))

    @builtins.property
    @jsii.member(jsii_name="mergeQueueInput")
    def merge_queue_input(self) -> typing.Optional["RepositoryRulesetRulesMergeQueue"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesMergeQueue"], jsii.get(self, "mergeQueueInput"))

    @builtins.property
    @jsii.member(jsii_name="nonFastForwardInput")
    def non_fast_forward_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "nonFastForwardInput"))

    @builtins.property
    @jsii.member(jsii_name="pullRequestInput")
    def pull_request_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesPullRequest"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesPullRequest"], jsii.get(self, "pullRequestInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredCodeScanningInput")
    def required_code_scanning_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesRequiredCodeScanning"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesRequiredCodeScanning"], jsii.get(self, "requiredCodeScanningInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredDeploymentsInput")
    def required_deployments_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesRequiredDeployments"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesRequiredDeployments"], jsii.get(self, "requiredDeploymentsInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredLinearHistoryInput")
    def required_linear_history_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "requiredLinearHistoryInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredSignaturesInput")
    def required_signatures_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "requiredSignaturesInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredStatusChecksInput")
    def required_status_checks_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesRequiredStatusChecks"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesRequiredStatusChecks"], jsii.get(self, "requiredStatusChecksInput"))

    @builtins.property
    @jsii.member(jsii_name="tagNamePatternInput")
    def tag_name_pattern_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesTagNamePattern"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesTagNamePattern"], jsii.get(self, "tagNamePatternInput"))

    @builtins.property
    @jsii.member(jsii_name="updateAllowsFetchAndMergeInput")
    def update_allows_fetch_and_merge_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "updateAllowsFetchAndMergeInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="creation")
    def creation(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "creation"))

    @creation.setter
    def creation(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f2b6cc92095e6ae848821efbac251842611c1ca17fa78738aba08cc87841c2e4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "creation", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="deletion")
    def deletion(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "deletion"))

    @deletion.setter
    def deletion(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fc1b0f463941e2c39447f4efa0c8f07a0a8322db31b3fc7a69eb47448925eaf3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "deletion", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nonFastForward")
    def non_fast_forward(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "nonFastForward"))

    @non_fast_forward.setter
    def non_fast_forward(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2cb8386240cf127ff018d347e4c78672e6f7a280c3bf4fc19088a5c4e622849e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nonFastForward", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requiredLinearHistory")
    def required_linear_history(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "requiredLinearHistory"))

    @required_linear_history.setter
    def required_linear_history(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a76975e64162e2f578a1f28df856d6dad2e6d28d741e9462eb7ba4356d0c464)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requiredLinearHistory", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requiredSignatures")
    def required_signatures(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "requiredSignatures"))

    @required_signatures.setter
    def required_signatures(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b2a212a3c5070fa74086be5a4b51c9e94491f7cb9d91206e62be2970ce242015)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requiredSignatures", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "update"))

    @update.setter
    def update(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9bdd5e1630d2baa1e64556fedf1f7c1a0235a2954c7822573f65e9521fc15ede)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="updateAllowsFetchAndMerge")
    def update_allows_fetch_and_merge(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "updateAllowsFetchAndMerge"))

    @update_allows_fetch_and_merge.setter
    def update_allows_fetch_and_merge(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cc4363ac7ccef6f2ad1498d1867dda9c95260413c01802623305b99d4ec19938)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "updateAllowsFetchAndMerge", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["RepositoryRulesetRules"]:
        return typing.cast(typing.Optional["RepositoryRulesetRules"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional["RepositoryRulesetRules"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c1b2a05d0d1d27741acaae029edddc8d80de53e4378659e746ac43a93f31a71)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesPullRequest",
    jsii_struct_bases=[],
    name_mapping={
        "allowed_merge_methods": "allowedMergeMethods",
        "dismiss_stale_reviews_on_push": "dismissStaleReviewsOnPush",
        "require_code_owner_review": "requireCodeOwnerReview",
        "required_approving_review_count": "requiredApprovingReviewCount",
        "required_reviewers": "requiredReviewers",
        "required_review_thread_resolution": "requiredReviewThreadResolution",
        "require_last_push_approval": "requireLastPushApproval",
    },
)
class RepositoryRulesetRulesPullRequest:
    def __init__(
        self,
        *,
        allowed_merge_methods: typing.Optional[typing.Sequence[builtins.str]] = None,
        dismiss_stale_reviews_on_push: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        require_code_owner_review: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_approving_review_count: typing.Optional[jsii.Number] = None,
        required_reviewers: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetRulesPullRequestRequiredReviewers", typing.Dict[builtins.str, typing.Any]]]]] = None,
        required_review_thread_resolution: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        require_last_push_approval: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param allowed_merge_methods: Array of allowed merge methods. Allowed values include ``merge``, ``squash``, and ``rebase``. At least one option must be enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#allowed_merge_methods RepositoryRuleset#allowed_merge_methods}
        :param dismiss_stale_reviews_on_push: New, reviewable commits pushed will dismiss previous pull request review approvals. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#dismiss_stale_reviews_on_push RepositoryRuleset#dismiss_stale_reviews_on_push}
        :param require_code_owner_review: Require an approving review in pull requests that modify files that have a designated code owner. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#require_code_owner_review RepositoryRuleset#require_code_owner_review}
        :param required_approving_review_count: The number of approving reviews that are required before a pull request can be merged. Defaults to ``0``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_approving_review_count RepositoryRuleset#required_approving_review_count}
        :param required_reviewers: required_reviewers block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_reviewers RepositoryRuleset#required_reviewers}
        :param required_review_thread_resolution: All conversations on code must be resolved before a pull request can be merged. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_review_thread_resolution RepositoryRuleset#required_review_thread_resolution}
        :param require_last_push_approval: Whether the most recent reviewable push must be approved by someone other than the person who pushed it. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#require_last_push_approval RepositoryRuleset#require_last_push_approval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ce8af5f7359061668a42bea22c3d0a06ac773a2cf01770d312437b1565fc5de)
            check_type(argname="argument allowed_merge_methods", value=allowed_merge_methods, expected_type=type_hints["allowed_merge_methods"])
            check_type(argname="argument dismiss_stale_reviews_on_push", value=dismiss_stale_reviews_on_push, expected_type=type_hints["dismiss_stale_reviews_on_push"])
            check_type(argname="argument require_code_owner_review", value=require_code_owner_review, expected_type=type_hints["require_code_owner_review"])
            check_type(argname="argument required_approving_review_count", value=required_approving_review_count, expected_type=type_hints["required_approving_review_count"])
            check_type(argname="argument required_reviewers", value=required_reviewers, expected_type=type_hints["required_reviewers"])
            check_type(argname="argument required_review_thread_resolution", value=required_review_thread_resolution, expected_type=type_hints["required_review_thread_resolution"])
            check_type(argname="argument require_last_push_approval", value=require_last_push_approval, expected_type=type_hints["require_last_push_approval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if allowed_merge_methods is not None:
            self._values["allowed_merge_methods"] = allowed_merge_methods
        if dismiss_stale_reviews_on_push is not None:
            self._values["dismiss_stale_reviews_on_push"] = dismiss_stale_reviews_on_push
        if require_code_owner_review is not None:
            self._values["require_code_owner_review"] = require_code_owner_review
        if required_approving_review_count is not None:
            self._values["required_approving_review_count"] = required_approving_review_count
        if required_reviewers is not None:
            self._values["required_reviewers"] = required_reviewers
        if required_review_thread_resolution is not None:
            self._values["required_review_thread_resolution"] = required_review_thread_resolution
        if require_last_push_approval is not None:
            self._values["require_last_push_approval"] = require_last_push_approval

    @builtins.property
    def allowed_merge_methods(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Array of allowed merge methods. Allowed values include ``merge``, ``squash``, and ``rebase``. At least one option must be enabled.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#allowed_merge_methods RepositoryRuleset#allowed_merge_methods}
        '''
        result = self._values.get("allowed_merge_methods")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def dismiss_stale_reviews_on_push(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''New, reviewable commits pushed will dismiss previous pull request review approvals. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#dismiss_stale_reviews_on_push RepositoryRuleset#dismiss_stale_reviews_on_push}
        '''
        result = self._values.get("dismiss_stale_reviews_on_push")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def require_code_owner_review(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Require an approving review in pull requests that modify files that have a designated code owner. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#require_code_owner_review RepositoryRuleset#require_code_owner_review}
        '''
        result = self._values.get("require_code_owner_review")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def required_approving_review_count(self) -> typing.Optional[jsii.Number]:
        '''The number of approving reviews that are required before a pull request can be merged. Defaults to ``0``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_approving_review_count RepositoryRuleset#required_approving_review_count}
        '''
        result = self._values.get("required_approving_review_count")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def required_reviewers(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesPullRequestRequiredReviewers"]]]:
        '''required_reviewers block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_reviewers RepositoryRuleset#required_reviewers}
        '''
        result = self._values.get("required_reviewers")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesPullRequestRequiredReviewers"]]], result)

    @builtins.property
    def required_review_thread_resolution(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''All conversations on code must be resolved before a pull request can be merged. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_review_thread_resolution RepositoryRuleset#required_review_thread_resolution}
        '''
        result = self._values.get("required_review_thread_resolution")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def require_last_push_approval(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Whether the most recent reviewable push must be approved by someone other than the person who pushed it.

        Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#require_last_push_approval RepositoryRuleset#require_last_push_approval}
        '''
        result = self._values.get("require_last_push_approval")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesPullRequest(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesPullRequestOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesPullRequestOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f65eb2d078d4ba13f5e9c2099190c5be7928482ecdff248e48959d6edec67f1)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRequiredReviewers")
    def put_required_reviewers(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetRulesPullRequestRequiredReviewers", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__96a12afa919ea5260f10c3e616f584ac8dfdcdc0c53c8ea923248712632c94f3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putRequiredReviewers", [value]))

    @jsii.member(jsii_name="resetAllowedMergeMethods")
    def reset_allowed_merge_methods(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowedMergeMethods", []))

    @jsii.member(jsii_name="resetDismissStaleReviewsOnPush")
    def reset_dismiss_stale_reviews_on_push(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDismissStaleReviewsOnPush", []))

    @jsii.member(jsii_name="resetRequireCodeOwnerReview")
    def reset_require_code_owner_review(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequireCodeOwnerReview", []))

    @jsii.member(jsii_name="resetRequiredApprovingReviewCount")
    def reset_required_approving_review_count(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredApprovingReviewCount", []))

    @jsii.member(jsii_name="resetRequiredReviewers")
    def reset_required_reviewers(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredReviewers", []))

    @jsii.member(jsii_name="resetRequiredReviewThreadResolution")
    def reset_required_review_thread_resolution(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredReviewThreadResolution", []))

    @jsii.member(jsii_name="resetRequireLastPushApproval")
    def reset_require_last_push_approval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequireLastPushApproval", []))

    @builtins.property
    @jsii.member(jsii_name="requiredReviewers")
    def required_reviewers(
        self,
    ) -> "RepositoryRulesetRulesPullRequestRequiredReviewersList":
        return typing.cast("RepositoryRulesetRulesPullRequestRequiredReviewersList", jsii.get(self, "requiredReviewers"))

    @builtins.property
    @jsii.member(jsii_name="allowedMergeMethodsInput")
    def allowed_merge_methods_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "allowedMergeMethodsInput"))

    @builtins.property
    @jsii.member(jsii_name="dismissStaleReviewsOnPushInput")
    def dismiss_stale_reviews_on_push_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "dismissStaleReviewsOnPushInput"))

    @builtins.property
    @jsii.member(jsii_name="requireCodeOwnerReviewInput")
    def require_code_owner_review_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "requireCodeOwnerReviewInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredApprovingReviewCountInput")
    def required_approving_review_count_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "requiredApprovingReviewCountInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredReviewersInput")
    def required_reviewers_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesPullRequestRequiredReviewers"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesPullRequestRequiredReviewers"]]], jsii.get(self, "requiredReviewersInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredReviewThreadResolutionInput")
    def required_review_thread_resolution_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "requiredReviewThreadResolutionInput"))

    @builtins.property
    @jsii.member(jsii_name="requireLastPushApprovalInput")
    def require_last_push_approval_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "requireLastPushApprovalInput"))

    @builtins.property
    @jsii.member(jsii_name="allowedMergeMethods")
    def allowed_merge_methods(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "allowedMergeMethods"))

    @allowed_merge_methods.setter
    def allowed_merge_methods(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ca39ca2eedba9ee8efdbd79f14b07243028d6f69f8c030e1f5c7a6d9361e4cd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowedMergeMethods", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="dismissStaleReviewsOnPush")
    def dismiss_stale_reviews_on_push(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "dismissStaleReviewsOnPush"))

    @dismiss_stale_reviews_on_push.setter
    def dismiss_stale_reviews_on_push(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a475a2c03bd5b44422c21065ea3dea7a17e2d64301d79a6449fda2e354431489)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "dismissStaleReviewsOnPush", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requireCodeOwnerReview")
    def require_code_owner_review(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "requireCodeOwnerReview"))

    @require_code_owner_review.setter
    def require_code_owner_review(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98c7ba4f8f46012c5f0e7df7c84414842d44088a130faf84d7457f21e9f8688c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requireCodeOwnerReview", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requiredApprovingReviewCount")
    def required_approving_review_count(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "requiredApprovingReviewCount"))

    @required_approving_review_count.setter
    def required_approving_review_count(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__43bae8dcccd4c9151514deffc9a3a5d122f21ca7114271b9739d906fca5e1a94)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requiredApprovingReviewCount", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requiredReviewThreadResolution")
    def required_review_thread_resolution(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "requiredReviewThreadResolution"))

    @required_review_thread_resolution.setter
    def required_review_thread_resolution(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4f48cf6614429ae85f962a0e3ddbb89ad108ca446599ee6b6dbb2107f3871fad)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requiredReviewThreadResolution", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requireLastPushApproval")
    def require_last_push_approval(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "requireLastPushApproval"))

    @require_last_push_approval.setter
    def require_last_push_approval(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1912b209a345f523db2ce9a044b04966e9ffeb61a98aebea054efc4312e5ed7e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requireLastPushApproval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["RepositoryRulesetRulesPullRequest"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesPullRequest"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesPullRequest"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__beb3e19ae9aa04cad9bc4ddec34f68be5429ddac7404bb6d80143e060efb4b1b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesPullRequestRequiredReviewers",
    jsii_struct_bases=[],
    name_mapping={
        "file_patterns": "filePatterns",
        "minimum_approvals": "minimumApprovals",
        "reviewer": "reviewer",
    },
)
class RepositoryRulesetRulesPullRequestRequiredReviewers:
    def __init__(
        self,
        *,
        file_patterns: typing.Sequence[builtins.str],
        minimum_approvals: jsii.Number,
        reviewer: typing.Union["RepositoryRulesetRulesPullRequestRequiredReviewersReviewer", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''
        :param file_patterns: File patterns (fnmatch syntax) that this reviewer must approve. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#file_patterns RepositoryRuleset#file_patterns}
        :param minimum_approvals: Minimum number of approvals required from this reviewer. Set to 0 to make approval optional. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#minimum_approvals RepositoryRuleset#minimum_approvals}
        :param reviewer: reviewer block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#reviewer RepositoryRuleset#reviewer}
        '''
        if isinstance(reviewer, dict):
            reviewer = RepositoryRulesetRulesPullRequestRequiredReviewersReviewer(**reviewer)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a25c88030d83c188d01155631e9762686216b477d78ad6bb6c566c5af84e6eb7)
            check_type(argname="argument file_patterns", value=file_patterns, expected_type=type_hints["file_patterns"])
            check_type(argname="argument minimum_approvals", value=minimum_approvals, expected_type=type_hints["minimum_approvals"])
            check_type(argname="argument reviewer", value=reviewer, expected_type=type_hints["reviewer"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "file_patterns": file_patterns,
            "minimum_approvals": minimum_approvals,
            "reviewer": reviewer,
        }

    @builtins.property
    def file_patterns(self) -> typing.List[builtins.str]:
        '''File patterns (fnmatch syntax) that this reviewer must approve.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#file_patterns RepositoryRuleset#file_patterns}
        '''
        result = self._values.get("file_patterns")
        assert result is not None, "Required property 'file_patterns' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def minimum_approvals(self) -> jsii.Number:
        '''Minimum number of approvals required from this reviewer. Set to 0 to make approval optional.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#minimum_approvals RepositoryRuleset#minimum_approvals}
        '''
        result = self._values.get("minimum_approvals")
        assert result is not None, "Required property 'minimum_approvals' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def reviewer(self) -> "RepositoryRulesetRulesPullRequestRequiredReviewersReviewer":
        '''reviewer block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#reviewer RepositoryRuleset#reviewer}
        '''
        result = self._values.get("reviewer")
        assert result is not None, "Required property 'reviewer' is missing"
        return typing.cast("RepositoryRulesetRulesPullRequestRequiredReviewersReviewer", result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesPullRequestRequiredReviewers(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesPullRequestRequiredReviewersList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesPullRequestRequiredReviewersList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7505d8df4c8ac1cf5f55bad0109870a27c490b73611743b2befdc855ea42c0a9)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "RepositoryRulesetRulesPullRequestRequiredReviewersOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c59d1d3cff3e1ada4fe56532d8e1a3aa0c755fddf6ad952e4140f45a7681ecfc)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("RepositoryRulesetRulesPullRequestRequiredReviewersOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesPullRequestRequiredReviewers"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesPullRequestRequiredReviewers"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesPullRequestRequiredReviewers"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca469716235f234bd7fea3b9e2fb1e0b367f66716de11293ae22c80aaa0bb944)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class RepositoryRulesetRulesPullRequestRequiredReviewersOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesPullRequestRequiredReviewersOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b4a7feb7ac7ce2c535f5a535ec1b0526fe9e4c235b4f60cde73bdf9d671b83e4)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putReviewer")
    def put_reviewer(self, *, id: jsii.Number, type: builtins.str) -> None:
        '''
        :param id: The ID of the reviewer that must review. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#id RepositoryRuleset#id} Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param type: The type of reviewer. Currently only ``Team`` is supported. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#type RepositoryRuleset#type}
        '''
        value = RepositoryRulesetRulesPullRequestRequiredReviewersReviewer(
            id=id, type=type
        )

        return typing.cast(None, jsii.invoke(self, "putReviewer", [value]))

    @builtins.property
    @jsii.member(jsii_name="reviewer")
    def reviewer(
        self,
    ) -> "RepositoryRulesetRulesPullRequestRequiredReviewersReviewerOutputReference":
        return typing.cast("RepositoryRulesetRulesPullRequestRequiredReviewersReviewerOutputReference", jsii.get(self, "reviewer"))

    @builtins.property
    @jsii.member(jsii_name="filePatternsInput")
    def file_patterns_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "filePatternsInput"))

    @builtins.property
    @jsii.member(jsii_name="minimumApprovalsInput")
    def minimum_approvals_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "minimumApprovalsInput"))

    @builtins.property
    @jsii.member(jsii_name="reviewerInput")
    def reviewer_input(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesPullRequestRequiredReviewersReviewer"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesPullRequestRequiredReviewersReviewer"], jsii.get(self, "reviewerInput"))

    @builtins.property
    @jsii.member(jsii_name="filePatterns")
    def file_patterns(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "filePatterns"))

    @file_patterns.setter
    def file_patterns(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__968874e9ef2a5738b15845d59a242262a5344571f2d0f33c9a199c24927e08e8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "filePatterns", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="minimumApprovals")
    def minimum_approvals(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "minimumApprovals"))

    @minimum_approvals.setter
    def minimum_approvals(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__134e9217b1e9968ff0c3757ef5bbcc4f6278cf7eee50412fa7e12426ced633f9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "minimumApprovals", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetRulesPullRequestRequiredReviewers"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetRulesPullRequestRequiredReviewers"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetRulesPullRequestRequiredReviewers"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ed79a16ec4407f0ecfffa92d0a6465e578d430e8792a8baf29a087ffdb5df3ca)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesPullRequestRequiredReviewersReviewer",
    jsii_struct_bases=[],
    name_mapping={"id": "id", "type": "type"},
)
class RepositoryRulesetRulesPullRequestRequiredReviewersReviewer:
    def __init__(self, *, id: jsii.Number, type: builtins.str) -> None:
        '''
        :param id: The ID of the reviewer that must review. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#id RepositoryRuleset#id} Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param type: The type of reviewer. Currently only ``Team`` is supported. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#type RepositoryRuleset#type}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a46c634e060e8537d069648a3e1316cff002797429a9deceaf3f26c3a2977d0)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "id": id,
            "type": type,
        }

    @builtins.property
    def id(self) -> jsii.Number:
        '''The ID of the reviewer that must review.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#id RepositoryRuleset#id}

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        assert result is not None, "Required property 'id' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def type(self) -> builtins.str:
        '''The type of reviewer. Currently only ``Team`` is supported.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#type RepositoryRuleset#type}
        '''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesPullRequestRequiredReviewersReviewer(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesPullRequestRequiredReviewersReviewerOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesPullRequestRequiredReviewersReviewerOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__989b6d3a9df07faab564d4a930aeebf4e042d5d3a5f0de3233439b1274f038a0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "id"))

    @id.setter
    def id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f4ec53bb65f65d10fd1427d6633ddca31be66276368dceebe0df83f1799c615f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0616eb34c2c0594311dd64bc7cc7c47a986be2ec4ddd69161e59ec0512d7f912)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesPullRequestRequiredReviewersReviewer"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesPullRequestRequiredReviewersReviewer"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesPullRequestRequiredReviewersReviewer"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1940e7acd8990d10cebdacdab693f3c8832bc723733df28ba87ce167a4d0110b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredCodeScanning",
    jsii_struct_bases=[],
    name_mapping={"required_code_scanning_tool": "requiredCodeScanningTool"},
)
class RepositoryRulesetRulesRequiredCodeScanning:
    def __init__(
        self,
        *,
        required_code_scanning_tool: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param required_code_scanning_tool: required_code_scanning_tool block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_code_scanning_tool RepositoryRuleset#required_code_scanning_tool}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__faf3f5b43bf7738262d0396c380284a1a5261e4f39a6c001350162ff08c2c8eb)
            check_type(argname="argument required_code_scanning_tool", value=required_code_scanning_tool, expected_type=type_hints["required_code_scanning_tool"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "required_code_scanning_tool": required_code_scanning_tool,
        }

    @builtins.property
    def required_code_scanning_tool(
        self,
    ) -> typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]:
        '''required_code_scanning_tool block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_code_scanning_tool RepositoryRuleset#required_code_scanning_tool}
        '''
        result = self._values.get("required_code_scanning_tool")
        assert result is not None, "Required property 'required_code_scanning_tool' is missing"
        return typing.cast(typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesRequiredCodeScanning(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesRequiredCodeScanningOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredCodeScanningOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9cbbcfed93ea0baf3845a93bf3b44149d4e2901654cc634cbb14d57c170a7665)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRequiredCodeScanningTool")
    def put_required_code_scanning_tool(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98253cc50e2326d52a5a57c61323ea43de3874a002139b26ab9cb6c5bb8a5e51)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putRequiredCodeScanningTool", [value]))

    @builtins.property
    @jsii.member(jsii_name="requiredCodeScanningTool")
    def required_code_scanning_tool(
        self,
    ) -> "RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningToolList":
        return typing.cast("RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningToolList", jsii.get(self, "requiredCodeScanningTool"))

    @builtins.property
    @jsii.member(jsii_name="requiredCodeScanningToolInput")
    def required_code_scanning_tool_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]], jsii.get(self, "requiredCodeScanningToolInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesRequiredCodeScanning"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesRequiredCodeScanning"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesRequiredCodeScanning"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__711d1614b27db593a50875494664bb1748d08d725265b2082753829472f53c30)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool",
    jsii_struct_bases=[],
    name_mapping={
        "alerts_threshold": "alertsThreshold",
        "security_alerts_threshold": "securityAlertsThreshold",
        "tool": "tool",
    },
)
class RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool:
    def __init__(
        self,
        *,
        alerts_threshold: builtins.str,
        security_alerts_threshold: builtins.str,
        tool: builtins.str,
    ) -> None:
        '''
        :param alerts_threshold: The severity level at which code scanning results that raise alerts block a reference update. Can be one of: ``none``, ``errors``, ``errors_and_warnings``, ``all``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#alerts_threshold RepositoryRuleset#alerts_threshold}
        :param security_alerts_threshold: The severity level at which code scanning results that raise security alerts block a reference update. Can be one of: ``none``, ``critical``, ``high_or_higher``, ``medium_or_higher``, ``all``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#security_alerts_threshold RepositoryRuleset#security_alerts_threshold}
        :param tool: The name of a code scanning tool. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#tool RepositoryRuleset#tool}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5b25a8dfe92341a77c1a6bcf8ede4f7ef0850cc06993565a481dc1f2467bbbf6)
            check_type(argname="argument alerts_threshold", value=alerts_threshold, expected_type=type_hints["alerts_threshold"])
            check_type(argname="argument security_alerts_threshold", value=security_alerts_threshold, expected_type=type_hints["security_alerts_threshold"])
            check_type(argname="argument tool", value=tool, expected_type=type_hints["tool"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "alerts_threshold": alerts_threshold,
            "security_alerts_threshold": security_alerts_threshold,
            "tool": tool,
        }

    @builtins.property
    def alerts_threshold(self) -> builtins.str:
        '''The severity level at which code scanning results that raise alerts block a reference update.

        Can be one of: ``none``, ``errors``, ``errors_and_warnings``, ``all``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#alerts_threshold RepositoryRuleset#alerts_threshold}
        '''
        result = self._values.get("alerts_threshold")
        assert result is not None, "Required property 'alerts_threshold' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def security_alerts_threshold(self) -> builtins.str:
        '''The severity level at which code scanning results that raise security alerts block a reference update.

        Can be one of: ``none``, ``critical``, ``high_or_higher``, ``medium_or_higher``, ``all``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#security_alerts_threshold RepositoryRuleset#security_alerts_threshold}
        '''
        result = self._values.get("security_alerts_threshold")
        assert result is not None, "Required property 'security_alerts_threshold' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def tool(self) -> builtins.str:
        '''The name of a code scanning tool.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#tool RepositoryRuleset#tool}
        '''
        result = self._values.get("tool")
        assert result is not None, "Required property 'tool' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningToolList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningToolList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ec925237e8aa5cc850d1a6c30dc7b4556181562030213a38fe374db44827e15a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningToolOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c26caec23851796ec2fb2cdec6c078ae2c6c74f4de573a8d306a31a076bc5620)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningToolOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eb22f7dd2a0c2299f5a240d27324ce5cca605fb1815e30a56e8e467e76347e27)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningToolOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningToolOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__23d5b35c04bc14cbc5ac29f898a69d12fc57c71398073d1ded9f2ffa1b6352bc)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="alertsThresholdInput")
    def alerts_threshold_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "alertsThresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="securityAlertsThresholdInput")
    def security_alerts_threshold_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "securityAlertsThresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="toolInput")
    def tool_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "toolInput"))

    @builtins.property
    @jsii.member(jsii_name="alertsThreshold")
    def alerts_threshold(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "alertsThreshold"))

    @alerts_threshold.setter
    def alerts_threshold(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4bc2240294bcca70091c3da32fde71a17cce01d3d1df428429c9ce6125a6920b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "alertsThreshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="securityAlertsThreshold")
    def security_alerts_threshold(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "securityAlertsThreshold"))

    @security_alerts_threshold.setter
    def security_alerts_threshold(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7bfdc6d91a734876a924e0cc87bdb7427719ec6a47b0ec764dcdc54107d9383c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "securityAlertsThreshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tool")
    def tool(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tool"))

    @tool.setter
    def tool(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dd1c33b7dbcba7ad5ef899e8f542d276132f1db8a3375492867a81d3a173fb4d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tool", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d97fc56b920e6f28b29245f9b174443ced56294f8658791a3ba8613bbe2848b1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredDeployments",
    jsii_struct_bases=[],
    name_mapping={
        "required_deployment_environments": "requiredDeploymentEnvironments",
    },
)
class RepositoryRulesetRulesRequiredDeployments:
    def __init__(
        self,
        *,
        required_deployment_environments: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param required_deployment_environments: The environments that must be successfully deployed to before branches can be merged. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_deployment_environments RepositoryRuleset#required_deployment_environments}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__612af87e9d29ba9f62248ca8fc517847986f11a0f8d701c63bd08d13f625b336)
            check_type(argname="argument required_deployment_environments", value=required_deployment_environments, expected_type=type_hints["required_deployment_environments"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "required_deployment_environments": required_deployment_environments,
        }

    @builtins.property
    def required_deployment_environments(self) -> typing.List[builtins.str]:
        '''The environments that must be successfully deployed to before branches can be merged.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_deployment_environments RepositoryRuleset#required_deployment_environments}
        '''
        result = self._values.get("required_deployment_environments")
        assert result is not None, "Required property 'required_deployment_environments' is missing"
        return typing.cast(typing.List[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesRequiredDeployments(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesRequiredDeploymentsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredDeploymentsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bd1edfff8599311fb4d4df57423fea991538fad8c05345b2d00cac4a5db5173d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="requiredDeploymentEnvironmentsInput")
    def required_deployment_environments_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "requiredDeploymentEnvironmentsInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredDeploymentEnvironments")
    def required_deployment_environments(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "requiredDeploymentEnvironments"))

    @required_deployment_environments.setter
    def required_deployment_environments(
        self,
        value: typing.List[builtins.str],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__691a146fb45a8296ebe6ecfcb2abf751e1c3eadda14cf954d413a98f6fd8dd37)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requiredDeploymentEnvironments", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesRequiredDeployments"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesRequiredDeployments"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesRequiredDeployments"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d32704d8598969597b095f3f628727d19a29889029f15986c0b20cf8f776e273)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredStatusChecks",
    jsii_struct_bases=[],
    name_mapping={
        "required_check": "requiredCheck",
        "do_not_enforce_on_create": "doNotEnforceOnCreate",
        "strict_required_status_checks_policy": "strictRequiredStatusChecksPolicy",
    },
)
class RepositoryRulesetRulesRequiredStatusChecks:
    def __init__(
        self,
        *,
        required_check: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetRulesRequiredStatusChecksRequiredCheck", typing.Dict[builtins.str, typing.Any]]]],
        do_not_enforce_on_create: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        strict_required_status_checks_policy: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param required_check: required_check block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_check RepositoryRuleset#required_check}
        :param do_not_enforce_on_create: Allow repositories and branches to be created if a check would otherwise prohibit it. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#do_not_enforce_on_create RepositoryRuleset#do_not_enforce_on_create}
        :param strict_required_status_checks_policy: Whether pull requests targeting a matching branch must be tested with the latest code. This setting will not take effect unless at least one status check is enabled. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#strict_required_status_checks_policy RepositoryRuleset#strict_required_status_checks_policy}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60f71cae5271950e60b9f10aae2f6ce5a3e7106d0edce3740c68b8b5ad7d5ae4)
            check_type(argname="argument required_check", value=required_check, expected_type=type_hints["required_check"])
            check_type(argname="argument do_not_enforce_on_create", value=do_not_enforce_on_create, expected_type=type_hints["do_not_enforce_on_create"])
            check_type(argname="argument strict_required_status_checks_policy", value=strict_required_status_checks_policy, expected_type=type_hints["strict_required_status_checks_policy"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "required_check": required_check,
        }
        if do_not_enforce_on_create is not None:
            self._values["do_not_enforce_on_create"] = do_not_enforce_on_create
        if strict_required_status_checks_policy is not None:
            self._values["strict_required_status_checks_policy"] = strict_required_status_checks_policy

    @builtins.property
    def required_check(
        self,
    ) -> typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredStatusChecksRequiredCheck"]]:
        '''required_check block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#required_check RepositoryRuleset#required_check}
        '''
        result = self._values.get("required_check")
        assert result is not None, "Required property 'required_check' is missing"
        return typing.cast(typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredStatusChecksRequiredCheck"]], result)

    @builtins.property
    def do_not_enforce_on_create(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Allow repositories and branches to be created if a check would otherwise prohibit it.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#do_not_enforce_on_create RepositoryRuleset#do_not_enforce_on_create}
        '''
        result = self._values.get("do_not_enforce_on_create")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def strict_required_status_checks_policy(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Whether pull requests targeting a matching branch must be tested with the latest code.

        This setting will not take effect unless at least one status check is enabled. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#strict_required_status_checks_policy RepositoryRuleset#strict_required_status_checks_policy}
        '''
        result = self._values.get("strict_required_status_checks_policy")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesRequiredStatusChecks(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesRequiredStatusChecksOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredStatusChecksOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8b11d8126ae259ad8753f32687e26bec5c5c6ceb8481538aeb2b5cd842f36cba)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRequiredCheck")
    def put_required_check(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["RepositoryRulesetRulesRequiredStatusChecksRequiredCheck", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7089f005b5687f3db86dd9a7b1ff20a3d04461ebe7f7f23a2fb59d9f14dfc3a1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putRequiredCheck", [value]))

    @jsii.member(jsii_name="resetDoNotEnforceOnCreate")
    def reset_do_not_enforce_on_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDoNotEnforceOnCreate", []))

    @jsii.member(jsii_name="resetStrictRequiredStatusChecksPolicy")
    def reset_strict_required_status_checks_policy(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStrictRequiredStatusChecksPolicy", []))

    @builtins.property
    @jsii.member(jsii_name="requiredCheck")
    def required_check(
        self,
    ) -> "RepositoryRulesetRulesRequiredStatusChecksRequiredCheckList":
        return typing.cast("RepositoryRulesetRulesRequiredStatusChecksRequiredCheckList", jsii.get(self, "requiredCheck"))

    @builtins.property
    @jsii.member(jsii_name="doNotEnforceOnCreateInput")
    def do_not_enforce_on_create_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "doNotEnforceOnCreateInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredCheckInput")
    def required_check_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredStatusChecksRequiredCheck"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredStatusChecksRequiredCheck"]]], jsii.get(self, "requiredCheckInput"))

    @builtins.property
    @jsii.member(jsii_name="strictRequiredStatusChecksPolicyInput")
    def strict_required_status_checks_policy_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "strictRequiredStatusChecksPolicyInput"))

    @builtins.property
    @jsii.member(jsii_name="doNotEnforceOnCreate")
    def do_not_enforce_on_create(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "doNotEnforceOnCreate"))

    @do_not_enforce_on_create.setter
    def do_not_enforce_on_create(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ae4a571828d184b4e0c0871c7f6641f3c63586c03bd1e9592b510f65c019aa8d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "doNotEnforceOnCreate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="strictRequiredStatusChecksPolicy")
    def strict_required_status_checks_policy(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "strictRequiredStatusChecksPolicy"))

    @strict_required_status_checks_policy.setter
    def strict_required_status_checks_policy(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95b4075f2f3443607cfd6e3389e3378efb6f27de7f49a66da29acff1170848a0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "strictRequiredStatusChecksPolicy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["RepositoryRulesetRulesRequiredStatusChecks"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesRequiredStatusChecks"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesRequiredStatusChecks"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eccc5f8faf36bfd0426a460fc7191deab0dca329fea35cb70a106b7fce99c017)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredStatusChecksRequiredCheck",
    jsii_struct_bases=[],
    name_mapping={"context": "context", "integration_id": "integrationId"},
)
class RepositoryRulesetRulesRequiredStatusChecksRequiredCheck:
    def __init__(
        self,
        *,
        context: builtins.str,
        integration_id: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param context: The status check context name that must be present on the commit. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#context RepositoryRuleset#context}
        :param integration_id: The optional integration ID that this status check must originate from. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#integration_id RepositoryRuleset#integration_id}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c5d88915ed0c41564d2679faf599d7e70eb62bbb07c5a8246943d967d9826685)
            check_type(argname="argument context", value=context, expected_type=type_hints["context"])
            check_type(argname="argument integration_id", value=integration_id, expected_type=type_hints["integration_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "context": context,
        }
        if integration_id is not None:
            self._values["integration_id"] = integration_id

    @builtins.property
    def context(self) -> builtins.str:
        '''The status check context name that must be present on the commit.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#context RepositoryRuleset#context}
        '''
        result = self._values.get("context")
        assert result is not None, "Required property 'context' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def integration_id(self) -> typing.Optional[jsii.Number]:
        '''The optional integration ID that this status check must originate from.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#integration_id RepositoryRuleset#integration_id}
        '''
        result = self._values.get("integration_id")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesRequiredStatusChecksRequiredCheck(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesRequiredStatusChecksRequiredCheckList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredStatusChecksRequiredCheckList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__faa9d457385c2673d4bf4623144f803853c0b5ed026f7b8d95effb9823328e75)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "RepositoryRulesetRulesRequiredStatusChecksRequiredCheckOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__942dff4a7a58c46bd164493791dd1873f1e0221249753da8c054e2d1ef71931a)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("RepositoryRulesetRulesRequiredStatusChecksRequiredCheckOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredStatusChecksRequiredCheck"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredStatusChecksRequiredCheck"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["RepositoryRulesetRulesRequiredStatusChecksRequiredCheck"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98256a71e808bcf6ed6caf1310f81fd7e20cf50fa6e43e2d25429522c5d6f072)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class RepositoryRulesetRulesRequiredStatusChecksRequiredCheckOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesRequiredStatusChecksRequiredCheckOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80261936ef51904a631d266dd9a796f482d1b189fd0c5a1548fa8a470611f14e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetIntegrationId")
    def reset_integration_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIntegrationId", []))

    @builtins.property
    @jsii.member(jsii_name="contextInput")
    def context_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "contextInput"))

    @builtins.property
    @jsii.member(jsii_name="integrationIdInput")
    def integration_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "integrationIdInput"))

    @builtins.property
    @jsii.member(jsii_name="context")
    def context(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "context"))

    @context.setter
    def context(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80cc7615721d68e930ee75c4594d971376a63b517e4d0922faa4977b49beeb42)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "context", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="integrationId")
    def integration_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "integrationId"))

    @integration_id.setter
    def integration_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fc722bc9ea505803b9e4f6ab6aa6f0a12aa7e9a19e347bde3ff0011c2cd95529)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "integrationId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetRulesRequiredStatusChecksRequiredCheck"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetRulesRequiredStatusChecksRequiredCheck"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "RepositoryRulesetRulesRequiredStatusChecksRequiredCheck"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7972e3e38e11a85710f03a3ec591c617e99d74713602eb5880174667e2a4820c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesTagNamePattern",
    jsii_struct_bases=[],
    name_mapping={
        "operator": "operator",
        "pattern": "pattern",
        "name": "name",
        "negate": "negate",
    },
)
class RepositoryRulesetRulesTagNamePattern:
    def __init__(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d88fa9aa86d1e6a754ffa373d00ab0e1ddf6bf3d457a7e2c732c911568183f3d)
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument negate", value=negate, expected_type=type_hints["negate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "operator": operator,
            "pattern": pattern,
        }
        if name is not None:
            self._values["name"] = name
        if negate is not None:
            self._values["negate"] = negate

    @builtins.property
    def operator(self) -> builtins.str:
        '''The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#operator RepositoryRuleset#operator}
        '''
        result = self._values.get("operator")
        assert result is not None, "Required property 'operator' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pattern(self) -> builtins.str:
        '''The pattern to match with.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#pattern RepositoryRuleset#pattern}
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''How this rule will appear to users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#name RepositoryRuleset#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def negate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''If true, the rule will fail if the pattern matches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/repository_ruleset#negate RepositoryRuleset#negate}
        '''
        result = self._values.get("negate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RepositoryRulesetRulesTagNamePattern(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class RepositoryRulesetRulesTagNamePatternOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.repositoryRuleset.RepositoryRulesetRulesTagNamePatternOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d7a085ae25bba9775f5ef0e525cdc2c799885dff45a21395881430d128e015a4)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetNegate")
    def reset_negate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNegate", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="negateInput")
    def negate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "negateInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="patternInput")
    def pattern_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "patternInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__32bcb9161d886c6c439a9be91dda0ad9f099b1e6a3a7ed1a7bf64daff1c7f8a6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="negate")
    def negate(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "negate"))

    @negate.setter
    def negate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2964c47736df400e42401618f8dac906724da53384aa393b06fec475560cd3a0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "negate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__03c72c7bd1b25678df61c8bde791d689669cad9d7674fd4eb105bd0899662130)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="pattern")
    def pattern(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "pattern"))

    @pattern.setter
    def pattern(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9db2f1787638254a11f831c9066750a1139f5b772bca7730a6d5ca63220049cb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "pattern", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["RepositoryRulesetRulesTagNamePattern"]:
        return typing.cast(typing.Optional["RepositoryRulesetRulesTagNamePattern"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["RepositoryRulesetRulesTagNamePattern"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a22c8e90f11d70e118cd7ef77b256587bcb1f41ef3f08f05a0e35356ce1d7142)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "RepositoryRuleset",
    "RepositoryRulesetBypassActors",
    "RepositoryRulesetBypassActorsList",
    "RepositoryRulesetBypassActorsOutputReference",
    "RepositoryRulesetConditions",
    "RepositoryRulesetConditionsOutputReference",
    "RepositoryRulesetConditionsRefName",
    "RepositoryRulesetConditionsRefNameOutputReference",
    "RepositoryRulesetConfig",
    "RepositoryRulesetRules",
    "RepositoryRulesetRulesBranchNamePattern",
    "RepositoryRulesetRulesBranchNamePatternOutputReference",
    "RepositoryRulesetRulesCommitAuthorEmailPattern",
    "RepositoryRulesetRulesCommitAuthorEmailPatternOutputReference",
    "RepositoryRulesetRulesCommitMessagePattern",
    "RepositoryRulesetRulesCommitMessagePatternOutputReference",
    "RepositoryRulesetRulesCommitterEmailPattern",
    "RepositoryRulesetRulesCommitterEmailPatternOutputReference",
    "RepositoryRulesetRulesCopilotCodeReview",
    "RepositoryRulesetRulesCopilotCodeReviewOutputReference",
    "RepositoryRulesetRulesFileExtensionRestriction",
    "RepositoryRulesetRulesFileExtensionRestrictionOutputReference",
    "RepositoryRulesetRulesFilePathRestriction",
    "RepositoryRulesetRulesFilePathRestrictionOutputReference",
    "RepositoryRulesetRulesMaxFilePathLength",
    "RepositoryRulesetRulesMaxFilePathLengthOutputReference",
    "RepositoryRulesetRulesMaxFileSize",
    "RepositoryRulesetRulesMaxFileSizeOutputReference",
    "RepositoryRulesetRulesMergeQueue",
    "RepositoryRulesetRulesMergeQueueOutputReference",
    "RepositoryRulesetRulesOutputReference",
    "RepositoryRulesetRulesPullRequest",
    "RepositoryRulesetRulesPullRequestOutputReference",
    "RepositoryRulesetRulesPullRequestRequiredReviewers",
    "RepositoryRulesetRulesPullRequestRequiredReviewersList",
    "RepositoryRulesetRulesPullRequestRequiredReviewersOutputReference",
    "RepositoryRulesetRulesPullRequestRequiredReviewersReviewer",
    "RepositoryRulesetRulesPullRequestRequiredReviewersReviewerOutputReference",
    "RepositoryRulesetRulesRequiredCodeScanning",
    "RepositoryRulesetRulesRequiredCodeScanningOutputReference",
    "RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool",
    "RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningToolList",
    "RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningToolOutputReference",
    "RepositoryRulesetRulesRequiredDeployments",
    "RepositoryRulesetRulesRequiredDeploymentsOutputReference",
    "RepositoryRulesetRulesRequiredStatusChecks",
    "RepositoryRulesetRulesRequiredStatusChecksOutputReference",
    "RepositoryRulesetRulesRequiredStatusChecksRequiredCheck",
    "RepositoryRulesetRulesRequiredStatusChecksRequiredCheckList",
    "RepositoryRulesetRulesRequiredStatusChecksRequiredCheckOutputReference",
    "RepositoryRulesetRulesTagNamePattern",
    "RepositoryRulesetRulesTagNamePatternOutputReference",
]

publication.publish()

def _typecheckingstub__eb822e129d01ac39a2a54c4ae0a14ccb3e193adf4f7160cac121eaa0b807cb47(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    enforcement: builtins.str,
    name: builtins.str,
    repository: builtins.str,
    rules: typing.Union[RepositoryRulesetRules, typing.Dict[builtins.str, typing.Any]],
    target: builtins.str,
    bypass_actors: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[RepositoryRulesetBypassActors, typing.Dict[builtins.str, typing.Any]]]]] = None,
    conditions: typing.Optional[typing.Union[RepositoryRulesetConditions, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba03999ed55e971e4528be74bf7c8712ba6dfb9ca7327d704649f164e301248d(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__38eccb1fabe6cbaab18ed5112fadae34d8fb1cdc800d1889d69c9e229724473d(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[RepositoryRulesetBypassActors, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6da98b82d303fc737a68dd9c0c06d86dfca16079cdf6a2a2710f571bc857a5d0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6b6fe62c59d41fd2537c85203c938d2e93d8435f6d46e671bd68e741eb5fbda3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__540cfabeb705510f5feaf912f9ff8e9e157f6e04943cc2ef4cfe94809065558d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97f273f05eb8111defaed1aa3c62c2b19c8be18db3a9ccc73fc83c6c86781a04(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__299fb8aaaa1c7d1572a18fa173341c3fee9c02477936b905cbed5c85d8944a9b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3358474d69de0ce04a30eeafc3ca9d4a40138d24fa8051cf22141a15af87a06b(
    *,
    actor_type: builtins.str,
    bypass_mode: builtins.str,
    actor_id: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__044cf360a17c1765874bc2322d58b3d0ad772777e5e07a1490b2c11300d9f2f1(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7bfb271d77f83f10a3d2492f070c2f25720d79ed5e9f4edd288b098386919854(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__12fccf8ccda84959b5adfe082e33a04a63007ff451a77e66287bc3543b53f403(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[RepositoryRulesetBypassActors]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f8cdb4354f612e4332561a4c288314e6f5da71779856332490aa31a3078e3a7f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b0f29cfa0b9f3866b48aec7c5a5f5de89b1bc87b4280c109d4a944b6e3cf2b57(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c2aca9c2b7e806cb1da0022f564ef9c8d24ccdf8594a54ce3fd82838556ccdd9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ab07848a2251a8ef31273e6791173572f158d4572dafc8eb7eb65cef123a10c4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8fbaed0b0af2c2ed2f624733db219ccfc333dd75746e17b1fd7d68396e8fa60b(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, RepositoryRulesetBypassActors]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4459967fad647222bb5b3b7c96355e9a4e649936ebecc7247acabcae8f77c4d0(
    *,
    ref_name: typing.Union[RepositoryRulesetConditionsRefName, typing.Dict[builtins.str, typing.Any]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08c5fd43bf9c3bf7ceb31761050faee449784cf94a4955f56d6012227626a612(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__26035c016807e7ff97c42ac555ce81ece6c74fd3305c493d151a1a8f59b7c787(
    value: typing.Optional[RepositoryRulesetConditions],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77141029ab2b279256149fdc05878bfc3617277765545be53e69b98c49accf7d(
    *,
    exclude: typing.Sequence[builtins.str],
    include: typing.Sequence[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b53d57e305ce599d9e892b312ef6176aa0d7d7e225a556c17133f09f8e50f510(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__88cf4412259ebb0ebb14abf57b7ce709cef22fc2f1938b2214c94a5de41b20ca(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd2d0c748d8e62056da404ea4c6e97a62b56391bd48041169613e81b04929aa6(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8bb94f8cc29b0899a6023795d910ca11eb33c222e65375098dc02200a34d3554(
    value: typing.Optional[RepositoryRulesetConditionsRefName],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8360b99d395a622ffb13ffae7c5632ff1fafff24c1925873aabc58a630539b20(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    enforcement: builtins.str,
    name: builtins.str,
    repository: builtins.str,
    rules: typing.Union[RepositoryRulesetRules, typing.Dict[builtins.str, typing.Any]],
    target: builtins.str,
    bypass_actors: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[RepositoryRulesetBypassActors, typing.Dict[builtins.str, typing.Any]]]]] = None,
    conditions: typing.Optional[typing.Union[RepositoryRulesetConditions, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41cfe0d393f819e1714eafb94eb7bff31d7b879a9efa27a1fb77aed74993c0b3(
    *,
    branch_name_pattern: typing.Optional[typing.Union[RepositoryRulesetRulesBranchNamePattern, typing.Dict[builtins.str, typing.Any]]] = None,
    commit_author_email_pattern: typing.Optional[typing.Union[RepositoryRulesetRulesCommitAuthorEmailPattern, typing.Dict[builtins.str, typing.Any]]] = None,
    commit_message_pattern: typing.Optional[typing.Union[RepositoryRulesetRulesCommitMessagePattern, typing.Dict[builtins.str, typing.Any]]] = None,
    committer_email_pattern: typing.Optional[typing.Union[RepositoryRulesetRulesCommitterEmailPattern, typing.Dict[builtins.str, typing.Any]]] = None,
    copilot_code_review: typing.Optional[typing.Union[RepositoryRulesetRulesCopilotCodeReview, typing.Dict[builtins.str, typing.Any]]] = None,
    creation: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    deletion: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    file_extension_restriction: typing.Optional[typing.Union[RepositoryRulesetRulesFileExtensionRestriction, typing.Dict[builtins.str, typing.Any]]] = None,
    file_path_restriction: typing.Optional[typing.Union[RepositoryRulesetRulesFilePathRestriction, typing.Dict[builtins.str, typing.Any]]] = None,
    max_file_path_length: typing.Optional[typing.Union[RepositoryRulesetRulesMaxFilePathLength, typing.Dict[builtins.str, typing.Any]]] = None,
    max_file_size: typing.Optional[typing.Union[RepositoryRulesetRulesMaxFileSize, typing.Dict[builtins.str, typing.Any]]] = None,
    merge_queue: typing.Optional[typing.Union[RepositoryRulesetRulesMergeQueue, typing.Dict[builtins.str, typing.Any]]] = None,
    non_fast_forward: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    pull_request: typing.Optional[typing.Union[RepositoryRulesetRulesPullRequest, typing.Dict[builtins.str, typing.Any]]] = None,
    required_code_scanning: typing.Optional[typing.Union[RepositoryRulesetRulesRequiredCodeScanning, typing.Dict[builtins.str, typing.Any]]] = None,
    required_deployments: typing.Optional[typing.Union[RepositoryRulesetRulesRequiredDeployments, typing.Dict[builtins.str, typing.Any]]] = None,
    required_linear_history: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    required_signatures: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    required_status_checks: typing.Optional[typing.Union[RepositoryRulesetRulesRequiredStatusChecks, typing.Dict[builtins.str, typing.Any]]] = None,
    tag_name_pattern: typing.Optional[typing.Union[RepositoryRulesetRulesTagNamePattern, typing.Dict[builtins.str, typing.Any]]] = None,
    update: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    update_allows_fetch_and_merge: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a0bd195224fee6e5b5d8f9dc50f63734f7e300fa2e713d86d3e11b3fb688a7e3(
    *,
    operator: builtins.str,
    pattern: builtins.str,
    name: typing.Optional[builtins.str] = None,
    negate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f3c8e6eebe44c77a2a3dd6ffe91a3acb69cc9acd5940f9634d509cf05c092bd(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1d0d957e74ef3218d6e13b7b5bd153eb0e33b5944a0c8e4102b7a9ab7c0566f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb8fb2c784aa40c130701f02dcd16c505cf7b0134034a1109d005d37b2a61f0b(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__22c59b1180e905f674e28f9fbb303206833bc0f603192cb904ba871bd157b797(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0cb985c6e531046fce2ffe959d6f0f80bd7df67761c496c157a994d49ba9e076(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__614c41d70afc256689918efb3a5b2770b369ac70dbbe12a3299ad76e67674331(
    value: typing.Optional[RepositoryRulesetRulesBranchNamePattern],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a482ebc12f0e8de727c2cbc98b6cd86917668d5c457a9af732b4006490ad38ee(
    *,
    operator: builtins.str,
    pattern: builtins.str,
    name: typing.Optional[builtins.str] = None,
    negate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3cca58c4758c232159f38cb342df0ff33f097c324db59b2cb22237d63e3c75cb(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5200d1751f1255f664dfc4d80059bdad02a8f57d87a8e6fa06211f7fae38d75b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6b079670eeca2c5d143848bdadaa7aa16f0997460f56221713ef59373c77e879(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3c66128daf55bb07b50835efa0402cebab9e6ef47f2c06f7b034924d4e6d72d4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db12df409ecca015f5c330b1646c788dfb1e3553d72a110de141e511c9c90741(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b5954dc28397f09d54cf0b355dc2995e3b308c84c76738daa1ed73a039a05df0(
    value: typing.Optional[RepositoryRulesetRulesCommitAuthorEmailPattern],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9cb51220900698b1ff2761e84e72b015266eb9ead30377bd177797beb4d8b810(
    *,
    operator: builtins.str,
    pattern: builtins.str,
    name: typing.Optional[builtins.str] = None,
    negate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b379421b7d15719ebbe408a83a4eee5e6b78078ad455b6119e1ce1841657402(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b1e22e32dc7eb7d68eda5fedcfaa339d8fb006d248769c8c460e45391bc1d5df(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e405dbfcc33210571c045ec21462d07dfa6207f994e28137059161f4ebed3daf(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8932214aac2b2c1167822929b8e8524d02e593f62014236ca85b3f13c7e93798(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__30e743ac5876b3ae8710aed5337b6e4552976b0fb2c4ade690dcf22f777db234(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a259ce0aa7c9d3f495a25fa086d5d68b3115bd9d3d1847522f8a96b0f9292195(
    value: typing.Optional[RepositoryRulesetRulesCommitMessagePattern],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3d96e9e8bcc0b705759218e11533eb78ae36592e1504228b10d07d6bece3b6db(
    *,
    operator: builtins.str,
    pattern: builtins.str,
    name: typing.Optional[builtins.str] = None,
    negate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__715911b0c2edf4b3f7d03ec7aba2148118bf66e5823f56825763b66a86897838(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9123eff769e095a9d9d5feff8939ca1494cc51d751588907ec07fc1d0e420332(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a89fc304bc6cf69487c2065b9a08c889f4df0fee42276524e78f476d88cabee2(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__46df13bcf4c08816537c696c46f47d02e44349333b3f5673e32fe3417972117c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1bc99173941398cb72284b11cc265bed7be4e72af6532fd8373a49aed08ec135(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__91be953ca25337e211cadea6cf9ee8a1bcaff9829b31795971497d0e1f1c2218(
    value: typing.Optional[RepositoryRulesetRulesCommitterEmailPattern],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77e8c12edf8ee169531bb808a8e04e48e02c00393bf97c92154433c661264418(
    *,
    review_draft_pull_requests: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    review_on_push: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__04eaeacf632ae2fec128ae42ce245603f7d87ee11b89045f429f125f54035e67(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97062fdf2165637cdc73352686626fa2d1c6970250d71a6a3cf0e949e399c33b(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d611570e24435a9bd3922531eac393cf0308f1fffc256b69e14a4373b709e858(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b9b31f84907148d208cb556ba6706686593b75a3f587b5c7c4934af9c27e6c05(
    value: typing.Optional[RepositoryRulesetRulesCopilotCodeReview],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eb18d274717ccf2dafc3fb05078ac7b13b196658c237aad5766f64a751830d59(
    *,
    restricted_file_extensions: typing.Sequence[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0710914d59b39d442a399018480e2f2af67dd0cd8bcc12da9b2f3271b879ff4c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ca2d16c4c76139297b20d5c38d6efe52919573cd62de617c1814599a3d36d63(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a5701f8d75c0ddc2c728742a12c9d817a93b09acbbd35010e676b707b87b04c(
    value: typing.Optional[RepositoryRulesetRulesFileExtensionRestriction],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f6521fb90b50899722a31b1c9034b327bc4d6450ea088a069434d85701b4b687(
    *,
    restricted_file_paths: typing.Sequence[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b701db0d1eb193265bb926c142d24e87e56505db9f77bc7f64cab67d9209900(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92f30f66c358105f5915ceaf639dca5d39f5be1e773fe52fd37d9c7fc8756701(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__99276d27a7c830e71669c4b5b5725a5e0ee83f477c7ff017319f6aba5c75bada(
    value: typing.Optional[RepositoryRulesetRulesFilePathRestriction],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fa059653b72c9523c4213aaf7f6e862d800d4b94a2ad285fdf8f0b46f0e5c26d(
    *,
    max_file_path_length: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__21d19dfc771901da172a78809de7184ba536462f5076c1cc311d99d19d9fd444(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__18f039bb81b1b7f9376b294dd11ad5fcb8dbcd98d7b654e7d4f3ded44a339c47(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__16faa98f0fe2b9deb40dffbe693b46f8d93e8b54266bc1ff5d475781038f91c3(
    value: typing.Optional[RepositoryRulesetRulesMaxFilePathLength],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5967d9f3b382caf6530500d026ddc3ab0020fd9986eb2656d462021781e67fe2(
    *,
    max_file_size: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__94ac6eddc33a0f52a557193869df83c9fa1ae806893f1eaea42f721a5a39dff3(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08a0324fccdf3c7e34499955fe02e0f244a907a35bb4419ab80490a7d4bfb0fb(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8f838845f14cd17e269910315c8e2a167a2e37791b35c79a4e13661814e2ed80(
    value: typing.Optional[RepositoryRulesetRulesMaxFileSize],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__132e2a5f4a1eedfc1c648d5f44a6a3bbc97e069112cdc4193b93256adee02764(
    *,
    check_response_timeout_minutes: typing.Optional[jsii.Number] = None,
    grouping_strategy: typing.Optional[builtins.str] = None,
    max_entries_to_build: typing.Optional[jsii.Number] = None,
    max_entries_to_merge: typing.Optional[jsii.Number] = None,
    merge_method: typing.Optional[builtins.str] = None,
    min_entries_to_merge: typing.Optional[jsii.Number] = None,
    min_entries_to_merge_wait_minutes: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a0789fdfae4da34a76d537ab14a1e8e45bd24ca1f7143c407cca1225767509a(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41b28354c938c484a9e5910a969584f5d3330d9aaea2d35715df176fcf6cb87a(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3624baaa31a64ebaa6a629ccbc6668a6a4e10a9e12ea569026b5d9083c1880d4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb504dee78105ee060757edfc1ab3fd2d06fe3ea164d0a809f8e2cece899ecec(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c1816906c2b2ca18edc5cbd721e8ebebd62904f541e7cfe326848624286e8074(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a8efb42af770e0d493cb85323782d49635a20949f9241ca968d1dd4b2aa093fd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a1a21a2be53774b02c20b93a297ecbbdf6af1280883c28a47f869c7fef702ae5(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb7fdd56881a417992330c21969c49cda5b9a6006723f5132fdfeef412a717ff(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3f4493519314f69ac9c19ad3b149a6fd4f6b7ccf17e86024680f0dcdbbc7808(
    value: typing.Optional[RepositoryRulesetRulesMergeQueue],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b98d4b65d139a0785dadda48e081142aa066d55034029ad6bcdffcb9e3f06d03(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f2b6cc92095e6ae848821efbac251842611c1ca17fa78738aba08cc87841c2e4(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc1b0f463941e2c39447f4efa0c8f07a0a8322db31b3fc7a69eb47448925eaf3(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2cb8386240cf127ff018d347e4c78672e6f7a280c3bf4fc19088a5c4e622849e(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a76975e64162e2f578a1f28df856d6dad2e6d28d741e9462eb7ba4356d0c464(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b2a212a3c5070fa74086be5a4b51c9e94491f7cb9d91206e62be2970ce242015(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9bdd5e1630d2baa1e64556fedf1f7c1a0235a2954c7822573f65e9521fc15ede(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cc4363ac7ccef6f2ad1498d1867dda9c95260413c01802623305b99d4ec19938(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c1b2a05d0d1d27741acaae029edddc8d80de53e4378659e746ac43a93f31a71(
    value: typing.Optional[RepositoryRulesetRules],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ce8af5f7359061668a42bea22c3d0a06ac773a2cf01770d312437b1565fc5de(
    *,
    allowed_merge_methods: typing.Optional[typing.Sequence[builtins.str]] = None,
    dismiss_stale_reviews_on_push: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    require_code_owner_review: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    required_approving_review_count: typing.Optional[jsii.Number] = None,
    required_reviewers: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[RepositoryRulesetRulesPullRequestRequiredReviewers, typing.Dict[builtins.str, typing.Any]]]]] = None,
    required_review_thread_resolution: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    require_last_push_approval: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f65eb2d078d4ba13f5e9c2099190c5be7928482ecdff248e48959d6edec67f1(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__96a12afa919ea5260f10c3e616f584ac8dfdcdc0c53c8ea923248712632c94f3(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[RepositoryRulesetRulesPullRequestRequiredReviewers, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ca39ca2eedba9ee8efdbd79f14b07243028d6f69f8c030e1f5c7a6d9361e4cd(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a475a2c03bd5b44422c21065ea3dea7a17e2d64301d79a6449fda2e354431489(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98c7ba4f8f46012c5f0e7df7c84414842d44088a130faf84d7457f21e9f8688c(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__43bae8dcccd4c9151514deffc9a3a5d122f21ca7114271b9739d906fca5e1a94(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f48cf6614429ae85f962a0e3ddbb89ad108ca446599ee6b6dbb2107f3871fad(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1912b209a345f523db2ce9a044b04966e9ffeb61a98aebea054efc4312e5ed7e(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__beb3e19ae9aa04cad9bc4ddec34f68be5429ddac7404bb6d80143e060efb4b1b(
    value: typing.Optional[RepositoryRulesetRulesPullRequest],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a25c88030d83c188d01155631e9762686216b477d78ad6bb6c566c5af84e6eb7(
    *,
    file_patterns: typing.Sequence[builtins.str],
    minimum_approvals: jsii.Number,
    reviewer: typing.Union[RepositoryRulesetRulesPullRequestRequiredReviewersReviewer, typing.Dict[builtins.str, typing.Any]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7505d8df4c8ac1cf5f55bad0109870a27c490b73611743b2befdc855ea42c0a9(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c59d1d3cff3e1ada4fe56532d8e1a3aa0c755fddf6ad952e4140f45a7681ecfc(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca469716235f234bd7fea3b9e2fb1e0b367f66716de11293ae22c80aaa0bb944(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[RepositoryRulesetRulesPullRequestRequiredReviewers]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b4a7feb7ac7ce2c535f5a535ec1b0526fe9e4c235b4f60cde73bdf9d671b83e4(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__968874e9ef2a5738b15845d59a242262a5344571f2d0f33c9a199c24927e08e8(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__134e9217b1e9968ff0c3757ef5bbcc4f6278cf7eee50412fa7e12426ced633f9(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ed79a16ec4407f0ecfffa92d0a6465e578d430e8792a8baf29a087ffdb5df3ca(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, RepositoryRulesetRulesPullRequestRequiredReviewers]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a46c634e060e8537d069648a3e1316cff002797429a9deceaf3f26c3a2977d0(
    *,
    id: jsii.Number,
    type: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__989b6d3a9df07faab564d4a930aeebf4e042d5d3a5f0de3233439b1274f038a0(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f4ec53bb65f65d10fd1427d6633ddca31be66276368dceebe0df83f1799c615f(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0616eb34c2c0594311dd64bc7cc7c47a986be2ec4ddd69161e59ec0512d7f912(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1940e7acd8990d10cebdacdab693f3c8832bc723733df28ba87ce167a4d0110b(
    value: typing.Optional[RepositoryRulesetRulesPullRequestRequiredReviewersReviewer],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__faf3f5b43bf7738262d0396c380284a1a5261e4f39a6c001350162ff08c2c8eb(
    *,
    required_code_scanning_tool: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9cbbcfed93ea0baf3845a93bf3b44149d4e2901654cc634cbb14d57c170a7665(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98253cc50e2326d52a5a57c61323ea43de3874a002139b26ab9cb6c5bb8a5e51(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__711d1614b27db593a50875494664bb1748d08d725265b2082753829472f53c30(
    value: typing.Optional[RepositoryRulesetRulesRequiredCodeScanning],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5b25a8dfe92341a77c1a6bcf8ede4f7ef0850cc06993565a481dc1f2467bbbf6(
    *,
    alerts_threshold: builtins.str,
    security_alerts_threshold: builtins.str,
    tool: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ec925237e8aa5cc850d1a6c30dc7b4556181562030213a38fe374db44827e15a(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c26caec23851796ec2fb2cdec6c078ae2c6c74f4de573a8d306a31a076bc5620(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eb22f7dd2a0c2299f5a240d27324ce5cca605fb1815e30a56e8e467e76347e27(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__23d5b35c04bc14cbc5ac29f898a69d12fc57c71398073d1ded9f2ffa1b6352bc(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4bc2240294bcca70091c3da32fde71a17cce01d3d1df428429c9ce6125a6920b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7bfdc6d91a734876a924e0cc87bdb7427719ec6a47b0ec764dcdc54107d9383c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dd1c33b7dbcba7ad5ef899e8f542d276132f1db8a3375492867a81d3a173fb4d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d97fc56b920e6f28b29245f9b174443ced56294f8658791a3ba8613bbe2848b1(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, RepositoryRulesetRulesRequiredCodeScanningRequiredCodeScanningTool]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__612af87e9d29ba9f62248ca8fc517847986f11a0f8d701c63bd08d13f625b336(
    *,
    required_deployment_environments: typing.Sequence[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd1edfff8599311fb4d4df57423fea991538fad8c05345b2d00cac4a5db5173d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__691a146fb45a8296ebe6ecfcb2abf751e1c3eadda14cf954d413a98f6fd8dd37(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d32704d8598969597b095f3f628727d19a29889029f15986c0b20cf8f776e273(
    value: typing.Optional[RepositoryRulesetRulesRequiredDeployments],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60f71cae5271950e60b9f10aae2f6ce5a3e7106d0edce3740c68b8b5ad7d5ae4(
    *,
    required_check: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[RepositoryRulesetRulesRequiredStatusChecksRequiredCheck, typing.Dict[builtins.str, typing.Any]]]],
    do_not_enforce_on_create: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    strict_required_status_checks_policy: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8b11d8126ae259ad8753f32687e26bec5c5c6ceb8481538aeb2b5cd842f36cba(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7089f005b5687f3db86dd9a7b1ff20a3d04461ebe7f7f23a2fb59d9f14dfc3a1(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[RepositoryRulesetRulesRequiredStatusChecksRequiredCheck, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ae4a571828d184b4e0c0871c7f6641f3c63586c03bd1e9592b510f65c019aa8d(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95b4075f2f3443607cfd6e3389e3378efb6f27de7f49a66da29acff1170848a0(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eccc5f8faf36bfd0426a460fc7191deab0dca329fea35cb70a106b7fce99c017(
    value: typing.Optional[RepositoryRulesetRulesRequiredStatusChecks],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c5d88915ed0c41564d2679faf599d7e70eb62bbb07c5a8246943d967d9826685(
    *,
    context: builtins.str,
    integration_id: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__faa9d457385c2673d4bf4623144f803853c0b5ed026f7b8d95effb9823328e75(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__942dff4a7a58c46bd164493791dd1873f1e0221249753da8c054e2d1ef71931a(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98256a71e808bcf6ed6caf1310f81fd7e20cf50fa6e43e2d25429522c5d6f072(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[RepositoryRulesetRulesRequiredStatusChecksRequiredCheck]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80261936ef51904a631d266dd9a796f482d1b189fd0c5a1548fa8a470611f14e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80cc7615721d68e930ee75c4594d971376a63b517e4d0922faa4977b49beeb42(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc722bc9ea505803b9e4f6ab6aa6f0a12aa7e9a19e347bde3ff0011c2cd95529(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7972e3e38e11a85710f03a3ec591c617e99d74713602eb5880174667e2a4820c(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, RepositoryRulesetRulesRequiredStatusChecksRequiredCheck]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d88fa9aa86d1e6a754ffa373d00ab0e1ddf6bf3d457a7e2c732c911568183f3d(
    *,
    operator: builtins.str,
    pattern: builtins.str,
    name: typing.Optional[builtins.str] = None,
    negate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d7a085ae25bba9775f5ef0e525cdc2c799885dff45a21395881430d128e015a4(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__32bcb9161d886c6c439a9be91dda0ad9f099b1e6a3a7ed1a7bf64daff1c7f8a6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2964c47736df400e42401618f8dac906724da53384aa393b06fec475560cd3a0(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__03c72c7bd1b25678df61c8bde791d689669cad9d7674fd4eb105bd0899662130(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9db2f1787638254a11f831c9066750a1139f5b772bca7730a6d5ca63220049cb(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a22c8e90f11d70e118cd7ef77b256587bcb1f41ef3f08f05a0e35356ce1d7142(
    value: typing.Optional[RepositoryRulesetRulesTagNamePattern],
) -> None:
    """Type checking stubs"""
    pass
