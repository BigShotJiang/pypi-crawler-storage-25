r'''
# `github_organization_ruleset`

Refer to the Terraform Registry for docs: [`github_organization_ruleset`](https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class OrganizationRuleset(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRuleset",
):
    '''Represents a {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset github_organization_ruleset}.'''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id_: builtins.str,
        *,
        enforcement: builtins.str,
        name: builtins.str,
        rules: typing.Union["OrganizationRulesetRules", typing.Dict[builtins.str, typing.Any]],
        target: builtins.str,
        bypass_actors: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetBypassActors", typing.Dict[builtins.str, typing.Any]]]]] = None,
        conditions: typing.Optional[typing.Union["OrganizationRulesetConditions", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset github_organization_ruleset} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param enforcement: The enforcement level of the ruleset. ``evaluate`` allows admins to test rules before enforcing them. Possible values are ``disabled``, ``active``, and ``evaluate``. Note: ``evaluate`` is only available for Enterprise plans. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#enforcement OrganizationRuleset#enforcement}
        :param name: The name of the ruleset. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param rules: rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#rules OrganizationRuleset#rules}
        :param target: The target of the ruleset. Possible values are branch, tag and push. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#target OrganizationRuleset#target}
        :param bypass_actors: bypass_actors block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#bypass_actors OrganizationRuleset#bypass_actors}
        :param conditions: conditions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#conditions OrganizationRuleset#conditions}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#id OrganizationRuleset#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__96e7f700b9d7c72ceb60cd5853bd63ec7f8fd3812d35a25b7245cdd550f72ac8)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = OrganizationRulesetConfig(
            enforcement=enforcement,
            name=name,
            rules=rules,
            target=target,
            bypass_actors=bypass_actors,
            conditions=conditions,
            id=id,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
    ) -> "_cdktn_78ede62e.ImportableResource":
        '''Generates CDKTN code for importing a OrganizationRuleset resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the OrganizationRuleset to import.
        :param import_from_id: The id of the existing OrganizationRuleset that should be imported. Refer to the {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the OrganizationRuleset to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5240e75b1e9f53673409e43d0c3e520e5ef9222608d889d1497086c2236d5148)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast("_cdktn_78ede62e.ImportableResource", jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putBypassActors")
    def put_bypass_actors(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetBypassActors", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7f474ee24571286138684f18b0dbae670008db026683b54885652df1cc83429a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putBypassActors", [value]))

    @jsii.member(jsii_name="putConditions")
    def put_conditions(
        self,
        *,
        ref_name: typing.Optional[typing.Union["OrganizationRulesetConditionsRefName", typing.Dict[builtins.str, typing.Any]]] = None,
        repository_id: typing.Optional[typing.Sequence[jsii.Number]] = None,
        repository_name: typing.Optional[typing.Union["OrganizationRulesetConditionsRepositoryName", typing.Dict[builtins.str, typing.Any]]] = None,
        repository_property: typing.Optional[typing.Union["OrganizationRulesetConditionsRepositoryProperty", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param ref_name: ref_name block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#ref_name OrganizationRuleset#ref_name}
        :param repository_id: The repository IDs that the ruleset applies to. One of these IDs must match for the ruleset to apply. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#repository_id OrganizationRuleset#repository_id}
        :param repository_name: repository_name block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#repository_name OrganizationRuleset#repository_name}
        :param repository_property: repository_property block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#repository_property OrganizationRuleset#repository_property}
        '''
        value = OrganizationRulesetConditions(
            ref_name=ref_name,
            repository_id=repository_id,
            repository_name=repository_name,
            repository_property=repository_property,
        )

        return typing.cast(None, jsii.invoke(self, "putConditions", [value]))

    @jsii.member(jsii_name="putRules")
    def put_rules(
        self,
        *,
        branch_name_pattern: typing.Optional[typing.Union["OrganizationRulesetRulesBranchNamePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        commit_author_email_pattern: typing.Optional[typing.Union["OrganizationRulesetRulesCommitAuthorEmailPattern", typing.Dict[builtins.str, typing.Any]]] = None,
        commit_message_pattern: typing.Optional[typing.Union["OrganizationRulesetRulesCommitMessagePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        committer_email_pattern: typing.Optional[typing.Union["OrganizationRulesetRulesCommitterEmailPattern", typing.Dict[builtins.str, typing.Any]]] = None,
        copilot_code_review: typing.Optional[typing.Union["OrganizationRulesetRulesCopilotCodeReview", typing.Dict[builtins.str, typing.Any]]] = None,
        creation: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        deletion: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        file_extension_restriction: typing.Optional[typing.Union["OrganizationRulesetRulesFileExtensionRestriction", typing.Dict[builtins.str, typing.Any]]] = None,
        file_path_restriction: typing.Optional[typing.Union["OrganizationRulesetRulesFilePathRestriction", typing.Dict[builtins.str, typing.Any]]] = None,
        max_file_path_length: typing.Optional[typing.Union["OrganizationRulesetRulesMaxFilePathLength", typing.Dict[builtins.str, typing.Any]]] = None,
        max_file_size: typing.Optional[typing.Union["OrganizationRulesetRulesMaxFileSize", typing.Dict[builtins.str, typing.Any]]] = None,
        non_fast_forward: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        pull_request: typing.Optional[typing.Union["OrganizationRulesetRulesPullRequest", typing.Dict[builtins.str, typing.Any]]] = None,
        required_code_scanning: typing.Optional[typing.Union["OrganizationRulesetRulesRequiredCodeScanning", typing.Dict[builtins.str, typing.Any]]] = None,
        required_linear_history: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_signatures: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_status_checks: typing.Optional[typing.Union["OrganizationRulesetRulesRequiredStatusChecks", typing.Dict[builtins.str, typing.Any]]] = None,
        required_workflows: typing.Optional[typing.Union["OrganizationRulesetRulesRequiredWorkflows", typing.Dict[builtins.str, typing.Any]]] = None,
        tag_name_pattern: typing.Optional[typing.Union["OrganizationRulesetRulesTagNamePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        update: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param branch_name_pattern: branch_name_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#branch_name_pattern OrganizationRuleset#branch_name_pattern}
        :param commit_author_email_pattern: commit_author_email_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#commit_author_email_pattern OrganizationRuleset#commit_author_email_pattern}
        :param commit_message_pattern: commit_message_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#commit_message_pattern OrganizationRuleset#commit_message_pattern}
        :param committer_email_pattern: committer_email_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#committer_email_pattern OrganizationRuleset#committer_email_pattern}
        :param copilot_code_review: copilot_code_review block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#copilot_code_review OrganizationRuleset#copilot_code_review}
        :param creation: Only allow users with bypass permission to create matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#creation OrganizationRuleset#creation}
        :param deletion: Only allow users with bypass permissions to delete matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#deletion OrganizationRuleset#deletion}
        :param file_extension_restriction: file_extension_restriction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#file_extension_restriction OrganizationRuleset#file_extension_restriction}
        :param file_path_restriction: file_path_restriction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#file_path_restriction OrganizationRuleset#file_path_restriction}
        :param max_file_path_length: max_file_path_length block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_path_length OrganizationRuleset#max_file_path_length}
        :param max_file_size: max_file_size block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_size OrganizationRuleset#max_file_size}
        :param non_fast_forward: Prevent users with push access from force pushing to refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#non_fast_forward OrganizationRuleset#non_fast_forward}
        :param pull_request: pull_request block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pull_request OrganizationRuleset#pull_request}
        :param required_code_scanning: required_code_scanning block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_code_scanning OrganizationRuleset#required_code_scanning}
        :param required_linear_history: Prevent merge commits from being pushed to matching branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_linear_history OrganizationRuleset#required_linear_history}
        :param required_signatures: Commits pushed to matching branches must have verified signatures. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_signatures OrganizationRuleset#required_signatures}
        :param required_status_checks: required_status_checks block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_status_checks OrganizationRuleset#required_status_checks}
        :param required_workflows: required_workflows block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_workflows OrganizationRuleset#required_workflows}
        :param tag_name_pattern: tag_name_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#tag_name_pattern OrganizationRuleset#tag_name_pattern}
        :param update: Only allow users with bypass permission to update matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#update OrganizationRuleset#update}
        '''
        value = OrganizationRulesetRules(
            branch_name_pattern=branch_name_pattern,
            commit_author_email_pattern=commit_author_email_pattern,
            commit_message_pattern=commit_message_pattern,
            committer_email_pattern=committer_email_pattern,
            copilot_code_review=copilot_code_review,
            creation=creation,
            deletion=deletion,
            file_extension_restriction=file_extension_restriction,
            file_path_restriction=file_path_restriction,
            max_file_path_length=max_file_path_length,
            max_file_size=max_file_size,
            non_fast_forward=non_fast_forward,
            pull_request=pull_request,
            required_code_scanning=required_code_scanning,
            required_linear_history=required_linear_history,
            required_signatures=required_signatures,
            required_status_checks=required_status_checks,
            required_workflows=required_workflows,
            tag_name_pattern=tag_name_pattern,
            update=update,
        )

        return typing.cast(None, jsii.invoke(self, "putRules", [value]))

    @jsii.member(jsii_name="resetBypassActors")
    def reset_bypass_actors(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBypassActors", []))

    @jsii.member(jsii_name="resetConditions")
    def reset_conditions(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetConditions", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="bypassActors")
    def bypass_actors(self) -> "OrganizationRulesetBypassActorsList":
        return typing.cast("OrganizationRulesetBypassActorsList", jsii.get(self, "bypassActors"))

    @builtins.property
    @jsii.member(jsii_name="conditions")
    def conditions(self) -> "OrganizationRulesetConditionsOutputReference":
        return typing.cast("OrganizationRulesetConditionsOutputReference", jsii.get(self, "conditions"))

    @builtins.property
    @jsii.member(jsii_name="etag")
    def etag(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "etag"))

    @builtins.property
    @jsii.member(jsii_name="nodeId")
    def node_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "nodeId"))

    @builtins.property
    @jsii.member(jsii_name="rules")
    def rules(self) -> "OrganizationRulesetRulesOutputReference":
        return typing.cast("OrganizationRulesetRulesOutputReference", jsii.get(self, "rules"))

    @builtins.property
    @jsii.member(jsii_name="rulesetId")
    def ruleset_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "rulesetId"))

    @builtins.property
    @jsii.member(jsii_name="bypassActorsInput")
    def bypass_actors_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetBypassActors"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetBypassActors"]]], jsii.get(self, "bypassActorsInput"))

    @builtins.property
    @jsii.member(jsii_name="conditionsInput")
    def conditions_input(self) -> typing.Optional["OrganizationRulesetConditions"]:
        return typing.cast(typing.Optional["OrganizationRulesetConditions"], jsii.get(self, "conditionsInput"))

    @builtins.property
    @jsii.member(jsii_name="enforcementInput")
    def enforcement_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "enforcementInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="rulesInput")
    def rules_input(self) -> typing.Optional["OrganizationRulesetRules"]:
        return typing.cast(typing.Optional["OrganizationRulesetRules"], jsii.get(self, "rulesInput"))

    @builtins.property
    @jsii.member(jsii_name="targetInput")
    def target_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "targetInput"))

    @builtins.property
    @jsii.member(jsii_name="enforcement")
    def enforcement(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "enforcement"))

    @enforcement.setter
    def enforcement(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__88721be48d84c8a59d7a0894455606d0fecfdeedea29412ec73811fbc6629dcd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enforcement", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d593ed4c7a12afd3af856a74dd4e8c5a1877dcaba1815553e567a979be60e919)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__61b0bb1cd34a1ce45288114244e3f9854ad414d002657ed9594d843c61bdd229)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="target")
    def target(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "target"))

    @target.setter
    def target(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a3d43405598c6be2c4809785bf77fa883b7c499adc2a1a2bf873d81845e3ae9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "target", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetBypassActors",
    jsii_struct_bases=[],
    name_mapping={
        "actor_type": "actorType",
        "bypass_mode": "bypassMode",
        "actor_id": "actorId",
    },
)
class OrganizationRulesetBypassActors:
    def __init__(
        self,
        *,
        actor_type: builtins.str,
        bypass_mode: builtins.str,
        actor_id: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param actor_type: The type of actor that can bypass a ruleset. Can be one of: ``Integration``, ``OrganizationAdmin``, ``RepositoryRole``, ``Team``, or ``DeployKey``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#actor_type OrganizationRuleset#actor_type}
        :param bypass_mode: When the specified actor can bypass the ruleset. pull_request means that an actor can only bypass rules on pull requests. Can be one of: ``always``, ``pull_request``, ``exempt``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#bypass_mode OrganizationRuleset#bypass_mode}
        :param actor_id: The ID of the actor that can bypass a ruleset. When ``actor_type`` is ``OrganizationAdmin``, this should be set to ``1``. Some resources such as DeployKey do not have an ID and this should be omitted. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#actor_id OrganizationRuleset#actor_id}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__762166be1992f09799f12ff3497e8419954c774fea730dab91d13f9e19b624c9)
            check_type(argname="argument actor_type", value=actor_type, expected_type=type_hints["actor_type"])
            check_type(argname="argument bypass_mode", value=bypass_mode, expected_type=type_hints["bypass_mode"])
            check_type(argname="argument actor_id", value=actor_id, expected_type=type_hints["actor_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "actor_type": actor_type,
            "bypass_mode": bypass_mode,
        }
        if actor_id is not None:
            self._values["actor_id"] = actor_id

    @builtins.property
    def actor_type(self) -> builtins.str:
        '''The type of actor that can bypass a ruleset. Can be one of: ``Integration``, ``OrganizationAdmin``, ``RepositoryRole``, ``Team``, or ``DeployKey``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#actor_type OrganizationRuleset#actor_type}
        '''
        result = self._values.get("actor_type")
        assert result is not None, "Required property 'actor_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def bypass_mode(self) -> builtins.str:
        '''When the specified actor can bypass the ruleset.

        pull_request means that an actor can only bypass rules on pull requests. Can be one of: ``always``, ``pull_request``, ``exempt``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#bypass_mode OrganizationRuleset#bypass_mode}
        '''
        result = self._values.get("bypass_mode")
        assert result is not None, "Required property 'bypass_mode' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def actor_id(self) -> typing.Optional[jsii.Number]:
        '''The ID of the actor that can bypass a ruleset.

        When ``actor_type`` is ``OrganizationAdmin``, this should be set to ``1``. Some resources such as DeployKey do not have an ID and this should be omitted.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#actor_id OrganizationRuleset#actor_id}
        '''
        result = self._values.get("actor_id")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetBypassActors(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetBypassActorsList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetBypassActorsList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ef6772cceef4a21960120c6304379f30b1d5d937eaa7f55f10c45d954c0fab4b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "OrganizationRulesetBypassActorsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__868916ba979f5b8a61ecbe7e15adea685b81acd0a135fc2630269d8dc92564c5)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("OrganizationRulesetBypassActorsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetBypassActors"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetBypassActors"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetBypassActors"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a084642b980c2a1e8b49733708104a6cdbaa171a754289f97561694d9287e51)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class OrganizationRulesetBypassActorsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetBypassActorsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ebf974c18a2b5511e7ac7e0db0d705878881675d9f9645df363c512179209572)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetActorId")
    def reset_actor_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetActorId", []))

    @builtins.property
    @jsii.member(jsii_name="actorIdInput")
    def actor_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "actorIdInput"))

    @builtins.property
    @jsii.member(jsii_name="actorTypeInput")
    def actor_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "actorTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="bypassModeInput")
    def bypass_mode_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "bypassModeInput"))

    @builtins.property
    @jsii.member(jsii_name="actorId")
    def actor_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "actorId"))

    @actor_id.setter
    def actor_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2649683cd7926d1a2495e9cad4d579f0d3af79238549a6023d012001fc3ab4d3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "actorId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="actorType")
    def actor_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "actorType"))

    @actor_type.setter
    def actor_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d25305e2c20799b1822814bdd6c4264fccf24451f33f93d4ee5a9d4df55185bd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "actorType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="bypassMode")
    def bypass_mode(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "bypassMode"))

    @bypass_mode.setter
    def bypass_mode(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__31ced0e64f6d89cc5602579a1899e880ac32c82b0ead3cfe257a824e93b366a0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "bypassMode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetBypassActors"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetBypassActors"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetBypassActors"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5b26009e74c48c3670b1f975eab35c16b23a38f85f8f5cbf1024017bbaf787af)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditions",
    jsii_struct_bases=[],
    name_mapping={
        "ref_name": "refName",
        "repository_id": "repositoryId",
        "repository_name": "repositoryName",
        "repository_property": "repositoryProperty",
    },
)
class OrganizationRulesetConditions:
    def __init__(
        self,
        *,
        ref_name: typing.Optional[typing.Union["OrganizationRulesetConditionsRefName", typing.Dict[builtins.str, typing.Any]]] = None,
        repository_id: typing.Optional[typing.Sequence[jsii.Number]] = None,
        repository_name: typing.Optional[typing.Union["OrganizationRulesetConditionsRepositoryName", typing.Dict[builtins.str, typing.Any]]] = None,
        repository_property: typing.Optional[typing.Union["OrganizationRulesetConditionsRepositoryProperty", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param ref_name: ref_name block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#ref_name OrganizationRuleset#ref_name}
        :param repository_id: The repository IDs that the ruleset applies to. One of these IDs must match for the ruleset to apply. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#repository_id OrganizationRuleset#repository_id}
        :param repository_name: repository_name block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#repository_name OrganizationRuleset#repository_name}
        :param repository_property: repository_property block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#repository_property OrganizationRuleset#repository_property}
        '''
        if isinstance(ref_name, dict):
            ref_name = OrganizationRulesetConditionsRefName(**ref_name)
        if isinstance(repository_name, dict):
            repository_name = OrganizationRulesetConditionsRepositoryName(**repository_name)
        if isinstance(repository_property, dict):
            repository_property = OrganizationRulesetConditionsRepositoryProperty(**repository_property)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__26fb2908e0053999e52a1fa48e14b4d3a6c877d4aca288a96eca6533976e2b4e)
            check_type(argname="argument ref_name", value=ref_name, expected_type=type_hints["ref_name"])
            check_type(argname="argument repository_id", value=repository_id, expected_type=type_hints["repository_id"])
            check_type(argname="argument repository_name", value=repository_name, expected_type=type_hints["repository_name"])
            check_type(argname="argument repository_property", value=repository_property, expected_type=type_hints["repository_property"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if ref_name is not None:
            self._values["ref_name"] = ref_name
        if repository_id is not None:
            self._values["repository_id"] = repository_id
        if repository_name is not None:
            self._values["repository_name"] = repository_name
        if repository_property is not None:
            self._values["repository_property"] = repository_property

    @builtins.property
    def ref_name(self) -> typing.Optional["OrganizationRulesetConditionsRefName"]:
        '''ref_name block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#ref_name OrganizationRuleset#ref_name}
        '''
        result = self._values.get("ref_name")
        return typing.cast(typing.Optional["OrganizationRulesetConditionsRefName"], result)

    @builtins.property
    def repository_id(self) -> typing.Optional[typing.List[jsii.Number]]:
        '''The repository IDs that the ruleset applies to. One of these IDs must match for the ruleset to apply.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#repository_id OrganizationRuleset#repository_id}
        '''
        result = self._values.get("repository_id")
        return typing.cast(typing.Optional[typing.List[jsii.Number]], result)

    @builtins.property
    def repository_name(
        self,
    ) -> typing.Optional["OrganizationRulesetConditionsRepositoryName"]:
        '''repository_name block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#repository_name OrganizationRuleset#repository_name}
        '''
        result = self._values.get("repository_name")
        return typing.cast(typing.Optional["OrganizationRulesetConditionsRepositoryName"], result)

    @builtins.property
    def repository_property(
        self,
    ) -> typing.Optional["OrganizationRulesetConditionsRepositoryProperty"]:
        '''repository_property block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#repository_property OrganizationRuleset#repository_property}
        '''
        result = self._values.get("repository_property")
        return typing.cast(typing.Optional["OrganizationRulesetConditionsRepositoryProperty"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetConditions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetConditionsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b830153020f728133c8c455a9cf8a499667509d53aa203c780db7fb7c6a1ee97)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRefName")
    def put_ref_name(
        self,
        *,
        exclude: typing.Sequence[builtins.str],
        include: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param exclude: Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#exclude OrganizationRuleset#exclude}
        :param include: Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts ``~DEFAULT_BRANCH`` to include the default branch or ``~ALL`` to include all branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#include OrganizationRuleset#include}
        '''
        value = OrganizationRulesetConditionsRefName(exclude=exclude, include=include)

        return typing.cast(None, jsii.invoke(self, "putRefName", [value]))

    @jsii.member(jsii_name="putRepositoryName")
    def put_repository_name(
        self,
        *,
        exclude: typing.Sequence[builtins.str],
        include: typing.Sequence[builtins.str],
        protected: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param exclude: Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#exclude OrganizationRuleset#exclude}
        :param include: Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts ``~ALL`` to include all repositories. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#include OrganizationRuleset#include}
        :param protected: Whether renaming of target repositories is prevented. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#protected OrganizationRuleset#protected}
        '''
        value = OrganizationRulesetConditionsRepositoryName(
            exclude=exclude, include=include, protected=protected
        )

        return typing.cast(None, jsii.invoke(self, "putRepositoryName", [value]))

    @jsii.member(jsii_name="putRepositoryProperty")
    def put_repository_property(
        self,
        *,
        exclude: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetConditionsRepositoryPropertyExclude", typing.Dict[builtins.str, typing.Any]]]]] = None,
        include: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetConditionsRepositoryPropertyInclude", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param exclude: The repository properties and values to exclude. The ruleset will not apply if any of these properties match. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#exclude OrganizationRuleset#exclude}
        :param include: The repository properties and values to include. All of these properties must match for the condition to pass. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#include OrganizationRuleset#include}
        '''
        value = OrganizationRulesetConditionsRepositoryProperty(
            exclude=exclude, include=include
        )

        return typing.cast(None, jsii.invoke(self, "putRepositoryProperty", [value]))

    @jsii.member(jsii_name="resetRefName")
    def reset_ref_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRefName", []))

    @jsii.member(jsii_name="resetRepositoryId")
    def reset_repository_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRepositoryId", []))

    @jsii.member(jsii_name="resetRepositoryName")
    def reset_repository_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRepositoryName", []))

    @jsii.member(jsii_name="resetRepositoryProperty")
    def reset_repository_property(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRepositoryProperty", []))

    @builtins.property
    @jsii.member(jsii_name="refName")
    def ref_name(self) -> "OrganizationRulesetConditionsRefNameOutputReference":
        return typing.cast("OrganizationRulesetConditionsRefNameOutputReference", jsii.get(self, "refName"))

    @builtins.property
    @jsii.member(jsii_name="repositoryName")
    def repository_name(
        self,
    ) -> "OrganizationRulesetConditionsRepositoryNameOutputReference":
        return typing.cast("OrganizationRulesetConditionsRepositoryNameOutputReference", jsii.get(self, "repositoryName"))

    @builtins.property
    @jsii.member(jsii_name="repositoryProperty")
    def repository_property(
        self,
    ) -> "OrganizationRulesetConditionsRepositoryPropertyOutputReference":
        return typing.cast("OrganizationRulesetConditionsRepositoryPropertyOutputReference", jsii.get(self, "repositoryProperty"))

    @builtins.property
    @jsii.member(jsii_name="refNameInput")
    def ref_name_input(self) -> typing.Optional["OrganizationRulesetConditionsRefName"]:
        return typing.cast(typing.Optional["OrganizationRulesetConditionsRefName"], jsii.get(self, "refNameInput"))

    @builtins.property
    @jsii.member(jsii_name="repositoryIdInput")
    def repository_id_input(self) -> typing.Optional[typing.List[jsii.Number]]:
        return typing.cast(typing.Optional[typing.List[jsii.Number]], jsii.get(self, "repositoryIdInput"))

    @builtins.property
    @jsii.member(jsii_name="repositoryNameInput")
    def repository_name_input(
        self,
    ) -> typing.Optional["OrganizationRulesetConditionsRepositoryName"]:
        return typing.cast(typing.Optional["OrganizationRulesetConditionsRepositoryName"], jsii.get(self, "repositoryNameInput"))

    @builtins.property
    @jsii.member(jsii_name="repositoryPropertyInput")
    def repository_property_input(
        self,
    ) -> typing.Optional["OrganizationRulesetConditionsRepositoryProperty"]:
        return typing.cast(typing.Optional["OrganizationRulesetConditionsRepositoryProperty"], jsii.get(self, "repositoryPropertyInput"))

    @builtins.property
    @jsii.member(jsii_name="repositoryId")
    def repository_id(self) -> typing.List[jsii.Number]:
        return typing.cast(typing.List[jsii.Number], jsii.get(self, "repositoryId"))

    @repository_id.setter
    def repository_id(self, value: typing.List[jsii.Number]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2c78c87d072a62011f3dd1ec9750c94e435d3ee9c2faf1673a6da274d8f7a614)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "repositoryId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["OrganizationRulesetConditions"]:
        return typing.cast(typing.Optional["OrganizationRulesetConditions"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetConditions"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7f974f6933c2162663a6dc2a45faaaeaa61d05910a8696426cfed399a975a1f2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRefName",
    jsii_struct_bases=[],
    name_mapping={"exclude": "exclude", "include": "include"},
)
class OrganizationRulesetConditionsRefName:
    def __init__(
        self,
        *,
        exclude: typing.Sequence[builtins.str],
        include: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param exclude: Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#exclude OrganizationRuleset#exclude}
        :param include: Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts ``~DEFAULT_BRANCH`` to include the default branch or ``~ALL`` to include all branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#include OrganizationRuleset#include}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bea66b29c616e0bb2f5e8d6d88cc03e33af9f42a710ddf5279cedf64192797e8)
            check_type(argname="argument exclude", value=exclude, expected_type=type_hints["exclude"])
            check_type(argname="argument include", value=include, expected_type=type_hints["include"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "exclude": exclude,
            "include": include,
        }

    @builtins.property
    def exclude(self) -> typing.List[builtins.str]:
        '''Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#exclude OrganizationRuleset#exclude}
        '''
        result = self._values.get("exclude")
        assert result is not None, "Required property 'exclude' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def include(self) -> typing.List[builtins.str]:
        '''Array of ref names or patterns to include.

        One of these patterns must match for the condition to pass. Also accepts ``~DEFAULT_BRANCH`` to include the default branch or ``~ALL`` to include all branches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#include OrganizationRuleset#include}
        '''
        result = self._values.get("include")
        assert result is not None, "Required property 'include' is missing"
        return typing.cast(typing.List[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetConditionsRefName(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetConditionsRefNameOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRefNameOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9df6c515c3cd4229ef2220e6d220f1234a33404ff26f305b86f1eff0d78e79ff)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="excludeInput")
    def exclude_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "excludeInput"))

    @builtins.property
    @jsii.member(jsii_name="includeInput")
    def include_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "includeInput"))

    @builtins.property
    @jsii.member(jsii_name="exclude")
    def exclude(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "exclude"))

    @exclude.setter
    def exclude(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__17014b19012331e144bc1b63463fe09a5155dcc44ead794d5b91975a58daf160)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "exclude", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="include")
    def include(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "include"))

    @include.setter
    def include(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9234565f31f3b9af198b6de106481c50fe46252b01e8369af25d612a0f8d7977)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "include", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["OrganizationRulesetConditionsRefName"]:
        return typing.cast(typing.Optional["OrganizationRulesetConditionsRefName"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetConditionsRefName"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b31987fb719153de5404b575e5ea0c7981afb9f10ddb7da0b2c290628c14212f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRepositoryName",
    jsii_struct_bases=[],
    name_mapping={
        "exclude": "exclude",
        "include": "include",
        "protected": "protected",
    },
)
class OrganizationRulesetConditionsRepositoryName:
    def __init__(
        self,
        *,
        exclude: typing.Sequence[builtins.str],
        include: typing.Sequence[builtins.str],
        protected: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param exclude: Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#exclude OrganizationRuleset#exclude}
        :param include: Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts ``~ALL`` to include all repositories. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#include OrganizationRuleset#include}
        :param protected: Whether renaming of target repositories is prevented. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#protected OrganizationRuleset#protected}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__83b18d71cec1b2395d3744afb6a73feec0cce6cb6f17079c3a182a508f91cf67)
            check_type(argname="argument exclude", value=exclude, expected_type=type_hints["exclude"])
            check_type(argname="argument include", value=include, expected_type=type_hints["include"])
            check_type(argname="argument protected", value=protected, expected_type=type_hints["protected"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "exclude": exclude,
            "include": include,
        }
        if protected is not None:
            self._values["protected"] = protected

    @builtins.property
    def exclude(self) -> typing.List[builtins.str]:
        '''Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#exclude OrganizationRuleset#exclude}
        '''
        result = self._values.get("exclude")
        assert result is not None, "Required property 'exclude' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def include(self) -> typing.List[builtins.str]:
        '''Array of repository names or patterns to include.

        One of these patterns must match for the condition to pass. Also accepts ``~ALL`` to include all repositories.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#include OrganizationRuleset#include}
        '''
        result = self._values.get("include")
        assert result is not None, "Required property 'include' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def protected(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Whether renaming of target repositories is prevented.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#protected OrganizationRuleset#protected}
        '''
        result = self._values.get("protected")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetConditionsRepositoryName(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetConditionsRepositoryNameOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRepositoryNameOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__00807354d8a0002c9ae1c494a33c12e35c83d68593189161542f27ffb99a3bf9)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetProtected")
    def reset_protected(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetProtected", []))

    @builtins.property
    @jsii.member(jsii_name="excludeInput")
    def exclude_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "excludeInput"))

    @builtins.property
    @jsii.member(jsii_name="includeInput")
    def include_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "includeInput"))

    @builtins.property
    @jsii.member(jsii_name="protectedInput")
    def protected_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "protectedInput"))

    @builtins.property
    @jsii.member(jsii_name="exclude")
    def exclude(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "exclude"))

    @exclude.setter
    def exclude(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9757d26ba460e4539476330774ea48cec24b8329aacf3c9992027c8556406cef)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "exclude", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="include")
    def include(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "include"))

    @include.setter
    def include(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ad5f41bc4b39d825d2fc4e05d4cb7408e7baff3b6963e0cc35032a8e4a4e38a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "include", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="protected")
    def protected(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "protected"))

    @protected.setter
    def protected(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__111c98c50ad29bd8519a5ef13234c78324aa3be14475e7866398bfcc67e698e6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "protected", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetConditionsRepositoryName"]:
        return typing.cast(typing.Optional["OrganizationRulesetConditionsRepositoryName"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetConditionsRepositoryName"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__814ed1c53a2e806664ffb2dc9dbbdfbc0d8a78755eec8f44d8985f607669bf23)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRepositoryProperty",
    jsii_struct_bases=[],
    name_mapping={"exclude": "exclude", "include": "include"},
)
class OrganizationRulesetConditionsRepositoryProperty:
    def __init__(
        self,
        *,
        exclude: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetConditionsRepositoryPropertyExclude", typing.Dict[builtins.str, typing.Any]]]]] = None,
        include: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetConditionsRepositoryPropertyInclude", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param exclude: The repository properties and values to exclude. The ruleset will not apply if any of these properties match. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#exclude OrganizationRuleset#exclude}
        :param include: The repository properties and values to include. All of these properties must match for the condition to pass. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#include OrganizationRuleset#include}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__613159194a911307856192559d57677a6fb47ea248f572dd5c244dec90abc104)
            check_type(argname="argument exclude", value=exclude, expected_type=type_hints["exclude"])
            check_type(argname="argument include", value=include, expected_type=type_hints["include"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if exclude is not None:
            self._values["exclude"] = exclude
        if include is not None:
            self._values["include"] = include

    @builtins.property
    def exclude(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyExclude"]]]:
        '''The repository properties and values to exclude. The ruleset will not apply if any of these properties match.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#exclude OrganizationRuleset#exclude}
        '''
        result = self._values.get("exclude")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyExclude"]]], result)

    @builtins.property
    def include(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyInclude"]]]:
        '''The repository properties and values to include. All of these properties must match for the condition to pass.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#include OrganizationRuleset#include}
        '''
        result = self._values.get("include")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyInclude"]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetConditionsRepositoryProperty(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRepositoryPropertyExclude",
    jsii_struct_bases=[],
    name_mapping={
        "name": "name",
        "property_values": "propertyValues",
        "source": "source",
    },
)
class OrganizationRulesetConditionsRepositoryPropertyExclude:
    def __init__(
        self,
        *,
        name: typing.Optional[builtins.str] = None,
        property_values: typing.Optional[typing.Sequence[builtins.str]] = None,
        source: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}.
        :param property_values: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#property_values OrganizationRuleset#property_values}.
        :param source: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#source OrganizationRuleset#source}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__251d5deced46cfa874c0b4518dbe085afaaac4e76f3143dccba034e33f816ac3)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument property_values", value=property_values, expected_type=type_hints["property_values"])
            check_type(argname="argument source", value=source, expected_type=type_hints["source"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if name is not None:
            self._values["name"] = name
        if property_values is not None:
            self._values["property_values"] = property_values
        if source is not None:
            self._values["source"] = source

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def property_values(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#property_values OrganizationRuleset#property_values}.'''
        result = self._values.get("property_values")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def source(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#source OrganizationRuleset#source}.'''
        result = self._values.get("source")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetConditionsRepositoryPropertyExclude(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetConditionsRepositoryPropertyExcludeList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRepositoryPropertyExcludeList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a24904188f6bb786e00f14623cc539a67567b90de4bf35eb574fa165ad11289)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "OrganizationRulesetConditionsRepositoryPropertyExcludeOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5558f4fe0e649fb6ddb98da35c3a88212ba8c8e33e05821c82fdb54d0a3129fd)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("OrganizationRulesetConditionsRepositoryPropertyExcludeOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyExclude"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyExclude"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyExclude"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7bfd32f6b558348b08abc15436f48a9ffaf5d85c45d887a90c50c2cb37c135ef)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class OrganizationRulesetConditionsRepositoryPropertyExcludeOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRepositoryPropertyExcludeOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a1b96453c33df0cda91d4739fbcf6524c371cf0f9b91bf958a1e78dc6fc9c6ed)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetPropertyValues")
    def reset_property_values(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPropertyValues", []))

    @jsii.member(jsii_name="resetSource")
    def reset_source(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSource", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="propertyValuesInput")
    def property_values_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "propertyValuesInput"))

    @builtins.property
    @jsii.member(jsii_name="sourceInput")
    def source_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sourceInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1df5e2b6d76b4c079b8c3c824c17342503a6f8ffb26b8882393cd05445d2c801)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="propertyValues")
    def property_values(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "propertyValues"))

    @property_values.setter
    def property_values(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b45532213ef28305cd7712bca4ced7edc24717c7ef5e9a404c1e9c4fa2d5a785)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "propertyValues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="source")
    def source(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "source"))

    @source.setter
    def source(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aeeedcccd4cfc19c54a7f5b7918b7ac7e50c84c9b317399b585585ee4654243b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "source", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetConditionsRepositoryPropertyExclude"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetConditionsRepositoryPropertyExclude"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetConditionsRepositoryPropertyExclude"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ad2d030db779c43d7da75dccb91b7e1081eafe737daf84fd1ec45cf3e3a7e6a6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRepositoryPropertyInclude",
    jsii_struct_bases=[],
    name_mapping={
        "name": "name",
        "property_values": "propertyValues",
        "source": "source",
    },
)
class OrganizationRulesetConditionsRepositoryPropertyInclude:
    def __init__(
        self,
        *,
        name: typing.Optional[builtins.str] = None,
        property_values: typing.Optional[typing.Sequence[builtins.str]] = None,
        source: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}.
        :param property_values: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#property_values OrganizationRuleset#property_values}.
        :param source: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#source OrganizationRuleset#source}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__137c789e3033a00708ffef5f131c6b3c56bc9b63c53b1e329249ba56a15035ff)
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument property_values", value=property_values, expected_type=type_hints["property_values"])
            check_type(argname="argument source", value=source, expected_type=type_hints["source"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if name is not None:
            self._values["name"] = name
        if property_values is not None:
            self._values["property_values"] = property_values
        if source is not None:
            self._values["source"] = source

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def property_values(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#property_values OrganizationRuleset#property_values}.'''
        result = self._values.get("property_values")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def source(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#source OrganizationRuleset#source}.'''
        result = self._values.get("source")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetConditionsRepositoryPropertyInclude(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetConditionsRepositoryPropertyIncludeList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRepositoryPropertyIncludeList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c8a089a944a84e29cabf6267e0ed3097974c46b7fc5f146ab0c2fde99325a743)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "OrganizationRulesetConditionsRepositoryPropertyIncludeOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__72ab6670d9916a611cf9e1c7d63cc617a465d03b296b4ac71b38f13404ad429a)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("OrganizationRulesetConditionsRepositoryPropertyIncludeOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyInclude"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyInclude"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyInclude"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a063834b66fe7ee988bbfb0c3fdd5f65a215da40194fad9e610e64ea20e0184f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class OrganizationRulesetConditionsRepositoryPropertyIncludeOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRepositoryPropertyIncludeOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__64920a0d9194394c65b5ee2208fd708a436ca060207e881943c8b3f988a50bfc)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetPropertyValues")
    def reset_property_values(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPropertyValues", []))

    @jsii.member(jsii_name="resetSource")
    def reset_source(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSource", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="propertyValuesInput")
    def property_values_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "propertyValuesInput"))

    @builtins.property
    @jsii.member(jsii_name="sourceInput")
    def source_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sourceInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2d8837905ffd2fae65116591cb7e4fd3e0361f91a7820a4800d6724fbe530f9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="propertyValues")
    def property_values(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "propertyValues"))

    @property_values.setter
    def property_values(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7dcaaf9473d2194d26451959770056c2fa392a1de7df4eb8a8f19ebfe27e703f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "propertyValues", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="source")
    def source(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "source"))

    @source.setter
    def source(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__de2eb260e900a14f7c9ea74b44df9ce9dc3392ddd2924c7d41be460a8cd90b98)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "source", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetConditionsRepositoryPropertyInclude"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetConditionsRepositoryPropertyInclude"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetConditionsRepositoryPropertyInclude"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f128b529a5a51e1d9f242c5b4e14ab1ed10fa0a39fde9d77fff021a825d6e92e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class OrganizationRulesetConditionsRepositoryPropertyOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConditionsRepositoryPropertyOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__53c75d7772c24599f2cc950443c3fdefbfcc66699ace0e5e00d171263e06f2b1)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putExclude")
    def put_exclude(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetConditionsRepositoryPropertyExclude", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__949601f1ef531b3984c64a7c9767e4c9ce48f4415cf10ec907f7572ac162c56d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putExclude", [value]))

    @jsii.member(jsii_name="putInclude")
    def put_include(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetConditionsRepositoryPropertyInclude", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e4309ed74cb15a62e15a2e0261017979d5419cef3c9860726b5d875f5c2086d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putInclude", [value]))

    @jsii.member(jsii_name="resetExclude")
    def reset_exclude(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExclude", []))

    @jsii.member(jsii_name="resetInclude")
    def reset_include(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetInclude", []))

    @builtins.property
    @jsii.member(jsii_name="exclude")
    def exclude(self) -> "OrganizationRulesetConditionsRepositoryPropertyExcludeList":
        return typing.cast("OrganizationRulesetConditionsRepositoryPropertyExcludeList", jsii.get(self, "exclude"))

    @builtins.property
    @jsii.member(jsii_name="include")
    def include(self) -> "OrganizationRulesetConditionsRepositoryPropertyIncludeList":
        return typing.cast("OrganizationRulesetConditionsRepositoryPropertyIncludeList", jsii.get(self, "include"))

    @builtins.property
    @jsii.member(jsii_name="excludeInput")
    def exclude_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyExclude"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyExclude"]]], jsii.get(self, "excludeInput"))

    @builtins.property
    @jsii.member(jsii_name="includeInput")
    def include_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyInclude"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetConditionsRepositoryPropertyInclude"]]], jsii.get(self, "includeInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetConditionsRepositoryProperty"]:
        return typing.cast(typing.Optional["OrganizationRulesetConditionsRepositoryProperty"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetConditionsRepositoryProperty"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__df59c8e4eaf7f269aad2e8a1cdebf293ceccc7ce281cbc5b859e23aeca15d0a6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "enforcement": "enforcement",
        "name": "name",
        "rules": "rules",
        "target": "target",
        "bypass_actors": "bypassActors",
        "conditions": "conditions",
        "id": "id",
    },
)
class OrganizationRulesetConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.WinrmProvisionerConnection", typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]] = None,
        depends_on: typing.Optional[typing.Sequence["_cdktn_78ede62e.ITerraformDependable"]] = None,
        for_each: typing.Optional["_cdktn_78ede62e.ITerraformIterator"] = None,
        lifecycle: typing.Optional[typing.Union["_cdktn_78ede62e.TerraformResourceLifecycle", typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional["_cdktn_78ede62e.TerraformProvider"] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union["_cdktn_78ede62e.FileProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.LocalExecProvisioner", typing.Dict[builtins.str, typing.Any]], typing.Union["_cdktn_78ede62e.RemoteExecProvisioner", typing.Dict[builtins.str, typing.Any]]]]] = None,
        enforcement: builtins.str,
        name: builtins.str,
        rules: typing.Union["OrganizationRulesetRules", typing.Dict[builtins.str, typing.Any]],
        target: builtins.str,
        bypass_actors: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetBypassActors", typing.Dict[builtins.str, typing.Any]]]]] = None,
        conditions: typing.Optional[typing.Union["OrganizationRulesetConditions", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param enforcement: The enforcement level of the ruleset. ``evaluate`` allows admins to test rules before enforcing them. Possible values are ``disabled``, ``active``, and ``evaluate``. Note: ``evaluate`` is only available for Enterprise plans. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#enforcement OrganizationRuleset#enforcement}
        :param name: The name of the ruleset. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param rules: rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#rules OrganizationRuleset#rules}
        :param target: The target of the ruleset. Possible values are branch, tag and push. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#target OrganizationRuleset#target}
        :param bypass_actors: bypass_actors block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#bypass_actors OrganizationRuleset#bypass_actors}
        :param conditions: conditions block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#conditions OrganizationRuleset#conditions}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#id OrganizationRuleset#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(rules, dict):
            rules = OrganizationRulesetRules(**rules)
        if isinstance(conditions, dict):
            conditions = OrganizationRulesetConditions(**conditions)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__65ad096a2579bee3fca1f1f0435b96fb63d2032ce04a18476bbe2a2926e8c456)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument enforcement", value=enforcement, expected_type=type_hints["enforcement"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument rules", value=rules, expected_type=type_hints["rules"])
            check_type(argname="argument target", value=target, expected_type=type_hints["target"])
            check_type(argname="argument bypass_actors", value=bypass_actors, expected_type=type_hints["bypass_actors"])
            check_type(argname="argument conditions", value=conditions, expected_type=type_hints["conditions"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "enforcement": enforcement,
            "name": name,
            "rules": rules,
            "target": target,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if bypass_actors is not None:
            self._values["bypass_actors"] = bypass_actors
        if conditions is not None:
            self._values["conditions"] = conditions
        if id is not None:
            self._values["id"] = id

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.SSHProvisionerConnection", "_cdktn_78ede62e.WinrmProvisionerConnection"]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, "_cdktn_78ede62e.TerraformCount"]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List["_cdktn_78ede62e.ITerraformDependable"]], result)

    @builtins.property
    def for_each(self) -> typing.Optional["_cdktn_78ede62e.ITerraformIterator"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional["_cdktn_78ede62e.ITerraformIterator"], result)

    @builtins.property
    def lifecycle(
        self,
    ) -> typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformResourceLifecycle"], result)

    @builtins.property
    def provider(self) -> typing.Optional["_cdktn_78ede62e.TerraformProvider"]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional["_cdktn_78ede62e.TerraformProvider"], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union["_cdktn_78ede62e.FileProvisioner", "_cdktn_78ede62e.LocalExecProvisioner", "_cdktn_78ede62e.RemoteExecProvisioner"]]], result)

    @builtins.property
    def enforcement(self) -> builtins.str:
        '''The enforcement level of the ruleset.

        ``evaluate`` allows admins to test rules before enforcing them. Possible values are ``disabled``, ``active``, and ``evaluate``. Note: ``evaluate`` is only available for Enterprise plans.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#enforcement OrganizationRuleset#enforcement}
        '''
        result = self._values.get("enforcement")
        assert result is not None, "Required property 'enforcement' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''The name of the ruleset.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        '''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def rules(self) -> "OrganizationRulesetRules":
        '''rules block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#rules OrganizationRuleset#rules}
        '''
        result = self._values.get("rules")
        assert result is not None, "Required property 'rules' is missing"
        return typing.cast("OrganizationRulesetRules", result)

    @builtins.property
    def target(self) -> builtins.str:
        '''The target of the ruleset. Possible values are branch, tag and push.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#target OrganizationRuleset#target}
        '''
        result = self._values.get("target")
        assert result is not None, "Required property 'target' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def bypass_actors(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetBypassActors"]]]:
        '''bypass_actors block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#bypass_actors OrganizationRuleset#bypass_actors}
        '''
        result = self._values.get("bypass_actors")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetBypassActors"]]], result)

    @builtins.property
    def conditions(self) -> typing.Optional["OrganizationRulesetConditions"]:
        '''conditions block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#conditions OrganizationRuleset#conditions}
        '''
        result = self._values.get("conditions")
        return typing.cast(typing.Optional["OrganizationRulesetConditions"], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#id OrganizationRuleset#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRules",
    jsii_struct_bases=[],
    name_mapping={
        "branch_name_pattern": "branchNamePattern",
        "commit_author_email_pattern": "commitAuthorEmailPattern",
        "commit_message_pattern": "commitMessagePattern",
        "committer_email_pattern": "committerEmailPattern",
        "copilot_code_review": "copilotCodeReview",
        "creation": "creation",
        "deletion": "deletion",
        "file_extension_restriction": "fileExtensionRestriction",
        "file_path_restriction": "filePathRestriction",
        "max_file_path_length": "maxFilePathLength",
        "max_file_size": "maxFileSize",
        "non_fast_forward": "nonFastForward",
        "pull_request": "pullRequest",
        "required_code_scanning": "requiredCodeScanning",
        "required_linear_history": "requiredLinearHistory",
        "required_signatures": "requiredSignatures",
        "required_status_checks": "requiredStatusChecks",
        "required_workflows": "requiredWorkflows",
        "tag_name_pattern": "tagNamePattern",
        "update": "update",
    },
)
class OrganizationRulesetRules:
    def __init__(
        self,
        *,
        branch_name_pattern: typing.Optional[typing.Union["OrganizationRulesetRulesBranchNamePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        commit_author_email_pattern: typing.Optional[typing.Union["OrganizationRulesetRulesCommitAuthorEmailPattern", typing.Dict[builtins.str, typing.Any]]] = None,
        commit_message_pattern: typing.Optional[typing.Union["OrganizationRulesetRulesCommitMessagePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        committer_email_pattern: typing.Optional[typing.Union["OrganizationRulesetRulesCommitterEmailPattern", typing.Dict[builtins.str, typing.Any]]] = None,
        copilot_code_review: typing.Optional[typing.Union["OrganizationRulesetRulesCopilotCodeReview", typing.Dict[builtins.str, typing.Any]]] = None,
        creation: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        deletion: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        file_extension_restriction: typing.Optional[typing.Union["OrganizationRulesetRulesFileExtensionRestriction", typing.Dict[builtins.str, typing.Any]]] = None,
        file_path_restriction: typing.Optional[typing.Union["OrganizationRulesetRulesFilePathRestriction", typing.Dict[builtins.str, typing.Any]]] = None,
        max_file_path_length: typing.Optional[typing.Union["OrganizationRulesetRulesMaxFilePathLength", typing.Dict[builtins.str, typing.Any]]] = None,
        max_file_size: typing.Optional[typing.Union["OrganizationRulesetRulesMaxFileSize", typing.Dict[builtins.str, typing.Any]]] = None,
        non_fast_forward: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        pull_request: typing.Optional[typing.Union["OrganizationRulesetRulesPullRequest", typing.Dict[builtins.str, typing.Any]]] = None,
        required_code_scanning: typing.Optional[typing.Union["OrganizationRulesetRulesRequiredCodeScanning", typing.Dict[builtins.str, typing.Any]]] = None,
        required_linear_history: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_signatures: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_status_checks: typing.Optional[typing.Union["OrganizationRulesetRulesRequiredStatusChecks", typing.Dict[builtins.str, typing.Any]]] = None,
        required_workflows: typing.Optional[typing.Union["OrganizationRulesetRulesRequiredWorkflows", typing.Dict[builtins.str, typing.Any]]] = None,
        tag_name_pattern: typing.Optional[typing.Union["OrganizationRulesetRulesTagNamePattern", typing.Dict[builtins.str, typing.Any]]] = None,
        update: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param branch_name_pattern: branch_name_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#branch_name_pattern OrganizationRuleset#branch_name_pattern}
        :param commit_author_email_pattern: commit_author_email_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#commit_author_email_pattern OrganizationRuleset#commit_author_email_pattern}
        :param commit_message_pattern: commit_message_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#commit_message_pattern OrganizationRuleset#commit_message_pattern}
        :param committer_email_pattern: committer_email_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#committer_email_pattern OrganizationRuleset#committer_email_pattern}
        :param copilot_code_review: copilot_code_review block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#copilot_code_review OrganizationRuleset#copilot_code_review}
        :param creation: Only allow users with bypass permission to create matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#creation OrganizationRuleset#creation}
        :param deletion: Only allow users with bypass permissions to delete matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#deletion OrganizationRuleset#deletion}
        :param file_extension_restriction: file_extension_restriction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#file_extension_restriction OrganizationRuleset#file_extension_restriction}
        :param file_path_restriction: file_path_restriction block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#file_path_restriction OrganizationRuleset#file_path_restriction}
        :param max_file_path_length: max_file_path_length block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_path_length OrganizationRuleset#max_file_path_length}
        :param max_file_size: max_file_size block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_size OrganizationRuleset#max_file_size}
        :param non_fast_forward: Prevent users with push access from force pushing to refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#non_fast_forward OrganizationRuleset#non_fast_forward}
        :param pull_request: pull_request block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pull_request OrganizationRuleset#pull_request}
        :param required_code_scanning: required_code_scanning block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_code_scanning OrganizationRuleset#required_code_scanning}
        :param required_linear_history: Prevent merge commits from being pushed to matching branches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_linear_history OrganizationRuleset#required_linear_history}
        :param required_signatures: Commits pushed to matching branches must have verified signatures. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_signatures OrganizationRuleset#required_signatures}
        :param required_status_checks: required_status_checks block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_status_checks OrganizationRuleset#required_status_checks}
        :param required_workflows: required_workflows block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_workflows OrganizationRuleset#required_workflows}
        :param tag_name_pattern: tag_name_pattern block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#tag_name_pattern OrganizationRuleset#tag_name_pattern}
        :param update: Only allow users with bypass permission to update matching refs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#update OrganizationRuleset#update}
        '''
        if isinstance(branch_name_pattern, dict):
            branch_name_pattern = OrganizationRulesetRulesBranchNamePattern(**branch_name_pattern)
        if isinstance(commit_author_email_pattern, dict):
            commit_author_email_pattern = OrganizationRulesetRulesCommitAuthorEmailPattern(**commit_author_email_pattern)
        if isinstance(commit_message_pattern, dict):
            commit_message_pattern = OrganizationRulesetRulesCommitMessagePattern(**commit_message_pattern)
        if isinstance(committer_email_pattern, dict):
            committer_email_pattern = OrganizationRulesetRulesCommitterEmailPattern(**committer_email_pattern)
        if isinstance(copilot_code_review, dict):
            copilot_code_review = OrganizationRulesetRulesCopilotCodeReview(**copilot_code_review)
        if isinstance(file_extension_restriction, dict):
            file_extension_restriction = OrganizationRulesetRulesFileExtensionRestriction(**file_extension_restriction)
        if isinstance(file_path_restriction, dict):
            file_path_restriction = OrganizationRulesetRulesFilePathRestriction(**file_path_restriction)
        if isinstance(max_file_path_length, dict):
            max_file_path_length = OrganizationRulesetRulesMaxFilePathLength(**max_file_path_length)
        if isinstance(max_file_size, dict):
            max_file_size = OrganizationRulesetRulesMaxFileSize(**max_file_size)
        if isinstance(pull_request, dict):
            pull_request = OrganizationRulesetRulesPullRequest(**pull_request)
        if isinstance(required_code_scanning, dict):
            required_code_scanning = OrganizationRulesetRulesRequiredCodeScanning(**required_code_scanning)
        if isinstance(required_status_checks, dict):
            required_status_checks = OrganizationRulesetRulesRequiredStatusChecks(**required_status_checks)
        if isinstance(required_workflows, dict):
            required_workflows = OrganizationRulesetRulesRequiredWorkflows(**required_workflows)
        if isinstance(tag_name_pattern, dict):
            tag_name_pattern = OrganizationRulesetRulesTagNamePattern(**tag_name_pattern)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b5602e6c69d9e545621030d56c7a562870baae4a18fe589299b72055c3b22b2f)
            check_type(argname="argument branch_name_pattern", value=branch_name_pattern, expected_type=type_hints["branch_name_pattern"])
            check_type(argname="argument commit_author_email_pattern", value=commit_author_email_pattern, expected_type=type_hints["commit_author_email_pattern"])
            check_type(argname="argument commit_message_pattern", value=commit_message_pattern, expected_type=type_hints["commit_message_pattern"])
            check_type(argname="argument committer_email_pattern", value=committer_email_pattern, expected_type=type_hints["committer_email_pattern"])
            check_type(argname="argument copilot_code_review", value=copilot_code_review, expected_type=type_hints["copilot_code_review"])
            check_type(argname="argument creation", value=creation, expected_type=type_hints["creation"])
            check_type(argname="argument deletion", value=deletion, expected_type=type_hints["deletion"])
            check_type(argname="argument file_extension_restriction", value=file_extension_restriction, expected_type=type_hints["file_extension_restriction"])
            check_type(argname="argument file_path_restriction", value=file_path_restriction, expected_type=type_hints["file_path_restriction"])
            check_type(argname="argument max_file_path_length", value=max_file_path_length, expected_type=type_hints["max_file_path_length"])
            check_type(argname="argument max_file_size", value=max_file_size, expected_type=type_hints["max_file_size"])
            check_type(argname="argument non_fast_forward", value=non_fast_forward, expected_type=type_hints["non_fast_forward"])
            check_type(argname="argument pull_request", value=pull_request, expected_type=type_hints["pull_request"])
            check_type(argname="argument required_code_scanning", value=required_code_scanning, expected_type=type_hints["required_code_scanning"])
            check_type(argname="argument required_linear_history", value=required_linear_history, expected_type=type_hints["required_linear_history"])
            check_type(argname="argument required_signatures", value=required_signatures, expected_type=type_hints["required_signatures"])
            check_type(argname="argument required_status_checks", value=required_status_checks, expected_type=type_hints["required_status_checks"])
            check_type(argname="argument required_workflows", value=required_workflows, expected_type=type_hints["required_workflows"])
            check_type(argname="argument tag_name_pattern", value=tag_name_pattern, expected_type=type_hints["tag_name_pattern"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if branch_name_pattern is not None:
            self._values["branch_name_pattern"] = branch_name_pattern
        if commit_author_email_pattern is not None:
            self._values["commit_author_email_pattern"] = commit_author_email_pattern
        if commit_message_pattern is not None:
            self._values["commit_message_pattern"] = commit_message_pattern
        if committer_email_pattern is not None:
            self._values["committer_email_pattern"] = committer_email_pattern
        if copilot_code_review is not None:
            self._values["copilot_code_review"] = copilot_code_review
        if creation is not None:
            self._values["creation"] = creation
        if deletion is not None:
            self._values["deletion"] = deletion
        if file_extension_restriction is not None:
            self._values["file_extension_restriction"] = file_extension_restriction
        if file_path_restriction is not None:
            self._values["file_path_restriction"] = file_path_restriction
        if max_file_path_length is not None:
            self._values["max_file_path_length"] = max_file_path_length
        if max_file_size is not None:
            self._values["max_file_size"] = max_file_size
        if non_fast_forward is not None:
            self._values["non_fast_forward"] = non_fast_forward
        if pull_request is not None:
            self._values["pull_request"] = pull_request
        if required_code_scanning is not None:
            self._values["required_code_scanning"] = required_code_scanning
        if required_linear_history is not None:
            self._values["required_linear_history"] = required_linear_history
        if required_signatures is not None:
            self._values["required_signatures"] = required_signatures
        if required_status_checks is not None:
            self._values["required_status_checks"] = required_status_checks
        if required_workflows is not None:
            self._values["required_workflows"] = required_workflows
        if tag_name_pattern is not None:
            self._values["tag_name_pattern"] = tag_name_pattern
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def branch_name_pattern(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesBranchNamePattern"]:
        '''branch_name_pattern block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#branch_name_pattern OrganizationRuleset#branch_name_pattern}
        '''
        result = self._values.get("branch_name_pattern")
        return typing.cast(typing.Optional["OrganizationRulesetRulesBranchNamePattern"], result)

    @builtins.property
    def commit_author_email_pattern(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCommitAuthorEmailPattern"]:
        '''commit_author_email_pattern block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#commit_author_email_pattern OrganizationRuleset#commit_author_email_pattern}
        '''
        result = self._values.get("commit_author_email_pattern")
        return typing.cast(typing.Optional["OrganizationRulesetRulesCommitAuthorEmailPattern"], result)

    @builtins.property
    def commit_message_pattern(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCommitMessagePattern"]:
        '''commit_message_pattern block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#commit_message_pattern OrganizationRuleset#commit_message_pattern}
        '''
        result = self._values.get("commit_message_pattern")
        return typing.cast(typing.Optional["OrganizationRulesetRulesCommitMessagePattern"], result)

    @builtins.property
    def committer_email_pattern(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCommitterEmailPattern"]:
        '''committer_email_pattern block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#committer_email_pattern OrganizationRuleset#committer_email_pattern}
        '''
        result = self._values.get("committer_email_pattern")
        return typing.cast(typing.Optional["OrganizationRulesetRulesCommitterEmailPattern"], result)

    @builtins.property
    def copilot_code_review(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCopilotCodeReview"]:
        '''copilot_code_review block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#copilot_code_review OrganizationRuleset#copilot_code_review}
        '''
        result = self._values.get("copilot_code_review")
        return typing.cast(typing.Optional["OrganizationRulesetRulesCopilotCodeReview"], result)

    @builtins.property
    def creation(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Only allow users with bypass permission to create matching refs.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#creation OrganizationRuleset#creation}
        '''
        result = self._values.get("creation")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def deletion(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Only allow users with bypass permissions to delete matching refs.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#deletion OrganizationRuleset#deletion}
        '''
        result = self._values.get("deletion")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def file_extension_restriction(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesFileExtensionRestriction"]:
        '''file_extension_restriction block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#file_extension_restriction OrganizationRuleset#file_extension_restriction}
        '''
        result = self._values.get("file_extension_restriction")
        return typing.cast(typing.Optional["OrganizationRulesetRulesFileExtensionRestriction"], result)

    @builtins.property
    def file_path_restriction(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesFilePathRestriction"]:
        '''file_path_restriction block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#file_path_restriction OrganizationRuleset#file_path_restriction}
        '''
        result = self._values.get("file_path_restriction")
        return typing.cast(typing.Optional["OrganizationRulesetRulesFilePathRestriction"], result)

    @builtins.property
    def max_file_path_length(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesMaxFilePathLength"]:
        '''max_file_path_length block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_path_length OrganizationRuleset#max_file_path_length}
        '''
        result = self._values.get("max_file_path_length")
        return typing.cast(typing.Optional["OrganizationRulesetRulesMaxFilePathLength"], result)

    @builtins.property
    def max_file_size(self) -> typing.Optional["OrganizationRulesetRulesMaxFileSize"]:
        '''max_file_size block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_size OrganizationRuleset#max_file_size}
        '''
        result = self._values.get("max_file_size")
        return typing.cast(typing.Optional["OrganizationRulesetRulesMaxFileSize"], result)

    @builtins.property
    def non_fast_forward(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Prevent users with push access from force pushing to refs.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#non_fast_forward OrganizationRuleset#non_fast_forward}
        '''
        result = self._values.get("non_fast_forward")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def pull_request(self) -> typing.Optional["OrganizationRulesetRulesPullRequest"]:
        '''pull_request block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pull_request OrganizationRuleset#pull_request}
        '''
        result = self._values.get("pull_request")
        return typing.cast(typing.Optional["OrganizationRulesetRulesPullRequest"], result)

    @builtins.property
    def required_code_scanning(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesRequiredCodeScanning"]:
        '''required_code_scanning block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_code_scanning OrganizationRuleset#required_code_scanning}
        '''
        result = self._values.get("required_code_scanning")
        return typing.cast(typing.Optional["OrganizationRulesetRulesRequiredCodeScanning"], result)

    @builtins.property
    def required_linear_history(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Prevent merge commits from being pushed to matching branches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_linear_history OrganizationRuleset#required_linear_history}
        '''
        result = self._values.get("required_linear_history")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def required_signatures(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Commits pushed to matching branches must have verified signatures.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_signatures OrganizationRuleset#required_signatures}
        '''
        result = self._values.get("required_signatures")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def required_status_checks(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesRequiredStatusChecks"]:
        '''required_status_checks block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_status_checks OrganizationRuleset#required_status_checks}
        '''
        result = self._values.get("required_status_checks")
        return typing.cast(typing.Optional["OrganizationRulesetRulesRequiredStatusChecks"], result)

    @builtins.property
    def required_workflows(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesRequiredWorkflows"]:
        '''required_workflows block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_workflows OrganizationRuleset#required_workflows}
        '''
        result = self._values.get("required_workflows")
        return typing.cast(typing.Optional["OrganizationRulesetRulesRequiredWorkflows"], result)

    @builtins.property
    def tag_name_pattern(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesTagNamePattern"]:
        '''tag_name_pattern block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#tag_name_pattern OrganizationRuleset#tag_name_pattern}
        '''
        result = self._values.get("tag_name_pattern")
        return typing.cast(typing.Optional["OrganizationRulesetRulesTagNamePattern"], result)

    @builtins.property
    def update(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Only allow users with bypass permission to update matching refs.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#update OrganizationRuleset#update}
        '''
        result = self._values.get("update")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRules(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesBranchNamePattern",
    jsii_struct_bases=[],
    name_mapping={
        "operator": "operator",
        "pattern": "pattern",
        "name": "name",
        "negate": "negate",
    },
)
class OrganizationRulesetRulesBranchNamePattern:
    def __init__(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b0d5b669f70d89a542af0aa74562cc4caab56aae907fae97bca1aa45c402020)
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument negate", value=negate, expected_type=type_hints["negate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "operator": operator,
            "pattern": pattern,
        }
        if name is not None:
            self._values["name"] = name
        if negate is not None:
            self._values["negate"] = negate

    @builtins.property
    def operator(self) -> builtins.str:
        '''The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        '''
        result = self._values.get("operator")
        assert result is not None, "Required property 'operator' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pattern(self) -> builtins.str:
        '''The pattern to match with.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''How this rule will appear to users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def negate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''If true, the rule will fail if the pattern matches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        result = self._values.get("negate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesBranchNamePattern(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesBranchNamePatternOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesBranchNamePatternOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d9f175d6fa7397266334e67a6353e777e36623c092080fe4c38e7cd7a9d57a2d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetNegate")
    def reset_negate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNegate", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="negateInput")
    def negate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "negateInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="patternInput")
    def pattern_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "patternInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bd90d96a29618340a2f0a49ce860ad308de2d3e6acf11711b49dae1215499fda)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="negate")
    def negate(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "negate"))

    @negate.setter
    def negate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60caba272c930d5a9f76d536e8ca7c3b1373f5901aa5bc078aa8ff7ad2b53e48)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "negate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e6679aae7a6e022f011f6138f884707f07af9980d32dc62f69bc6f464806539)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="pattern")
    def pattern(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "pattern"))

    @pattern.setter
    def pattern(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1d2e86f333336adb879b9efbc73a78c19d42aa559596e9b29d5d915a124dd77e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "pattern", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesBranchNamePattern"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesBranchNamePattern"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesBranchNamePattern"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e5d5b1aad1aa52bb34fd70eeb971b9154b14da26278e3e356427da601687da3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesCommitAuthorEmailPattern",
    jsii_struct_bases=[],
    name_mapping={
        "operator": "operator",
        "pattern": "pattern",
        "name": "name",
        "negate": "negate",
    },
)
class OrganizationRulesetRulesCommitAuthorEmailPattern:
    def __init__(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e827b612949fc2423200d9a9b23800099c867d08ff18be5dfa84a25d5b088664)
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument negate", value=negate, expected_type=type_hints["negate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "operator": operator,
            "pattern": pattern,
        }
        if name is not None:
            self._values["name"] = name
        if negate is not None:
            self._values["negate"] = negate

    @builtins.property
    def operator(self) -> builtins.str:
        '''The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        '''
        result = self._values.get("operator")
        assert result is not None, "Required property 'operator' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pattern(self) -> builtins.str:
        '''The pattern to match with.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''How this rule will appear to users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def negate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''If true, the rule will fail if the pattern matches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        result = self._values.get("negate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesCommitAuthorEmailPattern(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesCommitAuthorEmailPatternOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesCommitAuthorEmailPatternOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7865f15cf13ba0a9716e2dc39f7fbc2eca02db2449a850732565c5bc95639dbe)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetNegate")
    def reset_negate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNegate", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="negateInput")
    def negate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "negateInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="patternInput")
    def pattern_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "patternInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__62ca8fad0e36cff671b97eb04df643042e59a6e2bd6d058963313449ed08f0c2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="negate")
    def negate(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "negate"))

    @negate.setter
    def negate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a1401a0e9042ded5fae113af8b2ecdeeb11d60fc4e66807f2cfea2cbd4970b3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "negate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__37cacb7d4f3260c2b2c49a261ace4334162f11dce1342467f6381276494c7aac)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="pattern")
    def pattern(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "pattern"))

    @pattern.setter
    def pattern(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__468f43d3d326733a098daac9a2fba1d1650bd06edec77a97232bb2cc550aed19)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "pattern", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCommitAuthorEmailPattern"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesCommitAuthorEmailPattern"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesCommitAuthorEmailPattern"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2d139c39087fd1b6499b357a00c903c6be5fa088ca5c9104dc3221adfc65061d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesCommitMessagePattern",
    jsii_struct_bases=[],
    name_mapping={
        "operator": "operator",
        "pattern": "pattern",
        "name": "name",
        "negate": "negate",
    },
)
class OrganizationRulesetRulesCommitMessagePattern:
    def __init__(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__09e2486646e537b3bb8c0484c123202179898a4b804daf889657b73e8ecaa325)
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument negate", value=negate, expected_type=type_hints["negate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "operator": operator,
            "pattern": pattern,
        }
        if name is not None:
            self._values["name"] = name
        if negate is not None:
            self._values["negate"] = negate

    @builtins.property
    def operator(self) -> builtins.str:
        '''The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        '''
        result = self._values.get("operator")
        assert result is not None, "Required property 'operator' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pattern(self) -> builtins.str:
        '''The pattern to match with.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''How this rule will appear to users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def negate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''If true, the rule will fail if the pattern matches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        result = self._values.get("negate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesCommitMessagePattern(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesCommitMessagePatternOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesCommitMessagePatternOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__88efdcec012fae89b97e0165ec5c7512e6033952f644f165bb5466a9c88c40a0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetNegate")
    def reset_negate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNegate", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="negateInput")
    def negate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "negateInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="patternInput")
    def pattern_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "patternInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4253f30e214cfd76e4f521ff37da7f168549bd4c9f1c1606516501bb0cbb0ae4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="negate")
    def negate(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "negate"))

    @negate.setter
    def negate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__26042938aaf67484c724a749c7da70bd48e9f19c3a43dcb8df77d0cd93953aa0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "negate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3042121131db9edbb21a33bb02041839c7aa67da27fea071e7a52fa573ac7cb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="pattern")
    def pattern(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "pattern"))

    @pattern.setter
    def pattern(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97540aab39fd987a43b7f7c02637a570070600b7126461e0b1dbbbc832ddbda4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "pattern", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCommitMessagePattern"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesCommitMessagePattern"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesCommitMessagePattern"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__32d577c2d4bbea5c0904c88c70c308e525edef22da3d059fa9e9ad1117990556)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesCommitterEmailPattern",
    jsii_struct_bases=[],
    name_mapping={
        "operator": "operator",
        "pattern": "pattern",
        "name": "name",
        "negate": "negate",
    },
)
class OrganizationRulesetRulesCommitterEmailPattern:
    def __init__(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__70a4155b27d41300667cafd2bb35ea15fbd14839e02e4ea62d064c623ac97356)
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument negate", value=negate, expected_type=type_hints["negate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "operator": operator,
            "pattern": pattern,
        }
        if name is not None:
            self._values["name"] = name
        if negate is not None:
            self._values["negate"] = negate

    @builtins.property
    def operator(self) -> builtins.str:
        '''The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        '''
        result = self._values.get("operator")
        assert result is not None, "Required property 'operator' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pattern(self) -> builtins.str:
        '''The pattern to match with.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''How this rule will appear to users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def negate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''If true, the rule will fail if the pattern matches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        result = self._values.get("negate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesCommitterEmailPattern(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesCommitterEmailPatternOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesCommitterEmailPatternOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__81c9e8afd6a2231aa20252981c1d06859adef4b5e9da7b728c48341e32938233)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetNegate")
    def reset_negate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNegate", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="negateInput")
    def negate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "negateInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="patternInput")
    def pattern_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "patternInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b052eb5d938c83b169c062529c67c0196c3d8a94ff664b57bbef7fca0761bf0a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="negate")
    def negate(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "negate"))

    @negate.setter
    def negate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__763be80f5f45495ab74fbb99083f88e7920d2645b87ad512812650bdeb077e4f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "negate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__742982493f72062dcb30773f331573d5fda21bdf538fc035ddab4c16ec8b7fe6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="pattern")
    def pattern(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "pattern"))

    @pattern.setter
    def pattern(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54ecc06f56ca0219d3267e170f58b1d8538387702ed475235a557c9b6e41d439)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "pattern", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCommitterEmailPattern"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesCommitterEmailPattern"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesCommitterEmailPattern"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eeb0f50411403e20f2723634dda4837e208c7a0406c9b4b1960ad26008685a16)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesCopilotCodeReview",
    jsii_struct_bases=[],
    name_mapping={
        "review_draft_pull_requests": "reviewDraftPullRequests",
        "review_on_push": "reviewOnPush",
    },
)
class OrganizationRulesetRulesCopilotCodeReview:
    def __init__(
        self,
        *,
        review_draft_pull_requests: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        review_on_push: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param review_draft_pull_requests: Copilot automatically reviews draft pull requests before they are marked as ready for review. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#review_draft_pull_requests OrganizationRuleset#review_draft_pull_requests}
        :param review_on_push: Copilot automatically reviews each new push to the pull request. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#review_on_push OrganizationRuleset#review_on_push}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__96b2ad9fc497c8f853662e1abd21cd8b11bd3ba564018947e692698b211cbcaf)
            check_type(argname="argument review_draft_pull_requests", value=review_draft_pull_requests, expected_type=type_hints["review_draft_pull_requests"])
            check_type(argname="argument review_on_push", value=review_on_push, expected_type=type_hints["review_on_push"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if review_draft_pull_requests is not None:
            self._values["review_draft_pull_requests"] = review_draft_pull_requests
        if review_on_push is not None:
            self._values["review_on_push"] = review_on_push

    @builtins.property
    def review_draft_pull_requests(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Copilot automatically reviews draft pull requests before they are marked as ready for review. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#review_draft_pull_requests OrganizationRuleset#review_draft_pull_requests}
        '''
        result = self._values.get("review_draft_pull_requests")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def review_on_push(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Copilot automatically reviews each new push to the pull request. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#review_on_push OrganizationRuleset#review_on_push}
        '''
        result = self._values.get("review_on_push")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesCopilotCodeReview(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesCopilotCodeReviewOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesCopilotCodeReviewOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c6107d3228c9bfddeb926d5560c91e223a0d7b4c97dbe70538dc789be647cae2)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetReviewDraftPullRequests")
    def reset_review_draft_pull_requests(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReviewDraftPullRequests", []))

    @jsii.member(jsii_name="resetReviewOnPush")
    def reset_review_on_push(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReviewOnPush", []))

    @builtins.property
    @jsii.member(jsii_name="reviewDraftPullRequestsInput")
    def review_draft_pull_requests_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "reviewDraftPullRequestsInput"))

    @builtins.property
    @jsii.member(jsii_name="reviewOnPushInput")
    def review_on_push_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "reviewOnPushInput"))

    @builtins.property
    @jsii.member(jsii_name="reviewDraftPullRequests")
    def review_draft_pull_requests(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "reviewDraftPullRequests"))

    @review_draft_pull_requests.setter
    def review_draft_pull_requests(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8790285e824c86bd938acff4373c181728f56d5feafe967ecc3aed00d963d67f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "reviewDraftPullRequests", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="reviewOnPush")
    def review_on_push(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "reviewOnPush"))

    @review_on_push.setter
    def review_on_push(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98db29ea54ed435a93bcb3c175ccc99bac6acd8beaf1dcadf3efcd93d2ca7608)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "reviewOnPush", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCopilotCodeReview"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesCopilotCodeReview"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesCopilotCodeReview"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c563d6060e48c096a47dea190f5e64246aadb8b00a8eda208624fcfe420837c1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesFileExtensionRestriction",
    jsii_struct_bases=[],
    name_mapping={"restricted_file_extensions": "restrictedFileExtensions"},
)
class OrganizationRulesetRulesFileExtensionRestriction:
    def __init__(
        self,
        *,
        restricted_file_extensions: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param restricted_file_extensions: The file extensions that are restricted from being pushed to the commit graph. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#restricted_file_extensions OrganizationRuleset#restricted_file_extensions}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1142483baae28f2b5f2452f63e1a24015daa8d545061c7a4082640b2a32cb529)
            check_type(argname="argument restricted_file_extensions", value=restricted_file_extensions, expected_type=type_hints["restricted_file_extensions"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "restricted_file_extensions": restricted_file_extensions,
        }

    @builtins.property
    def restricted_file_extensions(self) -> typing.List[builtins.str]:
        '''The file extensions that are restricted from being pushed to the commit graph.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#restricted_file_extensions OrganizationRuleset#restricted_file_extensions}
        '''
        result = self._values.get("restricted_file_extensions")
        assert result is not None, "Required property 'restricted_file_extensions' is missing"
        return typing.cast(typing.List[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesFileExtensionRestriction(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesFileExtensionRestrictionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesFileExtensionRestrictionOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54e103356ec752eb0a82b402fa6f8f711bcc3cba50db9943535acc4ca829707d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="restrictedFileExtensionsInput")
    def restricted_file_extensions_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "restrictedFileExtensionsInput"))

    @builtins.property
    @jsii.member(jsii_name="restrictedFileExtensions")
    def restricted_file_extensions(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "restrictedFileExtensions"))

    @restricted_file_extensions.setter
    def restricted_file_extensions(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d85814020cd7b52a253fe1c402d23b76b4537d79cd346fb7c86b31319be75d15)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "restrictedFileExtensions", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesFileExtensionRestriction"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesFileExtensionRestriction"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesFileExtensionRestriction"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__07acef222e3c4b3d23c91658e0906232bc09bcb5aa0258a55d68831d78440dc7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesFilePathRestriction",
    jsii_struct_bases=[],
    name_mapping={"restricted_file_paths": "restrictedFilePaths"},
)
class OrganizationRulesetRulesFilePathRestriction:
    def __init__(self, *, restricted_file_paths: typing.Sequence[builtins.str]) -> None:
        '''
        :param restricted_file_paths: The file paths that are restricted from being pushed to the commit graph. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#restricted_file_paths OrganizationRuleset#restricted_file_paths}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98fc3411e25c989e760ebdd642dca1e61b827b7fcd762492551be1e3462648d9)
            check_type(argname="argument restricted_file_paths", value=restricted_file_paths, expected_type=type_hints["restricted_file_paths"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "restricted_file_paths": restricted_file_paths,
        }

    @builtins.property
    def restricted_file_paths(self) -> typing.List[builtins.str]:
        '''The file paths that are restricted from being pushed to the commit graph.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#restricted_file_paths OrganizationRuleset#restricted_file_paths}
        '''
        result = self._values.get("restricted_file_paths")
        assert result is not None, "Required property 'restricted_file_paths' is missing"
        return typing.cast(typing.List[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesFilePathRestriction(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesFilePathRestrictionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesFilePathRestrictionOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77bd3db678e31d1c6533327ffdea528890eeed0c4b66f2e9ae8b320717067534)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="restrictedFilePathsInput")
    def restricted_file_paths_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "restrictedFilePathsInput"))

    @builtins.property
    @jsii.member(jsii_name="restrictedFilePaths")
    def restricted_file_paths(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "restrictedFilePaths"))

    @restricted_file_paths.setter
    def restricted_file_paths(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__752d13f31c8ff14835cd0b8dfcbe9e4ee445ee2db3e8b2b5150601683950c3f9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "restrictedFilePaths", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesFilePathRestriction"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesFilePathRestriction"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesFilePathRestriction"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38fe1398d0390cb58474d09af6b526710f75e5e6f0e9bca76f00018faa55e4d0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesMaxFilePathLength",
    jsii_struct_bases=[],
    name_mapping={"max_file_path_length": "maxFilePathLength"},
)
class OrganizationRulesetRulesMaxFilePathLength:
    def __init__(self, *, max_file_path_length: jsii.Number) -> None:
        '''
        :param max_file_path_length: The maximum allowed length of a file path. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_path_length OrganizationRuleset#max_file_path_length}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3374e8e30b30ab3bd1f07b963f7c7f5870cc00fa3cf68ba0835f488e9c6ec781)
            check_type(argname="argument max_file_path_length", value=max_file_path_length, expected_type=type_hints["max_file_path_length"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "max_file_path_length": max_file_path_length,
        }

    @builtins.property
    def max_file_path_length(self) -> jsii.Number:
        '''The maximum allowed length of a file path.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_path_length OrganizationRuleset#max_file_path_length}
        '''
        result = self._values.get("max_file_path_length")
        assert result is not None, "Required property 'max_file_path_length' is missing"
        return typing.cast(jsii.Number, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesMaxFilePathLength(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesMaxFilePathLengthOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesMaxFilePathLengthOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9798307c8ae501d06e0a1de076c500c40c19ae7f971bb356e9ea12e9e626d321)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="maxFilePathLengthInput")
    def max_file_path_length_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxFilePathLengthInput"))

    @builtins.property
    @jsii.member(jsii_name="maxFilePathLength")
    def max_file_path_length(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "maxFilePathLength"))

    @max_file_path_length.setter
    def max_file_path_length(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__24c367d929c9f8fd7fc4e398696ee1c346434e8e182318007de83d6e2c292660)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxFilePathLength", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesMaxFilePathLength"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesMaxFilePathLength"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesMaxFilePathLength"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8fc97894fcdebfb563846a2b53a4bb74ce5940ddd360ad1ad848831135f6b09a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesMaxFileSize",
    jsii_struct_bases=[],
    name_mapping={"max_file_size": "maxFileSize"},
)
class OrganizationRulesetRulesMaxFileSize:
    def __init__(self, *, max_file_size: jsii.Number) -> None:
        '''
        :param max_file_size: The maximum allowed size of a file in megabytes (MB). Valid range is 1-100 MB. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_size OrganizationRuleset#max_file_size}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1ecb53ca13a367941940d8d35366ceb3ec517ed90d3addd7ec97a7fd0dfa497b)
            check_type(argname="argument max_file_size", value=max_file_size, expected_type=type_hints["max_file_size"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "max_file_size": max_file_size,
        }

    @builtins.property
    def max_file_size(self) -> jsii.Number:
        '''The maximum allowed size of a file in megabytes (MB). Valid range is 1-100 MB.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_size OrganizationRuleset#max_file_size}
        '''
        result = self._values.get("max_file_size")
        assert result is not None, "Required property 'max_file_size' is missing"
        return typing.cast(jsii.Number, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesMaxFileSize(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesMaxFileSizeOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesMaxFileSizeOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__88decc216093b704c1d50eb97625b6be747a6a4ad5687c020b3546f69ca0cd91)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="maxFileSizeInput")
    def max_file_size_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "maxFileSizeInput"))

    @builtins.property
    @jsii.member(jsii_name="maxFileSize")
    def max_file_size(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "maxFileSize"))

    @max_file_size.setter
    def max_file_size(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a9a7be27509fc7c994929792314b8f6465571484a1920b6114cfbec65551a7af)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maxFileSize", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["OrganizationRulesetRulesMaxFileSize"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesMaxFileSize"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesMaxFileSize"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b95f67c38e9b6d358559aef21ce1f1a91fe33e6bc987320e0ff4c1b0975d6dc9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class OrganizationRulesetRulesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4796b1b041ffdbe195c5cf1819a49110ccc1dc4d2cded129b93c50735085d38d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putBranchNamePattern")
    def put_branch_name_pattern(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        value = OrganizationRulesetRulesBranchNamePattern(
            operator=operator, pattern=pattern, name=name, negate=negate
        )

        return typing.cast(None, jsii.invoke(self, "putBranchNamePattern", [value]))

    @jsii.member(jsii_name="putCommitAuthorEmailPattern")
    def put_commit_author_email_pattern(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        value = OrganizationRulesetRulesCommitAuthorEmailPattern(
            operator=operator, pattern=pattern, name=name, negate=negate
        )

        return typing.cast(None, jsii.invoke(self, "putCommitAuthorEmailPattern", [value]))

    @jsii.member(jsii_name="putCommitMessagePattern")
    def put_commit_message_pattern(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        value = OrganizationRulesetRulesCommitMessagePattern(
            operator=operator, pattern=pattern, name=name, negate=negate
        )

        return typing.cast(None, jsii.invoke(self, "putCommitMessagePattern", [value]))

    @jsii.member(jsii_name="putCommitterEmailPattern")
    def put_committer_email_pattern(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        value = OrganizationRulesetRulesCommitterEmailPattern(
            operator=operator, pattern=pattern, name=name, negate=negate
        )

        return typing.cast(None, jsii.invoke(self, "putCommitterEmailPattern", [value]))

    @jsii.member(jsii_name="putCopilotCodeReview")
    def put_copilot_code_review(
        self,
        *,
        review_draft_pull_requests: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        review_on_push: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param review_draft_pull_requests: Copilot automatically reviews draft pull requests before they are marked as ready for review. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#review_draft_pull_requests OrganizationRuleset#review_draft_pull_requests}
        :param review_on_push: Copilot automatically reviews each new push to the pull request. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#review_on_push OrganizationRuleset#review_on_push}
        '''
        value = OrganizationRulesetRulesCopilotCodeReview(
            review_draft_pull_requests=review_draft_pull_requests,
            review_on_push=review_on_push,
        )

        return typing.cast(None, jsii.invoke(self, "putCopilotCodeReview", [value]))

    @jsii.member(jsii_name="putFileExtensionRestriction")
    def put_file_extension_restriction(
        self,
        *,
        restricted_file_extensions: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param restricted_file_extensions: The file extensions that are restricted from being pushed to the commit graph. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#restricted_file_extensions OrganizationRuleset#restricted_file_extensions}
        '''
        value = OrganizationRulesetRulesFileExtensionRestriction(
            restricted_file_extensions=restricted_file_extensions
        )

        return typing.cast(None, jsii.invoke(self, "putFileExtensionRestriction", [value]))

    @jsii.member(jsii_name="putFilePathRestriction")
    def put_file_path_restriction(
        self,
        *,
        restricted_file_paths: typing.Sequence[builtins.str],
    ) -> None:
        '''
        :param restricted_file_paths: The file paths that are restricted from being pushed to the commit graph. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#restricted_file_paths OrganizationRuleset#restricted_file_paths}
        '''
        value = OrganizationRulesetRulesFilePathRestriction(
            restricted_file_paths=restricted_file_paths
        )

        return typing.cast(None, jsii.invoke(self, "putFilePathRestriction", [value]))

    @jsii.member(jsii_name="putMaxFilePathLength")
    def put_max_file_path_length(self, *, max_file_path_length: jsii.Number) -> None:
        '''
        :param max_file_path_length: The maximum allowed length of a file path. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_path_length OrganizationRuleset#max_file_path_length}
        '''
        value = OrganizationRulesetRulesMaxFilePathLength(
            max_file_path_length=max_file_path_length
        )

        return typing.cast(None, jsii.invoke(self, "putMaxFilePathLength", [value]))

    @jsii.member(jsii_name="putMaxFileSize")
    def put_max_file_size(self, *, max_file_size: jsii.Number) -> None:
        '''
        :param max_file_size: The maximum allowed size of a file in megabytes (MB). Valid range is 1-100 MB. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#max_file_size OrganizationRuleset#max_file_size}
        '''
        value = OrganizationRulesetRulesMaxFileSize(max_file_size=max_file_size)

        return typing.cast(None, jsii.invoke(self, "putMaxFileSize", [value]))

    @jsii.member(jsii_name="putPullRequest")
    def put_pull_request(
        self,
        *,
        allowed_merge_methods: typing.Optional[typing.Sequence[builtins.str]] = None,
        dismiss_stale_reviews_on_push: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        require_code_owner_review: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_approving_review_count: typing.Optional[jsii.Number] = None,
        required_reviewers: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesPullRequestRequiredReviewers", typing.Dict[builtins.str, typing.Any]]]]] = None,
        required_review_thread_resolution: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        require_last_push_approval: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param allowed_merge_methods: Array of allowed merge methods. Allowed values include ``merge``, ``squash``, and ``rebase``. At least one option must be enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#allowed_merge_methods OrganizationRuleset#allowed_merge_methods}
        :param dismiss_stale_reviews_on_push: New, reviewable commits pushed will dismiss previous pull request review approvals. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#dismiss_stale_reviews_on_push OrganizationRuleset#dismiss_stale_reviews_on_push}
        :param require_code_owner_review: Require an approving review in pull requests that modify files that have a designated code owner. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#require_code_owner_review OrganizationRuleset#require_code_owner_review}
        :param required_approving_review_count: The number of approving reviews that are required before a pull request can be merged. Defaults to ``0``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_approving_review_count OrganizationRuleset#required_approving_review_count}
        :param required_reviewers: required_reviewers block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_reviewers OrganizationRuleset#required_reviewers}
        :param required_review_thread_resolution: All conversations on code must be resolved before a pull request can be merged. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_review_thread_resolution OrganizationRuleset#required_review_thread_resolution}
        :param require_last_push_approval: Whether the most recent reviewable push must be approved by someone other than the person who pushed it. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#require_last_push_approval OrganizationRuleset#require_last_push_approval}
        '''
        value = OrganizationRulesetRulesPullRequest(
            allowed_merge_methods=allowed_merge_methods,
            dismiss_stale_reviews_on_push=dismiss_stale_reviews_on_push,
            require_code_owner_review=require_code_owner_review,
            required_approving_review_count=required_approving_review_count,
            required_reviewers=required_reviewers,
            required_review_thread_resolution=required_review_thread_resolution,
            require_last_push_approval=require_last_push_approval,
        )

        return typing.cast(None, jsii.invoke(self, "putPullRequest", [value]))

    @jsii.member(jsii_name="putRequiredCodeScanning")
    def put_required_code_scanning(
        self,
        *,
        required_code_scanning_tool: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param required_code_scanning_tool: required_code_scanning_tool block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_code_scanning_tool OrganizationRuleset#required_code_scanning_tool}
        '''
        value = OrganizationRulesetRulesRequiredCodeScanning(
            required_code_scanning_tool=required_code_scanning_tool
        )

        return typing.cast(None, jsii.invoke(self, "putRequiredCodeScanning", [value]))

    @jsii.member(jsii_name="putRequiredStatusChecks")
    def put_required_status_checks(
        self,
        *,
        required_check: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesRequiredStatusChecksRequiredCheck", typing.Dict[builtins.str, typing.Any]]]],
        do_not_enforce_on_create: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        strict_required_status_checks_policy: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param required_check: required_check block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_check OrganizationRuleset#required_check}
        :param do_not_enforce_on_create: Allow repositories and branches to be created if a check would otherwise prohibit it. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#do_not_enforce_on_create OrganizationRuleset#do_not_enforce_on_create}
        :param strict_required_status_checks_policy: Whether pull requests targeting a matching branch must be tested with the latest code. This setting will not take effect unless at least one status check is enabled. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#strict_required_status_checks_policy OrganizationRuleset#strict_required_status_checks_policy}
        '''
        value = OrganizationRulesetRulesRequiredStatusChecks(
            required_check=required_check,
            do_not_enforce_on_create=do_not_enforce_on_create,
            strict_required_status_checks_policy=strict_required_status_checks_policy,
        )

        return typing.cast(None, jsii.invoke(self, "putRequiredStatusChecks", [value]))

    @jsii.member(jsii_name="putRequiredWorkflows")
    def put_required_workflows(
        self,
        *,
        required_workflow: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow", typing.Dict[builtins.str, typing.Any]]]],
        do_not_enforce_on_create: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param required_workflow: required_workflow block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_workflow OrganizationRuleset#required_workflow}
        :param do_not_enforce_on_create: Allow repositories and branches to be created if a check would otherwise prohibit it. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#do_not_enforce_on_create OrganizationRuleset#do_not_enforce_on_create}
        '''
        value = OrganizationRulesetRulesRequiredWorkflows(
            required_workflow=required_workflow,
            do_not_enforce_on_create=do_not_enforce_on_create,
        )

        return typing.cast(None, jsii.invoke(self, "putRequiredWorkflows", [value]))

    @jsii.member(jsii_name="putTagNamePattern")
    def put_tag_name_pattern(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        value = OrganizationRulesetRulesTagNamePattern(
            operator=operator, pattern=pattern, name=name, negate=negate
        )

        return typing.cast(None, jsii.invoke(self, "putTagNamePattern", [value]))

    @jsii.member(jsii_name="resetBranchNamePattern")
    def reset_branch_name_pattern(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBranchNamePattern", []))

    @jsii.member(jsii_name="resetCommitAuthorEmailPattern")
    def reset_commit_author_email_pattern(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCommitAuthorEmailPattern", []))

    @jsii.member(jsii_name="resetCommitMessagePattern")
    def reset_commit_message_pattern(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCommitMessagePattern", []))

    @jsii.member(jsii_name="resetCommitterEmailPattern")
    def reset_committer_email_pattern(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCommitterEmailPattern", []))

    @jsii.member(jsii_name="resetCopilotCodeReview")
    def reset_copilot_code_review(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCopilotCodeReview", []))

    @jsii.member(jsii_name="resetCreation")
    def reset_creation(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreation", []))

    @jsii.member(jsii_name="resetDeletion")
    def reset_deletion(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDeletion", []))

    @jsii.member(jsii_name="resetFileExtensionRestriction")
    def reset_file_extension_restriction(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFileExtensionRestriction", []))

    @jsii.member(jsii_name="resetFilePathRestriction")
    def reset_file_path_restriction(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFilePathRestriction", []))

    @jsii.member(jsii_name="resetMaxFilePathLength")
    def reset_max_file_path_length(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxFilePathLength", []))

    @jsii.member(jsii_name="resetMaxFileSize")
    def reset_max_file_size(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaxFileSize", []))

    @jsii.member(jsii_name="resetNonFastForward")
    def reset_non_fast_forward(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNonFastForward", []))

    @jsii.member(jsii_name="resetPullRequest")
    def reset_pull_request(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPullRequest", []))

    @jsii.member(jsii_name="resetRequiredCodeScanning")
    def reset_required_code_scanning(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredCodeScanning", []))

    @jsii.member(jsii_name="resetRequiredLinearHistory")
    def reset_required_linear_history(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredLinearHistory", []))

    @jsii.member(jsii_name="resetRequiredSignatures")
    def reset_required_signatures(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredSignatures", []))

    @jsii.member(jsii_name="resetRequiredStatusChecks")
    def reset_required_status_checks(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredStatusChecks", []))

    @jsii.member(jsii_name="resetRequiredWorkflows")
    def reset_required_workflows(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredWorkflows", []))

    @jsii.member(jsii_name="resetTagNamePattern")
    def reset_tag_name_pattern(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTagNamePattern", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="branchNamePattern")
    def branch_name_pattern(
        self,
    ) -> "OrganizationRulesetRulesBranchNamePatternOutputReference":
        return typing.cast("OrganizationRulesetRulesBranchNamePatternOutputReference", jsii.get(self, "branchNamePattern"))

    @builtins.property
    @jsii.member(jsii_name="commitAuthorEmailPattern")
    def commit_author_email_pattern(
        self,
    ) -> "OrganizationRulesetRulesCommitAuthorEmailPatternOutputReference":
        return typing.cast("OrganizationRulesetRulesCommitAuthorEmailPatternOutputReference", jsii.get(self, "commitAuthorEmailPattern"))

    @builtins.property
    @jsii.member(jsii_name="commitMessagePattern")
    def commit_message_pattern(
        self,
    ) -> "OrganizationRulesetRulesCommitMessagePatternOutputReference":
        return typing.cast("OrganizationRulesetRulesCommitMessagePatternOutputReference", jsii.get(self, "commitMessagePattern"))

    @builtins.property
    @jsii.member(jsii_name="committerEmailPattern")
    def committer_email_pattern(
        self,
    ) -> "OrganizationRulesetRulesCommitterEmailPatternOutputReference":
        return typing.cast("OrganizationRulesetRulesCommitterEmailPatternOutputReference", jsii.get(self, "committerEmailPattern"))

    @builtins.property
    @jsii.member(jsii_name="copilotCodeReview")
    def copilot_code_review(
        self,
    ) -> "OrganizationRulesetRulesCopilotCodeReviewOutputReference":
        return typing.cast("OrganizationRulesetRulesCopilotCodeReviewOutputReference", jsii.get(self, "copilotCodeReview"))

    @builtins.property
    @jsii.member(jsii_name="fileExtensionRestriction")
    def file_extension_restriction(
        self,
    ) -> "OrganizationRulesetRulesFileExtensionRestrictionOutputReference":
        return typing.cast("OrganizationRulesetRulesFileExtensionRestrictionOutputReference", jsii.get(self, "fileExtensionRestriction"))

    @builtins.property
    @jsii.member(jsii_name="filePathRestriction")
    def file_path_restriction(
        self,
    ) -> "OrganizationRulesetRulesFilePathRestrictionOutputReference":
        return typing.cast("OrganizationRulesetRulesFilePathRestrictionOutputReference", jsii.get(self, "filePathRestriction"))

    @builtins.property
    @jsii.member(jsii_name="maxFilePathLength")
    def max_file_path_length(
        self,
    ) -> "OrganizationRulesetRulesMaxFilePathLengthOutputReference":
        return typing.cast("OrganizationRulesetRulesMaxFilePathLengthOutputReference", jsii.get(self, "maxFilePathLength"))

    @builtins.property
    @jsii.member(jsii_name="maxFileSize")
    def max_file_size(self) -> "OrganizationRulesetRulesMaxFileSizeOutputReference":
        return typing.cast("OrganizationRulesetRulesMaxFileSizeOutputReference", jsii.get(self, "maxFileSize"))

    @builtins.property
    @jsii.member(jsii_name="pullRequest")
    def pull_request(self) -> "OrganizationRulesetRulesPullRequestOutputReference":
        return typing.cast("OrganizationRulesetRulesPullRequestOutputReference", jsii.get(self, "pullRequest"))

    @builtins.property
    @jsii.member(jsii_name="requiredCodeScanning")
    def required_code_scanning(
        self,
    ) -> "OrganizationRulesetRulesRequiredCodeScanningOutputReference":
        return typing.cast("OrganizationRulesetRulesRequiredCodeScanningOutputReference", jsii.get(self, "requiredCodeScanning"))

    @builtins.property
    @jsii.member(jsii_name="requiredStatusChecks")
    def required_status_checks(
        self,
    ) -> "OrganizationRulesetRulesRequiredStatusChecksOutputReference":
        return typing.cast("OrganizationRulesetRulesRequiredStatusChecksOutputReference", jsii.get(self, "requiredStatusChecks"))

    @builtins.property
    @jsii.member(jsii_name="requiredWorkflows")
    def required_workflows(
        self,
    ) -> "OrganizationRulesetRulesRequiredWorkflowsOutputReference":
        return typing.cast("OrganizationRulesetRulesRequiredWorkflowsOutputReference", jsii.get(self, "requiredWorkflows"))

    @builtins.property
    @jsii.member(jsii_name="tagNamePattern")
    def tag_name_pattern(
        self,
    ) -> "OrganizationRulesetRulesTagNamePatternOutputReference":
        return typing.cast("OrganizationRulesetRulesTagNamePatternOutputReference", jsii.get(self, "tagNamePattern"))

    @builtins.property
    @jsii.member(jsii_name="branchNamePatternInput")
    def branch_name_pattern_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesBranchNamePattern"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesBranchNamePattern"], jsii.get(self, "branchNamePatternInput"))

    @builtins.property
    @jsii.member(jsii_name="commitAuthorEmailPatternInput")
    def commit_author_email_pattern_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCommitAuthorEmailPattern"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesCommitAuthorEmailPattern"], jsii.get(self, "commitAuthorEmailPatternInput"))

    @builtins.property
    @jsii.member(jsii_name="commitMessagePatternInput")
    def commit_message_pattern_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCommitMessagePattern"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesCommitMessagePattern"], jsii.get(self, "commitMessagePatternInput"))

    @builtins.property
    @jsii.member(jsii_name="committerEmailPatternInput")
    def committer_email_pattern_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCommitterEmailPattern"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesCommitterEmailPattern"], jsii.get(self, "committerEmailPatternInput"))

    @builtins.property
    @jsii.member(jsii_name="copilotCodeReviewInput")
    def copilot_code_review_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesCopilotCodeReview"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesCopilotCodeReview"], jsii.get(self, "copilotCodeReviewInput"))

    @builtins.property
    @jsii.member(jsii_name="creationInput")
    def creation_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "creationInput"))

    @builtins.property
    @jsii.member(jsii_name="deletionInput")
    def deletion_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "deletionInput"))

    @builtins.property
    @jsii.member(jsii_name="fileExtensionRestrictionInput")
    def file_extension_restriction_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesFileExtensionRestriction"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesFileExtensionRestriction"], jsii.get(self, "fileExtensionRestrictionInput"))

    @builtins.property
    @jsii.member(jsii_name="filePathRestrictionInput")
    def file_path_restriction_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesFilePathRestriction"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesFilePathRestriction"], jsii.get(self, "filePathRestrictionInput"))

    @builtins.property
    @jsii.member(jsii_name="maxFilePathLengthInput")
    def max_file_path_length_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesMaxFilePathLength"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesMaxFilePathLength"], jsii.get(self, "maxFilePathLengthInput"))

    @builtins.property
    @jsii.member(jsii_name="maxFileSizeInput")
    def max_file_size_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesMaxFileSize"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesMaxFileSize"], jsii.get(self, "maxFileSizeInput"))

    @builtins.property
    @jsii.member(jsii_name="nonFastForwardInput")
    def non_fast_forward_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "nonFastForwardInput"))

    @builtins.property
    @jsii.member(jsii_name="pullRequestInput")
    def pull_request_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesPullRequest"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesPullRequest"], jsii.get(self, "pullRequestInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredCodeScanningInput")
    def required_code_scanning_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesRequiredCodeScanning"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesRequiredCodeScanning"], jsii.get(self, "requiredCodeScanningInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredLinearHistoryInput")
    def required_linear_history_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "requiredLinearHistoryInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredSignaturesInput")
    def required_signatures_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "requiredSignaturesInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredStatusChecksInput")
    def required_status_checks_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesRequiredStatusChecks"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesRequiredStatusChecks"], jsii.get(self, "requiredStatusChecksInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredWorkflowsInput")
    def required_workflows_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesRequiredWorkflows"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesRequiredWorkflows"], jsii.get(self, "requiredWorkflowsInput"))

    @builtins.property
    @jsii.member(jsii_name="tagNamePatternInput")
    def tag_name_pattern_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesTagNamePattern"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesTagNamePattern"], jsii.get(self, "tagNamePatternInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="creation")
    def creation(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "creation"))

    @creation.setter
    def creation(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b0d4de60ff51eaa931a9042b6ba23f6159094290dfcdf4202c947c2c969f61f8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "creation", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="deletion")
    def deletion(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "deletion"))

    @deletion.setter
    def deletion(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__abb74a422533847497a6d3b11bdfe92519ee277c3cc2387b382ecb578950b27d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "deletion", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="nonFastForward")
    def non_fast_forward(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "nonFastForward"))

    @non_fast_forward.setter
    def non_fast_forward(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__41ae130f746b1b6fc15941194a629dbba667bd1e36b35b944dd95884f31016fe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "nonFastForward", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requiredLinearHistory")
    def required_linear_history(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "requiredLinearHistory"))

    @required_linear_history.setter
    def required_linear_history(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__00641c6b7d748134751e52df1fab6ce996ee799412843e21b40ff4b5b4610f4e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requiredLinearHistory", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requiredSignatures")
    def required_signatures(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "requiredSignatures"))

    @required_signatures.setter
    def required_signatures(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9152706f1266d5e3dc296ac00bbeb9455ee8810efca6f1a15d95603a8d8232f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requiredSignatures", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "update"))

    @update.setter
    def update(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08edcad08a56ae70fc3a877dd67deae0d9ca452c66ef469a59b49cb8ce9e8851)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["OrganizationRulesetRules"]:
        return typing.cast(typing.Optional["OrganizationRulesetRules"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRules"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eff130a4ccb11eeaa0c2d97c01789302d02ee0f442ed41a2edf9a5ee0f3d2cc7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesPullRequest",
    jsii_struct_bases=[],
    name_mapping={
        "allowed_merge_methods": "allowedMergeMethods",
        "dismiss_stale_reviews_on_push": "dismissStaleReviewsOnPush",
        "require_code_owner_review": "requireCodeOwnerReview",
        "required_approving_review_count": "requiredApprovingReviewCount",
        "required_reviewers": "requiredReviewers",
        "required_review_thread_resolution": "requiredReviewThreadResolution",
        "require_last_push_approval": "requireLastPushApproval",
    },
)
class OrganizationRulesetRulesPullRequest:
    def __init__(
        self,
        *,
        allowed_merge_methods: typing.Optional[typing.Sequence[builtins.str]] = None,
        dismiss_stale_reviews_on_push: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        require_code_owner_review: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        required_approving_review_count: typing.Optional[jsii.Number] = None,
        required_reviewers: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesPullRequestRequiredReviewers", typing.Dict[builtins.str, typing.Any]]]]] = None,
        required_review_thread_resolution: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        require_last_push_approval: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param allowed_merge_methods: Array of allowed merge methods. Allowed values include ``merge``, ``squash``, and ``rebase``. At least one option must be enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#allowed_merge_methods OrganizationRuleset#allowed_merge_methods}
        :param dismiss_stale_reviews_on_push: New, reviewable commits pushed will dismiss previous pull request review approvals. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#dismiss_stale_reviews_on_push OrganizationRuleset#dismiss_stale_reviews_on_push}
        :param require_code_owner_review: Require an approving review in pull requests that modify files that have a designated code owner. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#require_code_owner_review OrganizationRuleset#require_code_owner_review}
        :param required_approving_review_count: The number of approving reviews that are required before a pull request can be merged. Defaults to ``0``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_approving_review_count OrganizationRuleset#required_approving_review_count}
        :param required_reviewers: required_reviewers block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_reviewers OrganizationRuleset#required_reviewers}
        :param required_review_thread_resolution: All conversations on code must be resolved before a pull request can be merged. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_review_thread_resolution OrganizationRuleset#required_review_thread_resolution}
        :param require_last_push_approval: Whether the most recent reviewable push must be approved by someone other than the person who pushed it. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#require_last_push_approval OrganizationRuleset#require_last_push_approval}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f9ca85a887f9f93f05db659b496f19f1b2d3e125ecdbaea908bf1624e7618a59)
            check_type(argname="argument allowed_merge_methods", value=allowed_merge_methods, expected_type=type_hints["allowed_merge_methods"])
            check_type(argname="argument dismiss_stale_reviews_on_push", value=dismiss_stale_reviews_on_push, expected_type=type_hints["dismiss_stale_reviews_on_push"])
            check_type(argname="argument require_code_owner_review", value=require_code_owner_review, expected_type=type_hints["require_code_owner_review"])
            check_type(argname="argument required_approving_review_count", value=required_approving_review_count, expected_type=type_hints["required_approving_review_count"])
            check_type(argname="argument required_reviewers", value=required_reviewers, expected_type=type_hints["required_reviewers"])
            check_type(argname="argument required_review_thread_resolution", value=required_review_thread_resolution, expected_type=type_hints["required_review_thread_resolution"])
            check_type(argname="argument require_last_push_approval", value=require_last_push_approval, expected_type=type_hints["require_last_push_approval"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if allowed_merge_methods is not None:
            self._values["allowed_merge_methods"] = allowed_merge_methods
        if dismiss_stale_reviews_on_push is not None:
            self._values["dismiss_stale_reviews_on_push"] = dismiss_stale_reviews_on_push
        if require_code_owner_review is not None:
            self._values["require_code_owner_review"] = require_code_owner_review
        if required_approving_review_count is not None:
            self._values["required_approving_review_count"] = required_approving_review_count
        if required_reviewers is not None:
            self._values["required_reviewers"] = required_reviewers
        if required_review_thread_resolution is not None:
            self._values["required_review_thread_resolution"] = required_review_thread_resolution
        if require_last_push_approval is not None:
            self._values["require_last_push_approval"] = require_last_push_approval

    @builtins.property
    def allowed_merge_methods(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Array of allowed merge methods. Allowed values include ``merge``, ``squash``, and ``rebase``. At least one option must be enabled.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#allowed_merge_methods OrganizationRuleset#allowed_merge_methods}
        '''
        result = self._values.get("allowed_merge_methods")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def dismiss_stale_reviews_on_push(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''New, reviewable commits pushed will dismiss previous pull request review approvals. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#dismiss_stale_reviews_on_push OrganizationRuleset#dismiss_stale_reviews_on_push}
        '''
        result = self._values.get("dismiss_stale_reviews_on_push")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def require_code_owner_review(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Require an approving review in pull requests that modify files that have a designated code owner. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#require_code_owner_review OrganizationRuleset#require_code_owner_review}
        '''
        result = self._values.get("require_code_owner_review")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def required_approving_review_count(self) -> typing.Optional[jsii.Number]:
        '''The number of approving reviews that are required before a pull request can be merged. Defaults to ``0``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_approving_review_count OrganizationRuleset#required_approving_review_count}
        '''
        result = self._values.get("required_approving_review_count")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def required_reviewers(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesPullRequestRequiredReviewers"]]]:
        '''required_reviewers block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_reviewers OrganizationRuleset#required_reviewers}
        '''
        result = self._values.get("required_reviewers")
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesPullRequestRequiredReviewers"]]], result)

    @builtins.property
    def required_review_thread_resolution(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''All conversations on code must be resolved before a pull request can be merged. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_review_thread_resolution OrganizationRuleset#required_review_thread_resolution}
        '''
        result = self._values.get("required_review_thread_resolution")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def require_last_push_approval(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Whether the most recent reviewable push must be approved by someone other than the person who pushed it.

        Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#require_last_push_approval OrganizationRuleset#require_last_push_approval}
        '''
        result = self._values.get("require_last_push_approval")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesPullRequest(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesPullRequestOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesPullRequestOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5f20e65082f7b18f8a3dbc064efd26ff85ec4bbfe9d9ba25c4ecc712b2125143)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRequiredReviewers")
    def put_required_reviewers(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesPullRequestRequiredReviewers", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0def8f246e2cf85cd6067b43fc460f263f6bd44f035565d01bb98e817ddd6186)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putRequiredReviewers", [value]))

    @jsii.member(jsii_name="resetAllowedMergeMethods")
    def reset_allowed_merge_methods(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAllowedMergeMethods", []))

    @jsii.member(jsii_name="resetDismissStaleReviewsOnPush")
    def reset_dismiss_stale_reviews_on_push(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDismissStaleReviewsOnPush", []))

    @jsii.member(jsii_name="resetRequireCodeOwnerReview")
    def reset_require_code_owner_review(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequireCodeOwnerReview", []))

    @jsii.member(jsii_name="resetRequiredApprovingReviewCount")
    def reset_required_approving_review_count(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredApprovingReviewCount", []))

    @jsii.member(jsii_name="resetRequiredReviewers")
    def reset_required_reviewers(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredReviewers", []))

    @jsii.member(jsii_name="resetRequiredReviewThreadResolution")
    def reset_required_review_thread_resolution(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredReviewThreadResolution", []))

    @jsii.member(jsii_name="resetRequireLastPushApproval")
    def reset_require_last_push_approval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequireLastPushApproval", []))

    @builtins.property
    @jsii.member(jsii_name="requiredReviewers")
    def required_reviewers(
        self,
    ) -> "OrganizationRulesetRulesPullRequestRequiredReviewersList":
        return typing.cast("OrganizationRulesetRulesPullRequestRequiredReviewersList", jsii.get(self, "requiredReviewers"))

    @builtins.property
    @jsii.member(jsii_name="allowedMergeMethodsInput")
    def allowed_merge_methods_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "allowedMergeMethodsInput"))

    @builtins.property
    @jsii.member(jsii_name="dismissStaleReviewsOnPushInput")
    def dismiss_stale_reviews_on_push_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "dismissStaleReviewsOnPushInput"))

    @builtins.property
    @jsii.member(jsii_name="requireCodeOwnerReviewInput")
    def require_code_owner_review_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "requireCodeOwnerReviewInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredApprovingReviewCountInput")
    def required_approving_review_count_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "requiredApprovingReviewCountInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredReviewersInput")
    def required_reviewers_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesPullRequestRequiredReviewers"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesPullRequestRequiredReviewers"]]], jsii.get(self, "requiredReviewersInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredReviewThreadResolutionInput")
    def required_review_thread_resolution_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "requiredReviewThreadResolutionInput"))

    @builtins.property
    @jsii.member(jsii_name="requireLastPushApprovalInput")
    def require_last_push_approval_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "requireLastPushApprovalInput"))

    @builtins.property
    @jsii.member(jsii_name="allowedMergeMethods")
    def allowed_merge_methods(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "allowedMergeMethods"))

    @allowed_merge_methods.setter
    def allowed_merge_methods(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5411ee07cf0e21487a02d9683057babc5f745836757e2cccbf3b7cf49c37ddfc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "allowedMergeMethods", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="dismissStaleReviewsOnPush")
    def dismiss_stale_reviews_on_push(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "dismissStaleReviewsOnPush"))

    @dismiss_stale_reviews_on_push.setter
    def dismiss_stale_reviews_on_push(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e4836b12e056740c4debd26ce0b98b2be2788c6d583a35d5c87ccaf88414531b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "dismissStaleReviewsOnPush", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requireCodeOwnerReview")
    def require_code_owner_review(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "requireCodeOwnerReview"))

    @require_code_owner_review.setter
    def require_code_owner_review(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b7cd89acde219f1c04bf3d3412ec47edaa14afae8cb10655eb64ef33c17074f4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requireCodeOwnerReview", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requiredApprovingReviewCount")
    def required_approving_review_count(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "requiredApprovingReviewCount"))

    @required_approving_review_count.setter
    def required_approving_review_count(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eeab95b95f0b5f9d423b3d2b6e110f882a01c119299e4b05830715470cf24c04)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requiredApprovingReviewCount", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requiredReviewThreadResolution")
    def required_review_thread_resolution(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "requiredReviewThreadResolution"))

    @required_review_thread_resolution.setter
    def required_review_thread_resolution(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb9627c5a5e385ca7345bc82d377d9b9c46c24ec0a4fdf06ccaebf506bc60b60)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requiredReviewThreadResolution", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requireLastPushApproval")
    def require_last_push_approval(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "requireLastPushApproval"))

    @require_last_push_approval.setter
    def require_last_push_approval(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__957ef8434b645d24519703d073f0931b3106aeed930f7fceda81f1a7d0e5f98d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requireLastPushApproval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional["OrganizationRulesetRulesPullRequest"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesPullRequest"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesPullRequest"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ae0688d7b3de8faa0e849ab2e7573785f91a70a6064379801b8c8fb3bf5cce8a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesPullRequestRequiredReviewers",
    jsii_struct_bases=[],
    name_mapping={
        "file_patterns": "filePatterns",
        "minimum_approvals": "minimumApprovals",
        "reviewer": "reviewer",
    },
)
class OrganizationRulesetRulesPullRequestRequiredReviewers:
    def __init__(
        self,
        *,
        file_patterns: typing.Sequence[builtins.str],
        minimum_approvals: jsii.Number,
        reviewer: typing.Union["OrganizationRulesetRulesPullRequestRequiredReviewersReviewer", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''
        :param file_patterns: File patterns (fnmatch syntax) that this reviewer must approve. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#file_patterns OrganizationRuleset#file_patterns}
        :param minimum_approvals: Minimum number of approvals required from this reviewer. Set to 0 to make approval optional. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#minimum_approvals OrganizationRuleset#minimum_approvals}
        :param reviewer: reviewer block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#reviewer OrganizationRuleset#reviewer}
        '''
        if isinstance(reviewer, dict):
            reviewer = OrganizationRulesetRulesPullRequestRequiredReviewersReviewer(**reviewer)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40ae167024ee7fd0cfc89b3b2cde7b6b29438f6a1d3694145c95c2323211a5b3)
            check_type(argname="argument file_patterns", value=file_patterns, expected_type=type_hints["file_patterns"])
            check_type(argname="argument minimum_approvals", value=minimum_approvals, expected_type=type_hints["minimum_approvals"])
            check_type(argname="argument reviewer", value=reviewer, expected_type=type_hints["reviewer"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "file_patterns": file_patterns,
            "minimum_approvals": minimum_approvals,
            "reviewer": reviewer,
        }

    @builtins.property
    def file_patterns(self) -> typing.List[builtins.str]:
        '''File patterns (fnmatch syntax) that this reviewer must approve.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#file_patterns OrganizationRuleset#file_patterns}
        '''
        result = self._values.get("file_patterns")
        assert result is not None, "Required property 'file_patterns' is missing"
        return typing.cast(typing.List[builtins.str], result)

    @builtins.property
    def minimum_approvals(self) -> jsii.Number:
        '''Minimum number of approvals required from this reviewer. Set to 0 to make approval optional.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#minimum_approvals OrganizationRuleset#minimum_approvals}
        '''
        result = self._values.get("minimum_approvals")
        assert result is not None, "Required property 'minimum_approvals' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def reviewer(
        self,
    ) -> "OrganizationRulesetRulesPullRequestRequiredReviewersReviewer":
        '''reviewer block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#reviewer OrganizationRuleset#reviewer}
        '''
        result = self._values.get("reviewer")
        assert result is not None, "Required property 'reviewer' is missing"
        return typing.cast("OrganizationRulesetRulesPullRequestRequiredReviewersReviewer", result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesPullRequestRequiredReviewers(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesPullRequestRequiredReviewersList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesPullRequestRequiredReviewersList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2a38dc41246073e243c726b2c6fbb4b187a2d5704ec9919041c8f727c97197a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "OrganizationRulesetRulesPullRequestRequiredReviewersOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d31b4a265370878a514b054f6d46e61bbf2a061cf6b4482f584df440bb020695)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("OrganizationRulesetRulesPullRequestRequiredReviewersOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesPullRequestRequiredReviewers"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesPullRequestRequiredReviewers"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesPullRequestRequiredReviewers"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__920a4ea473f24de6cc80fa40b47eb70602a5a93d9496215e99090981ec975e28)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class OrganizationRulesetRulesPullRequestRequiredReviewersOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesPullRequestRequiredReviewersOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__42e769031aaf27aea612442299a487e120bf1dfcbb1262999b68385fb9430c8b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putReviewer")
    def put_reviewer(self, *, id: jsii.Number, type: builtins.str) -> None:
        '''
        :param id: The ID of the reviewer that must review. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#id OrganizationRuleset#id} Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param type: The type of reviewer. Currently only ``Team`` is supported. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#type OrganizationRuleset#type}
        '''
        value = OrganizationRulesetRulesPullRequestRequiredReviewersReviewer(
            id=id, type=type
        )

        return typing.cast(None, jsii.invoke(self, "putReviewer", [value]))

    @builtins.property
    @jsii.member(jsii_name="reviewer")
    def reviewer(
        self,
    ) -> "OrganizationRulesetRulesPullRequestRequiredReviewersReviewerOutputReference":
        return typing.cast("OrganizationRulesetRulesPullRequestRequiredReviewersReviewerOutputReference", jsii.get(self, "reviewer"))

    @builtins.property
    @jsii.member(jsii_name="filePatternsInput")
    def file_patterns_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "filePatternsInput"))

    @builtins.property
    @jsii.member(jsii_name="minimumApprovalsInput")
    def minimum_approvals_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "minimumApprovalsInput"))

    @builtins.property
    @jsii.member(jsii_name="reviewerInput")
    def reviewer_input(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesPullRequestRequiredReviewersReviewer"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesPullRequestRequiredReviewersReviewer"], jsii.get(self, "reviewerInput"))

    @builtins.property
    @jsii.member(jsii_name="filePatterns")
    def file_patterns(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "filePatterns"))

    @file_patterns.setter
    def file_patterns(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__defbc5f7327ee3a0af41c41558cabc2aa315c29e0ca99ea0ad741897aa954f5b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "filePatterns", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="minimumApprovals")
    def minimum_approvals(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "minimumApprovals"))

    @minimum_approvals.setter
    def minimum_approvals(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__81e56eab18ae6c39430ff0d23c079ffd564f52e1587a240c2e5491357c73c113)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "minimumApprovals", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesPullRequestRequiredReviewers"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesPullRequestRequiredReviewers"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesPullRequestRequiredReviewers"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7744d5f7ae7811b62e3942a6e2127acaf1469829b3ec942ab139f3578129aeee)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesPullRequestRequiredReviewersReviewer",
    jsii_struct_bases=[],
    name_mapping={"id": "id", "type": "type"},
)
class OrganizationRulesetRulesPullRequestRequiredReviewersReviewer:
    def __init__(self, *, id: jsii.Number, type: builtins.str) -> None:
        '''
        :param id: The ID of the reviewer that must review. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#id OrganizationRuleset#id} Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param type: The type of reviewer. Currently only ``Team`` is supported. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#type OrganizationRuleset#type}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7737a089efd903270a9c9aa48b2928dd6b673bbd3ab58196e2d712a38cd789d5)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "id": id,
            "type": type,
        }

    @builtins.property
    def id(self) -> jsii.Number:
        '''The ID of the reviewer that must review.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#id OrganizationRuleset#id}

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        assert result is not None, "Required property 'id' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def type(self) -> builtins.str:
        '''The type of reviewer. Currently only ``Team`` is supported.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#type OrganizationRuleset#type}
        '''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesPullRequestRequiredReviewersReviewer(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesPullRequestRequiredReviewersReviewerOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesPullRequestRequiredReviewersReviewerOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a3595450c662d2f598564fe1def81ced90a42ad3f132a86a2d233cc4e72e363)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "id"))

    @id.setter
    def id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cc7b4baced192a4f9c295942da038422cc89d9f1344d56c2fc2a0c4474f30bf0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__acddca447d484d69c5b4503371617a0aeaf3259bd8c7ce9ce12c5efa0bc659d7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesPullRequestRequiredReviewersReviewer"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesPullRequestRequiredReviewersReviewer"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesPullRequestRequiredReviewersReviewer"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0448be93aea69cf121e3d74e859a3e682aea7b4d423d976c832393048458efcf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredCodeScanning",
    jsii_struct_bases=[],
    name_mapping={"required_code_scanning_tool": "requiredCodeScanningTool"},
)
class OrganizationRulesetRulesRequiredCodeScanning:
    def __init__(
        self,
        *,
        required_code_scanning_tool: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param required_code_scanning_tool: required_code_scanning_tool block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_code_scanning_tool OrganizationRuleset#required_code_scanning_tool}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1ef7bf67210a1fe34f9da8a4548ab4b9bef72c251e00d9d809d6e6bbf0aaa0d0)
            check_type(argname="argument required_code_scanning_tool", value=required_code_scanning_tool, expected_type=type_hints["required_code_scanning_tool"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "required_code_scanning_tool": required_code_scanning_tool,
        }

    @builtins.property
    def required_code_scanning_tool(
        self,
    ) -> typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]:
        '''required_code_scanning_tool block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_code_scanning_tool OrganizationRuleset#required_code_scanning_tool}
        '''
        result = self._values.get("required_code_scanning_tool")
        assert result is not None, "Required property 'required_code_scanning_tool' is missing"
        return typing.cast(typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesRequiredCodeScanning(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesRequiredCodeScanningOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredCodeScanningOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__72770e2661e39eaf269cd7f3568feb2d7f37f16d6fb0c1d3b77ca371350fe417)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRequiredCodeScanningTool")
    def put_required_code_scanning_tool(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__73ca602d935f01b9de2f25dd325444c2463628a748ab0d75b1bea33a414be2f8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putRequiredCodeScanningTool", [value]))

    @builtins.property
    @jsii.member(jsii_name="requiredCodeScanningTool")
    def required_code_scanning_tool(
        self,
    ) -> "OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningToolList":
        return typing.cast("OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningToolList", jsii.get(self, "requiredCodeScanningTool"))

    @builtins.property
    @jsii.member(jsii_name="requiredCodeScanningToolInput")
    def required_code_scanning_tool_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]], jsii.get(self, "requiredCodeScanningToolInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesRequiredCodeScanning"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesRequiredCodeScanning"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesRequiredCodeScanning"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__41ce9b8bc5a33e4906558edc4d2379f4a90a1aad94a927602723b29f53966381)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool",
    jsii_struct_bases=[],
    name_mapping={
        "alerts_threshold": "alertsThreshold",
        "security_alerts_threshold": "securityAlertsThreshold",
        "tool": "tool",
    },
)
class OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool:
    def __init__(
        self,
        *,
        alerts_threshold: builtins.str,
        security_alerts_threshold: builtins.str,
        tool: builtins.str,
    ) -> None:
        '''
        :param alerts_threshold: The severity level at which code scanning results that raise alerts block a reference update. Can be one of: ``none``, ``errors``, ``errors_and_warnings``, ``all``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#alerts_threshold OrganizationRuleset#alerts_threshold}
        :param security_alerts_threshold: The severity level at which code scanning results that raise security alerts block a reference update. Can be one of: ``none``, ``critical``, ``high_or_higher``, ``medium_or_higher``, ``all``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#security_alerts_threshold OrganizationRuleset#security_alerts_threshold}
        :param tool: The name of a code scanning tool. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#tool OrganizationRuleset#tool}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8c286283a242a54a2c13cb89317c332336ea8a6a6d05fe5edd68bbd2c24b79af)
            check_type(argname="argument alerts_threshold", value=alerts_threshold, expected_type=type_hints["alerts_threshold"])
            check_type(argname="argument security_alerts_threshold", value=security_alerts_threshold, expected_type=type_hints["security_alerts_threshold"])
            check_type(argname="argument tool", value=tool, expected_type=type_hints["tool"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "alerts_threshold": alerts_threshold,
            "security_alerts_threshold": security_alerts_threshold,
            "tool": tool,
        }

    @builtins.property
    def alerts_threshold(self) -> builtins.str:
        '''The severity level at which code scanning results that raise alerts block a reference update.

        Can be one of: ``none``, ``errors``, ``errors_and_warnings``, ``all``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#alerts_threshold OrganizationRuleset#alerts_threshold}
        '''
        result = self._values.get("alerts_threshold")
        assert result is not None, "Required property 'alerts_threshold' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def security_alerts_threshold(self) -> builtins.str:
        '''The severity level at which code scanning results that raise security alerts block a reference update.

        Can be one of: ``none``, ``critical``, ``high_or_higher``, ``medium_or_higher``, ``all``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#security_alerts_threshold OrganizationRuleset#security_alerts_threshold}
        '''
        result = self._values.get("security_alerts_threshold")
        assert result is not None, "Required property 'security_alerts_threshold' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def tool(self) -> builtins.str:
        '''The name of a code scanning tool.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#tool OrganizationRuleset#tool}
        '''
        result = self._values.get("tool")
        assert result is not None, "Required property 'tool' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningToolList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningToolList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1dcafadda36fd9a50de4005d9d5529b7dac17e19164e79d50de74d195dfddd3a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningToolOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b907b1d6f2ad546d74df849d5fe6ae0ba6f5b3359b715dbb093a74af9af4e9a7)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningToolOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__32f8d7c04b2791d5eba078b2f372283df26d5f6e71f8debbfec6c370d3797f87)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningToolOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningToolOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c0cfb9891de428839ad39992dff2eca9fa1a81d7c2889d8ed1d0ac1fdf5b50de)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="alertsThresholdInput")
    def alerts_threshold_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "alertsThresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="securityAlertsThresholdInput")
    def security_alerts_threshold_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "securityAlertsThresholdInput"))

    @builtins.property
    @jsii.member(jsii_name="toolInput")
    def tool_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "toolInput"))

    @builtins.property
    @jsii.member(jsii_name="alertsThreshold")
    def alerts_threshold(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "alertsThreshold"))

    @alerts_threshold.setter
    def alerts_threshold(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7cd93e4ab42195513609350d37d4ee023bf846f4b802a01a0b3b43bf5279264a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "alertsThreshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="securityAlertsThreshold")
    def security_alerts_threshold(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "securityAlertsThreshold"))

    @security_alerts_threshold.setter
    def security_alerts_threshold(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55326cd3a9b28c21417feab7eb386f95df05ecd9107516154e3599c6d7f171e6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "securityAlertsThreshold", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tool")
    def tool(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tool"))

    @tool.setter
    def tool(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3bc4dfb0be91d1e2579d724bee90c92463ccdd1cb5f2c09feba8bc46d60a5ac)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tool", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b96743972d5b4efd3e5ba29651e73fe04bc091ce440f3834fac23ad28c05a26)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredStatusChecks",
    jsii_struct_bases=[],
    name_mapping={
        "required_check": "requiredCheck",
        "do_not_enforce_on_create": "doNotEnforceOnCreate",
        "strict_required_status_checks_policy": "strictRequiredStatusChecksPolicy",
    },
)
class OrganizationRulesetRulesRequiredStatusChecks:
    def __init__(
        self,
        *,
        required_check: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesRequiredStatusChecksRequiredCheck", typing.Dict[builtins.str, typing.Any]]]],
        do_not_enforce_on_create: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
        strict_required_status_checks_policy: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param required_check: required_check block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_check OrganizationRuleset#required_check}
        :param do_not_enforce_on_create: Allow repositories and branches to be created if a check would otherwise prohibit it. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#do_not_enforce_on_create OrganizationRuleset#do_not_enforce_on_create}
        :param strict_required_status_checks_policy: Whether pull requests targeting a matching branch must be tested with the latest code. This setting will not take effect unless at least one status check is enabled. Defaults to ``false``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#strict_required_status_checks_policy OrganizationRuleset#strict_required_status_checks_policy}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d7d47fd301cf2d3b010d07ffc573cafbf8118632557cead1a5f7d2a9472fdab5)
            check_type(argname="argument required_check", value=required_check, expected_type=type_hints["required_check"])
            check_type(argname="argument do_not_enforce_on_create", value=do_not_enforce_on_create, expected_type=type_hints["do_not_enforce_on_create"])
            check_type(argname="argument strict_required_status_checks_policy", value=strict_required_status_checks_policy, expected_type=type_hints["strict_required_status_checks_policy"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "required_check": required_check,
        }
        if do_not_enforce_on_create is not None:
            self._values["do_not_enforce_on_create"] = do_not_enforce_on_create
        if strict_required_status_checks_policy is not None:
            self._values["strict_required_status_checks_policy"] = strict_required_status_checks_policy

    @builtins.property
    def required_check(
        self,
    ) -> typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredStatusChecksRequiredCheck"]]:
        '''required_check block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_check OrganizationRuleset#required_check}
        '''
        result = self._values.get("required_check")
        assert result is not None, "Required property 'required_check' is missing"
        return typing.cast(typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredStatusChecksRequiredCheck"]], result)

    @builtins.property
    def do_not_enforce_on_create(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Allow repositories and branches to be created if a check would otherwise prohibit it.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#do_not_enforce_on_create OrganizationRuleset#do_not_enforce_on_create}
        '''
        result = self._values.get("do_not_enforce_on_create")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    @builtins.property
    def strict_required_status_checks_policy(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Whether pull requests targeting a matching branch must be tested with the latest code.

        This setting will not take effect unless at least one status check is enabled. Defaults to ``false``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#strict_required_status_checks_policy OrganizationRuleset#strict_required_status_checks_policy}
        '''
        result = self._values.get("strict_required_status_checks_policy")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesRequiredStatusChecks(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesRequiredStatusChecksOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredStatusChecksOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e621d843321eb673ad88c1b43d43f93a7ba517e29b9fca13ed981b5182f9203d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRequiredCheck")
    def put_required_check(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesRequiredStatusChecksRequiredCheck", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__67aef54a829c6140b99c58785f5ebbb1113f43880aabc4b0dd168a3d8ff6f855)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putRequiredCheck", [value]))

    @jsii.member(jsii_name="resetDoNotEnforceOnCreate")
    def reset_do_not_enforce_on_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDoNotEnforceOnCreate", []))

    @jsii.member(jsii_name="resetStrictRequiredStatusChecksPolicy")
    def reset_strict_required_status_checks_policy(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStrictRequiredStatusChecksPolicy", []))

    @builtins.property
    @jsii.member(jsii_name="requiredCheck")
    def required_check(
        self,
    ) -> "OrganizationRulesetRulesRequiredStatusChecksRequiredCheckList":
        return typing.cast("OrganizationRulesetRulesRequiredStatusChecksRequiredCheckList", jsii.get(self, "requiredCheck"))

    @builtins.property
    @jsii.member(jsii_name="doNotEnforceOnCreateInput")
    def do_not_enforce_on_create_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "doNotEnforceOnCreateInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredCheckInput")
    def required_check_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredStatusChecksRequiredCheck"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredStatusChecksRequiredCheck"]]], jsii.get(self, "requiredCheckInput"))

    @builtins.property
    @jsii.member(jsii_name="strictRequiredStatusChecksPolicyInput")
    def strict_required_status_checks_policy_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "strictRequiredStatusChecksPolicyInput"))

    @builtins.property
    @jsii.member(jsii_name="doNotEnforceOnCreate")
    def do_not_enforce_on_create(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "doNotEnforceOnCreate"))

    @do_not_enforce_on_create.setter
    def do_not_enforce_on_create(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__59f00176a4637601dabf2c8bfe3264d63f8704a41854545148c182fcbd11b33a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "doNotEnforceOnCreate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="strictRequiredStatusChecksPolicy")
    def strict_required_status_checks_policy(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "strictRequiredStatusChecksPolicy"))

    @strict_required_status_checks_policy.setter
    def strict_required_status_checks_policy(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__04b8a76fddfbc9ae3804136b7750aefb05cdef05a99b10fb69005bc07d514109)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "strictRequiredStatusChecksPolicy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesRequiredStatusChecks"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesRequiredStatusChecks"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesRequiredStatusChecks"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6e75b11cd8422c0be105c11a2db970175c18a77f079af9485b3e74857263ac40)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredStatusChecksRequiredCheck",
    jsii_struct_bases=[],
    name_mapping={"context": "context", "integration_id": "integrationId"},
)
class OrganizationRulesetRulesRequiredStatusChecksRequiredCheck:
    def __init__(
        self,
        *,
        context: builtins.str,
        integration_id: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param context: The status check context name that must be present on the commit. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#context OrganizationRuleset#context}
        :param integration_id: The optional integration ID that this status check must originate from. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#integration_id OrganizationRuleset#integration_id}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f9dd4cc971105484e2e66f19b157af578e761f0ee18b11e93c6e3ba590b21c1)
            check_type(argname="argument context", value=context, expected_type=type_hints["context"])
            check_type(argname="argument integration_id", value=integration_id, expected_type=type_hints["integration_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "context": context,
        }
        if integration_id is not None:
            self._values["integration_id"] = integration_id

    @builtins.property
    def context(self) -> builtins.str:
        '''The status check context name that must be present on the commit.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#context OrganizationRuleset#context}
        '''
        result = self._values.get("context")
        assert result is not None, "Required property 'context' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def integration_id(self) -> typing.Optional[jsii.Number]:
        '''The optional integration ID that this status check must originate from.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#integration_id OrganizationRuleset#integration_id}
        '''
        result = self._values.get("integration_id")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesRequiredStatusChecksRequiredCheck(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesRequiredStatusChecksRequiredCheckList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredStatusChecksRequiredCheckList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__913e68dc6e8839933b976d86785902c54e7d1d8cc08950283b0cdd6be766e7d3)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "OrganizationRulesetRulesRequiredStatusChecksRequiredCheckOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__43836b2f02dbbb74b4610446f90307915aab556f3031f969e07e02a6c80ccac6)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("OrganizationRulesetRulesRequiredStatusChecksRequiredCheckOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredStatusChecksRequiredCheck"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredStatusChecksRequiredCheck"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredStatusChecksRequiredCheck"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fac404d6580082ed49cde974f49f51878d6a23b7a23f3f54303100b7c5b39ce2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class OrganizationRulesetRulesRequiredStatusChecksRequiredCheckOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredStatusChecksRequiredCheckOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3035ed03a7051211fe81480d6c090a4d40ff2441b237a04bce841d5b3a0b66a8)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetIntegrationId")
    def reset_integration_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetIntegrationId", []))

    @builtins.property
    @jsii.member(jsii_name="contextInput")
    def context_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "contextInput"))

    @builtins.property
    @jsii.member(jsii_name="integrationIdInput")
    def integration_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "integrationIdInput"))

    @builtins.property
    @jsii.member(jsii_name="context")
    def context(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "context"))

    @context.setter
    def context(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98b14df8e94f95d1cf97270f91ae944784bfd0322574087960a5bb20ac12db9c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "context", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="integrationId")
    def integration_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "integrationId"))

    @integration_id.setter
    def integration_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0515a4dc6bf8cc9352757285514e47bc0274e72619d44c1a2cda3d5e53be8254)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "integrationId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesRequiredStatusChecksRequiredCheck"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesRequiredStatusChecksRequiredCheck"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesRequiredStatusChecksRequiredCheck"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ac87517ca26715b4e17956e099fb867de119073fc51ef25d41f981015b65a9ed)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredWorkflows",
    jsii_struct_bases=[],
    name_mapping={
        "required_workflow": "requiredWorkflow",
        "do_not_enforce_on_create": "doNotEnforceOnCreate",
    },
)
class OrganizationRulesetRulesRequiredWorkflows:
    def __init__(
        self,
        *,
        required_workflow: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow", typing.Dict[builtins.str, typing.Any]]]],
        do_not_enforce_on_create: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param required_workflow: required_workflow block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_workflow OrganizationRuleset#required_workflow}
        :param do_not_enforce_on_create: Allow repositories and branches to be created if a check would otherwise prohibit it. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#do_not_enforce_on_create OrganizationRuleset#do_not_enforce_on_create}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__384954b5fb29b6ee47dc93cef70901011f761a4117d04efbb5950cd236518cd2)
            check_type(argname="argument required_workflow", value=required_workflow, expected_type=type_hints["required_workflow"])
            check_type(argname="argument do_not_enforce_on_create", value=do_not_enforce_on_create, expected_type=type_hints["do_not_enforce_on_create"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "required_workflow": required_workflow,
        }
        if do_not_enforce_on_create is not None:
            self._values["do_not_enforce_on_create"] = do_not_enforce_on_create

    @builtins.property
    def required_workflow(
        self,
    ) -> typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow"]]:
        '''required_workflow block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#required_workflow OrganizationRuleset#required_workflow}
        '''
        result = self._values.get("required_workflow")
        assert result is not None, "Required property 'required_workflow' is missing"
        return typing.cast(typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow"]], result)

    @builtins.property
    def do_not_enforce_on_create(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''Allow repositories and branches to be created if a check would otherwise prohibit it.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#do_not_enforce_on_create OrganizationRuleset#do_not_enforce_on_create}
        '''
        result = self._values.get("do_not_enforce_on_create")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesRequiredWorkflows(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesRequiredWorkflowsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredWorkflowsOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1a572f113449b508ee1de340525b63a65bd60e46d76cc77eca1ebd7f1fc0c996)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRequiredWorkflow")
    def put_required_workflow(
        self,
        value: typing.Union["_cdktn_78ede62e.IResolvable", typing.Sequence[typing.Union["OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__82c2a23b5444f0776fa68e9b7f680df654dd90781748791086b58a617643eb4c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putRequiredWorkflow", [value]))

    @jsii.member(jsii_name="resetDoNotEnforceOnCreate")
    def reset_do_not_enforce_on_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDoNotEnforceOnCreate", []))

    @builtins.property
    @jsii.member(jsii_name="requiredWorkflow")
    def required_workflow(
        self,
    ) -> "OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflowList":
        return typing.cast("OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflowList", jsii.get(self, "requiredWorkflow"))

    @builtins.property
    @jsii.member(jsii_name="doNotEnforceOnCreateInput")
    def do_not_enforce_on_create_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "doNotEnforceOnCreateInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredWorkflowInput")
    def required_workflow_input(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow"]]], jsii.get(self, "requiredWorkflowInput"))

    @builtins.property
    @jsii.member(jsii_name="doNotEnforceOnCreate")
    def do_not_enforce_on_create(
        self,
    ) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "doNotEnforceOnCreate"))

    @do_not_enforce_on_create.setter
    def do_not_enforce_on_create(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d33b81e8fea10fe35d601b19f259af3876fdadf0aeb633d3ecb2dfadd9aa4b5d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "doNotEnforceOnCreate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesRequiredWorkflows"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesRequiredWorkflows"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesRequiredWorkflows"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c45e55af2977c02a8b2c18d8ceedef8532b1ca52eddebb9b66c05839d3e6f7d2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow",
    jsii_struct_bases=[],
    name_mapping={"path": "path", "repository_id": "repositoryId", "ref": "ref"},
)
class OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow:
    def __init__(
        self,
        *,
        path: builtins.str,
        repository_id: jsii.Number,
        ref: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param path: The path to the workflow YAML definition file. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#path OrganizationRuleset#path}
        :param repository_id: The repository in which the workflow is defined. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#repository_id OrganizationRuleset#repository_id}
        :param ref: The ref (branch or tag) of the workflow file to use. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#ref OrganizationRuleset#ref}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7176f887a6d44a0b8bba0e5f5db35665f5ff298ec1ff8f63ac0df3b1de411bc5)
            check_type(argname="argument path", value=path, expected_type=type_hints["path"])
            check_type(argname="argument repository_id", value=repository_id, expected_type=type_hints["repository_id"])
            check_type(argname="argument ref", value=ref, expected_type=type_hints["ref"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "path": path,
            "repository_id": repository_id,
        }
        if ref is not None:
            self._values["ref"] = ref

    @builtins.property
    def path(self) -> builtins.str:
        '''The path to the workflow YAML definition file.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#path OrganizationRuleset#path}
        '''
        result = self._values.get("path")
        assert result is not None, "Required property 'path' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def repository_id(self) -> jsii.Number:
        '''The repository in which the workflow is defined.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#repository_id OrganizationRuleset#repository_id}
        '''
        result = self._values.get("repository_id")
        assert result is not None, "Required property 'repository_id' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def ref(self) -> typing.Optional[builtins.str]:
        '''The ref (branch or tag) of the workflow file to use.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#ref OrganizationRuleset#ref}
        '''
        result = self._values.get("ref")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflowList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflowList",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__53fac776f0a5e4699d2943ab56b055edf20d7937ce614e798ad3a7b7ce181c35)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflowOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e7d613ca12edd21f95a4e6d64e302a0e64ba572056994b0ca76d8b0e87347cd2)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflowOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow"]]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow"]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", typing.List["OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow"]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6662c3e3b18ff23c6e02eb87e26f81b40ce1241c4825bc0487ff513b0cac0771)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflowOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflowOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aba90df737c433d0333892f7fc678dc4efe409347e280a05bdfbbe21b54cff9e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetRef")
    def reset_ref(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRef", []))

    @builtins.property
    @jsii.member(jsii_name="pathInput")
    def path_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "pathInput"))

    @builtins.property
    @jsii.member(jsii_name="refInput")
    def ref_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "refInput"))

    @builtins.property
    @jsii.member(jsii_name="repositoryIdInput")
    def repository_id_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "repositoryIdInput"))

    @builtins.property
    @jsii.member(jsii_name="path")
    def path(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "path"))

    @path.setter
    def path(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__65d572768852ceb61251fdfd6140298841ba4a441cc3fd451994c7ee7329d54c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "path", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="ref")
    def ref(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "ref"))

    @ref.setter
    def ref(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b02c3de43747ea83c64b129e5077511c1e44c3a7d4a949618aef6d1c9238d61e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "ref", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="repositoryId")
    def repository_id(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "repositoryId"))

    @repository_id.setter
    def repository_id(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0fee2246899db7bd99a5c5ad7e017ea4d1706008cb74313d3700a7ee66bc77b0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "repositoryId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow"]]:
        return typing.cast(typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow"]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union["_cdktn_78ede62e.IResolvable", "OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow"]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b778a900aac3233634f426f547fa8ff7eccfbbe4b6462b1cc3175bdbd7cba88e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesTagNamePattern",
    jsii_struct_bases=[],
    name_mapping={
        "operator": "operator",
        "pattern": "pattern",
        "name": "name",
        "negate": "negate",
    },
)
class OrganizationRulesetRulesTagNamePattern:
    def __init__(
        self,
        *,
        operator: builtins.str,
        pattern: builtins.str,
        name: typing.Optional[builtins.str] = None,
        negate: typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]] = None,
    ) -> None:
        '''
        :param operator: The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        :param pattern: The pattern to match with. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        :param name: How this rule will appear to users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        :param negate: If true, the rule will fail if the pattern matches. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__30829f8fb279e06b63066a359601a4216b4a35fbb6a91cbb9432bfef97515b36)
            check_type(argname="argument operator", value=operator, expected_type=type_hints["operator"])
            check_type(argname="argument pattern", value=pattern, expected_type=type_hints["pattern"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument negate", value=negate, expected_type=type_hints["negate"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "operator": operator,
            "pattern": pattern,
        }
        if name is not None:
            self._values["name"] = name
        if negate is not None:
            self._values["negate"] = negate

    @builtins.property
    def operator(self) -> builtins.str:
        '''The operator to use for matching. Can be one of: ``starts_with``, ``ends_with``, ``contains``, ``regex``.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#operator OrganizationRuleset#operator}
        '''
        result = self._values.get("operator")
        assert result is not None, "Required property 'operator' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pattern(self) -> builtins.str:
        '''The pattern to match with.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#pattern OrganizationRuleset#pattern}
        '''
        result = self._values.get("pattern")
        assert result is not None, "Required property 'pattern' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''How this rule will appear to users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#name OrganizationRuleset#name}
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def negate(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        '''If true, the rule will fail if the pattern matches.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/integrations/github/6.12.1/docs/resources/organization_ruleset#negate OrganizationRuleset#negate}
        '''
        result = self._values.get("negate")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OrganizationRulesetRulesTagNamePattern(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OrganizationRulesetRulesTagNamePatternOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-github.organizationRuleset.OrganizationRulesetRulesTagNamePatternOutputReference",
):
    def __init__(
        self,
        terraform_resource: "_cdktn_78ede62e.IInterpolatingParent",
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2726e63c61a218dde0b22c48318805603bdc74e7df136b407c4e8cfbe41ac7a3)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @jsii.member(jsii_name="resetNegate")
    def reset_negate(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNegate", []))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="negateInput")
    def negate_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]], jsii.get(self, "negateInput"))

    @builtins.property
    @jsii.member(jsii_name="operatorInput")
    def operator_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "operatorInput"))

    @builtins.property
    @jsii.member(jsii_name="patternInput")
    def pattern_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "patternInput"))

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c90faa37cf687c2d6da568801d8a1836ed029d4ec68d0739fb8f306b14fb9ca3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="negate")
    def negate(self) -> typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"]:
        return typing.cast(typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"], jsii.get(self, "negate"))

    @negate.setter
    def negate(
        self,
        value: typing.Union[builtins.bool, "_cdktn_78ede62e.IResolvable"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eafdea6633a828ab437cd52ba116ba22582e0b2cb9410f660100494a976bdcef)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "negate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="operator")
    def operator(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "operator"))

    @operator.setter
    def operator(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e73fed8c29886591edb3813332883f81e9d7ab9802762ce33f727ee3e394d833)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "operator", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="pattern")
    def pattern(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "pattern"))

    @pattern.setter
    def pattern(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4c071dbfec35238ea4ccaeb317c86a8854bfa9da7251138a40387f7298feec88)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "pattern", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional["OrganizationRulesetRulesTagNamePattern"]:
        return typing.cast(typing.Optional["OrganizationRulesetRulesTagNamePattern"], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional["OrganizationRulesetRulesTagNamePattern"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__063850daaf55754a08de6057e0282da43d0e8629e1c0971221df55f839728799)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "OrganizationRuleset",
    "OrganizationRulesetBypassActors",
    "OrganizationRulesetBypassActorsList",
    "OrganizationRulesetBypassActorsOutputReference",
    "OrganizationRulesetConditions",
    "OrganizationRulesetConditionsOutputReference",
    "OrganizationRulesetConditionsRefName",
    "OrganizationRulesetConditionsRefNameOutputReference",
    "OrganizationRulesetConditionsRepositoryName",
    "OrganizationRulesetConditionsRepositoryNameOutputReference",
    "OrganizationRulesetConditionsRepositoryProperty",
    "OrganizationRulesetConditionsRepositoryPropertyExclude",
    "OrganizationRulesetConditionsRepositoryPropertyExcludeList",
    "OrganizationRulesetConditionsRepositoryPropertyExcludeOutputReference",
    "OrganizationRulesetConditionsRepositoryPropertyInclude",
    "OrganizationRulesetConditionsRepositoryPropertyIncludeList",
    "OrganizationRulesetConditionsRepositoryPropertyIncludeOutputReference",
    "OrganizationRulesetConditionsRepositoryPropertyOutputReference",
    "OrganizationRulesetConfig",
    "OrganizationRulesetRules",
    "OrganizationRulesetRulesBranchNamePattern",
    "OrganizationRulesetRulesBranchNamePatternOutputReference",
    "OrganizationRulesetRulesCommitAuthorEmailPattern",
    "OrganizationRulesetRulesCommitAuthorEmailPatternOutputReference",
    "OrganizationRulesetRulesCommitMessagePattern",
    "OrganizationRulesetRulesCommitMessagePatternOutputReference",
    "OrganizationRulesetRulesCommitterEmailPattern",
    "OrganizationRulesetRulesCommitterEmailPatternOutputReference",
    "OrganizationRulesetRulesCopilotCodeReview",
    "OrganizationRulesetRulesCopilotCodeReviewOutputReference",
    "OrganizationRulesetRulesFileExtensionRestriction",
    "OrganizationRulesetRulesFileExtensionRestrictionOutputReference",
    "OrganizationRulesetRulesFilePathRestriction",
    "OrganizationRulesetRulesFilePathRestrictionOutputReference",
    "OrganizationRulesetRulesMaxFilePathLength",
    "OrganizationRulesetRulesMaxFilePathLengthOutputReference",
    "OrganizationRulesetRulesMaxFileSize",
    "OrganizationRulesetRulesMaxFileSizeOutputReference",
    "OrganizationRulesetRulesOutputReference",
    "OrganizationRulesetRulesPullRequest",
    "OrganizationRulesetRulesPullRequestOutputReference",
    "OrganizationRulesetRulesPullRequestRequiredReviewers",
    "OrganizationRulesetRulesPullRequestRequiredReviewersList",
    "OrganizationRulesetRulesPullRequestRequiredReviewersOutputReference",
    "OrganizationRulesetRulesPullRequestRequiredReviewersReviewer",
    "OrganizationRulesetRulesPullRequestRequiredReviewersReviewerOutputReference",
    "OrganizationRulesetRulesRequiredCodeScanning",
    "OrganizationRulesetRulesRequiredCodeScanningOutputReference",
    "OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool",
    "OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningToolList",
    "OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningToolOutputReference",
    "OrganizationRulesetRulesRequiredStatusChecks",
    "OrganizationRulesetRulesRequiredStatusChecksOutputReference",
    "OrganizationRulesetRulesRequiredStatusChecksRequiredCheck",
    "OrganizationRulesetRulesRequiredStatusChecksRequiredCheckList",
    "OrganizationRulesetRulesRequiredStatusChecksRequiredCheckOutputReference",
    "OrganizationRulesetRulesRequiredWorkflows",
    "OrganizationRulesetRulesRequiredWorkflowsOutputReference",
    "OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow",
    "OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflowList",
    "OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflowOutputReference",
    "OrganizationRulesetRulesTagNamePattern",
    "OrganizationRulesetRulesTagNamePatternOutputReference",
]

publication.publish()

def _typecheckingstub__96e7f700b9d7c72ceb60cd5853bd63ec7f8fd3812d35a25b7245cdd550f72ac8(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    enforcement: builtins.str,
    name: builtins.str,
    rules: typing.Union[OrganizationRulesetRules, typing.Dict[builtins.str, typing.Any]],
    target: builtins.str,
    bypass_actors: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetBypassActors, typing.Dict[builtins.str, typing.Any]]]]] = None,
    conditions: typing.Optional[typing.Union[OrganizationRulesetConditions, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5240e75b1e9f53673409e43d0c3e520e5ef9222608d889d1497086c2236d5148(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f474ee24571286138684f18b0dbae670008db026683b54885652df1cc83429a(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetBypassActors, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__88721be48d84c8a59d7a0894455606d0fecfdeedea29412ec73811fbc6629dcd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d593ed4c7a12afd3af856a74dd4e8c5a1877dcaba1815553e567a979be60e919(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__61b0bb1cd34a1ce45288114244e3f9854ad414d002657ed9594d843c61bdd229(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a3d43405598c6be2c4809785bf77fa883b7c499adc2a1a2bf873d81845e3ae9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__762166be1992f09799f12ff3497e8419954c774fea730dab91d13f9e19b624c9(
    *,
    actor_type: builtins.str,
    bypass_mode: builtins.str,
    actor_id: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ef6772cceef4a21960120c6304379f30b1d5d937eaa7f55f10c45d954c0fab4b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__868916ba979f5b8a61ecbe7e15adea685b81acd0a135fc2630269d8dc92564c5(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a084642b980c2a1e8b49733708104a6cdbaa171a754289f97561694d9287e51(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[OrganizationRulesetBypassActors]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ebf974c18a2b5511e7ac7e0db0d705878881675d9f9645df363c512179209572(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2649683cd7926d1a2495e9cad4d579f0d3af79238549a6023d012001fc3ab4d3(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d25305e2c20799b1822814bdd6c4264fccf24451f33f93d4ee5a9d4df55185bd(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__31ced0e64f6d89cc5602579a1899e880ac32c82b0ead3cfe257a824e93b366a0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5b26009e74c48c3670b1f975eab35c16b23a38f85f8f5cbf1024017bbaf787af(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, OrganizationRulesetBypassActors]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__26fb2908e0053999e52a1fa48e14b4d3a6c877d4aca288a96eca6533976e2b4e(
    *,
    ref_name: typing.Optional[typing.Union[OrganizationRulesetConditionsRefName, typing.Dict[builtins.str, typing.Any]]] = None,
    repository_id: typing.Optional[typing.Sequence[jsii.Number]] = None,
    repository_name: typing.Optional[typing.Union[OrganizationRulesetConditionsRepositoryName, typing.Dict[builtins.str, typing.Any]]] = None,
    repository_property: typing.Optional[typing.Union[OrganizationRulesetConditionsRepositoryProperty, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b830153020f728133c8c455a9cf8a499667509d53aa203c780db7fb7c6a1ee97(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2c78c87d072a62011f3dd1ec9750c94e435d3ee9c2faf1673a6da274d8f7a614(
    value: typing.List[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f974f6933c2162663a6dc2a45faaaeaa61d05910a8696426cfed399a975a1f2(
    value: typing.Optional[OrganizationRulesetConditions],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bea66b29c616e0bb2f5e8d6d88cc03e33af9f42a710ddf5279cedf64192797e8(
    *,
    exclude: typing.Sequence[builtins.str],
    include: typing.Sequence[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9df6c515c3cd4229ef2220e6d220f1234a33404ff26f305b86f1eff0d78e79ff(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__17014b19012331e144bc1b63463fe09a5155dcc44ead794d5b91975a58daf160(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9234565f31f3b9af198b6de106481c50fe46252b01e8369af25d612a0f8d7977(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b31987fb719153de5404b575e5ea0c7981afb9f10ddb7da0b2c290628c14212f(
    value: typing.Optional[OrganizationRulesetConditionsRefName],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__83b18d71cec1b2395d3744afb6a73feec0cce6cb6f17079c3a182a508f91cf67(
    *,
    exclude: typing.Sequence[builtins.str],
    include: typing.Sequence[builtins.str],
    protected: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__00807354d8a0002c9ae1c494a33c12e35c83d68593189161542f27ffb99a3bf9(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9757d26ba460e4539476330774ea48cec24b8329aacf3c9992027c8556406cef(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ad5f41bc4b39d825d2fc4e05d4cb7408e7baff3b6963e0cc35032a8e4a4e38a(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__111c98c50ad29bd8519a5ef13234c78324aa3be14475e7866398bfcc67e698e6(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__814ed1c53a2e806664ffb2dc9dbbdfbc0d8a78755eec8f44d8985f607669bf23(
    value: typing.Optional[OrganizationRulesetConditionsRepositoryName],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__613159194a911307856192559d57677a6fb47ea248f572dd5c244dec90abc104(
    *,
    exclude: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetConditionsRepositoryPropertyExclude, typing.Dict[builtins.str, typing.Any]]]]] = None,
    include: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetConditionsRepositoryPropertyInclude, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__251d5deced46cfa874c0b4518dbe085afaaac4e76f3143dccba034e33f816ac3(
    *,
    name: typing.Optional[builtins.str] = None,
    property_values: typing.Optional[typing.Sequence[builtins.str]] = None,
    source: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a24904188f6bb786e00f14623cc539a67567b90de4bf35eb574fa165ad11289(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5558f4fe0e649fb6ddb98da35c3a88212ba8c8e33e05821c82fdb54d0a3129fd(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7bfd32f6b558348b08abc15436f48a9ffaf5d85c45d887a90c50c2cb37c135ef(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[OrganizationRulesetConditionsRepositoryPropertyExclude]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a1b96453c33df0cda91d4739fbcf6524c371cf0f9b91bf958a1e78dc6fc9c6ed(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1df5e2b6d76b4c079b8c3c824c17342503a6f8ffb26b8882393cd05445d2c801(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b45532213ef28305cd7712bca4ced7edc24717c7ef5e9a404c1e9c4fa2d5a785(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aeeedcccd4cfc19c54a7f5b7918b7ac7e50c84c9b317399b585585ee4654243b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ad2d030db779c43d7da75dccb91b7e1081eafe737daf84fd1ec45cf3e3a7e6a6(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, OrganizationRulesetConditionsRepositoryPropertyExclude]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__137c789e3033a00708ffef5f131c6b3c56bc9b63c53b1e329249ba56a15035ff(
    *,
    name: typing.Optional[builtins.str] = None,
    property_values: typing.Optional[typing.Sequence[builtins.str]] = None,
    source: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c8a089a944a84e29cabf6267e0ed3097974c46b7fc5f146ab0c2fde99325a743(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__72ab6670d9916a611cf9e1c7d63cc617a465d03b296b4ac71b38f13404ad429a(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a063834b66fe7ee988bbfb0c3fdd5f65a215da40194fad9e610e64ea20e0184f(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[OrganizationRulesetConditionsRepositoryPropertyInclude]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__64920a0d9194394c65b5ee2208fd708a436ca060207e881943c8b3f988a50bfc(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2d8837905ffd2fae65116591cb7e4fd3e0361f91a7820a4800d6724fbe530f9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7dcaaf9473d2194d26451959770056c2fa392a1de7df4eb8a8f19ebfe27e703f(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__de2eb260e900a14f7c9ea74b44df9ce9dc3392ddd2924c7d41be460a8cd90b98(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f128b529a5a51e1d9f242c5b4e14ab1ed10fa0a39fde9d77fff021a825d6e92e(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, OrganizationRulesetConditionsRepositoryPropertyInclude]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__53c75d7772c24599f2cc950443c3fdefbfcc66699ace0e5e00d171263e06f2b1(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__949601f1ef531b3984c64a7c9767e4c9ce48f4415cf10ec907f7572ac162c56d(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetConditionsRepositoryPropertyExclude, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e4309ed74cb15a62e15a2e0261017979d5419cef3c9860726b5d875f5c2086d(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetConditionsRepositoryPropertyInclude, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__df59c8e4eaf7f269aad2e8a1cdebf293ceccc7ce281cbc5b859e23aeca15d0a6(
    value: typing.Optional[OrganizationRulesetConditionsRepositoryProperty],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__65ad096a2579bee3fca1f1f0435b96fb63d2032ce04a18476bbe2a2926e8c456(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    enforcement: builtins.str,
    name: builtins.str,
    rules: typing.Union[OrganizationRulesetRules, typing.Dict[builtins.str, typing.Any]],
    target: builtins.str,
    bypass_actors: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetBypassActors, typing.Dict[builtins.str, typing.Any]]]]] = None,
    conditions: typing.Optional[typing.Union[OrganizationRulesetConditions, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b5602e6c69d9e545621030d56c7a562870baae4a18fe589299b72055c3b22b2f(
    *,
    branch_name_pattern: typing.Optional[typing.Union[OrganizationRulesetRulesBranchNamePattern, typing.Dict[builtins.str, typing.Any]]] = None,
    commit_author_email_pattern: typing.Optional[typing.Union[OrganizationRulesetRulesCommitAuthorEmailPattern, typing.Dict[builtins.str, typing.Any]]] = None,
    commit_message_pattern: typing.Optional[typing.Union[OrganizationRulesetRulesCommitMessagePattern, typing.Dict[builtins.str, typing.Any]]] = None,
    committer_email_pattern: typing.Optional[typing.Union[OrganizationRulesetRulesCommitterEmailPattern, typing.Dict[builtins.str, typing.Any]]] = None,
    copilot_code_review: typing.Optional[typing.Union[OrganizationRulesetRulesCopilotCodeReview, typing.Dict[builtins.str, typing.Any]]] = None,
    creation: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    deletion: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    file_extension_restriction: typing.Optional[typing.Union[OrganizationRulesetRulesFileExtensionRestriction, typing.Dict[builtins.str, typing.Any]]] = None,
    file_path_restriction: typing.Optional[typing.Union[OrganizationRulesetRulesFilePathRestriction, typing.Dict[builtins.str, typing.Any]]] = None,
    max_file_path_length: typing.Optional[typing.Union[OrganizationRulesetRulesMaxFilePathLength, typing.Dict[builtins.str, typing.Any]]] = None,
    max_file_size: typing.Optional[typing.Union[OrganizationRulesetRulesMaxFileSize, typing.Dict[builtins.str, typing.Any]]] = None,
    non_fast_forward: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    pull_request: typing.Optional[typing.Union[OrganizationRulesetRulesPullRequest, typing.Dict[builtins.str, typing.Any]]] = None,
    required_code_scanning: typing.Optional[typing.Union[OrganizationRulesetRulesRequiredCodeScanning, typing.Dict[builtins.str, typing.Any]]] = None,
    required_linear_history: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    required_signatures: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    required_status_checks: typing.Optional[typing.Union[OrganizationRulesetRulesRequiredStatusChecks, typing.Dict[builtins.str, typing.Any]]] = None,
    required_workflows: typing.Optional[typing.Union[OrganizationRulesetRulesRequiredWorkflows, typing.Dict[builtins.str, typing.Any]]] = None,
    tag_name_pattern: typing.Optional[typing.Union[OrganizationRulesetRulesTagNamePattern, typing.Dict[builtins.str, typing.Any]]] = None,
    update: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b0d5b669f70d89a542af0aa74562cc4caab56aae907fae97bca1aa45c402020(
    *,
    operator: builtins.str,
    pattern: builtins.str,
    name: typing.Optional[builtins.str] = None,
    negate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d9f175d6fa7397266334e67a6353e777e36623c092080fe4c38e7cd7a9d57a2d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd90d96a29618340a2f0a49ce860ad308de2d3e6acf11711b49dae1215499fda(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60caba272c930d5a9f76d536e8ca7c3b1373f5901aa5bc078aa8ff7ad2b53e48(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e6679aae7a6e022f011f6138f884707f07af9980d32dc62f69bc6f464806539(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d2e86f333336adb879b9efbc73a78c19d42aa559596e9b29d5d915a124dd77e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e5d5b1aad1aa52bb34fd70eeb971b9154b14da26278e3e356427da601687da3(
    value: typing.Optional[OrganizationRulesetRulesBranchNamePattern],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e827b612949fc2423200d9a9b23800099c867d08ff18be5dfa84a25d5b088664(
    *,
    operator: builtins.str,
    pattern: builtins.str,
    name: typing.Optional[builtins.str] = None,
    negate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7865f15cf13ba0a9716e2dc39f7fbc2eca02db2449a850732565c5bc95639dbe(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__62ca8fad0e36cff671b97eb04df643042e59a6e2bd6d058963313449ed08f0c2(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a1401a0e9042ded5fae113af8b2ecdeeb11d60fc4e66807f2cfea2cbd4970b3(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37cacb7d4f3260c2b2c49a261ace4334162f11dce1342467f6381276494c7aac(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__468f43d3d326733a098daac9a2fba1d1650bd06edec77a97232bb2cc550aed19(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2d139c39087fd1b6499b357a00c903c6be5fa088ca5c9104dc3221adfc65061d(
    value: typing.Optional[OrganizationRulesetRulesCommitAuthorEmailPattern],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__09e2486646e537b3bb8c0484c123202179898a4b804daf889657b73e8ecaa325(
    *,
    operator: builtins.str,
    pattern: builtins.str,
    name: typing.Optional[builtins.str] = None,
    negate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__88efdcec012fae89b97e0165ec5c7512e6033952f644f165bb5466a9c88c40a0(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4253f30e214cfd76e4f521ff37da7f168549bd4c9f1c1606516501bb0cbb0ae4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__26042938aaf67484c724a749c7da70bd48e9f19c3a43dcb8df77d0cd93953aa0(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3042121131db9edbb21a33bb02041839c7aa67da27fea071e7a52fa573ac7cb(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97540aab39fd987a43b7f7c02637a570070600b7126461e0b1dbbbc832ddbda4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__32d577c2d4bbea5c0904c88c70c308e525edef22da3d059fa9e9ad1117990556(
    value: typing.Optional[OrganizationRulesetRulesCommitMessagePattern],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__70a4155b27d41300667cafd2bb35ea15fbd14839e02e4ea62d064c623ac97356(
    *,
    operator: builtins.str,
    pattern: builtins.str,
    name: typing.Optional[builtins.str] = None,
    negate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__81c9e8afd6a2231aa20252981c1d06859adef4b5e9da7b728c48341e32938233(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b052eb5d938c83b169c062529c67c0196c3d8a94ff664b57bbef7fca0761bf0a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__763be80f5f45495ab74fbb99083f88e7920d2645b87ad512812650bdeb077e4f(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__742982493f72062dcb30773f331573d5fda21bdf538fc035ddab4c16ec8b7fe6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54ecc06f56ca0219d3267e170f58b1d8538387702ed475235a557c9b6e41d439(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eeb0f50411403e20f2723634dda4837e208c7a0406c9b4b1960ad26008685a16(
    value: typing.Optional[OrganizationRulesetRulesCommitterEmailPattern],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__96b2ad9fc497c8f853662e1abd21cd8b11bd3ba564018947e692698b211cbcaf(
    *,
    review_draft_pull_requests: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    review_on_push: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c6107d3228c9bfddeb926d5560c91e223a0d7b4c97dbe70538dc789be647cae2(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8790285e824c86bd938acff4373c181728f56d5feafe967ecc3aed00d963d67f(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98db29ea54ed435a93bcb3c175ccc99bac6acd8beaf1dcadf3efcd93d2ca7608(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c563d6060e48c096a47dea190f5e64246aadb8b00a8eda208624fcfe420837c1(
    value: typing.Optional[OrganizationRulesetRulesCopilotCodeReview],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1142483baae28f2b5f2452f63e1a24015daa8d545061c7a4082640b2a32cb529(
    *,
    restricted_file_extensions: typing.Sequence[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54e103356ec752eb0a82b402fa6f8f711bcc3cba50db9943535acc4ca829707d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d85814020cd7b52a253fe1c402d23b76b4537d79cd346fb7c86b31319be75d15(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__07acef222e3c4b3d23c91658e0906232bc09bcb5aa0258a55d68831d78440dc7(
    value: typing.Optional[OrganizationRulesetRulesFileExtensionRestriction],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98fc3411e25c989e760ebdd642dca1e61b827b7fcd762492551be1e3462648d9(
    *,
    restricted_file_paths: typing.Sequence[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77bd3db678e31d1c6533327ffdea528890eeed0c4b66f2e9ae8b320717067534(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__752d13f31c8ff14835cd0b8dfcbe9e4ee445ee2db3e8b2b5150601683950c3f9(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__38fe1398d0390cb58474d09af6b526710f75e5e6f0e9bca76f00018faa55e4d0(
    value: typing.Optional[OrganizationRulesetRulesFilePathRestriction],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3374e8e30b30ab3bd1f07b963f7c7f5870cc00fa3cf68ba0835f488e9c6ec781(
    *,
    max_file_path_length: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9798307c8ae501d06e0a1de076c500c40c19ae7f971bb356e9ea12e9e626d321(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__24c367d929c9f8fd7fc4e398696ee1c346434e8e182318007de83d6e2c292660(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8fc97894fcdebfb563846a2b53a4bb74ce5940ddd360ad1ad848831135f6b09a(
    value: typing.Optional[OrganizationRulesetRulesMaxFilePathLength],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ecb53ca13a367941940d8d35366ceb3ec517ed90d3addd7ec97a7fd0dfa497b(
    *,
    max_file_size: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__88decc216093b704c1d50eb97625b6be747a6a4ad5687c020b3546f69ca0cd91(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a9a7be27509fc7c994929792314b8f6465571484a1920b6114cfbec65551a7af(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b95f67c38e9b6d358559aef21ce1f1a91fe33e6bc987320e0ff4c1b0975d6dc9(
    value: typing.Optional[OrganizationRulesetRulesMaxFileSize],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4796b1b041ffdbe195c5cf1819a49110ccc1dc4d2cded129b93c50735085d38d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b0d4de60ff51eaa931a9042b6ba23f6159094290dfcdf4202c947c2c969f61f8(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__abb74a422533847497a6d3b11bdfe92519ee277c3cc2387b382ecb578950b27d(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41ae130f746b1b6fc15941194a629dbba667bd1e36b35b944dd95884f31016fe(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__00641c6b7d748134751e52df1fab6ce996ee799412843e21b40ff4b5b4610f4e(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9152706f1266d5e3dc296ac00bbeb9455ee8810efca6f1a15d95603a8d8232f(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08edcad08a56ae70fc3a877dd67deae0d9ca452c66ef469a59b49cb8ce9e8851(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eff130a4ccb11eeaa0c2d97c01789302d02ee0f442ed41a2edf9a5ee0f3d2cc7(
    value: typing.Optional[OrganizationRulesetRules],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f9ca85a887f9f93f05db659b496f19f1b2d3e125ecdbaea908bf1624e7618a59(
    *,
    allowed_merge_methods: typing.Optional[typing.Sequence[builtins.str]] = None,
    dismiss_stale_reviews_on_push: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    require_code_owner_review: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    required_approving_review_count: typing.Optional[jsii.Number] = None,
    required_reviewers: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetRulesPullRequestRequiredReviewers, typing.Dict[builtins.str, typing.Any]]]]] = None,
    required_review_thread_resolution: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    require_last_push_approval: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f20e65082f7b18f8a3dbc064efd26ff85ec4bbfe9d9ba25c4ecc712b2125143(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0def8f246e2cf85cd6067b43fc460f263f6bd44f035565d01bb98e817ddd6186(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetRulesPullRequestRequiredReviewers, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5411ee07cf0e21487a02d9683057babc5f745836757e2cccbf3b7cf49c37ddfc(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e4836b12e056740c4debd26ce0b98b2be2788c6d583a35d5c87ccaf88414531b(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b7cd89acde219f1c04bf3d3412ec47edaa14afae8cb10655eb64ef33c17074f4(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eeab95b95f0b5f9d423b3d2b6e110f882a01c119299e4b05830715470cf24c04(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb9627c5a5e385ca7345bc82d377d9b9c46c24ec0a4fdf06ccaebf506bc60b60(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__957ef8434b645d24519703d073f0931b3106aeed930f7fceda81f1a7d0e5f98d(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ae0688d7b3de8faa0e849ab2e7573785f91a70a6064379801b8c8fb3bf5cce8a(
    value: typing.Optional[OrganizationRulesetRulesPullRequest],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40ae167024ee7fd0cfc89b3b2cde7b6b29438f6a1d3694145c95c2323211a5b3(
    *,
    file_patterns: typing.Sequence[builtins.str],
    minimum_approvals: jsii.Number,
    reviewer: typing.Union[OrganizationRulesetRulesPullRequestRequiredReviewersReviewer, typing.Dict[builtins.str, typing.Any]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2a38dc41246073e243c726b2c6fbb4b187a2d5704ec9919041c8f727c97197a(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d31b4a265370878a514b054f6d46e61bbf2a061cf6b4482f584df440bb020695(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__920a4ea473f24de6cc80fa40b47eb70602a5a93d9496215e99090981ec975e28(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[OrganizationRulesetRulesPullRequestRequiredReviewers]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__42e769031aaf27aea612442299a487e120bf1dfcbb1262999b68385fb9430c8b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__defbc5f7327ee3a0af41c41558cabc2aa315c29e0ca99ea0ad741897aa954f5b(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__81e56eab18ae6c39430ff0d23c079ffd564f52e1587a240c2e5491357c73c113(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7744d5f7ae7811b62e3942a6e2127acaf1469829b3ec942ab139f3578129aeee(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, OrganizationRulesetRulesPullRequestRequiredReviewers]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7737a089efd903270a9c9aa48b2928dd6b673bbd3ab58196e2d712a38cd789d5(
    *,
    id: jsii.Number,
    type: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a3595450c662d2f598564fe1def81ced90a42ad3f132a86a2d233cc4e72e363(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cc7b4baced192a4f9c295942da038422cc89d9f1344d56c2fc2a0c4474f30bf0(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__acddca447d484d69c5b4503371617a0aeaf3259bd8c7ce9ce12c5efa0bc659d7(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0448be93aea69cf121e3d74e859a3e682aea7b4d423d976c832393048458efcf(
    value: typing.Optional[OrganizationRulesetRulesPullRequestRequiredReviewersReviewer],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ef7bf67210a1fe34f9da8a4548ab4b9bef72c251e00d9d809d6e6bbf0aaa0d0(
    *,
    required_code_scanning_tool: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__72770e2661e39eaf269cd7f3568feb2d7f37f16d6fb0c1d3b77ca371350fe417(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__73ca602d935f01b9de2f25dd325444c2463628a748ab0d75b1bea33a414be2f8(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41ce9b8bc5a33e4906558edc4d2379f4a90a1aad94a927602723b29f53966381(
    value: typing.Optional[OrganizationRulesetRulesRequiredCodeScanning],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8c286283a242a54a2c13cb89317c332336ea8a6a6d05fe5edd68bbd2c24b79af(
    *,
    alerts_threshold: builtins.str,
    security_alerts_threshold: builtins.str,
    tool: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1dcafadda36fd9a50de4005d9d5529b7dac17e19164e79d50de74d195dfddd3a(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b907b1d6f2ad546d74df849d5fe6ae0ba6f5b3359b715dbb093a74af9af4e9a7(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__32f8d7c04b2791d5eba078b2f372283df26d5f6e71f8debbfec6c370d3797f87(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c0cfb9891de428839ad39992dff2eca9fa1a81d7c2889d8ed1d0ac1fdf5b50de(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7cd93e4ab42195513609350d37d4ee023bf846f4b802a01a0b3b43bf5279264a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55326cd3a9b28c21417feab7eb386f95df05ecd9107516154e3599c6d7f171e6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3bc4dfb0be91d1e2579d724bee90c92463ccdd1cb5f2c09feba8bc46d60a5ac(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b96743972d5b4efd3e5ba29651e73fe04bc091ce440f3834fac23ad28c05a26(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, OrganizationRulesetRulesRequiredCodeScanningRequiredCodeScanningTool]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d7d47fd301cf2d3b010d07ffc573cafbf8118632557cead1a5f7d2a9472fdab5(
    *,
    required_check: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetRulesRequiredStatusChecksRequiredCheck, typing.Dict[builtins.str, typing.Any]]]],
    do_not_enforce_on_create: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    strict_required_status_checks_policy: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e621d843321eb673ad88c1b43d43f93a7ba517e29b9fca13ed981b5182f9203d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__67aef54a829c6140b99c58785f5ebbb1113f43880aabc4b0dd168a3d8ff6f855(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetRulesRequiredStatusChecksRequiredCheck, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__59f00176a4637601dabf2c8bfe3264d63f8704a41854545148c182fcbd11b33a(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__04b8a76fddfbc9ae3804136b7750aefb05cdef05a99b10fb69005bc07d514109(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6e75b11cd8422c0be105c11a2db970175c18a77f079af9485b3e74857263ac40(
    value: typing.Optional[OrganizationRulesetRulesRequiredStatusChecks],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f9dd4cc971105484e2e66f19b157af578e761f0ee18b11e93c6e3ba590b21c1(
    *,
    context: builtins.str,
    integration_id: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__913e68dc6e8839933b976d86785902c54e7d1d8cc08950283b0cdd6be766e7d3(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__43836b2f02dbbb74b4610446f90307915aab556f3031f969e07e02a6c80ccac6(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fac404d6580082ed49cde974f49f51878d6a23b7a23f3f54303100b7c5b39ce2(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[OrganizationRulesetRulesRequiredStatusChecksRequiredCheck]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3035ed03a7051211fe81480d6c090a4d40ff2441b237a04bce841d5b3a0b66a8(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98b14df8e94f95d1cf97270f91ae944784bfd0322574087960a5bb20ac12db9c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0515a4dc6bf8cc9352757285514e47bc0274e72619d44c1a2cda3d5e53be8254(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ac87517ca26715b4e17956e099fb867de119073fc51ef25d41f981015b65a9ed(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, OrganizationRulesetRulesRequiredStatusChecksRequiredCheck]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__384954b5fb29b6ee47dc93cef70901011f761a4117d04efbb5950cd236518cd2(
    *,
    required_workflow: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow, typing.Dict[builtins.str, typing.Any]]]],
    do_not_enforce_on_create: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a572f113449b508ee1de340525b63a65bd60e46d76cc77eca1ebd7f1fc0c996(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__82c2a23b5444f0776fa68e9b7f680df654dd90781748791086b58a617643eb4c(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d33b81e8fea10fe35d601b19f259af3876fdadf0aeb633d3ecb2dfadd9aa4b5d(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c45e55af2977c02a8b2c18d8ceedef8532b1ca52eddebb9b66c05839d3e6f7d2(
    value: typing.Optional[OrganizationRulesetRulesRequiredWorkflows],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7176f887a6d44a0b8bba0e5f5db35665f5ff298ec1ff8f63ac0df3b1de411bc5(
    *,
    path: builtins.str,
    repository_id: jsii.Number,
    ref: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__53fac776f0a5e4699d2943ab56b055edf20d7937ce614e798ad3a7b7ce181c35(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e7d613ca12edd21f95a4e6d64e302a0e64ba572056994b0ca76d8b0e87347cd2(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6662c3e3b18ff23c6e02eb87e26f81b40ce1241c4825bc0487ff513b0cac0771(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aba90df737c433d0333892f7fc678dc4efe409347e280a05bdfbbe21b54cff9e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__65d572768852ceb61251fdfd6140298841ba4a441cc3fd451994c7ee7329d54c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b02c3de43747ea83c64b129e5077511c1e44c3a7d4a949618aef6d1c9238d61e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0fee2246899db7bd99a5c5ad7e017ea4d1706008cb74313d3700a7ee66bc77b0(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b778a900aac3233634f426f547fa8ff7eccfbbe4b6462b1cc3175bdbd7cba88e(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, OrganizationRulesetRulesRequiredWorkflowsRequiredWorkflow]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__30829f8fb279e06b63066a359601a4216b4a35fbb6a91cbb9432bfef97515b36(
    *,
    operator: builtins.str,
    pattern: builtins.str,
    name: typing.Optional[builtins.str] = None,
    negate: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2726e63c61a218dde0b22c48318805603bdc74e7df136b407c4e8cfbe41ac7a3(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c90faa37cf687c2d6da568801d8a1836ed029d4ec68d0739fb8f306b14fb9ca3(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eafdea6633a828ab437cd52ba116ba22582e0b2cb9410f660100494a976bdcef(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e73fed8c29886591edb3813332883f81e9d7ab9802762ce33f727ee3e394d833(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c071dbfec35238ea4ccaeb317c86a8854bfa9da7251138a40387f7298feec88(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__063850daaf55754a08de6057e0282da43d0e8629e1c0971221df55f839728799(
    value: typing.Optional[OrganizationRulesetRulesTagNamePattern],
) -> None:
    """Type checking stubs"""
    pass
