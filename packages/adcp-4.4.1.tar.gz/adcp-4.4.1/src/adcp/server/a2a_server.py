"""A2A server support for ADCP handlers.

Bridges ADCPHandler to the a2a-sdk server framework so the same handler
can be served over both MCP and A2A transports.

    from adcp.server import ADCPHandler, serve
    serve(MyHandler(), name="my-agent", transport="a2a")

.. note::
    Function signatures here use ``ADCPHandler[Any]`` rather than a
    propagated ``TContext`` TypeVar. This module dispatches by tool
    name and never reads typed fields off the context, so ``Any`` is
    both correct and keeps the call sites tidy — downstream code that
    needs typed context (their own handler subclass) keeps the TypeVar
    all the way to dispatch via :class:`ADCPHandler`. See the matching
    note in :mod:`adcp.server.mcp_tools`.
"""

from __future__ import annotations

import json
import logging
import os
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from a2a import types as pb
from a2a.server.agent_execution.agent_executor import AgentExecutor
from a2a.server.agent_execution.context import RequestContext
from a2a.server.events.event_queue import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes import create_agent_card_routes, create_jsonrpc_routes
from a2a.server.tasks.inmemory_task_store import InMemoryTaskStore
from google.protobuf.json_format import MessageToDict, ParseDict
from google.protobuf.struct_pb2 import Value
from starlette.applications import Starlette

from adcp.exceptions import ADCPError
from adcp.server.base import ADCPHandler, ToolContext

# Decisioning-layer ``AdcpError`` (from ``adcp.decisioning.types``) is the
# wire-shaped structured error platform methods raise. It is NOT a subclass
# of :class:`adcp.exceptions.ADCPError`; the executor must catch both so
# storyboards graded against decisioning adopters see the same structured
# envelope as MCP. Lazy import — ``adcp.decisioning`` pulls in the
# decisioning graph, which the A2A server module shouldn't load at import
# time. When the import fails (decisioning extra not installed), only the
# client-side ``ADCPError`` path is active.
try:
    from adcp.decisioning.types import AdcpError as _DecisioningAdcpError
except Exception:  # pragma: no cover - decisioning is an optional dep surface
    _DecisioningAdcpError = None  # type: ignore[assignment,misc]

if TYPE_CHECKING:
    from collections.abc import Sequence

    from a2a.server.tasks.push_notification_config_store import (
        PushNotificationConfigStore,
    )
    from a2a.server.tasks.task_store import TaskStore

    from adcp.server.serve import ContextFactory, SkillMiddleware

from collections.abc import Callable  # noqa: E402

from adcp.validation.client_hooks import (  # noqa: E402
    SERVER_DEFAULT_VALIDATION,
    ValidationHookConfig,
)

MessageParser = Callable[[RequestContext], tuple[str | None, dict[str, Any]]]
"""Callable that extracts ``(skill_name, params)`` from an incoming
A2A :class:`RequestContext`.

The default parser handles a DataPart (``data`` oneof) carrying
``{"skill": ..., "parameters": ...}`` plus a TextPart JSON fallback.
Override this hook to accept alternative wire shapes — JSON-RPC 2.0
message bodies, vendor-specific DataPart schemas, or text-only skill
encodings. Return ``(None, {})`` to signal "no parseable skill"; the
executor will emit an error Task for the client.

Pair with :meth:`ADCPAgentExecutor._default_parse_request` when you
want to accept a custom shape *in addition to* the built-in shapes —
call the default as a fallback after your own parser returns
``(None, {})``.
"""


from adcp.server.mcp_tools import create_tool_caller, get_tools_for_handler
from adcp.server.test_controller import TestControllerStore, _handle_test_controller

logger = logging.getLogger(__name__)


def _part_data_dict(part: pb.Part) -> dict[str, Any] | None:
    """Return the dict payload of a Part if it carries a ``data`` oneof, else None."""
    if part.WhichOneof("content") != "data":
        return None
    value = MessageToDict(part.data)
    if isinstance(value, dict):
        return value
    return None


def _part_text(part: pb.Part) -> str | None:
    """Return the text payload of a Part if it carries a ``text`` oneof, else None."""
    if part.WhichOneof("content") != "text":
        return None
    return part.text


def _make_data_part(data: dict[str, Any]) -> pb.Part:
    """Build a Part carrying a ``data`` oneof from a plain dict."""
    value = Value()
    ParseDict(data, value)
    return pb.Part(data=value)


def _make_text_part(text: str) -> pb.Part:
    """Build a Part carrying a ``text`` oneof."""
    return pb.Part(text=text)


class ADCPAgentExecutor(AgentExecutor):
    """Bridges ADCPHandler methods to the a2a-sdk AgentExecutor interface.

    Incoming A2A messages are parsed to extract the ADCP skill name and
    parameters, dispatched to the matching handler method, and the result
    is published back as A2A Task events.

    Expects the explicit skill invocation format used by A2AAdapter:
        Part(data={"skill": "get_products", "parameters": {...}})
    """

    def __init__(
        self,
        handler: ADCPHandler[Any],
        test_controller: TestControllerStore | None = None,
        *,
        context_factory: ContextFactory | None = None,
        middleware: Sequence[SkillMiddleware] | None = None,
        message_parser: MessageParser | None = None,
        advertise_all: bool = False,
        validation: ValidationHookConfig | None = SERVER_DEFAULT_VALIDATION,
        test_controller_account_resolver: Any | None = None,
    ) -> None:
        self._handler = handler
        self._context_factory = context_factory
        self._test_controller_account_resolver = test_controller_account_resolver
        # Store as a tuple so the executor can't be mutated from underneath
        # at runtime (a flaky test or a handler reaching self._middleware
        # can't corrupt the dispatch chain). Tuple ordering = runtime
        # ordering; first entry wraps outermost (see ``SkillMiddleware``
        # docstring for the composition semantics).
        self._middleware: tuple[SkillMiddleware, ...] = tuple(middleware or ())
        # Seller-supplied parser for non-default wire shapes (JSON-RPC,
        # bare TextPart with different skill layout, etc.). Falls back
        # to the built-in parser when None.
        self._message_parser: MessageParser | None = message_parser
        self._tool_callers: dict[str, Any] = {}

        # Build tool callers for all tools this handler supports.
        # Skip comply_test_controller unless the seller passed a
        # TestControllerStore; otherwise we would advertise a skill
        # backed only by the handler's not-supported stub.
        tool_defs = get_tools_for_handler(handler, advertise_all=advertise_all)
        for tool_def in tool_defs:
            name = tool_def["name"]
            if name == "comply_test_controller" and test_controller is None:
                continue
            self._tool_callers[name] = create_tool_caller(handler, name, validation=validation)

        if test_controller is not None:
            self._register_test_controller(test_controller)

    @property
    def supported_skills(self) -> list[str]:
        """List of skill names this executor can handle."""
        return list(self._tool_callers.keys())

    def _register_test_controller(self, store: TestControllerStore) -> None:
        """Register comply_test_controller as a callable skill.

        Threads the ToolContext that the A2A executor built for this
        dispatch into the store so header-driven test state (populated
        by ``context_factory`` from ``ServerCallContext.user`` /
        message-metadata headers) composes with the storyboard-driven
        ``comply_test_controller`` skill. See #227.
        """

        resolver = self._test_controller_account_resolver

        async def _call_test_controller(
            params: dict[str, Any], context: ToolContext | None = None
        ) -> Any:
            return await _handle_test_controller(
                store,
                params,
                context=context,
                account_resolver=resolver,
            )

        self._tool_callers["comply_test_controller"] = _call_test_controller

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        """Execute an ADCP skill from an incoming A2A message."""
        skill_name, params = self._parse_request(context)

        if skill_name is None:
            await self._send_error(event_queue, context, "No skill specified in message")
            return

        if skill_name not in self._tool_callers:
            await self._send_error(event_queue, context, f"Unknown skill: {skill_name}")
            return

        tool_context = self._build_tool_context(skill_name, context)
        # Catch both the client-side :class:`ADCPError` (raised by
        # framework helpers like ``IdempotencyConflictError``) AND the
        # decisioning-layer :class:`AdcpError` (raised by platform methods
        # adopters write against the decisioning graph). They are
        # disjoint hierarchies; both project onto the same structured
        # ``adcp_error`` envelope per transport-errors.mdx §A2A Binding.
        structured_error_types: tuple[type[BaseException], ...] = (ADCPError,)
        if _DecisioningAdcpError is not None:
            structured_error_types = (ADCPError, _DecisioningAdcpError)
        try:
            result = await self._dispatch_with_middleware(skill_name, params, tool_context)
            # ``params`` carries the parsed wire request including any
            # ``context`` extension. Both success and error paths thread
            # it through to the result builder so the context-passthrough
            # contract holds across the dispatch outcome.
            await self._send_result(event_queue, context, skill_name, result, params)
        except structured_error_types as exc:
            # Application-layer AdCP error. Emit a failed task with the
            # adcp_error in a DataPart per transport-errors.mdx §A2A
            # Binding, plus a human-readable text part. The JSON-RPC
            # channel is reserved for transport-level errors (auth
            # rejected, rate-limited pre-dispatch).
            logger.info("AdCP application error for skill %s: %s", skill_name, exc)
            await self._send_adcp_error(event_queue, context, exc, params)
        except Exception:
            logger.exception("Error executing skill %s", skill_name)
            await self._send_error(event_queue, context, f"Skill execution failed: {skill_name}")

    async def _dispatch_with_middleware(
        self,
        skill_name: str,
        params: dict[str, Any],
        tool_context: ToolContext,
    ) -> Any:
        """Run the handler wrapped in the configured middleware chain.

        Delegates to :func:`adcp.server.serve._dispatch_with_middleware`
        so the composition semantics stay identical between transports —
        middleware that works with ``create_a2a_server(middleware=...)``
        works unchanged with ``create_mcp_server(middleware=...)``.

        Middleware exceptions propagate to the executor's normal error
        handling path in ``execute()``; this method does no try/except
        so short-circuiting, transform, and exception-observation all
        work the same way they do for the underlying handler.
        """
        from adcp.server.serve import _dispatch_with_middleware

        async def _call_handler() -> Any:
            return await self._tool_callers[skill_name](params, tool_context)

        return await _dispatch_with_middleware(
            self._middleware, skill_name, params, tool_context, _call_handler
        )

    def _build_tool_context(self, skill_name: str, request: RequestContext) -> ToolContext:
        """Build the :class:`ToolContext` handed to the skill dispatcher.

        When ``context_factory`` is configured, call it with a
        :class:`RequestMetadata` describing this A2A invocation; overlay the
        transport-derived ``caller_identity`` / ``request_id`` afterwards
        **only when the factory left them unset**, so factories that already
        know the principal (e.g. from a ContextVar the seller's auth layer
        populated) aren't clobbered.

        When no factory is configured, fall back to the A2A-only path that
        derives ``caller_identity`` from ``ServerCallContext.user`` —
        preserving behavior for sellers who haven't adopted
        ``context_factory=`` yet.
        """
        if self._context_factory is None:
            return _tool_context_from_request(request)

        from adcp.server.serve import RequestMetadata

        meta = RequestMetadata(
            tool_name=skill_name,
            transport="a2a",
            request_id=request.task_id,
        )
        ctx = self._context_factory(meta)
        if not isinstance(ctx, ToolContext):
            raise TypeError(
                f"context_factory for skill {skill_name!r} returned "
                f"{type(ctx).__name__}, not a ToolContext instance"
            )
        # Fill in transport-derived fields the factory didn't set. This
        # preserves the pre-factory A2A security invariant: if the seller
        # didn't explicitly populate caller_identity in their factory,
        # fall through to ServerCallContext.user (verified by the a2a-sdk
        # auth middleware) rather than silently sending None.
        if ctx.caller_identity is None:
            fallback = _tool_context_from_request(request)
            ctx.caller_identity = fallback.caller_identity
        if ctx.request_id is None:
            ctx.request_id = request.task_id
        return ctx

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        """ADCP operations are synchronous; cancellation sets state to canceled."""
        event = _make_task(
            context,
            state=pb.TaskState.TASK_STATE_CANCELED,
            message="Task canceled",
        )
        await event_queue.enqueue_event(event)

    # ------------------------------------------------------------------
    # Message parsing
    # ------------------------------------------------------------------

    def _parse_request(self, context: RequestContext) -> tuple[str | None, dict[str, Any]]:
        """Extract skill name and parameters from the A2A message.

        Dispatches to the caller-supplied :data:`MessageParser` when the
        executor was constructed with ``message_parser=``; otherwise
        falls through to :meth:`_default_parse_request`, which supports
        the standard shapes (DataPart with explicit skill + TextPart
        JSON fallback).
        """
        if self._message_parser is not None:
            return self._message_parser(context)
        return self._default_parse_request(context)

    def _default_parse_request(self, context: RequestContext) -> tuple[str | None, dict[str, Any]]:
        """Built-in parser. Supports two formats:

        1. Explicit skill invocation via a DataPart:
           ``Part(data={"skill": "get_products", "parameters": {...}})``
        2. Natural language fallback via TextPart (best-effort parse)

        Exposed as a module-level method so custom parsers can compose
        it — e.g. "try my JSON-RPC parser first, fall through to the
        default for legacy clients".
        """
        msg = context.message
        if msg is None or not msg.parts:
            return None, {}

        # Try DataPart first (explicit skill invocation)
        for part in msg.parts:
            data = _part_data_dict(part)
            if data is None:
                continue
            skill = data.get("skill")
            params = data.get("parameters", {})
            if skill:
                return str(skill), params if isinstance(params, dict) else {}

        # Fallback: try to parse TextPart as JSON
        for part in msg.parts:
            text = _part_text(part)
            if text is None:
                continue
            parsed = self._parse_text_request(text)
            if parsed[0] is not None:
                return parsed

        return None, {}

    def _parse_text_request(self, text: str) -> tuple[str | None, dict[str, Any]]:
        """Best-effort parse of a text request for skill + params."""
        try:
            data = json.loads(text)
            if isinstance(data, dict) and "skill" in data:
                return str(data["skill"]), data.get("parameters", {})
        except (json.JSONDecodeError, TypeError):
            pass
        return None, {}

    # ------------------------------------------------------------------
    # Response helpers
    # ------------------------------------------------------------------

    async def _send_result(
        self,
        event_queue: EventQueue,
        context: RequestContext,
        skill_name: str,
        result: Any,
        params: dict[str, Any] | None = None,
    ) -> None:
        """Publish a completed task with the skill result.

        When ``params`` is supplied and carries a wire ``context`` field,
        echo it onto the result DataPart per the AdCP context-passthrough
        contract. This mirrors the MCP success path's
        :func:`adcp.server.helpers.inject_context` call in
        :mod:`adcp.server.mcp_tools` and keeps the error path's echo
        (see :meth:`_send_adcp_error`) symmetric on A2A.
        """
        # Normalize result to a JSON-safe dict
        if hasattr(result, "model_dump"):
            data = result.model_dump(mode="json", exclude_none=True)
        elif not isinstance(result, dict):
            data = {"result": result}
        else:
            data = result

        if params is not None and isinstance(data, dict):
            from adcp.server.helpers import inject_context

            inject_context(params, data)

        task = _make_task(
            context,
            state=pb.TaskState.TASK_STATE_COMPLETED,
            data=data,
            message=f"Completed {skill_name}",
        )
        await event_queue.enqueue_event(task)

    async def _send_error(
        self,
        event_queue: EventQueue,
        context: RequestContext,
        error_msg: str,
    ) -> None:
        """Publish a failed task."""
        task = _make_task(
            context,
            state=pb.TaskState.TASK_STATE_FAILED,
            message=error_msg,
        )
        await event_queue.enqueue_event(task)

    async def _send_adcp_error(
        self,
        event_queue: EventQueue,
        context: RequestContext,
        exc: Any,
        params: dict[str, Any] | None = None,
    ) -> None:
        """Publish a failed task carrying an AdCP ``adcp_error`` payload.

        Follows transport-errors.mdx §A2A Binding: failed task with artifact
        containing a ``DataPart`` keyed under ``adcp_error`` plus a terse
        ``TextPart`` for human/LLM consumption.

        The structured envelope carries the full spec shape — ``code``,
        ``message``, ``recovery``, ``field``, ``suggestion``,
        ``retry_after``, ``details`` — populated when the raised
        exception supplies them, omitted when ``None``. Field extraction
        is shared with the MCP path via
        :func:`adcp.server.translate._extract_structured_fields`, so
        both transports project off the same source-of-truth shape.

        When ``params`` is supplied and carries a wire ``context`` field,
        that field is echoed alongside ``adcp_error`` in the DataPart —
        symmetric with the success path's
        :func:`adcp.server.helpers.inject_context` call. Without this
        echo, error responses violate the AdCP context-passthrough
        contract and buyers lose correlation IDs across the
        raise-AdcpError boundary.
        """
        # Lazy import — ``translate.py`` pulls in heavier server deps
        # (mcp.types) which the A2A module doesn't otherwise need.
        from adcp.server.helpers import inject_context
        from adcp.server.translate import _extract_structured_fields

        code, message, recovery, field, suggestion, details, _errors = _extract_structured_fields(
            exc
        )

        adcp_error: dict[str, Any] = {
            "code": code,
            "message": message,
            "recovery": recovery,
        }
        if field is not None:
            adcp_error["field"] = field
        if suggestion is not None:
            adcp_error["suggestion"] = suggestion
        # ``retry_after`` lives on decisioning AdcpError; project when present.
        retry_after = getattr(exc, "retry_after", None)
        if retry_after is not None:
            adcp_error["retry_after"] = retry_after
        if details:
            adcp_error["details"] = dict(details)

        data: dict[str, Any] = {"adcp_error": adcp_error}
        if params is not None:
            inject_context(params, data)

        task = _make_task(
            context,
            state=pb.TaskState.TASK_STATE_FAILED,
            data=data,
            message=message,
        )
        await event_queue.enqueue_event(task)


# ------------------------------------------------------------------
# Request context helpers
# ------------------------------------------------------------------


def _tool_context_from_request(request: RequestContext) -> ToolContext:
    """Derive a :class:`ToolContext` from an A2A :class:`RequestContext`.

    Extracts the authenticated principal from ``request.call_context.user``
    when present. Unauthenticated / anonymous requests get a bare
    ``ToolContext`` — server middleware that requires a principal (e.g. the
    idempotency store's per-principal scoping) falls through to its
    no-principal default rather than collapsing everyone into a shared
    namespace.

    Security invariant: ``ServerCallContext`` is populated by the seller's
    server-side auth middleware from verified transport material (bearer
    token, mTLS cert, OAuth identity). A malicious client cannot flip
    ``is_authenticated`` or set ``user_name`` from the message payload.
    The ``is_authenticated and user_name`` gate below relies on this
    invariant — do not relax it.

    PII note: the ``user_name`` string becomes ``caller_identity``, which
    the idempotency middleware logs prefix-truncated at DEBUG. If your auth
    layer sets ``user_name`` to an email address, treat idempotency debug
    logs as containing PII. Prefer opaque principal IDs.
    """
    ctx = ToolContext(request_id=request.task_id)
    call_context = getattr(request, "call_context", None)
    user = getattr(call_context, "user", None)
    if user is not None:
        is_auth = getattr(user, "is_authenticated", False)
        user_name = getattr(user, "user_name", "") or ""
        if is_auth and user_name:
            ctx.caller_identity = user_name
    return ctx


# ------------------------------------------------------------------
# Task factory
# ------------------------------------------------------------------


def _make_task(
    context: RequestContext,
    *,
    state: int,
    data: dict[str, Any] | None = None,
    message: str | None = None,
) -> pb.Task:
    """Build an a2a Task event from context and result data."""
    parts: list[pb.Part] = []
    if data is not None:
        parts.append(_make_data_part(data))
    if message:
        parts.append(_make_text_part(message))

    artifacts: list[pb.Artifact] = []
    if parts:
        artifacts.append(
            pb.Artifact(
                artifact_id=str(uuid4()),
                parts=parts,
            )
        )

    return pb.Task(
        id=context.task_id or str(uuid4()),
        context_id=context.context_id or str(uuid4()),
        status=pb.TaskStatus(state=state),  # type: ignore[arg-type]
        artifacts=artifacts,
    )


# ------------------------------------------------------------------
# Public API
# ------------------------------------------------------------------


def _build_agent_card(
    handler: ADCPHandler[Any],
    *,
    name: str,
    port: int,
    description: str | None = None,
    version: str = "1.0.0",
    extra_skills: list[pb.AgentSkill] | None = None,
    advertise_all: bool = False,
    push_notifications_supported: bool = False,
) -> pb.AgentCard:
    """Build an A2A AgentCard from an ADCPHandler's tool definitions.

    ``comply_test_controller`` is excluded from the card skills list unless
    the caller supplied it via ``extra_skills`` (which is how
    :func:`create_a2a_server` opts in when a ``TestControllerStore`` is
    wired). Extra skills are deduped by id so advertising the test
    controller never produces two entries.

    Honors the same ``advertise_all`` semantic as
    :func:`~adcp.server.get_tools_for_handler` so the published agent
    card reflects what the executor will actually dispatch.

    The card advertises both the 0.3 and 1.0 protocol bindings via
    ``supported_interfaces`` so ``enable_v0_3_compat`` clients and native
    1.0 clients see the transport they expect on
    ``/.well-known/agent-card.json``.
    """
    tool_defs = get_tools_for_handler(handler, advertise_all=advertise_all)
    extra_ids = {s.id for s in extra_skills} if extra_skills else set()

    skills = [
        pb.AgentSkill(
            id=td["name"],
            name=td["name"],
            description=td.get("description", td["name"]),
            tags=["adcp"],
        )
        for td in tool_defs
        if td["name"] != "comply_test_controller" and td["name"] not in extra_ids
    ]

    if extra_skills:
        skills.extend(extra_skills)

    url = f"http://localhost:{port}/"

    return pb.AgentCard(
        name=name,
        description=description or f"ADCP agent: {name}",
        version=version,
        # Ordering is load-bearing: a2a-sdk's v0.3 compat converter
        # (``a2a.compat.v0_3.conversions.to_compat_agent_card``) sets
        # ``primary_interface = compat_interfaces[0]``, so the entry it
        # picks for the top-level 0.3 ``url`` / ``preferredTransport`` /
        # ``protocolVersion`` back-fill is whichever 0.3 interface it
        # sees first. Keep 0.3 at index 0. 1.0 clients don't iterate
        # positionally — they filter by ``protocol_version`` — so
        # listing 1.0 second has no negotiation cost.
        supported_interfaces=[
            pb.AgentInterface(url=url, protocol_binding="JSONRPC", protocol_version="0.3"),
            pb.AgentInterface(url=url, protocol_binding="JSONRPC", protocol_version="1.0"),
        ],
        skills=skills,
        # Advertise ``push_notifications`` only when the server actually
        # has a store wired. The a2a-sdk request handler gates every
        # push-notif op on this capability flag, and advertising it
        # without a store just means clients hit
        # ``UnsupportedOperationError`` after a successful capability
        # probe — a worse UX than "capability says no, don't try".
        capabilities=pb.AgentCapabilities(
            streaming=False,
            push_notifications=push_notifications_supported,
        ),
        default_input_modes=["application/json"],
        default_output_modes=["application/json"],
    )


def create_a2a_server(
    handler: ADCPHandler[Any],
    *,
    name: str = "adcp-agent",
    port: int | None = None,
    description: str | None = None,
    version: str = "1.0.0",
    test_controller: TestControllerStore | None = None,
    test_controller_account_resolver: Any | None = None,
    context_factory: ContextFactory | None = None,
    task_store: TaskStore | None = None,
    push_config_store: PushNotificationConfigStore | None = None,
    middleware: Sequence[SkillMiddleware] | None = None,
    message_parser: MessageParser | None = None,
    advertise_all: bool = False,
    validation: ValidationHookConfig | None = SERVER_DEFAULT_VALIDATION,
    context_builder: Any | None = None,
) -> Any:
    """Create an A2A Starlette application from an ADCP handler.

    The returned app dual-serves the a2a-sdk 0.3 and 1.0 wire formats via
    ``create_jsonrpc_routes(enable_v0_3_compat=True)``. Existing 0.3
    clients keep getting lowercase ``"state": "completed"`` and
    ``"kind": "task"`` discriminators; native 1.0 clients get the new
    shape. Do not disable the compat flag.

    Args:
        handler: An ADCPHandler subclass instance.
        name: Agent name shown in the A2A agent card.
        port: Port number (used in the agent card URL).
        description: Agent description for the agent card.
        version: Agent version string.
        test_controller: Optional TestControllerStore for storyboard testing.
        context_factory: Optional callable invoked per skill call to build
            a :class:`ToolContext` from :class:`RequestMetadata`. Mirrors
            the MCP-side ``context_factory=`` on
            :func:`~adcp.server.create_mcp_server` so a single factory
            populates tenant/adapter fields on both transports. When
            unset, the executor falls back to deriving ``caller_identity``
            from ``ServerCallContext.user`` — preserving pre-factory
            behavior. See :data:`~adcp.server.ContextFactory` for the
            recommended contextvars pattern.
        task_store: Optional a2a-sdk :class:`~a2a.server.tasks.task_store.TaskStore`
            instance for persisting A2A task state. Defaults to
            :class:`~a2a.server.tasks.inmemory_task_store.InMemoryTaskStore`,
            which is single-process and non-durable — fine for demos and
            local development, but tasks vanish on restart and don't share
            across workers. Production agents pass a durable subclass
            (Postgres, Redis, etc.). See ``examples/a2a_db_tasks.py`` for
            a reference SQLite-backed implementation and
            ``docs/handler-authoring.md`` for the persistence caveats on
            the default store.
        push_config_store: Optional a2a-sdk
            :class:`~a2a.server.tasks.push_notification_config_store.PushNotificationConfigStore`
            instance for persisting push-notification configs that clients
            register via ``tasks/pushNotificationConfig/set``. **When
            unset, a2a-sdk surfaces push-notif endpoints as
            ``UnsupportedOperationError``** — clients cannot register
            subscriptions at all. Set this only when your agent is ready
            to accept push-notif subscriptions. See
            ``examples/a2a_db_tasks.py`` for a reference SQLite-backed
            implementation that pairs with the ``SqliteTaskStore`` there.

            Security note: unlike ``TaskStore``, a2a-sdk's
            ``PushNotificationConfigStore`` ABC does not pass a
            ``ServerCallContext`` to ``set_info`` / ``get_info`` /
            ``delete_info``. Scoping by principal has to happen out-of-band
            (via a ``ContextVar`` your auth middleware populates) or by
            composition with a tenant-scoped ``TaskStore`` — the reference
            impl shows the ContextVar pattern.
        middleware: Optional sequence of :data:`~adcp.server.SkillMiddleware`
            callables wrapping every A2A skill dispatch. Composes
            outermost-first (first entry sees the call before later
            entries and before the handler). Use for audit logging,
            activity-feed hooks, rate limiting, per-skill tracing. See
            :data:`~adcp.server.SkillMiddleware` for the signature,
            composition semantics, and the exception-capture pattern
            audit hooks need.
        message_parser: Optional :data:`MessageParser` for alternative
            wire shapes. The default parser handles a DataPart carrying
            ``{"skill": ..., "parameters": ...}`` plus a TextPart JSON
            fallback. Supply this to accept JSON-RPC 2.0 message bodies,
            vendor-specific DataPart schemas, or other layouts. The
            callable returns ``(skill_name, params)`` or ``(None, {})``
            for "no parseable skill"; see :data:`MessageParser` and
            :meth:`ADCPAgentExecutor._default_parse_request` for the
            built-in fallback shape to delegate to for legacy clients.
        advertise_all: When True, advertise every tool the handler type
            supports — including ones whose method is still the SDK's
            ``not_supported`` default. Defaults to ``False``, which
            reflects only overridden methods in the agent card's
            ``skills`` list and in the executor's tool-caller registry.
            Turn on for spec-compliance storyboards or when the agent
            deliberately wants clients to see a ``not_supported`` tool.
        validation: :class:`ValidationHookConfig` enabling schema
            validation of every request and response against the
            bundled AdCP JSON schemas. Defaults to
            :data:`~adcp.validation.client_hooks.SERVER_DEFAULT_VALIDATION`
            (strict on both sides). Pass
            ``ValidationHookConfig(responses="warn")`` to log+continue
            on response drift, or ``validation=None`` to disable
            validation entirely.

    Returns:
        A Starlette app ready to be run with uvicorn.
    """
    resolved_port = port or int(os.environ.get("PORT", "3001"))

    executor = ADCPAgentExecutor(
        handler,
        test_controller=test_controller,
        context_factory=context_factory,
        middleware=middleware,
        message_parser=message_parser,
        advertise_all=advertise_all,
        validation=validation,
        test_controller_account_resolver=test_controller_account_resolver,
    )

    agent_card = _build_agent_card(
        handler,
        name=name,
        port=resolved_port,
        description=description,
        version=version,
        extra_skills=_test_controller_skills() if test_controller else None,
        advertise_all=advertise_all,
        push_notifications_supported=push_config_store is not None,
    )

    if task_store is None:
        task_store = InMemoryTaskStore()

    # DefaultRequestHandler stores push_config_store verbatim and treats
    # None as "push-notif endpoints unsupported" (UnsupportedOperationError
    # on tasks/pushNotificationConfig/*). Passing None is the correct
    # default; sellers opt in by wiring a store.
    request_handler = DefaultRequestHandler(
        agent_executor=executor,
        task_store=task_store,
        agent_card=agent_card,
        push_config_store=push_config_store,
    )

    # ``enable_v0_3_compat=True`` is load-bearing: it makes the server
    # dual-serve 0.3 and 1.0 wire formats on the same endpoint so existing
    # 0.3 buyer clients keep working unchanged. Do not disable.
    #
    # ``context_builder`` is the a2a-sdk seam for customising the
    # :class:`ServerCallContext` each handler receives. We thread it
    # through verbatim when supplied — bearer-token auth is wired
    # separately via :class:`A2ABearerAuthMiddleware` at the ASGI
    # layer (see ``serve.py:_wrap_a2a_with_auth``) because the v0.3
    # compat adapter swallows builder-raised ``HTTPException``s. The
    # builder kwarg remains for adopters customising the
    # ``ServerCallContext`` shape (e.g. surfacing additional
    # ``state`` fields from the request).
    jsonrpc_kwargs: dict[str, Any] = {
        "request_handler": request_handler,
        "rpc_url": "/",
        "enable_v0_3_compat": True,
    }
    if context_builder is not None:
        jsonrpc_kwargs["context_builder"] = context_builder
    routes = list(create_agent_card_routes(agent_card=agent_card)) + list(
        create_jsonrpc_routes(**jsonrpc_kwargs)
    )
    app = Starlette(routes=routes)

    # Startup log lives on the create_a2a_server path (symmetric with
    # MCP's _register_handler_tools). Moved out of
    # ADCPAgentExecutor.__init__ so per-test executor constructions
    # don't pollute caplog with repeated startup messages.
    from adcp.server.serve import _log_advertised_tools

    _log_advertised_tools(
        transport="a2a",
        handler=handler,
        advertise_all=advertise_all,
        registered=list(executor.supported_skills),
    )

    return app


def _test_controller_skills() -> list[pb.AgentSkill]:
    """Build A2A skill definition for comply_test_controller."""
    return [
        pb.AgentSkill(
            id="comply_test_controller",
            name="comply_test_controller",
            description="Compliance test controller. Sandbox only, not for production use.",
            tags=["adcp", "testing"],
        )
    ]
