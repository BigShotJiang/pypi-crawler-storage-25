# AbstractVideo

AbstractVideo is the reserved Python package for AI-video capabilities in the AbstractFramework
ecosystem.

The package is intentionally minimal today. It exists to reserve the `abstractvideo` PyPI
namespace and provide a stable home for future video-related work that fits alongside
`abstractframework`, `abstractcore`, and `abstractgateway`.

Current scope:

- no runtime dependencies
- no public API yet
- namespace reservation only

The broader name is deliberate: it can cover video generation, video understanding, and other
video-related capabilities without forcing `abstractvision` to carry the full scope.
