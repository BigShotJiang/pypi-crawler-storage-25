"""AbstractVideo namespace package.

This distribution intentionally stays minimal until video capabilities are added.
"""

__all__ = []
