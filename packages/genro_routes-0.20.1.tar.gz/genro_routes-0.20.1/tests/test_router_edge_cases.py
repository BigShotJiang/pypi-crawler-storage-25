# Copyright 2025 Softwell S.r.l.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tests for Router edge cases and plugin behavior."""

import pytest

from genro_routes import RoutingClass, Router, route
from genro_routes.plugins import pydantic as pyd_mod
from genro_routes.plugins._base_plugin import BasePlugin, MethodEntry  # Not public API


class SimplePlugin(BasePlugin):
    plugin_code = "simple"
    plugin_description = "Simple test plugin"

    def configure(self, **config):
        """Accept any configuration - storage is handled by wrapper."""
        pass  # Storage is handled by the wrapper

    def wrap_handler(self, router, entry, call_next):
        return call_next


def test_plugin_configure_and_configuration():
    class Host(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api").plug("simple")

    svc = Host()
    # Access plugin via public attribute
    plugin = svc.api.simple

    # Test configure() with flags
    plugin.configure(flags="enabled,,beta")
    assert svc.api.get_config("simple")["enabled"] is True
    plugin.configure(threshold=5)
    assert svc.api.get_config("simple")["threshold"] == 5
    # Test configuration() reads back
    assert plugin.configuration()["threshold"] == 5

    # Test per-handler config with _target
    plugin.configure(_target="foo", flags="enabled:off")
    assert svc.api.get_config("simple", "foo")["enabled"] is False
    plugin.configure(_target="foo", mode="strict")
    assert svc.api.get_config("simple", "foo")["mode"] == "strict"


def test_plugin_constructor_flags():
    class Host(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api").plug("simple", flags="beta:on,alpha:off")

    svc = Host()
    # Access plugin via public attribute
    plugin = svc.api.simple
    assert svc.api.get_config("simple")["beta"] is True
    assert svc.api.get_config("simple")["alpha"] is False
    # Per-handler config via configure()
    plugin.configure(_target="foo", enabled=False)
    assert svc.api.get_config("simple", "foo")["enabled"] is False


def ensure_plugin(plugin_cls: type) -> None:
    if plugin_cls.plugin_code not in Router.available_plugins():
        Router.register_plugin(plugin_cls)


ensure_plugin(SimplePlugin)


def test_plugin_configuration_has_defaults():
    """Test that plugin configuration returns default config when no custom config set."""

    class Host(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api").plug("simple")

    svc = Host()
    # Fresh plugin has default enabled=True
    assert svc.api.simple.configuration()["enabled"] is True


def test_plugin_missing_plugin_raises():
    """Test that accessing missing plugin raises AttributeError."""

    class Host(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api").plug("simple")

    svc = Host()
    # Missing plugin triggers AttributeError on public setters/getters
    with pytest.raises(AttributeError):
        svc.api.set_plugin_enabled("foo", "ghost", True)
    with pytest.raises(AttributeError):
        svc.api.get_runtime_data("foo", "ghost", "k")
    with pytest.raises(AttributeError):
        svc.api.set_runtime_data("foo", "ghost", "k", 1)
    with pytest.raises(AttributeError):
        svc.api.is_plugin_enabled("foo", "ghost")


def test_route_decorator_with_plugin_options():
    """Test that handlers with plugin options in decorator work correctly."""

    class Host(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api").plug("simple")

        @route("api", simple_flag=True, simple_mode="x")
        def run(self):
            return "ok"

    svc = Host()
    # Handler works and is registered
    assert svc.api.node("run")() == "ok"
    # Entry is registered in nodes()
    info = svc.api.nodes()
    assert "run" in info["entries"]


def test_plugin_configure_after_binding():
    """Test that configure() works after binding."""

    class Host(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api").plug("simple")

        @route("api")
        def hello(self):
            return "hi"

    svc = Host()
    # Apply options via configure() after binding
    svc.api.simple.configure(opt="via_configure")
    # Options from configure() call are accessible via get_config()
    assert svc.api.get_config("simple")["opt"] == "via_configure"
    # Handler still works
    assert svc.api.node("hello")() == "hi"


def test_route_decorator_metadata_preserved():
    """Test that custom metadata from route decorator is preserved."""

    class Host(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api", core_value=123)
        def hello(self):
            return "hi"

    svc = Host()
    # Verify handler works
    assert svc.api.node("hello")() == "hi"
    # Verify entry is registered
    info = svc.api.nodes()
    assert "hello" in info["entries"]


def test_router_auto_registers_marked_methods_and_validates_plugins():
    class Demo(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api", name="alias")
        def handle(self):
            return "ok"

    svc = Demo()
    assert svc.api.node("alias")() == "ok"
    ensure_plugin(SimplePlugin)
    svc.api.plug("simple")
    with pytest.raises(ValueError):
        svc.api.plug("missing")


def test_router_detects_handler_name_collision():
    class DuplicateService(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api", name="dup")
        def first(self):
            return "one"

        @route("api", name="dup")
        def second(self):
            return "two"

    svc = DuplicateService()
    with pytest.raises(ValueError):
        svc.api.nodes()  # Lazy binding triggers collision error


def test_iter_plugins_and_missing_attribute():
    class Service(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api").plug("simple")

        @route("api")
        def ping(self):
            return "pong"

    svc = Service()
    plugins = svc.api.iter_plugins()
    assert plugins and isinstance(plugins[0], SimplePlugin)
    with pytest.raises(AttributeError):
        _ = svc.api.missing_plugin  # type: ignore[attr-defined]


def test_attach_and_detach_instance_single_router_with_alias():
    class Child(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api")
        def ping(self):
            return "pong"

    class Parent(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.child = Child()

    parent = Parent()
    parent.attach_instance(parent.child, name="sales")
    # Verify child is accessible via nodes()
    info = parent.api.nodes()
    assert "sales" in info.get("routers", {})
    # Verify handler is accessible via path
    assert parent.api.node("sales/ping")() == "pong"

    parent.api.detach_instance(parent.child)
    # Verify child is no longer accessible
    info = parent.api.nodes()
    assert "sales" not in info.get("routers", {})


def test_attach_instance_multiple_routers_requires_mapping():
    class Child(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.admin = Router(self, name="admin")

    class Parent(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.child = Child()

    parent = Parent()
    # Auto-mapping when child has multiple routers requires explicit mapping
    parent.attach_instance(parent.child, router_api="api:api,admin:admin")
    # Verify both children are accessible via node()
    assert parent.api.node("api")
    assert parent.api.node("admin")


def test_attach_instance_name_collision():
    class Child(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

    class Parent(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.child1 = Child()
            self.child2 = Child()

    parent = Parent()
    parent.attach_instance(parent.child1, name="sales")
    with pytest.raises(ValueError):
        parent.attach_instance(parent.child2, name="sales")


def test_detach_instance_missing_alias():
    class Child(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.admin = Router(self, name="admin")

    parent = Child()
    parent.self_ref = parent
    parent.attach_instance(parent, router_api="api:self_api,admin:self_admin")
    # detach without explicit mapping removes both
    parent.api.detach_instance(parent)
    info = parent.api.nodes()
    assert info.get("routers", {}) == {}


def test_attach_instance_requires_routing_class():
    class Parent(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

    parent = Parent()
    with pytest.raises(TypeError):
        parent.attach_instance(object(), name="x")
    with pytest.raises(TypeError):
        parent.api.detach_instance(object())


def test_auto_detach_on_attribute_replacement():
    class Child(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api")
        def ping(self):
            return "pong"

    class Parent(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.child = Child()
            self.attach_instance(self.child, name="child")

    parent = Parent()
    # Verify child is attached via nodes()
    info = parent.api.nodes()
    assert "child" in info.get("routers", {})
    # Verify handler is accessible
    assert parent.api.node("child/ping")() == "pong"

    parent.child = None  # triggers auto-detach
    info = parent.api.nodes()
    assert "child" not in info.get("routers", {})
    assert parent.child is None


def test_attach_instance_rejects_other_parent_when_already_bound():
    class Child(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

    class Parent(RoutingClass):
        def __init__(self, label: str):
            self.label = label
            self.api = Router(self, name="api")
            self.child = Child()

    first = Parent("first")
    second = Parent("second")

    # Bind to first parent
    first.attach_instance(first.child, name="child")
    # Verify child is attached via node()
    assert first.api.node("child")

    # Attempt to bind same child to another parent should fail
    with pytest.raises(ValueError):
        second.attach_instance(first.child, name="child")


def test_routing_proxy_attach_instance_with_single_router():
    """Test routing.attach_instance delegates to default_router."""

    class Child(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api")
        def hello(self):
            return "hello from child"

    class Parent(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.child = Child()

    parent = Parent()
    # Use routing.attach_instance proxy (delegates to default router)
    parent.routing.attach_instance(parent.child, name="child")

    # Verify child is accessible
    assert parent.api.node("child/hello")() == "hello from child"


def test_routing_proxy_attach_instance_fails_with_multiple_routers():
    """Test routing.attach_instance raises RuntimeError with multiple routers."""

    class Child(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

    class Parent(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.admin = Router(self, name="admin")
            self.child = Child()

    parent = Parent()
    with pytest.raises(ValueError) as exc_info:
        parent.routing.attach_instance(parent.child, name="child")
    assert "exactly one router" in str(exc_info.value)
    assert "has 2" in str(exc_info.value)


def test_routing_proxy_attach_instance_with_router_name():
    """Test routing.attach_instance with explicit router_name."""

    class Child(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api")
        def hello(self):
            return "hello from child"

    class Parent(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.admin = Router(self, name="admin")
            self.child = Child()

    parent = Parent()
    # With multiple routers, use router_<name> kwarg to specify target
    parent.routing.attach_instance(parent.child, router_admin="api:child")

    # Verify child is accessible on the specified router
    assert parent.admin.node("child/hello")() == "hello from child"


def test_routing_proxy_attach_instance_invalid_router_name():
    """Test routing.attach_instance raises AttributeError for invalid router_name."""

    class Child(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

    class Parent(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.child = Child()

    parent = Parent()
    with pytest.raises(ValueError) as exc_info:
        parent.routing.attach_instance(parent.child, router_nonexistent="api:child")
    assert "No router named 'nonexistent'" in str(exc_info.value)


def test_routing_proxy_instance():
    """Test routing.instance() returns child RoutingClass instance."""

    class UsersModule(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api")
        def list(self):
            return "users:list"

    class OrdersModule(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api")
        def list(self):
            return "orders:list"

    class App(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.attach_instance(UsersModule(), name="users")
            self.attach_instance(OrdersModule(), name="orders")

    app = App()

    # Retrieve child instances via routing.instance()
    users = app.routing.instance("api/users")
    orders = app.routing.instance("api/orders")

    assert isinstance(users, UsersModule)
    assert isinstance(orders, OrdersModule)

    # Routing still works
    assert app.api.node("users/list")() == "users:list"
    assert app.api.node("orders/list")() == "orders:list"


def test_routing_proxy_instance_not_found():
    """Test routing.instance() raises KeyError for non-existent child."""

    class App(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

    app = App()
    with pytest.raises(KeyError):
        app.routing.instance("api/nonexistent")


def test_endpoint_id_basic_lookup():
    """Test @endpoint_id resolution via node()."""

    class Service(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api", endpoint_id="USR-001/1")
        def list_users(self):
            return "users"

        @route("api", endpoint_id="USR-002/1")
        def get_user(self, user_id):
            return f"user:{user_id}"

    svc = Service()

    # Resolve by endpoint_id
    node = svc.api.node("@USR-001/1")
    assert node() == "users"
    assert node.endpoint_id == "USR-001/1"

    # Resolve by path still works
    assert svc.api.node("list_users")() == "users"

    # endpoint_id with positional args via call
    node2 = svc.api.node("@USR-002/1")
    assert node2(42) == "user:42"


def test_endpoint_id_in_child_router():
    """Test @endpoint_id lookup across child routers."""

    class UsersModule(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api", endpoint_id="USR-LIST")
        def list(self):
            return "users:list"

    class App(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.attach_instance(UsersModule(), name="users")

    app = App()

    # Endpoint_id found in child
    node = app.api.node("@USR-LIST")
    assert node() == "users:list"
    assert node.path == "users/list"
    assert node.endpoint_id == "USR-LIST"


def test_endpoint_id_not_found():
    """Test @endpoint_id returns not_found for unknown id."""

    class Service(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api")
        def hello(self):
            return "hello"

    svc = Service()
    node = svc.api.node("@NONEXISTENT")
    assert node.error == "not_found"


def test_endpoint_id_accessible_from_path_node():
    """Test endpoint_id is accessible on nodes resolved by path."""

    class Service(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")

        @route("api", endpoint_id="MY-EP")
        def handler(self):
            return "ok"

        @route("api")
        def no_id(self):
            return "no id"

    svc = Service()

    # Has endpoint_id
    assert svc.api.node("handler").endpoint_id == "MY-EP"

    # No endpoint_id
    assert svc.api.node("no_id").endpoint_id is None


def test_branch_router_blocks_entries():
    """Branch routers cannot register handlers directly."""

    class Service(RoutingClass):
        def __init__(self):
            self.branch = Router(self, name="branch", branch=True)

    svc = Service()
    with pytest.raises(ValueError):
        svc.branch.add_entry("missing")


def test_parent_router_creates_hierarchy():
    """Test that parent_router parameter creates router hierarchies."""

    class Service(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api", branch=True)
            self.users = Router(self, name="users", parent_router=self.api)
            self.orders = Router(self, name="orders", parent_router=self.api)

        @route("users")
        def list_users(self):
            return ["alice", "bob"]

        @route("orders")
        def list_orders(self):
            return ["order1", "order2"]

    svc = Service()

    # Verify hierarchy structure via nodes()
    info = svc.api.nodes()
    assert "users" in info.get("routers", {})
    assert "orders" in info.get("routers", {})

    # Verify path resolution works
    assert svc.api.node("users/list_users")() == ["alice", "bob"]
    assert svc.api.node("orders/list_orders")() == ["order1", "order2"]


def test_parent_router_child_not_in_owner_routers():
    """Test that a router with parent_router is NOT registered in owner._routers.

    Closes #27: child routers created with parent_router are internal structure,
    not root routers. They must not appear in _routers, so default_router
    returns the single root and name= shortcut works in attach_instance.
    """

    class MyApp(RoutingClass):
        def __init__(self):
            self.main = Router(self, name="main", branch=True)
            self._meta = Router(self, name="_meta", parent_router=self.main)

        @route("_meta")
        def info(self):
            return "meta"

    app = MyApp()

    # _routers contains only the root
    assert list(app._routers.keys()) == ["main"]
    assert "_meta" not in app._routers

    # default_router works (single root)
    assert app.default_router is app.main

    # child is in parent's _children
    assert "_meta" in app.main._children

    # path resolution works through the hierarchy
    assert app.main.node("_meta/info")() == "meta"


def test_parent_router_requires_name():
    """Test that parent_router raises ValueError if child has no name."""

    class Owner(RoutingClass):
        pass

    owner = Owner()
    parent = Router(owner, name="parent", branch=True)

    with pytest.raises(ValueError, match="must have a name"):
        Router(owner, parent_router=parent)


def test_parent_router_detects_collision():
    """Test that parent_router raises ValueError on name collision."""

    class Owner(RoutingClass):
        pass

    owner = Owner()
    parent = Router(owner, name="parent", branch=True)
    Router(owner, name="child", parent_router=parent)

    with pytest.raises(ValueError, match="collision"):
        Router(owner, name="child", parent_router=parent)


def _make_router_for_plugin_test():
    """Create a minimal router for testing plugin behavior."""

    class Owner(RoutingClass):
        pass

    return Router(Owner(), name="test")


def test_base_plugin_default_hooks():
    router = _make_router_for_plugin_test()

    class TestPlugin(BasePlugin):
        plugin_code = "testplugin"
        plugin_description = "Test plugin"

        def configure(self, **config):
            pass  # Storage is handled by the wrapper

    Router.register_plugin(TestPlugin)
    router.plug("testplugin")
    plugin = router._plugins_by_name["testplugin"]
    entry = MethodEntry(name="foo", func=lambda: "ok", router=router, plugins=[])
    plugin.on_decore(router, entry.func, entry)
    assert plugin.wrap_handler(router, entry, lambda: "ok")() == "ok"


def test_logging_plugin_emit_without_handlers(capsys):
    router = _make_router_for_plugin_test()
    router.plug("logging")
    plugin = router._plugins_by_name["logging"]

    class DummyLogger:
        def has_handlers(self):
            return False

        # Compatibility alias
        hasHandlers = has_handlers  # noqa: N815

    plugin._logger = DummyLogger()  # type: ignore[attr-defined]
    plugin._emit("hello")
    captured = capsys.readouterr()
    assert captured.out == ""


def test_logging_plugin_emit_falls_back_to_print_when_log_enabled(capsys):
    router = _make_router_for_plugin_test()
    router.plug("logging")
    plugin = router._plugins_by_name["logging"]

    class DummyLogger:
        def has_handlers(self):
            return False

        # Compatibility alias
        hasHandlers = has_handlers  # noqa: N815

        def info(self, message):
            raise AssertionError("Should not be called")

    plugin._logger = DummyLogger()  # type: ignore[attr-defined]
    plugin._emit("hello", cfg={"log": True, "print": False})
    captured = capsys.readouterr()
    assert "hello" in captured.out


def test_pydantic_plugin_handles_hint_errors(monkeypatch):
    router = _make_router_for_plugin_test()
    router.plug("pydantic")
    plugin = router._plugins_by_name["pydantic"]
    entry = MethodEntry(name="foo", func=lambda **kw: "ok", router=router, plugins=[])

    def broken_get_type_hints(func):
        raise RuntimeError("boom")

    monkeypatch.setattr(pyd_mod, "get_type_hints", broken_get_type_hints)

    def handler():
        return "ok"

    plugin.on_decore(router, handler, entry)
    wrapper = plugin.wrap_handler(router, entry, lambda **kw: "ok")
    assert wrapper() == "ok"


def test_builtin_plugins_registered():
    available = Router.available_plugins()
    assert "logging" in available
    assert "pydantic" in available
    assert "auth" in available
    assert "env" in available
    assert "openapi" in available


def test_register_plugin_validates():
    with pytest.raises(TypeError):
        Router.register_plugin(object)  # type: ignore[arg-type]

    class CustomPlugin(BasePlugin):
        plugin_code = "custom_edge"
        plugin_description = "Custom test plugin"

    Router.register_plugin(CustomPlugin)

    class OtherPlugin(BasePlugin):
        plugin_code = "custom_edge"  # same code, different class
        plugin_description = "Other test plugin"

    with pytest.raises(ValueError):
        Router.register_plugin(OtherPlugin)


def test_router_get_config_paths():
    class CfgPlugin(BasePlugin):
        plugin_code = "cfgplug"
        plugin_description = "Config test plugin"

        def configure(self, **config):
            pass  # Storage is handled by the wrapper

    Router.register_plugin(CfgPlugin)

    class Service(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api").plug("cfgplug", mode="x")
            # Per-handler config via configure()
            self.api._plugins_by_name["cfgplug"].configure(_target="hello", trace=True)

        @route("api")
        def hello(self):
            return "ok"

    svc = Service()
    assert svc.api.get_config("cfgplug")["mode"] == "x"
    merged = svc.api.get_config("cfgplug", "hello")
    assert merged["mode"] == "x" and merged["trace"] is True
    with pytest.raises(AttributeError):
        svc.api.get_config("missing")


def test_routed_proxy_get_router_handles_dotted_path():
    class Leaf(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="leaf")

    class Parent(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api")
            self.child = Leaf()
            self.api._children["child"] = self.child.api  # direct attach for test

    svc = Parent()
    router = svc.routing.get_router("api/child")
    assert router.name == "leaf"


def test_routed_configure_updates_plugins_global_and_local():
    ensure_plugin(SimplePlugin)

    class ConfService(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api").plug("simple")

        @route("api")
        def foo(self):
            return "foo"

        @route("api")
        def bar(self):
            return "bar"

    svc = ConfService()
    svc.api.nodes()  # Trigger lazy binding before configure
    svc.routing.configure("api:simple/_all_", threshold=10)
    assert svc.api.simple.configuration()["threshold"] == 10

    svc.routing.configure("api:simple/foo", enabled=False)
    assert svc.api.simple.configuration("foo")["enabled"] is False

    svc.routing.configure("api:simple/b*", mode="strict")
    assert svc.api.simple.configuration("bar")["mode"] == "strict"

    payload = [
        {"target": "api:simple/_all_", "flags": "trace"},
        {"target": "api:simple/foo", "limit": 5},
    ]
    result = svc.routing.configure(payload)
    assert len(result) == 2
    assert svc.api.simple.configuration("foo")["limit"] == 5


def test_routed_configure_question_lists_tree():
    ensure_plugin(SimplePlugin)

    class Root(RoutingClass):
        def __init__(self):
            self.api = Router(self, name="api").plug("simple")

        @route("api")
        def root_ping(self):
            return "root"

    svc = Root()
    info = svc.routing.configure("?")
    assert "api" in info
    assert info["api"]["plugins"]
    assert info["api"]["routers"] == {}
