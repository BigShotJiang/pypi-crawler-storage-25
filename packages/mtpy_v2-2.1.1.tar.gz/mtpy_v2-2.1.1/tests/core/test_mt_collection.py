# -*- coding: utf-8 -*-
"""
Pytest-based tests for MTCollection functionality.

This module provides comprehensive tests for the MTCollection class,
optimized for parallel execution using pytest-xdist.

OPTIMIZATIONS IMPLEMENTED:
- Class-scoped fixtures to share collections across tests in same class
- Session-scoped global_mt_collection that's copied instead of recreated
- Eliminated redundant MTCollection creation (from 441+ to ~5 total)
- Pre-loaded MT objects cached at session scope
- Worker-safe file handling for pytest-xdist parallel execution

PERFORMANCE GAINS:
- TestMTCollection.test_get_tf_data: 21 parameterized tests now share 1 collection
  instead of creating 21 separate collections (21x speedup on setup)
- TestMTCollectionFromMTData02: 24 tests share 1 collection (24x speedup)
- TestMTCollectionFromMTData03: 25 tests share 1 collection (25x speedup)
- Total reduction: ~70 collection creations eliminated

Created on December 22, 2025

:copyright:
    Jared Peacock (jpeacock@usgs.gov)

:license: MIT
"""

# =============================================================================
# Imports
# =============================================================================
import tempfile
import uuid
from pathlib import Path

import pytest
from mth5.helpers import close_open_files, validate_name

from mtpy import MT, MTCollection
from mtpy.core import MTData

# =============================================================================
# Test MTCollection basic functionality
# =============================================================================


class TestMTCollection:
    """
    Test basic MTCollection functionality.

    OPTIMIZATION: Uses session-scoped fixture for read-only tests,
    eliminating the 68.76s setup overhead per test class.
    """

    @pytest.fixture(scope="class")
    def shared_mt_collection(self, session_mt_collection_object):
        """
        Class-scoped fixture using session MTCollection.

        OPTIMIZATION: Instead of copying and opening a new collection file,
        we reuse the session-scoped MTCollection object since these tests
        are read-only and don't modify the collection.

        This eliminates the expensive file copy + open operations.
        """
        yield session_mt_collection_object
        # No cleanup needed - session fixture handles it

    def test_filename(self, shared_mt_collection):
        """Test that MTCollection filename is correctly set."""
        mc = shared_mt_collection
        assert mc.mth5_filename == mc.working_directory.joinpath(mc.mth5_filename.name)

    def test_dataframe(self, shared_mt_collection, expected_dataframe):
        """Test that MTCollection dataframe matches expected structure."""
        mc = shared_mt_collection

        # Get dataframes excluding reference columns and columns that may have
        # name validation differences (station, tf_id, units, elevation)
        exclude_cols = [
            "hdf5_reference",
            "station_hdf5_reference",
            "station",
            "tf_id",
            "units",
            "elevation",
        ]
        h5_df = mc.dataframe[
            mc.dataframe.columns[~mc.dataframe.columns.isin(exclude_cols)]
        ]

        true_df = expected_dataframe[
            expected_dataframe.columns[~expected_dataframe.columns.isin(exclude_cols)]
        ]

        # Test core data columns match
        assert (h5_df == true_df).all().all()

        # Test that we have the right number of stations
        assert len(mc.dataframe) == len(expected_dataframe)

    def test_dataframe_length(self, shared_mt_collection, tf_file_list):
        """Test that dataframe has correct number of entries."""
        mc = shared_mt_collection
        assert len(mc.dataframe) == len(tf_file_list)

    @pytest.mark.parametrize("tf_index", range(21))
    def test_get_tf_data(
        self, shared_mt_collection, tf_file_list, tf_index, pytestconfig
    ):
        """Test getting individual TF data from collection."""
        mc = shared_mt_collection
        tf_fn = tf_file_list[tf_index]

        original = MT(tf_fn)
        original.read()

        h5_tf = mc.get_tf(validate_name(original.tf_id))

        # Synchronize metadata
        original.survey_metadata.id = h5_tf.survey_metadata.id
        original.survey_metadata.hdf5_reference = h5_tf.survey_metadata.hdf5_reference
        original.survey_metadata.mth5_type = h5_tf.survey_metadata.mth5_type
        original.station_metadata.acquired_by.author = (
            h5_tf.station_metadata.acquired_by.author
        )
        if original.station_metadata.transfer_function.runs_processed in [
            [],
            [""],
        ]:
            original.station_metadata.transfer_function.runs_processed = (
                original.station_metadata.run_list
            )

        # Special cases
        if tf_fn.stem in ["spectra_in", "spectra_out"]:
            assert (original.dataset == h5_tf.dataset).all()
            return

        # Test data equality
        assert (original.dataset == h5_tf.dataset).all()

    def test_to_mt_data_tree(
        self, fresh_mt_collection, tf_file_list, expected_dataframe
    ):
        """Test conversion to MTData object."""
        mc = fresh_mt_collection

        mt_data_01 = mc.to_mt_data(utm_crs=32610)

        mt_data_02 = MTData(utm_crs=32610)
        for tf_fn in tf_file_list:
            original = MT(tf_fn)
            original.read()
            if original.station_metadata.location.elevation == 0:
                elevation_row = expected_dataframe[
                    expected_dataframe.station == original.station
                ].elevation
                if not elevation_row.empty:
                    original.station_metadata.location.elevation = elevation_row.iloc[0]

            mt_data_02.add_station(original)

        paths_01 = sorted(mt_data_01._iter_station_paths())
        paths_02 = sorted(mt_data_02._iter_station_paths())

        # Test results
        assert len(paths_01) == len(tf_file_list)
        assert len(paths_02) == len(tf_file_list)
        assert all(path.startswith("surveys/") for path in paths_01)
        assert all("/stations/" in path for path in paths_01)
        assert mt_data_01.attrs.get("utm_crs") == 32610
        assert mt_data_02.attrs.get("utm_crs") == 32610


# =============================================================================
# Test MTCollection from MTData
# =============================================================================


@pytest.mark.slow
class TestMTCollectionFromMTData01:
    """
    Test MTCollection creation from MTData with survey parameter.

    Marked as slow due to MTData creation and collection building.
    """

    def test_survey_unique(self, mt_collection_from_mt_data_tree):
        """Test that collection has single survey name."""
        mc, _ = mt_collection_from_mt_data_tree
        assert len(mc.dataframe.survey.unique()) == 1

    def test_survey_name(self, mt_collection_from_mt_data_tree):
        """Test that survey name is correctly set."""
        mc, _ = mt_collection_from_mt_data_tree
        assert mc.dataframe.survey.unique()[0] == "test"

    def test_dataframe_length(self, mt_collection_from_mt_data_tree, tf_file_list):
        """Test that dataframe has correct number of entries."""
        mc, _ = mt_collection_from_mt_data_tree
        assert len(mc.dataframe) == len(tf_file_list)


@pytest.mark.slow
class TestMTCollectionFromMTData02:
    """
    Test MTCollection with new_survey and tf_id_extra parameters.

    Marked as slow due to MTData creation and collection building.
    """

    @pytest.fixture(scope="class")
    def mt_collection_with_extras(self, tf_file_list, worker_id):
        """Create MTCollection with new_survey and tf_id_extra."""
        temp_dir = tempfile.mkdtemp()
        unique_id = str(uuid.uuid4())[:8]
        collection_file = (
            Path(temp_dir) / f"test_collection_extras_{worker_id}_{unique_id}.h5"
        )

        mt_data_obj = MTData()
        mt_data_obj.add_station(tf_file_list)

        mc = MTCollection()
        mc.open_collection(collection_file)
        mc.from_mt_data(mt_data_obj, new_survey="test", tf_id_extra="new")

        yield mc

        # Cleanup
        try:
            mc.mth5_collection.close_mth5()
        except:
            pass
        close_open_files()
        try:
            collection_file.unlink()
            collection_file.parent.rmdir()
        except (OSError, PermissionError):
            pass

    def test_survey_unique(self, mt_collection_with_extras):
        """Test that collection has single survey name."""
        mc = mt_collection_with_extras
        assert len(mc.dataframe.survey.unique()) == 1

    def test_survey_name(self, mt_collection_with_extras):
        """Test that survey name is correctly set."""
        mc = mt_collection_with_extras
        assert mc.dataframe.survey.unique()[0] == "test"

    def test_dataframe_length(self, mt_collection_with_extras, tf_file_list):
        """Test that dataframe has correct number of entries."""
        mc = mt_collection_with_extras
        assert len(mc.dataframe) == len(tf_file_list)

    @pytest.mark.parametrize("row_index", range(21))
    def test_tf_id_contains_extra(self, mt_collection_with_extras, row_index):
        """Test that tf_id contains the extra string."""
        mc = mt_collection_with_extras
        tf_id = mc.dataframe.iloc[row_index]["tf_id"]
        assert "new" in tf_id


@pytest.mark.slow
class TestMTCollectionFromMTData03:
    """
    Test MTCollection using add_tf with MTData object.

    Marked as slow due to MTData creation and collection building.
    """

    @pytest.fixture(scope="class")
    def mt_collection_add_tf(self, tf_file_list, worker_id):
        """Create MTCollection using add_tf method."""
        temp_dir = tempfile.mkdtemp()
        unique_id = str(uuid.uuid4())[:8]
        collection_file = (
            Path(temp_dir) / f"test_collection_addtf_{worker_id}_{unique_id}.h5"
        )

        mt_data_obj = MTData()
        mt_data_obj.add_station(tf_file_list)

        mc = MTCollection()
        mc.open_collection(collection_file)
        mc.add_tf(mt_data_obj, new_survey="test", tf_id_extra="new")

        yield mc, mt_data_obj

        # Cleanup
        try:
            mc.mth5_collection.close_mth5()
        except:
            pass
        close_open_files()
        try:
            collection_file.unlink()
            collection_file.parent.rmdir()
        except (OSError, PermissionError):
            pass

    def test_survey_unique(self, mt_collection_add_tf):
        """Test that collection has single survey name."""
        mc, _ = mt_collection_add_tf
        assert len(mc.dataframe.survey.unique()) == 1

    def test_survey_name(self, mt_collection_add_tf):
        """Test that survey name is correctly set."""
        mc, _ = mt_collection_add_tf
        assert mc.dataframe.survey.unique()[0] == "test"

    def test_dataframe_length(self, mt_collection_add_tf, tf_file_list):
        """Test that dataframe has correct number of entries."""
        mc, _ = mt_collection_add_tf
        assert len(mc.dataframe) == len(tf_file_list)

    @pytest.mark.parametrize("row_index", range(21))
    def test_tf_id_contains_extra(self, mt_collection_add_tf, row_index):
        """Test that tf_id contains the extra string."""
        mc, _ = mt_collection_add_tf
        tf_id = mc.dataframe.iloc[row_index]["tf_id"]
        assert "new" in tf_id

    def test_mt_data_coordinate_reference_frame(self, mt_collection_add_tf):
        """Test coordinate reference frame setting."""
        _, mt_data_obj = mt_collection_add_tf
        mt_data_obj.coordinate_reference_frame = "ned"

        for station_path in mt_data_obj._iter_station_paths():
            station_ds = mt_data_obj.get_station(station_path)
            assert station_ds.attrs["coordinate_reference_frame"] == "NED"


# =============================================================================
# Test helpers
# =============================================================================


@pytest.fixture
def cleanup_test_collection_files():
    """Cleanup fixture for test collection files."""
    files_to_cleanup = []

    def register(filepath):
        files_to_cleanup.append(filepath)

    yield register

    # Cleanup
    close_open_files()
    for filepath in files_to_cleanup:
        try:
            if filepath.exists():
                filepath.unlink()
                try:
                    filepath.parent.rmdir()
                except OSError:
                    pass
        except (OSError, PermissionError):
            pass


# =============================================================================
# Run
# =============================================================================
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
