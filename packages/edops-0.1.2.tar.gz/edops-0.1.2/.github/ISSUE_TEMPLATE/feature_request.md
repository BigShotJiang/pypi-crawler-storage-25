---
name: Feature request
about: Suggest a new command, flag, or behaviour
labels: enhancement
---

**What problem does this solve?**

**Proposed solution:**

**Alternatives considered:**

**Elastic Stack version this relates to (if applicable):**
