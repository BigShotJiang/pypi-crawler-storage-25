---
name: Bug report
about: Something isn't working as expected
labels: bug
---

**Command run** (sanitise credentials):
```
edr --verbose <command>
```

**Expected behaviour:**

**Actual behaviour / error output:**

**Environment:**
- elastic-edr version (`pip show elastic-edr`):
- Elastic Stack version:
- OS:
- Python version (`python --version`):
