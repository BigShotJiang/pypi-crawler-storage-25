# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.2] - 2026-05-05

### Added
- `session-export` command (replaces `session-io`) — exports terminal I/O for an alert's session to an asciicast v3 (`.cast`) file; output filename includes the alert ID and an optional incident label from the active console comment (e.g. `tty_INC-1231-7864e66fd2e47e92.cast`)
- `--gif` / `--mp4` flags on `session-export` — convert the cast file to GIF (via `agg`) or MP4 (via `agg` + `ffmpeg`) immediately after export, with step labels `[1/2]` / `[1/3]` etc.
- `--force` flag on `session-export` — overwrite an existing output file; also passes `-y` to `ffmpeg` when `--mp4` is used
- `--no-intro` flag on `session-export` — skip the animated intro (on by default)
- Animated 2-second intro prepended to every exported cast file: box-drawing frame with product name, session description, alert metadata (ID, rule, host, user, process, time, note), and right-aligned `created with renini/edops (version)` attribution; line-by-line reveal at 65 ms per line
- `session-play` command — replay a session directly in the terminal from an alert ID or `.cast` file; includes a safety prompt (bypass with `-y`) and post-play hints
- Alert summary header printed before export/play: rule name, host, user, process, and timestamp
- `--no-intro` option in the interactive console for `session-export`
- Plain-text scrolling: large single-buffer events (≥ 800 bytes with newlines) are split at line boundaries with 15 ms intervals to reproduce the scrolling effect seen in Kibana Session View
- `event.sequence` used as a tiebreaker when sorting same-millisecond I/O events

### Changed
- `session-io` renamed to `session-export`; `session-view` tip updated to reference both `session-export` and `session-play`
- `session-view` tip reformatted for clarity

### Fixed
- Alt-screen animation events (e.g. `vim`, `sl`) split into 200-byte chunks at escape boundaries so the player shows motion instead of one instantaneous frame

## [0.1.1] - 2026-05-03

### Added
- Global `--url`, `--api-key`, `--username`, `--password` flags on every command — override config, `.env`, and environment variables for a single invocation; `--api-key` and `--password` accept a value directly or omit the value to be prompted with hidden input
- Auto-prompt for missing credentials: when no URL or credentials are found from any source, edops asks interactively before running the command
- `.env` file support — place a `.env` in the working directory to set `EDOPS_KIBANA_*` variables; priority is shell env > `.env` > `config.json`
- `config set --api-key` and `config set --password` now support hidden-input prompts (pass the flag without a value)
- `session-view` command — show process tree and captured terminal I/O for an alert, with the alerted process highlighted and a clickable Kibana alert URL
- `alerts` now works without an endpoint ID: defaults to last 24 h when no endpoint is given
- `alerts --since` option to set a custom lookback window (e.g. `24h`, `7d`, `30m`)
- Alert rows in `alerts` output are numbered (`#`) and each number is a clickable hyperlink to the Kibana alert redirect URL when `url` is configured; full alert IDs are printed below the table for easy copy-paste
- `kibana.alert.reason` column in `alerts` output (wraps to multiple lines instead of truncating)
- Indicator column in `alerts` now uses ECS field names (`process.name`, `file.name`, `file.hash.sha256`, `source.ip`, `destination.ip`) with one indicator per line

### Fixed
- `processes` command: kernel processes (e.g. `[kworker/1:0-events_freezable]`) were shown with an empty COMMAND column due to Rich treating `[...]` as markup — now rendered correctly
- `console` banner: no longer shows loopback (`127.0.0.1` / `::1`) or link-local addresses as the endpoint IP
- `metadata` panel title is now left-aligned

## [0.1.0] - 2026-04-28

### Added
- `edr config set / show` — connection configuration stored in `~/.config/elastic-edr/config.json`
- `edr isolate / unisolate` — network isolation with optional `--wait` polling
- `edr processes` — list running processes on an endpoint
- `edr kill-process / suspend-process` — process termination and suspension by PID or entity ID
- `edr get-file` — retrieve a file from an endpoint as a password-protected zip
- `edr execute` — execute a shell command and capture stdout/stderr
- `edr upload` — upload a local file to an endpoint
- `edr scan` — scan a file or directory
- `edr memory-dump` — full kernel or process memory dump (Windows)
- `edr status` — inspect a response action by ID
- `edr actions` — list recent response actions with filtering
- `edr alerts` — query Elastic Security detection alerts per endpoint
- `edr agents` — list Fleet agents, filter by hostname prefix, IP, or MAC
- `edr metadata` — display OS, agent version, policy, capabilities, isolation state
- `edr osquery run / results / saved-queries` — osquery live query support
- `edr shell` — semi-interactive shell via wrapped execute actions
- `edr console` — interactive console scoped to a single endpoint with tab-completion
- API key and username/password authentication
- `--comment` / ticket traceability on all response actions
- `--json` output flag on every command
- `--verbose` global flag for HTTP request/response logging
- Environment variable overrides for all configuration fields
