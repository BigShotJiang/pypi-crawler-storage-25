"""Tests for pure helper functions — no network required."""
import io
import zipfile

import pytest

from edops.cli import (
    _af,
    _build_fleet_kuery,
    _mac_to_colon,
    _mac_to_dash,
    _parse_zip_output,
    _sanitize_prefix,
)


# ── _af ───────────────────────────────────────────────────────────────────────

class TestAf:
    def test_nested_access(self):
        src = {"kibana": {"alert": {"severity": "high"}}}
        assert _af(src, "kibana", "alert", "severity") == "high"

    def test_flat_key_fallback(self):
        # API sometimes stores fields as flat dot-notation keys
        src = {"kibana.alert.severity": "medium"}
        assert _af(src, "kibana", "alert", "severity") == "medium"

    def test_nested_takes_priority_over_flat(self):
        src = {
            "kibana": {"alert": {"severity": "high"}},
            "kibana.alert.severity": "low",
        }
        assert _af(src, "kibana", "alert", "severity") == "high"

    def test_missing_field_returns_empty(self):
        assert _af({}, "kibana", "alert", "severity") == ""

    def test_partial_path_missing(self):
        src = {"kibana": {"other": "value"}}
        assert _af(src, "kibana", "alert", "severity") == ""

    def test_non_scalar_nested_returns_empty(self):
        # dict values are not returned — only scalars
        src = {"kibana": {"alert": {"rule": {"name": "test"}}}}
        assert _af(src, "kibana", "alert") == ""

    def test_none_nested_value_returns_empty(self):
        src = {"kibana": None}
        assert _af(src, "kibana", "alert", "severity") == ""

    def test_numeric_value_converted_to_str(self):
        src = {"process": {"pid": 1234}}
        assert _af(src, "process", "pid") == "1234"

    def test_single_key(self):
        assert _af({"status": "open"}, "status") == "open"


# ── _build_fleet_kuery ────────────────────────────────────────────────────────

class TestBuildFleetKuery:
    def test_hostname_has_wildcard_suffix(self):
        q = _build_fleet_kuery("workstation-01")
        assert 'local_metadata.host.hostname:"workstation-01*"' in q

    def test_trailing_wildcard_stripped_before_appending(self):
        # User-supplied trailing * should not result in double wildcard
        q = _build_fleet_kuery("workstation-01*")
        assert 'local_metadata.host.hostname:"workstation-01*"' in q
        assert "workstation-01**" not in q

    def test_ip_clause_present(self):
        q = _build_fleet_kuery("10.0.1.42")
        assert 'local_metadata.host.ip:"10.0.1.42"' in q

    def test_mac_both_formats_present(self):
        q = _build_fleet_kuery("aa:bb:cc:dd:ee:ff")
        assert "aa:bb:cc:dd:ee:ff" in q
        assert "aa-bb-cc-dd-ee-ff" in q

    def test_mac_dash_input_normalised(self):
        q = _build_fleet_kuery("aa-bb-cc-dd-ee-ff")
        assert "aa:bb:cc:dd:ee:ff" in q
        assert "aa-bb-cc-dd-ee-ff" in q

    def test_agent_id_clause_present(self):
        q = _build_fleet_kuery("abc-123")
        assert 'local_metadata.elastic.agent.id:"abc-123"' in q

    def test_result_is_parenthesised_or_chain(self):
        q = _build_fleet_kuery("host-01")
        assert q.startswith("(")
        assert q.endswith(")")
        assert " OR " in q


# ── _sanitize_prefix ──────────────────────────────────────────────────────────

class TestSanitizePrefix:
    def test_plain_ticket(self):
        assert _sanitize_prefix("INC-1234") == "INC-1234"

    def test_spaces_become_underscores(self):
        assert _sanitize_prefix("INC 1234") == "INC_1234"

    def test_leading_trailing_whitespace_stripped(self):
        assert _sanitize_prefix("  INC-1234  ") == "INC-1234"

    def test_special_chars_replaced(self):
        result = _sanitize_prefix("INC/1234\\test")
        assert "/" not in result
        assert "\\" not in result

    def test_max_length_50(self):
        assert len(_sanitize_prefix("x" * 100)) <= 50

    def test_empty_returns_empty(self):
        assert _sanitize_prefix("") == ""

    def test_multiple_consecutive_special_chars_collapsed(self):
        result = _sanitize_prefix("INC///1234")
        assert "__" not in result


# ── _mac_to_colon / _mac_to_dash ─────────────────────────────────────────────

class TestMacNormalise:
    def test_dash_to_colon(self):
        assert _mac_to_colon("aa-bb-cc-dd-ee-ff") == "aa:bb:cc:dd:ee:ff"

    def test_dot_to_colon(self):
        assert _mac_to_colon("aabb.ccdd.eeff") == "aabb:ccdd:eeff"

    def test_colon_to_dash(self):
        assert _mac_to_dash("aa:bb:cc:dd:ee:ff") == "aa-bb-cc-dd-ee-ff"

    def test_uppercase_lowercased(self):
        assert _mac_to_colon("AA-BB-CC-DD-EE-FF") == "aa:bb:cc:dd:ee:ff"
        assert _mac_to_dash("AA:BB:CC:DD:EE:FF") == "aa-bb-cc-dd-ee-ff"


# ── _parse_zip_output ─────────────────────────────────────────────────────────

def _make_zip(files: dict[str, str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, content in files.items():
            zf.setpassword(b"elastic")
            zf.writestr(
                zipfile.ZipInfo(name),
                content.encode(),
            )
    return buf.getvalue()


def _make_zip_encrypted(files: dict[str, str]) -> bytes:
    """Create a zip encrypted with the 'elastic' password."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name, content in files.items():
            data = content.encode()
            info = zipfile.ZipInfo(name)
            zf.writestr(info, data)
    return buf.getvalue()


class TestParseZipOutput:
    def test_stdout_only(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("stdout", "hello world\n")
        stdout, stderr, rc = _parse_zip_output(buf.getvalue())
        assert stdout == "hello world\n"
        assert stderr == ""
        assert rc is None

    def test_stdout_and_stderr(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("stdout", "output\n")
            zf.writestr("stderr", "warning\n")
        stdout, stderr, rc = _parse_zip_output(buf.getvalue())
        assert stdout == "output\n"
        assert stderr == "warning\n"

    def test_return_code_extracted(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("stdout", "done\n")
            zf.writestr("return_code", "0")
        _, _, rc = _parse_zip_output(buf.getvalue())
        assert rc == 0

    def test_nonzero_return_code(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("stdout", "")
            zf.writestr("return_code", "127")
        _, _, rc = _parse_zip_output(buf.getvalue())
        assert rc == 127

    def test_exit_code_alias(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("stdout", "x")
            zf.writestr("exit_code", "1")
        _, _, rc = _parse_zip_output(buf.getvalue())
        assert rc == 1

    def test_bad_zip_falls_back_to_raw_bytes(self):
        raw = b"not a zip file, just raw text output"
        stdout, stderr, rc = _parse_zip_output(raw)
        assert "raw text output" in stdout
        assert stderr == ""
        assert rc is None

    def test_stdout_txt_filename_variant(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("stdout.txt", "hello\n")
        stdout, _, _ = _parse_zip_output(buf.getvalue())
        assert stdout == "hello\n"
