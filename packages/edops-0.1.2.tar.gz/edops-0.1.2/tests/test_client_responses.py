"""Fixture-based tests: real API response shapes replayed through respx mocks.

Each fixture in tests/fixtures/ was captured from a live Elastic Stack 9.3.3
instance and sanitised (real hostnames, IPs, UUIDs replaced with fakes).
These tests verify that the client correctly parses the shapes Elastic actually
returns — not shapes we invented.
"""
import json

import httpx
import pytest
import respx

from tests.conftest import AGENT_ID, ACTION_ID, BASE_URL, load_fixture

# ── helpers ───────────────────────────────────────────────────────────────────

def _url(path: str) -> str:
    return f"{BASE_URL}{path}"


# ── GET /api/status ───────────────────────────────────────────────────────────

@respx.mock
def test_kibana_status(kibana_client):
    payload = load_fixture("kibana_status.json")
    respx.get(_url("/api/status")).mock(return_value=httpx.Response(200, json=payload))

    result = kibana_client.get_kibana_status()

    assert result["version"]["number"] == "9.3.3"
    assert result["status"]["overall"]["level"] == "available"


# ── GET /api/endpoint/metadata ────────────────────────────────────────────────

@respx.mock
def test_list_endpoints_returns_data_array(kibana_client):
    payload = load_fixture("list_endpoints.json")
    respx.get(_url("/api/endpoint/metadata")).mock(return_value=httpx.Response(200, json=payload))

    result = kibana_client.list_endpoints()

    assert isinstance(result["data"], list)
    assert result["total"] == 1
    assert result["data"][0]["metadata"]["agent"]["id"] == AGENT_ID
    assert result["data"][0]["host_status"] == "healthy"


@respx.mock
def test_get_endpoint_metadata(kibana_client):
    payload = load_fixture("endpoint_metadata.json")
    respx.get(_url(f"/api/endpoint/metadata/{AGENT_ID}")).mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = kibana_client.get_endpoint_metadata(AGENT_ID)

    meta = result["metadata"]
    assert meta["agent"]["id"] == AGENT_ID
    assert meta["host"]["hostname"] == "workstation-lin-01"
    assert meta["host"]["os"]["full"] == "Debian 13.4"
    assert "kill_process" in meta["Endpoint"]["capabilities"]
    assert meta["Endpoint"]["state"]["isolation"] is False
    assert result["host_status"] == "healthy"
    assert result["last_checkin"] == "2026-04-28T13:07:14Z"


# ── GET /api/endpoint/action ──────────────────────────────────────────────────

@respx.mock
def test_list_actions(kibana_client):
    payload = load_fixture("list_actions.json")
    respx.get(_url("/api/endpoint/action")).mock(return_value=httpx.Response(200, json=payload))

    result = kibana_client.list_actions()

    items = result["data"]
    assert len(items) == 2
    first = items[0]
    assert first["id"] == ACTION_ID
    assert first["command"] == "execute"
    assert first["status"] == "successful"
    assert first["createdBy"] == "elastic"
    assert AGENT_ID in first["agents"]


# ── GET /api/endpoint/action/{id} ─────────────────────────────────────────────

@respx.mock
def test_action_detail_execute(kibana_client):
    payload = load_fixture("action_detail_execute.json")
    respx.get(_url(f"/api/endpoint/action/{ACTION_ID}")).mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = kibana_client.get_action(ACTION_ID)

    data = result["data"]
    assert data["id"] == ACTION_ID
    assert data["command"] == "execute"
    assert data["status"] == "successful"
    assert data["wasSuccessful"] is True

    ep_out = data["outputs"][AGENT_ID]
    assert ep_out["type"] == "json"
    assert ep_out["content"]["stdout"] == "workstation-lin-01\n"
    assert ep_out["content"]["return_code"] == 0
    assert ep_out["content"]["stderr"] == ""

    agent_state = data["agentState"][AGENT_ID]
    assert agent_state["isCompleted"] is True
    assert agent_state["wasSuccessful"] is True


@respx.mock
def test_running_procs_action(kibana_client):
    payload = load_fixture("running_procs_action.json")
    action_id = "bbbb0003-0000-0000-0000-000000000003"
    respx.get(_url(f"/api/endpoint/action/{action_id}")).mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = kibana_client.get_action(action_id)

    entries = result["data"]["outputs"][AGENT_ID]["content"]["entries"]
    assert len(entries) == 4
    pids = [e["pid"] for e in entries]
    assert 1 in pids
    commands = [e["command"] for e in entries]
    assert any("elastic-endpoint" in c for c in commands)


# ── POST /api/detection_engine/signals/search ─────────────────────────────────

@respx.mock
def test_alerts_empty(kibana_client):
    payload = load_fixture("alerts_empty.json")
    respx.post(_url("/api/detection_engine/signals/search")).mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = kibana_client.search_alerts(AGENT_ID)

    assert result["hits"]["total"]["value"] == 0
    assert result["hits"]["hits"] == []


@respx.mock
def test_alerts_with_hits(kibana_client):
    payload = load_fixture("alerts_with_hits.json")
    respx.post(_url("/api/detection_engine/signals/search")).mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = kibana_client.search_alerts(AGENT_ID)

    hits = result["hits"]["hits"]
    assert result["hits"]["total"]["value"] == 2
    assert len(hits) == 2

    first = hits[0]["_source"]
    # verify nested alert fields are present — these drive _print_alerts/_af logic
    assert first["kibana"]["alert"]["severity"] == "high"
    assert first["kibana"]["alert"]["rule"]["name"] == "Suspicious Process Execution via WMI"
    assert first["kibana"]["alert"]["workflow_status"] == "open"
    assert first["process"]["name"] == "cmd.exe"

    second = hits[1]["_source"]
    assert second["kibana"]["alert"]["severity"] == "medium"
    assert second["file"]["name"] == "malware.exe"
    assert second["source"]["ip"] == "10.0.1.99"
    assert second["destination"]["ip"] == "198.51.100.42"


# ── GET /api/fleet/agents ─────────────────────────────────────────────────────

@respx.mock
def test_fleet_agents(kibana_client):
    payload = load_fixture("fleet_agents.json")
    respx.get(_url("/api/fleet/agents")).mock(return_value=httpx.Response(200, json=payload))

    result = kibana_client.search_fleet_agents(kuery='local_metadata.host.hostname:"workstation*"')

    items = result["items"]
    assert len(items) == 2
    assert result["total"] == 2

    linux_agent = items[0]
    assert linux_agent["id"] == AGENT_ID
    assert linux_agent["status"] == "online"
    lm = linux_agent["local_metadata"]
    assert lm["host"]["hostname"] == "workstation-lin-01"
    assert lm["os"]["name"] == "Debian GNU/Linux"
    assert "10.0.1.11/24" in lm["host"]["ip"]

    win_agent = items[1]
    assert win_agent["local_metadata"]["os"]["family"] == "windows"
    assert win_agent["local_metadata"]["host"]["hostname"] == "workstation-win-01"


# ── GET /api/osquery/saved_queries ────────────────────────────────────────────

@respx.mock
def test_osquery_saved_queries(kibana_client):
    payload = load_fixture("osquery_saved.json")
    respx.get(_url("/api/osquery/saved_queries")).mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = kibana_client.osquery_saved_queries()

    assert result["total"] == 72
    queries = result["data"]
    assert len(queries) == 2
    assert queries[0]["id"] == "wdigest_uselogoncredential_windows_elastic"
    assert queries[0]["platform"] == "windows"
    assert queries[0]["prebuilt"] is True
    assert "SELECT" in queries[0]["query"]


# ── Error handling ────────────────────────────────────────────────────────────

@respx.mock
def test_submit_action_post_body(kibana_client):
    """submit_action must send agent_type, endpoint_ids, parameters, and comment."""
    respx.post(_url("/api/endpoint/action/execute")).mock(
        return_value=httpx.Response(200, json={"data": {"id": ACTION_ID, "status": "pending"}})
    )

    kibana_client.submit_action(
        "execute",
        endpoint_ids=[AGENT_ID],
        parameters={"command": "hostname", "timeout": 60},
        comment="INC-1234",
    )

    body = json.loads(respx.calls.last.request.content)
    assert body["agent_type"] == "endpoint"
    assert body["endpoint_ids"] == [AGENT_ID]
    assert body["parameters"] == {"command": "hostname", "timeout": 60}
    assert body["comment"] == "INC-1234"


# ── Error handling ────────────────────────────────────────────────────────────

@respx.mock
def test_http_error_raises_edr_error(kibana_client):
    from edops.client import EdopsError

    respx.get(_url("/api/status")).mock(
        return_value=httpx.Response(401, json={"message": "Unauthorized"})
    )
    with pytest.raises(EdopsError, match="401"):
        kibana_client.get_kibana_status()


@respx.mock
def test_connect_error_raises_edr_error(kibana_client):
    from edops.client import EdopsError

    respx.get(_url("/api/status")).mock(side_effect=httpx.ConnectError("refused"))
    with pytest.raises(EdopsError, match="Cannot connect"):
        kibana_client.get_kibana_status()


# ── session-view ──────────────────────────────────────────────────────────────

ALERT_DOC_ID = "cccc0001-0000-0000-0000-cccccccccc01"


@respx.mock
def test_get_alert_by_id(kibana_client):
    payload = load_fixture("session_alert.json")
    respx.post(_url("/api/detection_engine/signals/search")).mock(
        return_value=httpx.Response(200, json={"hits": {"hits": [payload]}})
    )

    result = kibana_client.get_alert_by_id(ALERT_DOC_ID)

    assert result["_id"] == ALERT_DOC_ID
    src = result["_source"]
    assert src["process"]["entry_leader"]["entity_id"] == "entry-leader-id-0001"
    assert src["kibana"]["alert"]["rule"]["name"] == "Malware Prevention Alert"

    body = json.loads(respx.calls.last.request.content)
    assert body["query"]["ids"]["values"] == [ALERT_DOC_ID]
    assert body["size"] == 1


@respx.mock
def test_get_alert_by_id_not_found(kibana_client):
    from edops.client import EdopsError

    respx.post(_url("/api/detection_engine/signals/search")).mock(
        return_value=httpx.Response(200, json={"hits": {"hits": []}})
    )
    with pytest.raises(EdopsError, match="Alert not found"):
        kibana_client.get_alert_by_id("nonexistent-id")


@respx.mock
def test_session_process_events(kibana_client):
    payload = load_fixture("session_process_events.json")
    respx.get(_url("/internal/session_view/process_events")).mock(
        return_value=httpx.Response(200, json=payload)
    )

    events = kibana_client.session_process_events("entry-leader-id-0001", "2026-04-24T02:14:16.160Z", "logs-endpoint.events.process-*")

    assert len(events) == 3
    entity_ids = [e["_source"]["process"]["entity_id"] for e in events]
    assert "entry-leader-id-0001" in entity_ids
    assert "proc-entity-id-0001" in entity_ids


@respx.mock
def test_session_process_events_pagination(kibana_client):
    page1 = {"events": [{"_source": {"process": {"entity_id": "e1"}}}], "cursor": "tok-page2"}
    page2 = {"events": [{"_source": {"process": {"entity_id": "e2"}}}]}
    respx.get(_url("/internal/session_view/process_events")).mock(
        side_effect=[
            httpx.Response(200, json=page1),
            httpx.Response(200, json=page2),
        ]
    )

    events = kibana_client.session_process_events("eid", "2026-01-01T00:00:00Z", "logs-*")

    assert len(events) == 2
    assert events[0]["_source"]["process"]["entity_id"] == "e1"
    assert events[1]["_source"]["process"]["entity_id"] == "e2"
    second_call_params = respx.calls[1].request.url.params
    assert second_call_params["cursor"] == "tok-page2"


@respx.mock
def test_session_io_events(kibana_client):
    payload = load_fixture("session_io_events.json")
    respx.get(_url("/internal/session_view/io_events")).mock(
        return_value=httpx.Response(200, json=payload)
    )

    events = kibana_client.session_io_events("entry-leader-id-0001", "2026-04-24T02:14:16.160Z", "logs-endpoint.events.process-*")

    assert len(events) == 2
    texts = [e["_source"]["process"]["io"]["text"] for e in events]
    assert any("analyst@" in t for t in texts)
