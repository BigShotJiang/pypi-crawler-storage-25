import json
import pytest
from pathlib import Path

from edops.config import Config
from edops.client import KibanaClient

FIXTURES_DIR = Path(__file__).parent / "fixtures"

AGENT_ID  = "aaaa0001-0000-0000-0000-000000000001"
AGENT_ID2 = "aaaa0002-0000-0000-0000-000000000002"
ACTION_ID = "bbbb0001-0000-0000-0000-000000000001"
BASE_URL  = "http://kibana-test:5601"


def load_fixture(name: str) -> dict:
    return json.loads((FIXTURES_DIR / name).read_text())


@pytest.fixture
def kibana_client():
    cfg = Config(url=BASE_URL, api_key="dGVzdDp0ZXN0")
    return KibanaClient(cfg)
