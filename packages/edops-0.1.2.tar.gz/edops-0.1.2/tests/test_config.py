"""Tests for config load/save — uses a temp directory, no network."""
import json
import os
from pathlib import Path

import pytest

from edops.config import Config, load_config, save_config


@pytest.fixture(autouse=True)
def isolated_config(tmp_path, monkeypatch):
    """Redirect config file and clear env vars for every test."""
    import edops.config as cfg_module

    monkeypatch.setattr(cfg_module, "CONFIG_DIR",  tmp_path)
    monkeypatch.setattr(cfg_module, "CONFIG_FILE", tmp_path / "config.json")

    for var in (
        "EDOPS_URL", "EDOPS_API_KEY",
        "EDOPS_USERNAME", "EDOPS_PASSWORD",
        "EDOPS_VERIFY_SSL", "EDOPS_CA_CERT",
        "EDOPS_SPACE_ID",
    ):
        monkeypatch.delenv(var, raising=False)


class TestDefaults:
    def test_fresh_config_has_correct_defaults(self):
        cfg = load_config()
        assert cfg.url == ""
        assert cfg.api_key == ""
        assert cfg.verify_ssl is True
        assert cfg.space_id == "default"
        assert cfg.require_comment is True


class TestSaveLoad:
    def test_round_trip(self):
        original = Config(
            url="https://kibana.example.com:5601",
            api_key="dGVzdDp0ZXN0",
            space_id="ops",
            verify_ssl=False,
            require_comment=False,
        )
        save_config(original)
        loaded = load_config()
        assert loaded.url == original.url
        assert loaded.api_key == original.api_key
        assert loaded.space_id == original.space_id
        assert loaded.verify_ssl is False
        assert loaded.require_comment is False

    def test_partial_config_file_fills_rest_with_defaults(self, tmp_path):
        import edops.config as cfg_module
        cfg_module.CONFIG_FILE.write_text(json.dumps({"url": "https://k:5601"}))
        cfg = load_config()
        assert cfg.url == "https://k:5601"
        assert cfg.api_key == ""
        assert cfg.verify_ssl is True

    def test_corrupt_config_file_falls_back_to_defaults(self, tmp_path):
        import edops.config as cfg_module
        cfg_module.CONFIG_FILE.write_text("not valid json {{{")
        cfg = load_config()
        assert cfg.url == ""

    def test_unknown_keys_in_config_file_are_ignored(self, tmp_path):
        import edops.config as cfg_module
        cfg_module.CONFIG_FILE.write_text(json.dumps({
            "url": "https://k:5601",
            "future_field_unknown": "value",
        }))
        cfg = load_config()
        assert cfg.url == "https://k:5601"


class TestEnvOverrides:
    def test_url_env_overrides_file(self, monkeypatch, tmp_path):
        import edops.config as cfg_module
        save_config(Config(url="https://from-file:5601"))
        monkeypatch.setenv("EDOPS_URL", "https://from-env:5601")
        cfg = load_config()
        assert cfg.url == "https://from-env:5601"

    def test_api_key_env_override(self, monkeypatch):
        monkeypatch.setenv("EDOPS_API_KEY", "env-key")
        assert load_config().api_key == "env-key"

    def test_verify_ssl_false_from_env(self, monkeypatch):
        for value in ("false", "False", "FALSE", "0", "no"):
            monkeypatch.setenv("EDOPS_VERIFY_SSL", value)
            assert load_config().verify_ssl is False

    def test_verify_ssl_true_when_not_false(self, monkeypatch):
        monkeypatch.setenv("EDOPS_VERIFY_SSL", "true")
        assert load_config().verify_ssl is True

    def test_space_id_env_override(self, monkeypatch):
        monkeypatch.setenv("EDOPS_SPACE_ID", "my-space")
        assert load_config().space_id == "my-space"

    def test_env_empty_string_does_not_override_file_value(self, monkeypatch):
        save_config(Config(url="https://from-file:5601"))
        monkeypatch.setenv("EDOPS_URL", "")
        cfg = load_config()
        # empty env var should not override the file value (falsy check)
        assert cfg.url == "https://from-file:5601"
