"""Unit tests for KibanaClient that don't require network access."""
import pytest

from edops.client import EdopsError, KibanaClient
from edops.config import Config

BASE = "http://kibana-test:5601"


def _client(**kwargs) -> KibanaClient:
    defaults = {"api_key": "dGVzdDp0ZXN0"}
    defaults.update(kwargs)
    return KibanaClient(Config(url=BASE, **defaults))


class TestPathRouting:
    def test_default_space_no_prefix(self):
        assert _client()._path("/api/foo") == "/api/foo"

    def test_default_space_id_string_no_prefix(self):
        assert _client(space_id="default")._path("/api/foo") == "/api/foo"

    def test_custom_space_gets_prefix(self):
        assert _client(space_id="ops")._path("/api/foo") == "/s/ops/api/foo"

    def test_custom_space_preserves_nested_path(self):
        assert _client(space_id="my-space")._path("/api/a/b/c") == "/s/my-space/api/a/b/c"


class TestAuthHeaders:
    def test_api_key_sets_authorization_header(self):
        client = _client(api_key="mykey")
        assert client._http.headers["Authorization"] == "ApiKey mykey"

    def test_kbn_xsrf_always_present(self):
        client = _client()
        assert client._http.headers["kbn-xsrf"] == "true"


class TestConfigValidation:
    def test_missing_url_raises(self):
        with pytest.raises(EdopsError, match="URL not configured"):
            KibanaClient(Config(url="", api_key="key"))

    def test_missing_credentials_raises(self):
        with pytest.raises(EdopsError, match="credentials"):
            KibanaClient(Config(url=BASE))

    def test_username_password_accepted(self):
        cfg = Config(url=BASE, username="elastic", password="changeme")
        client = KibanaClient(cfg)
        assert client._http.auth is not None
