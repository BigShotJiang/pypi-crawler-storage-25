from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Optional

import httpx

from .config import Config


class EdopsError(Exception):
    pass


class KibanaClient:
    def __init__(self, cfg: Config, verbose: bool = False) -> None:
        if not cfg.url:
            raise EdopsError("Kibana URL not configured. Run: edops config set --url <url>")
        if not cfg.api_key and not (cfg.username and cfg.password):
            raise EdopsError(
                "No credentials configured. Run: edops config set --api-key <key>"
            )

        self._base    = cfg.url.rstrip("/")
        self._space   = cfg.space_id
        self._verbose = verbose

        headers: dict[str, str] = {"kbn-xsrf": "true"}
        auth: Any = None

        if cfg.api_key:
            headers["Authorization"] = f"ApiKey {cfg.api_key}"
        elif cfg.username and cfg.password:
            auth = (cfg.username, cfg.password)

        verify: Any = cfg.ca_cert if cfg.ca_cert else cfg.verify_ssl

        self._http = httpx.Client(
            headers=headers,
            auth=auth,
            verify=verify,
            timeout=60.0,
        )

    # ── internal helpers ──────────────────────────────────────────────────────

    def _path(self, api: str) -> str:
        if self._space and self._space != "default":
            return f"/s/{self._space}{api}"
        return api

    def _req(self, method: str, api: str, **kw: Any) -> dict:
        url = self._base + self._path(api)
        if api.startswith("/internal/"):
            kw["headers"] = {**kw.get("headers", {}), "x-elastic-internal-origin": "Kibana"}
        if self._verbose:
            print(f"  → {method} {url}")
            if "params" in kw:
                print(f"    params: {kw['params']}")
            if "json" in kw:
                print(f"    body:   {json.dumps(kw['json'])}")
            if "headers" in kw:
                safe = {k: ("***" if k.lower() == "authorization" else v) for k, v in kw["headers"].items()}
                print(f"    headers: {safe}")
        try:
            resp = self._http.request(method, url, **kw)
        except httpx.ConnectError as exc:
            raise EdopsError(f"Cannot connect to {self._base}: {exc}") from exc
        except httpx.TimeoutException as exc:
            raise EdopsError(f"Request timed out: {exc}") from exc

        if self._verbose:
            try:
                body_preview = json.dumps(resp.json(), indent=2)
            except Exception:
                body_preview = resp.text
            print(f"  ← {resp.status_code}  {body_preview}")
        if not resp.is_success:
            try:
                body = resp.json()
                msg = body.get("message") or body.get("error") or resp.text
            except Exception:
                msg = resp.text
            raise EdopsError(f"HTTP {resp.status_code}: {msg}")

        return resp.json()

    # ── response actions ──────────────────────────────────────────────────────

    def submit_action(
        self,
        action: str,
        endpoint_ids: list[str],
        parameters: Optional[dict] = None,
        comment: Optional[str] = None,
    ) -> dict:
        body: dict[str, Any] = {"agent_type": "endpoint", "endpoint_ids": endpoint_ids}
        if parameters:
            body["parameters"] = parameters
        if comment:
            body["comment"] = comment
        return self._req("POST", f"/api/endpoint/action/{action}", json=body)

    def upload_file(
        self,
        endpoint_ids: list[str],
        file_path: str,
        overwrite: bool = False,
        comment: Optional[str] = None,
    ) -> dict:
        p = Path(file_path)
        if not p.exists():
            raise EdopsError(f"File not found: {file_path}")

        # multipart/form-data — parameters encoded as JSON string per Elastic spec
        data: dict[str, Any] = {
            "endpoint_ids": json.dumps(endpoint_ids),
            "parameters": json.dumps({"overwrite": overwrite}),
        }
        if comment:
            data["comment"] = comment

        url = self._base + self._path("/api/endpoint/action/upload")
        if self._verbose:
            print(f"  → POST {url}  (multipart, file={p.name})")
        with p.open("rb") as fh:
            try:
                resp = self._http.post(url, data=data, files={"file": (p.name, fh)})
            except httpx.TimeoutException as exc:
                raise EdopsError(f"Upload timed out: {exc}") from exc

        if not resp.is_success:
            try:
                msg = resp.json().get("message") or resp.text
            except Exception:
                msg = resp.text
            raise EdopsError(f"HTTP {resp.status_code}: {msg}")
        return resp.json()

    # ── endpoint metadata ─────────────────────────────────────────────────────

    def get_kibana_status(self) -> dict:
        return self._req("GET", "/api/status")

    def get_endpoint_metadata(self, endpoint_id: str) -> dict:
        return self._req("GET", f"/api/endpoint/metadata/{endpoint_id}")

    def list_endpoints(
        self,
        kuery: Optional[str] = None,
        page: int = 1,
        page_size: int = 50,
    ) -> dict:
        params: dict[str, Any] = {"page": page, "pageSize": page_size}
        if kuery:
            params["kuery"] = kuery
        return self._req("GET", "/api/endpoint/metadata", params=params)

    def search_fleet_agents(
        self,
        kuery: Optional[str],
        page: int = 1,
        page_size: int = 50,
        online_only: bool = False,
    ) -> dict:
        params: dict[str, Any] = {
            "page": page,
            "perPage": page_size,
            "showInactive": "false" if online_only else "true",
        }
        if online_only:
            kuery = f"(status:online AND {kuery})" if kuery else "status:online"
        if kuery:
            params["kuery"] = kuery
        return self._req("GET", "/api/fleet/agents", params=params)

    # ── action status & results ───────────────────────────────────────────────

    def get_action(self, action_id: str) -> dict:
        return self._req("GET", f"/api/endpoint/action/{action_id}")

    def list_actions(
        self,
        endpoint_ids: Optional[list[str]] = None,
        commands: Optional[list[str]] = None,
        page: int = 1,
        page_size: int = 20,
    ) -> dict:
        params: dict[str, Any] = {"page": page, "pageSize": page_size}
        if endpoint_ids:
            params["agentIds"] = endpoint_ids
        if commands:
            params["commands"] = commands
        return self._req("GET", "/api/endpoint/action", params=params)

    # ── osquery ───────────────────────────────────────────────────────────────

    def osquery_run(
        self,
        agent_ids: list[str],
        query: Optional[str] = None,
        saved_query_id: Optional[str] = None,
        pack_id: Optional[str] = None,
    ) -> dict:
        body: dict[str, Any] = {"agent_ids": agent_ids}
        if query:
            body["query"] = query
        if saved_query_id:
            body["saved_query_id"] = saved_query_id
        if pack_id:
            body["pack_id"] = pack_id
        return self._req("POST", "/api/osquery/live_queries", json=body)

    def osquery_get(self, action_id: str) -> dict:
        return self._req("GET", f"/api/osquery/live_queries/{action_id}")

    def osquery_results(
        self,
        action_id: str,
        query_action_id: Optional[str] = None,
        page: int = 0,
        page_size: int = 100,
    ) -> dict:
        path = f"/api/osquery/live_queries/{action_id}/results"
        if query_action_id:
            path = f"{path}/{query_action_id}"
        return self._req("GET", path, params={"activePage": page, "pageSize": page_size})

    def wait_for_osquery_results(
        self,
        action_id: str,
        query_action_id: str,
        expected_docs: int,
        timeout: int = 30,
        poll_interval: int = 2,
    ) -> dict:
        """Poll the results endpoint until ES has indexed the expected documents."""
        deadline = time.monotonic() + timeout
        while True:
            result = self.osquery_results(action_id, query_action_id=query_action_id)
            hits = result.get("data", {}).get("rawResponse", {}).get("hits", {})
            total = hits.get("total", 0)
            if isinstance(total, dict):
                total = total.get("value", 0)
            if total >= expected_docs:
                return result
            if time.monotonic() >= deadline:
                return result
            time.sleep(poll_interval)

    def osquery_saved_queries(self, page: int = 1, page_size: int = 20) -> dict:
        return self._req(
            "GET",
            "/api/osquery/saved_queries",
            params={"page": page, "pageSize": page_size},
        )

    def wait_for_osquery(
        self,
        action_id: str,
        timeout: int = 60,
        poll_interval: int = 2,
    ) -> dict:
        """Poll until all targeted agents have responded or timeout is reached."""
        deadline = time.monotonic() + timeout
        while True:
            result  = self.osquery_get(action_id)
            data    = result.get("data", {})
            queries = data.get("queries", [])
            # Kibana 9.x: done when no query has pending > 0
            if queries and all(q.get("pending", 0) == 0 for q in queries):
                return result
            # Legacy fallback fields
            status = data.get("status", "")
            if status in ("completed", "done", "finished"):
                return result
            agent_count = data.get("agents_count", 0)
            responses   = data.get("responses", [])
            if agent_count and len(responses) >= agent_count:
                return result
            if time.monotonic() >= deadline:
                return result
            time.sleep(poll_interval)

    def search_alerts(
        self,
        endpoint_id: Optional[str] = None,
        page: int = 1,
        page_size: int = 20,
        status: Optional[str] = None,
        since: Optional[str] = None,
    ) -> dict:
        filters: list[Any] = []
        if endpoint_id:
            filters.append({"term": {"agent.id": endpoint_id}})
        if status:
            filters.append({"term": {"kibana.alert.workflow_status": status}})
        if since:
            filters.append({"range": {"@timestamp": {"gte": since}}})
        body: dict[str, Any] = {
            "query": {"bool": {"filter": filters}} if filters else {"match_all": {}},
            "from": (page - 1) * page_size,
            "size": page_size,
            "sort": [{"@timestamp": {"order": "desc"}}],
        }
        return self._req("POST", "/api/detection_engine/signals/search", json=body)

    def get_alert_by_id(self, alert_id: str) -> dict:
        body = {"query": {"ids": {"values": [alert_id]}}, "size": 1}
        result = self._req("POST", "/api/detection_engine/signals/search", json=body)
        hits = result.get("hits", {}).get("hits", [])
        if not hits:
            raise EdopsError(f"Alert not found: {alert_id}")
        return hits[0]

    @staticmethod
    def _next_cursor(batch: list[dict]) -> Optional[str]:
        """Extract the search_after cursor from the last event's sort value."""
        if not batch:
            return None
        last_sort = batch[-1].get("sort", [])
        return str(last_sort[0]) if last_sort else None

    def session_process_events(self, session_entity_id: str, session_start_time: str, index: str) -> list[dict]:
        events: list[dict] = []
        cursor: Optional[str] = None
        while True:
            params: dict[str, Any] = {
                "index": index,
                "sessionEntityId": session_entity_id,
                "sessionStartTime": session_start_time,
                "forward": "true",
            }
            if cursor:
                params["cursor"] = cursor
            data = self._req("GET", "/internal/session_view/process_events", params=params)
            batch = data.get("events", [])
            if not batch:
                break
            events.extend(batch)
            cursor = self._next_cursor(batch)
            if not cursor:
                break
        return events

    def session_io_events(self, session_entity_id: str, session_start_time: str, index: str) -> list[dict]:
        events: list[dict] = []
        cursor: Optional[str] = None
        while True:
            params: dict[str, Any] = {
                "index": index,
                "sessionEntityId": session_entity_id,
                "sessionStartTime": session_start_time,
            }
            if cursor:
                params["cursor"] = cursor
            data = self._req("GET", "/internal/session_view/io_events", params=params)
            batch = data.get("events", [])
            if not batch:
                break
            events.extend(batch)
            cursor = self._next_cursor(batch)
            if not cursor:
                break
        return events

    def download_file(self, action_id: str, file_id: str) -> bytes:
        """Download a file result (zip, password: 'elastic')."""
        url = self._base + self._path(
            f"/api/endpoint/action/{action_id}/file/{file_id}/download"
        )
        if self._verbose:
            print(f"  → GET {url}")
        try:
            resp = self._http.get(url, timeout=120.0)
        except httpx.TimeoutException as exc:
            raise EdopsError(f"Download timed out: {exc}") from exc
        if not resp.is_success:
            raise EdopsError(f"Download failed HTTP {resp.status_code}")
        return resp.content

    # ── polling helper ────────────────────────────────────────────────────────

    def wait_for_action(
        self,
        action_id: str,
        timeout: int = 120,
        poll_interval: int = 3,
        wait_for_outputs: bool = False,
    ) -> dict:
        """Poll until the action is complete.

        When wait_for_outputs=True, keep polling after isCompleted until the
        outputs dict is populated — Elastic stages file results asynchronously
        after marking the action complete.
        """
        deadline = time.monotonic() + timeout
        result: dict = {}
        completed = False

        while True:
            result = self.get_action(action_id)
            data = result.get("data", {})

            if not completed:
                completed = bool(data.get("isCompleted") or data.get("completedAt"))

            if completed:
                if not wait_for_outputs or data.get("outputs"):
                    return result

            if time.monotonic() >= deadline:
                raise EdopsError(
                    f"Timed out waiting for action {action_id} after {timeout}s"
                )
            time.sleep(poll_interval)
