from __future__ import annotations

import io
import itertools
import json
import re
import shlex
from urllib.parse import urlencode
import sys
import threading
import time
import zipfile
from datetime import datetime, timedelta, timezone
from importlib.metadata import PackageNotFoundError, version as _pkg_version
from pathlib import Path
from typing import Annotated, Optional

try:
    _VERSION = _pkg_version("edops")
except PackageNotFoundError:
    _VERSION = "unknown"

import typer
from rich.console import Console
from rich.markup import escape as markup_escape
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich.tree import Tree

from .client import EdopsError, KibanaClient
from .config import Config, load_config, save_config

app = typer.Typer(
    name="edops",
    help="Elastic Defend Operations - Response Actions CLI for Elastic Endpoint Security XDR",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
config_app  = typer.Typer(help="Manage connection configuration and options.", no_args_is_help=True)
osquery_app = typer.Typer(
    help="Run osquery live queries on endpoints with the osquery integration.",
    no_args_is_help=True,
)

out = Console()
err = Console(stderr=True)

_verbose: bool = False
_global_url: Optional[str] = None
_global_api_key: Optional[str] = None
_global_username: Optional[str] = None
_global_password: Optional[str] = None


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


# ── helpers ────────────────────────────────────────────────────────────────────


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"edops {_VERSION}")
        raise typer.Exit()


@app.callback()
def _global_options(
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Print each HTTP request/response to stderr."),
    ] = False,
    version: Annotated[
        Optional[bool],
        typer.Option("--version", callback=_version_callback, is_eager=True, help="Show version and exit."),
    ] = None,
    url: Annotated[
        Optional[str],
        typer.Option("--url", help="Kibana URL — overrides config, .env, and environment variables."),
    ] = None,
    api_key: Annotated[
        Optional[str],
        typer.Option("--api-key", help="API key — overrides config. Omit value to be prompted.", prompt="API key", hide_input=True, prompt_required=False),
    ] = None,
    username: Annotated[
        Optional[str],
        typer.Option("--username", help="Username for basic auth — overrides config."),
    ] = None,
    password: Annotated[
        Optional[str],
        typer.Option("--password", help="Password for basic auth — overrides config. Omit value to be prompted.", prompt="Password", hide_input=True, prompt_required=False),
    ] = None,
) -> None:
    global _verbose, _global_url, _global_api_key, _global_username, _global_password
    _verbose  = verbose
    _global_url      = url
    _global_api_key  = api_key
    _global_username = username
    _global_password = password


def _client() -> KibanaClient:
    cfg = load_config()

    if _global_url      is not None: cfg.url      = _global_url
    if _global_api_key  is not None: cfg.api_key  = _global_api_key
    if _global_username is not None: cfg.username = _global_username
    if _global_password is not None: cfg.password = _global_password

    if not cfg.url:
        cfg.url = typer.prompt("Kibana URL")

    if not cfg.api_key and not (cfg.username and cfg.password):
        if typer.confirm("Authenticate with API key?", default=True):
            cfg.api_key = typer.prompt("API key", hide_input=True)
        else:
            if not cfg.username:
                cfg.username = typer.prompt("Username")
            cfg.password = typer.prompt("Password", hide_input=True)

    try:
        return KibanaClient(cfg, verbose=_verbose)
    except EdopsError as exc:
        err.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)


def _check_capability(client: KibanaClient, endpoint_id: str, capability: str) -> None:
    """Fetch endpoint metadata and abort if the capability is not advertised.

    Silently passes when metadata can't be fetched so a network hiccup doesn't
    block the action — the API itself will reject it with a clear error.
    """
    try:
        meta = client.get_endpoint_metadata(endpoint_id)
    except EdopsError:
        return

    ep = meta.get("metadata", {}).get("Endpoint", {})
    capabilities: list[str] = ep.get("capabilities", [])
    os_name: str = meta.get("metadata", {}).get("host", {}).get("os", {}).get("name", "")

    if capabilities and capability not in capabilities:
        os_hint = f" (host OS: {os_name})" if os_name else ""
        raise EdopsError(
            f"endpoint does not support '{capability}'{os_hint}. "
            f"Advertised capabilities: {', '.join(capabilities)}"
        )


def _print_action(data: dict, as_json: bool) -> None:
    if as_json:
        typer.echo(json.dumps(data, indent=2))
        return
    d = data.get("data", data)
    out.print(f"[bold cyan]Action ID:[/bold cyan]  {d.get('id', 'N/A')}")
    out.print(f"[cyan]Command:[/cyan]    {d.get('command', d.get('action', 'N/A'))}")
    status = d.get("status", "pending")
    color = "green" if status == "successful" else ("red" if status == "failed" else "yellow")
    out.print(f"[cyan]Status:[/cyan]     [{color}]{status}[/{color}]")
    out.print(f"[cyan]Agents:[/cyan]     {', '.join(d.get('agents', []))}")
    out.print(f"[cyan]Started:[/cyan]    {d.get('startedAt', 'N/A')}")


def _handle(exc: EdopsError) -> None:
    err.print(f"[red]Error:[/red] {markup_escape(str(exc))}")
    raise typer.Exit(1)


def _parse_since(since: str) -> str:
    """Parse '24h', '7d', '30m' → UTC ISO-8601 timestamp string."""
    m = re.match(r'^(\d+)([mhd])$', since.strip().lower())
    if not m:
        err.print(f"[red]Error:[/red] invalid --since value {since!r} — use e.g. 24h, 7d, 30m")
        raise typer.Exit(1)
    n, unit = int(m.group(1)), m.group(2)
    delta = timedelta(seconds={'m': 60, 'h': 3600, 'd': 86400}[unit] * n)
    return (datetime.now(timezone.utc) - delta).strftime("%Y-%m-%dT%H:%M:%SZ")


def _require_comment(comment: Optional[str]) -> None:
    """Abort when require_comment is enabled in config and no comment was supplied."""
    if load_config().require_comment and not comment:
        err.print(
            "[red]Error:[/red] a comment is required by your configuration.\n"
            "[dim]Pass [bold]--comment INC-1234[/bold] with a ticket or case reference, "
            "or disable the requirement with: "
            "[bold]edops config set --no-require-comment[/bold][/dim]"
        )
        raise typer.Exit(1)


# ── agents ─────────────────────────────────────────────────────────────────────


def _mac_to_colon(mac: str) -> str:
    return mac.lower().replace("-", ":").replace(".", ":")


def _mac_to_dash(mac: str) -> str:
    return mac.lower().replace(":", "-").replace(".", "-")


def _build_fleet_kuery(term: str) -> Optional[str]:
    """KQL for /api/fleet/agents.
    Trailing wildcards supplied by the user are stripped; we always append one
    to the hostname clause so prefix search always works.
    MAC is searched in both colon and dash format since storage varies.
    Returns None for a bare wildcard so the caller omits the kuery param entirely.
    """
    base = term.rstrip("*")
    if not base:
        return None
    esc       = base.replace("\\", "\\\\").replace('"', '\\"')
    mac_colon = _mac_to_colon(base).replace('"', '\\"')
    mac_dash  = _mac_to_dash(base).replace('"', '\\"')
    parts = [
        f'local_metadata.host.hostname:"{esc}*"',
        f'local_metadata.host.ip:"{esc}"',
        f'local_metadata.host.mac:"{mac_colon}"',
        f'local_metadata.host.mac:"{mac_dash}"',
        f'local_metadata.elastic.agent.id:"{esc}"',
    ]
    return "(" + " OR ".join(parts) + ")"


@app.command()
def agents(
    query: Annotated[Optional[str], typer.Argument(help="Hostname (prefix), IP, or MAC — omit to list all")] = None,
    online: Annotated[bool, typer.Option("--online", help="Only show agents with status online")] = False,
    as_json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
):
    """List agents enrolled in Fleet, optionally filtered by hostname, IP, or MAC."""
    client = _client()
    try:
        result = client.search_fleet_agents(
            kuery=_build_fleet_kuery((query or "").strip()),
            online_only=online,
        )
        if as_json:
            typer.echo(json.dumps(result, indent=2))
            return
        items = [
            i for i in result.get("items", [])
            if any(c.get("type") == "endpoint" for c in i.get("components", []))
        ]
        if not items:
            suffix = f" matching '{query}'" if query else ""
            out.print(f"[yellow]No agents found{suffix}[/yellow]")
            return
        total = len(items)
        title_text = f"Agents matching '{query}'" if query else "All agents"
        t = Table(title=f"{title_text}  ({total} found) @ {_ts()}", title_justify="left")
        t.add_column(Text("AGENT ID", justify="left"), style="cyan", no_wrap=True)
        t.add_column(Text("HOSTNAME", justify="left"))
        t.add_column(Text("OS", justify="left"))
        t.add_column(Text("IP", justify="left"))
        t.add_column(Text("MAC", justify="left"))
        t.add_column(Text("STATUS", justify="left"))
        t.add_column(Text("VERSION", justify="left"))
        t.add_column(Text("LAST SEEN", justify="left"), no_wrap=True)
        for item in items:
            lm       = item.get("local_metadata", {})
            host     = lm.get("host", {})
            os_info  = host.get("os", {}) or lm.get("os", {})
            all_ips  = host.get("ip", [])
            routable = [
                ip for ip in all_ips
                if not ip.startswith("127.")
                and ip != "::1"
                and not ip.lower().startswith("fe80")
            ]
            display_ip  = routable[0] if routable else (all_ips[0] if all_ips else "")
            macs        = host.get("mac", [])
            display_mac = macs[0] if macs else ""
            os_name    = os_info.get("name") or os_info.get("platform") or ""
            os_version = os_info.get("version") or ""
            os_display = f"{os_name} ({os_version})".strip()
            status  = item.get("status", "unknown")
            s_color = {"online": "green", "offline": "red", "updating": "yellow", "enrolling": "yellow"}.get(status, "dim")
            version = lm.get("elastic", {}).get("agent", {}).get("version") or item.get("agent", {}).get("version", "")
            t.add_row(
                item.get("id", ""),
                host.get("hostname") or host.get("name", ""),
                os_display,
                display_ip,
                display_mac,
                f"[{s_color}]{status}[/{s_color}]",
                version,
                (item.get("last_checkin") or "")[:19].replace("T", " "),
            )
        out.print(t)
    except EdopsError as exc:
        _handle(exc)


# ── metadata ───────────────────────────────────────────────────────────────────


def _print_metadata(data: dict) -> None:
    meta      = data.get("metadata", {})
    host      = meta.get("host", {})
    agent     = meta.get("agent", {})
    endpoint  = meta.get("Endpoint", {})
    os_info   = host.get("os", {})
    policy    = endpoint.get("policy", {}).get("applied", {})
    state     = endpoint.get("state", {})
    host_status   = data.get("host_status", "unknown")
    last_checkin  = data.get("last_checkin", "")

    hostname = host.get("hostname") or host.get("name", "unknown")

    status_color = {
        "healthy": "green", "offline": "red",
        "updating": "yellow", "inactive": "dim", "unenrolled": "dim",
    }.get(host_status, "white")

    # Keep only non-loopback, non-link-local IPs for the summary line
    all_ips = host.get("ip", [])
    routable = [
        ip for ip in all_ips
        if not ip.startswith("127.")
        and ip != "::1"
        and not ip.lower().startswith("fe80")
    ]
    display_ips = routable or all_ips

    def row(label: str, value: str) -> None:
        t.add_row(f"  [dim]{label}[/dim]", value)

    t = Table(show_header=False, box=None, padding=(0, 1), show_edge=False)
    t.add_column(Text("key", justify="left"), style="default", min_width=18, no_wrap=True)
    t.add_column(Text("value", justify="left"))

    # ── HOST ──────────────────────────────────────────────────────────────────
    t.add_row("[bold cyan]HOST[/bold cyan]", "")
    os_full    = os_info.get("full") or os_info.get("name", "")
    os_variant = os_info.get("Ext", {}).get("variant", "")
    os_arch    = host.get("architecture", "")
    os_label   = os_full
    if os_variant and os_variant.lower() not in os_full.lower():
        os_label += f" ({os_variant})"
    if os_arch:
        os_label += f"  [dim]{os_arch}[/dim]"
    row("OS", os_label)
    if kernel := os_info.get("kernel", ""):
        row("Kernel", kernel)
    row("Hostname", hostname)
    row("IP", "   ".join(display_ips))
    if macs := host.get("mac", []):
        row("MAC", "   ".join(macs))
    if last_checkin:
        row("Last seen", last_checkin.replace("T", " ").rstrip("Z") + " UTC")
    t.add_row("", "")

    # ── AGENT / ENDPOINT ──────────────────────────────────────────────────────
    t.add_row("[bold cyan]AGENT[/bold cyan]", "")
    row("ID", agent.get("id", ""))
    row("Version", agent.get("version", ""))
    row("Status", endpoint.get("status", ""))

    isolated = state.get("isolation", False)
    row("Isolated", "[red]yes[/red]" if isolated else "[green]no[/green]")

    tamper = state.get("tamper_protection", False)
    row("Tamper protection", "[green]enabled[/green]" if tamper else "[dim]disabled[/dim]")

    if policy:
        p_status = policy.get("status", "")
        p_color  = "green" if p_status == "success" else "yellow"
        p_rev    = policy.get("endpoint_policy_version", "")
        row(
            "Policy",
            f"{policy.get('name', '')}  "
            f"[dim]rev.{p_rev}  [{p_color}]{p_status}[/{p_color}][/dim]",
        )
    t.add_row("", "")

    # ── CAPABILITIES ─────────────────────────────────────────────────────────
    caps = endpoint.get("capabilities", [])
    t.add_row("[bold cyan]CAPABILITIES[/bold cyan]", "")
    if caps:
        row("", "   ".join(f"[cyan]{c}[/cyan]" for c in caps))
    else:
        row("", "[dim]none reported[/dim]")

    title = Text()
    title.append(hostname, style="bold")
    title.append("  [", style="dim")
    title.append(host_status, style=status_color)
    title.append("]", style="dim")

    out.print(Panel(t, title=title, title_align="left", border_style="bright_black", padding=(1, 2)))


@app.command()
def metadata(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    as_json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
):
    """Show endpoint metadata: OS, agent version, policy, capabilities."""
    client = _client()
    try:
        result = client.get_endpoint_metadata(endpoint_id)
        if as_json:
            typer.echo(json.dumps(result, indent=2))
            return
        _print_metadata(result)
    except EdopsError as exc:
        _handle(exc)


# ── shared output helpers ──────────────────────────────────────────────────────


def _print_processes(result: dict, endpoint_id: str, as_json: bool) -> None:
    if as_json:
        typer.echo(json.dumps(result, indent=2))
        return
    data = result.get("data", {})
    ep_out = data.get("outputs", {}).get(endpoint_id, {})
    entries = ep_out.get("content", {}).get("entries", [])
    if not entries:
        out.print("[yellow]No process data returned (action may still be pending).[/yellow]")
        return
    t = Table(title=f"Processes — {endpoint_id} @ {_ts()}", title_justify="left")
    t.add_column(Text("USER", justify="left"))
    t.add_column(Text("PID", justify="left"), style="cyan", justify="right")
    t.add_column(Text("ENTITY ID", justify="left"), style="dim")
    t.add_column(Text("COMMAND", justify="left"))
    for p in entries:
        t.add_row(
            p.get("user", ""),
            str(p.get("pid", "")),
            p.get("entity_id", ""),
            Text(p.get("command", "")),
        )
    out.print(t)


_SEVERITY_COLORS = {"critical": "red", "high": "bright_red", "medium": "yellow", "low": "cyan"}
_STATUS_COLORS   = {"open": "red", "acknowledged": "yellow", "closed": "green"}

_ANSI_DANGEROUS = re.compile(
    r"\x1b(?:"
    r"\][^\x07\x1b]*(?:\x07|\x1b\\)"   # OSC: clipboard (52), hyperlinks (8), title (0/1/2)
    r"|P[^\x1b]*(?:\x1b\\|$)"          # DCS
    r")"
)

# Sequences that would corrupt the analyst's terminal if replayed
_ANSI_TUI_CTRL = re.compile(
    r"\x1b(?:"
    r"\[\?[\d;]*[hl]"       # DEC private modes: alt screen (?1049h/l), mouse tracking, etc.
    r"|\[[\d;]*[HfJrKPX]"   # cursor home/abs (H,f), erase display/line (J,K), scroll region (r), delete/erase char (P,X)
    r"|\[[\d;]*R"           # cursor position report (terminal response — meaningless on replay)
    r"|\[>[\d;]*c"          # secondary device attribute response
    r"|\[\?[\d;]*\$y"       # DEC mode status reports
    r"|[=>]"                # application/normal keypad (ESC= / ESC>)
    r")"
)

# Matches a trailing incomplete CSI/escape sequence at end of a chunk (for cross-chunk stitching)
_INCOMPLETE_ESC = re.compile(r"\x1b(?:\[[\x30-\x3f]*[\x20-\x2f]*)?$")


def _sanitize_io(text: str) -> str:
    return _ANSI_TUI_CTRL.sub("", _ANSI_DANGEROUS.sub("", text))


def _af(src: dict, *path: str) -> str:
    """Read a field from an alert _source trying nested-dict access first,
    then falling back to a flat dot-notation key (ES stores both formats)."""
    cur: object = src
    for key in path:
        if not isinstance(cur, dict):
            cur = None
            break
        cur = cur.get(key)
    if cur is not None and not isinstance(cur, (dict, list)):
        return str(cur)
    val = src.get(".".join(path))
    return str(val) if val is not None and not isinstance(val, (dict, list)) else ""


def _print_alerts(result: dict, title: str, as_json: bool, base_url: str = "") -> None:
    if as_json:
        typer.echo(json.dumps(result, indent=2))
        return
    hits_obj  = result.get("hits", {})
    total_raw = hits_obj.get("total", 0)
    total     = total_raw.get("value", 0) if isinstance(total_raw, dict) else total_raw
    hits      = hits_obj.get("hits", [])
    if not hits:
        out.print("[yellow]No alerts found.[/yellow]")
        return
    t = Table(title=f"{title}  (total: {total}) @ {_ts()}", title_justify="left")
    t.add_column(Text("#", justify="right"), style="dim", no_wrap=True)
    t.add_column(Text("Time", justify="left"), no_wrap=True)
    t.add_column(Text("Host", justify="left"), no_wrap=True)
    t.add_column(Text("Severity", justify="left"), no_wrap=True)
    t.add_column(Text("Rule", justify="left"), max_width=40)
    t.add_column(Text("Reason", justify="left"), max_width=60)
    t.add_column(Text("Status", justify="left"), no_wrap=True)
    t.add_column(Text("Indicator", justify="left"))
    full_ids: list[tuple[int, str]] = []
    for row_num, hit in enumerate(hits, 1):
        src      = hit.get("_source", {})
        alert_id = hit.get("_id", "")
        full_ids.append((row_num, alert_id))

        ts       = (_af(src, "@timestamp"))[:19].replace("T", " ")
        host     = _af(src, "host", "name") or (_af(src, "agent", "id") or "")[:8]
        severity = (
            _af(src, "kibana", "alert", "severity")
            or _af(src, "signal", "rule", "severity")
        )
        rule = (
            _af(src, "kibana", "alert", "rule", "name")
            or _af(src, "signal", "rule", "name")
        )
        reason = _af(src, "kibana", "alert", "reason") or ""
        status = (
            _af(src, "kibana", "alert", "workflow_status")
            or _af(src, "signal", "status")
            or "open"
        )

        proc   = _af(src, "process", "name")
        fname  = _af(src, "file", "name")
        src_ip = _af(src, "source", "ip")
        dst_ip = _af(src, "destination", "ip")

        parts: list[str] = []
        if proc:
            parts.append(f"process.name:{proc}")
        if fname:
            parts.append(f"file.name:{fname}")
            if fhash := _af(src, "file", "hash", "sha256"):
                parts.append(f"file.hash.sha256:{fhash}")
        if src_ip:
            parts.append(f"source.ip:{src_ip}")
        if dst_ip:
            parts.append(f"destination.ip:{dst_ip}")
        indicator = "\n".join(parts)

        sc  = _SEVERITY_COLORS.get(severity.lower() if severity else "", "white")
        stc = _STATUS_COLORS.get(status.lower() if status else "", "white")
        if base_url:
            index     = hit.get("_index", "")
            timestamp = _af(src, "@timestamp") or ""
            url       = f"{base_url}/app/security/alerts/redirect/{alert_id}?{urlencode({'index': index, 'timestamp': timestamp})}"
            num_cell  = Text(str(row_num), style=f"link {url}")
        else:
            num_cell = Text(str(row_num))
        t.add_row(num_cell, ts, host, f"[{sc}]{severity}[/{sc}]", rule, Text(reason), f"[{stc}]{status}[/{stc}]", indicator)
    out.print(t)
    if base_url:
        out.print("[dim]Tip: # is a clickable link to the alert in Kibana[/dim]")
    out.print("[dim]Alert IDs:[/dim]")
    for n, aid in full_ids:
        out.print(f"  [dim][{n}][/dim]  {aid}")


def _print_osquery_results(result: dict, as_json: bool, action_id: str = "") -> None:
    if as_json:
        typer.echo(json.dumps(result, indent=2))
        return

    data  = result.get("data", {})
    rows: list[tuple[str, dict]] = []

    # Format A: data.edges[].node (Kibana 8.x results endpoint)
    for edge in data.get("edges", []):
        node = edge.get("node", {})
        src  = node.get("_source", node)
        agent_label = (
            src.get("agent", {}).get("name")
            or src.get("agent", {}).get("id", "")[:8]
            or src.get("agent.name", "")
            or src.get("agent.id", "")[:8]
        )
        osq = src.get("osquery", {})
        if osq:
            rows.append((agent_label, osq))

    # Format B: data.responses[].rows
    if not rows:
        for resp in data.get("responses", []):
            label = resp.get("agent_name") or resp.get("agent_id", "")[:8]
            for row in resp.get("rows", []):
                rows.append((label, row))

    # Format C: data.rawResponse.hits.hits[] (Kibana 9.x results endpoint)
    if not rows:
        for hit in data.get("rawResponse", {}).get("hits", {}).get("hits", []):
            src = hit.get("_source", {})
            agent_label = (
                src.get("agent", {}).get("name")
                or src.get("agent", {}).get("id", "")[:8]
                or src.get("agent.name", "")
                or src.get("agent.id", "")[:8]
            )
            osq = src.get("osquery", {})
            if osq:
                rows.append((agent_label, osq))

    if not rows:
        out.print("[yellow]No results returned — the query may have failed or returned no rows.[/yellow]")
        return

    # Collect column names from all rows, preserving first-seen order
    seen_cols: dict[str, None] = {}
    for _, row in rows:
        seen_cols.update(dict.fromkeys(row.keys()))
    cols = list(seen_cols)

    t = Table(title=f"osquery results  ({len(rows)} rows) @ {_ts()}", title_justify="left")
    t.add_column(Text("agent", justify="left"), style="cyan", no_wrap=True)
    for col in cols:
        t.add_column(col)
    for label, row in rows:
        t.add_row(label, *[str(row.get(c, "")) for c in cols])
    out.print(t)


# ── shared file-download helper ────────────────────────────────────────────────


def _sanitize_prefix(text: str) -> str:
    """Return a filename-safe prefix from *text* (e.g. a ticket reference)."""
    s = re.sub(r'\s+', '_', text.strip())
    s = re.sub(r'[^\w\-]', '_', s)
    s = re.sub(r'_+', '_', s)
    return s.strip('_')[:50]


def _save_file_output(
    client: KibanaClient,
    result: dict,
    action_id: str,
    endpoint_id: str,
    output_dir: str,
    comment: Optional[str] = None,
) -> None:
    data = result.get("data", {})
    outputs = data.get("outputs", {})
    ep_out = outputs.get(endpoint_id, {})
    otype = ep_out.get("type")
    content = ep_out.get("content", {})

    if not outputs:
        err.print(
            f"[yellow]Warning:[/yellow] action [cyan]{action_id}[/cyan] completed "
            f"but no outputs were returned yet.\n"
            f"Run [bold]edops status {action_id}[/bold] to check again."
        )
        return

    # "file" type — classic download response
    if otype == "file":
        file_id = content.get("file_id") or f"{action_id}.{endpoint_id}"
        file_name = content.get("file_name", "result.zip")

    # "json" type with a downloadUri — get-file / memory-dump returns this format
    elif otype == "json" and content.get("downloadUri"):
        file_id = f"{action_id}.{endpoint_id}"
        contents = content.get("contents", [])
        src_name = contents[0].get("file_name", "result") if contents else "result"
        file_name = src_name + ".zip"

    else:
        err.print(
            f"[yellow]Warning:[/yellow] expected downloadable output but got "
            f"[bold]{otype!r}[/bold] for endpoint [cyan]{endpoint_id}[/cyan].\n"
            f"Run [bold]edops status {action_id} --json[/bold] to inspect the raw output."
        )
        return

    if comment:
        prefix = _sanitize_prefix(comment)
        if prefix:
            file_name = f"{prefix}_{file_name}"

    base = Path(output_dir).resolve()
    out_path = (base / file_name).resolve()
    if not out_path.is_relative_to(base):
        raise EdopsError(f"Refusing to write outside output directory: {out_path}")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out.status(f"Downloading {file_name} ..."):
        data_bytes = client.download_file(action_id, file_id)
    out_path.write_bytes(data_bytes)
    out.print(f"[green]Saved:[/green] {out_path}  [dim](zip password: elastic)[/dim]")


# ── shell / console shared helpers ─────────────────────────────────────────────


class _Spinner:
    """Thread-based spinner — doesn't conflict with prompt_toolkit's terminal control."""

    _FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

    def __init__(self, msg: str = "running") -> None:
        self._msg = msg
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._spin, daemon=True)

    def _spin(self) -> None:
        for ch in itertools.cycle(self._FRAMES):
            if self._stop.is_set():
                sys.stderr.write("\r\033[K")
                sys.stderr.flush()
                return
            sys.stderr.write(f"\r{ch} {self._msg}  ")
            sys.stderr.flush()
            time.sleep(0.08)

    def __enter__(self) -> "_Spinner":
        self._thread.start()
        return self

    def __exit__(self, *_: object) -> None:
        self._stop.set()
        self._thread.join()


def _parse_zip_output(data: bytes) -> tuple[str, str, Optional[int]]:
    """Extract stdout, stderr, return code from an Elastic execute output zip (password: elastic)."""
    stdout = ""
    stderr = ""
    rc: Optional[int] = None

    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()

            for candidate in ("stdout", "stdout.txt", "output.txt", "output"):
                if candidate in names:
                    stdout = zf.read(candidate, pwd=b"elastic").decode("utf-8", errors="replace")
                    break

            for candidate in ("stderr", "stderr.txt"):
                if candidate in names:
                    stderr = zf.read(candidate, pwd=b"elastic").decode("utf-8", errors="replace")
                    break

            for candidate in ("return_code", "exit_code", "returncode", "status"):
                if candidate in names:
                    try:
                        rc = int(zf.read(candidate, pwd=b"elastic").decode().strip())
                    except (ValueError, UnicodeDecodeError):
                        pass
                    break

            # Fallback: no known names found — concatenate every readable file
            if not stdout and not stderr:
                _skip = {"return_code", "exit_code", "returncode", "status"}
                for name in names:
                    if name in _skip:
                        continue
                    try:
                        stdout += zf.read(name, pwd=b"elastic").decode("utf-8", errors="replace")
                    except Exception:
                        pass

    except zipfile.BadZipFile:
        stdout = data.decode("utf-8", errors="replace")

    return stdout, stderr, rc


def _emit(text: str, dest: "io.TextIOBase" = sys.stdout) -> None:
    if not text:
        return
    dest.write(text)
    if not text.endswith("\n"):
        dest.write("\n")
    dest.flush()


def _print_shell_output(client: KibanaClient, result: dict, endpoint_id: str, action_id: str) -> None:
    data   = result.get("data", {})
    ep_out = data.get("outputs", {}).get(endpoint_id, {})
    otype  = ep_out.get("type")
    rc: Optional[int] = None

    if otype == "file":
        content = ep_out.get("content", {})
        file_id = content.get("file_id") or f"{action_id}.{endpoint_id}"
        with _Spinner("downloading"):
            raw = client.download_file(action_id, file_id)
        stdout_text, stderr_text, rc = _parse_zip_output(raw)
        _emit(stdout_text, sys.stdout)
        _emit(stderr_text, sys.stderr)

    elif otype == "json":
        content = ep_out.get("content", {})
        _emit(content.get("stdout", ""), sys.stdout)
        _emit(content.get("stderr", ""), sys.stderr)
        rc = content.get("return_code", content.get("exit_code"))

    else:
        sys.stderr.write(f"[no output — action status: {data.get('status')}]\n")
        sys.stderr.flush()

    if rc is not None and rc != 0:
        sys.stderr.write(f"\033[2m[exit {rc}]\033[0m\n")
        sys.stderr.flush()


# ── console helpers ────────────────────────────────────────────────────────────


def _get_opt(args: list[str], flag: str) -> Optional[str]:
    """Return the value following *flag* in *args*, or None if absent."""
    try:
        i = args.index(flag)
        return args[i + 1] if i + 1 < len(args) else None
    except ValueError:
        return None


def _parse_pid_entity(args: list[str]) -> tuple[Optional[int], Optional[str]]:
    pid_str   = _get_opt(args, "--pid")
    entity_id = _get_opt(args, "--entity-id")
    pid: Optional[int] = None
    if pid_str is not None:
        try:
            pid = int(pid_str)
        except ValueError:
            pass
    return pid, entity_id


class _ConsoleCompleter:
    """prompt_toolkit completer for the edops interactive console."""

    async def get_completions_async(self, document, complete_event):
        for item in self.get_completions(document, complete_event):
            yield item

    _OPTS: dict[str, list[str]] = {
        "isolate":         [],
        "unisolate":       [],
        "processes":       [],
        "kill-process":    ["--pid", "--entity-id"],
        "suspend-process": ["--pid", "--entity-id"],
        "get-file":        ["--path", "--output-dir"],
        "execute":         ["--command", "--timeout", "--output-dir"],
        "upload":          ["--file", "--overwrite", "--no-wait"],
        "scan":            ["--path", "--wait"],
        "memory-dump":     ["--kernel", "--pid", "--entity-id", "--output-dir"],
        "status":          [],
        "actions":         [],
        "alerts":          ["--status"],
        "session-view":    [],
        "session-export":  ["--output", "--force", "--gif", "--mp4", "--no-intro"],
        "session-play":    ["--all", "--yes", "-y"],
        "osquery":         ["--query", "--saved-query-id", "--pack-id", "--no-wait"],
        "osquery-results": [],
        "osquery-saved":   [],
        "metadata":        [],
        "shell":           [],
        "comment":         [],
        "help":            [],
        "exit":            [],
        "quit":            [],
    }

    def get_completions(self, document, complete_event):
        from prompt_toolkit.completion import Completion

        text  = document.text_before_cursor
        words = text.split()

        # Complete command name
        if not words or (len(words) == 1 and not text.endswith(" ")):
            prefix = words[0] if words else ""
            for cmd in self._OPTS:
                if cmd.startswith(prefix):
                    yield Completion(cmd, start_position=-len(prefix))
            return

        cmd = words[0]
        if cmd not in self._OPTS:
            return

        # Complete option flags — skip flags already present
        used   = {w for w in words[1:] if w.startswith("-")}
        prefix = "" if text.endswith(" ") else words[-1]
        for flag in self._OPTS[cmd]:
            if flag not in used and flag.startswith(prefix):
                yield Completion(flag, start_position=-len(prefix))


def _console_help() -> None:
    t = Table(show_header=True, box=None, padding=(0, 2))
    t.add_column(Text("Command", justify="left"), style="cyan", min_width=38, no_wrap=True)
    t.add_column(Text("Description", justify="left"))
    for cmd, desc in [
        ("isolate",                            "Isolate endpoint from network"),
        ("unisolate",                          "Release network isolation"),
        ("processes",                          "List running processes"),
        ("kill-process --pid N",               "Kill process by PID"),
        ("kill-process --entity-id ID",        "Kill process by entity ID"),
        ("suspend-process --pid N",            "Suspend process by PID"),
        ("get-file --path PATH [--output-dir DIR]",    "Retrieve a file (zip, password: elastic)"),
        ("execute --command CMD [--timeout N]",        "Execute a shell command"),
        ("upload --file PATH [--overwrite] [--no-wait]", "Upload a file to endpoint"),
        ("scan --path PATH",                           "Scan a file or directory"),
        ("memory-dump [--pid N | --entity-id ID]",     "Memory dump (Windows); default: kernel"),
        ("  [--output-dir DIR]",               ""),
        ("status ACTION_ID",                   "Check status of a response action"),
        ("actions",                            "List recent actions for this endpoint"),
        ("alerts [--status open|acknowledged|closed]", "List security detection alerts"),
        ("session-view ALERT_ID",                        "Show Session View process tree"),
        ("session-export ALERT_ID",                    "Export terminal I/O to asciicast file (tty_[comment-]ID.cast)"),
        ("  [--output FILE] [--force]",                "  override filename / overwrite existing"),
        ("  [--gif] [--mp4] [--no-intro]",             "  also convert via agg / agg+ffmpeg / skip animated intro"),
        ("session-play ALERT_ID|FILE.cast",            "Replay terminal I/O live in this terminal"),
        ("  [--all] [-y]",                             "  include all session I/O / skip safety prompt"),
        ("osquery --query SQL",                        "Run osquery live query, wait for results"),
        ("osquery --saved-query-id ID",                "Run a saved osquery query"),
        ("osquery-results ACTION_ID",                  "Show results of a previous osquery run"),
        ("osquery-saved",                              "List saved osquery queries"),
        ("metadata",                           "Show endpoint metadata"),
        ("shell",                              "Semi-interactive shell via wrapped execute actions (Ctrl+D to return)"),
        ("comment [TEXT]",                     "Show or update session comment / ticket ref"),
        ("help",                               "Show this help"),
        ("exit / quit",                        "Exit the console"),
    ]:
        t.add_row(cmd, desc)
    out.print(t)


# ── console ────────────────────────────────────────────────────────────────────


@app.command()
def console(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID to target for this session")],
    comment: Annotated[Optional[str], typer.Option(
        help="Ticket / case reference attached to every API call (e.g. INC-1234)"
    )] = None,
):
    """Interactive Elastic Defend >_ Respond console targeting a single endpoint.

    Every response action in this session runs against the same endpoint.
    Set --comment to a ticket number (e.g. INC-1234) so every API call is
    stamped for traceability. The comment can be updated mid-session with the
    'comment' command.

    Tab-completion is available for all commands and their options.
    """
    _require_comment(comment)
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory, InMemoryHistory

    from .config import CONSOLE_HISTORY_FILE

    client = _client()
    cfg = load_config()

    # Resolve endpoint details for the header
    short_id = endpoint_id[:8]
    hostname = short_id
    console_ip  = ""
    console_mac = ""
    console_os  = ""
    try:
        meta      = client.get_endpoint_metadata(endpoint_id)
        md        = meta.get("metadata", {})
        host      = md.get("host", {})
        hostname  = host.get("hostname") or host.get("name") or short_id
        ips: list = host.get("ip", [])
        macs: list = host.get("mac", [])
        os_info   = host.get("os", {})
        routable    = [ip for ip in ips if not ip.startswith("127.") and ip != "::1" and not ip.lower().startswith("fe80")]
        console_ip  = routable[0] if routable else (ips[0] if ips else "")
        console_mac = macs[0] if macs else ""
        console_os  = (
            os_info.get("full")
            or os_info.get("name", "")
            + (" " + os_info.get("version", "") if os_info.get("version") else "")
        ).strip()
    except EdopsError:
        pass

    session_comment: Optional[str] = comment

    prompt_session: PromptSession = PromptSession(
        history=FileHistory(str(CONSOLE_HISTORY_FILE)) if cfg.persist_history else InMemoryHistory(),
        completer=_ConsoleCompleter(),
        complete_while_typing=True,
    )

    header_parts = [
        f"endpoint=[cyan]{endpoint_id}[/cyan]",
        f"host=[bold]{hostname}[/bold]",
    ]
    if console_os:
        header_parts.append(f"os=[dim]{console_os}[/dim]")
    if console_ip:
        header_parts.append(f"ip=[dim]{console_ip}[/dim]")
    if console_mac:
        header_parts.append(f"mac=[dim]{console_mac}[/dim]")
    out.print("\n[bold]Elastic Defend >_ Respond console[/bold]  " + "  ".join(header_parts))
    if session_comment:
        out.print(f"[dim]Comment: {session_comment}[/dim]")
    else:
        out.print("[dim yellow]Tip: pass --comment INC-1234 or run 'comment INC-1234' to stamp all actions.[/dim yellow]")
    out.print("[dim]Tab-complete available. Type 'help' for commands, Ctrl+D or 'exit' to quit.[/dim]\n")

    prompt_str    = f"[{hostname}]> "
    interrupt_cnt = 0

    while True:
        try:
            line = prompt_session.prompt(prompt_str)
            interrupt_cnt = 0
        except EOFError:
            print()
            break
        except KeyboardInterrupt:
            interrupt_cnt += 1
            if interrupt_cnt >= 2:
                print()
                break
            print("(Ctrl+C again or Ctrl+D to exit)")
            continue

        line = line.strip()
        if not line:
            continue

        try:
            parts = shlex.split(line)
        except ValueError as exc:
            err.print(f"[red]Parse error:[/red] {exc}")
            continue

        cmd  = parts[0].lower()
        args = parts[1:]

        # ── session control ───────────────────────────────────────────────────
        if cmd in ("exit", "quit"):
            break

        elif cmd == "help":
            _console_help()

        elif cmd == "comment":
            if args:
                session_comment = " ".join(args)
                out.print(f"[green]Session comment:[/green] {session_comment}")
            else:
                out.print(f"Comment: {session_comment or '[dim]not set[/dim]'}")

        # ── read-only ─────────────────────────────────────────────────────────
        elif cmd == "metadata":
            try:
                _print_metadata(client.get_endpoint_metadata(endpoint_id))
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        elif cmd == "actions":
            try:
                result = client.list_actions(endpoint_ids=[endpoint_id])
                items  = result.get("data", [])
                total  = result.get("total", len(items))
                t = Table(title=f"Recent actions ({total} total) @ {_ts()}", title_justify="left")
                t.add_column(Text("ID", justify="left"), style="cyan")
                t.add_column(Text("Command", justify="left"))
                t.add_column(Text("Status", justify="left"))
                t.add_column(Text("By", justify="left"))
                t.add_column(Text("Comment", justify="left"), style="dim")
                t.add_column(Text("Started", justify="left"), no_wrap=True)
                for item in items:
                    s     = item.get("status", "pending")
                    color = "green" if s == "successful" else ("red" if s == "failed" else "yellow")
                    t.add_row(
                        item.get("id", "")[:36],
                        item.get("command", ""),
                        f"[{color}]{s}[/{color}]",
                        item.get("createdBy", ""),
                        item.get("comment", ""),
                        (item.get("startedAt") or "")[:19],
                    )
                out.print(t)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        elif cmd == "alerts":
            alert_status = _get_opt(args, "--status")
            try:
                result = client.search_alerts(endpoint_id, status=alert_status)
                _print_alerts(result, f"Alerts — {hostname}", False, base_url=load_config().url)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        elif cmd == "session-view":
            if not args or args[0].startswith("-"):
                err.print("[red]Error:[/red] usage: session-view ALERT_ID")
            else:
                sv_alert_id = args[0]
                try:
                    with out.status("Fetching alert..."):
                        alert_hit = client.get_alert_by_id(sv_alert_id)
                    sv_src               = alert_hit.get("_source", {})
                    sv_session_entity_id = _af(sv_src, "process", "entry_leader", "entity_id")
                    if not sv_session_entity_id:
                        has_process = bool(_af(sv_src, "process", "pid") or _af(sv_src, "process", "entity_id"))
                        if has_process:
                            err.print(
                                "[red]Error:[/red] alert has process data but no session leader "
                                "(process.entry_leader.entity_id is missing).\n"
                                "Session View may be disabled on this Elastic Agent."
                            )
                        else:
                            err.print("[red]Error:[/red] alert has no process data — Session View requires a process-type alert.")
                    else:
                        sv_alerted_entity_id  = _af(sv_src, "process", "entity_id") or ""
                        sv_alert_ts           = _af(sv_src, "@timestamp") or ""
                        sv_session_start_time = _af(sv_src, "process", "entry_leader", "start") or sv_alert_ts
                        sv_rule_name          = (
                            _af(sv_src, "kibana", "alert", "rule", "name")
                            or _af(sv_src, "signal", "rule", "name")
                            or ""
                        )
                        sv_base_url  = cfg.url.rstrip("/")
                        sv_alert_idx = alert_hit.get("_index", "")
                        sv_alert_url = (
                            f"{sv_base_url}/app/security/alerts/redirect/{sv_alert_id}"
                            f"?{urlencode({'index': sv_alert_idx, 'timestamp': sv_alert_ts})}"
                            if sv_base_url else ""
                        )
                        with out.status("Fetching process events..."):
                            sv_proc = client.session_process_events(sv_session_entity_id, sv_session_start_time, "logs-endpoint.events.process-*")
                        with out.status("Fetching I/O events..."):
                            sv_io_events = client.session_io_events(sv_session_entity_id, sv_session_start_time, "logs-endpoint.events.process-*")
                        _print_session_view(sv_proc, sv_io_events, sv_alerted_entity_id, sv_alert_id, sv_rule_name, sv_alert_ts, sv_alert_url)
                except EdopsError as exc:
                    err.print(f"[red]Error:[/red] {exc}")

        elif cmd == "session-export":
            if not args or args[0].startswith("-"):
                err.print("[red]Error:[/red] usage: session-export ALERT_ID [--output FILE] [--force] [--gif] [--mp4] [--no-intro]")
            else:
                se_alert_id = args[0]
                se_output   = _get_opt(args, "--output")
                se_force    = "--force" in args
                se_gif      = "--gif" in args
                se_mp4      = "--mp4" in args
                se_no_intro = "--no-intro" in args
                # Use the active session comment automatically for the filename
                cast_path   = se_output or _cast_filename(se_alert_id, session_comment)
                if Path(cast_path).exists() and not se_force:
                    err.print(f"[red]File already exists:[/red] {cast_path}")
                    err.print("Use [bold]--output PATH[/bold] or [bold]--force[/bold] to overwrite.")
                else:
                    try:
                        with out.status("Fetching alert..."):
                            alert_hit = client.get_alert_by_id(se_alert_id)
                        se_src               = alert_hit.get("_source", {})
                        se_session_entity_id = _af(se_src, "process", "entry_leader", "entity_id")
                        if not se_session_entity_id:
                            err.print("[red]Error:[/red] alert has no session leader — Session View may be disabled on this Elastic Agent.")
                        else:
                            se_alerted_entity_id  = _af(se_src, "process", "entity_id") or ""
                            se_alert_ts           = _af(se_src, "@timestamp") or ""
                            se_session_start_time = _af(se_src, "process", "entry_leader", "start") or se_alert_ts
                            se_rule_name          = (
                                _af(se_src, "kibana", "alert", "rule", "name")
                                or _af(se_src, "signal", "rule", "name")
                                or ""
                            )
                            se_title = (
                                f"edops [{session_comment}]: {se_rule_name or se_alert_id[:16]}"
                                if session_comment else f"edops: {se_rule_name or se_alert_id[:16]}"
                            )
                            se_intro_info: Optional[dict] = None
                            if not se_no_intro:
                                try:
                                    se_ts_fmt = datetime.fromisoformat(se_alert_ts.replace("Z", "+00:00")).strftime("%Y-%m-%d %H:%M UTC")
                                except Exception:
                                    se_ts_fmt = se_alert_ts
                                se_intro_info = {
                                    "rule_name":  se_rule_name,
                                    "host":       _af(se_src, "host", "name") or _af(se_src, "host", "hostname") or "",
                                    "user":       _af(se_src, "user", "name") or "",
                                    "proc":       _af(se_src, "process", "name") or "",
                                    "alert_time": se_ts_fmt,
                                    "alert_id":   se_alert_id,
                                    "comment":    session_comment or "",
                                }
                            with out.status("Fetching process events..."):
                                se_proc = client.session_process_events(se_session_entity_id, se_session_start_time, "logs-endpoint.events.process-*")
                            with out.status("Fetching I/O events..."):
                                se_io = client.session_io_events(se_session_entity_id, se_session_start_time, "logs-endpoint.events.process-*")
                            n = _write_asciicast(se_io, cast_path, title=se_title, alerted_entity_id=se_alerted_entity_id, proc_events=se_proc, intro_info=se_intro_info)
                            if not n:
                                _print_no_io(se_alert_id)
                            else:
                                _print_cast_saved(n, cast_path, gif=se_gif, mp4=se_mp4)
                                stem = cast_path[:-5] if cast_path.endswith(".cast") else cast_path
                                if se_gif:
                                    if _run_converter(["agg", cast_path, f"{stem}.gif"], "agg", "Install: https://github.com/asciinema/agg"):
                                        out.print(f"\nGIF: [bold]{stem}.gif[/bold]")
                                if se_mp4:
                                    import tempfile as _tf
                                    with _tf.NamedTemporaryFile(suffix=".gif", delete=False) as _tmp:
                                        _tmp_gif = _tmp.name
                                    try:
                                        if _run_converter(["agg", cast_path, _tmp_gif], "agg", "Install: https://github.com/asciinema/agg"):
                                            _ffmpeg_cmd = ["ffmpeg", "-hide_banner", "-loglevel", "quiet", "-stats"] + (["-y"] if se_force else []) + ["-i", _tmp_gif, f"{stem}.mp4"]
                                            if _run_converter(_ffmpeg_cmd, "ffmpeg", "Install: https://ffmpeg.org"):
                                                out.print(f"\nMP4: [bold]{stem}.mp4[/bold]")
                                    finally:
                                        Path(_tmp_gif).unlink(missing_ok=True)
                    except EdopsError as exc:
                        err.print(f"[red]Error:[/red] {exc}")

        elif cmd == "session-play":
            if not args or args[0].startswith("-"):
                err.print("[red]Error:[/red] usage: session-play ALERT_ID|FILE.cast [--all] [-y]")
            else:
                import shutil as _shutil, subprocess as _sp, tempfile as _tf2
                sp_target   = args[0]
                sp_all      = "--all" in args
                sp_yes      = "-y" in args or "--yes" in args
                sp_path     = Path(sp_target)
                sp_is_cast  = sp_path.exists() or sp_target.endswith(".cast")

                if not sp_yes:
                    err.print("[yellow]Warning: Rendering untrusted TTY output. Escape sequences may affect your terminal.[/yellow]")
                    err.print("[dim]Exporting as GIF/MP4 is safer: session-export --gif[/dim]")
                    sp_ok = input("Continue? [y/N]: ").strip().lower()
                    if sp_ok != "y":
                        continue

                sp_temp_cast: Optional[str] = None
                try:
                    if sp_is_cast:
                        if not sp_path.exists():
                            err.print(f"[red]File not found:[/red] {sp_target}")
                            continue
                        sp_cast = str(sp_path)
                    else:
                        with out.status("Fetching alert..."):
                            alert_hit = client.get_alert_by_id(sp_target)
                        sp_src               = alert_hit.get("_source", {})
                        sp_session_entity_id = _af(sp_src, "process", "entry_leader", "entity_id")
                        if not sp_session_entity_id:
                            err.print("[red]Error:[/red] alert has no session leader.")
                            continue
                        sp_alerted_eid    = _af(sp_src, "process", "entity_id") or ""
                        sp_alert_ts       = _af(sp_src, "@timestamp") or ""
                        sp_session_start  = _af(sp_src, "process", "entry_leader", "start") or sp_alert_ts
                        with out.status("Fetching process events..."):
                            sp_proc = client.session_process_events(sp_session_entity_id, sp_session_start, "logs-endpoint.events.process-*")
                        with out.status("Fetching I/O events..."):
                            sp_io = client.session_io_events(sp_session_entity_id, sp_session_start, "logs-endpoint.events.process-*")
                        if not sp_all:
                            other_eids = {
                                _af(ev.get("_source", ev), "process", "entity_id")
                                for ev in sp_io
                                if _af(ev.get("_source", ev), "process", "entity_id") != sp_alerted_eid
                                and _af(ev.get("_source", ev), "process", "io", "text")
                            }
                            if other_eids:
                                out.print(f"[dim]Note: {len(other_eids)} other process(es) have I/O in this session. Use --all to include them.[/dim]")
                            sp_io = [ev for ev in sp_io if _af(ev.get("_source", ev), "process", "entity_id") == sp_alerted_eid]
                        with _tf2.NamedTemporaryFile(suffix=".cast", delete=False, mode="w", encoding="utf-8") as _tmp2:
                            sp_temp_cast = _tmp2.name
                        n = _write_asciicast(sp_io, sp_temp_cast, alerted_entity_id=sp_alerted_eid, proc_events=sp_proc)
                        if not n:
                            _print_no_io(sp_target)
                            continue
                        sp_cast = sp_temp_cast

                    if not _shutil.which("asciinema"):
                        err.print("[red]asciinema not found on PATH.[/red] Install: https://github.com/asciinema/asciinema")
                        continue
                    _sp.run(["asciinema", "play", sp_cast])
                    err.print("\n[dim]If your terminal looks wrong, run: [bold]reset[/bold][/dim]")
                    err.print("[dim]For safer viewing: session-export --gif (then open the GIF)[/dim]")
                except EdopsError as exc:
                    err.print(f"[red]Error:[/red] {exc}")
                finally:
                    if sp_temp_cast:
                        Path(sp_temp_cast).unlink(missing_ok=True)

        elif cmd == "osquery":
            oq_query   = _get_opt(args, "--query")
            oq_saved   = _get_opt(args, "--saved-query-id")
            oq_pack    = _get_opt(args, "--pack-id")
            oq_no_wait = "--no-wait" in args
            if not any([oq_query, oq_saved, oq_pack]):
                err.print("[red]Error:[/red] provide --query SQL, --saved-query-id ID, or --pack-id ID")
                continue
            try:
                result    = client.osquery_run([endpoint_id], query=oq_query, saved_query_id=oq_saved, pack_id=oq_pack)
                action_id = result.get("data", {}).get("action_id") or result.get("data", {}).get("id", "")
                if oq_no_wait:
                    out.print(f"[bold cyan]Action ID:[/bold cyan] {action_id}")
                else:
                    with out.status("Waiting for osquery results..."):
                        result = client.wait_for_osquery(action_id)
                    oq_queries = result.get("data", {}).get("queries", [])
                    for q in oq_queries:
                        if q.get("failed", 0):
                            err_msg = q.get("error_message") or q.get("error") or "unknown error"
                            err.print(f"[yellow]Warning:[/yellow] query failed on {q.get('failed')} agent(s): {err_msg}")
                    oq_query_action_id = oq_queries[0].get("action_id") if oq_queries else action_id
                    expected_docs = sum(q.get("docs", 0) for q in oq_queries)
                    if expected_docs > 0:
                        with out.status("Waiting for results to be indexed..."):
                            rows_result = client.wait_for_osquery_results(action_id, query_action_id=oq_query_action_id, expected_docs=expected_docs)
                    else:
                        rows_result = client.osquery_results(action_id, query_action_id=oq_query_action_id)
                    _print_osquery_results(rows_result, as_json=False, action_id=action_id)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        elif cmd == "osquery-results":
            if not args:
                err.print("[red]Error:[/red] provide an action ID")
                continue
            try:
                _print_osquery_results(client.osquery_results(args[0], agent_id=endpoint_id), as_json=False)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        elif cmd == "osquery-saved":
            try:
                result = client.osquery_saved_queries()
                data   = result.get("data", [])
                items  = data if isinstance(data, list) else data.get("items", data.get("saved_queries", []))
                if not items:
                    out.print("[yellow]No saved queries found.[/yellow]")
                else:
                    t = Table(title=f"Saved osquery queries @ {_ts()}", title_justify="left")
                    t.add_column(Text("ID", justify="left"), style="cyan")
                    t.add_column(Text("Name", justify="left"))
                    t.add_column(Text("Query", justify="left"), max_width=60, style="dim")
                    for item in items:
                        t.add_row(item.get("id", ""), item.get("name", ""), item.get("query", ""))
                    out.print(t)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        elif cmd == "status":
            if not args:
                err.print("[red]Error:[/red] provide an action ID")
                continue
            try:
                _print_action(client.get_action(args[0]), False)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        # ── isolation ─────────────────────────────────────────────────────────
        elif cmd in ("isolate", "unisolate"):
            try:
                result    = client.submit_action(cmd, [endpoint_id], comment=session_comment)
                action_id = result["data"]["id"]
                with out.status(f"Waiting..."):
                    result = client.wait_for_action(action_id)
                _print_action(result, False)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        # ── processes ─────────────────────────────────────────────────────────
        elif cmd == "processes":
            try:
                result    = client.submit_action("running_procs", [endpoint_id], comment=session_comment)
                action_id = result["data"]["id"]
                with out.status("Retrieving process list..."):
                    result = client.wait_for_action(action_id)
                _print_processes(result, endpoint_id, False)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        elif cmd in ("kill-process", "suspend-process"):
            pid, entity_id = _parse_pid_entity(args)
            if pid is None and entity_id is None:
                err.print("[red]Error:[/red] provide --pid N or --entity-id ID")
                continue
            params: dict = {}
            if pid       is not None: params["pid"]       = pid
            if entity_id is not None: params["entity_id"] = entity_id
            action = "kill_process" if cmd == "kill-process" else "suspend_process"
            try:
                result    = client.submit_action(action, [endpoint_id], parameters=params, comment=session_comment)
                action_id = result["data"]["id"]
                with out.status("Waiting..."):
                    result = client.wait_for_action(action_id)
                _print_action(result, False)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        # ── file operations ───────────────────────────────────────────────────
        elif cmd == "get-file":
            path       = _get_opt(args, "--path")
            output_dir = _get_opt(args, "--output-dir") or "."
            if not path:
                err.print("[red]Error:[/red] provide --path PATH")
                continue
            try:
                result    = client.submit_action("get_file", [endpoint_id], parameters={"path": path}, comment=session_comment)
                action_id = result["data"]["id"]
                with out.status(f"Retrieving {path} ..."):
                    result = client.wait_for_action(action_id, wait_for_outputs=True)
                _save_file_output(client, result, action_id, endpoint_id, output_dir, comment=session_comment)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        elif cmd == "execute":
            command    = _get_opt(args, "--command")
            timeout    = int(_get_opt(args, "--timeout") or "60")
            output_dir = _get_opt(args, "--output-dir") or "."
            if not command:
                err.print("[red]Error:[/red] provide --command CMD")
                continue
            try:
                result    = client.submit_action(
                    "execute", [endpoint_id],
                    parameters={"command": command, "timeout": timeout},
                    comment=session_comment,
                )
                action_id = result["data"]["id"]
                with out.status("Executing..."):
                    result = client.wait_for_action(action_id, timeout=timeout + 30)
                data   = result.get("data", {})
                ep_out = data.get("outputs", {}).get(endpoint_id, {})
                otype  = ep_out.get("type")
                if otype == "json":
                    content = ep_out.get("content", {})
                    if stdout := content.get("stdout", ""):
                        out.print(f"[bold]stdout:[/bold]\n{stdout}")
                    if stderr_txt := content.get("stderr", ""):
                        out.print(f"[bold yellow]stderr:[/bold yellow]\n{stderr_txt}")
                    rc = content.get("return_code", content.get("exit_code"))
                    if rc is not None:
                        out.print(f"[bold]return code:[/bold] {rc}")
                else:
                    _save_file_output(client, result, action_id, endpoint_id, output_dir)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        elif cmd == "upload":
            file_path = _get_opt(args, "--file")
            overwrite = "--overwrite" in args
            no_wait = "--no-wait" in args
            if not file_path:
                err.print("[red]Error:[/red] provide --file PATH")
                continue
            try:
                with out.status(f"Uploading {file_path} ..."):
                    result = client.upload_file([endpoint_id], file_path, overwrite=overwrite, comment=session_comment)
                if no_wait:
                    _print_action(result, False)
                else:
                    action_id = result["data"]["id"]
                    with out.status("Waiting for upload to complete..."):
                        result = client.wait_for_action(action_id)
                    _print_action(result, False)
                    data = result.get("data", {})
                    ep_out = data.get("outputs", {}).get(endpoint_id, {})
                    content = ep_out.get("content", {})
                    path = content.get("path")
                    if path:
                        out.print(f"[green]File saved on endpoint at:[/green] {path}")
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        elif cmd == "scan":
            path = _get_opt(args, "--path")
            if not path:
                err.print("[red]Error:[/red] provide --path PATH")
                continue
            try:
                result    = client.submit_action("scan", [endpoint_id], parameters={"path": path}, comment=session_comment)
                action_id = result["data"]["id"]
                with out.status(f"Scanning {path} ..."):
                    result = client.wait_for_action(action_id)
                _print_action(result, False)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        # ── memory dump ───────────────────────────────────────────────────────
        elif cmd == "memory-dump":
            pid, entity_id = _parse_pid_entity(args)
            output_dir     = _get_opt(args, "--output-dir") or "."
            if pid is not None:
                mdparams     = {"type": "process", "pid": pid}
                required_cap = "memdump_process"
            elif entity_id is not None:
                mdparams     = {"type": "process", "entity_id": entity_id}
                required_cap = "memdump_process"
            else:
                mdparams     = {"type": "kernel"}
                required_cap = "memdump_kernel"
            try:
                with out.status("Checking endpoint capabilities..."):
                    _check_capability(client, endpoint_id, required_cap)
                result    = client.submit_action("memory_dump", [endpoint_id], parameters=mdparams, comment=session_comment)
                action_id = result["data"]["id"]
                with out.status("Capturing memory dump (this may take several minutes)..."):
                    result = client.wait_for_action(action_id, timeout=600, wait_for_outputs=True)
                data      = result.get("data", {})
                ep_out    = data.get("outputs", {}).get(endpoint_id, {})
                content   = ep_out.get("content", {})
                dump_path = content.get("dump_file_path") or content.get("path")
                if dump_path:
                    out.print(f"[green]Dump written on endpoint at:[/green] {dump_path}")
                    out.print(f"Retrieve with: [bold]get-file --path \"{dump_path}\" --output-dir {output_dir}[/bold]")
                else:
                    _save_file_output(client, result, action_id, endpoint_id, output_dir)
            except EdopsError as exc:
                err.print(f"[red]Error:[/red] {exc}")

        # ── shell ─────────────────────────────────────────────────────────────
        elif cmd == "shell":
            from prompt_toolkit import PromptSession
            from prompt_toolkit.history import FileHistory, InMemoryHistory

            from .config import SHELL_HISTORY_FILE

            shell_session: PromptSession = PromptSession(
                history=FileHistory(str(SHELL_HISTORY_FILE)) if cfg.persist_history else InMemoryHistory()
            )
            shell_prompt = f"[{hostname}/shell]$ "
            out.print("[dim]Entering shell — Ctrl+D or 'exit' to return to console.[/dim]")
            shell_int = 0

            while True:
                try:
                    shell_cmd = shell_session.prompt(shell_prompt)
                    shell_int = 0
                except EOFError:
                    print()
                    break
                except KeyboardInterrupt:
                    shell_int += 1
                    if shell_int >= 2:
                        print()
                        break
                    print("(Ctrl+C again or Ctrl+D to exit shell)")
                    continue

                shell_cmd = shell_cmd.strip()
                if not shell_cmd:
                    continue
                if shell_cmd in ("exit", "quit"):
                    break

                try:
                    with _Spinner("submitting"):
                        result = client.submit_action(
                            "execute", [endpoint_id],
                            parameters={"command": shell_cmd, "timeout": 60},
                            comment=session_comment,
                        )
                    action_id = result["data"]["id"]
                    with _Spinner("waiting"):
                        result = client.wait_for_action(action_id, timeout=90)

                    _print_shell_output(client, result, endpoint_id, action_id)

                except EdopsError as exc:
                    sys.stderr.write(f"\033[31mError:\033[0m {exc}\n")
                    sys.stderr.flush()
                except KeyboardInterrupt:
                    sys.stderr.write("\n[interrupted]\n")
                    sys.stderr.flush()

            out.print("[dim]Shell ended — back in console.[/dim]")

        else:
            err.print(f"[yellow]Unknown command:[/yellow] {cmd!r}  (type 'help' for available commands)")

    out.print("\n[dim]Console session ended.[/dim]")


# ── processes ──────────────────────────────────────────────────────────────────


@app.command()
def processes(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    comment: Annotated[Optional[str], typer.Option(help="Reason / ticket reference")] = None,
    no_wait: Annotated[bool, typer.Option("--no-wait", help="Return action ID without waiting")] = False,
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """List running processes on an endpoint."""
    _require_comment(comment)
    client = _client()
    try:
        result = client.submit_action("running_procs", [endpoint_id], comment=comment)
        action_id = result["data"]["id"]
        if no_wait:
            _print_action(result, as_json)
            return
        with out.status("Retrieving process list..."):
            result = client.wait_for_action(action_id)
        _print_processes(result, endpoint_id, as_json)
    except EdopsError as exc:
        _handle(exc)


# ── process management ─────────────────────────────────────────────────────────


@app.command("kill-process")
def kill_process(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    pid: Annotated[Optional[int], typer.Option(help="Process ID")] = None,
    entity_id: Annotated[Optional[str], typer.Option(help="Process entity_id")] = None,
    comment: Annotated[Optional[str], typer.Option(help="Reason / comment")] = None,
    wait: Annotated[bool, typer.Option("--wait", help="Poll until action completes")] = False,
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """Terminate a process on an endpoint."""
    _require_comment(comment)
    if pid is None and entity_id is None:
        err.print("[red]Error:[/red] Provide --pid or --entity-id")
        raise typer.Exit(1)
    params: dict = {}
    if pid is not None:
        params["pid"] = pid
    if entity_id is not None:
        params["entity_id"] = entity_id
    client = _client()
    try:
        result = client.submit_action("kill_process", [endpoint_id], parameters=params, comment=comment)
        if wait:
            with out.status("Waiting..."):
                result = client.wait_for_action(result["data"]["id"])
        _print_action(result, as_json)
    except EdopsError as exc:
        _handle(exc)


@app.command("suspend-process")
def suspend_process(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    pid: Annotated[Optional[int], typer.Option(help="Process ID")] = None,
    entity_id: Annotated[Optional[str], typer.Option(help="Process entity_id")] = None,
    comment: Annotated[Optional[str], typer.Option(help="Reason / comment")] = None,
    wait: Annotated[bool, typer.Option("--wait", help="Poll until action completes")] = False,
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """Suspend a process on an endpoint."""
    _require_comment(comment)
    if pid is None and entity_id is None:
        err.print("[red]Error:[/red] Provide --pid or --entity-id")
        raise typer.Exit(1)
    params: dict = {}
    if pid is not None:
        params["pid"] = pid
    if entity_id is not None:
        params["entity_id"] = entity_id
    client = _client()
    try:
        result = client.submit_action("suspend_process", [endpoint_id], parameters=params, comment=comment)
        if wait:
            with out.status("Waiting..."):
                result = client.wait_for_action(result["data"]["id"])
        _print_action(result, as_json)
    except EdopsError as exc:
        _handle(exc)


# ── execute ────────────────────────────────────────────────────────────────────


@app.command()
def execute(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    command: Annotated[str, typer.Option(help="Shell command to run")],
    timeout: Annotated[int, typer.Option(help="Command timeout in seconds (max 600)")] = 60,
    output_dir: Annotated[Optional[str], typer.Option(help="Save output zip to this directory")] = None,
    comment: Annotated[Optional[str], typer.Option(help="Reason / comment")] = None,
    no_wait: Annotated[bool, typer.Option("--no-wait", help="Return action ID without waiting")] = False,
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """Execute a shell command on an endpoint."""
    _require_comment(comment)
    client = _client()
    try:
        params = {"command": command, "timeout": timeout}
        result = client.submit_action("execute", [endpoint_id], parameters=params, comment=comment)
        action_id = result["data"]["id"]
        if no_wait:
            _print_action(result, as_json)
            return
        with out.status("Executing command..."):
            result = client.wait_for_action(action_id, timeout=timeout + 30)

        if as_json:
            typer.echo(json.dumps(result, indent=2))
            return

        data = result.get("data", {})
        ep_out = data.get("outputs", {}).get(endpoint_id, {})
        otype = ep_out.get("type")

        if otype == "json":
            content = ep_out.get("content", {})
            if stdout := content.get("stdout", ""):
                out.print(f"[bold]stdout:[/bold]\n{stdout}")
            if stderr := content.get("stderr", ""):
                out.print(f"[bold yellow]stderr:[/bold yellow]\n{stderr}")
            rc = content.get("return_code", content.get("exit_code"))
            if rc is not None:
                out.print(f"[bold]return code:[/bold] {rc}")
        elif otype == "file" and output_dir:
            _save_file_output(client, result, action_id, endpoint_id, output_dir)
        else:
            _print_action(result, as_json)
    except EdopsError as exc:
        _handle(exc)


# ── file operations ────────────────────────────────────────────────────────────


@app.command("get-file")
def get_file(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    path: Annotated[str, typer.Option(help="Absolute path of file to retrieve")],
    output_dir: Annotated[str, typer.Option(help="Directory to save the retrieved zip")] = ".",
    comment: Annotated[Optional[str], typer.Option(help="Reason / comment")] = None,
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """Retrieve a file from an endpoint (saved as password-protected zip, password: elastic)."""
    _require_comment(comment)
    client = _client()
    try:
        result = client.submit_action("get_file", [endpoint_id], parameters={"path": path}, comment=comment)
        action_id = result["data"]["id"]
        with out.status(f"Retrieving {path} ..."):
            result = client.wait_for_action(action_id, wait_for_outputs=True)

        if as_json:
            typer.echo(json.dumps(result, indent=2))
            return

        _save_file_output(client, result, action_id, endpoint_id, output_dir, comment=comment)
    except EdopsError as exc:
        _handle(exc)


@app.command()
def upload(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    file: Annotated[str, typer.Option(help="Local file to upload")],
    overwrite: Annotated[bool, typer.Option("--overwrite", help="Overwrite if file exists")] = False,
    comment: Annotated[Optional[str], typer.Option(help="Reason / comment")] = None,
    no_wait: Annotated[bool, typer.Option("--no-wait", help="Return immediately without polling for completion")] = False,
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """Upload a file to an endpoint."""
    _require_comment(comment)
    client = _client()
    try:
        with out.status(f"Uploading {file} ..."):
            result = client.upload_file([endpoint_id], file, overwrite=overwrite, comment=comment)
        if no_wait:
            _print_action(result, as_json)
            return
        action_id = result["data"]["id"]
        with out.status("Waiting for upload to complete..."):
            result = client.wait_for_action(action_id)
        _print_action(result, as_json)
        if not as_json:
            data = result.get("data", {})
            ep_out = data.get("outputs", {}).get(endpoint_id, {})
            content = ep_out.get("content", {})
            path = content.get("path")
            if path:
                out.print(f"[green]File saved on endpoint at:[/green] {path}")
    except EdopsError as exc:
        _handle(exc)


@app.command()
def scan(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    path: Annotated[str, typer.Option(help="Full path of the file or directory to scan")],
    comment: Annotated[Optional[str], typer.Option(help="Reason / comment")] = None,
    wait: Annotated[bool, typer.Option("--wait", help="Poll until scan completes")] = False,
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """Scan a file or directory on an endpoint."""
    _require_comment(comment)
    client = _client()
    try:
        result = client.submit_action("scan", [endpoint_id], parameters={"path": path}, comment=comment)
        if wait:
            action_id = result["data"]["id"]
            with out.status(f"Scanning {path} ..."):
                result = client.wait_for_action(action_id)
        _print_action(result, as_json)
    except EdopsError as exc:
        _handle(exc)


# ── memory dump ────────────────────────────────────────────────────────────────


@app.command("memory-dump")
def memory_dump(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    kernel: Annotated[bool, typer.Option("--kernel", help="Full kernel memory dump (default)")] = False,
    pid: Annotated[Optional[int], typer.Option(help="Process ID for a process-level dump")] = None,
    entity_id: Annotated[Optional[str], typer.Option(help="Process entity_id for a process-level dump")] = None,
    output_dir: Annotated[str, typer.Option(help="Directory to save retrieved dump zip")] = ".",
    comment: Annotated[Optional[str], typer.Option(help="Reason / comment")] = None,
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """Capture a memory dump from an endpoint (Windows only).

    Defaults to a full kernel dump (--kernel). For a process dump provide
    --pid or --entity-id.

    Checks endpoint capabilities before submitting. The dump is written to the
    endpoint first; when complete the output contains the remote path — use
    'edops get-file' to retrieve it.
    """
    _require_comment(comment)
    if pid is not None and entity_id is not None:
        err.print("[red]Error:[/red] Provide --pid or --entity-id, not both")
        raise typer.Exit(1)

    if pid is not None:
        params: dict = {"type": "process", "pid": pid}
    elif entity_id is not None:
        params = {"type": "process", "entity_id": entity_id}
    else:
        params = {"type": "kernel"}

    client = _client()
    required_cap = "memdump_process" if params["type"] == "process" else "memdump_kernel"
    try:
        with out.status("Checking endpoint capabilities..."):
            _check_capability(client, endpoint_id, required_cap)
        result = client.submit_action(
            "memory_dump", [endpoint_id],
            parameters=params,
            comment=comment,
        )
        action_id = result["data"]["id"]
        with out.status("Capturing memory dump (this may take several minutes)..."):
            result = client.wait_for_action(action_id, timeout=600, wait_for_outputs=True)

        if as_json:
            typer.echo(json.dumps(result, indent=2))
            return

        data = result.get("data", {})
        ep_out = data.get("outputs", {}).get(endpoint_id, {})
        content = ep_out.get("content", {})

        dump_path = content.get("dump_file_path") or content.get("path")
        if dump_path:
            out.print(f"[green]Dump written on endpoint at:[/green] {dump_path}")
            out.print(f"Retrieve it with: [bold]edops get-file {endpoint_id} --path \"{dump_path}\" --output-dir {output_dir}[/bold]")
        elif ep_out.get("type") == "file":
            _save_file_output(client, result, action_id, endpoint_id, output_dir)
        else:
            out.print("[yellow]Dump action completed. Check the output below for the file path:[/yellow]")
            typer.echo(json.dumps(result.get("data", {}).get("outputs", {}), indent=2))
    except EdopsError as exc:
        _handle(exc)


# ── isolation ──────────────────────────────────────────────────────────────────


@app.command()
def isolate(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    comment: Annotated[Optional[str], typer.Option(help="Reason / comment")] = None,
    wait: Annotated[bool, typer.Option("--wait", help="Poll until action completes")] = False,
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """Isolate a host from the network."""
    _require_comment(comment)
    client = _client()
    try:
        result = client.submit_action("isolate", [endpoint_id], comment=comment)
        if wait:
            with out.status("Waiting for isolation to complete..."):
                result = client.wait_for_action(result["data"]["id"])
        _print_action(result, as_json)
    except EdopsError as exc:
        _handle(exc)


@app.command()
def unisolate(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    comment: Annotated[Optional[str], typer.Option(help="Reason / comment")] = None,
    wait: Annotated[bool, typer.Option("--wait", help="Poll until action completes")] = False,
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """Release a host from network isolation."""
    _require_comment(comment)
    client = _client()
    try:
        result = client.submit_action("unisolate", [endpoint_id], comment=comment)
        if wait:
            with out.status("Waiting..."):
                result = client.wait_for_action(result["data"]["id"])
        _print_action(result, as_json)
    except EdopsError as exc:
        _handle(exc)


# ── shell ──────────────────────────────────────────────────────────────────────


@app.command()
def shell(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    comment: Annotated[Optional[str], typer.Option(help="Ticket / case reference attached to every execute action")] = None,
    timeout: Annotated[int, typer.Option(help="Per-command timeout in seconds (max 600)")] = 60,
):
    """Semi-interactive command shell (wrapped execute actions) targetting a single endpoint.

    Each command is dispatched as an execute response action. stdout/stderr are
    extracted from the returned password-protected zip (password: elastic) and
    printed to the terminal as if running locally.

    Exit with Ctrl+D, type 'exit' / 'quit', or press Ctrl+C twice.
    """
    _require_comment(comment)
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory, InMemoryHistory

    from .config import SHELL_HISTORY_FILE

    client = _client()
    cfg = load_config()
    short = endpoint_id[:8]

    out.print(f"\n[bold]Edops Shell[/bold]  [cyan]{endpoint_id}[/cyan]")
    out.print("[dim]Ctrl+D or 'exit' to quit  ·  commands routed via Kibana execute action[/dim]\n")

    history = FileHistory(str(SHELL_HISTORY_FILE)) if cfg.persist_history else InMemoryHistory()
    session: PromptSession = PromptSession(history=history)
    prompt_str = f"[{short}]> "
    interrupt_count = 0

    while True:
        try:
            cmd = session.prompt(prompt_str)
            interrupt_count = 0
        except EOFError:
            print()
            break
        except KeyboardInterrupt:
            interrupt_count += 1
            if interrupt_count >= 2:
                print()
                break
            print("(Ctrl+C again or Ctrl+D to exit)")
            continue

        cmd = cmd.strip()
        if not cmd:
            continue
        if cmd in ("exit", "quit"):
            break

        try:
            params: dict = {"command": cmd, "timeout": timeout}
            with _Spinner("submitting"):
                result = client.submit_action("execute", [endpoint_id], parameters=params, comment=comment)
            action_id = result["data"]["id"]

            with _Spinner("waiting"):
                result = client.wait_for_action(action_id, timeout=timeout + 30)

            _print_shell_output(client, result, endpoint_id, action_id)

        except EdopsError as exc:
            sys.stderr.write(f"\033[31mError:\033[0m {exc}\n")
            sys.stderr.flush()
        except KeyboardInterrupt:
            sys.stderr.write("\n[interrupted]\n")
            sys.stderr.flush()

    out.print("\n[dim]Shell session ended.[/dim]")


# ── osquery ────────────────────────────────────────────────────────────────────

app.add_typer(osquery_app, name="osquery")


@osquery_app.command("run")
def osquery_run_cmd(
    endpoint_id: Annotated[str, typer.Argument(help="Endpoint agent ID")],
    query: Annotated[Optional[str], typer.Option(help="SQL query to execute")] = None,
    saved_query_id: Annotated[Optional[str], typer.Option(help="Saved query ID")] = None,
    pack_id: Annotated[Optional[str], typer.Option(help="Pack ID")] = None,
    timeout: Annotated[int, typer.Option(help="Seconds to wait for results")] = 60,
    no_wait: Annotated[bool, typer.Option("--no-wait", help="Return action ID without waiting")] = False,
    as_json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
):
    """Run an osquery live query on an endpoint and display the results.

    Exactly one of --query, --saved-query-id, or --pack-id must be supplied.
    """
    if not any([query, saved_query_id, pack_id]):
        err.print("[red]Error:[/red] provide --query SQL, --saved-query-id ID, or --pack-id ID")
        raise typer.Exit(1)

    client = _client()
    try:
        result    = client.osquery_run([endpoint_id], query=query, saved_query_id=saved_query_id, pack_id=pack_id)
        action_id = result.get("data", {}).get("action_id") or result.get("data", {}).get("id", "")

        if no_wait:
            queries_nowait = result.get("data", {}).get("queries", [])
            query_action_id_nowait = queries_nowait[0].get("action_id") if queries_nowait else ""
            if as_json:
                typer.echo(json.dumps(result, indent=2))
            else:
                out.print(f"[bold cyan]Action ID:[/bold cyan]       {action_id}")
                if query_action_id_nowait:
                    out.print(f"[cyan]Query Action ID:[/cyan]  {query_action_id_nowait}")
                out.print(f"[dim]Fetch results later: edops osquery results {action_id} {query_action_id_nowait}[/dim]")
            return

        with out.status(f"Waiting for osquery results (timeout: {timeout}s)..."):
            result = client.wait_for_osquery(action_id, timeout=timeout)

        if as_json:
            typer.echo(json.dumps(result, indent=2))
            return

        queries = result.get("data", {}).get("queries", [])

        # Surface per-query errors (e.g. SQL syntax failures)
        for q in queries:
            if q.get("failed", 0):
                err_msg = q.get("error_message") or q.get("error") or "unknown error"
                err.print(f"[yellow]Warning:[/yellow] query failed on {q.get('failed')} agent(s): {err_msg}")

        # The second path segment of the results endpoint is the inner queries[].action_id,
        # which is what Kibana uses as the action_id filter in its ES query.
        query_action_id = queries[0].get("action_id") if queries else action_id
        expected_docs = sum(q.get("docs", 0) for q in queries)
        if expected_docs > 0:
            with out.status("Waiting for results to be indexed..."):
                rows_result = client.wait_for_osquery_results(action_id, query_action_id=query_action_id, expected_docs=expected_docs)
        else:
            rows_result = client.osquery_results(action_id, query_action_id=query_action_id)
        _print_osquery_results(rows_result, as_json=False, action_id=action_id)
        out.print(f"[bold cyan]Action ID:[/bold cyan]       {action_id}")
        out.print(f"[cyan]Query Action ID:[/cyan]  {query_action_id}")

    except EdopsError as exc:
        _handle(exc)


@osquery_app.command("results")
def osquery_results_cmd(
    action_id: Annotated[str, typer.Argument(help="Live query action ID")],
    query_action_id: Annotated[str, typer.Argument(help="Inner query action ID (queries[0].action_id from the live query response)")],
    page: Annotated[int, typer.Option(help="Page index (0-based)")] = 0,
    page_size: Annotated[int, typer.Option(help="Max rows to fetch")] = 100,
    as_json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
):
    """Fetch and display results of a previously submitted osquery live query."""
    client = _client()
    try:
        result = client.osquery_results(action_id, query_action_id=query_action_id, page=page, page_size=page_size)
        _print_osquery_results(result, as_json)
    except EdopsError as exc:
        _handle(exc)


@osquery_app.command("saved-queries")
def osquery_saved_cmd(
    page: Annotated[int, typer.Option(help="Page number")] = 1,
    page_size: Annotated[int, typer.Option(help="Results per page")] = 20,
    as_json: Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
):
    """List saved osquery queries."""
    client = _client()
    try:
        result = client.osquery_saved_queries(page=page, page_size=page_size)
        if as_json:
            typer.echo(json.dumps(result, indent=2))
            return
        data  = result.get("data", [])
        items = data if isinstance(data, list) else data.get("items", data.get("saved_queries", []))
        total = result.get("total", len(items))
        if not items:
            out.print("[yellow]No saved queries found.[/yellow]")
            return
        t = Table(title=f"Saved osquery queries  (total: {total}) @ {_ts()}", title_justify="left")
        t.add_column(Text("ID", justify="left"), style="cyan")
        t.add_column(Text("Name", justify="left"))
        t.add_column(Text("Description", justify="left"), max_width=50)
        t.add_column(Text("Query", justify="left"), max_width=60, style="dim")
        for item in items:
            t.add_row(
                item.get("id", ""),
                item.get("name", item.get("id", "")),
                item.get("description", ""),
                item.get("query", ""),
            )
        out.print(t)
    except EdopsError as exc:
        _handle(exc)


# ── actions ────────────────────────────────────────────────────────────────────


@app.command()
def actions(
    endpoint_id: Annotated[Optional[str], typer.Argument(help="Endpoint agent ID — omit to show all recent actions")] = None,
    command: Annotated[Optional[str], typer.Option(help="Filter by command type")] = None,
    page: Annotated[int, typer.Option(help="Page number")] = 1,
    page_size: Annotated[int, typer.Option(help="Results per page (max 100)")] = 20,
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """List recent response actions."""
    client = _client()
    try:
        result = client.list_actions(
            endpoint_ids=[endpoint_id] if endpoint_id else None,
            commands=[command] if command else None,
            page=page,
            page_size=page_size,
        )
        if as_json:
            typer.echo(json.dumps(result, indent=2))
            return
        items = result.get("data", [])
        total = result.get("total", len(items))
        t = Table(title=f"Response actions  (total: {total}) @ {_ts()}", title_justify="left")
        t.add_column(Text("ID", justify="left"), style="cyan")
        t.add_column(Text("Command", justify="left"))
        t.add_column(Text("Status", justify="left"))
        t.add_column(Text("By", justify="left"))
        t.add_column(Text("Comment", justify="left"), style="dim")
        t.add_column(Text("Agents", justify="left"))
        t.add_column(Text("Started", justify="left"), no_wrap=True)
        for item in items:
            s = item.get("status", "pending")
            color = "green" if s == "successful" else ("red" if s == "failed" else "yellow")
            t.add_row(
                item.get("id", "")[:36],
                item.get("command", ""),
                f"[{color}]{s}[/{color}]",
                item.get("createdBy", ""),
                item.get("comment", ""),
                ", ".join(item.get("agents", []))[:40],
                (item.get("startedAt") or "")[:19],
            )
        out.print(t)
    except EdopsError as exc:
        _handle(exc)


# ── action status ──────────────────────────────────────────────────────────────


@app.command()
def status(
    action_id: Annotated[str, typer.Argument(help="Action ID to inspect")],
    as_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
):
    """Get the status and output of a response action."""
    client = _client()
    try:
        result = client.get_action(action_id)
        if as_json:
            typer.echo(json.dumps(result, indent=2))
            return
        _print_action(result, as_json)
        data = result.get("data", {})
        agent_state = data.get("agentState", {})
        if agent_state:
            t = Table(title=f"Agent state @ {_ts()}", title_justify="left")
            t.add_column(Text("Agent ID", justify="left"), style="cyan")
            t.add_column(Text("Completed", justify="left"))
            t.add_column(Text("Successful", justify="left"))
            t.add_column(Text("Completed at", justify="left"))
            for agent, s in agent_state.items():
                ok = s.get("wasSuccessful")
                t.add_row(
                    agent,
                    "yes" if s.get("isCompleted") else "no",
                    "[green]yes[/green]" if ok else "[red]no[/red]",
                    s.get("completedAt", ""),
                )
            out.print(t)
        if errors := data.get("errors", []):
            out.print(f"[red]Errors:[/red] {'; '.join(errors)}")
    except EdopsError as exc:
        _handle(exc)


# ── alerts ─────────────────────────────────────────────────────────────────────


@app.command()
def alerts(
    endpoint_id: Annotated[Optional[str], typer.Argument(help="Endpoint agent ID - omit to query all alerts")] = None,
    status:    Annotated[Optional[str], typer.Option(help="Filter by status: open, acknowledged, closed")] = None,
    since:     Annotated[Optional[str], typer.Option(help="Time window, e.g. 24h, 7d, 30m (default 24h when no endpoint given)")] = None,
    page:      Annotated[int, typer.Option(help="Page number")] = 1,
    page_size: Annotated[int, typer.Option(help="Results per page")] = 20,
    as_json:   Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
):
    """List security detection alerts, optionally filtered to a specific endpoint."""
    if endpoint_id is None and since is None:
        since = "24h"
    since_ts = _parse_since(since) if since else None
    title    = f"Alerts — {endpoint_id}" if endpoint_id else f"Alerts — all endpoints ({since or 'all time'})"
    cfg      = load_config()
    client   = _client()
    try:
        result = client.search_alerts(endpoint_id, page=page, page_size=page_size, status=status, since=since_ts)
        _print_alerts(result, title, as_json, base_url=cfg.url)
    except EdopsError as exc:
        _handle(exc)


# ── session-view ───────────────────────────────────────────────────────────────


def _session_term_size(proc_events: list[dict]) -> tuple[int, int]:
    """Extract original terminal dimensions from session process events."""
    for ev in proc_events:
        src = ev.get("_source", ev)
        c = _af(src, "process", "entry_leader", "tty", "columns")
        r = _af(src, "process", "entry_leader", "tty", "rows")
        if c and r:
            try:
                return int(c), int(r)
            except (ValueError, TypeError):
                pass
    return 0, 0


def _infer_term_size(io_events: list[dict]) -> tuple[int, int]:
    """Infer terminal dimensions from escape sequences in IO events.

    Looks for DECSTBM scroll region (ESC[1;Nr sets bottom margin = N rows)
    and the maximum column referenced in absolute cursor moves (ESC[row;colH).
    Falls back to (0, 0) if nothing useful is found."""
    _stbm = re.compile(r"\x1b\[1;(\d+)r")          # scroll region 1..N → rows=N
    _cup  = re.compile(r"\x1b\[(?:\d+);(\d+)[Hf]")  # CUP/HVP col position
    max_rows = 0
    max_cols = 0
    for ev in io_events:
        src  = ev.get("_source", ev)
        text = _af(src, "process", "io", "text") or ""
        if not text:
            continue
        for m in _stbm.finditer(text):
            max_rows = max(max_rows, int(m.group(1)))
        for m in _cup.finditer(text):
            max_cols = max(max_cols, int(m.group(1)))
    return max_cols, max_rows


def _write_asciicast(
    io_events: list[dict],
    path: str,
    title: str = "",
    alerted_entity_id: str = "",
    proc_events: Optional[list[dict]] = None,
    intro_info: Optional[dict] = None,
) -> int:
    """Write an asciicast v3 file from IO events for GIF/video rendering.

    No security sanitization is applied. We do remove terminal *response*
    sequences (CPR \x1b[row;colR, secondary DA, mode reports) that were
    captured by the PTY as if they were program output — replaying them as
    output corrupts the recording by repositioning the cursor."""
    import shutil

    cols, rows = _session_term_size(proc_events or [])
    if not cols or not rows:
        cols, rows = _infer_term_size(io_events)
    if not cols or not rows:
        cols, rows = shutil.get_terminal_size((80, 24))

    # Collect events and sort by timestamp, using event.sequence as tiebreaker
    evts: list[tuple[datetime, int, str, str]] = []
    for ev in io_events:
        src  = ev.get("_source", ev)
        eid  = _af(src, "process", "entity_id")
        ts_str = _af(src, "@timestamp") or ""
        text   = _af(src, "process", "io", "text") or ""
        seq    = src.get("event", {}).get("sequence", 0) or 0
        if not text:
            continue
        try:
            ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            continue
        evts.append((ts, seq, eid, text))

    if not evts:
        return 0

    evts.sort(key=lambda x: (x[0], x[1]))
    first_ts = evts[0][0]

    header = {
        "version": 3,
        "term": {"cols": cols, "rows": rows},
        "timestamp": int(first_ts.timestamp()),
        "title": title or "edops session-view",
    }

    seen_eids: set[str] = set()
    prev_ts = first_ts

    # For large events that look like terminal animations (alt screen + heavy cursor
    # movement), Elastic flushes the entire animation as a single buffer — all frames
    # with no internal timing. Split into ~200-byte chunks at escape boundaries so
    # the player shows motion instead of one instantaneous frame.
    _ALT_SCREEN_PAT = re.compile(r"\x1b\[\?1049h")
    ANIM_THRESHOLD   = 5000  # bytes — alt-screen animation splitting threshold
    ANIM_CHUNK       = 200   # bytes per synthetic frame
    ANIM_INTERVAL    = 0.05  # seconds between animation frames (50 ms ≈ 20 fps)
    SCROLL_THRESHOLD = 800   # bytes — plain-text events above this get line-split
    SCROLL_INTERVAL  = 0.015 # seconds between lines (15 ms)

    def _split_animation(text: str) -> list[str]:
        chunks: list[str] = []
        pos = 0
        while pos < len(text):
            end = min(pos + ANIM_CHUNK, len(text))
            # Don't cut inside an escape sequence: back up if the tail starts one
            if end < len(text):
                tail = text[max(pos, end - 8):end]
                m = re.search(r"\x1b(?:\[[\x30-\x3f]*[\x20-\x2f]*)?$", tail)
                if m and m.start() > 0:
                    end -= len(tail) - m.start()
            chunks.append(text[pos:end])
            pos = end
        return chunks

    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps(header) + "\n")
        if intro_info:
            _write_intro(f, cols, rows, intro_info)
        for ts, _seq, eid, text in evts:
            if eid not in seen_eids:
                seen_eids.add(eid)
                label = f"alerted: {eid}" if eid == alerted_entity_id else f"pid: {eid}"
                interval = round((ts - prev_ts).total_seconds(), 6)
                f.write(json.dumps([interval, "m", label]) + "\n")
                prev_ts = ts
            normalised = re.sub(r"(?<!\r)\n", "\r\n", text)
            if len(text) >= ANIM_THRESHOLD and _ALT_SCREEN_PAT.search(text):
                # Alt-screen animation (sl, vim, etc.): chunk at byte boundaries
                chunks = _split_animation(normalised)
                for i, chunk in enumerate(chunks):
                    interval = round((ts - prev_ts).total_seconds(), 6) if i == 0 else ANIM_INTERVAL
                    f.write(json.dumps([interval, "o", chunk]) + "\n")
                prev_ts = ts  # reset to real ts so next event timing is correct
            elif len(text) >= SCROLL_THRESHOLD and "\n" in text:
                # Large plain-text output: split at line boundaries to simulate scrolling
                lines = [p for p in re.split(r"(?<=\n)", normalised) if p]
                for i, line in enumerate(lines):
                    interval = round((ts - prev_ts).total_seconds(), 6) if i == 0 else SCROLL_INTERVAL
                    f.write(json.dumps([interval, "o", line]) + "\n")
                prev_ts = ts
            else:
                interval = round((ts - prev_ts).total_seconds(), 6)
                f.write(json.dumps([interval, "o", normalised]) + "\n")
                prev_ts = ts

    return len(evts)


def _cast_filename(alert_id: str, comment: Optional[str] = None) -> str:
    """tty[-COMMENT]-{alert_id[:16]}.cast — comment sanitised and included only if ≤30 chars."""
    if comment:
        safe = re.sub(r"[^\w-]", "-", comment.strip())
        safe = re.sub(r"-+", "-", safe).strip("-").lower()
        if safe and len(safe) <= 30:
            return f"tty_{safe}-{alert_id[:16]}.cast"
    return f"tty_{alert_id[:16]}.cast"


def _print_no_io(alert_id: str) -> None:
    err.print("[yellow]No terminal tty I/O captured for this session.[/yellow]\n")
    err.print("This usually means:")
    err.print("  • the process had no interactive TTY")
    err.print("  • eBPF I/O capture was not enabled")
    err.print("  • capture started after execution began\n")
    err.print("You can still inspect the session:")
    err.print(f"  [cyan]edops session-view {alert_id}[/cyan]")


def _print_alert_summary(alert_hit: dict, rule_name: str, alert_ts: str) -> None:
    src          = alert_hit.get("_source", {})
    host         = _af(src, "host", "name") or _af(src, "host", "hostname") or "-"
    user         = _af(src, "user", "name") or "-"
    proc_name    = _af(src, "process", "name") or "-"
    proc_pid     = _af(src, "process", "pid")
    proc_parent  = _af(src, "process", "parent", "name")
    try:
        ts = datetime.fromisoformat(alert_ts.replace("Z", "+00:00"))
        ts_fmt = ts.strftime("%Y-%m-%d %H:%M:%S UTC")
    except Exception:
        ts_fmt = alert_ts
    proc_str = proc_name
    if proc_pid:
        proc_str += f"  (pid {proc_pid})"
    if proc_parent:
        proc_str += f"  [dim]parent: {proc_parent}[/dim]"
    out.print(f"[bold]Alert  [/bold] {rule_name or '-'}")
    out.print(f"[bold]Host   [/bold] {host}")
    out.print(f"[bold]User   [/bold] {user}")
    out.print(f"[bold]Process[/bold] {proc_str}")
    out.print(f"[bold]Time   [/bold] {ts_fmt}")
    out.print("")


def _print_cast_saved(n: int, cast_path: str, gif: bool = False, mp4: bool = False) -> None:
    stem = cast_path[:-5] if cast_path.endswith(".cast") else cast_path
    if gif or mp4:
        out.print(f"[1/{'3' if mp4 else '2'}] Session I/O saved -> [bold]{cast_path}[/bold]  [dim](asciicast v3, {n} events)[/dim]")
        return
    out.print(f"\nSession I/O exported -> [bold]{cast_path}[/bold]  [dim](asciicast v3, {n} events)[/dim]")
    out.print("")
    out.print("[green]Recommended:[/green] convert to GIF for safe sharing and evidence storage")
    out.print(f"  [dim]agg {cast_path} {stem}.gif[/dim]")
    out.print("")
    out.print("[dim]To convert to MP4:[/dim]")
    out.print(f"  [dim]agg {cast_path} {stem}.gif && ffmpeg -i {stem}.gif {stem}.mp4[/dim]")
    out.print("")
    out.print("[dim]To play interactively (renders escape sequences in your terminal):[/dim]")
    out.print(f"  [dim]asciinema play {cast_path}[/dim]")
    out.print(f"  [dim]or: edops session-play {cast_path}  (includes safety prompt)[/dim]")


def _run_converter(cmd: list[str], tool: str, install_hint: str) -> bool:
    """Shell out to agg or ffmpeg. Returns True on success."""
    import shutil as _shutil
    import subprocess as _sp
    if not _shutil.which(cmd[0]):
        err.print(f"[red]{tool} not found on PATH.[/red] {install_hint}")
        return False
    try:
        _sp.run(cmd, check=True)
        return True
    except _sp.CalledProcessError as e:
        err.print(f"[red]{tool} exited with code {e.returncode}[/red]")
        return False


def _write_intro(f: Any, cols: int, rows: int, info: dict) -> None:
    """Write a 2-second animated intro (line-by-line box reveal) to an open cast file."""
    INTERVAL = 0.065  # seconds between revealed lines
    TOTAL    = 2.0    # total intro duration

    W     = min(64, max(32, cols - 4))
    inner = W - 2

    def _ctr(text: str) -> str:
        text = text[:inner]
        pad  = inner - len(text)
        return "║" + " " * (pad // 2) + text + " " * (pad - pad // 2) + "║"

    def _right(text: str) -> str:
        text = text[:inner]
        return "║" + " " * (inner - len(text)) + text + "║"

    LABEL_W = 9  # width of "Process: "
    rule  = (info.get("rule_name") or "")[:inner - LABEL_W]
    host  = (info.get("host")      or "")[:inner - LABEL_W]
    user  = (info.get("user")      or "")[:inner - LABEL_W]
    proc  = (info.get("proc")      or "")[:inner - LABEL_W]
    atime = (info.get("alert_time") or "")[:inner - LABEL_W]
    aid   = (info.get("alert_id")  or "")[:16]+".."
    note  = (info.get("comment")   or "")[:30]

    # Metadata rendered as a left-aligned block, centered as a unit in the box
    meta_pairs: list[tuple[str, str]] = [
        ("_id:     ", aid),
        ("Alert:   ", rule),
        ("Host:    ", host),
        ("User:    ", user),
        ("Process: ", proc),
        ("Time:    ", atime),
    ]
    if note:
        meta_pairs.append(("Note:    ", note))
    max_content = max(len(lbl + val) for lbl, val in meta_pairs)
    block_indent = (inner - max_content) // 2

    def _meta(label: str, value: str) -> str:
        content   = label + value
        right_pad = inner - block_indent - len(content)
        return "║" + " " * block_indent + content + " " * max(0, right_pad) + "║"

    lines: list[str] = [
        "╔" + "═" * inner + "╗",
        _ctr(""),
        _ctr("Elastic Defend Operations"),
        _ctr("Response Actions CLI"),
        _ctr("for Elastic Endpoint Security XDR"),
        _ctr(""),
        "╠" + "═" * inner + "╣",
        _ctr(""),
        _ctr("tty session i/o recording"),
        _ctr(""),
        "╠" + "═" * inner + "╣",
    ]
    for lbl, val in meta_pairs:
        lines.append(_meta(lbl, val))
    lines += [
        _ctr(""),
        "╠" + "═" * inner + "╣",
        _right(f"created with renini/edops ({_VERSION})"),
        "╚" + "═" * inner + "╝",
    ]

    n_lines   = len(lines)
    start_row = max(1, (rows - n_lines) // 2)
    col_off   = max(1, (cols - W) // 2 + 1)

    f.write(json.dumps([0.0, "o", "\x1b[2J\x1b[H"]) + "\n")
    for i, line in enumerate(lines):
        delta = 0.0 if i == 0 else INTERVAL
        f.write(json.dumps([delta, "o", f"\x1b[{start_row + i};{col_off}H{line}"]) + "\n")

    time_used = INTERVAL * (n_lines - 1)
    hold      = max(TOTAL - time_used, 0.15)
    f.write(json.dumps([hold, "o", "\x1b[2J\x1b[H"]) + "\n")


def _print_io_chunks(chunks: list[tuple[str, str]]) -> None:
    pending = ""  # incomplete escape sequence carried over from previous chunk
    for _, text in chunks:
        block = pending + text
        pending = ""
        m = _INCOMPLETE_ESC.search(block)
        if m:
            pending = block[m.start():]
            block   = block[:m.start()]
        out.file.write(_sanitize_io(block))
        out.file.flush()
    if pending:
        out.file.write(_sanitize_io(pending))
        out.file.flush()


def _print_session_view(
    proc_events: list[dict],
    io_events: list[dict],
    alerted_entity_id: str,
    alert_id: str,
    rule_name: str,
    alert_ts: str,
    alert_url: str = "",
    show_io: bool = False,
    all_io: bool = False,
    show_tree: bool = True,
) -> None:
    # Build node map: entity_id → node dict
    nodes: dict[str, dict] = {}
    order: list[str] = []  # insertion order for stable rendering

    for event in proc_events:
        src  = event.get("_source", event)
        proc = src.get("process", {})
        eid  = proc.get("entity_id", "")
        if not eid:
            continue
        action = src.get("event", {}).get("action", "")
        if eid not in nodes:
            nodes[eid] = {
                "entity_id": eid,
                "pid":        proc.get("pid", ""),
                "name":       proc.get("name", ""),
                "executable": proc.get("executable", ""),
                "args":       proc.get("args", []),
                "user":       proc.get("user", {}).get("name", ""),
                "parent_eid": proc.get("parent", {}).get("entity_id", ""),
                "children":   [],
                "io":         [],
            }
            order.append(eid)
        elif action == "exec":
            n = nodes[eid]
            n["executable"] = proc.get("executable", n["executable"])
            n["args"]       = proc.get("args",       n["args"])
            n["name"]       = proc.get("name",       n["name"])

    for eid in order:
        parent_eid = nodes[eid]["parent_eid"]
        if parent_eid and parent_eid in nodes and parent_eid != eid:
            nodes[parent_eid]["children"].append(eid)

    for event in io_events:
        src  = event.get("_source", event)
        eid  = src.get("process", {}).get("entity_id", "")
        text = _af(src, "process", "io", "text")
        ts   = _af(src, "@timestamp") or ""
        if text and eid in nodes:
            nodes[eid]["io"].append((ts, text))

    roots = [eid for eid in order
             if not nodes[eid]["parent_eid"] or nodes[eid]["parent_eid"] not in nodes]

    ts_display = alert_ts[:19].replace("T", " ") if alert_ts else ""
    out.print(f"\n[bold]Session View[/bold]  [dim]{alert_id[:22]}…[/dim]  {ts_display}")
    if rule_name:
        out.print(f"[dim]Rule: {rule_name}[/dim]")
    if alert_url:
        out.print(Text(f"Alert: {alert_url}", style=f"dim link {alert_url}"))
    out.print("")

    # ── process tree ───────────────────────────────────────────────────────────
    if show_tree:
        out.print("[bold cyan]Process Tree[/bold cyan]")

        def _node_label(eid: str) -> Text:
            n   = nodes[eid]
            exe = n["executable"] or n["name"] or eid
            cmd = " ".join(n["args"]) if n["args"] else exe
            lbl = Text()
            if n["user"]:
                lbl.append(f"{n['user']}  ", style="dim")
            is_alerted = eid == alerted_entity_id
            lbl.append(cmd, style="bold red" if is_alerted else "")
            if n["pid"]:
                lbl.append(f"  ({n['pid']})", style="dim")
            if is_alerted:
                lbl.append("  << alerted", style="red")
            if nodes[eid]["io"]:
                lbl.append("  [I/O]", style="dim cyan")
            return lbl

        def _build_tree(eid: str, rich_node: Tree) -> None:
            for child_eid in nodes[eid]["children"]:
                child_node = rich_node.add(_node_label(child_eid))
                _build_tree(child_eid, child_node)

        for root_eid in roots:
            root_tree = Tree(_node_label(root_eid))
            _build_tree(root_eid, root_tree)
            out.print(root_tree)

    # ── terminal I/O ───────────────────────────────────────────────────────────
    all_io_nodes = [eid for eid in order if nodes[eid]["io"]]
    if show_io or all_io:
        io_nodes = all_io_nodes if all_io else [eid for eid in all_io_nodes if eid == alerted_entity_id]
        if io_nodes:
            out.print("")
            out.print("[bold cyan]Terminal I/O[/bold cyan]")
            suppressed = len(all_io_nodes) - len(io_nodes)
            if suppressed:
                out.print(f"[dim]({suppressed} other process(es) with I/O not shown — use --all-io)[/dim]")
            for eid in io_nodes:
                n   = nodes[eid]
                exe = n["executable"] or n["name"] or eid
                is_alerted = eid == alerted_entity_id
                header = Text()
                header.append(exe, style="bold red" if is_alerted else "bold")
                header.append(f"  PID {n['pid']}", style="dim")
                if is_alerted:
                    header.append("  << alerted", style="red")
                out.print(Rule(title=header, style="red" if is_alerted else "dim", align="left"))
                _print_io_chunks(n["io"])
    elif all_io_nodes:
        out.print(f"\n[dim]{len(all_io_nodes)} process(es) have terminal I/O captured.[/dim]")
        out.print(f"[dim]  Export:  session-export {alert_id}[/dim]")
        out.print(f"[dim]  Replay:  session-play   {alert_id}[/dim]")


def _session_alert_context(alert_id: str, client: "KibanaClient") -> tuple:
    """Fetch and parse an alert into the fields needed by session commands.
    Returns (alert_hit, session_entity_id, alerted_entity_id, alert_ts,
             session_start_time, rule_name, alert_url).
    Raises EdopsError on failure or typer.Exit(1) if session data is missing."""
    try:
        with out.status("Fetching alert..."):
            alert_hit = client.get_alert_by_id(alert_id)
    except EdopsError as exc:
        _handle(exc)

    src               = alert_hit.get("_source", {})
    session_entity_id = _af(src, "process", "entry_leader", "entity_id")
    if not session_entity_id:
        has_process = bool(_af(src, "process", "pid") or _af(src, "process", "entity_id"))
        if has_process:
            err.print(
                "[red]Error:[/red] alert has process data but no session leader "
                "(process.entry_leader.entity_id is missing).\n"
                "Session View is an optional feature — the Elastic Agent on this host may have it "
                "disabled, or it was not enabled when this event was captured.\n"
                "The 'Open Session View' icon will also be absent in Kibana for this alert."
            )
        else:
            err.print("[red]Error:[/red] alert has no process data — Session View requires a process-type alert.")
        raise typer.Exit(1)

    alerted_entity_id  = _af(src, "process", "entity_id") or ""
    alert_ts           = _af(src, "@timestamp") or ""
    session_start_time = _af(src, "process", "entry_leader", "start") or alert_ts
    rule_name          = (
        _af(src, "kibana", "alert", "rule", "name")
        or _af(src, "signal", "rule", "name")
        or ""
    )
    base_url  = load_config().url.rstrip("/")
    alert_idx = alert_hit.get("_index", "")
    alert_url = (
        f"{base_url}/app/security/alerts/redirect/{alert_id}"
        f"?{urlencode({'index': alert_idx, 'timestamp': alert_ts})}"
        if base_url else ""
    )
    return alert_hit, session_entity_id, alerted_entity_id, alert_ts, session_start_time, rule_name, alert_url


@app.command()
def session_view(
    alert_id: Annotated[str, typer.Argument(help="Alert document ID (_id)")],
    index:    Annotated[str, typer.Option(help="Process events index")] = "logs-endpoint.events.process-*",
    as_json:  Annotated[bool, typer.Option("--json", help="Output raw JSON")] = False,
):
    """Show Session View for an alert: process tree with alerted process and I/O markers."""
    client = _client()
    _, session_entity_id, alerted_entity_id, alert_ts, session_start_time, rule_name, alert_url = \
        _session_alert_context(alert_id, client)

    try:
        with out.status("Fetching process events..."):
            proc_events = client.session_process_events(session_entity_id, session_start_time, index)
        with out.status("Fetching I/O events..."):
            io_events = client.session_io_events(session_entity_id, session_start_time, index)
    except EdopsError as exc:
        _handle(exc)

    if as_json:
        typer.echo(json.dumps({"process_events": proc_events, "io_events": io_events}, indent=2))
        return

    _print_session_view(proc_events, io_events, alerted_entity_id, alert_id, rule_name, alert_ts, alert_url)


@app.command()
def session_export(
    alert_id: Annotated[str, typer.Argument(help="Alert document ID (_id)")],
    index:    Annotated[str, typer.Option(help="Process events index")] = "logs-endpoint.events.process-*",
    output:   Annotated[Optional[str], typer.Option("--output", "-o", help="Output filename (default: tty_{alert_id[:16]}.cast)")] = None,
    comment:  Annotated[Optional[str], typer.Option("--comment", help="Incident/case label included in filename if ≤30 chars (e.g. INC-1231)")] = None,
    force:    Annotated[bool, typer.Option("--force", help="Overwrite if the output file already exists")] = False,
    gif:      Annotated[bool, typer.Option("--gif", help="Also produce a GIF via agg")] = False,
    mp4:      Annotated[bool, typer.Option("--mp4", help="Also produce an MP4 via agg + ffmpeg")] = False,
    no_intro: Annotated[bool, typer.Option("--no-intro", help="Skip the 2-second animated intro")] = False,
):
    """Export terminal I/O for an alert's session to an asciicast file."""
    import tempfile as _tempfile
    cast_path = output or _cast_filename(alert_id, comment)
    if Path(cast_path).exists() and not force:
        err.print(f"[red]File already exists:[/red] {cast_path}")
        err.print("Use [bold]--output PATH[/bold] to choose a different name, or [bold]--force[/bold] to overwrite.")
        raise typer.Exit(1)

    client = _client()
    alert_hit, session_entity_id, alerted_entity_id, alert_ts, session_start_time, rule_name, alert_url = \
        _session_alert_context(alert_id, client)

    _print_alert_summary(alert_hit, rule_name, alert_ts)

    try:
        with out.status("Fetching process events..."):
            proc_events = client.session_process_events(session_entity_id, session_start_time, index)
        with out.status("Fetching I/O events..."):
            io_events = client.session_io_events(session_entity_id, session_start_time, index)
    except EdopsError as exc:
        _handle(exc)

    title = f"edops [{comment}]: {rule_name or alert_id[:16]}" if comment else f"edops: {rule_name or alert_id[:16]}"

    src          = alert_hit.get("_source", {})
    intro_info: Optional[dict] = None
    if not no_intro:
        try:
            ts_fmt = datetime.fromisoformat(alert_ts.replace("Z", "+00:00")).strftime("%Y-%m-%d %H:%M UTC")
        except Exception:
            ts_fmt = alert_ts
        intro_info = {
            "rule_name":  rule_name or "",
            "host":       _af(src, "host", "name") or _af(src, "host", "hostname") or "",
            "user":       _af(src, "user", "name") or "",
            "proc":       _af(src, "process", "name") or "",
            "alert_time": ts_fmt,
            "alert_id":   alert_id,
            "comment":    comment or "",
        }

    n = _write_asciicast(io_events, cast_path, title=title, alerted_entity_id=alerted_entity_id, proc_events=proc_events, intro_info=intro_info)
    if not n:
        _print_no_io(alert_id)
        return

    _print_cast_saved(n, cast_path, gif=gif, mp4=mp4)
    stem = cast_path[:-5] if cast_path.endswith(".cast") else cast_path

    if gif:
        gif_path = f"{stem}.gif"
        out.print(f"[2/2] Converting ASCIICAST -> GIF via agg ...")
        if _run_converter(["agg", cast_path, gif_path], "agg", "Install: https://github.com/asciinema/agg"):
            out.print(f"\nGIF ready -> [bold]{gif_path}[/bold]  [dim](open in a browser or GIF viewer)[/dim]")
    if mp4:
        with _tempfile.NamedTemporaryFile(suffix=".gif", delete=False) as _tmp:
            _tmp_gif = _tmp.name
        try:
            mp4_path = f"{stem}.mp4"
            out.print(f"[2/3] Converting ASCIICAST -> GIF via agg (intermediate) ...")
            if _run_converter(["agg", cast_path, _tmp_gif], "agg", "Install: https://github.com/asciinema/agg"):
                out.print(f"[3/3] Converting GIF -> MP4 via ffmpeg ...")
                _ffmpeg_cmd = ["ffmpeg", "-hide_banner", "-loglevel", "quiet", "-stats"] + (["-y"] if force else []) + ["-i", _tmp_gif, mp4_path]
                if _run_converter(_ffmpeg_cmd, "ffmpeg", "Install: https://ffmpeg.org"):
                    out.print(f"\nMP4 ready -> [bold]{mp4_path}[/bold]")
        finally:
            Path(_tmp_gif).unlink(missing_ok=True)


@app.command()
def session_play(
    target: Annotated[str, typer.Argument(help="Alert document ID (_id) or path to a .cast file")],
    index:  Annotated[str, typer.Option(help="Process events index")] = "logs-endpoint.events.process-*",
    all_io: Annotated[bool, typer.Option("--all", help="Include I/O for all session processes, not just the alerted one")] = False,
    yes:    Annotated[bool, typer.Option("--yes", "-y", help="Skip the safety prompt")] = False,
):
    """Replay a session as live terminal output. Accepts an alert ID or a .cast file."""
    import shutil as _shutil
    import subprocess as _sp
    import tempfile as _tempfile

    target_path  = Path(target)
    is_cast_file = target_path.exists() or target.endswith(".cast")

    if not yes:
        err.print("[yellow]Warning: Rendering untrusted TTY output. Escape sequences may affect your terminal.[/yellow]")
        err.print("[dim]Exporting as GIF/MP4 is safer:  edops session-export --gif ALERT_ID[/dim]")
        if not typer.confirm("Continue?", default=False):
            raise typer.Exit(0)

    if is_cast_file:
        if not target_path.exists():
            err.print(f"[red]File not found:[/red] {target}")
            raise typer.Exit(1)
        cast_path = str(target_path)
        _temp_cast: Optional[str] = None
    else:
        alert_id = target
        client = _client()
        alert_hit, session_entity_id, alerted_entity_id, alert_ts, session_start_time, rule_name, alert_url = \
            _session_alert_context(alert_id, client)

        _print_alert_summary(alert_hit, rule_name, alert_ts)

        try:
            with out.status("Fetching process events..."):
                proc_events = client.session_process_events(session_entity_id, session_start_time, index)
            with out.status("Fetching I/O events..."):
                io_events = client.session_io_events(session_entity_id, session_start_time, index)
        except EdopsError as exc:
            _handle(exc)

        if not all_io:
            other_eids = {
                _af(ev.get("_source", ev), "process", "entity_id")
                for ev in io_events
                if _af(ev.get("_source", ev), "process", "entity_id") != alerted_entity_id
                and _af(ev.get("_source", ev), "process", "io", "text")
            }
            if other_eids:
                out.print(f"[dim]Note: {len(other_eids)} other process(es) in this session have I/O. Use --all to include them.[/dim]")
            io_events = [
                ev for ev in io_events
                if _af(ev.get("_source", ev), "process", "entity_id") == alerted_entity_id
            ]

        with _tempfile.NamedTemporaryFile(suffix=".cast", delete=False, mode="w", encoding="utf-8") as _tmp:
            _temp_cast = _tmp.name

        n = _write_asciicast(io_events, _temp_cast, alerted_entity_id=alerted_entity_id, proc_events=proc_events)
        if not n:
            Path(_temp_cast).unlink(missing_ok=True)
            _print_no_io(alert_id)
            return
        cast_path = _temp_cast

    if not _shutil.which("asciinema"):
        err.print("[red]asciinema not found on PATH.[/red] Install: https://github.com/asciinema/asciinema")
        if _temp_cast:
            Path(_temp_cast).unlink(missing_ok=True)
        raise typer.Exit(1)

    try:
        _sp.run(["asciinema", "play", cast_path])
    finally:
        if _temp_cast:
            Path(_temp_cast).unlink(missing_ok=True)

    err.print("\n[dim]If your terminal looks wrong, run: [bold]reset[/bold][/dim]")
    err.print("[dim]For safer viewing, export first: [cyan]edops session-export --gif ALERT_ID[/cyan][/dim]")


# ── config ─────────────────────────────────────────────────────────────────────

app.add_typer(config_app, name="config")


@config_app.command("set")
def config_set(
    url: Annotated[Optional[str], typer.Option(help="Kibana URL, e.g. https://kibana:5601")] = None,
    api_key: Annotated[Optional[str], typer.Option(help="API key (base64 id:key); use flag without value to be prompted", prompt="API key", hide_input=True, prompt_required=False)] = None,
    username: Annotated[Optional[str], typer.Option(help="Username for basic auth")] = None,
    password: Annotated[Optional[str], typer.Option(help="Password for basic auth; use flag without value to be prompted", prompt="Password", hide_input=True, prompt_required=False)] = None,
    space_id: Annotated[Optional[str], typer.Option(help="Kibana space ID")] = None,
    ca_cert: Annotated[Optional[str], typer.Option(help="Path to CA certificate bundle")] = None,
    no_verify_ssl: Annotated[bool, typer.Option("--no-verify-ssl", help="Disable TLS verification")] = False,
    require_comment: Annotated[Optional[bool], typer.Option("--require-comment/--no-require-comment", help="Require a comment/ticket reference on every action")] = None,
    persist_history: Annotated[Optional[bool], typer.Option("--persist-history/--no-persist-history", help="Save console/shell history to ~/.config/edops/ across sessions")] = None,
):
    """Set connection configuration (stored in ~/.config/edops/config.json)."""
    cfg = load_config()
    if url is not None:
        cfg.url = url
    if api_key is not None:
        cfg.api_key = api_key
    if username is not None:
        cfg.username = username
    if password is not None:
        cfg.password = password
    if space_id is not None:
        cfg.space_id = space_id
    if ca_cert is not None:
        cfg.ca_cert = ca_cert
    if no_verify_ssl:
        cfg.verify_ssl = False
    if require_comment is not None:
        cfg.require_comment = require_comment
    if persist_history is not None:
        cfg.persist_history = persist_history
    save_config(cfg)
    out.print("[green]Configuration saved.[/green]")


@config_app.command("show")
def config_show():
    """Show current configuration."""
    cfg = load_config()
    t = Table(show_header=False, box=None)
    t.add_column(Text("Key", justify="left"), style="cyan", min_width=12)
    t.add_column(Text("Value", justify="left"))

    t.add_row("url", cfg.url or "[dim]not set[/dim]")
    t.add_row("api_key", cfg.api_key or "[dim]not set[/dim]")
    t.add_row("username", cfg.username or "[dim]not set[/dim]")
    t.add_row("password", cfg.password or "[dim]not set[/dim]")
    t.add_row("space_id", cfg.space_id)
    t.add_row("verify_ssl", str(cfg.verify_ssl))
    t.add_row("ca_cert", cfg.ca_cert or "[dim]not set[/dim]")
    t.add_row("require_comment", "[green]yes[/green]" if cfg.require_comment else "[yellow]no[/yellow]")
    t.add_row("persist_history", "[green]yes[/green]" if cfg.persist_history else "[yellow]no[/yellow]")
    out.print(t)




if __name__ == "__main__":
    app()
