from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path


def _load_dotenv(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    try:
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            # strip optional leading "export "
            if line.startswith("export "):
                line = line[7:].lstrip()
            if "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = val.strip()
            if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
                val = val[1:-1]
            result[key] = val
    except Exception:
        pass
    return result

CONFIG_DIR = Path.home() / ".config" / "edops"
CONFIG_FILE = CONFIG_DIR / "config.json"

_FIELDS = {
    "url", "api_key", "username", "password",
    "verify_ssl", "ca_cert", "space_id", "require_comment", "persist_history",
}

CONSOLE_HISTORY_FILE = CONFIG_DIR / "console_history"
SHELL_HISTORY_FILE   = CONFIG_DIR / "shell_history"


@dataclass
class Config:
    url: str = ""
    api_key: str = ""
    username: str = ""
    password: str = ""
    verify_ssl: bool = True
    ca_cert: str = ""
    space_id: str = "default"
    require_comment: bool = True
    persist_history: bool = False


def load_config() -> Config:
    file_cfg = Config()
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text())
            file_cfg = Config(**{k: v for k, v in data.items() if k in _FIELDS})
        except Exception:
            pass

    dot = _load_dotenv(Path.cwd() / ".env")

    def _e(key: str) -> str:
        # shell env > .env file > empty string
        return os.environ.get(key) or dot.get(key, "")

    env_verify = _e("EDOPS_KIBANA_VERIFY_SSL")
    return Config(
        url=_e("EDOPS_KIBANA_URL") or file_cfg.url,
        api_key=_e("EDOPS_KIBANA_API_KEY") or file_cfg.api_key,
        username=_e("EDOPS_KIBANA_USERNAME") or file_cfg.username,
        password=_e("EDOPS_KIBANA_PASSWORD") or file_cfg.password,
        verify_ssl=(
            env_verify.lower() not in ("false", "0", "no")
            if env_verify
            else file_cfg.verify_ssl
        ),
        ca_cert=_e("EDOPS_KIBANA_CA_CERT") or file_cfg.ca_cert,
        space_id=_e("EDOPS_KIBANA_SPACE_ID") or file_cfg.space_id,
        require_comment=file_cfg.require_comment,
        persist_history=file_cfg.persist_history,
    )


def save_config(cfg: Config) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(asdict(cfg), indent=2))
    try:
        CONFIG_FILE.chmod(0o600)
    except Exception:
        pass
