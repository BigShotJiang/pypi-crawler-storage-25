# Elastic Security API Reference

This document describes every Kibana/Fleet API endpoint used by elastic-edr, including the exact
response shapes returned by a live **Elastic Stack 9.3.3** cluster. Shapes were captured from a
real cluster, sanitised, and stored as test fixtures in `tests/fixtures/`. Use this document to
judge whether the code still works after an Elastic version upgrade.

---

## Authentication & base URL

All requests target the Kibana HTTP API.  The base URL is configurable (`edr config set --url`).

| Auth method | Header / mechanism |
|---|---|
| API key | `Authorization: ApiKey <base64-encoded id:key>` |
| Username/password | HTTP Basic auth |

All mutating requests also require `kbn-xsrf: true`.

### Space routing

Non-default Kibana spaces prepend `/s/<space_id>` to every path:

```
default space:  GET /api/endpoint/metadata
ops space:      GET /s/ops/api/endpoint/metadata
```

---

## Endpoints

### `GET /api/status`

Kibana health check.  Used by `edr status`.

**Response shape** (`tests/fixtures/kibana_status.json`):

```json
{
  "name": "kibana-node-1",
  "uuid": "…",
  "version": {
    "number": "9.3.3",
    "build_hash": "…",
    "build_number": 96197,
    "build_snapshot": false,
    "build_flavor": "traditional",
    "build_date": "…"
  },
  "status": {
    "overall": {
      "level": "available",
      "summary": "All services and plugins are available"
    }
  }
}
```

**Key fields used by the CLI:**

| Field | Description |
|---|---|
| `version.number` | Stack version string |
| `status.overall.level` | `"available"` when healthy |

---

### `GET /api/endpoint/metadata`

List enrolled Elastic Defend endpoints.

**Query params:**

| Param | Default | Notes |
|---|---|---|
| `page` | `1` | 1-indexed |
| `pageSize` | `50` | |
| `kuery` | — | KQL filter, e.g. `host.hostname : "web*"` |

**Response shape** (`tests/fixtures/list_endpoints.json`):

```json
{
  "data": [ /* array of endpoint objects — see below */ ],
  "total": 1,
  "page": 1,
  "pageSize": 3,
  "sortField": "enrolled_at",
  "sortDirection": "desc"
}
```

> **Quirk (9.x):** With certain `pageSize` values the API returns `data: []` while `total` is
> non-zero.  This appears to be a server-side pagination bug — retry with `pageSize=1` or iterate
> through pages to retrieve all records.  The fixture preserves this observed behaviour.

Each element in `data` has the same shape as the `GET /api/endpoint/metadata/{id}` response (see
below), minus `policy_info` and `last_checkin`.

---

### `GET /api/endpoint/metadata/{endpoint_id}`

Full metadata for a single endpoint.

**Response shape** (`tests/fixtures/endpoint_metadata.json`):

```json
{
  "metadata": {
    "@timestamp": "…",
    "Endpoint": {
      "capabilities": ["kill_process", "suspend_process", "running_processes",
                       "get_file", "upload_file", "execute", "scan",
                       "isolation", "session_data"],
      "configuration": { "isolation": false },
      "state": {
        "orphaned": false,
        "isolation": false,
        "tamper_protection": false
      },
      "policy": {
        "applied": {
          "name": "defend",
          "id": "…",
          "endpoint_policy_version": "5",
          "version": "23",
          "status": "success"
        }
      },
      "status": "enrolled"
    },
    "agent": { "id": "…", "type": "endpoint", "version": "9.3.3+build…" },
    "elastic": { "agent": { "id": "…" } },
    "host": {
      "hostname": "workstation-lin-01",
      "name": "workstation-lin-01",
      "id": "…",
      "architecture": "x86_64",
      "ip": ["127.0.0.1", "::1", "10.0.1.11", "fe80::…"],
      "mac": ["00-50-56-aa-bb-01"],
      "os": {
        "Ext": { "variant": "Debian" },
        "kernel": "6.12.74+deb13+1-amd64 …",
        "name": "Linux",
        "family": "debian",
        "type": "linux",
        "version": "13.4",
        "platform": "debian",
        "full": "Debian 13.4"
      }
    }
  },
  "host_status": "healthy",
  "policy_info": {
    "agent": {
      "applied":    { "revision": 23, "id": "…" },
      "configured": { "revision": 23, "id": "…" }
    },
    "endpoint": { "revision": 5, "id": "…" }
  },
  "last_checkin": "2026-04-28T13:07:14Z"
}
```

**Key fields:**

| Field | Description |
|---|---|
| `metadata.Endpoint.capabilities` | Actions this agent supports |
| `metadata.Endpoint.state.isolation` | `true` when network-isolated |
| `metadata.host.os.full` | Human-readable OS string |
| `host_status` | `"healthy"` / `"unhealthy"` / `"unenrolled"` |
| `last_checkin` | ISO-8601 timestamp of last agent check-in |

> **Note:** MAC addresses in this endpoint use **dash** notation (`00-50-56-aa-bb-01`).
> Fleet agents (see below) use **colon** notation.  The CLI normalises both forms.

---

### `GET /api/fleet/agents`

Fleet view of enrolled agents.  Used by `edr agents` to look up agents by hostname.

**Query params:**

| Param | Default | Notes |
|---|---|---|
| `page` | `1` | 1-indexed |
| `perPage` | `50` | Note: `perPage`, not `pageSize` |
| `showInactive` | `"true"` | Include offline/inactive agents; set to `"false"` when `--online` is used |
| `kuery` | — | KQL filter |

**Response shape** (`tests/fixtures/fleet_agents.json`):

```json
{
  "items": [ /* array of agent objects */ ],
  "total": 2,
  "page": 1,
  "perPage": 50
}
```

> **Key difference from other endpoints:** results are in `items`, not `data`.

Each agent object:

```json
{
  "id": "…",
  "type": "PERMANENT",
  "active": true,
  "enrolled_at": "…",
  "last_checkin": "…",
  "last_checkin_status": "online",
  "policy_id": "…",
  "policy_revision": 23,
  "status": "online",
  "agent": { "id": "…", "version": "9.3.3+build…" },
  "local_metadata": {
    "elastic": { "agent": { "id": "…", "version": "…", "upgradeable": false } },
    "host": {
      "architecture": "x86_64",
      "hostname": "workstation-lin-01",
      "id": "…",
      "ip": ["127.0.0.1/8", "10.0.1.11/24", "::1/128", "fe80::…/64"],
      "mac": ["00:50:56:aa:bb:01"],
      "name": "workstation-lin-01"
    },
    "os": {
      "family": "debian",
      "full": "Debian GNU/Linux trixie(13 (trixie))",
      "kernel": "…",
      "name": "Debian GNU/Linux",
      "platform": "debian",
      "version": "13 (trixie)"
    }
  }
}
```

> **Note:** `local_metadata.host.ip` entries include CIDR prefix length
> (`"10.0.1.11/24"`), unlike the Endpoint metadata endpoint which omits it.
> MAC addresses use colon notation here, dash notation in `/api/endpoint/metadata`.

---

### `POST /api/endpoint/action/{action}`

Submit a response action to one or more endpoints.  The `{action}` token is one of:
`isolate`, `unisolate`, `execute`, `kill_process`, `suspend_process`, `running_procs`,
`get_file`, `scan`, `upload`.

**Request body:**

```json
{
  "agent_type": "endpoint",
  "endpoint_ids": ["<agent-id>", …],
  "parameters": { /* action-specific — see table below */ },
  "comment": "INC-1234"
}
```

**`parameters` by action:**

| Action | Parameters |
|---|---|
| `execute` | `{"command": "whoami", "timeout": 60}` |
| `kill_process` | `{"pid": 1234}` or `{"entity_id": "…"}` |
| `suspend_process` | `{"pid": 1234}` or `{"entity_id": "…"}` |
| `get_file` | `{"path": "/etc/passwd"}` |
| `scan` | `{"path": "/tmp"}` |
| `upload` | (multipart form — see `upload_file()` below) |
| `isolate` / `unisolate` / `running_procs` | no parameters |

**Response** — same shape as `GET /api/endpoint/action/{id}` (see below), returned
immediately with `status: "pending"`.

---

### `GET /api/endpoint/action/{action_id}`

Fetch the current status and output of an action.

**Response shape — `execute` with inline output** (`tests/fixtures/action_detail_execute.json`):

```json
{
  "data": {
    "id": "…",
    "action": "…",
    "agentType": "endpoint",
    "agents": ["<agent-id>"],
    "hosts": { "<agent-id>": { "name": "workstation-lin-01" } },
    "command": "execute",
    "startedAt": "…",
    "isCompleted": true,
    "completedAt": "…",
    "wasSuccessful": true,
    "isExpired": false,
    "status": "successful",
    "createdBy": "elastic",
    "comment": "INC-1234",
    "parameters": { "command": "hostname", "timeout": 60 },
    "outputs": {
      "<agent-id>": {
        "type": "json",
        "content": {
          "stdout": "workstation-lin-01\n",
          "stderr": "",
          "return_code": 0,
          "shell": "bash",
          "cwd": "/opt/Elastic/Endpoint/state/response_actions",
          "stdout_truncated": false,
          "stderr_truncated": false,
          "code": "ra_execute_success_done",
          "output_file_id": "…",
          "downloadUri": "/api/endpoint/action/…/file/…/download"
        }
      }
    },
    "agentState": {
      "<agent-id>": {
        "isCompleted": true,
        "wasSuccessful": true,
        "completedAt": "…"
      }
    }
  }
}
```

**Output types:**

| `outputs[id].type` | Meaning | How to get output |
|---|---|---|
| `"json"` | Small output embedded inline | Read `content.stdout` / `content.stderr` / `content.return_code` |
| `"file"` | Large output stored as a zip | Call `download_file(action_id, file_id)` |

> **Alias:** `content.exit_code` is sometimes used instead of `content.return_code` in older
> agent versions.  The CLI checks both.

**`running_procs` output** (`tests/fixtures/running_procs_action.json`) — `type: "json"`,
`content.entries` is an array:

```json
{
  "entries": [
    { "pid": 1,    "user": "root",    "entity_id": "…", "command": "/sbin/init" },
    { "pid": 1024, "user": "elastic", "entity_id": "…", "command": "elastic-endpoint" }
  ]
}
```

**`status` values:** `"pending"` → `"successful"` / `"failed"` / `"expired"`

---

### `GET /api/endpoint/action`

List recent actions across endpoints.

**Query params:**

| Param | Default | Notes |
|---|---|---|
| `page` | `1` | 1-indexed |
| `pageSize` | `20` | |
| `agentIds` | — | Array — repeat param or pass comma-separated |
| `commands` | — | Filter by action type |

**Response shape** (`tests/fixtures/list_actions.json`):

```json
{
  "page": 1,
  "pageSize": 3,
  "data": [
    {
      "id": "…",
      "action": "…",
      "agentType": "endpoint",
      "agents": ["<agent-id>"],
      "hosts": { "<agent-id>": { "name": "workstation-lin-01" } },
      "command": "execute",
      "startedAt": "…",
      "isCompleted": true,
      "completedAt": "…",
      "wasSuccessful": true,
      "isExpired": false,
      "status": "successful",
      "createdBy": "elastic",
      "comment": "INC-1234",
      "parameters": { "command": "hostname", "timeout": 60 }
    }
  ]
}
```

> **Note:** `data` items here are summaries — no `outputs` or `agentState`.
> Use `GET /api/endpoint/action/{id}` for full detail.

---

### `GET /api/endpoint/action/{action_id}/file/{file_id}/download`

Download a file action result (zip archive, password: `elastic`).

- Returns raw bytes (`Content-Type: application/zip`).
- `file_id` is typically `<action_id>.<agent_id>` but is also surfaced as
  `outputs[agent_id].content.output_file_id` and `downloadUri` in the action detail response.
- The zip contains `stdout.txt`, `stderr.txt`, and `exit_code.txt`.

---

### `POST /api/endpoint/action/upload`

Upload a file to one or more endpoints.  Uses `multipart/form-data`.

**Form fields:**

| Field | Type | Notes |
|---|---|---|
| `endpoint_ids` | JSON string | `'["<agent-id>"]'` |
| `parameters` | JSON string | `'{"overwrite": false}'` |
| `comment` | string | Optional |
| `file` | binary | File content |

> The `endpoint_ids` and `parameters` fields must be JSON-encoded strings inside the
> multipart body — not raw JSON.  This is an Elastic API quirk.

---

### `POST /api/detection_engine/signals/search`

Elasticsearch-style search over security alerts.  Used by `edr alerts`.

**Request body:**

```json
{
  "query": {
    "bool": {
      "filter": [
        { "term": { "agent.id": "<agent-id>" } },
        { "term": { "kibana.alert.workflow_status": "open" } }
      ]
    }
  },
  "from": 0,
  "size": 20,
  "sort": [{ "@timestamp": { "order": "desc" } }]
}
```

**Response shape** (`tests/fixtures/alerts_with_hits.json`):

```json
{
  "took": 4,
  "timed_out": false,
  "_shards": { "total": 1, "successful": 1, "skipped": 0, "failed": 0 },
  "hits": {
    "total": { "value": 2, "relation": "eq" },
    "max_score": null,
    "hits": [
      {
        "_id": "…",
        "_index": ".internal.alerts-security.alerts-default-000001",
        "_source": {
          "@timestamp": "…",
          "agent": { "id": "…" },
          "kibana": {
            "alert": {
              "severity": "high",
              "rule": { "name": "Suspicious Process Execution via WMI" },
              "workflow_status": "open"
            }
          },
          "process": { "name": "cmd.exe", "pid": 4488, "command_line": "cmd.exe /c whoami" },
          "host": { "name": "…", "id": "…" }
        }
      }
    ]
  }
}
```

**Alert fields accessed by the CLI** (all via `_af()` helper with flat-key fallback):

| Field path | Description |
|---|---|
| `kibana.alert.severity` | `"critical"` / `"high"` / `"medium"` / `"low"` |
| `kibana.alert.rule.name` | Detection rule name |
| `kibana.alert.workflow_status` | `"open"` / `"acknowledged"` / `"closed"` |
| `signal.rule.severity` | Legacy field (pre-8.x) — same meaning |
| `process.name` | Process involved in the alert |
| `file.name` | File involved |
| `source.ip` / `destination.ip` | Network context |

---

### `POST /api/osquery/live_queries`

Run an ad-hoc or saved osquery against one or more agents.

**Request body:**

```json
{
  "agent_ids": ["<agent-id>"],
  "query": "SELECT * FROM users;",
  "saved_query_id": "…",
  "pack_id": "…"
}
```

Exactly one of `query`, `saved_query_id`, or `pack_id` should be provided.

**Response:** action object with `data.action_id`, `data.queries[]`.

---

### `GET /api/osquery/live_queries/{action_id}`

Poll an osquery action status.

**Completion signal (9.x):** all entries in `data.queries[]` have `pending == 0`.

**Legacy fallback fields** (pre-9.x): `data.status` is `"completed"` / `"done"` / `"finished"`,
or `len(data.responses) >= data.agents_count`.

---

### `GET /api/osquery/live_queries/{action_id}/results[/{query_action_id}]`

Fetch results for a completed osquery.

**Query params:**

| Param | Default | Notes |
|---|---|---|
| `activePage` | `0` | **0-indexed** (differs from other endpoints) |
| `pageSize` | `100` | |

**Response:** `data.rawResponse.hits` contains standard Elasticsearch hits with osquery row data.

---

### `GET /internal/session_view/process_events`

Fetch process events for a session, used by `edops session-view`.  This is a Kibana internal API — subject to change between major versions.

**Query params:**

| Param | Notes |
|---|---|
| `index` | Process events index, default `logs-endpoint.events.process-*` |
| `sessionEntityId` | `process.entry_leader.entity_id` from the alert |
| `sessionStartTime` | `process.entry_leader.start` from the alert (ISO-8601) |
| `forward` | `"true"` to walk events forward in time |
| `cursor` | Pagination cursor from previous response; omit on first request |

**Response shape** (`tests/fixtures/session_process_events.json`):

```json
{
  "events": [
    {
      "_source": {
        "@timestamp": "…",
        "event": { "action": ["exec"] },
        "process": {
          "entity_id": "…",
          "name": "sshd-session",
          "executable": "/usr/lib/openssh/sshd-session",
          "args": ["…"],
          "pid": 11793,
          "user": { "name": "root" },
          "parent": { "entity_id": "…" }
        }
      }
    }
  ],
  "cursor": "…"
}
```

The client loops fetching pages until `cursor` is absent or `events` is empty, then returns the full flat list.

---

### `GET /internal/session_view/io_events`

Fetch captured terminal I/O for a session.  Same internal API tier as `process_events`.

**Query params:** same as `process_events` except `forward` is omitted.

**Response shape** (`tests/fixtures/session_io_events.json`):

```json
{
  "events": [
    {
      "_source": {
        "@timestamp": "…",
        "process": {
          "entity_id": "…",
          "io": { "text": "analyst@workstation-lin-01:~$ " }
        }
      }
    }
  ],
  "cursor": "…"
}
```

> **Note:** `get_alert_by_id()` reuses `POST /api/detection_engine/signals/search` (documented
> above under alerts) but passes `{"query": {"ids": {"values": ["<alert-id>"]}}, "size": 1}`
> instead of the agent filter, and returns the single hit directly.

---

### `GET /api/osquery/saved_queries`

List saved osquery queries (Elastic prebuilt + user-created).

**Query params:**

| Param | Default | Notes |
|---|---|---|
| `page` | `1` | 1-indexed |
| `pageSize` | `20` | |

**Response shape** (`tests/fixtures/osquery_saved.json`):

```json
{
  "page": 1,
  "per_page": 3,
  "total": 72,
  "data": [
    {
      "id": "wdigest_uselogoncredential_windows_elastic",
      "created_at": "…",
      "created_by": "elastic",
      "updated_at": "…",
      "updated_by": "elastic",
      "description": "…",
      "interval": "3600",
      "platform": "windows",
      "prebuilt": true,
      "query": "SELECT …",
      "saved_object_id": "osquery_manager-…"
    }
  ]
}
```

> **Note:** Results are in a top-level `data` array — not `data.items` or `items`.
> The pagination key is `per_page` (with underscore), not `pageSize`.

---

## Common quirks & version notes

All observations are from **Elastic Stack 9.3.3**.

| Behaviour | Details |
|---|---|
| `list_endpoints` may return empty `data` | `/api/endpoint/metadata` can return `data: []` with `total > 0` depending on `pageSize`. Iterate pages or use smaller page sizes. |
| Fleet vs Endpoint MAC format | `/api/fleet/agents` → colon notation (`00:50:56:…`). `/api/endpoint/metadata` → dash notation (`00-50-56-…`). |
| Fleet vs Endpoint IP format | Fleet includes CIDR prefix (`10.0.1.11/24`); Endpoint metadata omits it (`10.0.1.11`). |
| Fleet uses `items`, not `data` | `/api/fleet/agents` response root key is `items`; most other paginated endpoints use `data`. |
| Osquery pagination is 0-indexed | `activePage=0` is the first page; all other endpoints use `page=1`. |
| `execute` output type | Small results are `type: "json"` (inline); large results are `type: "file"` (requires download). Both appear in the same `outputs[agent_id]` structure. |
| `return_code` vs `exit_code` | Seen in the wild: some agent versions emit `exit_code` instead of `return_code` in `execute` output content. |
| Osquery `per_page` key | Saved-queries pagination response uses `per_page` (underscore); action endpoints use `pageSize` (camelCase). |
