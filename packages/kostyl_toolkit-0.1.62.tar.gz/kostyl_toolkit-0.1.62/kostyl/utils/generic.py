from pathlib import Path
from typing import Any

import yaml


def convert_to_flat_dict(
    nested_dict: dict[str, Any], parent_key: str = "", sep: str = "."
) -> dict[str, Any]:
    """
    Converts a nested dictionary to a flat one.

    Example: {'a': 1, 'b': {'c': 2}} -> {'a': 1, 'b.c': 2}
    """
    items = []
    for k, v in nested_dict.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(convert_to_flat_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def flattened_dict_to_nested(
    flattened_dict: dict[str, Any], sep: str = "."
) -> dict[str, Any]:
    """
    Converts a flat dictionary back to a nested one.

    Example: {'a': 1, 'b.c': 2} -> {'a': 1, 'b': {'c': 2}}
    """
    result = {}
    for key, value in flattened_dict.items():
        parts = key.split(sep)
        d = result
        for part in parts[:-1]:
            if part not in d:
                d[part] = {}
            d = d[part]

        d[parts[-1]] = value
    return result


def load_config(path: Path | str) -> dict:
    """Load a configuration from file."""
    if isinstance(path, str):
        path = Path(path)

    if not path.is_file():
        raise ValueError(f"Config file {path} does not exist or is not a file.")

    match path.suffix:
        case ".yaml" | ".yml":
            config = yaml.safe_load(path.open("r"))
        case _:
            raise ValueError(f"Unsupported config file format: {path.suffix}")
    return config


def is_overridden(cls: type, method_name: str) -> bool:
    """Check if a method is overridden in a subclass."""
    return method_name in cls.__dict__
