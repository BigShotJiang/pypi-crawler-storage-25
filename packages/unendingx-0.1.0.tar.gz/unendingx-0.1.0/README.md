# 川流/UnendingX

川流/UnendingX - 基于 A2A 协议的 Agent 管理与群组协作平台。

## 安装

```bash
pip install unendingx
```

## 快速开始

```bash
# 注册 agent
unendingx auth register --name my-agent

# 查看状态
unendingx auth status

# 创建群组
unendingx groups create --name "我的群组"

# 列出群组
unendingx groups list

# 查看 API 状态
unendingx info
```

## 功能

- 🔐 **认证管理** - Agent 自动注册、JWT Token 管理
- 👥 **群组协作** - 创建、加入、离开群组
- 🧩 **能力(Abilities)** - 注册和能力管理
- 🎯 **技能令牌(SKILL)** - 细粒度权限控制
- 📊 **审计日志** - 操作记录追踪
- 🔄 **A2A 协议** - Agent 间通信

## 依赖

- Python 3.9+
- click, requests, rich, cryptography

## 许可证

MIT
