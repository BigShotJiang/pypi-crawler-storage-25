from __future__ import annotations

import logging
import uuid

from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import transaction
from django.http import FileResponse
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from djmoney.money import Money
from drf_spectacular.utils import (
    OpenApiParameter,
    extend_schema,
    extend_schema_view,
)
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.exceptions import (
    NotAuthenticated,
    NotFound,
    PermissionDenied,
    ValidationError,
)
from rest_framework.permissions import AllowAny, IsAdminUser
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle, UserRateThrottle

from core.api.permissions import IsOwnerOrAdmin, IsOwnerOrAdminOrGuest
from core.api.serializers import ErrorResponseSerializer
from core.api.throttling import (
    PaymentAttemptAnonThrottle,
    PaymentAttemptThrottle,
)
from core.api.views import BaseModelViewSet
from core.utils.serializers import (
    ActionConfig,
    SerializersConfig,
    create_schema_view_config,
)
from order.exceptions import (
    InsufficientStockError,
    InvalidOrderDataError,
    InvalidStatusTransitionError,
    OrderCancellationError,
    PaymentAmountMismatchError,
    PaymentCurrencyMismatchError,
    PaymentNotFoundError,
)
from order.filters import OrderFilter
from order.models.history import OrderHistory
from order.models.order import Order
from order.payment import get_payment_provider
from order.serializers.invoice import InvoiceDownloadResponseSerializer
from order.serializers.order import (
    AddTrackingSerializer,
    CancelOrderRequestSerializer,
    CreateCheckoutSessionRequestSerializer,
    CreateCheckoutSessionResponseSerializer,
    CreatePaymentIntentRequestSerializer,
    CreatePaymentIntentResponseSerializer,
    OrderCreateFromCartSerializer,
    OrderDetailSerializer,
    OrderSerializer,
    OrderWriteSerializer,
    PaymentStatusResponseSerializer,
    RefundOrderRequestSerializer,
    RefundOrderResponseSerializer,
    ReorderResponseSerializer,
    UpdateStatusSerializer,
)
from order.services import OrderService
from pay_way.models import PayWay
from pay_way.services import PayWayService

logger = logging.getLogger(__name__)

serializers_config: SerializersConfig = {
    "list": ActionConfig(response=OrderSerializer),
    "retrieve": ActionConfig(response=OrderDetailSerializer),
    "create": ActionConfig(
        request=OrderCreateFromCartSerializer, response=OrderDetailSerializer
    ),
    "update": ActionConfig(
        request=OrderWriteSerializer, response=OrderDetailSerializer
    ),
    "partial_update": ActionConfig(
        request=OrderWriteSerializer, response=OrderDetailSerializer
    ),
    "retrieve_by_uuid": ActionConfig(
        response=OrderDetailSerializer,
        operation_id="retrieveOrderByUuid",
        summary=_("Retrieve an order by UUID"),
        description=_(
            "Get detailed information about a specific order using its UUID"
        ),
        tags=["Orders"],
    ),
    "cancel": ActionConfig(
        request=CancelOrderRequestSerializer,
        response=OrderDetailSerializer,
        operation_id="cancelOrder",
        summary=_("Cancel an order"),
        description=_("Cancel an existing order and restore product stock"),
        tags=["Orders"],
    ),
    "my_orders": ActionConfig(
        response=OrderSerializer,
        many=True,
        operation_id="listMyOrders",
        summary=_("List current user's orders"),
        description=_("Returns a list of the authenticated user's orders"),
        tags=["Orders"],
    ),
    "add_tracking": ActionConfig(
        request=AddTrackingSerializer,
        response=OrderDetailSerializer,
        operation_id="addOrderTracking",
        summary=_("Add tracking information to an order"),
        description=_("Add tracking information to an existing order"),
        tags=["Orders"],
    ),
    "update_status": ActionConfig(
        request=UpdateStatusSerializer,
        response=OrderDetailSerializer,
        operation_id="updateOrderStatus",
        summary=_("Update the status of an order"),
        description=_("Update the status of an existing order"),
        tags=["Orders"],
    ),
    "create_payment_intent": ActionConfig(
        request=CreatePaymentIntentRequestSerializer,
        response=CreatePaymentIntentResponseSerializer,
        operation_id="createOrderPaymentIntent",
        summary=_("Create a payment intent for an order"),
        description=_(
            "Create a payment intent for Stripe payments on an existing order"
        ),
        tags=["Orders"],
    ),
    "create_checkout_session": ActionConfig(
        request=CreateCheckoutSessionRequestSerializer,
        response=CreateCheckoutSessionResponseSerializer,
        operation_id="createOrderCheckoutSession",
        summary=_("Create a hosted checkout session for an order"),
        description=_(
            "Create a hosted checkout session (Stripe or Viva Wallet). "
            "The customer will be redirected to the provider's checkout page to complete payment."
        ),
        tags=["Orders"],
    ),
    "refund_order": ActionConfig(
        request=RefundOrderRequestSerializer,
        response=RefundOrderResponseSerializer,
        operation_id="refundOrder",
        summary=_("Refund an order payment"),
        description=_(
            "Process a full or partial refund for an order's payment. "
            "Only available for paid orders with valid payment providers."
        ),
        tags=["Orders"],
    ),
    "payment_status": ActionConfig(
        response=PaymentStatusResponseSerializer,
        operation_id="getOrderPaymentStatus",
        summary=_("Get payment status for an order"),
        description=_(
            "Retrieve the current payment status from the payment provider. "
            "This fetches the latest status directly from Stripe/PayPal."
        ),
        tags=["Orders"],
    ),
    "retry_payment": ActionConfig(
        request=CreatePaymentIntentRequestSerializer,
        response=CreatePaymentIntentResponseSerializer,
        operation_id="retryOrderPayment",
        summary=_("Retry payment for a failed or pending order"),
        description=_(
            "Create a fresh Stripe PaymentIntent for an order whose previous "
            "payment failed or was never completed, so the customer can try again "
            "without starting a new order."
        ),
        tags=["Orders"],
    ),
    "reorder": ActionConfig(
        response=ReorderResponseSerializer,
        operation_id="reorderOrder",
        summary=_("Reorder the items from a past order"),
        description=_(
            "Copy each item from a past order back into the authenticated "
            "user's active cart. Items whose products are inactive or out "
            "of stock are returned in skipped_items; quantities are capped "
            "at current stock."
        ),
        tags=["Orders"],
    ),
    "invoice": ActionConfig(
        response=InvoiceDownloadResponseSerializer,
        operation_id="retrieveOrderInvoice",
        summary=_("Get invoice download metadata for an order"),
        description=_(
            "Return the order's invoice metadata and an absolute URL to "
            "the streaming download endpoint (``/order/{id}/invoice/"
            "download``). The URL is gated by the same owner/admin "
            "permission check as this metadata endpoint — no raw "
            "storage URLs are exposed to the client. 404 if the invoice "
            "has not been generated yet (e.g. order not completed)."
        ),
        tags=["Orders"],
    ),
    "boxnow_cancel": ActionConfig(
        operation_id="cancelBoxNowShipmentForOrder",
        summary=_("Cancel the BoxNow shipment for an order"),
        description=_(
            "Admin-only. Requests parcel cancellation via the BoxNow API. "
            "Only valid when the parcel state is NEW (BoxNow error P420 "
            "otherwise). Accepts an optional ``reason`` field in the "
            "request body."
        ),
        tags=["Orders"],
    ),
    "boxnow_label": ActionConfig(
        operation_id="getBoxNowLabelForOrder",
        summary=_("Download the BoxNow parcel label PDF for an order"),
        description=_(
            "Streams the BoxNow label PDF through Django auth. "
            "Accessible by the order owner, staff, or a guest with the "
            "order UUID. Returns 404 when no BoxNow shipment exists for "
            "the order or the parcel ID has not yet been assigned."
        ),
        tags=["Orders"],
    ),
    "acs_cancel": ActionConfig(
        operation_id="cancelAcsShipmentForOrder",
        summary=_("Cancel the ACS shipment for an order"),
        description=_(
            "Admin-only. Calls ACS_Delete_Voucher. Only valid before "
            "the voucher is finalised in a pickup list."
        ),
        tags=["Orders"],
    ),
    "acs_label": ActionConfig(
        operation_id="getAcsLabelForOrder",
        summary=_("Download the ACS voucher label PDF for an order"),
        description=_(
            "Streams the ACS label PDF through Django auth. "
            "Accessible by the order owner, staff, or a guest with the "
            "order UUID. Returns 404 when no ACS shipment exists for "
            "the order or the voucher has not been minted yet."
        ),
        tags=["Orders"],
    ),
    "shipment_label": ActionConfig(
        response=OrderDetailSerializer,
        operation_id="getShipmentLabelForOrder",
        summary=_("Download the carrier label PDF for an order"),
        description=_(
            "Provider-agnostic label download. Looks up the order's "
            "shipping provider and dispatches to the matching carrier "
            "adapter via the shipping registry — frontends can call "
            "the same endpoint regardless of which courier is "
            "fulfilling the order."
        ),
        tags=["Orders"],
    ),
    "shipment_cancel": ActionConfig(
        response=OrderDetailSerializer,
        operation_id="cancelShipmentForOrder",
        summary=_("Cancel the carrier shipment for an order"),
        description=_(
            "Admin-only. Provider-agnostic cancellation: looks up the "
            "order's shipping provider and dispatches to the carrier "
            "adapter. The provider's own rules apply (BoxNow only "
            "cancels parcels in NEW state; ACS only cancels vouchers "
            "not yet finalised in a pickup list)."
        ),
        tags=["Orders"],
    ),
}


@extend_schema_view(
    **create_schema_view_config(
        model_class=Order,
        display_config={"tag": "Orders"},
        serializers_config=serializers_config,
        error_serializer=ErrorResponseSerializer,
    ),
)
class OrderViewSet(BaseModelViewSet):
    queryset = Order.objects.all()
    serializers_config = serializers_config

    filterset_class = OrderFilter
    ordering_fields = [
        "id",
        "created_at",
        "updated_at",
        "status",
        "status_updated_at",
        "paid_amount",
        "shipping_price",
        "payment_status",
        "user__first_name",
        "user__last_name",
    ]
    ordering = ["-created_at"]
    search_fields = [
        "user__email",
        "user__username",
        "user__first_name",
        "user__last_name",
        "first_name",
        "last_name",
        "email",
        "phone",
        "city",
        "street",
        "zipcode",
        "tracking_number",
        "payment_id",
    ]

    def get_queryset(self):
        """
        Return optimized queryset based on action.

        Uses Order.objects.for_list() for list views and
        Order.objects.for_detail() for detail views to avoid N+1 queries.

        Non-staff users on the list action only see their own orders to
        prevent IDOR enumeration of all orders.
        """
        if self.action == "list":
            qs = Order.objects.for_list()
            if not self.request.user.is_staff:
                qs = qs.filter(user=self.request.user)
            return qs
        elif self.action == "my_orders":
            return Order.objects.for_list()
        return Order.objects.for_detail()

    def get_permissions(self):
        owner_or_admin_actions = {
            "list",
            "retrieve",
            "update",
            "partial_update",
            "destroy",
            "my_orders",
            "reorder",
            "invoice",
            "invoice_download",
            "boxnow_label",
            "acs_label",
            "shipment_label",
        }
        guest_allowed_actions = {
            "retrieve_by_uuid",
            "cancel",
            "payment_status",
            "create_payment_intent",
            "create_checkout_session",
            "retry_payment",
        }
        admin_only_actions = {
            "add_tracking",
            "update_status",
            "refund_order",
            "boxnow_cancel",
            "acs_cancel",
            "shipment_cancel",
        }
        public_actions = {"create"}

        if self.action in owner_or_admin_actions:
            self.permission_classes = [IsOwnerOrAdmin]
        elif self.action in guest_allowed_actions:
            self.permission_classes = [IsOwnerOrAdminOrGuest]
        elif self.action in admin_only_actions:
            self.permission_classes = [IsAdminUser]
        elif self.action in public_actions:
            self.permission_classes = []
        else:
            self.permission_classes = [IsAdminUser]

        return super().get_permissions()

    def check_object_permissions(self, request, obj):
        if (
            request.user
            and request.user.is_authenticated
            and request.user.is_staff
        ):
            super().check_object_permissions(request, obj)
            return

        if obj.user_id is None:
            guest_allowed_actions = {
                "retrieve_by_uuid",
                "cancel",
                "payment_status",
                "create_payment_intent",
                "create_checkout_session",
                "retry_payment",
            }
            if self.action not in guest_allowed_actions:
                raise PermissionDenied(
                    _("Guest orders can only be accessed via UUID.")
                )
            return

        if request.user and request.user.is_authenticated:
            if obj.user_id != request.user.id:
                raise PermissionDenied(
                    _("You do not have permission to access this order.")
                )
            super().check_object_permissions(request, obj)
            return

        raise PermissionDenied(
            _("You do not have permission to access this order.")
        )

    def get_object(self):
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field
        order_id: str = self.kwargs[lookup_url_kwarg]
        max_order_id_length = 8

        try:
            if (
                isinstance(order_id, str)
                and len(order_id) > max_order_id_length
                and "-" in order_id
            ):
                try:
                    uuid.UUID(order_id)
                    obj = OrderService.get_order_by_uuid(order_id)
                    self.check_object_permissions(self.request, obj)
                    return obj
                except (ValueError, TypeError):
                    pass

            obj = OrderService.get_order_by_id(int(order_id))
            self.check_object_permissions(self.request, obj)
            return obj
        except Order.DoesNotExist as e:
            raise NotFound(
                _("Order with ID {order_id} not found").format(
                    order_id=order_id
                )
            ) from e

    @transaction.atomic
    def create(self, request, *args, **kwargs):
        """
        Create an order with dual-flow support.

        This endpoint supports two payment flows based on payment method type:

        **Payment-first (online, intent-based):**
        - Requires payment_intent_id
        - Flow: Payment confirmed → Order created
        - Examples: Stripe

        **Order-first (offline + redirect-based online):**
        - No payment_intent_id required
        - Flow: Order created → Payment pending (redirect to hosted checkout or pay later)
        - Examples: Cash on Delivery, Bank Transfer, Viva Wallet

        Required request data:
        - cart_id: Cart ID or UUID to create order from
        - pay_way_id: Payment method ID
        - payment_intent_id: Required ONLY for online payments
        - Shipping address fields (first_name, last_name, email, street, etc.)

        Returns:
            Response: Order details with 201 status on success

        Raises:
            ValidationError: If validation fails or required fields missing
        """

        try:
            # Step 0: Validate the full request body through
            # OrderCreateFromCartSerializer so every field is type-checked,
            # cross-field rules (B2B, BoxNow) are applied, and the runtime
            # shape matches what the OpenAPI schema advertises.  All
            # subsequent helpers receive ``validated_data`` from this
            # serializer so they no longer touch ``request.data`` directly.
            request_serializer_class = self.get_request_serializer()
            request_serializer = request_serializer_class(data=request.data)
            request_serializer.is_valid(raise_exception=True)
            validated_data = request_serializer.validated_data

            # Step 1: Get payment method to determine flow
            pay_way_id = validated_data["pay_way_id"]

            try:
                pay_way = PayWay.objects.get(id=pay_way_id)
            except PayWay.DoesNotExist:
                raise ValidationError(
                    {
                        "pay_way_id": [
                            _(
                                "Payment method with ID {pay_way_id} not found"
                            ).format(pay_way_id=pay_way_id)
                        ]
                    }
                )

            # Step 2: Route to appropriate flow based on payment type
            # Providers that use hosted redirect checkout (order-first, no payment intent)
            redirect_checkout_providers = {"viva_wallet"}

            if (
                pay_way.is_online_payment
                and pay_way.provider_code not in redirect_checkout_providers
            ):
                # Payment-first flow: Requires payment_intent_id (e.g. Stripe)
                return self._create_with_payment_intent(
                    request, pay_way, validated_data
                )
            else:
                # Order-first flow: No payment_intent_id required
                # (offline payments + redirect-based online providers like Viva Wallet)
                return self._create_without_payment_intent(
                    request, pay_way, validated_data
                )

        except InsufficientStockError as e:
            logger.warning(
                "Insufficient stock for order creation: product_id=%s, available=%s, requested=%s",
                e.product_id,
                e.available,
                e.requested,
            )
            return Response(
                {
                    "detail": _("Insufficient stock for product"),
                    "error": {
                        "type": "insufficient_stock",
                        "product_id": e.product_id,
                        "available": e.available,
                        "requested": e.requested,
                    },
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        except InvalidOrderDataError as e:
            logger.warning("Invalid order data: %s", e)
            error_response = {
                "detail": _("Invalid order data"),
                "error": {
                    "type": "invalid_order_data",
                },
            }
            if e.field_errors:
                error_response["field_errors"] = e.field_errors
            return Response(
                error_response,
                status=status.HTTP_400_BAD_REQUEST,
            )

        except PaymentNotFoundError as e:
            logger.warning("Payment not found: %s", e)
            return Response(
                {
                    "detail": _("Payment not found"),
                    "error": {
                        "type": "payment_not_found",
                    },
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        except PaymentAmountMismatchError as e:
            logger.warning(
                "Payment amount mismatch: provider=%d cents, calculated=%d cents",
                e.provider_amount_cents,
                e.calculated_amount_cents,
            )
            return Response(
                {
                    "detail": _("Payment amount does not match order total."),
                    "error": {
                        "type": "payment_amount_mismatch",
                    },
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        except PaymentCurrencyMismatchError as e:
            logger.warning(
                "Payment currency mismatch: provider='%s', expected='%s'",
                e.provider_currency,
                e.expected_currency,
            )
            return Response(
                {
                    "detail": _(
                        "Payment currency does not match order currency."
                    ),
                    "error": {
                        "type": "payment_currency_mismatch",
                    },
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        except ValidationError as e:
            logger.warning("Validation error: %s", e)
            error_detail = (
                e.detail
                if hasattr(e, "detail")
                else {"detail": _("Validation error")}
            )
            return Response(
                error_detail,
                status=status.HTTP_400_BAD_REQUEST,
            )

        except PermissionDenied:
            return Response(
                {
                    "detail": _(
                        "You do not have permission to perform this action."
                    )
                },
                status=status.HTTP_403_FORBIDDEN,
            )

        except Exception as e:
            logger.error(
                "Unexpected error creating order: %s", e, exc_info=True
            )
            return Response(
                {"detail": _("An unexpected error occurred")},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def _create_with_payment_intent(
        self, request, pay_way: PayWay, validated_data: dict
    ) -> Response:
        """
        Create order with payment-first flow (online payments).

        Requires payment_intent_id to be provided and confirmed.
        ``validated_data`` comes from ``OrderCreateFromCartSerializer``
        and is already type-checked and cross-validated.
        """

        # Step 1: Get cart from request (validate cart exists first)
        cart, user = self._get_cart_and_user(request)

        # Step 2: Validate payment_intent_id is provided
        # The serializer marks this optional (offline path uses the same
        # serializer) so we enforce the online-only requirement here.
        payment_intent_id = validated_data.get("payment_intent_id") or ""
        if not payment_intent_id:
            raise ValidationError(
                {
                    "payment_intent_id": [
                        _(
                            "Payment intent ID is required for online payment methods"
                        )
                    ]
                }
            )

        # Step 3: Validate cart is ready for checkout
        validation_result = OrderService.validate_cart_for_checkout(cart)
        if not validation_result.get("valid", False):
            errors = validation_result.get("errors", [])
            raise ValidationError({"cart": errors})

        # Step 4: Build and validate shipping address from validated data
        shipping_address = self._build_shipping_address_from_validated(
            validated_data
        )
        try:
            OrderService.validate_shipping_address(
                shipping_address, pay_way=pay_way
            )
        except DjangoValidationError as e:
            raise ValidationError(
                e.message_dict
                if hasattr(e, "message_dict")
                else {"detail": _("Invalid shipping address")}
            )

        # Step 5: Get loyalty points to redeem (if any)
        loyalty_points_to_redeem = validated_data.get(
            "loyalty_points_to_redeem"
        )

        # Step 5.5: Pull Meta Pixel context (fbp/fbc/UA/IP/event_ids) the
        # storefront proxy forwarded for Conversions API matching. The
        # service-level helper ``_sanitise_meta_context`` filters this
        # against an allow-list, so it's safe to forward as-is here.
        meta_context = validated_data.get("meta")

        # Step 6: Create order from cart with payment_intent_id
        order = OrderService.create_order_from_cart(
            cart=cart,
            shipping_address=shipping_address,
            payment_intent_id=payment_intent_id,
            pay_way=pay_way,
            user=user,
            loyalty_points_to_redeem=loyalty_points_to_redeem,
            meta_context=meta_context,
        )

        # Return order details
        response_serializer_class = self.get_response_serializer()
        response_serializer = response_serializer_class(
            order, context={"request": request}
        )

        logger.info(
            "Order %s created successfully (online payment) for user %s with payment %s",
            order.id,
            user.id if user else "guest",
            payment_intent_id,
        )

        return Response(
            response_serializer.data, status=status.HTTP_201_CREATED
        )

    def _create_without_payment_intent(
        self, request, pay_way: PayWay, validated_data: dict
    ) -> Response:
        """
        Create order with order-first flow.

        Used for offline payments and redirect-based online providers
        (e.g. Viva Wallet). No payment_intent_id required.
        Order created with PENDING status.
        ``validated_data`` comes from ``OrderCreateFromCartSerializer``
        and is already type-checked and cross-validated.
        """

        # Step 1: Get cart from request
        cart, user = self._get_cart_and_user(request)

        # Step 2: Validate cart is ready for checkout
        validation_result = OrderService.validate_cart_for_checkout(cart)
        if not validation_result.get("valid", False):
            errors = validation_result.get("errors", [])
            raise ValidationError({"cart": errors})

        # Step 3: Build and validate shipping address from validated data
        shipping_address = self._build_shipping_address_from_validated(
            validated_data
        )
        try:
            OrderService.validate_shipping_address(
                shipping_address, pay_way=pay_way
            )
        except DjangoValidationError as e:
            raise ValidationError(
                e.message_dict
                if hasattr(e, "message_dict")
                else {"detail": _("Invalid shipping address")}
            )

        # Step 4: Get loyalty points to redeem (if any)
        loyalty_points_to_redeem = validated_data.get(
            "loyalty_points_to_redeem"
        )

        # Step 4.5: Pull Meta Pixel context for the offline path too —
        # COD orders trigger the canonical Purchase event from
        # ``order_paid`` so the dispatcher needs the same fbp/fbc.
        meta_context = validated_data.get("meta")

        # Step 5: Create order from cart without payment_intent_id
        order = OrderService.create_order_from_cart_offline(
            cart=cart,
            shipping_address=shipping_address,
            pay_way=pay_way,
            user=user,
            loyalty_points_to_redeem=loyalty_points_to_redeem,
            meta_context=meta_context,
        )

        # Return order details
        response_serializer_class = self.get_response_serializer()
        response_serializer = response_serializer_class(
            order, context={"request": request}
        )

        logger.info(
            "Order %s created successfully (order-first, %s) for user %s",
            order.id,
            pay_way.provider_code or "offline",
            user.id if user else "guest",
        )

        return Response(
            response_serializer.data, status=status.HTTP_201_CREATED
        )

    def _get_cart_and_user(self, request):
        """
        Helper method to get cart and user from request using CartService.

        Cart is identified via X-Cart-Id header (standard approach).
        Uses CartService pattern consistent with cart views.

        Note: For order creation, we need an existing cart with items.
        We use get_existing_cart() instead of get_or_create_cart() to ensure
        the cart already exists and is not created on-the-fly.
        """
        from cart.services import CartService

        # Use CartService to get cart from X-Cart-Id header
        cart_service = CartService(request)
        cart = cart_service.get_existing_cart()

        if not cart:
            raise ValidationError(
                {
                    "cart": [
                        _(
                            "Cart not found. Please add items to cart before checkout."
                        )
                    ]
                }
            )

        # Verify cart has items
        if not cart.items.exists():
            raise ValidationError(
                {
                    "cart": [
                        _("Cart is empty. Please add items before checkout.")
                    ]
                }
            )

        # Get user (None for guest orders)
        user = request.user if request.user.is_authenticated else None

        # Verify cart ownership for authenticated users
        if user and cart.user and cart.user.id != user.id:
            raise PermissionDenied(
                _("You do not have permission to access this cart.")
            )

        return cart, user

    def _build_shipping_address_from_validated(
        self, validated_data: dict
    ) -> dict:
        """Build the shipping-address dict from serializer-validated data.

        Uses ``validated_data`` (output of ``OrderCreateFromCartSerializer``)
        instead of ``request.data`` so callers always receive type-safe,
        cross-validated values that match the published OpenAPI schema.

        IMPORTANT: this dict is the only path by which the request body
        reaches ``OrderService.create_order_from_cart`` and
        ``create_order_from_cart_offline``. Every field the service reads
        must be forwarded here — silently dropping a key means the field
        is lost on the order without any error to the caller.
        """
        return {
            # Customer + address (always present)
            "first_name": validated_data.get("first_name"),
            "last_name": validated_data.get("last_name"),
            "email": validated_data.get("email"),
            "phone": validated_data.get("phone"),
            "street": validated_data.get("street"),
            "street_number": validated_data.get("street_number"),
            "city": validated_data.get("city"),
            "zipcode": validated_data.get("zipcode"),
            "place": validated_data.get("place", ""),
            "floor": validated_data.get("floor", ""),
            "location_type": validated_data.get("location_type", ""),
            "country_id": validated_data.get("country_id"),
            "region_id": validated_data.get("region_id"),
            "customer_notes": validated_data.get("customer_notes", ""),
            # B2B billing identity (Tier B — Τιμολόγιο Πώλησης). Empty for retail.
            "document_type": validated_data.get("document_type"),
            "billing_vat_id": validated_data.get("billing_vat_id", ""),
            "billing_country": validated_data.get("billing_country", ""),
            # Registry-driven shipping dispatch: explicit
            # ``(shipping_provider_code, shipping_kind)`` flows through
            # ``_resolve_shipping_provider`` → carrier adapter.
            "shipping_provider_code": validated_data.get(
                "shipping_provider_code"
            ),
            "shipping_kind": validated_data.get("shipping_kind"),
            # Carrier-specific payload keys — kept here so each
            # adapter's ``payload_keys`` ClassVar can pop what it
            # needs in ``_extract_shipment_payload``. Adding a new
            # carrier means listing its keys on the adapter, not
            # editing this dict.
            "boxnow_locker_id": validated_data.get("boxnow_locker_id", ""),
            "boxnow_compartment_size": validated_data.get(
                "boxnow_compartment_size", 1
            ),
            "acs_station_external_id": validated_data.get(
                "acs_station_external_id", ""
            ),
            "acs_station_branch": validated_data.get("acs_station_branch", ""),
            "acs_charge_type": validated_data.get("acs_charge_type"),
            "acs_item_quantity": validated_data.get("acs_item_quantity"),
        }

    # Payment endpoints are expensive and abuse-prone (Stripe PaymentIntent
    # creation, Viva Wallet checkout session). Stack the global anon/user caps
    # with tight per-IP / per-user burst throttles. Guest orders can hit these
    # via uuid query param, so both anon and user throttles are needed.
    @action(
        detail=True,
        methods=["POST"],
        throttle_classes=[
            AnonRateThrottle,
            UserRateThrottle,
            PaymentAttemptThrottle,
            PaymentAttemptAnonThrottle,
        ],
    )
    def create_payment_intent(self, request, *args, **kwargs):
        """Create a payment intent for an order."""
        order = self.get_object()

        if order.is_paid:
            return Response(
                {"detail": _("This order has already been paid.")},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if not order.pay_way or order.pay_way.provider_code != "stripe":
            return Response(
                {
                    "detail": _(
                        "This order is not configured for Stripe payments."
                    )
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        request_serializer_class = self.get_request_serializer()
        request_serializer = request_serializer_class(data=request.data)
        request_serializer.is_valid(raise_exception=True)

        validated_data = request_serializer.validated_data

        payment_data = validated_data.get("payment_data", {})

        if validated_data.get("payment_method_id"):
            payment_data["payment_method_id"] = validated_data[
                "payment_method_id"
            ]
        if validated_data.get("customer_id"):
            payment_data["customer_id"] = validated_data["customer_id"]
        if validated_data.get("return_url"):
            payment_data["return_url"] = validated_data["return_url"]

        success, payment_response = PayWayService.process_payment(
            pay_way=order.pay_way, order=order, **payment_data
        )

        if not success:
            return Response(
                {
                    "detail": _("Failed to create payment intent."),
                    "error": payment_response,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        response_serializer_class = self.get_response_serializer()
        response_serializer = response_serializer_class(data=payment_response)
        response_serializer.is_valid(raise_exception=True)

        return Response(response_serializer.validated_data)

    @action(
        detail=True,
        methods=["POST"],
        url_path="retry-payment",
        throttle_classes=[
            AnonRateThrottle,
            UserRateThrottle,
            PaymentAttemptThrottle,
            PaymentAttemptAnonThrottle,
        ],
    )
    def retry_payment(self, request, *args, **kwargs):
        """Create a fresh Stripe PaymentIntent for a failed/pending order.

        The customer retains the same order, the same items, and the
        same reserved stock (already decremented at order creation).
        We just mint a new PaymentIntent, store its id on the order,
        reset the payment status to PENDING, and return the client
        secret so the frontend can re-mount Stripe Elements.
        """
        from order.enum.status import PaymentStatus

        order = self.get_object()

        if order.is_paid:
            return Response(
                {"detail": _("This order has already been paid.")},
                status=status.HTTP_400_BAD_REQUEST,
            )

        retryable_statuses = {
            PaymentStatus.FAILED,
            PaymentStatus.PENDING,
            PaymentStatus.CANCELED,
        }
        if order.payment_status not in retryable_statuses:
            return Response(
                {
                    "detail": _(
                        "This order's payment status does not allow a retry."
                    )
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        if not order.pay_way or order.pay_way.provider_code != "stripe":
            return Response(
                {"detail": _("Retry is only supported for Stripe payments.")},
                status=status.HTTP_400_BAD_REQUEST,
            )

        request_serializer_class = self.get_request_serializer()
        request_serializer = request_serializer_class(data=request.data)
        request_serializer.is_valid(raise_exception=True)
        validated_data = request_serializer.validated_data

        payment_data = dict(validated_data.get("payment_data") or {})
        for key in ("payment_method_id", "customer_id", "return_url"):
            value = validated_data.get(key)
            if value:
                payment_data[key] = value

        previous_payment_id = order.payment_id
        previous_payment_status = order.payment_status
        success, payment_response = PayWayService.process_payment(
            pay_way=order.pay_way, order=order, **payment_data
        )

        if not success:
            return Response(
                {
                    "detail": _("Failed to create payment intent."),
                    "error": payment_response,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        new_payment_id = payment_response.get("payment_id")

        # Lock the order row while we swap in the new payment intent.
        # A late `payment_intent.payment_failed` webhook for the OLD
        # intent could otherwise land between read and save, flip
        # payment_status to FAILED, and enqueue a duplicate failure
        # email concurrently with this retry flow.
        with transaction.atomic():
            locked_order = Order.objects.select_for_update().get(pk=order.pk)
            if new_payment_id:
                locked_order.payment_id = new_payment_id
            locked_order.payment_status = PaymentStatus.PENDING
            if not locked_order.metadata:
                locked_order.metadata = {}
            retry_history = locked_order.metadata.setdefault(
                "payment_retries", []
            )
            retry_history.append(
                {
                    "at": timezone.now().isoformat(),
                    "previous_payment_id": previous_payment_id or "",
                    "new_payment_id": new_payment_id or "",
                }
            )
            # Reset per-flow idempotency flags so the confirmation
            # email can fire again on the (expected) new
            # payment_intent.succeeded, and the customer can be
            # re-notified of any new failure.
            # Clear both the legacy boolean and the new timestamp key
            # introduced by the worker-kill-safe idempotency refactor.
            locked_order.metadata.pop("confirmation_email_sent", None)
            locked_order.metadata.pop("confirmation_email_sent_at", None)
            locked_order.metadata.pop("payment_failed_email_sent", None)
            locked_order.save(
                update_fields=["payment_id", "payment_status", "metadata"]
            )
        order = locked_order

        OrderHistory.log_payment_update(
            order=order,
            previous_value={
                "payment_status": str(previous_payment_status),
                "payment_id": previous_payment_id or "",
            },
            new_value={
                "payment_status": "pending",
                "payment_id": new_payment_id or "",
                "retry": True,
            },
        )

        response_serializer_class = self.get_response_serializer()
        response_serializer = response_serializer_class(data=payment_response)
        response_serializer.is_valid(raise_exception=True)
        return Response(response_serializer.validated_data)

    @action(
        detail=True,
        methods=["POST"],
        throttle_classes=[
            AnonRateThrottle,
            UserRateThrottle,
            PaymentAttemptThrottle,
            PaymentAttemptAnonThrottle,
        ],
    )
    def create_checkout_session(self, request, *args, **kwargs):
        """Create a hosted checkout session for an order."""
        order = self.get_object()

        if order.is_paid:
            return Response(
                {"detail": _("This order has already been paid.")},
                status=status.HTTP_400_BAD_REQUEST,
            )

        supported_providers = {"stripe", "viva_wallet"}
        if (
            not order.pay_way
            or order.pay_way.provider_code not in supported_providers
        ):
            return Response(
                {
                    "detail": _(
                        "This order is not configured for online payments."
                    )
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        request_serializer_class = self.get_request_serializer()
        request_serializer = request_serializer_class(data=request.data)
        request_serializer.is_valid(raise_exception=True)

        validated_data = request_serializer.validated_data

        checkout_params = {
            "success_url": validated_data["success_url"],
            "cancel_url": validated_data["cancel_url"],
            "customer_email": validated_data.get("customer_email", order.email),
            "description": validated_data.get(
                "description", f"Payment for Order #{order.id}"
            ),
        }

        if request.user.is_authenticated:
            checkout_params["subscriber_id"] = request.user.id

        provider_code = order.pay_way.provider_code
        provider = get_payment_provider(provider_code)

        # Pass the full order total for all providers.
        # Stripe also receives shipping_price separately for
        # a proper line-item breakdown on the checkout page.
        amount = order.total_price

        if provider_code == "stripe":
            checkout_params["shipping_price"] = order.shipping_price

        success, checkout_response = provider.create_checkout_session(
            amount=amount,
            order_id=str(order.id),
            **checkout_params,
        )

        if not success:
            return Response(
                {
                    "detail": _("Failed to create checkout session."),
                    "error": checkout_response,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        if not order.metadata:
            order.metadata = {}

        if provider_code == "viva_wallet":
            existing_code = order.metadata.get("viva_order_code")
            new_code = checkout_response["session_id"]
            if existing_code and existing_code != new_code:
                logger.warning(
                    "Order %s Viva order code replaced: %s → %s "
                    "(retry or duplicate checkout session creation)",
                    order.id,
                    existing_code,
                    new_code,
                )
            order.metadata["viva_order_code"] = new_code
        else:
            order.metadata["stripe_checkout_session_id"] = checkout_response[
                "session_id"
            ]
        order.save(update_fields=["metadata"])

        response_serializer_class = self.get_response_serializer()
        response_serializer = response_serializer_class(data=checkout_response)
        response_serializer.is_valid(raise_exception=True)

        return Response(response_serializer.validated_data)

    @action(detail=True, methods=["GET"])
    def retrieve_by_uuid(self, request, *args, **kwargs):
        """Retrieve an order by UUID."""
        uuid_str = kwargs.get("uuid")
        if not uuid_str:
            raise NotFound(_("UUID parameter is required"))

        try:
            order = OrderService.get_order_by_uuid(uuid_str)
        except Order.DoesNotExist as e:
            raise NotFound(
                _("Order with UUID {uuid} not found").format(uuid=uuid_str)
            ) from e

        self.check_object_permissions(request, order)
        response_serializer_class = self.get_response_serializer()
        serializer = response_serializer_class(order)
        return Response(serializer.data)

    @action(detail=True, methods=["POST"])
    def cancel(self, request, *args, **kwargs):
        """Cancel an order and optionally process refund."""
        order = self.get_object()

        user = request.user

        is_admin = user and user.is_authenticated and user.is_staff
        is_owner = (
            user
            and user.is_authenticated
            and order.user
            and order.user.id == user.id
        )
        is_guest_order = order.user is None

        if not (is_admin or is_owner or is_guest_order):
            raise PermissionDenied(
                _("You do not have permission to cancel this order")
            )

        request_serializer_class = self.get_request_serializer()
        request_serializer = request_serializer_class(
            data=request.data if request.data else {}
        )
        request_serializer.is_valid(raise_exception=True)

        validated_data = request_serializer.validated_data
        cancellation_reason = validated_data.get("reason", "")
        should_refund = validated_data.get("refund_payment", True)

        try:
            canceled_order, refund_info = OrderService.cancel_order(
                order=order,
                reason=cancellation_reason,
                refund_payment=should_refund,
                canceled_by=user.id if user and user.is_authenticated else None,
            )

            response_serializer_class = self.get_response_serializer()
            serializer = response_serializer_class(
                canceled_order, context={"request": request}
            )
            response_data = serializer.data

            if refund_info:
                response_data["refund_info"] = refund_info

            return Response(response_data)

        except OrderCancellationError as e:
            # The service raises this for expected state-transition
            # failures (order already shipped, already canceled, stale
            # status, etc.). Surface it as a 400 so the frontend can
            # treat it as a conflict (refresh + toast) rather than the
            # generic "unexpected error" branch.
            logger.warning("Order %s cancel rejected: %s", order.id, e.reason)
            raise ValidationError({"detail": str(e.reason)}) from e
        except ValueError as e:
            logger.warning("Error canceling order: %s", e)
            raise ValidationError(
                {"detail": _("Unable to cancel this order.")}
            ) from e
        except Exception as e:
            logger.error("Error canceling order: %s", e, exc_info=True)
            return Response(
                {"detail": _("An unexpected error occurred")},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    @extend_schema(
        operation_id="vivaReturnLookup",
        tags=["Orders"],
        summary=_(
            "Look up an order by Viva Wallet transaction id (post-payment redirect)"
        ),
        description=_(
            "Viva's hosted checkout redirects to a static success URL "
            "configured in the merchant portal — Viva does not support "
            "per-order success URLs (only ``urlFail``). This endpoint "
            "translates the ``t`` (transaction_id) query param that "
            "Viva appends to the redirect into the order's UUID so the "
            "Nuxt return page can forward the customer to the canonical "
            "``/checkout/success/{uuid}`` route. Permission is open "
            "because the transaction_id is a Viva-generated UUID "
            "(unguessable) and the response carries no PII — just the "
            "order's UUID, public id, status, and payment_status."
        ),
        parameters=[
            OpenApiParameter(
                name="t",
                location=OpenApiParameter.QUERY,
                required=True,
                description="Viva transaction_id (UUID).",
                type=str,
            ),
        ],
        responses={200: None, 400: None, 404: None},
    )
    @action(
        detail=False,
        methods=["GET"],
        permission_classes=[AllowAny],
        url_path="viva_return",
    )
    def viva_return(self, request, *args, **kwargs):
        """Return the order UUID for a Viva transaction id."""
        transaction_id = request.query_params.get("t", "").strip()
        if not transaction_id:
            return Response(
                {"detail": _("Missing transaction id (t query param).")},
                status=status.HTTP_400_BAD_REQUEST,
            )

        order = (
            Order.objects.only(
                "id", "uuid", "status", "payment_status", "payment_id"
            )
            .filter(payment_id=transaction_id, payment_method="viva_wallet")
            .first()
        )
        if order is None:
            raise NotFound(
                _("No order found for transaction id {t}").format(
                    t=transaction_id
                )
            )

        return Response(
            {
                "id": order.id,
                "uuid": str(order.uuid),
                "status": str(order.status),
                "paymentStatus": str(order.payment_status),
            }
        )

    @action(detail=False, methods=["GET"])
    def my_orders(self, request, *args, **kwargs):
        """List current user's orders."""
        if not request.user.is_authenticated:
            raise NotAuthenticated(
                _("Authentication is required to view your orders")
            )

        user_orders = OrderService.get_user_orders(request.user.id)

        filtered_qs = self.filter_queryset(user_orders)

        response_serializer_class = self.get_response_serializer()
        return self.paginate_and_serialize(
            filtered_qs,
            request,
            serializer_class=response_serializer_class,
        )

    @action(detail=True, methods=["GET"])
    def invoice(self, request, *args, **kwargs):
        """Return invoice metadata + download URL for an order.

        404 when the invoice has not been generated yet (e.g. order
        still PENDING). Permission check is done via the viewset's
        standard ``get_object`` flow which already covers owner/admin
        and guest-via-uuid access.
        """
        order = self.get_object()
        invoice = getattr(order, "invoice", None)
        if invoice is None or not invoice.has_document():
            raise NotFound(
                _("Invoice has not been generated for this order yet.")
            )
        serializer = InvoiceDownloadResponseSerializer(
            invoice, context={"request": request}
        )
        return Response(serializer.data)

    @extend_schema(
        operation_id="downloadOrderInvoice",
        tags=["Orders"],
        summary=_("Download the invoice PDF"),
        description=_(
            "Streams the rendered PDF through Django auth. 404 when "
            "the invoice has not been generated yet. Same ownership "
            "check as the metadata endpoint — returns a signed S3 "
            "stream on prod and a filesystem stream in dev without "
            "exposing the storage URL to the client."
        ),
        responses={200: None, 404: None},
    )
    @action(detail=True, methods=["GET"], url_path="invoice/download")
    def invoice_download(self, request, *args, **kwargs):
        """Stream the invoice PDF through Django auth.

        Why this exists instead of redirecting to ``document_file.url``:
        - FileSystem backend: ``url()`` returns ``/media/...`` which
          isn't actually served (private files live under a separate
          ``mediafiles_private/`` root).
        - S3 backend: ``AWS_QUERYSTRING_AUTH`` is ``False`` globally
          for static / public media; ``PrivateMediaStorage`` overrides
          it locally but even then direct S3 URLs leak the bucket layout.
        - Streaming through Django keeps the download gated by the
          same ``IsOwnerOrAdmin`` check as the metadata endpoint, works
          identically on every backend, and the customer's browser
          sees a clean ``api.webside.gr`` URL in history.

        Uses ``storage.open('rb')`` rather than ``open(abs_path, 'rb')``
        so it works on S3 without downloading the file to disk first
        (django-storages' S3 file object streams chunks).
        """
        order = self.get_object()
        invoice = getattr(order, "invoice", None)
        if invoice is None or not invoice.has_document():
            raise NotFound(
                _("Invoice has not been generated for this order yet.")
            )
        return FileResponse(
            invoice.document_file.open("rb"),
            content_type="application/pdf",
            as_attachment=True,
            filename=f"{invoice.invoice_number}.pdf",
        )

    @action(detail=True, methods=["POST"])
    def reorder(self, request, *args, **kwargs):
        """Clone a past order's items back into the user's active cart."""
        order = self.get_object()

        user = request.user
        if not user or not user.is_authenticated:
            raise NotAuthenticated(
                _("Authentication is required to reorder a past order.")
            )
        if order.user_id != user.id and not user.is_staff:
            raise PermissionDenied(
                _("You can only reorder your own past orders.")
            )

        result = OrderService.reorder_to_cart(order=order, user=user)
        response_serializer_class = self.get_response_serializer()
        serializer = response_serializer_class(data=result)
        serializer.is_valid(raise_exception=True)
        return Response(serializer.validated_data)

    @action(detail=True, methods=["POST"])
    def add_tracking(self, request, *args, **kwargs):
        """Add tracking information to an order."""
        order = self.get_object()

        if not request.user.is_staff:
            raise PermissionDenied(_("Only staff can add tracking information"))

        request_serializer_class = self.get_request_serializer()
        request_serializer = request_serializer_class(data=request.data)
        request_serializer.is_valid(raise_exception=True)

        validated_data = request_serializer.validated_data
        tracking_number = validated_data["tracking_number"]
        shipping_carrier = validated_data["shipping_carrier"]

        try:
            order = OrderService.add_tracking_info(
                order=order,
                tracking_number=tracking_number,
                shipping_carrier=shipping_carrier,
                auto_update_status=True,
            )

            response_serializer_class = self.get_response_serializer()
            response_serializer = response_serializer_class(
                order, context=self.get_serializer_context()
            )
            return Response(response_serializer.data)

        except Exception as e:
            logger.error(
                "Error adding tracking information: %s", e, exc_info=True
            )
            return Response(
                {"detail": _("An unexpected error occurred")},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    @action(detail=True, methods=["POST"])
    def update_status(self, request, *args, **kwargs):
        """Update the status of an order."""
        order = self.get_object()

        if not request.user.is_staff:
            raise PermissionDenied(_("Only staff can update order status"))

        request_serializer_class = self.get_request_serializer()
        request_serializer = request_serializer_class(data=request.data)
        request_serializer.is_valid(raise_exception=True)

        validated_data = request_serializer.validated_data
        status_value = validated_data["status"]

        try:
            OrderService.update_order_status(order, status_value)

            order = OrderService.get_order_by_id(order.id)

            response_serializer_class = self.get_response_serializer()
            response_serializer = response_serializer_class(
                order, context=self.get_serializer_context()
            )
            return Response(response_serializer.data)

        except InvalidStatusTransitionError as e:
            logger.warning("Invalid status transition: %s", e)
            raise ValidationError(
                {
                    "detail": _("Invalid status transition."),
                    "current_status": e.current_status,
                    "new_status": e.new_status,
                    "allowed_transitions": e.allowed,
                }
            ) from e
        except ValueError as e:
            logger.error("Error updating order status: %s", e)
            raise ValidationError(
                {
                    "detail": _(
                        "An error occurred while processing your request."
                    )
                }
            ) from e
        except Exception as e:
            logger.error("Error updating order status: %s", e, exc_info=True)
            return Response(
                {"detail": _("An unexpected error occurred")},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    @action(detail=True, methods=["POST"])
    def refund_order(self, request, *args, **kwargs):
        """Process full or partial refund for an order."""
        order = self.get_object()

        request_serializer_class = self.get_request_serializer()
        request_serializer = request_serializer_class(data=request.data)
        request_serializer.is_valid(raise_exception=True)

        validated_data = request_serializer.validated_data

        refund_amount = None
        if validated_data.get("amount"):
            currency = validated_data.get(
                "currency", str(order.total_price.currency)
            )
            refund_amount = Money(validated_data["amount"], currency)

        try:
            success, response_data = OrderService.refund_order(
                order=order,
                amount=refund_amount,
                reason=validated_data.get("reason", ""),
                refunded_by=request.user.id
                if request.user.is_authenticated
                else None,
            )

            if not success:
                return Response(
                    {
                        "detail": _("Failed to process refund."),
                        "error": response_data.get("error"),
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            response_data["success"] = True
            response_data["message"] = _("Refund processed successfully.")

            response_serializer_class = self.get_response_serializer()
            response_serializer = response_serializer_class(data=response_data)
            response_serializer.is_valid(raise_exception=True)

            return Response(response_serializer.validated_data)

        except ValueError as e:
            logger.warning(
                "Refund validation error for order %s: %s",
                order.id,
                e,
            )
            return Response(
                {"detail": _("Unable to process refund for this order.")},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except Exception as e:
            logger.error(
                "Error processing refund for order %s: %s",
                order.id,
                e,
                exc_info=True,
            )
            return Response(
                {
                    "detail": _(
                        "An error occurred while processing the refund."
                    ),
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    @action(detail=True, methods=["GET"])
    def payment_status(self, request, *args, **kwargs):
        """Get current payment status from payment provider."""
        order = self.get_object()

        try:
            payment_status_enum, status_data = OrderService.get_payment_status(
                order
            )

            response_data = {"status": payment_status_enum.value, **status_data}

            response_serializer_class = self.get_response_serializer()
            response_serializer = response_serializer_class(data=response_data)
            response_serializer.is_valid(raise_exception=True)

            return Response(response_serializer.validated_data)

        except ValueError as e:
            logger.warning(
                "Payment status error for order %s: %s",
                order.id,
                e,
            )
            return Response(
                {"detail": _("Unable to retrieve payment status.")},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except Exception as e:
            logger.error(
                "Error getting payment status for order %s: %s",
                order.id,
                e,
                exc_info=True,
            )
            return Response(
                {
                    "detail": _(
                        "An error occurred while fetching payment status."
                    ),
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    @action(
        detail=True,
        methods=["post"],
        url_path="boxnow_cancel",
        permission_classes=[IsAdminUser],
    )
    def boxnow_cancel(self, request, pk=None):
        """Cancel the BoxNow shipment for an order (admin-only)."""
        from shipping_boxnow.exceptions import BoxNowAPIError
        from shipping_boxnow.services import BoxNowService

        order = self.get_object()

        shipment = getattr(order, "boxnow_shipment", None)
        if shipment is None:
            raise NotFound(_("This order does not have a BoxNow shipment."))

        reason: str = request.data.get("reason", "")

        try:
            BoxNowService.cancel_shipment(shipment, reason=reason)
        except BoxNowAPIError as exc:
            logger.warning(
                "BoxNow cancel (order-action) failed | order=%s"
                " | parcel_id=%s | code=%s | msg=%s",
                order.id,
                shipment.parcel_id,
                exc.code,
                exc,
            )
            return Response(
                {"detail": str(exc), "code": exc.code},
                status=status.HTTP_400_BAD_REQUEST,
            )

        order = OrderService.get_order_by_id(order.id)
        response_serializer_class = self.get_response_serializer()
        serializer = response_serializer_class(
            order, context=self.get_serializer_context()
        )
        return Response(serializer.data)

    @action(
        detail=True,
        methods=["get"],
        url_path="boxnow_label",
    )
    def boxnow_label(self, request, pk=None):
        """Download the BoxNow parcel label PDF for an order."""
        from io import BytesIO

        from shipping_boxnow.services import BoxNowService

        order = self.get_object()

        shipment = getattr(order, "boxnow_shipment", None)
        if shipment is None or not shipment.parcel_id:
            raise NotFound(
                _("No BoxNow shipment or parcel ID found for this order.")
            )

        label_bytes: bytes = BoxNowService.fetch_label_bytes(shipment)
        return FileResponse(
            BytesIO(label_bytes),
            content_type="application/pdf",
            as_attachment=True,
            filename=f"boxnow-{shipment.parcel_id}.pdf",
        )

    @action(
        detail=True,
        methods=["post"],
        url_path="acs_cancel",
        permission_classes=[IsAdminUser],
    )
    def acs_cancel(self, request, pk=None):
        """Cancel the ACS shipment for an order (admin-only)."""
        from shipping_acs.exceptions import AcsAPIError
        from shipping_acs.services import AcsService

        order = self.get_object()

        shipment = getattr(order, "acs_shipment", None)
        if shipment is None:
            raise NotFound(_("This order does not have an ACS shipment."))

        reason: str = request.data.get("reason", "")
        try:
            AcsService.cancel_voucher(shipment, reason=reason)
        except AcsAPIError as exc:
            logger.warning(
                "ACS cancel (order-action) failed | order=%s | "
                "voucher_no=%s | msg=%s",
                order.id,
                shipment.voucher_no,
                exc,
            )
            return Response(
                {"detail": str(exc)},
                status=status.HTTP_400_BAD_REQUEST,
            )

        order = OrderService.get_order_by_id(order.id)
        response_serializer_class = self.get_response_serializer()
        serializer = response_serializer_class(
            order, context=self.get_serializer_context()
        )
        return Response(serializer.data)

    @action(
        detail=True,
        methods=["get"],
        url_path="acs_label",
    )
    def acs_label(self, request, pk=None):
        """Download the ACS voucher label PDF for an order."""
        from io import BytesIO

        from shipping_acs.services import AcsService

        order = self.get_object()

        shipment = getattr(order, "acs_shipment", None)
        if shipment is None or not shipment.voucher_no:
            raise NotFound(
                _("No ACS shipment or voucher found for this order.")
            )

        label_bytes: bytes = AcsService.fetch_label_bytes(shipment)
        return FileResponse(
            BytesIO(label_bytes),
            content_type="application/pdf",
            as_attachment=True,
            filename=f"acs-{shipment.voucher_no}.pdf",
        )

    @action(
        detail=True,
        methods=["get"],
        url_path="shipment_label",
    )
    def shipment_label(self, request, pk=None):
        """Download the carrier label PDF — provider-agnostic.

        Looks up the order's ``shipping_provider`` and dispatches to
        the matching carrier adapter via the shipping registry.  Lets
        the frontend hit a single endpoint regardless of which courier
        is fulfilling the order.
        """
        from io import BytesIO

        from shipping.services import ShippingService

        order = self.get_object()

        adapter = ShippingService.adapter_for_order(order)
        if adapter is None:
            raise NotFound(_("No carrier shipment found for this order."))
        shipment = adapter.shipment_for_order(order)
        if shipment is None:
            raise NotFound(_("No carrier shipment found for this order."))

        label_bytes: bytes = adapter.fetch_label_bytes(shipment)
        provider_code = order.shipping_provider.code
        return FileResponse(
            BytesIO(label_bytes),
            content_type="application/pdf",
            as_attachment=True,
            filename=f"{provider_code}-{order.id}.pdf",
        )

    @action(
        detail=True,
        methods=["post"],
        url_path="shipment_cancel",
        permission_classes=[IsAdminUser],
    )
    def shipment_cancel(self, request, pk=None):
        """Cancel the carrier shipment — provider-agnostic.

        Admin-only.  Dispatches to the order's carrier adapter; the
        provider's own state-machine rules apply (BoxNow rejects
        already-shipped parcels with P420; ACS rejects vouchers
        already in a pickup list).
        """
        from shipping.services import ShippingService
        from shipping_acs.exceptions import AcsAPIError
        from shipping_boxnow.exceptions import BoxNowAPIError

        order = self.get_object()

        adapter = ShippingService.adapter_for_order(order)
        if adapter is None:
            raise NotFound(_("No carrier shipment found for this order."))
        shipment = adapter.shipment_for_order(order)
        if shipment is None:
            raise NotFound(_("No carrier shipment found for this order."))

        reason: str = request.data.get("reason", "")
        try:
            adapter.cancel_shipment(shipment, reason=reason)
        except (BoxNowAPIError, AcsAPIError) as exc:
            logger.warning(
                "Shipment cancel (generic) failed | order=%s | "
                "provider=%s | msg=%s",
                order.id,
                order.shipping_provider.code,
                exc,
            )
            return Response(
                {"detail": str(exc)},
                status=status.HTTP_400_BAD_REQUEST,
            )

        order = OrderService.get_order_by_id(order.id)
        response_serializer_class = self.get_response_serializer()
        serializer = response_serializer_class(
            order, context=self.get_serializer_context()
        )
        return Response(serializer.data)
