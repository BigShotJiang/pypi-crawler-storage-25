"""auth-sdk-m8 shared authentication utilities for m8 microservices."""

__version__ = "0.6.3"

__all__ = ["__version__"]
