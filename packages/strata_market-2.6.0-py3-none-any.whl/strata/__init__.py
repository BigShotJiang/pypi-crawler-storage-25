"""
STRATA — Market State Framework
================================
Structured Trading Reasoning Architecture

A layered, stateful framework for market regime estimation and
decision support. STRATA does not predict prices; it maintains
a continuous internal state representing current market conditions
and produces auditable action recommendations gated by hard risk rules.

Public API
----------
sense(candles)                  OHLCV window → semantic signals
initial_state()                 zeroed state vector
update_state(state, inp, mem)   core state transition F(S, I, M) → S'
compute_confidence(state)       scalar confidence from current state
classify_regime(state)          TRENDING | RANGING | TRANSITIONING | CHOPPY
decide(state)                   state → {action, confidence, risk, regime}
StrataGUARD(asset=None)         hard-rule risk gate (regime + asset aware)
StrataMEMORY()                  3-layer pattern memory (Short/Mid/Long)
StrataLOOP()                    closed-loop weight adaptation via P&L feedback

See README.md for usage examples.
See MANIFESTO.md for architecture and design principles.
"""

__version__ = "2.6.0"   # V2.6: tick-level sense (bid/ask spread anticipatory liquidity)

from .core        import initial_state, update_state, compute_confidence, classify_regime
from .memory      import StrataMEMORY
from .guard       import StrataGUARD
from .decide      import decide
from .sense       import sense, sense_tick
from .loop        import StrataLOOP
from .model       import StrataModel
from .trainer     import StrataTrainer
from .net         import StrataNet, StrataNetConfig, StrataNetOutput, ACTION_IDX, IDX_ACTION, REGIME_IDX, IDX_REGIME
from .net_trainer import StrataNetTrainer, StrataNetDataset

__all__ = [
    # ── Neural network architecture (new in v2.5) ──────────────────────
    "StrataNet",           # PyTorch model — train/save/load/predict_action
    "StrataNetConfig",     # hyperparameter config dataclass
    "StrataNetOutput",     # forward pass output container
    "StrataNetTrainer",    # gradient descent training loop
    "StrataNetDataset",    # OHLCV → labeled PyTorch Dataset
    # ── High-level state-machine model API (v2.4) ──────────────────────
    "StrataModel",         # gradient-free trainable model (JSON)
    "StrataTrainer",       # coordinate optimizer
    # ── Core state engine ──────────────────────────────────────────────
    "initial_state",
    "update_state",
    "compute_confidence",
    "classify_regime",
    # ── Layers ─────────────────────────────────────────────────────────
    "sense",
    "sense_tick",
    "StrataMEMORY",
    "decide",
    "StrataGUARD",
    "StrataLOOP",
    # ── Index maps ─────────────────────────────────────────────────────
    "ACTION_IDX",
    "IDX_ACTION",
    "REGIME_IDX",
    "IDX_REGIME",
    # ── Meta ───────────────────────────────────────────────────────────
    "__version__",
]
