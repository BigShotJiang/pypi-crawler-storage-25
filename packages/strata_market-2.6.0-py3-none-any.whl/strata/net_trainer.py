"""
STRATA-NET Trainer: Gradient Descent Training Loop
====================================================
Trains StrataNet end-to-end from labeled OHLCV sequences using PyTorch.

Label generation: uses the existing STRATA state machine as a "teacher"
to generate soft action + regime labels from historical data — a form of
knowledge distillation where the interpretable rule-based system teaches
the neural network.

This means:
  - No manual labeling required
  - Labels are regime-aware and risk-gated (GUARD outputs are respected)
  - Training data = any OHLCV history you have

Usage:
    from strata.net import StrataNet, StrataNetConfig
    from strata.net_trainer import StrataNetTrainer, StrataNetDataset

    # Prepare dataset from flat OHLCV candles
    dataset = StrataNetDataset.from_candles(my_candles, seq_len=30)

    # Train
    trainer = StrataNetTrainer(asset="AAPL")
    model   = trainer.train(dataset, epochs=30)
    model.save("aapl_net.pt")

    # Load and predict
    model  = StrataNet.load("aapl_net.pt")
    result = model.predict_action(x_tensor)
"""

import random
from typing import List, Optional, Dict, Tuple

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader

from .net     import StrataNet, StrataNetConfig, ACTION_IDX, REGIME_IDX
from .core    import DEFAULT_WEIGHTS, initial_state, update_state
from .memory  import StrataMEMORY
from .decide  import decide
from .guard   import StrataGUARD
from .sense   import sense


# ---------------------------------------------------------------------------
# OHLCV normalisation helpers
# ---------------------------------------------------------------------------

def _normalise_window(window: List[Dict]) -> List[List[float]]:
    """
    Normalise a candle window to a list of 5-feature vectors.

    Normalisation:
      - open, high, low, close: percent change relative to window's first close
      - volume: ratio to window mean volume

    Returns: list of [open_pct, high_pct, low_pct, close_pct, vol_ratio]
    """
    base_close = window[0]["close"] + 1e-9
    volumes    = [c["volume"] for c in window]
    mean_vol   = sum(volumes) / len(volumes) + 1e-9

    rows = []
    for c in window:
        rows.append([
            (c["open"]   - base_close) / base_close,
            (c["high"]   - base_close) / base_close,
            (c["low"]    - base_close) / base_close,
            (c["close"]  - base_close) / base_close,
            c["volume"]  / mean_vol,
        ])
    return rows


def _generate_labels(
    windows: List[List[Dict]],
    asset:   Optional[str] = None,
) -> Tuple[List[int], List[int]]:
    """
    Use STRATA state machine as teacher to generate action + regime labels.

    Returns:
        action_labels: list of int (0=LONG, 1=SHORT, 2=HOLD)
        regime_labels: list of int (0=TRENDING, 1=RANGING, 2=TRANSITIONING, 3=CHOPPY)
    """
    state  = initial_state()
    memory = StrataMEMORY()
    guard  = StrataGUARD(asset=asset)

    action_labels = []
    regime_labels = []

    for window in windows:
        inp        = sense(window)
        mem_signal = memory.snapshot()
        state      = update_state(state, inp, mem_signal)
        decision   = decide(state)
        confidence = decision["confidence"]

        approved, _ = guard.evaluate(state, decision, confidence)
        final_action = decision["action"] if approved else "HOLD"

        action_labels.append(ACTION_IDX[final_action])
        regime_labels.append(REGIME_IDX.get(decision["regime"], 2))

    return action_labels, regime_labels


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

class StrataNetDataset(Dataset):
    """
    PyTorch Dataset of (x_tensor, action_label, regime_label) triples.

    x_tensor shape: (seq_len, 5) — normalised OHLCV features
    """

    def __init__(
        self,
        sequences:     List[torch.Tensor],   # each (seq_len, 5)
        action_labels: List[int],
        regime_labels: List[int],
    ):
        assert len(sequences) == len(action_labels) == len(regime_labels)
        self.sequences     = sequences
        self.action_labels = action_labels
        self.regime_labels = regime_labels

    def __len__(self) -> int:
        return len(self.sequences)

    def __getitem__(self, idx):
        return (
            self.sequences[idx],
            torch.tensor(self.action_labels[idx], dtype=torch.long),
            torch.tensor(self.regime_labels[idx], dtype=torch.long),
        )

    @classmethod
    def from_candles(
        cls,
        candles:  List[Dict],
        seq_len:  int           = 30,
        asset:    Optional[str] = None,
        verbose:  bool          = True,
    ) -> "StrataNetDataset":
        """
        Build dataset from a flat list of OHLCV candles.

        Args:
            candles:  flat list of OHLCV dicts, oldest → newest
            seq_len:  sequence length (number of bars per sample)
            asset:    ticker for GUARD profile
            verbose:  print progress

        Returns:
            StrataNetDataset ready for DataLoader
        """
        if len(candles) < seq_len + 1:
            raise ValueError(f"Need at least {seq_len + 1} candles, got {len(candles)}")

        windows = [candles[i : i + seq_len] for i in range(len(candles) - seq_len + 1)]

        if verbose:
            print(f"[StrataNetDataset] Generating labels from {len(windows)} windows "
                  f"(teacher: STRATA state machine) ...")

        action_labels, regime_labels = _generate_labels(windows, asset=asset)

        sequences = [
            torch.tensor(_normalise_window(w), dtype=torch.float32)
            for w in windows
        ]

        if verbose:
            n_long  = action_labels.count(0)
            n_short = action_labels.count(1)
            n_hold  = action_labels.count(2)
            total   = len(action_labels)
            print(f"  Labels: LONG={n_long/total:.1%}  SHORT={n_short/total:.1%}  "
                  f"HOLD={n_hold/total:.1%}  total={total}")

        return cls(sequences, action_labels, regime_labels)


# ---------------------------------------------------------------------------
# Trainer
# ---------------------------------------------------------------------------

class StrataNetTrainer:
    """
    Trains StrataNet via gradient descent with teacher-generated labels.

    The training objective has two components:
      1. Action loss    — cross-entropy on LONG/SHORT/HOLD
      2. Regime loss    — cross-entropy on TRENDING/RANGING/TRANSITIONING/CHOPPY
      3. Confidence reg — encourage confidence to be high when action is correct

    No manual labeling required — STRATA state machine generates all labels.
    """

    def __init__(
        self,
        asset:   Optional[str] = None,
        device:  str           = "cpu",
        verbose: bool          = True,
    ):
        self.asset   = asset
        self.device  = torch.device(device)
        self.verbose = verbose

    def train(
        self,
        dataset:     StrataNetDataset,
        cfg:         Optional[StrataNetConfig] = None,
        epochs:      int   = 30,
        batch_size:  int   = 64,
        lr:          float = 1e-3,
        weight_decay: float = 1e-4,
    ) -> StrataNet:
        """
        Train a StrataNet model from a StrataNetDataset.

        Args:
            dataset:      StrataNetDataset from StrataNetDataset.from_candles()
            cfg:          StrataNetConfig (defaults used if None)
            epochs:       number of training epochs
            batch_size:   mini-batch size
            lr:           learning rate (Adam)
            weight_decay: L2 regularization

        Returns:
            Trained StrataNet model (eval mode), ready for predict_action() and save()
        """
        if cfg is None:
            cfg = StrataNetConfig(
                asset   = self.asset or "GENERIC",
                seq_len = dataset.sequences[0].shape[0],
            )

        model  = StrataNet(cfg).to(self.device)
        opt    = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
        sched  = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=lr * 0.1)
        loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=False)

        action_loss_fn = nn.CrossEntropyLoss(label_smoothing=cfg.label_smoothing)
        regime_loss_fn = nn.CrossEntropyLoss(label_smoothing=cfg.label_smoothing)

        if self.verbose:
            print(f"\n[StrataNetTrainer] Training {model}")
            print(f"  asset={self.asset}  epochs={epochs}  "
                  f"batch={batch_size}  lr={lr}  samples={len(dataset)}")
            print(f"  Architecture:\n{model.summary()}\n")

        for epoch in range(1, epochs + 1):
            model.train()
            total_loss = 0.0
            n_batches  = 0

            for x_batch, a_labels, r_labels in loader:
                x_batch  = x_batch.to(self.device)
                a_labels = a_labels.to(self.device)
                r_labels = r_labels.to(self.device)

                opt.zero_grad()
                out = model(x_batch)

                loss_action = action_loss_fn(out.action_logits, a_labels)
                loss_regime = regime_loss_fn(out.regime_logits, r_labels)

                # Confidence regularization: penalize low confidence on correct predictions
                pred_correct = out.action_logits.argmax(-1) == a_labels
                conf_penalty = (1.0 - out.confidence[pred_correct]).mean() if pred_correct.any() else torch.tensor(0.0)

                loss = loss_action + 0.3 * loss_regime + 0.1 * conf_penalty
                loss.backward()

                nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                opt.step()

                total_loss += loss.item()
                n_batches  += 1

            sched.step()
            avg_loss = total_loss / max(n_batches, 1)

            if self.verbose and (epoch % 5 == 0 or epoch == 1 or epoch == epochs):
                acc = self._eval_accuracy(model, dataset)
                print(f"  Epoch {epoch:>3}/{epochs}  loss={avg_loss:.4f}  "
                      f"action_acc={acc:.1%}  lr={sched.get_last_lr()[0]:.2e}")

        model.eval()
        if self.verbose:
            final_acc = self._eval_accuracy(model, dataset)
            print(f"\n[StrataNetTrainer] Done — final action_acc={final_acc:.1%}")

        return model

    def _eval_accuracy(self, model: StrataNet, dataset: StrataNetDataset) -> float:
        """Compute action classification accuracy over full dataset."""
        model.eval()
        correct = total = 0
        loader  = DataLoader(dataset, batch_size=256, shuffle=False)
        with torch.no_grad():
            for x_batch, a_labels, _ in loader:
                x_batch  = x_batch.to(self.device)
                a_labels = a_labels.to(self.device)
                out      = model(x_batch)
                preds    = out.action_logits.argmax(-1)
                correct += (preds == a_labels).sum().item()
                total   += len(a_labels)
        model.train()
        return correct / max(total, 1)
