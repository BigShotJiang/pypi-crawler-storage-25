"""
STRATA-SENSE: Input Layer
Converts raw OHLCV candles into semantic signals for STRATA-CORE.

Input:  raw OHLCV window (pandas DataFrame or list of dicts)
Output: {trend, vol, liquidity_above, break_structure}

All outputs are normalised to their expected ranges:
  trend            : [-1.0,  1.0]  (direction + magnitude)
  vol              : [ 0.0,  1.0]  (volatility intensity)
  liquidity_above  : [ 0.0,  1.0]  (volume anomaly flag / spread pressure)
  break_structure  : [ 0.0,  1.0]  (structure break strength)

Tick-level upgrade (v2.6):
  If candles contain 'bid' and 'ask' fields, sense() automatically uses
  bid/ask spread as the liquidity_above signal instead of volume proxy.

  Spread-based sensing is ANTICIPATORY — it detects liquidity tension
  BEFORE price moves, unlike volume which is reactive (recorded after).

  Spread signal: current_spread_ratio vs rolling average, z-score mapped to [0,1].
  Wide spread relative to recent norm -> elevated liquidity_above -> trap_risk rises.

  Use sense_tick() for richer tick data (bid/ask + bid_size/ask_size side imbalance).
"""

import math
from typing import Dict, List


def _ema(values: List[float], period: int) -> float:
    """Lightweight EMA on a list of floats (most-recent-last)."""
    if not values:
        return 0.0
    k = 2.0 / (period + 1)
    ema = values[0]
    for v in values[1:]:
        ema = v * k + ema * (1 - k)
    return ema


def _atr(candles: List[Dict], period: int = 14) -> float:
    """Average True Range over last `period` candles."""
    trs = []
    for i in range(1, len(candles)):
        h = candles[i]["high"]
        l = candles[i]["low"]
        pc = candles[i - 1]["close"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    if not trs:
        return 1e-9
    window = trs[-period:]
    return sum(window) / len(window)


def _spread_liquidity(candles: List[Dict], vol_period: int = 20) -> float:
    """
    Tick-level liquidity signal derived from bid/ask spread.

    ANTICIPATORY: spread widens BEFORE price moves as market makers
    pull liquidity, making this a leading indicator vs volume (lagging).

    Signal: current spread ratio vs rolling window average, mapped via z-score.
    Wide spread relative to recent norm -> elevated liquidity_above.

    Returns:
        float [0, 1]
    """
    spreads = []
    for c in candles:
        bid = c.get("bid", 0.0) or 0.0
        ask = c.get("ask", 0.0) or 0.0
        if bid > 0 and ask > 0 and ask >= bid:
            mid = (bid + ask) / 2.0
            spreads.append((ask - bid) / (mid + 1e-9))

    if len(spreads) < 3:
        return 0.0

    recent     = spreads[-vol_period:]
    avg_spread = sum(recent) / len(recent)
    curr       = spreads[-1]

    if len(recent) > 1:
        variance   = sum((s - avg_spread) ** 2 for s in recent) / len(recent)
        std_spread = math.sqrt(variance) + 1e-9
        z          = (curr - avg_spread) / std_spread
        # Map z-score to [0, 1]: z=0 -> 0.0, z=2 -> 0.73, z=4 -> 0.98
        liq = 1.0 - 1.0 / (1.0 + max(0.0, z) ** 1.5)
    else:
        ratio = curr / (avg_spread + 1e-9)
        liq   = min(1.0, max(0.0, (ratio - 1.0) / 2.0))

    return round(min(1.0, max(0.0, liq)), 6)


def sense(candles: List[Dict], vol_period: int = 20) -> Dict[str, float]:
    """
    Convert a window of OHLCV candles into STRATA semantic signals.

    Args:
        candles: list of dicts with keys open/high/low/close/volume,
                 ordered oldest → newest. Minimum 3 candles required.
                 Optional tick-level keys: 'bid', 'ask'  — when present,
                 enables spread-based anticipatory liquidity sensing.
        vol_period: lookback for volume and volatility normalisation.

    Returns:
        {
            "trend":           float [-1, 1],
            "vol":             float [0,  1],
            "liquidity_above": float [0,  1],   # spread-based if bid/ask present
            "break_structure": float [0,  1],
            "source":          str,             # "spread" | "volume" | "none"
        }
    """
    if len(candles) < 3:
        return {"trend": 0.0, "vol": 0.0, "liquidity_above": 0.0,
                "break_structure": 0.0, "source": "none"}

    closes  = [c["close"]  for c in candles]
    highs   = [c["high"]   for c in candles]
    lows    = [c["low"]    for c in candles]
    volumes = [c["volume"] for c in candles]

    # ── TREND ──────────────────────────────────────────────────────────────
    # Fast EMA vs Slow EMA crossover, normalised by ATR
    fast_period = max(3,  len(candles) // 4)
    slow_period = max(6,  len(candles) // 2)
    fast_ema = _ema(closes, fast_period)
    slow_ema = _ema(closes, slow_period)
    atr      = _atr(candles, min(14, len(candles) - 1))
    raw_trend = (fast_ema - slow_ema) / (atr + 1e-9)
    # Soft-clamp via tanh so extreme moves don't saturate
    trend = math.tanh(raw_trend * 0.5)

    # ── VOLATILITY ─────────────────────────────────────────────────────────
    # ATR normalised by recent median close price
    median_close = sorted(closes[-vol_period:])
    median_close = median_close[len(median_close) // 2]
    vol_ratio = atr / (median_close + 1e-9)
    vol = min(1.0, vol_ratio * 50.0)   # v2: raised from 20 → 50; large-cap stocks have small ATR/price

    # ── LIQUIDITY ABOVE ────────────────────────────────────────────────────
    # V2.6: spread-based (anticipatory) if bid/ask present, else volume (reactive).
    has_spread = (candles[-1].get("bid") is not None
                  and candles[-1].get("ask") is not None)
    if has_spread:
        liquidity_above = _spread_liquidity(candles, vol_period)
        liq_source = "spread"
    else:
        vol_window  = volumes[-vol_period:]
        avg_volume  = sum(vol_window) / len(vol_window) if vol_window else 1.0
        current_vol = volumes[-1]
        liq_ratio   = current_vol / (avg_volume + 1e-9)
        liquidity_above = min(1.0, max(0.0, (liq_ratio - 1.0) / 2.0))
        liq_source = "volume"

    # ── STRUCTURE BREAK ────────────────────────────────────────────────────
    # Price closes beyond the highest high / lowest low of prior N candles
    lookback   = min(20, len(candles) - 1)
    prior_high = max(highs[-lookback - 1:-1])
    prior_low  = min(lows[-lookback - 1:-1])
    last_close = closes[-1]

    if last_close > prior_high:
        break_mag = (last_close - prior_high) / (atr + 1e-9)
        break_structure = min(1.0, break_mag * 0.3)
    elif last_close < prior_low:
        break_mag = (prior_low - last_close) / (atr + 1e-9)
        break_structure = min(1.0, break_mag * 0.3)
    else:
        break_structure = 0.0

    return {
        "trend":           round(trend, 6),
        "vol":             round(vol, 6),
        "liquidity_above": round(liquidity_above, 6),
        "break_structure": round(break_structure, 6),
        "source":          liq_source,
    }


def sense_tick(candles: List[Dict], vol_period: int = 20) -> Dict[str, float]:
    """
    Extended sense for full tick-level data (bid/ask + order book imbalance).

    Requires candles to have bid/ask fields. Adds 'spread_pressure' and
    'side_imbalance' on top of standard sense() output.

    Args:
        candles: list of OHLCV dicts with additional tick fields:
            'bid'       float  best bid price  (required)
            'ask'       float  best ask price  (required)
            'bid_size'  float  size at best bid  (optional)
            'ask_size'  float  size at best ask  (optional)

    Returns:
        Standard sense() output plus:
            "spread_pressure"  float [0, 1]   — current spread vs historical norm
                                                0 = normal, 1 = extreme widening
            "side_imbalance"   float [-1, 1]  — order book side pressure
                                                +1 = ask-heavy (sell pressure)
                                                -1 = bid-heavy (buy pressure)
            "source"           always "spread"

    Example:
        candle = {
            "open": 150.0, "high": 150.5, "low": 149.8, "close": 150.2,
            "volume": 1_000_000,
            "bid": 150.18, "ask": 150.22,          # spread = 0.04
            "bid_size": 2500, "ask_size": 800,      # bid-heavy = buy pressure
        }
        signals = sense_tick([...window..., candle])
        # signals["spread_pressure"] = 0.0   (spread is normal)
        # signals["side_imbalance"]  = -0.51 (bid-heavy -> buy pressure)
    """
    base = sense(candles, vol_period)

    last     = candles[-1]
    bid      = last.get("bid") or 0.0
    ask      = last.get("ask") or 0.0

    if not (bid > 0 and ask > 0 and ask >= bid):
        base["spread_pressure"] = 0.0
        base["side_imbalance"]  = 0.0
        return base

    # spread_pressure: same as _spread_liquidity, exposed as named signal
    base["spread_pressure"] = _spread_liquidity(candles, vol_period)
    base["liquidity_above"] = base["spread_pressure"]
    base["source"]          = "spread"

    # side_imbalance: ask_size vs bid_size
    bid_size = last.get("bid_size") or 0.0
    ask_size = last.get("ask_size") or 0.0

    if bid_size > 0 and ask_size > 0:
        total    = bid_size + ask_size
        imbalance = (ask_size - bid_size) / (total + 1e-9)
        base["side_imbalance"] = round(max(-1.0, min(1.0, imbalance)), 6)
    else:
        base["side_imbalance"] = 0.0

    return base
