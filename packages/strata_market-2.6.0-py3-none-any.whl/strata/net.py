"""
STRATA-NET: Neural Network Architecture for Market Trading
===========================================================
A novel recurrent neural network architecture designed specifically
for financial market regime estimation and decision support.

STRATA-NET is NOT a vanilla LSTM/GRU — it is a purpose-built architecture
where the hidden state dimensions correspond to interpretable market concepts:

    h = [bias, momentum, trap_risk, uncertainty]   (4D structured hidden state)

This mirrors the STRATA state machine design, but implemented as a differentiable
neural network trainable end-to-end via gradient descent.

Architecture:
    StrataEmbedding    OHLCV window → semantic feature vector
    StrataCoreCell     Custom GRU-like cell with 4 interpretable gates
    StrataHead         Hidden state → action logits + confidence
    (StrataGuardLayer  Hard-rule masking — not learned, applied post-inference)

Usage:
    import torch
    from strata.net import StrataNet, StrataNetConfig

    # Build model
    cfg   = StrataNetConfig()
    model = StrataNet(cfg)

    # Forward pass (batch_size=1, seq_len=30, features=5)
    x      = torch.randn(1, 30, 5)
    output = model(x)
    # output.action_logits  shape (1, 3)   — LONG / SHORT / HOLD
    # output.confidence     shape (1, 1)
    # output.hidden         shape (1, 4)   — [bias, momentum, trap_risk, uncertainty]
    # output.regime         shape (1, 4)   — regime probabilities

    # Save / load
    model.save("aapl_net.pt")
    model = StrataNet.load("aapl_net.pt")
"""

import math
import json
import copy
from dataclasses import dataclass, asdict
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class StrataNetConfig:
    """
    Hyperparameter configuration for StrataNet.

    All defaults are calibrated for 1-minute OHLCV market data.
    """
    # Input
    n_features:      int   = 5      # OHLCV features per bar
    seq_len:         int   = 30     # input sequence length (bars)

    # Embedding
    embed_dim:       int   = 32     # OHLCV → semantic embedding size
    embed_layers:    int   = 2      # depth of embedding MLP

    # Core recurrent cell
    hidden_dim:      int   = 4      # MUST be 4: [bias, momentum, trap_risk, uncertainty]
    core_expand:     int   = 16     # internal expansion factor in StrataCoreCell

    # Head
    head_dim:        int   = 16     # hidden → logits MLP width
    n_actions:       int   = 3      # LONG=0, SHORT=1, HOLD=2
    n_regimes:       int   = 4      # TRENDING=0, RANGING=1, TRANSITIONING=2, CHOPPY=3

    # Training
    dropout:         float = 0.10
    label_smoothing: float = 0.05

    # Model identity
    version:         str   = "1.0"
    asset:           str   = "GENERIC"


# ---------------------------------------------------------------------------
# Action / regime index maps
# ---------------------------------------------------------------------------

ACTION_IDX  = {"LONG": 0, "SHORT": 1, "HOLD": 2}
IDX_ACTION  = {0: "LONG", 1: "SHORT", 2: "HOLD"}
REGIME_IDX  = {"TRENDING": 0, "RANGING": 1, "TRANSITIONING": 2, "CHOPPY": 3}
IDX_REGIME  = {0: "TRENDING", 1: "RANGING", 2: "TRANSITIONING", 3: "CHOPPY"}


# ---------------------------------------------------------------------------
# Output container
# ---------------------------------------------------------------------------

@dataclass
class StrataNetOutput:
    action_logits: torch.Tensor    # (B, 3)
    confidence:    torch.Tensor    # (B, 1)
    hidden:        torch.Tensor    # (B, 4)  interpretable state
    regime_logits: torch.Tensor    # (B, 4)


# ---------------------------------------------------------------------------
# Sub-modules
# ---------------------------------------------------------------------------

class StrataEmbedding(nn.Module):
    """
    OHLCV sequence → semantic feature sequence.

    Replaces the hand-crafted STRATA-SENSE layer with a learned embedding.
    Input:  (B, T, 5)  — batch, sequence, OHLCV
    Output: (B, T, embed_dim)
    """

    def __init__(self, cfg: StrataNetConfig):
        super().__init__()
        layers = []
        in_dim = cfg.n_features
        for i in range(cfg.embed_layers):
            out_dim = cfg.embed_dim if i == cfg.embed_layers - 1 else cfg.embed_dim * 2
            layers += [nn.Linear(in_dim, out_dim), nn.LayerNorm(out_dim), nn.GELU()]
            in_dim = out_dim
        self.net     = nn.Sequential(*layers)
        self.dropout = nn.Dropout(cfg.dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dropout(self.net(x))


class StrataCoreCell(nn.Module):
    """
    Custom recurrent cell — the heart of STRATA-NET.

    Hidden state h ∈ R^4 represents:
        h[0] = bias          (directional conviction, tanh-bounded)
        h[1] = momentum      (structural energy,      sigmoid-bounded)
        h[2] = trap_risk     (adverse selection,      sigmoid-bounded)
        h[3] = uncertainty   (volatility ambiguity,   sigmoid-bounded)

    Update rule (GRU-inspired but with structured gating):
        z  = sigmoid(W_z · [h, x])          # update gate
        r  = sigmoid(W_r · [h, x])          # reset gate
        h̃  = tanh(W_h · [r*h, x])          # candidate state (expanded then projected)
        h' = (1-z) * h + z * h̃             # new hidden state
        h' is then element-wise bounded to enforce interpretability invariants
    """

    def __init__(self, cfg: StrataNetConfig):
        super().__init__()
        input_dim  = cfg.embed_dim
        hidden_dim = cfg.hidden_dim    # = 4
        expand     = cfg.core_expand  # internal width

        # Gates operate in expanded space for expressiveness
        self.W_z = nn.Linear(input_dim + hidden_dim, expand)
        self.W_r = nn.Linear(input_dim + hidden_dim, expand)
        self.W_h = nn.Linear(input_dim + hidden_dim, expand)

        # Project back to hidden_dim
        self.proj_z = nn.Linear(expand, hidden_dim)
        self.proj_r = nn.Linear(expand, hidden_dim)
        self.proj_h = nn.Linear(expand, hidden_dim)

        self.norm = nn.LayerNorm(hidden_dim)

    def forward(
        self,
        x: torch.Tensor,       # (B, embed_dim)
        h: torch.Tensor,       # (B, hidden_dim=4)
    ) -> torch.Tensor:
        xh = torch.cat([x, h], dim=-1)

        z = torch.sigmoid(self.proj_z(F.gelu(self.W_z(xh))))
        r = torch.sigmoid(self.proj_r(F.gelu(self.W_r(xh))))

        xrh     = torch.cat([x, r * h], dim=-1)
        h_cand  = torch.tanh(self.proj_h(F.gelu(self.W_h(xrh))))

        h_new = (1 - z) * h + z * h_cand
        h_new = self.norm(h_new)

        # Enforce interpretability bounds per dimension
        # bias:        tanh → [-1, 1]
        # momentum:    sigmoid → [0, 1]
        # trap_risk:   sigmoid → [0, 1]
        # uncertainty: sigmoid → [0, 1]
        bias        = torch.tanh(h_new[:, 0:1])
        momentum    = torch.sigmoid(h_new[:, 1:2])
        trap_risk   = torch.sigmoid(h_new[:, 2:3])
        uncertainty = torch.sigmoid(h_new[:, 3:4])

        return torch.cat([bias, momentum, trap_risk, uncertainty], dim=-1)


class StrataHead(nn.Module):
    """
    Hidden state → action logits + confidence + regime logits.

    Input:  h ∈ R^4 (interpretable hidden state)
    Output: action_logits (3), confidence (1), regime_logits (4)
    """

    def __init__(self, cfg: StrataNetConfig):
        super().__init__()
        self.action_mlp = nn.Sequential(
            nn.Linear(cfg.hidden_dim, cfg.head_dim),
            nn.GELU(),
            nn.Dropout(cfg.dropout),
            nn.Linear(cfg.head_dim, cfg.n_actions),
        )
        self.confidence_mlp = nn.Sequential(
            nn.Linear(cfg.hidden_dim, cfg.head_dim),
            nn.GELU(),
            nn.Linear(cfg.head_dim, 1),
            nn.Sigmoid(),
        )
        self.regime_mlp = nn.Sequential(
            nn.Linear(cfg.hidden_dim, cfg.head_dim),
            nn.GELU(),
            nn.Linear(cfg.head_dim, cfg.n_regimes),
        )

    def forward(
        self, h: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        return (
            self.action_mlp(h),
            self.confidence_mlp(h),
            self.regime_mlp(h),
        )


# ---------------------------------------------------------------------------
# Main model
# ---------------------------------------------------------------------------

class StrataNet(nn.Module):
    """
    STRATA-NET: Neural network architecture for market trading.

    A novel recurrent architecture where the hidden state encodes
    interpretable market concepts: bias, momentum, trap_risk, uncertainty.

    Analogous to LSTM/GRU but purpose-built for financial regime estimation.

    Input:  OHLCV sequences  (B, T, 5)
    Output: StrataNetOutput  — action logits, confidence, hidden state, regime

    Example:
        cfg   = StrataNetConfig(asset="AAPL", seq_len=30)
        model = StrataNet(cfg)

        x = torch.randn(1, 30, 5)          # 1 sample, 30 bars, 5 features
        out = model(x)
        print(out.hidden)                  # [bias, momentum, trap_risk, uncertainty]
        print(IDX_ACTION[out.action_logits.argmax(-1).item()])   # LONG/SHORT/HOLD
    """

    def __init__(self, cfg: Optional[StrataNetConfig] = None):
        super().__init__()
        self.cfg       = cfg or StrataNetConfig()
        self.embedding = StrataEmbedding(self.cfg)
        self.cell      = StrataCoreCell(self.cfg)
        self.head      = StrataHead(self.cfg)

    def forward(
        self,
        x:    torch.Tensor,                        # (B, T, 5)
        h0:   Optional[torch.Tensor] = None,       # (B, 4)  initial hidden state
    ) -> StrataNetOutput:
        B, T, _ = x.shape

        # Embed entire sequence at once (parallelisable)
        emb = self.embedding(x)   # (B, T, embed_dim)

        # Initialise hidden state
        h = h0 if h0 is not None else torch.zeros(B, self.cfg.hidden_dim, device=x.device)

        # Recurrent pass over time steps
        for t in range(T):
            h = self.cell(emb[:, t, :], h)

        # Decode final hidden state
        action_logits, confidence, regime_logits = self.head(h)

        return StrataNetOutput(
            action_logits = action_logits,
            confidence    = confidence,
            hidden        = h,
            regime_logits = regime_logits,
        )

    def predict_action(self, x: torch.Tensor) -> dict:
        """
        Convenience inference method — returns human-readable output dict.

        Args:
            x: (1, T, 5) tensor or (T, 5) tensor

        Returns:
            {
                "action":     "LONG" | "SHORT" | "HOLD",
                "confidence": float,
                "regime":     str,
                "state":      {"bias": ..., "momentum": ..., "trap_risk": ..., "uncertainty": ...}
            }
        """
        self.eval()
        with torch.no_grad():
            if x.dim() == 2:
                x = x.unsqueeze(0)
            out    = self(x)
            action = IDX_ACTION[out.action_logits.argmax(-1).item()]
            regime = IDX_REGIME[out.regime_logits.argmax(-1).item()]
            h      = out.hidden.squeeze(0).tolist()
            return {
                "action":     action,
                "confidence": round(out.confidence.item(), 4),
                "regime":     regime,
                "state": {
                    "bias":        round(h[0], 4),
                    "momentum":    round(h[1], 4),
                    "trap_risk":   round(h[2], 4),
                    "uncertainty": round(h[3], 4),
                },
            }

    # ------------------------------------------------------------------
    # Save / Load
    # ------------------------------------------------------------------

    def save(self, path: str) -> None:
        """
        Save model weights and config to a .pt file.

        Args:
            path: file path, e.g. "aapl_net.pt"
        """
        torch.save({
            "config":      asdict(self.cfg),
            "state_dict":  self.state_dict(),
            "strata_arch": "StrataNet",
            "version":     self.cfg.version,
        }, path)
        print(f"[StrataNet] saved → {path}  ({self._param_count()} params)")

    @classmethod
    def load(cls, path: str, map_location: str = "cpu") -> "StrataNet":
        """
        Load a StrataNet model from a .pt file.

        Args:
            path:         path to .pt file
            map_location: torch device string (default "cpu")

        Returns:
            StrataNet instance ready for inference
        """
        checkpoint = torch.load(path, map_location=map_location, weights_only=True)
        cfg        = StrataNetConfig(**checkpoint["config"])
        model      = cls(cfg)
        model.load_state_dict(checkpoint["state_dict"])
        model.eval()
        return model

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def _param_count(self) -> str:
        n = sum(p.numel() for p in self.parameters())
        return f"{n:,}"

    def summary(self) -> str:
        lines = [
            f"StrataNet v{self.cfg.version}",
            f"  asset       : {self.cfg.asset}",
            f"  seq_len     : {self.cfg.seq_len}",
            f"  embed_dim   : {self.cfg.embed_dim}",
            f"  hidden_dim  : {self.cfg.hidden_dim}  [bias, momentum, trap_risk, uncertainty]",
            f"  core_expand : {self.cfg.core_expand}",
            f"  parameters  : {self._param_count()}",
            f"  sub-modules :",
            f"    StrataEmbedding  ({self.cfg.n_features} → {self.cfg.embed_dim})",
            f"    StrataCoreCell   ({self.cfg.embed_dim} + 4 → 4)  [structured hidden state]",
            f"    StrataHead       (4 → 3 actions + 1 conf + 4 regimes)",
        ]
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"StrataNet(asset={self.cfg.asset!r}, params={self._param_count()}, v{self.cfg.version})"
