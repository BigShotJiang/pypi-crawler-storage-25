""" memorph-bin-linux-arm64-gnu """


def main() -> None:
    print("  memorph-bin-linux-arm64-gnu  ")
