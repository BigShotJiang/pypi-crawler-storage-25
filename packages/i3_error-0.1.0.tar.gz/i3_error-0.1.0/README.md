# i3-error
Display errors from an i3wm reload.

ai-generated and unreviewed.

## Motivation
I almost certainly want to run this on other machines. I don't really want to maintain my own repository of tools. It's probably useful for someone else.

## Installation
pipx install i3-error

## Usage
`i3-error`
