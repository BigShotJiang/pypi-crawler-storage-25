#!/usr/bin/env python3
"""i3-error — display errors from an i3wm reload."""
from __future__ import annotations
import os
import sys
import glob
from pathlib import Path


def find_errorlog() -> Path | None:
    runtime = os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid()}"
    candidates = sorted(
        glob.glob(f"{runtime}/i3/errorlog.*"),
        key=os.path.getmtime,
        reverse=True,
    )
    return Path(candidates[0]) if candidates else None


def main() -> int:
    log = find_errorlog()
    if log is None:
        print("i3-error: no i3 errorlog found", file=sys.stderr)
        return 1
    try:
        sys.stdout.write(log.read_text())
    except OSError as e:
        print(f"i3-error: cannot read {log}: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())