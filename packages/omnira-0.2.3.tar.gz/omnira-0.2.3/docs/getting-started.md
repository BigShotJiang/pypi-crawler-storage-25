# Getting Started with the Omnira CLI

The Omnira CLI (`omnira`) gives you full control of your Omnira account from the command line. This guide takes you from zero to sending your first command in under five minutes.

---

## 1. Install

The CLI is a Python 3.10+ package published on PyPI. Install it with either [uv](https://docs.astral.sh/uv/) or [pipx](https://pipx.pypa.io/) — both install the CLI into an isolated environment and put the `omnira` command on your `PATH`.

**With uv (recommended):**

```bash
uv tool install omnira
```

**With pipx:**

```bash
pipx install omnira
```

Verify the install:

```bash
omnira version
```

You should see `omnira-cli 0.2.1` (or later).

---

## 2. Generate your API key

Every CLI command authenticates with a partner API key that is scoped to your Omnira account. You generate and manage keys from the dashboard.

1. Sign in at [omnira.so](https://omnira.so).
2. Open **Settings → API**.
3. Click **Generate API Key**. Copy it immediately — **this is the only time the full key is shown**.
4. Store it somewhere safe (password manager). The dashboard will only show a masked preview after this point.

If you lose a key, you can always revoke it on the same page and generate a new one.

---

## 3. Authenticate the CLI

Run:

```bash
omnira login
```

You will be asked to paste the API key you just generated. The CLI validates it against the Omnira gateway, then writes the credentials to `~/.omnira/config.toml` (permissions `0600` on your local machine only).

On first login the CLI also offers to install the Claude Code integration (for AI agent use). You can safely accept, decline, or skip — you can always run `omnira agent install` later.

Verify you are authenticated:

```bash
omnira account
```

Expected output:

```json
{
  "success": true,
  "data": {
    "partner_id": 123,
    "partner_name": "Your Company",
    "credits": { "leads": 1000, "contacts": 2500 }
  }
}
```

---

## 4. Your first real command

List your leads:

```bash
omnira leads list --limit 10
```

By default the CLI renders tables in a terminal and JSON when piped. To explicitly request JSON:

```bash
omnira leads list --limit 10 --output json
```

Every command supports `--help` to discover its options:

```bash
omnira leads --help
omnira leads list --help
```

---

## 5. Common first tasks

Here are five commands that cover the most common things partners do in their first session. Full detail for each is in the [command reference](command-reference.md) and [workflows](workflows.md) docs.

| Task | Command |
|---|---|
| See unanswered replies | `omnira morning replies` |
| See pending AI message approvals | `omnira hitl list` |
| View outreach pipeline | `omnira outreach pipeline` |
| See all offerings | `omnira offerings list` |
| View pipeline summary | `omnira pipeline summary` |

---

## 6. Output formats

Every command supports three output modes via `--output` (or `-o`):

- `auto` (default) — table when interactive, JSON when piped.
- `json` — always JSON. Use for scripts.
- `table` — always a formatted table.

Example:

```bash
omnira leads list -o json | jq '.data[].email'
```

---

## 7. Upgrading

When a new version is released, upgrade with:

```bash
uv tool upgrade omnira    # if you installed with uv
pipx upgrade omnira       # if you installed with pipx
```

To check whether you are on the latest release:

```bash
omnira version --check
```

---

## 8. Logging out

To revoke the local credentials on this machine (this does not revoke the key server-side):

```bash
omnira logout
```

To revoke the API key entirely, open **Settings → API** in the dashboard and click **Revoke**.

---

## Where to go next

- **[Command reference](command-reference.md)** — every command, grouped by area.
- **[Workflows](workflows.md)** — end-to-end recipes for common tasks (morning review, launching outreach, closing deals).
- **[Troubleshooting](troubleshooting.md)** — errors, credit issues, rate limits, and safety checklists.

Support: `support@omnirasystems.com`
