# Omnira CLI Workflows

End-to-end recipes for the most common tasks partners do with the CLI. Each recipe is a sequence of commands you can run (or adapt) in one sitting.

If you haven't set up the CLI yet, start with the [getting-started guide](getting-started.md).

---

## Table of contents

1. [Morning review — triage overnight activity](#1-morning-review)
2. [Review and approve AI messages (HITL)](#2-review-and-approve-ai-messages)
3. [Respond to unanswered replies](#3-respond-to-unanswered-replies)
4. [Set up a new offering and launch outreach](#4-set-up-a-new-offering-and-launch-outreach)
5. [Send a manual follow-up message](#5-send-a-manual-follow-up-message)
6. [Close a won deal](#6-close-a-won-deal)
7. [Pause outreach for a holiday or freeze](#7-pause-outreach-for-a-holiday-or-freeze)
8. [Bulk import and enrich leads](#8-bulk-import-and-enrich-leads)
9. [Purchase new leads](#9-purchase-new-leads)
10. [Reconfigure a sales process](#10-reconfigure-a-sales-process)

---

## 1. Morning review

The 5-minute daily ritual: see what changed overnight and act on what needs your attention.

```bash
# What happened overnight
omnira morning replies -o json        # leads who replied, awaiting you
omnira hitl list -o json              # AI messages awaiting approval
omnira plans list --status pending    # action plans awaiting approval

# High-level state
omnira outreach pipeline              # current stage distribution
omnira outreach health                # send + reply + booking rates
```

Work through each queue one at a time (see recipes 2 and 3).

---

## 2. Review and approve AI messages

The AI drafts messages for complex conversations. You approve, edit, or reject before they send.

```bash
# 1. List pending approvals — the response includes each proposed message
omnira hitl list -o json

# 2. For each pending item, read the context before deciding
omnira outreach conversations <lead_app_id> -o json

# 3. Act on the message. Choose ONE:

#    - Approve as-is:
omnira hitl approve <approval_token> --by "Sarah"

#    - Edit and approve:
omnira hitl edit <approval_token> "Modified version of the message..."

#    - Reject (message will not send):
omnira hitl reject <approval_token> --reason "Too aggressive for this lead"
```

**Safety rule:** always read the `proposed_response` text in the `hitl list` output before approving. Edit if it says anything you wouldn't say in your own voice.

---

## 3. Respond to unanswered replies

Leads who replied to outreach but haven't been responded to yet.

```bash
# 1. See the queue
omnira morning replies -o json

# 2. For each, fetch full conversation context
omnira outreach conversations <lead_app_id> -o json

# 3a. Respond via the best channel
omnira messages imessage-check "+15551234567"    # check iMessage support first
omnira messages imessage <lead_app_id> "Great to hear from you..."
#    or
omnira messages sms <lead_app_id> "Great to hear from you..."
#    or
omnira messages email <lead_app_id> "Great to hear from you..." \
    --subject "Re: Your question"

# 3b. Or dismiss (no response needed)
omnira morning dismiss <lead_app_id>
```

---

## 4. Set up a new offering and launch outreach

End-to-end flow for a brand new product/service.

```bash
# 1. Create the offering
omnira offerings create "HVAC Maintenance Plans" \
    --description "Seasonal tune-ups for residential customers"
# → note the offering_id in the response

# 2. Generate the sales process + message templates
omnira offerings initialize <offering_id>

# 3. Review templates
omnira content list <offering_id> -o json

# 4. Customize any template that doesn't match your voice
omnira content update <skeleton_id> --body "Hey {{first_name}}, ..."

# 5. Configure the sales process
omnira sales-config get <offering_id> -o json                    # review current config
omnira sales-config preset <sales_process_id> standard            # or aggressive / relationship
omnira sales-config schedule <sales_process_id> \
    --start 9 --end 17 --days "mon,tue,wed,thu,fri"

# 6. Assign leads to the offering
omnira offerings assign-leads <offering_id> --lead-ids "id1,id2,id3"

# 7. Validate before launch
omnira sales-config pre-launch-check <offering_id> -o json
# → must return success: true before proceeding

# 8. Launch
omnira outreach launch --offering-id <offering_id> --lead-ids "id1,id2,id3"
# → note the launch_id in the response

# 9. Monitor
omnira outreach launch-status <launch_id>
```

---

## 5. Send a manual follow-up message

Bypass the AI pipeline for a one-off message.

```bash
# 1. Find the lead
omnira leads list --search "acme" -o json

# 2. Read conversation history first — know what they already heard
omnira outreach conversations <lead_app_id> -o json

# 3. Choose a channel (check iMessage support if sending to mobile)
omnira messages imessage-check "+15551234567"

# 4. Send. Always confirm the text before running.
omnira messages imessage <lead_app_id> "Quick follow-up — ..."
# or
omnira messages sms <lead_app_id> "Quick follow-up — ..."
# or
omnira messages email <lead_app_id> "Following up on our conversation" \
    --subject "Quick follow-up"
```

> Every send costs money (Twilio, Gmail, or iMessage). Treat this command with the same care as hitting Send on a draft email.

---

## 6. Close a won deal

```bash
# 1. Find the lead
omnira leads list --search "John Smith" -o json

# 2. Move to the closed-won pipeline stage
omnira pipeline stages --offering-id <offering_id> -o json    # find the won stage ID
omnira pipeline move <lead_app_id> --stage <won_stage_id>

# 3. Mark as won (stops outreach)
omnira leads mark-won <lead_app_id>
```

For closed-lost: same flow, but `omnira leads mark-lost <lead_app_id>`.

---

## 7. Pause outreach for a holiday or freeze

```bash
# Pause a single offering
omnira offerings pause <offering_id>

# ...or pause a single lead
omnira outreach pause <lead_app_id> --offering-id <offering_id>

# When the freeze is over:
omnira offerings resume <offering_id>
omnira outreach resume <lead_app_id> --offering-id <offering_id>
```

---

## 8. Bulk import and enrich leads

```bash
# Option A — import from CSV
omnira leads import-csv ./leads.csv --offering-id 42

# Option B — enrich by company domain (pulls contacts from the domain)
omnira leads enrich-domain "acme.com"

# Option C — enrich a specific LinkedIn URL
omnira leads enrich-linkedin "https://www.linkedin.com/in/janesmith"

# Option D — extract company context from a website before reaching out
omnira leads crawl-url "https://acme.com/about"
```

Both enrichment and crawl help personalize outreach. Enrichment spends contact credits — crawl does not.

---

## 9. Purchase new leads

```bash
# 1. Check your credit balance first
omnira account -o json

# 2. Fetch
omnira leads fetch --quantity 50 \
    --name "Q2 dental owners" \
    --titles "Owner,CEO,Practice Manager" \
    --industries "Dental practice" \
    --locations "Colorado"

# 3. Track the fetch
omnira leads fetches -o json

# 4. Once complete, assign them to an offering to start outreach
omnira offerings assign-leads <offering_id> --lead-ids "id1,id2,..."
```

Fetching spends 1 lead credit per lead. Start small with a new segment to validate the filter shape.

---

## 10. Reconfigure a sales process

Change the timing, sending hours, or step cadence for an offering already in flight.

```bash
# 1. Pull the full current config
omnira sales-config get <offering_id> -o json

# 2. Apply a preset for a broad adjustment
omnira sales-config preset <sales_process_id> aggressive    # or standard / relationship

# 3. Or fine-tune a specific step
omnira sales-config update-step <step_id> --delay 48 --channel email

# 4. Update the sending window
omnira sales-config schedule <sales_process_id> \
    --start 8 --end 18 --days "mon,tue,wed,thu,fri"

# 5. Turn on cycling (loop the process if no response)
omnira sales-config cycling <sales_process_id> --enabled --max-cycles 3

# 6. Validate
omnira sales-config pre-launch-check <offering_id> -o json
```

---

## Safety rules (applies to every workflow)

1. **Always confirm before sending messages.** Never let a script auto-send SMS, email, or iMessage without you reading the exact text first.
2. **Always confirm before approving HITL items.** Read `proposed_response` in the approval payload.
3. **Check credits before bulk operations.** Run `omnira account` before `leads fetch` or large enrichment runs.
4. **Always run `pre-launch-check` before `outreach launch`.** It catches broken templates, empty lead lists, and insufficient credits.
5. **Respect the ID system.** `lead_app_id` is for messaging/HITL/conversations. `lead_database_id` is for enrichment/pipeline. Mixing them up will fail silently or hit the wrong lead. See the [ID system section](command-reference.md#id-system) in the command reference.

---

## See also

- **[Command reference](command-reference.md)** — every command with full syntax.
- **[Troubleshooting](troubleshooting.md)** — when things go wrong.
