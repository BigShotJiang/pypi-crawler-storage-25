# Omnira CLI Documentation

The Omnira CLI (`omnira`) gives you command-line control of your Omnira Lead Engagement Platform account.

| Doc | Read when |
|---|---|
| **[Getting started](getting-started.md)** | First time setting up the CLI. Covers install, API key, first command. |
| **[Command reference](command-reference.md)** | Looking up what a specific command does or what flags it takes. |
| **[Workflows](workflows.md)** | Need an end-to-end recipe: morning review, launching outreach, closing a deal, bulk enrichment, etc. |
| **[Troubleshooting](troubleshooting.md)** | Something is failing — error codes, recovery steps, safety checklist. |

---

## Quick reference

```bash
# Install
uv tool install omnira        # or: pipx install omnira

# Authenticate (once)
omnira login
# → generate a key at https://omnira.so/settings/api and paste it

# Use it
omnira account                # confirm auth + see credits
omnira leads list             # your leads
omnira morning replies        # leads awaiting your response
omnira hitl list              # AI messages awaiting approval
omnira outreach pipeline      # current outreach state

# Get help for any command
omnira <group> --help
omnira <group> <subcommand> --help
```

---

## Links

- **PyPI:** [pypi.org/project/omnira](https://pypi.org/project/omnira)
- **Dashboard:** [omnira.so](https://omnira.so)
- **API reference:** [api.omnira.so/docs](https://api.omnira.so/docs)
- **Support:** `support@omnirasystems.com`
