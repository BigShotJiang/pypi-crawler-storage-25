# Omnira CLI Troubleshooting

Common errors, how to recover, and safety checklists.

---

## Quick checks

If anything is unexpected, start here:

```bash
omnira version --check              # Are you on the latest release?
omnira account                      # Is the API key still valid?
omnira config show                  # What URL / profile is active?
```

If `omnira account` fails with `UNAUTHORIZED`, regenerate a key at [omnira.so/settings/api](https://omnira.so/settings/api) and run `omnira login`.

---

## Error codes

Every CLI command returns a structured error envelope:

```json
{
  "success": false,
  "error": {
    "code": "NOT_FOUND",
    "message": "Lead not found",
    "suggestion": "..."
  }
}
```

### `UNAUTHORIZED` (HTTP 401)

Your API key is missing, invalid, or revoked.

**Fix:**
1. Go to [omnira.so/settings/api](https://omnira.so/settings/api).
2. If your key shows "revoked", generate a new one.
3. Run `omnira login` and paste the new key.

### `FORBIDDEN` (HTTP 403)

The API key exists but isn't allowed to access that resource. Two common cases:

- **"API key does not own the specified lead/offering/..."** — You're trying to act on a resource that belongs to a different partner account. Double-check the ID.
- **Plan limits** — your account plan doesn't include this feature. Contact support.

### `NOT_FOUND` (HTTP 404)

The resource doesn't exist, or you used the wrong ID type.

**Fix:**
- Re-run the matching list command: `omnira leads list --search ...`, `omnira offerings list`, etc.
- Verify the ID matches the expected type (see [ID system](command-reference.md#id-system) — `lead_app_id` vs `lead_database_id`).

### `VALIDATION_ERROR` (HTTP 422)

A required parameter is missing or malformed.

**Fix:**
- Re-read the command's `--help` to see required flags.
- Check that UUIDs look like UUIDs and integers look like integers.

### `RATE_LIMITED` (HTTP 429)

You've exceeded your API rate limit (default: 600 requests/minute).

**Fix:**
- Wait 60 seconds.
- Batch operations (e.g. import via CSV instead of one-by-one creates).
- If you need a higher limit, contact support.

### `CONNECTION_ERROR`

The CLI couldn't reach `api.omnira.so`.

**Fix:**
- Check your network connection.
- Check [Cloudflare status](https://www.cloudflarestatus.com/).
- Check for firewalls or proxies blocking HTTPS to `api.omnira.so`.

### `HTTP_5xx`

Something broke on our side. Retry once after a few seconds. If it persists, send the exact command + timestamp to `support@omnirasystems.com`.

---

## Specific problems

### "I ran `omnira login` and it asked for an API key I don't have"

Generate one at [omnira.so/settings/api](https://omnira.so/settings/api). Click **Generate API Key**. Copy it immediately — the full key is only shown once.

### "I lost my API key"

Go to [omnira.so/settings/api](https://omnira.so/settings/api), **Revoke** the existing key, and **Generate** a new one. Then run `omnira login` with the new key. The old key stops working immediately.

### "`omnira leads fetch` fails with insufficient credits"

Check your balance:

```bash
omnira account
```

If lead credits are low, purchase more from the dashboard. Each lead costs 1 lead credit.

### "`omnira outreach launch` fails pre-launch-check"

Run it with JSON output to see the specific issue:

```bash
omnira sales-config pre-launch-check <offering_id> -o json
```

Common causes:
- **No templates** — run `omnira content generate <offering_id>` or create them manually.
- **Empty lead list** — run `omnira offerings assign-leads <offering_id> --lead-ids "..."`.
- **Invalid schedule** — fix with `omnira sales-config schedule`.
- **Insufficient credits** — see above.

### "I sent a message to the wrong lead"

The message has already been sent. There's no undo. Reach out directly to the lead if the context warrants it.

To prevent this: always run `omnira outreach conversations <lead_app_id>` first to confirm you have the right lead before any `omnira messages <channel> send` call.

### "My AI autonomy level is too low / too high"

Check the current level:

```bash
omnira morning autonomy
```

Set it:

```bash
omnira morning set-autonomy 0    # approve everything
omnira morning set-autonomy 1    # approve sensitive actions
omnira morning set-autonomy 2    # approve only destructive actions
omnira morning set-autonomy 3    # AI acts autonomously within safety rails
```

Start at 0 if you're new. Raise it as you build trust.

### "I want to use the CLI in a script / CI / container"

Use environment variables instead of the config file:

```bash
export OMNIRA_API_KEY="propello_..."
export OMNIRA_API_URL="https://api.omnira.so"
omnira account -o json
```

Or put credentials in a profile and switch:

```bash
OMNIRA_PROFILE=production omnira leads list -o json
```

### "Output is broken / piping to `jq` fails"

Always pass `-o json` when piping:

```bash
omnira leads list -o json | jq '.data[].email'
```

If you omit `-o json`, the CLI auto-detects whether it's piped — but explicit is safer for scripts.

---

## Credit and rate limit safety

**Credits** are spent by:
- `omnira leads fetch` — 1 lead credit per lead returned.
- `omnira leads enrich`, `omnira leads enrich-linkedin`, `omnira leads enrich-domain` — 1 contact credit per successful enrichment.
- `omnira leads gtm` — 1 GTM credit per run.

Before any bulk operation, check your balance:

```bash
omnira account
```

**Rate limits** default to 600 requests per minute. You will hit this if you run large loops without `sleep`. Pace bulk work:

```bash
for id in "${lead_ids[@]}"; do
    omnira leads get "$id" -o json >> results.jsonl
    sleep 0.1    # stay well under 600/minute
done
```

---

## Safety checklist for every command

Use this mental checklist (or put it on a sticky note) before running anything that sends messages, spends credits, or modifies data:

1. **Does the command send a message?** (`omnira messages ...`, `omnira hitl approve`, `omnira plans approve`)
   - Read the exact text. Would you send it from your own phone?
2. **Does the command spend credits?** (`omnira leads fetch`, `omnira leads enrich*`, `omnira leads gtm`)
   - Run `omnira account` first. Scope the request so you don't over-spend.
3. **Does the command change state you can't easily undo?** (`omnira offerings delete`, `omnira assets delete`, `omnira leads mark-won`, `omnira outreach launch`)
   - Read the ID in the command. Is it the right one?
4. **Am I in the right profile?** (`omnira config show`)
   - If you use separate profiles for staging/production, confirm you're not running prod commands against staging data (or vice versa).

---

## Getting help

- **Docs:** [getting-started](getting-started.md) · [command reference](command-reference.md) · [workflows](workflows.md)
- **API docs:** [api.omnira.so/docs](https://api.omnira.so/docs)
- **Dashboard:** [omnira.so](https://omnira.so)
- **Support:** `support@omnirasystems.com` — include the exact command, full JSON error, and timestamp.

When you email support, please include:

```bash
omnira version --check
omnira config show
# ...and the failing command with its -o json output
```

That's enough for us to identify whether it's a local issue, an API issue, or a data issue.
