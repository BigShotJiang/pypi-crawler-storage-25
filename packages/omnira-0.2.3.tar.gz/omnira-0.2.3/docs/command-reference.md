# Omnira CLI Command Reference

Complete reference for every `omnira` command, grouped by area. Every command supports `--output json` (`-o json`) for machine-parsable output and `--help` for in-terminal help.

> **Tip:** Names like `LEAD_APP_ID` are UUIDs. `OFFERING_ID` and `SALES_PROCESS_ID` are integers. See the [ID system](#id-system) section at the end for how they relate.

---

## Table of contents

- [Root commands](#root-commands)
- [Account](#account)
- [Leads](#leads)
- [Offerings](#offerings)
- [Outreach](#outreach)
- [Pipeline](#pipeline)
- [HITL (AI message approvals)](#hitl)
- [Messages](#messages)
- [Contacts](#contacts)
- [Sales config](#sales-config)
- [Content (message templates)](#content)
- [Action plans](#plans)
- [Morning (daily digest)](#morning)
- [Aria (AI assistant)](#aria)
- [Assets (landing pages)](#assets)
- [Calendar](#calendar)
- [Travel](#travel)
- [Configuration](#configuration)
- [ID system](#id-system)

---

## Root commands

### `omnira login`

Authenticate with your Omnira API key. The CLI will prompt for the key and store it at `~/.omnira/config.toml`.

```bash
omnira login
omnira login --profile staging   # store under a named profile
```

### `omnira logout`

Clear saved credentials on this machine. Does not revoke the key server-side.

### `omnira version [--check]`

Show CLI version. With `--check`, query PyPI to see if a newer version is available.

### `omnira config show`

Print the resolved configuration (API URL, masked key, profile, output format).

---

## Account

### `omnira account`

Show your account summary: partner ID, partner name, and credit balance.

```bash
omnira account -o json
```

```json
{
  "success": true,
  "data": {
    "partner_id": 123,
    "partner_name": "Your Company",
    "credits": { "leads": 1000, "contacts": 2500 }
  }
}
```

### `omnira account balance`

Same as `omnira account` — an explicit alias.

### `omnira account history`

List recent credit transactions (purchases and spends).

### `omnira account wallet`

Show your wallet balance (if wallet features are enabled on your account).

---

## Leads

### `omnira leads list`

List your leads with filters.

```bash
omnira leads list                             # 50 most recent
omnira leads list --search "acme" --limit 20
omnira leads list --has-email --enriched      # only enriched leads with email
omnira leads list --campaign CAMPAIGN_ID
omnira leads list --fetch FETCH_ID            # only leads from a specific fetch
```

Options: `--search/-s`, `--campaign`, `--fetch`, `--has-email`, `--has-mobile`, `--enriched`, `--limit/-l`, `--offset`, `--sort`, `--order`.

### `omnira leads get LEAD_APP_ID`

Get full detail for a single lead, including conversation history and enrichment data.

```bash
omnira leads get 3245894e-dcc9-43fa-a082-81518f9d708c
```

### `omnira leads fetch`

Purchase new leads using your lead credits.

```bash
omnira leads fetch --quantity 50 \
    --name "April dental practice owners" \
    --titles "Owner,CEO,Practice Manager" \
    --industries "Dental practice"
```

Required: `--quantity`, `--name`. Optional: `--titles`, `--industries`, `--locations`, `--min-employees`, `--max-employees`, `--keywords`.

> Spends `quantity × 1` lead credit. Check your balance first (`omnira account`).

### `omnira leads fetches`

List recent fetch requests and their status.

### `omnira leads enrich LEAD_APP_ID`

Re-enrich an existing lead to refresh contact details. Spends 1 contact credit per successful enrichment.

### `omnira leads enrich-linkedin URL`

Enrich a lead from a LinkedIn profile URL. Spends 1 contact credit.

```bash
omnira leads enrich-linkedin "https://www.linkedin.com/in/janesmith"
```

### `omnira leads enrich-domain DOMAIN`

Bulk-enrich by company domain. Returns matched contacts.

```bash
omnira leads enrich-domain "acme.com"
```

### `omnira leads gtm LEAD_APP_ID`

Run go-to-market intelligence on a lead (buying signals, company context, recent events).

### `omnira leads recruit-search`

Structured candidate search for recruiting workflows.

```bash
omnira leads recruit-search --job "Senior Sales Executive" --count 25 --location "Denver, CO"
```

### `omnira leads recruit-natural "PROMPT"`

Natural-language candidate search.

```bash
omnira leads recruit-natural "SaaS founders in Austin who raised Series A in 2024" --count 50
```

### `omnira leads mark-won LEAD_APP_ID`

Mark a lead as closed-won. Stops outreach on that lead.

### `omnira leads mark-lost LEAD_APP_ID`

Mark a lead as closed-lost. Stops outreach on that lead.

### `omnira leads import-csv FILE`

Bulk-import leads from a CSV file.

```bash
omnira leads import-csv ./leads.csv --offering-id 42
```

### `omnira leads crawl-url URL`

Crawl a URL to extract business context (About page, product pages). Does not spend credits.

---

## Offerings

### `omnira offerings list`

List all offerings in your account.

### `omnira offerings get OFFERING_ID`

Show full offering detail, including sales process config and associated templates.

### `omnira offerings create "NAME"`

Create a new offering.

```bash
omnira offerings create "HVAC Maintenance Plans" \
    --description "Seasonal tune-ups for homeowners"
```

### `omnira offerings initialize OFFERING_ID`

Generate the sales process (steps, schedule, cycling) and initial message templates for a new offering.

### `omnira offerings update OFFERING_ID`

Update an offering's name, description, or status.

### `omnira offerings delete OFFERING_ID`

Delete an offering. **Destructive** — removes all associated sales processes and templates.

### `omnira offerings pause OFFERING_ID`

Pause all outreach for this offering (e.g. for holiday freeze).

### `omnira offerings resume OFFERING_ID`

Resume paused outreach.

### `omnira offerings assign-leads OFFERING_ID`

Assign leads to an offering so they enter its sales process.

```bash
omnira offerings assign-leads 42 --lead-ids "id1,id2,id3"
```

### `omnira offerings leads OFFERING_ID`

List leads currently assigned to an offering.

---

## Outreach

### `omnira outreach launch`

Launch outreach for one or more leads on a specific offering.

```bash
omnira outreach launch --offering-id 42 --lead-ids "id1,id2,id3"
```

### `omnira outreach launch-status LAUNCH_ID`

Check progress of a launch.

### `omnira outreach pause LEAD_APP_ID --offering-id N`

Pause outreach for a single lead (message will not send until resumed).

### `omnira outreach resume LEAD_APP_ID --offering-id N`

Resume paused outreach for a lead.

### `omnira outreach force-step LEAD_APP_ID --offering-id N --step N`

Manually advance a lead to a specific step in the sales process.

### `omnira outreach pipeline`

High-level view of leads currently in active outreach (by stage, by step, counts).

### `omnira outreach health`

Campaign health metrics: send rate, reply rate, booking rate, bounce rate.

### `omnira outreach journey LEAD_APP_ID`

Full outreach history for a single lead — every step, every message, with timestamps.

### `omnira outreach conversations LEAD_APP_ID`

Conversation history (inbound + outbound messages) for a single lead across all channels.

### `omnira outreach plans`

List action plans pending your review (see [Plans](#plans) for detail).

---

## Pipeline

### `omnira pipeline stages --offering-id N`

List pipeline stages configured for an offering.

```bash
omnira pipeline stages --offering-id 42 -o json
```

### `omnira pipeline create-stage "NAME"`

Create a new pipeline stage. Required: `--offering-id`.

```bash
omnira pipeline create-stage "Proposal Sent" --offering-id 42 --position 3
```

### `omnira pipeline update-stage STAGE_ID`

Rename a stage or change its position or color.

### `omnira pipeline leads [--stage STAGE_ID]`

List leads currently in the pipeline, optionally filtered by stage.

### `omnira pipeline summary`

Count of leads per stage.

### `omnira pipeline move LEAD_APP_ID --stage STAGE_ID`

Move a lead to a different stage.

---

## HITL

Human-in-the-loop review of AI-drafted messages. Use this to approve, edit, or reject messages before they send.

### `omnira hitl list`

List pending approvals across the last 24 hours. Each item includes the proposed message text and the inbound conversation context.

```bash
omnira hitl list -o json
```

### `omnira hitl approve TOKEN`

Approve a proposed AI message for sending. Get the `TOKEN` from `omnira hitl list`.

```bash
omnira hitl approve abc123xyz --by "Sarah"
```

### `omnira hitl edit TOKEN "NEW MESSAGE"`

Edit and approve a modified version of the AI's proposed message.

### `omnira hitl reject TOKEN`

Reject a proposed message. The lead will not receive it.

```bash
omnira hitl reject abc123xyz --reason "Too aggressive for this lead"
```

### `omnira hitl process CONTACT_ID "MESSAGE"`

Inject an inbound message into the AI pipeline (for testing or manual handling).

---

## Messages

Direct messaging — bypasses the AI pipeline. Every send costs money (Twilio, Gmail, or iMessage). **Always confirm the message text before sending.**

### `omnira messages sms LEAD_APP_ID "BODY"`

Send SMS via Twilio.

```bash
omnira messages sms 3245894e-... "Hi John, just following up on our chat..."
```

### `omnira messages email LEAD_APP_ID "BODY"`

Send email via Gmail integration.

```bash
omnira messages email 3245894e-... "Following up on our conversation..." \
    --subject "Quick follow-up"
```

### `omnira messages imessage LEAD_APP_ID "BODY"`

Send via iMessage (requires the recipient's number supports iMessage — check first with `imessage-check`).

### `omnira messages imessage-check PHONE`

Check if a phone number supports iMessage before attempting to send.

```bash
omnira messages imessage-check "+15551234567"
```

---

## Contacts

### `omnira contacts create "FIRST_NAME"`

Create a new contact. Required: `--email`. Optional: `--last-name`, `--mobile`, `--company-name`, `--job-title`, `--linkedin`.

```bash
omnira contacts create "Jane" --last-name "Smith" \
    --email "jane@acme.com" --company-name "Acme Inc"
```

Returns `lead_app_id` and `lead_database_id` (see [ID system](#id-system)).

### `omnira contacts update LEAD_APP_ID`

Update a contact's fields.

```bash
omnira contacts update 3245894e-... --email "new@acme.com" --job-title "VP Sales"
```

---

## Sales config

Configure the sales process that drives outreach: step timing, sending hours, cycling. Most settings apply per offering (`SALES_PROCESS_ID`).

### `omnira sales-config get OFFERING_ID`

View the complete sales process configuration — all steps, timing, cycling rules, sending schedule.

### `omnira sales-config preset SALES_PROCESS_ID PRESET`

Apply a named preset (`aggressive`, `standard`, `relationship`) to all steps at once.

```bash
omnira sales-config preset 42 standard
```

### `omnira sales-config schedule SALES_PROCESS_ID`

Set the daily sending window.

```bash
omnira sales-config schedule 42 --start 9 --end 17 --days "mon,tue,wed,thu,fri"
```

### `omnira sales-config cycling SALES_PROCESS_ID`

Configure how many times the sales process loops when a lead doesn't respond.

```bash
omnira sales-config cycling 42 --enabled --max-cycles 3
```

### `omnira sales-config update-step STEP_ID`

Modify a single step's timing or channel.

```bash
omnira sales-config update-step 999 --delay 24 --channel sms
```

### `omnira sales-config pre-launch-check OFFERING_ID`

Validate that an offering is ready to launch outreach. Checks: templates exist, schedule is valid, assigned leads have required fields, credits are sufficient.

> **Always run this before `omnira outreach launch`.**

---

## Content

Manage the message templates that drive outreach.

### `omnira content list OFFERING_ID`

List all templates for an offering.

### `omnira content update SKELETON_ID`

Edit a template's body text, subject line, or tone.

```bash
omnira content update 42 --body "New message text..."
```

### `omnira content generate OFFERING_ID`

Generate a new batch of templates based on the offering's positioning.

### `omnira content regenerate SKELETON_ID`

Regenerate a single template.

---

## Plans

Action plans are AI-suggested next actions (e.g. "respond to John with a booking link"). Review and approve them to execute.

### `omnira plans list [--status pending]`

List plans. Filter by `pending`, `approved`, `rejected`, `expired`.

### `omnira plans approve PLAN_ID`

Approve a plan. The action executes immediately.

### `omnira plans edit PLAN_ID`

Edit a plan's proposed text before approving.

### `omnira plans reject PLAN_ID`

Reject a plan without executing.

### `omnira plans regenerate PLAN_ID`

Ask the AI to propose a different plan for the same situation.

---

## Morning

Daily operational commands — what changed overnight, what needs your attention.

### `omnira morning replies`

List leads who replied but haven't been responded to yet.

### `omnira morning dismiss LEAD_APP_ID`

Dismiss a reply from the unanswered queue without sending a response.

### `omnira morning autonomy`

View your current AI autonomy level (how much the AI can act without approval).

### `omnira morning set-autonomy LEVEL`

Set the AI autonomy level (0–3). Level 0 = approve everything, Level 3 = the AI acts autonomously within safety rails.

---

## Aria

Aria is your AI business advisor. Use `omnira aria <your question>` to chat.

### `omnira aria "QUESTION"`

Ask Aria a question. Aria has context on your leads, offerings, and campaigns.

```bash
omnira aria "Which of my top 10 leads haven't responded in two weeks?"
```

### `omnira aria --thread THREAD_ID "FOLLOW_UP"`

Continue a previous Aria conversation.

### `omnira aria threads`

List your Aria chat threads.

---

## Assets

AI-generated landing pages and microsites tied to an offering.

### `omnira assets list`

List all assets in your account.

### `omnira assets get ASSET_ID`

Get detail for a single asset (URL, build status, linked offering).

### `omnira assets deploy --offering-id N`

Create and build a new asset for an offering.

### `omnira assets preview ASSET_ID`

Get a preview URL to review the asset before it goes live.

### `omnira assets status ASSET_ID`

Check build status (`pending`, `building`, `complete`, `failed`).

### `omnira assets delete ASSET_ID`

Delete an asset. **Destructive.**

---

## Calendar

Calendar integration for appointment booking.

### `omnira calendar status`

Show calendar connection status.

### `omnira calendar list`

List available calendars linked to your account.

### `omnira calendar select --calendar-id X`

Set the active calendar (where new bookings land).

### `omnira calendar create`

Create a new calendar for the partner.

### `omnira calendar events`

List upcoming events in the active calendar.

```bash
omnira calendar events --start 2026-05-01 --end 2026-05-31
```

### `omnira calendar sync --appointment-id X`

Manually sync an appointment from Omnira to the calendar.

---

## Travel

Travel-specific commands (resort inventory, flight search). These are only useful if your account has the travel module enabled.

### `omnira travel inventory RESORT_ID`

Fetch resort inventory.

### `omnira travel flights`

Search for flights.

```bash
omnira travel flights --origin DEN --destination MIA --date 2026-06-15
```

### `omnira travel availability`

Check travel availability for an upcoming booking.

---

## Configuration

### Config file

`~/.omnira/config.toml`:

```toml
[default]
api_url = "https://api.omnira.so"
api_key = "propello_..."
```

Multiple profiles:

```toml
[production]
api_url = "https://api.omnira.so"
api_key = "propello_prod_..."

[staging]
api_url = "https://staging-api.omnira.so"
api_key = "propello_staging_..."
```

Switch profiles with `OMNIRA_PROFILE=<name>` or the `--profile` flag on `login`/`logout`.

### Environment variables

Environment variables override the config file. Useful in CI or containers.

- `OMNIRA_API_KEY` — API key.
- `OMNIRA_API_URL` — gateway URL (default: `https://api.omnira.so`).
- `OMNIRA_PROFILE` — active profile name.
- `OMNIRA_OUTPUT` — output format (`auto`, `json`, `table`, `plain`).

---

## ID system

Omnira uses two different IDs for leads. Getting them mixed up causes silent failures or actions on the wrong lead.

| ID | Format | Used by |
|---|---|---|
| **`lead_app_id`** | UUID | messages, HITL, conversations, journey, mark-won/lost, contacts, outreach actions |
| **`lead_database_id`** (a.k.a. `contact_id`) | UUID | enrichment, GTM, pipeline moves, HITL process |
| **`offering_id`** | integer | offerings, content, sales-config, outreach launch |
| **`sales_process_id`** | integer | sales-config preset/schedule/cycling/update-step |
| **`approval_token`** | string | HITL approve/edit/reject |

**How to find the right ID:**

```bash
# Lead IDs
omnira leads list --search "Jane Smith" -o json
# → data[].id is the lead_app_id
# → data[].leadId (or data[].lead_database.id) is the lead_database_id

# Offering ID
omnira offerings list -o json
# → data[].id

# Sales process ID
omnira sales-config get OFFERING_ID -o json
# → data.sales_process.id

# Approval token
omnira hitl list -o json
# → data[].approval_token
```

---

## Response envelope

Every command returns a consistent envelope.

**Success:**

```json
{
  "success": true,
  "data": { /* ... */ },
  "meta": { "count": 10, "total": 150 }
}
```

**Error:**

```json
{
  "success": false,
  "error": {
    "code": "NOT_FOUND",
    "message": "Lead not found",
    "suggestion": "Re-check the ID with `omnira leads list --search ...`"
  }
}
```

See [troubleshooting](troubleshooting.md) for all error codes and what they mean.
