# Publishing the Omnira CLI to PyPI

This document describes the one-time setup and the recurring release workflow for publishing the `omnira` package to PyPI.

---

## One-time setup (do this once, as the admin)

### 1. Claim the `omnira` name on PyPI

As of 2026-04-17 the name is available (verified via `curl https://pypi.org/pypi/omnira/json` → 404).

1. Create or sign in to a PyPI account at <https://pypi.org/account/register/>. Use a role email like `support@omnirasystems.com` so it doesn't belong to one individual.
2. Enable 2FA on that account (PyPI now requires it).
3. Generate a scoped API token at <https://pypi.org/manage/account/token/>:
   - Token name: `omnira-first-publish`
   - Scope: **Entire account** (required because the project doesn't exist yet — you'll scope it tighter after the first publish)

### 2. Do the first publish manually (claims the name)

From your local machine, with the token from step 1 exported:

```bash
cd /Users/harrisonriehle/dev/omnira/omnira-cli

# Build fresh (should already have dist/ from this session, but rebuild to be sure)
rm -rf dist/
uv build

# Publish using the account-scoped token
uv publish --token pypi-<the-full-token-string>
```

When this succeeds, the package is live at <https://pypi.org/project/omnira/> and anyone can run:

```bash
uv tool install omnira
# or
pipx install omnira
```

### 3. Lock it down (tighter token + trusted publishing)

After the first publish, replace the account-wide token with a project-scoped setup so future releases run from GitHub without any secrets:

1. Go to <https://pypi.org/manage/project/omnira/settings/publishing/>
2. Click **Add a new publisher** → **GitHub**
3. Fill in:
   - Owner: `hpriehle`
   - Repository name: `omnira`
   - Workflow name: `publish-cli.yml`
   - Environment name: `pypi`
4. Save.
5. (Optional but recommended) Revoke the account-wide token from step 1, now that you don't need it.

Trusted publishing uses short-lived OIDC tokens from GitHub — no PyPI secret lives in your repo.

### 4. Configure the `pypi` environment in GitHub

1. Go to <https://github.com/hpriehle/omnira/settings/environments>
2. Click **New environment**, name it `pypi`
3. Protection rules (optional but recommended):
   - Required reviewers: yourself (or your GitHub org)
   - Deployment branches: `main` (and any branch matching `cli-v*` tags)

---

## Recurring release workflow

### Cutting a new release

1. Bump the version in `omnira-cli/pyproject.toml`:
   ```toml
   version = "0.1.1"  # was 0.1.0
   ```

2. Commit:
   ```bash
   git add omnira-cli/pyproject.toml
   git commit -m "release(cli): v0.1.1"
   ```

3. Tag and push:
   ```bash
   git tag cli-v0.1.1
   git push origin main cli-v0.1.1
   ```

4. Watch the workflow run at <https://github.com/hpriehle/omnira/actions/workflows/publish-cli.yml>

The workflow:
- Builds the wheel and sdist
- Verifies the tag version matches `pyproject.toml`
- Publishes to PyPI via trusted publishing (no secrets needed)

Within 60 seconds of the workflow completing, `uv tool install omnira==0.1.1` should pull the new version.

### Emergency / out-of-band publish

If you need to publish without cutting a tag (e.g. first-ever publish, or a fix that can't wait for the tag dance):

- **Option A:** Run the workflow manually from the GitHub Actions UI (`Run workflow` button — uses `workflow_dispatch`).
- **Option B:** Publish from your local machine with a scoped PyPI token (same as the first-publish command above).

---

## Verifying a release

From any machine that isn't yours:

```bash
# Install fresh
uv tool install omnira

# Or with pipx
pipx install omnira

# Confirm
omnira version
omnira --help
```

---

## Troubleshooting

### "File already exists" on publish
PyPI doesn't allow re-uploading the same version. Bump the version in `pyproject.toml` and retry. You cannot overwrite existing wheels.

### "Invalid token" on first publish
Make sure you copied the ENTIRE token including the `pypi-` prefix. Tokens expire — regenerate if needed.

### Trusted publishing fails on the workflow
Check that:
1. The `pypi` environment exists in GitHub settings
2. The trusted publisher on PyPI matches the workflow filename exactly (`publish-cli.yml`, not `publish.yml`)
3. The environment name in PyPI matches the one in the workflow (`pypi`)

### Package version on PyPI doesn't match expected
The workflow verifies tag vs. `pyproject.toml` version. If they disagree, the build step fails before publishing. Fix the mismatch and retag:
```bash
git tag -d cli-v0.1.1                    # delete local tag
git push origin :refs/tags/cli-v0.1.1    # delete remote tag
# ... fix version in pyproject.toml, commit ...
git tag cli-v0.1.1
git push origin cli-v0.1.1
```
