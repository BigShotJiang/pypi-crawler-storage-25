"""Omnira CLI — entry point.

Usage:
    omnira                        # first run → login flow
    omnira login                  # authenticate
    omnira account                # view account + credits
    omnira leads list             # list your leads
    omnira outreach campaigns     # list campaigns
"""

from __future__ import annotations

import asyncio
import sys
from typing import Optional

import typer
from rich.console import Console
from rich.text import Text

from omnira_cli import __version__
from omnira_cli.client import OmniraClient, OmniraError
from omnira_cli.config import OmniraConfig, load_config, write_config, clear_config
from omnira_cli.output import print_error, print_success

console = Console()

# ── Banner ─────────────────────────────────────────────────────────────────

LOGO_LINES = [
    "  ██████╗  ███╗   ███╗ ███╗   ██╗ ██╗ ██████╗   █████╗ ",
    "  ██╔═══██╗████╗ ████║ ████╗  ██║ ██║ ██╔══██╗ ██╔══██╗",
    "  ██║   ██║██╔████╔██║ ██╔██╗ ██║ ██║ ██████╔╝ ███████║",
    "  ██║   ██║██║╚██╔╝██║ ██║╚██╗██║ ██║ ██╔══██╗ ██╔══██║",
    "  ╚██████╔╝██║ ╚═╝ ██║ ██║ ╚████║ ██║ ██║  ██║ ██║  ██║",
    "   ╚═════╝ ╚═╝     ╚═╝ ╚═╝  ╚═══╝ ╚═╝ ╚═╝  ╚═╝ ╚═╝  ╚═╝",
]

GRADIENT = [
    (14, 165, 233),   # #0ea5e9
    (46, 134, 237),
    (78, 103, 241),
    (99, 102, 241),   # #6366f1
    (131, 101, 245),
    (168, 85, 247),   # #a855f7
]


def _print_banner(force: bool = False) -> None:
    if not force and not sys.stdout.isatty():
        return
    c = Console()
    for i, line in enumerate(LOGO_LINES):
        r, g, b = GRADIENT[i % len(GRADIENT)]
        text = Text(line)
        text.stylize(f"bold rgb({r},{g},{b})")
        c.print(text)
    c.print()


# ── Login Flow ─────────────────────────────────────────────────────────────

def _offer_agent_install() -> None:
    """Offer to install the Claude Code agent integration.

    Called at the end of a successful login so partners get the MCP + skill
    wiring in one flow. Safe to skip — user can always run `omnira agent install`
    later.
    """
    from omnira_cli.services import agent_setup

    install_agent = typer.confirm(
        "  Install Claude Code integration? (skill + MCP server, global ~/.claude)",
        default=True,
    )
    if not install_agent:
        console.print("  [dim]Skipped. Run `omnira agent install` anytime to set it up.[/dim]\n")
        return

    try:
        result = agent_setup.install(force_global=True)
    except FileNotFoundError as e:
        console.print(f"  [red]✗[/red] Skill template missing: {e}")
        return

    console.print(f"  [green]✓[/green] Installed to [dim]{result.target}[/dim]")
    if result.skill_action != "unchanged":
        console.print(f"      [{_action_color(result.skill_action)}]{result.skill_action}[/{_action_color(result.skill_action)}]  skill file")
    if result.claude_md_action != "unchanged":
        console.print(f"      [{_action_color(result.claude_md_action)}]{result.claude_md_action}[/{_action_color(result.claude_md_action)}]  CLAUDE.md section")
    if result.mcp_action != "unchanged":
        console.print(f"      [{_action_color(result.mcp_action)}]{result.mcp_action}[/{_action_color(result.mcp_action)}]  MCP server config")
    console.print("  [dim]Restart Claude Code in any project to load omnira tools.[/dim]\n")


def _action_color(action: str) -> str:
    return {"created": "green", "updated": "yellow", "unchanged": "dim"}.get(action, "dim")


def _run_login(profile: str = "default") -> None:
    """Interactive login flow — API key auth + optional agent install."""
    console.print("[bold]Welcome to Omnira![/bold] Let's get you set up.\n")
    console.print("  Generate an API key at [cyan]https://omnira.so/settings/api[/cyan] then paste it below.\n")

    api_key = typer.prompt("  API Key", hide_input=True)
    api_key = api_key.strip()

    if not api_key:
        console.print("[red]No key provided.[/red]")
        raise typer.Exit(code=1)

    console.print("  Verifying...", end=" ")

    cfg = OmniraConfig(api_key=api_key)
    client = OmniraClient(cfg)

    async def _verify():
        try:
            result = await client.authenticate()
            partner_name = result.get("partner_name", "Unknown")
            credits = result.get("credits", {})
            lead_credits = credits.get("leads", 0)
            contact_credits = credits.get("contacts", 0)

            console.print(f'[green]✓[/green] Authenticated as [bold]"{partner_name}"[/bold]')
            console.print(f"    Credits: [cyan]{lead_credits}[/cyan] leads, [cyan]{contact_credits}[/cyan] contacts\n")

            write_config(profile, api_url=cfg.api_url, api_key=api_key)
            console.print(f"  Config saved to [dim]~/.omnira/config.toml[/dim]\n")
        except OmniraError as e:
            console.print(f"[red]✗[/red] {e.message}")
            if e.suggestion:
                console.print(f"  [dim]{e.suggestion}[/dim]")
            raise typer.Exit(code=1)
        finally:
            await client.close()

    asyncio.run(_verify())

    _offer_agent_install()

    console.print("  [bold]You're all set![/bold] Try:\n")
    console.print("    [cyan]omnira account[/cyan]        — see your account + credits")
    console.print("    [cyan]omnira leads list[/cyan]     — list your leads")
    console.print("    [cyan]omnira leads fetch[/cyan]    — fetch new leads")
    console.print("    [cyan]omnira outreach campaigns[/cyan] — view campaigns")
    console.print()


# ── Typer App ──────────────────────────────────────────────────────────────

app = typer.Typer(
    name="omnira",
    help="CLI for the Omnira Lead Engagement Platform.",
    no_args_is_help=False,
    add_completion=False,
)


@app.callback(invoke_without_command=True)
def _main_callback(
    ctx: typer.Context,
    as_partner: Optional[int] = typer.Option(
        None, "--as-partner",
        hidden=True,
        help="Admin only — run this command scoped to the given partner_id.",
    ),
    profile: Optional[str] = typer.Option(
        None, "--profile",
        help="Use a named config profile from ~/.omnira/config.toml (alias for OMNIRA_PROFILE env var).",
    ),
) -> None:
    """Entry point — login flow if unconfigured, help if configured."""
    # Stash top-level flags so get_config() can pick them up.
    global _cli_as_partner, _cli_profile
    if as_partner is not None:
        _cli_as_partner = as_partner
    if profile is not None:
        _cli_profile = profile

    if ctx.invoked_subcommand is not None:
        return

    _print_banner(force=True)

    cfg = load_config()
    if not cfg.is_configured:
        _run_login()
    else:
        typer.echo(ctx.get_help())

    raise typer.Exit()


# ── Global State ───────────────────────────────────────────────────────────

_config: Optional[OmniraConfig] = None
_cli_as_partner: Optional[int] = None
_cli_profile: Optional[str] = None


def get_config(*, output: Optional[str] = None, profile: Optional[str] = None) -> OmniraConfig:
    global _config
    if _config is None:
        _config = load_config(
            profile=profile or _cli_profile,
            output=output,
            as_partner=_cli_as_partner,
        )
    elif output:
        _config.output = output
    return _config


def get_client(cfg: Optional[OmniraConfig] = None) -> OmniraClient:
    cfg = cfg or get_config()
    errors = cfg.validate()
    if errors:
        for e in errors:
            print_error("CONFIG_ERROR", e, mode=cfg.output)
        raise typer.Exit(code=1)
    return OmniraClient(cfg)


# ── Command Groups ─────────────────────────────────────────────────────────

from omnira_cli.commands.account import app as account_app
from omnira_cli.commands.leads import app as leads_app
from omnira_cli.commands.assets import app as assets_app
from omnira_cli.commands.outreach import app as outreach_app
from omnira_cli.commands.aria import app as aria_app
from omnira_cli.commands.plans import app as plans_app
from omnira_cli.commands.morning import app as morning_app
from omnira_cli.commands.calendar import app as calendar_app
from omnira_cli.commands.travel import app as travel_app
from omnira_cli.commands.messages import app as messages_app
from omnira_cli.commands.hitl import app as hitl_app
from omnira_cli.commands.offerings import app as offerings_app
from omnira_cli.commands.pipeline import app as pipeline_app
from omnira_cli.commands.contacts import app as contacts_app
from omnira_cli.commands.sales_config import app as sales_config_app
from omnira_cli.commands.content import app as content_app
from omnira_cli.commands.agent import app as agent_app
from omnira_cli.commands.mcp import app as mcp_app
from omnira_cli.commands.admin import app as admin_app

app.add_typer(account_app)
app.add_typer(leads_app)
app.add_typer(assets_app)
app.add_typer(outreach_app)
app.add_typer(aria_app)
app.add_typer(plans_app)
app.add_typer(morning_app)
app.add_typer(calendar_app)
app.add_typer(travel_app)
app.add_typer(messages_app)
app.add_typer(hitl_app)
app.add_typer(offerings_app)
app.add_typer(pipeline_app)
app.add_typer(contacts_app)
app.add_typer(sales_config_app)
app.add_typer(content_app)
app.add_typer(agent_app)
app.add_typer(mcp_app)
# Admin command group is hidden from `omnira --help`. It remains fully
# functional when invoked directly (`omnira admin partners`), but the command
# surface is only advertised to operators who know it exists.
app.add_typer(admin_app, hidden=True)


# ── Root Commands ──────────────────────────────────────────────────────────

@app.command()
def login(
    profile: str = typer.Option("default", "--profile"),
) -> None:
    """Authenticate with your Omnira account."""
    _print_banner(force=True)
    _run_login(profile=profile)


@app.command()
def logout() -> None:
    """Clear saved credentials."""
    clear_config()
    console.print("Logged out. Run [cyan]omnira login[/cyan] to re-authenticate.")


@app.command()
def version(
    check: bool = typer.Option(
        False, "--check", help="Query PyPI for the latest release and warn if outdated.",
    ),
) -> None:
    """Show CLI version (and optionally check for updates)."""
    _print_banner(force=True)
    typer.echo(f"omnira-cli {__version__}")
    if not check:
        return

    try:
        import httpx

        r = httpx.get("https://pypi.org/pypi/omnira/json", timeout=3.0)
        r.raise_for_status()
        latest = r.json()["info"]["version"]
    except Exception:
        console.print("[dim]Could not reach PyPI to check for updates.[/dim]")
        return

    if _is_newer(latest, __version__):
        console.print(
            f"\n[yellow]A newer version is available:[/yellow] {latest} "
            f"(installed: {__version__})"
        )
        console.print("  Run [cyan]uv tool upgrade omnira[/cyan] or [cyan]pipx upgrade omnira[/cyan] to update.")
    else:
        console.print("[green]You're on the latest version.[/green]")


def _is_newer(candidate: str, current: str) -> bool:
    """Return True if candidate version > current (PEP 440 tuple compare)."""
    def _parts(v: str) -> tuple[int, ...]:
        return tuple(int(p) for p in v.split(".") if p.isdigit())
    try:
        return _parts(candidate) > _parts(current)
    except Exception:
        return False


# ── Config Subcommands ─────────────────────────────────────────────────────

config_app = typer.Typer(name="config", help="Manage CLI configuration.")
app.add_typer(config_app)


@config_app.command()
def show(
    profile: Optional[str] = typer.Option(None, "--profile"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Print current resolved configuration."""
    cfg = get_config(profile=profile, output=output)
    masked_key = f"{cfg.api_key[:8]}...{cfg.api_key[-4:]}" if len(cfg.api_key) > 12 else "(not set)"
    data = {
        "profile": cfg.profile,
        "api_url": cfg.api_url,
        "api_key": masked_key,
        "output": cfg.output,
    }
    print_success(data, mode=cfg.output, title="Config")


if __name__ == "__main__":
    app()
