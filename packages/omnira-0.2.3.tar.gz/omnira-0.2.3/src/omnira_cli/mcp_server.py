"""MCP server wrapping the Omnira CLI service layer.

Each function in omnira_cli.services is exposed as an MCP tool with
schema auto-generated from its Python type hints. The server is launched
via `omnira mcp serve` and uses the same ~/.omnira/config.toml as the CLI.

Transports:
- stdio (default): for Claude Code, Cursor, OpenClaw subprocess integrations
- HTTP: for testing, remote agents, or MCP clients that prefer network transport

Tool safety:
- Tools marked ⚠️ DESTRUCTIVE modify data, spend credits, or send real
  messages to real leads. Always confirm with the user before calling.
- Read tools (list_*, get_*, summary, status) are safe to call freely.
- The dual-ID system matters: `lead_app_id` (UUID, per-partner) is used by
  messages / hitl / conversations / mark-won / mark-lost. `lead_database_id`
  (UUID, master) is used by `pipeline_move_lead` and enrichment. See the
  omnira skill for the full mapping.
"""
from __future__ import annotations

from typing import Any, Optional

from fastmcp import FastMCP

from omnira_cli.client import OmniraClient
from omnira_cli.config import load_config

from omnira_cli.services import account as account_svc
from omnira_cli.services import aria as aria_svc
from omnira_cli.services import assets as assets_svc
from omnira_cli.services import calendar as calendar_svc
from omnira_cli.services import contacts as contacts_svc
from omnira_cli.services import content as content_svc
from omnira_cli.services import hitl as hitl_svc
from omnira_cli.services import leads as leads_svc
from omnira_cli.services import messages as messages_svc
from omnira_cli.services import morning as morning_svc
from omnira_cli.services import offerings as offerings_svc
from omnira_cli.services import outreach as outreach_svc
from omnira_cli.services import pipeline as pipeline_svc
from omnira_cli.services import plans as plans_svc
from omnira_cli.services import sales_config as sales_config_svc
from omnira_cli.services import travel as travel_svc

mcp = FastMCP("omnira")

_client: Optional[OmniraClient] = None


async def _c() -> OmniraClient:
    """Return the shared OmniraClient, authenticating on first call."""
    global _client
    if _client is None:
        cfg = load_config()
        if not cfg.is_configured:
            raise RuntimeError(
                "Omnira CLI is not configured. Run `omnira login` first."
            )
        _client = OmniraClient(cfg)
        await _client.authenticate()
    return _client


# ── System ────────────────────────────────────────────────────────────────


@mcp.tool()
async def whoami() -> dict:
    """Return the authenticated partner's identity, credits, and rate limits.

    Safe smoke-test tool. Call this first to confirm the server is
    authenticated against a working partner account.
    """
    return await (await _c()).authenticate()


# ── Account ───────────────────────────────────────────────────────────────


@mcp.tool()
async def account_balance() -> dict:
    """Get account balance, partner name, and credit pool."""
    return await account_svc.get_balance(await _c())


# ── Aria (AI Advisor) ─────────────────────────────────────────────────────


@mcp.tool()
async def aria_send_message(message: str, thread_id: Optional[str] = None) -> dict:
    """Send a message to Aria, the AI business advisor, and poll for response.

    Returns the response text plus thread_id for follow-up messages.
    """
    return await aria_svc.send_message(await _c(), message=message, thread_id=thread_id)


@mcp.tool()
async def aria_list_threads() -> dict:
    """List Aria chat threads for the partner."""
    return await aria_svc.list_threads(await _c())


# ── Assets ────────────────────────────────────────────────────────────────


@mcp.tool()
async def list_assets() -> dict:
    """List all assets (landing pages, sites) for the partner."""
    return await assets_svc.list_assets(await _c())


@mcp.tool()
async def get_asset(asset_id: int) -> dict:
    """Get detailed asset information."""
    return await assets_svc.get_asset(await _c(), asset_id)


@mcp.tool()
async def deploy_asset(
    offering_id: int,
    asset_type: str = "static",
    name: Optional[str] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Create and build a new asset linked to an offering."""
    return await assets_svc.deploy_asset(
        await _c(), offering_id=offering_id, asset_type=asset_type, name=name,
    )


@mcp.tool()
async def preview_asset(asset_id: int) -> dict:
    """Get the preview URL for an asset."""
    return await assets_svc.preview_asset(await _c(), asset_id)


@mcp.tool()
async def asset_status(asset_id: int) -> dict:
    """Check build status of an asset (pending, building, complete, failed)."""
    return await assets_svc.asset_status(await _c(), asset_id)


@mcp.tool()
async def delete_asset(asset_id: int) -> dict:
    """⚠️ DESTRUCTIVE: Delete an asset."""
    return await assets_svc.delete_asset(await _c(), asset_id)


# ── Calendar ──────────────────────────────────────────────────────────────


@mcp.tool()
async def calendar_status() -> dict:
    """Get calendar connection status for the partner."""
    return await calendar_svc.get_status(await _c())


@mcp.tool()
async def calendar_list() -> dict:
    """List available calendars for the partner."""
    return await calendar_svc.list_calendars(await _c())


@mcp.tool()
async def calendar_select(calendar_id: str, calendar_name: Optional[str] = None) -> dict:
    """⚠️ Set the active calendar for the partner."""
    return await calendar_svc.select_calendar(
        await _c(), calendar_id=calendar_id, calendar_name=calendar_name,
    )


@mcp.tool()
async def calendar_create(
    name: str,
    description: Optional[str] = None,
    timezone: Optional[str] = None,
) -> dict:
    """⚠️ Create a new calendar for the partner."""
    return await calendar_svc.create_calendar(
        await _c(), name=name, description=description, timezone=timezone,
    )


@mcp.tool()
async def calendar_events(
    start: Optional[str] = None, end: Optional[str] = None,
) -> dict:
    """List calendar events for the partner in an optional time window."""
    return await calendar_svc.list_events(await _c(), start=start, end=end)


@mcp.tool()
async def calendar_sync_appointment(
    appointment_id: str, action: str = "create",
) -> dict:
    """⚠️ Sync an appointment to the calendar (create/update/delete)."""
    return await calendar_svc.sync_appointment(
        await _c(), appointment_id=appointment_id, action=action,
    )


# ── Contacts ──────────────────────────────────────────────────────────────


@mcp.tool()
async def create_contact(
    first_name: str,
    last_name: Optional[str] = None,
    email: Optional[str] = None,
    mobile_number: Optional[str] = None,
    job_title: Optional[str] = None,
    company_name: Optional[str] = None,
    linkedin: Optional[str] = None,
) -> dict:
    """⚠️ Create a new contact (lead). Returns lead_app_id + lead_db_id."""
    return await contacts_svc.create_contact(
        await _c(),
        first_name=first_name, last_name=last_name, email=email,
        mobile_number=mobile_number, job_title=job_title,
        company_name=company_name, linkedin=linkedin,
    )


@mcp.tool()
async def update_contact(
    lead_app_id: str,
    first_name: Optional[str] = None,
    last_name: Optional[str] = None,
    email: Optional[str] = None,
    mobile_number: Optional[str] = None,
    job_title: Optional[str] = None,
    company_name: Optional[str] = None,
    linkedin: Optional[str] = None,
) -> dict:
    """⚠️ Update an existing contact's fields (identified by lead_app_id)."""
    return await contacts_svc.update_contact(
        await _c(), lead_app_id,
        first_name=first_name, last_name=last_name, email=email,
        mobile_number=mobile_number, job_title=job_title,
        company_name=company_name, linkedin=linkedin,
    )


# ── Content (Message Templates) ───────────────────────────────────────────


@mcp.tool()
async def list_skeletons(offering_id: int) -> dict:
    """List content templates (skeletons) for an offering."""
    return await content_svc.list_skeletons(await _c(), offering_id)


@mcp.tool()
async def update_skeleton(
    skeleton_id: int,
    subject: Optional[str] = None,
    body: Optional[str] = None,
    channel: Optional[str] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Update a content template. Changes affect future sends."""
    return await content_svc.update_skeleton(
        await _c(), skeleton_id, subject=subject, body=body, channel=channel,
    )


@mcp.tool()
async def generate_skeletons(offering_id: int) -> dict:
    """⚠️ DESTRUCTIVE: Generate new content templates for an offering (costs AI credits)."""
    return await content_svc.generate_skeletons(await _c(), offering_id)


@mcp.tool()
async def regenerate_skeleton(skeleton_id: int) -> dict:
    """⚠️ DESTRUCTIVE: Regenerate a single content template (overwrites existing)."""
    return await content_svc.regenerate_skeleton(await _c(), skeleton_id)


# ── HITL (Human-in-the-Loop Approvals) ────────────────────────────────────


@mcp.tool()
async def hitl_list_pending() -> dict:
    """List pending AI-generated messages awaiting approval."""
    return await hitl_svc.list_pending(await _c())


@mcp.tool()
async def hitl_approve(
    approval_token: str, approved_by: Optional[str] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Approve a pending AI message — triggers real send to the lead."""
    return await hitl_svc.approve(
        await _c(), approval_token, approved_by=approved_by,
    )


@mcp.tool()
async def hitl_reject(
    approval_token: str,
    reason: Optional[str] = None,
    rejected_by: Optional[str] = None,
) -> dict:
    """Reject a pending AI message. Safe; no send occurs."""
    return await hitl_svc.reject(
        await _c(), approval_token, reason=reason, rejected_by=rejected_by,
    )


@mcp.tool()
async def hitl_edit_and_approve(
    approval_token: str,
    modified_response: str,
    approved_by: Optional[str] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Approve with modifications — triggers real send with the edited text."""
    return await hitl_svc.edit_and_approve(
        await _c(), approval_token, modified_response, approved_by=approved_by,
    )


@mcp.tool()
async def hitl_process_inbound(
    contact_id: str, message_body: str, message_id: Optional[str] = None,
) -> dict:
    """⚠️ Inject an inbound message into the AI conversation pipeline (triggers AI response generation)."""
    return await hitl_svc.process_inbound(
        await _c(), contact_id, message_body, message_id=message_id,
    )


# ── Leads ─────────────────────────────────────────────────────────────────


@mcp.tool()
async def list_leads(
    search: Optional[str] = None,
    campaign_id: Optional[str] = None,
    fetch_id: Optional[str] = None,
    has_email: Optional[bool] = None,
    has_mobile: Optional[bool] = None,
    enriched: Optional[bool] = None,
    limit: int = 50,
    offset: int = 0,
    sort_by: str = "created_at",
    sort_direction: str = "desc",
) -> dict:
    """List the partner's leads with optional filters.

    Returns `{partner_id, leads: [...]}` where each lead has `id` (lead_app_id),
    `leadId` (lead_database_id), and contact info via nested `lead_database`.
    """
    return await leads_svc.list_leads(
        await _c(), search=search, campaign_id=campaign_id, fetch_id=fetch_id,
        has_email=has_email, has_mobile=has_mobile, enriched=enriched,
        limit=limit, offset=offset,
        sort_by=sort_by, sort_direction=sort_direction,
    )


@mcp.tool()
async def get_lead(lead_id: str) -> dict:
    """Get detailed lead info by lead_app_id (UUID)."""
    return await leads_svc.get_lead(await _c(), lead_id)


@mcp.tool()
async def fetch_leads(
    quantity: int,
    file_name: str,
    job_titles: Optional[list[str]] = None,
    industries: Optional[list[str]] = None,
    locations: Optional[list[str]] = None,
    seniority: Optional[list[str]] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Fetch leads in bulk. Spends 1 credit per lead.

    Always confirm quantity with the user before calling.
    """
    return await leads_svc.fetch_leads(
        await _c(), quantity=quantity, file_name=file_name,
        job_titles=job_titles, industries=industries,
        locations=locations, seniority=seniority,
    )


@mcp.tool()
async def list_fetch_requests(
    status: Optional[str] = None, limit: int = 20, offset: int = 0,
) -> dict:
    """List bulk-fetch requests for the partner."""
    return await leads_svc.list_fetch_requests(
        await _c(), status=status, limit=limit, offset=offset,
    )


@mcp.tool()
async def get_fetch_request(
    fetch_id: str, limit: int = 100, offset: int = 0,
) -> dict:
    """Get a fetch request's progress and its resulting leads."""
    return await leads_svc.get_fetch_request(
        await _c(), fetch_id, limit=limit, offset=offset,
    )


@mcp.tool()
async def re_enrich_leads(lead_ids: list[str], run_gtm: bool = True) -> dict:
    """⚠️ DESTRUCTIVE: Re-run enrichment for a batch of leads (may spend contact credits)."""
    return await leads_svc.re_enrich(await _c(), lead_ids, run_gtm=run_gtm)


@mcp.tool()
async def enrich_linkedin(
    linkedin_url: str,
    offering_id: Optional[int] = None,
    run_gtm: bool = True,
) -> dict:
    """⚠️ Enrich a lead from a LinkedIn profile URL (spends contact credit)."""
    return await leads_svc.enrich_linkedin(
        await _c(), linkedin_url, offering_id=offering_id, run_gtm=run_gtm,
    )


@mcp.tool()
async def gtm_enrich(
    lead_ids: list[str], refresh_mode: str = "add_only",
) -> dict:
    """⚠️ Run GTM intelligence enrichment (company + narrative) on leads."""
    return await leads_svc.gtm_enrich(
        await _c(), lead_ids, refresh_mode=refresh_mode,
    )


@mcp.tool()
async def recruit_search(
    job_description: str,
    metros: Optional[list[dict]] = None,
    keywords: Optional[list[str]] = None,
    fetch_count: int = 50,
    file_name: str = "Recruitment Leads",
) -> dict:
    """⚠️ DESTRUCTIVE: Search for recruit candidates. Spends credits."""
    return await leads_svc.recruit_search(
        await _c(), job_description=job_description, metros=metros,
        keywords=keywords, fetch_count=fetch_count, file_name=file_name,
    )


@mcp.tool()
async def recruit_search_natural(
    prompt: str, fetch_count: int = 50,
) -> dict:
    """⚠️ DESTRUCTIVE: Natural-language recruit search. Spends credits."""
    return await leads_svc.recruit_natural(
        await _c(), prompt=prompt, fetch_count=fetch_count,
    )


@mcp.tool()
async def mark_lead_won(lead_app_id: str) -> dict:
    """⚠️ Mark a lead as won (closes the deal, moves to won stage)."""
    return await leads_svc.mark_won(await _c(), lead_app_id)


@mcp.tool()
async def mark_lead_lost(lead_app_id: str) -> dict:
    """⚠️ Mark a lead as lost."""
    return await leads_svc.mark_lost(await _c(), lead_app_id)


@mcp.tool()
async def import_csv_leads(
    csv_data: list[dict], offering_id: Optional[int] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Import leads from CSV row data (list of dicts)."""
    return await leads_svc.import_csv(
        await _c(), csv_data=csv_data, offering_id=offering_id,
    )


@mcp.tool()
async def enrich_domain(domain: str) -> dict:
    """⚠️ Enrich leads by company domain (spends contact credits)."""
    return await leads_svc.enrich_domain(await _c(), domain)


@mcp.tool()
async def crawl_url(url: str) -> dict:
    """Crawl a URL to extract business context. Safe (no credit spend)."""
    return await leads_svc.crawl_url(await _c(), url)


# ── Messages (Manual Send) ────────────────────────────────────────────────


@mcp.tool()
async def send_sms(
    lead_app_id: str, body: str, from_number: Optional[str] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Send a real SMS to a real lead. Always confirm before calling."""
    return await messages_svc.send_sms(
        await _c(), lead_app_id, body, from_number=from_number,
    )


@mcp.tool()
async def send_email(
    lead_app_id: str, body: str, subject: Optional[str] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Send a real email to a real lead via connected Gmail."""
    return await messages_svc.send_email(
        await _c(), lead_app_id, body, subject=subject,
    )


@mcp.tool()
async def send_imessage(lead_app_id: str, body: str) -> dict:
    """⚠️ DESTRUCTIVE: Send a real iMessage to a real lead."""
    return await messages_svc.send_imessage(await _c(), lead_app_id, body)


@mcp.tool()
async def check_imessage_capability(phone: str) -> dict:
    """Check if a phone number supports iMessage. Safe."""
    return await messages_svc.check_imessage(await _c(), phone)


# ── Morning (Daily Digest) ────────────────────────────────────────────────


@mcp.tool()
async def morning_stats() -> dict:
    """Get morning-plan stats (activity, counts, engagement for the day)."""
    return await morning_svc.get_stats(await _c())


@mcp.tool()
async def morning_replies(limit: int = 20) -> dict:
    """Get unanswered replies from leads."""
    return await morning_svc.list_replies(await _c(), limit=limit)


@mcp.tool()
async def morning_dismiss_reply(lead_app_id: str) -> dict:
    """⚠️ Dismiss a reply from the unanswered queue."""
    return await morning_svc.dismiss_reply(await _c(), lead_app_id)


@mcp.tool()
async def morning_get_autonomy() -> dict:
    """Get the partner's AI autonomy level (0–3)."""
    return await morning_svc.get_autonomy(await _c())


@mcp.tool()
async def morning_set_autonomy(level: int) -> dict:
    """⚠️ Set the partner's nurture AI autonomy level (0–3). Higher = less human review."""
    return await morning_svc.set_autonomy(await _c(), level=level)


# ── Offerings ─────────────────────────────────────────────────────────────


@mcp.tool()
async def list_offerings() -> dict:
    """List all offerings for the partner."""
    return await offerings_svc.list_offerings(await _c())


@mcp.tool()
async def get_offering(offering_id: int) -> dict:
    """Get offering detail including sales process config."""
    return await offerings_svc.get_offering(await _c(), offering_id)


@mcp.tool()
async def create_offering(
    name: str,
    description: Optional[str] = None,
    offering_type: Optional[str] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Create a new offering."""
    return await offerings_svc.create_offering(
        await _c(), name=name, description=description, offering_type=offering_type,
    )


@mcp.tool()
async def update_offering(
    offering_id: int,
    name: Optional[str] = None,
    description: Optional[str] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Update an offering's name or description."""
    return await offerings_svc.update_offering(
        await _c(), offering_id, name=name, description=description,
    )


@mcp.tool()
async def delete_offering(offering_id: int) -> dict:
    """⚠️ DESTRUCTIVE: Delete an offering. Always confirm with the user first."""
    return await offerings_svc.delete_offering(await _c(), offering_id)


@mcp.tool()
async def initialize_offering(offering_id: int) -> dict:
    """⚠️ Initialize an offering — generate sales process + skeletons (spends AI credits)."""
    return await offerings_svc.initialize_offering(await _c(), offering_id)


@mcp.tool()
async def pause_offering(offering_id: int) -> dict:
    """⚠️ Pause all outreach for an offering."""
    return await offerings_svc.pause_offering(await _c(), offering_id)


@mcp.tool()
async def resume_offering(offering_id: int) -> dict:
    """⚠️ Resume outreach for a paused offering."""
    return await offerings_svc.resume_offering(await _c(), offering_id)


@mcp.tool()
async def assign_leads_to_offering(
    offering_id: int, lead_ids: list[str],
) -> dict:
    """⚠️ DESTRUCTIVE: Assign leads to an offering. Moves them into that sales process."""
    return await offerings_svc.assign_leads(await _c(), offering_id, lead_ids)


@mcp.tool()
async def list_offering_leads(
    offering_id: int, limit: int = 50, offset: int = 0,
) -> dict:
    """List leads assigned to a specific offering."""
    return await offerings_svc.list_offering_leads(
        await _c(), offering_id, limit=limit, offset=offset,
    )


# ── Outreach / Sales Engine ───────────────────────────────────────────────


@mcp.tool()
async def list_action_plans(limit: int = 50, offset: int = 0) -> dict:
    """Get pending action plans (AI-generated HITL queue)."""
    return await outreach_svc.list_action_plans(
        await _c(), limit=limit, offset=offset,
    )


@mcp.tool()
async def outreach_pipeline() -> dict:
    """Get the outreach pipeline overview with stage counts."""
    return await outreach_svc.get_pipeline(await _c())


@mcp.tool()
async def outreach_health() -> dict:
    """Get outreach health metrics per offering."""
    return await outreach_svc.get_health(await _c())


@mcp.tool()
async def list_conversations(
    lead_id: str,
    channel: Optional[str] = None,
    direction: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> dict:
    """Get conversation history for a lead across all channels.

    Use lead_app_id (UUID). Optional filters: channel (sms/email/imessage),
    direction (inbound/outbound).
    """
    return await outreach_svc.list_conversations(
        await _c(), lead_id,
        channel=channel, direction=direction,
        limit=limit, offset=offset,
    )


@mcp.tool()
async def launch_outreach(
    offering_id: int,
    lead_ids: list[str],
    stagger_seconds: float = 0.5,
    launch_mode: str = "now",
    window_mode: str = "respect_schedule",
    personalized_outreach: bool = False,
) -> dict:
    """⚠️ DESTRUCTIVE: Launch a sales outreach sequence for leads.

    Starts real outreach (SMS/email/RVM) on the configured schedule. Always
    run `sales_config_pre_launch_check` first and confirm with the user.
    """
    return await outreach_svc.launch_outreach(
        await _c(),
        offering_id=offering_id, lead_ids=lead_ids,
        stagger_seconds=stagger_seconds, launch_mode=launch_mode,
        window_mode=window_mode, personalized_outreach=personalized_outreach,
    )


@mcp.tool()
async def get_launch_status(launch_id: str) -> dict:
    """Check the status of a sales process launch."""
    return await outreach_svc.get_launch_status(await _c(), launch_id)


@mcp.tool()
async def pause_outreach(lead_id: str, offering_id: int) -> dict:
    """⚠️ Pause outreach for a specific lead+offering combo."""
    return await outreach_svc.pause_outreach(
        await _c(), lead_id, offering_id=offering_id,
    )


@mcp.tool()
async def resume_outreach(lead_id: str, offering_id: int) -> dict:
    """⚠️ Resume outreach for a paused lead+offering combo."""
    return await outreach_svc.resume_outreach(
        await _c(), lead_id, offering_id=offering_id,
    )


@mcp.tool()
async def force_outreach_step(
    lead_id: str,
    offering_id: int,
    step_number: int,
    channels: Optional[list[str]] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Force the next outreach step for a lead. Skips the schedule."""
    return await outreach_svc.force_step(
        await _c(), lead_id,
        offering_id=offering_id, step_number=step_number, channels=channels,
    )


@mcp.tool()
async def get_lead_journey(lead_id: str) -> dict:
    """Get the outreach journey (step-by-step history) for a lead."""
    return await outreach_svc.get_journey(await _c(), lead_id)


# ── Pipeline (Kanban Stages) ──────────────────────────────────────────────


@mcp.tool()
async def pipeline_list_stages(offering_id: int) -> dict:
    """List all pipeline stages for an offering."""
    return await pipeline_svc.list_stages(await _c(), offering_id=offering_id)


@mcp.tool()
async def pipeline_create_stage(
    name: str, position: Optional[int] = None, color: Optional[str] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Create a new pipeline stage."""
    return await pipeline_svc.create_stage(
        await _c(), name=name, position=position, color=color,
    )


@mcp.tool()
async def pipeline_update_stage(
    stage_id: str,
    name: Optional[str] = None,
    position: Optional[int] = None,
    color: Optional[str] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Update a pipeline stage."""
    return await pipeline_svc.update_stage(
        await _c(), stage_id, name=name, position=position, color=color,
    )


@mcp.tool()
async def pipeline_list_leads(
    stage_id: Optional[str] = None, limit: int = 50, offset: int = 0,
) -> dict:
    """List leads in the pipeline, optionally filtered by stage."""
    return await pipeline_svc.list_leads(
        await _c(), stage_id=stage_id, limit=limit, offset=offset,
    )


@mcp.tool()
async def pipeline_summary() -> dict:
    """Get pipeline summary with counts per stage."""
    return await pipeline_svc.summary(await _c())


@mcp.tool()
async def pipeline_move_lead(lead_db_id: str, stage_id: str) -> dict:
    """⚠️ Move a lead to a different pipeline stage. Uses lead_database_id, not lead_app_id."""
    return await pipeline_svc.move_lead(await _c(), lead_db_id, stage_id)


# ── Plans (Action Plans) ──────────────────────────────────────────────────


@mcp.tool()
async def list_plans(
    status: Optional[str] = None, limit: int = 50, offset: int = 0,
) -> dict:
    """List action plans for the partner. Status filter: pending/approved/rejected."""
    return await plans_svc.list_plans(
        await _c(), status=status, limit=limit, offset=offset,
    )


@mcp.tool()
async def approve_plan(
    plan_id: int,
    action: str = "approve",
    modified_content: Optional[str] = None,
    modified_subject: Optional[str] = None,
    modified_channels: Optional[list] = None,
    rejection_reason: Optional[str] = None,
) -> dict:
    """⚠️ DESTRUCTIVE (when action='approve'): Approve, edit, or reject an action plan.

    action='approve' triggers the real send; 'reject' is safe.
    """
    return await plans_svc.approve_plan(
        await _c(), plan_id,
        action=action,
        modified_content=modified_content,
        modified_subject=modified_subject,
        modified_channels=modified_channels,
        rejection_reason=rejection_reason,
    )


@mcp.tool()
async def regenerate_plan(plan_id: int) -> dict:
    """⚠️ Regenerate an action plan with fresh AI (spends AI credits)."""
    return await plans_svc.regenerate_plan(await _c(), plan_id)


# ── Sales Process Config ──────────────────────────────────────────────────


@mcp.tool()
async def sales_config_get(offering_id: int) -> dict:
    """Get full sales process config (steps, schedule, cycling) for an offering."""
    return await sales_config_svc.get_sales_process(await _c(), offering_id)


@mcp.tool()
async def sales_config_preset(
    sales_process_id: int, preset: str,
) -> dict:
    """⚠️ DESTRUCTIVE: Set step preset (e.g. aggressive/standard/gentle) for a sales process."""
    return await sales_config_svc.update_preset(
        await _c(), sales_process_id, preset,
    )


@mcp.tool()
async def sales_config_schedule(
    sales_process_id: int,
    timezone: Optional[str] = None,
    start_hour: Optional[int] = None,
    end_hour: Optional[int] = None,
    days: Optional[list[str]] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Update sending schedule for a sales process."""
    return await sales_config_svc.update_schedule(
        await _c(), sales_process_id,
        timezone=timezone, start_hour=start_hour, end_hour=end_hour, days=days,
    )


@mcp.tool()
async def sales_config_cycling(
    sales_process_id: int,
    enabled: Optional[bool] = None,
    max_cycles: Optional[int] = None,
    cooldown_days: Optional[int] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Update cycling config (re-engage after sequence completes)."""
    return await sales_config_svc.update_cycling(
        await _c(), sales_process_id,
        enabled=enabled, max_cycles=max_cycles, cooldown_days=cooldown_days,
    )


@mcp.tool()
async def sales_config_update_step(
    step_id: int,
    delay_hours: Optional[int] = None,
    channels: Optional[list[str]] = None,
    enabled: Optional[bool] = None,
) -> dict:
    """⚠️ DESTRUCTIVE: Update a single outreach step."""
    return await sales_config_svc.update_step(
        await _c(), step_id,
        delay_hours=delay_hours, channels=channels, enabled=enabled,
    )


@mcp.tool()
async def sales_config_pre_launch_check(offering_id: int) -> dict:
    """Run pre-launch validation for an offering's sales process.

    ALWAYS call before `launch_outreach`. Safe, read-only.
    """
    return await sales_config_svc.pre_launch_check(await _c(), offering_id)


# ── Travel (Resort / Flight) ──────────────────────────────────────────────


@mcp.tool()
async def travel_get_inventory(
    resort_id: str, start_date: Optional[str] = None,
) -> dict:
    """Get resort inventory."""
    return await travel_svc.get_inventory(
        await _c(), resort_id, start_date=start_date,
    )


@mcp.tool()
async def travel_search_flights(
    origin: str, destination: str, departure_date: str, passengers: int = 1,
) -> dict:
    """Search available flights."""
    return await travel_svc.search_flights(
        await _c(),
        origin=origin, destination=destination,
        departure_date=departure_date, passengers=passengers,
    )


@mcp.tool()
async def travel_check_availability(
    resort_id: Optional[str] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> dict:
    """Check travel / resort availability."""
    return await travel_svc.check_availability(
        await _c(), resort_id=resort_id, start=start, end=end,
    )
