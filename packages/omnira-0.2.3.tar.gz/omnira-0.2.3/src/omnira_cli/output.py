"""Output formatting for CLI responses.

Supports json, table, and plain modes with auto-detection.
All output follows the envelope contract:
  {"success": true, "data": ..., "meta": {...}}
  {"success": false, "error": {"code": ..., "message": ..., "suggestion": ...}}
"""

from __future__ import annotations

import json
import sys
import time
from typing import Any, Optional, Sequence

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import print_json

console = Console()
err_console = Console(stderr=True)


def _is_tty() -> bool:
    return sys.stdout.isatty()


def resolve_output_mode(mode: str) -> str:
    """Resolve 'auto' to concrete mode based on TTY detection."""
    if mode == "auto":
        return "table" if _is_tty() else "json"
    return mode


def print_success(
    data: Any,
    *,
    mode: str = "auto",
    columns: Optional[list[tuple[str, str]]] = None,
    meta: Optional[dict] = None,
    title: Optional[str] = None,
) -> None:
    """Print a successful response.

    Args:
        data: The response data (dict, list, or scalar).
        mode: Output mode (auto/json/table/plain).
        columns: For table mode — list of (key, header_label) tuples.
        meta: Optional metadata (count, total, elapsed_ms).
        title: Optional title for table/panel display.
    """
    mode = resolve_output_mode(mode)

    if mode == "json":
        envelope: dict[str, Any] = {"success": True, "data": data}
        if meta:
            envelope["meta"] = meta
        sys.stdout.write(json.dumps(envelope, indent=2, default=str) + "\n")
        return

    if mode == "plain":
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    parts = [str(v) for v in item.values()]
                    sys.stdout.write("\t".join(parts) + "\n")
                else:
                    sys.stdout.write(str(item) + "\n")
        elif isinstance(data, dict):
            for k, v in data.items():
                sys.stdout.write(f"{k}\t{v}\n")
        else:
            sys.stdout.write(str(data) + "\n")
        return

    # Table mode
    if isinstance(data, list) and columns:
        table = Table(title=title, show_header=True, header_style="bold cyan")
        for _, header in columns:
            table.add_column(header)
        for item in data:
            row = []
            for key, _ in columns:
                val = _nested_get(item, key)
                row.append(_format_cell(val))
            table.add_row(*row)
        console.print(table)
        if meta:
            _print_meta(meta)
        return

    if isinstance(data, dict):
        if title:
            console.print(f"\n[bold]{title}[/bold]")
        _print_dict(data, indent=1)
        console.print()
        return

    # Fallback
    console.print(data)


def print_error(
    code: str,
    message: str,
    suggestion: str = "",
    *,
    mode: str = "auto",
) -> None:
    """Print an error response."""
    mode = resolve_output_mode(mode)

    if mode == "json":
        envelope: dict[str, Any] = {
            "success": False,
            "error": {"code": code, "message": message},
        }
        if suggestion:
            envelope["error"]["suggestion"] = suggestion
        sys.stdout.write(json.dumps(envelope, indent=2) + "\n")
        return

    # Interactive modes
    err_console.print(f"[red bold]Error:[/red bold] {message}")
    if suggestion:
        err_console.print(f"[dim]  Hint: {suggestion}[/dim]")


def _print_dict(d: dict, indent: int = 1) -> None:
    """Recursively print a dict with indentation for nested values."""
    prefix = "  " * indent
    for k, v in d.items():
        label = k.replace("_", " ").title()
        if isinstance(v, dict):
            console.print(f"{prefix}[cyan]{label}:[/cyan]")
            _print_dict(v, indent + 1)
        elif isinstance(v, list):
            console.print(f"{prefix}[cyan]{label}:[/cyan] {', '.join(str(i) for i in v)}")
        else:
            console.print(f"{prefix}[cyan]{label}:[/cyan] {_format_cell(v)}")


def _nested_get(d: dict, key: str) -> Any:
    """Get a value from a nested dict using dot notation (e.g., 'lead_database.first_name')."""
    parts = key.split(".")
    current = d
    for part in parts:
        if isinstance(current, dict):
            current = current.get(part)
        else:
            return None
    return current


def _format_cell(val: Any) -> str:
    """Format a value for table display."""
    if val is None:
        return "—"
    if isinstance(val, bool):
        return "Yes" if val else "No"
    if isinstance(val, list):
        return f"[{len(val)} items]"
    if isinstance(val, dict):
        return f"{{{len(val)} fields}}"
    return str(val)


def _print_meta(meta: dict) -> None:
    """Print metadata line below a table."""
    parts = []
    if "count" in meta:
        parts.append(f"{meta['count']} shown")
    if "total" in meta:
        parts.append(f"{meta['total']} total")
    if "elapsed_ms" in meta:
        parts.append(f"{meta['elapsed_ms']}ms")
    if parts:
        console.print(f"  [dim]{' · '.join(parts)}[/dim]\n")
