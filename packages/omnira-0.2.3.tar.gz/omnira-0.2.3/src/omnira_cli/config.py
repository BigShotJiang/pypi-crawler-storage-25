"""Configuration loading with layered resolution.

Priority: CLI flags > env vars > config file (~/.omnira/config.toml)
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:
    import tomli
except ImportError:
    import tomllib as tomli  # type: ignore[no-redef]  # Python 3.11+


CONFIG_DIR = Path.home() / ".omnira"
CONFIG_FILE = CONFIG_DIR / "config.toml"

DEFAULT_API_URL = "https://api.omnira.so"


@dataclass
class OmniraConfig:
    """Resolved configuration for the CLI."""

    api_url: str = DEFAULT_API_URL
    api_key: str = ""
    partner_id: Optional[int] = None
    profile: str = "default"
    output: str = "auto"  # auto | json | table | plain
    as_partner: Optional[int] = None  # X-Act-As-Partner-ID for admin keys

    def validate(self) -> list[str]:
        """Return list of validation errors (empty = valid)."""
        errors = []
        if not self.api_key:
            errors.append(
                "No API key configured. Run 'omnira login' to authenticate."
            )
        if not self.api_url:
            errors.append("No API URL configured.")
        return errors

    @property
    def is_configured(self) -> bool:
        """True if an API key is set (from any source)."""
        return bool(self.api_key)


def _load_config_file(profile: str = "default") -> dict:
    """Load config from ~/.omnira/config.toml for the given profile."""
    if not CONFIG_FILE.exists():
        return {}

    with open(CONFIG_FILE, "rb") as f:
        data = tomli.load(f)

    # Profile-based: [default], [staging], etc.
    return data.get(profile, data.get("default", {}))


def load_config(
    *,
    profile: Optional[str] = None,
    api_url: Optional[str] = None,
    api_key: Optional[str] = None,
    partner_id: Optional[int] = None,
    output: Optional[str] = None,
    as_partner: Optional[int] = None,
) -> OmniraConfig:
    """Load configuration with layered resolution.

    Args:
        profile: Config profile name (CLI flag).
        api_url: API base URL (CLI flag).
        api_key: API key (CLI flag).
        partner_id: Default partner ID (CLI flag).
        output: Output format (CLI flag).
        as_partner: Act-as partner ID for admin keys (CLI flag).

    Returns:
        Resolved OmniraConfig with CLI flags > env vars > config file.
    """
    resolved_profile = profile or os.getenv("OMNIRA_PROFILE", "default")

    # Layer 1: config file (lowest priority)
    file_cfg = _load_config_file(resolved_profile)

    # Layer 2: env vars (override file)
    env_api_url = os.getenv("OMNIRA_API_URL")
    env_api_key = os.getenv("OMNIRA_API_KEY")
    env_partner_id = os.getenv("OMNIRA_PARTNER_ID")
    env_output = os.getenv("OMNIRA_OUTPUT")
    env_as_partner = os.getenv("OMNIRA_AS_PARTNER")

    # Layer 3: CLI flags (highest priority, passed as args)
    return OmniraConfig(
        api_url=(
            api_url
            or env_api_url
            or file_cfg.get("api_url", DEFAULT_API_URL)
        ),
        api_key=(
            api_key
            or env_api_key
            or file_cfg.get("api_key", "")
        ),
        partner_id=(
            partner_id
            or (int(env_partner_id) if env_partner_id else None)
            or file_cfg.get("partner_id")
        ),
        profile=resolved_profile,
        output=(
            output
            or env_output
            or file_cfg.get("output", "auto")
        ),
        as_partner=(
            as_partner
            if as_partner is not None
            else (int(env_as_partner) if env_as_partner else None)
        ),
    )


def write_config(
    profile: str,
    *,
    api_url: Optional[str] = None,
    api_key: Optional[str] = None,
    partner_id: Optional[int] = None,
) -> None:
    """Write config values to ~/.omnira/config.toml for a profile."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Load existing
    existing: dict = {}
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "rb") as f:
            existing = tomli.load(f)

    # Update profile section
    section = existing.setdefault(profile, {})
    if api_url is not None:
        section["api_url"] = api_url
    if api_key is not None:
        section["api_key"] = api_key
    if partner_id is not None:
        section["partner_id"] = partner_id

    # Write back as TOML (simple serializer — no external dep needed)
    lines = []
    for prof, values in existing.items():
        lines.append(f"[{prof}]")
        for k, v in values.items():
            if isinstance(v, str):
                lines.append(f'{k} = "{v}"')
            elif isinstance(v, int):
                lines.append(f"{k} = {v}")
            elif isinstance(v, bool):
                lines.append(f"{k} = {'true' if v else 'false'}")
        lines.append("")

    CONFIG_FILE.write_text("\n".join(lines))


def clear_config(profile: str = "default") -> None:
    """Remove config for a profile (logout)."""
    if not CONFIG_FILE.exists():
        return

    existing: dict = {}
    with open(CONFIG_FILE, "rb") as f:
        existing = tomli.load(f)

    if profile in existing:
        del existing[profile]

    if existing:
        lines = []
        for prof, values in existing.items():
            lines.append(f"[{prof}]")
            for k, v in values.items():
                if isinstance(v, str):
                    lines.append(f'{k} = "{v}"')
                elif isinstance(v, int):
                    lines.append(f"{k} = {v}")
                elif isinstance(v, bool):
                    lines.append(f"{k} = {'true' if v else 'false'}")
            lines.append("")
        CONFIG_FILE.write_text("\n".join(lines))
    else:
        CONFIG_FILE.unlink(missing_ok=True)
