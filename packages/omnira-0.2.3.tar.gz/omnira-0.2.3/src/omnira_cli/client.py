"""HTTP client for the Omnira API gateway (api.omnira.so).

Authenticates using partner API keys via X-API-Key header.
All requests are scoped to the partner associated with the key.
"""

from __future__ import annotations

import time
from typing import Any, Optional

import httpx

from omnira_cli.config import OmniraConfig


class OmniraError(Exception):
    """Structured error from the Omnira API."""

    def __init__(self, code: str, message: str, suggestion: str = ""):
        self.code = code
        self.message = message
        self.suggestion = suggestion
        super().__init__(message)

    def to_dict(self) -> dict:
        d: dict[str, Any] = {"code": self.code, "message": self.message}
        if self.suggestion:
            d["suggestion"] = self.suggestion
        return d


class OmniraClient:
    """Async HTTP client for the Omnira API gateway.

    Uses partner API keys for authentication. The key is validated via
    the /api/me endpoint which returns partner identity and rate limits.
    """

    def __init__(self, config: OmniraConfig):
        self.config = config
        self.base_url = config.api_url.rstrip("/")
        self._client: Optional[httpx.AsyncClient] = None
        self._partner_id: Optional[int] = None
        self._partner_name: Optional[str] = None
        self._whoami: Optional[dict] = None

    @property
    def partner_id(self) -> int:
        if self._partner_id is None:
            raise OmniraError(
                "NOT_AUTHENTICATED",
                "Not authenticated. Call authenticate() first.",
                "Run 'omnira login' to set up your API key.",
            )
        return self._partner_id

    @property
    def partner_name(self) -> str:
        return self._partner_name or ""

    async def authenticate(self) -> dict:
        """Validate the API key and resolve partner identity."""
        if self._whoami is not None:
            return self._whoami

        # Step 1: Validate key and get partner_id
        me = await self._request("GET", "/api/me", retries=1)
        self._partner_id = me.get("partner_id")

        if not self._partner_id:
            raise OmniraError(
                "NO_PARTNER",
                "API key is not associated with a partner account.",
                "Generate a new key at https://omnira.so/settings/api.",
            )

        # Step 2: Get credits
        credits = await self._request(
            "GET", f"/api/partner/{self._partner_id}/credits", retries=1
        )

        # Step 3: Get partner name from context
        self._partner_name = ""
        try:
            ctx = await self._request(
                "GET", f"/api/partner/{self._partner_id}/context", retries=1
            )
            self._partner_name = ctx.get("partner_config", {}).get("partner_name", "")
        except Exception:
            pass

        self._whoami = {
            "partner_id": self._partner_id,
            "partner_name": self._partner_name,
            "credits": {
                "leads": credits.get("lead_available_credits", 0),
                "contacts": credits.get("contact_available_credits", 0),
            },
            "rate_limits": {"per_minute": me.get("rate_limit_per_minute", 600)},
        }
        return self._whoami

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            # Use certifi certs if available (macOS system Python has outdated certs)
            import ssl
            ssl_context: Any = True  # default: use system certs
            try:
                import certifi
                ssl_context = ssl.create_default_context(cafile=certifi.where())
            except ImportError:
                pass
            headers = {
                "X-API-Key": self.config.api_key,
                "Content-Type": "application/json",
            }
            # Admin keys can act as any partner via this header.
            # Non-admin keys: the gateway ignores the header, so it's harmless.
            if self.config.as_partner is not None:
                headers["X-Act-As-Partner-ID"] = str(self.config.as_partner)

            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=headers,
                timeout=httpx.Timeout(30.0, connect=10.0),
                verify=ssl_context,
            )
        return self._client

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
        retries: int = 2,
    ) -> dict:
        """Make an HTTP request with retry on 429/5xx."""
        client = await self._get_client()

        for attempt in range(retries + 1):
            try:
                start = time.monotonic()
                response = await client.request(
                    method, path, json=json, params=params
                )
                elapsed_ms = int((time.monotonic() - start) * 1000)

                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", "2"))
                    if attempt < retries:
                        import asyncio
                        await asyncio.sleep(retry_after)
                        continue
                    raise OmniraError(
                        "RATE_LIMITED",
                        "Rate limit exceeded.",
                        f"Retry after {retry_after} seconds.",
                    )

                if response.status_code >= 500 and attempt < retries:
                    import asyncio
                    await asyncio.sleep(1 * (attempt + 1))
                    continue

                if response.status_code >= 400:
                    detail = ""
                    try:
                        body = response.json()
                        if isinstance(body, dict):
                            detail = body.get("detail", "")
                        else:
                            detail = str(body)
                    except Exception:
                        detail = response.text[:200]

                    code_map = {
                        401: "UNAUTHORIZED",
                        403: "FORBIDDEN",
                        404: "NOT_FOUND",
                        422: "VALIDATION_ERROR",
                    }
                    error_code = code_map.get(
                        response.status_code,
                        f"HTTP_{response.status_code}",
                    )
                    suggestion = ""
                    if response.status_code == 401:
                        suggestion = (
                            "Get a new API key at https://omnira.so/settings/api, "
                            "then run 'omnira login' to update your credentials."
                        )
                    elif response.status_code == 403:
                        suggestion = "Your API key doesn't have access to this resource."
                    raise OmniraError(error_code, str(detail), suggestion)

                try:
                    data = response.json()
                except Exception:
                    data = {"raw": response.text}

                return data

            except httpx.ConnectError as e:
                if attempt < retries:
                    import asyncio
                    await asyncio.sleep(1)
                    continue
                raise OmniraError(
                    "CONNECTION_ERROR",
                    f"Cannot connect to {self.base_url}",
                    "Check your internet connection or try again later.",
                ) from e
            except OmniraError:
                raise
            except httpx.HTTPError as e:
                raise OmniraError("HTTP_ERROR", str(e)) from e

        raise OmniraError("UNKNOWN", "Request failed after retries.")

    async def get(self, path: str, *, params: Optional[dict] = None) -> dict:
        return await self._request("GET", path, params=params)

    async def post(
        self, path: str, *, json: Optional[dict] = None, params: Optional[dict] = None
    ) -> dict:
        return await self._request("POST", path, json=json, params=params)

    async def patch(self, path: str, *, json: Optional[dict] = None) -> dict:
        return await self._request("PATCH", path, json=json)

    async def delete(self, path: str) -> dict:
        return await self._request("DELETE", path)
