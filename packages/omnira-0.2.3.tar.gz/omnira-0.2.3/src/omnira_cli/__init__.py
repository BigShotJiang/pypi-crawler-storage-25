"""Omnira CLI — command-line interface for the Omnira Lead Engagement Platform."""

__version__ = "0.2.3"
