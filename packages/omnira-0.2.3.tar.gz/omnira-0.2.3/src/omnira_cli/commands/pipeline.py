"""Pipeline commands — manage sales pipeline stages and lead progression."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import pipeline as pipe_svc

app = typer.Typer(name="pipeline", help="Sales pipeline stages, leads, and progression.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command()
def stages(
    offering_id: int = typer.Option(..., "--offering-id", "-O", help="Offering whose pipeline stages to list."),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List all pipeline stages for an offering."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await pipe_svc.list_stages(client, offering_id=offering_id)
        items = result if isinstance(result, list) else result.get("stages", [])
        if isinstance(items, list):
            print_success(
                items, mode=cfg.output,
                columns=[("id", "ID"), ("name", "Name"), ("position", "Position"), ("color", "Color")],
                meta={"count": len(items)},
                title="Pipeline Stages",
            )
        else:
            print_success(result, mode=cfg.output, title="Pipeline Stages")
    _run(cfg, client, _do)


@app.command("create-stage")
def create_stage(
    name: str = typer.Argument(..., help="Stage name"),
    position: Optional[int] = typer.Option(None, "--position", "-p"),
    color: Optional[str] = typer.Option(None, "--color"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Create a new pipeline stage."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await pipe_svc.create_stage(client, name=name, position=position, color=color)
        print_success(result, mode=cfg.output, title="Stage Created")
    _run(cfg, client, _do)


@app.command("update-stage")
def update_stage(
    stage_id: str = typer.Argument(..., help="Stage ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n"),
    position: Optional[int] = typer.Option(None, "--position", "-p"),
    color: Optional[str] = typer.Option(None, "--color"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Update a pipeline stage."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await pipe_svc.update_stage(client, stage_id, name=name, position=position, color=color)
        print_success(result, mode=cfg.output, title="Stage Updated")
    _run(cfg, client, _do)


@app.command("leads")
def list_leads(
    stage_id: Optional[str] = typer.Option(None, "--stage", "-s", help="Filter by stage ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    offset: int = typer.Option(0, "--offset"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List leads in the pipeline."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await pipe_svc.list_leads(client, stage_id=stage_id, limit=limit, offset=offset)
        items = result if isinstance(result, list) else result.get("leads", [])
        if isinstance(items, list):
            print_success(
                items, mode=cfg.output,
                columns=[
                    ("id", "ID"), ("lead_name", "Lead"), ("stage_name", "Stage"),
                    ("value", "Value"), ("updated_at", "Updated"),
                ],
                meta={"count": len(items)},
                title="Pipeline Leads",
            )
        else:
            print_success(result, mode=cfg.output, title="Pipeline Leads")
    _run(cfg, client, _do)


@app.command()
def summary(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Get pipeline summary with counts per stage."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await pipe_svc.summary(client)
        print_success(result, mode=cfg.output, title="Pipeline Summary")
    _run(cfg, client, _do)


@app.command("move")
def move_lead(
    lead_db_id: str = typer.Argument(..., help="Lead database ID"),
    stage_id: str = typer.Option(..., "--stage", "-s", help="Target stage ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Move a lead to a different pipeline stage."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await pipe_svc.move_lead(client, lead_db_id, stage_id)
        print_success(result, mode=cfg.output, title="Lead Moved")
    _run(cfg, client, _do)
