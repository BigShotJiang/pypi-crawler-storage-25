"""Leads commands — list, get, create, fetch, enrichment, GTM, recruit search."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import leads as leads_svc

app = typer.Typer(name="leads", help="Search, view, manage, and enrich your leads.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command("list")
def list_leads(
    campaign_id: Optional[str] = typer.Option(None, "--campaign"),
    fetch_id: Optional[str] = typer.Option(None, "--fetch"),
    search: Optional[str] = typer.Option(None, "--search", "-s"),
    has_email: Optional[bool] = typer.Option(None, "--has-email"),
    has_mobile: Optional[bool] = typer.Option(None, "--has-mobile"),
    enriched: Optional[bool] = typer.Option(None, "--enriched"),
    limit: int = typer.Option(50, "--limit", "-l"),
    offset: int = typer.Option(0, "--offset"),
    sort_by: str = typer.Option("created_at", "--sort"),
    sort_direction: str = typer.Option("desc", "--order"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List your leads with optional filters."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await leads_svc.list_leads(
            client, campaign_id=campaign_id, fetch_id=fetch_id, search=search,
            has_email=has_email, has_mobile=has_mobile, enriched=enriched,
            limit=limit, offset=offset, sort_by=sort_by, sort_direction=sort_direction,
        )
        leads = result.get("leads", [])
        print_success(
            leads, mode=cfg.output,
            columns=[
                ("id", "ID"),
                ("lead_database.first_name", "First"),
                ("lead_database.last_name", "Last"),
                ("lead_database.company_name", "Company"),
                ("lead_database.job_title", "Title"),
                ("lead_database.email", "Email"),
            ],
            meta={"count": len(leads), "total": result.get("total", 0), "offset": offset},
            title="Leads",
        )
    _run(cfg, client, _do)


@app.command()
def get(
    lead_id: str = typer.Argument(..., help="Lead UUID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Get detailed information for a lead."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await leads_svc.get_lead(client, lead_id)
        print_success(result, mode=cfg.output, title=f"Lead {lead_id[:8]}...")
    _run(cfg, client, _do)


@app.command()
def create(
    first_name: str = typer.Option(..., "--first-name", "-f"),
    last_name: Optional[str] = typer.Option(None, "--last-name"),
    email: Optional[str] = typer.Option(None, "--email", "-e"),
    mobile: Optional[str] = typer.Option(None, "--mobile", "-m"),
    job_title: Optional[str] = typer.Option(None, "--title"),
    company: Optional[str] = typer.Option(None, "--company", "-c"),
    industry: Optional[str] = typer.Option(None, "--industry"),
    city: Optional[str] = typer.Option(None, "--city"),
    state: Optional[str] = typer.Option(None, "--state"),
    linkedin: Optional[str] = typer.Option(None, "--linkedin"),
    campaign_id: Optional[int] = typer.Option(None, "--campaign-id"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Create a single lead. Requires email or mobile."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await leads_svc.create_lead(
            client, first_name=first_name, last_name=last_name,
            email=email, mobile_number=mobile, job_title=job_title,
            company_name=company, industry=industry, city=city,
            state=state, linkedin=linkedin, campaign_id=campaign_id,
        )
        print_success(result, mode=cfg.output, title="Lead Created")
    _run(cfg, client, _do)


@app.command()
def fetch(
    quantity: int = typer.Option(..., "--quantity", "-n", help="Number of leads to fetch (uses credits)"),
    name: str = typer.Option(..., "--name", help="Name for this batch"),
    titles: Optional[str] = typer.Option(None, "--titles", help="Comma-separated job titles"),
    industries: Optional[str] = typer.Option(None, "--industries", help="Comma-separated industries"),
    locations: Optional[str] = typer.Option(None, "--locations", help="Comma-separated locations"),
    seniority: Optional[str] = typer.Option(None, "--seniority", help="Comma-separated seniority levels"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Fetch leads in bulk from the database (uses credits)."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await leads_svc.fetch_leads(
            client, quantity=quantity, file_name=name,
            job_titles=titles.split(",") if titles else None,
            industries=industries.split(",") if industries else None,
            locations=locations.split(",") if locations else None,
            seniority=seniority.split(",") if seniority else None,
        )
        print_success(result, mode=cfg.output, title="Fetch Started")
    _run(cfg, client, _do)


@app.command("fetches")
def list_fetches(
    status: Optional[str] = typer.Option(None, "--status"),
    limit: int = typer.Option(20, "--limit", "-l"),
    offset: int = typer.Option(0, "--offset"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List your fetch requests (bulk lead imports)."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await leads_svc.list_fetch_requests(client, status=status, limit=limit, offset=offset)
        items = result.get("lead_lists", [])
        print_success(
            items, mode=cfg.output,
            columns=[
                ("id", "ID"), ("name", "Name"), ("status", "Status"),
                ("leads_delivered", "Delivered"), ("created_at", "Created"),
            ],
            meta={"count": len(items)},
            title="Fetch Requests",
        )
    _run(cfg, client, _do)


# ── Enrichment ────────────────────────────────────────────────────────────


@app.command()
def enrich(
    lead_ids: str = typer.Argument(..., help="Comma-separated lead database IDs"),
    gtm: bool = typer.Option(True, "--gtm/--no-gtm", help="Run GTM intelligence enrichment"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Re-enrich leads with updated contact data."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        ids = [lid.strip() for lid in lead_ids.split(",")]
        result = await leads_svc.re_enrich(client, ids, run_gtm=gtm)
        print_success(result, mode=cfg.output, title="Enrichment Started")
    _run(cfg, client, _do)


@app.command("enrich-linkedin")
def enrich_linkedin(
    url: str = typer.Argument(..., help="LinkedIn profile URL"),
    offering_id: Optional[int] = typer.Option(None, "--offering-id", help="Assign to offering"),
    gtm: bool = typer.Option(True, "--gtm/--no-gtm", help="Run GTM intelligence enrichment"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Enrich a lead from a LinkedIn URL."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await leads_svc.enrich_linkedin(
            client, url, offering_id=offering_id, run_gtm=gtm,
        )
        print_success(result, mode=cfg.output, title="LinkedIn Enrichment")
    _run(cfg, client, _do)


@app.command()
def gtm(
    lead_ids: str = typer.Argument(..., help="Comma-separated lead database IDs"),
    refresh_mode: str = typer.Option("add_only", "--refresh-mode", "-r", help="add_only or refresh_all"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Run GTM intelligence enrichment on leads."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        ids = [lid.strip() for lid in lead_ids.split(",")]
        result = await leads_svc.gtm_enrich(client, ids, refresh_mode=refresh_mode)
        print_success(result, mode=cfg.output, title="GTM Enrichment Started")
    _run(cfg, client, _do)


@app.command("recruit-search")
def recruit_search(
    job: str = typer.Option(..., "--job", "-j", help="Job description to search for"),
    metros: Optional[str] = typer.Option(None, "--metros", "-m", help="Comma-separated city:state pairs"),
    keywords: Optional[str] = typer.Option(None, "--keywords", "-k", help="Comma-separated keywords"),
    count: int = typer.Option(50, "--count", "-n", help="Number of candidates to find"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Search for recruit candidates by job description."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        parsed_metros = None
        if metros:
            parsed_metros = []
            for m in metros.split(","):
                parts = m.strip().split(":")
                if len(parts) == 2:
                    parsed_metros.append({"city": parts[0].strip(), "state": parts[1].strip()})
        parsed_keywords = [k.strip() for k in keywords.split(",")] if keywords else None
        result = await leads_svc.recruit_search(
            client,
            job_description=job,
            metros=parsed_metros,
            keywords=parsed_keywords,
            fetch_count=count,
        )
        print_success(result, mode=cfg.output, title="Recruit Search Started")
    _run(cfg, client, _do)


@app.command("mark-won")
def mark_won(
    lead_app_id: str = typer.Argument(..., help="Lead app database ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Mark a lead as won (closed deal)."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await leads_svc.mark_won(client, lead_app_id)
        print_success(result, mode=cfg.output, title="Lead Marked Won")
    _run(cfg, client, _do)


@app.command("mark-lost")
def mark_lost(
    lead_app_id: str = typer.Argument(..., help="Lead app database ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Mark a lead as lost."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await leads_svc.mark_lost(client, lead_app_id)
        print_success(result, mode=cfg.output, title="Lead Marked Lost")
    _run(cfg, client, _do)


@app.command("import-csv")
def import_csv(
    file: str = typer.Argument(..., help="Path to CSV file"),
    offering_id: Optional[int] = typer.Option(None, "--offering-id", help="Assign imported leads to offering"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Import leads from a CSV file."""
    import csv as csv_mod
    import os
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    if not os.path.isfile(file):
        print_error("FILE_NOT_FOUND", f"File not found: {file}", mode=cfg.output)
        raise typer.Exit(code=1)

    async def _do():
        with open(file, newline="", encoding="utf-8") as f:
            reader = csv_mod.DictReader(f)
            rows = list(reader)
        if not rows:
            print_error("EMPTY_FILE", "CSV file has no rows.", mode=cfg.output)
            raise typer.Exit(code=1)
        result = await leads_svc.import_csv(client, csv_data=rows, offering_id=offering_id)
        print_success(result, mode=cfg.output, title=f"Imported {len(rows)} leads")
    _run(cfg, client, _do)


@app.command("enrich-domain")
def enrich_domain(
    domain: str = typer.Argument(..., help="Company domain (e.g. acme.com)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Enrich leads by company domain."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await leads_svc.enrich_domain(client, domain)
        print_success(result, mode=cfg.output, title="Domain Enrichment")
    _run(cfg, client, _do)


@app.command("crawl-url")
def crawl_url(
    url: str = typer.Argument(..., help="URL to crawl for business context"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Crawl a URL to extract business context."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await leads_svc.crawl_url(client, url)
        print_success(result, mode=cfg.output, title="URL Crawled")
    _run(cfg, client, _do)


@app.command("recruit-natural")
def recruit_natural(
    prompt: str = typer.Argument(..., help="Natural language search description"),
    count: int = typer.Option(50, "--count", "-n", help="Number of candidates to find"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Search for recruits using natural language."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await leads_svc.recruit_natural(client, prompt=prompt, fetch_count=count)
        print_success(result, mode=cfg.output, title="Recruit Search Started")
    _run(cfg, client, _do)
