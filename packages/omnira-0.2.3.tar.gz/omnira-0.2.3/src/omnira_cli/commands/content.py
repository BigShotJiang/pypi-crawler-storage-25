"""Content commands — manage outreach message templates (skeletons)."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import content as content_svc

app = typer.Typer(name="content", help="Manage outreach message templates.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command("list")
def list_skeletons(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List message templates for an offering."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await content_svc.list_skeletons(client, offering_id)
        items = result if isinstance(result, list) else result.get("skeletons", [])
        if isinstance(items, list):
            print_success(
                items, mode=cfg.output,
                columns=[
                    ("id", "ID"), ("channel", "Channel"), ("step_number", "Step"),
                    ("subject", "Subject"), ("body", "Body"),
                ],
                meta={"count": len(items)},
                title=f"Templates — Offering {offering_id}",
            )
        else:
            print_success(result, mode=cfg.output, title=f"Templates — Offering {offering_id}")
    _run(cfg, client, _do)


@app.command()
def update(
    skeleton_id: int = typer.Argument(..., help="Template ID"),
    subject: Optional[str] = typer.Option(None, "--subject", "-s"),
    body: Optional[str] = typer.Option(None, "--body", "-b"),
    channel: Optional[str] = typer.Option(None, "--channel", "-c"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Update a message template."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await content_svc.update_skeleton(
            client, skeleton_id, subject=subject, body=body, channel=channel,
        )
        print_success(result, mode=cfg.output, title="Template Updated")
    _run(cfg, client, _do)


@app.command()
def generate(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Generate new message templates for an offering."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await content_svc.generate_skeletons(client, offering_id)
        print_success(result, mode=cfg.output, title="Templates Generated")
    _run(cfg, client, _do)


@app.command()
def regenerate(
    skeleton_id: int = typer.Argument(..., help="Template ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Regenerate a single message template."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await content_svc.regenerate_skeleton(client, skeleton_id)
        print_success(result, mode=cfg.output, title="Template Regenerated")
    _run(cfg, client, _do)
