"""Calendar commands — connection, calendars, events, sync."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import calendar as calendar_svc

app = typer.Typer(name="calendar", help="Calendar connection, calendars, events, and sync.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command()
def status(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Show calendar connection status."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await calendar_svc.get_status(client)
        result_data = result.get("connection", result)
        print_success(result_data, mode=cfg.output, title="Calendar Connection")
    _run(cfg, client, _do)


@app.command("list")
def list_calendars(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List available calendars."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await calendar_svc.list_calendars(client)
        items = result.get("calendars", [])
        selected_id = result.get("selectedCalendarId")
        for item in items:
            item["selected"] = "✓" if str(item.get("id")) == str(selected_id) else ""
        print_success(
            items, mode=cfg.output,
            columns=[
                ("id", "ID"), ("name", "Name"), ("primary", "Primary"), ("selected", "Selected"),
            ],
            title="Calendars",
        )
    _run(cfg, client, _do)


@app.command()
def select(
    calendar_id: str = typer.Argument(..., help="Calendar ID to select"),
    name: str = typer.Option(..., "--name", "-n", help="Calendar display name"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Select the active calendar."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await calendar_svc.select_calendar(client, calendar_id=calendar_id, calendar_name=name)
        print_success(result, mode=cfg.output, title="Calendar Selected")
    _run(cfg, client, _do)


@app.command()
def create(
    name: str = typer.Argument(..., help="Calendar name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Calendar description"),
    tz: Optional[str] = typer.Option(None, "--timezone", help="Timezone (e.g. America/New_York)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Create a new calendar."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await calendar_svc.create_calendar(client, name=name, description=description, timezone=tz)
        print_success(result, mode=cfg.output, title="Calendar Created")
    _run(cfg, client, _do)


@app.command()
def events(
    start: Optional[str] = typer.Option(None, "--start", help="Start date (ISO format, e.g. 2026-04-01)"),
    end: Optional[str] = typer.Option(None, "--end", help="End date (ISO format, e.g. 2026-04-30)"),
    days: int = typer.Option(7, "--days", help="Number of days ahead (used when --start/--end not set)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List upcoming calendar events."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        from datetime import date, timedelta
        resolved_start = start
        resolved_end = end
        if resolved_start is None and resolved_end is None:
            resolved_start = date.today().isoformat()
            resolved_end = (date.today() + timedelta(days=days)).isoformat()
        elif resolved_start and not resolved_end:
            resolved_end = (date.today() + timedelta(days=days)).isoformat()
        elif resolved_end and not resolved_start:
            resolved_start = date.today().isoformat()
        result = await calendar_svc.list_events(client, start=resolved_start, end=resolved_end)
        items = result.get("events", [])
        print_success(
            items, mode=cfg.output,
            columns=[
                ("title", "Event"), ("start_time", "Start"), ("end_time", "End"), ("location", "Location"),
            ],
            title="Calendar Events",
        )
    _run(cfg, client, _do)


@app.command()
def sync(
    appointment_id: str = typer.Argument(..., help="Appointment ID to sync"),
    action: str = typer.Option("create", "--action", "-a", help="Sync action: create, update, delete"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Sync an appointment to the calendar."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await calendar_svc.sync_appointment(client, appointment_id=appointment_id, action=action)
        print_success(result, mode=cfg.output, title="Appointment Sync")
    _run(cfg, client, _do)
