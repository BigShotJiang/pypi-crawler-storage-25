"""Aria commands — chat with your AI business advisor."""

from __future__ import annotations

import asyncio
import sys
from typing import Optional

import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.live import Live
from rich.spinner import Spinner

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success

console = Console()

app = typer.Typer(
    name="aria",
    help="Chat with Aria, your AI business advisor.",
    invoke_without_command=True,
    no_args_is_help=False,
)


def _run_async(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.callback(invoke_without_command=True)
def _default(
    ctx: typer.Context,
    message: Optional[str] = typer.Argument(None, help="Message to send to Aria"),
    thread: Optional[str] = typer.Option(None, "--thread", "-t", help="Continue a previous conversation"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Chat with Aria. Pass a message or enter interactive mode."""
    if ctx.invoked_subcommand is not None:
        return

    from omnira_cli.main import get_config, get_client
    from omnira_cli.services import aria as aria_svc

    cfg = get_config(output=output)
    client = get_client(cfg)

    if message:
        # Single message mode
        async def _do():
            console.print("[dim]Thinking...[/dim]")
            result = await aria_svc.send_message(client, message=message, thread_id=thread)
            response = result.get("response", "")
            tid = result.get("thread_id", "")

            if cfg.output == "json" or (cfg.output == "auto" and not sys.stdout.isatty()):
                print_success(result, mode="json")
            else:
                console.print()
                console.print(Markdown(response))
                console.print()
                if tid:
                    console.print(f"[dim]thread: {tid}[/dim]")

        _run_async(cfg, client, _do)
    else:
        # Interactive mode
        async def _do():
            tid = thread
            console.print("[bold]Aria[/bold] — your AI business advisor")
            console.print("[dim]Type your message. 'exit' or Ctrl+C to quit.[/dim]\n")

            while True:
                try:
                    user_input = console.input("[bold cyan]> [/bold cyan]")
                except (KeyboardInterrupt, EOFError):
                    console.print("\n[dim]Goodbye.[/dim]")
                    break

                user_input = user_input.strip()
                if not user_input:
                    continue
                if user_input.lower() in ("exit", "quit", "q"):
                    console.print("[dim]Goodbye.[/dim]")
                    break

                console.print("[dim]Thinking...[/dim]")
                result = await aria_svc.send_message(client, message=user_input, thread_id=tid)
                response = result.get("response", "")
                tid = result.get("thread_id", tid)

                console.print()
                console.print(Markdown(response))
                console.print()

        _run_async(cfg, client, _do)

    raise typer.Exit()


@app.command()
def threads(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List your Aria chat threads."""
    from omnira_cli.main import get_config, get_client
    from omnira_cli.services import aria as aria_svc

    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await aria_svc.list_threads(client)
        items = result if isinstance(result, list) else result.get("threads", [])
        if isinstance(items, list):
            print_success(
                items, mode=cfg.output,
                columns=[
                    ("id", "Thread ID"), ("title", "Title"), ("created_at", "Created"),
                ],
                meta={"count": len(items)},
                title="Aria Threads",
            )
        else:
            print_success(items, mode=cfg.output, title="Aria Threads")

    _run_async(cfg, client, _do)
