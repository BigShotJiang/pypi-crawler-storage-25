"""Morning commands — daily stats, replies, dismiss, autonomy."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import morning as morning_svc

app = typer.Typer(name="morning", help="Morning stats, unanswered replies, and autonomy settings.")


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.callback(invoke_without_command=True)
def _default(ctx: typer.Context, output: Optional[str] = typer.Option(None, "--output", "-o")) -> None:
    """Show morning stats (default when no subcommand given)."""
    if ctx.invoked_subcommand is not None:
        return
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await morning_svc.get_stats(client)
        print_success(result, mode=cfg.output, title="Morning Stats")
    _run(cfg, client, _do)


@app.command()
def replies(
    limit: int = typer.Option(20, "--limit", "-l"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List unanswered replies."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await morning_svc.list_replies(client, limit=limit)
        items = result.get("replies", [])
        for item in items:
            body = item.get("body", "")
            item["body"] = (body[:60] + "...") if len(body) > 60 else body
        print_success(
            items, mode=cfg.output,
            columns=[
                ("contactName", "Contact"), ("company", "Company"), ("channel", "Channel"),
                ("body", "Message"), ("message_at", "Received"),
            ],
            meta={"count": len(items), "total": result.get("total", 0)},
            title="Unanswered Replies",
        )
    _run(cfg, client, _do)


@app.command()
def dismiss(
    lead_app_id: str = typer.Argument(..., help="Lead app database ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Dismiss a reply from the unanswered queue."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await morning_svc.dismiss_reply(client, lead_app_id)
        print_success(result, mode=cfg.output, title="Reply Dismissed")
    _run(cfg, client, _do)


@app.command()
def autonomy(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """View autonomy settings."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await morning_svc.get_autonomy(client)
        print_success(result, mode=cfg.output, title="Autonomy Settings")
    _run(cfg, client, _do)


@app.command("set-autonomy")
def set_autonomy(
    level: int = typer.Argument(..., help="Autonomy level (0–3)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Set the nurture autonomy level (0–3)."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    if not 0 <= level <= 3:
        print_error("INVALID_LEVEL", "Autonomy level must be between 0 and 3.", mode=cfg.output)
        raise typer.Exit(code=1)

    async def _do():
        result = await morning_svc.set_autonomy(client, level=level)
        print_success(result, mode=cfg.output, title="Autonomy Updated")
    _run(cfg, client, _do)
