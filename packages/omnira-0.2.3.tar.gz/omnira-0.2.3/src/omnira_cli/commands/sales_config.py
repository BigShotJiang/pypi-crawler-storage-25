"""Sales config commands — configure outreach steps, presets, schedules, and cycling."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import sales_config as sc_svc

app = typer.Typer(name="sales-config", help="Configure sales process steps, timing, and cycling.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command()
def get(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """View the full sales process configuration for an offering."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await sc_svc.get_sales_process(client, offering_id)
        print_success(result, mode=cfg.output, title=f"Sales Process — Offering {offering_id}")
    _run(cfg, client, _do)


@app.command()
def preset(
    sales_process_id: int = typer.Argument(..., help="Sales process ID"),
    preset: str = typer.Argument(..., help="Preset name: aggressive, standard, gentle, custom"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Set the step preset for a sales process."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await sc_svc.update_preset(client, sales_process_id, preset)
        print_success(result, mode=cfg.output, title="Preset Updated")
    _run(cfg, client, _do)


@app.command()
def schedule(
    sales_process_id: int = typer.Argument(..., help="Sales process ID"),
    timezone: Optional[str] = typer.Option(None, "--timezone", "-tz"),
    start_hour: Optional[int] = typer.Option(None, "--start", help="Start hour (0-23)"),
    end_hour: Optional[int] = typer.Option(None, "--end", help="End hour (0-23)"),
    days: Optional[str] = typer.Option(None, "--days", help="Comma-separated days: mon,tue,wed,thu,fri"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Update the sending schedule for a sales process."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        parsed_days = [d.strip() for d in days.split(",")] if days else None
        result = await sc_svc.update_schedule(
            client, sales_process_id,
            timezone=timezone, start_hour=start_hour, end_hour=end_hour, days=parsed_days,
        )
        print_success(result, mode=cfg.output, title="Schedule Updated")
    _run(cfg, client, _do)


@app.command()
def cycling(
    sales_process_id: int = typer.Argument(..., help="Sales process ID"),
    enabled: Optional[bool] = typer.Option(None, "--enabled/--disabled"),
    max_cycles: Optional[int] = typer.Option(None, "--max-cycles"),
    cooldown_days: Optional[int] = typer.Option(None, "--cooldown-days"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Configure cycling (re-engage leads after sequence ends)."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await sc_svc.update_cycling(
            client, sales_process_id,
            enabled=enabled, max_cycles=max_cycles, cooldown_days=cooldown_days,
        )
        print_success(result, mode=cfg.output, title="Cycling Updated")
    _run(cfg, client, _do)


@app.command("update-step")
def update_step(
    step_id: int = typer.Argument(..., help="Step ID"),
    delay_hours: Optional[int] = typer.Option(None, "--delay", help="Hours before this step fires"),
    channels: Optional[str] = typer.Option(None, "--channels", help="Comma-separated: sms,email,rvm"),
    enabled: Optional[bool] = typer.Option(None, "--enabled/--disabled"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Update an individual outreach step."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        parsed_channels = [c.strip() for c in channels.split(",")] if channels else None
        result = await sc_svc.update_step(
            client, step_id,
            delay_hours=delay_hours, channels=parsed_channels, enabled=enabled,
        )
        print_success(result, mode=cfg.output, title="Step Updated")
    _run(cfg, client, _do)


@app.command("pre-launch-check")
def pre_launch_check(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Run pre-launch validation for a sales process."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await sc_svc.pre_launch_check(client, offering_id)
        print_success(result, mode=cfg.output, title="Pre-Launch Check")
    _run(cfg, client, _do)
