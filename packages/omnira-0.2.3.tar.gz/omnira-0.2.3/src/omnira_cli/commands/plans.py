"""Plans commands — list, approve, edit, reject, and regenerate action plans."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import plans as plans_svc

app = typer.Typer(name="plans", help="List, approve, edit, reject, and regenerate action plans.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command("list")
def plans_list(
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status"),
    limit: int = typer.Option(50, "--limit", "-l"),
    offset: int = typer.Option(0, "--offset"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List action plans."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await plans_svc.list_plans(client, status=status, limit=limit, offset=offset)
        items = result.get("plans", [])
        for item in items:
            item["lead_name"] = f'{item.get("lead_first_name", "")} {item.get("lead_last_name", "")}'.strip()
        print_success(
            items, mode=cfg.output,
            columns=[
                ("id", "ID"), ("lead_name", "Lead"), ("lead_company_name", "Company"),
                ("channel", "Channel"), ("sales_group", "Group"), ("status", "Status"),
                ("created_at", "Created"),
            ],
            meta={"count": len(items), "total": result.get("total", 0)},
            title="Action Plans",
        )
    _run(cfg, client, _do)


@app.command()
def approve(
    plan_id: int = typer.Argument(..., help="Action plan ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Approve an action plan."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await plans_svc.approve_plan(client, plan_id, action="approve")
        print_success(result, mode=cfg.output, title="Plan Approved")
    _run(cfg, client, _do)


@app.command()
def edit(
    plan_id: int = typer.Argument(..., help="Action plan ID"),
    content: str = typer.Argument(..., help="Replacement message content"),
    subject: Optional[str] = typer.Option(None, "--subject", help="Replacement subject (email only)"),
    channels: Optional[str] = typer.Option(None, "--channels", help="Comma-separated channels to override"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Edit and approve an action plan with modified content."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        channels_list = channels.split(",") if channels else None
        parsed_channels = [{"channel": c.strip()} for c in channels_list] if channels_list else None
        result = await plans_svc.approve_plan(
            client, plan_id,
            action="edit",
            modified_content=content,
            modified_subject=subject,
            modified_channels=parsed_channels,
        )
        print_success(result, mode=cfg.output, title="Plan Updated")
    _run(cfg, client, _do)


@app.command()
def reject(
    plan_id: int = typer.Argument(..., help="Action plan ID"),
    reason: Optional[str] = typer.Option(None, "--reason", "-r", help="Rejection reason"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Reject an action plan."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await plans_svc.approve_plan(client, plan_id, action="reject", rejection_reason=reason)
        print_success(result, mode=cfg.output, title="Plan Rejected")
    _run(cfg, client, _do)


@app.command()
def regenerate(
    plan_id: int = typer.Argument(..., help="Action plan ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Regenerate an action plan."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await plans_svc.regenerate_plan(client, plan_id)
        print_success(result, mode=cfg.output, title="Plan Regenerated")
    _run(cfg, client, _do)
