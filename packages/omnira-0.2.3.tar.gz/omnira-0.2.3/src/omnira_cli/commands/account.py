"""Account commands — balance, wallet, history."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import account as account_svc

app = typer.Typer(name="account", help="View your account, credits, and wallet.")


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.callback(invoke_without_command=True)
def _default(ctx: typer.Context, output: Optional[str] = typer.Option(None, "--output", "-o")) -> None:
    """Show account balance (default when no subcommand given)."""
    if ctx.invoked_subcommand is not None:
        return
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await account_svc.get_balance(client)
        print_success(result, mode=cfg.output, title=f"{result.get('partner_name', 'Account')}")
    _run(cfg, client, _do)


@app.command()
def balance(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Show your credit balance and rate limits."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await account_svc.get_balance(client)
        print_success(result, mode=cfg.output, title=f"{result.get('partner_name', 'Account')}")
    _run(cfg, client, _do)


@app.command()
def wallet(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Show wallet and auto-top-up settings."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await account_svc.get_wallet_settings(client)
        print_success(result, mode=cfg.output, title="Wallet Settings")
    _run(cfg, client, _do)


@app.command()
def history(
    limit: int = typer.Option(20, "--limit", "-l"),
    offset: int = typer.Option(0, "--offset"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Show transaction history."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await account_svc.get_wallet_history(client, limit=limit, offset=offset)
        items = result.get("transactions", [])
        print_success(
            items, mode=cfg.output,
            columns=[("created_at", "Date"), ("type", "Type"), ("amount", "Amount"), ("status", "Status")],
            meta={"count": len(items)},
            title="Transaction History",
        )
    _run(cfg, client, _do)
