"""Offerings commands — manage your products/services for outreach."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import offerings as off_svc

app = typer.Typer(name="offerings", help="Manage offerings (products/services) for outreach.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command("list")
def list_offerings(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List all your offerings."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await off_svc.list_offerings(client)
        items = result if isinstance(result, list) else result.get("offerings", [])
        if isinstance(items, list):
            print_success(
                items, mode=cfg.output,
                columns=[
                    ("id", "ID"), ("name", "Name"), ("offering_type", "Type"),
                    ("status", "Status"), ("created_at", "Created"),
                ],
                meta={"count": len(items)},
                title="Offerings",
            )
        else:
            print_success(result, mode=cfg.output, title="Offerings")
    _run(cfg, client, _do)


@app.command()
def get(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Get detailed offering info including sales process."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await off_svc.get_offering(client, offering_id)
        print_success(result, mode=cfg.output, title=f"Offering {offering_id}")
    _run(cfg, client, _do)


@app.command()
def create(
    name: str = typer.Argument(..., help="Offering name"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    offering_type: Optional[str] = typer.Option(None, "--type", "-t"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Create a new offering."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await off_svc.create_offering(
            client, name=name, description=description, offering_type=offering_type,
        )
        print_success(result, mode=cfg.output, title="Offering Created")
    _run(cfg, client, _do)


@app.command()
def update(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Update an offering."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await off_svc.update_offering(client, offering_id, name=name, description=description)
        print_success(result, mode=cfg.output, title="Offering Updated")
    _run(cfg, client, _do)


@app.command()
def delete(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Delete an offering."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await off_svc.delete_offering(client, offering_id)
        print_success(result, mode=cfg.output, title="Offering Deleted")
    _run(cfg, client, _do)


@app.command()
def initialize(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Initialize an offering (generate sales process and templates)."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await off_svc.initialize_offering(client, offering_id)
        print_success(result, mode=cfg.output, title="Offering Initialized")
    _run(cfg, client, _do)


@app.command()
def pause(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Pause all outreach for an offering."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await off_svc.pause_offering(client, offering_id)
        print_success(result, mode=cfg.output, title="Offering Paused")
    _run(cfg, client, _do)


@app.command()
def resume(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Resume outreach for a paused offering."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await off_svc.resume_offering(client, offering_id)
        print_success(result, mode=cfg.output, title="Offering Resumed")
    _run(cfg, client, _do)


@app.command("assign-leads")
def assign_leads(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    lead_ids: str = typer.Option(..., "--lead-ids", help="Comma-separated lead IDs"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Assign leads to an offering."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        ids = [lid.strip() for lid in lead_ids.split(",")]
        result = await off_svc.assign_leads(client, offering_id, ids)
        print_success(result, mode=cfg.output, title="Leads Assigned")
    _run(cfg, client, _do)


@app.command()
def leads(
    offering_id: int = typer.Argument(..., help="Offering ID"),
    limit: int = typer.Option(50, "--limit", "-l"),
    offset: int = typer.Option(0, "--offset"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List leads assigned to an offering."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await off_svc.list_offering_leads(client, offering_id, limit=limit, offset=offset)
        items = result if isinstance(result, list) else result.get("leads", [])
        if isinstance(items, list):
            print_success(
                items, mode=cfg.output,
                columns=[
                    ("id", "ID"), ("first_name", "First"), ("last_name", "Last"),
                    ("company_name", "Company"), ("status", "Status"),
                ],
                meta={"count": len(items)},
                title=f"Offering {offering_id} Leads",
            )
        else:
            print_success(result, mode=cfg.output, title=f"Offering {offering_id} Leads")
    _run(cfg, client, _do)
