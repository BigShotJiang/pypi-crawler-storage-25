"""Outreach commands — action plans, pipeline, health, conversations, sales engine."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import outreach as outreach_svc

app = typer.Typer(name="outreach", help="Sales engine, action plans, pipeline, health, and conversations.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command()
def plans(
    limit: int = typer.Option(50, "--limit", "-l"),
    offset: int = typer.Option(0, "--offset"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """View pending action plans (HITL approvals)."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await outreach_svc.list_action_plans(client, limit=limit, offset=offset)
        items = result if isinstance(result, list) else result.get("action_plans", result.get("plans", []))
        if isinstance(items, list):
            print_success(
                items, mode=cfg.output,
                columns=[
                    ("id", "ID"), ("lead_name", "Lead"), ("channel", "Channel"),
                    ("action", "Action"), ("created_at", "Created"),
                ],
                meta={"count": len(items)},
                title="Action Plans",
            )
        else:
            print_success(items, mode=cfg.output, title="Action Plans")
    _run(cfg, client, _do)


@app.command()
def pipeline(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """View your lead pipeline."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await outreach_svc.get_pipeline(client)
        print_success(result, mode=cfg.output, title="Pipeline")
    _run(cfg, client, _do)


@app.command()
def health(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """View outreach health metrics."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await outreach_svc.get_health(client)
        print_success(result, mode=cfg.output, title="Outreach Health")
    _run(cfg, client, _do)


@app.command()
def conversations(
    lead_id: str = typer.Argument(..., help="Lead app database ID"),
    channel: Optional[str] = typer.Option(None, "--channel", "-c", help="Filter: sms, email, rvm"),
    direction: Optional[str] = typer.Option(None, "--direction", "-d", help="Filter: inbound, outbound"),
    limit: int = typer.Option(50, "--limit", "-l"),
    offset: int = typer.Option(0, "--offset"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """View conversation history for a lead."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await outreach_svc.list_conversations(
            client, lead_id, channel=channel, direction=direction,
            limit=limit, offset=offset,
        )
        messages = result if isinstance(result, list) else result.get("messages", result.get("conversations", []))
        if isinstance(messages, list):
            print_success(
                messages, mode=cfg.output,
                columns=[
                    ("direction", "Dir"), ("channel", "Channel"),
                    ("body", "Message"), ("created_at", "Time"),
                ],
                meta={"count": len(messages)},
                title=f"Conversations — {lead_id}",
            )
        else:
            print_success(messages, mode=cfg.output, title=f"Conversations — {lead_id}")
    _run(cfg, client, _do)


# ── Sales Engine ──────────────────────────────────────────────────────────


@app.command()
def launch(
    offering_id: int = typer.Option(..., "--offering-id", help="Offering ID to launch"),
    lead_ids: str = typer.Option(..., "--lead-ids", help="Comma-separated lead database IDs"),
    stagger: float = typer.Option(0.5, "--stagger", help="Seconds between enrollments"),
    mode: str = typer.Option("now", "--mode", help="Launch mode: now or scheduled"),
    window_mode: str = typer.Option("respect_schedule", "--window-mode", help="respect_schedule or unrestricted"),
    personalized: bool = typer.Option(False, "--personalized/--no-personalized", help="Enable personalized outreach"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Launch a sales outreach process."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await outreach_svc.launch_outreach(
            client,
            offering_id=offering_id,
            lead_ids=[lid.strip() for lid in lead_ids.split(",")],
            stagger_seconds=stagger,
            launch_mode=mode,
            window_mode=window_mode,
            personalized_outreach=personalized,
        )
        print_success(result, mode=cfg.output, title="Outreach Launched")
    _run(cfg, client, _do)


@app.command("launch-status")
def launch_status(
    launch_id: str = typer.Argument(..., help="Launch ID returned from launch command"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Check the status of a launch."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await outreach_svc.get_launch_status(client, launch_id)
        print_success(result, mode=cfg.output, title=f"Launch Status — {launch_id[:12]}...")
    _run(cfg, client, _do)


@app.command()
def pause(
    lead_id: str = typer.Argument(..., help="Lead database ID"),
    offering_id: int = typer.Option(..., "--offering-id", help="Offering ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Pause outreach for a lead."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await outreach_svc.pause_outreach(client, lead_id, offering_id=offering_id)
        print_success(result, mode=cfg.output, title="Outreach Paused")
    _run(cfg, client, _do)


@app.command()
def resume(
    lead_id: str = typer.Argument(..., help="Lead database ID"),
    offering_id: int = typer.Option(..., "--offering-id", help="Offering ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Resume outreach for a lead."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await outreach_svc.resume_outreach(client, lead_id, offering_id=offering_id)
        print_success(result, mode=cfg.output, title="Outreach Resumed")
    _run(cfg, client, _do)


@app.command("force-step")
def force_step(
    lead_id: str = typer.Argument(..., help="Lead database ID"),
    offering_id: int = typer.Option(..., "--offering-id", help="Offering ID"),
    step: int = typer.Option(..., "--step", help="Step number to force"),
    channels: Optional[str] = typer.Option(None, "--channels", help="Comma-separated channels (email,sms,rvm)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Force the next outreach step for a lead."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        parsed_channels = [c.strip() for c in channels.split(",")] if channels else None
        result = await outreach_svc.force_step(
            client, lead_id,
            offering_id=offering_id,
            step_number=step,
            channels=parsed_channels,
        )
        print_success(result, mode=cfg.output, title="Step Forced")
    _run(cfg, client, _do)


@app.command()
def journey(
    lead_id: str = typer.Argument(..., help="Lead app database ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """View the outreach journey for a lead."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await outreach_svc.get_journey(client, lead_id)
        journey_data = result.get("journey")
        if journey_data:
            print_success(journey_data, mode=cfg.output, title=f"Journey — {lead_id[:12]}...")
        else:
            print_success({"message": "No journey found for this lead."}, mode=cfg.output, title="Journey")
    _run(cfg, client, _do)
