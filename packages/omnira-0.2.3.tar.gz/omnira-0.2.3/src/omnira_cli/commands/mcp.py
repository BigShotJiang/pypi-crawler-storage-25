"""MCP commands — serve the Model Context Protocol server."""
from __future__ import annotations

import typer

app = typer.Typer(
    name="mcp",
    help="Model Context Protocol server — lets agents call omnira tools with typed schemas.",
)


@app.command()
def serve(
    transport: str = typer.Option(
        "stdio", "--transport", "-t",
        help="Transport: stdio (for Claude Code subprocess) or http (for testing).",
    ),
    port: int = typer.Option(
        8087, "--port", "-p",
        help="Port for HTTP transport (ignored for stdio).",
    ),
    host: str = typer.Option(
        "127.0.0.1", "--host",
        help="Bind host for HTTP transport (ignored for stdio).",
    ),
) -> None:
    """Start the Omnira MCP server.

    Use stdio for Claude Code / OpenClaw subprocess integrations (default).
    Use http for manual testing or remote MCP clients.
    """
    from omnira_cli.mcp_server import mcp

    if transport == "http":
        mcp.run(transport="http", host=host, port=port)
    elif transport == "stdio":
        mcp.run()
    else:
        typer.echo(
            f"Unknown transport: {transport!r}. Use 'stdio' or 'http'.",
            err=True,
        )
        raise typer.Exit(code=1)


@app.command()
def list_tools() -> None:
    """List all MCP tools the server exposes (useful for debugging)."""
    import asyncio

    from omnira_cli.mcp_server import mcp

    async def _list() -> None:
        tools = await mcp.get_tools()
        typer.echo(f"{len(tools)} tools registered:\n")
        for name in sorted(tools.keys()):
            tool = tools[name]
            desc = (tool.description or "").split("\n")[0][:80]
            typer.echo(f"  {name:<40} {desc}")

    asyncio.run(_list())
