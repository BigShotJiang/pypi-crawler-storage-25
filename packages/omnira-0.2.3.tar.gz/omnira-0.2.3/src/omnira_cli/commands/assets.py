"""Assets commands — list, get, deploy, preview, status, delete."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import assets as assets_svc

app = typer.Typer(name="assets", help="Manage AI-generated landing pages and assets.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command("list")
def list_assets(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List all your assets."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await assets_svc.list_assets(client)
        items = result if isinstance(result, list) else result.get("assets", [result])
        print_success(items, mode=cfg.output, columns=[("id", "ID"), ("name", "Name"), ("status", "Status"), ("asset_type", "Type")], title="Assets")
    _run(cfg, client, _do)


@app.command()
def get(
    asset_id: int = typer.Argument(..., help="Asset ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Get detailed asset information."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await assets_svc.get_asset(client, asset_id)
        print_success(result, mode=cfg.output, title=f"Asset {asset_id}")
    _run(cfg, client, _do)


@app.command()
def deploy(
    offering_id: int = typer.Option(..., "--offer-id", help="Offering to link asset to"),
    asset_type: str = typer.Option("static", "--type", "-t"),
    name: Optional[str] = typer.Option(None, "--name", "-n"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Create and build a new asset."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await assets_svc.deploy_asset(client, offering_id=offering_id, asset_type=asset_type, name=name)
        print_success(result, mode=cfg.output, title="Asset Deployed")
    _run(cfg, client, _do)


@app.command()
def preview(
    asset_id: int = typer.Argument(..., help="Asset ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Get preview URL for an asset."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await assets_svc.preview_asset(client, asset_id)
        print_success(result, mode=cfg.output, title=f"Preview — Asset {asset_id}")
    _run(cfg, client, _do)


@app.command()
def status(
    asset_id: int = typer.Argument(..., help="Asset ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Check build status of an asset."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await assets_svc.asset_status(client, asset_id)
        print_success(result, mode=cfg.output, title=f"Build Status — Asset {asset_id}")
    _run(cfg, client, _do)


@app.command()
def delete(
    asset_id: int = typer.Argument(..., help="Asset ID"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Delete an asset."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await assets_svc.delete_asset(client, asset_id)
        print_success(result, mode=cfg.output, title=f"Deleted Asset {asset_id}")
    _run(cfg, client, _do)
