"""Travel commands — resort inventory, flight search, availability."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import travel as travel_svc

app = typer.Typer(name="travel", help="Resort inventory, flight search, and availability.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command()
def inventory(
    resort_id: str = typer.Argument(..., help="Resort ID"),
    start_date: Optional[str] = typer.Option(None, "--start-date", "-d", help="Start date (ISO format, e.g. 2026-04-01)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """View resort inventory."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await travel_svc.get_inventory(client, resort_id, start_date=start_date)
        print_success(result, mode=cfg.output, title=f"Resort {resort_id} Inventory")
    _run(cfg, client, _do)


@app.command()
def flights(
    from_airport: str = typer.Option(..., "--from", "-f", help="Origin airport code"),
    to: str = typer.Option(..., "--to", "-t", help="Destination airport code"),
    date: str = typer.Option(..., "--date", "-d", help="Departure date (ISO format, e.g. 2026-04-15)"),
    passengers: int = typer.Option(1, "--passengers", "-p", help="Number of passengers"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Search for available flights."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await travel_svc.search_flights(
            client,
            origin=from_airport,
            destination=to,
            departure_date=date,
            passengers=passengers,
        )
        items = result.get("flights", result.get("data", []))
        if isinstance(items, list):
            print_success(
                items, mode=cfg.output,
                columns=[
                    ("airline", "Airline"), ("flight_number", "Flight"),
                    ("departure", "Depart"), ("arrival", "Arrive"), ("price", "Price"),
                ],
                title="Flights",
            )
        else:
            print_success(result, mode=cfg.output, title="Flights")
    _run(cfg, client, _do)


@app.command()
def availability(
    resort_id: Optional[str] = typer.Option(None, "--resort-id", "-r", help="Resort ID to filter by"),
    start: Optional[str] = typer.Option(None, "--start", "-s", help="Start date (ISO format)"),
    end: Optional[str] = typer.Option(None, "--end", "-e", help="End date (ISO format)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Check travel availability."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await travel_svc.check_availability(client, resort_id=resort_id, start=start, end=end)
        print_success(result, mode=cfg.output, title="Travel Availability")
    _run(cfg, client, _do)
