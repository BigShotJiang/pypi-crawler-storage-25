"""Admin commands — cross-partner operations. Requires an admin-flagged API key.

Your admin key is a regular partner API key with is_admin=true. Use --as-partner
(or OMNIRA_AS_PARTNER env var) on normal partner-scoped commands to choose which
partner to act as. The commands in this group operate across all partners and
don't need --as-partner.
"""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.services import admin as admin_svc
from omnira_cli.output import print_error, print_success

app = typer.Typer(
    name="admin",
    help="Admin-only commands (requires an admin API key).",
    no_args_is_help=True,
    hidden=True,
)


def _run(cfg, client, coro_factory):
    async def _inner():
        try:
            await coro_factory()
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command()
def partners(
    agency_id: Optional[int] = typer.Option(
        None, "--agency-id", "-a",
        help="Filter to partners under this agency (GHL company ID).",
    ),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List all partners on the platform."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        try:
            partners = await admin_svc.list_partners(client, agency_id=agency_id)
        except Exception as e:
            print_error("ADMIN_ERROR", str(e), mode=cfg.output)
            raise typer.Exit(code=1)
        print_success(
            partners,
            mode=cfg.output,
            columns=[
                ("id", "ID"),
                ("name", "Name"),
                ("account_type", "Type"),
                ("agency_name", "Agency"),
                ("user_count", "Users"),
                ("opportunity_status", "Status"),
            ],
            meta={"count": len(partners)},
            title="Partners",
        )
    _run(cfg, client, _do)
