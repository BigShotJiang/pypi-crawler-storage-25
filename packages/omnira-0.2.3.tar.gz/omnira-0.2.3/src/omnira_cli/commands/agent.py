"""Agent commands — install, uninstall, and check the omnira skill in a Claude Code project.

These are local-only commands. They don't talk to the Omnira API. They write
files into your project (or home directory) so AI agents like Claude Code can
discover and use the omnira CLI.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from omnira_cli.services import agent_setup

app = typer.Typer(name="agent", help="Set up the omnira CLI for use with AI agents (Claude Code, etc).")
console = Console()


@app.command()
def install(
    global_: bool = typer.Option(
        False,
        "--global",
        "-g",
        help="Install globally to ~/.claude (instead of the current project).",
    ),
    project: Optional[Path] = typer.Option(
        None,
        "--project",
        "-p",
        help="Install to a specific project path (overrides auto-detection).",
        file_okay=False,
        dir_okay=True,
    ),
) -> None:
    """Install the omnira skill so AI agents can discover the CLI.

    By default, looks for a project root (.claude/, CLAUDE.md, or .git/) starting
    from the current directory. If found, installs project-scoped. Otherwise
    falls back to ~/.claude (global install).

    The install creates:
      - <target>/.claude/skills/omnira/SKILL.md  (full command reference)
      - <target>/CLAUDE.md                        (one-paragraph pointer section)
      - <target>/.claude/mcp_servers.json         (so Claude Code auto-starts
                                                   the MCP server with 89 tools)

    After running, restart Claude Code to pick up the new skill + MCP tools.
    """
    try:
        result = agent_setup.install(
            force_global=global_,
            force_project=project,
        )
    except FileNotFoundError as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(code=1)

    scope_label = "globally to" if result.scope == "global" else "into project"
    console.print()
    console.print(f"[green]✓[/green] Installed omnira skill {scope_label} [bold]{result.target}[/bold]")
    console.print()

    action_color = {"created": "green", "updated": "yellow", "unchanged": "dim"}
    skill_color = action_color.get(result.skill_action, "dim")
    claude_color = action_color.get(result.claude_md_action, "dim")
    mcp_color = action_color.get(result.mcp_action, "dim")

    console.print(f"  [{skill_color}]{result.skill_action:<9}[/{skill_color}]  skill file  [dim]{result.skill_path}[/dim]")
    console.print(f"  [{claude_color}]{result.claude_md_action:<9}[/{claude_color}]  CLAUDE.md   [dim]{result.claude_md_path}[/dim]")
    console.print(f"  [{mcp_color}]{result.mcp_action:<9}[/{mcp_color}]  MCP config  [dim]{result.mcp_config_path}[/dim]")
    console.print()

    if result.scope == "project":
        console.print("  [bold]Next:[/bold] Restart Claude Code in this project. The agent will discover")
        console.print("  the omnira skill and can manage your account on your behalf.")
    else:
        console.print("  [bold]Next:[/bold] Restart Claude Code in any project. The omnira skill is now")
        console.print("  available globally.")
    console.print()
    console.print("  Try asking the agent: [cyan]\"Show me my pending HITL messages\"[/cyan]")
    console.print()


@app.command()
def uninstall(
    global_: bool = typer.Option(
        False,
        "--global",
        "-g",
        help="Uninstall the global ~/.claude install.",
    ),
    project: Optional[Path] = typer.Option(
        None,
        "--project",
        "-p",
        help="Uninstall from a specific project path.",
        file_okay=False,
        dir_okay=True,
    ),
) -> None:
    """Remove the omnira skill from a Claude Code project (or global)."""
    result = agent_setup.uninstall(
        force_global=global_,
        force_project=project,
    )
    console.print()
    any_removed = result["removed_skill"] or result["removed_section"] or result["removed_mcp"]
    if any_removed:
        console.print(f"[green]✓[/green] Removed omnira skill from [bold]{result['target']}[/bold]")
        if result["removed_skill"]:
            console.print("  [yellow]removed[/yellow]  .claude/skills/omnira/")
        if result["removed_section"]:
            console.print("  [yellow]removed[/yellow]  CLAUDE.md section")
        if result["removed_mcp"]:
            console.print("  [yellow]removed[/yellow]  MCP config entry")
    else:
        console.print(f"[dim]No omnira skill found at {result['target']}[/dim]")
    console.print()


@app.command()
def status(
    global_: bool = typer.Option(False, "--global", "-g"),
    project: Optional[Path] = typer.Option(None, "--project", "-p", file_okay=False, dir_okay=True),
) -> None:
    """Show whether the omnira skill is installed at a given location."""
    result = agent_setup.status(
        force_global=global_,
        force_project=project,
    )

    console.print()
    console.print(f"  Target: [bold]{result['target']}[/bold] ([dim]{result['scope']}[/dim])")
    ok = "[green]✓ installed[/green]"
    no = "[red]✗ not installed[/red]"
    skill_state = ok if result["skill_installed"] else no
    section_state = ok if result["section_installed"] else no
    mcp_state = ok if result["mcp_installed"] else no
    console.print(f"  Skill file:        {skill_state}  [dim]{result['skill_path']}[/dim]")
    console.print(f"  CLAUDE.md section: {section_state}  [dim]{result['claude_md_path']}[/dim]")
    console.print(f"  MCP config entry:  {mcp_state}  [dim]{result['mcp_config_path']}[/dim]")
    console.print()
