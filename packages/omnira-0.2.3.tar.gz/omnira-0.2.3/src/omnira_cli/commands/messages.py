"""Messages commands — send SMS, email, and iMessage to leads."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import messages as msg_svc

app = typer.Typer(name="messages", help="Send SMS, email, and iMessage to leads.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command()
def sms(
    lead_app_id: str = typer.Argument(..., help="Lead app database ID"),
    body: str = typer.Argument(..., help="Message text to send"),
    from_number: Optional[str] = typer.Option(None, "--from", help="Override sending phone number"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Send an SMS to a lead."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await msg_svc.send_sms(client, lead_app_id, body, from_number=from_number)
        print_success(result, mode=cfg.output, title="SMS Sent")
    _run(cfg, client, _do)


@app.command()
def email(
    lead_app_id: str = typer.Argument(..., help="Lead app database ID"),
    body: str = typer.Argument(..., help="Email body text"),
    subject: Optional[str] = typer.Option(None, "--subject", "-s", help="Email subject (auto-threads if omitted)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Send an email to a lead via connected Gmail."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await msg_svc.send_email(client, lead_app_id, body, subject=subject)
        print_success(result, mode=cfg.output, title="Email Sent")
    _run(cfg, client, _do)


@app.command()
def imessage(
    lead_app_id: str = typer.Argument(..., help="Lead app database ID"),
    body: str = typer.Argument(..., help="Message text to send"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Send an iMessage to a lead."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await msg_svc.send_imessage(client, lead_app_id, body)
        print_success(result, mode=cfg.output, title="iMessage Sent")
    _run(cfg, client, _do)


@app.command("imessage-check")
def imessage_check(
    phone: str = typer.Argument(..., help="Phone number to check (any format)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Check if a phone number supports iMessage."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await msg_svc.check_imessage(client, phone)
        print_success(result, mode=cfg.output, title="iMessage Capability")
    _run(cfg, client, _do)
