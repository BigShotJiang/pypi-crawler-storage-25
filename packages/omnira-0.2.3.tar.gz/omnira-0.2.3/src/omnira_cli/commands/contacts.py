"""Contacts commands — create and update lead contacts."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import contacts as contact_svc

app = typer.Typer(name="contacts", help="Create and update lead contacts.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command()
def create(
    first_name: str = typer.Argument(..., help="First name"),
    last_name: Optional[str] = typer.Option(None, "--last-name"),
    email: Optional[str] = typer.Option(None, "--email"),
    mobile: Optional[str] = typer.Option(None, "--mobile"),
    title: Optional[str] = typer.Option(None, "--title", help="Job title"),
    company: Optional[str] = typer.Option(None, "--company"),
    linkedin: Optional[str] = typer.Option(None, "--linkedin"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Create a new contact."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await contact_svc.create_contact(
            client,
            first_name=first_name, last_name=last_name,
            email=email, mobile_number=mobile,
            job_title=title, company_name=company, linkedin=linkedin,
        )
        print_success(result, mode=cfg.output, title="Contact Created")
    _run(cfg, client, _do)


@app.command()
def update(
    lead_app_id: str = typer.Argument(..., help="Lead app database ID"),
    first_name: Optional[str] = typer.Option(None, "--first-name"),
    last_name: Optional[str] = typer.Option(None, "--last-name"),
    email: Optional[str] = typer.Option(None, "--email"),
    mobile: Optional[str] = typer.Option(None, "--mobile"),
    title: Optional[str] = typer.Option(None, "--title", help="Job title"),
    company: Optional[str] = typer.Option(None, "--company"),
    linkedin: Optional[str] = typer.Option(None, "--linkedin"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Update an existing contact."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await contact_svc.update_contact(
            client, lead_app_id,
            first_name=first_name, last_name=last_name,
            email=email, mobile_number=mobile,
            job_title=title, company_name=company, linkedin=linkedin,
        )
        print_success(result, mode=cfg.output, title="Contact Updated")
    _run(cfg, client, _do)
