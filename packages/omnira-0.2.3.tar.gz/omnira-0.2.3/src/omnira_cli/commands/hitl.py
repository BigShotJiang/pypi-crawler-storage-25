"""HITL commands — review and act on AI-generated messages awaiting approval."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer

from omnira_cli.client import OmniraError
from omnira_cli.output import print_error, print_success
from omnira_cli.services import hitl as hitl_svc

app = typer.Typer(name="hitl", help="Human-in-the-loop: review, approve, edit, or reject AI messages.", no_args_is_help=True)


def _run(cfg, client, coro_fn):
    async def _inner():
        try:
            await client.authenticate()
            await coro_fn()
        except OmniraError as e:
            print_error(e.code, e.message, e.suggestion, mode=cfg.output)
            raise typer.Exit(code=1)
        finally:
            await client.close()
    asyncio.run(_inner())


@app.command("list")
def list_pending(
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """List pending AI messages awaiting your approval."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await hitl_svc.list_pending(client)
        items = result if isinstance(result, list) else result.get("pending", result.get("approvals", []))
        if isinstance(items, list):
            print_success(
                items, mode=cfg.output,
                columns=[
                    ("approval_token", "Token"),
                    ("lead_name", "Lead"),
                    ("channel", "Channel"),
                    ("proposed_response", "Message"),
                    ("created_at", "Created"),
                ],
                meta={"count": len(items)},
                title="Pending Approvals",
            )
        else:
            print_success(result, mode=cfg.output, title="Pending Approvals")
    _run(cfg, client, _do)


@app.command()
def approve(
    token: str = typer.Argument(..., help="Approval token from hitl list"),
    approved_by: Optional[str] = typer.Option(None, "--by", help="Who approved (your name)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Approve an AI-generated message for sending."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await hitl_svc.approve(client, token, approved_by=approved_by)
        print_success(result, mode=cfg.output, title="Approved")
    _run(cfg, client, _do)


@app.command()
def reject(
    token: str = typer.Argument(..., help="Approval token from hitl list"),
    reason: Optional[str] = typer.Option(None, "--reason", "-r", help="Why you're rejecting"),
    rejected_by: Optional[str] = typer.Option(None, "--by", help="Who rejected (your name)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Reject an AI-generated message."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await hitl_svc.reject(client, token, reason=reason, rejected_by=rejected_by)
        print_success(result, mode=cfg.output, title="Rejected")
    _run(cfg, client, _do)


@app.command()
def edit(
    token: str = typer.Argument(..., help="Approval token from hitl list"),
    message: str = typer.Argument(..., help="Your edited version of the message"),
    approved_by: Optional[str] = typer.Option(None, "--by", help="Who edited (your name)"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Edit an AI message and approve the modified version."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await hitl_svc.edit_and_approve(client, token, message, approved_by=approved_by)
        print_success(result, mode=cfg.output, title="Edited & Approved")
    _run(cfg, client, _do)


@app.command()
def process(
    contact_id: str = typer.Argument(..., help="Lead database ID (contact_id)"),
    message: str = typer.Argument(..., help="Inbound message text to process"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
) -> None:
    """Inject an inbound message into the AI conversation pipeline."""
    from omnira_cli.main import get_config, get_client
    cfg = get_config(output=output)
    client = get_client(cfg)

    async def _do():
        result = await hitl_svc.process_inbound(client, contact_id, message)
        print_success(result, mode=cfg.output, title="Message Processed")
    _run(cfg, client, _do)
