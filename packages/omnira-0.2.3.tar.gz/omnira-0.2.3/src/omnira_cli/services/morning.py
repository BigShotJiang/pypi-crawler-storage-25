"""Morning service — stats, replies, dismiss, autonomy."""

from __future__ import annotations

from typing import Any

from omnira_cli.client import OmniraClient


async def get_stats(client: OmniraClient) -> dict:
    """Get morning plan stats for the partner."""
    return await client.get(
        "/api/v2/morning-plan/stats",
        params={"partner_id": client.partner_id},
    )


async def list_replies(client: OmniraClient, *, limit: int = 20) -> dict:
    """Get unanswered replies for the partner."""
    return await client.get(
        "/api/v2/dashboard/unanswered-replies",
        params={"partner_id": client.partner_id, "limit": limit},
    )


async def dismiss_reply(client: OmniraClient, lead_app_id: str) -> dict:
    """Dismiss a reply from the unanswered queue."""
    body: dict[str, Any] = {"lead_app_id": lead_app_id, "partner_id": client.partner_id}
    return await client.post("/api/v2/dashboard/dismiss-reply", json=body)


async def get_autonomy(client: OmniraClient) -> dict:
    """Get the partner's autonomy settings."""
    return await client.get(f"/api/v2/partners/{client.partner_id}/autonomy")


async def set_autonomy(client: OmniraClient, *, level: int) -> dict:
    """Set the partner's nurture autonomy level."""
    body: dict[str, Any] = {"nurture_autonomy_level": level}
    return await client.patch(f"/api/v2/partners/{client.partner_id}/autonomy", json=body)
