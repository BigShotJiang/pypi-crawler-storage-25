"""Travel service — resort inventory, flight search, availability."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient


async def get_inventory(
    client: OmniraClient,
    resort_id: str,
    *,
    start_date: Optional[str] = None,
) -> dict:
    """Get inventory for a resort."""
    params: dict[str, Any] = {}
    if start_date is not None:
        params["start_date"] = start_date
    return await client.get(
        f"/api/travel/resort/{resort_id}/inventory", params=params
    )


async def search_flights(
    client: OmniraClient,
    *,
    origin: str,
    destination: str,
    departure_date: str,
    passengers: int = 1,
) -> dict:
    """Search for available flights."""
    body: dict[str, Any] = {
        "origin": origin,
        "destination": destination,
        "date": departure_date,
        "passengers": passengers,
    }
    return await client.post("/api/travel/flights/search", json=body)


async def check_availability(
    client: OmniraClient,
    *,
    resort_id: Optional[str] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> dict:
    """Check travel availability."""
    params: dict[str, Any] = {}
    if resort_id is not None:
        params["resort_id"] = resort_id
    if start is not None:
        params["start"] = start
    if end is not None:
        params["end"] = end
    return await client.get("/api/travel/availability", params=params)
