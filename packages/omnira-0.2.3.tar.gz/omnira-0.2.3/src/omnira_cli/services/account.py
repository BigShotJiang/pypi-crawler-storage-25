"""Account service — balance, credits, wallet."""

from __future__ import annotations

from omnira_cli.client import OmniraClient, OmniraError


async def get_balance(client: OmniraClient) -> dict:
    """Get account balance including partner name and credits."""
    credits = await client.get(f"/api/partner/{client.partner_id}/credits")
    partner_name = client.partner_name
    try:
        ctx = await client.get(f"/api/partner/{client.partner_id}/context")
        partner_name = ctx.get("partner_config", {}).get("partner_name", partner_name)
    except Exception:
        pass
    return {
        "partner_id": client.partner_id,
        "partner_name": partner_name,
        "credits": {
            "leads": credits.get("lead_available_credits", 0),
            "contacts": credits.get("contact_available_credits", 0),
        },
    }


async def get_wallet_settings(client: OmniraClient) -> dict:
    """Get auto-top-up settings."""
    raise OmniraError(
        "NOT_AVAILABLE",
        "Wallet settings not yet available via API.",
        "Use the Omnira dashboard instead.",
    )


async def get_wallet_history(client: OmniraClient, *, limit: int = 20, offset: int = 0) -> dict:
    """Get auto-top-up transaction history."""
    raise OmniraError(
        "NOT_AVAILABLE",
        "Wallet history not yet available via API.",
        "Use the Omnira dashboard instead.",
    )
