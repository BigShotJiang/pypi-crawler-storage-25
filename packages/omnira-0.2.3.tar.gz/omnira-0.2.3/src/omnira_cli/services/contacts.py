"""Contacts service — create and update lead contacts."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient


async def create_contact(
    client: OmniraClient,
    *,
    first_name: str,
    last_name: Optional[str] = None,
    email: Optional[str] = None,
    mobile_number: Optional[str] = None,
    job_title: Optional[str] = None,
    company_name: Optional[str] = None,
    linkedin: Optional[str] = None,
) -> dict:
    """Create a new contact."""
    payload: dict[str, Any] = {
        "partner_id": client.partner_id,
        "first_name": first_name,
    }
    if last_name:
        payload["last_name"] = last_name
    if email:
        payload["email"] = email
    if mobile_number:
        payload["mobile_number"] = mobile_number
    if job_title:
        payload["job_title"] = job_title
    if company_name:
        payload["company_name"] = company_name
    if linkedin:
        payload["linkedin"] = linkedin
    return await client.post("/api/contacts", json=payload)


async def update_contact(
    client: OmniraClient,
    lead_app_id: str,
    *,
    first_name: Optional[str] = None,
    last_name: Optional[str] = None,
    email: Optional[str] = None,
    mobile_number: Optional[str] = None,
    job_title: Optional[str] = None,
    company_name: Optional[str] = None,
    linkedin: Optional[str] = None,
) -> dict:
    """Update an existing contact's fields."""
    payload: dict[str, Any] = {"partner_id": client.partner_id}
    if first_name:
        payload["first_name"] = first_name
    if last_name:
        payload["last_name"] = last_name
    if email:
        payload["email"] = email
    if mobile_number:
        payload["mobile_number"] = mobile_number
    if job_title:
        payload["job_title"] = job_title
    if company_name:
        payload["company_name"] = company_name
    if linkedin:
        payload["linkedin"] = linkedin
    return await client.patch(f"/api/contacts/{lead_app_id}", json=payload)
