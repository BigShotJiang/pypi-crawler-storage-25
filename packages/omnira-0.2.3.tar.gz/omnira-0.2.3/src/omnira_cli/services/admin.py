"""Admin service — cross-partner operations. Requires an admin-flagged API key."""

from __future__ import annotations

from typing import Optional

from omnira_cli.client import OmniraClient


async def list_partners(
    client: OmniraClient,
    *,
    agency_id: Optional[int] = None,
) -> list:
    """List all partners on the platform. Admin-only.

    Returns a flat list of partner dicts with:
        id, name, locationid, agency_name, agency_id, opportunity_status,
        onboarding_completed_at, user_count, account_type.
    """
    params: dict = {}
    if agency_id is not None:
        params["agency_id"] = agency_id
    result = await client.get("/api/admin/partners", params=params or None)
    # Endpoint returns a flat list, not a wrapped envelope.
    return result if isinstance(result, list) else result.get("partners", [])
