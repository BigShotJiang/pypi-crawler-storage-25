"""Outreach service — action plans, pipeline, health, conversations, sales engine."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient, OmniraError


async def list_action_plans(
    client: OmniraClient,
    *,
    limit: int = 50,
    offset: int = 0,
) -> dict:
    """Get pending action plans (HITL approvals)."""
    params: dict[str, Any] = {"limit": limit, "offset": offset}
    return await client.get(
        f"/api/partner/{client.partner_id}/action-plans", params=params
    )


async def get_pipeline(
    client: OmniraClient,
) -> dict:
    """Get the lead pipeline overview."""
    return await client.get(f"/api/partner/{client.partner_id}/pipeline")


async def get_health(
    client: OmniraClient,
) -> dict:
    """Get outreach health metrics."""
    return await client.get(f"/api/partner/{client.partner_id}/campaign-health")


async def list_conversations(
    client: OmniraClient,
    lead_id: str,
    *,
    channel: Optional[str] = None,
    direction: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> dict:
    """Get conversation history for a lead."""
    params: dict[str, Any] = {"limit": limit, "offset": offset}
    if channel:
        params["channel"] = channel
    if direction:
        params["direction"] = direction
    return await client.get(
        f"/api/partner/{client.partner_id}/leads/{lead_id}/conversations",
        params=params,
    )


# ── Sales Engine ──────────────────────────────────────────────────────────


async def launch_outreach(
    client: OmniraClient,
    *,
    offering_id: int,
    lead_ids: list[str],
    stagger_seconds: float = 0.5,
    launch_mode: str = "now",
    window_mode: str = "respect_schedule",
    personalized_outreach: bool = False,
) -> dict:
    """Launch a sales outreach process for leads."""
    body: dict[str, Any] = {
        "partner_id": client.partner_id,
        "offering_id": offering_id,
        "lead_ids": lead_ids,
        "stagger_seconds": stagger_seconds,
        "launch_mode": launch_mode,
        "window_mode": window_mode,
        "personalized_outreach": personalized_outreach,
    }
    return await client.post("/api/sales-process/launch", json=body)


async def get_launch_status(
    client: OmniraClient,
    launch_id: str,
) -> dict:
    """Check the status of a sales process launch."""
    return await client.get(f"/api/sales-process/launch/{launch_id}/status")


async def pause_outreach(
    client: OmniraClient,
    lead_id: str,
    *,
    offering_id: int,
) -> dict:
    """Pause outreach for a specific lead and offering."""
    body: dict[str, Any] = {
        "partner_id": client.partner_id,
        "lead_id": lead_id,
        "offering_id": offering_id,
    }
    return await client.post("/api/sales-process/pause", json=body)


async def resume_outreach(
    client: OmniraClient,
    lead_id: str,
    *,
    offering_id: int,
) -> dict:
    """Resume outreach for a specific lead and offering."""
    body: dict[str, Any] = {
        "partner_id": client.partner_id,
        "lead_id": lead_id,
        "offering_id": offering_id,
    }
    return await client.post("/api/sales-process/resume", json=body)


async def force_step(
    client: OmniraClient,
    lead_id: str,
    *,
    offering_id: int,
    step_number: int,
    channels: Optional[list[str]] = None,
) -> dict:
    """Force the next outreach step for a lead."""
    body: dict[str, Any] = {
        "partner_id": client.partner_id,
        "lead_id": lead_id,
        "offering_id": offering_id,
        "step_number": step_number,
    }
    if channels:
        body["channels"] = channels
    return await client.post("/api/sales-process/force-step-now", json=body)


async def get_journey(
    client: OmniraClient,
    lead_id: str,
) -> dict:
    """Get the outreach journey for a lead."""
    return await client.get(
        f"/api/lead/{lead_id}/journey",
        params={"partner_id": client.partner_id},
    )
