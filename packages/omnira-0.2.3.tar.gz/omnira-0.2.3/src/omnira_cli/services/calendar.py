"""Calendar service — connection status, calendars, events, sync."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient


async def get_status(client: OmniraClient) -> dict:
    """Get calendar connection status for the partner."""
    return await client.get(f"/api/calendar/connection/{client.partner_id}")


async def list_calendars(client: OmniraClient) -> dict:
    """List available calendars for the partner."""
    return await client.get(f"/api/calendar/calendars/{client.partner_id}")


async def select_calendar(
    client: OmniraClient,
    *,
    calendar_id: str,
    calendar_name: Optional[str] = None,
) -> dict:
    """Select the active calendar for the partner."""
    body: dict[str, Any] = {
        "partner_id": client.partner_id,
        "calendar_id": calendar_id,
    }
    if calendar_name is not None:
        body["calendar_name"] = calendar_name
    return await client.post("/api/calendar/select-calendar", json=body)


async def create_calendar(
    client: OmniraClient,
    *,
    name: str,
    description: Optional[str] = None,
    timezone: Optional[str] = None,
) -> dict:
    """Create a new calendar for the partner."""
    body: dict[str, Any] = {
        "partner_id": client.partner_id,
        "calendar_name": name,
    }
    if description is not None:
        body["description"] = description
    if timezone is not None:
        body["timezone"] = timezone
    return await client.post("/api/calendar/create-calendar", json=body)


async def list_events(
    client: OmniraClient,
    *,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> dict:
    """List calendar events for the partner."""
    params: dict[str, Any] = {}
    if start is not None:
        params["start"] = start
    if end is not None:
        params["end"] = end
    return await client.get(
        f"/api/calendar/events/{client.partner_id}", params=params
    )


async def sync_appointment(
    client: OmniraClient,
    *,
    appointment_id: str,
    action: str = "create",
) -> dict:
    """Sync an appointment to the calendar."""
    body: dict[str, Any] = {
        "appointment_id": appointment_id,
        "action": action,
    }
    return await client.post("/api/calendar/sync", json=body)
