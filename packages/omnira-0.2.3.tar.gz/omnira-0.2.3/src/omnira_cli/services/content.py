"""Content service — manage outreach message templates (skeletons)."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient


async def list_skeletons(
    client: OmniraClient,
    offering_id: int,
) -> dict:
    """List content templates (skeletons) for an offering."""
    return await client.get(f"/api/skeletons/{offering_id}")


async def update_skeleton(
    client: OmniraClient,
    skeleton_id: int,
    *,
    subject: Optional[str] = None,
    body: Optional[str] = None,
    channel: Optional[str] = None,
) -> dict:
    """Update a content template."""
    payload: dict[str, Any] = {}
    if subject:
        payload["subject"] = subject
    if body:
        payload["body"] = body
    if channel:
        payload["channel"] = channel
    return await client.patch(f"/api/skeletons/{skeleton_id}", json=payload)


async def generate_skeletons(
    client: OmniraClient,
    offering_id: int,
) -> dict:
    """Generate new content templates for an offering."""
    payload: dict[str, Any] = {
        "partner_id": client.partner_id,
        "offering_id": offering_id,
    }
    return await client.post("/api/skeletons/generate", json=payload)


async def regenerate_skeleton(
    client: OmniraClient,
    skeleton_id: int,
) -> dict:
    """Regenerate a single content template."""
    payload: dict[str, Any] = {"partner_id": client.partner_id}
    return await client.post(f"/api/skeletons/{skeleton_id}/regenerate", json=payload)
