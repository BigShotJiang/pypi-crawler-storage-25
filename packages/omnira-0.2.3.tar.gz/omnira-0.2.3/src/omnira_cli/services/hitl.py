"""HITL service — human-in-the-loop approvals for AI-generated messages."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient


async def list_pending(
    client: OmniraClient,
) -> dict:
    """List pending HITL approvals for the partner.

    Returns the same envelope as /api/dashboard/hitl — partners get a summary
    block + a `pending_approvals` array containing per-message details
    (approval_token, inbound_message, proposed_response, lead context).
    """
    return await client.get(
        "/api/dashboard/hitl",
        params={"partner_id": client.partner_id, "time_range": "24h"},
    )


async def approve(
    client: OmniraClient,
    approval_token: str,
    *,
    approved_by: Optional[str] = None,
) -> dict:
    """Approve a pending AI-generated message for sending."""
    payload: dict[str, Any] = {
        "approval_token": approval_token,
        "action": "approve",
    }
    if approved_by:
        payload["approved_by"] = approved_by
    return await client.post("/api/ai-text/hitl/approve", json=payload)


async def reject(
    client: OmniraClient,
    approval_token: str,
    *,
    reason: Optional[str] = None,
    rejected_by: Optional[str] = None,
) -> dict:
    """Reject a pending AI-generated message."""
    payload: dict[str, Any] = {
        "approval_token": approval_token,
        "action": "reject",
    }
    if reason:
        payload["rejection_reason"] = reason
    if rejected_by:
        payload["rejected_by"] = rejected_by
    return await client.post("/api/ai-text/hitl/reject", json=payload)


async def edit_and_approve(
    client: OmniraClient,
    approval_token: str,
    modified_response: str,
    *,
    approved_by: Optional[str] = None,
) -> dict:
    """Approve a message with modifications (edit before sending)."""
    payload: dict[str, Any] = {
        "approval_token": approval_token,
        "action": "approve",
        "modified_response": modified_response,
    }
    if approved_by:
        payload["approved_by"] = approved_by
    return await client.post("/api/ai-text/hitl/approve", json=payload)


async def process_inbound(
    client: OmniraClient,
    contact_id: str,
    message_body: str,
    *,
    message_id: Optional[str] = None,
) -> dict:
    """Inject an inbound message into the AI conversation pipeline.

    This signals the V3 entity workflow with an inbound_reply,
    triggering the AI to generate a response.

    Args:
        contact_id: The lead_database.id (contact ID).
        message_body: The message text to process.
    """
    payload: dict[str, Any] = {
        "partner_id": client.partner_id,
        "contact_id": contact_id,
        "message_body": message_body,
    }
    if message_id:
        payload["message_id"] = message_id
    return await client.post("/api/ai-text/process-message", json=payload)
