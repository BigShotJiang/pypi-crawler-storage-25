"""Plans service — list, approve, edit, reject, and regenerate action plans."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient


async def list_plans(
    client: OmniraClient,
    *,
    status: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> dict:
    """Get action plans for the partner."""
    params: dict[str, Any] = {"partner_id": client.partner_id, "limit": limit, "offset": offset}
    if status is not None:
        params["status"] = status
    return await client.get("/api/v2/action-plans", params=params)


async def approve_plan(
    client: OmniraClient,
    plan_id: int,
    *,
    action: str = "approve",
    modified_content: Optional[str] = None,
    modified_subject: Optional[str] = None,
    modified_channels: Optional[list] = None,
    rejection_reason: Optional[str] = None,
) -> dict:
    """Approve, edit, or reject an action plan."""
    body: dict[str, Any] = {"action": action}
    if modified_content is not None:
        body["modified_content"] = modified_content
    if modified_subject is not None:
        body["modified_subject"] = modified_subject
    if modified_channels is not None:
        body["modified_channels"] = modified_channels
    if rejection_reason is not None:
        body["rejection_reason"] = rejection_reason
    return await client.post(f"/api/v2/action-plans/{plan_id}/approve", json=body)


async def regenerate_plan(
    client: OmniraClient,
    plan_id: int,
) -> dict:
    """Regenerate an action plan."""
    body: dict[str, Any] = {"partner_id": client.partner_id}
    return await client.post(f"/api/v2/action-plans/{plan_id}/regenerate", json=body)
