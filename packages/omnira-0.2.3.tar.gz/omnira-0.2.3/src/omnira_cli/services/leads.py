"""Leads service — list, get, create, fetch, enrichment, GTM, recruit search."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient, OmniraError


async def list_leads(
    client: OmniraClient,
    *,
    campaign_id: Optional[str] = None,
    fetch_id: Optional[str] = None,
    search: Optional[str] = None,
    has_email: Optional[bool] = None,
    has_mobile: Optional[bool] = None,
    enriched: Optional[bool] = None,
    limit: int = 50,
    offset: int = 0,
    sort_by: str = "created_at",
    sort_direction: str = "desc",
) -> dict:
    """List your leads with optional filters."""
    params: dict[str, Any] = {"limit": limit, "offset": offset}
    if campaign_id:
        params["campaign_id"] = campaign_id
    if fetch_id:
        params["fetch_id"] = fetch_id
    if search:
        params["search"] = search
    # Gateway returns {partner_id, leads: [...]}
    return await client.get(f"/api/partner/{client.partner_id}/leads", params=params)


async def get_lead(client: OmniraClient, lead_id: str) -> dict:
    """Get detailed lead information."""
    return await client.get(f"/api/partner/{client.partner_id}/leads/{lead_id}")


async def create_lead(
    client: OmniraClient,
    *,
    first_name: str,
    last_name: Optional[str] = None,
    email: Optional[str] = None,
    mobile_number: Optional[str] = None,
    job_title: Optional[str] = None,
    company_name: Optional[str] = None,
    industry: Optional[str] = None,
    city: Optional[str] = None,
    state: Optional[str] = None,
    linkedin: Optional[str] = None,
    campaign_id: Optional[int] = None,
) -> dict:
    """Create a single lead."""
    raise OmniraError(
        "NOT_AVAILABLE",
        "Lead creation not yet available via API.",
        "Use the Omnira dashboard or 'omnira leads fetch' for bulk import.",
    )


async def fetch_leads(
    client: OmniraClient,
    *,
    quantity: int,
    file_name: str,
    job_titles: Optional[list] = None,
    industries: Optional[list] = None,
    locations: Optional[list] = None,
    seniority: Optional[list] = None,
) -> dict:
    """Fetch leads in bulk (uses credits). Triggers a Temporal workflow."""
    body: dict[str, Any] = {"fetch_count": quantity, "file_name": file_name}
    if job_titles:
        body["contact_job_title"] = job_titles
    if industries:
        body["company_industry"] = industries
    if locations:
        body["contact_location"] = locations
    if seniority:
        body["seniority_level"] = seniority

    return await client.post(f"/api/partner/{client.partner_id}/fetch-leads", json=body)


async def list_fetch_requests(
    client: OmniraClient,
    *,
    status: Optional[str] = None,
    limit: int = 20,
    offset: int = 0,
) -> dict:
    """List fetch requests (bulk lead imports)."""
    params: dict[str, Any] = {"limit": limit, "offset": offset}
    if status:
        params["status"] = status
    return await client.get(f"/api/partner/{client.partner_id}/lead-lists", params=params)


async def get_fetch_request(
    client: OmniraClient,
    fetch_id: str,
    *,
    limit: int = 100,
    offset: int = 0,
) -> dict:
    """Get a fetch request with its progress."""
    return await client.get(
        f"/api/partner/{client.partner_id}/fetch-progress",
        params={"request_id": fetch_id},
    )


# ── Enrichment ────────────────────────────────────────────────────────────


async def re_enrich(
    client: OmniraClient,
    lead_ids: list[str],
    *,
    run_gtm: bool = True,
) -> dict:
    """Re-enrich leads with updated contact data."""
    body: dict[str, Any] = {
        "partner_id": client.partner_id,
        "lead_ids": lead_ids,
        "run_gtm": run_gtm,
    }
    return await client.post("/api/leads/re-enrich", json=body)


async def enrich_linkedin(
    client: OmniraClient,
    linkedin_url: str,
    *,
    offering_id: Optional[int] = None,
    run_gtm: bool = True,
) -> dict:
    """Enrich a lead from a LinkedIn profile URL."""
    body: dict[str, Any] = {
        "linkedin_url": linkedin_url,
        "partner_id": client.partner_id,
        "run_gtm": run_gtm,
    }
    if offering_id is not None:
        body["offering_id"] = offering_id
    return await client.post("/api/leads/enrich-linkedin", json=body)


async def gtm_enrich(
    client: OmniraClient,
    lead_ids: list[str],
    *,
    refresh_mode: str = "add_only",
) -> dict:
    """Run GTM intelligence enrichment on leads."""
    body: dict[str, Any] = {
        "partner_id": client.partner_id,
        "lead_ids": lead_ids,
        "refresh_mode": refresh_mode,
    }
    return await client.post("/api/gtm/enrich", json=body)


async def recruit_search(
    client: OmniraClient,
    *,
    job_description: str,
    metros: Optional[list[dict]] = None,
    keywords: Optional[list[str]] = None,
    fetch_count: int = 50,
    file_name: str = "Recruitment Leads",
) -> dict:
    """Search for recruit candidates by job description and location."""
    body: dict[str, Any] = {
        "partner_id": client.partner_id,
        "job_description": job_description,
        "fetch_count": fetch_count,
        "file_name": file_name,
    }
    if metros:
        body["metros"] = metros
    if keywords:
        body["keywords"] = keywords
    return await client.post("/api/leads/recruit-search", json=body)


async def recruit_natural(
    client: OmniraClient,
    *,
    prompt: str,
    fetch_count: int = 50,
) -> dict:
    """Search for recruits using natural language."""
    body: dict[str, Any] = {
        "partner_id": client.partner_id,
        "prompt": prompt,
        "fetch_count": fetch_count,
    }
    return await client.post("/api/leads/recruit-search/natural", json=body)


# ── Deal Outcomes ────────────────────────────────────────────────────────


async def mark_won(
    client: OmniraClient,
    lead_app_id: str,
) -> dict:
    """Mark a lead as won (closed deal)."""
    return await client.post(
        f"/api/v2/aria/partner/{client.partner_id}/leads/{lead_app_id}/mark-won",
        json={},
    )


async def mark_lost(
    client: OmniraClient,
    lead_app_id: str,
) -> dict:
    """Mark a lead as lost."""
    return await client.post(
        f"/api/v2/aria/partner/{client.partner_id}/leads/{lead_app_id}/mark-lost",
        json={},
    )


# ── Import & Enrichment ─────────────────────────────────────────────────


async def import_csv(
    client: OmniraClient,
    *,
    csv_data: list[dict],
    offering_id: Optional[int] = None,
) -> dict:
    """Import leads from CSV data."""
    body: dict[str, Any] = {
        "leads": csv_data,
    }
    if offering_id is not None:
        body["offering_id"] = offering_id
    return await client.post(
        f"/api/v2/aria/partner/{client.partner_id}/import-csv-leads",
        json=body,
    )


async def enrich_domain(
    client: OmniraClient,
    domain: str,
) -> dict:
    """Enrich leads by company domain."""
    body: dict[str, Any] = {"domain": domain}
    return await client.post(
        f"/api/v2/aria/partner/{client.partner_id}/enrich-domain",
        json=body,
    )


async def crawl_url(
    client: OmniraClient,
    url: str,
) -> dict:
    """Crawl a URL to extract business context."""
    body: dict[str, Any] = {"url": url}
    return await client.post(
        f"/api/v2/aria/partner/{client.partner_id}/crawl-url",
        json=body,
    )
