"""Sales config service — configure sales process steps, presets, schedules, and cycling."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient


async def get_sales_process(
    client: OmniraClient,
    offering_id: int,
) -> dict:
    """Get the full sales process configuration for an offering."""
    return await client.get(f"/api/sales-process/{offering_id}")


async def update_preset(
    client: OmniraClient,
    sales_process_id: int,
    preset: str,
) -> dict:
    """Update the step preset for a sales process.

    Common presets: 'aggressive', 'standard', 'gentle', 'custom'.
    """
    payload: dict[str, Any] = {"preset": preset}
    return await client.patch(
        f"/api/sales-process/{sales_process_id}/preset", json=payload
    )


async def update_schedule(
    client: OmniraClient,
    sales_process_id: int,
    *,
    timezone: Optional[str] = None,
    start_hour: Optional[int] = None,
    end_hour: Optional[int] = None,
    days: Optional[list[str]] = None,
) -> dict:
    """Update the sending schedule for a sales process."""
    payload: dict[str, Any] = {}
    if timezone:
        payload["timezone"] = timezone
    if start_hour is not None:
        payload["start_hour"] = start_hour
    if end_hour is not None:
        payload["end_hour"] = end_hour
    if days:
        payload["days"] = days
    return await client.patch(
        f"/api/sales-process/{sales_process_id}/schedule", json=payload
    )


async def update_cycling(
    client: OmniraClient,
    sales_process_id: int,
    *,
    enabled: Optional[bool] = None,
    max_cycles: Optional[int] = None,
    cooldown_days: Optional[int] = None,
) -> dict:
    """Update cycling configuration (re-engage leads after sequence completes)."""
    payload: dict[str, Any] = {}
    if enabled is not None:
        payload["enabled"] = enabled
    if max_cycles is not None:
        payload["max_cycles"] = max_cycles
    if cooldown_days is not None:
        payload["cooldown_days"] = cooldown_days
    return await client.patch(
        f"/api/sales-process/{sales_process_id}/cycling-config", json=payload
    )


async def update_step(
    client: OmniraClient,
    step_id: int,
    *,
    delay_hours: Optional[int] = None,
    channels: Optional[list[str]] = None,
    enabled: Optional[bool] = None,
) -> dict:
    """Update a single outreach step."""
    payload: dict[str, Any] = {}
    if delay_hours is not None:
        payload["delay_hours"] = delay_hours
    if channels:
        payload["channels"] = channels
    if enabled is not None:
        payload["enabled"] = enabled
    return await client.patch(f"/api/sales-process/steps/{step_id}", json=payload)


async def pre_launch_check(
    client: OmniraClient,
    offering_id: int,
) -> dict:
    """Run pre-launch validation for an offering's sales process."""
    return await client.get(
        f"/api/sales-process/pre-launch-check",
        params={"offering_id": offering_id, "partner_id": client.partner_id},
    )
