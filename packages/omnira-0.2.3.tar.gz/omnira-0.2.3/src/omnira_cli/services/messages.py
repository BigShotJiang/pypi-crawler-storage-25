"""Messages service — send SMS, email, and iMessage to leads."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient


async def send_sms(
    client: OmniraClient,
    lead_app_id: str,
    body: str,
    *,
    from_number: Optional[str] = None,
) -> dict:
    """Send an SMS to a lead.

    Uses the partner's Twilio phone pool. If from_number is not provided,
    the lead's assigned number (or a random pool number) is used.
    """
    payload: dict[str, Any] = {
        "lead_app_id": lead_app_id,
        "body": body,
    }
    if from_number:
        payload["from_number"] = from_number
    return await client.post("/api/sms/send", json=payload)


async def send_email(
    client: OmniraClient,
    lead_app_id: str,
    body: str,
    *,
    subject: Optional[str] = None,
) -> dict:
    """Send an email to a lead via the partner's connected Gmail.

    If subject is not provided, it continues the last email thread
    or defaults to "Following up".
    """
    payload: dict[str, Any] = {
        "lead_app_id": lead_app_id,
        "body": body,
    }
    if subject:
        payload["subject"] = subject
    return await client.post("/api/email/send", json=payload)


async def send_imessage(
    client: OmniraClient,
    lead_app_id: str,
    body: str,
) -> dict:
    """Send an iMessage to a lead.

    Requires iMessage to be enabled for the partner account.
    Automatically checks iMessage capability before sending.
    """
    payload: dict[str, Any] = {
        "lead_app_id": lead_app_id,
        "body": body,
    }
    return await client.post("/api/imessage/send", json=payload)


async def check_imessage(
    client: OmniraClient,
    phone: str,
) -> dict:
    """Check if a phone number supports iMessage."""
    return await client.get(f"/api/imessage/capability/{phone}")
