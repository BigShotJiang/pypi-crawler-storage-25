"""Aria service — chat with your AI business advisor."""

from __future__ import annotations

import asyncio
from typing import Optional

from omnira_cli.client import OmniraClient


async def send_message(
    client: OmniraClient,
    *,
    message: str,
    thread_id: Optional[str] = None,
) -> dict:
    """Send a message to Aria and poll for response.

    The assistant endpoint returns immediately with status "processing".
    We poll the thread history until Aria's response appears.
    """
    body = {
        "partner_id": client.partner_id,
        "message": message,
    }
    if thread_id:
        body["thread_id"] = thread_id

    # Send message (returns immediately)
    result = await client.post("/api/assistant/message", json=body)
    tid = result.get("thread_id", "")
    title = result.get("thread_title", "")

    if not tid:
        return {"response": result.get("response", ""), "thread_id": "", "thread_title": ""}

    # If response came back immediately (non-processing), return it
    if result.get("status") != "processing" and result.get("response"):
        return {"response": result["response"], "thread_id": tid, "thread_title": title}

    # Poll for response — check thread history for assistant reply
    for attempt in range(90):  # 90 second timeout
        await asyncio.sleep(1)
        try:
            history = await client.get(
                f"/api/assistant/threads/{tid}/history",
                params={"partner_id": client.partner_id},
            )
            messages = history.get("messages", history.get("history", []))
            if messages and messages[-1].get("role") == "assistant":
                return {
                    "response": messages[-1].get("content", ""),
                    "thread_id": tid,
                    "thread_title": title,
                }
        except Exception:
            pass  # Retry on transient errors

    return {
        "response": "(Aria is still thinking... try `omnira aria --thread {tid}` to check later)",
        "thread_id": tid,
        "thread_title": title,
    }


async def list_threads(
    client: OmniraClient,
) -> dict:
    """List chat threads for the current partner."""
    return await client.get(
        "/api/assistant/threads",
        params={"partner_id": client.partner_id},
    )
