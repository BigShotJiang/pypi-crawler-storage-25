"""Pipeline service — manage sales pipeline stages and lead progression."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient


async def list_stages(client: OmniraClient, *, offering_id: int) -> dict:
    """List all pipeline stages for an offering."""
    return await client.get(
        "/api/pipeline/stages",
        params={"partner_id": client.partner_id, "offering_id": offering_id},
    )


async def create_stage(
    client: OmniraClient,
    *,
    name: str,
    position: Optional[int] = None,
    color: Optional[str] = None,
) -> dict:
    """Create a new pipeline stage."""
    payload: dict[str, Any] = {
        "partner_id": client.partner_id,
        "name": name,
    }
    if position is not None:
        payload["position"] = position
    if color:
        payload["color"] = color
    return await client.post("/api/pipeline/stages", json=payload)


async def update_stage(
    client: OmniraClient,
    stage_id: str,
    *,
    name: Optional[str] = None,
    position: Optional[int] = None,
    color: Optional[str] = None,
) -> dict:
    """Update a pipeline stage."""
    payload: dict[str, Any] = {}
    if name:
        payload["name"] = name
    if position is not None:
        payload["position"] = position
    if color:
        payload["color"] = color
    return await client.patch(f"/api/pipeline/stages/{stage_id}", json=payload)


async def list_leads(
    client: OmniraClient,
    *,
    stage_id: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> dict:
    """List leads in the pipeline, optionally filtered by stage."""
    params: dict[str, Any] = {
        "partner_id": client.partner_id,
        "limit": limit,
        "offset": offset,
    }
    if stage_id:
        params["stage_id"] = stage_id
    return await client.get("/api/pipeline/leads", params=params)


async def summary(client: OmniraClient) -> dict:
    """Get pipeline summary with counts per stage."""
    return await client.get(
        "/api/pipeline/summary",
        params={"partner_id": client.partner_id},
    )


async def move_lead(
    client: OmniraClient,
    lead_db_id: str,
    stage_id: str,
) -> dict:
    """Move a lead to a different pipeline stage."""
    payload: dict[str, Any] = {
        "partner_id": client.partner_id,
        "stage_id": stage_id,
    }
    return await client.patch(f"/api/pipeline/leads/{lead_db_id}/stage", json=payload)
