"""Assets service — list, get, deploy, preview, status, delete."""

from __future__ import annotations

from typing import Optional

from omnira_cli.client import OmniraClient


async def list_assets(client: OmniraClient) -> dict:
    """List all your assets.

    Returns list of assets with status, type, and URLs.
    """
    return await client.get(f"/api/asset/partner/{client.partner_id}")


async def get_asset(client: OmniraClient, asset_id: int) -> dict:
    """Get detailed asset information.

    Args:
        asset_id: The asset ID.

    Returns asset detail including status, version, URLs, and config.
    """
    return await client.get(f"/api/asset/{asset_id}")


async def deploy_asset(
    client: OmniraClient,
    *,
    offering_id: int,
    asset_type: str = "static",
    name: Optional[str] = None,
) -> dict:
    """Create and build a new asset.

    Args:
        offering_id: The offering to link the asset to.
        asset_type: Asset type (static, landing_page, etc.).
        name: Optional asset name.

    Returns created asset with build workflow ID.
    """
    create_result = await client.post(
        "/api/asset",
        json={
            "partner_id": client.partner_id,
            "offering_id": offering_id,
            "asset_type": asset_type,
            **({"name": name} if name else {}),
        },
    )

    asset_id = create_result.get("id") or create_result.get("asset_id")
    if not asset_id:
        return create_result

    build_result = await client.post(f"/api/asset/{asset_id}/build")
    return {**create_result, "build": build_result}


async def preview_asset(client: OmniraClient, asset_id: int) -> dict:
    """Get preview URL for an asset.

    Args:
        asset_id: The asset ID.

    Returns preview URL.
    """
    asset = await client.get(f"/api/asset/{asset_id}")
    return {"asset_id": asset_id, "preview_url": f"/api/asset/{asset_id}/preview", "asset": asset}


async def asset_status(client: OmniraClient, asset_id: int) -> dict:
    """Check build status of an asset.

    Args:
        asset_id: The asset ID.

    Returns build status (pending, building, complete, failed).
    """
    return await client.get(f"/api/asset/{asset_id}/build/status")


async def delete_asset(client: OmniraClient, asset_id: int) -> dict:
    """Delete an asset.

    Args:
        asset_id: The asset ID.

    Returns deletion confirmation.
    """
    return await client.delete(f"/api/asset/{asset_id}")
