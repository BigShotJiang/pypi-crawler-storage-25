"""Agent setup service — install/uninstall the omnira skill into a Claude Code project.

This is a local-only service. It doesn't talk to the Omnira API. It detects whether
the user is in a project directory or wants global install, then writes a SKILL.md
and CLAUDE.md fragment so Claude Code (and similar agents) can discover the CLI.

Layout it produces:

  <target>/.claude/skills/omnira/SKILL.md       (the bundled skill template)
  <target>/CLAUDE.md                             (project) — appended with omnira section
  ~/.claude/CLAUDE.md                            (global) — appended with omnira section
"""

from __future__ import annotations

import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

SECTION_MARKER_START = "<!-- omnira-cli:start -->"
SECTION_MARKER_END = "<!-- omnira-cli:end -->"

MCP_CONFIG_FILENAME = "mcp_servers.json"
MCP_SERVER_NAME = "omnira"
MCP_SERVER_ENTRY = {
    "command": "omnira",
    "args": ["mcp", "serve"],
}


@dataclass
class InstallResult:
    """Result of an `omnira agent install` operation."""

    target: Path
    scope: str  # "project" or "global"
    skill_path: Path
    claude_md_path: Path
    mcp_config_path: Path
    skill_action: str  # "created", "updated", "unchanged"
    claude_md_action: str  # "created", "updated", "unchanged"
    mcp_action: str  # "created", "updated", "unchanged"


def _bundled_template_dir() -> Path:
    """Return the directory containing the bundled skill template files.

    Resolved relative to this module so it works whether installed via wheel
    or editable install.
    """
    return Path(__file__).resolve().parent.parent / "skill_template"


def _read_bundled(filename: str) -> str:
    """Read a file from the bundled skill template directory."""
    path = _bundled_template_dir() / filename
    if not path.exists():
        raise FileNotFoundError(
            f"Bundled template file not found: {path}. "
            "Reinstall omnira if you see this — the package may be corrupted."
        )
    return path.read_text(encoding="utf-8")


def detect_target(
    *,
    cwd: Optional[Path] = None,
    force_global: bool = False,
    force_project: Optional[Path] = None,
) -> tuple[Path, str]:
    """Decide where to install the agent skill.

    Resolution order:
    1. force_project (explicit --project flag) → use that path, scope="project"
    2. force_global (--global flag) → ~/.claude, scope="global"
    3. Auto-detect: if cwd is a project (has .claude/, CLAUDE.md, or .git/),
       use cwd as project root, scope="project"
    4. Fall back to ~/.claude, scope="global"

    Returns (target_path, scope).
    """
    if force_project is not None:
        return force_project.resolve(), "project"

    if force_global:
        return Path.home() / ".claude", "global"

    cwd = (cwd or Path.cwd()).resolve()

    # Walk up to find a project root (git repo, .claude/, or CLAUDE.md)
    for candidate in [cwd, *cwd.parents]:
        if (candidate / ".claude").exists():
            return candidate, "project"
        if (candidate / "CLAUDE.md").exists():
            return candidate, "project"
        if (candidate / ".git").exists():
            return candidate, "project"

    # Fall back to global
    return Path.home() / ".claude", "global"


def _skill_paths(target: Path, scope: str) -> tuple[Path, Path]:
    """Return (skill_dir, claude_md_path) for a given target.

    For project scope: <target>/.claude/skills/omnira/SKILL.md and <target>/CLAUDE.md
    For global scope: ~/.claude/skills/omnira/SKILL.md and ~/.claude/CLAUDE.md
    """
    if scope == "project":
        skill_path = target / ".claude" / "skills" / "omnira" / "SKILL.md"
        claude_md = target / "CLAUDE.md"
    else:  # global
        # target is already ~/.claude
        skill_path = target / "skills" / "omnira" / "SKILL.md"
        claude_md = target / "CLAUDE.md"
    return skill_path, claude_md


def _mcp_config_path(target: Path, scope: str) -> Path:
    """Return the MCP config file path for Claude Code.

    Project scope: <target>/.claude/mcp_servers.json
    Global scope: ~/.claude/mcp_servers.json (target is already ~/.claude)
    """
    if scope == "project":
        return target / ".claude" / MCP_CONFIG_FILENAME
    return target / MCP_CONFIG_FILENAME


def _write_skill(skill_path: Path, content: str) -> str:
    """Write the SKILL.md to disk. Returns 'created', 'updated', or 'unchanged'."""
    skill_path.parent.mkdir(parents=True, exist_ok=True)

    if skill_path.exists():
        existing = skill_path.read_text(encoding="utf-8")
        if existing == content:
            return "unchanged"
        skill_path.write_text(content, encoding="utf-8")
        return "updated"

    skill_path.write_text(content, encoding="utf-8")
    return "created"


def _build_section(snippet_body: str) -> str:
    body = snippet_body.strip()
    return f"{SECTION_MARKER_START}\n{body}\n{SECTION_MARKER_END}\n"


def _strip_section(content: str) -> Optional[tuple[str, str]]:
    """Find the omnira marker section in `content` and return `(before, after)`.

    Returns None if the section is not present (or markers are malformed —
    END must come after START to count as a valid section).
    """
    start_idx = content.find(SECTION_MARKER_START)
    if start_idx == -1:
        return None
    end_idx = content.find(SECTION_MARKER_END, start_idx)
    if end_idx == -1:
        return None
    before = content[:start_idx].rstrip()
    after = content[end_idx + len(SECTION_MARKER_END):].lstrip()
    return before, after


def _write_claude_md(claude_md_path: Path, snippet_body: str) -> str:
    """Append or update the omnira section in CLAUDE.md.

    Idempotent. Returns 'created', 'updated', or 'unchanged'.
    """
    new_section = _build_section(snippet_body)
    claude_md_path.parent.mkdir(parents=True, exist_ok=True)

    if not claude_md_path.exists():
        claude_md_path.write_text(new_section, encoding="utf-8")
        return "created"

    existing = claude_md_path.read_text(encoding="utf-8")
    stripped = _strip_section(existing)

    if stripped is not None:
        before, after = stripped
        parts = [p for p in (before, new_section.rstrip(), after) if p]
        new_content = "\n\n".join(parts) + "\n"
    else:
        sep = "" if existing.endswith("\n\n") else ("\n" if existing.endswith("\n") else "\n\n")
        new_content = existing + sep + new_section

    if new_content == existing:
        return "unchanged"
    claude_md_path.write_text(new_content, encoding="utf-8")
    return "updated"


def _write_mcp_config(mcp_path: Path) -> str:
    """Merge the omnira MCP server entry into Claude Code's mcp_servers.json.

    Idempotent. Preserves other MCP server entries.
    Returns 'created', 'updated', or 'unchanged'.
    """
    mcp_path.parent.mkdir(parents=True, exist_ok=True)

    config: dict = {"mcpServers": {}}
    created = not mcp_path.exists()
    if not created:
        try:
            config = json.loads(mcp_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            config = {"mcpServers": {}}

    if "mcpServers" not in config:
        config["mcpServers"] = {}

    existing = config["mcpServers"].get(MCP_SERVER_NAME)
    if existing == MCP_SERVER_ENTRY:
        return "unchanged"

    config["mcpServers"][MCP_SERVER_NAME] = MCP_SERVER_ENTRY
    mcp_path.write_text(
        json.dumps(config, indent=2) + "\n", encoding="utf-8",
    )
    return "created" if created else "updated"


def install(
    *,
    cwd: Optional[Path] = None,
    force_global: bool = False,
    force_project: Optional[Path] = None,
) -> InstallResult:
    """Install the omnira skill + MCP server config into a Claude Code project.

    Writes three things (idempotently):
      1. SKILL.md under .claude/skills/omnira/
      2. Omnira section appended/merged into CLAUDE.md
      3. Omnira entry in .claude/mcp_servers.json (so Claude Code auto-starts
         the MCP server on next session)

    Safe to run multiple times.
    """
    target, scope = detect_target(
        cwd=cwd,
        force_global=force_global,
        force_project=force_project,
    )

    skill_path, claude_md_path = _skill_paths(target, scope)
    mcp_path = _mcp_config_path(target, scope)

    skill_content = _read_bundled("SKILL.md")
    snippet_body = _read_bundled("CLAUDE.md.snippet")

    skill_action = _write_skill(skill_path, skill_content)
    claude_md_action = _write_claude_md(claude_md_path, snippet_body)
    mcp_action = _write_mcp_config(mcp_path)

    return InstallResult(
        target=target,
        scope=scope,
        skill_path=skill_path,
        claude_md_path=claude_md_path,
        mcp_config_path=mcp_path,
        skill_action=skill_action,
        claude_md_action=claude_md_action,
        mcp_action=mcp_action,
    )


def _remove_mcp_entry(mcp_path: Path) -> bool:
    """Remove the omnira entry from mcp_servers.json, keeping other entries.

    If omnira was the only entry, remove the file entirely. Returns True if
    something was removed.
    """
    if not mcp_path.exists():
        return False
    try:
        config = json.loads(mcp_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return False

    servers = config.get("mcpServers", {})
    if MCP_SERVER_NAME not in servers:
        return False

    del servers[MCP_SERVER_NAME]

    if servers:
        config["mcpServers"] = servers
        mcp_path.write_text(
            json.dumps(config, indent=2) + "\n", encoding="utf-8",
        )
    else:
        # No other entries — remove the file
        mcp_path.unlink()
    return True


def uninstall(
    *,
    cwd: Optional[Path] = None,
    force_global: bool = False,
    force_project: Optional[Path] = None,
) -> dict:
    """Remove the omnira skill, CLAUDE.md section, and MCP config entry.

    Preserves other MCP servers if present.
    """
    target, scope = detect_target(
        cwd=cwd,
        force_global=force_global,
        force_project=force_project,
    )

    skill_path, claude_md_path = _skill_paths(target, scope)
    mcp_path = _mcp_config_path(target, scope)
    skill_dir = skill_path.parent

    removed_skill = False
    if skill_dir.exists():
        shutil.rmtree(skill_dir)
        removed_skill = True

    removed_section = False
    if claude_md_path.exists():
        existing = claude_md_path.read_text(encoding="utf-8")
        stripped = _strip_section(existing)
        if stripped is not None:
            before, after = stripped
            parts = [p for p in (before, after) if p]
            if parts:
                claude_md_path.write_text("\n\n".join(parts) + "\n", encoding="utf-8")
            else:
                # CLAUDE.md contained only the omnira section — remove the empty file
                claude_md_path.unlink()
            removed_section = True

    removed_mcp = _remove_mcp_entry(mcp_path)

    return {
        "target": str(target),
        "scope": scope,
        "removed_skill": removed_skill,
        "removed_section": removed_section,
        "removed_mcp": removed_mcp,
    }


def status(
    *,
    cwd: Optional[Path] = None,
    force_global: bool = False,
    force_project: Optional[Path] = None,
) -> dict:
    """Report the install state at a target (skill + CLAUDE.md + MCP config)."""
    target, scope = detect_target(
        cwd=cwd,
        force_global=force_global,
        force_project=force_project,
    )
    skill_path, claude_md_path = _skill_paths(target, scope)
    mcp_path = _mcp_config_path(target, scope)

    skill_installed = skill_path.exists()
    section_installed = False
    if claude_md_path.exists():
        section_installed = _strip_section(claude_md_path.read_text(encoding="utf-8")) is not None

    mcp_installed = False
    if mcp_path.exists():
        try:
            config = json.loads(mcp_path.read_text(encoding="utf-8"))
            mcp_installed = MCP_SERVER_NAME in config.get("mcpServers", {})
        except json.JSONDecodeError:
            pass

    return {
        "target": str(target),
        "scope": scope,
        "skill_path": str(skill_path),
        "skill_installed": skill_installed,
        "claude_md_path": str(claude_md_path),
        "section_installed": section_installed,
        "mcp_config_path": str(mcp_path),
        "mcp_installed": mcp_installed,
    }
