"""Offerings service — manage your products/services for outreach."""

from __future__ import annotations

from typing import Any, Optional

from omnira_cli.client import OmniraClient


async def list_offerings(client: OmniraClient) -> dict:
    """List all offerings for the partner."""
    return await client.get(
        "/api/offerings",
        params={"partner_id": client.partner_id},
    )


async def get_offering(client: OmniraClient, offering_id: int) -> dict:
    """Get detailed offering information including sales process."""
    return await client.get(f"/api/sales-process/{offering_id}")


async def create_offering(
    client: OmniraClient,
    *,
    name: str,
    description: Optional[str] = None,
    offering_type: Optional[str] = None,
) -> dict:
    """Create a new offering."""
    payload: dict[str, Any] = {
        "partner_id": client.partner_id,
        "name": name,
    }
    if description:
        payload["description"] = description
    if offering_type:
        payload["offering_type"] = offering_type
    return await client.post("/api/offerings", json=payload)


async def update_offering(
    client: OmniraClient,
    offering_id: int,
    *,
    name: Optional[str] = None,
    description: Optional[str] = None,
) -> dict:
    """Update an existing offering."""
    payload: dict[str, Any] = {"partner_id": client.partner_id}
    if name:
        payload["name"] = name
    if description:
        payload["description"] = description
    return await client.patch(f"/api/offerings/{offering_id}", json=payload)


async def delete_offering(client: OmniraClient, offering_id: int) -> dict:
    """Delete an offering."""
    return await client.delete(f"/api/offerings/{offering_id}")


async def initialize_offering(client: OmniraClient, offering_id: int) -> dict:
    """Initialize an offering (generate sales process, skeletons, etc.)."""
    return await client.post(
        f"/api/offerings/{offering_id}/initialize",
        json={"partner_id": client.partner_id},
    )


async def pause_offering(
    client: OmniraClient,
    offering_id: int,
) -> dict:
    """Pause all outreach for an offering."""
    return await client.post(
        f"/api/v2/aria/partner/{client.partner_id}/offerings/{offering_id}/pause",
        json={},
    )


async def resume_offering(
    client: OmniraClient,
    offering_id: int,
) -> dict:
    """Resume outreach for a paused offering."""
    return await client.post(
        f"/api/v2/aria/partner/{client.partner_id}/offerings/{offering_id}/resume",
        json={},
    )


async def assign_leads(
    client: OmniraClient,
    offering_id: int,
    lead_ids: list[str],
) -> dict:
    """Assign leads to an offering."""
    payload: dict[str, Any] = {
        "partner_id": client.partner_id,
        "lead_ids": lead_ids,
    }
    return await client.post(f"/api/offerings/{offering_id}/leads/assign", json=payload)


async def list_offering_leads(
    client: OmniraClient,
    offering_id: int,
    *,
    limit: int = 50,
    offset: int = 0,
) -> dict:
    """List leads assigned to an offering."""
    return await client.get(
        f"/api/offerings/{offering_id}/leads",
        params={"partner_id": client.partner_id, "limit": limit, "offset": offset},
    )
