---
name: omnira
description: Operate an Omnira partner account from the command line. Manage leads, offerings, sales pipeline, AI message approvals, and outreach. Use this skill when the user asks anything about their Omnira leads, campaigns, pipeline, conversations, or outreach.
---

# Omnira CLI

You have access to the `omnira` CLI, which gives you full control of the user's Omnira Lead Engagement Platform account. Use it whenever the user asks about leads, offerings, outreach, pipeline, conversations, or AI message approvals.

## Two Ways to Use These Tools

If `omnira agent install` has been run in this project (or globally), you have **two** ways to operate the user's account:

1. **MCP tools (preferred)** — Native tools with typed schemas, named `omnira__<function>` (e.g. `omnira__list_leads`, `omnira__send_sms`, `omnira__hitl_approve`). These are faster, give you structured inputs/outputs, and avoid shell parsing. Prefer these whenever they're available.
2. **CLI fallback** — Shell out to `omnira <command>` (described in this skill). Use when an MCP tool isn't available or when the user explicitly asks to see the command.

Both paths hit the same API and respect the same partner authentication. The ID system, safety rules, and workflow recipes in this skill apply to both.

## Getting Started

Before using the CLI (or MCP tools), verify the user is authenticated:

```bash
omnira account
```

If this fails with `UNAUTHORIZED`, the user needs to run `omnira login` and paste their API key from **Settings → API** in the Omnira dashboard. Do not attempt to log them in yourself — only the user can paste a key.

Once authenticated, every CLI command supports `--help` to show its options. Use `--help` whenever you're unsure:

```bash
omnira leads --help
omnira leads list --help
```

## Output Format

Always use `--output json` (or `-o json`) when reading data so you can parse it reliably:

```bash
omnira leads list -o json
```

All responses follow this envelope:

```json
{"success": true, "data": {...}, "meta": {"count": 10, "total": 150}}
```

Errors:

```json
{"success": false, "error": {"code": "NOT_FOUND", "message": "...", "suggestion": "..."}}
```

## Command Groups

| Group | What it does |
|---|---|
| `omnira account` | Account balance, credits, partner info, authentication check |
| `omnira leads` | List, view, create, fetch, enrich, mark won/lost |
| `omnira offerings` | Manage products/services, generate sales processes |
| `omnira outreach` | Launch campaigns, pause, force step, view conversations |
| `omnira pipeline` | Pipeline stages, lead progression, summary |
| `omnira hitl` | Review and approve AI-drafted messages |
| `omnira messages` | Send manual SMS, email, or iMessage |
| `omnira sales-config` | Configure sales process steps, timing, cycling |
| `omnira content` | Manage outreach message templates |
| `omnira plans` | List, approve, regenerate AI action plans |
| `omnira morning` | Daily stats, unanswered replies |
| `omnira aria` | Chat with the Aria AI business advisor |
| `omnira assets` | Manage AI-generated landing pages |
| `omnira calendar` | Calendar connection, events, sync |
| `omnira contacts` | Create and update contacts |

Run `omnira <group> --help` to see all subcommands in a group.

## ID System (Critical)

Omnira uses two different lead IDs. **Confusing them will cause silent failures or actions on the wrong lead.**

| ID | Format | Used by |
|---|---|---|
| **lead_app_id** | UUID | `messages`, `hitl`, `outreach conversations`, `outreach journey`, `leads mark-won/lost`, `contacts update` |
| **lead_database_id** (a.k.a. `contact_id`) | UUID | `leads enrich`, `leads gtm`, `pipeline move` |
| **offering_id** | Integer | `offerings`, `content`, `sales-config`, `outreach launch` |
| **sales_process_id** | Integer | `sales-config preset/schedule/cycling` |
| **approval_token** | String | `hitl approve/reject/edit` |

**How to find the right ID:**

```bash
# lead_app_id and lead_database_id from a search
omnira leads list --search "John Smith" -o json
# → data.leads[].id is the lead_app_id
# → data.leads[].lead_database.id (or .leadId) is the lead_database_id

# offering_id
omnira offerings list -o json
# → data[].id

# sales_process_id from an offering
omnira sales-config get OFFERING_ID -o json
# → data.sales_process.id

# approval_token
omnira hitl list -o json
# → data[].approval_token
```

**Never guess or fabricate IDs.** Always look them up first with a list command.

## Workflow Recipes

### Morning Review

Check what needs attention, then act on it.

```bash
omnira morning replies -o json                # unanswered replies
omnira hitl list -o json                      # pending AI message approvals
omnira plans list --status pending -o json    # pending action plans
```

For each item, fetch context before acting:

```bash
omnira outreach conversations <lead_app_id> -o json
```

### Approve, Edit, or Reject AI Messages

```bash
# 1. List pending — the response includes the proposed message text
omnira hitl list -o json

# 2. Show the user the proposed message and ask for confirmation
# 3. Then act:
omnira hitl approve <token>
omnira hitl edit <token> "Modified version"
omnira hitl reject <token> --reason "Too aggressive"
```

### Set Up a New Offering and Launch Outreach

```bash
# 1. Create the offering
omnira offerings create "HVAC Maintenance Plans" --description "Seasonal tune-ups for homeowners"

# 2. Initialize — generates sales process + message templates
omnira offerings initialize <offering_id>

# 3. Review templates
omnira content list <offering_id> -o json

# 4. Customize a template if needed
omnira content update <skeleton_id> --body "New message text"

# 5. Configure timing
omnira sales-config get <offering_id> -o json
omnira sales-config preset <sales_process_id> standard
omnira sales-config schedule <sales_process_id> --start 9 --end 17

# 6. Assign leads
omnira offerings assign-leads <offering_id> --lead-ids "id1,id2,id3"

# 7. Pre-launch check
omnira sales-config pre-launch-check <offering_id> -o json

# 8. Launch
omnira outreach launch --offering-id <offering_id> --lead-ids "id1,id2,id3"

# 9. Monitor
omnira outreach launch-status <launch_id>
```

### Send a Manual Follow-Up

```bash
# 1. Find the lead
omnira leads list --search "acme" -o json

# 2. Read conversation history first
omnira outreach conversations <lead_app_id> -o json

# 3. Check best channel
omnira messages imessage-check "+15551234567"

# 4. Show the user your draft message and ask before sending
# 5. Then send via the best channel:
omnira messages imessage <lead_app_id> "..."
omnira messages sms <lead_app_id> "..."
omnira messages email <lead_app_id> "..." --subject "..."
```

### Close a Won Deal

```bash
# 1. Find the lead
omnira leads list --search "John" -o json

# 2. Move to closed-won stage
omnira pipeline stages -o json                        # find the won stage ID
omnira pipeline move <lead_database_id> --stage <won_stage_id>

# 3. Mark as won
omnira leads mark-won <lead_app_id>
```

### Bulk Import Leads

```bash
# From a CSV
omnira leads import-csv ./leads.csv --offering-id 42

# Enrich an existing company by domain
omnira leads enrich-domain "acme.com"

# Crawl a company website for context
omnira leads crawl-url "https://acme.com/about"
```

### Fetch New Leads (Uses Credits)

```bash
# Always check credits first
omnira account -o json

# Then fetch
omnira leads fetch --quantity 50 --name "Q2 dental owners" \
    --titles "Owner,CEO,Practice Manager" \
    --industries "Dental practice"
```

## Safety Rules

Follow these without exception when operating on the user's behalf:

1. **Always confirm before sending messages.** Never auto-send SMS, email, or iMessage. Show the user the exact draft text and wait for explicit approval.
2. **Always confirm before approving HITL items.** Show the user the proposed AI message before running `hitl approve`.
3. **Always read context before acting on a lead.** Run `outreach conversations <lead_app_id>` before sending a follow-up.
4. **Check credits before bulk operations.** Run `omnira account` before `leads fetch` or large enrichment runs.
5. **Never launch outreach without `pre-launch-check`.** Skipping this can ship broken templates or untargeted leads.
6. **Use `-o json` for all reads.** Never guess or fabricate IDs — always look them up.
7. **Don't delete offerings, pipeline stages, or assets without confirmation.** These are destructive.
8. **Respect rate limits.** The API allows ~600 requests/minute. Pace bulk operations.

## Error Recovery

| Error code | Meaning | What to do |
|---|---|---|
| `UNAUTHORIZED` | API key missing or revoked | Tell the user to run `omnira login` |
| `FORBIDDEN` | Key lacks permission for this resource | Tell the user to check their account access |
| `NOT_FOUND` | Wrong ID or resource doesn't exist | Re-run a list command to find the correct ID |
| `VALIDATION_ERROR` | Bad request parameters | Re-read the command's `--help` to find the right shape |
| `RATE_LIMITED` | Too many requests | Wait 60 seconds and retry, or batch operations |
| `CONNECTION_ERROR` | Can't reach the API | Tell the user to check their network |

## Configuration

Config file: `~/.omnira/config.toml`

```toml
[default]
api_url = "https://api.omnira.so"
api_key = "propello_..."
```

Multiple profiles are supported:

```bash
omnira --profile staging leads list
```

Environment variables override config:

- `OMNIRA_API_KEY`
- `OMNIRA_API_URL`
- `OMNIRA_PROFILE`
- `OMNIRA_OUTPUT` (`auto`, `json`, `table`, `plain`)
