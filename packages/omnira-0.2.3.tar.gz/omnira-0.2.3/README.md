# Omnira CLI

The command-line interface for the [Omnira Lead Engagement Platform](https://omnira.so). Manage your leads, offerings, sales pipeline, and AI-driven outreach from your terminal — built for both human use and AI agent integration (Claude Code, OpenClaw).

## Install

```bash
uv tool install omnira
```

Or with pipx:

```bash
pipx install omnira
```

Then authenticate with your Omnira API key — generate one at [omnira.so/settings/api](https://omnira.so/settings/api):

```bash
omnira login
```

### Upgrade

```bash
uv tool upgrade omnira    # if installed with uv
pipx upgrade omnira       # if installed with pipx
```

## Quick Start

```bash
omnira account                     # confirm authentication, see credits
omnira leads list                  # see your leads
omnira offerings list              # see your products/services
omnira pipeline summary            # pipeline overview
omnira hitl list                   # pending AI message approvals
```

Every command supports `--help` to discover its options:

```bash
omnira leads --help
omnira leads list --help
```

## Use With AI Agents

The CLI is designed to be operated by AI agents like Claude Code. To set up an agent integration:

```bash
omnira agent install
```

This installs three things so Claude Code can operate your Omnira account with zero additional configuration:

1. A **skill file** at `.claude/skills/omnira/SKILL.md` (command reference, ID system, workflow recipes)
2. An **MCP server entry** in `.claude/mcp_servers.json` that auto-starts `omnira mcp serve` on the next Claude Code session
3. A **CLAUDE.md section** pointing the agent at both

Pass `--global` to install to `~/.claude` instead of the current project.

Restart Claude Code, and the agent will have ~90 typed MCP tools for every CLI capability (leads, offerings, outreach, pipeline, HITL, messages, sales config, content, plans, morning, aria, assets, calendar, contacts). The agent can also shell out to `omnira <command>` when it prefers — both paths hit the same API with the same partner auth.

Try asking:

> "List my pending HITL messages and tell me which to approve"

### MCP Server (Advanced)

If you want to run the MCP server manually (e.g. for a non-Claude-Code agent, or for testing):

```bash
omnira mcp serve                         # stdio transport (default)
omnira mcp serve --transport http --port 8087   # HTTP transport
omnira mcp list-tools                    # show all registered tools
```

## What You Can Do

- **Leads** — list, create, fetch new leads, enrich with GTM data, mark won/lost
- **Offerings** — manage products/services, generate sales processes, configure templates
- **Outreach** — launch campaigns, pause/resume, force steps, view conversations
- **Pipeline** — create stages, move leads, view summary
- **HITL** — review, approve, edit, or reject AI-generated messages
- **Messages** — send SMS, email, and iMessage manually
- **Action Plans** — review and approve AI-suggested next actions
- **Calendar** — manage appointments and availability
- **Aria** — chat with your AI business advisor

Run `omnira --help` to see all command groups.

## Documentation

Full customer-facing docs live in [docs/](docs/):

- **[Getting started](docs/getting-started.md)** — install, API key, first commands.
- **[Command reference](docs/command-reference.md)** — every command with syntax and examples.
- **[Workflows](docs/workflows.md)** — end-to-end recipes (morning review, launching outreach, closing deals, bulk enrichment).
- **[Troubleshooting](docs/troubleshooting.md)** — error codes, safety checklist, credit/rate-limit guidance.

## Output Formats

By default, output is formatted as a rich table when running interactively, or as JSON when piped:

```bash
omnira leads list                  # table view
omnira leads list -o json          # explicit JSON
omnira leads list | jq '.data.leads[].email'   # auto-detects pipe → JSON
```

## Configuration

Configuration is stored in `~/.omnira/config.toml`. You can manage multiple profiles:

```bash
omnira --profile staging login
omnira --profile staging leads list
```

Environment variables override config file values:

- `OMNIRA_API_KEY` — your API key
- `OMNIRA_API_URL` — gateway URL (defaults to `https://api.omnira.so`)
- `OMNIRA_PROFILE` — active profile name
- `OMNIRA_OUTPUT` — output format (`auto`, `json`, `table`, `plain`)

## Support

- Dashboard: [omnira.so](https://omnira.so)
- API keys: [omnira.so/settings/api](https://omnira.so/settings/api)
- PyPI: [pypi.org/project/omnira](https://pypi.org/project/omnira)
- Issues: support@omnirasystems.com

## License

Proprietary. © Omnira.
