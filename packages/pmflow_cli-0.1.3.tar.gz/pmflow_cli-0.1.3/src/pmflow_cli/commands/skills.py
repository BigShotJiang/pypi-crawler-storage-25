"""Install/uninstall pmflow Claude Code skills and Codex prompts."""

import re
import shutil
from pathlib import Path

import typer
from rich.table import Table

from pmflow_cli.output import console

app = typer.Typer(help="Manage Claude Code skills and Codex prompts")

SKILLS_SOURCE = Path(__file__).parent.parent / "skills"

# Claude Code target
COMMANDS_TARGET = Path.home() / ".claude" / "commands" / "pmflow"

# Codex target
CODEX_TARGET = Path.home() / ".codex" / "prompts"

SKILL_NAMES = ["plan-space", "plan-task", "prd", "prdfix", "snapshot-space"]

# Argument hints for Codex prompts (derived from each skill's usage)
_ARGUMENT_HINTS: dict[str, str] = {
    "plan-space": "{slug}",
    "plan-task": "{slug}-{seq_num}",
    "prd": "功能描述",
    "prdfix": "{slug}-{seq_num}",
    "snapshot-space": "{slug}",
}

# Legacy install path (pre-v0.2), cleaned up on install/uninstall
_LEGACY_TARGET = Path.home() / ".claude" / "skills"


def _clean_legacy():
    """Remove skills installed to the old ~/.claude/skills/ location."""
    for name in SKILL_NAMES:
        legacy = _LEGACY_TARGET / f"pmflow-{name}"
        if legacy.exists():
            shutil.rmtree(legacy)


def _convert_to_codex_prompt(skill_md: str, name: str) -> str:
    """Convert a Claude Code SKILL.md to a Codex-compatible prompt.

    Replaces the Claude Code frontmatter (name/description/user-invocable)
    with Codex frontmatter (description/argument-hint), keeping the body as-is.
    """
    # Split frontmatter and body
    match = re.match(r"^---\n(.*?)\n---\n(.*)", skill_md, re.DOTALL)
    if not match:
        return skill_md

    frontmatter_text = match.group(1)
    body = match.group(2)

    # Extract description from original frontmatter
    desc_match = re.search(r"^description:\s*(.+)$", frontmatter_text, re.MULTILINE)
    # Use first sentence of description (before "用法：")
    description = desc_match.group(1).strip() if desc_match else name
    description = re.split(r"[。.]?用法[：:]", description)[0].rstrip("。. ")

    hint = _ARGUMENT_HINTS.get(name, "")

    lines = [
        "---",
        f"description: {description}",
    ]
    if hint:
        lines.append(f"argument-hint: {hint}")
    lines.append("---")

    return "\n".join(lines) + "\n" + body


@app.command()
def install(
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing skills"),
):
    """Install pmflow skills into Claude Code and Codex."""
    if not SKILLS_SOURCE.exists():
        console.print("[red]Error:[/red] Skills source directory not found. Package may be corrupted.")
        raise typer.Exit(1)

    _clean_legacy()
    COMMANDS_TARGET.mkdir(parents=True, exist_ok=True)
    CODEX_TARGET.mkdir(parents=True, exist_ok=True)

    installed_cc: list[str] = []
    installed_codex: list[str] = []
    skipped_cc: list[str] = []
    skipped_codex: list[str] = []

    for name in SKILL_NAMES:
        src = SKILLS_SOURCE / name / "SKILL.md"
        if not src.exists():
            continue

        # --- Claude Code ---
        cc_dst = COMMANDS_TARGET / f"{name}.md"
        if cc_dst.exists() and not force:
            skipped_cc.append(name)
        else:
            shutil.copy2(src, cc_dst)
            installed_cc.append(name)

        # --- Codex ---
        codex_dst = CODEX_TARGET / f"pmflow-{name}.md"
        if codex_dst.exists() and not force:
            skipped_codex.append(name)
        else:
            skill_content = src.read_text(encoding="utf-8")
            codex_content = _convert_to_codex_prompt(skill_content, name)
            codex_dst.write_text(codex_content, encoding="utf-8")
            installed_codex.append(name)

    # Report
    if installed_cc:
        console.print(f"[green]Claude Code — installed {len(installed_cc)} skill(s):[/green] {', '.join(installed_cc)}")
    if skipped_cc:
        console.print(f"[yellow]Claude Code — skipped {len(skipped_cc)} (already exist):[/yellow] {', '.join(skipped_cc)}")

    if installed_codex:
        console.print(f"[green]Codex — installed {len(installed_codex)} prompt(s):[/green] {', '.join(installed_codex)}")
    if skipped_codex:
        console.print(f"[yellow]Codex — skipped {len(skipped_codex)} (already exist):[/yellow] {', '.join(skipped_codex)}")

    if skipped_cc or skipped_codex:
        console.print("Use [bold]--force[/bold] to overwrite.")

    if installed_cc or installed_codex:
        console.print(
            "\n[dim]Claude Code: /pmflow:plan-space, /pmflow:plan-task, /pmflow:prd, /pmflow:prdfix, /pmflow:snapshot-space\n"
            "Codex:       /prompts:pmflow-plan-space, /prompts:pmflow-plan-task, /prompts:pmflow-prd, /prompts:pmflow-prdfix, /prompts:pmflow-snapshot-space[/dim]"
        )


@app.command()
def uninstall():
    """Remove pmflow skills from Claude Code and Codex."""
    _clean_legacy()

    removed_cc: list[str] = []
    removed_codex: list[str] = []

    for name in SKILL_NAMES:
        # Claude Code
        cc_dst = COMMANDS_TARGET / f"{name}.md"
        if cc_dst.exists():
            cc_dst.unlink()
            removed_cc.append(name)

        # Codex
        codex_dst = CODEX_TARGET / f"pmflow-{name}.md"
        if codex_dst.exists():
            codex_dst.unlink()
            removed_codex.append(name)

    # Remove empty directories
    if COMMANDS_TARGET.exists() and not any(COMMANDS_TARGET.iterdir()):
        COMMANDS_TARGET.rmdir()

    if removed_cc:
        console.print(f"[green]Claude Code — removed {len(removed_cc)} skill(s):[/green] {', '.join(removed_cc)}")
    if removed_codex:
        console.print(f"[green]Codex — removed {len(removed_codex)} prompt(s):[/green] {', '.join(removed_codex)}")
    if not removed_cc and not removed_codex:
        console.print("[dim]No pmflow skills or prompts found to remove.[/dim]")


@app.command(name="list")
def list_skills():
    """List pmflow skills and their install status."""
    table = Table(title="pmflow Skills & Prompts")
    table.add_column("Skill", style="bold")
    table.add_column("Claude Code")
    table.add_column("CC Status")
    table.add_column("Codex")
    table.add_column("Codex Status")

    for name in SKILL_NAMES:
        cc_dst = COMMANDS_TARGET / f"{name}.md"
        cc_status = "[green]installed[/green]" if cc_dst.exists() else "[dim]not installed[/dim]"

        codex_dst = CODEX_TARGET / f"pmflow-{name}.md"
        codex_status = "[green]installed[/green]" if codex_dst.exists() else "[dim]not installed[/dim]"

        table.add_row(
            name,
            f"/pmflow:{name}",
            cc_status,
            f"/prompts:pmflow-{name}",
            codex_status,
        )

    console.print(table)
