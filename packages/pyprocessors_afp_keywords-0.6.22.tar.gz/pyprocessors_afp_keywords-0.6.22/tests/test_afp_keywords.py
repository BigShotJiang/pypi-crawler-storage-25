import json
from pathlib import Path

from pymultirole_plugins.v1.schema import Document

from pyprocessors_afp_keywords.afp_keywords import (
    AFPKeywordsParameters,
    AFPKeywordsProcessor,
)


def test_afp_keywords_fr():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/afp_doc_fr.json")
    parameters = AFPKeywordsParameters()
    annotator = AFPKeywordsProcessor()
    with source.open("r") as fin:
        jdoc = json.load(fin)
        jdocs = [Document(**jdoc)]

    docs: list[Document] = annotator.process(jdocs, parameters)
    doc = docs[0]
    alt0 = doc.altTexts[0]
    assert alt0.name == "slug"
    assert alt0.text == "USA-cinéma-célébrités-récompense-GB-médias-Allemagne-France"

    parameters.threshold = 0.01
    docs: list[Document] = annotator.process(jdocs, parameters)
    doc = docs[0]
    alt0 = doc.altTexts[0]
    assert alt0.name == "slug"
    assert alt0.text == "USA-cinéma-célébrités-récompense-GB-médias"


def test_afp_keywords_empty_document():
    """Test processing a document with no categories."""
    parameters = AFPKeywordsParameters()
    processor = AFPKeywordsProcessor()
    doc = Document(text="Hello world")
    docs = processor.process([doc], parameters)
    assert docs[0].altTexts is not None
    assert docs[0].altTexts[0].name == "slug"
    assert docs[0].altTexts[0].text == ""


def test_afp_keywords_no_alttext():
    """Test processing when as_altText is empty string (disabled)."""
    parameters = AFPKeywordsParameters(as_altText="")
    processor = AFPKeywordsProcessor()
    doc = Document(text="Hello world")
    docs = processor.process([doc], parameters)
    assert docs[0].altTexts is None


def test_afp_keywords_custom_alttext_name():
    """Test processing with a custom altText name."""
    parameters = AFPKeywordsParameters(as_altText="keywords")
    processor = AFPKeywordsProcessor()
    doc = Document(text="Hello world")
    docs = processor.process([doc], parameters)
    assert docs[0].altTexts is not None
    assert docs[0].altTexts[0].name == "keywords"


def test_get_model():
    """Test that get_model returns the correct parameters class."""
    assert AFPKeywordsProcessor.get_model() is AFPKeywordsParameters
