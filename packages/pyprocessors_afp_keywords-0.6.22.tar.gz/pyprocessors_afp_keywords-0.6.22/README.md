# pyprocessors_afp_keywords

[![license](https://img.shields.io/github/license/oterrier/pyprocessors_afp_keywords)](https://github.com/oterrier/pyprocessors_afp_keywords/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyprocessors_afp_keywords/workflows/tests/badge.svg)](https://github.com/oterrier/pyprocessors_afp_keywords/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyprocessors_afp_keywords)](https://codecov.io/gh/oterrier/pyprocessors_afp_keywords)
[![docs](https://img.shields.io/readthedocs/pyprocessors_afp_keywords)](https://pyprocessors_afp_keywords.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyprocessors_afp_keywords)](https://pypi.org/project/pyprocessors_afp_keywords/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyprocessors_afp_keywords)](https://pypi.org/project/pyprocessors_afp_keywords/)

AFP keywords extractor processor. Extracts keywords from document categories and generates a slug by joining category labels that exceed a configurable score threshold.

## Installation

```
pip install pyprocessors_afp_keywords
```

## Developing

### Pre-requisites

You will need to install [uv](https://docs.astral.sh/uv/):

```
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Clone the repository:

```
git clone https://github.com/oterrier/pyprocessors_afp_keywords
```

Install dependencies:

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
