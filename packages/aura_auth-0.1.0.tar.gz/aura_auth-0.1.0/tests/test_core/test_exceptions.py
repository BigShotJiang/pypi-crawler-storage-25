"""Tests for custom exceptions."""

from __future__ import annotations

import pytest

from aura_auth._core.exceptions import (
    AuraAuthError,
    InvalidTokenError,
    MissingDependencyError,
    TokenExpiredError,
    UserNotFoundError,
)


def test_all_subclass_aura_auth_error() -> None:
    assert issubclass(UserNotFoundError, AuraAuthError)
    assert issubclass(TokenExpiredError, InvalidTokenError)


def test_missing_dependency_message() -> None:
    err = MissingDependencyError("httpx", "google")
    assert "httpx" in str(err)
    assert "aura-auth[google]" in str(err)


def test_exceptions_can_be_raised_and_caught() -> None:
    with pytest.raises(TokenExpiredError):
        raise TokenExpiredError("expired")
