"""Tests for Pydantic schemas."""

from __future__ import annotations

import uuid
from types import SimpleNamespace

import pytest
from pydantic import ValidationError

from aura_auth._core.schemas import LoginRequest, TokenResponse, UserCreate, UserRead, UserUpdate


def test_user_create_valid() -> None:
    user = UserCreate(email="user@example.com", password="super-secret")
    assert user.email == "user@example.com"


def test_user_create_invalid_email() -> None:
    with pytest.raises(ValidationError):
        UserCreate(email="not-an-email", password="super-secret")


def test_user_read_from_attributes() -> None:
    obj = SimpleNamespace(
        id=uuid.uuid4(),
        email="user@example.com",
        is_active=True,
        is_verified=False,
    )
    read = UserRead[uuid.UUID].model_validate(obj)
    assert read.email == "user@example.com"


def test_user_update_all_none_valid() -> None:
    assert UserUpdate().model_dump() == {
        "email": None,
        "password": None,
        "is_active": None,
        "is_verified": None,
    }


def test_token_response_default_token_type() -> None:
    token = TokenResponse(access_token="abc")
    assert token.token_type == "bearer"


def test_login_request_roundtrip() -> None:
    payload = LoginRequest(email="a@b.com", password="x")
    restored = LoginRequest.model_validate(payload.model_dump())
    assert restored == payload
