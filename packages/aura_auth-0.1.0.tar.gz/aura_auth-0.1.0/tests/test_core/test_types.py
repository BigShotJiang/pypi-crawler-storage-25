"""Tests for core type aliases."""

from __future__ import annotations

import uuid

from aura_auth._core.types import ID


def test_id_typevar_importable() -> None:
    assert ID.__name__ == "ID"


def test_id_typevar_constraints() -> None:
    assert ID.__constraints__ == (int, str, uuid.UUID)
