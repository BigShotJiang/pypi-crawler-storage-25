"""Tests for FastAPI dependency helpers."""

from __future__ import annotations

import httpx
import pytest
from fastapi import FastAPI


@pytest.mark.asyncio
async def test_current_user_dependency_used_by_me_endpoint(app: FastAPI) -> None:
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        await client.post(
            "/auth/register",
            json={"email": "depuser@example.com", "password": "password123"},
        )
        login = await client.post(
            "/auth/login",
            json={"email": "depuser@example.com", "password": "password123"},
        )
        token = login.json()["access_token"]
        response = await client.get("/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
