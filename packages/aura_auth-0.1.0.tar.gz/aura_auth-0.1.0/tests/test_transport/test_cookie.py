"""Tests for cookie transport."""

from __future__ import annotations

import pytest
from starlette.requests import Request
from starlette.responses import Response

from aura_auth._core.protocols import TransportProtocol
from aura_auth.transport.cookie import CookieTransport


@pytest.mark.asyncio
async def test_cookie_set_token_adds_cookie() -> None:
    transport = CookieTransport(cookie_secure=False, cookie_httponly=True, cookie_samesite="lax")
    response = Response()
    transport.set_token(response, "token-value")
    set_cookie = response.headers.get("set-cookie", "")
    assert "aura_token=token-value" in set_cookie
    assert "HttpOnly" in set_cookie
    assert "SameSite=lax" in set_cookie


@pytest.mark.asyncio
async def test_cookie_get_token_reads_cookie() -> None:
    transport = CookieTransport()
    scope = {
        "type": "http",
        "headers": [[b"cookie", b"aura_token=abc"]],
        "method": "GET",
        "path": "/",
        "client": ("testclient", 50000),
        "server": ("testserver", 80),
        "scheme": "http",
        "http_version": "1.1",
    }
    request = Request(scope)
    assert await transport.get_token(request) == "abc"


@pytest.mark.asyncio
async def test_cookie_remove_deletes_cookie() -> None:
    transport = CookieTransport()
    response = Response()
    transport.remove_token(response)
    header = response.headers.get("set-cookie", "")
    assert "aura_token=" in header
    assert "Max-Age=0" in header or "max-age=0" in header.lower()


@pytest.mark.asyncio
async def test_cookie_custom_name() -> None:
    transport = CookieTransport(cookie_name="custom", cookie_secure=False)
    response = Response()
    transport.set_token(response, "x")
    assert "custom=x" in response.headers.get("set-cookie", "")


@pytest.mark.asyncio
async def test_cookie_secure_flags() -> None:
    transport = CookieTransport(cookie_secure=True, cookie_samesite="strict")
    response = Response()
    transport.set_token(response, "x")
    header = response.headers.get("set-cookie", "")
    assert "Secure" in header
    assert "SameSite=strict" in header


@pytest.mark.asyncio
async def test_cookie_is_transport_protocol() -> None:
    assert isinstance(CookieTransport(), TransportProtocol)
