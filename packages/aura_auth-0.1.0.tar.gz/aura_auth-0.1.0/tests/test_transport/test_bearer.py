"""Tests for bearer header transport."""

from __future__ import annotations

import pytest
from starlette.requests import Request
from starlette.responses import Response

from aura_auth._core.protocols import TransportProtocol
from aura_auth.transport.bearer import BearerTransport


@pytest.mark.asyncio
async def test_bearer_extracts_token() -> None:
    transport = BearerTransport()
    scope = {
        "type": "http",
        "headers": [[b"authorization", b"Bearer abc.token.value"]],
        "method": "GET",
        "path": "/",
    }
    request = Request(scope)
    assert await transport.get_token(request) == "abc.token.value"


@pytest.mark.asyncio
async def test_bearer_missing_header_returns_none() -> None:
    transport = BearerTransport()
    scope = {"type": "http", "headers": [], "method": "GET", "path": "/"}
    request = Request(scope)
    assert await transport.get_token(request) is None


@pytest.mark.asyncio
async def test_bearer_non_bearer_scheme_returns_none() -> None:
    transport = BearerTransport()
    scope = {
        "type": "http",
        "headers": [[b"authorization", b"Basic abc"]],
        "method": "GET",
        "path": "/",
    }
    request = Request(scope)
    assert await transport.get_token(request) is None


@pytest.mark.asyncio
async def test_bearer_handles_whitespace() -> None:
    transport = BearerTransport()
    scope = {
        "type": "http",
        "headers": [[b"authorization", b"  Bearer   trimmed  "]],
        "method": "GET",
        "path": "/",
    }
    request = Request(scope)
    assert await transport.get_token(request) == "trimmed"


@pytest.mark.asyncio
async def test_bearer_is_transport_protocol() -> None:
    assert isinstance(BearerTransport(), TransportProtocol)


@pytest.mark.asyncio
async def test_bearer_set_remove_noop() -> None:
    transport = BearerTransport()
    response = Response()
    transport.set_token(response, "ignored")
    transport.remove_token(response)
    assert response.headers.get("set-cookie") is None
