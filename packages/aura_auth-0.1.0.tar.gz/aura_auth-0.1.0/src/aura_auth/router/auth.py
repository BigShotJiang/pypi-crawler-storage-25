"""Built-in authentication routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Response, status

from aura_auth._core.schemas import LoginRequest, TokenResponse, UserCreate, UserRead
from aura_auth.dependencies import current_user, get_aura_auth

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", status_code=status.HTTP_201_CREATED, response_model=UserRead)
async def register_user(
    payload: UserCreate,
    aura=Depends(get_aura_auth),
) -> UserRead:
    user = await aura.manager.register(payload)
    return UserRead.model_validate(user)


@router.post("/login", response_model=TokenResponse)
async def login_user(
    payload: LoginRequest,
    response: Response,
    aura=Depends(get_aura_auth),
) -> TokenResponse:
    token = await aura.manager.login(payload)
    aura.transport.set_token(response, token)
    return TokenResponse(access_token=token)


@router.post("/logout")
async def logout_user(response: Response, aura=Depends(get_aura_auth)) -> dict[str, str]:
    aura.transport.remove_token(response)
    return {"detail": "logged out"}


@router.get("/me", response_model=UserRead)
async def read_me(user=Depends(current_user)) -> UserRead:
    return UserRead.model_validate(user)
