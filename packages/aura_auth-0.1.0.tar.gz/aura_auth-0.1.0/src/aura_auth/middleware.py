"""HTTP middleware hooks (reserved for future extensions)."""
