"""Abstract database backend."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Generic

from aura_auth._core.protocols import UserProtocol
from aura_auth._core.types import ID


class BaseBackend(ABC, Generic[ID]):
    """Abstract base for all database backends."""

    @abstractmethod
    async def get_by_id(self, user_id: ID) -> UserProtocol[ID] | None:
        """Return a user by id or None."""

    @abstractmethod
    async def get_by_email(self, email: str) -> UserProtocol[ID] | None:
        """Return a user by email or None."""

    @abstractmethod
    async def create(self, data: dict[str, Any]) -> UserProtocol[ID]:
        """Persist a new user from a data dictionary."""

    @abstractmethod
    async def update(self, user: UserProtocol[ID], data: dict[str, Any]) -> UserProtocol[ID]:
        """Apply a partial update and return the updated user."""

    @abstractmethod
    async def delete(self, user: UserProtocol[ID]) -> None:
        """Delete a user record."""
