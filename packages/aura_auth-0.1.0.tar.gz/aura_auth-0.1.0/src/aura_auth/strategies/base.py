"""Base authentication strategy."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Generic

from aura_auth._core.protocols import BackendProtocol, UserProtocol
from aura_auth._core.types import ID


class BaseStrategy(ABC, Generic[ID]):
    """Base class for all auth strategies."""

    @abstractmethod
    async def authenticate(
        self,
        credentials: dict[str, Any],
        backend: BackendProtocol[ID],
    ) -> UserProtocol[ID] | None:
        """Validate credentials and return the user, or None."""

    async def on_after_register(self, user: UserProtocol[ID]) -> None:
        """Hook called after successful registration. Override for custom logic."""
        return None

    async def on_after_login(self, user: UserProtocol[ID]) -> None:
        """Hook called after successful login. Override for custom logic."""
        return None
