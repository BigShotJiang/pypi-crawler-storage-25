"""Default SQLAlchemy user model."""

from __future__ import annotations

import uuid

from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from aura_auth.models.base import UserMixin


class Base(DeclarativeBase):
    """Declarative base for built-in models."""


class SQLAlchemyBaseUser(UserMixin, Base):
    """Concrete user table with a UUID primary key."""

    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
