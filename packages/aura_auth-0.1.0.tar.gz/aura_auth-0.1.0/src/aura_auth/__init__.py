"""Aura Auth — pluggable authentication for FastAPI."""

from __future__ import annotations

__all__ = ["AuraAuth"]


def __getattr__(name: str):
    if name == "AuraAuth":
        from aura_auth.app import AuraAuth

        return AuraAuth
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)
