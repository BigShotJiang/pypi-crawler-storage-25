"""HTTP-only cookie transport."""

from __future__ import annotations

from typing import Literal

from starlette.requests import Request
from starlette.responses import Response

from aura_auth.transport.base import BaseTransport

SameSitePolicy = Literal["lax", "strict", "none"]


class CookieTransport(BaseTransport):
    """Store tokens in an HTTP-only cookie."""

    def __init__(
        self,
        cookie_name: str = "aura_token",
        cookie_secure: bool = True,
        cookie_httponly: bool = True,
        cookie_samesite: SameSitePolicy = "lax",
        cookie_max_age: int = 3600,
    ) -> None:
        self._cookie_name = cookie_name
        self._cookie_secure = cookie_secure
        self._cookie_httponly = cookie_httponly
        self._cookie_samesite = cookie_samesite
        self._cookie_max_age = cookie_max_age

    async def get_token(self, request: Request) -> str | None:
        return request.cookies.get(self._cookie_name)

    def set_token(self, response: Response, token: str) -> None:
        response.set_cookie(
            key=self._cookie_name,
            value=token,
            max_age=self._cookie_max_age,
            httponly=self._cookie_httponly,
            secure=self._cookie_secure,
            samesite=self._cookie_samesite,
        )

    def remove_token(self, response: Response) -> None:
        response.delete_cookie(self._cookie_name)
