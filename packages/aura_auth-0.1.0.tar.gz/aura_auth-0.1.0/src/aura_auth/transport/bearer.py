"""Bearer header transport."""

from __future__ import annotations

from starlette.requests import Request
from starlette.responses import Response

from aura_auth.transport.base import BaseTransport


class BearerTransport(BaseTransport):
    """Read tokens from the ``Authorization: Bearer`` header."""

    async def get_token(self, request: Request) -> str | None:
        auth = request.headers.get("Authorization")
        if not auth:
            return None
        auth = auth.strip()
        prefix = "bearer "
        if not auth.lower().startswith(prefix):
            return None
        token = auth[len(prefix) :].strip()
        return token or None

    def set_token(self, response: Response, token: str) -> None:
        """Bearer tokens are returned in the response body, not headers."""
        pass

    def remove_token(self, response: Response) -> None:
        """Bearer clients drop tokens locally; nothing to clear server-side."""
        pass
