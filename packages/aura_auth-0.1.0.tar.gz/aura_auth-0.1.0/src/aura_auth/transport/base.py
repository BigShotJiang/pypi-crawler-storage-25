"""Transport base class."""

from __future__ import annotations

from abc import ABC, abstractmethod

from starlette.requests import Request
from starlette.responses import Response


class BaseTransport(ABC):
    """Abstract transport for reading/writing tokens on HTTP messages."""

    @abstractmethod
    async def get_token(self, request: Request) -> str | None:
        """Extract a token from the incoming request, if present."""

    @abstractmethod
    def set_token(self, response: Response, token: str) -> None:
        """Attach a token to an outgoing response (for example a cookie)."""

    @abstractmethod
    def remove_token(self, response: Response) -> None:
        """Remove a token from the outgoing response."""
