"""Pydantic request/response schemas."""

from __future__ import annotations

from typing import Generic

from pydantic import BaseModel, ConfigDict, EmailStr

from .types import ID


class UserCreate(BaseModel):
    """Payload for registering a new user."""

    email: EmailStr
    password: str


class UserRead(BaseModel, Generic[ID]):
    """Serialized user returned to clients."""

    id: ID
    email: str
    is_active: bool
    is_verified: bool

    model_config = ConfigDict(from_attributes=True)


class UserUpdate(BaseModel):
    """Partial update payload for user fields."""

    email: str | None = None
    password: str | None = None
    is_active: bool | None = None
    is_verified: bool | None = None


class TokenResponse(BaseModel):
    """OAuth2-style token payload."""

    access_token: str
    token_type: str = "bearer"


class LoginRequest(BaseModel):
    """Credentials for password login."""

    email: str
    password: str
