"""Core type aliases for aura-auth."""

from __future__ import annotations

import uuid
from typing import TypeVar

# The user ID can be int, str, or UUID depending on the ORM model
ID = TypeVar("ID", int, str, uuid.UUID)
