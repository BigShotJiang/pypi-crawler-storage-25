"""Library configuration objects."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class AuraAuthConfig:
    """Configuration for wiring AuraAuth components."""

    database_url: str
    secret: str
    token_lifetime_seconds: int = 3600
    verify_token_lifetime_seconds: int = 86_400
    cookie_transport: bool = False
    password_min_length: int = 8
    user_model: type[Any] | None = None
