"""Custom exceptions for aura-auth."""


class AuraAuthError(Exception):
    """Base exception for aura-auth."""


class UserNotFoundError(AuraAuthError):
    """Raised when a user is not found."""


class UserAlreadyExistsError(AuraAuthError):
    """Raised when a user already exists."""


class UserInactiveError(AuraAuthError):
    """Raised when a user is inactive."""


class UserNotVerifiedError(AuraAuthError):
    """Raised when a user is not verified."""


class InvalidCredentialsError(AuraAuthError):
    """Raised when invalid credentials are provided."""


class InvalidTokenError(AuraAuthError):
    """Raised when an invalid token is provided."""


class TokenExpiredError(InvalidTokenError):
    """Raised when a token has expired."""


class InvalidPasswordError(AuraAuthError):
    """Raised when a password fails validation or policy checks."""


class MissingDependencyError(AuraAuthError):
    """Raised when an optional dependency is not installed."""

    def __init__(self, package: str, extra: str) -> None:
        super().__init__(f'{package} is required. Install it with: pip install "aura-auth[{extra}]"')
