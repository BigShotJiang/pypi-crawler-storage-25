from argparse import ArgumentParser
from typing import Any

import numpy as np
from beartype import beartype

from sequifier.hyperparameter_search import hyperparameter_search
from sequifier.infer import infer
from sequifier.make import make
from sequifier.preprocess import preprocess
from sequifier.train import train
from sequifier.visualize_training import visualize_training


@beartype
def build_args_config(args: Any) -> dict[str, Any]:
    """
    Build configuration dictionary from command-line arguments.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Dictionary containing configuration options.
    """

    args_config = {
        k: v
        for k, v in vars(args).items()
        if v is not None and k not in ["randomize", "command", "config_path"]
    }
    if args.command not in ["make", "visualize-training"]:
        if args.randomize:
            seed = np.random.choice(np.arange(int(1e9)))
            args_config["seed"] = seed
        elif args.command in ["train", "infer"] and args.seed:
            args_config["seed"] = args.seed

    if "selected_columns" in args_config:
        if (
            len(args_config["selected_columns"]) == 1
            and args_config["selected_columns"][0] == "None"
        ):
            args_config["selected_columns"] = None

    if "input_columns" in args_config:
        if (
            len(args_config["input_columns"]) == 1
            and args_config["input_columns"][0] == "None"
        ):
            args_config["input_columns"] = None

    return args_config


@beartype
def setup_parser() -> ArgumentParser:
    """
    Set up the argument parser for the command-line interface.

    Returns:
        Configured ArgumentParser object.
    """
    parser = ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    parser_make = subparsers.add_parser("make", help="Set up sequifier project")
    parser_make.add_argument("project_name", type=str)
    parser_preprocess = subparsers.add_parser(
        "preprocess", help="Run the preprocessing step"
    )
    parser_train = subparsers.add_parser("train", help="Run the training step")
    parser_infer = subparsers.add_parser("infer", help="Run the inference step")

    parser_hyperparameter_search = subparsers.add_parser(
        "hyperparameter-search", help="Run hyperparamter search"
    )
    parser_visualize_training = subparsers.add_parser(
        "visualize-training", help="Visualize training losses"
    )

    for subparser in [
        parser_preprocess,
        parser_train,
        parser_infer,
        parser_hyperparameter_search,
    ]:
        subparser.add_argument(
            "--config-path",
            type=str,
            help="File path to config for current processing step",
        )

        if subparser != parser_hyperparameter_search:
            subparser.add_argument("-r", "--randomize", action="store_true")
            subparser.add_argument("-dp", "--data-path", type=str)

    for subparser in [parser_train, parser_infer, parser_hyperparameter_search]:
        subparser.add_argument(
            "-ic",
            "--input-columns",
            type=str,
            nargs="+",
            help="Space-separated list of input columns (e.g. --input-columns col1 col2)",
        )
        subparser.add_argument("-mc", "--metadata-config-path", type=str)
        subparser.add_argument("-sm", "--skip-metadata", action="store_true")

    parser_preprocess.add_argument(
        "-sc",
        "--selected-columns",
        type=str,
        nargs="+",
        help="Space-separated list of selected columns",
    )
    parser_train.add_argument("-mn", "--model-name", type=str)
    parser_train.add_argument("-s", "--seed", type=int)

    parser_infer.add_argument("-mp", "--model-path", type=str)
    parser_infer.add_argument("-s", "--seed", type=int)

    parser_visualize_training.add_argument(
        "models",
        type=str,
        help="Model name, comma-separated names, or path to txt file containing model names",
    )
    parser_visualize_training.add_argument(
        "--log-scale",
        action="store_true",
        help="Use a logarithmic scale on the y-axis",
    )
    parser_visualize_training.add_argument(
        "--bucket-training-batches",
        type=int,
        help="Bucket the training batches by taking the average loss over a specified number of batches. Must be a multiple of the logged batch interval.",
    )

    parser_visualize_training.add_argument(
        "--project-root",
        type=str,
        default=".",
        help="Path to the project root directory.",
    )

    return parser


def main() -> None:
    """
    Main function to run the Sequifier CLI.
    """
    parser = setup_parser()
    args = parser.parse_args()

    if args.command != "hyperparameter-search":
        args_config = build_args_config(args)

        if args.command == "make":
            make(args)
        elif args.command == "preprocess":
            preprocess(args, args_config)
        elif args.command == "train":
            train(args, args_config)
        elif args.command == "infer":
            infer(args, args_config)
        elif args.command == "visualize-training":
            visualize_training(args)
    elif args.command == "hyperparameter-search":
        hyperparameter_search(args.config_path, args.skip_metadata)


if __name__ == "__main__":
    main()
