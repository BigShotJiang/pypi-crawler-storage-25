import os
import pandas as pd


class CSVLogger2d:
    def __init__(self, file_path="table.csv"):
        self.file_path = file_path

        if os.path.exists(file_path):
            self.df = pd.read_csv(file_path, index_col=0)
        else:
            self.df = pd.DataFrame()

    def __enter__(self):
        # 返回自身，供 with 内使用
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        exc_type 不为 None 表示 with 内发生异常
        """
        self.save()

        # False 表示异常继续抛出（推荐）
        return False

    def set(self, row, col, value):
        """
        在 (row, col) 位置写入 value
        """

        # 如果列名不纯在, 则创建该空列
        if col not in self.df.columns:
            self.df[col] = pd.NA

        # 如果指定的行索引不存在，会自动创建该行
        self.df.loc[row, col] = value

    def set_many(self, entries: list[tuple]):
        """
        批量写入: [(row, col, value), ...]
        """
        for row, col, value in entries:
            self.set(row, col, value)

    def save(self):
        self.df.to_csv(self.file_path)

    def get(self, row, col):
        return self.df.loc[row, col]


if __name__ == '__main__':
    # 法一
    logger = CSVLogger2d("csvlogger2d.csv")

    logger.set("lr=0.01", "bs=128", 0.91)
    logger.set("lr=0.01", "bs=64", 0.89)
    logger.set("lr=0.001", "bs=128", 0.88)
    logger.set("awa=0.001", "qwq=128", 1314)

    logger.save()

    # 法二
    # with CSVLogger2d("csvlogger2d.csv") as logger:
    #     logger.set("lr=0.01", "bs=128", 0.91)
    #     logger.set("lr=0.01", "bs=64", 0.89)
    #     logger.set("lr=0.001", "bs=128", 0.88)
    #     logger.set("awa=0.001", "qwq=128", 1314)