import sqlite3
import pandas as pd
from typing import List, Dict


class DBLogger1d:
    def __init__(self, db_path="results.db", table_name="experiments"):
        self.db_path = db_path
        self.table_name = table_name

    def _create_table_if_not_exists(self, cur, data: Dict):
        """
        用已有 cursor 建表（不负责连接生命周期）
        """
        columns = []
        for k, v in data.items():
            if isinstance(v, int):
                col_type = "INTEGER"
            elif isinstance(v, float):
                col_type = "REAL"
            else:
                col_type = "TEXT"

            columns.append(f"{k} {col_type}")

        columns_sql = ", ".join(columns)

        sql = f"""
        CREATE TABLE IF NOT EXISTS {self.table_name} (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            {columns_sql}
        )
        """

        cur.execute(sql)

    def insert(self, data: Dict):
        """
        单条插入（短连接）
        """
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()

        try:
            self._create_table_if_not_exists(cur, data)

            keys = ", ".join(data.keys())
            placeholders = ", ".join(["?"] * len(data))

            sql = f"""
            INSERT INTO {self.table_name} ({keys})
            VALUES ({placeholders})
            """

            cur.execute(sql, tuple(data.values()))
            conn.commit()

        finally:
            conn.close()

    def insert_many(self, data_list: List[Dict]):
        """
        批量插入（单次连接）
        """
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()

        try:
            self._create_table_if_not_exists(cur, data_list[0])

            keys = ", ".join(data_list[0].keys())
            placeholders = ", ".join(["?"] * len(data_list[0]))

            sql = f"""
            INSERT INTO {self.table_name} ({keys})
            VALUES ({placeholders})
            """

            values = [tuple(d.values()) for d in data_list]

            cur.executemany(sql, values)
            conn.commit()

        finally:
            conn.close()

    def to_csv(self, file_path="export.csv", sql: str = None, index=True):
        """
        导出为 CSV（以 id 作为 index）
        """
        conn = sqlite3.connect(self.db_path)

        try:
            if sql is None:
                sql = f"SELECT * FROM {self.table_name}"

            df = pd.read_sql_query(sql, conn)

            # 将`id列`作为index
            if "id" in df.columns:
                df = df.set_index("id")
            # 去掉 index 名称
            df.index.name = None

            df.to_csv(file_path, index=index)

        finally:
            conn.close()

if __name__ == '__main__':
    logger = DBLogger1d("dblogger1d.db")

    logger.insert({
        "lr": 0.01,
        "batch_size": 128,
        "acc": 0.9,
        "loss": 0.1,
    })

    logger.insert_many([
        {"lr": 0.001, "batch_size": 64, "acc": 0.88, "loss": 0.12},
        {"lr": 0.0001, "batch_size": 32, "acc": 0.85, "loss": 0.15},
    ])

    logger.to_csv(file_path="dblogger1d_export.csv")