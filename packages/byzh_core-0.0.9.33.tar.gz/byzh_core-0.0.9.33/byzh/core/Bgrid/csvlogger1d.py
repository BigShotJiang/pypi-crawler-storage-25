import os
import pandas as pd


class CSVLogger1d:
    def __init__(self, file_path="results.csv", index=True):
        self.file_path = file_path
        self.index = index

    def insert(self, data: dict):
        """
        插入一条实验记录（追加模式）
        """
        df_new = pd.DataFrame([data])

        if not os.path.exists(self.file_path):
            # 文件不存在 → 直接写（带表头）
            df_new.to_csv(self.file_path, index=self.index)
        else:
            # 文件存在 → 追加（不写表头）
            df_new.to_csv(self.file_path, mode='a', header=False, index=self.index)

    def insert_many(self, data_list: list[dict]):
        """
        批量插入
        """
        df_new = pd.DataFrame(data_list)

        if not os.path.exists(self.file_path):
            df_new.to_csv(self.file_path, index=self.index)
        else:
            df_new.to_csv(self.file_path, mode='a', header=False, index=self.index)


if __name__ == "__main__":
    logger = CSVLogger1d("csvlogger1d.csv")

    logger.insert({
        "lr": 0.01,
        "batch_size": 128,
        "acc": 0.9,
        "loss": 0.1,
    })

    logger.insert_many([
        {"lr": 0.001, "batch_size": 64, "acc": 0.88, "loss": 0.12},
        {"lr": 0.0001, "batch_size": 32, "acc": 0.85, "loss": 0.15},
    ])