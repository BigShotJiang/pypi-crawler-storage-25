import sys
import time

class B_ModernBar:
    def __init__(self, total, headers, widths=None, bar_width=30, prefix=['┌ ', '│ ', '└ ']):
        self.total = total
        self.headers = headers
        self.bar_width = bar_width
        self.lines_written = 0

        # 自动宽度
        if widths is None:
            self.widths = [max(len(h), 10) for h in headers]
        else:
            assert len(widths) == len(headers)
            self.widths = widths

        # 前缀
        self.prefix = prefix
        assert len(self.prefix) == 3, "prefix must be a list of 3 strings"

    def _bar(self, i):
        ratio = i / self.total
        done = int(ratio * self.bar_width)
        remain = self.bar_width - done
        bar = "━" * done + "─" * remain
        return f"{bar} {ratio*100:5.1f}%"

    def _fmt(self, v, w):
        if isinstance(v, float):
            return f"{v:<{w}.4f}"
        return f"{str(v):<{w}}"

    def update(self, i, values):
        """
        values:
            - dict: {"loss":0.1, "acc":0.9}
            - list: 按 headers 顺序
        """

        if isinstance(values, dict):
            row = [values.get(h, "") for h in self.headers]
        else:
            assert len(values) == len(self.headers)
            row = values

        header_line = " ".join(
            self._fmt(h, w) for h, w in zip(self.headers, self.widths)
        )

        value_line = " ".join(
            self._fmt(v, w) for v, w in zip(row, self.widths)
        )

        bar_line = self._bar(i)

        # 回退
        if self.lines_written > 0:
            sys.stdout.write("\033[F" * self.lines_written)

        # 输出
        if self.lines_written == 0:
            sys.stdout.write(self.prefix[0] + bar_line + "\n")
            sys.stdout.write(self.prefix[1] + header_line + "\n")
            sys.stdout.write(self.prefix[2] + value_line + "\n")
            self.lines_written = 3
        else:
            sys.stdout.write(self.prefix[0] + bar_line + "\n")
            sys.stdout.write(self.prefix[1] + header_line + "\n")  # 稳一点
            sys.stdout.write(self.prefix[2] + value_line + "\n")

        sys.stdout.flush()

def main_train():
    total_iter = 50
    epochs = 3

    for epoch in range(1, epochs + 1):
        print(f"\n=== Epoch {epoch} ===")

        logger = B_ModernBar(
            total=total_iter,
            headers=["epoch", "iter", "loss", "acc", "lr"],
            widths=[8, 10, 10, 10, 10]
        )

        for i in range(1, total_iter + 1):
            loss = 2.5 - (i / total_iter) * 2.0 + (epoch - 1) * 0.3
            acc = 0.5 + (i / total_iter) * 0.45 + (epoch - 1) * 0.15
            lr = 0.001 - (epoch - 1) * 0.0003

            logger.update(i, {
                "epoch": f"{epoch}/{epochs}",
                "iter": f"{i}/{total_iter}",
                "loss": loss,
                "acc": acc,
                "lr": lr
            })

            time.sleep(0.03)

    print("\n训练完成！")

def main_download():
    total = 100

    logger = B_ModernBar(
        total=total,
        headers=["file", "speed", "progress"],
        widths=[20, 10, 10]
    )

    for i in range(1, total + 1):
        logger.update(i, {
            "file": "dataset.zip",
            "speed": f"{10 + i * 0.1:.1f} MB/s",
            "progress": f"{i}%"
        })

        time.sleep(0.02)

    print("\n下载完成！")


if __name__ == '__main__':
    main_train()
    # main_download()