[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

# Parallel execution using lazyscribe

``spacecadet`` is a library designed to enable parallel code execution without defining
custom serialization. Instead, we leverage ``lazyscribe`` to track and manage experimentation
as well as usage of current, "deployment" artifacts.
