"""Semaphore that allows for acquisition of multiple resources at once."""

import multiprocessing
import threading
from multiprocessing.sharedctypes import Synchronized


class ThreadedSemaphore:
    """Wait for multiple threads to be available.

    This implementation was mostly written by :cite:`69366850`.

    .. bibliography:: refs.bib

    Parameters
    ----------
    total_threads : int, optional (default 1)
        The number of available threads.

    Examples
    --------
    Suppose you have a 4-core system. Let's acquire 2 threads:

    >>> counter = ThreadedSemaphore(4)
    >>> counter.acquire(2)
    >>> counter.locked()
    False

    Now, if we acquire 2 more resources and check the status of the counter we will
    find it locked:

    >>> counter.acquire(2)
    >>> counter.locked()
    True

    We have to release resources before we can use more:

    >>> counter.release(2)
    >>> counter.locked()
    False
    """

    def __init__(self, total_threads: int = 1, /):
        """Init method."""
        self._available_resources = total_threads
        self._mutex = threading.Lock()
        self._condition = threading.Condition()

    def acquire(self, threads: int = 1, timeout: float = 60, /) -> None:
        """Acquire threads or wait until they are available.

        Parameters
        ----------
        threads : int, optional (default 1)
            The number of threads to acquire.
        timeout : float, optional (default 60)
            The number of seconds to wait.
        """
        with self._condition:
            self._condition.wait_for(lambda: not self.locked(threads), timeout=timeout)
            with self._mutex:
                self._available_resources -= threads

    def locked(self, threads: int = 1, /) -> bool:
        """Check whether there are available threads.

        Parameters
        ----------
        threads : int, optional (default 1)
            The number of threads.

        Returns
        -------
        bool
            Evaluates to ``False`` if :py:meth:`spacecadet.semaphore.ThreadedSemaphore.acquire`
            would return immediately.
        """
        return self._available_resources < threads

    def release(self, threads: int = 1, /) -> None:
        """Release the acquired resources.

        Parameters
        ----------
        threads : int, optional (default 1)
            The number of threads to release.
        """
        with self._condition:
            with self._mutex:
                self._available_resources += threads
            self._condition.notify_all()


class ProcessSemaphore:
    """Wait for multiple processes to be available.

    This implementation was mostly written by :cite:`69366850`. Importantly,
    this semaphore object uses :py:class:`multiprocessing.Value`. That means
    that out of the box this class is not compatible with pools. To use this
    semaphore, supply an instance to the target process directly.

    .. bibliography:: refs.bib

    Parameters
    ----------
    total_processes : int, optional (default 1)
        The number of available resources.

    Examples
    --------
    Suppose you have a 4-core system. Let's acquire 2 cores:

    >>> counter = ProcessSemaphore(4)
    >>> counter.acquire(2)
    >>> counter.locked()
    False

    Now, if we acquire 2 more resources and check the status of the counter we will
    find it locked:

    >>> counter.acquire(2)
    >>> counter.locked()
    True

    We have to release resources before we can use more:

    >>> counter.release(2)
    >>> counter.locked()
    False
    """

    def __init__(self, total_processes: int = 1, /):
        """Init method."""
        self._available_resources: Synchronized[int] = multiprocessing.Value(
            "i", total_processes
        )
        self._condition = multiprocessing.Condition()

    def acquire(self, cores: int = 1, timeout: float = 60, /) -> None:
        """Acquire cores or wait until they are available.

        Parameters
        ----------
        cores : int, optional (default 1)
            The number of cores/threads to acquire.
        timeout : float, optional (default 60)
            The number of seconds to wait.
        """
        with self._condition:
            self._condition.wait_for(lambda: not self.locked(cores), timeout=timeout)
            with self._available_resources.get_lock():
                self._available_resources.value -= cores

    def locked(self, cores: int = 1, /) -> bool:
        """Check whether there are available resources.

        Parameters
        ----------
        cores : int, optional (default 1)
            The number of cores/threads.

        Returns
        -------
        bool
            Evaluates to ``False`` if :py:meth:`spacecadet.semaphore.MultiPermitSemaphore.aquire`
            would return immediately.
        """
        return self._available_resources.value < cores

    def release(self, cores: int = 1, /) -> None:
        """Release the acquired cores.

        Parameters
        ----------
        cores : int, optional (default 1)
            The number of cores to release.
        """
        with self._condition:
            with self._available_resources.get_lock():
                self._available_resources.value += cores
            self._condition.notify_all()
