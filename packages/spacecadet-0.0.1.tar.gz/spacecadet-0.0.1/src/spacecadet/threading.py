"""Threading-based execution."""

import functools
import inspect
from collections.abc import Callable
from datetime import datetime
from threading import Thread

from spacecadet.protocols import HasArtifacts
from spacecadet.semaphore import ThreadedSemaphore
from spacecadet.utils import find_artifact_args


class CadetThread(Thread):
    """Custom multithreading executor.

    This extension of the threading class allows users to overwrite supplied function
    arguments at runtime with artifacts from Lazyscribe. It also allows users to wait
    for and release multiple threads.
    """

    def set_allocator(self, semaphore: ThreadedSemaphore, threads: int = 1, /) -> None:
        """Add a threaded semaphore.

        Parameters
        ----------
        semaphore : ThreadedSemaphore
            A multi-permit semaphore object.
        threads : int, optional (default 1)
            The number of threads to request and release.
        """
        self._semaphore = semaphore
        self._required_threads = threads

    def set_source(self, source: HasArtifacts, /):
        """Set a source object for dynamic argument replacement.

        Here, the input argument has available artifacts (typically via Lazyscribe).

        Parameters
        ----------
        source : HasArtifacts
            A Lazyscribe-style object that provides the ability to load artifacts
            from a filesystem. Common examples include :py:class:`lazyscribe.repository.Repository`,
            :py:class:`lazyscribe.experiment.Experiment`, and :py:class:`lazyscribe.test.Test`.
        """
        self._source = source

    def run(self):
        """Run the specified function.

        The input arguments may be modified based on whether a ``source`` is added. This function
        parses the signature of the upstream function, looking for string arguments to parameters
        that are annotated with a non-string type :cite:`74544539`.

        .. bibliography:: refs.bib
        """
        # Acquire resources according to the init
        if hasattr(self, "_semaphore"):
            self._semaphore.acquire(self._required_threads)

        if self._target is not None:  # ty: ignore[unresolved-attribute]
            sig_ = inspect.signature(self._target)  # ty: ignore[unresolved-attribute]
            bound_ = sig_.bind(*self._args, **self._kwargs)  # ty: ignore[unresolved-attribute]

            if hasattr(self, "_source"):
                for param in find_artifact_args(sig_):
                    value = bound_.arguments[param]
                    match value:
                        case str():
                            bound_.arguments[param] = self._source.load_artifact(
                                name=value
                            )
                        case (str(), datetime() | str() | int() | None):
                            bound_.arguments[param] = self._source.load_artifact(
                                name=value[0], version=value[1]
                            )

            self._target(*bound_.args, **bound_.kwargs)  # ty: ignore[unresolved-attribute]

        # Release resources
        if hasattr(self, "_semaphore"):
            self._semaphore.release(self._required_threads)


def cadet(
    allocator: ThreadedSemaphore | None = None,
    /,
    num_threads: int = 1,
    source: HasArtifacts | None = None,
):
    """Wrap a function and return an instance of :py:class:`spacecadet.threading.CadetThread`.

    Parameters
    ----------
    allocator : ThreadedSemaphore, optional (default None)
        A thread tracker. This object determines the number of resources (threads) available.
    num_threads : int, optional (default 1)
        Number of threads to reserve for the provided function. This argument is only used if
        an allocator is provided.
    source : HasArtifacts, optional (default None)
        A source lazyscribe-like object that can provide objects at runtime. When
        :py:meth:`spacecadet.threading.CadetThread.start` is called, the objects will be loaded.
    """

    def _inner_deco(func: Callable[..., object]):
        @functools.wraps(func)
        def wrapped(*args, **kwargs):
            """We substitute the arguments here."""
            thread = CadetThread(target=func, args=args, kwargs=kwargs)
            if allocator is not None:
                thread.set_allocator(allocator, num_threads)
            if source is not None:
                thread.set_source(source)

            return thread

        return wrapped

    return _inner_deco
