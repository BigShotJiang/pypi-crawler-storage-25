import yaml
from pathlib import Path
from easysam.generate import generate

def test_onelambda_generation():
    example_path = Path("example/onelambda")
    
    # Custom constructors for SAM tags
    def get_att_constructor(loader, node):
        value = loader.construct_scalar(node)
        return {'Fn::GetAtt': value.split('.')}

    def sub_constructor(loader, node):
        return {'Fn::Sub': loader.construct_scalar(node)}

    def ref_constructor(loader, node):
        return {'Ref': loader.construct_scalar(node)}

    yaml.SafeLoader.add_constructor('!GetAtt', get_att_constructor)
    yaml.SafeLoader.add_constructor('!Sub', sub_constructor)
    yaml.SafeLoader.add_constructor('!Ref', ref_constructor)

    cliparams = {'verbose': True}
    deploy_ctx = {'environment': 'dev', 'target_region': 'us-east-1'}
    
    resources_data, errors = generate(cliparams, example_path, [], deploy_ctx)
    
    assert not errors
    
    template_path = example_path / "template.yml"
    assert template_path.exists()
    
    with open(template_path, 'r') as f:
        template = yaml.safe_load(f)
        
    resources = template['Resources']
    
    # Verify myfunctionFunction
    assert 'myfunctionFunction' in resources
    myfunction = resources['myfunctionFunction']
    assert myfunction['Type'] == 'AWS::Serverless::Function'
    
    # Check if 'Events' is present and if so, if it's empty
    if 'Events' in myfunction['Properties']:
        events = myfunction['Properties']['Events']
        assert events is not None, "Events property should not be None if present"
        assert len(events) > 0, "Events property should not be empty if present"
