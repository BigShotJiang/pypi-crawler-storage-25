drop view a cascade
