drop table a cascade
