import json
import logging
from pathlib import Path
from typing import Any, Optional

from latencyx.config import ExporterType, TimeUnit, config
from latencyx.core import Span


def make_span(
    name: str = "test_op",
    span_type: str = "generic",
    duration_ms: float = 50.0,
    error: Optional[str] = None,
    metadata: Optional[dict] = None,
) -> Span:
    span = Span(name, span_type, metadata or {})
    span.end = span.start + duration_ms / 1000
    span.duration_ms = duration_ms
    span.error = error
    return span


# ---------------------------------------------------------------------------
# ConsoleExporter
# ---------------------------------------------------------------------------


class TestConsoleExporter:
    def test_export_logs_info(self, caplog):
        from latencyx.exporters.console import ConsoleExporter

        exporter = ConsoleExporter()
        span = make_span()
        with caplog.at_level(logging.INFO, logger="latencyx"):
            exporter.export(span)
        assert "test_op" in caplog.text
        assert "50.00ms" in caplog.text

    def test_export_error_logs_at_error_level(self, caplog):
        from latencyx.exporters.console import ConsoleExporter

        exporter = ConsoleExporter()
        span = make_span(error="something failed")
        with caplog.at_level(logging.ERROR, logger="latencyx"):
            exporter.export(span)
        assert "ERROR=something failed" in caplog.text

    def test_export_includes_metadata(self, caplog):
        from latencyx.exporters.console import ConsoleExporter

        exporter = ConsoleExporter()
        span = make_span(metadata={"method": "GET", "status_code": 200})
        with caplog.at_level(logging.INFO, logger="latencyx"):
            exporter.export(span)
        assert "method=GET" in caplog.text
        assert "status=200" in caplog.text  # status_code is shortened to 'status'

    def test_format_duration_milliseconds(self):
        from latencyx.exporters.console import ConsoleExporter

        exporter = ConsoleExporter()
        assert exporter._format_duration(50.0) == "50.00ms"
        assert exporter._format_duration(150.0) == "150.0ms"
        assert exporter._format_duration(1500.0) == "1.50s"

    def test_format_duration_seconds_unit(self):
        from latencyx.exporters.console import ConsoleExporter

        config.time_unit = TimeUnit.SECONDS
        exporter = ConsoleExporter()
        result = exporter._format_duration(500.0)
        assert result == "0.500s"

    def test_priority_field_ordering(self, caplog):
        from latencyx.exporters.console import ConsoleExporter

        exporter = ConsoleExporter()
        span = make_span(metadata={"custom": "data", "status_code": 200, "method": "POST"})
        with caplog.at_level(logging.INFO, logger="latencyx"):
            exporter.export(span)
        # status and method should appear before custom
        log_line = caplog.text
        assert log_line.index("status=200") < log_line.index("custom=data")


# ---------------------------------------------------------------------------
# JsonFileExporter
# ---------------------------------------------------------------------------


class TestJsonFileExporter:
    def test_export_writes_valid_jsonl(self, tmp_path):
        from latencyx.exporters.json_file import JsonFileExporter

        config.json_file_path = str(tmp_path / "traces.jsonl")
        exporter = JsonFileExporter()
        exporter.export(make_span(name="op1", duration_ms=42.0))

        lines = Path(config.json_file_path).read_text().splitlines()
        assert len(lines) == 1
        record = json.loads(lines[0])
        assert record["span_name"] == "op1"
        assert record["duration_ms"] == 42.0
        assert record["status"] == "success"
        assert "timestamp" in record

    def test_export_error_span(self, tmp_path):
        from latencyx.exporters.json_file import JsonFileExporter

        config.json_file_path = str(tmp_path / "traces.jsonl")
        exporter = JsonFileExporter()
        exporter.export(make_span(error="db connection failed"))

        record = json.loads(Path(config.json_file_path).read_text())
        assert record["status"] == "error"
        assert record["error"] == "db connection failed"

    def test_export_flattens_metadata(self, tmp_path):
        from latencyx.exporters.json_file import JsonFileExporter

        config.json_file_path = str(tmp_path / "traces.jsonl")
        exporter = JsonFileExporter()
        exporter.export(make_span(metadata={"status_code": 201, "method": "POST"}))

        record = json.loads(Path(config.json_file_path).read_text())
        assert record["status_code"] == 201
        assert record["method"] == "POST"

    def test_export_appends_multiple_lines(self, tmp_path):
        from latencyx.exporters.json_file import JsonFileExporter

        config.json_file_path = str(tmp_path / "traces.jsonl")
        exporter = JsonFileExporter()
        exporter.export(make_span(name="op1"))
        exporter.export(make_span(name="op2"))
        exporter.export(make_span(name="op3"))

        lines = Path(config.json_file_path).read_text().splitlines()
        assert len(lines) == 3
        assert json.loads(lines[0])["span_name"] == "op1"
        assert json.loads(lines[2])["span_name"] == "op3"

    def test_timestamp_is_utc_aware(self, tmp_path):
        from latencyx.exporters.json_file import JsonFileExporter

        config.json_file_path = str(tmp_path / "traces.jsonl")
        exporter = JsonFileExporter()
        exporter.export(make_span())

        record = json.loads(Path(config.json_file_path).read_text())
        # UTC-aware timestamps end with +00:00
        assert "+00:00" in record["timestamp"]

    def test_export_silently_handles_io_error(self, tmp_path, monkeypatch):
        from latencyx.exporters import json_file as jf_module

        config.json_file_path = str(tmp_path / "traces.jsonl")
        exporter = jf_module.JsonFileExporter()

        def raise_oserror(*a, **kw):
            raise OSError("disk full")

        monkeypatch.setattr("builtins.open", raise_oserror)
        exporter.export(make_span())  # should not raise


# ---------------------------------------------------------------------------
# init_exporters / export_span
# ---------------------------------------------------------------------------


class TestExporterRegistry:
    def test_init_exporters_console(self):
        import latencyx.exporters as exp_module
        from latencyx.exporters.console import ConsoleExporter

        config.exporters = [ExporterType.CONSOLE]
        exp_module.init_exporters()
        assert len(exp_module._exporters) == 1
        assert isinstance(exp_module._exporters[0], ConsoleExporter)

    def test_init_exporters_json_file(self, tmp_path):
        import latencyx.exporters as exp_module
        from latencyx.exporters.json_file import JsonFileExporter

        config.exporters = [ExporterType.JSON_FILE]
        config.json_file_path = str(tmp_path / "t.jsonl")
        exp_module.init_exporters()
        assert len(exp_module._exporters) == 1
        assert isinstance(exp_module._exporters[0], JsonFileExporter)

    def test_init_exporters_both(self, tmp_path):
        import latencyx.exporters as exp_module

        config.exporters = [ExporterType.CONSOLE, ExporterType.JSON_FILE]
        config.json_file_path = str(tmp_path / "t.jsonl")
        exp_module.init_exporters()
        assert len(exp_module._exporters) == 2

    def test_export_span_calls_all_exporters(self, tmp_path, caplog):
        from latencyx.exporters import export_span, init_exporters

        config.exporters = [ExporterType.CONSOLE, ExporterType.JSON_FILE]
        config.json_file_path = str(tmp_path / "t.jsonl")
        init_exporters()

        with caplog.at_level(logging.INFO, logger="latencyx"):
            export_span(make_span(name="multi_export"))

        assert "multi_export" in caplog.text
        assert Path(config.json_file_path).exists()

    def test_export_span_continues_after_exporter_failure(self, tmp_path, caplog):
        """A broken exporter must not prevent other exporters from running."""
        import latencyx.exporters as exp_module

        config.exporters = [ExporterType.JSON_FILE]
        config.json_file_path = str(tmp_path / "t.jsonl")
        exp_module.init_exporters()

        class BrokenExporter:
            def export(self, span: Any) -> None:
                raise RuntimeError("I am broken")

        exp_module._exporters.insert(0, BrokenExporter())

        with caplog.at_level(logging.WARNING, logger="latencyx"):
            exp_module.export_span(make_span(name="resilience_test"))

        assert "BrokenExporter" in caplog.text
        lines = Path(config.json_file_path).read_text().splitlines()
        assert len(lines) == 1
