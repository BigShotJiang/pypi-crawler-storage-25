from py4j.java_gateway import JavaObject


class NIHeaderNode:
    def __init__(self, java_object: JavaObject):
        self._java_object = java_object

    def get_id(self): return self._java_object.getId()
    def set_id(self, v): self._java_object.setId(v)
    def get_name(self): return self._java_object.getName()
    def set_name(self, v): self._java_object.setName(v)
    def get_children(self) -> list['NIHeaderNode']: return [NIHeaderNode(child) for child in self._java_object.getChildren()]
    def set_children(self, v: list['NIHeaderNode']): self._java_object.setChildren([child._java_object for child in v])
    def get_parent_node(self) -> 'NIHeaderNode': return NIHeaderNode(self._java_object.getParentNode())
    def set_parent_node(self, v: 'NIHeaderNode'): self._java_object.setParentNode(v._java_object)
