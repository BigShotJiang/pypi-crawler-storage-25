"""Python wrapper for Java enum NIEnumScanType.

This enum maps the scan types used by the API. It extends
EnumWrapper to provide conversion helpers between Python and Java enums.
"""
from enum import unique
from ..enum_wrapper import EnumWrapper


@unique
class NIEnumScanType(EnumWrapper):
    """Python representation of Java NIEnumScanType."""

    EMPTY = "EMPTY"
    ASCAN = "ASCAN"
    AMPLITUDE_CSCAN = "AMPLITUDE_CSCAN"
    TIME_CSCAN = "TIME_CSCAN"
    SPECIFIC_CSCAN = "SPECIFIC_CSCAN"
    ASCAN_MULTIPIC = "ASCAN_MULTIPIC"
    ASCAN_SYNTHETIC = "ASCAN_SYNTHETIC"
    SEGMENTED_CSCAN = "SEGMENTED_CSCAN"
    RT_SCAN = "RT_SCAN"

    def get_java_enum_class_path(self) -> str:
        """Return the Java enum class path for NIEnumScanType."""
        return "agi.ndtkit.api.model.NIEnumScanType"
