from ..ndtkit_socket_connection import gateway


def to_java_list(py_list):
    java_list = gateway.jvm.java.util.ArrayList()
    for item in py_list:
        java_list.add(item)
    return java_list


def to_java_array(py_list: list[float]):
    object_class = gateway.jvm.float
    java_array = gateway.new_array(object_class, len(py_list))
    for i in range(len(py_list)):
        java_array[i] = float(py_list[i])
    return java_array
