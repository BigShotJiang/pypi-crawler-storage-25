import argparse
from pathlib import Path
from .utils import *


def modify_plugin(args):
    if "port" in args and args.port:
        update_socket_ports(Path("."), args.port)


def main():
    # --- ARGUMENT PARSING ---
    parser = argparse.ArgumentParser(
        description="NDTkit Plugin Creator - Automate the generation of NDTkit plugins.",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog="""
EXAMPLES:
  1. Interactive Mode:
     python script.py

  2. Fully Automated (Java):
     python script.py --language Java --name "MyJavaPlugin" --gui-location "No UI" --is-external no

  3. Fully Automated with custom Port:
     python script.py --language Python --name "VisionTool" --port 8080
"""
    )

    gradle_folder = find_gradle_project()
    if not gradle_folder:
        raise Exception("This command must launched within a NDTkit plugin directory")

    with chdir(gradle_folder):
        # Group 1: General Settings
        general_group = parser.add_argument_group('General Settings')
        general_group.add_argument(
            "--port",
            type=int,
            help="The socket server port number (default: 1212)."
        )

        args = parser.parse_args()

        # --- VALIDATION PHASE ---
        # This runs immediately. If invalid, it prints an error and exits.
        validate_arguments(parser, args)

        modify_plugin(args)


if __name__ == "__main__":
    main()
