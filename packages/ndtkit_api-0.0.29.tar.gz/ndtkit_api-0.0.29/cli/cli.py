import sys
import argparse
from . import create, modify, deploy


def build_args_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="NDTkit CLI for managing your plugins",
        formatter_class=argparse.RawTextHelpFormatter,
        usage="ndtkit <command> [options]",
        add_help=False,
    )

    parser.add_argument(
        "command",
        choices=["create", "modify", "deploy"],
        help=(
            "The action to perform:\n"
            "  create - Generate a new NDTkit plugin\n"
            "  modify - Modify an existing NDTkit plugin\n"
            "  deploy - Deploy the NDTkit plugin"
        )
    )
    return parser


def main():
    parser = build_args_parser()

    # 1. Parse ONLY the command (e.g., "create"), ignore the rest for now
    # args contains the command.
    # remaining_args contains everything else (e.g., ['--name', 'MyPlugin'])
    if len(sys.argv) == 1 or (len(sys.argv) == 2 and sys.argv[1] in ["--help", "-H"]):
        parser.print_help()
        sys.exit(1)

    args, remaining_args = parser.parse_known_args()

    # 2. Prepare the environment for the sub-module
    # We need to trick the sub-module into thinking it was called directly.
    # Current sys.argv might be: ['ndtkit.py', 'create', '--name', 'MyPlugin']
    # The sub-module expects:    ['create.py', '--name', 'MyPlugin']

    # We keep the script name (index 0) but replace the arguments with the remaining ones
    sys.argv = [sys.argv[0]] + remaining_args

    # 3. Dispatch to the correct module
    if args.command == "create":
        create.main()
    elif args.command == "modify":
        modify.main()
    elif args.command == "deploy":
        deploy.main()


if __name__ == "__main__":
    main()
