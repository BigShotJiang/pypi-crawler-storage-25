import sys
import os
import re
import shutil
import subprocess
import stat
from pathlib import Path
from .utils import *


def remove_readonly(func, path, _):
    """
    Helper to force remove read-only files on Windows (fixes PermissionError on .git).
    """
    os.chmod(path, stat.S_IWRITE)
    func(path)


def get_yes_no(prompt):
    """
    Helper function for Yes/No questions (default to No).
    """
    choice = input(f"{prompt} ").strip().lower()
    return choice == 'y'


def update_ndtkit_versions(file_path: str, new_version: str):
    """
    Updates the 'declinationName' and 'apiVersion' values within the
    'ndtkitConfig' block of the specified build.gradle file.
    """
    if not os.path.exists(file_path):
        print(f"Error: The file {file_path} was not found.")
        return

    # Extract version logic
    declination_match = re.match(r"^(\d+\.\d+)", new_version)
    new_declination_version = declination_match.group(1) if declination_match else new_version
    new_api_version = new_version

    print(f"Target version: '{new_version}'")

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        original_content = content

        # Regex patterns
        declination_regex = r'(declinationName\s*=\s*")([^"]+)(")'
        api_regex = r'(apiVersion\s*=\s*")([^"]+)(")'

        # Replace declinationName
        replacement_declination = r'\g<1>{}\g<3>'.format(new_declination_version)
        content = re.sub(declination_regex, replacement_declination, content, count=1)

        if content == original_content:
            print("Warning: 'declinationName' was not found or updated.")

        # Replace apiVersion
        replacement_api = r'\g<1>{}\g<3>'.format(new_api_version)
        content = re.sub(api_regex, replacement_api, content, count=1)

        if content == original_content:
            print("Warning: 'apiVersion' was not found or updated.")

        # Save
        if content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"\nSuccess: File '{file_path}' has been updated.")
        else:
            print("\nNo changes were applied.")

    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")


def update_ndtkit_path(target_gradle_file, ndtkit_path):
    # 2. Read the file
    with open(target_gradle_file, 'r') as file:
        lines = file.readlines()

    # 3. Modify the specific line using Regex
    # We look for: def ndtkitDir = "..."
    pattern = r'(def ndtkitDir\s*=\s*").*?(")'

    for i, line in enumerate(lines):
        # Check if the line matches the pattern
        if re.search(pattern, line):
            # Replace the content inside the quotes with the new path
            # note: we use replace() on the matched line string, or re.sub()
            lines[i] = re.sub(pattern, r'\1' + ndtkit_path.replace('\\', '/') + r'\2', line)
            break  # Stop as soon as we found and modified the line

    # 4. Write the changes back only if we actually changed something
    with open(target_gradle_file, 'w') as file:
        file.writelines(lines)
    print(f"NDTkit path successfully updated in {target_gradle_file}")


def remove_unneeded_template_files(target_directory: Path, plugin_data: dict):
    """
    Deletes directories and files from the cloned template that are not needed
    based on the user's language and automation choices.
    """
    selected_language = plugin_data.get('language')
    source_code_folder = "/src/main/java/com/testia/ndtkit/plugin/pythonplugin/"

    removal_map = {
        'Python': [
            source_code_folder + "/infos",
            source_code_folder + "/preferences",
            source_code_folder + "/ui/preferences",
        ]
    }

    # Execute removals
    for lang, paths_to_remove in removal_map.items():
        if selected_language != lang:
            continue

        for rel_path in paths_to_remove:
            path_to_delete = Path(str(target_directory) + '/' + str(rel_path))

            if path_to_delete.exists():
                try:
                    if path_to_delete.is_dir():
                        shutil.rmtree(path_to_delete, onerror=remove_readonly)
                    else:
                        os.remove(path_to_delete)
                except Exception as e:
                    print(f"    - [WARN] Could not delete {rel_path}: {e}")


def sanitize_name(name):
    """
    Generates different variations of the plugin name for replacement.
    """
    clean_parts = name.strip().split()
    pascal_case = "".join(part.capitalize() for part in clean_parts)
    flat_lower = "".join(part.lower() for part in clean_parts)
    dotted = ".".join(part.lower() for part in clean_parts)
    kebab = "-".join(part.lower() for part in clean_parts)

    return {
        "PythonPlugin": pascal_case,
        "pythonplugin": flat_lower,
        "python.plugin": dotted,
        "python-plugin": kebab
    }


def initialize_git_repository(target_directory: Path):
    """
    Initializes a Git repository in the target directory and makes an initial commit.
    """
    try:
        target_directory.mkdir(parents=True, exist_ok=True)
        git_commands = [
            ["git", "init"],
            ["git", "add", "."],
            ["git", "commit", "-m", "Initial commit"]
        ]

        for command in git_commands:
            subprocess.run(
                command,
                cwd=target_directory,
                check=True,
                capture_output=True,
                text=True
            )
    except subprocess.CalledProcessError as e:
        print(f"Error executing Git command: {e.cmd}")
        print(f"Stderr: {e.stderr.strip()}")
    except FileNotFoundError:
        print("Error: 'git' command not found. Ensure Git is installed and in PATH.")


def get_repo_url(gui_location: str):
    custom_base_repo = os.environ.get("NDTKIT_PLUGIN_TEMPLATE_BASE_REPO")
    base_url = custom_base_repo if custom_base_repo else "https://github.com/cedric-bertrand-testia/"
    if gui_location == "Right Panel":
        return base_url + "ndtkit-plugin-python-right-panel-template.git"
    raise Exception(gui_location + " graphical interface is still not implemented")


def create_plugin(plugin_data):
    """
    Clones the repo, performs replacements, and finally removes git history.
    """
    print("\n" + "="*40)
    print("       PLUGIN GENERATION STARTED       ")
    print("="*40)

    names = sanitize_name(plugin_data['name'])
    target_dir = names["python-plugin"]
    target_path = Path(target_dir)

    # 1. Clone the repository
    repo_url = get_repo_url(plugin_data['gui_location'])

    print(f"[INFO] Cloning template from {repo_url}...")
    try:
        if os.path.exists(target_dir):
            print(f"[ERROR] Directory '{target_dir}' already exists. Aborting.")
            return

        subprocess.check_call(
            ["git", "clone", "--depth", "1", repo_url, target_dir])
    except subprocess.CalledProcessError:
        print("[ERROR] Git clone failed. Check connection/URL.")
        return
    except FileNotFoundError:
        print("[ERROR] Git is not installed or not in PATH.")
        return

    save_config(plugin_data, path=target_dir)
    remove_unneeded_template_files(target_path, plugin_data)
    update_ndtkit_versions(str(target_path) + "/build.gradle", plugin_data.get('ndtkit_version'))
    if 'socket_port' in plugin_data:
        update_socket_ports(target_path, plugin_data['socket_port'])

    # 2. Define Replacements
    replacements = {
        "python.plugin": names["python.plugin"],
        "python-plugin": names["python-plugin"],
        "PythonPlugin": names["PythonPlugin"],
        "pythonplugin": names["pythonplugin"]
    }

    print(f"[INFO] Performing replacements for project: {plugin_data['name']}")
    for target, replacement in replacements.items():
        print(f"      - Replacing '{target}' with '{replacement}'")

    # 3. Traverse directory tree
    for root, dirs, files in os.walk(target_dir, topdown=False):
        if ".git" in root:
            continue

        # A. Process Files
        for filename in files:
            filepath = os.path.join(root, filename)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()

                new_content = content
                for old_str, new_str in replacements.items():
                    new_content = new_content.replace(old_str, new_str)

                if new_content != content:
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(new_content)
            except UnicodeDecodeError:
                pass

            # B. Rename File if needed
            new_filename = filename
            for old_str, new_str in replacements.items():
                if old_str in new_filename:
                    new_filename = new_filename.replace(old_str, new_str)

            if new_filename != filename:
                try:
                    os.rename(filepath, os.path.join(root, new_filename))
                except OSError as e:
                    print(f"[WARN] Could not rename file {filename}: {e}")

        # C. Process Directories
        for dirname in dirs:
            if dirname == ".git":
                continue

            new_dirname = dirname
            for old_str, new_str in replacements.items():
                if old_str in new_dirname:
                    new_dirname = new_dirname.replace(old_str, new_str)

            if new_dirname != dirname:
                old_path = os.path.join(root, dirname)
                new_path = os.path.join(root, new_dirname)
                try:
                    os.rename(old_path, new_path)
                except OSError as e:
                    print(f"[WARN] Could not rename directory {dirname}: {e}")

    # 4. Remove the old .git folder
    print("[INFO] Removing old git history...")
    git_folder = os.path.join(target_dir, ".git")
    if os.path.exists(git_folder):
        shutil.rmtree(git_folder, onerror=remove_readonly)

    initialize_git_repository(target_path)

    if plugin_data['is_external']:
        print('Activation of the configuration for external customers')
        update_ndtkit_path(str(target_path / "build.gradle"), plugin_data['ndtkit_location'])

    try:
        run_gradle_task(target_path, "installJar")
        if plugin_data.get('language') == 'Python':
            python_folder = target_path / f"python-source-code"
            setup_virtual_environment(python_folder)
            if not open_folder_in_vscode(python_folder):
                print(f"""
                ================================================================================
                PYTHON DEVELOPMENT READY
                The Python source files have been successfully copied into {python_folder} directory.
                Socket Port Configured: {plugin_data.get('socket_port', 1212)}
                ...
                ================================================================================
                """)
        elif plugin_data.get('language') == 'Java':
            print(f"""
            ================================================================================
            JAVA DEVELOPMENT READY
            The Java source files have been successfully copied into {plugin_data['name']} directory.
            ...
            ================================================================================
            """)
    except Exception as e:
        print(f"ERROR: {e}")


def main():
    config = ask_questions()
    # Execute generation
    create_plugin(config)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
        sys.exit(0)
