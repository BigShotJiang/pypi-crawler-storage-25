from contextlib import contextmanager
import os
import shutil
import re
import subprocess
import platform
from pathlib import Path
import json
import argparse
import sys


CONFIG_FILE = 'build_config.json'


def get_plugin_class_name(gradle_file_path="./build.gradle") -> str:
    """
    Parses a build.gradle file to find the 'Plugin-Class' attribute in the manifest
    and returns just the class name (e.g., 'TestPort2' from 'com.package.TestPort2').

    Args:
        gradle_file_path (str): Path to the build.gradle file.

    Returns:
        str: The class name if found, otherwise None.
    """

    default_plugin_name = "PythonPlugin"

    if not os.path.exists(gradle_file_path):
        print(f"Error: File not found at {gradle_file_path}")
        return default_plugin_name

    try:
        with open(gradle_file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Regex explanation:
        # ["']          -> Match opening quote (single or double)
        # Plugin-Class  -> The specific key
        # ["']          -> Match closing quote of the key
        # \s*:\s* -> Match the colon with optional whitespace
        # ["']          -> Match opening quote of the value
        # ([^"']+)      -> Capture Group 1: The full class path (stops at the next quote)
        pattern = r'["\']Plugin-Class["\']\s*:\s*["\']([^"\']+)["\']'

        match = re.search(pattern, content)

        if match:
            full_class_path = match.group(1)  # e.g., com.testia.ndtkit.plugin.testport2.pf4j.PythonPlugin

            # Split by '.' and take the last part to get just the class name
            class_name = full_class_path.split('.')[-1]
            return class_name
        else:
            print("Warning: 'Plugin-Class' attribute not found in the manifest.")
            return default_plugin_name

    except Exception as e:
        print(f"An error occurred: {e}")
        return default_plugin_name


def run_gradle_task(project_path: Path, task_name: str):
    """
    Executes a specific Gradle task using the Gradle Wrapper found in the project_path.
    """
    project_path = project_path.resolve()

    if not (project_path / "build.gradle").exists():
        raise FileNotFoundError(f"The directory '{project_path}' does not contain a Gradle build file.")

    # Determine the wrapper executable based on the OS
    if os.name == 'nt':  # Windows
        wrapper_name = 'gradlew.bat'
    else:  # Linux/macOS
        wrapper_name = 'gradlew'

    wrapper_path = project_path / wrapper_name

    if not wrapper_path.exists():
        raise FileNotFoundError(f"Gradle wrapper not found at: {wrapper_path}")

    command = [str(wrapper_path), task_name]

    print("Executing " + str(command))
    subprocess.run(
        command,
        cwd=project_path,
        check=True,
        text=True
    )


def update_socket_ports(target_directory: Path, new_port: int):
    """
    Searches for specific configuration files and updates the default socket port.
    """
    print(f"[INFO] Updating socket port to {new_port}...")

    # We need to find the files recursively because their location might have changed
    # due to the renaming process.
    target_files = {
        "configuration.py": {
            # Pattern: def get_port_from_config(default_port=1212) -> int:
            "regex": r"(def get_port_from_config\(default_port=)(\d+)(\) -> int:)",
            "replacement": f"\\g<1>{new_port}\\g<3>"
        },
        get_plugin_class_name() + "Configuration.java": {
            # Pattern: int defaultPort = 1212;
            "regex": r"(int\s+defaultPort\s+=\s+)(\d+)(;)",
            "replacement": f"\\g<1>{new_port}\\g<3>"
        }
    }

    found_count = 0

    # Walk through the directory to find the files
    for root, _, files in os.walk(target_directory):
        for filename in files:
            if filename in target_files:
                file_path = os.path.join(root, filename)
                config = target_files[filename]

                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()

                    # Perform substitution
                    new_content = re.sub(config["regex"], config["replacement"], content)

                    if new_content != content:
                        with open(file_path, 'w', encoding='utf-8') as f:
                            f.write(new_content)
                        print(f"      - Updated port in: {filename}")
                        found_count += 1
                    else:
                        print(f"      - [WARN] Port pattern not found in {filename}")

                except Exception as e:
                    print(f"      - [ERROR] Failed to update {filename}: {e}")

    if found_count == 0:
        print("      - [WARN] No configuration files found to update the port.")


def validate_arguments(parser, args):
    """
    Performs strict validation on provided command line arguments.
    If an argument is invalid, the script exits immediately.
    """
    # 1. Validate Name format
    if "name" in args and args.name:
        if re.search(r"[^a-zA-Z0-9_\s]", args.name):
            parser.error(f"Invalid --name '{args.name}'. Name must only contain letters, numbers, spaces, or underscores.")

    # 2. Validate Port Range
    if "port" in args and args.port:
        if not (1024 <= args.port <= 65535):
            parser.error(f"Invalid --port '{args.port}'. Port must be between 1024 and 65535.")

    # 3. Validate NDTkit Location (only if provided)
    if "ndtkit_location" in args and args.ndtkit_location:
        if not os.path.exists(args.ndtkit_location):
            parser.error(f"Invalid --ndtkit-location '{args.ndtkit_location}'. Directory does not exist.")
        if not os.path.exists(os.path.join(args.ndtkit_location, "NDTkit.jar")):
            parser.error(f"Invalid --ndtkit-location. 'NDTkit.jar' not found in '{args.ndtkit_location}'.")

    # 4. Validate Menu Position (simple positive integer check)
    if "menu_position" in args and args.menu_position is not None:
        if args.menu_position < 0:
            parser.error(f"Invalid --menu-position '{args.menu_position}'. Must be a positive integer.")


def find_gradle_project(directory=".", limit=12):
    """
    Searches for a Gradle project in the current directory and its parents.

    Args:
        directory (str): The starting path. Defaults to current directory.
        limit (int): How many parent directories to climb before giving up.

    Returns:
        str: The path to the Gradle project root if found, None otherwise.
    """
    # Convert to absolute path to ensure os.path.dirname works correctly
    current_dir = os.path.abspath(directory)

    gradle_markers = [
        "build.gradle",
        "build.gradle.kts",
        "settings.gradle",
        "settings.gradle.kts"
    ]

    for _ in range(limit + 1):
        # Check if any marker exists in the current iteration's directory
        if any(os.path.isfile(os.path.join(current_dir, m)) for m in gradle_markers):
            return current_dir

        # Move to the parent directory
        parent_dir = os.path.dirname(current_dir)

        # Stop if we've reached the root of the file system
        if parent_dir == current_dir:
            break

        current_dir = parent_dir

    return None


def get_vscode_path():
    """
    Attempts to find the VS Code executable path.
    Returns the command/path if found, otherwise None.
    """
    # 1. Check if 'code' is in the system PATH (Works for Win/Mac/Linux)
    # This is the standard way developers use VS Code from CLI.
    path_in_env = shutil.which("code")
    if path_in_env:
        return path_in_env

    # 2. Fallback: Check default installation directories if not in PATH
    system = platform.system()

    if system == "Windows":
        # Check User Install (AppData) and System Install (Program Files)
        possible_paths = [
            os.path.expandvars(r"%LOCALAPPDATA%/Programs/Microsoft VS Code/bin/code.cmd"),
            os.path.expandvars(r"%PROGRAMFILES%/Microsoft VS Code/bin/code.cmd"),
            os.path.expandvars(r"%PROGRAMFILES(x86)%/Microsoft VS Code/bin/code.cmd"),
        ]
        for p in possible_paths:
            if os.path.exists(p):
                return p

    elif system == "Darwin":  # macOS
        # Standard application folder
        mac_path = "/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code"
        if os.path.exists(mac_path):
            return mac_path

    elif system == "Linux":
        # Common snap or standard install locations
        possible_paths = ["/usr/bin/code", "/snap/bin/code"]
        for p in possible_paths:
            if os.path.exists(p):
                return p

    return None


def open_folder_in_vscode(folder_path, file_to_open="main.py") -> bool:
    """
    Opens the folder in VS Code. 
    If 'file_to_open' exists inside that folder, it opens that file as well.
    """
    target_path = Path(folder_path).resolve()

    if not target_path.exists():
        print(f"[ERROR] The folder '{target_path}' does not exist.")
        return False

    vscode_cmd = get_vscode_path()

    if vscode_cmd:
        print(f"[INFO] VS Code found at: {vscode_cmd}")

        # Base command: code <folder>
        cmd = [vscode_cmd, str(target_path)]

        # Check if the specific file exists inside the folder
        target_file = target_path / file_to_open
        if target_file.exists():
            print(f"[INFO] Opening specific file: {target_file.name}")
            # Append the file path to the command: code <folder> <file>
            cmd.append(str(target_file))

        try:
            print(f"[INFO] Launching VS Code...")
            subprocess.run(cmd, check=True)
            return True
        except Exception as e:
            print(f"[ERROR] Failed to launch VS Code: {e}")
    return False


def load_config(path=".") -> dict:
    """Loads configuration from the JSON file if it exists."""
    full_path = os.path.join(path, CONFIG_FILE)
    if os.path.exists(full_path):
        try:
            with open(full_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            print(f"Error: Config file '{full_path}' is corrupted. It will be reset.")
            os.remove(full_path)
            return {}
    return {}


def save_config(config, path="."):
    """Saves the configuration to the JSON file, creating the folder if needed."""
    try:
        if path and path != "." and not os.path.exists(path):
            os.makedirs(path, exist_ok=True)
            print(f"Created missing directory: {os.path.abspath(path)}")

        full_path = os.path.join(path, CONFIG_FILE)

        with open(full_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4)

        config_path = os.path.abspath(full_path)
        print(f"\nConfiguration successfully saved to: {config_path}")
        print("Please delete/edit this file if any configuration has changed")
    except IOError as e:
        print(f"Error saving configuration file: {e}")


def read_ndtkit_version(ndtkit_location: str) -> str:
    """Reads the NDTkit version from the version.txt file in the given location."""
    version_file = os.path.join(ndtkit_location, "version.txt")
    try:
        with open(version_file, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            match = re.search(r'(\d+\.\d+\.\d+)', content)
            if match:
                return match.group(1)
    except Exception as e:
        print(f"Error reading NDTkit version from '{version_file}': {e}")
    return "4.1.0"  # Default version if not found


def get_user_selection(prompt, options):
    """
    Helper function to display a numbered list of options and get a valid index.
    """
    still_not_available = []
    print(prompt)
    for i, option in enumerate(options, 1):
        print(f"    {i} - {option}")
        if option.endswith("(available soon)"):
            still_not_available.append(option)

    while True:
        try:
            choice = input("Select an option: ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(options):
                if options[idx] in still_not_available:
                    print(f"Option '{options[idx]}' is not available yet.")
                    continue
                return options[idx]
            print(f"Please enter a number between 1 and {len(options) - len(still_not_available)}.")
        except ValueError:
            print("Invalid input. Please enter a number.")


def parse_arguments():
    # --- ARGUMENT PARSING ---
    parser = argparse.ArgumentParser(
        description="NDTkit Plugin Creator - Automate the generation of NDTkit plugins.",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog="""
            EXAMPLES:
            1. Interactive Mode:
                python script.py

            2. Fully Automated (Java):
                python script.py --language Java --name "MyJavaPlugin" --gui-location "No UI" --is-external no

            3. Fully Automated with custom Port:
                python script.py --language Python --name "VisionTool" --port 8080
            """
    )

    # Group 1: General Settings
    general_group = parser.add_argument_group('General Settings')
    general_group.add_argument(
        "--language",
        choices=["Java", "Python"],
        help="The target programming language for the plugin."
    )
    general_group.add_argument(
        "--name",
        help="The name of the plugin (letters, numbers, underscores only)."
    )
    general_group.add_argument(
        "--ndtkit-version",
        help="The target NDTkit version (default: 4.1.0)."
    )

    general_group.add_argument(
        "--port",
        type=int,
        help="The socket server port number (default: 1212)."
    )

    # Group 2: UI / Graphical Interface
    ui_group = parser.add_argument_group('UI Settings')
    ui_group.add_argument(
        "--gui-location",
        choices=["Right Panel", "Menu (available soon)", "Both (available soon)", "No UI (available soon)"],
        help="Where the plugin's graphical interface should appear."
    )
    ui_group.add_argument(
        "--target-menu",
        choices=["File", "Edit", "View", "Tools", "Help"],
        help="The parent menu if 'Menu' or 'Both' is selected."
    )
    ui_group.add_argument(
        "--menu-position",
        type=int,
        help="The integer position index within the target menu."
    )

    # Group 3: External Company Configuration
    ext_group = parser.add_argument_group('External Configuration')
    ext_group.add_argument(
        "--is-external",
        choices=['yes', 'y', 'true', '1', 'no', 'n', 'false', '0'],
        help="Flag to configure the build for external customers."
    )
    ext_group.add_argument(
        "--ndtkit-location",
        help="Absolute path to the NDTkit installation folder."
    )

    args = parser.parse_args()

    # --- VALIDATION PHASE ---
    # This runs immediately. If invalid, it prints an error and exits.
    validate_arguments(parser, args)
    return args


def ask_questions(is_for_creation: bool = True) -> dict:
    args = parse_arguments()
    print("--- NDTkit Plugin Creator ---\n")
    plugin_config = {} if is_for_creation else load_config()
    provided_args = {k: v for k, v in vars(args).items() if v is not None}
    plugin_config.update(provided_args)

    q_idx = 0
    # 0 - Target Programming Language

    plugin_config['language'] = "Python"

    # if not plugin_config.get('language'):
    #     languages = ["Java", "Python"]
    #     plugin_config['language'] = get_user_selection(
    #         f"{q_idx} - What is the target programming language?",
    #         languages
    #     )
    print()
    q_idx += 1

    # 1 - Plugin Name
    if not plugin_config.get('name'):
        while True:
            name = input(f"{q_idx} - Plugin Name (e.g. 'My Plugin'): ").strip()
            if re.search(r"[^a-zA-Z0-9_\s]", name):
                print("Invalid input. The name must only contain letters, numbers, spaces, or underscores.")
                continue
            if name:
                plugin_config['name'] = name
                break
            print("Name cannot be empty.")
    print()
    q_idx += 1

    # 3 - GUI Location
    gui_locations = ["Right Panel", "Menu (available soon)", "Both (available soon)", "No UI (available soon)"]

    if not plugin_config.get('gui_location'):
        selected_gui = get_user_selection(
            f"{q_idx} - The graphical interface must appear in:",
            gui_locations
        )
        plugin_config['gui_location'] = selected_gui
    print()
    q_idx += 1

    # Conditional: Menu selection
    if plugin_config['gui_location'] in ["Menu", "Both"]:
        menus = ["File", "Edit", "View", "Tools", "Help"]

        if not plugin_config.get('target_menu'):
            target_menu = get_user_selection(
                f"{q_idx} - In which menu should the tool appear?",
                menus
            )
            plugin_config['target_menu'] = target_menu
        print()
        q_idx += 1

        if not plugin_config.get('menu_position'):
            while True:
                try:
                    pos = input(f"{q_idx} - Position in '{plugin_config['target_menu']}' (integer): ").strip()
                    plugin_config['menu_position'] = int(pos)
                    break
                except ValueError:
                    print("Please enter a valid integer.")
        print()
        q_idx += 1
    else:
        plugin_config['target_menu'] = None
        plugin_config['menu_position'] = None

    # is_external Logic
    truthy = ['yes', 'y', 'true', '1']
    plugin_config['is_external'] = str(plugin_config.get('is_external')).lower() in truthy if plugin_config.get('is_external') else True

    print()
    q_idx += 1

    # If external, get NDTkit location
    if plugin_config['is_external']:
        if not plugin_config.get('ndtkit_location'):
            while True:
                ndtkit_location = input(f"{q_idx} - NDTkit installation folder: ").strip()
                if ndtkit_location and os.path.exists(ndtkit_location) and os.path.exists(os.path.join(ndtkit_location, "version.txt")):
                    plugin_config['ndtkit_location'] = ndtkit_location
                    plugin_config['ndtkit_version'] = read_ndtkit_version(ndtkit_location)
                    plugin_config['declination'] = "UT"  # TODO read the declination within the installation folder
                    break
                else:
                    print("Please enter a valid path for NDTkit installation folder")
    else:
        # 2 - NDTkit Version
        if not plugin_config.get('ndtkit_version'):
            plugin_config['ndtkit_version'] = '4.1.0'
            version = input(f"{q_idx} - Target NDTkit version (default '4.1.0'): ").strip()
            if version:
                plugin_config['ndtkit_version'] = version
        plugin_config['declination'] = "UT"  # TODO ask for declination
    print()
    q_idx += 1
    return plugin_config


def setup_virtual_environment(python_dir: Path):
    """
    Creates a Python virtual environment (.venv), installs requirements,
    and configures VS Code to use it automatically.
    """
    print(f"\n[INFO] Setting up Python Virtual Environment in {python_dir.name}...")
    venv_dir = python_dir / ".venv"

    try:
        if sys.version_info[0] < 3 or (sys.version_info[0] == 3 and sys.version_info[1] < 11):
            raise RuntimeError(f"Error: Python 3.11 or higher is required. Current version: {sys.version_info.major}.{sys.version_info.minor}")

        # 1. Create the virtual environment
        print("      - Creating .venv folder...")
        # sys.executable ensures we use the same Python version running this script
        subprocess.run([sys.executable, "-m", "venv", str(venv_dir)], check=True)

        # 2. Determine paths based on OS
        if platform.system() == "Windows":
            pip_exe = venv_dir / "Scripts" / "pip.exe"
        else:
            pip_exe = venv_dir / "bin" / "pip"

        # 3. Upgrade pip using the venv executable
        # Define the path to the .venv Python executable (Windows specific)
        python_exe = venv_dir / "Scripts" / "python.exe"

        if not python_exe.exists():
            raise FileNotFoundError(f"Python executable not found at {python_exe}")

        print("[INFO] Upgrading pip...")
        subprocess.run(
            [str(python_exe), "-m", "pip", "install", "--upgrade", "pip"],
            check=True,
            capture_output=False  # Set to True if you want to hide pip logs in the console
        )

        # 3. Install requirements
        req_file = python_dir / "requirements.txt"
        if not req_file.exists():
            print("[INFO] No requirements.txt found. Skipping venv creation.")
            return

        print("      - Installing dependencies (this may take a moment)...")
        subprocess.run([str(pip_exe), "install", "--only-binary", "pydantic-core", "-r", "requirements.txt"], cwd=python_dir, check=True)

        # 4. Configure VS Code to use this venv automatically
        print("      - Configuring VS Code workspace...")
        vscode_dir = python_dir / ".vscode"
        vscode_dir.mkdir(exist_ok=True)
        settings_file = vscode_dir / "settings.json"

        settings = {}
        if settings_file.exists():
            try:
                with open(settings_file, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
            except json.JSONDecodeError:
                pass

        # Determine strict relative paths based on the OS
        if platform.system() == "Windows":
            python_exe_rel = "${workspaceFolder}/.venv/Scripts/python.exe"
            site_packages_rel = "${workspaceFolder}/.venv/Lib/site-packages"
        else:
            python_exe_rel = "${workspaceFolder}/.venv/bin/python"
            # Linux/Mac structure depends on the exact Python version (e.g., lib/python3.10/site-packages)
            py_version = f"python{sys.version_info.major}.{sys.version_info.minor}"
            site_packages_rel = f"${{workspaceFolder}}/.venv/lib/{py_version}/site-packages"

        # 1. Force the default interpreter path (relative path is safer here)
        settings["python.defaultInterpreterPath"] = python_exe_rel

        # 2. Give Pylance a direct map to the installed dependencies
        if "python.analysis.extraPaths" not in settings:
            settings["python.analysis.extraPaths"] = []

        if site_packages_rel not in settings["python.analysis.extraPaths"]:
            settings["python.analysis.extraPaths"].append(site_packages_rel)

        # 3. Ensure the integrated terminal activates the venv automatically
        settings["python.terminal.activateEnvironment"] = True

        with open(settings_file, 'w', encoding='utf-8') as f:
            json.dump(settings, f, indent=4)

        print("[SUCCESS] Virtual environment ready.")

    except subprocess.CalledProcessError as e:
        print(f"[ERROR] Failed to setup virtual environment: {e}")
    except Exception as e:
        print(f"[ERROR] Unexpected error during venv setup: {e}")


@contextmanager
def chdir(path):
    """Custom context manager to change directory."""
    old_dir = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(old_dir)
