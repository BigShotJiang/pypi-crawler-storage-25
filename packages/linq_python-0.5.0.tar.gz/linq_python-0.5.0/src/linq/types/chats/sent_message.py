# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from ..._models import BaseModel
from ..reply_to import ReplyTo
from ..message_effect import MessageEffect
from ..shared.chat_handle import ChatHandle
from ..shared.service_type import ServiceType
from ..shared.link_part_response import LinkPartResponse
from ..shared.text_part_response import TextPartResponse
from ..shared.media_part_response import MediaPartResponse

__all__ = ["SentMessage", "Part"]

Part: TypeAlias = Union[TextPartResponse, MediaPartResponse, LinkPartResponse]


class SentMessage(BaseModel):
    """A message that was sent (used in CreateChat and SendMessage responses)"""

    id: str
    """Message identifier (UUID)"""

    created_at: datetime
    """When the message was created"""

    delivery_status: Literal["pending", "queued", "sent", "delivered", "failed"]
    """Current delivery status of a message"""

    is_read: bool
    """Whether the message has been read"""

    parts: List[Part]
    """Message parts in order (text, media, and link)"""

    sent_at: Optional[datetime] = None
    """When the message was actually sent (null if still queued)"""

    delivered_at: Optional[datetime] = None
    """When the message was delivered"""

    effect: Optional[MessageEffect] = None
    """iMessage effect applied to a message (screen or bubble effect)"""

    from_handle: Optional[ChatHandle] = None
    """The sender of this message as a full handle object"""

    preferred_service: Optional[ServiceType] = None
    """Messaging service type"""

    reply_to: Optional[ReplyTo] = None
    """Indicates this message is a threaded reply to another message"""

    service: Optional[ServiceType] = None
    """Messaging service type"""
