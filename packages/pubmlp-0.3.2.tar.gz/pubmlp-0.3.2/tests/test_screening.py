"""Tests for pubmlp.screening module."""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path
from unittest.mock import patch, MagicMock

from pubmlp.screening import (
    extract_window_evidence,
    extract_sentence_evidence,
    format_evidence_display,
    score_full_text,
    generate_descriptions,
    confirm_descriptions,
    _extract_terms,
)


SAMPLE_ABSTRACT = (
    "This study examines mathematical difficulties among elementary school students. "
    "We investigated how linguistic factors influence algebra performance. "
    "Results show significant correlations between vocabulary and math achievement."
)


class TestWindowEvidence:
    def test_match_found(self):
        evidence = extract_window_evidence(SAMPLE_ABSTRACT, r'\bmath\w*\b', 'abstract', window_size=3)
        assert len(evidence) > 0
        assert evidence[0]['field'] == 'abstract'
        assert 'matched_term' in evidence[0]

    def test_no_match(self):
        evidence = extract_window_evidence("no relevant terms here", r'\bmath\w*\b', 'abstract')
        assert evidence == []

    def test_na_input(self):
        assert extract_window_evidence(None, r'\bmath\w*\b', 'abstract') == []
        assert extract_window_evidence('', r'\bmath\w*\b', 'abstract') == []

    def test_deduplication(self):
        text = "math math math"
        evidence = extract_window_evidence(text, r'\bmath\b', 'title', window_size=0)
        texts = [e['text'] for e in evidence]
        assert len(texts) == len(set(texts))


class TestSentenceEvidence:
    def test_match_found(self):
        evidence = extract_sentence_evidence(SAMPLE_ABSTRACT, r'\balgebra\w*\b', 'abstract')
        assert len(evidence) == 1
        assert 'algebra' in evidence[0]['text'].lower()

    def test_no_match(self):
        evidence = extract_sentence_evidence("No relevant terms.", r'\bcalculus\b', 'abstract')
        assert evidence == []

    def test_multiple_sentences(self):
        evidence = extract_sentence_evidence(SAMPLE_ABSTRACT, r'\bmath\w*\b', 'abstract')
        assert len(evidence) >= 2


class TestFormatEvidence:
    def test_formatting(self):
        evidence = [
            {'text': 'some text', 'field': 'abstract', 'matched_term': 'math'},
            {'text': 'other text', 'field': 'title', 'matched_term': 'algebra'},
        ]
        result = format_evidence_display(evidence)
        assert 'abstract: some text' in result
        assert 'title: other text' in result
        assert '; ' in result

    def test_empty(self):
        assert format_evidence_display([]) == ''


class TestScoreFullText:
    @pytest.fixture
    def sample_df(self):
        return pd.DataFrame({
            'title': [
                'Single-case design in special education',
                'Cooking recipes for beginners',
                'Multiple baseline reading intervention',
            ],
            'abstract': [
                'A multiple baseline design evaluated reading interventions for students.',
                'A guide to cooking Italian pasta dishes at home.',
                'Alternating treatment design compared two math interventions.',
            ],
        })

    @patch('pubmlp.screening.SentenceTransformer')
    def test_adds_semantic_full_columns(self, mock_st_class, sample_df):
        mock_model = MagicMock()
        mock_st_class.return_value = mock_model
        mock_model.encode.side_effect = [
            np.array([[0.9, 0.1], [0.1, 0.9], [0.7, 0.3]]),  # texts
            np.array([[0.8, 0.2]]),  # description
        ]

        patterns = {'math': {'pattern': r'\bmath\w*\b', 'description': 'mathematics education'}}
        result = score_full_text(sample_df.copy(), patterns)

        assert 'math_semantic_full' in result.columns
        assert len(result) == 3
        assert not result['math_semantic_full'].isna().any()

    @patch('pubmlp.screening.SentenceTransformer')
    def test_skips_empty_description(self, mock_st_class, sample_df):
        mock_model = MagicMock()
        mock_st_class.return_value = mock_model
        mock_model.encode.return_value = np.array([[0.5, 0.5]] * 3)

        patterns = {'math': {'pattern': r'\bmath\w*\b', 'description': ''}}
        result = score_full_text(sample_df.copy(), patterns)

        assert 'math_semantic_full' not in result.columns

    def test_missing_fields_raises(self, sample_df):
        patterns = {'math': {'pattern': r'\bmath\w*\b', 'description': 'test'}}
        with pytest.raises(ValueError, match="None of"):
            with patch('pubmlp.screening.SentenceTransformer'):
                score_full_text(sample_df.copy(), patterns, fields=['nonexistent'])


class TestExtractTerms:
    def test_simple_alternation(self):
        terms = _extract_terms(r'\b(algebra|calculus|geometry)\w*\b')
        assert 'algebra' in terms
        assert 'calculus' in terms
        assert 'geometry' in terms

    def test_hyphenated_terms(self):
        terms = _extract_terms(r'\bsingle[\s-]?case\b')
        assert 'single' in terms
        assert 'case' in terms

    def test_deduplication(self):
        terms = _extract_terms(r'\b(math|math|algebra)\w*\b')
        assert terms.count('math') == 1

    def test_filters_short_tokens(self):
        terms = _extract_terms(r'\b(a|algebra)\w*\b')
        assert 'a' not in terms
        assert 'algebra' in terms


class TestGenerateDescriptions:
    def test_generates_from_pattern(self):
        patterns = {'math': {'pattern': r'\b(algebra|geometry)\w*\b'}}
        result = generate_descriptions(patterns)

        assert 'math' in result
        assert 'algebra' in result['math']['description']
        assert result['math']['source'] == 'generated'

    def test_preserves_existing_description(self):
        patterns = {'math': {'pattern': r'\bmath\w*\b', 'description': 'custom description'}}
        result = generate_descriptions(patterns)

        assert result['math']['description'] == 'custom description'
        assert result['math']['source'] == 'user-provided'

    def test_domain_prefix(self):
        patterns = {'math': {'pattern': r'\b(algebra)\w*\b'}}
        result = generate_descriptions(patterns, domain='K-12 education')

        assert result['math']['description'].startswith('In K-12 education')

    def test_no_domain(self):
        patterns = {'math': {'pattern': r'\b(algebra)\w*\b'}}
        result = generate_descriptions(patterns)

        assert result['math']['description'].startswith('The study')


class TestConfirmDescriptions:
    def test_returns_confirmed(self):
        drafts = {
            'math': {'pattern': r'\bmath\b', 'description': 'math studies', 'source': 'generated'},
            'lang': {'pattern': r'\blang\b', 'description': 'language studies', 'source': 'generated'},
        }
        confirmed = confirm_descriptions(drafts)

        assert 'math' in confirmed
        assert confirmed['math']['description'] == 'math studies'
        assert 'source' not in confirmed['math']

    def test_raises_on_empty_description(self):
        drafts = {
            'math': {'pattern': r'\bmath\b', 'description': ''},
        }
        with pytest.raises(ValueError, match="Empty descriptions"):
            confirm_descriptions(drafts)

    def test_saves_to_json(self, tmp_path):
        drafts = {'math': {'pattern': r'\bmath\b', 'description': 'test', 'source': 'generated'}}
        path = str(tmp_path / 'confirmed.json')
        confirm_descriptions(drafts, save_path=path)

        import json
        with open(path) as f:
            saved = json.load(f)
        assert saved['math']['description'] == 'test'
