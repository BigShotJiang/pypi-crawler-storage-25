"""Model-visible schema descriptions for built-in tools."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from typing import Any

from .runtime import ToolDefinition

_STRING_ARRAY_SCHEMA: Mapping[str, Any] = {"type": "string"}

_PROPERTY_DESCRIPTIONS: Mapping[str, Mapping[str, str]] = {
    "tool.terminal.exec": {
        "command": "Shell command to run in a bounded subprocess.",
        "cwd": "Working directory override for this command.",
        "timeout_seconds": "Maximum foreground command runtime in seconds.",
        "background": "Start the command as a managed background process.",
        "env": "Additional environment variables for the command.",
    },
    "tool.process.manage": {
        "process_id": "Managed process id returned by a background terminal command.",
        "input": "Text to write to the managed process stdin when action=write.",
        "timeout_seconds": "Maximum time to wait for a process action.",
    },
    "tool.browser.navigate": {"url": "URL to open in the active browser session."},
    "tool.browser.snapshot": {"full": "Capture the full page snapshot instead of the compact view."},
    "tool.browser.type": {"text": "Text to type into the referenced browser element."},
    "tool.browser.scroll": {
        "direction": "Scroll direction.",
        "amount": "Scroll amount in backend-defined units.",
    },
    "tool.browser.press": {"key": "Keyboard key to press, such as Enter or Escape."},
    "tool.browser.vision": {
        "question": "Question for the vision analyzer about the current browser screenshot.",
        "prompt": "Alternate prompt for the vision analyzer.",
        "annotate": "Whether to include visual annotations when supported.",
    },
    "tool.browser.console": {
        "clear": "Clear buffered console entries after reading them.",
        "expression": "JavaScript expression to evaluate in the page context.",
    },
    "tool.clarify": {
        "question": "Question to ask the user.",
        "mode": "Use open for free-form input or choice for a bounded option list.",
        "choices": "Choice labels for mode=choice, as an array or newline/comma-delimited string.",
    },
    "tool.cron.manage": {
        "profile_id": "Optional profile scope filter for listing or creating jobs.",
        "clone_id": "Optional clone scope filter for listing or creating jobs.",
    },
    "tool.sub_agents": {
        "action": "Use run|start to launch one bounded sub-agent task or a small task pool.",
        "name": "Optional label for a single sub-agent.",
        "task": "Single sub-agent assignment.",
        "prompt": "Alias for task when launching a single sub-agent.",
        "tasks": "Array of bounded sub-agent assignments for a small parallel pool.",
        "tasks[].name": "Optional label for this sub-agent task.",
        "tasks[].task": "Assignment for this sub-agent task.",
        "tasks[].prompt": "Alias for task in a task-list item.",
        "tasks[].skills": "Skill ids to load for this sub-agent task.",
        "max_concurrency": "Maximum parallel sub-agent tasks to run.",
        "skills": "Skill ids to load for a single sub-agent task.",
    },
    "tool.memory.recall": {
        "action": "Use list|ls to enumerate, inspect with memory_id, lineage with memory_id, or search with query.",
        "memory_id": "Durable memory id to inspect or trace.",
        "query": "Recall search query.",
        "limit": "Maximum number of recall search results.",
    },
    "tool.memory.upload": {
        "action": "Use correct with content, delete with reason, or pin|unpin with memory_id.",
        "memory_id": "Durable memory id to mutate.",
        "content": "Corrected memory content when action=correct.",
        "reason": "Reason for the memory governance change.",
    },
    "tool.message.send": {
        "body": "Outbound message body.",
        "target": "Optional delivery target override.",
        "metadata": "Optional delivery metadata.",
    },
    "tool.todo.manage": {
        "item_id": "Todo item id for inspect, update, complete, reopen, remove, delete, or promote.",
        "title": "Todo title when creating or updating an item.",
        "status": "Todo status when creating or updating an item.",
        "notes": "Todo notes when creating or updating an item.",
    },
    "tool.skill.manage": {
        "action": "Use install, enable, disable, create, update, delete, or remove for operator-owned skill changes.",
    },
    "tool.profile.manage": {
        "action": "Use inspect|show|get to read profile state or patch|update|set with one or more profile fields.",
        "display_name": "Profile display name.",
        "name": "Alias for profile display name when patching.",
        "personality_preset": "Personality preset id or label.",
        "initiative": "Initiative posture or guidance for the profile.",
        "charter_text": "Replacement identity charter text.",
        "text": "Generic profile text patch payload.",
        "content": "Generic profile content patch payload.",
        "clear_charter": "Clear the stored identity charter.",
        "user_text": "Replacement or appended user-state text.",
        "user_content": "Alias for user_text.",
        "user_fields": "Structured user-state fields to patch.",
        "user_append": "Append user text instead of replacing it.",
        "user_clear": "Clear the stored user-state text.",
        "relationship_text": "Replacement or appended relationship-continuity text.",
        "relationship_content": "Alias for relationship_text.",
        "relationship_append": "Append relationship text instead of replacing it.",
        "relationship_clear": "Clear the stored relationship-continuity text.",
    },
    "tool.activity.manage": {
        "action": "Use list|ls|show, inspect, create, focus|activate, update, or drop|delete.",
        "goal_id": "Durable activity goal id to inspect, update, focus, or drop.",
        "parent_goal_id": "Parent goal id when creating a child activity.",
        "title": "Activity title when creating or updating.",
        "status": "Activity status when creating or updating.",
        "priority": "Activity priority when creating or updating.",
        "owner": "Activity owner when creating.",
        "dependency_refs": "Dependency references for a new activity.",
        "evidence_refs": "Evidence references for a new activity.",
        "related_memory_ids": "Related durable memory ids for a new activity.",
        "review_checkpoint": "Review checkpoint text for a new activity.",
        "deadline": "Deadline or due date for a new activity.",
        "time_sensitivity": "Time-sensitivity label for a new activity.",
        "reason": "Reason for the activity mutation.",
        "activate": "Whether a created activity should become active immediately.",
    },
    "tool.procedure.inspect": {
        "action": "Use list|ls|show to enumerate candidates, or inspect with procedure_id.",
        "procedure_id": "Procedure id to inspect.",
        "minimum_support": "Minimum supporting evidence count for listing procedure candidates.",
    },
    "tool.procedure.manage": {
        "action": "Use patch|update with mutable fields, or retire with procedure_id.",
        "procedure_id": "Promoted procedure id to patch or retire.",
        "title": "Replacement procedure title.",
        "summary": "Replacement procedure summary.",
        "content": "Replacement procedure body.",
        "trigger_refs": "Trigger references for the procedure.",
        "status": "Replacement procedure status.",
    },
}


def enrich_builtin_tool_schema(definition: ToolDefinition) -> ToolDefinition:
    """Return a built-in definition with complete model-visible schema guidance."""

    schema = _enrich_schema(definition.tool_id, definition.schema, ())
    return definition if schema == definition.schema else replace(definition, schema=schema)


def _enrich_schema(tool_id: str, schema: Mapping[str, Any], path: tuple[str, ...]) -> Mapping[str, Any]:
    enriched = {str(key): value for key, value in schema.items()}
    properties = enriched.get("properties")
    if isinstance(properties, Mapping):
        enriched["properties"] = {
            str(name): _enrich_property(tool_id, str(name), payload, path)
            for name, payload in properties.items()
        }
    return enriched


def _enrich_property(
    tool_id: str,
    name: str,
    payload: object,
    path: tuple[str, ...],
) -> object:
    if not isinstance(payload, Mapping):
        return payload
    next_path = (*path, name)
    enriched = {str(key): value for key, value in payload.items()}
    description = _description_for(tool_id, next_path)
    if description and not str(enriched.get("description") or "").strip():
        enriched["description"] = description
    if enriched.get("type") == "array" and "items" not in enriched:
        enriched["items"] = _STRING_ARRAY_SCHEMA
    items = enriched.get("items")
    if isinstance(items, Mapping):
        enriched["items"] = _enrich_schema(tool_id, items, (*next_path, "[]"))
    one_of = enriched.get("oneOf")
    if isinstance(one_of, list | tuple):
        enriched["oneOf"] = [_enrich_branch(tool_id, branch, next_path) for branch in one_of]
    properties = enriched.get("properties")
    if isinstance(properties, Mapping):
        enriched["properties"] = {
            str(child): _enrich_property(tool_id, str(child), child_payload, next_path)
            for child, child_payload in properties.items()
        }
    return enriched


def _enrich_branch(tool_id: str, branch: object, path: tuple[str, ...]) -> object:
    if not isinstance(branch, Mapping):
        return branch
    enriched = {str(key): value for key, value in branch.items()}
    if enriched.get("type") == "array" and "items" not in enriched:
        enriched["items"] = _STRING_ARRAY_SCHEMA
    items = enriched.get("items")
    if isinstance(items, Mapping):
        enriched["items"] = _enrich_schema(tool_id, items, (*path, "[]"))
    return enriched


def _description_for(tool_id: str, path: tuple[str, ...]) -> str | None:
    return _PROPERTY_DESCRIPTIONS.get(tool_id, {}).get(_path_key(path))


def _path_key(path: tuple[str, ...]) -> str:
    return ".".join(path).replace(".[]", "[]")


__all__ = ["enrich_builtin_tool_schema"]
