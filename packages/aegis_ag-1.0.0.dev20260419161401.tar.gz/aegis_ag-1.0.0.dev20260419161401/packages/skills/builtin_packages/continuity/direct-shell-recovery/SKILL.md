---
name: Direct Shell Recovery
skill_id: direct-shell-recovery
description: Keeps first-run, health, resume, and recovery guidance aligned with the direct shell.
version: 1.0.0
source_kind: aegis-builtin
default_enabled: true
include_in_overlay: false
aliases: ["shell recovery", "resume shell work", "recover terminal state"]
keywords: ["shell", "resume", "recovery", "health", "continuity"]
category: continuity
---

# Direct Shell Recovery

Use this built-in skill when the shell or workspace state needs recovery, resume guidance, or health-oriented diagnosis.

## Core rules

- Reconstruct the current shell and workspace state before proposing a reset.
- Prefer the smallest recovery step that restores progress.
- Keep recovery grounded in observable terminal state, process state, and repo state.
