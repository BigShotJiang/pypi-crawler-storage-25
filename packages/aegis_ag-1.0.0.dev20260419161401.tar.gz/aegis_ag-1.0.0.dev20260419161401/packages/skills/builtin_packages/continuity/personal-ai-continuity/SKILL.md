---
name: Personal AI Continuity
skill_id: personal-ai-continuity
description: Applies profile-aware continuity heuristics for durable personal AI sessions.
version: 1.0.0
source_kind: aegis-builtin
default_enabled: true
include_in_overlay: false
aliases: ["personal ai continuity", "session continuity", "durable continuity"]
keywords: ["continuity", "profile", "durable", "session", "memory"]
category: continuity
---

# Personal AI Continuity

Use this built-in skill as the default continuity posture for long-lived Aegis collaboration.

## Core rules

- Keep current work, durable identity state, and recent evidence aligned instead of treating each turn as disposable chat.
- Prefer continuity-preserving next steps over resetting the conversation when the current thread is still recoverable.
- Use the canonical runtime surfaces for memory, work, and planning rather than inventing hidden side channels.
