---
name: Voice Reply
skill_id: voice-reply
description: Enables voice reply guidance once provider-backed voice paths are ready.
version: 1.0.0
source_kind: aegis-builtin
default_enabled: true
include_in_overlay: false
aliases: ["voice reply", "speak reply", "audio response"]
keywords: ["voice", "audio", "reply", "speech"]
---

# Voice Reply

Use this built-in skill when the response should be shaped for voice delivery rather than only text.

## Core rules

- Favor concise, speakable phrasing over dense wall-of-text replies.
- Keep pauses, confirmations, and next actions easy to follow aloud.
- Do not claim voice output exists when the active provider or surface has not enabled it.
