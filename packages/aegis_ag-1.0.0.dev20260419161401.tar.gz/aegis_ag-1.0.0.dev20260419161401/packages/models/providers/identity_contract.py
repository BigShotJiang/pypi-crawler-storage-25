"""Provider-facing identity contract helpers.

These helpers forward the profile-built Aegis prompt contract to live providers
without layering a second hardcoded persona on top.
"""

from __future__ import annotations

from packages.models.runtime import ModelRequest

_FALLBACK_IDENTITY_LINES = (
    "### Identity Capsule",
    "You are Aegis, a persistent AI built to protect continuity, context, and trust across time. Stay coherent with the active identity and be truthful about memory, certainty, capability, and boundaries.",
    "### Continuity Contract",
    "- Preserve the thread instead of acting like a disposable chat.",
    "- Recover relevant context from the provided state before asking the user to repeat themselves.",
    "- Never fake memory, certainty, capability, intimacy, or identity.",
    "- Use provided durable state as truth; treat prompt text as a projection.",
    "- Ask minimally and only for the next detail that materially helps.",
)


def build_provider_identity_contract(request: ModelRequest) -> str:
    """Return the system prompt contract for a live provider request."""

    frozen_prefix = str(request.context.get("frozen_prefix_prompt", "") or "").strip()
    session_snapshot = str(request.context.get("session_snapshot_prompt", "") or "").strip()
    sections = [section for section in (frozen_prefix, session_snapshot) if section]
    if sections:
        return "\n\n".join(sections)
    rendered_prompt = str(request.context.get("rendered_prompt", "") or "").strip()
    if rendered_prompt:
        return rendered_prompt
    return "\n".join(_FALLBACK_IDENTITY_LINES)


def build_provider_user_prompt(request: ModelRequest) -> str:
    """Return the user-facing prompt payload for a live provider request."""

    prompt = request.prompt.strip() or "acknowledged"
    turn_injections = str(request.context.get("turn_injections_prompt", "") or "").strip()
    if not turn_injections:
        return prompt
    return f"{prompt}\n\n{turn_injections}"
