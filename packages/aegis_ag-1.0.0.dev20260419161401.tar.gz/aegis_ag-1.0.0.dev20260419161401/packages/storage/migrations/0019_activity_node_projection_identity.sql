PRAGMA foreign_keys = OFF;

DROP INDEX IF EXISTS idx_activity_nodes_session_order;
DROP INDEX IF EXISTS idx_activity_nodes_status;
DROP INDEX IF EXISTS idx_activity_lifecycle_events_goal;

ALTER TABLE activity_nodes RENAME TO activity_nodes_old;
ALTER TABLE activity_lifecycle_events RENAME TO activity_lifecycle_events_old;

CREATE TABLE activity_nodes (
    goal_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    goal_order INTEGER NOT NULL DEFAULT 0,
    title TEXT NOT NULL,
    status TEXT NOT NULL,
    priority TEXT NOT NULL,
    owner TEXT,
    parent_goal_id TEXT,
    dependency_refs_json TEXT NOT NULL,
    evidence_refs_json TEXT NOT NULL,
    related_memory_ids_json TEXT NOT NULL,
    deadline TEXT,
    time_sensitivity TEXT NOT NULL,
    review_checkpoint TEXT,
    revision_id TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(session_id, goal_id),
    FOREIGN KEY(session_id) REFERENCES activity_graphs(session_id) ON DELETE CASCADE
);

INSERT INTO activity_nodes (
    goal_id,
    session_id,
    goal_order,
    title,
    status,
    priority,
    owner,
    parent_goal_id,
    dependency_refs_json,
    evidence_refs_json,
    related_memory_ids_json,
    deadline,
    time_sensitivity,
    review_checkpoint,
    revision_id,
    created_at,
    updated_at
)
SELECT
    goal_id,
    session_id,
    goal_order,
    title,
    status,
    priority,
    owner,
    parent_goal_id,
    dependency_refs_json,
    evidence_refs_json,
    related_memory_ids_json,
    deadline,
    time_sensitivity,
    review_checkpoint,
    revision_id,
    created_at,
    updated_at
FROM activity_nodes_old;

CREATE TABLE activity_lifecycle_events (
    event_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    goal_id TEXT NOT NULL,
    from_status TEXT,
    to_status TEXT NOT NULL,
    reason TEXT,
    revision_id TEXT,
    metadata_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES activity_graphs(session_id) ON DELETE CASCADE,
    FOREIGN KEY(session_id, goal_id) REFERENCES activity_nodes(session_id, goal_id) ON DELETE CASCADE
);

INSERT INTO activity_lifecycle_events (
    event_id,
    session_id,
    goal_id,
    from_status,
    to_status,
    reason,
    revision_id,
    metadata_json,
    created_at
)
SELECT
    event_id,
    session_id,
    goal_id,
    from_status,
    to_status,
    reason,
    revision_id,
    metadata_json,
    created_at
FROM activity_lifecycle_events_old;

DROP TABLE activity_lifecycle_events_old;
DROP TABLE activity_nodes_old;

CREATE INDEX IF NOT EXISTS idx_activity_nodes_session_order
    ON activity_nodes(session_id, goal_order ASC, goal_id ASC);

CREATE INDEX IF NOT EXISTS idx_activity_nodes_status
    ON activity_nodes(session_id, status ASC, priority DESC, goal_id ASC);

CREATE INDEX IF NOT EXISTS idx_activity_lifecycle_events_goal
    ON activity_lifecycle_events(session_id, goal_id, created_at DESC, event_id ASC);

PRAGMA foreign_keys = ON;
