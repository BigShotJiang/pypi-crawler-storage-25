UPDATE agent_runs
SET max_wall_time_seconds = 28800
WHERE max_wall_time_seconds = 180;
