"""Prompt contract assembly for Aegis canonical identity and user state."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .governance import (
    aegis_text,
    build_companion_identity_state,
    parse_user_profile_content,
    render_user_profile_text,
    user_profile_text,
)
from .loader import LoadedProfile

PromptMode = Literal["full", "minimal"]

_USER_FIELD_LABELS = (
    "Preferred name",
    "Current work",
    "School",
    "Current city",
    "MBTI",
    "Dream",
    "Creative hobby",
    "Media hobby",
    "Movement hobby",
    "Boundaries",
)


@dataclass(frozen=True, slots=True)
class PromptContract:
    prompt_mode: PromptMode
    section_names: tuple[str, ...]
    instruction_refs: tuple[str, ...]
    stable_prefix_refs: tuple[str, ...] = ()
    profile_snapshot_refs: tuple[str, ...] = ()


def build_identity_capsule_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    capsule = (
        f"You are {identity.display_name}, a named Aegis clone on one long-lived continuity line. "
        f"Carry this clone as {identity.personality_summary} "
        f"Use a {identity.initiative} initiative style and keep the relational stance as {identity.relational_stance}. "
        "Stay warm where appropriate, direct when useful, and bounded: never fake memory, certainty, capability, intimacy, or identity."
    )
    lines = [
        "### Identity Capsule",
        "Core charter:",
        aegis_text(profile).strip(),
        "",
        "Clone posture:",
        capsule,
    ]
    custom_clone_note = _custom_clone_note(profile, display_name=identity.display_name)
    if prompt_mode == "full" and custom_clone_note:
        lines.extend(("", "Clone-specific note:", custom_clone_note))
    return tuple(lines)


def build_continuity_contract_section(profile: LoadedProfile) -> tuple[str, ...]:
    del profile
    return (
        "### Continuity Contract",
        "- Preserve the thread instead of acting like a disposable chat.",
        "- Recover relevant context from the provided state before asking the user to repeat themselves.",
        "- Never fake memory, certainty, capability, intimacy, or identity.",
        "- Use canonical identity, user, relationship, work, and evidence state as durable truth; treat prompt text as a projection.",
        "- Ask minimally and only for the next detail that materially helps the current task or durable continuity.",
    )


def build_state_write_policy_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    lines = [
        "### State Write Policy",
        "- When state, memory, profile, relationship, or work-write tools are available, preserve concrete durable changes through those governed tools.",
        "- If no write tool is available, state the durable update clearly without pretending it was stored.",
        "- Store stable facts, preferences, boundaries, recurring work context, and collaboration rhythm; do not store transient tasks, one-off asks, generic chatter, or completed-work logs as user facts.",
        "- When the user corrects durable identity, preferences, boundaries, voice, stance, initiative, or collaboration rhythm, write only the concise delta.",
        "- If the user asks what you already know, answer from current identity, user, relationship, and work state before writing anything new.",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"- Governance flags: {identity.governance_summary}.",
            )
        )
    return tuple(lines)


def build_identity_kernel(profile: LoadedProfile) -> tuple[str, ...]:
    return build_identity_capsule_section(profile)


def build_aegis_section(profile: LoadedProfile) -> tuple[str, ...]:
    return build_continuity_contract_section(profile)


def build_identity_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    return build_identity_capsule_section(profile, prompt_mode=prompt_mode)


def build_user_snapshot_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    parsed_profile = parse_user_profile_content(user_profile_text(profile))
    known_fields = dict(parsed_profile.field_values)
    durable_notes = parsed_profile.durable_notes
    structured_summary = render_user_profile_text(**known_fields)
    note_summary = _durable_note_summary(durable_notes)
    summary_parts = [structured_summary] if structured_summary else []
    if note_summary:
        summary_parts.append(f"Durable notes: {note_summary}")
    lines = [
        "section:user-snapshot",
        f"user-known-fields={', '.join(known_fields.keys()) or 'none'}",
        f"user-summary={' | '.join(summary_parts) or 'No durable user profile facts are set yet.'}",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"active-display-name={identity.display_name}",
                f"mode={identity.mode}",
                f"continuity-notes={', '.join(identity.continuity_notes) or 'none'}",
                f"user-canonical-fields={', '.join(_USER_FIELD_LABELS)}",
                f"user-open-facts={note_summary or 'none'}",
                f"user-open-facts-count={len(durable_notes)}",
            )
        )
    return tuple(lines)


def build_personality_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    return build_identity_section(profile, prompt_mode=prompt_mode)


def build_runtime_contract_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    return build_state_write_policy_section(profile, prompt_mode=prompt_mode)


def build_prompt_contract(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> PromptContract:
    stable_sections: list[tuple[str, tuple[str, ...]]] = [
        ("identity-capsule", build_identity_capsule_section(profile, prompt_mode=prompt_mode)),
        ("continuity-contract", build_continuity_contract_section(profile)),
        ("state-write-policy", build_state_write_policy_section(profile, prompt_mode=prompt_mode)),
    ]
    profile_snapshot_sections: list[tuple[str, tuple[str, ...]]] = [
        ("user-snapshot", build_user_snapshot_section(profile, prompt_mode=prompt_mode)),
    ]
    sections = [*stable_sections, *profile_snapshot_sections]
    stable_prefix_refs = tuple(line for _, lines in stable_sections for line in lines)
    profile_snapshot_refs = tuple(line for _, lines in profile_snapshot_sections for line in lines)
    instruction_refs = tuple((*stable_prefix_refs, *profile_snapshot_refs))
    return PromptContract(
        prompt_mode=prompt_mode,
        section_names=tuple(name for name, _ in sections),
        instruction_refs=instruction_refs,
        stable_prefix_refs=stable_prefix_refs,
        profile_snapshot_refs=profile_snapshot_refs,
    )


def _durable_note_summary(notes: tuple[str, ...], *, limit: int = 3) -> str:
    if not notes:
        return ""
    shown = notes[:limit]
    remainder = len(notes) - len(shown)
    summary = " | ".join(shown)
    if remainder > 0:
        summary += f" | +{remainder} more"
    return summary


def _custom_clone_note(profile: LoadedProfile, *, display_name: str) -> str:
    note = (profile.clone_text or "").strip()
    if not note:
        return ""
    normalized = " ".join(note.split()).casefold()
    generated_prefix = f"you are {display_name}, a named aegis clone on one long-lived continuity line.".casefold()
    if normalized.startswith(generated_prefix) and "default posture:" in normalized:
        return ""
    return note
