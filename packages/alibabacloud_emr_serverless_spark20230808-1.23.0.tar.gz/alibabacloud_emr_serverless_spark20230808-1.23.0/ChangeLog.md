2026-04-23 Version: 1.22.0
- Support API ListExecutorLogs.


2026-04-21 Version: 1.21.1
- Update API CreateKyuubiToken: add request parameters body.sparkRole.
- Update API GetKyuubiToken: add response parameters Body.data.sparkRole.
- Update API ListKyuubiToken: add response parameters Body.data.tokens.$.sparkRole.
- Update API UpdateKyuubiToken: add request parameters body.sparkRole.


2026-04-19 Version: 1.21.0
- Support API ChangeResourceGroup.


2026-04-15 Version: 1.20.1
- Generated python 2023-08-08 for emr-serverless-spark.

2026-04-14 Version: 1.20.0
- Support API CreateNetworkService.
- Support API ListNetworkServices.


2026-04-14 Version: 1.20.0
- Support API CreateNetworkService.
- Support API ListNetworkServices.


2026-03-23 Version: 1.19.2
- Update API CreateRayCluster: add request parameters body.volumeIds.
- Update API CreateRayCluster: add request parameters body.headSpec.gpuSpec.
- Update API CreateRayCluster: add request parameters body.workerSpec.$.gpuSpec.
- Update API CreateWorkspace: add request parameters body.gpuSpec.
- Update API CreateWorkspace: add request parameters body.resourceSpec.gpu.
- Update API EditWorkspaceQueue: add request parameters body.gpuSpec.
- Update API EditWorkspaceQueue: add request parameters body.resourceSpec.gpu.
- Update API GetJobRun: add response parameters Body.jobRun.priority.
- Update API GetRayCluster: add response parameters Body.jobUrlInner.
- Update API GetRayCluster: add response parameters Body.volumeIds.
- Update API GetRayCluster: add response parameters Body.headSpec.gpuSpec.
- Update API GetRayCluster: add response parameters Body.workerSpec.$.gpuSpec.
- Update API ListJobRuns: add response parameters Body.jobRuns.$.priority.
- Update API ListKyuubiSparkApplications: add request parameters endTime.
- Update API ListKyuubiSparkApplications: add request parameters latestSqlStatementStatuses.
- Update API ListKyuubiSparkApplications: add request parameters states.
- Update API ListKyuubiSparkApplications: add response parameters Body.applications.$.priority.
- Update API ListRayCluster: add response parameters Body.rayClusters.$.headSpec.gpuSpec.
- Update API ListRayCluster: add response parameters Body.rayClusters.$.workerSpec.$.gpuSpec.
- Update API ListWorkspaceQueues: add response parameters Body.queues.$.gpuSpec.
- Update API ListWorkspaceQueues: add response parameters Body.queues.$.queueCategory.
- Update API ListWorkspaces: add response parameters Body.workspaces.$.gpuSpec.
- Update API UpdateRayCluster: add request parameters body.volumeIds.
- Update API UpdateRayCluster: add request parameters body.headSpec.gpuSpec.
- Update API UpdateRayCluster: add request parameters body.workerSpec.$.gpuSpec.


2026-01-19 Version: 1.19.0
- Support API ListLivyComputeSessions.


2026-01-13 Version: 1.18.1
- Update API ListCatalogs: add response parameters Body.catalogs.$.alias.
- Update API ListKyuubiSparkApplications: add response parameters Body.applications.$.tags.


2025-12-12 Version: 1.18.0
- Support API GetRunConfiguration.


2025-11-25 Version: 1.17.0
- Support API CancelKyuubiSparkApplication.
- Support API CreateKyuubiService.
- Support API DeleteKyuubiService.
- Support API GenerateTaskCodes.
- Support API GetKyuubiService.
- Support API StartKyuubiService.
- Support API StopKyuubiService.
- Support API UpdateKyuubiService.
- Update API EditWorkspaceQueue: add request parameters body.resourceSpec.maxCu.
- Update API GetJobRun: add response parameters Body.jobRun.notebookAccessUrl.
- Update API ListJobRuns: add response parameters Body.jobRuns.$.resourceQueueId.
- Update API ListKyuubiSparkApplications: add response parameters Body.applications.$.kyuubiServiceId.
- Update API ListKyuubiSparkApplications: add response parameters Body.applications.$.runLog.
- Update API ListWorkspaceQueues: add response parameters Body.queues.$.preheat.


2025-10-17 Version: 1.16.0
- Support API ListCatalogs.
- Support API ListJobExecutors.
- Support API ListTemplate.


2025-09-09 Version: 1.15.0
- Support API CreateKyuubiToken.
- Support API DeleteKyuubiToken.
- Support API GetKyuubiToken.
- Support API UpdateKyuubiToken.
- Update API CreateSqlStatement: add request parameters body.taskBizId.


2025-08-20 Version: 1.14.0
- Support API ListMembers.


2025-08-19 Version: 1.13.1
- Update API CreateSessionCluster: add request parameters body.clientToken.
- Update API ListJobRuns: add request parameters applicationConfigs.
- Update API ListJobRuns: add request parameters runtimeConfigs.
- Update API ListKyuubiServices: add response parameters Body.data.kyuubiServices.$.kyuubiReleaseVersion.
- Update API ListKyuubiSparkApplications: add response parameters Body.applications.$.exitReason.
- Update API ListKyuubiToken: add response parameters Body.data.tokens.$.accountNames.
- Update API ListKyuubiToken: add response parameters Body.data.tokens.$.memberArns.


2025-08-15 Version: 1.13.0
- Support API ListSqlStatementContents.


2025-07-24 Version: 1.12.1
- Update API ListKyuubiSparkApplications: add response parameters Body.applications.$.latestSqlStatementStatus.
- Update API ListSessionClusters: add response parameters Body.sessionClusters.$.connectionToken.


2025-07-07 Version: 1.12.0
- Support API CreateLivyCompute.
- Support API CreateLivyComputeToken.
- Support API DeleteLivyCompute.
- Support API DeleteLivyComputeToken.
- Support API GetLivyCompute.
- Support API GetLivyComputeToken.
- Support API ListLivyCompute.
- Support API ListLivyComputeToken.
- Support API RefreshLivyComputeToken.
- Support API StartLivyCompute.
- Support API StopLivyCompute.
- Support API UpdateLivyCompute.


2025-06-26 Version: 1.11.0
- Support API ListKyuubiServices.
- Support API ListKyuubiToken.
- Update API GetSessionCluster: add response parameters Body.sessionCluster.connectionToken.
- Update API ListJobRuns: add request parameters isWorkflow.
- Update API ListKyuubiSparkApplications: add request parameters minDuration.
- Update API ListKyuubiSparkApplications: add request parameters orderBy.
- Update API ListKyuubiSparkApplications: add request parameters resourceQueueId.
- Update API ListKyuubiSparkApplications: add request parameters sort.


2025-05-30 Version: 1.10.3
- Generated python 2023-08-08 for emr-serverless-spark.

2025-05-19 Version: 1.10.2
- Update API CreateSessionCluster: add request parameters body.publicEndpointEnabled.
- Update API GetSessionCluster: add response parameters Body.sessionCluster.publicEndpointEnabled.
- Update API GetTemplate: add request parameters templateBizId.
- Update API ListSessionClusters: add response parameters Body.sessionClusters.$.publicEndpointEnabled.
- Update API ListWorkspaces: add response parameters Body.workspaces.$.prePaidQuota.orderId.


2025-05-16 Version: 1.10.1
- Generated python 2023-08-08 for emr-serverless-spark.

2025-05-06 Version: 1.10.0
- Support API CreateSessionCluster.
- Support API CreateWorkspace.
- Support API EditWorkspaceQueue.
- Support API GetCuHours.
- Support API GetDoctorApplication.
- Support API ListKyuubiSparkApplications.
- Update API CreateProcessDefinitionWithSchedule: add request parameters globalParams.
- Update API CreateProcessDefinitionWithSchedule: add request parameters taskDefinitionJson.$.taskParams.localParams.
- Update API GetSessionCluster: add response parameters Body.sessionCluster.extra.
- Update API GetSqlStatement: add response parameters Body.data.sqlOutputs.$.rowsFilePath.
- Update API ListJobRuns: add request parameters minDuration.
- Update API ListReleaseVersions: add request parameters serviceFilter.
- Update API ListSessionClusters: add response parameters Body.sessionClusters.$.extra.
- Update API ListWorkspaceQueues: add response parameters Body.queues.$.createTime.
- Update API ListWorkspaceQueues: add response parameters Body.queues.$.paymentType.
- Update API ListWorkspaces: add request parameters tag.
- Update API ListWorkspaces: add response parameters Body.workspaces.$.prePaidQuota.
- Update API ListWorkspaces: add response parameters Body.workspaces.$.tags.
- Update API StartProcessInstance: add request parameters action.
- Update API StartProcessInstance: add request parameters comments.
- Update API StartProcessInstance: add request parameters email.
- Update API StartProcessInstance: add request parameters interval.
- Update API UpdateProcessDefinitionWithSchedule: add request parameters globalParams.
- Update API UpdateProcessDefinitionWithSchedule: add request parameters taskDefinitionJson.$.taskParams.localParams.


2024-12-24 Version: 1.9.0
- Support API CreateProcessDefinitionWithSchedule.
- Support API StartProcessInstance.
- Support API UpdateProcessDefinitionWithSchedule.


2024-12-10 Version: 1.8.1
- Update API ListJobRuns: update response param.


2024-11-27 Version: 1.8.0
- Support API GetTemplate.


2024-11-25 Version: 1.7.0
- Support API GetSessionCluster.
- Update API GetJobRun: update response param.
- Update API ListSessionClusters: update response param.


2024-11-06 Version: 1.6.0
- Support API ListLogContents.


2024-10-17 Version: 1.5.0
- Support API StartSessionCluster.
- Support API StopSessionCluster.
- Update API ListJobRuns: update param workspaceId.
- Update API ListJobRuns: update param creator.
- Update API ListJobRuns: update param endTime.
- Update API ListJobRuns: update param jobRunDeploymentId.
- Update API ListJobRuns: update param jobRunId.
- Update API ListJobRuns: update param maxResults.
- Update API ListJobRuns: update param name.
- Update API ListJobRuns: update param nextToken.
- Update API ListJobRuns: update param resourceQueueId.
- Update API ListJobRuns: update param startTime.
- Update API ListJobRuns: update param states.
- Update API ListJobRuns: update param tags.
- Update API ListReleaseVersions: add param workspaceId.


2024-08-22 Version: 1.4.3
- Update API GetJobRun: update response param.


2024-08-20 Version: 1.4.2
- Update API ListJobRuns: update response param.
- Update API ListReleaseVersions: update response param.
- Update API ListSessionClusters: update response param.
- Update API ListWorkspaces: update response param.
- Update API StartJobRun: update param body.


2024-07-09 Version: 1.4.1
- Update API ListSessionClusters: add param kind.
- Update API ListSessionClusters: update response param.


2024-05-31 Version: 1.4.0
- Support API CreateSqlStatement.
- Support API GetSqlStatement.
- Support API TerminateSqlStatement.
- Update API ListJobRuns: add param jobRunDeploymentId.


2024-05-22 Version: 1.3.0
- Support API AddMembers.
- Support API GrantRoleToUsers.


2024-05-21 Version: 1.2.0
- Support API ListSessionClusters.


2024-05-21 Version: 1.2.0
- Support API ListSessionClusters.


2024-05-20 Version: 1.1.0
- Support API ListReleaseVersions.
- Support API ListWorkspaceQueues.
- Support API ListWorkspaces.


2024-05-17 Version: 1.0.1
- Update API CancelJobRun: update param workspaceId.
- Update API CancelJobRun: update param jobRunId.
- Update API GetJobRun: update param workspaceId.
- Update API GetJobRun: update param jobRunId.
- Update API ListJobRuns: update param workspaceId.
- Update API StartJobRun: update param workspaceId.


2024-04-16 Version: 1.0.0
- Generated python 2023-08-08 for emr-serverless-spark.

