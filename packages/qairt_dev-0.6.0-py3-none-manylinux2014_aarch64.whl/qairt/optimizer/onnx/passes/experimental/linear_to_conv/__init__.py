# ==============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
Passes to replace linear node (matmul/gemm) with conv

Note:

for replacing matmul(+bias) with conv
- LinearToConvPass is enough

for replacing Gemm with conv
- CanonizeGemmPass + LinearToConvPass should be called

"""

from qairt.optimizer.onnx.passes.experimental.linear_to_conv.canonize_gemm import CanonizeGemmPass
from qairt.optimizer.onnx.passes.experimental.linear_to_conv.linear_to_conv import LinearToConvPass

__all__ = ["LinearToConvPass", "CanonizeGemmPass"]
