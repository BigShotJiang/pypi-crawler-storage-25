# ==============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
This module provides the pass to convert the linear op to conv1x1 op in the graph
"""

import copy
from dataclasses import dataclass
from typing import List

import numpy as np
import onnx_ir as ir

from qairt.optimizer.onnx.passes.base import BasePredicatePass, MatchInfoProtocol, PassConfig
from qairt.optimizer.onnx.utils.ir_extra_info import VariableExtraInfo
from qairt.optimizer.onnx.utils.utils import (
    get_attribute_with_default,
    get_constant_np,
    get_value_numeric_shape,
    has_static_shape_on_value,
    have_static_shape_on_node_io,
    is_constant,
    make_initializer,
    safe_replace_all_uses_with,
)
from qairt.optimizer.utils.logger import logger


class LinearToConvPass(BasePredicatePass):
    """
    A graph rewriter pass that converts Linear (MatMul + Add) to Conv 1x1.
    The Transpose/Reshape should be used on pre/post layout transfering.

    Here are some examples:

    1. Transform subgraph:
        Subgraph(input:FLOAT[4, 64]) -> output:FLOAT[4, 32]
        {
            gemm_weight:FLOAT[64, 32]
            gemm_bias:FLOAT[32]
            output = Gemm(
                input,
                gemm_weight,
                gemm_bias,
                alpha=1.5,
                beta=1.0,
                transA=0,
                transB=0
            )
        }
    Into:
        Subgraph(input:FLOAT[4, 64]) -> output:FLOAT[4, 32]
        {
            gemm_weight:FLOAT[64, 32]
            gemm_bias:FLOAT[32]

            conv_input = Reshape(input, [4,1,1,64])
            conv_input = Transpose(conv_input, perm=[0,3,1,2])

            conv_weight = gemm_weight * alpha
            conv_weight = Transpose(conv_weight, perm=[1,0])
            conv_weight = Reshape(conv_weight, [32,64,1,1])
            conv_bias = gemm_bias

            output = Conv(
                conv_input,
                conv_weight,
                conv_bias,
                dilations=[1, 1],
                group=1,
                kernel_shape=[1, 1],
                pads=[0, 0, 0, 0],
                strides=[1, 1]
            )
        } (1) (2)

    2. Transform subgraph:
        Subgraph(input:FLOAT[3, 2, 4, 64]) -> output:FLOAT[3, 2, 4, 32]
        {
            matmul_weight:FLOAT[64, 32]
            add_bias:FLOAT[32]
            output = MatMul(
                input,
                matmul_weight,
            )
            output = Add(
                output,
                add_bias,
            )
        }
    Into:
        Subgraph(input:FLOAT[3, 2, 4, 64]) -> output:FLOAT[3, 2, 4, 32]
        {
            matmul_weight:FLOAT[64, 32]
            add_bias:FLOAT[32]

            conv_input = Transpose(input, perm=[0,3,1,2])

            conv_weight = Transpose(matmul_weight, perm=[1,0])
            conv_weight = Reshape(conv_weight, [32,64,1,1])
            conv_bias = add_bias

            output = Conv(
                conv_input,
                conv_weight,
                conv_bias,
                dilations=[1, 1],
                group=1,
                kernel_shape=[1, 1],
                pads=[0, 0, 0, 0],
                strides=[1, 1]
            )
            output = Transpose(output, perm=[0,2,3,1])
        }

    (1) For Gemm op, it has many variants, It will handle many cases if directly converting Gemm to Conv.
    To simplify the logic, we first canonicalize Gemm using `canonize_gemm.py`, and then process it afterward.
    `cannonize_gemm.py` can keep input0 as a dynamic input and input1 as a static input, while setting transA and transB to 0.
    LinearToConvPass then converts these canonicalized Gemms into Conv.
    (2) If Gemm's inputs[0] has a large batch dim (such as [16384,256]), it will be reshaped and transposed into [16384,256,1,1],
    which is not good for its performance, so we need some layout optimization pass(es) that can modify the input shape as chip-friendly.
    """

    @dataclass
    class Config(PassConfig):
        """Configuration for LinearToConvPass pass."""

        op_types: tuple[str, ...] = (
            "MatMul",
            "Gemm",
        )

    def __init__(self, config: Config | None = None):
        super().__init__()
        if config is None:
            config = LinearToConvPass.Config()

        self.l2c_ops = set(config.op_types)

    def _is_canonize_gemm(self, gemm_node: ir.Node) -> bool:
        return (
            int(get_attribute_with_default(gemm_node, "transA", 0)) == 0
            and int(get_attribute_with_default(gemm_node, "transB", 0)) == 0
            and (not is_constant(gemm_node.inputs[0]))
            and is_constant(gemm_node.inputs[1])
        )

    def match(self, graph: ir.Graph, node: ir.Node) -> bool:
        if node.op_type in self.l2c_ops:
            if not have_static_shape_on_node_io(node):
                return False

            weight_v = node.inputs[1]
            if not is_constant(weight_v):
                return False

            if node.op_type == "Gemm":
                if not self._is_canonize_gemm(node):
                    return False
            return True
        return False

    def _compute_input_reshape_shape(self, input_value: ir.Value) -> List[int]:
        """Compute input reshape dimensions to add spatial dimensions
        2D: [Batch, in_feature] -> [Batch, 1, 1, in_feature]
        3D: [Batch, length, in_feature] -> [Batch, 1, length, in_feature]
        4D: [Batch, height, width, in_feature] -> [Batch, height, width, in_feature] and will be squashed by LayoutOptRewriter
        nD(n>4): [Batch, dim1, dim2, ..., dim{n_1}, in_feature] -> [Batch, dim1, dim2*dim3*...*dim{n_1}, in_feature]
        """

        input_shape = get_value_numeric_shape(input_value)

        # Validate all dimensions are positive
        if any(isinstance(dim, int) and dim <= 0 for dim in input_shape):
            raise ValueError(f"All input shape dimensions must be positive, got {input_shape}")

        if len(input_shape) == 2:
            return [input_shape[0], 1, 1, input_shape[1]]

        elif len(input_shape) == 3:
            return [input_shape[0], 1, input_shape[1], input_shape[2]]

        elif len(input_shape) > 4:
            # Flatten all intermediate dimensions (between batch and features)
            intermediate_size = 1
            for dim in input_shape[2:-1]:
                intermediate_size *= dim

            return [input_shape[0], input_shape[1], intermediate_size, input_shape[-1]]
        return list(input_shape)

    def _compute_output_reshape_shape(self, input_value: ir.Value, out_features: int):
        """Compute output reshape dimensions to restore original shape
        Restores to [batch, dim1, dim2, ..., out_features]
        For 2D inputs, this becomes [batch, out_features]
        """
        input_shape = get_value_numeric_shape(input_value)
        if len(input_shape) < 2:
            return None

        # Preserve all intermediate dimensions (between batch and features)
        return list(input_shape[:-1]) + [out_features]

    def _add_reshape_for_l2c(
        self,
        graph: ir.Graph,
        input_value: ir.Value,
        reshape_shape: List[int],
        ori_linear_node_name: str,
        value_to_copy_info: ir.Value,
        suffix: str,
    ) -> ir.Node:
        reshape_shape_v = make_initializer(
            graph,
            graph.meta["extra_info"].get_unique_name(ori_linear_node_name + "/" + suffix + "_reshape_shape"),
            reshape_shape,
        )

        reshape = ir.Node(
            "",
            "Reshape",
            [input_value, reshape_shape_v],
            name=graph.meta["extra_info"].get_unique_name(ori_linear_node_name + "/" + suffix + "_reshape"),
        )
        reshape.outputs[0].type = copy.deepcopy(value_to_copy_info.type)
        reshape.outputs[0].shape = ir.Shape(np.array(reshape_shape))
        reshape.outputs[0].name = graph.meta["extra_info"].get_unique_name(
            (value_to_copy_info.name or "") + "/l2c/" + suffix + "_reshape"
        )
        reshape.outputs[0].meta["extra_info"] = value_to_copy_info.meta["extra_info"].copy()

        return reshape

    def _add_transpose_for_l2c(
        self,
        graph: ir.Graph,
        input_value: ir.Value,
        perm: List[int],
        ori_linear_node_name: str,
        value_to_copy_info: ir.Value,
        suffix: str,
    ) -> ir.Node | None:
        if len(perm) != 4:
            return None
        if input_value.shape is None:
            return None
        transpose = ir.Node(
            "",
            "Transpose",
            [input_value],
            attributes=[ir.AttrInt64s("perm", perm)],
            name=graph.meta["extra_info"].get_unique_name(ori_linear_node_name + "/" + suffix + "_transpose"),
        )
        transpose.outputs[0].type = copy.deepcopy(value_to_copy_info.type)
        transpose.outputs[0].shape = ir.Shape(np.array([input_value.shape[d] for d in perm]))
        transpose.outputs[0].name = graph.meta["extra_info"].get_unique_name(
            (value_to_copy_info.name or "") + "/l2c/" + suffix + "_transpose"
        )
        transpose.outputs[0].meta["extra_info"] = value_to_copy_info.meta["extra_info"].copy()

        return transpose

    def _add_conv_weight_for_l2c(
        self,
        graph: ir.Graph,
        weight_value: ir.Value,
        alpha: float = 1.0,
    ) -> ir.Value:
        weight_np = get_constant_np(weight_value)
        # weight_np shape should be [1,1,...,1,in_feature,out_feature]
        assert np.prod(np.array([i for i in weight_np.shape[:-2]])) == 1
        weight_np = weight_np.reshape([weight_np.shape[-2], weight_np.shape[-1]])
        weight_np = np.transpose(weight_np, [1, 0])
        weight_np = weight_np * alpha
        new_conv_weight = make_initializer(
            graph,
            graph.meta["extra_info"].get_unique_name((weight_value.name or "") + "/l2c/conv_weight"),
            weight_np.reshape(list(weight_np.shape) + [1, 1]),
        )
        new_conv_weight.meta["extra_info"] = weight_value.meta["extra_info"].copy()

        return new_conv_weight

    def _get_conv_bias_value(self, graph: ir.Graph, node: ir.Node, beta: float):
        """Extract or create conv bias value from MatMul+Add or Gemm pattern.

        Returns:
            tuple: (bias_value, pattern_end_node) where:
                - bias_value: ir.Value or None (None means no bias)
                - pattern_end_node: ir.Node or None (None means conversion should be skipped)
        """

        def _create_normalized_conv_bias_v(
            bias_v: ir.Value, expected_N: int, beta: float = 1.0
        ) -> ir.Value | None:
            # bias_v shape can be (), (1), (1,1), (N,), (1,N), (1,...1,,N)
            if not has_static_shape_on_value(bias_v):
                return None
            squeezed_bias_shape = get_value_numeric_shape(bias_v)
            # squeeze the first 1 dims
            while len(squeezed_bias_shape) > 0 and squeezed_bias_shape[0] == 1:
                squeezed_bias_shape = squeezed_bias_shape[1:]

            # now the expected bias_v shape should be
            # (), (N,)
            if squeezed_bias_shape not in (tuple(), (expected_N,)):
                return None

            bias_np = get_constant_np(bias_v).reshape(squeezed_bias_shape)
            bias_np = np.broadcast_to(bias_np, (expected_N,))  # the shape should be (N,)
            bias_np = bias_np * beta

            bias_namehint = bias_v.name if bias_v.name is not None else ""
            new_conv_bias = make_initializer(
                graph,
                graph.meta["extra_info"].get_unique_name(bias_namehint + "/l2c/conv_bias"),
                bias_np,
            )
            extra_info: VariableExtraInfo = bias_v.meta["extra_info"].scale(beta)
            new_conv_bias.meta["extra_info"] = extra_info
            return new_conv_bias

        if node.op_type == "MatMul":
            if len(node.outputs[0].uses()) == 1:
                # has some op next to MatMul
                candidate_add = list(node.outputs[0].uses())[0].node
                if candidate_add.op_type == "Add":
                    # the next op is Add
                    # we need to support the case that bias as input 0 of add
                    # because torch.nn.Linear will be translated into MatMul+Add onnx graph with bias as input0 of Add
                    candidate_bias_as_input0 = candidate_add.inputs[0]
                    candidate_bias_as_input1 = candidate_add.inputs[1]
                    if candidate_bias_as_input0 is not None and is_constant(candidate_bias_as_input0):
                        candidate_bias_v: ir.Value = candidate_bias_as_input0
                    elif candidate_bias_as_input1 is not None and is_constant(candidate_bias_as_input1):
                        candidate_bias_v = candidate_bias_as_input1
                    else:
                        # the inputs of Add are both dynamic
                        # we can ignore the Add and continue l2c
                        return None, node

                    matmul_out_shape = get_value_numeric_shape(node.outputs[0])
                    expected_N = matmul_out_shape[-1]
                    conv_bias_v = _create_normalized_conv_bias_v(candidate_bias_v, expected_N)
                    if conv_bias_v is None:
                        return None, None
                    return conv_bias_v, candidate_add
                else:
                    # no Add next to MatMul
                    # we can convert only matmul into conv
                    return None, node
            else:
                # MatMul is the last node of Graph or MatMul has multi consumers
                # we can be converted only matmul into conv
                return None, node

        elif node.op_type == "Gemm":
            if len(node.inputs) > 2:
                # has bias
                gemm_bias_v = node.inputs[2]
                if gemm_bias_v is None:
                    return None, None
                gemm_out_shape = get_value_numeric_shape(node.outputs[0])
                expected_N = gemm_out_shape[-1]  # gemm_out_shape: [M,N]
                conv_bias_v = _create_normalized_conv_bias_v(gemm_bias_v, expected_N, beta=beta)
                if conv_bias_v is None:
                    return None, None
                return conv_bias_v, node

            else:
                # no bias
                return None, node

    def _add_conv1x1_for_l2c(
        self,
        graph: ir.Graph,
        input_value: ir.Value,
        weight_value: ir.Value,
        ori_linear_node: ir.Node,
        bias_value: ir.Value | None,
        value_to_copy_info: ir.Value,
    ) -> ir.Node | None:
        if input_value.shape is None or weight_value.shape is None:
            return None
        inputs = [input_value, weight_value]
        if bias_value is not None:
            inputs.append(bias_value)

        conv = ir.Node(
            "",
            "Conv",
            inputs,
            name=graph.meta["extra_info"].get_unique_name((ori_linear_node.name or "") + "/conv"),
        )
        conv.attributes.add(ir.AttrInt64s("dilations", [1, 1]))
        conv.attributes.add(ir.AttrInt64("group", 1))
        conv.attributes.add(ir.AttrInt64s("kernel_shape", [1, 1]))
        conv.attributes.add(ir.AttrInt64s("pads", [0, 0, 0, 0]))
        conv.attributes.add(ir.AttrInt64s("strides", [1, 1]))

        conv.outputs[0].name = graph.meta["extra_info"].get_unique_name(
            (ori_linear_node.outputs[0].name or "") + "/l2c"
        )
        conv.outputs[0].type = copy.deepcopy(ori_linear_node.outputs[0].type)
        conv.outputs[0].shape = ir.Shape(
            np.array(
                [
                    input_value.shape[0],
                    weight_value.shape[0],
                    input_value.shape[2],
                    input_value.shape[3],
                ]
            )
        )
        conv.outputs[0].meta["extra_info"] = value_to_copy_info.meta["extra_info"].copy()

        return conv

    def rewrite(self, graph: ir.Graph, node: ir.Node, match_info=MatchInfoProtocol | None) -> bool:
        alpha, beta = 1.0, 1.0
        if node.op_type == "Gemm":
            alpha = float(get_attribute_with_default(node, "alpha", 1.0))
            beta = float(get_attribute_with_default(node, "beta", 1.0))

        conv_bias_value, pattern_end_node = self._get_conv_bias_value(graph=graph, node=node, beta=beta)
        if pattern_end_node is None:
            return False

        input_value = node.inputs[0]
        weight_value = node.inputs[1]
        node_name = node.name
        if input_value is None or weight_value is None or node_name is None:
            return False
        if input_value.shape is None:
            return False

        pre_reshape = self._add_reshape_for_l2c(
            graph=graph,
            input_value=input_value,
            reshape_shape=self._compute_input_reshape_shape(input_value),
            ori_linear_node_name=node_name,
            value_to_copy_info=input_value,
            suffix="pre",
        )
        pre_transpose = self._add_transpose_for_l2c(
            graph=graph,
            input_value=pre_reshape.outputs[0],
            perm=[0, 3, 1, 2],
            ori_linear_node_name=node_name,
            value_to_copy_info=input_value,
            suffix="pre",
        )
        if pre_transpose is None:
            return False
        conv_weight_value = self._add_conv_weight_for_l2c(graph=graph, weight_value=weight_value, alpha=alpha)
        conv = self._add_conv1x1_for_l2c(
            graph=graph,
            input_value=pre_transpose.outputs[0],
            weight_value=conv_weight_value,
            ori_linear_node=node,
            bias_value=conv_bias_value,
            value_to_copy_info=pattern_end_node.outputs[0],
        )
        if conv is None:
            return False

        post_transpose = self._add_transpose_for_l2c(
            graph=graph,
            input_value=conv.outputs[0],
            perm=[0, 2, 3, 1],
            ori_linear_node_name=node_name,
            value_to_copy_info=pattern_end_node.outputs[0],
            suffix="post",
        )
        if post_transpose is None:
            return False

        conv_weight_shape0 = get_value_numeric_shape(conv_weight_value)[0]
        if not isinstance(conv_weight_shape0, int):
            return False
        output_reshape_shape = self._compute_output_reshape_shape(input_value, conv_weight_shape0)
        if output_reshape_shape is None:
            return False
        post_reshape = self._add_reshape_for_l2c(
            graph=graph,
            input_value=post_transpose.outputs[0],
            reshape_shape=output_reshape_shape,
            ori_linear_node_name=node_name,
            value_to_copy_info=pattern_end_node.outputs[0],
            suffix="post",
        )

        graph.insert_before(node, pre_reshape)
        graph.insert_after(pre_reshape, pre_transpose)
        graph.insert_after(pre_transpose, conv)
        graph.insert_after(conv, post_transpose)
        graph.insert_after(post_transpose, post_reshape)

        safe_replace_all_uses_with(graph, pattern_end_node.outputs[0], post_reshape.outputs[0])

        return True
