# ==============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
This module provides the pass to generalize the Gemm op in the graph
"""

import copy
from typing import List

import numpy as np
import onnx_ir as ir

from qairt.optimizer.onnx.passes.base import BasePredicatePass, MatchInfoProtocol
from qairt.optimizer.onnx.utils.utils import (
    get_attribute_with_default,
    get_constant_np,
    get_value_numeric_shape,
    has_static_shape_on_value,
    is_constant,
    make_initializer,
    safe_replace_all_uses_with,
)
from qairt.optimizer.utils.logger import logger


class CanonizeGemmPass(BasePredicatePass):
    """
    A graph rewriter pass that generalize the Gemm op,
    keep input0 as a dynamic input and input1 as a static input
    and set transA and transB into 0.

    Here is an example:
    Transform subgraph:
        Subgraph(input:FLOAT[4, 64]) -> output:FLOAT[4, 32]
        {
            constant_weight:FLOAT[32, 64]
            constant_bias:FLOAT[32]
            output = Gemm(
                input,
                constant_weight,
                constant_bias,
                alpha=1.5,
                beta=2.5,
                transA=0,
                transB=1
            )
        }
    Into:
        Subgraph(input:FLOAT[4, 64]) -> output:FLOAT[4, 32]
        {
            constant_weight:FLOAT[32, 64]
            constant_bias:FLOAT[32]

            transposed_weight = Transpose(constant_weight, perm=[1,0])    <-
            output = Gemm(
                input,
                transposed_weight,     <-
                constant_bias,
                alpha=1.5,
                beta=2.5,
                transA=0,
                transB=0    <-
            )
        }

    this is a preprocessing pass for LinearToConvPass
    """

    def _add_pre_or_post_transpose_for_gemm(
        self,
        graph: ir.Graph,
        input_value: ir.Value,
        ori_gemm_node_name: str,
        value_to_copy_info: ir.Value,
        transpose_type: str,
    ) -> ir.Node | None:
        if input_value.shape is None:
            return None
        if transpose_type == "pre":
            suffix = "/gnlz_gemm/pre_transpose"
        elif transpose_type == "post":
            suffix = "/gnlz_gemm/post_transpose"
        else:
            raise ValueError("transpose_type should be `pre` or `post`")
        transpose = ir.Node(
            "",
            "Transpose",
            [input_value],
            attributes=[ir.AttrInt64s("perm", [1, 0])],
            name=graph.meta["extra_info"].get_unique_name(ori_gemm_node_name + suffix),
        )
        transpose.outputs[0].type = copy.deepcopy(value_to_copy_info.type)
        transpose.outputs[0].shape = ir.Shape(np.array([input_value.shape[1], input_value.shape[0]]))
        transpose.outputs[0].name = graph.meta["extra_info"].get_unique_name(
            (value_to_copy_info.name or "") + suffix
        )
        transpose.outputs[0].meta["extra_info"] = value_to_copy_info.meta["extra_info"].copy()

        return transpose

    def _add_weight_for_gemm(
        self, graph: ir.Graph, weight_value: ir.Value, weight_need_transpose: bool
    ) -> ir.Value:
        weight_np = get_constant_np(weight_value)
        assert weight_np is not None
        assert len(weight_np.shape) == 2
        if weight_need_transpose:
            weight_np = np.transpose(weight_np, [1, 0])
        new_gemm_weight = make_initializer(
            graph,
            graph.meta["extra_info"].get_unique_name((weight_value.name or "") + "/gnlz_gemm/weight"),
            weight_np,
        )
        new_gemm_weight.meta["extra_info"] = weight_value.meta["extra_info"].copy()

        return new_gemm_weight

    def _add_bias_for_gemm(
        self, graph: ir.Graph, bias_value: ir.Value, bias_need_transpose: bool
    ) -> ir.Value:
        bias_np = get_constant_np(bias_value)
        assert bias_np is not None
        # Validate bias shape
        if len(bias_np.shape) > 2:
            raise ValueError(f"Bias must be 1D or 2D, got shape {bias_np.shape}")

        if bias_need_transpose:
            if len(bias_np.shape) == 1:
                # need to expand the bias before being transposed
                bias_np = bias_np.reshape([1, bias_np.shape[0]])
            elif len(bias_np.shape) == 2:
                # Validate 2D bias has compatible shape
                if bias_np.shape[0] != 1 and bias_np.shape[1] != 1:
                    raise ValueError(f"2D bias must have one dimension equal to 1, got shape {bias_np.shape}")
            bias_np = np.transpose(bias_np, [1, 0])

        new_gemm_bias = make_initializer(
            graph,
            graph.meta["extra_info"].get_unique_name((bias_value.name or "") + "/gnlz_gemm/bias"),
            bias_np,
        )
        new_gemm_bias.meta["extra_info"] = bias_value.meta["extra_info"].copy()

        return new_gemm_bias

    def _make_canonical_gemm(
        self,
        graph: ir.Graph,
        ori_gemm_node: ir.Node,
        new_gemm_inputs: List[ir.Value],
        new_gemm_alpha: float,
        new_gemm_beta: float,
    ) -> ir.Node | None:
        if new_gemm_inputs[0].shape is None or new_gemm_inputs[1].shape is None:
            return None
        new_gemm = ir.Node(
            "",
            "Gemm",
            new_gemm_inputs,
            name=graph.meta["extra_info"].get_unique_name((ori_gemm_node.name or "") + "/gnlz_gemm"),
        )
        new_gemm.attributes.add(ir.AttrFloat32("alpha", new_gemm_alpha))
        new_gemm.attributes.add(ir.AttrFloat32("beta", new_gemm_beta))
        new_gemm.attributes.add(ir.AttrInt64("transA", 0))
        new_gemm.attributes.add(ir.AttrInt64("transB", 0))
        ori_gemm_output0 = ori_gemm_node.outputs[0]
        assert ori_gemm_output0 is not None
        new_gemm_output0 = new_gemm.outputs[0]
        assert new_gemm_output0 is not None
        new_gemm_output0.name = graph.meta["extra_info"].get_unique_name(
            (ori_gemm_output0.name or "") + "/gnlz_gemm"
        )
        new_gemm_output0.type = copy.deepcopy(ori_gemm_output0.type)
        new_gemm_output0.meta["extra_info"] = ori_gemm_output0.meta["extra_info"].copy()
        new_gemm_output0.shape = ir.Shape(
            np.array([new_gemm_inputs[0].shape[0], new_gemm_inputs[1].shape[1]])
        )

        return new_gemm

    def match(self, graph: ir.Graph, node: ir.Node) -> bool:
        #  need to check if safetensors exist,
        # if true, then don't apply this transform.
        if node.op_type != "Gemm":
            return False
        # Only check the matrix inputs (A and B), not the optional bias
        if any(
            len(inp.meta["extra_info"].named_safetensors) != 0
            for inp in list(node.inputs)[: min(2, len(node.inputs))]
            if inp is not None
        ):
            return False
        return True

    def rewrite(self, graph: ir.Graph, node: ir.Node, match_info=MatchInfoProtocol | None) -> bool:
        alpha = float(get_attribute_with_default(node, "alpha", 1.0))
        beta = float(get_attribute_with_default(node, "beta", 1.0))
        trans_a = int(get_attribute_with_default(node, "transA", 0))
        trans_b = int(get_attribute_with_default(node, "transB", 0))
        if is_constant(node.inputs[0]) and not is_constant(node.inputs[1]):
            # need to swap input0 and input1

            #      input0      input1     input2               input1         input0         input2
            #     (statics)  (dynamics)  (statics)           (dynamics)      (statics)      (statics)
            #         |          |          |                     |              |              |
            #          \         v         /                      v              v              v
            #            ---->  Gemm  <---          ==>     pre-Transpose   np.transpose   np.transpose
            #             (transA, transB)                      (Node)       (fused into weight/bias)
            #                    |                                |              |              |
            #                    v                                 \             v             /
            #                 output                                 ------>  new_Gemm  <-----
            #                                                           (transA=0, transB=0)
            #                                                                    |
            #                                                                    v
            #                                                             pose-Transpose
            #                                                                    |
            #                                                                    v
            #                                                                  output

            # transA       transB       pre-Transpose     weight_need_transpose

            #    0           0                y                     y
            #  K x M       M x N         -> N x M              -> M x K

            #    1           0                y                     n
            #  M x K       M x N         -> N x M              -> M x K

            #    0           1                n                     y
            #  K x M       N x M         -> N x M              -> M x K

            #    1           1                n                     n
            #  M x K       N x M         -> N x M              -> M x K

            # if transB is 0, we need pre-Transpose Node
            # if transA is 0, we need to transpose the weight

            # ori_input2:      K x N  or  1 x N  or  N
            # new_gemm_bias:   N x K  or  N x 1
            # so we always need to transpose the bias and need pose-Transpose for these cases

            input0 = node.inputs[0]
            input1 = node.inputs[1]
            node_name = node.name
            if input0 is None or input1 is None or node_name is None:
                return False

            if len(get_value_numeric_shape(input0)) != 2:
                return False
            if has_static_shape_on_value(input1):
                if len(get_value_numeric_shape(input1)) != 2:
                    return False

            if trans_b == 0:
                pre_transpose = self._add_pre_or_post_transpose_for_gemm(
                    graph=graph,
                    input_value=input1,
                    ori_gemm_node_name=node_name,
                    value_to_copy_info=input1,
                    transpose_type="pre",
                )
                if pre_transpose is None:
                    return False
                new_gemm_input0 = pre_transpose.outputs[0]
            else:
                new_gemm_input0 = input1

            if trans_a == 0:
                weight_need_transpose = True
                bias_need_transpose = True
            else:
                weight_need_transpose = False
                bias_need_transpose = True

            new_gemm_weight = self._add_weight_for_gemm(
                graph=graph, weight_value=input0, weight_need_transpose=weight_need_transpose
            )

            new_gemm_inputs = [new_gemm_input0, new_gemm_weight]

            if len(node.inputs) > 2:
                input2 = node.inputs[2]
                if input2 is None or not is_constant(input2):
                    return False
                new_gemm_bias = self._add_bias_for_gemm(
                    graph=graph, bias_value=input2, bias_need_transpose=bias_need_transpose
                )
                new_gemm_inputs.append(new_gemm_bias)

            new_gemm = self._make_canonical_gemm(
                graph=graph,
                ori_gemm_node=node,
                new_gemm_inputs=new_gemm_inputs,
                new_gemm_alpha=alpha,
                new_gemm_beta=beta,
            )
            if new_gemm is None:
                return False

            post_transpose = self._add_pre_or_post_transpose_for_gemm(
                graph=graph,
                input_value=new_gemm.outputs[0],
                ori_gemm_node_name=node_name,
                value_to_copy_info=node.outputs[0],
                transpose_type="post",
            )
            if post_transpose is None:
                return False

            # compose
            if trans_b == 0:
                if pre_transpose is None:
                    return False
                graph.insert_before(node, pre_transpose)
                graph.insert_after(pre_transpose, new_gemm)
            else:
                graph.insert_before(node, new_gemm)

            graph.insert_after(new_gemm, post_transpose)
            safe_replace_all_uses_with(graph, node.outputs[0], post_transpose.outputs[0])
            return True

        elif not is_constant(node.inputs[0]) and is_constant(node.inputs[1]):
            # no need to swap input0 and input1

            #      input0      input1     input2               input0         input1         input2
            #     (statics)  (dynamics)  (statics)           (dynamics)      (statics)      (statics)
            #         |          |          |                     |              |              |
            #          \         v         /                      v              v              v
            #            ---->  Gemm  <---          ==>     pre-Transpose   np.transpose   np.transpose
            #             (transA, transB)                      (Node)       (fused into weight/bias)
            #                    |                                |              |              |
            #                    v                                 \             v             /
            #                 output                                 ------>  new_Gemm  <-----
            #                                                           (transA=0, transB=0)
            #                                                                    |
            #                                                                    v
            #                                                             pose-Transpose
            #                                                                    |
            #                                                                    v
            #                                                                  output

            # transA       transB       pre-Transpose     weight_need_transpose

            #    0           0                n                     n
            #  K x M       M x N         -> K x M              -> M x N

            #    1           0                y                     n
            #  M x K       M x N         -> K x M              -> M x N

            #    0           1                n                     y
            #  K x M       N x M         -> K x M              -> M x N

            #    1           1                y                     y
            #  M x K       N x M         -> K x M              -> M x N

            # if transA is 1, we need pre-Transpose Node
            # if transB is 1, we need to transpose the weight

            # ori_input2:      K x N  or  1 x N  or  N
            # new_gemm_bias:   K x N  or  1 x N  or  N
            # so we always no need to transpose the bias and need pose-Transpose for these cases

            input0 = node.inputs[0]
            input1 = node.inputs[1]
            node_name = node.name
            if input0 is None or input1 is None or node_name is None:
                return False

            if has_static_shape_on_value(input0):
                if len(get_value_numeric_shape(input0)) != 2:
                    return False
            if len(get_value_numeric_shape(input1)) != 2:
                return False

            if trans_a == 1:
                pre_transpose = self._add_pre_or_post_transpose_for_gemm(
                    graph=graph,
                    input_value=input0,
                    ori_gemm_node_name=node_name,
                    value_to_copy_info=input0,
                    transpose_type="pre",
                )
                if pre_transpose is None:
                    return False
                new_gemm_input0 = pre_transpose.outputs[0]
            else:
                new_gemm_input0 = input0

            if trans_b == 1:
                weight_need_transpose = True
                bias_need_transpose = False
            else:
                weight_need_transpose = False
                bias_need_transpose = False

            new_gemm_weight = self._add_weight_for_gemm(
                graph=graph, weight_value=input1, weight_need_transpose=weight_need_transpose
            )

            new_gemm_inputs = [new_gemm_input0, new_gemm_weight]

            if len(node.inputs) > 2:
                input2 = node.inputs[2]
                if input2 is None or not is_constant(input2):
                    return False
                new_gemm_bias = self._add_bias_for_gemm(
                    graph=graph, bias_value=input2, bias_need_transpose=bias_need_transpose
                )
                new_gemm_inputs.append(new_gemm_bias)

            new_gemm = self._make_canonical_gemm(
                graph=graph,
                ori_gemm_node=node,
                new_gemm_inputs=new_gemm_inputs,
                new_gemm_alpha=alpha,
                new_gemm_beta=beta,
            )
            if new_gemm is None:
                return False

            # compose
            if trans_a == 1:
                if pre_transpose is None:
                    return False
                graph.insert_before(node, pre_transpose)
                graph.insert_after(pre_transpose, new_gemm)
            else:
                graph.insert_before(node, new_gemm)

            safe_replace_all_uses_with(graph, node.outputs[0], new_gemm.outputs[0])
            return True

        return False
