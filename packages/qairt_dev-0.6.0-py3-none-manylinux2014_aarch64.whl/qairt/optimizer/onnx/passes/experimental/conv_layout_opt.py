# ==============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
This module provides passes for Conv layout optimization under the unified entry point
OptConvLayout, which runs the following sub-passes in order:

  1. OptSwinTransformerMatMulBeforeReshapeTranspose /
     OptSwinTransformerMatMulAfterReshapeTranspose — move 1x1 Conv ops through
     Reshape/Transpose sequences in Swin-Transformer-style models
     (window-partition / window-unpartition patterns).

  2. FoldConv1x1PreNhwcSeqPass — simplifies layout transformations around 1x1 Conv ops
     whose pre-Conv Reshape/Transpose sequence has a net effect of NHWC→NCHW.
"""

from dataclasses import dataclass

import onnx_ir as ir

from qairt.optimizer.onnx.graph import GraphContext
from qairt.optimizer.onnx.passes.base import BasePass, BasePredicatePass, MatchInfoProtocol
from qairt.optimizer.onnx.passes.cleaning import (
    DeadCodeRemovalRewriter,
    MergeSequenceTransposeOps,
)
from qairt.optimizer.onnx.passes.experimental.linear_to_conv import (
    CanonizeGemmPass,
    LinearToConvPass,
)
from qairt.optimizer.onnx.passes.layout_opt import (
    ProtectLayoutSensitiveOps,
    UnProtectLayoutSensitiveOps,
)
from qairt.optimizer.onnx.passes.layout_opt.protect_layout_sensitive_ops import CONV_CHN_LAST
from qairt.optimizer.onnx.utils.reshape_transpose_analysis import (
    DimRoot,
    DimTree,
    OneSizeDimNode,
    ReshapeTransposeInfoSeq,
)
from qairt.optimizer.onnx.utils.reshape_transpose_seq_utils import (
    ReshapeTransposeInfoSeq,
    ReshapeTransposeOpSeq,
    determine_seq_complexity,
    find_reshape_transpose_seq_bottom_up,
    find_reshape_transpose_seq_top_down,
)
from qairt.optimizer.onnx.utils.utils import (
    get_value_numeric_shape,
    has_static_shape_on_value,
    is_1x1_conv,
    safe_insert_node_after,
    safe_replace_all_uses_with,
)
from qairt.optimizer.utils.logger import logger

# ==============================================================================
# ── From swin_transformer_conv_layout_opt ──────────────────────────────────
# ==============================================================================

_TARGET_TRANSPOSE_PERM = [0, 1, 3, 2, 4, 5]  # 6D Swin-Transformer window partition


def _is_unsplit_source_dim(node) -> bool:
    """Return True if node is an original, unsplit source dimension."""
    return isinstance(node, OneSizeDimNode) or isinstance(node.parent, DimRoot)


def _apply_dim_tree_ops(
    dt: DimTree,
    ops: list,
) -> bool:
    """Apply a list of ReshapeNodeInfo / TransposeNodeInfo ops to dt in order.
    Returns False (or raises nothing) if any reshape fails; propagates no exceptions.
    """
    for op in ops:
        try:
            if isinstance(op, ReshapeTransposeInfoSeq.ReshapeNodeInfo):
                if not dt.reshape(op.shape):
                    return False
            else:
                dt.transpose(op.perm)
        except AssertionError:
            return False
    return True


def _check_c_last(cd: list) -> bool:
    """Return True if the last slot of curr_dims is a single unsplit source dim (C)."""
    return len(cd[-1]) == 1 and _is_unsplit_source_dim(cd[-1][0])


def _find_window_partition_subseq(op_seq: ReshapeTransposeOpSeq) -> ReshapeTransposeOpSeq | None:
    """
    Scan op_seq for the first position where the window-partition target pattern begins,
    then return a new ReshapeTransposeOpSeq starting from that position.

    DimTree checks:
      Check A: input to the pattern must be 4D
      Check B: after Reshape1 — 6 slots, each 1 node; N (slot[0]) and C (slot[5]) are unsplit
               source dims; H split into 2 siblings at slots [1,2]; W split into 2 siblings at
               slots [3,4]; H-parent ≠ W-parent
      Check C: after Reshape2 — ≤ 4 slots (spatial dims merged); C is last unsplit dim
      Check D: after all remaining ops — C is still the last single unsplit dim

    Returns None if no such starting position is found.
    """
    info_seq = op_seq.build_info_seq()
    if info_seq is None:
        return None

    seq = info_seq.seq
    n = len(seq)

    for i in range(n - 2):
        # Op-type / perm checks for the 3-op pattern at position i
        if not isinstance(seq[i], ReshapeTransposeInfoSeq.ReshapeNodeInfo):
            continue
        if not isinstance(seq[i + 1], ReshapeTransposeInfoSeq.TransposeNodeInfo):
            continue
        if list(seq[i + 1].perm) != _TARGET_TRANSPOSE_PERM:
            continue
        if not isinstance(seq[i + 2], ReshapeTransposeInfoSeq.ReshapeNodeInfo):
            continue

        # Compute the input shape at position i by applying ops [0..i)
        dt_pre = DimTree(info_seq.input_shape)
        if not _apply_dim_tree_ops(dt_pre, seq[:i]):
            continue
        shape_at_i = [s[0].size if len(s) == 1 else -1 for s in dt_pre.curr_dims]

        # Check A: input to the pattern must be 4D
        if len(shape_at_i) != 4:
            continue

        # Apply Reshape1 and check B
        dt = DimTree(shape_at_i)
        if not _apply_dim_tree_ops(dt, seq[i : i + 1]):
            continue
        cd = dt.curr_dims
        if len(cd) != 6 or not all(len(s) == 1 for s in cd):
            continue
        if not _is_unsplit_source_dim(cd[0][0]) or not _is_unsplit_source_dim(cd[5][0]):
            continue
        h_parent = cd[1][0].parent
        if h_parent is None or isinstance(h_parent, DimRoot) or cd[2][0].parent is not h_parent:
            continue
        w_parent = cd[3][0].parent
        if w_parent is None or isinstance(w_parent, DimRoot) or cd[4][0].parent is not w_parent:
            continue
        if h_parent is w_parent:
            continue

        # Apply Transpose + Reshape2 and check C: ≤ 4 slots (spatial dims merged); C is last unsplit dim
        if not _apply_dim_tree_ops(dt, seq[i + 1 : i + 3]):
            continue
        if len(dt.curr_dims) > 4 or not _check_c_last(dt.curr_dims):
            continue

        # Check D: apply remaining ops and verify C stays last and unsplit
        if not _apply_dim_tree_ops(dt, seq[i + 3 :]):
            continue
        if not _check_c_last(dt.curr_dims):
            continue

        # Found the pattern at index i — build the sub-sequence starting there
        sub_op_list = op_seq.op_list[i:]
        sub_input_v = op_seq.op_list[i].inputs[0]
        assert sub_input_v is not None
        return ReshapeTransposeOpSeq(sub_input_v, op_seq.output_v, sub_op_list, op_seq.v_extra_info)

    return None


def _find_window_unpartition_subseq(op_seq: ReshapeTransposeOpSeq) -> ReshapeTransposeOpSeq | None:
    """
    Scan op_seq for the last position where the window-unpartition target pattern ends,
    then return a new ReshapeTransposeOpSeq ending at that position.

    DimTree checks:
      Check A: C is the last single unsplit dim before the 3-op suffix
      Check B: after Reshape1 — 6 slots, each 1 node; slot[5] (C) is an unsplit source dim
      Check C: after Reshape2 — 4 slots; slot[0] has 1 node; slots [1,2] each have 2 nodes;
               slot[3] has 1 unsplit node (C)

    Note: when N=1, DimTree represents slot[0] as OneSizeDimNode (parent=None). Structural
    validity is confirmed via the sibling check on slots [1,2] and DimRoot ancestry of
    remain1's parent.

    Returns None if no such ending position is found.
    """
    info_seq = op_seq.build_info_seq()
    if info_seq is None:
        return None

    seq = info_seq.seq
    n = len(seq)

    # Scan from the end: try each possible end position j (exclusive), j >= 3
    for j in range(n, 2, -1):
        # Op-type / perm checks for the 3-op pattern ending at j
        if not isinstance(seq[j - 3], ReshapeTransposeInfoSeq.ReshapeNodeInfo):
            continue
        if not isinstance(seq[j - 2], ReshapeTransposeInfoSeq.TransposeNodeInfo):
            continue
        if list(seq[j - 2].perm) != _TARGET_TRANSPOSE_PERM:
            continue
        if not isinstance(seq[j - 1], ReshapeTransposeInfoSeq.ReshapeNodeInfo):
            continue

        dt = DimTree(info_seq.input_shape)

        # Check A: apply all ops before the 3-op suffix; C must be last unsplit dim
        if not _apply_dim_tree_ops(dt, seq[: j - 3]):
            continue
        if not _check_c_last(dt.curr_dims):
            continue

        # Apply Reshape1 and check B: 6 slots, each 1 node, C at slot[5] unsplit
        if not _apply_dim_tree_ops(dt, seq[j - 3 : j - 2]):
            continue
        cd = dt.curr_dims
        if len(cd) != 6 or not all(len(s) == 1 for s in cd):
            continue
        if not _is_unsplit_source_dim(cd[5][0]):
            continue

        # Apply Transpose + Reshape2 and check C
        if not _apply_dim_tree_ops(dt, seq[j - 2 : j]):
            continue
        cd = dt.curr_dims
        if len(cd) != 4 or len(cd[0]) != 1:
            continue
        if len(cd[1]) != 2 or len(cd[2]) != 2:
            continue
        if len(cd[3]) != 1 or not _is_unsplit_source_dim(cd[3][0]):
            continue

        # Found the pattern ending at index j — build the sub-sequence ending there
        sub_op_list = op_seq.op_list[:j]
        sub_output_v = op_seq.op_list[j - 1].outputs[0]
        assert sub_output_v is not None
        return ReshapeTransposeOpSeq(op_seq.input_v, sub_output_v, sub_op_list, op_seq.v_extra_info)

    return None


_META_REBUILT_BY_BEFORE = "OptSwinTransformerMatMulBeforeReshapeTranspose.rebuilt_by_before"


def _apply_last_dim_remap_to_info_seq(
    info_seq: ReshapeTransposeInfoSeq,
    c_in: int,
    c_out: int,
) -> ReshapeTransposeInfoSeq:
    """
    Return a new ReshapeTransposeInfoSeq with the last dim of each ReshapeNodeInfo shape
    remapped from c_in to c_out. Only the last position is touched to avoid incorrectly
    remapping spatial dims that happen to share the same value as c_in.
    TransposeNodeInfo entries are copied unchanged.
    """
    if c_in == c_out:
        return info_seq
    new_seq = []
    for node_info in info_seq.seq:
        if isinstance(node_info, ReshapeTransposeInfoSeq.ReshapeNodeInfo):
            shape = list(node_info.shape)
            if shape and shape[-1] == c_in:
                shape[-1] = c_out
            new_seq.append(ReshapeTransposeInfoSeq.ReshapeNodeInfo(shape))
        else:
            new_seq.append(node_info)
    return ReshapeTransposeInfoSeq(new_seq, info_seq.input_shape)


def _rebuild_rt_seq_for_new_input(
    graph: ir.Graph,
    op_seq: ReshapeTransposeOpSeq,
    new_input_v: ir.Value,
    mark_rebuilt_by_before: bool = False,
    c_in: int | None = None,
    c_out: int | None = None,
) -> tuple[ir.Value, ir.Node | None]:
    """
    Rebuild the R/T sequence (op_seq) starting from new_input_v.

    If c_in and c_out are provided, the last dim of each ReshapeNodeInfo shape is remapped
    from c_in to c_out (only the last position is touched to avoid incorrectly remapping
    spatial dims that share the same value).

    If mark_rebuilt_by_before is True, each rebuilt node is tagged with
    node.meta[_META_REBUILT_BY_BEFORE] = True so that
    OptSwinTransformerMatMulAfterReshapeTranspose can skip them.

    Returns (final_output_value, first_rebuilt_node). first_rebuilt_node is None if
    the sequence is empty.
    """
    info_seq = op_seq.build_info_seq()
    assert info_seq is not None

    if c_in is not None and c_out is not None:
        info_seq = _apply_last_dim_remap_to_info_seq(info_seq, c_in, c_out)

    new_op_seq = ReshapeTransposeOpSeq.create_by_info_seq(graph, new_input_v, op_seq.v_extra_info, info_seq)
    assert new_op_seq is not None

    if mark_rebuilt_by_before:
        for rebuilt_node in new_op_seq.op_list:
            rebuilt_node.meta[_META_REBUILT_BY_BEFORE] = True

    first_node = new_op_seq.op_list[0] if new_op_seq.op_list else None
    return new_op_seq.output_v, first_node


# ---------------------------------------------------------------------------
# MatchInfo dataclasses — cache op_seq between match() and rewrite()
# ---------------------------------------------------------------------------


@dataclass
class _BeforeMatchInfo(MatchInfoProtocol):
    op_seq: ReshapeTransposeOpSeq


@dataclass
class _AfterMatchInfo(MatchInfoProtocol):
    op_seq: ReshapeTransposeOpSeq


class OptSwinTransformerMatMulBeforeReshapeTranspose(BasePredicatePass):
    """
    Move a CONV_CHN_LAST 1x1 (NHWC format) that is preceded by a Reshape/Transpose sequence
    to before those ops.

    Swin model partition is [N,H,W,C_in] → [N, H/ws, ws_H, W/ws, ws_W, C_in] -> [..., C_in].

    Transform subgraph:
        Subgraph(input : [N, H, W, C_in]) --> conv_out
        {
            r1 = Reshape1(input)                                         # [N, H/ws, ws_H, W/ws, ws_W, C_in]
            t1 = Transpose(r1, perm=[0,1,3,2,4,5])                       # [N, H/ws, W/ws, ws_H, ws_W, C_in] swap dims 2↔3
            r2 = Reshape2(t1)                                            # [..., C_in]
            rn = [... optional further reshape/transpose ops ...]        # seq_out: [..., C_in]
            conv_out = CONV_CHN_LAST(rn, weight, bias)                   # 1x1 conv: [...,C_out]
        }
    Into:
        Subgraph(input : [N, H, W, C_in]) --> conv_out
        {
            conv_out_pre = CONV_CHN_LAST(input, weight, bias)            # 1x1 conv, [N, H, W, C_out]
            r1 = Reshape1(conv_out_pre)                                  # [N, H/ws, ws_H, W/ws, ws_W, C_out]
            t1 = Transpose(r1, perm=[0,1,3,2,4,5]):                      # swap dims 2↔3, [N, H/ws, W/ws, ws_H, ws_W, C_out]
            r2 = Reshape2(t1)                                            # [..., C_out]
            rn = [... optional further reshape/transpose ops ...]        # [..., C_out]
        }
    """

    def match(self, graph: ir.Graph, node: ir.Node) -> _BeforeMatchInfo | bool:
        if node.op_type != CONV_CHN_LAST:
            return False
        if "kernel_shape" in node.attributes:
            if not all(k == 1 for k in node.attributes["kernel_shape"].as_ints()):
                return False
        else:
            w = node.inputs[1]
            if w is None or w.shape is None:
                return False
            if not all(k == 1 for k in list(w.shape)[2:]):
                return False

        # CONV_CHN_LAST input is already NHWC (produced by ProtectLayoutSensitiveOps).
        in_a = node.inputs[0]
        if in_a is None or not has_static_shape_on_value(in_a):
            return False

        op_seq = find_reshape_transpose_seq_bottom_up(in_a, set())
        if len(op_seq.op_list) == 0:
            return False
        if not has_static_shape_on_value(op_seq.input_v):
            return False

        op_seq = _find_window_partition_subseq(op_seq)
        if op_seq is None:
            return False
        if not has_static_shape_on_value(op_seq.input_v):
            return False

        return _BeforeMatchInfo(op_seq=op_seq)

    def rewrite(self, graph: ir.Graph, node: ir.Node, match_info: MatchInfoProtocol | None = None) -> bool:
        assert isinstance(match_info, _BeforeMatchInfo)
        op_seq = match_info.op_seq

        seq_input = op_seq.input_v
        seq_input_shape = get_value_numeric_shape(seq_input)

        in_a_shape = get_value_numeric_shape(node.inputs[0])
        c_in = in_a_shape[-1]

        # CONV_CHN_LAST output shape (NHWC): [..., C_out]
        conv_out_shape = get_value_numeric_shape(node.outputs[0])
        c_out = conv_out_shape[-1]
        node.replace_input_with(0, seq_input)

        nhwc_out = list(seq_input_shape[:-1]) + [c_out]
        node.outputs[0].shape = ir.Shape(nhwc_out)
        safe_insert_node_after(graph, seq_input.producer(), node)

        curr_v, first_rebuilt_node = _rebuild_rt_seq_for_new_input(
            graph=graph,
            op_seq=op_seq,
            new_input_v=node.outputs[0],
            mark_rebuilt_by_before=True,
            c_in=c_in,
            c_out=c_out,
        )

        except_nodes = [first_rebuilt_node] if first_rebuilt_node is not None else []
        safe_replace_all_uses_with(graph, node.outputs[0], curr_v, except_users=except_nodes)
        graph.meta["extra_info"].record_sharing_encodings(
            node.outputs[0].name, curr_v.name, self.__class__.__name__
        )
        logger.debug(
            "applied pass %s on '%s': moved Conv before reshape/transpose sequence",
            self.__class__.__name__,
            node.name,
        )
        return True


class OptSwinTransformerMatMulAfterReshapeTranspose(BasePredicatePass):
    """
    Move a CONV_CHN_LAST 1x1 (NHWC format) that is followed by a Reshape/Transpose sequence
    to after those ops.

    Swin model unpartition is [..., C_out] → [N, H/ws, ws_H, W/ws, ws_W, C_out] -> [N, H, W, C_out].

    Transform subgraph:
        Subgraph(in_a : [N, H, W, C]) --> seq_out
        {
            conv_out = CONV_CHN_LAST(in_a, weight, bias)                # 1x1 conv, [N, H, W, C_out]
            rn = [... optional further reshape/transpose ops ...]       # [..., C_out]
            r1 = Reshape1(rn)                                           # [..., C_out]
            t1 = Transpose(r1, perm = [0,1,3,2,4,5])                    # swap dims 2↔3, [N, H/ws, ws_H, W/ws, ws_W, C_out]
            Reshape2(t1)                                                # [N, H, W, C_out]  [window-unpartition]
        }
    Into:
        Subgraph(in_a : [N, H, W, C]) --> seq_out
        {
            rn = [... optional further reshape/transpose ops ...]       # [..., C_in]
            r1 = Reshape1(rn)                                           # [..., C_in]
            t1 = Transpose(r1, perm=[0,1,3,2,4,5])                      # swap dims 2↔3, [N, H/ws, ws_H, W/ws, ws_W, C_in]
            r2 = Reshape2(t1)                                           # [N,H,W,C_in]  [window-unpartition]
            seq_out = CONV_CHN_LAST(r2, weight, bias)                   # [N, H, W, C_out]
        }
    """

    def match(self, graph: ir.Graph, node: ir.Node) -> _AfterMatchInfo | bool:
        if node.op_type != CONV_CHN_LAST:
            return False
        if "kernel_shape" in node.attributes:
            if not all(k == 1 for k in node.attributes["kernel_shape"].as_ints()):
                return False
        else:
            w = node.inputs[1]
            if w is None or w.shape is None:
                return False
            if not all(k == 1 for k in list(w.shape)[2:]):
                return False

        # CONV_CHN_LAST output is NHWC (produced by ProtectLayoutSensitiveOps).
        conv_out = node.outputs[0]
        if not has_static_shape_on_value(conv_out):
            return False
        if len(list(conv_out.uses())) != 1:
            return False

        # R/T sequence starts from conv_out (includes T_post and everything after)
        op_seq = find_reshape_transpose_seq_top_down(conv_out, set())
        if len(op_seq.op_list) == 0:
            return False
        if not has_static_shape_on_value(op_seq.output_v):
            return False

        op_seq = _find_window_unpartition_subseq(op_seq)
        if op_seq is None:
            return False
        if not has_static_shape_on_value(op_seq.output_v):
            return False

        # Skip R/T sequences rebuilt by Before to avoid undoing its work.
        if any(n.meta.get(_META_REBUILT_BY_BEFORE) for n in op_seq.op_list):
            return False

        if node.inputs[0] is None or not has_static_shape_on_value(node.inputs[0]):
            return False

        return _AfterMatchInfo(op_seq=op_seq)

    def rewrite(self, graph: ir.Graph, node: ir.Node, match_info: MatchInfoProtocol | None = None) -> bool:
        assert isinstance(match_info, _AfterMatchInfo)
        op_seq = match_info.op_seq

        in_a = node.inputs[0]
        if in_a is None:
            return False

        conv_out_shape = get_value_numeric_shape(node.outputs[0])
        c_out = conv_out_shape[-1]

        # Rebuild the R/T sequence from in_a (T_pre's output, NHWC).
        # C doesn't appear as a literal in the reshape shapes, so no dim_remap needed" rather than "same C_in".
        curr_v, _ = _rebuild_rt_seq_for_new_input(graph=graph, op_seq=op_seq, new_input_v=in_a)
        curr_v_producer = curr_v.producer()
        assert curr_v_producer is not None, "rebuilt sequence must have a producer node"

        curr_v_shape = get_value_numeric_shape(curr_v)
        nhwc_out = list(curr_v_shape[:-1]) + [c_out]
        node.outputs[0].shape = ir.Shape(nhwc_out)

        node.replace_input_with(0, curr_v)
        graph.insert_after(curr_v_producer, node)

        safe_replace_all_uses_with(graph, op_seq.output_v, node.outputs[0])
        graph.meta["extra_info"].record_sharing_encodings(
            op_seq.output_v.name, node.outputs[0].name, self.__class__.__name__
        )

        logger.debug(
            "applied pass %s on '%s': moved Conv after reshape/transpose sequence",
            self.__class__.__name__,
            node.name,
        )
        return True


# ==============================================================================
# ── From simplify_conv_layout ──────────────────────────────────────────────
# ==============================================================================


def _trim_seq_to_4d_start(seq: ReshapeTransposeOpSeq) -> ReshapeTransposeOpSeq | None:
    """
    Walk forward through `seq` to find the first intermediate value that is 4D.
    Returns a (possibly trimmed) ReshapeTransposeOpSeq whose input_v is 4D, or
    None if no 4D starting point exists or the remaining sequence is empty.
    """
    input_v = seq.input_v
    op_list = list(seq.op_list)
    while True:
        if not has_static_shape_on_value(input_v):
            return None
        if len(get_value_numeric_shape(input_v)) == 4:
            break
        # Not 4D: skip this op and try the next intermediate value
        if not op_list:
            return None
        input_v = op_list[0].outputs[0]
        op_list = op_list[1:]

    if not op_list:
        return None
    if input_v is seq.input_v:
        return seq
    return ReshapeTransposeOpSeq(input_v, seq.output_v, op_list, seq.v_extra_info)


def _pre_conv_nc_unchanged(pre_info_seq: ReshapeTransposeInfoSeq) -> bool:
    """Return True if the pre-conv sequence preserves both N and C as individual
    unsplit source dimensions in the correct positions (NCHW layout).

    Correctness principle: when N stays at position 0 (unsplit) and C (last dim of the
    4D NHWC input) stays at position 1 (unsplit), the HW dims can reshape/transpose
    freely.  Since Conv1x1 is spatially independent, the replacement conv is correct.

    N==1 trivially satisfies the N constraint — there is only one batch element, so N
    is unchanged regardless of where it appears in the layout.  This matters because
    DimTree represents size-1 dims as new OneSizeDimNode() instances (parent=None),
    so an identity-check against src_root.children[0] would incorrectly fail for N=1.
    """
    dt = DimTree(pre_info_seq.input_shape)
    if not _apply_dim_tree_ops(dt, pre_info_seq.seq):
        return False
    curr_dims = dt.curr_dims
    if len(curr_dims) != 4:  # Conv input must be 4D (NCHW)
        return False

    # Check C is at position 1 unsplit
    slot_1 = curr_dims[1]
    if len(slot_1) != 1:
        return False
    # C is src_root.children[-1] (last source dim in NHWC = channel)
    c_source = dt.src_root.children[-1]
    if slot_1[0] is not c_source:
        return False

    # Check N is at position 0 unsplit.
    # N==1: skip check — a single-element batch is trivially unchanged regardless of
    # position.  (DimTree creates a fresh OneSizeDimNode for N=1, so an `is`-check
    # against src_root.children[0] would incorrectly fail even when N is at pos 0.)
    n_input = pre_info_seq.input_shape[0]
    if n_input != 1:
        slot_0 = curr_dims[0]
        if len(slot_0) != 1:
            return False
        n_source = dt.src_root.children[0]  # original N DimNode (size > 1)
        if slot_0[0] is not n_source:
            return False

    return True


def _build_post_conv_laytout(
    pre_info_seq: ReshapeTransposeInfoSeq,
    c_out: int,
) -> list[ReshapeTransposeInfoSeq.BaseNodeInfo]:
    """Return ops that convert the new NCHW Conv output to the old Conv output layout.

    The new Conv output is [N, C_out, H, W] (because the pre-conv is simplified to a
    single Transpose([0,3,1,2])).  The old Conv output was produced by the original
    pre-conv sequence and has shape [a0, C_out, a2, a3] — the spatial dims N/H/W may
    be merged/permuted differently.

    The correct bridge is:
      1. Transpose([0,2,3,1]):  NCHW → NHWC  →  [N, H, W, C_out]
      2. Apply the same ops as pre_info_seq, but with C_out substituted for C_in in
         any Reshape target shapes.  DimTree is used to track the exact position of
         the C dim before each Reshape so the substitution is always at the right slot.

    For the pure-transpose case (no Reshape in pre_info_seq), the two transposes
    compose to the identity and simplify_seq folds them away.
    """
    # Use DimTree to track which curr_dims slot holds C as we replay the ops.
    dt = DimTree(pre_info_seq.input_shape)
    c_source = dt.src_root.children[-1]  # C dim node (last dim of NHWC input)

    adapted_ops: list[ReshapeTransposeInfoSeq.BaseNodeInfo] = []
    for op in pre_info_seq.seq:
        if isinstance(op, ReshapeTransposeInfoSeq.TransposeNodeInfo):
            dt.transpose(op.perm)
            adapted_ops.append(op)  # Transpose perms are position-based; reuse as-is.
        elif isinstance(op, ReshapeTransposeInfoSeq.ReshapeNodeInfo):
            dt.reshape(op.shape)
            # Find C's position in curr_dims AFTER the reshape (= index into target shape).
            c_pos = next(
                (i for i, slot in enumerate(dt.curr_dims) if len(slot) == 1 and slot[0] is c_source),
                None,
            )
            adapted_shape = list(op.shape)
            if c_pos is not None:
                adapted_shape[c_pos] = c_out
            adapted_ops.append(ReshapeTransposeInfoSeq.ReshapeNodeInfo(adapted_shape))

    # Prepend NCHW→NHWC so the full bridge starts from [N, C_out, H, W].
    nchw_to_nhwc = ReshapeTransposeInfoSeq.TransposeNodeInfo([0, 2, 3, 1])
    return [nchw_to_nhwc] + adapted_ops


class FoldConv1x1PreNhwcSeqPass(BasePredicatePass):
    """
    Simplify a Conv1x1 which contains a redundant Reshape/Transpose
    layout conversion into a cheaper equivalent, when the input is a 4D NHWC tensor.

    Condition: the C channel dim must land unsplit at position 1 of the Conv input
    (NCHW order).The rewrite fires only when the combined pre+post
    complexity strictly decreases.


    Transform subgraph:
        Subgraph(input : [S1, S_in0, S_in1, C_in]) --> seq_out
        {
            sq_prev = [... Reshape/Transpose sequence ...]           # conv_input: [S1, C_in, S2, S3]
            conv_out = Conv(rn, weight, bias)                        # 1x1 conv, [S1, C_out, S2, S3]
            sq_post = [... optional further R/T ops ...]             # seq_out, [S1, D2, c_out, D3]
        }
    Into:
        Subgraph(input : [S1, S_in0, S_in1, C_in]) --> seq_out
        {
            sq_prev = Transpose(input, perm=[0,3,1,2])               # NHWC→NCHW, [S1, C_in, S_in0, S_in1]
            conv_out = Conv(t1, weight, bias)                        # conv, [S1, C_out, S_in0, S_in1]
            sq_post = [... simplified R/T ops ...]                   # seq_out, [S1, D2, c_out, D3]
        }
    """

    class MatchInfo(MatchInfoProtocol):
        def __init__(
            self,
            pre_seq: ReshapeTransposeOpSeq,
            pre_info_seq: ReshapeTransposeInfoSeq,
            new_pre_info_seq: ReshapeTransposeInfoSeq,
            post_seq: ReshapeTransposeOpSeq,
            post_info_seq: ReshapeTransposeInfoSeq,
            new_post_info_seq: ReshapeTransposeInfoSeq,
            new_conv_out_shape: list[int] | None = None,
        ):
            self.pre_seq = pre_seq
            self.pre_info_seq = pre_info_seq
            self.new_pre_info_seq = new_pre_info_seq
            self.post_seq = post_seq
            self.post_info_seq = post_info_seq
            self.new_post_info_seq = new_post_info_seq
            self.new_conv_out_shape = new_conv_out_shape

    def match(self, graph: ir.Graph, node: ir.Node) -> bool | MatchInfo:
        """Check if the node is a 1x1 Conv with a qualifying pre/post Reshape/Transpose
        sequence, and pre-compute the sequences for use in rewrite()."""
        if not is_1x1_conv(node):
            return False

        conv_input = node.inputs[0]
        if conv_input is None:
            return False

        pre_seq = find_reshape_transpose_seq_bottom_up(conv_input, set())
        if not pre_seq.op_list:
            return False

        # Trim the sequence front to find a 4D start. For simplification implementation,
        # we ensure we can find the correct HW dimension.
        pre_seq = _trim_seq_to_4d_start(pre_seq)
        if pre_seq is None:
            return False
        input_shape = get_value_numeric_shape(pre_seq.input_v)

        # Verify the C dim (last dim of NHWC input) still lands unsplit at position 1
        # of the Conv input, regardless of any Reshape ops in the pre-conv sequence.
        pre_info_seq = pre_seq.build_info_seq()
        if pre_info_seq is None:
            return False
        if not _pre_conv_nc_unchanged(pre_info_seq):
            return False
        conv_weight = node.inputs[1]
        if conv_weight is None or not has_static_shape_on_value(conv_weight):
            return False
        new_pre_info_seq = ReshapeTransposeInfoSeq(
            [ReshapeTransposeInfoSeq.TransposeNodeInfo([0, 3, 1, 2])],
            list(input_shape),
        )
        c_out = get_value_numeric_shape(conv_weight)[0]
        new_conv_out_shape = [input_shape[0], c_out, input_shape[1], input_shape[2]]

        # Find the post-Conv Reshape/Transpose sequence (top-down from Conv output).
        # When no post-seq exists (Conv output feeds directly into a non-R/T op),
        # we still proceed — the bridge alone becomes the new post-seq.
        post_seq = find_reshape_transpose_seq_top_down(node.outputs[0], set())
        if post_seq.op_list:
            post_info_seq = post_seq.build_info_seq()
            if post_info_seq is None:
                return False
        else:
            old_conv_out_shape = get_value_numeric_shape(node.outputs[0])
            if old_conv_out_shape is None:
                return False
            post_info_seq = ReshapeTransposeInfoSeq([], old_conv_out_shape)

        # Build the simplified post-Conv sequence.  The bridge converts the new
        # NCHW Conv output back to the old layout so that downstream ops see the
        # shape they were originally built for. `simplify_seq` folds the bridge
        # away when it reduces to the identity (pure-transpose case).
        bridge_ops = _build_post_conv_laytout(pre_info_seq, c_out)
        simplified_post = post_info_seq.simplify_seq()
        combined = ReshapeTransposeInfoSeq(
            bridge_ops + list(simplified_post.seq),
            new_conv_out_shape,
        )
        new_post_info_seq = combined.simplify_seq()

        if post_seq.op_list:
            # When a post-seq exists, require the total pre+post complexity to decrease.
            origin_complexity = determine_seq_complexity(pre_info_seq) + determine_seq_complexity(
                post_info_seq
            )
            new_complexity = determine_seq_complexity(new_pre_info_seq) + determine_seq_complexity(
                new_post_info_seq
            )
            if new_complexity >= origin_complexity:
                return False
        else:
            if determine_seq_complexity(new_pre_info_seq) >= determine_seq_complexity(pre_info_seq):
                return False

        return self.MatchInfo(
            pre_seq,
            pre_info_seq,
            new_pre_info_seq,
            post_seq,
            post_info_seq,
            new_post_info_seq,
            new_conv_out_shape,
        )

    def rewrite(
        self,
        graph: ir.Graph,
        node: ir.Node,
        match_info: MatchInfoProtocol | None = None,
    ) -> bool:
        """Replace the pre-Conv sequence with Transpose([0,3,1,2]) and rebuild the
        post-Conv sequence using the pre-computed match data."""
        assert node.name is not None
        assert isinstance(match_info, self.MatchInfo)

        pre_seq = match_info.pre_seq
        new_pre_info_seq = match_info.new_pre_info_seq
        post_seq = match_info.post_seq
        new_post_info_seq = match_info.new_post_info_seq

        # Build and insert the new pre-Conv node (single Transpose([0,3,1,2]))
        new_pre_op_seq = ReshapeTransposeOpSeq.create_by_info_seq(
            graph,
            pre_seq.input_v,
            pre_seq.v_extra_info,
            new_pre_info_seq,
        )
        if new_pre_op_seq is None:
            return False
        node.replace_input_with(0, new_pre_op_seq.output_v)

        # When the pre-conv included Reshape ops that changed the Conv's input shape,
        # the Conv output shape must be updated to match the new NCHW input before
        # the new post-conv sequence is built.
        if match_info.new_conv_out_shape is not None:
            node.outputs[0].shape = ir.Shape(match_info.new_conv_out_shape)

        # Build and insert the new post-Conv sequence
        new_post_op_seq = ReshapeTransposeOpSeq.create_by_info_seq(
            graph,
            node.outputs[0],
            post_seq.v_extra_info,
            new_post_info_seq,
        )
        if new_post_op_seq is None:
            return False

        # When there's no original post_seq, the post nodes start from
        # node.outputs[0] (same value as post_seq.output_v).  Exclude them
        # from replacement to avoid circular references.
        except_users: set[ir.Node] | None = None
        if not post_seq.op_list and new_post_op_seq.op_list:
            except_users = set(new_post_op_seq.op_list)

        safe_replace_all_uses_with(
            graph, post_seq.output_v, new_post_op_seq.output_v, except_users=except_users
        )
        graph.meta["extra_info"].record_copy(
            post_seq.output_v.name,
            new_post_op_seq.output_v.name,
            self.get_curr_pass_name(),
        )

        logger.debug(
            "applied pass %s on Conv '%s': pre-seq '%s' -> '%s', post-seq '%s' -> '%s'",
            self.get_curr_pass_name(),
            node.name,
            match_info.pre_info_seq.as_oneline_str(),
            new_pre_info_seq.as_oneline_str(),
            match_info.post_info_seq.as_oneline_str(),
            new_post_info_seq.as_oneline_str(),
        )
        return True


# ==============================================================================
# ── Unified entry point ────────────────────────────────────────────────────
# ==============================================================================


class OptConvLayout(BasePass):
    """
    Unified entry point for Conv layout optimization.

    Runs the following sub-passes in order:
      1. CanonizeGemmPass / LinearToConvPass  — canonicalize Gemm → Conv
      2. OptSwinTransformerMatMul{Before,After}ReshapeTranspose  — move 1x1 Conv through
         Swin window-partition / window-unpartition Reshape/Transpose sequences
      3. MergeSequenceTransposeOps / DeadCodeRemovalRewriter  — clean up (if 2 rewrote anything)
      4. FoldConv1x1PreNhwcSeqPass  — simplify NHWC→NCHW pre-Conv sequences to a single Transpose
    """

    def apply(self, ctx: GraphContext) -> int:
        count = 0
        count += CanonizeGemmPass().apply(ctx)
        count += LinearToConvPass().apply(ctx)

        ProtectLayoutSensitiveOps().apply(ctx)
        before_count = OptSwinTransformerMatMulBeforeReshapeTranspose().apply(ctx)
        count += before_count
        after_count = OptSwinTransformerMatMulAfterReshapeTranspose().apply(ctx)
        count += after_count
        UnProtectLayoutSensitiveOps().apply(ctx)

        if before_count + after_count > 0:
            MergeSequenceTransposeOps().apply(ctx)

        simplify_count = FoldConv1x1PreNhwcSeqPass().apply(ctx)
        count += simplify_count
        if count > 0:
            DeadCodeRemovalRewriter().apply(ctx)

        return count
