# ==============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
This module provides passes for replacing
1) (Gather->GroupSlice) -> (GroupSlice->GroupSlice)
2) (Gather split) -> (GroupSlice [+ Squeeze])
"""

from dataclasses import dataclass

import onnx
import onnx_ir as ir

from qairt.optimizer.onnx.passes.base import MatchInfoProtocol
from qairt.optimizer.onnx.passes.mha2sha.base_rewriter import M2sBasePass
from qairt.optimizer.onnx.passes.mha2sha.utils import GroupSliceAttrs, is_reorderable_group_slice
from qairt.optimizer.onnx.utils.utils import (
    check_static_shape_of_node_io,
    get_attribute_with_default,
    get_constant_np,
    is_constant,
    make_initializer,
    safe_replace_all_uses_with,
)
from qairt.optimizer.utils.logger import logger


class M2sReplaceGatherSplit2Groupslice(M2sBasePass):
    """
    Transform subgraph:
        Subgraph(in_a) --> b0,b1,b2...
        {
            b0 = Gather(in_a, idx0)
            b1 = Gather(in_a, idx1)
            b2 = Gather(in_a, idx2)
            ...
        }
    Into:
        Subgraph(in_a) --> b0,b1,b2...
        {
            c0,c1,c2... = GroupSlice(in_a)
            b0 = Squeeze(c0)  # if Gather used scalar indices
            b1 = Squeeze(c1)
            b2 = Squeeze(c2)
            ...
        }

    Only supports Gather with constant scalar indices or 1-length indices
    (equivalent to Slice of length 1). Requires splittable tag.
    """

    @dataclass
    class MatchInfo(MatchInfoProtocol):
        """Match information for M2sReplaceGatherSplit2Groupslice pass"""

        in_value: ir.Value
        """Input value of Gather nodes"""

        gather_nodes: list[ir.Node]
        """Gather nodes to replace"""

        gather_axis: int
        """Gather axis"""

        indices: list[tuple[int, bool]]
        """
        List of (index_value, keep_dim) for each gather node
        keep_dim=True means indices is 1-length (rank preserved)
        """

    def _get_squeeze_axes_input(self, graph: ir.Graph, axis: int):
        axes_name = graph.meta["extra_info"].get_unique_name("squeeze_axes")
        return make_initializer(graph, axes_name, [axis])

    def _build_squeeze_node(self, graph: ir.Graph, data: ir.Value, axis: int, name_hint: str) -> ir.Node:
        # determine whether to use attribute or input for axes
        op_version = graph.opset_imports.get("", None)
        if op_version is None:
            op_version = graph.opset_imports.get("ai.onnx", 13)
        schema = onnx.defs.get_schema("Squeeze", op_version, "")
        if "axes" in schema.attributes:
            squeeze_node = ir.Node("", "Squeeze", [data], name=name_hint)
            squeeze_node.attributes["axes"] = ir.AttrInt64s("axes", [axis])
        else:
            axes_input = self._get_squeeze_axes_input(graph, axis)
            squeeze_node = ir.Node("", "Squeeze", [data, axes_input], name=name_hint)
        return squeeze_node

    def match(self, graph: ir.Graph, node: ir.Node) -> bool | MatchInfo:
        if node.op_type != "Gather":
            return False
        assert len(node.inputs) == 2
        if node.inputs[0] is None or node.inputs[1] is None:
            return False

        check_static_shape_of_node_io(node)

        in_value = node.inputs[0]
        if in_value is None:
            return False
        in_shape = in_value.shape
        if in_shape is None:
            return False

        # collect all Gather nodes using the same input
        gather_nodes = [u for u, _ in in_value.uses() if u.op_type == "Gather"]
        if len(gather_nodes) == 0:
            return False

        # ensure this node is the first to avoid repeated processing
        gather_nodes_sorted = sorted(gather_nodes, key=lambda n: n.name or "")
        if gather_nodes_sorted[0] is not node:
            return False

        gather_axis = get_attribute_with_default(node, "axis", 0)
        if gather_axis < 0:
            gather_axis += in_shape.rank()

        # require splittable on input
        splittable_ok = False
        for param in in_value.meta["extra_info"].splittable:
            if param.axis == gather_axis:
                splittable_ok = True
                break
        if not splittable_ok:
            return False

        indices = []
        for g in gather_nodes_sorted:
            axis = get_attribute_with_default(g, "axis", 0)
            if axis < 0:
                axis += in_shape.rank()
            if axis != gather_axis:
                return False
            if g.inputs[1] is None or not is_constant(g.inputs[1]):
                return False
            idx_np = get_constant_np(g.inputs[1])
            if idx_np.ndim == 0:
                idx_val = int(idx_np)
                keep_dim = False
            elif idx_np.ndim == 1 and idx_np.size == 1:
                idx_val = int(idx_np[0])
                keep_dim = True
            else:
                return False
            if idx_val < 0:
                return False
            indices.append((idx_val, keep_dim))

        return M2sReplaceGatherSplit2Groupslice.MatchInfo(
            in_value=in_value,
            gather_nodes=gather_nodes_sorted,
            gather_axis=gather_axis,
            indices=indices,
        )

    def rewrite(self, graph: ir.Graph, node: ir.Node, match_info: MatchInfoProtocol | None = None) -> bool:
        assert isinstance(match_info, M2sReplaceGatherSplit2Groupslice.MatchInfo)
        in_value = match_info.in_value
        gather_axis = match_info.gather_axis

        # build starts/ends from indices
        idx_with_nodes = list(zip(match_info.indices, match_info.gather_nodes))
        idx_with_nodes.sort(key=lambda x: x[0][0])

        starts = []
        ends = []
        for (idx_val, _), _ in idx_with_nodes:
            starts.append(idx_val)
            ends.append(idx_val + 1)

        gslice_node = self._create_groupslice_node(
            graph,
            in_value,
            GroupSliceAttrs(
                axis=gather_axis,
                starts=starts,
                ends=ends,
                head_slice_ids=[-1] * len(starts),
                batch_slice_ids=[-1] * len(starts),
            ),
            node_namehint=(node.name if node.name is not None else "") + "/as_gslice",
        )
        graph.insert_before(node, gslice_node)

        # map outputs back to gathers
        for out_idx, ((idx_val, keep_dim), gnode) in enumerate(idx_with_nodes):
            g_out = gnode.outputs[0]
            gslice_out = gslice_node.outputs[out_idx]
            replace_v = gslice_out
            if not keep_dim:
                squeeze_name = graph.meta["extra_info"].get_unique_name_with_suffix(gnode.name, "/squeeze")
                squeeze_node = self._build_squeeze_node(graph, gslice_out, gather_axis, squeeze_name)
                graph.insert_after(gslice_node, squeeze_node)
                replace_v = squeeze_node.outputs[0]

            self.mark_value_as_copy(graph, g_out, replace_v)
            safe_replace_all_uses_with(graph, g_out, replace_v)
            graph.remove(gnode, safe=True)

        logger.debug("applied pass %s on '%s'", self.get_curr_pass_name(), node.name)
        return True


class M2sReplaceGatherGroupslice2GroupsliceGroupslice(M2sBasePass):
    """
    Transform subgraph:
        Subgraph(in_a) --> b,b0,b1,b2
        {
            b = Gather(in_a)
            b0,b1,b2... = GroupSlice(b)
        }
    Into:
        Subgraph(in_a) --> c,b0,b1,b2
        {
            c = GroupSlice(in_a)
            b0,b1,b2... = GroupSlice(c)
        }

    Only supports Gather with constant, 1-D, contiguous indices (equivalent to Slice).
    Also, encodings are updated.
    """

    @dataclass
    class MatchInfo(MatchInfoProtocol):
        """Match information for M2sReplaceGatherGroupslice2GroupsliceGroupslice pass"""

        op_node: ir.Node
        """The Gather node"""

        gather_axis: int
        """Gather axis"""

        start: int
        """Start index"""

        end: int
        """End index"""

    def match(self, graph: ir.Graph, node: ir.Node) -> bool | MatchInfo:
        gslice_node = node
        if not is_reorderable_group_slice(gslice_node):
            return False
        assert gslice_node.inputs[0] is not None
        op_node = gslice_node.inputs[0].producer()
        if op_node is None:
            return False
        if op_node.op_type != "Gather":
            return False
        if len(op_node.inputs) < 2 or op_node.inputs[0] is None or op_node.inputs[1] is None:
            return False

        check_static_shape_of_node_io(op_node)

        input_value = op_node.inputs[0]
        assert input_value is not None
        input_shape = input_value.shape
        if input_shape is None:
            return False
        gather_axis = get_attribute_with_default(op_node, "axis", 0)
        if gather_axis < 0:
            gather_axis += input_shape.rank()

        if not is_constant(op_node.inputs[1]):
            return False
        indices_np = get_constant_np(op_node.inputs[1])
        if indices_np.ndim != 1 or indices_np.size == 0:
            return False
        indices_list = indices_np.astype(int).tolist()
        if any(idx < 0 for idx in indices_list):
            return False
        if indices_list != list(range(indices_list[0], indices_list[0] + len(indices_list))):
            return False

        start = indices_list[0]
        end = indices_list[-1] + 1

        splittable_axis_match = False
        for param in op_node.inputs[0].meta["extra_info"].splittable:
            if gather_axis == param.axis and start >= param.start and end <= param.end:
                splittable_axis_match = True
                break
        if not splittable_axis_match:
            return False

        return M2sReplaceGatherGroupslice2GroupsliceGroupslice.MatchInfo(
            op_node=op_node, gather_axis=gather_axis, start=start, end=end
        )

    def rewrite(self, graph: ir.Graph, node: ir.Node, match_info: MatchInfoProtocol | None = None) -> bool:
        assert isinstance(match_info, M2sReplaceGatherGroupslice2GroupsliceGroupslice.MatchInfo)
        op_node = match_info.op_node

        assert op_node.inputs[0] is not None
        gslice_node = self._create_groupslice_node(
            graph,
            op_node.inputs[0],
            GroupSliceAttrs(
                axis=match_info.gather_axis,
                starts=[match_info.start],
                ends=[match_info.end],
                head_slice_ids=[-1],
                batch_slice_ids=[-1],
            ),
            node_namehint=(op_node.name if op_node.name is not None else "") + "/as_gslice",
        )
        graph.insert_before(op_node, gslice_node)

        self.mark_value_as_copy(graph, op_node.outputs[0], gslice_node.outputs[0])
        safe_replace_all_uses_with(graph, op_node.outputs[0], gslice_node.outputs[0])

        logger.debug("applied pass %s on '%s'", self.get_curr_pass_name(), op_node.name)
        return True
