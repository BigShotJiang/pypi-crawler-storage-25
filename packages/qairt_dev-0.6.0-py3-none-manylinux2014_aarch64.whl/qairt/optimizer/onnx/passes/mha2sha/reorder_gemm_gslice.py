# ==============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
This module provides the pass for reordering
(Gemm->GroupSlice) -> (GroupSlice->Gemm)
"""

import copy
from dataclasses import dataclass

import onnx_ir as ir

from qairt.optimizer.onnx.passes.base import MatchInfoProtocol
from qairt.optimizer.onnx.passes.mha2sha.base_rewriter import M2sBasePass
from qairt.optimizer.onnx.passes.mha2sha.utils import (
    BaseGroupSliceAttrs,
    FullGroupSliceAttrs,
    GroupSliceAttrs,
    get_gslice_attrs,
    is_reorderable_group_slice,
)
from qairt.optimizer.onnx.utils.utils import get_value_numeric_shape, have_static_shape_on_node_io
from qairt.optimizer.utils.logger import logger


def _get_gemm_c_gslice_attrs(
    in_c: ir.Value,
    gslice_attrs: GroupSliceAttrs,
    output_axis: int,
) -> GroupSliceAttrs | FullGroupSliceAttrs:
    """
    Determine the GroupSlice attrs for Gemm's optional bias input C.

    Gemm output Y has shape [M, N].  C is unidirectionally broadcastable to [M, N],
    so its possible shapes are (from lowest to highest rank):
        scalar []
        [N]
        [1, N]  or  [M, 1]  or  [M, N]

    When slicing output on axis=1 (N dim):
        - scalar / [M, 1]: C does not vary along N -> FullGroupSliceAttrs (no-op)
        - [N]            : slice C on axis 0
        - [1, N] / [M, N]: slice C on axis 1

    When slicing output on axis=0 (M dim):
        - scalar / [N] / [1, N]: C does not vary along M -> FullGroupSliceAttrs (no-op)
        - [M, 1] / [M, N]      : slice C on axis 0

    Args:
        in_c:        the C input value of the Gemm node
        gslice_attrs: GroupSliceAttrs of the downstream GroupSlice (carries starts/ends/ids)
        output_axis: the axis being sliced on the Gemm output (0 = M, 1 = N)

    Returns:
        GroupSliceAttrs or FullGroupSliceAttrs for C
    """
    c_shape = get_value_numeric_shape(in_c)
    c_rank = len(c_shape)

    full = FullGroupSliceAttrs(
        gslice_attrs.num_outputs(),
        head_slice_ids=gslice_attrs.head_slice_ids,
        batch_slice_ids=gslice_attrs.batch_slice_ids,
    )

    if c_rank == 0:
        # scalar: broadcast to any shape, no slicing needed
        return full

    if output_axis == 1:
        # Slicing the N dimension of the output
        # C's last dim corresponds to N (or is 1 if broadcast along N)
        c_last_dim = c_shape[-1]
        if c_last_dim == 1:
            # broadcast along N, no slicing needed
            return full
        # C varies along N: slice on C's last axis
        c_gslice_attrs = copy.deepcopy(gslice_attrs)
        c_gslice_attrs.axis = c_rank - 1
        return c_gslice_attrs

    else:
        # output_axis == 0: slicing the M dimension of the output
        if c_rank == 1:
            # shape [N]: no M dimension, broadcast along M
            return full
        # c_rank == 2: shape [M_or_1, N_or_1]
        c_first_dim = c_shape[0]
        if c_first_dim == 1:
            # broadcast along M, no slicing needed
            return full
        # C varies along M: slice on C's axis 0
        c_gslice_attrs = copy.deepcopy(gslice_attrs)
        c_gslice_attrs.axis = 0
        return c_gslice_attrs


class M2sReorderGemmGroupslice(M2sBasePass):
    """
    Transform subgraph:
        Subgraph(in_a, in_b[, in_c]) --> y, y0, y1, y2, ...
        {
            y = Gemm(in_a, in_b[, in_c])
            # Y = alpha * A' * B' + beta * C,  output shape [M, N]
            # A' = A if transA=0 else A^T
            # B' = B if transB=0 else B^T
            # C is unidirectionally broadcastable to [M, N]
            y0, y1, y2, ... = GroupSlice(y)
        }
    to (one of two cases depending on the GroupSlice axis):

        # --- Case 1: axis == 1 (N dim) — slice weight B, A is untouched ---
        Subgraph(in_a, in_b[, in_c]) --> y, y0, y1, y2, ...
        {
            # in_a is passed through as-is (full-range GroupSlice, effectively a no-op)
            # in_b is sliced along its N-axis: axis 1 if transB=0, axis 0 if transB=1
            b0, b1, ... = GroupSlice(in_b)
            [c0, c1, ... = GroupSlice(in_c)] # slice along N if C varies on that dim

            y0 = Gemm(in_a, b0[, c0])
            y1 = Gemm(in_a, b1[, c1])
            ...
        }

        # --- Case 2: axis == 0 (M dim) — slice activation A, B is untouched ---
        Subgraph(in_a, in_b[, in_c]) --> y, y0, y1, y2, ...
        {
            # in_a is sliced along its M-axis: axis rank-2 if transA=0, axis rank-1 if transA=1
            a0, a1, ... = GroupSlice(in_a)
            # in_b is passed through as-is (full-range GroupSlice, effectively a no-op)
            [c0, c1, ... = GroupSlice(in_c)] # slice along M if C varies on that dim

            y0 = Gemm(a0, in_b[, c0])
            y1 = Gemm(a1, in_b[, c1])
            ...
        }

    Also, encodings are updated
    """

    @dataclass
    class MatchInfo(MatchInfoProtocol):
        """Match information for M2sReorderGemmGroupslice pass"""

        gemm_node: ir.Node
        gslice_attrs: GroupSliceAttrs

    def match(self, graph: ir.Graph, node: ir.Node) -> bool | MatchInfo:
        if not is_reorderable_group_slice(node):
            return False

        assert node.inputs[0] is not None  # check for mypy, definitely true
        gemm_node = node.inputs[0].producer()
        assert gemm_node is not None  # check for mypy, definitely true
        if gemm_node.op_type != "Gemm":
            return False

        if not have_static_shape_on_node_io(gemm_node):
            return False

        gslice_attrs = get_gslice_attrs(node)
        return M2sReorderGemmGroupslice.MatchInfo(gemm_node=gemm_node, gslice_attrs=gslice_attrs)

    def rewrite(self, graph: ir.Graph, node: ir.Node, match_info: MatchInfoProtocol | None = None) -> bool:
        assert isinstance(match_info, M2sReorderGemmGroupslice.MatchInfo)  # For mypy
        gslice_node = node
        gemm_node = match_info.gemm_node
        gslice_attrs = match_info.gslice_attrs

        in_a = gemm_node.inputs[0]
        in_b = gemm_node.inputs[1]
        in_c = gemm_node.inputs[2] if len(gemm_node.inputs) >= 3 and gemm_node.inputs[2] is not None else None

        trans_a_attr = gemm_node.attributes.get("transA")
        trans_a = trans_a_attr.as_int() if trans_a_attr is not None else 0
        trans_b_attr = gemm_node.attributes.get("transB")
        trans_b = trans_b_attr.as_int() if trans_b_attr is not None else 0

        a_gslice_attrs: BaseGroupSliceAttrs
        b_gslice_attrs: BaseGroupSliceAttrs

        if gslice_attrs.axis == 1:
            # Slicing on N dim (output columns) -> slice weight B along its N-axis
            # A is not sliced: use a full-range GroupSlice
            a_gslice_attrs = FullGroupSliceAttrs(
                gslice_attrs.num_outputs(),
                head_slice_ids=gslice_attrs.head_slice_ids,
                batch_slice_ids=gslice_attrs.batch_slice_ids,
            )

            # B's N-axis depends on transB:
            #   transB=0 (default): B shape [K, N], N is axis 1
            #   transB=1:           B shape [N, K], N is axis 0
            b_gslice_attrs_copy = copy.deepcopy(gslice_attrs)
            b_gslice_attrs_copy.axis = 0 if trans_b == 1 else 1
            b_gslice_attrs = b_gslice_attrs_copy

            inputs_gslice_attrs: list[BaseGroupSliceAttrs] = [a_gslice_attrs, b_gslice_attrs]

            if in_c is not None:
                inputs_gslice_attrs.append(_get_gemm_c_gslice_attrs(in_c, gslice_attrs, output_axis=1))

        else:
            # gslice_attrs.axis == 0: slicing on M dim (output rows) -> slice activation A
            # A's M-axis depends on transA:
            #   transA=0 (default): A shape [M, K], M is axis 0  (rank-2 for 2D input)
            #   transA=1:           A shape [K, M], M is axis 1  (rank-1 for 2D input)
            a_rank = len(get_value_numeric_shape(in_a))
            a_gslice_attrs_copy = copy.deepcopy(gslice_attrs)
            a_gslice_attrs_copy.axis = a_rank - 1 if trans_a == 1 else a_rank - 2
            a_gslice_attrs = a_gslice_attrs_copy

            # B is not sliced: use a full-range GroupSlice
            b_gslice_attrs = FullGroupSliceAttrs(
                gslice_attrs.num_outputs(),
                head_slice_ids=gslice_attrs.head_slice_ids,
                batch_slice_ids=gslice_attrs.batch_slice_ids,
            )

            inputs_gslice_attrs = [a_gslice_attrs, b_gslice_attrs]

            if in_c is not None:
                inputs_gslice_attrs.append(_get_gemm_c_gslice_attrs(in_c, gslice_attrs, output_axis=0))

        _ = self.rewrite_based_on_gslice_attrs(
            graph, gemm_node, [gslice_node], inputs_gslice_attrs=inputs_gslice_attrs
        )

        logger.debug("applied pass %s on '%s'", self.get_curr_pass_name(), gemm_node.name)
        return True
