# ==============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
This module provides the pass for reordering
(MaxPool->GroupSlice) -> (GroupSlice->MaxPool)
"""

import onnx_ir as ir

from qairt.optimizer.onnx.passes.base import MatchInfoProtocol
from qairt.optimizer.onnx.passes.mha2sha.base_rewriter import M2sBasePass
from qairt.optimizer.onnx.passes.mha2sha.utils import get_gslice_attrs, is_reorderable_group_slice
from qairt.optimizer.onnx.utils.utils import (
    get_attribute_with_default,
    have_static_shape_on_node_io,
)
from qairt.optimizer.utils.logger import logger


class M2sReorderMaxPoolGroupslice(M2sBasePass):
    """
    Transform subgraph:
        Subgraph(in_a) --> c, c0,c1,c2...
        {
            c = MaxPool(in_a)
            c0,c1,c2... = GroupSlice(c)
        }
    Into:
        Subgraph(in_a) --> c, c0,c1,c2...
        {
            a0,a1,a2,... = GroupSlice(in_a)

            c0 = MaxPool(a0)
            c1 = MaxPool(a1)
            c2 = MaxPool(a2)

            # if possible
            c = concat(c0,c1,c2,...)
            # or c = MaxPool(in_a)
        }

    This pass is intentionally conservative:
    - only single-output MaxPool is supported
    - storage_order must be 0
    - group slicing axis must not be one of MaxPool spatial axes
    """

    def match(self, graph: ir.Graph, node: ir.Node) -> bool:
        gslice_node = node
        if not is_reorderable_group_slice(gslice_node):
            return False

        assert gslice_node.inputs[0] is not None  # check for mypy, definitely true
        op_node = gslice_node.inputs[0].producer()
        assert op_node is not None  # check for mypy, definitely true
        if op_node.op_type != "MaxPool":
            return False

        if len(op_node.inputs) != 1 or op_node.inputs[0] is None:
            return False
        if len(op_node.outputs) != 1:
            return False

        if not have_static_shape_on_node_io(op_node):
            return False

        storage_order = get_attribute_with_default(op_node, "storage_order", 0)
        if storage_order != 0:
            return False

        kernel_shape = list(get_attribute_with_default(op_node, "kernel_shape", []))
        if len(kernel_shape) == 0:
            return False

        assert op_node.outputs[0].shape is not None  # guaranteed by have_static_shape_on_node_io
        out_rank = op_node.outputs[0].shape.rank()
        gslice_attrs = get_gslice_attrs(gslice_node)

        spatial_rank = len(kernel_shape)
        spatial_axes = list(range(out_rank - spatial_rank, out_rank))

        if gslice_attrs.axis in spatial_axes:
            return False

        return True

    def rewrite(self, graph: ir.Graph, node: ir.Node, match_info: MatchInfoProtocol | None = None) -> bool:
        gslice_node = node
        assert gslice_node.inputs[0] is not None
        op_node = gslice_node.inputs[0].producer()
        assert op_node is not None

        in_a_gslice_attrs = get_gslice_attrs(gslice_node)

        _ = self.rewrite_based_on_gslice_attrs(
            graph, op_node, [gslice_node], inputs_gslice_attrs=[in_a_gslice_attrs]
        )

        logger.debug("applied pass %s on '%s'", self.get_curr_pass_name(), op_node.name)
        return True
