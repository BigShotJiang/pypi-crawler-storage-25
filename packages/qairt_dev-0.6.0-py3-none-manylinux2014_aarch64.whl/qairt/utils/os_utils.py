# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================


def is_arm_64(arch_name: str, processor_name: str = "") -> bool:
    names = ["aarch64", "arm64", "armv8"]
    combined = (processor_name + " " + arch_name).lower()
    return any(name in combined for name in names)


def is_x86_64(arch_name):
    return any(name in arch_name.lower() for name in ["x86_64", "amd64", "intel64"])


def is_windows(platform_name):
    return platform_name.lower() == "windows"


def is_linux(platform_name):
    return platform_name.lower() == "linux"
