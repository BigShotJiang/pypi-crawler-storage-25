# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
GenAI Builder Stage

Builds an ``LLMContainer`` from ONNX/model artifacts using ``GenAIBuilderFactory``.
The stage can also run generation by creating a ``T2TExecutor`` from the container.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional, cast

from pydantic import model_validator

from qairt.api.configs.common import BackendType
from qairt.api.configs.device import Device, SocDetails
from qairt.api.converter.converter_config import CalibrationConfig, ConverterConfig
from qairt.experimental.pipeline.torch.common.bases.stage import (
    Stage,
    StageConfig,
    StageDependencies,
    StageInput,
    StageOutput,
)
from qairt.experimental.pipeline.torch.common.bases.stage_registry import BuiltInStage, register_stage
from qairt.gen_ai_api.builders.gen_ai_builder_htp import GenAIBuilderHTP
from qairt.gen_ai_api.chat.chat_templates import CustomChatTemplate, HFChatTemplate
from qairt.gen_ai_api.configs.eaglet_config import EagletBuilderConfig
from qairt.gen_ai_api.configs.lade_config import LadeBuilderConfig
from qairt.gen_ai_api.configs.ssd_config import SsdBuilderConfig
from qairt.gen_ai_api.containers.llm_container import LLMContainer
from qairt.gen_ai_api.executors.gen_ai_executable import TextGenerationResult
from qairt.gen_ai_api.gen_ai_builder_factory import GenAIBuilderFactory


class GenAIBuilderInput(StageInput):
    """Upstream model artifact paths provided by the immediate previous stage."""

    model_path: str
    tokenizer_path: Optional[str] = None
    config_path: Optional[str] = None


class GenAIBuilderConfig(StageConfig):
    """Stage config for container build: backend/targets and advanced builder options."""

    model_config = {"extra": "allow", "protected_namespaces": (), "arbitrary_types_allowed": True}

    stage_name: str = "genai_builder"

    # Advanced builder options
    weight_sharing: Optional[bool] = None
    multi_graph: Optional[bool] = None
    native_kv: Optional[bool] = None
    encodings_path: Optional[str] = None
    transform_options: Optional[dict[str, Any]] = None
    conversion_options: Optional[dict[str, Any]] = None
    calibration_options: Optional[dict[str, Any]] = None
    compile_options: Optional[dict[str, Any]] = None

    # Chat template options
    model_id: Optional[str] = None
    chat_template: Optional[str] = None

    # Speculative decoding builder config
    speculative_config: Optional[LadeBuilderConfig | EagletBuilderConfig | SsdBuilderConfig] = None

    @model_validator(mode="after")
    def _validate_template_sources(self) -> "GenAIBuilderConfig":
        if self.model_id and self.chat_template:
            raise ValueError("Only one of model_id or chat_template may be provided.")
        return self


class GenAIBuilderOutput(StageOutput):
    """Build output containing the LLM container and resolved backend."""

    container: LLMContainer
    backend: BackendType


@register_stage(BuiltInStage.GENAI_BUILDER.value, built_in=True)
class GenAIBuilderStage(Stage[GenAIBuilderInput, GenAIBuilderConfig, GenAIBuilderOutput]):
    """Builds an LLMContainer via GenAIBuilderFactory and can run generation through its executor."""

    Input = GenAIBuilderInput
    Config = GenAIBuilderConfig
    Output = GenAIBuilderOutput

    can_export = True
    can_generate = True

    def _execute(self, input: GenAIBuilderInput, config: GenAIBuilderConfig) -> GenAIBuilderOutput:
        """Build the container from resolved paths/config."""
        model_path = input.model_path
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"GenAIBuilderStage expects a local model path; got: {model_path}")
        tokenizer_path = input.tokenizer_path
        config_path = input.config_path
        pipeline_config = getattr(config, "_pipeline_config", None)
        if pipeline_config is None:
            raise ValueError(
                "GenAIBuilderStage requires pipeline context (_pipeline_config). "
                "Make sure the pipeline is initialized."
            )
        backend_value = getattr(pipeline_config, "backend", None)
        cache_dir_value = getattr(pipeline_config, "cache_dir", None)
        if backend_value is None or cache_dir_value is None:
            raise ValueError("GenAIBuilderStage requires pipeline backend and cache_dir in _pipeline_config.")
        soc_details = getattr(pipeline_config, "soc_details", None)
        builder_cache_dir = str(Path(cache_dir_value) / "genaibuilder")

        backend = BackendType(str(backend_value).upper())
        if backend != BackendType.HTP:
            raise ValueError("GenAIBuilderStage currently supports only HTP backend in pipeline mode.")

        builder = GenAIBuilderFactory.create(
            pretrained_model_path=model_path,
            backend_type=backend,
            cache_root=builder_cache_dir,
            tokenizer_path=tokenizer_path,
            config_path=config_path,
        )

        chat_template_obj = None
        if config.model_id:
            chat_template_obj = HFChatTemplate.from_pretrained(config.model_id)
        elif config.chat_template:
            model_path_obj = Path(model_path)
            model_tokenizer_dir = str(model_path_obj.parent if model_path_obj.is_file() else model_path_obj)
            chat_template_obj = CustomChatTemplate.from_template_string(
                config.chat_template, model_tokenizer_dir
            )

        htp_builder = cast(GenAIBuilderHTP, builder)
        if config.weight_sharing is not None:
            htp_builder.weight_sharing = config.weight_sharing
        if config.multi_graph is not None:
            htp_builder.multi_graph = config.multi_graph
        if config.native_kv is not None:
            htp_builder.native_kv = config.native_kv
        if config.encodings_path:
            htp_builder.encodings_path = config.encodings_path

        if chat_template_obj is not None:
            htp_builder.chat_template = chat_template_obj

        if config.speculative_config is not None:
            htp_builder.speculative_config = config.speculative_config

        if config.transform_options:
            htp_builder.set_transformation_options(options=config.transform_options)

        if config.conversion_options is not None or config.calibration_options is not None:
            conv_cfg = ConverterConfig(**(config.conversion_options or {}))
            calib_cfg = (
                CalibrationConfig(**config.calibration_options)
                if config.calibration_options is not None
                else None
            )
            htp_builder.set_conversion_options(conv_cfg, calib_cfg)

        if soc_details:
            htp_builder.set_targets([soc_details])

        if config.compile_options:
            htp_builder.set_compilation_options(options=config.compile_options)

        try:
            container = builder.build()
        except Exception as e:
            raise RuntimeError(
                f"[GenAIBuilderStage] Failed to build container ({type(e).__name__}): {e}"
            ) from e

        return GenAIBuilderOutput(
            container=container,
            backend=backend,
        )

    @classmethod
    def export(cls, stage_output: GenAIBuilderOutput, output_path: Path, **kwargs: Any) -> None:
        """Export the built container artifacts to ``output_path``."""
        stage_output.container.export(str(output_path), **kwargs)

    @classmethod
    def load_from_cache(cls, cache_path: Path) -> GenAIBuilderOutput:
        """Restore a previously exported container from ``cache_path``."""
        container = LLMContainer.load(cache_path)
        return GenAIBuilderOutput(container=container, backend=container._backend)

    def generate(
        self,
        stage_output: GenAIBuilderOutput,
        prompt: str,
        **kwargs: Any,
    ) -> TextGenerationResult:
        """Create a GenAI executor from the container and run text generation.

        Supported ``kwargs``:
            device (Device | None): Target device for execution.
            clean_up (bool): Clean temporary runtime artifacts after execution. Default ``True``.
            prepare_environment (bool): Prepare runtime environment before execution. Default ``True``.
            qairt_sdk_root (str | None): Optional QAIRT SDK root override.
            lora_config (Any): Optional LoRA runtime config forwarded to executor.generate().
        """
        device: Optional[Device] = kwargs.pop("device", None)
        clean_up: bool = kwargs.pop("clean_up", True)
        prepare_environment: bool = kwargs.pop("prepare_environment", True)
        qairt_sdk_root: Optional[str] = kwargs.pop("qairt_sdk_root", None)
        lora_config = kwargs.pop("lora_config", None)

        if kwargs:
            unsupported = ", ".join(sorted(kwargs.keys()))
            raise ValueError(f"Unsupported generate kwargs for genai_builder: {unsupported}")

        with stage_output.container.get_executor(
            device=device,
            clean_up=clean_up,
            prepare_environment=prepare_environment,
            qairt_sdk_root=qairt_sdk_root,
        ) as executor:
            return executor.generate(prompt, lora_config=lora_config)

    @classmethod
    def get_stage_dependency(cls) -> StageDependencies:
        return StageDependencies(requires=[BuiltInStage.QUANTIZATION.value])
