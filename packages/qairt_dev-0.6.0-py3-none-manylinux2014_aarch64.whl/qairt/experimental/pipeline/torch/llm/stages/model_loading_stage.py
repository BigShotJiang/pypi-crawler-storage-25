# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
Model Loading Stage

This stage handles loading and re-authoring models using QcAutoModelForCausalLM.
"""

from __future__ import annotations

import json
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional, cast

import torch
from pydantic import Field
from transformers import AutoTokenizer, PretrainedConfig

from qairt.experimental.pipeline.torch.common.bases.stage_registry import register_stage

from ...common.bases.stage import (
    ExecutionEnvironment,
    Stage,
    StageConfig,
    StageInput,
    StageOutput,
)


class ExportFormat(str, Enum):
    """Supported export formats for :meth:`ModelLoadingStage.export`."""

    ONNX = "onnx"
    HF = "hf"


class ModelLoadingConfig(StageConfig):
    """Configuration for model loading stage.

    Attributes:
        model_id_or_path: HuggingFace model ID or local path to the model.
        backend: Target backend for adaptations.
        hf_config: Optional HuggingFace config to pass to QcAutoModelForCausalLM.
        model_config_overrides: Optional overrides for model config (HF config + QC config)
            after loading.
        hf_pretrained_kwargs: kwargs forwarded to QcAutoModelForCausalLM.from_pretrained
            (e.g. trust_remote_code, revision, etc.).
        model_reauthoring: Whether to re-author the model via QcAutoModelForCausalLM.
        qc_config: Populated by _pre_hook when model_reauthoring=True.
        load_tokenizer: Whether to load the tokenizer (can be skipped if not needed).
        hf_tokenizer_kwargs: kwargs forwarded to AutoTokenizer.from_pretrained
            (e.g. trust_remote_code, revision, etc.).
        apply_default_adaptations: Whether to apply default backend adaptations.
    """

    model_config = {"extra": "allow", "protected_namespaces": (), "arbitrary_types_allowed": True}

    model_id_or_path: str
    backend: str = "HTP"

    # Model loading options
    hf_config: PretrainedConfig | None = None
    model_config_overrides: Dict[str, Any] = Field(default_factory=dict)
    hf_pretrained_kwargs: Dict[str, Any] = Field(default_factory=dict)

    # Re-authoring options
    model_reauthoring: bool = True
    qc_config: Optional[Any] = None

    # Tokenizer options
    load_tokenizer: bool = True
    hf_tokenizer_kwargs: Dict[str, Any] = Field(default_factory=dict)

    # Adaptation options
    apply_default_adaptations: bool = True


class ModelLoadingOutput(StageOutput):
    """Output from model loading stage."""

    model: torch.nn.Module
    tokenizer: Any | None = None
    config: Optional[Any] = None
    is_reauthored: bool = False


@register_stage("model_loading")
class ModelLoadingStage(Stage):
    """Stage for loading and re-authoring models using QcAutoModelForCausalLM."""

    name = "model_loading"
    Config = ModelLoadingConfig
    Output = ModelLoadingOutput

    can_export = True
    can_generate = True
    can_start = True

    def _pre_hook(
        self, input: StageInput, config: ModelLoadingConfig
    ) -> tuple[StageInput, ModelLoadingConfig]:
        """Build QcAutoConfig before model loading (reauthoring path only)."""
        if config.model_reauthoring:
            from qairt.experimental.pipeline.torch.llm.loader.auto_classes import QcAutoConfig

            if config.hf_config is not None:
                base_config = config.hf_config
                for key, value in config.model_config_overrides.items():
                    setattr(base_config, key, value)
                qc_config = QcAutoConfig.from_config(base_config)
            else:
                qc_config = QcAutoConfig.from_pretrained(
                    config.model_id_or_path,
                    model_config_overrides=config.model_config_overrides or None,
                )
            config = config.model_copy(update={"qc_config": qc_config})
        return input, config

    def _execute(self, input: StageInput, config: ModelLoadingConfig) -> ModelLoadingOutput:
        """Load pretrained model from HuggingFace or local path."""
        # input is intentionally unused — model loading has no upstream dependencies

        model = None
        model_config = None
        tokenizer = None

        try:
            from qairt.experimental.pipeline.torch.llm.loader.auto_classes import QcAutoModelForCausalLM

            if config.model_reauthoring:
                # qc_config was built in _pre_hook
                model = QcAutoModelForCausalLM.from_pretrained(
                    config.model_id_or_path,
                    model_reauthoring=True,
                    qc_config=config.qc_config,
                    **config.hf_pretrained_kwargs,
                )
            else:
                # Vanilla model — no re-authoring, no qc_config.
                model = QcAutoModelForCausalLM.from_pretrained(
                    config.model_id_or_path,
                    model_reauthoring=False,
                    **config.hf_pretrained_kwargs,
                )

            # Load tokenizer separately
            if config.load_tokenizer:
                tokenizer = AutoTokenizer.from_pretrained(
                    config.model_id_or_path, **config.hf_tokenizer_kwargs
                )

            model_config = getattr(model, "config", None)

        except Exception as e:
            raise RuntimeError(f"[ModelLoadingStage] Failed to load model: {e}")

        # Apply HTP adaptations (e.g. Linear → ConvInplaceLinear)
        if config.apply_default_adaptations:
            from qairt.experimental.pipeline.torch.common.adaptations.adapter import Adapter

            Adapter.apply_adaptations(model, backend=config.backend, model_type="LLM")

        if config.execution_environment == ExecutionEnvironment.GPU:
            model = model.cuda()
        elif config.execution_environment == ExecutionEnvironment.LOCAL:
            model = model.cpu()

        return ModelLoadingOutput(
            model=model, tokenizer=tokenizer, config=model_config, is_reauthored=config.model_reauthoring
        )

    def _post_hook(
        self, input: StageInput, config: ModelLoadingConfig, output: ModelLoadingOutput
    ) -> ModelLoadingOutput:
        """Apply vanilla model_config_overrides after loading."""
        # model_config_overrides are only applied post-hoc for vanilla (non-reauthored) models.
        # When reauthoring is enabled, overrides were applied to base_config in _pre_hook before
        # qc_config was built, so no post-hoc setattr is needed here.
        if not config.model_reauthoring and config.model_config_overrides:
            if output.config is None:
                raise ValueError(
                    "[ModelLoadingStage] Cannot apply model_config_overrides: model.config is None"
                )
            for key, value in config.model_config_overrides.items():
                setattr(output.config, key, value)

        return output

    @classmethod
    def export(
        cls,
        stage_output: ModelLoadingOutput,
        output_path: Path,
        format: ExportFormat = ExportFormat.HF,
        **kwargs,
    ) -> None:
        """Export the loaded model in the requested format.

        Args:
            stage_output: Output from this stage containing the loaded model.
            output_path:  Destination path.  For ``HF``, treated as a directory;
                          for ``ONNX``, treated as a file path.
            format:       One of :class:`ExportFormat` — ``HF`` (default, used for
                          pipeline cache round-trips) or ``ONNX``.
            **kwargs:     Forwarded to the underlying export function.
        """
        if format == ExportFormat.HF:
            stage_output.model.save_pretrained(output_path)
            if stage_output.tokenizer is not None:
                stage_output.tokenizer.save_pretrained(output_path)
            meta = {"is_reauthored": stage_output.is_reauthored}
            with open(output_path / "stage_meta.json", "w") as f:
                json.dump(meta, f)
            return

        from transformers import PreTrainedModel

        from qairt.experimental.pipeline.torch.llm.exporter.export import export_to_onnx

        export_to_onnx(cast(PreTrainedModel, stage_output.model), output_path, **kwargs)

    @classmethod
    def load_from_cache(cls, cache_path: Path) -> ModelLoadingOutput:
        """Restore a previously exported model from ``cache_path`` (HF format)."""
        from qairt.experimental.pipeline.torch.llm.loader.auto_classes import QcAutoModelForCausalLM

        meta_path = cache_path / "stage_meta.json"
        is_reauthored = False
        if meta_path.exists():
            with open(meta_path) as f:
                is_reauthored = json.load(f).get("is_reauthored", False)

        model = QcAutoModelForCausalLM.from_pretrained(str(cache_path), model_reauthoring=False)
        tokenizer = None
        if (cache_path / "tokenizer_config.json").exists():
            tokenizer = AutoTokenizer.from_pretrained(str(cache_path))
        model_config = getattr(model, "config", None)
        return ModelLoadingOutput(
            model=model,
            tokenizer=tokenizer,
            config=model_config,
            is_reauthored=is_reauthored,
        )

    def generate(self, stage_output: ModelLoadingOutput, prompt: str, **generation_kwargs) -> Any:
        """
        Optional generation method using the loaded model. Uses fixed arguments. Use model.generate() for
        more flexible generation with dynamic arguments.

        Args:
            stage_output: Output from the model loading stage.
            prompt: Input text to generate from.
            **generation_kwargs: Additional keyword arguments forwarded to the underlying generator.
        """
        if not prompt:
            raise ValueError("input text must be provided")
        if self.can_generate and stage_output.model is not None:
            model = stage_output.model

            if stage_output.tokenizer is None:
                raise ValueError(
                    "[ModelLoadingStage] Tokenizer was not loaded. Ensure a valid tokenizer configuration."
                )
            tokenizer = stage_output.tokenizer

            inputs = tokenizer(prompt, return_tensors="pt")
            inputs = inputs.to(model.device)

            if stage_output.is_reauthored:
                from qairt.experimental.pipeline.torch.llm.generation.generator import LLMGenerator

                sequence_length = generation_kwargs.pop("sequence_length")
                context_length = generation_kwargs.pop("context_length")

                llm_generator = LLMGenerator(
                    model=model,
                    tokenizer=tokenizer,
                    sequence_length=sequence_length,
                    context_length=context_length,
                    **generation_kwargs,
                )
                outputs = llm_generator.generate(input_ids=inputs.input_ids, **generation_kwargs)
                new_tokens = outputs[:, inputs.input_ids.shape[-1] :]
                result = tokenizer.batch_decode(new_tokens, skip_special_tokens=True)[0]
                return result
            else:
                outputs = model.generate(
                    inputs.input_ids, attention_mask=inputs.attention_mask, **generation_kwargs
                )
                new_tokens = outputs[0][inputs.input_ids.shape[-1] :]
                generated_text = tokenizer.decode(new_tokens, skip_special_tokens=True)
                return generated_text
        else:
            raise NotImplementedError(
                "Generation could not be performed through the stage. Use model.generate() instead."
            )
