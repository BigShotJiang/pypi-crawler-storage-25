# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
LLM Pipeline

LLM-specific pipeline config and pipeline class.

All generic orchestration (stage resolution, binding injection, validation,
execution loop, export) lives in the ``Pipeline`` base class. This module
adds only what is specific to large language models:

  - ``LLMPipelineConfig``  — LLM-specific global config (model_id, backend, …)
  - ``LLMPipeline``        — adds ``model`` property and ``generate(prompt)``
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional, Tuple, Union, cast

import torch
from pydantic import Field, field_validator
from torch.utils.data.dataloader import DataLoader

from qairt import BackendType
from qairt.api.configs.device import SocDetails, soc_details_from_str
from qairt.experimental.pipeline.torch.common.bases.pipeline import Pipeline, PipelineConfig
from qairt.experimental.pipeline.torch.common.configs import (  # noqa: E402
    EvaluatorConfig,
    ExporterConfig,
    GeneratorConfig,
)
from qairt.experimental.pipeline.torch.common.recipe import Recipe
from qairt.experimental.pipeline.torch.llm import stages  # noqa: F401 - registers all built-in stages
from qairt.utils.loggers import get_logger


@dataclass
class PipelineFeatures:
    """
    Cross-cutting features that can be enabled/disabled for the entire pipeline.
    These features can affect multiple stages. If set:
        - stages will check to ensure feature related configs are provided.
        - stages will enable feature-specific logic during execution.
    """

    speculative_decoding: Tuple[bool, str | None] = (False, None)  # (enabled, method)
    lora: bool = False


class LLMPipelineConfig(PipelineConfig):
    """Global pipeline configuration for LLM pipelines."""

    model_config = {"protected_namespaces": (), "arbitrary_types_allowed": True}

    # Global parameters
    backend: str = "HTP"
    soc_details: Optional[Union[SocDetails, str]] = None

    # Task configuration
    task: str = "text-generation"

    # Features (cross-cutting concerns that affect all stages)
    features: PipelineFeatures = Field(default_factory=PipelineFeatures)

    # Generator configuration (global). A generator config can also be provided at stage level
    # (e.g., quantization) to override global settings if needed
    generator_config: GeneratorConfig | None = Field(default_factory=GeneratorConfig)

    # Evaluator configuration (global). An evaluator config can also be provided at stage level
    # to override global settings if needed
    evaluator_config: EvaluatorConfig | None = None

    # Exporter configuration (global). An exporter config can also be provided at stage level
    # to override global settings if needed
    exporter_config: ExporterConfig | None = None

    # Global log level (can be overridden by stages if needed)
    log_level: Optional[str] = None

    # store resolved soc details if provided, for use in stages that need it (e.g., builder)
    _soc_details_resolved: Optional[SocDetails] = None

    # store original recipe if created from recipe, for reference and potential export
    _recipe: Union[dict[str, Any], None] = None

    # Additional fields can be added as needed, and will be available in stage configs
    extra_info: dict[str, Any] = Field(default_factory=dict)

    def model_post_init(self, __context):
        if self.soc_details:
            self._set_soc_details()
        if self.log_level is None:
            self._set_log_level()

    @field_validator("model_id_or_path")
    @classmethod
    def validate_model_id(cls, v):
        if not v:
            raise ValueError("model_id_or_path cannot be empty")
        return v

    def _set_soc_details(self):
        """Sets soc details and uses it to derive device custom configs."""
        if not self.backend == BackendType.HTP:
            print("Compile time device specifications are only valid for HTP. Ignoring.")
            return self
        if isinstance(self.soc_details, str):
            soc_details = soc_details_from_str(self.soc_details)
        else:
            soc_details = self.soc_details
        self._soc_details_resolved = soc_details

    def _set_log_level(self):
        from qti.aisw.tools.core.utilities.qairt_logging import QAIRTLogger

        self.log_level = QAIRTLogger.get_default_logging_level().lower()

    def add_dataloader(self, stage_name: str, dataloader: DataLoader) -> None:
        """
        Adds a data loader for a specific stage.

        Args:
            stage_name: Name of the stage to associate the dataloader with (e.g.,
                        "quantization" for calibration dataloader)
            dataloader: The DataLoader instance to add
        """
        if stage_name not in self.stage_info:
            self.stage_info[stage_name] = {}
        self.stage_info[stage_name]["dataloader"] = dataloader

    def add_config(self, stage_name: str, config: ExporterConfig | GeneratorConfig | EvaluatorConfig) -> None:
        """
        Adds a config for a specific stage.

        Args:
            stage_name: Name of the stage to associate the config with.
            config: Must be one of ExporterConfig, GeneratorConfig or EvaluatorConfig.
                    Stage-specific configs override global configs for the same stage.
        """
        if stage_name not in self.stage_info:
            raise ValueError(f"Unknown stage name: {stage_name}")
        if isinstance(config, GeneratorConfig):
            self.stage_info[stage_name]["generator_config"] = config
        elif isinstance(config, EvaluatorConfig):
            self.stage_info[stage_name]["evaluator_config"] = config
        elif isinstance(config, ExporterConfig):
            self.stage_info[stage_name]["exporter_config"] = config
        else:
            raise ValueError(
                f"Unsupported config type: {type(config)}. "
                f"Must be one of ExporterConfig, GeneratorConfig or EvaluatorConfig."
            )

    # TODO: Usage of omegaconf
    @classmethod
    def from_recipe(cls, recipe_path: Union[str, Path]) -> LLMPipelineConfig:
        """
        Load pipeline configuration from a YAML recipe file.

        Args:
            recipe_path: Path to YAML recipe file.

        Returns:
            ``LLMPipelineConfig`` instance.
        """
        data = Recipe.from_file(recipe_path)

        if not data.get("model_id_or_path"):
            raise ValueError("Recipe must contain a non-empty 'model_id_or_path' field")

        # Extract keys that require transformation before construction
        features_data = data.get("features", {})
        stages_data = data.get("stages", {})
        evaluator_data = data.get("evaluator_config", None)

        # Build flat kwargs from all remaining recipe fields
        flat_fields = {k: v for k, v in data.items() if k not in ("features", "stages", "evaluator_config")}

        # Construct the pydantic config
        config = cls(**flat_fields)

        # Handle features (requires transformation from raw dict)
        speculative_decoding = (False, None)
        if "speculative_decoding" in features_data:
            sd_data = features_data["speculative_decoding"]
            speculative_decoding = (
                (True, sd_data.get("type", "SSD")) if isinstance(sd_data, dict) else (True, sd_data)
            )
        config.features = PipelineFeatures(
            speculative_decoding=speculative_decoding,
            lora=features_data.get("lora", False),
        )

        # Handle stage_info (ordered mapping)
        config.stage_info = OrderedDict(stages_data)

        # Handle evaluator_config (requires transformation from raw dict)
        if evaluator_data:
            config.evaluator_config = EvaluatorConfig(**evaluator_data)

        return config


class LLMPipeline(Pipeline[LLMPipelineConfig]):
    """Pipeline for PyTorch LLMs."""

    # Override the base class logger so all Pipeline orchestration methods
    # log as "LLMPipeline" when running on an LLMPipeline instance.
    _logger = get_logger("LLMPipeline")

    def __init__(self, config: LLMPipelineConfig) -> None:
        self._config = config
        if config.log_level:
            self._logger.setLevel(config.log_level.upper())
        super().__init__(config)

    @property
    def config(self) -> LLMPipelineConfig:
        return self._config

    @config.setter
    def config(self, new_config: LLMPipelineConfig) -> None:
        self._config = new_config
        self._logger.warning(
            "Pipeline configuration updated. May need to re-run construct() to apply changes."
        )

    @property
    def _stage_info(self) -> OrderedDict[str, dict[str, Any]]:
        return self.config.stage_info

    @classmethod
    def _config_from_recipe(cls, recipe_path: Union[str, Path]) -> LLMPipelineConfig:
        return LLMPipelineConfig.from_recipe(recipe_path)

    @classmethod
    def _config_from_kwargs(cls, model_id_or_path: str, **kwargs: Any) -> LLMPipelineConfig:
        return LLMPipelineConfig(model_id_or_path=model_id_or_path, **kwargs)

    @classmethod
    def from_pretrained(
        cls,
        model_id_or_path: str,
        recipe: Union[str, Path, dict[str, Any], None] = None,
        **kwargs: Any,
    ) -> "LLMPipeline":
        """
        Create a pipeline from a recipe and execute the ``model_loading`` stage.

        Args:
            model_id_or_path: HuggingFace model ID or local path.
            recipe: Recipe file path or dict.
            **kwargs: Forwarded to the base ``from_pretrained`` as config overrides.

        Returns:
            An ``LLMPipeline`` with the ``model_loading`` stage executed. The model
            and tokenizer are available via ``pipeline.model`` and
            ``pipeline.stage_outputs.model_loading``.
        """
        pipeline = cast("LLMPipeline", super().from_pretrained(model_id_or_path, recipe=recipe, **kwargs))

        # The first stage in the recipe must be able to bootstrap the pipeline
        start_stage_name = list(pipeline._stage_classes.keys())[0]
        if not pipeline._stage_classes[start_stage_name].can_start:
            raise ValueError(
                f"The first stage in the recipe ('{start_stage_name}') must have "
                "'can_start = True' (e.g. a model-loading stage)."
            )

        # On resume via load(), a downstream artifact means the start stage's output
        # will be satisfied by manifest restoration — no need to re-run it.
        manifest_stages = pipeline._manifest.read().get("stages", {})
        if any(entry.get("artifact_path") for entry in manifest_stages.values()):
            pipeline._logger.info(
                f"Stage '{start_stage_name}': skipping bootstrap in from_pretrained() — "
                f"resuming from manifest artifacts."
            )
            return pipeline

        stage = pipeline._stage_instances[start_stage_name]
        stage_config = pipeline._stage_configs[start_stage_name]
        stage_input = pipeline._construct_stage_input(start_stage_name)
        pipeline._stage_inputs[start_stage_name] = stage_input

        result = pipeline._runner.run(stage, stage_input, stage_config)
        pipeline._stage_outputs[start_stage_name] = result.output

        try:
            pipeline._manifest.update(start_stage_name, result.artifact_path, stage_config)
        except Exception as e:
            pipeline._logger.warning(
                f"Failed to update manifest for stage '{start_stage_name}': {e}. "
                f"Pipeline will continue, but resume functionality may be affected."
            )

        return pipeline

    @property
    def model(self) -> torch.nn.Module | None:
        """Convenience property: returns the model from the most recent stage that produced one."""
        for stage_name, output in self._stage_outputs.items():
            if hasattr(output, "model") and output.model is not None:
                self._logger.debug(f"Returning model from stage '{stage_name}'.")
                return output.model
        self._logger.debug("No stage produced a model. Returning None.")
        return None

    def generate(self, prompt: str, device: Optional[Any] = None, **kwargs) -> Any:
        """
        Generate text using the last stage in the pipeline.

        The last stage must have ``can_generate = True`` and implement ``generate()``.
        Users should be aware of the generation capabilities of the last stage and
        provide appropriate kwargs (e.g. ``max_length``, ``num_beams``).

        Args:
            prompt: Input prompt for generation.
            device: Optional device specification (forwarded to the stage).
            **kwargs: Additional generation parameters forwarded to the last stage.

        Returns:
            Generation result from the last stage.

        Raises:
            RuntimeError: If ``construct()`` has not been called or the last stage
                          has not been executed.
            NotImplementedError: If the last stage does not support generation.
        """
        if not self._stage_instances:
            raise RuntimeError("No stage instances found. Please run construct() first.")

        last_stage_name = list(self._stage_instances.keys())[-1]
        last_stage = self._stage_instances[last_stage_name]

        last_output = self._stage_outputs.get(last_stage_name)
        if last_output is None:
            raise RuntimeError(
                f"No output found for last stage '{last_stage_name}'. "
                f"Please ensure construct() has been called."
            )

        if not getattr(last_stage, "can_generate", False):
            raise NotImplementedError(
                f"Last stage '{last_stage_name}' does not support generation "
                f"(can_generate={getattr(last_stage, 'can_generate', False)})."
            )

        try:
            return last_stage.generate(last_output, prompt, device=device, **kwargs)
        except Exception as e:
            raise RuntimeError(f"Generation failed in stage '{last_stage_name}': {e}") from e

    def evaluate(self, **kwargs) -> dict[str, float]:
        """Run configured evaluation metrics on the most recent stage output.

        Returns:
            ``{display_name: score}`` e.g. ``{"PPL_wikitext": 8.41}``.

        Raises:
            RuntimeError: If ``construct()`` has not been called.
            ValueError: If no ``evaluator_config`` or metrics are configured.
        """
        if not self._stage_outputs:
            raise RuntimeError("No stage outputs found. Please run construct() first.")

        evaluator_config = self._config.evaluator_config
        if evaluator_config is None or not evaluator_config.metrics:
            raise ValueError("No evaluator_config or metrics configured.")

        # Find model, tokenizer, and model_forward_kwargs from most recent stage output
        model = None
        tokenizer = None
        model_forward_kwargs: dict = {}
        found_forward_kwargs = False
        for stage_name in reversed(list(self._stage_outputs.keys())):
            output = self._stage_outputs[stage_name]
            if model is None and hasattr(output, "model") and output.model is not None:
                model = output.model
            if tokenizer is None and hasattr(output, "tokenizer") and output.tokenizer is not None:
                tokenizer = output.tokenizer
            if not found_forward_kwargs and hasattr(output, "model_forward_kwargs"):
                model_forward_kwargs = output.model_forward_kwargs or {}
                found_forward_kwargs = True
            if model is not None and tokenizer is not None and found_forward_kwargs:
                break

        if model is None:
            raise RuntimeError(
                "No model found in stage outputs for evaluation. "
                "Ensure at least one stage produces a 'model' attribute."
            )

        from qairt.experimental.pipeline.torch.llm.evaluation.evaluator import run_evaluation

        return run_evaluation(
            metrics_config=evaluator_config.metrics,
            model=model,
            tokenizer=tokenizer,
            context_length=evaluator_config.context_length,
            model_forward_kwargs=model_forward_kwargs,
            output_dir=evaluator_config.output_dir,
            **kwargs,
        )
