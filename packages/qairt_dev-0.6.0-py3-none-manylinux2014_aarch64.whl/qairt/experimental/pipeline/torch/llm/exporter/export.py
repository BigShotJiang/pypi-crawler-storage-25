# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""Utils for exporting GenAI models to ONNX or TorchScript"""

from pathlib import Path

import torch
import torch.onnx
from transformers import DynamicCache, PreTrainedModel
from transformers.configuration_utils import PretrainedConfig

from qairt.utils.loggers import get_logger

_logger = get_logger("ExportableModuleWithCache")


class ExportableModuleWithCache(torch.nn.Module):
    """
    Helper class to enable Torch JIT trace and ONNX export of HuggingFace models
    that produce and consume Cache objects.
    """

    def __init__(self, model: PreTrainedModel):
        super().__init__()
        self.model = model

    @property
    def device(self) -> torch.device:
        """Return model device"""
        return self.model.device

    @property
    def dtype(self) -> torch.dtype:
        """Return model dtype"""
        return self.model.dtype

    @property
    def config(self) -> PretrainedConfig:
        """Return model config"""
        return self.model.config

    # pylint: disable=keyword-arg-before-vararg
    def forward(
        self,
        input_ids: torch.Tensor | None = None,
        attention_mask: torch.Tensor | None = None,
        position_ids: torch.Tensor | None = None,
        *past_key_values: torch.Tensor,
    ):
        """Redefine model forward to convert to/from HuggingFace DynamicCache objects"""
        if len(past_key_values) % 2 != 0:
            raise ValueError(
                f"past_key_values must contain an even number of tensors (got {len(past_key_values)})"
            )
        kv_cache = DynamicCache()
        for layer_idx, (k, v) in enumerate(zip(past_key_values[::2], past_key_values[1::2])):
            kv_cache.update(k, v, layer_idx, {})

        lm_logits, new_past_key_values = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=kv_cache,
            num_logits_to_return=0,
            return_dict=False,
        )

        flat_output_past_key_values = []
        for layer in range(len(new_past_key_values)):
            k, v = new_past_key_values[layer]
            flat_output_past_key_values += [k, v]

        return lm_logits, *flat_output_past_key_values


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_dummy_inputs(
    model: ExportableModuleWithCache,
    batch_size: int = 1,
    sequence_length: int = 16,
    past_sequence_length: int = 0,
) -> tuple[tuple[torch.Tensor, ...], dict]:
    """
    Build dummy inputs for tracing / export.

    Returns a ``(args, kwargs)`` pair whose ``args`` matches the positional
    signature of :class:`ExportableModuleWithCache`:

        ``(input_ids, attention_mask, position_ids, *past_key_values)``

    All shapes are derived from ``model.config`` so the helper works for any
    decoder-only HuggingFace model.

    Args:
        model:                Wrapped exportable module.
        batch_size:           Batch dimension of the dummy tensors.
        sequence_length:      Number of new tokens in the dummy input.
        past_sequence_length: Number of tokens already in the KV cache
                              (0 = prefill / first-chunk shape).

    Returns:
        ``(args, {})`` — kwargs are always empty because the wrapper uses
        positional arguments only.
    """
    cfg = model.config
    num_layers: int = cfg.num_hidden_layers
    num_kv_heads: int = getattr(cfg, "num_key_value_heads", cfg.num_attention_heads)
    head_dim: int = getattr(cfg, "head_dim", cfg.hidden_size // cfg.num_attention_heads)
    device: torch.device = model.device
    dtype: torch.dtype = model.dtype

    total_seq = past_sequence_length + sequence_length

    input_ids = torch.zeros((batch_size, sequence_length), dtype=torch.long, device=device)
    attention_mask = torch.ones((batch_size, total_seq), dtype=torch.long, device=device)
    position_ids = (
        torch.arange(
            past_sequence_length,
            past_sequence_length + sequence_length,
            dtype=torch.long,
            device=device,
        )
        .unsqueeze(0)
        .expand(batch_size, -1)
    )

    past_key_values: list[torch.Tensor] = []
    for _ in range(num_layers):
        k = torch.zeros(
            (batch_size, num_kv_heads, past_sequence_length, head_dim),
            dtype=dtype,
            device=device,
        )
        v = torch.zeros_like(k)
        past_key_values += [k, v]

    args = (input_ids, attention_mask, position_ids, *past_key_values)
    return args, {}


# TODO - _build_onnx_io_names is to use LLM IO (currently WIP)
def _build_onnx_io_names(
    num_layers: int,
) -> tuple[list[str], list[str]]:
    """
    Return flat input / output name lists for ``torch.onnx.export``.

    Inputs:  ``input_ids``, ``attention_mask``, ``position_ids``,
             ``past_key_0``, ``past_value_0``, …
    Outputs: ``logits``,
             ``present_key_0``, ``present_value_0``, …

    Args:
        num_layers: Number of transformer layers (= number of KV-cache pairs).

    Returns:
        ``(input_names, output_names)``
    """
    input_names = ["input_ids", "attention_mask", "position_ids"]
    output_names = ["logits"]

    for i in range(num_layers):
        input_names += [f"past_key_{i}", f"past_value_{i}"]
        output_names += [f"present_key_{i}", f"present_value_{i}"]

    return input_names, output_names


def _build_dynamic_axes(
    num_layers: int,
) -> dict[str, dict[int, str]]:
    """
    Return the ``dynamic_axes`` dict expected by ``torch.onnx.export``.

    Marks batch, sequence, and cache dimensions as symbolic so the exported
    graph accepts variable-length inputs at runtime.

    Args:
        num_layers:   Number of transformer layers.

    Returns:
        Mapping of tensor name → {axis_index: axis_name}.
    """
    dynamic_axes: dict[str, dict[int, str]] = {
        "input_ids": {0: "batch_size", 1: "sequence_length"},
        "attention_mask": {0: "batch_size", 1: "total_sequence_length"},
        "position_ids": {0: "batch_size", 1: "sequence_length"},
        "logits": {0: "batch_size", 1: "sequence_length"},
    }

    for i in range(num_layers):
        for prefix in ("past_key", "past_value"):
            dynamic_axes[f"{prefix}_{i}"] = {
                0: "batch_size",
                2: "past_sequence_length",
            }
        for prefix in ("present_key", "present_value"):
            dynamic_axes[f"{prefix}_{i}"] = {
                0: "batch_size",
                2: "total_sequence_length",
            }

    return dynamic_axes


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def export_to_onnx(
    model: PreTrainedModel,
    output_path: str | Path,
    batch_size: int = 1,
    sequence_length: int = 16,
    past_sequence_length: int = 0,
    opset_version: int = 17,
    do_constant_folding: bool = True,
    verbose: bool = False,
) -> Path:
    """
    Export a HuggingFace causal-LM model to ONNX.

    The model is first wrapped in :class:`ExportableModuleWithCache` so
    that the HuggingFace ``DynamicCache`` is converted to / from flat tensors
    at the graph boundary, making the resulting ONNX graph fully static and
    portable.

    Args:
        model:                HuggingFace ``PreTrainedModel`` already placed on
                              the desired device and cast to the desired dtype.
        output_path:          Destination ``.onnx`` file.  Parent directories
                              are created automatically.
        batch_size:           Batch size of the dummy input used during tracing.
        sequence_length:      Token sequence length of the dummy input.
        past_sequence_length: KV-cache length of the dummy input.
                              Use ``0`` to export with a prefill-style shape.
        opset_version:        ONNX opset version to target (default: 17).
        do_constant_folding:  Whether to fold constants during export.
        verbose:              Forward ``verbose=True`` to ``torch.onnx.export``
                              for operator-level debug output.

    Returns:
        Resolved :class:`~pathlib.Path` to the written ``.onnx`` file.

    Example::

        model = AutoModelForCausalLM.from_pretrained(
            "meta-llama/Llama-3.2-1B-Instruct", torch_dtype=torch.float16
        ).cuda()
        export_to_onnx(model, "artifacts/llama.onnx")
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    wrapped = ExportableModuleWithCache(model)
    wrapped.eval()

    dummy_args, _ = _build_dummy_inputs(wrapped, batch_size, sequence_length, past_sequence_length)

    num_layers: int = model.config.num_hidden_layers
    input_names, output_names = _build_onnx_io_names(num_layers)
    dynamic_axes = _build_dynamic_axes(num_layers)

    _logger.info("Exporting model to ONNX → %s", output_path)
    with torch.no_grad():
        try:
            torch.onnx.export(
                wrapped,
                dummy_args,
                str(output_path),
                input_names=input_names,
                output_names=output_names,
                dynamic_axes=dynamic_axes,
                opset_version=opset_version,
                do_constant_folding=do_constant_folding,
                verbose=verbose,
            )
        except Exception as e:
            raise RuntimeError(f"ONNX export failed for {output_path}: {e}") from e

    _logger.info("ONNX export complete → %s", output_path)
    return output_path.resolve()


def export_to_torchscript(
    model: PreTrainedModel,
    output_path: str | Path | None = None,
    batch_size: int = 1,
    sequence_length: int = 16,
    past_sequence_length: int = 0,
    strict: bool = False,
) -> torch.ScriptModule:
    """
    Export a HuggingFace causal-LM model to a TorchScript module via
    ``torch.jit.trace``.

    Like :func:`export_to_onnx`, the model is wrapped in
    :class:`ExportableModuleWithCache` before tracing so that the
    ``DynamicCache`` boundary is hidden from the tracer.

    Args:
        model:                HuggingFace ``PreTrainedModel``.
        output_path:          If provided, the traced module is saved to this
                              ``.pt`` path via ``torch.jit.save``.  Parent
                              directories are created automatically.
        batch_size:           Batch size of the dummy input used during tracing.
        sequence_length:      Token sequence length of the dummy input.
        past_sequence_length: KV-cache length of the dummy input.
        strict:               Passed directly to ``torch.jit.trace``.  Set to
                              ``True`` to disallow data-dependent control flow.

    Returns:
        The traced :class:`torch.ScriptModule`, ready for inference or further
        optimisation.

    Example::

        model = AutoModelForCausalLM.from_pretrained(
            "meta-llama/Llama-3.2-1B-Instruct", torch_dtype=torch.float16
        ).cuda()
        traced = export_to_torchscript(model, "artifacts/llama.pt")
    """
    wrapped = ExportableModuleWithCache(model)
    wrapped.eval()

    dummy_args, _ = _build_dummy_inputs(wrapped, batch_size, sequence_length, past_sequence_length)

    _logger.info("Tracing model with torch.jit.trace …")
    with torch.no_grad():
        try:
            traced: torch.ScriptModule = torch.jit.trace(wrapped, dummy_args, strict=strict)
        except Exception as e:
            raise RuntimeError(f"TorchScript tracing failed: {e}") from e

    if output_path is not None:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        torch.jit.save(traced, str(output_path))
        _logger.info("TorchScript model saved → %s", output_path.resolve())

    return traced
