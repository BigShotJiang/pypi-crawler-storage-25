# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Utility for preparing LLM models via the QAIRT model preparer."""

from __future__ import annotations

import functools
import os
import tempfile
from typing import TYPE_CHECKING, Any, Callable

import torch

from qairt.utils.loggers import get_logger
from qti.aisw.emitter.utils import onnx_saver

if TYPE_CHECKING:
    from qairt.experimental.pipeline.torch.llm.generation.generator import (
        LLMGenerator,
    )

_logger = get_logger("ModelPreparation")
onnx_saver.EXPORT_TO_ONNX_DIRECT = True


def _run_on_cpu(func: Callable) -> Callable:
    """Move the generator's model to CPU before calling ``func``, restore original device after.

    Dummy inputs are created from ``model.device`` inside the wrapped function, so they
    will be on CPU.  The returned ``prepared_model`` is moved back to the original device
    before returning.  The original model is always restored even if the call raises.
    """

    @functools.wraps(func)
    def wrapper(generator: LLMGenerator, *args: Any, **kwargs: Any) -> Any:
        model = generator.model
        original_device = model.device
        model.to("cpu")
        try:
            prepared_model = func(generator, *args, **kwargs)
            prepared_model.to(original_device)
        finally:
            model.to(original_device)
        return prepared_model

    return wrapper


@_run_on_cpu
def prepare_llm(
    generator: LLMGenerator,
    *,
    path: str | None = None,
    filename: str = "converted_model",
    model_name: str = "ConvertedModel",
    **prepare_model_kwargs: Any,
) -> torch.nn.Module:
    """Prepare an LLM for quantization using the QAIRT model preparer.

    Passes the raw dict from ``prepare_inputs`` as ``dummy_input`` with
    ``order_inputs=True`` to unpack nested structures in the model body and
    retain dict keys as ``forward()`` parameters. ``input_names`` is omitted
    to preserve the ``converter_args`` tensor names, which (along with
    ``output_names``) are driven by :class:`LlmIO`.

    Args:
        generator: An ``LLMGenerator`` instance that provides the model,
            context/sequence lengths, IO config, and input preparation logic.
        path: Directory to write preparation artifacts. If provided, the
            directory is created if it does not exist and artifacts are
            retained after the call (useful for debugging). If ``None``, a
            temporary directory is used and cleaned up automatically.
        filename: Base filename for the prepared model definition and weights.
        model_name: Class name for the prepared model.
        **prepare_model_kwargs: Additional arguments forwarded to
            ``model_preparer.prepare_model()`` (e.g. ``onnx_export_args``).

    Returns:
        The prepared PyTorch module cast to the original model's dtype and
        device, in eval mode.
    """
    from qti.aisw.preparer_api import model_preparer

    model = generator.model
    num_layers = generator.config.num_hidden_layers
    context_length = generator.context_length
    sequence_length = generator.sequence_length

    # LlmIO drives converter_args and output_names.
    llm_io = type(generator)._resolve_llm_io(num_layers)
    output_names = llm_io.get_output_names()
    converter_args = llm_io.get_input_tensor_configs() | llm_io.get_output_tensor_configs()
    _logger.debug("Output names: %s", output_names)

    # Build dummy inputs via the generator's prepare_inputs classmethod.
    device = model.device
    generator_cls = type(generator)
    dummy_input = generator_cls.prepare_inputs(
        model=model,
        input_ids=torch.zeros((1, sequence_length), dtype=torch.int64, device=device),
        attention_mask=torch.ones((1, sequence_length), dtype=torch.int64, device=device),
        past_key_values=[],
        sequence_length=sequence_length,
        context_length=context_length,
    )

    # If path is provided, retain artifacts (e.g. for debugging); otherwise
    # use a TemporaryDirectory that is cleaned up after the model is loaded.
    _tmp_dir = None
    if path is not None:
        os.makedirs(path, exist_ok=True)
        actual_path = path
    else:
        _tmp_dir = tempfile.TemporaryDirectory(prefix="prepare_llm_")
        actual_path = _tmp_dir.name

    _logger.debug("Preparation path: %s", actual_path)

    # Run model preparer with order_inputs=True so the dict keys become the
    # forward() parameter names and nested structures (position_ids, past_key_values)
    # are unpacked in the body.  input_names is omitted (None) so get_model_inputs()
    # returns the dict unchanged and update_converter_args_input_names is a no-op.
    try:
        prepared_model = model_preparer.prepare_model(
            model,
            dummy_input,
            path=actual_path,
            filename=filename,
            model_name=model_name,
            output_names=output_names,
            converter_args=converter_args,
            order_inputs=True,
            order_outputs=True,
            return_prepare_model=True,
            **prepare_model_kwargs,
        ).to(dtype=model.dtype, device=device)
    except Exception as e:
        _logger.error("Failed to prepare model: %s", e)
        raise
    finally:
        if _tmp_dir is not None:
            _tmp_dir.cleanup()
    prepared_model.eval()

    _logger.debug("Prepared model loaded successfully")

    return prepared_model
