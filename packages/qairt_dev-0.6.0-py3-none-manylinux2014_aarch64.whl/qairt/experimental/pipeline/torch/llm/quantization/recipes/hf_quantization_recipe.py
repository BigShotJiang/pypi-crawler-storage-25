# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""Recipe for orchestrating HuggingFace-style quantization optimizers."""

import importlib
import os
from typing import Any, Dict, List, Optional, Type, Union

import torch
from transformers import AutoTokenizer
from transformers.quantizers.auto import AUTO_QUANTIZATION_CONFIG_MAPPING, AUTO_QUANTIZER_MAPPING

from qairt.utils.loggers import get_logger

from ..techniques.hf.base import BaseHFQuantizer
from .recipe import AIMETQuantizationRecipe
from .recipe_utils import load_and_validate_yaml

logger = get_logger(__name__)


class HFQuantizationRecipe(AIMETQuantizationRecipe):
    """
    Orchestrates a pipeline of HF-style quantization optimizers.

    Manually instantiates each optimizer and triggers its hooks, allowing multiple
    algorithms to be applied sequentially to a single loaded model.
    """

    config: Optional[Union[Dict[str, Any], str]] = None

    def __init__(self, steps: List[Dict[str, Any]]):
        """
        Args:
            steps: List of step dicts, each with keys ``optimizer_cls`` and ``config``.
        """
        self.steps = steps

    def _resolve_optimizer_cls(
        self, optimizer_cls_or_name: Union[str, Type[BaseHFQuantizer]]
    ) -> Type[BaseHFQuantizer]:
        """Resolve an optimizer class from its string name via the transformers registry.

        Falls back to dynamic import using the convention
        ``techniques.hf.{name}_hf_optimizer.py`` when the name is not yet registered.
        """
        if isinstance(optimizer_cls_or_name, str):
            name = optimizer_cls_or_name.lower()

            if name not in AUTO_QUANTIZER_MAPPING:
                try:
                    module_name = f"{name}_hf_optimizer"
                    importlib.import_module(f"..techniques.hf.{module_name}", package=__package__)
                except (ImportError, ValueError) as e:
                    logger.warning(
                        f"Failed to auto-import '{name}': {e}. "
                        f"Ensure techniques.hf.{name}_hf_optimizer.py exists and is registered."
                    )
                    if name not in AUTO_QUANTIZER_MAPPING:
                        raise ImportError(
                            f"Could not load optimizer '{name}': {e}. "
                            f"Available: {list(AUTO_QUANTIZER_MAPPING.keys())}"
                        ) from e

            if name in AUTO_QUANTIZER_MAPPING:
                return AUTO_QUANTIZER_MAPPING[name]  # type: ignore[return-value]

            raise ValueError(f"Unknown optimizer '{name}'. Available: {list(AUTO_QUANTIZER_MAPPING.keys())}")
        return optimizer_cls_or_name

    def _manual_apply_hf_optimizer(
        self,
        optimizer_cls: Type[BaseHFQuantizer],
        config: Any,
        model: torch.nn.Module,
        tokenizer: Optional[AutoTokenizer] = None,
    ) -> torch.nn.Module:
        """Instantiate *optimizer_cls* and run its pre/post weight-loading hooks."""
        optimizer = optimizer_cls(config)
        optimizer._process_model_before_weight_loading(model)  # type: ignore[arg-type]
        model = optimizer._process_model_after_weight_loading(model)  # type: ignore[arg-type]
        return model

    def _resolve_config_cls(self, optimizer_cls_or_name: Union[str, Type[BaseHFQuantizer]]) -> Type[Any]:
        """Resolve a config class from its string name via the transformers registry."""
        if isinstance(optimizer_cls_or_name, str):
            name = optimizer_cls_or_name.lower()
            if name in AUTO_QUANTIZATION_CONFIG_MAPPING:
                return AUTO_QUANTIZATION_CONFIG_MAPPING[name]
            raise ValueError(
                f"Unknown config '{name}'. Available: {list(AUTO_QUANTIZATION_CONFIG_MAPPING.keys())}"
            )

        if hasattr(optimizer_cls_or_name, "params_cls"):
            try:
                return optimizer_cls_or_name.params_cls()
            except Exception:
                pass

        raise ValueError(
            "Cannot resolve config class from optimizer class object. "
            "Pass a string name (e.g. 'adascale') or provide the config instance directly."
        )

    @classmethod
    def from_yaml(
        cls,
        yaml_path: str,
        tokenizer: Optional[Any] = None,
        dataloader: Optional[Any] = None,
        workspace_root: Optional[str] = None,
        output_dir: Optional[str] = None,
    ) -> "HFQuantizationRecipe":
        """Build an ``HFQuantizationRecipe`` from a YAML config file.

        The dataloader is validated and materialised **once** here, then stored in each
        step's config dict so ``apply()`` does not need to receive it again.

        Args:
            yaml_path: Path to the YAML recipe file.
            tokenizer: HF tokenizer (used by PrefixQuant for token-ID conversion).
            dataloader: Calibration dataloader shared across all steps that require one.
            workspace_root: Base dir for resolving relative paths; defaults to ``yaml_path``'s dir.
            output_dir: Overrides the ``output_dir`` in the YAML ``global`` section.
        """
        if workspace_root is None:
            workspace_root = os.path.dirname(os.path.abspath(yaml_path))

        cfg, global_cfg, dataloader = load_and_validate_yaml(yaml_path, dataloader)

        device = "cuda" if torch.cuda.is_available() and global_cfg.get("device") == "cuda" else "cpu"
        output_dir = output_dir if output_dir is not None else global_cfg["output_dir"]

        recipe_steps: List[Dict[str, Any]] = []
        for step_info in cfg["recipe"]:
            if "optimizer" not in step_info:
                raise ValueError(f"Missing 'optimizer' key in recipe step: {step_info}")

            opt_name = step_info["optimizer"].lower()
            raw_config = step_info.get("config", {}).copy()

            # Inject shared runtime values
            if opt_name in ("prefixquant", "adascale"):
                raw_config["device"] = device
            if opt_name in ("gptaq", "adascale"):
                raw_config["dataloader"] = dataloader

            # Inject optimizer-specific values
            if opt_name == "gptaq":
                raw_config["seqlen"] = raw_config.get("seqlen", global_cfg["seqlen"])
            elif opt_name == "prefixquant":
                raw_config["output_dir"] = output_dir
                if tokenizer is not None:
                    prefix_text = raw_config.pop("prefix_text", "<|im_start|>")
                    tokens = tokenizer.encode(prefix_text, add_special_tokens=False)
                    raw_config["prefix_token_ids"] = tokens if tokens else [1]
            elif opt_name != "adascale" and opt_name not in AUTO_QUANTIZER_MAPPING:
                raise ValueError(
                    f"Unknown optimizer '{opt_name}'. Available: {list(AUTO_QUANTIZER_MAPPING.keys())}"
                )

            recipe_steps.append({"optimizer_cls": opt_name, "config": raw_config})
            logger.info(f"[from_yaml] Configured step: {opt_name}")

        if not recipe_steps:
            raise ValueError(
                f"No valid recipe steps found in '{yaml_path}'. "
                f"Ensure the 'recipe' section contains at least one valid optimizer."
            )

        return cls(recipe_steps)

    def apply(
        self,
        hf_model: torch.nn.Module,
        tokenizer: Optional[AutoTokenizer] = None,
        dataloader: Any = None,
        **recipe_kwargs: Any,
    ) -> torch.nn.Module:
        """Apply the quantization pipeline to *hf_model*.

        When built via ``from_yaml`` the dataloader is already embedded in each step's
        config; pass it here only when constructing the recipe programmatically.
        """
        logger.info("Starting HF Quantization Recipe...")
        current_model = hf_model

        for i, step in enumerate(self.steps):
            try:
                optimizer_cls_raw = step["optimizer_cls"]
                optimizer_cls = self._resolve_optimizer_cls(optimizer_cls_raw)
                config_or_kwargs = step.get("config", step.get("config_kwargs", {}))

                if isinstance(config_or_kwargs, dict):
                    # Fallback for programmatic path: inject dataloader if not pre-set.
                    if "dataloader" not in config_or_kwargs and dataloader is not None:
                        config_or_kwargs = {**config_or_kwargs, "dataloader": dataloader}
                    ConfigClass = self._resolve_config_cls(optimizer_cls_raw)
                    try:
                        config = ConfigClass(**config_or_kwargs)
                    except TypeError as e:
                        logger.error(
                            f"Step {i + 1} ({optimizer_cls.__name__}): failed to instantiate "
                            f"{ConfigClass.__name__} with {config_or_kwargs}"
                        )
                        raise RuntimeError(f"Configuration error in step {i + 1}") from e
                else:
                    config = config_or_kwargs

                logger.info(f"Step {i + 1}: Applying {optimizer_cls.__name__}")
                current_model = self._manual_apply_hf_optimizer(
                    optimizer_cls, config, current_model, tokenizer
                )
            except Exception as e:
                logger.error(f"Step {i + 1} ({optimizer_cls_raw}) failed: {e}")
                raise RuntimeError(
                    f"Recipe failed at step {i + 1}/{len(self.steps)}: {optimizer_cls_raw}"
                ) from e

        logger.info("Recipe execution completed!")
        return current_model
