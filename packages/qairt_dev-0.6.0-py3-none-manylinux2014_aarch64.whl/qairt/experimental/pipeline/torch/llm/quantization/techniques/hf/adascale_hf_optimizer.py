# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""AdaScale HF Optimizer – HuggingFace adapter for the AdaScale algorithm."""

from typing import Dict, Optional, Tuple, Type, Union

import torch
from torch.utils.data import DataLoader
from transformers.quantizers import register_quantization_config, register_quantizer
from transformers.utils.quantization_config import QuantizationConfigMixin

from ..adascale.adascale_optimizer import AdaScale, AdaScaleParams  # noqa: F401 (re-export)
from ..bases.aimet_optimizer import AIMETOptimizer
from .aimet_hf_optimizer import AIMETHFOptimizer
from .aimet_hf_quantizer import AIMETConfigMixin

# ---------------------------------------------------------------------------
# AdaScaleHfConfig
# ---------------------------------------------------------------------------


@register_quantization_config("adascale")
class AdaScaleHfConfig(AIMETConfigMixin):
    """Configuration class for AdaScale optimization.

    Passed to ``AdaScaleHfOptimizer`` via the HuggingFace quantizer registry.
    All fields are forwarded to ``AdaScaleParams.from_hf_config()`` when the
    optimizer runs.

    Note
    ----
    ``AIMETConfigMixin.__init__`` has a variable-name bug that causes
    ``NameError``.  We call ``QuantizationConfigMixin.__init__`` directly and
    set attributes manually as a workaround.

    Mode control
    ------------
    is_hf_quantization : bool
        ``True`` (default) – HF mode: collect raw dict batches, bake weights,
        remove AIMET wrappers, return clean HF model.
        ``False`` – Prefill mode: use ``generator`` to run KV-cache prefill,
        return ``quantsim.model`` with AIMET wrappers intact.

    generator : Any | None
        Generator instance required when ``is_hf_quantization=False``.
        Must expose ``.model``, ``.device``, and
        ``.prefill(input_ids, attention_mask)``.

    forward_fn : Callable | None
        Custom forward function for ``apply_adascale``.  Defaults to a
        dict-unpacking forward in HF mode and ``None`` in Prefill mode.
    """

    def __init__(
        self,
        dataloader: Optional[DataLoader] = None,
        modules_to_not_convert: Optional[list] = None,
        default_param_bw: int = 4,
        default_output_bw: int = 16,
        embedding_bw: Optional[int] = None,
        lmhead_bw: Optional[int] = None,
        dummy_inputs: Union[Tuple, Dict, torch.Tensor, None] = None,
        device: str = "cpu",
        num_iterations: int = 1500,
        beta_gamma_lr: float = 1e-3,
        scales_lr: float = 5e-4,
        num_batches: int = 20,
        is_hf_quantization: bool = True,
        generator=None,
        forward_fn=None,
        **kwargs,
    ):
        # Bypass AIMETConfigMixin.__init__ bug – call grandparent directly
        QuantizationConfigMixin.__init__(self, quant_method="adascale")  # type: ignore[arg-type]
        # Replicate AIMETConfigMixin attributes manually
        self.dataloader = dataloader
        self.modules_to_not_convert = modules_to_not_convert
        self.default_param_bw = default_param_bw
        self.default_output_bw = default_output_bw
        self.embedding_bw = embedding_bw
        self.lmhead_bw = lmhead_bw
        self.dummy_inputs = (dummy_inputs,) if isinstance(dummy_inputs, torch.Tensor) else dummy_inputs
        self.device = device
        self.tie_quantizers = None
        # AdaScale-specific
        self.num_iterations = num_iterations
        self.beta_gamma_lr = beta_gamma_lr
        self.scales_lr = scales_lr
        self.num_batches = num_batches
        # Mode control
        self.is_hf_quantization = is_hf_quantization
        self.generator = generator
        self.forward_fn = forward_fn


# ---------------------------------------------------------------------------
# AdaScaleHfOptimizer
# ---------------------------------------------------------------------------


@register_quantizer("adascale")
class AdaScaleHfOptimizer(AIMETHFOptimizer):
    """AdaScale optimizer adapter for the HuggingFace framework.

    Delegates all algorithm logic to
    :class:`~qairt.experimental.pipeline.torch.llm.quantization.techniques.adascale.AdaScale`
    via the ``AIMETHFOptimizer`` delegation pattern.

    Execution flow
    --------------
    Phase 1 – ``_process_model_before_weight_loading`` (inherited)
        Instantiates ``AdaScale(hf_model=model, ...)`` and stores it as
        ``self._aimet_instance``.

    Phase 2 – HF framework loads weights into the model.
        Because Python passes objects by reference, ``self._aimet_instance.hf_model``
        IS the same object as ``model`` and receives the loaded weights.

    Phase 3 – ``_process_model_after_weight_loading`` (inherited)
        1. Builds ``AdaScaleParams`` via ``AdaScaleParams.from_hf_config(config)``.
        2. Calls ``self._aimet_instance.apply(params)`` which:
           - Creates a ``QuantizationSimModel``
           - Collects calibration data
           - Runs ``apply_adascale``
           - Bakes quantization parameters into weights
           - Removes AIMET wrappers (restores clean HF model)
           - Returns ``OptimizationResult(quantsim=None)``
        3. Because ``result.quantsim is None``, ``save_pretrained`` is **not**
           wrapped – the model is returned as a clean HF model ready for
           ``save_pretrained`` / inference.
    """

    def __init__(self, quantization_config: QuantizationConfigMixin, **kwargs):
        super().__init__(quantization_config, **kwargs)

    @classmethod
    def aimet_optimizer_cls(cls) -> Type[AIMETOptimizer]:
        """Return the AdaScale optimizer class."""
        return AdaScale
