# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""GPTAQ HF optimizer: Config and Optimizer adapter for the HuggingFace quantization framework."""

from typing import Any, cast

import torch
import torch.nn as nn
from transformers import PreTrainedModel
from transformers.quantizers import register_quantization_config, register_quantizer
from transformers.utils.quantization_config import QuantizationConfigMixin

from qairt.utils.loggers import get_logger

from .base import BaseHFQuantizer
from .gptaq_utils import (
    TARGET_LAYER_SUFFIXES,
    GPTAQParams,
    GPTQIntLinear,
    gptaq_quantize,
    temp_model_config,
)

logger = get_logger(__name__)


@register_quantization_config("gptaq")
class GPTAQHfConfig(QuantizationConfigMixin):
    """HuggingFace quantization config for GPTAQ."""

    def __init__(
        self,
        dataloader: Any,
        param_bw: int = 4,
        group_size: int = -1,
        num_calib_batches: int = -1,
        seqlen: int = 2048,
        device: str = "cpu",
        **kwargs,
    ):
        super().__init__(quant_method="gptaq")  # type: ignore[arg-type]
        self.dataloader = dataloader
        self.param_bw = param_bw
        self.group_size = group_size
        self.num_calib_batches = num_calib_batches
        self.seqlen = seqlen
        self.device = device
        self.qdq_weights = True


@register_quantizer("gptaq")
class GPTAQHfOptimizer(BaseHFQuantizer):
    """HuggingFace quantizer adapter for GPTAQ.

    Phase 1 (``_process_model_before_weight_loading``):
        Replaces target ``nn.Linear`` layers with ``GPTQIntLinear`` wrappers.

    Phase 2 (``_process_model_after_weight_loading``):
        Runs the GPTAQ PTQ pass, then converts ``GPTQIntLinear`` back to ``nn.Linear``.
    """

    requires_calibration = False
    requires_parameters_quantization = True

    def __init__(self, quantization_config: QuantizationConfigMixin, **kwargs):
        super().__init__(quantization_config, **kwargs)

    def _process_model_before_weight_loading(self, model: nn.Module, **kwargs) -> None:
        logger.info("[GPTAQ] Replacing linear layers with GPTQIntLinear...")
        cfg = cast(GPTAQHfConfig, self.quantization_config)
        for parent_name, parent in model.named_modules():
            for child_name, child in parent.named_children():
                if not isinstance(child, nn.Linear):
                    continue
                full_name = f"{parent_name}.{child_name}" if parent_name else child_name
                if any(full_name.endswith(s) for s in TARGET_LAYER_SUFFIXES):
                    setattr(
                        parent,
                        child_name,
                        GPTQIntLinear(child, bitwidth=cfg.param_bw, group_size=cfg.group_size),
                    )

    def _process_model_after_weight_loading(self, model: nn.Module, **kwargs) -> PreTrainedModel:
        logger.info("[GPTAQ] Running GPTAQ PTQ pass...")
        params = GPTAQParams.from_hf_config(self.quantization_config)
        model.eval()
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        with temp_model_config(model, use_cache=False):
            gptaq_quantize(
                model,
                dataloader=params.dataloader,
                num_calib_batches=params.num_calib_batches,
                seqlen=params.seqlen,
                device=params.device,
            )
        logger.info("[GPTAQ] Converting GPTQIntLinear back to nn.Linear...")
        for parent_name, parent in model.named_modules():
            for child_name, child in parent.named_children():
                if isinstance(child, GPTQIntLinear):
                    setattr(parent, child_name, child.to_linear(params.qdq_weights))
        return model  # type: ignore[return-value]

    def check_quantized_param(self, model, param_value, param_name, state_dict, **kwargs) -> bool:
        return False
