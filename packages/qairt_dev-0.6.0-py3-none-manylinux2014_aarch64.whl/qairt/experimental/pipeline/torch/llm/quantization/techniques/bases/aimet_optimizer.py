# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Interface classes for AIMET quantization and optimization techniques"""

from abc import ABC, abstractmethod
from typing import Generic, List, Optional, Type, TypeVar

import torch
from aimet_torch import QuantizationSimModel
from torch.utils.data import DataLoader
from transformers import AutoTokenizer

from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.definitions import (
    CommonParams,
    Generator,
    OptimizationResult,
)

from .aimet_mixin import AIMETMixin

OptimizerParams = TypeVar("OptimizerParams", bound=CommonParams)


class AIMETOptimizer(AIMETMixin, Generic[OptimizerParams], ABC):
    """Base class for AIMET optimization techniques.

    An optimizer improves a model's ability to be quantized without actually quantizing it.
    Think of it as preparing your model to handle lower precision (like int8) more accurately.

    What optimizers do:
        Optimizers modify model weights or structure to reduce errors that occur during
        quantization. After optimization, you pass the improved model to a quantizer to
        actually convert it to lower precision.

    How to use optimizers:
        You can chain multiple optimizers together, then finish with a quantizer.
        Each optimizer takes a model and returns an improved version.

    Example:
        .. code-block:: python

            # Step 1: Apply first optimization (SpinQuant)
            opt1 = SpinQuant(model, tokenizer)
            optimized_model = opt1.apply(dataloader=data)

            # Step 2: Apply second optimization (AdaScale) on top
            opt2 = AdaScale(optimized_model, tokenizer)
            opt2.prepared_model = opt1.prepared_model  # Share prepared model
            final_optimized = opt2.apply(dataloader=data)

            # Step 3: Quantize the optimized model
            quantizer = LPBQ_Quantizer(final_optimized, tokenizer)
            quantizer.prepared_model = opt2.prepared_model
            quantsim = quantizer.quantize(dataloader=data)

    Note:
        Some optimizers (AdaScale, SeqMSE, OmniQuant) internally create a temporary
        quantized model (QuantizationSimModel) because the AIMET library requires it.
        However, they only return the optimized weights, not the quantized model.
        The temporary quantized model is stored in ``self.quantsim`` if you need it.
    """

    _requires_data: bool = False
    _requires_calibration: bool = False
    _requires_generation: bool = False

    def __init__(
        self,
        hf_model: torch.nn.Module,
        context_length: int | None,
        sequence_length: int | None,
        tokenizer: AutoTokenizer | None = None,
    ):
        """Initialize the optimizer.

        Args:
            hf_model: The PyTorch model to optimize (typically from HuggingFace).
            context_length: Maximum number of tokens the model can process at once.
                Set to None if your model doesn't need a fixed context length.
                Required if the optimizer needs to generate text or calibrate.
            sequence_length: Length of input sequences for testing the model.
                Set to None if your model doesn't need a fixed sequence length.
                Required if the optimizer needs to generate text or calibrate.
            tokenizer: The tokenizer that converts text to tokens for your model.
                Optional, but needed for most optimizers.
        """
        super().__init__(hf_model, context_length, sequence_length, tokenizer)
        self._quantsim = None

    @property
    def quantsim(self) -> QuantizationSimModel | None:
        """Get the internal quantization model if one was created.

        Some optimizers (AdaScale, SeqMSE, OmniQuant) create a temporary quantized
        model internally because the AIMET library requires it. This property lets
        you access that temporary model if you need to inspect it.

        Returns:
            The temporary QuantizationSimModel if created, None otherwise.
        """
        return self._quantsim

    @quantsim.setter
    def quantsim(self, value: QuantizationSimModel | None):
        """Set the internal quantization model.

        Args:
            value: The QuantizationSimModel to store, or None to clear it.
        """
        self._quantsim = value

    @classmethod
    @abstractmethod
    def params_cls(cls) -> Type[CommonParams]:
        """Return the CommonParams subclass this optimizer expects.

        Concrete optimizers (SpinQuant, AdaScale, SeqMSE, OmniQuant, etc.) must
        implement this to declare the param type they accept in `apply()`. This
        allows HF adapters to dynamically determine which param class to instantiate
        via `from_hf_config()`.

        Returns:
            A CommonParams subclass (e.g., SpinQuantParams, AdaScaleParams).

        Example:
            .. code-block:: python

                class SpinQuantOptimizer(AIMETOptimizer):
                    @classmethod
                    def params_cls(cls) -> Type[CommonParams]:
                        return SpinQuantParams
        """
        raise NotImplementedError

    def _prepare_model(self, **kwargs):
        """Prepare the model for optimization.

        This method is called automatically before optimization if needed.
        For optimizers, it typically just uses the model as-is without modification.

        Note:
            This sets ``self.prepared_model`` to ``self.hf_model``.
        """
        self._logger.info(
            "Model preparation is skipped in the AIMET Optimization class. Setting prepared model to hf_model"
        )
        self.prepared_model = self.hf_model

    def _prefill_inputs(
        self,
        generator: Generator,
        dataloader: DataLoader,
        num_batches: int,
        device: torch.device,
    ) -> List[torch.Tensor]:
        """Generate input tensors for optimization.

        This method creates a list of input tensors by running the generator on
        calibration data. These inputs are used by optimization techniques that
        need pre-computed tensors.

        Args:
            generator: The generator that processes inputs through the model.
            dataloader: Source of calibration data (text samples).
            num_batches: How many batches of data to process from the dataloader.
            device: Which device (CPU/GPU) to place the tensors on.

        Returns:
            List of input tensors ready for optimization.
        """

        raise NotImplementedError("Prefill inputs is not yet implemented")

    @abstractmethod
    def apply(
        self,
        params: OptimizerParams,
    ) -> OptimizationResult:
        """Apply the optimization technique to improve the model.

        This is the main method you call to optimize your model. It modifies the model
        weights or structure to make quantization more accurate.

        Args:
            params: Configuration for this optimization technique. Each optimizer has
                its own parameter class (like SeqMSEParams, AdaScaleParams, SpinQuantParams)
                that inherits from CommonParams. The params object includes:

                - Common parameters: dataloader, dummy_inputs, generator, quantsim
                - Technique-specific parameters: num_batches, num_candidates, etc.

        Returns:
            OptimizationResult containing:
                - model: The optimized PyTorch model
                - quantsim: Internal quantization model (if created)
                - prepared_model: Model prepared for export

        Example:
            .. code-block:: python

                from qairt.gen_ai_api.experimental.pipeline.llm.quantization.torch.techniques.params import (
                    SeqMSEParams
                )

                # Create optimizer
                optimizer = SeqMSE(model, tokenizer)

                # Configure and run optimization
                result = optimizer.apply(
                    params=SeqMSEParams(
                        dataloader=dataloader,
                        num_batches=10,
                        num_candidates=15
                    )
                )

                # Use the optimized model
                optimized_model = result.model
        """
        ...

    def export(
        self,
        export_path: str,
        quantsim: QuantizationSimModel,
        filename_prefix: str = "model",
        generator: Generator | None = None,
        dummy_inputs: Optional[tuple[torch.Tensor, ...]] = None,
        **export_kwargs,
    ):
        """Export the optimized model to disk.

        Args:
            export_path: Directory where the model files will be saved.
            quantsim: The quantization model to export.
            filename_prefix: Name prefix for the exported files. Defaults to "model".
            generator: A Generator instance for creating dummy inputs.
                Provide either this or dummy_inputs, but not both.
            dummy_inputs: Pre-created dummy inputs for the model.
                Provide either this or generator, but not both.
            **export_kwargs: Additional options to pass to the export function.

        Raises:
            NotImplementedError: This method is not yet implemented for optimizers.
        """

        raise NotImplementedError("Export is not implemented for AIMETOptimizer")
