# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""Base protocol for AIMET quantization recipes."""

import json
from typing import Any, Dict, Optional, Protocol, Union

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from qairt.utils.loggers import get_logger

logger = get_logger(__name__)

CONTEXT_LENGTH = 4096
SEQUENCE_LENGTH = 2048


class AIMETQuantizationRecipe(Protocol):
    """Protocol for AIMET Quantization Recipes.

    A recipe combines optimization techniques (e.g., SpinQuant, AdaScale) with
    quantization techniques (e.g., LPBQ, PCQ) to create complete quantization workflows.

    Any class that implements the ``apply`` method with this signature is considered
    a valid recipe, regardless of inheritance.

    Example:
        .. code-block:: python

            # This class is a valid recipe without inheriting from AIMETQuantizationRecipe
            class MyCustomRecipe:
                def apply(
                    self,
                    hf_model: torch.nn.Module,
                    tokenizer: AutoTokenizer | None = None,
                    dataloader=None,
                    **recipe_kwargs,
                ) -> torch.nn.Module:
                    ...
                    return result

            # Type checker will recognise this as conforming to AIMETQuantizationRecipe
            def process_recipe(recipe: AIMETQuantizationRecipe):
                ...

            process_recipe(MyCustomRecipe())  # Valid!
    """

    config: Optional[Union[Dict[str, Any], str]] = None

    def apply(
        self,
        hf_model: torch.nn.Module,
        tokenizer: Optional[AutoTokenizer] = None,
        dataloader=None,
        **recipe_kwargs,
    ) -> torch.nn.Module:
        """Apply the quantization recipe.

        Args:
            hf_model: HuggingFace model to quantize.
            tokenizer: Optional tokenizer associated with the model.
            dataloader: Optional dataloader for calibration/optimization.
            **recipe_kwargs: Additional keyword arguments forwarded to
                optimizers/quantizers.

        Returns:
            The optimised (and optionally quantized) ``torch.nn.Module``.
        """
        ...

    @classmethod
    def apply_from_config(
        cls,
        config: Union[str, Dict, None] = None,
        hf_model: Optional[torch.nn.Module] = None,
        tokenizer: Optional[AutoTokenizer] = None,
        dataloader=None,
    ) -> Optional[torch.nn.Module]:
        """Apply the quantization recipe using configuration from a JSON file or dict.

        The configuration must include:
        - ``model_id``: Model identifier. Used to load model/tokenizer if not provided,
          and to filter whether the recipe should be applied when a model is already given.

        The configuration can optionally include:
        - ``dataset``: Automatically create a dataloader. Currently supports ``'wikitext'``.
          If specified and *dataloader* is ``None``, a dataloader will be created automatically.

        Args:
            config: Path to a recipe configuration JSON file, a config dict, or ``None``
                to use the class-level ``config`` attribute.
            hf_model: Optional HuggingFace model to quantize. If ``None``, the model will
                be loaded using ``model_id`` from the config.
            tokenizer: Optional tokenizer. If ``None``, will be loaded using ``model_id``.
            dataloader: Optional dataloader for calibration/optimization. If ``None`` and
                ``dataset`` is specified in the config, a dataloader will be created
                automatically.

        Returns:
            The optimised model, or ``None`` if the ``model_id`` filter does not match.

        Raises:
            ValueError: If ``model_id`` is absent from the config and *hf_model* is ``None``.
            ValueError: If no dataloader is provided and ``dataset`` is not in the config.
            ValueError: If an unsupported dataset name is specified.
        """
        if config is None:
            config = cls.config  # type: ignore[attr-defined]
            assert config is not None, "No config provided and class does not define a default config."

        # Load configuration from JSON file
        if isinstance(config, str):
            with open(config, "r") as f:
                config = json.load(f)

        # Work on a copy so we can pop keys without mutating the caller's dict
        assert isinstance(config, dict), f"Expected dict config after loading, got {type(config)}"
        config = dict(config)

        # Extract model_id (required for loading; optional if model already provided)
        model_id: Optional[str] = config.pop("model_id", None)
        if model_id is None and hf_model is None:
            raise ValueError("'model_id' must be specified in config if hf_model is not provided")

        # Load or validate model
        if hf_model is None:
            assert model_id is not None  # guaranteed by the ValueError check above
            logger.info(f"Loading model from '{model_id}'...")
            hf_model = AutoModelForCausalLM.from_pretrained(model_id)
        elif model_id is not None:
            actual_model_id = getattr(hf_model.config, "_name_or_path", None)
            if actual_model_id != model_id:
                logger.info(
                    f"Skipping recipe: model_id '{actual_model_id}' does not match required '{model_id}'"
                )
                return None

        # Load tokenizer if not provided
        if tokenizer is None:
            tokenizer_id = model_id or getattr(hf_model.config, "_name_or_path", None)
            if tokenizer_id is None:
                raise ValueError("Cannot determine model_id for tokenizer loading")
            logger.info(f"Loading tokenizer from '{tokenizer_id}'...")
            tokenizer = AutoTokenizer.from_pretrained(tokenizer_id, use_fast=True, trust_remote_code=True)

        # Auto-create dataloader from dataset spec if needed
        if "dataset" in config:
            dataset_name = config.pop("dataset")
            if dataloader is None:
                if dataset_name == "wikitext":
                    try:
                        from qairt.experimental.pipeline.torch.llm.quantization.datasets import (
                            Wikitext,
                        )
                    except ImportError:
                        from datasets import load_dataset  # type: ignore[import]

                        context_length = config.get("context_length", CONTEXT_LENGTH)
                        logger.info(f"Loading Wikitext dataset with context_length={context_length}...")
                        raw = load_dataset("wikitext", "wikitext-2-raw-v1", split="train")
                        dataloader = raw
                    else:
                        context_length = config.get("context_length", CONTEXT_LENGTH)
                        logger.info(f"Loading Wikitext dataset with context_length={context_length}...")
                        dataloader = Wikitext.load_encoded_dataset(tokenizer, context_length, "train")
                else:
                    raise ValueError(f"Unsupported dataset: '{dataset_name}'. Supported datasets: 'wikitext'")

        if dataloader is None:
            raise ValueError("dataloader must be provided or 'dataset' must be specified in config")

        return cls().apply(  # type: ignore[misc]
            hf_model=hf_model,
            tokenizer=tokenizer,
            dataloader=dataloader,
            **config,
        )
