# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""PrefixQuant HF optimizer: Config and Optimizer adapter for the HuggingFace quantization framework."""

import os
from typing import List, Optional, cast

import torch
import torch.nn as nn
from transformers import PreTrainedModel
from transformers.quantizers import register_quantization_config, register_quantizer
from transformers.utils.quantization_config import QuantizationConfigMixin

from qairt.utils.loggers import get_logger

from .base import BaseHFQuantizer
from .prefixquant_utils import PrefixQuantParams, generate_prefix_kvcache

logger = get_logger(__name__)


@register_quantization_config("prefixquant")
class PrefixQuantHfConfig(QuantizationConfigMixin):
    """HuggingFace quantization config for PrefixQuant.

    Args:
        prefix_token_ids: Token IDs for which the KV cache is pre-computed.
        dummy_input: Optional ``[1, seq_len]`` tensor for shape inference; auto-created if ``None``.
        do_kvcache_save: Whether to persist the KV cache to ``output_dir/prefix_kv.pt``.
        output_dir: Directory for saving the KV cache artifact.
        device: Inference device.
        allow_tf32: Enable TensorFloat-32 precision (default ``False`` for determinism).
    """

    def __init__(
        self,
        prefix_token_ids: Optional[List[int]] = None,
        dummy_input: Optional[torch.Tensor] = None,
        do_kvcache_save: bool = True,
        output_dir: str = ".",
        device: str = "cpu",
        allow_tf32: bool = False,
        **kwargs,
    ):
        super().__init__(quant_method="prefixquant")  # type: ignore[arg-type]
        self.prefix_token_ids = prefix_token_ids
        self.dummy_input = dummy_input
        self.do_kvcache_save = do_kvcache_save
        self.output_dir = output_dir
        self.device = device
        self.allow_tf32 = allow_tf32
        self.modules_to_not_convert = None


@register_quantizer("prefixquant")
class PrefixQuantHfOptimizer(BaseHFQuantizer):
    """HuggingFace quantizer adapter for PrefixQuant.

    Generates and optionally saves the KV cache for a set of prefix tokens so that
    downstream inference can skip re-computing attention over the fixed prefix.
    """

    requires_calibration = False
    requires_parameters_quantization = False

    def __init__(self, quantization_config: QuantizationConfigMixin, **kwargs):
        super().__init__(quantization_config, **kwargs)

    def _process_model_before_weight_loading(self, model: nn.Module, **kwargs) -> None:
        pass

    def _process_model_after_weight_loading(self, model: nn.Module, **kwargs) -> PreTrainedModel:
        logger.info("[PrefixQuant] Starting execution...")
        params = PrefixQuantParams.from_hf_config(self.quantization_config)

        if not params.prefix_token_ids:
            raise ValueError("[PrefixQuant] prefix_token_ids must be a non-empty list.")

        model.eval()
        orig_matmul_tf32 = torch.backends.cuda.matmul.allow_tf32
        orig_cudnn_tf32 = torch.backends.cudnn.allow_tf32
        torch.backends.cuda.matmul.allow_tf32 = params.allow_tf32
        torch.backends.cudnn.allow_tf32 = params.allow_tf32
        logger.info("[PrefixQuant] TF32 allowed: %s", params.allow_tf32)

        try:
            return self._run(model, params)
        finally:
            torch.backends.cuda.matmul.allow_tf32 = orig_matmul_tf32
            torch.backends.cudnn.allow_tf32 = orig_cudnn_tf32

    def _run(self, model: nn.Module, params: PrefixQuantParams) -> PreTrainedModel:
        dummy_input = params.dummy_input
        if dummy_input is None:
            seq_len = max(128, len(params.prefix_token_ids) + 1)
            dummy_input = torch.zeros((1, seq_len), dtype=torch.long)
            logger.info("[PrefixQuant] Auto-created dummy_input with shape %s", dummy_input.shape)

        logger.info("[PrefixQuant] Generating KV Cache for %d tokens...", len(params.prefix_token_ids))
        past_key_values = generate_prefix_kvcache(model, dummy_input, params.device, params.prefix_token_ids)

        if params.do_kvcache_save:
            save_path = os.path.join(params.output_dir, "prefix_kv.pt")
            os.makedirs(params.output_dir, exist_ok=True)
            torch.save(past_key_values, save_path)
            logger.info("[PrefixQuant] KV Cache saved to %s", save_path)

        model.prefix_kvcache = past_key_values  # type: ignore[assignment]
        return cast(PreTrainedModel, model)

    def check_quantized_param(self, model, param_value, param_name, state_dict, **kwargs) -> bool:
        return False
