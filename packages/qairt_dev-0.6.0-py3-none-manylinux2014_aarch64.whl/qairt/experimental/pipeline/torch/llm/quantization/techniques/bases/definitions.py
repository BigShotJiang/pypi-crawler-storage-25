# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Parameter and result classes for AIMET quantization techniques.

This module defines the configuration classes (parameters) and result classes
used by optimizers and quantizers. These classes provide type safety, validation,
and clear documentation of what each technique needs.
"""

from abc import abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Literal, Optional, Protocol, TypedDict, TypeVar, get_args

import torch
from aimet_torch.v2.quantsim import QuantizationSimModel
from torch.utils.data import DataLoader

from qairt.api.configs.common import DspArchitecture

if TYPE_CHECKING:
    from transformers.utils.quantization_config import QuantizationConfigMixin

    from qairt.experimental.pipeline.torch.llm.generation.generator import LLMGenerator


PrecisionType = Literal["int4", "int8", "int16"]


class Precisions(TypedDict, total=False):
    """Per-module precision settings for weight and activation quantization.

    Both keys are optional, but at least one must be present when a ``Precisions``
    object is assigned to a module slot in ``ModulePrecisions``.

    Attributes:
        weight_precision: Bit precision for weight quantization ("int4", "int8", or "int16").
        activation_precision: Bit precision for activation quantization ("int4", "int8", or "int16").
                              Note that activation precision is applied to the output only.
    """

    weight_precision: PrecisionType
    activation_precision: PrecisionType
    mode: Literal["asymmetric", "symmetric"] | None
    # TODO: maybe change activation precision to output precision for more clarity
    # TODO: Add output index if it should not apply to all outputs. Defaults should be all outputs.
    # TODO: Add asymmetric boolean field
    # TODO: Introduce match info property that allows string based module match or callable module match
    # In reference to this comment: https://github.qualcomm.com/MLG/qairt-tools/pull/955/files#r1141896


def _validate_precisions(name: str, p: Precisions) -> None:
    """Validate a Precisions dict for a named module slot.

    Args:
        name: Module slot name (e.g., "lm_head", "kv_cache") for error messages.
        p: The Precisions dict to validate.

    Raises:
        ValueError: If the dict is empty or contains invalid precision values.
    """
    if not p:
        raise ValueError(
            f"{name}: Precisions dict must have at least one key (weight_precision or activation_precision)"
        )
    valid = set(get_args(PrecisionType))
    if "weight_precision" in p and p["weight_precision"] not in valid:
        raise ValueError(
            f"{name}.weight_precision must be one of {sorted(valid)}, got '{p['weight_precision']}'"
        )
    if "activation_precision" in p and p["activation_precision"] not in valid:
        raise ValueError(
            f"{name}.activation_precision must be one of {sorted(valid)}, got '{p['activation_precision']}'"
        )


@dataclass
class ModulePrecisions:
    """Per-module precision configuration for mixed-precision quantization.

    Consolidates all per-module precision settings into a single dataclass.
    An entirely empty ``ModulePrecisions()`` (all None) is valid and means
    "use defaults".

    Attributes:
        lm_head: Precision settings for the language model head module.
        embedding: Precision settings for the token embedding module (``embed_tokens``).
        kv_cache: Precision settings for KV cache weights. ``weight_precision``
            is restricted to "int8" or "int16" (no int4 — AIMET API constraint).
        rms_norm: Precision settings for RMSNorm modules.
        custom: Mapping of module name or regex pattern to precision settings.
            Keys are matched first by exact module name, then by full regex match
            against all named modules (use ``.*`` for partial matching).
            Validation of module existence is deferred to apply time.

    Example:
        .. code-block:: python

            # Use int4 for lm_head, int16 for kv_cache
            mp = ModulePrecisions(
                lm_head=Precisions(weight_precision="int4"),
                kv_cache=Precisions(weight_precision="int16"),
            )

            # Custom module precision by name or regex
            mp = ModulePrecisions(
                custom={".*norm.*": Precisions(weight_precision="int8")}
            )
    """

    lm_head: Precisions | None = None
    embedding: Precisions | None = None
    kv_cache: Precisions | None = None
    rms_norm: Precisions | None = None
    custom: dict[str, Precisions] | None = None

    def __post_init__(self) -> None:
        """Validate all precision settings."""
        if self.lm_head is not None:
            _validate_precisions("lm_head", self.lm_head)
        if self.embedding is not None:
            _validate_precisions("embedding", self.embedding)
        if self.kv_cache is not None:
            _validate_precisions("kv_cache", self.kv_cache)
            if "weight_precision" in self.kv_cache and self.kv_cache["weight_precision"] == "int4":
                raise ValueError(
                    "kv_cache.weight_precision cannot be 'int4' (AIMET API constraint); use 'int8' or 'int16'"
                )
        if self.rms_norm is not None:
            _validate_precisions("rms_norm", self.rms_norm)
        if self.custom is not None:
            for key, prec in self.custom.items():
                _validate_precisions(f"custom['{key}']", prec)


class Generator(Protocol):
    """Protocol for Generator classes used in quantization.

    Generator provides static shape handling for LLM inference,
    managing KV cache and input/output transformations.
    """

    model: torch.nn.Module
    device: torch.device

    def prefill(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, ...]:
        """Prefill the KV cache with input tokens.

        Args:
            input_ids: Input token IDs.
            attention_mask: Attention mask for inputs.

        Returns:
            Tuple of output tensors (logits, *past_key_values).
        """
        ...

    def __call__(self, input_ids: torch.Tensor) -> torch.Tensor:
        """Generate next token logits.

        Args:
            input_ids: Input token IDs.

        Returns:
            Logits for next token prediction.
        """
        ...


@dataclass
class CommonParams:
    """Common configuration shared by all optimization and quantization techniques.

    Subclasses must implement `from_hf_config()` to map HuggingFace configs to AIMET params.

    Attributes:
        dataloader: DataLoader providing calibration data for computing quantization
            parameters or optimization objectives.
        dummy_inputs: Pre-assembled dummy inputs for model tracing and graph construction.
        generator: LLMGenerator instance for static shape handling in LLM inference,
            managing KV cache and input/output transformations.
        quantsim: Pre-created QuantizationSimModel for techniques that modify an
            existing quantized model.
    """

    dataloader: Optional[DataLoader] = None
    dummy_inputs: Optional[tuple[torch.Tensor, ...]] = None
    generator: Optional["LLMGenerator"] = None
    quantsim: Optional[QuantizationSimModel] = None

    @classmethod
    @abstractmethod
    def from_hf_config(cls, config: "QuantizationConfigMixin") -> "CommonParams":
        """Construct params from a HuggingFace quantization config.

        This method translates HuggingFace configuration objects (typically
        `AIMETConfigMixin` or its subclasses) into AIMET parameter objects.
        Each concrete param class must implement this to extract and validate
        the fields it needs.

        Args:
            config: A HuggingFace QuantizationConfigMixin instance containing
                configuration parameters. Typically an AIMETConfigMixin or
                technique-specific subclass (e.g., LPBQConfig, PCQConfig).

        Returns:
            A fully-populated instance of this param class with all required
            fields extracted and validated from the config.

        Raises:
            NotImplementedError: Concrete subclasses must implement this method.
            ValueError: If required config fields are missing or invalid.
            TypeError: If config fields have incorrect types.

        Example:
            .. code-block:: python

                # Concrete implementation in PCQParams
                @classmethod
                def from_hf_config(cls, config: QuantizationConfigMixin) -> "PCQParams":
                    return cls(
                        dataloader=config.dataloader,
                        dummy_inputs=config.dummy_inputs,
                        generator=config.generator,
                        lm_head_precision=config.lm_head_precision,
                    )
        """
        raise NotImplementedError


@dataclass
class SeqMSEParams(CommonParams):
    """Configuration for the SeqMSE optimizer.

    SeqMSE (Sequential Mean Squared Error) performs layer-wise optimization to
    minimize quantization error by evaluating multiple candidate weight adjustments
    per layer and selecting the optimal solution.

    Attributes:
        num_batches: Number of calibration batches for computing optimization objectives.
        num_candidates: Number of candidate weight adjustments to evaluate per layer.
    """

    num_batches: int = 20
    num_candidates: int = 20

    def __post_init__(self):
        """Validate that parameters are valid."""
        if self.num_batches <= 0:
            raise ValueError(f"num_batches must be positive, got {self.num_batches}")
        if self.num_candidates <= 0:
            raise ValueError(f"num_candidates must be positive, got {self.num_candidates}")

    @classmethod
    def from_hf_config(cls, config: "QuantizationConfigMixin") -> "SeqMSEParams":
        """Construct SeqMSEParams from a HuggingFace quantization config.

        Args:
            config: A HuggingFace QuantizationConfigMixin instance.

        Returns:
            A fully-populated SeqMSEParams instance.
        """
        return cls(
            dataloader=getattr(config, "dataloader", None),
            dummy_inputs=getattr(config, "dummy_inputs", None),
            generator=getattr(config, "generator", None),
            num_batches=getattr(config, "num_batches", 20),
            num_candidates=getattr(config, "num_candidates", 20),
        )


@dataclass
class AdaScaleParams(CommonParams):
    """Parameters for AdaScale optimization.

    AdaScale requires building an internal QuantSim to perform optimization.
    The QuantSim creation parameters are encapsulated within `pcq_params`.

    Algorithm parameters:
        num_iterations: AdaScale iterations (default 1500).
        beta_gamma_lr: Learning rate for beta/gamma (default 1e-3).
        scales_lr: Learning rate for scale params (default 5e-4).
        num_batches: Calibration batches (default 20).

    Mode control:
        is_hf_quantization:
            True (default) – HF mode: collect raw dict batches, bake
            weights, remove AIMET wrappers → OptimizationResult(quantsim=None).
            False – Prefill mode: run KV-cache prefill via generator,
            keep AIMET wrappers → OptimizationResult(quantsim=<QuantSim>).
        forward_fn: Override the default forward function passed to apply_adascale.
        device: Device on which to perform optimization (default "cuda").

    QuantSim parameters:
        pcq_params: An instance of PCQParams holding parameters needed to
            instantiate the internal QuantSim (e.g., bitwidths, tie_quantizers).
    """

    num_iterations: int = 1500
    beta_gamma_lr: float = 1e-3
    scales_lr: float = 5e-4
    num_batches: int = 20
    is_hf_quantization: bool = True
    forward_fn: Optional[Callable] = field(default=None, repr=False)
    device: str = "cuda"
    pcq_params: Optional["PCQParams"] = None

    def __post_init__(self):
        """Validate that parameters are valid."""
        if self.num_batches <= 0:
            raise ValueError(f"num_batches must be positive, got {self.num_batches}")
        if self.num_iterations <= 0:
            raise ValueError(f"num_iterations must be positive, got {self.num_iterations}")
        if self.pcq_params is None:
            raise ValueError("pcq_params must be provided for AdaScale optimization")

    @classmethod
    def from_hf_config(cls, config: Any) -> "AdaScaleParams":
        """Construct AdaScaleParams from a HuggingFace quantization config.

        Extracts both optimization-specific parameters and QuantSim-creation
        parameters, bundling the latter into a `PCQParams` object.

        Args:
            config: A HuggingFace QuantizationConfigMixin instance (e.g., AdaScaleHfConfig).

        Returns:
            A fully-populated AdaScaleParams instance.
        """
        # Consolidate fallback quantsim_kwargs for the embedded PCQParams
        quantsim_kwargs = getattr(config, "quantsim_kwargs", {}).copy()
        if "default_param_bw" not in quantsim_kwargs and hasattr(config, "default_param_bw"):
            quantsim_kwargs["default_param_bw"] = config.default_param_bw
        if "default_output_bw" not in quantsim_kwargs and hasattr(config, "default_output_bw"):
            quantsim_kwargs["default_output_bw"] = config.default_output_bw

        # Build ModulePrecisions for PCQParams if legacy keys are present
        lm_head_wp = getattr(config, "lm_head_weight_precision", None)
        kvcache_wp = getattr(config, "kvcache_weight_precision", None)
        module_precisions = getattr(config, "module_precisions", None)

        if module_precisions is None and (lm_head_wp is not None or kvcache_wp is not None):
            module_precisions = ModulePrecisions(
                lm_head=Precisions(weight_precision=lm_head_wp) if lm_head_wp is not None else None,
                kv_cache=Precisions(weight_precision=kvcache_wp) if kvcache_wp is not None else None,
            )

        try:
            pcq_params = PCQParams(
                dataloader=getattr(config, "dataloader", None),
                dummy_inputs=getattr(config, "dummy_inputs", None),
                generator=getattr(config, "generator", None),
                quantsim=getattr(config, "quantsim", None),
                quantsim_kwargs=quantsim_kwargs,
                dsp_arch=getattr(config, "dsp_arch", DspArchitecture.v79),
                tie_quantizers=getattr(config, "tie_quantizers", None) or ["concat"],
                module_precisions=module_precisions,
            )
        except (TypeError, ValueError) as e:
            raise ValueError(
                f"Failed to construct PCQParams from config: {e}. "
                f"Check that config contains valid values for quantsim_kwargs, dsp_arch, tie_quantizers, and module_precisions."
            ) from e

        return cls(
            dataloader=getattr(config, "dataloader", None),
            dummy_inputs=getattr(config, "dummy_inputs", None),
            generator=getattr(config, "generator", None),
            quantsim=getattr(config, "quantsim", None),
            num_iterations=getattr(config, "num_iterations", 1500),
            beta_gamma_lr=getattr(config, "beta_gamma_lr", 1e-3),
            scales_lr=getattr(config, "scales_lr", 5e-4),
            num_batches=getattr(config, "num_batches", 20),
            is_hf_quantization=getattr(config, "is_hf_quantization", True),
            forward_fn=getattr(config, "forward_fn", None),
            device=getattr(config, "device", "cuda"),
            pcq_params=pcq_params,
        )


@dataclass
class SpinQuantParams(CommonParams):
    """Configuration for the SpinQuant optimizer.

    SpinQuant applies rotation-based weight transformations to improve weight
    distribution for quantization. The technique uses Hadamard rotations to
    reduce outliers in weight matrices.

    Note:
        Currently has no technique-specific parameters beyond CommonParams.
    """

    @classmethod
    def from_hf_config(cls, config: "QuantizationConfigMixin") -> "SpinQuantParams":
        """Construct SpinQuantParams from a HuggingFace quantization config.

        Args:
            config: A HuggingFace QuantizationConfigMixin instance.

        Returns:
            A fully-populated SpinQuantParams instance.
        """
        return cls(
            dataloader=getattr(config, "dataloader", None),
            dummy_inputs=getattr(config, "dummy_inputs", None),
            generator=getattr(config, "generator", None),
        )


@dataclass
class OmniQuantParams(CommonParams):
    """Configuration for the OmniQuant optimizer.

    OmniQuant combines weight clipping, activation smoothing, and learnable
    equivalent transformations to jointly optimize for quantization accuracy.

    Attributes:
        num_batches: Number of calibration batches for optimization.
        num_iterations: Number of gradient descent iterations for joint optimization.
    """

    num_batches: int = 20
    num_iterations: int = 1500

    def __post_init__(self):
        """Validate that parameters are valid."""
        if self.num_batches <= 0:
            raise ValueError(f"num_batches must be positive, got {self.num_batches}")
        if self.num_iterations <= 0:
            raise ValueError(f"num_iterations must be positive, got {self.num_iterations}")

    @classmethod
    def from_hf_config(cls, config: "QuantizationConfigMixin") -> "OmniQuantParams":
        """Construct OmniQuantParams from a HuggingFace quantization config.

        Args:
            config: A HuggingFace QuantizationConfigMixin instance.

        Returns:
            A fully-populated OmniQuantParams instance.
        """
        return cls(
            dataloader=getattr(config, "dataloader", None),
            dummy_inputs=getattr(config, "dummy_inputs", None),
            generator=getattr(config, "generator", None),
            num_batches=getattr(config, "num_batches", 20),
            num_iterations=getattr(config, "num_iterations", 1500),
        )


@dataclass
class GPTAQParams(CommonParams):
    """Runtime parameters for the GPTAQ PTQ pass."""

    dataloader: Any = None
    param_bw: int = 4
    group_size: int = -1
    num_calib_batches: int = -1
    seqlen: int = 2048
    device: str = "cuda"
    qdq_weights: bool = True

    @classmethod
    def from_hf_config(cls, hf_config: Any) -> "GPTAQParams":
        return cls(
            dataloader=getattr(hf_config, "dataloader", None),
            param_bw=getattr(hf_config, "param_bw", 4),
            group_size=getattr(hf_config, "group_size", -1),
            num_calib_batches=getattr(hf_config, "num_calib_batches", -1),
            seqlen=getattr(hf_config, "seqlen", 2048),
            device=getattr(hf_config, "device", "cuda"),
            qdq_weights=getattr(hf_config, "qdq_weights", True),
        )


@dataclass
class PrefixQuantParams(CommonParams):
    """Runtime parameters for the PrefixQuant KV-cache generation pass."""

    prefix_token_ids: list[int] = field(default_factory=list)
    dummy_input: Optional[torch.Tensor] = None
    do_kvcache_save: bool = True
    output_dir: str = "."
    device: str = "cuda"
    allow_tf32: bool = False

    @classmethod
    def from_hf_config(cls, hf_config: Any) -> "PrefixQuantParams":
        return cls(
            prefix_token_ids=getattr(hf_config, "prefix_token_ids", None) or [],
            dummy_input=getattr(hf_config, "dummy_input", None),
            do_kvcache_save=getattr(hf_config, "do_kvcache_save", True),
            output_dir=getattr(hf_config, "output_dir", "."),
            device=getattr(hf_config, "device", "cuda"),
            allow_tf32=getattr(hf_config, "allow_tf32", False),
        )


T_FPArgs = TypeVar("T_FPArgs")  # Type variable for forward pass callback arguments


@dataclass
class QuantSimParams(CommonParams):
    """Base configuration for quantizers using QuantizationSimModel.

    Provides common quantization settings inherited by all quantizer parameter classes.

    Attributes:
        tie_quantizers: List of operation types that share quantization parameters.
            For example, ["concat"] ties all concat operations to use identical
            scale and offset values.
        module_precisions: Per-module precision configuration for mixed-precision
            quantization. Use ``ModulePrecisions`` to set per-module bit widths
            for lm_head, kv_cache, rms_norm, or custom modules.
        dsp_arch: DSP architecture version for HTP config selection (e.g., DspArchitecture.v79).
            Accepts a ``DspArchitecture`` enum or a string that will be validated and converted.
            Defaults to ``DspArchitecture.v79``.
        quantsim_kwargs: Additional arguments passed to QuantizationSimModel constructor.
            Only used when quantsim is None.
        forward_pass_callback: Optional custom calibration function. If provided,
            this function is called with (model, args) to perform forward passes
            instead of the default calibration routine.
    """

    tie_quantizers: list[str] = field(default_factory=lambda: ["concat"])
    module_precisions: ModulePrecisions | None = None
    dsp_arch: DspArchitecture | str = DspArchitecture.v79
    quantsim_kwargs: dict = field(default_factory=dict)
    forward_pass_callback: Optional[Callable[[torch.nn.Module, T_FPArgs], Any]] = None

    def __post_init__(self):
        """Validate that parameters are valid."""
        if self.dataloader is None:
            raise TypeError("dataloader must be provided")
        if not isinstance(self.tie_quantizers, list):
            raise TypeError(f"tie_quantizers must be a list, got {type(self.tie_quantizers).__name__}")
        if isinstance(self.dsp_arch, str):
            self.dsp_arch = DspArchitecture(self.dsp_arch)
        if self.quantsim_kwargs and self.quantsim is not None:
            raise ValueError("quantsim and quantsim kwargs cannot be set simultaneously")

    @staticmethod
    def _extract_module_precisions(config: "QuantizationConfigMixin") -> ModulePrecisions | None:
        """Extract ModulePrecisions from a HuggingFace config, with legacy key support.

        Supports legacy HF config keys ``lm_head_weight_precision`` and
        ``kvcache_weight_precision`` for backwards compatibility.

        Args:
            config: A HuggingFace QuantizationConfigMixin instance.

        Returns:
            A ModulePrecisions instance, or None if no precision config is found.
        """
        mp_from_config = getattr(config, "module_precisions", None)
        lm_wp = getattr(config, "lm_head_weight_precision", None)
        kv_wp = getattr(config, "kvcache_weight_precision", None)

        if mp_from_config is None and (lm_wp is not None or kv_wp is not None):
            return ModulePrecisions(
                lm_head=Precisions(weight_precision=lm_wp) if lm_wp else None,
                kv_cache=Precisions(weight_precision=kv_wp) if kv_wp else None,
            )
        return mp_from_config


@dataclass
class LPBQParams(QuantSimParams):
    """Configuration for the LPBQ quantizer.

    LPBQ (Learned Post-training Block Quantization) applies block-wise weight
    quantization with learned per-block scale and zero-point parameters.

    Attributes:
        block_size: Number of weights per quantization block.
        block_grouping: Number of blocks sharing quantization parameters.
        symmetric: Whether to use symmetric quantization for blockwise weights.
        decompressed_bw: Decompressed bit width used in blockwise quantization.
    """

    block_size: int = 64
    block_grouping: int = 1
    symmetric: bool = True
    decompressed_bw: int = 4

    def __post_init__(self):
        """Validate that parameters are valid."""
        super().__post_init__()
        if self.block_size <= 0:
            raise ValueError(f"block_size must be positive, got {self.block_size}")
        if self.block_grouping <= 0:
            raise ValueError(f"block_grouping must be positive, got {self.block_grouping}")

    @classmethod
    def from_hf_config(cls, config: "QuantizationConfigMixin") -> "LPBQParams":
        """Construct LPBQParams from a HuggingFace quantization config.

        Supports legacy HF config keys ``lm_head_weight_precision`` and
        ``kvcache_weight_precision`` for backwards compatibility by constructing
        a ``ModulePrecisions`` object from them.

        Args:
            config: A HuggingFace QuantizationConfigMixin instance (typically LPBQConfig).

        Returns:
            A fully-populated LPBQParams instance.
        """
        module_precisions_from_config = cls._extract_module_precisions(config)

        return cls(
            dataloader=getattr(config, "dataloader", None),
            dummy_inputs=getattr(config, "dummy_inputs", None),
            generator=getattr(config, "generator", None),
            quantsim_kwargs=getattr(config, "quantsim_kwargs", {}),
            tie_quantizers=getattr(config, "tie_quantizers", ["concat"]),
            module_precisions=module_precisions_from_config,
            dsp_arch=getattr(config, "dsp_arch", DspArchitecture.v79),
            block_size=getattr(config, "block_size", 64),
            block_grouping=getattr(config, "block_grouping", 1),
            symmetric=getattr(config, "symmetric", True),
            decompressed_bw=getattr(config, "decompressed_bw", 4),
        )


@dataclass
class PCQParams(QuantSimParams):
    """Configuration for the PCQ quantizer.

    PCQ (Post-training Calibration Quantization) uses calibration-based quantization
    without learnable parameters, computing scale and zero-point from activation
    statistics.
    """

    def __post_init__(self):
        """Validate that parameters are valid."""
        super().__post_init__()

    @classmethod
    def from_hf_config(cls, config: "QuantizationConfigMixin") -> "PCQParams":
        """Construct PCQParams from a HuggingFace quantization config.

        Supports legacy HF config keys ``lm_head_weight_precision`` and
        ``kvcache_weight_precision`` for backwards compatibility by constructing
        a ``ModulePrecisions`` object from them.

        Args:
            config: A HuggingFace QuantizationConfigMixin instance (typically PCQConfig).

        Returns:
            A fully-populated PCQParams instance.
        """
        module_precisions_from_config = cls._extract_module_precisions(config)

        return cls(
            dataloader=getattr(config, "dataloader", None),
            dummy_inputs=getattr(config, "dummy_inputs", None),
            generator=getattr(config, "generator", None),
            quantsim_kwargs=getattr(config, "quantsim_kwargs", {}),
            tie_quantizers=getattr(config, "tie_quantizers", ["concat"]),
            module_precisions=module_precisions_from_config,
            dsp_arch=getattr(config, "dsp_arch", DspArchitecture.v79),
        )


@dataclass
class OptimizationResult:
    """Result returned by optimization techniques.

    Optimizers modify model weights or structure to reduce quantization error
    without performing actual quantization.

    Attributes:
        model: The optimized torch.nn.Module with modified weights or structure.
        quantsim: Optional QuantizationSimModel created internally by some optimizers
            (AdaScale, SeqMSE, OmniQuant). Does not contain computed encodings.
        prepared_model: Optional model prepared for ONNX export with flattened structure.
    """

    model: torch.nn.Module
    quantsim: Optional[QuantizationSimModel] = None
    prepared_model: Optional[torch.nn.Module] = None


@dataclass
class QuantizationResult:
    """Result returned by quantization techniques.

    Quantizers create a QuantizationSimModel with computed encodings for
    simulating low-precision inference.

    Attributes:
        quantsim: QuantizationSimModel containing the quantized model and
            computed scale/zero-point encodings.
        prepared_model: Optional model prepared for ONNX export with flattened structure.

    Note:
        Access the quantized model via ``result.model``, which is equivalent
        to ``result.quantsim.model``.
    """

    quantsim: QuantizationSimModel
    prepared_model: Optional[torch.nn.Module] = None

    @property
    def model(self) -> torch.nn.Module:
        """Get the quantized model from the QuantizationSimModel.

        Returns:
            The quantized torch.nn.Module.
        """
        return self.quantsim.model
