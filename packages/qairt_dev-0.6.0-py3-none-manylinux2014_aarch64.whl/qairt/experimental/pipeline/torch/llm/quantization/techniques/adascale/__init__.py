# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""AdaScale optimization technique."""

from .adascale_optimizer import AdaScale, AdaScaleParams

__all__ = ["AdaScale", "AdaScaleParams"]
