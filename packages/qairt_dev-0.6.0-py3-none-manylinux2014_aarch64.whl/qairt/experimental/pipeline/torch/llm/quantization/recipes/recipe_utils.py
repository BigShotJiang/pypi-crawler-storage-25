# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""Utility helpers shared across quantization recipe modules."""

from itertools import islice
from typing import Any, Dict, Optional, Tuple

import yaml

from qairt.utils.loggers import get_logger

logger = get_logger(__name__)

_REQUIRED_GLOBAL_KEYS = ["device", "output_dir", "seqlen"]


def validate_and_prepare_dataloader(dataloader: Any, opt_name: str, max_samples: Optional[int] = None) -> Any:
    """Validate *dataloader* and materialise iterator-based dataloaders to a list.

    Args:
        dataloader: The dataloader to validate.
        opt_name: Caller name used in error messages.
        max_samples: Cap on samples when materialising an iterator (``None`` = no limit).
    """
    if dataloader is None:
        raise ValueError(f"{opt_name} requires a dataloader but none was provided")

    if not hasattr(dataloader, "__iter__") and not hasattr(dataloader, "__getitem__"):
        raise ValueError(f"Invalid dataloader for {opt_name}: '{type(dataloader).__name__}' is not iterable.")

    try:
        if hasattr(dataloader, "__len__"):
            if len(dataloader) == 0:
                raise ValueError(f"Dataloader for {opt_name} is empty")
            return dataloader
        else:
            items = list(islice(dataloader, max_samples))
            if not items:
                raise ValueError(f"Dataloader for {opt_name} is empty")
            logger.warning(
                f"[{opt_name}] Iterator-based dataloader converted to list "
                f"({len(items)} samples). Consider using a DataLoader with __len__."
            )
            return items
    except ValueError:
        raise
    except Exception as e:
        raise ValueError(f"Invalid dataloader for {opt_name}: {e}. Must be iterable and non-empty.") from e


def load_and_validate_yaml(
    yaml_path: str,
    dataloader: Optional[Any] = None,
) -> Tuple[Dict[str, Any], Dict[str, Any], Any]:
    """Load a YAML recipe file, validate its structure and required global keys,
    and prepare the dataloader.

    Args:
        yaml_path: Path to the YAML recipe file.
        dataloader: Optional dataloader to validate and materialise.

    Returns:
        ``(cfg, global_cfg, prepared_dataloader)``
    """
    try:
        with open(yaml_path, "r") as f:
            cfg = yaml.safe_load(f)
    except (OSError, yaml.YAMLError) as e:
        raise ValueError(f"Failed to load YAML '{yaml_path}': {e}") from e

    if not cfg or "global" not in cfg or not isinstance(cfg.get("recipe"), list):
        raise ValueError(f"YAML '{yaml_path}' must contain non-empty 'global' and 'recipe' (list) sections")

    global_cfg = cfg["global"]
    missing = [k for k in _REQUIRED_GLOBAL_KEYS if k not in global_cfg]
    if missing:
        raise ValueError(f"Missing required global config keys: {missing}")

    # Validate once; iterator-based dataloaders are materialised to a list so all
    # steps share the same samples without re-consuming the iterator.
    if dataloader is not None:
        dataloader = validate_and_prepare_dataloader(dataloader, "from_yaml")

    return cfg, global_cfg, dataloader
