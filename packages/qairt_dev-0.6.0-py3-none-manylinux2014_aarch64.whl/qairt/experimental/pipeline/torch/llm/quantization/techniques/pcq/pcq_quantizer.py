# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""PCQ (Post-training Calibration Quantization) quantizer implementation."""

import importlib.resources
from typing import Any, Type

import torch
from aimet_torch.common.defs import QuantScheme
from aimet_torch.v2.quantsim import QuantizationSimModel

from qairt.api.configs.common import DspArchitecture
from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.aimet_quantizer import (
    AIMETQuantizer,
)
from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.definitions import (
    ModulePrecisions,
    PCQParams,
    Precisions,
    QuantizationResult,
    QuantSimParams,
)
from qairt.utils.loggers import get_logger

logger = get_logger(__name__)


def _get_htp_config_path(dsp_arch: DspArchitecture) -> str:
    """Get the path to the HTP quantization config file from the AIMET package.

    Args:
        dsp_arch: DSP architecture version selecting the HTP config file.

    Returns:
        Path to the HTP quantsim config file.
    """
    config_filename = f"htp_quantsim_config_{dsp_arch.value}.json"
    return str(importlib.resources.files("aimet_torch.common.quantsim_config").joinpath(config_filename))


class PCQQuantizer(AIMETQuantizer):
    """PCQ (Post-training Calibration Quantization) quantizer.

    PCQ uses calibration data to compute quantization encodings (scale and
    zero-point) without any learnable parameters. It is the simplest and
    fastest quantization technique.

    Example:
        .. code-block:: python

            from qairt.experimental.pipeline.torch.llm.quantization.techniques.pcq import (
                PCQQuantizer,
            )
            from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.definitions import (
                PCQParams,
            )

            quantizer = PCQQuantizer(model, context_length=2048, sequence_length=128)
            result = quantizer.quantize(
                params=PCQParams(
                    dataloader=calibration_loader,
                    module_precisions=ModulePrecisions(lm_head=Precisions(weight_precision="int8")),
                )
            )
    """

    _name = "PCQ"

    @classmethod
    def params_cls(cls) -> Type[QuantSimParams]:
        """Return the parameter class for PCQ quantization.

        Returns:
            The PCQParams class.
        """
        return PCQParams

    @classmethod
    def _create_quantsim(  # type: ignore[override]
        cls,
        model: torch.nn.Module,
        assembled_dummy_inputs: tuple[torch.Tensor, ...],
        tie_quantizers: list[str] | None = None,
        module_precisions: ModulePrecisions | None = None,
        dsp_arch: DspArchitecture = DspArchitecture.v79,
        quantsim_kwargs: dict[str, Any] | None = None,
    ) -> QuantizationSimModel:
        """Create a QuantizationSimModel configured for PCQ.

        Args:
            model: The prepared PyTorch model.
            assembled_dummy_inputs: Dummy inputs for model tracing.
            tie_quantizers: Op types whose output encodings should be propagated
                (e.g., ``["concat"]``).
            module_precisions: Per-module precision configuration. Use
                ``ModulePrecisions`` to set per-module bit widths for lm_head,
                kv_cache, rms_norm, or custom modules.
            dsp_arch: DSP architecture version to select the HTP quantsim config file.
                Defaults to ``DspArchitecture.v79``.
            quantsim_kwargs: Additional overrides for QuantizationSimModel constructor.
                Supported keys: ``quant_scheme``, ``default_output_bw``, ``default_param_bw``,
                ``in_place``, ``default_data_type``. ``model`` and ``dummy_input`` are reserved
                and will raise ``ValueError`` if provided.

        Returns:
            A configured QuantizationSimModel.

        Raises:
            ValueError: If ``dummy_input`` is in ``quantsim_kwargs``, if unknown keys are
                present in ``quantsim_kwargs``, or if ``model`` is provided in ``quantsim_kwargs``.
        """
        kwargs = dict(quantsim_kwargs or {})

        if "dummy_input" in kwargs:
            raise ValueError("'dummy_input' cannot be provided in quantsim_kwargs. It is a fixed argument.")

        # Extract known quantsim kwargs
        quant_scheme = kwargs.pop("quant_scheme", QuantScheme.post_training_tf)
        default_output_bw = kwargs.pop("default_output_bw", 16)
        default_param_bw = kwargs.pop("default_param_bw", 8)
        in_place = kwargs.pop("in_place", True)
        default_data_type = kwargs.pop("default_data_type", None)

        # Raise on any remaining unknown kwargs
        if kwargs:
            unknown_keys = ", ".join(kwargs.keys())
            raise ValueError(f"Unknown quantsim_kwargs: {unknown_keys}")

        config_file = _get_htp_config_path(dsp_arch)

        # Align AIMET's internal logger level to the qairt logger level
        from aimet_torch.common.utils import AimetLogger

        AimetLogger.set_level_for_all_areas(logger.getEffectiveLevel())

        quantsim_args: dict[str, Any] = {
            "model": model,
            "dummy_input": assembled_dummy_inputs,
            "quant_scheme": quant_scheme,
            "default_output_bw": default_output_bw,
            "default_param_bw": default_param_bw,
            "in_place": in_place,
            "config_file": config_file,
        }
        if default_data_type is not None:
            quantsim_args["default_data_type"] = default_data_type

        quantsim = QuantizationSimModel(**quantsim_args)

        if tie_quantizers:
            from aimet_torch.nn.modules import custom as aimet_ops
            from aimet_torch.v2.experimental import propagate_output_encodings

            for op_type in tie_quantizers:
                op_type_lower = op_type.lower()
                if op_type_lower == "concat":
                    propagate_output_encodings(quantsim, aimet_ops.Concat)
                elif hasattr(aimet_ops, op_type):
                    propagate_output_encodings(quantsim, getattr(aimet_ops, op_type))
                else:
                    logger.warning("Unknown op type for tie_quantizers: %s", op_type)

        cls._apply_module_precisions(quantsim, module_precisions)

        return quantsim

    def quantize(
        self,
        params: QuantSimParams,
    ) -> QuantizationResult:
        """Quantize the model using post-training calibration.

        Args:
            params: PCQ configuration (must be a ``PCQParams`` instance) including
                dataloader, precision settings, and optional quantsim overrides.

        Returns:
            QuantizationResult with the calibrated QuantizationSimModel.

        Raises:
            TypeError: If ``params`` is not a ``PCQParams`` instance.
            ValueError: If ``params.dataloader`` is None.
        """
        if not isinstance(params, PCQParams):
            raise TypeError(f"Expected PCQParams, got {type(params).__name__}")

        if params.dataloader is None:
            raise ValueError("dataloader is required for PCQ quantization")

        if self.prepared_model is None:
            self._prepare_model(generator=params.generator)

        assembled_dummy_inputs = self._prepare_inputs(dummy_inputs=params.dummy_inputs)

        assert self.prepared_model is not None
        assert isinstance(params.dsp_arch, DspArchitecture)

        quantsim = params.quantsim or self._create_quantsim(
            self.prepared_model,
            assembled_dummy_inputs,
            tie_quantizers=params.tie_quantizers,
            module_precisions=params.module_precisions,
            dsp_arch=params.dsp_arch,
            quantsim_kwargs=params.quantsim_kwargs,
        )

        self._compute_encodings(
            quantsim,
            params.dataloader,
            forward_pass_callback=params.forward_pass_callback,
        )

        self.quantsim = quantsim

        return QuantizationResult(
            quantsim=quantsim,
            prepared_model=self.prepared_model,
        )
