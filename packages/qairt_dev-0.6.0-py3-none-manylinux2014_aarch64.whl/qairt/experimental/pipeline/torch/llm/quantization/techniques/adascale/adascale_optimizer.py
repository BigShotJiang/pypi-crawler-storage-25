# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""AdaScale optimizer – main entry point."""

from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Type

import torch
from aimet_torch.common.defs import QuantScheme
from aimet_torch.experimental.adascale.adascale_optimizer import apply_adascale
from aimet_torch.utils import change_tensor_device_placement, place_model
from aimet_torch.v2.quantsim import QuantizationSimModel
from torch.utils.data import DataLoader

from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.aimet_optimizer import (
    AIMETOptimizer,
)
from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.definitions import (
    AdaScaleParams,
    CommonParams,
    OptimizationResult,
)
from qairt.experimental.pipeline.torch.llm.quantization.techniques.pcq import PCQQuantizer
from qairt.utils.loggers import get_logger

from .adascale_utils import (
    _patch_inner_model_for_return_dict,
    collect_calibration_data,
    make_hf_forward_fn,
    prefill_inputs,
    restore_model_config,
)

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# AdaScale
# ---------------------------------------------------------------------------


class AdaScale(AIMETOptimizer):
    """AdaScale optimizer.

    Supports two operating modes via ``AdaScaleParams.is_hf_quantization``:

    **HF mode** (``True``, default)
        Raw dict batches → ``apply_adascale`` → bake weights → remove wrappers
        → ``OptimizationResult(quantsim=None)``  (clean HF model).

    **Prefill mode** (``False``)
        KV-cache prefill via ``generator`` → ``apply_adascale``
        → ``OptimizationResult(quantsim=<QuantSim>)``  (AIMET wrappers intact).

    QuantSim is always created via ``PCQQuantizer`` regardless of mode.
    See ``adascale_utils.py`` for the implementation of each helper step.
    """

    _name = "AdaScale"

    @classmethod
    def params_cls(cls) -> Type[CommonParams]:
        return AdaScaleParams

    def _create_quantsim(
        self,
        model: torch.nn.Module,
        device: str,
        pcq_params: Any,
    ):
        """Create a ``QuantizationSimModel`` via ``PCQQuantizer``.

        Temporarily patches ``model.config.return_dict`` and
        ``model.config.use_cache`` for AIMET Tracer compatibility, then restores
        ``use_cache`` immediately after the QuantSim is built.
        ``return_dict`` is returned to the caller for deferred restoration.

        Returns:
            Tuple of ``(quantsim, original_return_dict)``.
        """
        if pcq_params is None:
            raise ValueError("pcq_params cannot be None")

        # Resolve dummy inputs with validation
        dummy_inputs = pcq_params.dummy_inputs
        if dummy_inputs is not None:
            dummy_inputs = change_tensor_device_placement(dummy_inputs, device)
            # Validate dummy_inputs structure
            if not isinstance(dummy_inputs, (tuple, list)) or len(dummy_inputs) == 0:
                raise ValueError("dummy_inputs must be a non-empty tuple or list of tensors")
            logger.debug(f"[AdaScale] Using user-provided dummy_inputs with shape {dummy_inputs[0].shape}")
        else:
            # Auto-create with reasonable defaults
            seq_len = getattr(pcq_params, "seqlen", 128)
            dummy_inputs = (torch.zeros((1, seq_len), dtype=torch.int32).to(device),)
            logger.debug(f"[AdaScale] Auto-created dummy_inputs with shape {dummy_inputs[0].shape}")

        # Patch model config for AIMET Tracer compatibility
        original_return_dict = None
        original_use_cache = None
        if hasattr(model, "config"):
            if hasattr(model.config, "return_dict"):
                original_return_dict = model.config.return_dict
                model.config.return_dict = False
                logger.debug(
                    f"[AdaScale] Patched model.config.return_dict=False (was {original_return_dict})"
                )
            if hasattr(model.config, "use_cache"):
                original_use_cache = model.config.use_cache
                model.config.use_cache = False
                logger.debug("[AdaScale] Patched model.config.use_cache=False")

        quantsim_kwargs = (pcq_params.quantsim_kwargs or {}).copy()
        if "quant_scheme" not in quantsim_kwargs:
            quantsim_kwargs["quant_scheme"] = QuantScheme.post_training_tf
        if "in_place" not in quantsim_kwargs:
            quantsim_kwargs["in_place"] = True
        if "default_param_bw" not in quantsim_kwargs:
            quantsim_kwargs["default_param_bw"] = 4
        if "default_output_bw" not in quantsim_kwargs:
            quantsim_kwargs["default_output_bw"] = 16

        # Patch inner backbone to always return ModelOutput so that CausalLM wrappers
        # can access outputs.last_hidden_state (transformers>=4.57.0 compatibility).
        with _patch_inner_model_for_return_dict(model), place_model(model, device), torch.no_grad():
            quantsim = PCQQuantizer._create_quantsim(
                model,
                dummy_inputs,
                tie_quantizers=pcq_params.tie_quantizers,
                module_precisions=pcq_params.module_precisions,
                dsp_arch=pcq_params.dsp_arch,
                quantsim_kwargs=quantsim_kwargs,
            )

            if quantsim is None:
                raise RuntimeError(
                    "Failed to create QuantizationSimModel. "
                    "Check PCQParams configuration and model compatibility."
                )

        # Restore use_cache immediately; return_dict is restored after apply_adascale
        if original_use_cache is not None and hasattr(model, "config"):
            model.config.use_cache = original_use_cache
            logger.debug(f"[AdaScale] Restored model.config.use_cache={original_use_cache}")

        logger.info(
            f"[AdaScale] QuantSim created (param_bw={quantsim_kwargs.get('default_param_bw')}, "
            f"output_bw={quantsim_kwargs.get('default_output_bw')})"
        )
        return quantsim, original_return_dict

    @torch.no_grad()
    def apply(self, params: AdaScaleParams) -> OptimizationResult:
        """Apply AdaScale optimisation.

        Args:
            params: ``AdaScaleParams`` instance.

        Returns:
            ``OptimizationResult`` – ``quantsim=None`` in HF mode,
            ``quantsim=<QuantSim>`` in Prefill mode.

        Raises:
            TypeError:  ``params`` is not ``AdaScaleParams``.
            ValueError: ``params.dataloader`` is ``None``.
            ValueError: ``is_hf_quantization=False`` but ``generator`` is ``None``.
        """
        if not isinstance(params, AdaScaleParams):
            raise TypeError(f"Expected AdaScaleParams, got {type(params).__name__}")
        if params.dataloader is None:
            raise ValueError("AdaScaleParams.dataloader must be set before calling apply().")
        if params.pcq_params is None:
            raise ValueError(
                "AdaScaleParams.pcq_params must be provided. "
                "PCQParams are required to create the internal QuantSim for AdaScale optimization."
            )

        # Validate generator interface BEFORE preparing model
        if not params.is_hf_quantization:
            if params.generator is None:
                raise ValueError("AdaScaleParams.generator is required when is_hf_quantization=False.")

        if self.prepared_model is None:
            self._prepare_model()
        model = self.prepared_model
        assert model is not None, "prepared_model must not be None after _prepare_model()"

        logger.info("[AdaScale] Starting optimization...")

        # Step 1: Create QuantSim
        logger.debug("[AdaScale Step 1/4] Creating QuantizationSimModel...")
        quantsim, original_return_dict = self._create_quantsim(model, params.device, params.pcq_params)
        logger.debug("[AdaScale Step 1/4] QuantSim created successfully")

        # Step 2: Collect calibration data based on mode
        logger.debug(f"[AdaScale Step 2/4] Collecting calibration data (max {params.num_batches} batches)...")
        if params.is_hf_quantization:
            inputs = collect_calibration_data(params.dataloader, params.num_batches)
            forward_fn = params.forward_fn or make_hf_forward_fn()
        else:
            inputs = prefill_inputs(
                params.generator, params.dataloader, params.num_batches, torch.device(params.device)
            )
            forward_fn = params.forward_fn or (lambda m, inp: m(*inp))

        if not inputs:
            raise ValueError("[AdaScale] No calibration data collected – check dataloader.")
        logger.debug(f"[AdaScale Step 2/4] Collected {len(inputs)} calibration samples")

        # Step 3: Run AdaScale
        logger.debug(f"[AdaScale Step 3/4] Running AdaScale (iterations={params.num_iterations})...")
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False

        apply_adascale(
            qsim=quantsim,
            data_loader=inputs,
            num_iterations=params.num_iterations,
            forward_fn=forward_fn,
        )
        logger.debug("[AdaScale Step 3/4] AdaScale optimization completed")

        # Step 4: Post-processing based on mode
        if params.is_hf_quantization:
            logger.debug("[AdaScale Step 4/4] Baking quantization parameters and removing wrappers...")

            QuantizationSimModel._apply_qdq_to_model_parameters(model)
            QuantizationSimModel._remove_quantization_wrappers(model, list(model.modules()))
            restore_model_config(model, original_return_dict)
            logger.info("[AdaScale] Completed! Model restored to standard HF format.")
            return OptimizationResult(model=model, quantsim=None, prepared_model=model)
        else:
            logger.debug("[AdaScale Step 4/4] Keeping QuantSim wrappers for Prefill mode...")
            restore_model_config(model, original_return_dict)
            logger.info("[AdaScale] Completed! QuantSim returned with wrappers intact.")
            return OptimizationResult(model=quantsim.model, quantsim=quantsim, prepared_model=model)
