# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Interface classes for AIMET quantization and optimization techniques"""

import itertools
import os
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Callable, Optional, Type, TypeVar

import torch
from aimet_torch.v2.quantsim import QuantizationSimModel
from torch.utils.data import DataLoader
from transformers import AutoTokenizer

from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.definitions import (
    ModulePrecisions,
    Precisions,
    QuantizationResult,
    QuantSimParams,
)
from qairt.experimental.pipeline.torch.llm.quantization.utils.model_preparation import (
    prepare_llm,
)
from qairt.utils.loggers import get_logger

from .aimet_mixin import AIMETMixin

if TYPE_CHECKING:
    from qairt.experimental.pipeline.torch.llm.generation.generator import (
        LLMGenerator,
    )

logger = get_logger("AIMETQuantizer")


QuantizerParams = TypeVar("QuantizerParams", bound=QuantSimParams)


def _parse_bitwidth(precision_str: str) -> int:
    """Extract the numeric bitwidth from a precision string like "int8".

    Args:
        precision_str: A precision string (e.g., "int4", "int8", "int16").

    Returns:
        The numeric bitwidth.

    Raises:
        ValueError: If the precision string does not start with "int".
    """
    if not precision_str.startswith("int"):
        raise ValueError(
            f"Unsupported precision format '{precision_str}'; expected 'int<N>' (e.g., 'int4', 'int8', 'int16')"
        )
    numeric_part = precision_str[3:]
    if not numeric_part.isdigit():
        raise ValueError(
            f"Invalid numeric value in precision string '{precision_str}'; expected 'int<N>' where N is a positive integer"
        )
    return int(numeric_part)


def _set_module_precisions(module: torch.nn.Module, precisions: Precisions) -> None:
    """Apply weight and/or activation precision to a single quantized module.

    Args:
        module: The quantized module to configure.
        precisions: Precision settings to apply.
    """
    # TODO: needs logging every time a precision is set
    if "weight_precision" in precisions:
        bw = _parse_bitwidth(precisions["weight_precision"])
        if hasattr(module, "param_quantizers") and "weight" in module.param_quantizers:
            module.param_quantizers["weight"].bitwidth = bw
            logger.debug(f"Changed weight precision to {bw} bits for module {module.__class__.__name__}")
    if "activation_precision" in precisions:
        bw = _parse_bitwidth(precisions["activation_precision"])
        if hasattr(module, "output_quantizers"):
            for q in module.output_quantizers:
                if q is not None:
                    q.bitwidth = bw
                    logger.debug(
                        f"Changed activation precision to {bw} bits for module {module.__class__.__name__}"
                    )


class AIMETQuantizer(AIMETMixin, ABC):
    """Base class for AIMET quantization techniques.

    A quantizer converts a model from high precision (float32) to low precision
    (like int8) to make it faster and smaller. This is the final step after
    optimization.

    What quantizers do:
        Quantizers create a QuantizationSimModel that simulates how your model will
        behave at lower precision. They compute "encodings" (scale and offset values)
        that determine how to convert between float and integer representations.

    How to use quantizers:
        After optimizing your model (optional), pass it to a quantizer. The quantizer
        will calibrate using your data and return a quantized model ready for export.

    Example:
        .. code-block:: python

            from qairt.gen_ai_api.experimental.pipeline.llm.quantization.torch.techniques.params import (
                LPBQParams
            )

            # Create quantizer with your model
            quantizer = LPBQ_Quantizer(model, tokenizer)

            # Quantize the model
            result = quantizer.quantize(
                params=LPBQParams(
                    dataloader=calibration_data,
                    module_precisions=ModulePrecisions(kv_cache=Precisions(weight_precision="int16")),
                )
            )

            # Access the quantized model
            quantsim = result.quantsim
    """

    _requires_data: bool = True
    _requires_calibration: bool = True
    _requires_generation = True

    def __init__(
        self,
        hf_model: torch.nn.Module,
        context_length: int | None,
        sequence_length: int | None,
        tokenizer: AutoTokenizer | None = None,
    ):
        """Initialize the quantizer.

        Args:
            hf_model: The PyTorch model to quantize (typically from HuggingFace).
            context_length: Maximum number of tokens the model can process at once.
                Set to None if your model doesn't need a fixed context length.
                Required for quantizers since they need to generate text and calibrate.
            sequence_length: Length of input sequences for testing the model.
                Set to None if your model doesn't need a fixed sequence length.
                Required for quantizers since they need to generate text and calibrate.
            tokenizer: The tokenizer that converts text to tokens for your model.
                Optional, but needed for most quantizers.
        """
        super().__init__(hf_model, context_length, sequence_length, tokenizer)
        self._quantsim = None

    @property
    def quantsim(self) -> QuantizationSimModel | None:
        """Get the quantized model.

        Returns:
            The QuantizationSimModel containing the quantized model and encodings,
            or None if quantization hasn't been performed yet.
        """
        return self._quantsim

    @quantsim.setter
    def quantsim(self, value: QuantizationSimModel | None):
        """Set the quantized model.

        Args:
            value: The QuantizationSimModel to store, or None to clear it.
        """
        self._quantsim = value

    @classmethod
    @abstractmethod
    def params_cls(cls) -> Type[QuantSimParams]:
        """Return the QuantSimParams subclass this quantizer expects.

        Concrete quantizers (PCQ, LPBQ, etc.) must implement this to declare
        the param type they accept in `quantize()`. This allows HF adapters to
        dynamically determine which param class to instantiate via `from_hf_config()`.

        Returns:
            A QuantSimParams subclass (e.g., PCQParams, LPBQParams).

        Example:
            .. code-block:: python

                class PCQQuantizer(AIMETQuantizer):
                    @classmethod
                    def params_cls(cls) -> Type[QuantSimParams]:
                        return PCQParams
        """
        raise NotImplementedError

    def _prepare_model(
        self,
        generator: "LLMGenerator | None" = None,
        **kwargs: Any,
    ) -> None:
        """Prepare the model for quantization.

        This method transforms the model to make it ready for quantization. When
        a generator is provided, the model preparer pipeline is run:

        1. Exports the model to ONNX format
        2. Converts to QNN IR (intermediate representation) with optimizations
        3. Converts back to PyTorch as a "prepared" model

        When no generator is provided, the original HF model is used directly.

        Args:
            generator: An ``LLMGenerator`` instance that provides the
                model's IO configuration, dummy inputs, and input/output names.
                If ``None``, the model preparer is skipped.
            **kwargs: Additional arguments forwarded to ``prepare_llm()``
                (e.g. ``onnx_export_args``, ``filename``, ``model_name``).
                Pass ``path=<dir>`` to retain preparation artifacts on disk;
                if omitted, artifacts are written to a temporary directory
                and cleaned up automatically.

        Note:
            This sets ``self.prepared_model`` to the prepared version of the model.
            If ``path`` is passed via ``kwargs``, preparation artifacts are written
            there and retained. Otherwise a temporary directory is used and cleaned
            up automatically.
        """

        assert self.hf_model is not None, "hf_model must be set before preparing the model"

        if generator is None:
            self.prepared_model = self.hf_model
            return

        self.prepared_model = prepare_llm(
            generator=generator,  # type: ignore[arg-type]
            **kwargs,
        )

    @classmethod
    @abstractmethod
    def _create_quantsim(
        cls,
        model: torch.nn.Module,
        assembled_dummy_inputs: tuple[torch.Tensor, ...],
        **kwargs,
    ) -> QuantizationSimModel:
        """Create a quantization simulation model.

        This method creates a QuantizationSimModel that simulates how the model
        will behave at lower precision. It configures the bit widths (precision)
        for weights and activations.

        Args:
            model: The prepared PyTorch model to quantize.
            assembled_dummy_inputs: Example inputs used to trace the model and
                determine which operations need quantization.
            **kwargs: Additional configuration options for the QuantizationSimModel,
                such as bit widths, quantization schemes, etc.

        Returns:
            A QuantizationSimModel ready for calibration.
        """
        ...

    @classmethod
    def _apply_module_precisions(
        cls,
        quantsim: QuantizationSimModel,
        config: str | dict[str, Precisions] | ModulePrecisions | None = None,
    ) -> None:
        """Apply per-module precision settings to the quantized model.

        Dispatches based on the type of ``config``:

        - ``str``: Load from config file (not yet implemented).
        - ``dict[str, Precisions]``: Treat as a flat custom mapping (module name
          or regex → Precisions); same logic as ``ModulePrecisions.custom``.
        - ``ModulePrecisions``: Resolves all semantic fields (lm_head, embedding,
          kv_cache, rms_norm) and custom entries into a single flat mapping, then
          applies them in one pass. Special AIMET APIs (e.g., kv_cache int8
          weight precision) are applied as a pre-step.
        - ``None``: No-op.

        Args:
            quantsim: The QuantizationSimModel to configure.
            config: Precision configuration. See above for dispatch rules.

        Raises:
            NotImplementedError: If ``config`` is a ``str`` (file-based config not yet supported).
            TypeError: If ``config`` is not a supported type.
            ValueError: If a non-regex key in ``custom`` does not match any module.
        """
        if config is None:
            return

        if isinstance(config, str):
            raise NotImplementedError(
                "File-based module precision config is not yet supported. "
                "Pass a ModulePrecisions instance or a dict[str, Precisions] instead."
            )

        # Cache named_modules to avoid redundant traversals
        named_modules = dict(quantsim.model.named_modules())

        if isinstance(config, dict):
            cls._apply_custom_precisions(quantsim, config, named_modules)
            return

        if not isinstance(config, ModulePrecisions):
            raise TypeError(f"Unsupported config type: {type(config)}")

        # --- Special AIMET API calls that don't fit the regex→precision pattern ---
        if config.kv_cache is not None:
            wp = config.kv_cache.get("weight_precision")
            if wp == "int8":
                from aimet_torch.v2.experimental.quantsim_utils import (
                    set_matmul_second_input_producer_to_8bit_symmetric,
                )

                set_matmul_second_input_producer_to_8bit_symmetric(quantsim)

        # --- Resolve all fields into a single flat dict, then apply once ---
        merged = cls._resolve_precisions(quantsim.model, config)
        if merged:
            cls._apply_custom_precisions(
                quantsim, merged, named_modules
            )  # TODO: change name to apply_precisions

    @classmethod
    def _resolve_precisions(
        cls,
        model: torch.nn.Module,
        config: ModulePrecisions,
        named_modules: dict[str, torch.nn.Module] | None = None,
    ) -> dict[str, Precisions]:
        """Resolve a ``ModulePrecisions`` into a flat module-name/regex → Precisions mapping.

        Semantic fields (``lm_head``, ``embedding``, ``kv_cache``, ``rms_norm``) are
        translated into concrete module names or regex patterns. ``custom`` entries
        are merged last so they can override semantic defaults.

        Args:
            model: The underlying model (``quantsim.model``) used to discover
                module names for rms_norm resolution.
            config: The high-level precision configuration.
            named_modules: List of named modules to traverse

        Returns:
            A flat dict mapping module names or regex patterns to Precisions.
        """
        merged: dict[str, Precisions] = {}

        if named_modules is None:
            named_modules = dict(model.named_modules())

        # TODO: map config setting to re or name so user can easily override
        # Maybe add a match_strategy to precision. Could be string match or callable?

        if config.lm_head is not None:
            merged["lm_head"] = config.lm_head

        if config.embedding is not None:
            # Support both HF CausalLM (model.embed_tokens) and flat (embed_tokens) structures
            if hasattr(model, "model") and hasattr(model.model, "embed_tokens"):
                merged["model.embed_tokens"] = config.embedding
            elif hasattr(model, "embed_tokens"):
                merged["embed_tokens"] = config.embedding

        if config.kv_cache is not None:
            # kv_cache weight_precision "int8" is handled via special AIMET API in
            # _apply_module_precisions; only activation_precision flows through here.
            if "activation_precision" in config.kv_cache:
                merged[".*k_proj.*|.*v_proj.*|.*qkv_proj.*"] = Precisions(
                    activation_precision=config.kv_cache["activation_precision"]
                )

        if config.rms_norm is not None:
            for name, module in named_modules.items():
                if "rmsnorm" in type(module).__name__.lower():
                    merged[name] = config.rms_norm

        # custom entries override semantic defaults
        if config.custom is not None:
            merged.update(config.custom)

        return merged

    @classmethod
    def _apply_custom_precisions(
        cls,
        quantsim: QuantizationSimModel,
        custom: dict[str, Precisions],
        named_modules: dict[str, torch.nn.Module] | None = None,
    ) -> None:
        """Apply custom per-module precision settings by name or regex.

        For each key in ``custom``, tries exact attribute match on ``quantsim.model``
        first, then exact name match in ``named_modules``, then falls back to
        **full** regex matching (``re.fullmatch``) against all named modules.
        Use ``.*`` wildcards for partial matching (e.g., ``".*k_proj.*"``).

        Args:
            quantsim: The QuantizationSimModel to configure.
            custom: Mapping of module name or regex pattern to Precisions.

        Raises:
            ValueError: If a key does not match any module.
        """
        import re

        if named_modules is None:
            named_modules = dict(quantsim.model.named_modules())
        # TODO: Log all matches

        for key, prec in custom.items():
            # Try exact attribute match first
            if hasattr(quantsim.model, key):
                _set_module_precisions(getattr(quantsim.model, key), prec)
                continue

            # Try exact name match in named_modules
            if key in named_modules:
                _set_module_precisions(named_modules[key], prec)
                continue

            # Try full regex match
            matched = False
            try:
                pattern = re.compile(key)
                for mod_name, module in named_modules.items():
                    if pattern.fullmatch(mod_name):
                        _set_module_precisions(module, prec)
                        matched = True
            except re.error as e:
                logger.warning("Invalid regex pattern '%s': %s", key, e)

            if not matched:
                raise ValueError(
                    f"module_precisions: no module matched key '{key}'. "
                    "Provide an exact module name or a valid regex pattern "
                    "(uses fullmatch — use '.*' for partial matching)."
                )

    @abstractmethod
    def quantize(
        self,
        params: QuantizerParams,
    ) -> QuantizationResult:
        """Quantize the model to lower precision.

        This is the main method you call to quantize your model. It creates a
        QuantizationSimModel, calibrates it using your data, and computes the
        encodings needed for quantization.

        Args:
            params: Configuration for this quantization technique. Each quantizer has
                its own parameter class (like LPBQParams, PCQParams) that inherits from
                QuantSimParams. The params object includes:

                - Common parameters: dataloader, dummy_inputs, generator
                - Quantizer parameters: tie_quantizers, module_precisions
                - Technique-specific parameters: block_size, etc.

        Returns:
            QuantizationResult containing:
                - quantsim: The QuantizationSimModel with computed encodings
                - model: Shortcut to quantsim.model
                - prepared_model: Model prepared for export

        Example:
            .. code-block:: python

                from qairt.gen_ai_api.experimental.pipeline.llm.quantization.torch.techniques.params import (
                    LPBQParams
                )

                # Create quantizer
                quantizer = LPBQ_Quantizer(model, tokenizer)

                # Configure and run quantization
                result = quantizer.quantize(
                    params=LPBQParams(
                        dataloader=calibration_data,
                        module_precisions=ModulePrecisions(kv_cache=Precisions(weight_precision="int16")),
                    )
                )

                # Access the quantized model
                quantsim = result.quantsim
        """
        ...

    def _compute_encodings(
        self,
        quantsim: QuantizationSimModel,
        dataloader: DataLoader,
        num_batches: int | None = None,
        forward_pass_callback: Callable[[torch.nn.Module, Any], Any] | None = None,
    ) -> None:
        """Compute quantization encodings using calibration data.

        Encodings are the scale and offset values that determine how to convert
        between floating point and integer representations. This method runs
        calibration data through the model to compute optimal encodings.

        Args:
            quantsim: The QuantizationSimModel to calibrate.
            dataloader: Source of calibration data.
            num_batches: How many batches of calibration data to use.
                If None, uses all available data.
            forward_pass_callback: Optional custom function to run forward passes.
                If provided, this function is called instead of the default
                calibration process. Signature: ``(model, args) -> Any``.
        """
        if forward_pass_callback is not None:
            quantsim.compute_encodings(forward_pass_callback)
            return

        def _default_callback(model: torch.nn.Module, _: Any = None) -> None:
            batches = itertools.islice(dataloader, num_batches) if num_batches else dataloader
            with torch.no_grad():
                for batch in batches:
                    if isinstance(batch, dict):
                        input_ids = batch["input_ids"]
                    else:
                        input_ids = batch
                    model(input_ids)

        quantsim.compute_encodings(_default_callback)

    def export(
        self,
        export_path: str,
        filename_prefix: str = "model",
        dummy_inputs: Optional[tuple[torch.Tensor, ...]] = None,
        **export_kwargs: Any,
    ) -> None:
        """Export the quantized model to disk.

        Args:
            export_path: Directory where the model files will be saved.
            filename_prefix: Name prefix for the exported files. Defaults to "model".
            dummy_inputs: Pre-created dummy inputs for the model. If None, inputs
                are generated via ``_prepare_inputs()``.
            **export_kwargs: Additional options to pass to the AIMET export function.

        Raises:
            AssertionError: If ``quantize()`` has not been called yet.
        """
        os.makedirs(export_path, exist_ok=True)

        if dummy_inputs is None:
            dummy_inputs = self._prepare_inputs()

        assert self.quantsim is not None, "Must run quantize() before export()"
        self.quantsim.export(
            path=export_path,
            filename_prefix=filename_prefix,
            dummy_input=dummy_inputs,
            **export_kwargs,
        )
