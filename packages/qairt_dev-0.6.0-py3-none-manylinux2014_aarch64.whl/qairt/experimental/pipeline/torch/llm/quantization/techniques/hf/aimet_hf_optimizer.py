# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Generic HuggingFace adapter for AIMET optimization techniques."""

from abc import abstractmethod
from typing import TYPE_CHECKING, Type, cast

import torch
from transformers.utils.quantization_config import QuantizationConfigMixin

from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.aimet_optimizer import (
    AIMETOptimizer,
)
from qairt.utils.loggers import get_logger

from .aimet_hf_quantizer import AIMETConfigMixin
from .base import BaseHFQuantizer

if TYPE_CHECKING:
    from transformers import PreTrainedModel

logger = get_logger(__name__)


class AIMETHFOptimizer(BaseHFQuantizer):
    """Generic HuggingFace adapter for AIMET optimization techniques.

    This class handles the HuggingFace lifecycle (pre/post weight loading) and delegates
    to concrete AIMET optimizers via the `aimet_optimizer_cls()` hook. Subclasses must
    override `aimet_optimizer_cls()` to specify which concrete optimizer to use.

    The generic adapter:
    1. Instantiates the concrete optimizer in `_process_model_before_weight_loading()`
    2. Builds params via `params_cls.from_hf_config()` in `_process_model_after_weight_loading()`
    3. Calls `optimizer.apply(params)` to perform optimization
    4. Wraps `save_pretrained()` to export AIMET artifacts (if any)

    Subclasses only need to override `aimet_optimizer_cls()` to specify the concrete
    optimizer class. All other logic is handled by this generic base.

    Example:
        .. code-block:: python

            @register_quantizer("SpinQuant")
            class SpinQuantHFOptimizer(AIMETHFOptimizer):
                @classmethod
                def aimet_optimizer_cls(cls) -> Type[AIMETOptimizer]:
                    from ..spinquant.spinquant_optimizer import SpinQuantOptimizer
                    return SpinQuantOptimizer
    """

    def __init__(self, quantization_config: QuantizationConfigMixin, **kwargs):
        """Initialize the HF optimizer adapter.

        Args:
            quantization_config: A QuantizationConfigMixin instance (typically AIMETConfigMixin
                or a technique-specific subclass).
            **kwargs: Additional keyword arguments for the base class.
        """
        assert isinstance(quantization_config, AIMETConfigMixin), (
            f"Expected AIMETConfigMixin or subclass, got {type(quantization_config)}"
        )
        super().__init__(quantization_config, **kwargs)
        self._aimet_instance: AIMETOptimizer | None = None

    @classmethod
    @abstractmethod
    def aimet_optimizer_cls(cls) -> Type[AIMETOptimizer]:
        """Return the concrete AIMETOptimizer subclass for this technique.

        Concrete HF optimizers must override this to specify which AIMET optimizer
        to use. The generic adapter will instantiate this class and call its methods.

        Returns:
            An AIMETOptimizer subclass (e.g., SpinQuantOptimizer, AdaScaleOptimizer).

        Example:
            .. code-block:: python

                @classmethod
                def aimet_optimizer_cls(cls) -> Type[AIMETOptimizer]:
                    from ..spinquant.spinquant_optimizer import SpinQuantOptimizer
                    return SpinQuantOptimizer
        """
        raise NotImplementedError

    def _process_model_before_weight_loading(self, model: "PreTrainedModel", **kwargs) -> None:
        """Pre-weight-loading setup: instantiate the AIMET optimizer.

        This method is called by the HuggingFace framework before loading model weights.
        It instantiates the concrete AIMET optimizer with the model and context information.

        Args:
            model: The model to optimize.
            **kwargs: Additional keyword arguments from HF framework.
        """
        optimizer_cls = self.aimet_optimizer_cls()

        # Instantiate the concrete AIMET optimizer with HF model + context
        self._aimet_instance = optimizer_cls(
            hf_model=cast(torch.nn.Module, model),
            context_length=getattr(self.quantization_config, "context_length", None),
            sequence_length=getattr(self.quantization_config, "sequence_length", None),
            tokenizer=getattr(self.quantization_config, "tokenizer", None),
        )

    def _process_model_after_weight_loading(self, model, **kwargs):
        """Post-weight-loading: build params and run optimization.

        This method is called by the HuggingFace framework after loading model weights.
        It builds params via ``from_hf_config()`` and calls the optimizer's ``apply()``
        method.

        Whether ``save_pretrained`` is wrapped depends on the algorithm's result:

        - If ``result.quantsim is not None``: the algorithm produced a live
          ``QuantizationSimModel`` that needs to be exported (e.g. LPBQ).
          ``save_pretrained`` is wrapped to also export AIMET encodings/artifacts.
        - If ``result.quantsim is None``: the algorithm returned a clean HF model
          (e.g. AdaScale bakes params and removes wrappers; SpinQuant only rotates
          weights).  No wrapping is needed.

        Args:
            model: The model with weights loaded.
            **kwargs: Additional keyword arguments from HF framework.

        Returns:
            The optimised model.  For algorithms that produce a quantsim the
            ``save_pretrained`` method is wrapped to export AIMET artifacts.
        """
        optimizer_cls = self.aimet_optimizer_cls()
        params_cls = optimizer_cls.params_cls()

        # Build params via the abstract from_hf_config contract
        params = params_cls.from_hf_config(self.quantization_config)

        # Apply optimization
        assert self._aimet_instance is not None, "Optimizer not initialized"
        result = self._aimet_instance.apply(params=params)

        # Only attach the AIMET instance and wrap save_pretrained when the
        # algorithm produces a live QuantSim that needs to be exported.
        # Algorithms that return a clean model (quantsim=None) do not need the export wrapper.
        if result is not None and getattr(result, "quantsim", None) is not None:
            model._aimet_instance = self._aimet_instance
            model.save_pretrained = self._get_save_pretrained_with_export(model, model.save_pretrained)

        return model
