# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""SpinQuant optimizer implementation."""

from typing import Type

import torch
from aimet_torch.experimental.spinquant.spinquant_optimizer import apply_spinquant

from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.aimet_optimizer import (
    AIMETOptimizer,
)
from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.definitions import (
    CommonParams,
    OptimizationResult,
    SpinQuantParams,
)
from qairt.utils.loggers import get_logger

logger = get_logger(__name__)


class SpinQuantOptimizer(AIMETOptimizer):
    """SpinQuant optimizer.

    SpinQuant applies rotation-based weight transformations (Hadamard rotations)
    to reduce outliers in weight matrices, improving the model's amenability
    to low-precision quantization.

    Supports LLaMA, Qwen2, Qwen3, and Phi3 architectures. Raises ``RuntimeError``
    if ``embed_tokens`` and ``lm_head`` weights are tied; call ``_untie_weights``
    first or ensure the model has separate tensors.

    Example:
        .. code-block:: python

            from qairt.experimental.pipeline.torch.llm.quantization.techniques.spinquant import (
                SpinQuantOptimizer,
            )
            from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.definitions import (
                SpinQuantParams,
            )

            optimizer = SpinQuantOptimizer(model, context_length=None, sequence_length=None)
            result = optimizer.apply(params=SpinQuantParams())
            optimized_model = result.model
    """

    _name = "SpinQuant"

    @classmethod
    def params_cls(cls) -> Type[CommonParams]:
        """Return the parameter class for SpinQuant optimization.

        Returns:
            The SpinQuantParams class.
        """
        return SpinQuantParams

    @staticmethod
    def _untie_weights(model: torch.nn.Module) -> None:
        """Untie embed_tokens and lm_head weights if they share the same tensor.

        ``apply_spinquant`` raises ``RuntimeError`` when these weights are tied.
        This method clones the ``lm_head`` weight to make it an independent tensor.

        Handles both HF CausalLM structure (``model.model.embed_tokens`` /
        ``model.lm_head``) and flat structure (``model.embed_tokens`` /
        ``model.lm_head``).

        Args:
            model: The model whose weights to check and potentially untie.
        """
        embed_weight = None
        lm_head_module = None

        if hasattr(model, "model") and hasattr(model.model, "embed_tokens"):
            embed_weight = model.model.embed_tokens.weight
        elif hasattr(model, "embed_tokens"):
            embed_weight = model.embed_tokens.weight

        if hasattr(model, "lm_head"):
            lm_head_module = model.lm_head

        if embed_weight is not None and lm_head_module is not None:
            if embed_weight is lm_head_module.weight:
                lm_head_module.weight = torch.nn.Parameter(
                    lm_head_module.weight.data.clone().detach(),
                    requires_grad=lm_head_module.weight.requires_grad,
                )

    @torch.no_grad()
    def apply(self, params: CommonParams) -> OptimizationResult:
        """Apply SpinQuant rotation-based weight optimization to the model.

        Unties ``embed_tokens`` / ``lm_head`` weights if necessary, then
        applies Hadamard rotations via AIMET's ``apply_spinquant``.

        Args:
            params: SpinQuant configuration (must be a ``SpinQuantParams`` instance).

        Returns:
            OptimizationResult with the optimized model and prepared model.
            ``quantsim`` is always None (SpinQuant does not create a quantsim).

        Raises:
            TypeError: If ``params`` is not a ``SpinQuantParams`` instance.
        """
        if not isinstance(params, SpinQuantParams):
            raise TypeError(f"Expected SpinQuantParams, got {type(params).__name__}")

        if self.prepared_model is None:
            self._prepare_model()

        assert self.prepared_model is not None

        self._untie_weights(self.prepared_model)

        apply_spinquant(model=self.prepared_model)

        return OptimizationResult(
            model=self.prepared_model,
            quantsim=None,
            prepared_model=self.prepared_model,
        )
