# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""Internal GPTAQ algorithm implementation: quantization primitives, layer wrappers, and PTQ pass."""

import functools
import gc
import math
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm

from qairt.utils.loggers import get_logger

from ..bases.definitions import CommonParams, GPTAQParams
from .utils import temp_model_config

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def cleanup_memory() -> None:
    gc.collect()
    torch.cuda.empty_cache()


# ---------------------------------------------------------------------------
# Quantization primitives
# ---------------------------------------------------------------------------


def sym_quant_dequant(x: torch.Tensor, scale: torch.Tensor, maxq: torch.Tensor) -> torch.Tensor:
    scale = scale.to(x.device)
    return scale * torch.clamp(torch.round(x / scale), -(maxq + 1), maxq)


def asym_quant_dequant(
    x: torch.Tensor, scale: torch.Tensor, zero: torch.Tensor, maxq: torch.Tensor
) -> torch.Tensor:
    scale, zero = scale.to(x.device), zero.to(x.device)
    q = torch.clamp(torch.round(x / scale) + zero, torch.zeros_like(maxq), maxq)
    return scale * (q - zero)


class STEQuantize(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, scale, maxq):
        scale = scale.to(x.device)
        return scale * torch.clamp(torch.round(x / scale), -(maxq + 1), maxq)

    @staticmethod
    def backward(ctx, g):
        return g, None, None


class AsymSTEQuantize(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, scale, zero, maxq):
        scale, zero = scale.to(x.device), zero.to(x.device)
        q = torch.clamp(torch.round(x / scale) + zero, 0, maxq)
        return scale * (q - zero)

    @staticmethod
    def backward(ctx, g):
        return g, None, None, None


# ---------------------------------------------------------------------------
# GPTQIntLinear
# ---------------------------------------------------------------------------


class GPTQIntLinear(nn.Module):
    """``nn.Linear`` wrapper that accumulates Hessian statistics and supports in-place GPTQ quantization."""

    def __init__(self, orig: nn.Linear, bitwidth: int = 4, group_size: int = -1):
        super().__init__()
        self.in_features = orig.in_features
        self.out_features = orig.out_features
        self.weight = nn.Parameter(orig.weight.data.clone())
        if orig.bias is not None:
            self.bias = nn.Parameter(orig.bias.data.clone())
        else:
            self.register_parameter("bias", None)
        self.enable_quant = False
        self._configure(bitwidth, group_size)

    def _configure(
        self,
        bits: int,
        group_size: int = -1,
        perchannel: bool = True,
        sym: bool = True,
        mse: bool = True,
        norm: float = 2.4,
        grid: int = 100,
        maxshrink: float = 0.8,
    ) -> None:
        self.bits = bits
        self.perchannel = perchannel
        self.sym = sym
        self.mse = mse
        self.norm = norm
        self.grid = grid
        self.maxshrink = maxshrink
        self.group_size = group_size
        self.maxq = torch.tensor(2 ** (bits - 1) - 1 if sym else 2**bits - 1)
        self.scale: Optional[torch.Tensor] = None
        self.zero: Optional[torch.Tensor] = None

    def find_params(self, x: torch.Tensor) -> None:
        if self.bits >= 16:
            return
        self.enable_quant = True
        self.maxq = self.maxq.to(x.device)
        if self.group_size is not None and self.group_size > 0:
            self._find_params_groupwise(x)
        else:
            self._find_params_perchannel(x)

    def _find_params_groupwise(self, x: torch.Tensor) -> None:
        gs = self.group_size
        if x.shape[-1] % gs != 0:
            raise ValueError(f"Weight dim {x.shape[-1]} not divisible by group_size {gs}")
        init_shape = x.shape
        x = x.reshape(x.shape[-2], x.shape[-1] // gs, gs)
        xmax = torch.amax(x, dim=-1, keepdim=True)
        xmin = torch.amin(x, dim=-1, keepdim=True)
        self.scale, self.zero = self._compute_scale_zero_groupwise(xmin, xmax)
        if self.mse:
            self._refine_mse_groupwise(x, xmin, xmax)
        self.scale = self.scale.reshape(init_shape)
        self.zero = self.zero.reshape(init_shape)

    def _find_params_perchannel(self, x: torch.Tensor) -> None:
        shape = x.shape
        x = x.flatten(1) if self.perchannel else x.flatten().unsqueeze(0)
        tmp = torch.zeros(x.shape[0], device=x.device)
        xmin = torch.minimum(x.min(1)[0], tmp)
        xmax = torch.maximum(x.max(1)[0], tmp)
        self.scale, self.zero = self._compute_scale_zero_perchannel(xmin, xmax)
        if self.mse:
            self._refine_mse_perchannel(x, xmin, xmax)
        if not self.perchannel:
            self.scale = self.scale.repeat(shape[0])
            self.zero = self.zero.repeat(shape[0])
        reshape = [-1] + [1] * (len(shape) - 1)
        self.scale = self.scale.reshape(reshape)
        self.zero = self.zero.reshape(reshape)

    def _compute_scale_zero_groupwise(self, xmin, xmax):
        gs = self.group_size
        if self.sym:
            xmax = torch.maximum(torch.abs(xmin), xmax).clamp(min=1e-5)
            scale = (xmax / self.maxq).repeat(1, 1, gs)
            zero = torch.zeros_like(scale)
        else:
            xmin = xmin.clone()
            xmax = xmax.clone()
            tmp = (xmin == 0) & (xmax == 0)
            xmin[tmp] = -1
            xmax[tmp] = 1
            scale = ((xmax - xmin).clamp(min=1e-5) / self.maxq).repeat(1, 1, gs)
            zero = torch.round(-xmin / (scale / gs)).repeat(1, 1, gs)
        return scale, zero

    def _compute_scale_zero_perchannel(self, xmin, xmax):
        if self.sym:
            xmax = torch.maximum(torch.abs(xmin), xmax).clamp(min=1e-5)
            return xmax / self.maxq, torch.zeros_like(xmax)
        tmp = (xmin == 0) & (xmax == 0)
        xmin = xmin.clone()
        xmax = xmax.clone()
        xmin[tmp] = -1
        xmax[tmp] = 1
        scale = (xmax - xmin).clamp(min=1e-5) / self.maxq
        return scale, torch.round(-xmin / scale)

    def _refine_mse_groupwise(self, x, xmin, xmax) -> None:
        gs = self.group_size
        best = torch.full([x.shape[0], x.shape[1]], float("inf"), device=x.device).type_as(x)
        for i in range(int(self.maxshrink * self.grid)):
            p = 1 - i / self.grid
            xmin1, xmax1 = p * xmin, p * xmax
            if self.sym:
                s1 = (xmax1 / self.maxq).repeat(1, 1, gs)
                z1 = torch.zeros_like(s1)
                q = sym_quant_dequant(x, s1, self.maxq)
            else:
                s1 = ((xmax1 - xmin1) / self.maxq).repeat(1, 1, gs)
                z1 = torch.round(-xmin1 / (s1 / gs)).repeat(1, 1, gs)
                q = asym_quant_dequant(x, s1, z1, self.maxq)
            err = ((q - x).abs() ** self.norm).sum(-1)
            better = err < best
            if torch.any(better):
                best[better] = err[better]
                assert self.scale is not None
                assert self.zero is not None
                self.scale[better] = s1[better]
                self.zero[better] = z1[better]

    def _refine_mse_perchannel(self, x, xmin, xmax) -> None:
        best = torch.full([x.shape[0]], float("inf"), device=x.device)
        for i in range(int(self.maxshrink * self.grid)):
            p = 1 - i / self.grid
            xmin1, xmax1 = p * xmin, p * xmax
            if self.sym:
                s1 = xmax1 / self.maxq
                q = sym_quant_dequant(x, s1.unsqueeze(1), self.maxq)
            else:
                s1 = (xmax1 - xmin1) / self.maxq
                z1 = torch.round(-xmin1 / s1)
                q = asym_quant_dequant(x, s1.unsqueeze(1), z1.unsqueeze(1), self.maxq)
            err = ((q - x).abs() ** self.norm).sum(1)
            better = err < best
            if torch.any(better):
                best[better] = err[better]
                assert self.scale is not None
                self.scale[better] = s1[better]
                if not self.sym:
                    assert self.zero is not None
                    self.zero[better] = z1[better]

    def quantize(self, x: torch.Tensor) -> torch.Tensor:
        if not self.enable_quant or self.bits >= 16:
            return x
        dtype = x.dtype
        if self.sym:
            return STEQuantize.apply(x, self.scale, self.maxq).to(dtype)
        return AsymSTEQuantize.apply(x, self.scale, self.zero, self.maxq).to(dtype)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.linear(x, self.quantize(self.weight), self.bias)

    @torch.no_grad()
    def to_linear(self, qdq_weights: bool = True) -> nn.Linear:
        layer = nn.Linear(self.in_features, self.out_features, self.bias is not None)
        layer.weight.data.copy_(self.quantize(self.weight) if qdq_weights else self.weight.data)
        if self.bias is not None:
            layer.bias.data.copy_(self.bias.data)
        return layer


# ---------------------------------------------------------------------------
# GPTAQ core
# ---------------------------------------------------------------------------


def find_qlayers(module: nn.Module, name: str = "") -> Dict[str, GPTQIntLinear]:
    if isinstance(module, GPTQIntLinear):
        return {name: module}
    result: Dict[str, GPTQIntLinear] = {}
    for child_name, child in module.named_children():
        result.update(find_qlayers(child, f"{name}.{child_name}" if name else child_name))
    return result


TARGET_LAYER_SUFFIXES: List[str] = [
    "self_attn.k_proj",
    "self_attn.v_proj",
    "self_attn.q_proj",
    "self_attn.o_proj",
    "mlp.up_proj",
    "mlp.gate_proj",
    "mlp.down_proj",
    "c_attn",
    "c_proj",
    "c_fc",
]

SEQUENTIAL_GROUPS: List[List[str]] = [
    ["self_attn.k_proj", "self_attn.v_proj", "self_attn.q_proj", "c_attn"],
    ["self_attn.o_proj", "c_proj"],
    ["mlp.up_proj", "mlp.gate_proj", "c_fc"],
    ["mlp.down_proj"],
]


class GPTAQ:
    """Per-layer GPTQ-AQ quantizer that accumulates Hessian and correction statistics."""

    def __init__(self, layer: GPTQIntLinear):
        self.layer = layer
        self.dev = layer.weight.device
        cols = layer.weight.shape[1]
        self.H = torch.zeros((cols, cols), device=self.dev)
        self.dXXT = torch.zeros((cols, cols), device=self.dev)
        self.nsamples = 0
        self.fp_inp: List[torch.Tensor] = []

    def add_batch(self, inp: torch.Tensor, _out: torch.Tensor) -> None:
        if inp.dim() == 2:
            inp = inp.unsqueeze(0)
        n = inp.shape[0]
        inp = inp.reshape(-1, inp.shape[-1]).t()
        scale = self.nsamples / (self.nsamples + n)
        self.H *= scale
        self.dXXT *= scale
        self.nsamples += n
        inp = math.sqrt(2 / self.nsamples) * inp.float()
        self.H += inp.matmul(inp.t())
        if not self.fp_inp:
            raise RuntimeError(
                f"fp_inp is empty at sample {self.nsamples}; "
                "FPInputsCache must be populated before quantization."
            )
        dX = self.fp_inp.pop(0).to(inp.device).float() * math.sqrt(2 / self.nsamples) - inp
        self.dXXT += dX.matmul(inp.t())

    def fasterquant(self, blocksize: int = 128, percdamp: float = 0.01) -> None:
        W = self.layer.weight.data.clone().float()
        if not self.layer.enable_quant:
            self.layer.find_params(W)

        H = self.H
        del self.H
        dead = torch.diag(H) == 0
        H[dead, dead] = 1
        W[:, dead] = 0
        self.dXXT[:, dead] = 0

        cols = W.shape[1]
        diag = torch.arange(cols, device=self.dev)
        H[diag, diag] += percdamp * torch.mean(torch.diag(H))
        Hinv = torch.linalg.cholesky(torch.cholesky_inverse(torch.linalg.cholesky(H)), upper=True)

        P = 0.25 * ((self.dXXT @ Hinv.T).triu(diagonal=1)) @ Hinv
        del self.dXXT

        Q = torch.zeros_like(W)
        groupsize = self.layer.group_size

        for i1 in range(0, cols, blocksize):
            i2 = min(i1 + blocksize, cols)
            W1 = W[:, i1:i2].clone()
            Q1 = torch.zeros_like(W1)
            Err1 = torch.zeros_like(W1)
            Hinv1 = Hinv[i1:i2, i1:i2]
            P1 = P[i1:i2, i1:i2]

            if self.layer.scale is not None:
                self.layer.scale = self.layer.scale.to(self.dev)
            if self.layer.zero is not None:
                self.layer.zero = self.layer.zero.to(self.dev)

            for i in range(i2 - i1):
                if groupsize != -1 and (i1 + i) % groupsize == 0:
                    self.layer.find_params(W[:, (i1 + i) : (i1 + i + groupsize)])
                w = W1[:, i]
                d = Hinv1[i, i]
                q = self.layer.quantize(w.unsqueeze(1)).flatten()
                Q1[:, i] = q
                err1 = (w - q) / d
                W1[:, i:] -= err1.unsqueeze(1).matmul(Hinv1[i, i:].unsqueeze(0)) - w.unsqueeze(1).matmul(
                    P1[i, i:].unsqueeze(0)
                )
                Err1[:, i] = err1

            Q[:, i1:i2] = Q1
            W[:, i2:] -= Err1.matmul(Hinv[i1:i2, i2:]) - W1.matmul(P[i1:i2, i2:])

        torch.cuda.synchronize()

        # Validate before assignment
        Q_reshaped = Q.reshape(self.layer.weight.shape).to(self.layer.weight.dtype)
        if torch.any(torch.isnan(Q_reshaped)):
            raise ValueError("NaN detected in quantized weights before assignment.")

        self.layer.weight.data = Q_reshaped

    def free(self) -> None:
        self.H = None  # type: ignore[assignment]
        self.dXXT = None  # type: ignore[assignment]
        cleanup_memory()


class FPInputsCache:
    """Caches full-precision layer inputs needed for the GPTAQ correction term."""

    def __init__(self, sequential: List[List[str]]):
        self.names: List[str] = [n for group in sequential for n in group]
        self.fp_cache: Dict[str, List[torch.Tensor]] = {n: [] for n in self.names}
        self._handles: List[Any] = []

    def _hook(self, _m, inp, _out, name: str) -> None:
        x = inp[0].detach()
        if x.dim() == 3:
            x = x.reshape(-1, x.shape[-1])
        self.fp_cache[name].append(x.t().cpu())

    def register(self, full: Dict[str, GPTQIntLinear]) -> None:
        for name in self.names:
            if name in full:
                self._handles.append(
                    full[name].register_forward_hook(functools.partial(self._hook, name=name))
                )

    def remove(self) -> None:
        for h in self._handles:
            h.remove()
        self._handles.clear()
        torch.cuda.empty_cache()

    def clear(self) -> None:
        for name in self.names:
            self.fp_cache[name].clear()


# ---------------------------------------------------------------------------
# PTQ pass
# ---------------------------------------------------------------------------


def _resolve_model_components(
    model: nn.Module,
) -> Tuple[Any, nn.Module, Optional[nn.Module], Optional[nn.Module]]:
    """Return ``(layers, embed_tokens, norm, rotary_emb)`` for supported architectures."""
    if hasattr(model, "model") and hasattr(model.model, "layers"):
        m = model.model
        return m.layers, m.embed_tokens, m.norm, getattr(m, "rotary_emb", None)
    if hasattr(model, "transformer") and hasattr(model.transformer, "h"):
        t = model.transformer
        return t.h, t.wte, getattr(t, "ln_f", None), getattr(t, "wpe", None)
    raise ValueError("Unsupported model architecture for GPTAQ.")


def _layer_forward(layer, inp, attn_mask, pos_ids, pos_emb, dev):
    kwargs = {
        k: v
        for k, v in [
            ("attention_mask", attn_mask),
            ("position_ids", pos_ids),
            ("position_embeddings", pos_emb),
        ]
        if v is not None
    }
    try:
        out = layer(inp.unsqueeze(0).to(dev), **kwargs)
    except (TypeError, RuntimeError):
        out = layer(inp.unsqueeze(0).to(dev))
    return out[0].cpu() if isinstance(out, tuple) else out.cpu()


def _capture_first_layer_inputs(model, layers, dataloader, nsamples, seqlen, hidden_size, dtype, dev):
    inps = torch.zeros((nsamples, seqlen, hidden_size), dtype=dtype, device="cpu")
    cache: Dict[str, Any] = {
        "i": 0,
        "attention_mask": None,
        "position_ids": None,
        "position_embeddings": None,
    }

    class _Catcher(nn.Module):
        def __init__(self, module):
            super().__init__()
            self.module = module

        def __getattr__(self, name: str):
            try:
                return super().__getattr__(name)
            except AttributeError:
                return getattr(self.module, name)

        def forward(self, inp, **kwargs):
            if cache["i"] < nsamples:
                sl = min(inp.shape[1], seqlen)
                inps[cache["i"], :sl] = inp[0, :sl].cpu()
                cache["attention_mask"] = kwargs.get("attention_mask")
                cache["position_ids"] = kwargs.get("position_ids")
                cache["position_embeddings"] = kwargs.get("position_embeddings")
            cache["i"] += 1
            raise ValueError("_Catcher: input captured")

    layers[0] = _Catcher(layers[0])
    for idx, batch in tqdm(enumerate(dataloader), desc="Capturing inputs", total=nsamples):
        if idx >= nsamples:
            break
        try:
            if isinstance(batch, dict):
                batch = {k: v.to(dev) if hasattr(v, "to") else v for k, v in batch.items()}
                if "input_ids" in batch and batch["input_ids"].shape[1] > seqlen:
                    batch["input_ids"] = batch["input_ids"][:, :seqlen]
                    if "attention_mask" in batch:
                        batch["attention_mask"] = batch["attention_mask"][:, :seqlen]
                model(**batch)
            else:
                batch = [v.to(dev) if hasattr(v, "to") else v for v in batch]
                inp = batch[0]
                model(inp[:, :seqlen] if inp.shape[1] > seqlen else inp)
        except ValueError as e:
            if "_Catcher" not in str(e):
                raise

    layers[0] = layers[0].module
    return inps, cache["attention_mask"], cache["position_ids"], cache["position_embeddings"]


@torch.no_grad()
def gptaq_quantize(model: nn.Module, dataloader, num_calib_batches: int, seqlen: int, device: str) -> None:
    """Run the full GPTAQ layer-by-layer PTQ pass in-place on ``model``."""
    layers, embed_tokens, norm, rotary_emb = _resolve_model_components(model)

    for mod in filter(None, [embed_tokens, norm, rotary_emb]):
        mod.to(device)
    layers[0] = layers[0].to(device)

    dtype = next(iter(model.parameters())).dtype
    nsamples = len(dataloader) if num_calib_batches <= 0 else num_calib_batches
    if nsamples <= 0:
        raise ValueError("Dataloader is empty or num_calib_batches is invalid.")

    hidden_size = (
        getattr(model.config, "hidden_size", None)
        or getattr(model.config, "n_embd", None)
        or embed_tokens.weight.shape[1]
    )

    inps, attn_mask, pos_ids, pos_emb = _capture_first_layer_inputs(
        model, layers, dataloader, nsamples, seqlen, hidden_size, dtype, device
    )

    layers[0] = layers[0].cpu()
    for mod in filter(None, [embed_tokens, norm, rotary_emb]):
        mod.cpu()
    torch.cuda.empty_cache()

    outs = torch.zeros_like(inps)
    fp_cache = FPInputsCache(SEQUENTIAL_GROUPS)
    fp_inps = inps.clone()

    for i, layer in enumerate(layers):
        logger.info("GPTAQ Processing Layer %d/%d", i, len(layers))
        layer = layer.to(device)
        full = find_qlayers(layer)
        if not full:
            layers[i] = layer.cpu()
            continue

        fp_cache.register(full)
        for j in range(nsamples):
            fp_inps[j] = _layer_forward(layer, fp_inps[j], attn_mask, pos_ids, pos_emb, device)
        fp_cache.remove()

        for group in SEQUENTIAL_GROUPS:
            subset = {n: full[n] for n in group if n in full}
            if not subset:
                continue

            gptq = {n: GPTAQ(subset[n]) for n in subset}
            for n in subset:
                gptq[n].fp_inp = fp_cache.fp_cache[n]

            first = next(iter(subset))
            handle = subset[first].register_forward_hook(
                lambda _m, inp, out, name=first: gptq[name].add_batch(inp[0].data, out.data)
            )
            for j in range(nsamples):
                outs[j] = _layer_forward(layer, inps[j], attn_mask, pos_ids, pos_emb, device)
                if j % 5 == 0:
                    torch.cuda.empty_cache()
            handle.remove()

            for n in subset:
                if n != first:
                    gptq[n].H = gptq[first].H
                    gptq[n].dXXT = gptq[first].dXXT
            for n in subset:
                gptq[n].fasterquant()
                gptq[n].free()

        for mod in full.values():
            mod.enable_quant = False

        for j in range(nsamples):
            outs[j] = _layer_forward(layer, inps[j], attn_mask, pos_ids, pos_emb, device)

        fp_cache.clear()
        layers[i] = layer.cpu()
        del layer, gptq
        torch.cuda.empty_cache()
        inps, outs = outs, inps

    cleanup_memory()
