# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Generic HuggingFace adapter for AIMET quantization techniques."""

from abc import abstractmethod
from typing import TYPE_CHECKING, Any, Optional, Type, cast

import torch
from transformers.utils.quantization_config import QuantizationConfigMixin

from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.aimet_quantizer import (
    AIMETQuantizer,
)
from qairt.utils.loggers import get_logger

from .base import BaseHFQuantizer

if TYPE_CHECKING:
    from transformers import PreTrainedModel

logger = get_logger(__name__)


class AIMETConfigMixin(QuantizationConfigMixin):
    """Base configuration mixin for AIMET quantization techniques.

    This class serves as the base for technique-specific config classes (e.g., PCQConfig,
    LPBQConfig). It is used by AIMET param classes via their `from_hf_config()` method
    to translate HuggingFace configurations into AIMET parameters.

    Different techniques may use different subsets of fields. Param classes are responsible
    for reading and validating their required fields from this config.

    Attributes:
        dataloader: DataLoader providing calibration data.
        dummy_inputs: Pre-assembled dummy inputs for model tracing.
        generator: Generator instance for LLM inference.
        context_length: Optional, max tokens the model can process.
        sequence_length: Optional, length of input sequences.
        tokenizer: Optional, HuggingFace tokenizer.
        quantsim_kwargs: Optional dictionary of keyword arguments for quantsim creation.
    """

    _AIMET_QUANT_METHOD = "aimet"

    def __init__(
        self,
        dataloader: Optional[Any] = None,
        dummy_inputs: Optional[Any] = None,
        generator: Optional[Any] = None,
        context_length: Optional[int] = None,
        sequence_length: Optional[int] = None,
        tokenizer: Optional[Any] = None,
        quantsim_kwargs: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ):
        """Initialize AIMET config mixin.

        Args:
            dataloader: DataLoader for calibration data.
            dummy_inputs: Pre-assembled dummy inputs (tuple[Tensor, ...] | dict | Tensor).
            generator: Generator instance for LLM inference.
            context_length: Optional, max tokens the model can process.
            sequence_length: Optional, length of input sequences.
            tokenizer: Optional, HuggingFace tokenizer.
            quantsim_kwargs: Optional dictionary of keyword arguments for quantsim creation.
            **kwargs: Additional keyword arguments for subclasses.
        """
        super().__init__(quant_method=self._AIMET_QUANT_METHOD)  # type: ignore[arg-type]
        self.dataloader = dataloader
        self.dummy_inputs = dummy_inputs
        self.generator = generator
        self.context_length = context_length
        self.sequence_length = sequence_length
        self.tokenizer = tokenizer
        self.quantsim_kwargs = quantsim_kwargs or {}


class AIMETHFQuantizer(BaseHFQuantizer):
    """Generic HuggingFace adapter for AIMET quantization techniques.

    This class handles the HuggingFace lifecycle (pre/post weight loading) and delegates
    to concrete AIMET quantizers via the `aimet_quantizer_cls()` hook. Subclasses must
    override `aimet_quantizer_cls()` to specify which concrete quantizer to use.

    The generic adapter:
    1. Instantiates the concrete quantizer in `_process_model_before_weight_loading()`
    2. Builds params via `params_cls.from_hf_config()` in `_process_model_after_weight_loading()`
    3. Calls `quantizer.quantize(params)` to perform quantization
    4. Wraps `save_pretrained()` to export AIMET artifacts

    Subclasses only need to override `aimet_quantizer_cls()` to specify the concrete
    quantizer class. All other logic is handled by this generic base.

    Example:
        .. code-block:: python

            @register_quantizer("PCQ")
            class PCQ_HFQuantizer(AIMETHFQuantizer):
                @classmethod
                def aimet_quantizer_cls(cls) -> Type[AIMETQuantizer]:
                    from ..pcq.pcq_quantizer import PCQQuantizer
                    return PCQQuantizer
    """

    def __init__(self, quantization_config: QuantizationConfigMixin, **kwargs):
        """Initialize the HF quantizer adapter.

        Args:
            quantization_config: A QuantizationConfigMixin instance (typically AIMETConfigMixin
                or a technique-specific subclass).
            **kwargs: Additional keyword arguments for the base class.
        """
        assert isinstance(quantization_config, AIMETConfigMixin), (
            f"Expected AIMETConfigMixin or subclass, got {type(quantization_config)}"
        )
        super().__init__(quantization_config, **kwargs)
        self._aimet_instance: AIMETQuantizer | None = None

    @classmethod
    @abstractmethod
    def aimet_quantizer_cls(cls) -> Type[AIMETQuantizer]:
        """Return the concrete AIMETQuantizer subclass for this technique.

        Concrete HF quantizers must override this to specify which AIMET quantizer
        to use. The generic adapter will instantiate this class and call its methods.

        Returns:
            An AIMETQuantizer subclass (e.g., PCQQuantizer, LPBQQuantizer).

        Example:
            .. code-block:: python

                @classmethod
                def aimet_quantizer_cls(cls) -> Type[AIMETQuantizer]:
                    from ..pcq.pcq_quantizer import PCQQuantizer
                    return PCQQuantizer
        """
        raise NotImplementedError

    def _process_model_before_weight_loading(self, model: "PreTrainedModel", **kwargs) -> None:
        """Pre-weight-loading setup: instantiate the AIMET quantizer.

        This method is called by the HuggingFace framework before loading model weights.
        It instantiates the concrete AIMET quantizer with the model and context information.

        Args:
            model: The model to quantize.
            **kwargs: Additional keyword arguments from HF framework.
        """
        quantizer_cls = self.aimet_quantizer_cls()

        # Instantiate the concrete AIMET quantizer with HF model + context
        self._aimet_instance = quantizer_cls(
            hf_model=cast(torch.nn.Module, model),
            context_length=getattr(self.quantization_config, "context_length", None),
            sequence_length=getattr(self.quantization_config, "sequence_length", None),
            tokenizer=getattr(self.quantization_config, "tokenizer", None),
        )

    def _process_model_after_weight_loading(self, model, **kwargs):
        """Post-weight-loading: build params and run quantization.

        This method is called by the HuggingFace framework after loading model weights.
        It builds params via `from_hf_config()` and calls the quantizer's `quantize()` method.

        Args:
            model: The model with weights loaded.
            **kwargs: Additional keyword arguments from HF framework.

        Returns:
            The model with quantization applied and export wrapper attached.
        """
        quantizer_cls = self.aimet_quantizer_cls()
        params_cls = quantizer_cls.params_cls()

        # Build params via the abstract from_hf_config contract
        params = params_cls.from_hf_config(self.quantization_config)

        # Run the AIMET quantization technique
        assert self._aimet_instance is not None, "Quantizer not initialized"
        result = self._aimet_instance.quantize(params=params)  # type: ignore[type-var]

        # Attach instance to model for export
        model._aimet_instance = self._aimet_instance

        # Wrap save_pretrained to export quantsim artifacts
        model.save_pretrained = self._get_save_pretrained_with_export(model, model.save_pretrained)
        return model
