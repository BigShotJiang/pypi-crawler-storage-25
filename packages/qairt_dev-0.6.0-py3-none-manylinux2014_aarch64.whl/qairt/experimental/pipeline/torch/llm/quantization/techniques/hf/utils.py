# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""Shared utilities for HF quantization techniques."""

from contextlib import contextmanager
from typing import Any, Dict

import torch.nn as nn


@contextmanager
def temp_model_config(model: nn.Module, **kwargs):
    """Temporarily override ``model.config`` attributes, restoring them on exit."""
    saved: Dict[str, Any] = {}
    if hasattr(model, "config"):
        for k, v in kwargs.items():
            if hasattr(model.config, k):
                saved[k] = getattr(model.config, k)
                setattr(model.config, k, v)
    try:
        yield
    finally:
        for k, v in saved.items():
            setattr(model.config, k, v)
