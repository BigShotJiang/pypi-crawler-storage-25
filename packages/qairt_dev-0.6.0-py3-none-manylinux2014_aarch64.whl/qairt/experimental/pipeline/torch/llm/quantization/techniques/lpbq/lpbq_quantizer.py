# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""LPBQ (Low Precision Blockwise Quantization) quantizer implementation."""

from typing import Any, Type

import torch
from aimet_torch.v2.nn.true_quant import QuantizedConv2d, QuantizedLinear
from aimet_torch.v2.quantsim import QuantizationSimModel
from aimet_torch.v2.quantsim.config_utils import (
    set_grouped_blockwise_quantization_for_weights,
)

from qairt.api.configs.common import DspArchitecture
from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.aimet_quantizer import (
    AIMETQuantizer,
)
from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.definitions import (
    LPBQParams,
    ModulePrecisions,
    QuantizationResult,
    QuantSimParams,
)
from qairt.experimental.pipeline.torch.llm.quantization.techniques.pcq.pcq_quantizer import (
    PCQQuantizer,
)
from qairt.utils.loggers import get_logger

logger = get_logger(__name__)


class LPBQQuantizer(AIMETQuantizer):
    """LPBQ (Low Precision Blockwise Quantization) quantizer.

    LPBQ extends PCQ by applying grouped blockwise quantization for 4-bit
    weights after the standard quantsim creation. This enables finer-grained
    quantization control at the block level within each weight tensor.

    Example:
        .. code-block:: python

            from qairt.experimental.pipeline.torch.llm.quantization.techniques.lpbq import (
                LPBQQuantizer,
            )
            from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.definitions import (
                LPBQParams,
            )

            quantizer = LPBQQuantizer(model, context_length=2048, sequence_length=128)
            result = quantizer.quantize(
                params=LPBQParams(
                    dataloader=calibration_loader,
                    block_size=64,
                    block_grouping=1,
                )
            )
    """

    _name = "LPBQ"

    @classmethod
    def params_cls(cls) -> Type[QuantSimParams]:
        """Return the parameter class for LPBQ quantization.

        Returns:
            The LPBQParams class.
        """
        return LPBQParams

    @classmethod
    def _create_quantsim(  # type: ignore[override]
        cls,
        model: torch.nn.Module,
        assembled_dummy_inputs: tuple[torch.Tensor, ...],
        tie_quantizers: list[str] | None = None,
        module_precisions: ModulePrecisions | None = None,
        dsp_arch: DspArchitecture = DspArchitecture.v79,
        quantsim_kwargs: dict[str, Any] | None = None,
    ) -> QuantizationSimModel:
        """Create a QuantizationSimModel configured for LPBQ.

        Delegates to ``PCQQuantizer._create_quantsim`` for base quantsim creation
        (handles QuantizationSimModel construction, tie_quantizers, and module
        precision application). LPBQ-specific grouped blockwise quantization is applied
        in the ``quantize()`` method after encodings are computed.

        Args:
            model: The prepared PyTorch model.
            assembled_dummy_inputs: Dummy inputs for model tracing.
            tie_quantizers: Op types whose output encodings should be propagated
                (e.g., ``["concat"]``).
            module_precisions: Per-module precision configuration. Use
                ``ModulePrecisions`` to set per-module bit widths for lm_head,
                kv_cache, rms_norm, or custom modules.
            dsp_arch: DSP architecture version to select the HTP quantsim config file.
                Defaults to ``DspArchitecture.v79``.
            quantsim_kwargs: Additional overrides for QuantizationSimModel constructor.
                Supported keys: ``quant_scheme``, ``default_output_bw``, ``default_param_bw``,
                ``in_place``, ``default_data_type``. ``model`` and ``dummy_input`` are reserved
                and will raise ``ValueError`` if provided.

        Returns:
            A configured QuantizationSimModel (blockwise quantization applied later in quantize()).

        Raises:
            ValueError: If ``dummy_input`` is in ``quantsim_kwargs`` or unknown keys are present.
        """
        return PCQQuantizer._create_quantsim(
            model,
            assembled_dummy_inputs,
            tie_quantizers=tie_quantizers,
            module_precisions=module_precisions,
            dsp_arch=dsp_arch,
            quantsim_kwargs=quantsim_kwargs,
        )

    def quantize(
        self,
        params: QuantSimParams,
    ) -> QuantizationResult:
        """Quantize the model using LPBQ blockwise quantization.

        Args:
            params: LPBQ configuration (must be an ``LPBQParams`` instance) including
                dataloader, precision settings, block size/grouping, and optional
                quantsim overrides.

        Returns:
            QuantizationResult with the calibrated QuantizationSimModel.

        Raises:
            TypeError: If ``params`` is not an ``LPBQParams`` instance.
            ValueError: If ``params.dataloader`` is None.
        """
        if not isinstance(params, LPBQParams):
            raise TypeError(f"Expected LPBQParams, got {type(params).__name__}")

        if params.dataloader is None:
            raise ValueError("dataloader is required for LPBQ quantization")

        if self.prepared_model is None:
            self._prepare_model(generator=params.generator)

        assembled_dummy_inputs = self._prepare_inputs(dummy_inputs=params.dummy_inputs)

        assert self.prepared_model is not None
        assert isinstance(params.dsp_arch, DspArchitecture)

        quantsim = params.quantsim or self._create_quantsim(
            self.prepared_model,
            assembled_dummy_inputs,
            tie_quantizers=params.tie_quantizers,
            module_precisions=params.module_precisions,
            dsp_arch=params.dsp_arch,
            quantsim_kwargs=params.quantsim_kwargs,
        )

        self._compute_encodings(
            quantsim,
            params.dataloader,
            forward_pass_callback=params.forward_pass_callback,
        )

        # Apply LPBQ-specific grouped blockwise quantization for 4-bit weights
        def _is_4bit_quantized(module: torch.nn.Module) -> bool:
            return (
                isinstance(module, (QuantizedConv2d, QuantizedLinear))
                and module.param_quantizers["weight"]
                and module.param_quantizers["weight"].bitwidth == 4
            )

        set_grouped_blockwise_quantization_for_weights(
            sim=quantsim,
            arg=_is_4bit_quantized,
            bitwidth=params.quantsim_kwargs.get("default_param_bw", 4),
            symmetric=params.symmetric,
            decompressed_bw=params.decompressed_bw,
            block_size=params.block_size,
            block_grouping=-params.block_grouping,
        )

        self.quantsim = quantsim

        return QuantizationResult(
            quantsim=quantsim,
            prepared_model=self.prepared_model,
        )
