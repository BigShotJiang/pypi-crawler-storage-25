# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""Internal PrefixQuant implementation: KV-cache generation for prefix tokens."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn
from aimet_torch.utils import change_tensor_device_placement, place_model
from transformers.cache_utils import DynamicCache

from qairt.utils.loggers import get_logger

from ..bases.definitions import CommonParams, PrefixQuantParams
from .utils import temp_model_config

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# KV-cache generation
# ---------------------------------------------------------------------------


@torch.inference_mode()
def generate_prefix_kvcache(
    model: nn.Module,
    dummy_input: torch.Tensor,
    device: Union[torch.device, str],
    prefix_token_ids: List[int],
) -> Tuple[Tuple[torch.Tensor, ...], ...]:
    """Run a single forward pass to generate the KV cache for ``prefix_token_ids``.

    Args:
        model: The causal LM model.
        dummy_input: A ``[1, seq_len]`` integer tensor used as the input template.
        device: Device on which to run inference.
        prefix_token_ids: Token IDs whose KV cache should be pre-computed.

    Returns:
        A tuple-of-tuples ``past_key_values`` sliced to ``len(prefix_token_ids)`` positions.
    """
    if not prefix_token_ids:
        raise ValueError("prefix_token_ids cannot be empty")

    if len(prefix_token_ids) > dummy_input.shape[1]:
        raise ValueError(
            f"Prefix length ({len(prefix_token_ids)}) exceeds dummy_input length ({dummy_input.shape[1]})."
        )

    batch = {"input_ids": dummy_input.clone()}
    batch["input_ids"][0, : len(prefix_token_ids)] = torch.tensor(
        prefix_token_ids, dtype=batch["input_ids"].dtype, device=batch["input_ids"].device
    )

    with place_model(model, device), temp_model_config(model, use_cache=True, return_dict=True):
        batch = change_tensor_device_placement(batch, device)
        output = model(**batch, return_dict=True)

    if not hasattr(output, "past_key_values"):
        raise RuntimeError(
            "Model output does not contain 'past_key_values'. Ensure use_cache=True is supported."
        )

    pkv = output.past_key_values
    if isinstance(pkv, DynamicCache):
        pkv = pkv.to_legacy_cache()

    pkv = list(change_tensor_device_placement(pkv, "cpu"))
    n = len(prefix_token_ids)
    for layer_idx in range(len(pkv)):
        layer_kv = pkv[layer_idx]
        if layer_kv is None or any(t is None for t in layer_kv):
            # Some architectures (e.g. sliding-window attention layers in Qwen3)
            # do not populate KV cache for every layer — the HybridCache expands
            # to the full model depth and fills missing layers with None tensors.
            # Skip those entries to avoid 'NoneType' subscript errors.
            continue
        pkv[layer_idx] = tuple(t[..., :n, :] for t in layer_kv)

    return tuple(pkv)
