# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Interface classes for AIMET quantization and optimization techniques"""

import tempfile
from typing import Optional

import torch
from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer
from typing_extensions import Self

from qairt.utils.loggers import get_logger


class AIMETMixin:
    """Shared functionality for AIMET optimization and quantization techniques.

    This mixin provides common methods that both optimizers and quantizers need,
    such as loading models from HuggingFace, preparing models, and handling inputs.

    Note:
        This is a mixin class, meaning it's designed to be combined with other
        classes. You won't use this directly - instead, AIMETOptimizer and
        AIMETQuantizer inherit from it.
    """

    # Indicates if the subclass requires data for calibration or optimization
    _requires_data: bool
    # Indicates if the subclass requires calibration
    _requires_calibration: bool
    # Indicates if the subclass requires a generator class to be provided
    _requires_generation: bool

    _name: str  # name of the technique

    def __init__(
        self,
        hf_model: torch.nn.Module,
        context_length: int | None,
        sequence_length: int | None,
        tokenizer: AutoTokenizer | None = None,
    ):
        """Initialize the mixin with a model and configuration.

        Args:
            hf_model: The PyTorch model to work with (typically from HuggingFace).
            context_length: Maximum number of tokens the model can process at once.
                Set to None if your model doesn't need a fixed context length.
                Required if the technique needs to generate text or calibrate.
            sequence_length: Length of input sequences for testing the model.
                Set to None if your model doesn't need a fixed sequence length.
                Required if the technique needs to generate text or calibrate.
            tokenizer: The tokenizer that converts text to tokens for your model.
                Optional, but needed for most techniques.

        Raises:
            AssertionError: If context_length or sequence_length is None when the
                technique requires generation or calibration.
        """
        self.hf_model = hf_model
        self.tokenizer = tokenizer
        self.context_length = context_length
        self.sequence_length = sequence_length
        self.prepared_model: Optional[torch.nn.Module] = None
        self._logger = get_logger(self.__class__.__name__)
        self._name: str = ""  # Initialize _name attribute
        self._workspace: tempfile.TemporaryDirectory | None = None

        if self._requires_calibration or self._requires_generation:
            assert self.context_length is not None, (
                "context_length must be set if calibration or generation is required"
            )
            assert self.sequence_length is not None, (
                "sequence_length must be set if calibration or generation is required"
            )

    @property
    def workspace_dir(self) -> str:
        """Lazily create and return a temporary workspace directory.
        The directory is created on first access and cleaned up when the
        instance is garbage collected. It can be used for any temporary
        artifacts (model preparation, exports, etc.).
        Returns:
            Path to the workspace directory.
        """
        if self._workspace is None:
            self._workspace = tempfile.TemporaryDirectory(prefix="aimet_workspace_")
        return self._workspace.name

    def cleanup(self) -> None:
        """Explicitly clean up the workspace directory."""
        if self._workspace is not None:
            try:
                self._workspace.cleanup()
            except Exception as e:
                self._logger.warning("Failed to clean up workspace %s: %s", self._workspace.name, e)
            self._workspace = None

    def __enter__(self) -> "Self":
        return self

    def __exit__(self, *args) -> None:
        self.cleanup()

    @classmethod
    def from_pretrained(
        cls,
        model_id_or_path: str,
        context_length: int | None,
        sequence_length: int,
        *,
        model_kwargs: dict | None = None,
        tokenizer: AutoTokenizer | None = None,
        tokenizer_kwargs: dict | None = None,
        prepare_model: bool = False,
        model_preparation_kwargs: dict | None = None,
    ) -> "Self":
        """Load a model and tokenizer from HuggingFace Hub.

        This is a convenience method that downloads a model from HuggingFace,
        loads the tokenizer, and creates an instance of the optimizer or quantizer.

        Args:
            model_id_or_path: HuggingFace model identifier (like "meta-llama/Llama-2-7b")
                or path to a local model directory.
            context_length: Maximum number of tokens the model can process at once.
            sequence_length: Length of input sequences for testing the model.
            model_kwargs: Optional settings to pass to the model loader.
                For example: ``{"torch_dtype": torch.float16, "device_map": "auto"}``.
                Pass ``tiny_model=True`` (debug only) to reduce the model to 2 hidden layers
                for quick local testing. This flag is stripped before forwarding to
                ``AutoModelForCausalLM.from_pretrained``.
            tokenizer: Optional pre-loaded tokenizer. If provided, tokenizer_kwargs
                is ignored.
            tokenizer_kwargs: Optional settings to pass to the tokenizer loader.
                Only used if tokenizer is not provided.
            prepare_model: Whether to prepare the model immediately after loading.
                Defaults to False.
            model_preparation_kwargs: Optional settings for model preparation.
                Only used if prepare_model is True.

        Returns:
            An instance of the optimizer or quantizer with the loaded model.

        Example:
            .. code-block:: python

                # Load model and create quantizer
                quantizer = LPBQ_Quantizer.from_pretrained(
                    "meta-llama/Llama-2-7b-hf",
                    context_length=2048,
                    sequence_length=512,
                    model_kwargs={"torch_dtype": torch.float16}
                )
        """
        kwargs = dict(model_kwargs or {})

        # Debug-only: load a tiny 2-layer version of the model for fast local testing
        tiny_model = kwargs.pop("tiny_model", False)
        if tiny_model:
            config = AutoConfig.from_pretrained(model_id_or_path, **kwargs)
            config.num_hidden_layers = 2
            hf_model = AutoModelForCausalLM.from_pretrained(model_id_or_path, config=config, **kwargs)
        else:
            hf_model = AutoModelForCausalLM.from_pretrained(model_id_or_path, **kwargs)

        # Use provided tokenizer or create one
        if tokenizer is None:
            # Default tokenizer kwargs
            default_tokenizer_kwargs = {"use_fast": True, "trust_remote_code": True}

            # Merge default tokenizer kwargs with user-provided ones
            final_tokenizer_kwargs = default_tokenizer_kwargs.copy()
            if tokenizer_kwargs is not None:
                final_tokenizer_kwargs.update(tokenizer_kwargs)

            tokenizer = AutoTokenizer.from_pretrained(model_id_or_path, **final_tokenizer_kwargs)

        instance = cls(hf_model, context_length, sequence_length, tokenizer)

        if prepare_model:
            instance._prepare_model(**(model_preparation_kwargs or {}))

        return instance

    def _prepare_model(self, **kwargs):
        """Prepare the model for optimization or quantization.

        This method transforms the model to make it ready for the technique.
        The specific preparation steps depend on whether this is an optimizer
        or quantizer (implemented in subclasses).

        Args:
            **kwargs: Additional configuration options for preparation.

        Raises:
            NotImplementedError: This method must be implemented by subclasses
                (AIMETOptimizer or AIMETQuantizer).

        Note:
            This sets ``self.prepared_model`` to the prepared version of the model.
        """
        raise NotImplementedError("_prepare_model must be implemented in subclasses")

    def _prepare_inputs(
        self,
        dummy_inputs: tuple[torch.Tensor, ...] | None = None,
        generator: Optional[object] = None,
    ) -> tuple[torch.Tensor, ...]:
        """Prepare inputs for model tracing and quantization.

        Creates or returns dummy inputs used by AIMET's QuantizationSimModel to
        trace the model graph. If no dummy inputs are provided, minimal inputs
        are generated from the model's sequence_length.

        Args:
            dummy_inputs: Pre-created dummy inputs. If provided, returned as-is
                after ensuring the model is prepared.
            generator: Optional Generator instance (reserved for future use when
                generator support is fully implemented).

        Returns:
            Tuple of tensors suitable for passing to QuantizationSimModel as
            ``dummy_input``.
        """
        if self.prepared_model is None:
            self._prepare_model()
        assert self.prepared_model is not None

        if dummy_inputs is not None:
            return dummy_inputs

        seq_len = self.sequence_length or 1
        input_ids = torch.zeros((1, seq_len), dtype=torch.long)
        attention_mask = torch.ones((1, seq_len), dtype=torch.long)
        return (input_ids, attention_mask)

    @property
    def name(self) -> str:
        """Get the name of this technique.

        Returns:
            The technique name (e.g., "SeqMSE", "LPBQ", "SpinQuant").
        """
        return self._name

    @name.setter
    def name(self, value: str):
        """Set the name of this technique.

        Args:
            value: The name to set.

        Raises:
            ValueError: If trying to change the name after it's already been set.
        """
        if self._name:
            raise ValueError("Cannot change the name of the technique once it is set.")
        self._name = value
