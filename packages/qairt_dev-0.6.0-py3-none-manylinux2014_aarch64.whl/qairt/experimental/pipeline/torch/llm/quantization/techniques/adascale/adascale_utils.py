# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""AdaScale utility functions (QuantSim creation, calibration data helpers)."""

import functools
import itertools
from contextlib import contextmanager
from typing import Any, Callable, List

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from qairt.utils.loggers import get_logger

logger = get_logger(__name__)


@contextmanager
def _patch_inner_model_for_return_dict(model: torch.nn.Module):
    """Temporarily force ``model.model.forward`` to return a ``ModelOutput`` (return_dict=True).

    Fixes transformers>=4.57.0 where CausalLM wrappers (e.g. Qwen3ForCausalLM)
    access ``outputs.last_hidden_state`` even when ``config.return_dict=False``,
    causing ``AttributeError: 'tuple' object has no attribute 'last_hidden_state'``.
    """
    inner_model = getattr(model, "model", None)
    if inner_model is None:
        yield
        return

    original_forward = inner_model.forward

    @functools.wraps(original_forward)
    def _patched(*args, **kwargs):
        kwargs["return_dict"] = True
        return original_forward(*args, **kwargs)

    inner_model.forward = _patched
    logger.debug("[AdaScale] Patched inner model forward: force return_dict=True (transformers>=4.57.0)")
    try:
        yield
    finally:
        inner_model.forward = original_forward
        logger.debug("[AdaScale] Restored inner model forward")


def restore_model_config(model: torch.nn.Module, original_return_dict: Any) -> None:
    """Restore ``model.config.return_dict`` to its pre-patch value.

    No-op if ``original_return_dict`` is ``None``.
    """
    if original_return_dict is not None and hasattr(model, "config"):
        model.config.return_dict = original_return_dict
        logger.debug(f"[AdaScale] Restored model.config.return_dict={original_return_dict}")


def collect_calibration_data(dataloader: DataLoader, num_batches: int) -> List[dict]:
    """Collect raw dict batches from a dataloader (HF mode).

    Each batch is moved to CPU so that the forward function can place tensors
    on the correct device at call time.

    Raises:
        ValueError: If no calibration data could be collected.
    """
    inputs: List[dict] = []
    for sample in tqdm(
        itertools.islice(dataloader, num_batches),
        total=num_batches,
        desc="[AdaScale] Collecting calibration data",
    ):
        if isinstance(sample, dict):
            inputs.append({k: v.cpu() if isinstance(v, torch.Tensor) else v for k, v in sample.items()})
        else:
            inputs.append(sample)

    if not inputs:
        raise ValueError("[AdaScale] No calibration data collected – dataloader may be empty.")

    return inputs


def prefill_inputs(
    generator: Any,
    dataloader: DataLoader,
    num_batches: int,
    device: torch.device,
) -> List[Any]:
    """Run KV-cache prefill and collect static tensor inputs (Prefill mode).

    ...
    """
    from aimet_torch.utils import change_tensor_device_placement
    from aimet_torch.v2.utils import remove_all_quantizers

    # Validate device compatibility
    if str(generator.device) != str(device):
        logger.warning(
            f"Generator device ({generator.device}) differs from target device ({device}). "
            f"Moving generator to {device}."
        )
        # Attempt to move generator model to correct device
        try:
            generator.model = generator.model.to(device)
            generator.device = device
        except Exception as e:
            raise RuntimeError(
                f"Cannot move generator to device {device}: {e}. "
                "Please ensure generator is initialized on the correct device."
            ) from e

    inputs: List[Any] = []
    last_error = None
    try:
        with remove_all_quantizers(generator.model), torch.no_grad():
            for idx, sample in enumerate(
                tqdm(
                    itertools.islice(dataloader, num_batches),
                    total=num_batches,
                    desc="[AdaScale] Pre-filling calibration data",
                )
            ):
                try:
                    prefill_result = generator.prefill(
                        sample["input_ids"].to(device=generator.device),
                        sample["attention_mask"].to(device=generator.device),
                    )
                    inputs.extend(
                        change_tensor_device_placement(
                            list(prefill_result),
                            device=device,
                        )
                    )
                except (KeyError, RuntimeError, torch.cuda.OutOfMemoryError) as e:
                    logger.warning(
                        f"[AdaScale] Failed to prefill batch {idx}: {type(e).__name__}: {e}. Skipping."
                    )
                    if isinstance(e, torch.cuda.OutOfMemoryError):
                        logger.error("[AdaScale] CUDA OOM during prefill - consider reducing batch size")
                        raise
                    continue
    except torch.cuda.OutOfMemoryError:
        raise  # Re-raise OOM errors immediately
    except Exception as e:
        logger.error(f"[AdaScale] Critical error during prefill: {type(e).__name__}: {e}")
        raise RuntimeError(f"Prefill operation failed after processing {len(inputs)} samples") from e

    if not inputs:
        raise ValueError("[AdaScale] No prefill data collected - all batches failed")

    return inputs


def make_hf_forward_fn() -> Callable:
    """Return the default HF-mode forward function for ``apply_adascale``."""

    def forward_fn(m: torch.nn.Module, inp: dict) -> torch.Tensor:
        try:
            device = next(m.parameters()).device
        except StopIteration:
            # Fallback to checking buffers if no parameters exist
            try:
                device = next(m.buffers()).device
            except StopIteration:
                # If no parameters or buffers, assume CPU
                device = torch.device("cpu")
        inp = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in inp.items()}
        return m(**inp)

    return forward_fn
