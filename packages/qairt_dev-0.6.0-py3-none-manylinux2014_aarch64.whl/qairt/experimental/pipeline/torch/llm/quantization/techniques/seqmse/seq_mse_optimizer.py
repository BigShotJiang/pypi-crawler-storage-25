# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""SeqMSE (Sequential Mean Squared Error) optimizer implementation."""

from typing import Type

import torch
from aimet_torch.v2.seq_mse import apply_seq_mse

from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.aimet_optimizer import (
    AIMETOptimizer,
)
from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.definitions import (
    CommonParams,
    ModulePrecisions,
    OptimizationResult,
    Precisions,
    SeqMSEParams,
)
from qairt.experimental.pipeline.torch.llm.quantization.techniques.pcq.pcq_quantizer import (
    PCQQuantizer,
)
from qairt.utils.loggers import get_logger

logger = get_logger(__name__)


class SeqMSEOptimizer(AIMETOptimizer):
    """SeqMSE (Sequential Mean Squared Error) optimizer.

    SeqMSE performs layer-wise weight optimization to minimize quantization
    error. It evaluates multiple candidate weight adjustments per layer and
    selects the optimal solution by minimizing the mean squared error between
    the original and quantized layer outputs.

    An internal QuantizationSimModel is created to evaluate candidates; the
    resulting optimized weights are returned via ``OptimizationResult.model``.
    The temporary quantsim is also accessible via ``self.quantsim``.

    Example:
        .. code-block:: python

            from qairt.experimental.pipeline.torch.llm.quantization.techniques.seqmse import (
                SeqMSEOptimizer,
            )
            from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.definitions import (
                SeqMSEParams,
            )

            optimizer = SeqMSEOptimizer(model, context_length=2048, sequence_length=128)
            result = optimizer.apply(
                params=SeqMSEParams(
                    dataloader=calibration_loader,
                    num_batches=20,
                    num_candidates=20,
                )
            )
            optimized_model = result.model
    """

    _name = "SeqMSE"

    @classmethod
    def params_cls(cls) -> Type[CommonParams]:
        """Return the parameter class for SeqMSE optimization.

        Returns:
            The SeqMSEParams class.
        """
        return SeqMSEParams

    @torch.no_grad()
    def apply(self, params: CommonParams) -> OptimizationResult:
        """Apply SeqMSE weight optimization to the model.

        Creates a temporary QuantizationSimModel, then runs ``apply_seq_mse``
        to minimize per-layer quantization error across calibration batches.
        The optimized weights are extracted from the quantsim model.

        Args:
            params: SeqMSE configuration (must be a ``SeqMSEParams`` instance)
                including dataloader and candidate/batch settings.

        Returns:
            OptimizationResult with the optimized model, internal quantsim,
            and prepared model.

        Raises:
            TypeError: If ``params`` is not a ``SeqMSEParams`` instance.
            ValueError: If ``params.dataloader`` is None.
        """
        if not isinstance(params, SeqMSEParams):
            raise TypeError(f"Expected SeqMSEParams, got {type(params).__name__}")

        if params.dataloader is None:
            raise ValueError("dataloader is required for SeqMSE optimization")

        if self.prepared_model is None:
            self._prepare_model()

        assembled_dummy_inputs = self._prepare_inputs(dummy_inputs=params.dummy_inputs)

        assert self.prepared_model is not None

        quantsim = params.quantsim or PCQQuantizer._create_quantsim(
            self.prepared_model,
            assembled_dummy_inputs,
            tie_quantizers=None,
            module_precisions=ModulePrecisions(kv_cache=Precisions(weight_precision="int16")),
        )

        apply_seq_mse(
            sim=quantsim,
            data_loader=params.dataloader,
            num_candidates=params.num_candidates,
        )

        self.quantsim = quantsim

        return OptimizationResult(
            model=quantsim.model,
            quantsim=quantsim,
            prepared_model=self.prepared_model,
        )
