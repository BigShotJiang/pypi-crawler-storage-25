# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Base class for HuggingFace quantization executors."""

from functools import wraps
from typing import TYPE_CHECKING, Any, Callable, Optional

from transformers.quantizers import HfQuantizer, get_module_from_name

from qairt.utils.loggers import get_logger

if TYPE_CHECKING:
    import torch
    from transformers import PreTrainedModel

    from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.aimet_optimizer import (
        AIMETOptimizer,
    )
    from qairt.experimental.pipeline.torch.llm.quantization.techniques.bases.aimet_quantizer import (
        AIMETQuantizer,
    )

logger = get_logger(__name__)


class BaseHFQuantizer(HfQuantizer):
    """Base class to create quantization executors."""

    requires_calibration = False
    requires_parameters_quantization = True
    device: str | None = "cuda:0"

    def is_serializable(self, safe_serialization: Optional[bool] = None) -> bool:
        return True

    @property
    def is_trainable(self) -> bool:
        return False

    def check_quantized_param(  # type: ignore[override]
        self,
        model: "PreTrainedModel",
        param_value: "torch.Tensor",
        param_name: str,
        state_dict: dict,
        **kwargs,
    ) -> bool:
        """
        checks if a loaded state_dict component is part of quantized param + some validation; only defined if
        requires_parameters_quantization == True for quantization methods that require to create
        a new parameters for quantization.
        """
        return False

    def update_device_map(self, device_map: Optional[dict[str, Any]]) -> Optional[dict[str, Any]]:
        if isinstance(device_map, dict):
            self.device = next(iter(device_map.values()))
        else:
            self.device = device_map
        return device_map

    def param_needs_quantization(self, model: "PreTrainedModel", param_name: str, **kwargs) -> bool:
        """
        Check whether a given param needs quantization as defined by `create_quantized_param`.
        """
        return False

    def remove_quantization_config(self, model: "PreTrainedModel") -> None:
        """
        Remove the quantization config from the model.
        """
        if hasattr(model, "hf_quantizer"):
            del model.hf_quantizer
        if hasattr(model.config, "quantization_config"):  # type: ignore[attr-defined]
            del model.config.quantization_config  # type: ignore[attr-defined]
        if hasattr(model.config, "_pre_quantization_dtype"):  # type: ignore[attr-defined]
            del model.config._pre_quantization_dtype  # type: ignore[attr-defined]
        if hasattr(model, "quantization_method"):
            del model.quantization_method
        model.is_quantized = False  # type: ignore[attr-defined, assignment]

    def __init_subclass__(cls, **kwargs) -> None:
        """
        Automatically wraps the subclass's `_process_model_after_weight_loading`
        (if overridden) so that `remove_quantization_config(model)` is guaranteed
        to run afterwards, without the subclass needing to call it explicitly.
        """
        super().__init_subclass__(**kwargs)

        # Only wrap if the subclass overrides the method itself
        if "_process_model_after_weight_loading" in cls.__dict__:
            original = cls.__dict__["_process_model_after_weight_loading"]

            @wraps(original)
            def _wrapped(self, model: "PreTrainedModel", **kw):
                try:
                    return original(self, model, **kw)
                finally:
                    self.remove_quantization_config(model)

            setattr(cls, "_process_model_after_weight_loading", _wrapped)

    def _process_model_before_weight_loading(self, model: "PreTrainedModel", **kwargs) -> None:
        raise NotImplementedError(
            f"{self.quantization_config.quant_method} has no implementation of "
            "`_process_model_before_weight_loading`."
        )

    def _process_model_after_weight_loading(self, model: "PreTrainedModel", **kwargs) -> "PreTrainedModel":
        """
        Abstract: subclasses MUST override this method to perform post-weight-loading work.
        Even when overridden, `remove_quantization_config(model)` will be executed automatically
        after the subclass logic via the wrapper installed in `__init_subclass__`.
        """
        raise NotImplementedError(
            f"{self.quantization_config.quant_method} must override `_process_model_after_weight_loading`."
        )

    def create_quantized_param(  # type: ignore[override]
        self,
        model: "PreTrainedModel",
        param_value: "torch.Tensor",
        param_name: str,
        target_device: "torch.device",
        state_dict: dict[str, Any],
        unexpected_keys: Optional[list[str]] = None,
    ) -> None:
        # Sanity check
        module, tensor_name = get_module_from_name(model, param_name)
        # This will check potential shape mismatch if skipped before
        module.load_state_dict({tensor_name: param_value.to(target_device)}, strict=False, assign=True)

    def _get_save_pretrained_with_export(
        self, model: "PreTrainedModel", original_save_pretrained: Callable
    ) -> Callable:
        """Create a save_pretrained wrapper that exports AIMET artifacts.

        This method wraps the original `save_pretrained()` to also export AIMET
        artifacts (quantsim model, encodings, etc.) when the model is saved.

        Args:
            model: The model to attach the wrapper to.
            original_save_pretrained: The original save_pretrained method to wrap.

        Returns:
            A wrapped save_pretrained function that exports AIMET artifacts.
        """

        def save_pretrained_with_export(save_directory: str, *args, **kwargs):  # type: ignore[no-untyped-def]
            """Extended save_pretrained that also exports AIMET artifacts."""
            result = original_save_pretrained(save_directory, *args, **kwargs)

            if hasattr(model, "_aimet_instance") and model._aimet_instance is not None:
                logger.debug(f"Exporting AIMET artifacts to {save_directory}...")
                try:
                    if hasattr(model._aimet_instance, "export"):
                        model._aimet_instance.export(save_directory)
                    logger.debug("AIMET artifacts exported successfully")
                except Exception as e:
                    logger.warning(f"Failed to export AIMET artifacts: {e}")

            return result

        return save_pretrained_with_export

    def post_init_model(self, model: "PreTrainedModel") -> "PreTrainedModel":
        """
        Post-initialization after quantization. Attach instance to model for export.

        Args:
            model: The quantized model.

        Returns:
            The model with instance reference attached.
        """
        # Store instance reference for export during save_pretrained
        # This can be either AIMETQuantizer or AIMETOptimizer
        model._aimet_instance = self._quantizer  # type: ignore[attr-defined]
        return model
