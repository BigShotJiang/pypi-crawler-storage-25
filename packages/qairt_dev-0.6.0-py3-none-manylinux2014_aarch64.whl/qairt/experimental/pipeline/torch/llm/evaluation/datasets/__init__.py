# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Dataset registry for evaluation."""

from __future__ import annotations

from typing import Any

import torch

from .base import EvaluationDataset
from .c4 import C4
from .wikitext import Wikitext

_DATASET_REGISTRY: dict[str, type[EvaluationDataset]] = {
    "wikitext": Wikitext,
    "c4": C4,
}


def load_evaluation_dataset(
    name: str, tokenizer: Any, context_length: int, **kwargs
) -> torch.utils.data.Dataset:
    """Look up a dataset by name and load it."""
    if name not in _DATASET_REGISTRY:
        raise KeyError(f"Unknown dataset: {name!r}. Available: {list(_DATASET_REGISTRY)}")
    return _DATASET_REGISTRY[name].load(tokenizer=tokenizer, context_length=context_length, **kwargs)


__all__ = ["load_evaluation_dataset", "C4", "Wikitext"]
