# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Base classes for evaluation datasets."""

from abc import ABC, abstractmethod
from typing import Any

import torch


class EvaluationDataset(ABC):
    """Base class for all evaluation datasets."""

    @staticmethod
    @abstractmethod
    def load(tokenizer: Any, context_length: int, **kwargs: Any) -> torch.utils.data.Dataset:
        """Load and return a chunked evaluation dataset.

        Args:
            tokenizer: Tokenizer used to encode the raw text.
            context_length: Number of tokens per chunk.
            **kwargs: Dataset-specific options (e.g. ``split``, ``num_samples``).

        Returns:
            A ``torch.utils.data.Dataset`` yielding tokenized chunks.
        """
        ...


class ChunkedDataset(torch.utils.data.Dataset):
    """Splits a tokenized sequence into fixed-length chunks.

    Each item is a dict with ``input_ids`` and ``attention_mask``,
    both of shape ``(size_per_chunk,)``.
    """

    def __init__(self, tokenized_data: dict[str, torch.Tensor], size_per_chunk: int):
        """Initialise a ChunkedDataset.

        Args:
            tokenized_data: Dict with ``"input_ids"`` and ``"attention_mask"``
                tensors, each of shape ``(1, total_tokens)``.
            size_per_chunk: Number of tokens per chunk.
        """
        self.tokenized_data = tokenized_data
        self.size_per_chunk = size_per_chunk

    def __len__(self) -> int:
        return len(self.tokenized_data["input_ids"][0]) // self.size_per_chunk

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        """Return the *index*-th chunk.

        Args:
            index: Zero-based chunk index.

        Returns:
            Dict with ``"input_ids"`` and ``"attention_mask"`` tensors,
            each of shape ``(size_per_chunk,)``.
        """
        start = index * self.size_per_chunk
        end = (index + 1) * self.size_per_chunk
        return {
            "input_ids": self.tokenized_data["input_ids"][0, start:end],
            "attention_mask": self.tokenized_data["attention_mask"][0, start:end],
        }
