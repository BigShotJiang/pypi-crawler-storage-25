# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Metric registry for evaluation."""

from .base import EvaluationMetric
from .perplexity import Perplexity

_METRIC_REGISTRY: dict[str, type[EvaluationMetric]] = {
    "PPL": Perplexity,
}


def get_metric(name: str) -> type[EvaluationMetric]:
    """Look up a metric class by name."""
    if name not in _METRIC_REGISTRY:
        raise KeyError(f"Unknown metric: {name!r}. Available: {list(_METRIC_REGISTRY)}")
    return _METRIC_REGISTRY[name]


__all__ = ["get_metric", "EvaluationMetric", "Perplexity"]
