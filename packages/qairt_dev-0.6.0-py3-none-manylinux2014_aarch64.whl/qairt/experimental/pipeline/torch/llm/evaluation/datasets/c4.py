# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""C4 evaluation dataset."""

from .base import ChunkedDataset, EvaluationDataset


class C4(EvaluationDataset):
    """Streams ``allenai/c4`` (English), tokenizes, and chunks."""

    @staticmethod
    def load(
        tokenizer,
        context_length: int,
        config: str = "en",
        num_samples: int = 2048,
        **kwargs,
    ) -> ChunkedDataset:
        """Stream C4, tokenize, and chunk.

        Args:
            tokenizer: HuggingFace-compatible tokenizer.
            context_length: Number of tokens per chunk.
            config: C4 configuration name (default ``"en"``).
            num_samples: Number of streaming samples to consume (default 2048).
            **kwargs: Additional keyword arguments (unused).

        Returns:
            A ``ChunkedDataset`` of tokenized, fixed-length chunks.
        """
        from datasets import Dataset as HFDataset
        from datasets import load_dataset

        stream = load_dataset("allenai/c4", name=config, split="train", streaming=True)
        dataset_split = HFDataset.from_list(list(stream.take(num_samples)))

        join_token = "\n\n" if tokenizer.bos_token is None else tokenizer.bos_token

        encoded = tokenizer(
            join_token.join(dataset_split["text"]),
            return_tensors="pt",
            add_special_tokens=True,
        )

        return ChunkedDataset(encoded, context_length)
