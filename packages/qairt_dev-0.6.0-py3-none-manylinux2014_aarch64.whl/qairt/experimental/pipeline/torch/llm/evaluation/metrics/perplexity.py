# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Perplexity (PPL) evaluation metric."""

from __future__ import annotations

import math
import warnings
from typing import Any, Optional

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from ..datasets import load_evaluation_dataset
from .base import EvaluationMetric


def _device_of(model: torch.nn.Module) -> torch.device:
    """Return the device of the first parameter of *model*.

    Args:
        model: A ``torch.nn.Module`` with at least one parameter.

    Returns:
        The ``torch.device`` where the first parameter resides.

    Raises:
        ValueError: If the model has no parameters.
    """
    param = next(model.parameters(), None)
    if param is None:
        raise ValueError(f"Model {type(model).__name__} has no parameters — cannot determine device.")
    return param.device


def _cross_entropy_loss(logits: torch.Tensor, input_ids: torch.Tensor) -> torch.Tensor:
    """Compute causal-LM cross-entropy loss between shifted logits and labels.

    Args:
        logits: Model output logits, shape ``(batch, seq_len, vocab_size)``.
        input_ids: Ground-truth token ids, shape ``(batch, seq_len)``.

    Returns:
        Scalar loss tensor (mean negative log-likelihood).
    """
    # Shift: position i predicts position i+1
    shift_logits = logits[..., :-1, :].contiguous().to(dtype=torch.float32)
    shift_labels = input_ids[..., 1:].contiguous().to(shift_logits.device)

    loss_fn = torch.nn.CrossEntropyLoss()
    return loss_fn(
        shift_logits.view(-1, shift_logits.size(-1)),
        shift_labels.view(-1),
    )


class Perplexity(EvaluationMetric):
    """Perplexity metric using PyTorch evaluation."""

    name = "PPL"

    def __init__(
        self,
        dataset_name: str = "wikitext",
        batch_size: int = 1,
        max_batches: Optional[int] = None,
        dataset_kwargs: Optional[dict[str, Any]] = None,
        model_forward_kwargs: Optional[dict[str, Any]] = None,
        **extra,  # absorb unknown keys from YAML without error
    ):
        """Initialise the Perplexity metric.

        Args:
            dataset_name: Evaluation dataset name (default ``"wikitext"``).
            batch_size: Batch size for the dataloader (default 1).
            max_batches: If set, stop evaluation after this many batches.
            dataset_kwargs: Extra keyword arguments passed to the dataset
                loader (e.g. ``split``, ``num_samples``).
            model_forward_kwargs: Extra keyword arguments forwarded to
                ``model.forward()`` during torch evaluation.
            **extra: Unknown keys from YAML config; triggers a warning.
        """
        self.dataset_name = dataset_name
        self.batch_size = batch_size
        self.max_batches = max_batches
        self.dataset_kwargs = dataset_kwargs or {}
        self.model_forward_kwargs = model_forward_kwargs or {}
        if extra:
            warnings.warn(
                f"Perplexity received unexpected kwargs that will be ignored: {sorted(extra)}. "
                "Check for typos in your metric config.",
                UserWarning,
                stacklevel=2,
            )

    def evaluate(self, model: Any, tokenizer: Any, context_length: int, **kwargs) -> float:
        """Compute perplexity using PyTorch evaluation.

        Args:
            model: A ``torch.nn.Module`` whose forward pass returns logits.
            tokenizer: Tokenizer compatible with *model*.
            context_length: Maximum sequence length for evaluation chunks.
            **kwargs: Additional options (unused, reserved for future backends).

        Returns:
            Perplexity score (lower is better).
        """
        return self._evaluate_torch(model, tokenizer, context_length)

    def _evaluate_torch(self, model: torch.nn.Module, tokenizer: Any, context_length: int) -> float:
        """Standard PyTorch evaluation — works with nn.Module, merged LoRA, unmerged LoRA.

        Args:
            model: A ``torch.nn.Module`` whose first output is logits.
            tokenizer: HuggingFace-compatible tokenizer.
            context_length: Number of tokens per evaluation chunk.

        Returns:
            Perplexity score.
        """
        dataset = load_evaluation_dataset(self.dataset_name, tokenizer, context_length, **self.dataset_kwargs)
        dataloader = DataLoader(dataset, batch_size=self.batch_size)
        device = _device_of(model)

        losses: list[torch.Tensor] = []
        total = self.max_batches or len(dataloader)
        for i, batch in tqdm(
            enumerate(dataloader), total=total, desc=f"Evaluating PPL ({self.dataset_name})"
        ):
            if self.max_batches is not None and i >= self.max_batches:
                break

            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)

            with torch.no_grad():
                outputs = model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    **self.model_forward_kwargs,
                )

            logits = outputs.logits if hasattr(outputs, "logits") else outputs[0]
            losses.append(_cross_entropy_loss(logits, input_ids))
            del outputs

        mean_loss = torch.stack(losses).mean().item() if losses else float("inf")
        try:
            return float(math.exp(mean_loss))
        except OverflowError:
            return float("inf")
