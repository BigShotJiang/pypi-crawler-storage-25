# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Wikitext-2 evaluation dataset."""

from .base import ChunkedDataset, EvaluationDataset


class Wikitext(EvaluationDataset):
    """Loads ``Salesforce/wikitext`` (wikitext-2-raw-v1), tokenizes, and chunks."""

    @staticmethod
    def load(tokenizer, context_length: int, split: str = "test", **kwargs) -> ChunkedDataset:
        """Load Wikitext-2, tokenize, and chunk.

        Args:
            tokenizer: HuggingFace-compatible tokenizer.
            context_length: Number of tokens per chunk.
            split: Dataset split to load (default ``"test"``).
            **kwargs: Additional keyword arguments (unused).

        Returns:
            A ``ChunkedDataset`` of tokenized, fixed-length chunks.
        """
        from datasets import load_dataset

        dataset_split = load_dataset("Salesforce/wikitext", "wikitext-2-raw-v1", split=split)

        # Use BOS for train split, "\n\n" for test or when BOS is unavailable.
        join_token = "\n\n" if split == "test" or tokenizer.bos_token is None else tokenizer.bos_token

        encoded = tokenizer(
            join_token.join(dataset_split["text"]),
            return_tensors="pt",
            add_special_tokens=True,
        )

        return ChunkedDataset(encoded, context_length)
