# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Core evaluation orchestrator."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from qairt.utils.loggers import get_logger

from .metrics import get_metric

logger = get_logger(__name__)


def run_evaluation(
    metrics_config: list[dict[str, Any]],
    model: Optional[Any] = None,
    tokenizer: Optional[Any] = None,
    context_length: int = 2048,
    model_forward_kwargs: Optional[dict[str, Any]] = None,
    output_dir: Optional[str] = None,
    **kwargs,
) -> dict[str, float]:
    """Run all configured metrics and return ``{display_name: score}``.

    Args:
        metrics_config: List of metric specification dicts. Each dict must
            contain a ``"name"`` key (e.g. ``"PPL"``) plus any metric-specific
            options.
        model: The model to evaluate (``torch.nn.Module``).
        tokenizer: Tokenizer compatible with *model*.
        context_length: Maximum sequence length for evaluation chunks.
        model_forward_kwargs: Extra keyword arguments forwarded to
            ``model.forward()`` (e.g. ``use_cache``).
        output_dir: If provided, results are written as JSON and plain-text
            tables to this directory.
        **kwargs: Additional options forwarded to each metric's
            ``evaluate()`` call.

    Returns:
        Dictionary mapping ``display_name`` to the scalar metric score.
    """
    results: dict[str, float] = {}
    detailed: list[dict[str, Any]] = []
    name_counts: dict[str, int] = {}

    for metric_spec in metrics_config:
        spec = dict(metric_spec)
        if "name" not in spec:
            raise ValueError(f"Metric config entry missing required 'name' key: {metric_spec}")
        metric_name = spec.pop("name")
        dataset_name = spec.get("dataset_name", "")

        if model_forward_kwargs and "model_forward_kwargs" not in spec:
            spec["model_forward_kwargs"] = model_forward_kwargs

        metric_cls = get_metric(metric_name)
        metric = metric_cls(**spec)
        score = metric.evaluate(model, tokenizer, context_length, **kwargs)

        base_name = f"{metric_name}_{dataset_name}" if dataset_name else metric_name
        count = name_counts.get(base_name, 0)
        name_counts[base_name] = count + 1
        display_name = base_name if count == 0 else f"{base_name}_{count + 1}"

        results[display_name] = score
        detailed.append(
            {
                "display_name": display_name,
                "score": score,
                "config": metric_spec,
            }
        )
        logger.info(f"  {display_name}: {score:.4f}")

    _print_results_table(results)

    if output_dir:
        _write_results(results, detailed, output_dir)

    return results


def _print_results_table(results: dict[str, float]) -> None:
    """Log a results summary table.

    Args:
        results: Mapping of metric display names to scores.
    """
    sep = "-" * 44
    lines = [
        "",
        sep,
        "  Evaluation Results",
        sep,
        f"  {'Metric':<30} {'Score':>12}",
        f"  {'-' * 30} {'-' * 12}",
    ]
    for name, score in results.items():
        lines.append(f"  {name:<30} {score:>12.4f}")
    lines.append(sep)
    logger.info("\n".join(lines))


def _write_results(
    results: dict[str, float],
    detailed: list[dict[str, Any]],
    output_dir: str,
) -> None:
    """Write results as JSON and text table to *output_dir*.

    Args:
        results: Mapping of metric display names to scores.
        detailed: List of per-metric dicts with ``display_name``, ``score``,
            and the original ``config``.
        output_dir: Directory to write ``evaluation_results.json`` and
            ``evaluation_results.txt`` into.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    json_payload = {
        "metrics": detailed,
        "summary": results,
    }
    json_path = out / "evaluation_results.json"
    json_path.write_text(json.dumps(json_payload, indent=2))
    logger.info(f"Results JSON written to {json_path}")

    table_path = out / "evaluation_results.txt"
    lines = [
        f"{'Metric':<30} {'Score':>12}",
        f"{'-' * 30} {'-' * 12}",
    ]
    for name, score in results.items():
        lines.append(f"{name:<30} {score:>12.4f}")
    table_path.write_text("\n".join(lines))
    logger.info(f"Results table written to {table_path}")
