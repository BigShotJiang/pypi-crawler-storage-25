# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Base class for evaluation metrics."""

from abc import ABC, abstractmethod
from typing import Any


class EvaluationMetric(ABC):
    """Base class for all evaluation metrics.

    Subclasses are instantiated with metric-specific kwargs (from the YAML
    recipe) and must implement ``evaluate()`` which returns a scalar score.
    """

    name: str

    @abstractmethod
    def evaluate(
        self,
        model: Any,
        tokenizer: Any,
        context_length: int,
        **kwargs,
    ) -> float:
        """Run evaluation and return a scalar score.

        Args:
            model: The model to evaluate (``torch.nn.Module``).
            tokenizer: Tokenizer compatible with the model.
            context_length: Maximum sequence length for evaluation chunks.
            **kwargs: Additional options forwarded to the evaluation backend.

        Returns:
            Scalar metric score.
        """
        ...
