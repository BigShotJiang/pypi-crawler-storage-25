# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""LLM Generator class to restore HF API on models with static shape constraints"""

from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional, Tuple, Union, cast

import torch
from torch import Tensor
from transformers import PretrainedConfig, PreTrainedTokenizer
from transformers.cache_utils import Cache, DynamicCache
from transformers.generation import GenerationConfig, GenerationMixin
from transformers.masking_utils import create_causal_mask
from transformers.modeling_outputs import CausalLMOutputWithPast

from qairt.experimental.pipeline.torch.llm.utils.llm_io import IOType, LlmIO, LlmIOConfig


def get_past_keyval_with_shift(
    past_key_vals: List[Tuple[torch.Tensor, torch.Tensor]],
    new_key_vals: List[Tuple[torch.Tensor, torch.Tensor]],
    length: int,
    device: torch.device = torch.device("cpu"),
    dtype: torch.dtype = torch.float32,
    transposed_key_cache: bool = False,
) -> List[Tuple[torch.Tensor, torch.Tensor]]:
    """Combine past_key_vals with new_key_vals and clip to at most ``length`` tokens of context.

    Concatenates existing cached key/value tensors with newly computed ones,
    then clips the result so the sequence dimension does not exceed ``length``.

    When ``transposed_key_cache`` is ``True``:
        Key tensors have shape ``(batch, heads, head_dim, seq_len)`` and are
        concatenated on ``dim=3``.
        Value tensors have shape ``(batch, heads, seq_len, head_dim)`` and are
        concatenated on ``dim=2``.

    When ``transposed_key_cache`` is ``False``:
        Both key and value tensors are concatenated on ``dim=2``.

    Args:
        past_key_vals: Previously cached key/value pairs, each element being a
            ``(key, value)`` tuple. Pass an empty list when there is no prior
            cache.
        new_key_vals: Newly computed key/value pairs for the current step, each
            element being a ``(key, value)`` tuple. Must have the same number of
            layers as ``past_key_vals`` when ``past_key_vals`` is non-empty.
        length: Maximum number of tokens to retain in the sequence dimension
            after concatenation.
        device: Target device for the output tensors. Defaults to
            ``torch.device("cpu")``.
        dtype: Target data type for the output tensors. Defaults to
            ``torch.float32``.
        transposed_key_cache: If ``True``, key tensors are treated as
            transposed ``(batch, heads, head_dim, seq_len)`` and clipped on
            ``dim=3``. Defaults to ``False``.

    Returns:
        A list of ``(key, value)`` tuples with the same number of layers as
        ``new_key_vals``, where each tensor's sequence dimension is clipped to
        at most ``length`` tokens and cast to ``dtype`` on ``device``.
    """
    ret = []

    # Determine the concatenation axes based on transposed_key_cache
    key_concat_axis = 3 if transposed_key_cache else 2
    value_concat_axis = 2  # Always 2 for value

    # Key and Values are concatenated on sequence dimension
    for i in range(len(new_key_vals)):
        key_cache = new_key_vals[i][0].to(device)
        value_cache = new_key_vals[i][1].to(device)
        if len(past_key_vals) > 0:
            key_cache = torch.cat(
                (past_key_vals[i][0].to(device), new_key_vals[i][0].to(device)), dim=key_concat_axis
            )
            value_cache = torch.cat(
                (past_key_vals[i][1].to(device), new_key_vals[i][1].to(device)), dim=value_concat_axis
            )

        if transposed_key_cache:
            key_cache = key_cache[:, :, :, :length]
        else:
            key_cache = key_cache[:, :, :length, :]
        value_cache = value_cache[:, :, :length, :]
        ret.append((key_cache.to(dtype=dtype), value_cache.to(dtype=dtype)))
    return ret


class LLMGenerationMixin(GenerationMixin):
    """
    Helper class to restore HuggingFace LLM API to Torch and ONNX models with static shape requirements, including
    the `forward` and `generate` APIs
    """

    io_config: Optional[LlmIOConfig] = None

    @classmethod
    def create_position_embeddings(cls, model, config, position_ids, dtype=torch.float32):
        """Create position embeddings for the model.

        Args:
            model: The language model containing a ``RotaryEmbedding`` submodule.
            config (PretrainedConfig): Model configuration used to determine the
                head dimension (``config.head_dim`` or
                ``config.hidden_size // config.num_attention_heads``).
            position_ids (torch.Tensor): Position indices of shape
                ``(batch, seq_len)``.
            dtype (torch.dtype): Data type for the output embeddings. Defaults
                to ``torch.float32``.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: A ``(cos, sin)`` pair, each of
            shape ``(batch, 1, seq_len, head_dim // 2)``.
        """
        # Determine the head dimension
        if hasattr(config, "head_dim"):
            dim = config.head_dim
        else:
            dim = int(config.hidden_size // config.num_attention_heads)

        device = position_ids.device
        x = torch.ones(1, device=device, dtype=dtype)

        # Get the pre-initialized rotary_emb from the model
        rotary_emb = model.rotary_emb(model.config)

        # Generate and format cos, sin
        cos, sin = rotary_emb(x, position_ids=position_ids)
        cos, sin = cos.unsqueeze(dim=1), sin.unsqueeze(dim=1)

        # Keep only the first half of the dimension for standard RoPE formatting
        cos = cos[:, :, :, : dim // 2]
        sin = sin[:, :, :, : dim // 2]

        return cos, sin

    def prepare_inputs_for_generation(
        self,
        input_ids: torch.LongTensor,
        past_key_values: Cache | None = None,
        attention_mask: Optional[torch.LongTensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        cache_position: Optional[torch.LongTensor] = None,
        **kwargs: Any,
    ) -> Dict[str, Union[torch.Tensor, Cache, None]]:
        """Prepare model inputs for a single generation step.

        Overrides the HuggingFace ``GenerationMixin.prepare_inputs_for_generation``
        to support models with static graph constraints. Slices away already-
        processed tokens from ``input_ids`` or ``inputs_embeds`` based on the
        number of tokens present in ``past_key_values``.

        Args:
            input_ids (torch.LongTensor): Token IDs of shape ``(batch, seq_len)``.
                Mutually exclusive with ``inputs_embeds``.
            past_key_values (Cache | None): Cache object holding previously
                computed key/value states. If ``None``, no tokens have been
                processed yet.
            attention_mask (torch.LongTensor | None): Attention mask of shape
                ``(batch, seq_len)``. Passed through unchanged.
            inputs_embeds (torch.FloatTensor | None): Pre-computed input
                embeddings of shape ``(batch, seq_len, hidden_dim)``. Mutually
                exclusive with ``input_ids``.
            cache_position (torch.LongTensor | None): Unused; kept for API
                compatibility with HuggingFace ``GenerationMixin``.
            **kwargs: Additional keyword arguments forwarded to the model.

        Returns:
            Dict[str, torch.Tensor | Cache | None]: A dictionary containing
            ``"input_ids"`` or ``"inputs_embeds"`` (sliced to unprocessed
            tokens), ``"attention_mask"``, and ``"past_key_values"``.

        Raises:
            ValueError: If both ``input_ids`` and ``inputs_embeds`` are provided,
                or if neither is provided.
        """

        if (input_ids is None) ^ (inputs_embeds is not None):
            raise ValueError("Exactly one of `input_ids` or `inputs_embeds` must be provided.")

        num_processed_tokens = 0
        if past_key_values is not None:
            num_processed_tokens = (
                past_key_values.get_seq_length()
                if not isinstance(past_key_values, tuple)
                else past_key_values[0][1].shape[-2]
            )

        inputs: Dict[str, Union[torch.Tensor, Cache, None]]
        if input_ids is not None:
            inputs = {"input_ids": input_ids[:, num_processed_tokens:]}
        else:
            assert inputs_embeds is not None
            inputs = {"inputs_embeds": inputs_embeds[:, num_processed_tokens:, :]}

        # Add attention mask, ensuring it remains as an integer type for precision
        # Cast to int32 or int64 to maintain binary mask integrity
        if attention_mask is not None and hasattr(self, "model"):
            # Keep as integer type to avoid precision issues
            attention_mask = cast(torch.LongTensor, attention_mask.to(dtype=torch.long))
        inputs |= {"attention_mask": attention_mask, "past_key_values": past_key_values}

        return inputs

    @classmethod
    def get_input_names(cls, num_layers: int, *, io_type: Optional[IOType] = None) -> Tuple[str, ...]:
        """Return the ordered input tensor names for a model with ``num_layers`` transformer layers.

        Uses ``cls.io_config`` when it is set and its ``io_type`` matches the
        requested *io_type* (or when *io_type* is ``None``).  A new
        :class:`LlmIOConfig` is created when ``cls.io_config`` is ``None`` or
        when *io_type* is provided and differs from ``cls.io_config.io_type``.

        Args:
            num_layers (int): Number of transformer layers (i.e., the number of
                key/value cache pairs).
            io_type (IOType | None): Naming convention for input tensors.
                Defaults to ``IOType.GENIE`` when no ``io_config`` is set.

        Returns:
            Tuple[str, ...]: Ordered tuple of input tensor names.
        """
        config = cls._resolve_io_config(num_layers, io_type)
        return tuple(LlmIO.from_config(config).get_input_names())

    @classmethod
    def get_output_names(cls, num_layers: int, *, io_type: Optional[IOType] = None) -> Tuple[str, ...]:
        """Return the ordered output tensor names for a model with ``num_layers`` transformer layers.

        Uses ``cls.io_config`` when it is set and its ``io_type`` matches the
        requested *io_type* (or when *io_type* is ``None``).  A new
        :class:`LlmIOConfig` is created when ``cls.io_config`` is ``None`` or
        when *io_type* is provided and differs from ``cls.io_config.io_type``.

        Args:
            num_layers (int): Number of transformer layers (i.e., the number of
                key/value cache pairs).
            io_type (IOType | None): Naming convention for output tensors.
                Defaults to ``IOType.GENIE`` when no ``io_config`` is set.

        Returns:
            Tuple[str, ...]: Ordered tuple of output tensor names.
        """
        config = cls._resolve_io_config(num_layers, io_type)
        return tuple(LlmIO.from_config(config).get_output_names())

    @classmethod
    def _resolve_io_config(
        cls,
        num_layers: int,
        io_type: Optional[IOType],
    ) -> LlmIOConfig:
        """Return the :class:`LlmIOConfig` to use for name generation.

        Returns ``cls.io_config`` when it is set and its ``io_type`` is
        compatible with *io_type*.  A new config is created when:

        - ``cls.io_config`` is ``None``, or
        - *io_type* is provided and differs from ``cls.io_config.io_type``.

        Args:
            num_layers (int): Number of transformer layers used when creating a
                new config.
            io_type (IOType | None): Requested IO type.  ``None`` means "use
                whatever is already configured".

        Returns:
            LlmIOConfig: The config to use.
        """
        if cls.io_config is not None:
            if io_type is None or io_type == cls.io_config.io_type:
                return cls.io_config

        effective_io_type = io_type if io_type is not None else IOType.GENIE
        return LlmIOConfig(
            num_hidden_layers=num_layers,
            io_type=effective_io_type,
            use_position_embedding_input=False,
        )

    @classmethod
    def _resolve_llm_io(cls, num_layers: int) -> LlmIO:
        """Return the :class:`LlmIO` instance for ONNX export / model preparation.

        Unlike :meth:`_resolve_io_config`, the fallback uses
        ``use_position_embedding_input=True`` so that position embeddings appear
        as separate ``position_ids_cos`` / ``position_ids_sin`` nodes in the
        exported graph.

        Args:
            num_layers (int): Number of transformer layers.

        Returns:
            LlmIO: The IO specification for model preparation.
        """
        if cls.io_config is not None:
            return LlmIO.from_config(cls.io_config)
        return LlmIO(num_hidden_layers=num_layers, io_type=IOType.GENIE)

    @classmethod
    def _prepare_attention_mask(
        cls,
        shape: Tuple,
        attention_mask: Optional[torch.Tensor],
        context_length: int,
        sequence_length: int,
        past_key_values: List[Tuple[torch.Tensor, torch.Tensor]],
        device: torch.device,
        cache_index: Optional[torch.Tensor] = None,
        **kwargs: Any,
    ) -> torch.Tensor:
        """Prepare a padded attention mask that accounts for the KV cache.

        Creates or extends the attention mask to cover both the current input
        tokens and the tokens already stored in ``past_key_values``. The
        resulting mask has shape ``(batch, context_length)`` and ensures the
        model attends only to valid (non-padding) positions.

        Args:
            shape (tuple): Shape of the current input, expected to be
                ``(batch_size, input_length)``.
            attention_mask (torch.Tensor | None): Existing attention mask of
                shape ``(batch, input_length)``. If ``None``, a mask of ones is
                created automatically.
            context_length (int): Total context window size (KV cache capacity +
                sequence length).
            sequence_length (int): Maximum number of tokens consumed per
                inference step (ARN length).
            past_key_values (List[Tuple[torch.Tensor, torch.Tensor]]): Cached
                key/value pairs from previous steps. Used to determine how many
                KV positions are already occupied.
            device (torch.device): Target device for newly created tensors.
            cache_index (torch.Tensor | None): Position in the KV cache
                at which the current tokens should be inserted. If ``None``,
                the current tokens are appended after all cached tokens.
            **kwargs: Additional keyword arguments (unused; reserved for
                subclass compatibility).

        Returns:
            torch.Tensor: Padded attention mask of shape
            ``(batch, context_length)`` with ``1`` for valid positions and
            ``0`` for padding.

        Raises:
            ValueError: If ``shape`` does not have exactly 2 dimensions.
        """

        if len(shape) != 2:
            raise ValueError("Expected shape of size 2")

        batch_size, input_length = shape

        # Create an attention mask if none is provided
        if attention_mask is None:
            attention_mask = torch.ones((batch_size, input_length), dtype=torch.long, device=device)

        if attention_mask.shape[1] > sequence_length:
            raise ValueError(
                f"attention_mask length ({attention_mask.shape[1]}) exceeds sequence_length ({sequence_length})."
            )

        attention_mask_extension = torch.zeros(
            (attention_mask.shape[0], sequence_length - attention_mask.shape[1]),
            dtype=torch.long,
            device=attention_mask.device,
        )

        # Pad attention mask to [batch_size, sequence_length] (necessary for static shape requirements)

        padded_attention_mask = torch.cat((attention_mask, attention_mask_extension), dim=1)

        past_kv_length = (
            past_key_values[0][1].shape[
                -2
            ]  # past_key_values[0] is (key, value) tuple, so [0][1] gets the value tensor
            if past_key_values
            else 0
        )

        # Mask out zero-padded entries in KV cache that go over past KV length.
        past_kv_attention_mask = torch.ones((batch_size, past_kv_length), dtype=torch.long, device=device)
        past_kv_attention_mask_extension = torch.zeros(
            (batch_size, (context_length - sequence_length) - past_kv_length),
            dtype=torch.long,
            device=device,
        )

        padded_kv_attention_mask = torch.cat(
            (past_kv_attention_mask, past_kv_attention_mask_extension), dim=1
        ).to(device)

        # Retrieve cache_index if provided
        if cache_index is None:
            padded_attention_mask = torch.cat((padded_kv_attention_mask, padded_attention_mask), dim=1)
        else:
            # Insert attention mask according to cache position
            padded_attention_mask = torch.cat(
                (
                    padded_kv_attention_mask[:, :cache_index],
                    padded_attention_mask,
                    padded_kv_attention_mask[:, cache_index:],
                ),
                dim=1,
            )

        return padded_attention_mask

    @classmethod
    def prepare_inputs(
        cls,
        model,
        input_ids: Optional[torch.Tensor],
        attention_mask: Optional[torch.Tensor],
        past_key_values: List[Tuple[torch.Tensor, torch.Tensor]],
        sequence_length: int,
        context_length: int,
        attention_mask_min: int = -100,
        inputs_embeds: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        *,
        cache_index: Optional[torch.Tensor] = None,
        pad_token: int = 0,
        config: Optional[PretrainedConfig] = None,
        dtype: Optional[torch.dtype] = None,
        **kwargs,
    ) -> Dict[str, Union[Tensor, Tuple[Tensor, Tensor], List[Tuple[Tensor, Tensor]]]]:
        """Prepare all inputs for a model forward pass under static graph constraints.

        Args:
            model: The language model. Used to access ``model.config``,
                ``model.dtype``, ``model.device``, and the RoPE layer.
            input_ids (torch.Tensor | None): Token IDs of shape
                ``(batch, input_length)``. Mutually exclusive with
                ``inputs_embeds``.
            attention_mask (torch.Tensor | None): Attention mask of shape
                ``(batch, input_length)``. If ``None``, a mask of ones is
                created.
            past_key_values (List[Tuple[torch.Tensor, torch.Tensor]]): Cached
                key/value pairs from previous steps. Pass an empty list for the
                first step.
            sequence_length (int): Static sequence length (ARN) the model
                expects per forward pass.
            context_length (int): Total context window size (KV cache capacity +
                sequence length).
            attention_mask_min (int): Minimum value used to clamp the causal
                attention mask (large negative number to mask out positions).
                Defaults to ``-100``.
            inputs_embeds (torch.Tensor | None): Pre-computed embeddings of
                shape ``(batch, input_length, hidden_dim)``. Mutually exclusive
                with ``input_ids``.
            position_ids (torch.Tensor | None): Explicit position IDs of shape
                ``(batch, input_length)``. If ``None``, they are derived from
                the cumulative sum of the attention mask.
            cache_index (torch.Tensor | None): KV cache write position
                for the current step. If ``None``, it is inferred from the
                length of ``past_key_values``.
            pad_token (int): Token ID used to pad ``input_ids`` to
                ``sequence_length``. Defaults to ``0``.
            config (PretrainedConfig | None): Model configuration override. If
                ``None``, ``model.config`` is used. Defaults to ``None``.
            dtype (torch.dtype | None): Data type for KV cache and attention mask
                tensors. If ``None``, ``model.dtype`` is used. Defaults to ``None``.
            **kwargs: Additional keyword arguments forwarded to
                :meth:`_prepare_attention_mask`.

        Returns:
            dict: A dictionary with the following keys:

            - ``"input_ids"`` or ``"inputs_embeds"`` (torch.Tensor): Input
              tokens or embeddings padded to ``sequence_length``.
            - ``"attention_mask"`` (torch.Tensor): Causal attention mask of
              shape ``(batch, 1, sequence_length, context_length)``, clamped
              to ``attention_mask_min``.
            - ``"position_ids"`` (Tuple[torch.Tensor, torch.Tensor]): RoPE
              ``(cos, sin)`` embeddings derived from position IDs.
            - ``"past_key_values"`` (List[Tuple[torch.Tensor, torch.Tensor]]):
              KV cache padded to ``context_length``.
            - ``"cache_index"`` (torch.Tensor): Scalar tensor indicating the
              current write position in the KV cache.

        Raises:
            ValueError: If both ``input_ids`` and ``inputs_embeds`` are
                provided, or if neither is provided.
        """

        if config is None:
            config = model.config

        if dtype is None:
            dtype = model.dtype

        if (input_ids is None) ^ (inputs_embeds is not None):
            raise ValueError("Exactly one of `input_ids` or `inputs_embeds` must be provided.")

        input_tokens = input_ids if input_ids is not None else inputs_embeds
        assert input_tokens is not None
        input_tokens = input_tokens.to(dtype=torch.int32 if input_ids is not None else torch.float32)

        batch_size = input_tokens.shape[0]
        input_length = input_tokens.shape[1]
        device = input_tokens.device

        # Pad input tokens and attention mask to [batch_size, sequence_length] (necessary for static shape requirements)
        if input_ids is not None:
            input_tokens_extension = torch.full(
                (batch_size, sequence_length - input_length),
                fill_value=pad_token,
                dtype=input_tokens.dtype,
                device=device,
            )
        else:
            embedding_dim = input_tokens.shape[2]
            input_tokens_extension = torch.zeros(
                (batch_size, sequence_length - input_length, embedding_dim),
                dtype=input_tokens.dtype,
                device=device,
            )

        padded_input_tokens = torch.cat((input_tokens, input_tokens_extension), dim=1)

        past_kv_length = past_key_values[0][1].shape[-2] if past_key_values else 0

        if cache_index is None:
            cache_index = torch.tensor([past_kv_length], dtype=torch.int64, device=device)

        # Create and pad attention mask according to KV

        padded_attention_mask = cls._prepare_attention_mask(
            shape=input_tokens.shape,
            attention_mask=attention_mask,
            context_length=context_length,
            sequence_length=sequence_length,
            past_key_values=past_key_values,
            cache_index=cache_index,
            device=device,
            **kwargs,
        )

        # Fix position ids to sequence length
        if position_ids is not None:
            position_ids_extension = torch.zeros(
                (batch_size, sequence_length - input_length),
                dtype=position_ids.dtype,
                device=device,
            )

            position_ids = torch.cat((position_ids, position_ids_extension), dim=1)
        else:
            position_ids = (
                torch.arange(past_kv_length, past_kv_length + sequence_length)
                .unsqueeze(0)
                .repeat(batch_size, 1)
                .to(device)
            )

        position_ids_cos, position_ids_sin = cls.create_position_embeddings(
            model=model, config=config, position_ids=position_ids
        )

        cache_position = torch.arange(sequence_length, dtype=torch.float32, device=device) + cache_index.to(
            device
        )
        input_embeds = torch.ones((input_tokens.shape[0], context_length, 1), device=device)
        cm_attention_mask = create_causal_mask(
            config=config,
            input_embeds=input_embeds,
            attention_mask=padded_attention_mask,
            cache_position=cache_position,
            past_key_values=None,
        )
        assert cm_attention_mask is not None
        cm_attention_mask = cm_attention_mask.clamp_min(attention_mask_min)

        key_value_length = context_length
        padded_past_key_values = cls._prepare_past_key_values(
            past_key_values=past_key_values,
            key_value_length=key_value_length,
            config=config,
            device=device,
            dtype=dtype,
            batch_size=batch_size,
        )

        # Return a named dictionary for clarity

        prepared: Dict[str, Union[Tensor, Tuple[Tensor, Tensor], List[Tuple[Tensor, Tensor]]]]
        if input_ids is not None:
            prepared = {"input_ids": padded_input_tokens}
        else:
            prepared = {"inputs_embeds": padded_input_tokens}

        prepared.update(
            {
                "attention_mask": cm_attention_mask.to(dtype=dtype),
                "position_ids": (position_ids_cos, position_ids_sin),
                "past_key_values": padded_past_key_values,
                "cache_index": cache_index.to(device=device),
            }
        )

        return prepared

    @classmethod
    def _prepare_past_key_values(
        cls,
        past_key_values: List[Tuple[torch.Tensor, torch.Tensor]],
        key_value_length: int,
        config: PretrainedConfig,
        device: torch.device = torch.device("cpu"),
        dtype: torch.dtype = torch.float32,
        batch_size: int = 1,
        **kwargs,
    ) -> List[Tuple[torch.Tensor, torch.Tensor]]:
        """Pad the KV cache to ``key_value_length`` for static-shape inference.

        Allocates zero_padded key/value tensors of the full static shape
        and merges them with the existing ``past_key_values`` via
        :func:`get_past_keyval_with_shift`, ensuring the output always has
        exactly ``key_value_length`` positions in the sequence dimension.

        Args:
            past_key_values (List[Tuple[torch.Tensor, torch.Tensor]]): Existing
                KV cache from previous steps. Pass an empty list for the first
                step; zero_padded tensors will be created automatically.
            key_value_length (int): Target sequence-dimension length for the
                padded KV cache (typically equal to ``context_length``).
            config (PretrainedConfig): Model configuration used to derive
                ``num_hidden_layers``, ``num_key_value_heads``, and
                ``head_dim``.
            device (torch.device): Device on which to allocate zero_padded tensors.
                Defaults to ``torch.device("cpu")``.
            dtype (torch.dtype): Data type for zero_padded tensor allocation.
                Defaults to ``torch.float32``.
            batch_size (int): Batch size for zero_padded tensor allocation.
                Defaults to ``1``.

        Returns:
            List[Tuple[torch.Tensor, torch.Tensor]]: A list of
            ``(key, value)`` tuples, one per transformer layer, where each
            tensor's sequence dimension equals ``key_value_length``.
        """
        head_dim = (
            config.head_dim
            if hasattr(config, "head_dim") and config.head_dim is not None
            else config.hidden_size // config.num_attention_heads
        )
        num_hidden_layers = config.num_hidden_layers
        num_kv_heads = config.num_key_value_heads

        transposed_key_cache = hasattr(config, "transposed_key_cache") and config.transposed_key_cache

        value_shape = (
            batch_size,
            num_kv_heads,
            key_value_length,
            head_dim,
        )
        key_shape = (
            (value_shape[0], value_shape[1], value_shape[3], value_shape[2])
            if transposed_key_cache
            else tuple(value_shape)
        )

        zero_padded_kv = [
            (
                torch.zeros(key_shape, device=device, dtype=dtype),
                torch.zeros(value_shape, device=device, dtype=dtype),
            )
            for _ in range(num_hidden_layers)
        ]

        # Join input past_key_values with zero_padded_kv, and clip all padding values that go over the max context
        padded_past_key_values = get_past_keyval_with_shift(
            past_key_vals=past_key_values,
            new_key_vals=zero_padded_kv,
            length=key_value_length,
            device=device,
            dtype=dtype,
            transposed_key_cache=transposed_key_cache,
        )

        return padded_past_key_values

    @staticmethod
    def slice_inputs_for_inference(
        input_ids: Optional[torch.Tensor],
        attention_mask: torch.Tensor,
        sequence_length: int,
        inputs_embeds: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        hidden_states: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> Iterable[Dict[str, Optional[torch.Tensor]]]:
        """
        Slice inputs into chunks suitable for inference.

        Slices provided inputs based on the autoregressive window size and
        yields per-chunk dictionaries containing aligned slices for input IDs or
        embeddings, attention mask, position IDs, and optionally hidden states.

        Args:
          input_ids: Input token IDs of shape (batch, seq_len). Provide either
            ``input_ids`` or ``inputs_embeds``, not both.
          attention_mask: Attention mask of shape (batch, seq_len). If not
            provided, a mask of ones is created.
          sequence_length: Maximum number of tokens the model consumes per step
            (ARN length).
          inputs_embeds: Input embeddings of shape (batch, seq_len, hidden_dim).
            Provide either ``input_ids`` or ``inputs_embeds``, not both.
          position_ids: Position IDs of shape (batch, seq_len).
          hidden_states: Optional hidden states of shape (batch, seq_len, ...)
            aligned with inputs.

        Yields:
          A dictionary with keys like ``input_ids`` or ``inputs_embeds``,
          ``attention_mask``, ``position_ids``, and optionally
          ``hidden_states`` for each chunk.

        Raises:
          ValueError: If both ``input_ids`` and ``inputs_embeds`` are provided
        """

        if (input_ids is None) ^ (inputs_embeds is not None):
            raise ValueError("You must specify exactly one of input_ids or inputs_embeds")

        inputs = input_ids if input_ids is not None else inputs_embeds
        assert inputs is not None

        total_len = inputs.shape[1]
        remainder = total_len % sequence_length

        def make_slice(start: int, end: int) -> Dict[str, Optional[torch.Tensor]]:
            model_inputs: Dict[str, Optional[torch.Tensor]] = {}
            if input_ids is not None:
                model_inputs["input_ids"] = inputs[:, start:end]
            else:
                model_inputs["inputs_embeds"] = inputs[:, start:end, :]

            model_inputs["attention_mask"] = attention_mask[:, start:end]
            model_inputs["position_ids"] = position_ids[:, start:end] if position_ids is not None else None
            model_inputs["hidden_states"] = hidden_states[:, start:end] if hidden_states is not None else None

            return model_inputs

        # Emit remainder first
        if remainder > 0:
            yield make_slice(0, remainder)

        # Emit full windows
        start = remainder if remainder > 0 else 0
        while start < total_len:
            end = min(start + sequence_length, total_len)
            yield make_slice(start, end)
            start = end


class LLMGenerator(LLMGenerationMixin, torch.nn.Module):
    _is_stateful: bool = False

    def __init__(
        self,
        model,
        tokenizer: PreTrainedTokenizer,
        sequence_length: int,
        context_length: int,
        config: Optional[PretrainedConfig] = None,
        attention_mask_min: int = -100,
        bypass_adapted_forward: bool = False,
        **kwargs,
    ):
        """Initialize the LLMGenerator.

        Args:
            model: The underlying language model (PyTorch ``nn.Module``) to
                wrap. Must expose a ``forward`` method compatible with the
                prepared inputs produced by :meth:`prepare_inputs`.
            tokenizer (PreTrainedTokenizer): HuggingFace tokenizer associated
                with ``model``. Used to resolve special token IDs (e.g.
                ``eos_token_id``) during generation.
            sequence_length (int): Static autoregressive window size (ARN).
                The model processes exactly this many tokens per forward pass.
            context_length (int): Total context window size, i.e. the maximum
                number of tokens the KV cache can hold plus ``sequence_length``.
            config (PretrainedConfig | None): Optional model configuration
                override. If ``None``, ``model.config`` is used. Defaults to
                ``None``.
            attention_mask_min (int): Minimum clamp value applied to the causal
                attention mask to represent masked-out positions. Defaults to
                ``-100``.
            bypass_adapted_forward (bool): If ``True``, calls
                ``model.model(**inputs)`` instead of ``model(**inputs)``,
                bypassing any adapted ``forward`` wrapper. Defaults to
                ``False``.
            **kwargs: Additional keyword arguments (currently unused; reserved
                for future extensions).
        """
        super().__init__()

        self.model = model
        self.tokenizer = tokenizer
        self.sequence_length = sequence_length
        self.context_length = context_length
        self.generation_config = getattr(self.model, "generation_config", GenerationConfig())
        self._config = config
        self.attention_mask_min = attention_mask_min
        self.bypass_adapted_forward = bypass_adapted_forward

    @staticmethod
    def can_generate() -> bool:
        return True

    @property
    def config(self) -> PretrainedConfig:
        if self._config is not None:
            return self._config
        return self.model.config

    @property
    def main_input_name(self) -> str:
        return "input_ids"

    @property
    def _supports_cache_class(self) -> bool:
        return True

    @property
    def device(self) -> torch.device:
        return self.model.device

    def forward(
        self,
        input_ids: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        past_key_values: Optional[DynamicCache] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        hidden_states: Optional[torch.Tensor] = None,
        cache_index: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> CausalLMOutputWithPast:
        """Run a full forward pass over the input sequence.

        Slices the input into chunks of ``sequence_length`` tokens, prepares
        static-shape inputs for each chunk via :meth:`prepare_inputs`, runs the
        wrapped model, and accumulates logits and KV cache across all chunks.

        Args:
            input_ids (torch.Tensor | None): Token IDs of shape
                ``(batch, seq_len)``. Mutually exclusive with
                ``inputs_embeds``.
            attention_mask (torch.Tensor | None): Attention mask of shape
                ``(batch, seq_len)``. If ``None``, a mask of ones is created
                automatically.
            past_key_values (DynamicCache | None): HuggingFace cache object
                holding previously computed key/value states. If ``None`` or
                empty, the KV cache is initialised from scratch.
            inputs_embeds (torch.FloatTensor | None): Pre-computed input
                embeddings of shape ``(batch, seq_len, hidden_dim)``. Mutually
                exclusive with ``input_ids``.
            position_ids (torch.Tensor | None): Explicit position IDs of shape
                ``(batch, seq_len)``. If ``None``, they are derived from the
                attention mask.
            hidden_states (torch.Tensor | None): Optional hidden states of
                shape ``(batch, seq_len, hidden_dim)`` aligned with the input.
                Passed through to :meth:`slice_inputs_for_inference`.
            cache_index (torch.Tensor | None): KV cache write position
                override. If ``None``, the position is inferred from the
                current cache length.
            **kwargs: Additional keyword arguments forwarded to
                :meth:`prepare_inputs`.

        Returns:
            CausalLMOutputWithPast: A HuggingFace output object containing:

            - ``logits`` (torch.FloatTensor): Concatenated logits of shape
              ``(batch, seq_len, vocab_size)`` cast to ``float32``.
            - ``past_key_values`` (Tuple[Tuple[torch.Tensor, ...], ...] | None):
              Updated KV cache as a tuple of ``(key, value)`` pairs, one per
              layer, moved to ``self.device``. ``None`` if no KV cache was
              produced.

        Raises:
            ValueError: If both ``input_ids`` and ``inputs_embeds`` are
                provided, or if neither is provided.
        """
        if (input_ids is None) ^ (inputs_embeds is not None):
            raise ValueError("You must specify exactly one of input_ids or inputs_embeds")
        input_tokens = input_ids if input_ids is not None else inputs_embeds
        assert input_tokens is not None

        if attention_mask is None:
            batch_size = input_tokens.shape[0]
            input_length = input_tokens.shape[1]
            attention_mask = torch.ones(
                (batch_size, input_length), device=input_tokens.device, dtype=torch.int32
            )

        # Initialize past_key_values as list of tuples [(k0, v0), (k1, v1), ...]
        global_model_outputs: Dict[str, Any] = {}
        if past_key_values is None or (
            isinstance(past_key_values, DynamicCache) and past_key_values.get_seq_length() == 0
        ):
            global_model_outputs["past_key_values"] = []
        elif isinstance(past_key_values, tuple):
            global_model_outputs["past_key_values"] = list(past_key_values)
        else:
            # Convert DynamicCache to legacy cache format (list of tuples)
            legacy_cache = past_key_values.to_legacy_cache()
            global_model_outputs["past_key_values"] = list(legacy_cache)

        pad_token = getattr(self.config, "eos_token_id", 0)
        if isinstance(pad_token, (list, tuple)):
            pad_token = pad_token[0]

        for inputs in self.slice_inputs_for_inference(
            input_ids=input_ids,
            attention_mask=attention_mask,
            sequence_length=self.sequence_length,
            inputs_embeds=inputs_embeds,
            position_ids=position_ids,
            hidden_states=hidden_states,
        ):
            input_ids_slice = inputs.get("input_ids", None)
            attention_mask_slice = inputs["attention_mask"]
            position_ids_slice = inputs["position_ids"]
            inputs_embeds_slice = inputs.get("inputs_embeds", None)

            if input_ids_slice is not None:
                num_valid_input_tokens = input_ids_slice.shape[1]
            else:
                assert inputs_embeds_slice is not None
                num_valid_input_tokens = inputs_embeds_slice.shape[1]

            prepared_inputs = self.prepare_inputs(
                model=self.model,
                input_ids=input_ids_slice,
                attention_mask=attention_mask_slice,
                position_ids=position_ids_slice,
                inputs_embeds=inputs_embeds_slice,
                past_key_values=global_model_outputs["past_key_values"],
                sequence_length=self.sequence_length,
                context_length=self.context_length,
                pad_token=pad_token,
                attention_mask_min=self.attention_mask_min,
                cache_index=cache_index,
                config=self.config,
                **kwargs,
            )

            if self.bypass_adapted_forward:
                model_outputs = self.model.model(**prepared_inputs)
            else:
                model_outputs = self.model(**prepared_inputs)

            self._update_model_outputs(
                model_outputs,
                global_model_outputs,
                num_valid_input_tokens,
            )

        # make sure all outputs are on the correct device
        assert isinstance(global_model_outputs["logits"], torch.Tensor)
        logits = global_model_outputs["logits"].to(device=self.device)

        # Convert list of tuples [(k0, v0), (k1, v1), ...] to device
        output_past_key_values = (
            tuple(
                (key.to(device=self.device), value.to(device=self.device))
                for key, value in global_model_outputs["past_key_values"]
            )
            if global_model_outputs["past_key_values"]
            else None
        )

        return CausalLMOutputWithPast(
            logits=cast(torch.FloatTensor, logits.to(torch.float32)),
            past_key_values=cast(Optional[Cache], output_past_key_values),
        )

    def _update_model_outputs(
        self,
        current_outputs: Union[CausalLMOutputWithPast, Tuple[torch.Tensor, ...]],
        global_outputs: Dict[str, Any],
        num_valid_input_tokens: int,
    ):
        """
        Updates model outputs according to the number of valid input tokens.

        Args:
            current_outputs: the outputs of the model for the current set of input tokens
            global_outputs: the outputs of the model across all tokens seen so far
            num_valid_input_tokens: The number of valid input tokens. Determines how much should be added to global
            outputs.
        """
        # strip logits corresponding to padding tokens

        logits = current_outputs[0]

        logits = torch.narrow(logits, 1, 0, num_valid_input_tokens)

        # concatenate logits from local to global output
        global_outputs["logits"] = (
            torch.cat((global_outputs["logits"], logits), dim=1) if "logits" in global_outputs else logits
        )

        # Extract KV cache from current_outputs
        # current_outputs is a tuple: (logits, past_key_values)
        # where past_key_values is either a tuple of (key, value) tuples or CausalLMOutputWithPast
        if hasattr(current_outputs, "past_key_values"):
            # Handle CausalLMOutputWithPast
            current_kv = list(current_outputs.past_key_values) if current_outputs.past_key_values else []
        elif len(current_outputs) > 1:
            # Handle tuple format: (logits, past_key_values)
            current_kv = list(current_outputs[1]) if isinstance(current_outputs[1], (tuple, list)) else []
        else:
            current_kv = []

        transposed_key_cache = (
            hasattr(self.config, "transposed_key_cache") and self.config.transposed_key_cache
        )

        # strip KV cache corresponding to padding tokens
        current_past_key_values = get_past_keyval_with_shift(
            past_key_vals=[],
            new_key_vals=current_kv,
            length=num_valid_input_tokens,
            device=self.device,
            transposed_key_cache=transposed_key_cache,
        )

        # shift global KV cache, concatenate local KV cache
        global_key_value_length = (
            global_outputs["past_key_values"][0][1].shape[-2] if global_outputs["past_key_values"] else 0
        )

        global_outputs["past_key_values"] = get_past_keyval_with_shift(
            past_key_vals=global_outputs["past_key_values"],
            new_key_vals=current_past_key_values,
            length=min(
                global_key_value_length + num_valid_input_tokens,
                self.context_length - self.sequence_length,
            ),
            device=self.device,
            transposed_key_cache=transposed_key_cache,
        )
