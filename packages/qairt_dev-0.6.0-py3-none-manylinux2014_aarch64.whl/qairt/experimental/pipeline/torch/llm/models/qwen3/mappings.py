# =============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries. Not a Contribution.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# =============================================================================
"""Qwen3 module mappings (MAPPINGS, INIT_MAPPINGS, REVERT_INIT_MAPPINGS) for TransformersModuleMapping
auto-discovery."""

import torch

try:
    from transformers.models.qwen3.configuration_qwen3 import Qwen3Config
    from transformers.models.qwen3.modeling_qwen3 import (
        Qwen3Attention,
        Qwen3ForCausalLM,
        Qwen3RotaryEmbedding,
    )

    from .reauthoring import (
        QcQwen3Attention,
        QcQwen3Config,
        QcQwen3ForCausalLM,
        QcQwen3RotaryEmbedding,
    )

    # ------------------------------------------------------------------
    # init_fn / revert_fn for Qwen3ForCausalLM  <->  QcQwen3ForCausalLM
    # ------------------------------------------------------------------

    def _init_causal_lm_cache_tensor(module):
        """
        Register cache_tensor buffer on QcQwen3ForCausalLM after __class__ swap.

        TransformersModuleMapping swaps __class__ in-place without calling __init__, so
        this init_fn replicates the buffer registration from QcQwen3ForCausalLM.__init__.
        The buffer is only registered when input_tokens_per_inference is set in config.

        Args:
            module: A Qwen3ForCausalLM instance whose __class__ has been set to QcQwen3ForCausalLM.
        """
        if (
            hasattr(module.config, "input_tokens_per_inference")
            and module.config.input_tokens_per_inference is not None
        ):
            module.register_buffer(
                name="cache_tensor",
                tensor=torch.arange(module.config.input_tokens_per_inference),
                persistent=False,
            )

    def _revert_causal_lm_cache_tensor(module):
        """
        Remove cache_tensor buffer before reverting QcQwen3ForCausalLM to Qwen3ForCausalLM.

        Cleans up the buffer added during init_fn, since Qwen3ForCausalLM does not have it.

        Args:
            module: A QcQwen3ForCausalLM instance whose __class__ is about to be restored.
        """
        if hasattr(module, "cache_tensor"):
            delattr(module, "cache_tensor")

    # ------------------------------------------------------------------
    # init_fn / revert_fn for Qwen3Attention  <->  QcQwen3Attention
    # ------------------------------------------------------------------

    def _init_qwen3_attention_r3(module):
        """
        Create R3 Hadamard components on QcQwen3Attention after __class__ swap, if enabled.

        Instantiates q_R3 and k_R3 as R3Hadamard modules and initializes their weight matrices
        when enable_r3_hadamard is True in config.

        Args:
            module: A Qwen3Attention instance whose __class__ has been set to QcQwen3Attention.
        """
        if hasattr(module.config, "enable_r3_hadamard") and module.config.enable_r3_hadamard:
            from qairt.experimental.pipeline.torch.llm.models.utils import R3Hadamard

            module.q_R3 = R3Hadamard(head_dim=module.head_dim)
            module.k_R3 = R3Hadamard(head_dim=module.head_dim)
            # Populate the Hadamard weight matrix so the modules are ready for
            # a forward pass.
            module.q_R3.initialize_r3_hadamard()
            module.k_R3.initialize_r3_hadamard()
            from qairt.experimental.pipeline.torch.llm.models.utils import log_qc_operation
            from qairt.utils.loggers import get_logger

            logger = get_logger("Qwen3Reauthoring")
            log_qc_operation(logger, "r3_hadamard_init", {"head_dim": module.head_dim})

    def _revert_qwen3_attention_r3(module):
        """
        Remove R3 Hadamard components before reverting QcQwen3Attention to Qwen3Attention.

        Deletes q_R3 and k_R3 attributes added during init_fn, since Qwen3Attention does not have them.

        Args:
            module: A QcQwen3Attention instance whose __class__ is about to be restored to Qwen3Attention.
        """
        if hasattr(module, "q_R3"):
            delattr(module, "q_R3")
        if hasattr(module, "k_R3"):
            delattr(module, "k_R3")

    # ------------------------------------------------------------------
    # Exported mappings
    # ------------------------------------------------------------------

    MAPPINGS = {
        Qwen3Attention: QcQwen3Attention,
        Qwen3ForCausalLM: QcQwen3ForCausalLM,
        Qwen3RotaryEmbedding: QcQwen3RotaryEmbedding,
        Qwen3Config: QcQwen3Config,
    }

    # Maps replacement class → callable(module) invoked by apply() after __class__ swap.
    INIT_MAPPINGS = {
        QcQwen3ForCausalLM: _init_causal_lm_cache_tensor,
        QcQwen3Attention: _init_qwen3_attention_r3,
    }

    # Maps replacement class → callable(module) invoked by revert() before __class__ restore.
    REVERT_INIT_MAPPINGS = {
        QcQwen3ForCausalLM: _revert_causal_lm_cache_tensor,
        QcQwen3Attention: _revert_qwen3_attention_r3,
    }

except ImportError:
    MAPPINGS = {}
    INIT_MAPPINGS = {}
    REVERT_INIT_MAPPINGS = {}
