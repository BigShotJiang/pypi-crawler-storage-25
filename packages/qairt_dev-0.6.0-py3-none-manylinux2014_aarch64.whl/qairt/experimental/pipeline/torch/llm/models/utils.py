# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import math
from typing import TYPE_CHECKING, Any, Dict, Optional, Tuple

import scipy
import torch
from torch import nn

if TYPE_CHECKING:
    from transformers import PretrainedConfig

from qairt.utils.loggers import get_logger

_attention_mixin_logger = get_logger("QcAttentionMixin")


def apply_rope_single(x, rope_vals: Tuple[torch.Tensor, torch.Tensor]):
    """
    Based on FacebookResearch's llama implementation of RoPE:
    """
    rope_real = rope_vals[0]  # shape should be 1, 1, seqlen, head_dim/2
    rope_im = rope_vals[1]  # shape should be 1, 1, seqlen, head_dim/2

    x_real = x[:, :, :, : x.shape[-1] // 2]  # extract first half elements
    x_im = x[:, :, :, x.shape[-1] // 2 :]  # extract second half elements

    x_prod_real = x_real * rope_real - x_im * rope_im
    x_prod_im = x_real * rope_im + x_im * rope_real

    x = torch.cat((x_prod_real, x_prod_im), dim=3).view(*x.shape)
    return x


class QcConfigMixin:
    """
    Mixin class to add Qc-specific configuration parameters to the model config.

    This mixin uses properties with lazy initialization to ensure attributes are
    always available even when __init__ is not called (e.g., when using __class__ replacement).

    All properties default to False and are stored with a '_' prefix in the instance dict.

    Configuration flags:
    - enable_masked_softmax: Enable optimized masked softmax operations
    - transposed_key_cache: Store key cache in transposed format for better memory access
    - return_new_key_value_only: Return only new KV tokens instead of full cache
    - perform_scatter_kv_cache_update: Use scatter operations for KV cache updates
    - input_tokens_per_inference: Number of input tokens per inference for cache tensor
    - num_logits_to_keep: Number of logits to keep in output
    - enable_r3_hadamard: Apply R3 Hadamard rotation (SpinQuant) to query/key states after RoPE
    """

    # QC_BACKING_ATTRS is a class-level dict that centralizes all QC-specific config flag names
    # and their defaults, so adding a new flag here automatically propagates it to __init__,
    # instance copying, and htp_mappings.py without any other changes.
    QC_BACKING_ATTRS: Dict[str, Any] = {
        "enable_masked_softmax": False,
        "transposed_key_cache": False,
        "return_new_key_value_only": False,
        "perform_scatter_kv_cache_update": False,
        "input_tokens_per_inference": None,
        "num_logits_to_keep": 0,
        "enable_r3_hadamard": False,
        "use_combined_mask_input": False,
        "use_position_embedding_input": False,
    }

    def __init__(self, **kwargs):
        # Explicit type annotations for mypy: QC_BACKING_ATTRS defaults use None/False/0
        # which mypy would otherwise infer as Literal[None]/Literal[False]/Literal[0],
        # causing type errors in the property setters that accept broader types.
        self._enable_masked_softmax: bool
        self._transposed_key_cache: bool
        self._return_new_key_value_only: bool
        self._perform_scatter_kv_cache_update: bool
        self._input_tokens_per_inference: Optional[int]
        self._num_logits_to_keep: int
        self._enable_r3_hadamard: bool
        self._use_combined_mask_input: bool
        self._use_position_embedding_input: bool
        # Initialise every backing attribute from kwargs or its declared default.
        for attr, default in self.QC_BACKING_ATTRS.items():
            setattr(self, f"_{attr}", kwargs.get(attr, default))

    @property
    def enable_masked_softmax(self) -> bool:
        """Enable optimized masked softmax operations (default: False)"""
        if not hasattr(self, "_enable_masked_softmax"):
            self._enable_masked_softmax = False
        return self._enable_masked_softmax

    @enable_masked_softmax.setter
    def enable_masked_softmax(self, value: bool):
        self._enable_masked_softmax = value

    @property
    def transposed_key_cache(self) -> bool:
        """Store key cache in transposed format for better memory access (default: False)"""
        if not hasattr(self, "_transposed_key_cache"):
            self._transposed_key_cache = False
        return self._transposed_key_cache

    @transposed_key_cache.setter
    def transposed_key_cache(self, value: bool):
        self._transposed_key_cache = value

    @property
    def return_new_key_value_only(self) -> bool:
        """Return only new KV tokens instead of full cache (default: False)"""
        if not hasattr(self, "_return_new_key_value_only"):
            self._return_new_key_value_only = False
        return self._return_new_key_value_only

    @return_new_key_value_only.setter
    def return_new_key_value_only(self, value: bool):
        self._return_new_key_value_only = value

    @property
    def perform_scatter_kv_cache_update(self) -> bool:
        """Use scatter operations for KV cache updates (default: False)"""
        if not hasattr(self, "_perform_scatter_kv_cache_update"):
            self._perform_scatter_kv_cache_update = False
        return self._perform_scatter_kv_cache_update

    @perform_scatter_kv_cache_update.setter
    def perform_scatter_kv_cache_update(self, value: bool):
        self._perform_scatter_kv_cache_update = value

    @property
    def input_tokens_per_inference(self) -> Optional[int]:
        """Number of input tokens per inference for cache tensor (default: None)"""
        if not hasattr(self, "_input_tokens_per_inference"):
            self._input_tokens_per_inference = None
        return self._input_tokens_per_inference

    @input_tokens_per_inference.setter
    def input_tokens_per_inference(self, value: Optional[int]):
        self._input_tokens_per_inference = value

    @property
    def num_logits_to_keep(self) -> int:
        """Number of logits to keep in output (default: 0 for all)"""
        if not hasattr(self, "_num_logits_to_keep"):
            self._num_logits_to_keep = 0
        return self._num_logits_to_keep

    @num_logits_to_keep.setter
    def num_logits_to_keep(self, value: int):
        self._num_logits_to_keep = value

    @property
    def enable_r3_hadamard(self) -> bool:
        """Apply R3 Hadamard rotation (SpinQuant) to query/key states after RoPE (default: False)"""
        if not hasattr(self, "_enable_r3_hadamard"):
            self._enable_r3_hadamard = False
        return self._enable_r3_hadamard

    @enable_r3_hadamard.setter
    def enable_r3_hadamard(self, value: bool):
        self._enable_r3_hadamard = value

    @property
    def use_combined_mask_input(self) -> bool:
        """Use a combined mask tensor as model input instead of computing it internally (default: False)"""
        if not hasattr(self, "_use_combined_mask_input"):
            self._use_combined_mask_input = False
        return self._use_combined_mask_input

    @use_combined_mask_input.setter
    def use_combined_mask_input(self, value: bool):
        self._use_combined_mask_input = value

    @property
    def use_position_embedding_input(self) -> bool:
        """Use a position embedding tensor as model input instead of computing it internally (default: False)"""
        if not hasattr(self, "_use_position_embedding_input"):
            self._use_position_embedding_input = False
        return self._use_position_embedding_input

    @use_position_embedding_input.setter
    def use_position_embedding_input(self, value: bool):
        self._use_position_embedding_input = value

    def __repr__(self):
        base_repr = super().__repr__()
        extra_attrs = ", ".join(f"{attr}={getattr(self, attr)}" for attr in self.QC_BACKING_ATTRS)
        return f"{base_repr[:-1]}, {extra_attrs})"


def _qc_dynamic_layer_update(
    self,
    key_states: torch.Tensor,
    value_states: torch.Tensor,
    cache_kwargs: Optional[Dict[str, Any]] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Updates the layer cache with the new `key_states` and `value_states`.

    This method implements QC-specific optimizations including:
    - Transposed key cache support for better memory access patterns
    - Scatter-based updates for efficient cache position updates
    - Optional return of only new key/value pairs to reduce memory overhead

    Parameters:
        key_states (`torch.Tensor`):
            The new key states to cache.
        value_states (`torch.Tensor`):
            The new value states to cache.
        cache_kwargs (`Dict[str, Any]`, `optional`):
            Additional arguments for the cache subclass. Supported arguments:
            - transposed_key_cache: Whether keys are stored in transposed format
            - return_new_key_value_only: Whether to return only new KV pairs
            - cache_position: Positions where new KV pairs should be inserted
            - num_key_value_heads: Number of key/value heads for scatter indexing
            - head_dim: Head dimension for scatter indexing

    Return:
        A tuple containing the updated key and value states.
    """
    if cache_kwargs is None:
        cache_kwargs = {}

    # Handle initial cache creation
    if self.keys is None or self.keys.numel() == 0 or self.values is None:
        self.keys = key_states
        self.values = value_states
        # Set is_initialized flag if the instance supports it (for DynamicCache compatibility)
        if hasattr(self, "is_initialized"):
            self.is_initialized = True
        return self.keys, self.values

    # Extract cache configuration
    return_new_key_value_only = cache_kwargs.get("return_new_key_value_only", False)
    transposed_key_cache = cache_kwargs.get("transposed_key_cache", False)
    cache_position = cache_kwargs.get("cache_position")
    num_key_value_heads = cache_kwargs.get("num_key_value_heads")
    head_dim = cache_kwargs.get("head_dim")

    key_cat_dim = -1 if transposed_key_cache else -2

    # Determine whether to use scatter or concatenation
    # If the cache is smaller than the last position, we need to concatenate
    if cache_position is None or cache_position.numel() == 0 or self.values.shape[-2] <= cache_position[-1]:
        key_cache = torch.cat([self.keys, key_states], dim=key_cat_dim)
        value_cache = torch.cat([self.values, value_states], dim=-2)
    else:
        # Use scatter operation for efficient in-place updates
        # Convert cache_position (1D tensor) to indices for scattering
        # Shape: [bsz, num_key_value_heads, head_dim, seq_len] for transposed keys
        indices = cache_position.view(1, 1, 1, -1).expand(
            value_states.shape[0], num_key_value_heads, head_dim, cache_position.shape[-1]
        )

        # Scatter value states
        value_cache = self.values.scatter(dim=-2, index=indices.transpose(-1, -2), src=value_states)

        # Adjust indices based on key concatenation dimension
        indices = indices.transpose(-1, -2) if key_cat_dim == -2 else indices
        key_cache = self.keys.scatter(dim=key_cat_dim, index=indices, src=key_states)

    # Update internal cache based on return mode
    if return_new_key_value_only:
        # Store only new KV pairs (useful for reducing memory in certain scenarios)
        self.keys = key_states
        self.values = value_states
    else:
        # Store full concatenated cache
        self.keys = key_cache
        self.values = value_cache

    return key_cache, value_cache


def _qc_dynamic_layer_get_seq_length(self, cache_position: Optional[torch.LongTensor] = None) -> int:
    """
    Returns the sequence length of the cached states at this layer.

    Parameters:
        cache_position (`torch.LongTensor`, `optional`):
            Cache position tensor (unused but kept for API compatibility)

    Returns:
        The sequence length of the cached values, or 0 if cache is empty.
    """
    if self.values is None or self.values.numel() == 0:
        return 0
    return self.values.shape[-2]


class QcDynamicLayer:
    """
    Namespace class containing QC-specific DynamicLayer methods for patching.

    This class does NOT inherit from DynamicLayer. Instead, it serves as a container
    for standalone functions that will be patched onto the DynamicLayer class at runtime.

    When these functions are patched onto DynamicLayer, Python will automatically
    bind them as instance methods, with 'self' referring to the DynamicLayer instance.

    This approach avoids signature mismatches that occur when inheriting from the
    class we're trying to patch.

    Note: These methods work at the layer level (using self.keys and self.values) rather than
    the cache level (using self.key_cache[layer_idx] and self.value_cache[layer_idx]).
    """

    update = _qc_dynamic_layer_update
    get_seq_length = _qc_dynamic_layer_get_seq_length


class QcAttentionMixin:
    """
    Mixin class providing shared QC-specific attention utilities.

    Intended to be mixed into HuggingFace attention subclasses (e.g. LlamaAttention,
    PhiAttention) that use a QcConfigMixin-based config. The mixin assumes the

    Typical usage:
        class QcLlamaAttention(QcAttentionMixin, LlamaAttention): ...
        class QcPhiAttention(QcAttentionMixin, PhiAttention): ...

    The mixin must appear before the HF attention base class in the MRO so that
    _update_cache_kwargs_with_qc_config is resolved from the mixin.
    """

    if TYPE_CHECKING:
        config: Any
        head_dim: int

    def _update_cache_kwargs_with_qc_config(self, cache_kwargs: dict) -> dict:
        """
        Populate cache_kwargs with QC-specific parameters drawn from self.config.

        This helper keeps the forward method of each attention subclass clean by
        centralising the mapping from config attributes to the dict consumed by
        DynamicCache.update().

        Args:
            cache_kwargs: Base cache kwargs dict (typically containing sin, cos,
                and cache_position).

        Returns:
            The same dict, extended with the following keys:
                - return_new_key_value_only: whether to return only the newly
                  computed KV pair instead of the full accumulated cache.
                - transposed_key_cache: whether keys are stored transposed.
                - perform_scatter_kv_cache_update: whether to use scatter-based
                  cache writes.
                - num_key_value_heads: number of KV heads (needed for scatter
                  index construction).
                - head_dim: per-head dimension (needed for scatter index
                  construction).
        """
        cache_kwargs["return_new_key_value_only"] = self.config.return_new_key_value_only
        cache_kwargs["transposed_key_cache"] = self.config.transposed_key_cache
        cache_kwargs["perform_scatter_kv_cache_update"] = self.config.perform_scatter_kv_cache_update
        cache_kwargs["num_key_value_heads"] = self.config.num_key_value_heads
        cache_kwargs["head_dim"] = self.head_dim

        log_qc_operation(
            _attention_mixin_logger,
            "cache_kwargs_update",
            {
                "return_new_key_value_only": cache_kwargs["return_new_key_value_only"],
                "transposed_key_cache": cache_kwargs["transposed_key_cache"],
                "perform_scatter_kv_cache_update": cache_kwargs["perform_scatter_kv_cache_update"],
            },
            log_once=True,
        )

        return cache_kwargs


def update_attr(cls, attr_name, new_attr):
    attr_backup_name = f"_original_{attr_name}"
    if hasattr(cls, attr_name):
        if not hasattr(cls, attr_backup_name):
            setattr(cls, attr_backup_name, getattr(cls, attr_name))
            setattr(cls, attr_name, new_attr)
        return True
    return False


def revert_attr(cls, attr_name):
    """Restore a previously patched attribute and remove the backup.

    Companion to ``update_attr``.  Looks for the ``_original_{attr_name}``
    backup attribute that ``update_attr`` creates, restores the original value
    onto ``cls``, and then deletes the backup so that a subsequent call to
    ``update_attr`` can patch the attribute again cleanly.

    Args:
        cls: The class whose attribute should be restored.
        attr_name: The name of the attribute to restore (e.g. ``"update"``).

    Returns:
        ``True`` if the backup was found and the attribute was restored,
        ``False`` if no backup existed (i.e. the attribute was never patched).
    """
    attr_backup_name = f"_original_{attr_name}"
    if hasattr(cls, attr_backup_name):
        setattr(cls, attr_name, getattr(cls, attr_backup_name))
        delattr(cls, attr_backup_name)
        return True
    return False


def log_qc_operation(
    logger,
    operation_name: str,
    details: Optional[Dict[str, Any]] = None,
    log_once: bool = False,
) -> None:
    """
    Standardized logging for QC-specific operations.

    This function provides consistent logging format for all QC adaptations,
    making it easier to debug and trace optimization-specific behavior.

    Args:
        logger: Logger instance to use for logging
        operation_name: Name of the QC operation being performed
        details: Optional dictionary of additional details to log
        log_once: When True, each unique message is logged only once per logger
            instance. Subsequent calls with the same message are silently dropped.
            The seen-message set is stored directly on the logger object so that
            different logger instances (e.g. LlamaReauthoring vs Qwen3Reauthoring)
            track their own seen messages independently.

    Example:
        .. code-block:: python

            log_qc_operation(logger, "transposed_key_cache", {"shape": key_states.shape})
            log_qc_operation(logger, "custom_rope_application", {"cos_shape": 32}, log_once=True)
    """
    if details:
        details_str = ", ".join(f"{k}={v}" for k, v in details.items())
        msg = f"QC Operation [{operation_name}]: {details_str}"
    else:
        msg = f"QC Operation [{operation_name}]"

    if log_once:
        if not isinstance(getattr(logger, "_logged_ops", None), set):
            logger._logged_ops = set()
        if msg in logger._logged_ops:
            return
        logger._logged_ops.add(msg)

    logger.debug(msg)


class R3Hadamard(nn.Linear):
    """
    Fixed scaled Hadamard rotation (SpinQuant) applied to query/key states after
    RoPE to reduce outliers and improve quantization quality. Weight is lazily
    initialized via :meth:`initialize_r3_hadamard` before the first forward pass.

    Args:
        head_dim: Per-head dimension.  Must be a power of two for the
            Hadamard construction to be valid.

    Raises:
        AssertionError: If :meth:`forward` is called before
            :meth:`initialize_r3_hadamard`.
        TypeError: If the instance is neither ``nn.Linear`` nor ``nn.Conv2d``
            when :meth:`initialize_r3_hadamard` is called.

    Example:
        .. code-block:: python

            r3 = R3Hadamard(head_dim=128)
            r3.initialize_r3_hadamard()
            out = r3(query_states)  # shape unchanged
    """

    def __init__(self, head_dim: int):
        super(R3Hadamard, self).__init__(
            in_features=head_dim,
            out_features=head_dim,
            bias=False,
            dtype=torch.float,
        )
        self.head_dim = head_dim
        self.is_initialized = False

    def initialize_r3_hadamard(self):
        """Populate the weight matrix with the scaled Hadamard matrix.

        Must be called once before the first forward pass.
        """
        r3_weight = torch.tensor(
            scipy.linalg.hadamard(self.head_dim) / math.sqrt(self.head_dim),
            dtype=torch.float,
        )
        if isinstance(self, nn.Linear):
            self.weight.data.copy_(r3_weight.T)
        elif isinstance(self, nn.Conv2d):  # For support to ConvInplaceLinear
            self.weight.data.copy_(r3_weight.T[:, :, None, None])
        else:
            raise TypeError(
                f"Class {self.__class__.__name__} became an instance of {type(self)}, "
                "but only nn.Linear and nn.Conv2d are supported types"
            )
        self.is_initialized = True

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if not self.is_initialized:
            raise AssertionError(
                f"{self.__class__.__name__} has not been fully initialized. "
                "Invoke class method `initialize_r3_hadamard()` before doing a forward pass with this object"
            )
        return super().forward(x)
