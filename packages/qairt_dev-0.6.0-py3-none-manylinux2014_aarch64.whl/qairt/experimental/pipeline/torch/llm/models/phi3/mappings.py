# =============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries. Not a Contribution.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# =============================================================================
"""
Phi3 module mappings (MAPPINGS, INIT_MAPPINGS, REVERT_INIT_MAPPINGS) for
TransformersModuleMapping auto-discovery.
"""

import torch

try:
    from transformers import Phi3ForCausalLM
    from transformers.models.phi3.modeling_phi3 import (
        Phi3Attention,
        Phi3Config,
        Phi3MLP,
        Phi3Model,
        Phi3RotaryEmbedding,
    )

    from .reauthoring import (
        Phi3UnpackedMLP,
        QcPhi3Model,
        QcPhiAttention,
        QcPhiConfig,
        QcPhiForCausalLM,
        QcPhiRotaryEmbedding,
    )

    # ------------------------------------------------------------------
    # init_fn / revert_fn for Phi3Attention  <->  QcPhiAttention
    # ------------------------------------------------------------------

    def _unpack_attention_init(module):
        """
        Unpack fused qkv_proj into separate q_proj, k_proj, v_proj on QcPhiAttention after __class__ swap.

        Skips __init__ to preserve pretrained weights. Calls unpack_qkv() to slice the fused
        projection, then deletes qkv_proj to free memory.

        Args:
            module: A Phi3Attention instance whose __class__ has been set to QcPhiAttention.
        """
        # 1. Unpack qkv_proj → q_proj, k_proj, v_proj (copies sliced weights)
        module.unpack_qkv()

        # 2. Remove qkv_proj: del calls nn.Module.__delattr__ which removes it
        #    from _modules cleanly.
        del module.qkv_proj

    def _repack_attention_revert(module):
        """
        Repack separate q_proj, k_proj, v_proj back into fused qkv_proj before reverting to Phi3Attention.

        Saves unpacked weights, calls Phi3Attention.__init__ to restore the original attribute
        layout, then reconstructs qkv_proj by concatenating saved weights and restores o_proj.

        Args:
            module: A QcPhiAttention instance whose __class__ is about to be restored to Phi3Attention.
        """
        # 1. Save current unpacked weights
        q_weight = module.q_proj.weight.data.clone()
        k_weight = module.k_proj.weight.data.clone()
        v_weight = module.v_proj.weight.data.clone()
        o_proj_weight = module.o_proj.weight.data.clone()
        config = module.config
        layer_idx = module.layer_idx

        # 2. Restore original Phi3Attention attribute layout
        Phi3Attention.__init__(module, config, layer_idx)

        # 3. Reconstruct fused qkv_proj and restore o_proj
        module.qkv_proj.weight.data.copy_(torch.cat([q_weight, k_weight, v_weight], dim=0))
        module.o_proj.weight.data.copy_(o_proj_weight)

    # ------------------------------------------------------------------
    # init_fn / revert_fn for Phi3MLP  <->  Phi3UnpackedMLP
    # ------------------------------------------------------------------

    def _unpack_mlp_init(module):
        """
        Split fused gate_up_proj into separate gate_proj and up_proj on Phi3UnpackedMLP after __class__ swap.

        Saves fused weights, calls Phi3UnpackedMLP.__init__ to build the new layout, then slices
        the saved weight into gate_proj (first half) and up_proj (second half) and restores down_proj.

        Args:
            module: A Phi3MLP instance whose __class__ has been set to Phi3UnpackedMLP.
        """
        # 1. Save weights before __init__ wipes _modules / _parameters
        gate_up_weight = module.gate_up_proj.weight.data.clone()
        down_weight = module.down_proj.weight.data.clone()

        # 2. Call __init__ — builds gate_proj, up_proj, down_proj, activation_fn.
        #    nn.Module.__init__ is called inside, resetting all sub-modules.
        Phi3UnpackedMLP.__init__(module, module.config)

        # 3. Slice fused weight: first half → gate_proj, second half → up_proj
        intermediate_size = module.config.intermediate_size
        module.gate_proj.weight.data.copy_(gate_up_weight[:intermediate_size, :])
        module.up_proj.weight.data.copy_(gate_up_weight[intermediate_size:, :])

        # 4. Restore down_proj weights (overwritten by __init__ with random values)
        module.down_proj.weight.data.copy_(down_weight)

    def _repack_mlp_revert(module):
        """
        Repack separate gate_proj and up_proj back into fused gate_up_proj before reverting to Phi3MLP.

        Saves unpacked weights, calls Phi3MLP.__init__ to restore the original attribute layout,
        then reconstructs gate_up_proj by concatenating saved weights and restores down_proj.

        Args:
            module: A Phi3UnpackedMLP instance whose __class__ is about to be restored to Phi3MLP.
        """
        # 1. Save current unpacked weights
        gate_weight = module.gate_proj.weight.data.clone()
        up_weight = module.up_proj.weight.data.clone()
        down_weight = module.down_proj.weight.data.clone()
        config = module.config

        # 2. Restore original Phi3MLP attribute layout
        #    (nn.Module.__init__ resets _modules again, so we copy weights after)
        Phi3MLP.__init__(module, config)

        # 3. Reconstruct fused gate_up_proj and restore down_proj
        module.gate_up_proj.weight.data.copy_(torch.cat([gate_weight, up_weight], dim=0))
        module.down_proj.weight.data.copy_(down_weight)

    # ------------------------------------------------------------------
    # init_fn / revert_fn for Phi3ForCausalLM  <->  QcPhiForCausalLM
    # ------------------------------------------------------------------

    def _init_causal_lm_cache_tensor(module):
        """
        Register cache_tensor buffer on QcPhiForCausalLM after __class__ swap.

        TransformersModuleMapping swaps __class__ in-place without calling __init__, so
        this init_fn replicates the buffer registration from QcPhiForCausalLM.__init__.
        The buffer is only registered when input_tokens_per_inference is set in config.

        Args:
            module: A Phi3ForCausalLM instance whose __class__ has been set to QcPhiForCausalLM.
        """
        if (
            hasattr(module.config, "input_tokens_per_inference")
            and module.config.input_tokens_per_inference is not None
        ):
            module.register_buffer(
                name="cache_tensor",
                tensor=torch.arange(module.config.input_tokens_per_inference),
                persistent=False,
            )

    def _revert_causal_lm_cache_tensor(module):
        """
        Remove cache_tensor buffer before reverting QcPhiForCausalLM to Phi3ForCausalLM.

        Cleans up the buffer added during init_fn, since Phi3ForCausalLM does not have it.

        Args:
            module: A QcPhiForCausalLM instance whose __class__ is about to be restored.
        """
        if hasattr(module, "cache_tensor"):
            delattr(module, "cache_tensor")

    # ------------------------------------------------------------------
    # Exported mappings
    # ------------------------------------------------------------------

    MAPPINGS = {
        Phi3Attention: QcPhiAttention,
        Phi3ForCausalLM: QcPhiForCausalLM,
        Phi3Config: QcPhiConfig,
        Phi3Model: QcPhi3Model,
        Phi3RotaryEmbedding: QcPhiRotaryEmbedding,
        Phi3MLP: Phi3UnpackedMLP,
    }

    # Maps replacement class → callable(module) invoked by apply() after __class__ swap.
    # Only needed for replacements whose __init__ creates a different attribute layout.
    INIT_MAPPINGS = {
        QcPhiAttention: _unpack_attention_init,
        Phi3UnpackedMLP: _unpack_mlp_init,
        QcPhiForCausalLM: _init_causal_lm_cache_tensor,
    }

    # Maps replacement class → callable(module) invoked by revert() before __class__ restore.
    REVERT_INIT_MAPPINGS = {
        QcPhiAttention: _repack_attention_revert,
        Phi3UnpackedMLP: _repack_mlp_revert,
        QcPhiForCausalLM: _revert_causal_lm_cache_tensor,
    }

except ImportError:
    MAPPINGS = {}
    INIT_MAPPINGS = {}
    REVERT_INIT_MAPPINGS = {}
