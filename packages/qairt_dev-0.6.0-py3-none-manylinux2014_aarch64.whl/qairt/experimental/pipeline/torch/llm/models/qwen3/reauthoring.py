#!/usr/bin/env python3
# =============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries. Not a Contribution.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# =============================================================================

# =============================================================================
# coding=utf-8
# Copyright 2024 The Qwen team, Alibaba Group and the HuggingFace Inc. team. All rights reserved.
#
# This code is based on EleutherAI's GPT-NeoX library and the GPT-NeoX
# and OPT implementations in this library. It has been modified from its
# original forms to accommodate minor architectural differences compared
# to GPT-NeoX and OPT used by the Meta AI team that trained the model.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# =============================================================================

"""This file provides adaptations to the Qwen3 model. These adaptations are being done to
    optimize the model execution on the QAIRT HTP backend.
https://github.com/huggingface/transformers/blob/main/src/transformers/models/qwen3/modeling_qwen3.py"""

import math
from typing import Optional, Tuple, Union

import torch
from torch import nn
from transformers import Qwen3ForCausalLM
from transformers.modeling_outputs import CausalLMOutputWithPast
from transformers.models.qwen3.configuration_qwen3 import Qwen3Config
from transformers.models.qwen3.modeling_qwen3 import (
    Cache,
    DynamicCache,
    Qwen3Attention,
    Qwen3RotaryEmbedding,
    apply_rotary_pos_emb,
    repeat_kv,
)

from qairt.experimental.pipeline.torch.llm.models.utils import (
    QcAttentionMixin,
    QcConfigMixin,
    R3Hadamard,
    apply_rope_single,
    log_qc_operation,
)
from qairt.utils.loggers import get_logger

logger = get_logger("Qwen3Reauthoring")


class QcQwen3Config(Qwen3Config, QcConfigMixin):
    """
    Subclass of Qwen3Config to include additional configuration parameters for Qc optimizations.
    """

    def __init__(self, *args, **kwargs):
        Qwen3Config.__init__(self, *args, **kwargs)
        QcConfigMixin.__init__(self, **kwargs)


class QcQwen3Attention(QcAttentionMixin, Qwen3Attention):
    """Multi-headed attention from 'Attention Is All You Need' paper.

    Qwen3-specific adaptations over the base Llama-style attention:
      - Applies ``q_norm`` and ``k_norm`` (per-head RMSNorm) to query and key
        states *before* RoPE, as introduced in the Qwen3 architecture.
      - Output reshape uses ``num_attention_heads * head_dim`` rather than
        ``hidden_size`` (they are equivalent for standard configs but the
        explicit form matches the upstream Qwen3 implementation).

    We override the init and forward to apply these Qwen3-specific operations
    while reusing the shared QC optimizations (transposed key cache, masked
    softmax, scatter KV updates) provided by ``QcAttentionMixin``.
    """

    def __init__(self, config: QcQwen3Config, layer_idx: Optional[int] = None):
        """
        Override the init to enforce QcQwen3Config.

        Args:
            config: QcQwen3Config object
            layer_idx: Layer index for the attention layer
        """
        assert isinstance(config, QcQwen3Config), (
            "QcQwen3Attention requires a QcQwen3Config object. Use standard Qwen3Attention for Qwen3Config."
        )
        super(QcQwen3Attention, self).__init__(config, layer_idx or 0)

        if self.config.enable_r3_hadamard:
            """R3 Hadamard sourced from SpinQuant paper: https://arxiv.org/pdf/2405.16406"""
            self.q_R3 = R3Hadamard(head_dim=self.head_dim)
            self.k_R3 = R3Hadamard(head_dim=self.head_dim)
            log_qc_operation(logger, "r3_hadamard_init", {"head_dim": self.head_dim})

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Tuple[torch.Tensor]] = None,
        past_key_value: Optional[Tuple[torch.Tensor]] = None,
        output_attentions: bool = False,
        use_cache: bool = False,
        cache_position: Optional[torch.LongTensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        **kwargs,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        # QC Adaptation: From transformers>=4.56, past_key_value is deprecated
        # in favour of past_key_values.
        past_key_values = past_key_value if past_key_value is not None else past_key_values

        bsz, q_len, _ = hidden_states.size()

        query_states = self.q_proj(hidden_states)
        key_states = self.k_proj(hidden_states)
        value_states = self.v_proj(hidden_states)

        # Qwen3-specific: apply per-head RMSNorm (q_norm / k_norm) before RoPE.
        # The norm is applied in head-split form, then transposed to
        # (bsz, num_heads, seq_len, head_dim) for the rest of the attention path.
        query_states = self.q_norm(
            query_states.view(bsz, q_len, self.config.num_attention_heads, self.head_dim)
        ).transpose(1, 2)
        key_states = self.k_norm(
            key_states.view(bsz, q_len, self.config.num_key_value_heads, self.head_dim)
        ).transpose(1, 2)
        value_states = value_states.view(
            bsz, q_len, self.config.num_key_value_heads, self.head_dim
        ).transpose(1, 2)

        if position_embeddings is None:
            # QC: Check if position_ids is already a tuple (pre-computed embeddings)
            if isinstance(position_ids, (tuple, list)):
                position_embeddings = position_ids
            else:
                position_embeddings = self.rotary_emb(value_states, position_ids)

        cos, sin = position_embeddings

        if cos.shape[-1] == query_states.shape[-1]:
            query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin)
        else:
            query_states = apply_rope_single(query_states, position_embeddings)
            key_states = apply_rope_single(key_states, position_embeddings)
            log_qc_operation(
                logger,
                "custom_rope_application",
                {"cos_shape": cos.shape[-1], "query_shape": query_states.shape[-1]},
                log_once=True,
            )

        if self.config.enable_r3_hadamard:
            query_states = self.q_R3(query_states)
            key_states = self.k_R3(key_states)
            log_qc_operation(logger, "r3_hadamard_applied", log_once=True)

        # QC: Transpose keys if configured
        if self.config.transposed_key_cache:
            key_states = key_states.transpose(2, 3)
            log_qc_operation(
                logger, "transposed_key_cache", {"key_states_shape": key_states.shape}, log_once=True
            )

        if past_key_values is not None:
            assert isinstance(past_key_values, DynamicCache)
            # sin and cos are specific to RoPE models; cache_position needed for the static cache
            cache_kwargs = {
                "sin": sin,
                "cos": cos,
                "cache_position": cache_position,
            }
            cache_kwargs = self._update_cache_kwargs_with_qc_config(cache_kwargs)
            key_states, value_states = past_key_values.update(
                key_states, value_states, self.layer_idx, cache_kwargs
            )

        key_states = repeat_kv(key_states, self.num_key_value_groups)
        value_states = repeat_kv(value_states, self.num_key_value_groups)

        attn_weights: Optional[torch.Tensor] = None
        if self.config.transposed_key_cache:
            attn_weights = torch.matmul(query_states, key_states) / math.sqrt(self.head_dim)
            log_qc_operation(logger, "attention_with_transposed_keys", log_once=True)
        else:
            attn_weights = torch.matmul(query_states, key_states.transpose(2, 3)) / math.sqrt(self.head_dim)

        if attention_mask is not None:
            if attention_mask.shape[-1] != value_states.shape[-2]:
                attention_mask = attention_mask[:, :, :, : value_states.shape[-2]]
                log_qc_operation(
                    logger,
                    "attention_mask_adjustment",
                    {"mask_shape": attention_mask.shape, "value_states_shape": value_states.shape[-2]},
                    log_once=True,
                )

            if self.config.enable_masked_softmax:
                attn_weights_min, _ = torch.min(attn_weights, dim=-1, keepdim=True)
                minus_value = -20
                attn_weights = torch.where(attention_mask == 0, attn_weights, attn_weights_min + minus_value)
                log_qc_operation(logger, "masked_softmax", {"minus_value": minus_value}, log_once=True)
            else:
                attn_weights = attn_weights + attention_mask

        # upcast attention to fp32, ignore dropout here as it is not used during inference
        attn_weights = nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(query_states.dtype)
        attn_output = torch.matmul(attn_weights, value_states)

        if attn_output.size() != (bsz, self.config.num_attention_heads, q_len, self.head_dim):
            raise ValueError(
                f"`attn_output` should be of size "
                f"{(bsz, self.config.num_attention_heads, q_len, self.head_dim)}, but is"
                f" {attn_output.size()}"
            )

        attn_output = attn_output.transpose(1, 2)
        # Qwen3-specific: reshape uses num_attention_heads * head_dim (not hidden_size).
        # For standard configs these are equivalent, but the explicit form matches
        # the upstream Qwen3 implementation.
        attn_output = attn_output.reshape(bsz, q_len, self.config.num_attention_heads * self.head_dim)
        attn_output = self.o_proj(attn_output)

        if not output_attentions:
            attn_weights = None

        return attn_output, attn_weights


class QcQwen3RotaryEmbedding(Qwen3RotaryEmbedding):
    """
    Subclass of Qwen3RotaryEmbedding that short-circuits the forward pass when
    pre-computed position embeddings are passed as a ``(cos, sin)`` tuple via
    ``position_ids``.

    This allows the static-graph pipeline to inject pre-computed RoPE tensors
    without modifying the model's call sites.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def forward(self, x, position_ids, *args, **kwargs):
        if isinstance(position_ids, tuple) and len(position_ids) == 2:
            return position_ids
        return Qwen3RotaryEmbedding.forward(self, x, position_ids, *args, **kwargs)


class QcQwen3ForCausalLM(Qwen3ForCausalLM):
    """
    Subclass of original Qwen3ForCausalLM.

    Adds two QC-specific capabilities on top of the standard HuggingFace model:

    1. ``logits_to_keep`` is inferred from ``config.num_logits_to_keep`` when not
       supplied by the caller, ensuring compatibility with the static graph pipeline.

    2. ``cache_index`` support — allows explicit cache position control during
       autoregressive decoding (consistent with the reference adaptation pattern).
    """

    rotary_emb = QcQwen3RotaryEmbedding

    def __init__(self, config):
        super().__init__(config)
        if self.config.input_tokens_per_inference is not None:
            self.register_buffer(
                name="cache_tensor",
                tensor=torch.arange(config.input_tokens_per_inference),
                persistent=False,
            )

    @classmethod
    def from_pretrained(
        cls,
        pretrained_model_name_or_path: str,
        *model_args,
        model_reauthoring: bool = True,
        **pretrained_kwargs,
    ) -> "QcQwen3ForCausalLM":
        """
        Load a pretrained Qwen3 model with optional Qc re-authoring for the QAIRT HTP backend.
        Delegates to ``QcAutoModelForCausalLM.from_pretrained()``. See ``models/README.md``
        for full details on the re-authoring pipeline and class mappings.

        Args:
            pretrained_model_name_or_path: HuggingFace Hub model ID or local path.
            *model_args: Extra positional arguments forwarded to
                ``Qwen3ForCausalLM.from_pretrained()``.
            model_reauthoring: When ``True`` (default) the full Qwen3-specific Qc
                re-authoring pipeline is applied.  Set to ``False`` to obtain a
                vanilla HuggingFace ``Qwen3ForCausalLM`` for debugging.
            **pretrained_kwargs: Extra keyword arguments forwarded to
                ``Qwen3ForCausalLM.from_pretrained()`` (e.g. ``torch_dtype``,
                ``device_map``).

        Returns:
            A ``QcQwen3ForCausalLM`` instance (when ``model_reauthoring=True``) or a
            vanilla ``Qwen3ForCausalLM`` instance (when ``model_reauthoring=False``).

        Raises:
            Exception: Re-raised as-is if model loading or re-authoring fails.

        Example:
            .. code-block:: python

                # Standard usage — loads and re-authors the model
                model = QcQwen3ForCausalLM.from_pretrained(
                    "Qwen/Qwen3-4B",
                    torch_dtype="auto",
                    device_map="auto",
                )

                # Skip re-authoring for debugging
                vanilla = QcQwen3ForCausalLM.from_pretrained(
                    "Qwen/Qwen3-4B",
                    model_reauthoring=False,
                )
        """
        # Lazy import to avoid a circular dependency:
        #   reauthoring.py → auto_classes.py → htp_mappings.py
        #                  ↳ (lazy via importlib) models/qwen3/mappings.py → reauthoring.py
        from qairt.experimental.pipeline.torch.llm.loader.auto_classes import QcAutoModelForCausalLM

        logger.info(f"Loading Qwen3 model: {pretrained_model_name_or_path}")

        # Delegate entirely to QcAutoModelForCausalLM.from_pretrained, which:
        #   1. Loads the base model via AutoModelForCausalLM.from_pretrained()
        #   2. Applies TransformersModuleMapping (resolves "qwen3" → Qwen3-specific MAPPINGS)
        #   3. Applies KVCacheMapping (patches DynamicCache / DynamicLayer for HTP)
        return QcAutoModelForCausalLM.from_pretrained(
            pretrained_model_name_or_path,
            *model_args,
            model_reauthoring=model_reauthoring,
            **pretrained_kwargs,
        )

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Union[Cache, Tuple[Tuple[torch.Tensor, torch.Tensor]]]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        cache_index: Optional[torch.Tensor] = None,
        logits_to_keep: Optional[Union[int, torch.Tensor]] = None,
        **kwargs,
    ) -> Union[Tuple, CausalLMOutputWithPast]:
        if cache_index is not None:
            assert hasattr(self, "cache_tensor"), (
                'QcQwen3ForCausalLM doesn\'t have attribute "cache_tensor", '
                'check if "input_tokens_per_inference" is specified in model config'
            )
            cache_position = cache_index + self.cache_tensor

        return_dict = return_dict if return_dict else False

        if isinstance(past_key_values, (tuple, list)):
            past_key_values = DynamicCache.from_legacy_cache(past_key_values)

        if logits_to_keep is None:
            logits_to_keep = self.config.num_logits_to_keep

        outputs = super().forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            labels=labels,
            use_cache=use_cache,
            return_dict=return_dict,
            cache_position=cache_position,
            logits_to_keep=logits_to_keep,
            **kwargs,
        )

        if return_dict:
            assert type(outputs.past_key_values) != tuple
            past_key_values_output = DynamicCache.to_legacy_cache(outputs.past_key_values)
            outputs.past_key_values = past_key_values_output
        else:
            new_outputs = []
            for item in outputs:
                if isinstance(item, DynamicCache):
                    past_key_values_output = DynamicCache.to_legacy_cache(item)
                    new_outputs.append(past_key_values_output)
                else:
                    new_outputs.append(item)
            outputs = tuple(new_outputs)

        return outputs
