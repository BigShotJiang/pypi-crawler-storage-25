#!/usr/bin/env python3
# =============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# =============================================================================

# =============================================================================
# coding=utf-8
# Copyright 2022 EleutherAI and the HuggingFace Inc. team. All rights reserved.
#
# This code is based on EleutherAI's GPT-NeoX library and the GPT-NeoX
# and OPT implementations in this library. It has been modified from its
# original forms to accommodate minor architectural differences compared
# to GPT-NeoX and OPT used by the Meta AI team that trained the model.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# =============================================================================

"""This file provides adaptations to the Phi3 model. These adaptations are being done to
    optimize the model execution on the QAIRT HTP backend.
https://github.com/huggingface/transformers/blob/main/src/transformers/models/phi3/modeling_phi3.py"""

import math
from typing import Optional, Tuple, Union

import torch
from torch import nn
from transformers import Phi3ForCausalLM
from transformers.activations import ACT2FN
from transformers.modeling_outputs import BaseModelOutputWithPast, CausalLMOutputWithPast
from transformers.models.phi3.modeling_phi3 import (
    Cache,
    DynamicCache,
    Phi3Attention,
    Phi3Config,
    Phi3Model,
    Phi3RotaryEmbedding,
    apply_rotary_pos_emb,
    repeat_kv,
)

from qairt.experimental.pipeline.torch.llm.models.utils import (
    QcAttentionMixin,
    QcConfigMixin,
    apply_rope_single,
    log_qc_operation,
)
from qairt.utils.loggers import get_logger

logger = get_logger("PhiReauthoring")


class QcPhiConfig(Phi3Config, QcConfigMixin):
    """
    Subclass of PhiConfig to include additional configuration parameters for Qc optimizations.
    """

    def __init__(self, *args, **kwargs):
        Phi3Config.__init__(self, *args, **kwargs)
        QcConfigMixin.__init__(self, **kwargs)


class QcPhiAttention(QcAttentionMixin, Phi3Attention):
    """Multi-headed attention from 'Attention Is All You Need' paper
    We override the init and initialize the anchor updater.
    The user can optionally pass in the alpha value to initialize the anchor_updater through the model config.
    """

    def __init__(self, config: QcPhiConfig, layer_idx: Optional[int] = None):
        """
        Override the init to initialize the anchor updater.
        Args:
            config: QcPhiConfig object
            layer_idx: Layer index for the attention layer
        """
        assert isinstance(config, QcPhiConfig), (
            "QcPhiAttention requires a QcPhiConfig object. Use standard Phi3Attention for Phi3Config."
        )
        super(QcPhiAttention, self).__init__(config, layer_idx)

    def unpack_qkv(self):
        """Split the combined qkv_proj into separate q_proj, k_proj, v_proj for independent access."""
        device = self.qkv_proj.weight.device

        self.q_proj = nn.Linear(
            self.config.hidden_size, self.config.num_attention_heads * self.head_dim, bias=False
        ).to(device)
        self.k_proj = nn.Linear(
            self.config.hidden_size, self.config.num_key_value_heads * self.head_dim, bias=False
        ).to(device)
        self.v_proj = nn.Linear(
            self.config.hidden_size, self.config.num_key_value_heads * self.head_dim, bias=False
        ).to(device)

        # Calculate the positions for slicing
        total_hidden_size = self.config.num_attention_heads * self.head_dim  # query size
        key_value_size = self.config.num_key_value_heads * self.head_dim  # key and value size

        # Slicing and copying weights to q_proj, k_proj, v_proj
        self.q_proj.weight.data.copy_(self.qkv_proj.weight[:total_hidden_size, :])
        self.k_proj.weight.data.copy_(
            self.qkv_proj.weight[total_hidden_size : total_hidden_size + key_value_size, :]
        )
        self.v_proj.weight.data.copy_(self.qkv_proj.weight[total_hidden_size + key_value_size :, :])

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[Tuple[torch.Tensor]] = None,
        output_attentions: bool = False,
        use_cache: bool = False,
        cache_position: Optional[torch.LongTensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        *,
        past_key_values: Optional[Tuple[torch.Tensor]] = None,
        **kwargs,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        past_key_values = past_key_value if past_key_value is not None else past_key_values

        transposed_key_cache = (
            self.config.transposed_key_cache if hasattr(self.config, "transposed_key_cache") else False
        )

        bsz, q_len, _ = hidden_states.size()
        input_shape = hidden_states.shape[:-1]
        hidden_shape = (*input_shape, -1, self.head_dim)

        # Use separate projections after unpack_qkv() has been called
        query_states = self.q_proj(hidden_states).view(hidden_shape).transpose(1, 2)
        key_states = self.k_proj(hidden_states).view(hidden_shape).transpose(1, 2)
        value_states = self.v_proj(hidden_states).view(hidden_shape).transpose(1, 2)

        if position_embeddings is None:
            if isinstance(position_ids, (tuple, list)):  # QC: position_ids may carry pre-computed embeddings
                position_embeddings = position_ids
            else:
                position_embeddings = self.rotary_emb(value_states, position_ids)

        cos, sin = position_embeddings
        if cos.shape[-1] == query_states.shape[-1]:
            query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin)
        else:
            query_states = apply_rope_single(query_states, position_embeddings)
            key_states = apply_rope_single(key_states, position_embeddings)
            log_qc_operation(
                logger,
                "custom_rope_application",
                {"cos_shape": cos.shape[-1], "query_shape": query_states.shape[-1]},
                log_once=True,
            )

        # QC: Transpose keys if configured
        if transposed_key_cache:
            key_states = key_states.transpose(2, 3)
            log_qc_operation(
                logger, "transposed_key_cache", {"key_states_shape": key_states.shape}, log_once=True
            )

        if past_key_values is not None:
            assert isinstance(past_key_values, DynamicCache)
            # sin and cos are specific to RoPE models; cache_position needed for the static cache
            cache_kwargs = {
                "sin": sin,
                "cos": cos,
                "cache_position": cache_position,
            }
            cache_kwargs = self._update_cache_kwargs_with_qc_config(cache_kwargs)

            key_states, value_states = past_key_values.update(
                key_states, value_states, self.layer_idx, cache_kwargs
            )

        key_states = repeat_kv(key_states, self.num_key_value_groups)
        value_states = repeat_kv(value_states, self.num_key_value_groups)

        attn_weights: Optional[torch.Tensor] = None
        if transposed_key_cache:
            attn_weights = torch.matmul(query_states, key_states) / math.sqrt(self.head_dim)
            log_qc_operation(logger, "attention_with_transposed_keys", log_once=True)
        else:
            attn_weights = torch.matmul(query_states, key_states.transpose(2, 3)) / math.sqrt(self.head_dim)

        if attention_mask is not None:
            if attention_mask.shape[-1] != value_states.shape[-2]:
                attention_mask = attention_mask[:, :, :, : value_states.shape[-2]]
                log_qc_operation(
                    logger,
                    "attention_mask_adjustment",
                    {
                        "mask_shape": attention_mask.shape,
                        "value_states_shape": value_states.shape[-2],
                    },
                    log_once=True,
                )

            if self.config.enable_masked_softmax:
                attn_weights_min, _ = torch.min(attn_weights, dim=-1, keepdim=True)
                minus_value = -20
                attn_weights = torch.where(attention_mask == 0, attn_weights, attn_weights_min + minus_value)
                log_qc_operation(logger, "masked_softmax", {"minus_value": minus_value}, log_once=True)
            else:
                attn_weights = attn_weights + attention_mask

        # upcast attention to fp32
        attn_weights = nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(query_states.dtype)
        attn_output = torch.matmul(attn_weights, value_states)

        if attn_output.size() != (bsz, self.config.num_attention_heads, q_len, self.head_dim):
            raise ValueError(
                f"`attn_output` should be of size {(bsz, self.config.num_attention_heads, q_len, self.head_dim)}, but is"
                f" {attn_output.size()}"
            )

        attn_output = attn_output.transpose(1, 2)
        attn_output = attn_output.reshape(bsz, q_len, self.config.hidden_size)
        attn_output = self.o_proj(attn_output)

        if not output_attentions:
            attn_weights = None

        return attn_output, attn_weights


class QcPhiRotaryEmbedding(Phi3RotaryEmbedding):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def forward(self, x, position_ids, *args, **kwargs):
        if isinstance(position_ids, tuple) and len(position_ids) == 2:
            return position_ids
        else:
            return Phi3RotaryEmbedding.forward(self, x, position_ids, *args, **kwargs)


class QcPhiForCausalLM(Phi3ForCausalLM):
    """
    Subclass of original Phi3ForCausalLM. This is needed to serve two purposes:

    1. The logits_to_keep argument is inferred from the config when not supplied by the caller,
    ensuring compatibility with the static graph pipeline.

    2. Adds support for cache_index to allow explicit cache position control during autoregressive
    decoding, consistent with the reference adaptation pattern.
    """

    rotary_emb = QcPhiRotaryEmbedding

    def __init__(self, config):
        super().__init__(config)
        if self.config.input_tokens_per_inference is not None:
            self.register_buffer(
                name="cache_tensor", tensor=torch.arange(config.input_tokens_per_inference), persistent=False
            )

    @classmethod
    def from_pretrained(
        cls,
        pretrained_model_name_or_path: str,
        *model_args,
        model_reauthoring: bool = True,
        **pretrained_kwargs,
    ) -> "QcPhiForCausalLM":
        """
        Load a pretrained Phi3 model with optional Qc re-authoring for the QAIRT HTP backend.
        Delegates to ``QcAutoModelForCausalLM.from_pretrained()``. See ``models/README.md``
        for full details on the re-authoring pipeline and class mappings.

        Args:
            pretrained_model_name_or_path: HuggingFace Hub model ID or local path.
            *model_args: Extra positional arguments forwarded to
                Phi3ForCausalLM.from_pretrained().
            model_reauthoring: When True (default) the full Phi-specific Qc
                re-authoring pipeline is applied.  Set to False to obtain a
                vanilla HuggingFace Phi3ForCausalLM for debugging.
            **pretrained_kwargs: Extra keyword arguments forwarded to
                Phi3ForCausalLM.from_pretrained() (e.g. torch_dtype,
                device_map).

        Returns:
            A QcPhiForCausalLM instance (when model_reauthoring=True) or a
            vanilla Phi3ForCausalLM instance (when model_reauthoring=False).

        Raises:
            Exception: Re-raised as-is if model loading or re-authoring fails.

        Example:
            .. code-block:: python

                # Standard usage — loads and re-authors the model
                model = QcPhiForCausalLM.from_pretrained(
                    "microsoft/Phi-3-mini-4k-instruct",
                    torch_dtype="auto",
                    device_map="auto",
                )

                # Skip re-authoring for debugging
                vanilla = QcPhiForCausalLM.from_pretrained(
                    "microsoft/Phi-3-mini-4k-instruct",
                    model_reauthoring=False,
                )
        """
        # Lazy import to avoid a circular dependency:
        #   reauthoring.py → auto_classes.py → htp_mappings.py
        #                  ↳ (lazy via importlib) models/phi3/mappings.py → reauthoring.py
        from qairt.experimental.pipeline.torch.llm.loader.auto_classes import QcAutoModelForCausalLM

        logger.info(f"Loading Phi model: {pretrained_model_name_or_path}")

        # Delegate entirely to QcAutoModelForCausalLM.from_pretrained, which:
        #   1. Loads the base model via AutoModelForCausalLM.from_pretrained()
        #   2. Applies TransformersModuleMapping (resolves "phi3" → Phi3-specific MAPPINGS)
        #   3. Applies KVCacheMapping (patches DynamicCache / DynamicLayer for HTP)
        return QcAutoModelForCausalLM.from_pretrained(
            pretrained_model_name_or_path,
            *model_args,
            model_reauthoring=model_reauthoring,
            **pretrained_kwargs,
        )

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Union[Cache, Tuple[Tuple[torch.Tensor, torch.Tensor]]]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        cache_index: Optional[torch.Tensor] = None,
        logits_to_keep: Optional[Union[int, torch.Tensor]] = None,
        **kwargs,
    ) -> Union[Tuple, CausalLMOutputWithPast]:
        if cache_index is not None:
            assert hasattr(self, "cache_tensor"), (
                'QcPhiForCausal doesn\'t have attribute "cache_tensor", '
                'check if "input_tokens_per_inference" is specified in model config'
            )
            cache_position = cache_index + self.cache_tensor

        return_dict = return_dict if return_dict else False

        if isinstance(past_key_values, (tuple, list)):
            past_key_values = DynamicCache.from_legacy_cache(past_key_values)  # type: ignore[assignment]

        if logits_to_keep is None:
            logits_to_keep = self.config.num_logits_to_keep

        outputs = super().forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            labels=labels,
            use_cache=use_cache,
            return_dict=return_dict,
            cache_position=cache_position,
            logits_to_keep=logits_to_keep,
            **kwargs,
        )

        if return_dict:
            assert type(outputs.past_key_values) != tuple
            past_key_values_output = DynamicCache.to_legacy_cache(outputs.past_key_values)
            outputs.past_key_values = past_key_values_output
        else:
            new_outputs = []
            for item in outputs:
                if isinstance(item, DynamicCache):
                    past_key_values_output = DynamicCache.to_legacy_cache(item)
                    new_outputs.append(past_key_values_output)
                else:
                    new_outputs.append(item)
            outputs = tuple(new_outputs)

        return outputs


class QcPhi3Model(Phi3Model):
    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Union[Cache, Tuple[Tuple[torch.Tensor, torch.Tensor]]]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        **kwargs,
    ):
        if isinstance(past_key_values, (tuple, list)):
            past_key_values = DynamicCache.from_legacy_cache(past_key_values)  # type: ignore[assignment]

        outputs = super().forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            cache_position=cache_position,
            **kwargs,
        )

        if isinstance(outputs, BaseModelOutputWithPast):
            # Only convert if past_key_values is a DynamicCache.
            # When use_cache=False, past_key_values is None — leave it unchanged.
            if isinstance(outputs.past_key_values, DynamicCache):
                outputs.past_key_values = outputs.past_key_values.to_legacy_cache()  # type: ignore[assignment]
        elif isinstance(outputs, tuple):
            new_outputs = []
            for item in outputs:
                if isinstance(item, DynamicCache):
                    new_outputs.append(item.to_legacy_cache())
                else:
                    new_outputs.append(item)
            outputs = tuple(new_outputs)
        else:
            raise ValueError(
                f"Model output is expected to be an instance of BaseModelOutputWithPast or Tuple, got {type(outputs)}"
            )

        return outputs


class Phi3UnpackedMLP(nn.Module):
    def __init__(self, config):
        super().__init__()

        self.config = config
        self.gate_proj = nn.Linear(config.hidden_size, config.intermediate_size, bias=False)
        self.up_proj = nn.Linear(config.hidden_size, config.intermediate_size, bias=False)

        self.down_proj = nn.Linear(config.intermediate_size, config.hidden_size, bias=False)

        self.activation_fn = ACT2FN[config.hidden_act]

    def forward(self, hidden_states: torch.FloatTensor) -> torch.FloatTensor:
        gate = self.gate_proj(hidden_states)
        up_states = self.up_proj(hidden_states)

        up_states = up_states * self.activation_fn(gate)

        return self.down_proj(up_states)
