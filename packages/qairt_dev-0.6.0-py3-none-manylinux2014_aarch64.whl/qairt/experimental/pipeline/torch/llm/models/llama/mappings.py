# =============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries. Not a Contribution.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# =============================================================================
"""Llama module mappings (MAPPINGS, INIT_MAPPINGS, REVERT_INIT_MAPPINGS) for TransformersModuleMapping auto-discovery."""

import torch

try:
    from transformers.models.llama.configuration_llama import LlamaConfig
    from transformers.models.llama.modeling_llama import (
        LlamaAttention,
        LlamaForCausalLM,
        LlamaRotaryEmbedding,
    )

    from .reauthoring import (
        QcLlamaAttention,
        QcLlamaConfig,
        QcLlamaForCausalLM,
        QcLlamaRotaryEmbedding,
    )

    # ------------------------------------------------------------------
    # init_fn / revert_fn for LlamaForCausalLM  <->  QcLlamaForCausalLM
    # ------------------------------------------------------------------

    def _init_causal_lm_cache_tensor(module):
        """
        Register cache_tensor buffer on QcLlamaForCausalLM after __class__ swap.

        TransformersModuleMapping swaps __class__ in-place without calling __init__, so
        this init_fn replicates the buffer registration from QcLlamaForCausalLM.__init__.
        The buffer is only registered when input_tokens_per_inference is set in config.

        Args:
            module: A LlamaForCausalLM instance whose __class__ has been set to QcLlamaForCausalLM.
        """
        if (
            hasattr(module.config, "input_tokens_per_inference")
            and module.config.input_tokens_per_inference is not None
        ):
            module.register_buffer(
                name="cache_tensor",
                tensor=torch.arange(module.config.input_tokens_per_inference),
                persistent=False,
            )

    def _revert_causal_lm_cache_tensor(module):
        """
        Remove cache_tensor buffer before reverting QcLlamaForCausalLM to LlamaForCausalLM.

        Called before __class__ is restored. Removes the buffer added during init_fn,
        since LlamaForCausalLM does not have cache_tensor.

        Args:
            module: A QcLlamaForCausalLM instance whose __class__ is about to be restored.
        """
        if hasattr(module, "cache_tensor"):
            delattr(module, "cache_tensor")

    # ------------------------------------------------------------------
    # Exported mappings
    # ------------------------------------------------------------------

    MAPPINGS = {
        LlamaAttention: QcLlamaAttention,
        LlamaForCausalLM: QcLlamaForCausalLM,
        LlamaRotaryEmbedding: QcLlamaRotaryEmbedding,
        LlamaConfig: QcLlamaConfig,
    }

    # Maps replacement class → callable(module) invoked by apply() after __class__ swap.
    INIT_MAPPINGS = {
        QcLlamaForCausalLM: _init_causal_lm_cache_tensor,
    }

    # Maps replacement class → callable(module) invoked by revert() before __class__ restore.
    REVERT_INIT_MAPPINGS = {
        QcLlamaForCausalLM: _revert_causal_lm_cache_tensor,
    }

except ImportError:
    MAPPINGS = {}
    INIT_MAPPINGS = {}
    REVERT_INIT_MAPPINGS = {}
