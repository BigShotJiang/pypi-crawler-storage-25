# =============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries. Not a Contribution.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# =============================================================================
"""
Qc Auto Classes for Model Loading

This module provides Qc-enhanced auto classes that wrap HuggingFace's auto classes
with internal re-authoring and cache management for quantization-aware training and export.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Type

from transformers import AutoModelForCausalLM

from qairt.utils.loggers import get_logger

from .htp_mappings import KVCacheMapping, TransformersModuleMapping


class QcAutoConfig:
    """
    Creates Qc-enhanced model configs (e.g., QcLlamaConfig) by model type, passed to
    QcAutoModelForCausalLM.from_pretrained via qc_config to avoid Unrecognized configuration
    class errors.

    Three factory methods:

    - ``from_pretrained(pretrained_model_name_or_path, **qc_kwargs)``: Loads config from Hub ID or path.
    - ``from_model_type(model_type, base_config, **qc_kwargs)``: Takes an explicit model type string.
    - ``from_config(config, **qc_kwargs)``: Reads ``config.model_type`` automatically.

    Example:
        .. code-block:: python

            from qairt.experimental.pipeline.torch.llm.loader.auto_classes import (
                QcAutoConfig,
                QcAutoModelForCausalLM,
            )

            # Single-step: load the HF config and build the Qc config together.
            # AutoConfig.from_pretrained is called internally — no separate step needed.
            qc_config = QcAutoConfig.from_pretrained(
                "meta-llama/Llama-3.2-1B-Instruct",
                transposed_key_cache=True,
                perform_scatter_kv_cache_update=True,
                input_tokens_per_inference=512,
                num_logits_to_keep=1,
            )

            # Load the model — the Qc config is applied during re-authoring,
            # not during AutoModelForCausalLM.from_pretrained, so no
            # "Unrecognized configuration class" error is raised.
            model = QcAutoModelForCausalLM.from_pretrained(
                "meta-llama/Llama-3.2-1B-Instruct",
                qc_config=qc_config,
                torch_dtype="auto",
                device_map="auto",
            )
    """

    _logger = get_logger("QcAutoConfig")

    @classmethod
    def from_model_type(
        cls,
        model_type: str,
        base_config: Any,
        **qc_kwargs,
    ) -> Any:
        """
        Create a Qc config for the given model type by discovering the Qc config class,
        instantiating it from the base config's serialized dict, and applying any
        Qc-specific kwargs.

        Args:
            model_type: HuggingFace model type string (e.g. ``"llama"``, ``"phi"``).
            base_config: The original HuggingFace config whose attributes are copied
                         into the new Qc config.
            **qc_kwargs: Qc-specific parameters to set on the config (must be valid
                         QcConfigMixin attribute names, e.g. ``transposed_key_cache``,
                         ``perform_scatter_kv_cache_update``).

        Returns:
            A new Qc config instance (e.g. ``QcLlamaConfig``) with all base config
            attributes and the requested Qc parameters applied.

        Raises:
            ImportError: If the model type is not supported or its mappings module
                         cannot be imported.
            ValueError: If no Qc config class is found for the base config type.
        """
        import importlib

        try:
            # Load the model-specific mappings module.
            mappings_module = f"..models.{model_type}.mappings"
            mod = importlib.import_module(mappings_module, package=__package__)
        except ModuleNotFoundError:
            cls._logger.error(
                f"Failed to load mappings for model type '{model_type}': unsupported model type"
            )
            raise

        try:
            # Locate the Qc config class for the base config type.
            mappings: dict = getattr(mod, "MAPPINGS", {})
            base_config_type = type(base_config)
            qc_config_class = mappings.get(base_config_type)

            if qc_config_class is None:
                raise ValueError(
                    f"No Qc config mapping found for {base_config_type.__name__} "
                    f"in model type '{model_type}'. "
                    f"Available mappings: {list(mappings.keys())}"
                )

            # Instantiate the Qc config from the base config's serialized dict so
            # that all standard HuggingFace attributes are preserved.
            qc_config = qc_config_class(**base_config.to_dict())

            # Apply Qc-specific parameters directly onto the new config object.
            for key, value in qc_kwargs.items():
                if hasattr(qc_config, key):
                    setattr(qc_config, key, value)
                else:
                    cls._logger.warning(
                        f"QcAutoConfig: '{key}' is not a recognised attribute of "
                        f"{qc_config_class.__name__} — skipping."
                    )

            # QC attrs that were non-default before qc_kwargs were applied (i.e. came from base_config).
            backing_attrs = getattr(qc_config, "QC_BACKING_ATTRS", {})
            qc_attrs_from_base = {
                k: getattr(qc_config, k)
                for k in backing_attrs
                if k not in qc_kwargs and getattr(qc_config, k) != backing_attrs[k]
            }
            parts = [f"Created {qc_config_class.__name__} from {base_config_type.__name__}"]
            if qc_kwargs:
                parts.append(f"qc_kwargs={qc_kwargs}")
            if qc_attrs_from_base:
                parts.append(f"qc_attrs_from_base_config={qc_attrs_from_base}")
            cls._logger.debug(", ".join(parts))
            return qc_config

        except Exception as e:
            cls._logger.error(f"Failed to create Qc config for model type '{model_type}': {e}")
            raise

    @classmethod
    def from_pretrained(
        cls,
        pretrained_model_name_or_path: str,
        model_config_overrides: Optional[Dict[str, Any]] = None,
        **qc_kwargs,
    ) -> Any:
        """
        Load a HuggingFace config from a local path or Hub ID and create the
        corresponding Qc config in one step — combines ``AutoConfig.from_pretrained``
        and ``QcAutoConfig.from_config``.

        Args:
            pretrained_model_name_or_path: Local path or Hub model ID.
            model_config_overrides: Optional dict of config attributes to apply before
                wrapping into a Qc config. HuggingFace attributes (e.g. ``{"num_hidden_layers": 16}``)
                are set on the base config; QC-specific attributes (any key in
                ``QcConfigMixin.QC_BACKING_ATTRS``, e.g. ``{"transposed_key_cache": True}``) are
                forwarded as ``qc_kwargs``. Explicit ``qc_kwargs`` take precedence over the same
                key in ``model_config_overrides``.
            **qc_kwargs: Qc-specific ``QcConfigMixin`` attributes to set.

        Returns:
            A new Qc config instance (e.g. ``QcLlamaConfig``) with all base
            config attributes and the requested Qc parameters applied.

        Raises:
            ImportError: If the model type is not supported or its mappings
                         module cannot be imported.
            ValueError: If no Qc config class is found for the base config type.

        Example:
            .. code-block:: python

                qc_config = QcAutoConfig.from_pretrained(
                    "meta-llama/Llama-3.2-1B-Instruct",
                    transposed_key_cache=True,
                    perform_scatter_kv_cache_update=True,
                    input_tokens_per_inference=512,
                    num_logits_to_keep=1,
                )

                model = QcAutoModelForCausalLM.from_pretrained(
                    "meta-llama/Llama-3.2-1B-Instruct",
                    qc_config=qc_config,
                )
        """
        from transformers import AutoConfig

        from ..models.utils import QcConfigMixin

        base_config = AutoConfig.from_pretrained(pretrained_model_name_or_path)
        cls._logger.info(
            f"Loaded base config ({type(base_config).__name__}) from '{pretrained_model_name_or_path}'"
        )
        if model_config_overrides:
            qc_keys = QcConfigMixin.QC_BACKING_ATTRS.keys()
            for key, value in model_config_overrides.items():
                if key in qc_keys:
                    # QC-specific override: merge into qc_kwargs (explicit qc_kwargs take precedence)
                    qc_kwargs.setdefault(key, value)
                else:
                    setattr(base_config, key, value)
        return cls.from_config(base_config, **qc_kwargs)

    @classmethod
    def from_config(cls, config: Any, **qc_kwargs) -> Any:
        """
        Create a Qc config object from an existing HuggingFace config object.

        Args:
            config: The original HuggingFace config whose ``model_type``
                    attribute is used to look up the Qc config class.
            **qc_kwargs: Qc-specific parameters to set on the config.

        Returns:
            Qc config object with the specified parameters.

        Raises:
            ValueError: If ``config`` does not have a ``model_type`` attribute.
        """
        model_type = getattr(config, "model_type", None)
        if model_type is None:
            raise ValueError("Config does not have a model_type attribute")

        return cls.from_model_type(model_type, config, **qc_kwargs)


class QcAutoModelForCausalLM:
    """
    Qc-enhanced AutoModelForCausalLM with internal re-authoring.

    This class provides an interface for loading models with Qc-specific
    optimizations for Qualcomm hardware.

    The class automatically applies:
    1. Module replacement (HF modules → Qc-optimized modules)
    2. DynamicLayer patching for KV cache management
    3. Config flag setting (use_cache, padding_side, etc.)

    Example:
    .. code-block:: python
        # Load with automatic re-authoring (default)
        model = QcAutoModelForCausalLM.from_pretrained("meta-llama/Llama-3.2-1B")

        # Load without re-authoring (for debugging)
        model = QcAutoModelForCausalLM.from_pretrained(
            "meta-llama/Llama-3.2-1B",
            model_reauthoring=False
        )

    """

    # Class attribute: module mapping transformer
    # Can be overridden for different model architectures (LVM, LMM, etc.)
    _transformers_module_mapping: Type[TransformersModuleMapping] = TransformersModuleMapping
    _kv_cache_module_mapping: Type[KVCacheMapping] = KVCacheMapping
    _logger = get_logger("QcAutoModelForCausalLM")

    def __init__(self):
        """Prevent instantiation - this is a utility class with class methods only."""
        raise TypeError(
            "QcAutoModelForCausalLM is not meant to be instantiated. "
            "Use QcAutoModelForCausalLM.from_pretrained() instead."
        )

    @classmethod
    def from_pretrained(
        cls,
        pretrained_model_name_or_path: str,
        *model_args,
        model_reauthoring: bool = True,
        qc_config: Optional[Any] = None,
        **pretrained_kwargs,
    ) -> Any:
        """
        Load a pretrained model via AutoModelForCausalLM with optional Qc re-authoring
        for the QAIRT HTP backend.

        Args:
            pretrained_model_name_or_path: Hub ID or local path.
            *model_args: Positional arguments passed to AutoModelForCausalLM.from_pretrained().
            model_reauthoring: If True (default), apply Qc optimization pipeline; if False,
                return a vanilla HF model.
            qc_config: Optional Qc config (from QcAutoConfig) to replace the model's config
                during re-authoring instead of class replacement.
            **pretrained_kwargs: Passed to AutoModelForCausalLM.from_pretrained().

        Returns:
            Loaded model, optionally re-authored.

        Example:
            .. code-block:: python

                # Standard usage with re-authoring
                model = QcAutoModelForCausalLM.from_pretrained(
                    "meta-llama/Llama-3.2-1B-Instruct",
                    torch_dtype="auto",
                    device_map="auto"
                )

                # Usage with Qc config
                qc_config = QcAutoConfig.from_model_type(
                    "llama",
                    base_config,  # obtained separately
                    transposed_key_cache=True,
                    perform_scatter_kv_cache_update=True,
                )
                model = QcAutoModelForCausalLM.from_pretrained(
                    "meta-llama/Llama-3.2-1B-Instruct",
                    qc_config=qc_config,
                )

                # Skip re-authoring for debugging
                vanilla_model = QcAutoModelForCausalLM.from_pretrained(
                    "meta-llama/Llama-3.2-1B-Instruct",
                    model_reauthoring=False
                )
        """

        cls._logger.info(f"Loading model: {pretrained_model_name_or_path}")

        # Step 1: Load the base model using standard HuggingFace loader
        try:
            model: Any = AutoModelForCausalLM.from_pretrained(
                pretrained_model_name_or_path, *model_args, **pretrained_kwargs
            )
            cls._logger.info("Model loaded successfully")
        except Exception as e:
            cls._logger.error(f"Failed to load model: {e}")
            raise

        # Step 2: Apply Qc re-authoring if not skipped
        if model_reauthoring:
            try:
                # Apply the module mapping transformer
                # This will:
                # - Replace modules (e.g., LlamaAttention → QcLlamaAttention)
                # - Replace config with qc_config if provided
                # - Patch DynamicLayer methods
                # - Set config flags
                model = cls._transformers_module_mapping.apply(model, qc_config=qc_config)
                cls._logger.debug("Module mapping completed successfully")

                model = cls._kv_cache_module_mapping.apply(model)
                cls._logger.debug("KV cache patching completed successfully")
            except Exception as e:
                cls._logger.error(f"Re-authoring failed: {e}")
                raise
        else:
            cls._logger.info("Skipping re-authoring (model_reauthoring=False)")

        # Step 3: Return the model (re-authored or vanilla)
        cls._logger.info("Returning model")
        return model
