# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
Re-authoring Registry System - Base Classes

This module provides the base classes for model re-authoring transforms.
Specialized transforms for different model types (LLM, LVM, LMM) inherit from these base classes.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Callable, Dict, Generator, Optional, Type

import torch.nn as nn


class PytorchTransform:
    """
    Base class for PyTorch module transformations.
    """

    def __init__(self):
        raise TypeError("Transform classes are not to be instantiated. Directly use the `apply` method.")

    @classmethod
    def apply(cls, model: nn.Module) -> nn.Module:
        """
        Apply transformation to model. Implement logic in subclass.

        Args:
            model: The torch module to transform (may be transformed in-place).

        Returns:
            Transformed model.
        """
        raise NotImplementedError("Use subclasses for Pytorch transform")

    @classmethod
    def revert(cls, model: nn.Module) -> nn.Module:
        """
        Revert transformation applied to model.

        Args:
            model: The torch module to revert

        Returns:
            Reverted model
        """
        raise NotImplementedError("Use subclasses for Pytorch transform")

    @classmethod
    @contextmanager
    def applied(cls, model: nn.Module) -> Generator[nn.Module, None, None]:
        """
        Context manager that applies the transform on entry and reverts it on exit.

        Args:
            model: The torch module to transform

        Yields:
            Transformed model

        Example:
            .. code-block:: python

                with SomeTransform.applied(model) as m:
                    export(m)   # model has Qc modules here
                # model is back to original HF modules here
        """
        try:
            cls.apply(model)
            yield model
        finally:
            cls.revert(model)


class ModuleMappingTransform(PytorchTransform):
    """
    Replaces PyTorch modules based on the _module_mapping class variable.

    This is the core transform class that handles all module replacements
    across different model architectures.
    """

    _module_mapping: Dict[Type[nn.Module], Type[nn.Module]] = {}

    # Maps replacement module class -> callable(module) invoked after __class__ swap.
    # Use this when the replacement class's __init__ must run to create new attributes
    # (e.g. Phi3UnpackedMLP splits gate_up_proj into gate_proj / up_proj).
    _init_mapping: Dict[Type[nn.Module], Callable[[nn.Module], None]] = {}

    # Maps replacement module class -> callable(module) invoked during revert to undo
    # any attributes that were added by the forward init_fn.
    _revert_init_mapping: Dict[Type[nn.Module], Callable[[nn.Module], None]] = {}

    @classmethod
    def apply(cls, model: nn.Module) -> nn.Module:
        """
        Apply module replacements by iterating all modules and swapping ``__class__``
        per ``_module_mapping``. Calls the registered ``init_fn`` after each swap
        if one exists.

        Args:
            model: Model to transform.

        Returns:
            Transformed model.
        """

        for module in model.modules():
            if repl_module := cls._module_mapping.get(type(module)):
                module.__class__ = repl_module

                # If an init_fn was registered for this replacement class, call it now.
                # This is necessary when the replacement __init__ creates new attributes
                # that do not exist on the original module (e.g. splitting a fused
                # projection into separate nn.Linear layers).
                if init_fn := cls._init_mapping.get(repl_module):
                    init_fn(module)

                # Qgenie-TODO: add a reference to the original module
                # Qgenie-TODO: Add a string mapping showing every module that was replaced
                #  and what it was replaced with.

        return model

    @classmethod
    def revert(cls, model: nn.Module) -> nn.Module:
        """
        Revert module class replacements made by apply().

        Builds the reverse mapping from _module_mapping and restores each
        module's __class__ to its original type.

        Args:
            model: Model whose modules should be reverted

        Returns:
            Model with original module classes restored
        """
        reverse_mapping = {v: k for k, v in cls._module_mapping.items()}
        for module in model.modules():
            if orig_class := reverse_mapping.get(type(module)):
                # If a revert_init_fn was registered, call it before restoring the class
                # so it can clean up attributes that were added by the forward init_fn.
                if revert_fn := cls._revert_init_mapping.get(type(module)):
                    revert_fn(module)
                module.__class__ = orig_class
        return model

    @classmethod
    def register(
        cls,
        from_module: Type[nn.Module],
        to_module: Type[nn.Module],
        init_fn: Optional[Callable[[nn.Module], None]] = None,
        revert_init_fn: Optional[Callable[[nn.Module], None]] = None,
    ) -> None:
        """
        Register a module replacement mapping for use by apply() and revert().

        Args:
            from_module: Original HF module class.
            to_module: Replacement module class.
            init_fn: Optional callable ``(module) -> None`` invoked after ``__class__``
                is set to ``to_module`` — use when the replacement needs to create new
                attributes (e.g. splitting a fused projection).
            revert_init_fn: Optional callable ``(module) -> None`` invoked during revert
                before restoring ``__class__`` — use to clean up attributes added by
                ``init_fn``.
        """
        cls._module_mapping[from_module] = to_module
        if init_fn is not None:
            cls._init_mapping[to_module] = init_fn
        if revert_init_fn is not None:
            cls._revert_init_mapping[to_module] = revert_init_fn
