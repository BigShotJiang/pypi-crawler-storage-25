# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
LLM Model Re-authoring Registry for transformer-based models (Llama, GPT, Mistral, Phi, Qwen).

Provides re-authoring transforms including module replacement, DynamicCache patching,
and config flag setting. Inherits from ModuleMappingTransform and adds LLM-specific steps.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Type

import torch.nn as nn
from transformers.configuration_utils import PretrainedConfig

from qairt.experimental.pipeline.torch.llm.models.utils import (
    QcConfigMixin,
    QcDynamicLayer,
    revert_attr,
    update_attr,
)
from qairt.utils.loggers import get_logger

from .pytorch_transforms import ModuleMappingTransform, PytorchTransform


class TransformersModuleMapping(ModuleMappingTransform):
    """
    Re-authoring transform for LLM models (Llama, GPT, Mistral, etc.).
    Handles module replacement and config flag setting.
    """

    _logger = get_logger("TransformersModuleMapping")
    _module_mapping: Dict[Type[nn.Module], Type[nn.Module]] = {}
    # Tracks which model packages have already been loaded to avoid redundant imports
    _loaded_models: set = set()

    @classmethod
    def _initialize_module_mapping(cls, model_name: Optional[str] = None) -> None:
        """Initialize module mappings from model packages.

        Each model package exposes ``mappings.py`` with ``MAPPINGS = {HFClass: QcClass}``.
        If ``model_name`` is given, only that model's mappings are loaded; otherwise all
        packages are discovered via pkgutil. Import failures are isolated and logged.

        Args:
            model_name: HuggingFace ``config.model_type`` (e.g. ``"llama"``). Pass ``None``
                to load all available model packages.
        """
        import importlib
        import pkgutil

        from .. import models as _models_pkg

        if model_name is not None:
            # Fast path: already loaded this model's mappings.
            if model_name in cls._loaded_models:
                return

            # Check whether a sub-package exists for this model_name.
            available = {name for _finder, name, _ispkg in pkgutil.iter_modules(_models_pkg.__path__)}

            if model_name in available:
                mappings_module = f"..models.{model_name}.mappings"
                try:
                    mod = importlib.import_module(mappings_module, package=__package__)
                    model_mappings: dict = getattr(mod, "MAPPINGS", {})
                    cls._module_mapping.update(model_mappings)
                    cls._init_mapping.update(getattr(mod, "INIT_MAPPINGS", {}))
                    cls._revert_init_mapping.update(getattr(mod, "REVERT_INIT_MAPPINGS", {}))
                    cls._loaded_models.add(model_name)
                    cls._logger.debug(f"Loaded {len(model_mappings)} mapping(s) for: {model_name}")
                except ImportError as e:
                    # Mark as attempted so we don't retry on every call.
                    cls._loaded_models.add(model_name)
                    cls._logger.warning(f"Skipped '{model_name}' — could not import {mappings_module}: {e}")
            else:
                cls._logger.warning(
                    f"No model package found for '{model_name}', "
                    "falling back to loading all available models."
                )
                cls._initialize_module_mapping()  # Fall back to full discovery
        else:
            # Load all available model packages, skipping any already loaded.
            for _finder, name, _ispkg in pkgutil.iter_modules(_models_pkg.__path__):
                if name in cls._loaded_models:
                    continue
                mappings_module = f"..models.{name}.mappings"
                try:
                    mod = importlib.import_module(mappings_module, package=__package__)
                    model_mappings = getattr(mod, "MAPPINGS", {})
                    cls._module_mapping.update(model_mappings)
                    cls._init_mapping.update(getattr(mod, "INIT_MAPPINGS", {}))
                    cls._revert_init_mapping.update(getattr(mod, "REVERT_INIT_MAPPINGS", {}))
                    cls._loaded_models.add(name)
                    cls._logger.debug(f"Loaded {len(model_mappings)} mapping(s) for: {name}")
                except ImportError as e:
                    cls._loaded_models.add(name)
                    cls._logger.warning(f"Skipped '{name}' — could not import {mappings_module}: {e}")

            cls._logger.debug(f"Initialized module mapping with {len(cls._module_mapping)} total entries")

    @classmethod
    def apply(cls, model: nn.Module, qc_config: Optional[Any] = None) -> nn.Module:
        """
        Apply LLM re-authoring: loads module mappings, replaces model.config with the
        Qc config class (or assigns qc_config directly), replaces submodules, and sets
        config flags.

        Args:
            model: LLM model to transform.
            qc_config: Optional pre-built Qc config (via QcAutoConfig). When provided,
                used directly instead of class-level replacement.

        Returns:
            Transformed model.
        """

        # Initialize module mapping — load only the mappings relevant to
        # this model by resolving its HuggingFace model_type string (e.g. "llama",
        # "phi").  Falls back to loading all packages when the type is unknown.
        model_name = getattr(getattr(model, "config", None), "model_type", None)
        cls._initialize_module_mapping(model_name)

        # Step 1: Replace config
        # Use pre-built qc_config if provided; otherwise use standard class replacement.
        cls._replace_config(model, qc_config=qc_config)

        # Step 2: Replace modules
        model = super().apply(model)

        # Step 3: Set config flags
        cls._set_config_flags(model)

        cls._logger.debug("apply() EXIT")
        return model

    @classmethod
    def revert(cls, model: nn.Module) -> nn.Module:
        """
        Revert all changes made by apply(): restore config and module classes to originals.

        Args:
            model: Model to revert.

        Returns:
            Model with original classes restored.
        """
        # Revert config class
        if hasattr(model, "config"):
            reverse_mapping = {v: k for k, v in cls._module_mapping.items()}
            # Capture the current (Qc) class name BEFORE reassigning __class__,
            current_config_class = type(model.config)
            if orig_config_class := reverse_mapping.get(current_config_class):
                model.config.__class__ = orig_config_class
                cls._logger.debug(
                    f"Reverted config: {current_config_class.__name__} → {orig_config_class.__name__}"
                )

        # Revert module classes via parent
        super().revert(model)
        return model

    @classmethod
    def _replace_config(cls, model: nn.Module, qc_config: Optional[Any] = None) -> None:
        """
        Replace model.config with a Qc-enhanced version. Two strategies:

        1. **qc_config provided**: assigns it directly to ``model.config``, preserving
           all ``QcConfigMixin`` parameters.
        2. **qc_config not provided**: replaces ``model.config.__class__`` in-place using
           ``_module_mapping``; ``QcConfigMixin`` properties use defaults.

        Args:
            model: Model whose config should be replaced.
            qc_config: Optional pre-built Qc config object (e.g. QcLlamaConfig).
        """
        if not hasattr(model, "config"):
            return

        if qc_config is not None:
            # Replace __class__ in-place so attention modules see QcConfigMixin properties,
            # then copy Qc attributes from qc_config to preserve caller-supplied values.
            original_class = type(model.config).__name__
            qc_config_class = type(qc_config)
            model.config.__class__ = qc_config_class

            for attr in (f"_{k}" for k in QcConfigMixin.QC_BACKING_ATTRS):
                if hasattr(qc_config, attr):
                    setattr(model.config, attr, getattr(qc_config, attr))

            # Copy HF config fields that were overridden in qc_config.
            qc_backing = {f"_{k}" for k in QcConfigMixin.QC_BACKING_ATTRS}
            for attr, qc_val in vars(qc_config).items():
                if attr.startswith("_") or attr in qc_backing:
                    continue
                if getattr(model.config, attr, None) != qc_val:
                    setattr(model.config, attr, qc_val)

            cls._logger.debug(
                f"Replaced config: {original_class} → {qc_config_class.__name__} (via QcAutoConfig)"
            )
        else:
            # Strategy 2: in-place class replacement using the module mapping.
            config_type = type(model.config)
            if repl_config := cls._module_mapping.get(config_type):
                model.config.__class__ = repl_config
                cls._logger.debug(f"Replaced config: {config_type.__name__} → {repl_config.__name__}")

    @classmethod
    def _set_config_flags(cls, model: nn.Module, **flags) -> PretrainedConfig:
        """
        Set config flags for the LLM model.

        Args:
            model: Model to configure.
            **flags: Additional flags to set on config.

        Returns:
            Updated model config.
        """
        model.config._attn_implementation = "eager"
        model.config._attn_implementation_internal = "eager"

        return model.config


# Create a separate mapping class for KVCache
class KVCacheMapping(PytorchTransform):
    """
    Separate mapping class for KV Cache transformations. Currently patches DynamicLayer
    methods directly; can be extended for more complex KV cache transforms if needed.
    """

    _logger = get_logger("KVCacheMapping")
    # Stores original DynamicCache methods so they can be restored by revert()
    _saved_methods: Dict[str, Any] = {}

    @classmethod
    def apply(cls, model: nn.Module) -> nn.Module:
        """
        Patch DynamicLayer methods so KV cache updates use Qc implementations
        during export/inference.

        Args:
            model: LLM model to patch.

        Returns:
            Patched model.
        """
        cls._apply_cache_patches(model)
        return model

    @classmethod
    def revert(cls, model: nn.Module) -> nn.Module:
        """
        Restore original DynamicLayer methods saved during apply().

        Args:
            model: Unused — DynamicLayer patches are global.

        Returns:
            model (unchanged).
        """
        if not cls._saved_methods:
            return model

        from transformers import cache_utils

        for method_name in list(cls._saved_methods.keys()):
            reverted = revert_attr(cache_utils.DynamicLayer, method_name)
            if reverted:
                cls._logger.debug(f"Restored DynamicLayer.{method_name}")
            else:
                cls._logger.warning(f"Could not restore DynamicLayer.{method_name} — backup not found")

        cls._saved_methods.clear()
        return model

    @classmethod
    def _apply_cache_patches(cls, model: nn.Module) -> None:
        """
        Patch DynamicCache methods for KV cache management: saves originals, then
        replaces ``update`` and ``get_seq_length`` with Qc implementations.

        Args:
            model: Model to patch cache for.
        """

        # Patch DynamicLayer methods for transformers
        from transformers import cache_utils

        methods_to_patch = {
            "update": QcDynamicLayer.update,
            "get_seq_length": QcDynamicLayer.get_seq_length,
        }

        for method_name, qc_method in methods_to_patch.items():
            # Save original only on first patch (avoid overwriting with Qc version)
            if method_name not in cls._saved_methods:
                cls._saved_methods[method_name] = getattr(cache_utils.DynamicLayer, method_name)

            # Patch the method
            success = update_attr(cache_utils.DynamicLayer, method_name, qc_method)
            if success:
                cls._logger.debug(f"Successfully patched DynamicLayer.{method_name}")

                patched_method = getattr(cache_utils.DynamicLayer, method_name)
                cls._logger.debug(
                    f"Mapping: {method_name} -> {patched_method} (original: {cls._saved_methods[method_name]})"
                )
            else:
                cls._logger.warning(f"Failed to patch DynamicLayer.{method_name}")

        cls._logger.debug("_apply_cache_patches() EXIT")
