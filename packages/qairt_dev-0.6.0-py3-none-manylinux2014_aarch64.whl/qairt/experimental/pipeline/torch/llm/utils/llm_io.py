# =============================================================================
#
#  Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
#  All rights reserved.
#  Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# =============================================================================

"""Unified LLM input/output tensor specification."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Literal, NamedTuple, Optional, overload

if TYPE_CHECKING:
    from qti.aisw.tools.core.modules.converter.converter_module import (
        InputTensorConfig,
        OutputTensorConfig,
    )


class IOType(str, Enum):
    """Whether tensor names are flattened (GENIE) or tupled (HF)."""

    GENIE = "genie"
    HF = "hf"


class Feature(str, Enum):
    """Feature flags that determine which additional tensors are added."""

    EAGLET = "eaglet"
    EAGLET_V2 = "eaglet_v2"
    SLIDING_WINDOW_ATTENTION = "sliding_window_attention"
    LONG_CONTEXT = "long_context"
    DEEPSTACK = "deepstack"
    KV_SHARING = "kv_sharing"


class TensorSpec(NamedTuple):
    """Full specification of a single logical tensor."""

    name: str
    datatype: Optional[str]
    layout: str
    repeated: bool = False
    io: Literal["input", "output"] = "input"
    io_type: Optional["IOType"] = None
    use_embedding: Optional[bool] = None


def _s(
    name: str,
    datatype: Optional[str],
    layout: str = "NONTRIVIAL",
    repeated: bool = False,
    io: Literal["input", "output"] = "input",
    io_type: Optional["IOType"] = None,
    use_embedding: Optional[bool] = None,
) -> TensorSpec:
    """Shorthand for building TensorSpec tuples."""
    return TensorSpec(name, datatype, layout, repeated, io, io_type, use_embedding)


class IOSpecs:
    """Static registry mapping features to their tensor specs.

    Each class attribute is a tuple of :class:`TensorSpec` objects for the
    inputs and outputs that belong to that feature group.

    ``IOSpecs.COMMON`` contains all canonical common tensors for both HF and
    GENIE io_types.  Each spec carries ``io_type`` and ``use_embedding``
    metadata so :class:`LlmIO` can filter the full set down to the active
    configuration without any per-name conditionals.

    Example::

        IOSpecs.COMMON                          # all standard LLM tensors
        IOSpecs.EAGLET                          # eaglet-specific tensors
        IOSpecs.get_spec_by_feature(Feature.EAGLET)  # same, via enum lookup
        IOSpecs.get_spec_by_name("hidden_states")    # single spec by name
    """

    # ------------------------------------------------------------------
    # Common tensors
    #
    # io_type=None      → included for both HF and GENIE
    # io_type=IOType.HF → included only when the relevant side is HF
    #                     (or when use_position_embedding_input=False for
    #                      position_ids, handled in LlmIO._filter_common)
    # io_type=IOType.GENIE → included only when the relevant side is GENIE
    #                        and use_position_embedding_input=True
    #
    # use_embedding=None  → always included
    # use_embedding=True  → only when use_input_embedding=True
    # use_embedding=False → only when use_input_embedding=False
    # ------------------------------------------------------------------
    COMMON: tuple[TensorSpec, ...] = (
        # inputs
        _s("input_ids", "int64", use_embedding=False),
        _s("inputs_embeds", None, use_embedding=True),
        _s("attention_mask", None),
        _s("cache_index", "int64"),
        _s("position_ids", "int64", io_type=IOType.HF),
        _s("position_ids_cos", "float32", io_type=IOType.GENIE),
        _s("position_ids_sin", "float32", io_type=IOType.GENIE),
        _s("past_key_values", "float32", repeated=True),
        # outputs
        _s("logits", None, io="output"),
        _s("past_key_values", "float32", repeated=True, io="output"),
    )

    # ------------------------------------------------------------------
    # Feature-specific tensors
    # ------------------------------------------------------------------
    EAGLET: tuple[TensorSpec, ...] = (
        _s("hidden_states", "float32"),
        _s("last_hidden_states", "float32", io="output"),
    )

    EAGLET_V2: tuple[TensorSpec, ...] = (
        _s("hidden_states", "float32"),
        _s("target_hidden_states", "float32"),
        _s("last_hidden_states", "float32", io="output"),
    )

    SLIDING_WINDOW_ATTENTION: tuple[TensorSpec, ...] = (
        _s("swa_attention_mask", None),  # dtype follows default_dtype
        _s("swa_position_ids", "float32"),
        _s("swa_cache_index", "int64"),
    )

    LONG_CONTEXT: tuple[TensorSpec, ...] = (
        _s("valid_token_mask", "float32"),
        _s("anchor_buffer", "float32"),
    )

    DEEPSTACK: tuple[TensorSpec, ...] = (_s("deepstack_visual_embeds", "float32"),)

    KV_SHARING: tuple[TensorSpec, ...] = (_s("conv_cache_position", "int64"),)

    # ------------------------------------------------------------------
    # Lookup methods
    # ------------------------------------------------------------------
    _MAP: dict  # populated after Feature is defined

    @classmethod
    def get_spec_by_name(cls, name: str, io: Optional[Literal["input", "output"]] = None) -> TensorSpec:
        """Return the spec for a tensor by name, searching COMMON then all features.

        Args:
            name: Tensor name to look up.
            io: Whether to match an ``"input"`` or ``"output"`` spec.  Useful
                for tensors like ``past_key_values`` that appear in both
                directions.  When ``None`` (the default), the first matching
                spec in either direction is returned.
        """
        for spec in cls.COMMON:
            if spec.name == name and (io is None or spec.io == io):
                return spec
        for feature_specs in cls._MAP.values():
            for spec in feature_specs:
                if spec.name == name and (io is None or spec.io == io):
                    return spec
        raise KeyError(f"Tensor spec not found for name={name!r}, io={io!r}")

    @classmethod
    def get_spec_by_feature(cls, feature: Feature) -> tuple[TensorSpec, ...]:
        """Return the spec tuple for *feature*.

        Example::

            IOSpecs.get_spec_by_feature(Feature.EAGLET)
        """
        return cls._MAP[feature]


IOSpecs._MAP = {
    Feature.EAGLET: IOSpecs.EAGLET,
    Feature.EAGLET_V2: IOSpecs.EAGLET_V2,
    Feature.SLIDING_WINDOW_ATTENTION: IOSpecs.SLIDING_WINDOW_ATTENTION,
    Feature.LONG_CONTEXT: IOSpecs.LONG_CONTEXT,
    Feature.DEEPSTACK: IOSpecs.DEEPSTACK,
    Feature.KV_SHARING: IOSpecs.KV_SHARING,
}


@dataclass
class LlmIOConfig:
    """Configuration for :class:`LlmIO`.

    Attributes:
        num_hidden_layers: Number of hidden (decoder) layers in the model.
            Controls how many per-layer KV cache entries are generated.
        io_type: Default IO naming convention applied to both inputs and
            outputs. ``IOType.HF`` uses tupled names (e.g.
            ``past_key_values``), ``IOType.GENIE`` uses flattened per-layer
            names (e.g. ``past_key_0_in``).
        input_io_type: Overrides *io_type* for input tensors only. Useful
            for mixed configurations such as Qwen3 where inputs and outputs
            use different naming conventions. When ``None``, falls back to
            *io_type*.
        output_io_type: Overrides *io_type* for output tensors only. When
            ``None``, falls back to *io_type*.
        use_position_embedding_input: When ``True`` and the IO type is
            GENIE, position IDs are split into ``position_ids_cos`` and
            ``position_ids_sin``. When ``False``, a single
            ``position_ids`` tensor is used regardless of IO type.
        use_input_embedding: When ``True``, the first input tensor is
            ``inputs_embeds`` instead of ``input_ids``.
        attention_indices: Indices of layers that are attention layers.
            Controls per-layer KV cache expansion in
            ``get_input_tensor_configs`` — attention layers get two entries
            (key + value) while non-attention layers get one. Defaults to
            all layers (``range(num_hidden_layers)``). Use this for models
            with heterogeneous layer types (e.g., Gemma3n with KV-sharing
            layers) where not all layers compute their own KV cache.
        num_deepstack_layers: Number of deepstack layers. Required when
            ``deepstack_visual_embeds`` is added via ``add_input``.
        separate_position_ids: When ``True``, ``position_ids`` and
            ``swa_position_ids`` are expanded into ``[0]`` and ``[1]``
            sub-tensors during ``get_input_tensor_configs`` generation.
        default_dtype: Fallback datatype (e.g. ``"float32"``) assigned to
            tensors that do not have a well-known type (like
            ``attention_mask``). When ``None``, the QAIRT converter infers
            the datatype automatically from the model.
        features: Sequence of :class:`Feature` flags that determine which
            additional tensors are automatically added. Each feature adds
            specific inputs/outputs:

            - ``Feature.EAGLET``: Adds ``hidden_states`` (float32) input and
              ``last_hidden_states`` (float32) output, plus ``cache_index``
              (int64) input.
            - ``Feature.EAGLET_V2``: Superset of EAGLET; adds all EAGLET
              tensors plus ``target_hidden_states`` (float32) input.
            - ``Feature.SLIDING_WINDOW_ATTENTION``: Adds ``swa_attention_mask``
              (default_dtype) input, ``swa_position_ids`` (float32) input,
              and ``swa_cache_index`` (int64) input.
            - ``Feature.LONG_CONTEXT``: Adds ``valid_token_mask`` (float32)
              and ``anchor_buffer`` (float32) inputs.
            - ``Feature.DEEPSTACK``: Adds ``deepstack_visual_embeds`` (float32)
              input. Requires ``num_deepstack_layers`` to be set.
            - ``Feature.KV_SHARING``: Adds ``conv_cache_position`` (int64) input.
    """

    num_hidden_layers: int
    io_type: IOType = IOType.HF
    input_io_type: Optional[IOType] = None
    output_io_type: Optional[IOType] = None
    use_position_embedding_input: bool = True
    use_input_embedding: bool = False
    attention_indices: Optional[Sequence[int]] = None
    num_deepstack_layers: Optional[int] = None
    separate_position_ids: bool = True
    default_dtype: Optional[str] = None
    features: Sequence[Feature] = ()


class LlmIO:
    """Owns the full tensor specification (name + layout + datatype) for an LLM.

    Provides methods for name generation, spec lookup, and InputTensorConfig
    creation, replacing the fragmented logic previously split across
    ``utils.py`` and ``model_preparation_utils.py``.
    """

    def __init__(self, num_hidden_layers: int, **kwargs):
        """Initialize the LLM IO specification.

        All keyword arguments are forwarded to :class:`LlmIOConfig`; see
        :class:`LlmIOConfig` for the full parameter reference.
        """
        self._init_from_config(LlmIOConfig(num_hidden_layers=num_hidden_layers, **kwargs))

    @classmethod
    def from_config(cls, config: LlmIOConfig) -> "LlmIO":
        """Create an :class:`LlmIO` instance from an :class:`LlmIOConfig`."""
        instance = cls.__new__(cls)
        instance._init_from_config(config)
        return instance

    def _init_from_config(self, config: LlmIOConfig) -> None:
        """Shared initialisation logic used by ``__init__`` and ``from_config``."""
        if config.num_hidden_layers < 0:
            raise ValueError(f"num_hidden_layers must be non-negative, got {config.num_hidden_layers}")
        self._num_hidden_layers = config.num_hidden_layers
        self._input_io_type = config.input_io_type if config.input_io_type is not None else config.io_type
        self._output_io_type = config.output_io_type if config.output_io_type is not None else config.io_type
        self._use_position_embedding_input = config.use_position_embedding_input
        self._use_input_embedding = config.use_input_embedding
        self._attention_indices: frozenset[int] = frozenset(
            config.attention_indices
            if config.attention_indices is not None
            else range(config.num_hidden_layers)
        )
        self._num_deepstack_layers = config.num_deepstack_layers
        self._separate_position_ids = config.separate_position_ids
        self._default_dtype = config.default_dtype

        self._input_specs: list[TensorSpec] = []
        self._output_specs: list[TensorSpec] = []
        self._build_standard_specs()
        self._build_feature_specs(config.features)

    # ------------------------------------------------------------------
    # Public API – names
    # ------------------------------------------------------------------

    def get_input_names(self) -> list[str]:
        """Return the ordered list of input tensor names."""
        return [s.name for s in self._input_specs]

    def get_output_names(self) -> list[str]:
        """Return the ordered list of output tensor names."""
        return [s.name for s in self._output_specs]

    # ------------------------------------------------------------------
    # Public API – specs
    # ------------------------------------------------------------------

    @overload
    def get_input_specs(self) -> list[TensorSpec]: ...

    @overload
    def get_input_specs(self, input_name: None) -> list[TensorSpec]: ...

    @overload
    def get_input_specs(self, input_name: str) -> TensorSpec: ...

    def get_input_specs(self, input_name: Optional[str] = None) -> list[TensorSpec] | TensorSpec:
        """Return all input specs, or a single spec by *input_name*."""
        if input_name is not None:
            return self._lookup(self._input_specs, input_name)
        return list(self._input_specs)

    @overload
    def get_output_specs(self) -> list[TensorSpec]: ...

    @overload
    def get_output_specs(self, output_name: None) -> list[TensorSpec]: ...

    @overload
    def get_output_specs(self, output_name: str) -> TensorSpec: ...

    def get_output_specs(self, output_name: Optional[str] = None) -> list[TensorSpec] | TensorSpec:
        """Return all output specs, or a single spec by *output_name*."""
        if output_name is not None:
            return self._lookup(self._output_specs, output_name)
        return list(self._output_specs)

    # ------------------------------------------------------------------
    # Public API – fluent mutators
    # ------------------------------------------------------------------

    def add_io(self, spec: TensorSpec) -> "LlmIO":
        """Append a tensor spec, routing to inputs or outputs via ``spec.io``.

        When ``spec.datatype`` is ``None``, falls back to ``default_dtype``.
        Returns *self* for fluent chaining.
        """
        if spec.datatype is None and self._default_dtype is not None:
            spec = spec._replace(datatype=self._default_dtype)
        if spec.io == "output":
            self._output_specs.append(spec)
        else:
            self._input_specs.append(spec)
        return self

    # ------------------------------------------------------------------
    # Public API – InputTensorConfig generation (QAIRT MPP)
    # ------------------------------------------------------------------

    def get_input_tensor_configs(self) -> dict[str, list["InputTensorConfig"]]:
        """Build the ``{"input_tensors": [...]}`` dict for the QAIRT converter."""
        from qti.aisw.tools.core.modules.converter.converter_module import (
            InputTensorConfig,
        )

        configs: list[InputTensorConfig] = []
        for spec in self._input_specs:
            configs.extend(self._expand_spec(spec, InputTensorConfig))
        return {"input_tensors": configs}

    def get_output_tensor_configs(self) -> dict[str, list["OutputTensorConfig"]]:
        """Build the ``{"output_tensors": [...]}`` dict for the QAIRT converter."""
        from qti.aisw.tools.core.modules.converter.converter_module import (
            OutputTensorConfig,
        )

        configs: list[OutputTensorConfig] = []
        for spec in self._output_specs:
            configs.extend(self._expand_output_spec(spec, OutputTensorConfig))
        return {"output_tensors": configs}

    # ------------------------------------------------------------------
    # Internal – build standard specs
    # ------------------------------------------------------------------

    def _build_standard_specs(self) -> None:
        """Populate ``_input_specs`` and ``_output_specs`` from ``IOSpecs.COMMON``.

        Iterates the full COMMON registry and filters each spec against the
        active configuration via :meth:`_filter_common`.  GENIE-style per-layer
        KV names are appended afterwards since they are dynamic (layer count).
        """
        for spec in IOSpecs.COMMON:
            if not self._filter_common(spec):
                continue
            # GENIE KV inputs/outputs are handled separately below.
            if spec.name == "past_key_values" and (
                (spec.io == "input" and self._input_io_type is IOType.GENIE)
                or (spec.io == "output" and self._output_io_type is IOType.GENIE)
            ):
                continue
            self.add_io(spec)

        # GENIE per-layer KV names (dynamic — depend on num_hidden_layers)
        if self._input_io_type is IOType.GENIE:
            for spec in self._genie_kv_specs(suffix="in", io="input"):
                self.add_io(spec)
        if self._output_io_type is IOType.GENIE:
            for spec in self._genie_kv_specs(suffix="out", io="output"):
                self.add_io(spec)

    def _filter_common(self, spec: TensorSpec) -> bool:
        """Return True if *spec* should be included given the active config."""
        # Embedding filter
        if spec.use_embedding is not None:
            if spec.use_embedding != self._use_input_embedding:
                return False

        # io_type filter — determine the effective io_type for this spec's side
        if spec.io_type is not None:
            effective_io_type = self._input_io_type if spec.io == "input" else self._output_io_type
            # position_ids (io_type=HF) is also included when
            # use_position_embedding_input=False regardless of io_type.
            if spec.name == "position_ids" and not self._use_position_embedding_input:
                return True
            # position_ids_cos/sin (io_type=GENIE) are only included when
            # use_position_embedding_input=True.
            if (
                spec.name in {"position_ids_cos", "position_ids_sin"}
                and not self._use_position_embedding_input
            ):
                return False
            if spec.io_type != effective_io_type:
                return False

        return True

    def _build_feature_specs(self, features: Sequence[Feature]) -> None:
        """Add feature-specific tensors driven by :class:`IOSpecs`.

        Raises ValueError if deepstack is requested without num_deepstack_layers.
        """
        if Feature.DEEPSTACK in features and self._num_deepstack_layers is None:
            raise ValueError("num_deepstack_layers must be provided when Feature.DEEPSTACK is used")

        # EAGLET_V2 is a superset of EAGLET; skip EAGLET when V2 is listed.
        for feature in features:
            if feature == Feature.EAGLET and Feature.EAGLET_V2 in features:
                continue
            for spec in IOSpecs.get_spec_by_feature(feature):
                self.add_io(spec)

    def _genie_kv_specs(self, suffix: str, io: Literal["input", "output"]) -> list[TensorSpec]:
        specs: list[TensorSpec] = []
        for i in range(self._num_hidden_layers):
            specs.append(_s(f"past_key_{i}_{suffix}", "float32", io=io))
            if i in self._attention_indices:
                specs.append(_s(f"past_value_{i}_{suffix}", "float32", io=io))
        return specs

    # ------------------------------------------------------------------
    # Internal – per-layer expansion for InputTensorConfig
    # ------------------------------------------------------------------

    def _expand_spec(self, spec: TensorSpec, config_cls: type) -> list:
        """Expand a single TensorSpec into one or more InputTensorConfig objects.

        HF-style names like ``past_key_values`` and ``position_ids`` are
        expanded into per-layer / per-component entries.  GENIE-style names
        (already per-layer) pass through without expansion.
        """
        name, layout, dtype = spec.name, spec.layout, spec.datatype

        # past_key_values -> per-layer expansion
        if name == "past_key_values":
            configs = []
            for i in range(self._num_hidden_layers):
                rangelen = 2 if i in self._attention_indices else 1
                for j in range(rangelen):
                    configs.append(
                        config_cls(
                            name=f"past_key_values[{i}][{j}]",
                            source_model_input_layout=layout,
                            source_model_input_datatype=dtype,
                        )
                    )
            return configs

        # position_ids / swa_position_ids -> [0], [1] when separate
        if name in {"position_ids", "swa_position_ids"} and self._separate_position_ids:
            return [
                config_cls(
                    name=f"{name}[{i}]",
                    source_model_input_layout=layout,
                    source_model_input_datatype=dtype,
                )
                for i in range(2)
            ]

        # anchor_buffer -> per-layer [i]
        if name == "anchor_buffer":
            return [
                config_cls(
                    name=f"{name}[{i}]",
                    source_model_input_layout=layout,
                    source_model_input_datatype=dtype,
                )
                for i in range(self._num_hidden_layers)
            ]

        # deepstack_visual_embeds -> per deepstack layer [i]
        if name == "deepstack_visual_embeds":
            if self._num_deepstack_layers is None:
                raise ValueError("num_deepstack_layers must be set when 'deepstack_visual_embeds' is used.")
            return [
                config_cls(
                    name=f"deepstack_visual_embeds[{i}]",
                    source_model_input_layout=layout,
                    source_model_input_datatype=dtype,
                )
                for i in range(self._num_deepstack_layers)
            ]

        # Everything else: single entry, no expansion
        return [
            config_cls(
                name=name,
                source_model_input_layout=layout,
                source_model_input_datatype=dtype,
            )
        ]

    def _expand_output_spec(self, spec: TensorSpec, config_cls: type) -> list:
        """Expand a single output TensorSpec into one or more OutputTensorConfig objects.

        Mirrors :meth:`_expand_spec` but uses ``OutputTensorConfig`` field names
        (``source_model_output_layout``, ``desired_model_output_datatype``) instead
        of the input equivalents.
        """
        name, layout, dtype = spec.name, spec.layout, spec.datatype

        # past_key_values output -> per-layer expansion
        if name == "past_key_values":
            configs = []
            for i in range(self._num_hidden_layers):
                rangelen = 2 if i in self._attention_indices else 1
                for j in range(rangelen):
                    configs.append(
                        config_cls(
                            name=f"past_key_values[{i}][{j}]",
                            source_model_output_layout=layout,
                            desired_model_output_datatype=dtype,
                        )
                    )
            return configs

        # GENIE per-layer outputs pass through without expansion (already named)
        return [
            config_cls(
                name=name,
                source_model_output_layout=layout,
                desired_model_output_datatype=dtype,
            )
        ]

    # ------------------------------------------------------------------
    # Internal – helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _lookup(specs: list[TensorSpec], name: str) -> TensorSpec:
        for s in specs:
            if s.name == name:
                return s
        raise KeyError(f"No tensor named {name!r}")
