# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
Pipeline Manifest

Tracks which stages have completed and where their artifacts live.

Manifest structure on disk (``{cache_dir}/.pipeline_state/manifest.json``)::

    {
        "stages": {
            "<stage_name>": {
                "artifact_path": "<path>",
                "timestamp":     "<iso8601>",
                "config":        "<json string>",   # optional, exclude-unset fields only
            }
        }
    }
"""

from __future__ import annotations

import dataclasses
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Union

from qairt.experimental.pipeline.torch.common.bases.stage import StageConfig
from qairt.utils.loggers import get_logger

_logger = get_logger("PipelineManifest")

_MANIFEST_FILE = "manifest.json"


def _serialize_model_unset(model: Any, label: str) -> bytes:
    """Serialize only explicitly-set fields to JSON bytes for manifest storage."""
    try:
        if hasattr(model, "model_dump"):
            data = model.model_dump(mode="json", exclude_unset=True)
        elif dataclasses.is_dataclass(model) and not isinstance(model, type):
            _logger.debug(f"{label} is a dataclass; serializing all fields (exclude_unset not supported)")
            data = dataclasses.asdict(model)
        else:
            data = dict(model)

        def _default(obj: Any) -> Any:
            if isinstance(obj, Path):
                return str(obj)
            type_name = type(obj).__module__ + "." + type(obj).__qualname__
            if type_name.startswith("torch."):
                return str(obj)
            return f"<{type_name}:{str(obj)}>"

        return json.dumps(data, sort_keys=True, default=_default).encode()
    except Exception as e:
        raise TypeError(
            f"{label} contains fields that cannot be stably serialized for manifest "
            f"storage. Use only JSON-serializable types in "
            f"StageConfig to ensure reliable caching. Error type: {type(e).__name__}"
        ) from e


class PipelineManifest:
    """
    Reads and writes the pipeline-level manifest file.

    The manifest records each completed stage's artifact path, timestamp, and
    config snapshot.
    """

    def __init__(self, cache_dir: Union[str, Path]) -> None:
        self._cache_dir = Path(cache_dir) / ".pipeline_state"

    @property
    def path(self) -> Path:
        """Absolute path to ``manifest.json``."""
        return self._cache_dir / _MANIFEST_FILE

    def read(self) -> dict[str, Any]:
        """
        Return the manifest as a dict, or an empty structure if absent.

        Manifest structure::

            {
                "stages": {
                    "<stage_name>": {
                        "artifact_path": "<path>",
                        "timestamp": "<iso8601>",
                        "config": "<json string>",   # optional
                    }
                }
            }
        """
        if not self.path.exists():
            return {"stages": {}}
        try:
            with open(self.path) as f:
                return json.load(f)
        except Exception as e:
            _logger.error(f"Could not read manifest at '{self.path}': {e}")
            raise

    def remove(self, *stage_names: str) -> None:
        """
        Remove one or more stage entries from the manifest.

        Stages not present in the manifest are silently ignored.

        Args:
            *stage_names: Names of the stages to remove.
        """
        try:
            manifest = self.read()
            for stage_name in stage_names:
                manifest["stages"].pop(stage_name, None)
            with open(self.path, "w") as f:
                json.dump(manifest, f, indent=2)
            _logger.info(f"Manifest entries removed: {list(stage_names)}")
        except Exception as e:
            _logger.error(f"Failed to remove manifest entries {list(stage_names)}: {e}")
            raise

    def update(
        self,
        stage_name: str,
        artifact_path: Optional[Path],
        stage_config: Optional[StageConfig] = None,
    ) -> None:
        """
        Add or update the manifest entry for a single stage.

        Args:
            stage_name:    Name of the stage.
            artifact_path: Directory where artifacts were written, or ``None`` if no
                           artifacts were persisted (caching disabled, no checkpoint).
            stage_config:  Optional; only explicitly-set fields are serialised.
        """
        try:
            self._cache_dir.mkdir(parents=True, exist_ok=True)
            manifest = self.read()

            entry: dict[str, Any] = {
                "artifact_path": str(artifact_path) if artifact_path is not None else None,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            if stage_config is not None:
                entry["config"] = _serialize_model_unset(stage_config, "StageConfig").decode()

            manifest["stages"][stage_name] = entry

            with open(self.path, "w") as f:
                json.dump(manifest, f, indent=2)
            _logger.info(f"Manifest updated for stage '{stage_name}'")
        except Exception as e:
            _logger.error(f"Failed to update manifest for stage '{stage_name}': {e}")
            raise
