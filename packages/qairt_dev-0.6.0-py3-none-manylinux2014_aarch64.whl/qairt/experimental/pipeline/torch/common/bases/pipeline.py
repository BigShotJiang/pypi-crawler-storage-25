# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
Pipeline Base Class

Domain-specific pipelines (LLMPipeline, LVMPipeline, LMMPipeline, …) subclass
this and add only their own config type, factory helpers, and user-facing API
(e.g. generate()).
"""

from __future__ import annotations

import importlib
import json
import shutil
from abc import ABC, abstractmethod
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Generic, Optional, Type, TypeVar, Union

from pydantic import BaseModel, Field

from qairt.experimental.pipeline.torch.common.bases.runners import (
    RunResult,
    _CachingRunner,
    _CheckpointRunner,
    _DirectRunner,
    _ObservingRunner,
    _RunnerInterface,
)
from qairt.experimental.pipeline.torch.common.bases.stage import (
    Stage,
    StageConfig,
    StageDependencies,
    StageInput,
    StageOutput,
)
from qairt.experimental.pipeline.torch.common.bases.stage_observer import StageObserver
from qairt.experimental.pipeline.torch.common.bases.stage_registry import _DEFAULT_STAGE_REGISTRY
from qairt.experimental.pipeline.torch.common.cache import StageCache
from qairt.experimental.pipeline.torch.common.manifest import PipelineManifest
from qairt.experimental.pipeline.torch.common.utils import ConfigAccessor
from qairt.utils.loggers import get_logger


class PipelineConfig(BaseModel):
    """
    Base configuration shared by all pipeline types.
    """

    model_config = {"arbitrary_types_allowed": True, "protected_namespaces": ()}

    model_id_or_path: str = ""
    cache_dir: str = "./workspace"
    enable_cache: bool = False
    checkpoint: Optional[str] = None
    enable_observers: bool = False
    observers: dict[str, Any] = Field(default_factory=dict)
    stage_info: OrderedDict[str, dict[str, Any]] = Field(default_factory=OrderedDict)


@dataclass
class FieldBinding:
    """
    Declares a rename/alias mapping from an upstream output field to a downstream
    stage's input field.

    Used in a recipe's ``io_bindings`` entry when the immediate predecessor's
    output field name differs from this stage's input field name. When names
    match, no ``FieldBinding`` is needed — the pipeline wires them automatically.

    Attributes:
        target_field: Field name in the downstream stage's ``Input`` to populate.
        source_field: Field name in the immediate predecessor's ``Output`` to
                      read from. Differs from ``target_field`` only for renames.
    """

    target_field: str
    source_field: str


PipelineConfigT = TypeVar("PipelineConfigT", bound="PipelineConfig")
PipelineT = TypeVar("PipelineT", bound="Pipeline")


class Pipeline(ABC, Generic[PipelineConfigT]):
    """
    Generic pipeline base class.

    Handles all orchestration concerns that are common across model types
    (LLM, LVM, LMM, …):

    - Stage class resolution via the stage registry and optional dynamic import
    - Stage config initialization from ``_stage_info``
    - Stage instantiation
    - I/O binding resolution: name-matching between consecutive stages is the
      primary contract; recipe-level ``io_bindings`` serve as the complete
      wiring specification when rename/alias overrides are needed
    - Stage order validation
    - Execution loop with before/after observer hooks
    - Export dispatch
    """

    # Class-level logger. Subclasses override this to show their own name
    _logger = get_logger("Pipeline")

    def __init__(self, config: PipelineConfigT) -> None:
        self._config = config
        self._observers: list[StageObserver] = []
        self._stage_outputs: OrderedDict[str, StageOutput] = OrderedDict()
        self._stage_inputs: OrderedDict[str, StageInput] = OrderedDict()
        self._stage_configs: OrderedDict[str, StageConfig] = OrderedDict()
        self._stage_classes: OrderedDict[str, Type[Stage]] = OrderedDict()
        self._stage_instances: OrderedDict[str, Stage] = OrderedDict()
        self._cache: Optional[StageCache] = None
        self._recipe_path: Optional[Path] = None
        self._observer_active_stages: Optional[set[str]] = None
        self._manifest_restored_stages: set[str] = set()

        self._initialize_stage_configs()
        self._initialize_stages()
        self._validate_checkpoint()
        self._initialize_cache()
        self._initialize_observers()
        self._manifest: PipelineManifest = self._initialize_manifest()
        self._runner: _RunnerInterface = self._build_runner()

    @property
    def _pipeline_state_dir(self) -> Path:
        """Return the pipeline state directory: ``{cache_dir}/.pipeline_state``."""
        return Path(getattr(self.config, "cache_dir", "./workspace")) / ".pipeline_state"

    @classmethod
    def from_pretrained(
        cls: Type[PipelineT],
        model_id_or_path: str,
        recipe: Optional[Union[str, Path, dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> PipelineT:
        """
        Create a pipeline from a pretrained model identifier or local path.

        Args:
            model_id_or_path: HuggingFace model ID or local path to the model.
            recipe: Optional recipe configuration. Accepts:
                    - A file path (``str`` or ``Path``) to a YAML recipe.
                    - A ``dict`` with recipe fields.
            **kwargs: Additional config fields. When a recipe is provided, these
                      override matching fields in the loaded recipe config.

        Returns:
            A fully initialized instance of the calling pipeline subclass.
        """
        cls._logger.info(f"Creating {cls.__name__} for '{model_id_or_path}'")

        if recipe is not None:
            if isinstance(recipe, (str, Path)):
                cls._logger.info(f"Loading recipe from: {recipe}")
                config = cls._config_from_recipe(recipe)
                # Allow caller to override model_id_or_path from the recipe
                recipe_model = getattr(config, "model_id_or_path", None)
                if recipe_model and recipe_model != model_id_or_path:
                    cls._logger.info(
                        f"Overriding recipe model_id_or_path '{recipe_model}' with '{model_id_or_path}'"
                    )
                    config.model_id_or_path = model_id_or_path  # type: ignore[attr-defined]
            elif isinstance(recipe, dict):
                recipe_dict = dict(recipe)
                # Allow caller to override model_id_or_path from the recipe
                recipe_model = recipe_dict.get("model_id_or_path")
                if recipe_model and recipe_model != model_id_or_path:
                    cls._logger.info(
                        f"Overriding recipe model_id_or_path '{recipe_model}' with '{model_id_or_path}'"
                    )
                recipe_dict["model_id_or_path"] = model_id_or_path
                config = cls._config_from_kwargs(**recipe_dict)
            else:
                raise TypeError(f"recipe must be a file path or a dict, got {type(recipe).__name__!r}")

            # Apply any additional kwargs as overrides
            for key, value in kwargs.items():
                if hasattr(config, key):
                    setattr(config, key, value)
        else:
            config = cls._config_from_kwargs(model_id_or_path=model_id_or_path, **kwargs)

        pipeline = cls(config=config)
        if isinstance(recipe, (str, Path)):
            pipeline._recipe_path = Path(recipe)
        elif isinstance(recipe, dict):
            # Serialize the dict recipe to a file so construct() can cache it for load() resume
            from qairt.experimental.pipeline.torch.common.recipe import Recipe

            recipe_file = pipeline._pipeline_state_dir / "recipe.yaml"
            recipe_file.parent.mkdir(parents=True, exist_ok=True)
            Recipe(recipe_dict).to_yaml(recipe_file)
            pipeline._recipe_path = recipe_file
            cls._logger.info(f"Dict recipe serialized to '{recipe_file}'")
        return pipeline

    @property
    @abstractmethod
    def config(self) -> PipelineConfigT:
        """Return the domain-specific pipeline configuration."""
        ...

    @property
    @abstractmethod
    def _stage_info(self) -> OrderedDict[str, dict[str, Any]]:
        """
        Return the ordered ``{stage_name: stage_dict}`` mapping that drives
        stage construction. Typically ``self.config.stage_info``.
        """
        ...

    @classmethod
    @abstractmethod
    def _config_from_recipe(cls, recipe_path: Union[str, Path]) -> PipelineConfigT:
        """
        Construct a domain-specific config from a recipe file.

        Called by ``from_pretrained`` when a recipe path is provided.
        """
        ...

    @classmethod
    @abstractmethod
    def _config_from_kwargs(cls, model_id_or_path: str, **kwargs: Any) -> PipelineConfigT:
        """
        Construct a domain-specific config from keyword arguments.

        Called by ``from_pretrained`` when no recipe is provided.
        """
        ...

    @classmethod
    def load(
        cls: Type[PipelineT],
        cache_dir: Union[str, Path],
    ) -> PipelineT:
        """
        Resume a pipeline from a previous run by restoring completed stages from the manifest.

        Supports all cases where artifacts were written to disk:
        - Caching enabled (with or without checkpoint)
        - Caching disabled with checkpoint set

        Args:
            cache_dir: Directory from the original run; must contain ``.pipeline_cache/manifest.json``
                       and ``.pipeline_cache/recipe.yaml``.

        Returns:
            Pipeline ready to resume. Call ``construct()`` to continue from where it left off.

        Raises:
            FileNotFoundError: If the manifest or cached recipe does not exist.
            ValueError: If the manifest is empty, the recipe has no model identifier, or
                        the original run had neither caching nor a checkpoint (no artifacts on disk).
        """
        cache_dir = Path(cache_dir)
        manifest = PipelineManifest(cache_dir)
        if not manifest.path.exists():
            raise FileNotFoundError(
                f"No manifest found at '{manifest.path}'. "
                f"Ensure the pipeline was run with enable_cache=True or a checkpoint set "
                f"before calling load()."
            )

        manifest_data = manifest.read()
        completed_stages: dict[str, Any] = manifest_data.get("stages", {})
        if not completed_stages:
            raise ValueError(f"Manifest at '{manifest.path}' contains no completed stages.")

        # Verify at least one stage has artifacts — if none do, resume is not possible.
        has_artifacts = any(entry.get("artifact_path") for entry in completed_stages.values())
        if not has_artifacts:
            stages_without_artifacts = [
                name for name, entry in completed_stages.items() if not entry.get("artifact_path")
            ]
            raise ValueError(
                f"No stage artifacts found in the manifest. "
                f"load() requires either enable_cache=True or a checkpoint to have been set "
                f"in the original run so that artifacts are available for resume.\n"
                f"Stages in manifest without artifacts: {stages_without_artifacts}\n"
                f"Total stages in manifest: {len(completed_stages)}"
            )

        cls._logger.info(f"Loading pipeline from manifest. Completed stages: {list(completed_stages.keys())}")

        cached_recipe_path = manifest.path.parent / "recipe.yaml"
        if not cached_recipe_path.exists():
            raise FileNotFoundError(
                f"No recipe found in cache at '{cached_recipe_path}'. "
                f"Re-run the original pipeline with enable_cache=True or a checkpoint set "
                f"so the recipe is saved automatically."
            )
        cls._logger.info(f"Using cached recipe from '{cached_recipe_path}'")

        from qairt.experimental.pipeline.torch.common.recipe import Recipe

        data = Recipe.from_file(cached_recipe_path)
        model_id = data.get("model_id_or_path")

        if not model_id or (isinstance(model_id, str) and not model_id.strip()):
            raise ValueError(
                "The cached recipe does not contain a model_id_or_path. "
                "Cannot resume pipeline without a model identifier."
            )

        pipeline = cls.from_pretrained(
            model_id,
            recipe=cached_recipe_path,
            checkpoint=None,
            cache_dir=str(cache_dir),
        )

        cls._logger.info("Pipeline loaded and ready to resume. Call construct() to continue.")
        return pipeline

    @property
    def manifest(self) -> dict[str, Any]:
        """Return the pipeline manifest."""
        return self._manifest.read()

    @property
    def stages(self) -> ConfigAccessor:
        """Provide access to stage configs for runtime modification before construct."""
        return ConfigAccessor(self._stage_configs)

    @property
    def stage_outputs(self) -> ConfigAccessor:
        """Provide read access to stage outputs after construct."""
        return ConfigAccessor(self._stage_outputs)

    @property
    def stage_inputs(self) -> ConfigAccessor:
        """Provide read access to stage inputs after construct."""
        return ConfigAccessor(self._stage_inputs)

    def add_observer(self, observer: StageObserver) -> None:
        """
        Attach an observer to monitor stage execution.
        Multiple observers can be attached. They are called in registration order.

        Args:
            observer: A ``StageObserver`` instance to attach.

        Raises:
            ValueError: If the observer is already registered.
        """
        if observer in self._observers:
            raise ValueError(f"'{type(observer).__name__}' is already registered in observers.")
        self._observers.append(observer)

    def get_observer_reports(self) -> dict[str, Any]:
        """
        Retrieve the observer report from all observers that implement ``get_observer_report()``.

        Returns:
            Dict mapping observer class name to its report object.
            Observers without ``get_observer_report()`` are silently skipped.
        """
        reports: dict[str, Any] = {}
        for observer in self._observers:
            if hasattr(observer, "get_observer_report"):
                reports[type(observer).__name__] = observer.get_observer_report()
        return reports

    def construct(self) -> Pipeline:
        """
        Execute all pipeline stages in order, skipping any already completed or pre-executed.

        Raises:
            AttributeError: If no stage instances have been initialised.
        """
        if not self._stage_instances:
            raise AttributeError("No stage instances found. Stages must be initialised before construct().")

        # Save recipe so load() can resume from any run that writes artifacts.
        cached_recipe_path = self._manifest.path.parent / "recipe.yaml"
        if not cached_recipe_path.exists():
            try:
                cached_recipe_path.parent.mkdir(parents=True, exist_ok=True)
                if self._recipe_path is not None:
                    shutil.copy2(self._recipe_path, cached_recipe_path)
                    self._logger.info(f"Recipe saved to '{cached_recipe_path}'")
                else:
                    from qairt.experimental.pipeline.torch.common.recipe import Recipe

                    recipe_data = self.config.model_dump(mode="json")
                    Recipe(recipe_data).to_yaml(cached_recipe_path)
                    self._logger.info(f"Recipe synthesized from config and saved to '{cached_recipe_path}'")
            except Exception as e:
                self._logger.warning(
                    f"Failed to save recipe to '{cached_recipe_path}': {e}. "
                    f"Pipeline will continue, but load() resume may not work."
                )

        stages_to_skip = self._preload_manifest_stages()

        # Skip stages whose outputs are already in memory but were not restored
        pre_executed = frozenset(
            name for name in self._stage_outputs if name not in self._manifest_restored_stages
        )
        if pre_executed:
            self._logger.info(
                f"Skipping pre-executed stages (output already in memory): {sorted(pre_executed)}"
            )
            stages_to_skip = stages_to_skip | pre_executed
            manifest_stages = self._manifest.read().get("stages", {})
            for name in sorted(pre_executed):
                if name in manifest_stages:
                    continue  # already recorded (e.g. by from_pretrained())
                try:
                    self._manifest.update(name, None, self._stage_configs.get(name))
                except Exception as e:
                    self._logger.warning(
                        f"Failed to update manifest for pre-executed stage '{name}': {e}. "
                        f"Pipeline will continue, but resume functionality may be affected."
                    )

        for stage_name, stage in self._stage_instances.items():
            if stage_name in stages_to_skip:
                continue

            stage_config = self._stage_configs[stage_name]
            stage_input = self._construct_stage_input(stage_name)
            self._stage_inputs[stage_name] = stage_input

            self._logger.info(f"Running stage: {stage_name}")
            result: RunResult = self._runner.run(stage, stage_input, stage_config)
            self._stage_outputs[stage_name] = result.output

            try:
                self._manifest.update(stage_name, result.artifact_path, stage_config)
            except Exception as e:
                self._logger.warning(
                    f"Failed to update manifest for stage '{stage_name}': {e}. "
                    f"Pipeline will continue, but resume functionality may be affected."
                )

            if result.is_terminal:
                break

        self._runner.finalize(self._pipeline_state_dir)
        return self

    def export(self, export_dir: Optional[str] = None, all_stages: bool = False) -> None:
        """
        Export pipeline artifacts to disk.

        Args:
            export_dir: Directory to write artifacts to. Defaults to the pipeline
                        config's ``cache_dir`` if not provided.
            all_stages: If ``True``, export from every stage that supports export.
                        If ``False`` (default), export only from the last stage.

        Raises:
            AttributeError: If ``construct()`` has not been called yet.
            RuntimeError: If the target stage does not support export.
        """
        if not self._stage_instances:
            raise AttributeError("No stage instances found. Ensure stages are initialised before export().")
        if not self._stage_outputs:
            raise AttributeError("No outputs to export. Call construct() before export().")

        base_path = Path(export_dir) if export_dir else self._pipeline_state_dir.parent
        base_path.mkdir(parents=True, exist_ok=True)

        if all_stages:
            for stage_name, stage in self._stage_instances.items():
                if not stage.can_export:
                    self._logger.debug(f"Stage '{stage_name}' does not support export. Skipping.")
                    continue
                stage_output = self._stage_outputs.get(stage_name)
                if stage_output is None:
                    self._logger.debug(f"No output for stage '{stage_name}'. Skipping export.")
                    continue
                try:
                    stage.export(stage_output, base_path)
                except Exception as e:
                    self._logger.error(f"Export failed for stage '{stage_name}': {e}")
                    raise
        else:
            last_stage_name = list(self._stage_instances.keys())[-1]
            last_stage = self._stage_instances[last_stage_name]
            if not last_stage.can_export:
                raise RuntimeError(f"Last stage '{last_stage_name}' does not support export.")
            last_output = self._stage_outputs.get(last_stage_name)
            if not last_output:
                raise AttributeError(f"No output found for last stage '{last_stage_name}'.")
            try:
                last_stage.export(last_output, base_path)
            except Exception as e:
                self._logger.error(f"Export failed for stage '{last_stage_name}': {e}")
                raise

    def _initialize_stage_configs(self) -> None:
        """
        Resolve stage classes from the registry and build stage configs.

        Populates ``self._stage_classes`` and ``self._stage_configs``.
        Calls ``_validate_stage_order()`` after all classes are resolved.
        """
        stage_info = self._stage_info
        assert stage_info, "No stage information found. Provide stage configurations via the pipeline config."

        for stage_name, stage_dict in stage_info.items():
            stage_class = _DEFAULT_STAGE_REGISTRY.get(stage_name)

            if stage_class is None:
                class_path = stage_dict.get("class")
                if class_path is None:
                    raise ValueError(
                        f"Stage '{stage_name}' is not registered and no 'class' field was "
                        f"provided in the recipe. Either import the stage module before "
                        f"creating the pipeline, or add a 'class' field "
                        f'(e.g. "class": "my_package.stages.MyStage") to the stage entry.'
                    )
                module_path, class_name = class_path.rsplit(".", 1)
                try:
                    module = importlib.import_module(module_path)
                    getattr(module, class_name)  # execute the class body / decorator
                except (ImportError, AttributeError) as e:
                    raise ImportError(
                        f"Failed to import stage class '{class_path}' for stage '{stage_name}': {e}"
                    ) from e

                stage_class = _DEFAULT_STAGE_REGISTRY.get(stage_name)
                if stage_class is None:
                    raise ValueError(
                        f"Stage '{stage_name}' still not found in registry after importing "
                        f"'{class_path}'. Ensure the class is decorated with "
                        f"@register_stage('{stage_name}')."
                    )

            assert stage_class.Config is not None, (
                f"Stage class {stage_class} must declare a Config attribute."
            )
            if stage_name in _DEFAULT_STAGE_REGISTRY._built_in_stages:
                assert issubclass(stage_class.Config, StageConfig)

            self._stage_classes[stage_name] = stage_class

            # Pull pipeline-level fields that the stage config also declares
            pipeline_args: dict[str, Any] = {}
            for field_name in self.config.model_fields:  # type: ignore[union-attr,attr-defined]
                if field_name in stage_class.Config.model_fields:
                    pipeline_args[field_name] = getattr(self.config, field_name)

            # Strip pipeline directives - not stage config fields
            config_dict = {
                k: v for k, v in stage_dict.items() if k not in ("class", "io_bindings", "enable_observers")
            }
            stage_config = stage_class.Config(**pipeline_args, **config_dict)
            object.__setattr__(stage_config, "_pipeline_config", self.config)
            self._stage_configs[stage_name] = stage_config

        self._validate_stage_order()

    def _initialize_stages(self) -> None:
        """
        Instantiate stage classes using configs resolved by ``_initialize_stage_configs``.
        """
        if not self._stage_configs:
            raise AttributeError("No stage configs found. Run _initialize_stage_configs() first.")
        for stage_name in self._stage_configs:
            stage_class = self._stage_classes[stage_name]
            self._stage_instances[stage_name] = stage_class()
            self._logger.debug(f"Initialized stage: '{stage_name}' ({stage_class.__name__})")
        self._logger.info(f"Initialized {len(self._stage_instances)} stage(s)")

    def _initialize_cache(self) -> None:
        """
        Initialize ``StageCache`` if ``enable_cache`` is ``True`` on the pipeline config.

        Called after ``_initialize_stages()`` so that stage names are already available.
        """
        enable_cache = self.config.enable_cache
        if not enable_cache:
            return

        cache_dir = self._pipeline_state_dir.parent
        self._cache = StageCache(cache_dir=cache_dir)
        self._logger.info(f"Stage cache enabled at '{self._pipeline_state_dir}'")

    def _initialize_manifest(self) -> PipelineManifest:
        """
        Create the ``PipelineManifest`` for this pipeline run.

        Always created, regardless of whether caching is enabled.
        """
        return PipelineManifest(self._pipeline_state_dir.parent)

    def _validate_checkpoint(self) -> None:
        """
        Validate the ``checkpoint`` stage name (if set) against the initialized stage instances.

        Called unconditionally after ``_initialize_stages()`` so that an invalid checkpoint
        is caught at construction time regardless of whether caching is enabled.

        Raises:
            ValueError: If ``checkpoint`` names a stage not present in the pipeline, or if
                        caching is disabled and the checkpoint stage does not support export.
        """
        checkpoint = self.config.checkpoint
        if checkpoint is None:
            return
        if checkpoint not in self._stage_instances:
            raise ValueError(
                f"Checkpoint stage '{checkpoint}' is not in the pipeline. "
                f"Available stages: {list(self._stage_instances.keys())}"
            )
        if not self.config.enable_cache:
            stage = self._stage_instances[checkpoint]
            if not stage.can_export:
                raise ValueError(
                    f"Checkpoint stage '{checkpoint}' does not support export. "
                    f"When caching is disabled, checkpoint stages must have can_export=True. "
                    f"Either enable caching or choose a different checkpoint stage."
                )

    def _initialize_observers(self) -> None:
        """
        Instantiate observers from recipe config and determine which stages they apply to.

        Reads ``enable_observers`` at the pipeline level (global) and at each stage level
        (per-stage). If global is ``True``, observers run for all stages. If only per-stage
        flags are set, observers run only for those stages.

        The ``observers`` dict on the pipeline config maps observer names to ``{"class": "..."}``
        dicts. If ``enable_observers`` is ``True`` but no ``observers`` dict is provided,
        ``StageProfilerObserver`` is instantiated by default.
        """
        global_enabled: bool = self.config.enable_observers

        per_stage_enabled: set[str] = {
            stage_name
            for stage_name, stage_dict in self._stage_info.items()
            if stage_dict.get("enable_observers", False)
        }

        if not global_enabled and not per_stage_enabled:
            return

        self._observer_active_stages = None if global_enabled else per_stage_enabled

        obs_config: dict = self.config.observers or {}
        if obs_config:
            for obs_name, obs_dict in obs_config.items():
                class_path = obs_dict.get("class")
                if not class_path:
                    raise ValueError(f"Observer '{obs_name}' must specify a 'class' field.")
                module_path, class_name = class_path.rsplit(".", 1)
                try:
                    module = importlib.import_module(module_path)
                    obs_class = getattr(module, class_name)
                except (ImportError, AttributeError) as e:
                    raise ImportError(
                        f"Failed to import observer class '{class_path}' for observer '{obs_name}': {e}"
                    ) from e
                self._observers.append(obs_class())
                self._logger.info(f"Observer '{obs_name}' ({class_path}) registered.")
        else:
            from qairt.experimental.pipeline.torch.common.observers.profiler_observer import (
                StageProfilerObserver,
            )

            self._observers.append(StageProfilerObserver())
            self._logger.info("Observer 'profiler' (StageProfilerObserver) registered by default.")

        scope = "all stages" if self._observer_active_stages is None else str(self._observer_active_stages)
        self._logger.info(f"Observers active for: {scope}")

    def _build_runner(self) -> _RunnerInterface:
        """Compose the runner chain: [_CheckpointRunner →] [_CachingRunner →] _ObservingRunner → _DirectRunner."""
        runner: _RunnerInterface = _ObservingRunner(
            _DirectRunner(), self._observers, self._observer_active_stages
        )
        if self._cache is not None:
            runner = _CachingRunner(runner, self._cache)
        if self.config.checkpoint is not None:
            runner = _CheckpointRunner(runner, self.config.checkpoint, self._pipeline_state_dir.parent)
        return runner

    def _preload_manifest_stages(self) -> frozenset[str]:
        """
        Restore completed stages from the manifest into ``_stage_outputs``.

        Returns stage names to skip in the construct loop — stages restored from
        artifacts and artifact-less stages covered by a later restored stage.
        Returns an empty frozenset on a fresh run.
        """
        completed_stages = self._manifest.read().get("stages", {})
        if not completed_stages:
            return frozenset()

        stage_names_ordered = list(self._stage_instances.keys())
        stages_with_artifacts = {
            name for name, entry in completed_stages.items() if entry.get("artifact_path")
        }
        skippable_no_artifact: set[str] = set()
        for i, name in enumerate(stage_names_ordered):
            if name in completed_stages and name not in stages_with_artifacts:
                later_stages = stage_names_ordered[i + 1 :]
                if any(s in stages_with_artifacts for s in later_stages):
                    skippable_no_artifact.add(name)

        stages_to_skip: set[str] = set()

        for stage_name, stage in self._stage_instances.items():
            if stage_name not in completed_stages:
                continue

            manifest_artifact_str = completed_stages[stage_name].get("artifact_path")
            if manifest_artifact_str:
                manifest_artifact = Path(manifest_artifact_str)
                if not manifest_artifact.exists():
                    self._logger.warning(
                        f"Stage '{stage_name}': artifacts at '{manifest_artifact}' no longer exist, re-executing."
                    )
                    continue
                try:
                    stage_output = type(stage).load_from_cache(manifest_artifact)
                    self._stage_outputs[stage_name] = stage_output
                    self._manifest_restored_stages.add(stage_name)
                    self._logger.info(f"Stage '{stage_name}': restored from manifest, skipping execution")
                    stages_to_skip.add(stage_name)
                except Exception as e:
                    self._logger.warning(
                        f"Stage '{stage_name}': manifest restore failed ({e}), re-executing."
                    )
            elif stage_name in skippable_no_artifact:
                self._logger.info(
                    f"Stage '{stage_name}': completed in prior run (no artifacts), skipping — "
                    f"downstream input satisfied by a later restored stage."
                )
                stages_to_skip.add(stage_name)

        return frozenset(stages_to_skip)

    def _validate_stage_order(self) -> None:
        """
        Validate the configured stage order against all dependency constraints.

        Validation runs in two sequential passes:
        Pass 1: Structural: conflict, requires, and optional constraints are checked across all stages.
        Pass 2: Data-flow: Every required input field is checked against the predecessor's output.

        Raises:
            ValueError: Consolidated message for all structural violations (Pass 1),
                        or all binding violations (Pass 2).
        """
        stage_names = list(self._stage_classes.keys())
        all_stages: set[str] = set(stage_names)

        # Pass 1: structural constraints across all stages
        structural_errors: list[str] = []
        for i, stage_name in enumerate(stage_names):
            stage_class = self._stage_classes[stage_name]
            preceding: dict[str, Type[Stage]] = {n: self._stage_classes[n] for n in stage_names[:i]}
            structural_errors.extend(
                self._validate_stage_relations(stage_name, stage_class, preceding, all_stages)
            )

        if structural_errors:
            msg = "Pipeline stage order validation failed:\n" + "\n".join(
                f"  - {e}" for e in structural_errors
            )
            self._logger.error(msg)
            raise ValueError(msg)

        # Pass 2: data-flow / binding constraints
        binding_errors: list[str] = []
        for i, stage_name in enumerate(stage_names):
            binding_errors.extend(self._validate_stage_bindings(stage_name, stage_names, i))

        if binding_errors:
            msg = "Pipeline stage order validation failed:\n" + "\n".join(f"  - {e}" for e in binding_errors)
            self._logger.error(msg)
            raise ValueError(msg)
        self._logger.info("Stage order validation passed.")

    def _validate_stage_relations(
        self,
        stage_name: str,
        stage_class: Type[Stage],
        preceding: dict[str, Type[Stage]],
        all_stages: set[str],
    ) -> list[str]:
        """
        Check conflict, requires, and optional constraints for a single stage.

        Args:
            stage_name:  Name of the stage being validated.
            stage_class: Resolved class for that stage.
            preceding:   Mapping of stage names that appear before this stage.
            all_stages:  Set of all stage names in the pipeline.

        Returns:
            List of error strings (empty when the stage passes all checks).
        """
        errors: list[str] = []
        dependencies = stage_class.get_stage_dependency()

        # TODO: Should be DEBUG but debug logs are not showing up and needs fixing
        self._logger.debug(f"Checking structural constraints for stage '{stage_name}'...")

        # conflict - mutually exclusive stages must not coexist.
        for conflict_stage in dependencies.conflict:
            conf_name = conflict_stage.__name__ if isinstance(conflict_stage, type) else conflict_stage
            if conf_name in all_stages:
                msg = f"Stage '{stage_name}' conflicts with '{conf_name}' and both present in the pipeline."
                self._logger.error(msg)
                errors.append(msg)

        # requires - all declared dependencies must be present and precede this stage.
        for required_stage in dependencies.requires:
            req_name = required_stage.__name__ if isinstance(required_stage, type) else required_stage
            if req_name not in all_stages:
                msg = f"Stage '{stage_name}' requires '{req_name}', but it is not present in the pipeline."
                self._logger.error(msg)
                errors.append(msg)
            elif req_name not in preceding:
                msg = f"Stage '{stage_name}' requires '{req_name}' to precede it, but it is configured after."
                self._logger.error(msg)
                errors.append(msg)

        # optional - if present in the pipeline, must precede this stage; absence is fine.
        for opt_stage in dependencies.optional:
            opt_name = opt_stage.__name__ if isinstance(opt_stage, type) else opt_stage
            if opt_name in all_stages and opt_name not in preceding:
                msg = (
                    f"Stage '{stage_name}' - optional dependency '{opt_name}' "
                    f"is present in the pipeline but is configured after."
                )
                self._logger.error(msg)
                errors.append(msg)

        return errors

    def _validate_stage_bindings(
        self,
        stage_name: str,
        stage_names: list[str],
        stage_index: int,
    ) -> list[str]:
        """
        Validate that a stage's input fields can be satisfied by the immediate
        predecessor's output.

        Two paths for all other stages:

        - Explicit io_bindings**: each declared binding's ``source_field``
          must exist in the immediate predecessor's ``Output``.
        - Name-matching (no io_bindings): each required ``Input`` field
          must exist by the same name in the immediate predecessor's ``Output``.

        Args:
            stage_name:   Name of the stage being validated.
            stage_names:  Ordered list of all stage names in the pipeline.
            stage_index:  Position of ``stage_name`` in ``stage_names``.
                          Stages at index 0 have no predecessor and are skipped.

        Returns:
            List of error strings (empty when all required fields are satisfiable).
        """
        # First stage has no predecessor - nothing to validate
        if stage_index == 0:
            return []

        errors: list[str] = []
        prev_stage_name = stage_names[stage_index - 1]
        prev_output_fields = self._stage_classes[prev_stage_name].Output.model_fields

        self._logger.debug(
            f"Checking data-flow bindings for stage '{stage_name}' (predecessor: '{prev_stage_name}')..."
        )

        recipe_bindings = self._parse_recipe_bindings(stage_name)

        if recipe_bindings:
            for binding in recipe_bindings:
                if binding.source_field not in prev_output_fields:
                    msg = (
                        f"Stage '{stage_name}': io_binding '{binding.target_field}' "
                        f"expects source field '{binding.source_field}' in "
                        f"'{prev_stage_name}'.Output, but that field is not declared there."
                    )
                    self._logger.error(msg)
                    errors.append(msg)
        else:
            stage_class = self._stage_classes[stage_name]
            for field_name, field_info in stage_class.Input.model_fields.items():
                if field_info.is_required() and field_name not in prev_output_fields:
                    msg = (
                        f"Stage '{stage_name}': required input '{field_name}' "
                        f"is not provided by the immediate preceding stage '{prev_stage_name}'."
                    )
                    self._logger.error(msg)
                    errors.append(msg)

        return errors

    def _parse_recipe_bindings(self, stage_name: str) -> list[FieldBinding]:
        """
        Parse ``io_bindings`` from the recipe's ``stage_info`` entry for a given stage.
        Expected format in recipe (dict) — ``"target_field": "source_field"``::

            "io_bindings": {
                "model":     "base_model",
                "tokenizer": "tokenizer"
            }

        Returns:
            List of ``FieldBinding`` objects. Empty list if no ``io_bindings`` key present.
        """
        raw = self._stage_info[stage_name].get("io_bindings")
        if raw is None:
            return []

        if isinstance(raw, dict):
            return [
                FieldBinding(target_field=target_field, source_field=source_field)
                for target_field, source_field in raw.items()
            ]

        self._logger.warning(
            f"Stage '{stage_name}': unrecognised io_bindings format "
            f"({type(raw).__name__}). Expected dict. Ignoring."
        )
        return []

    def _construct_stage_input(self, stage_name: str) -> StageInput:
        """
        Construct the ``StageInput`` instance for a stage by injecting values.

        Returns:
            A populated ``StageInput`` instance ready to pass to ``stage.run()``.
        """
        stage_class = self._stage_classes[stage_name]
        preceding_outputs = list(self._stage_outputs.values())
        prev_output = preceding_outputs[-1] if preceding_outputs else None
        if prev_output is None:
            self._logger.debug(
                f"Stage '{stage_name}': no preceding stage output — Input will use field defaults only."
            )
        input_kwargs: dict[str, Any] = {}

        recipe_bindings = self._parse_recipe_bindings(stage_name)

        if recipe_bindings:
            for binding in recipe_bindings:
                if prev_output is not None:
                    value = getattr(prev_output, binding.source_field, None)
                    if value is not None:
                        input_kwargs[binding.target_field] = value
        else:
            if prev_output is not None:
                for field_name in stage_class.Input.model_fields:
                    value = getattr(prev_output, field_name, None)
                    if value is not None:
                        input_kwargs[field_name] = value

        return stage_class.Input(**input_kwargs)
