# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Stage runner chain: _CheckpointRunner → _CachingRunner → _ObservingRunner → _DirectRunner → stage.run()"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional, Protocol

from qairt.experimental.pipeline.torch.common.bases.stage import (
    Stage,
    StageConfig,
    StageInput,
    StageOutput,
)
from qairt.experimental.pipeline.torch.common.bases.stage_observer import StageObserver
from qairt.experimental.pipeline.torch.common.cache import StageCache
from qairt.utils.loggers import get_logger

_runner_logger = get_logger("StageRunner")


@dataclass
class RunResult:
    """Return value of all stage runners, carrying output and where artifacts landed."""

    output: StageOutput
    artifact_path: Optional[Path] = field(default=None)
    is_terminal: bool = field(default=False)


class _RunnerInterface(Protocol):
    """Interface that all stage runners must implement."""

    def run(self, stage: Stage, stage_input: StageInput, stage_config: StageConfig) -> RunResult: ...

    def finalize(self, pipeline_state_dir: Path) -> None: ...


class _DirectRunner:
    """Executes a stage directly, logging failures before re-raising."""

    def run(self, stage: Stage, stage_input: StageInput, stage_config: StageConfig) -> RunResult:
        try:
            output = stage.run(stage_input, stage_config)
            _runner_logger.info(f"Stage '{stage.name}': successfully completed")
            return RunResult(output)
        except Exception as e:
            _runner_logger.error(f"Stage '{stage.name}' failed: {e}")
            raise

    def finalize(self, pipeline_state_dir: Path) -> None:
        pass


class _ObservingRunner:
    """Fires observer hooks around the inner runner; finalize() flushes metrics and reports."""

    def __init__(
        self,
        inner: _RunnerInterface,
        observers: list[StageObserver],
        active_stages: Optional[set[str]],
    ) -> None:
        self._inner = inner
        self._observers = observers
        self._active_stages = active_stages

    def run(self, stage: Stage, stage_input: StageInput, stage_config: StageConfig) -> RunResult:
        observe = self._active_stages is None or stage.name in self._active_stages
        if observe:
            for obs in self._observers:
                obs.run_before_stage(stage, stage_config, stage_input)
        result = self._inner.run(stage, stage_input, stage_config)
        if observe:
            for obs in self._observers:
                obs.run_after_stage(stage, stage_config, stage_input, result.output)
        return result

    def finalize(self, pipeline_state_dir: Path) -> None:
        self._inner.finalize(pipeline_state_dir)

        all_metrics: dict[str, Any] = {}
        for observer in self._observers:
            if hasattr(observer, "get_metrics"):
                all_metrics.update(observer.get_metrics())
        if all_metrics:
            metrics_path = pipeline_state_dir / "metrics.json"
            try:
                pipeline_state_dir.mkdir(parents=True, exist_ok=True)
                existing: dict[str, Any] = {}
                if metrics_path.exists():
                    with open(metrics_path) as f:
                        existing = json.load(f)
                existing.update(all_metrics)
                with open(metrics_path, "w") as f:
                    json.dump(existing, f, indent=2)
                _runner_logger.info(f"Metrics written to '{metrics_path}'")
            except Exception as e:
                _runner_logger.error(f"Failed to write metrics to '{metrics_path}': {e}")

        for observer in self._observers:
            if hasattr(observer, "get_observer_report"):
                observer.get_observer_report()


class _CachingRunner:
    """Cache-aside decorator: skips the inner runner on a cache hit."""

    def __init__(self, inner: _RunnerInterface, cache: StageCache) -> None:
        self._inner = inner
        self._cache = cache

    def run(self, stage: Stage, stage_input: StageInput, stage_config: StageConfig) -> RunResult:
        key = StageCache.compute_key(stage.name, stage_config, stage_input)
        artifact_path = self._cache.cache_dir / stage.name / f"{stage.name}_{key[:8]}"
        cached = self._cache.get(key, type(stage))
        if cached is not None:
            _runner_logger.info(f"Stage '{stage.name}': cache hit, skipping execution")
            return RunResult(cached, artifact_path)
        result = self._inner.run(stage, stage_input, stage_config)
        self._cache.put(key, result.output, stage, artifact_path)
        return RunResult(result.output, artifact_path, result.is_terminal)

    def finalize(self, pipeline_state_dir: Path) -> None:
        self._inner.finalize(pipeline_state_dir)


class _CheckpointRunner:
    """Calls stage.export() on the checkpoint stage and sets is_terminal in the RunResult."""

    def __init__(
        self,
        inner: _RunnerInterface,
        checkpoint_stage_name: str,
        artifact_path: Path,
    ) -> None:
        self._inner = inner
        self._checkpoint_stage_name = checkpoint_stage_name
        self._artifact_path = artifact_path

    def run(self, stage: Stage, stage_input: StageInput, stage_config: StageConfig) -> RunResult:
        result = self._inner.run(stage, stage_input, stage_config)
        if stage.name == self._checkpoint_stage_name:
            try:
                stage.export(result.output, self._artifact_path)
            except Exception as e:
                _runner_logger.error(f"Checkpoint export failed for stage '{stage.name}': {e}")
                raise
            _runner_logger.info(f"Checkpoint '{self._checkpoint_stage_name}' reached. Stopping.")
            return RunResult(result.output, self._artifact_path, is_terminal=True)
        return result

    def finalize(self, pipeline_state_dir: Path) -> None:
        self._inner.finalize(pipeline_state_dir)
