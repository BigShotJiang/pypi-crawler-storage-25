# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
Stage Registry - Global registry for pipeline stages.

This module provides a singleton registry for managing pipeline stages,
including both built-in and custom stages.
"""

from __future__ import annotations

from enum import Enum
from typing import Optional, Type, Union

from typing_extensions import TypeAlias

from .stage import Stage


class BuiltInStage(str, Enum):
    """Built-in stage identifiers."""

    MODEL_LOADER = "MODEL_LOADER"
    ADAPTATIONS = "ADAPTATIONS"
    QUANTIZATION = "QUANTIZATION"
    QUANTIZATION_OPT = "QUANTIZATION_OPT"
    GENAI_BUILDER = "genai_builder"


RegistryKey: TypeAlias = Union[str, BuiltInStage, tuple[str, ...]]
"""Valid key types for the stage registry: a plain string, a BuiltInStage enum value, or a tuple of strings."""


class StageRegistry:
    """
    Registry for managing pipeline stages.

    The registry maps stage names (or tuples of identifiers) to stage classes.
    It distinguishes between built-in stages and custom stages, and provides
    methods for registration, removal, and listing of stages.

    Example:
        >>> registry = StageRegistry()
        >>> registry.register("quantization", QuantizationStage, built_in=True)
        >>> registry.register(("custom", "my_stage"), MyCustomStage)
        >>> stages = registry.list_stages()
    """

    def __init__(self):
        """Initialize the registry."""
        self._stages: dict[RegistryKey, Type[Stage]] = {}
        self._built_in_stages: set[RegistryKey] = set()
        self._custom_stages: set[RegistryKey] = set()

    def register(self, key: RegistryKey, stage_class: Type[Stage], built_in: bool = False) -> None:
        """
        Register a stage in the registry.

        Args:
            key: Stage identifier (string name or tuple for extra delimiters)
            stage_class: The stage class to register
            built_in: Whether this is a built-in stage (default: False)

        Raises:
            ValueError: If the key is already registered

        Example:
            >>> registry.register("quantization", QuantizationStage, built_in=True)
            >>> registry.register(("custom", "adapter"), CustomAdapterStage)
        """
        if key in self._stages:
            raise ValueError(
                f"Stage with key '{key}' is already registered. Use unregister() first to replace it."
            )

        self._stages[key] = stage_class

        if built_in:
            self._built_in_stages.add(key)
        else:
            self._custom_stages.add(key)

    def unregister(self, key: RegistryKey) -> None:
        """
        Remove a stage from the registry.

        Args:
            key: Stage identifier to remove

        Raises:
            KeyError: If the key is not found in the registry

        Example:
            >>> registry.unregister("my_custom_stage")
        """
        if key not in self._stages:
            raise KeyError(f"Stage with key '{key}' is not registered")

        del self._stages[key]

        # Remove from tracking sets
        self._built_in_stages.discard(key)
        self._custom_stages.discard(key)

    def get(self, key: RegistryKey) -> Optional[Type[Stage]]:
        """
        Retrieve a stage class by its key.

        Args:
            key: Stage identifier

        Returns:
            The stage class, or None if not found

        Example:
            >>> stage_class = registry.get("quantization")
        """
        return self._stages.get(key)

    def list_stages(
        self, built_in_only: bool = False, custom_only: bool = False
    ) -> dict[RegistryKey, Type[Stage]]:
        """
        List all registered stages.

        Args:
            built_in_only: If True, return only built-in stages
            custom_only: If True, return only custom stages

        Returns:
            Dictionary mapping stage keys to stage classes

        Example:
            >>> all_stages = registry.list_stages()
            >>> built_in = registry.list_stages(built_in_only=True)
            >>> custom = registry.list_stages(custom_only=True)
        """
        if built_in_only and custom_only:
            raise ValueError("Cannot specify both built_in_only and custom_only")

        if built_in_only:
            return {k: v for k, v in self._stages.items() if k in self._built_in_stages}
        elif custom_only:
            return {k: v for k, v in self._stages.items() if k in self._custom_stages}
        else:
            return self._stages.copy()

    def is_built_in(self, key: RegistryKey) -> bool:
        """
        Check if a stage is a built-in stage.

        Args:
            key: Stage identifier

        Returns:
            True if the stage is built-in, False otherwise

        Example:
            >>> registry.is_built_in("quantization")
            True
        """
        return key in self._built_in_stages

    def is_custom(self, key: RegistryKey) -> bool:
        """
        Check if a stage is a custom stage.

        Args:
            key: Stage identifier

        Returns:
            True if the stage is custom, False otherwise

        Example:
            >>> registry.is_custom(("custom", "my_stage"))
            True
        """
        return key in self._custom_stages

    def clear(self, custom_only: bool = False) -> None:
        """
        Clear the registry.

        Args:
            custom_only: If True, only clear custom stages (keep built-in stages)

        Example:
            >>> registry.clear(custom_only=True)  # Remove only custom stages
            >>> registry.clear()  # Remove all stages
        """
        if custom_only:
            for key in list(self._custom_stages):
                del self._stages[key]
            self._custom_stages.clear()
        else:
            self._stages.clear()
            self._built_in_stages.clear()
            self._custom_stages.clear()

    def __contains__(self, key: RegistryKey) -> bool:
        """Check if a stage key is registered."""
        return key in self._stages

    def __len__(self) -> int:
        """Return the number of registered stages."""
        return len(self._stages)

    def __repr__(self) -> str:
        """Return a string representation of the registry."""
        return (
            f"StageRegistry("
            f"total={len(self._stages)}, "
            f"built_in={len(self._built_in_stages)}, "
            f"custom={len(self._custom_stages)}"
            f")"
        )


_DEFAULT_STAGE_REGISTRY: StageRegistry = StageRegistry()


def register_stage(
    key: RegistryKey,
    built_in: bool = False,
    registry: Optional[StageRegistry] = _DEFAULT_STAGE_REGISTRY,
):
    """
    Decorator to automatically register a stage class.

    Args:
        key: Stage identifier (string name or tuple for extra delimiters)
        built_in: Whether this is a built-in stage (default: False)
        registry: Optional registry instance (uses singleton if None)

    Returns:
        Decorator function that registers the stage class

    Example:
        >>> @register_stage("quantization", built_in=True)
        ... class QuantizationStage:
        ...     name = "quantization"
        ...     # ... stage implementation

        >>> @register_stage(("custom", "my_adapter"))
        ... class MyCustomAdapterStage:
        ...     name = "my_adapter"
        ...     # ... stage implementation
    """

    def decorator(stage_class: Type[Stage]) -> Type[Stage]:
        """Register the stage class and return it unchanged."""
        reg = registry if registry is not None else StageRegistry()
        reg.register(key, stage_class, built_in=built_in)
        return stage_class

    return decorator
