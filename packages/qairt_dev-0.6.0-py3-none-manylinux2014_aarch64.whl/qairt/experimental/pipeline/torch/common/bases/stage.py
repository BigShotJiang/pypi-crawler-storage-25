# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
Pipeline Stage

This module defines the abstract stage base class for the pipeline system
and the three-class contract (StageInput, StageConfig, StageOutput).
"""

from __future__ import annotations

import dataclasses
from abc import ABC, abstractmethod
from dataclasses import Field
from enum import Enum
from logging import config
from pathlib import Path
from typing import Any, ClassVar, Generic, List, Optional, Protocol, Type, TypeVar, Union, final

from pydantic import BaseModel
from typing_extensions import TypeAlias


class StageExecutionError(Exception):
    """Custom exception for errors during stage execution."""

    pass


class StageDependencies(BaseModel):
    """Defines ordering and conflict constraints for a pipeline stage."""

    model_config = {"arbitrary_types_allowed": True}

    # Mutually exclusive stages - none of the listed stages may appear in the same pipeline
    conflict: List[Type["Stage"]] | List[str] = []

    # ALL listed stages must precede this stage
    requires: List[Union[Type["Stage"], str]] = []

    # If any listed stage is present, it must precede this stage
    # (soft ordering constraint - absence is not an error)
    optional: List[Union[Type["Stage"], str]] = []

    # TODO: Consider adding requires_one_of for OR semantics
    #       (at least one of the listed stages must precede). Useful when a stage
    #       can accept output from alternative upstream implementations
    #       e.g. requires_one_of: [QuantizationStage, QuantizationOptStage].


class ExecutionEnvironment(str, Enum):
    """Supported execution environments for stages."""

    LOCAL = "local"  # CPU execution (default)
    GPU = "gpu"  # GPU execution (CUDA); torch.device will be "cuda" for all downstream calls (if applicable)
    DEVICE = "device"  # Generic QCOM target execution


class StageInput(BaseModel):
    """
    Base input for all pipeline stages.

    Populated by the pipeline from the immediate predecessor's output.
    Subclass this to declare the upstream fields a stage needs. Required fields
    (no default) will be validated by the pipeline before execution; optional
    fields (default=None) are injected when available.

    Example::

        class QuantizationInput(StageInput):
            model: torch.nn.Module          # required - must be provided by upstream
            tokenizer: Any | None = None    # optional - injected if available
    """

    model_config = {"extra": "allow", "protected_namespaces": (), "arbitrary_types_allowed": True}


class StageConfig(BaseModel):
    """Base configuration for all pipeline stages. Set by users via recipe or code."""

    model_config = {"extra": "allow", "protected_namespaces": (), "arbitrary_types_allowed": True}

    # Execution environment
    execution_environment: ExecutionEnvironment = ExecutionEnvironment.LOCAL

    # Pipeline config access (injected by pipeline for cross-cutting components)
    _pipeline_config: Optional[Any] = None


class StageOutput(BaseModel):
    """Base output for all pipeline stages. Produced by a stage and made available to downstream stages."""

    model_config = {"extra": "allow", "protected_namespaces": (), "arbitrary_types_allowed": True}


class _TypedDictLike(Protocol):
    """TypedDict structural protocol."""

    __required_keys__: ClassVar[frozenset[str]]
    __optional_keys__: ClassVar[frozenset[str]]


class _DataclassLike(Protocol):
    """Dataclass structural protocol, mirroring dataclasses._DataclassT."""

    __dataclass_fields__: ClassVar[dict[str, Field[Any]]]


StageInputLike: TypeAlias = StageInput | _TypedDictLike | _DataclassLike
StageConfigLike: TypeAlias = StageConfig | _TypedDictLike | _DataclassLike
StageOutputLike: TypeAlias = StageOutput | _TypedDictLike | _DataclassLike

InputT = TypeVar("InputT", bound=StageInputLike)
ConfigT = TypeVar("ConfigT", bound=StageConfigLike)
OutputT = TypeVar("OutputT", bound=StageOutputLike)


class Stage(ABC, Generic[InputT, ConfigT, OutputT]):
    """
    Base class that all pipeline stages must implement.

    A stage is defined by three Pydantic models that form its contract:

    - ``Input`` - upstream data injected by the pipeline.
    - ``Config``- user-provided settings from recipe/code.
    - ``Output``- data produced and made available downstream.
    """

    name: str
    Input: Type[InputT] = StageInput  # type: ignore[assignment]  # Runtime default: stages with no upstream deps don't need to override this
    Config: Type[ConfigT]
    Output: Type[OutputT]

    can_generate: bool = False  # Indicates if the stage supports generation (optional)
    can_export: bool = True  # Indicates if the stage supports export (optional)
    can_start: bool = False  # Indicates if the stage can be the first stage in a pipeline

    @final
    def run(self, input: InputT, config: ConfigT) -> OutputT:
        """
        Orchestrates stage execution by running hooks and core logic in order:
            1. ``_pre_hook``:  preprocessing
            2. ``_execute``:   core stage logic
            3. ``_post_hook``: postprocessing

        Args:
            input:  Upstream data constructed by the pipeline from prior stage outputs.
            config: Validated stage configuration.

        Returns:
            ``OutputT``: The final stage output after all hooks have been applied.

        Raises:
            StageExecutionError: If an error occurs during stage execution.
        """
        # Validate input/config types at runtime
        self._validate_stage_types(input, config)

        prepared_input, prepared_config = self._pre_hook(input=input, config=config)
        raw_output = self._execute(input=prepared_input, config=prepared_config)
        final_output = self._post_hook(input=prepared_input, config=prepared_config, output=raw_output)
        return final_output

    def _validate_stage_types(self, input: InputT, config: ConfigT) -> None:
        """Validate that input and config conform to expected protocols."""
        # Check if it's a valid Pydantic model, TypedDict, or dataclass
        for obj, name in [(input, "input"), (config, "config")]:
            if not (
                hasattr(obj, "model_dump")  # Pydantic
                or (hasattr(obj, "__required_keys__") and hasattr(obj, "__optional_keys__"))  # TypedDict
                or (dataclasses.is_dataclass(obj) and not isinstance(obj, type))  # dataclass instance
            ):
                raise StageExecutionError(
                    f"Stage {name} must be a Pydantic model, TypedDict, or dataclass instance. "
                    f"Got {type(obj).__name__}"
                )

    def _pre_hook(self, input: InputT, config: ConfigT) -> tuple[InputT, ConfigT]:
        """
        Optional hook called before ``_execute()`` for stage-specific preprocessing.

        Use cases:
        - Data preparation / validation
        - Environment setup
        - Resource allocation

        Args:
            input:  Injected upstream data.
            config: Validated stage configuration.

        Returns:
            Tuple of (possibly modified) input and config to pass to ``_execute()``.
            Default implementation returns both unchanged.
        """
        return input, config

    @abstractmethod
    def _execute(self, input: InputT, config: ConfigT) -> OutputT:
        """
        Execute the stage with the given input and configuration.

        This abstract method defines the core logic of the stage and must be
        implemented by all subclasses of Stage.

        Args:
            input:  Upstream data injected by the pipeline (from ``StageInput``).
            config: User-provided stage configuration (from ``StageConfig``).

        Returns:
            ``StageOutput`` instance containing the results of this stage.

        Raises:
            StageExecutionError: For any errors that occur during stage execution.
        """
        ...

    def _post_hook(self, input: InputT, config: ConfigT, output: OutputT) -> OutputT:
        """
        Optional hook called after ``_execute()``.
        Override this method for stage-specific postprocessing.

        Use cases:
        - Cleanup operations
        - Result transformation / validation
        - Resource deallocation

        Args:
            input:  Upstream data that was passed to ``_execute()``.
            config: Stage configuration used in ``_execute()``.
            output: Raw output from ``_execute()``.

        Returns:
            Modified (or unchanged) stage output.
            Default implementation returns output unchanged.
        """
        return output

    def generate(self, stage_output: OutputT, *args, **kwargs) -> Any:
        """
        Optional method for stages that perform generation using their stage output.
        Override this method to implement custom generation logic.
        By default, raises ``NotImplementedError``.
        """
        raise NotImplementedError(f"{self.name} stage does not implement generation.")

    @classmethod
    @abstractmethod
    def export(cls, stage_output: OutputT, output_path: Path, **kwargs) -> None:
        """
        Export stage artifacts to disk.

        Args:
            stage_output: The output of the stage to be exported.
            output_path:  The file path where the stage output should be exported.
        """
        ...

    @classmethod
    def load_from_cache(cls, cache_path: Path) -> OutputT:
        """
        Restore a ``StageOutput`` from artifacts written by ``export()``.

        Override in stages that support caching; raises ``NotImplementedError`` by default.

        Args:
            cache_path: Directory where this stage's artifacts were previously exported.

        Returns:
            A ``StageOutput`` equivalent to what ``_execute()`` would have produced.
        """
        raise NotImplementedError(f"{cls.__name__} does not implement load_from_cache().")

    @classmethod
    def get_stage_dependency(cls) -> StageDependencies:
        """
        Declare dependencies for this stage.
        Override in subclasses; default is no dependencies.
        """
        return StageDependencies()
