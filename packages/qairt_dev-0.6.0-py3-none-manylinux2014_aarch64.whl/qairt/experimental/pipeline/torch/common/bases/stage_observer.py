# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Stage Observers - Monitoring stage execution"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from qairt.experimental.pipeline.torch.common.bases.stage import (
        Stage,
        StageConfig,
        StageInput,
        StageOutput,
    )


class StageObserver(ABC):
    """
    Base class for stage observers.
    Observers can monitor stage execution and collect data before and after each stage runs.
    Multiple observers can be attached; they are called in registration order.

    Example::

        # Using the built-in observer:
        from qairt.experimental.pipeline.common.observers import StageProfilerObserver

        observer = StageProfilerObserver()
        pipe.add_observer(observer)
        pipe.construct()

        print(observer.get_execution_times())
        # {'model_loading': 1.23, 'quantization': 45.67}

        # Or implement a custom observer:
        class CheckpointObserver(StageObserver):
            def run_before_stage(self, stage, stage_config, stage_input):
                pass

            def run_after_stage(self, stage, stage_config, stage_input, stage_output):
                stage_output.save_checkpoint(stage.name)

        pipe.add_observer(CheckpointObserver())
        pipe.construct()
    """

    @abstractmethod
    def run_before_stage(self, stage: Stage, stage_config: StageConfig, stage_input: StageInput) -> None:
        """
        Called before stage execution.

        Args:
            stage:        The stage instance about to be executed.
            stage_config: The stage configuration in its declared state.
            stage_input:  The input constructed for the stage from upstream outputs.
        """
        ...

    @abstractmethod
    def run_after_stage(
        self,
        stage: Stage,
        stage_config: StageConfig,
        stage_input: StageInput,
        stage_output: StageOutput,
    ) -> None:
        """
        Called after stage execution.

        Args:
            stage:        The stage instance that was executed.
            stage_config: The stage configuration.
            stage_input:  The input that was passed to the stage.
            stage_output: The output produced by the stage.
        """
        ...

    def get_report(self) -> dict:
        """Return a structured report of the observer's findings.

        Override in subclasses that collect per-stage data (e.g. timings,
        metrics).

        Returns:
            Dictionary mapping stage name to the captured value(s) for that stage.
        """
        return {}
