# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Common pipeline configuration classes"""

from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional, Union

from pydantic import BaseModel, Field


class GeneratorConfig(BaseModel):
    """TBD"""

    ARGS: dict[str, Any] = Field(default_factory=dict)


class EvaluatorConfig(BaseModel):
    """Pipeline-level evaluator configuration. Parallel to GeneratorConfig.

    The ``metrics`` list drives evaluation. Each entry is a dict with a ``name``
    key that selects the metric class from the registry; every other key is
    forwarded as **kwargs to that metric's ``__init__``.
    """

    metrics: list[dict[str, Any]] = Field(default_factory=list)
    context_length: int = 2048
    output_dir: Optional[str] = None


# TODO: Flesh out exporter config and stage, and integrate into pipeline
class ExporterConfig(BaseModel):
    """Global exporter configuration."""

    pass


class OnnxExporterConfig(ExporterConfig):
    """ONNX exporter configuration."""

    # Add any ONNX-specific export parameters here, e.g., opset_version, input_names, output_names, etc.
    args: dict[str, Any] = Field(default_factory=dict)
