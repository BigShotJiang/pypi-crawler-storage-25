# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
Stage Profiler Observer

A single observer backed by one Profiler instance that captures both timing
and memory metrics for each pipeline stage.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from qairt.api.profiler.resource_profiler.events import ProfileEventType
from qairt.api.profiler.resource_profiler.resource_profiler import ResourceProfiler, SnapshotPoint
from qairt.experimental.pipeline.torch.common.bases.stage_observer import StageObserver
from qairt.utils.loggers import get_logger

if TYPE_CHECKING:
    from qairt.api.bases.report_base import Report
    from qairt.experimental.pipeline.torch.common.bases.stage import (
        Stage,
        StageConfig,
        StageInput,
        StageOutput,
    )

_logger = get_logger("StageProfilerObserver")


class StageProfilerObserver(StageObserver):
    """
    Records timing and RAM/GPU memory metrics for each pipeline stage.

    Uses a single ResourceProfiler instance so timing and memory are captured in one
    snapshot pair per stage. Results are available via ``get_execution_times()``,
    ``get_metrics()``, and ``get_observer_report()``.
    """

    def __init__(self) -> None:
        self._profiler = ResourceProfiler.create_isolated()
        self._start_snapshots: dict[str, SnapshotPoint] = {}
        self._stage_durations: dict[str, float] = {}
        self._metrics: dict[str, dict[str, Any]] = {}

    def reset(self) -> None:
        """Reset all collected data and profiler store."""
        self._start_snapshots.clear()
        self._stage_durations.clear()
        self._metrics.clear()
        self._profiler = ResourceProfiler.create_isolated()

    def run_before_stage(self, stage: Stage, stage_config: StageConfig, stage_input: StageInput) -> None:
        """Capture a snapshot before stage execution."""
        snap = self._profiler.snapshot(
            event_name=stage.name,
            event_type=ProfileEventType.PIPELINE_STAGE,
        )
        self._start_snapshots[stage.name] = snap
        _logger.debug(f"Profiler snapshot taken before stage: {stage.name}")

    def run_after_stage(
        self,
        stage: Stage,
        stage_config: StageConfig,
        stage_input: StageInput,
        stage_output: StageOutput,
    ) -> None:
        """Record timing and memory metrics after stage completion."""
        end_snap = self._profiler.snapshot(
            event_name=stage.name,
            event_type=ProfileEventType.PIPELINE_STAGE,
        )
        start_snap = self._start_snapshots.get(stage.name)

        if start_snap is not None:
            marker = self._profiler.record(
                event_name=stage.name,
                event_type=ProfileEventType.PIPELINE_STAGE,
                start_marker=start_snap,
                end_marker=end_snap,
            )
            self._stage_durations[stage.name] = marker.duration_s
            self._metrics[stage.name] = {
                "ram_pss_entry_mb": marker.ram_pss_bytes / (1024 * 1024),
                "ram_pss_mb": marker.ram_delta_bytes / (1024 * 1024),
                "gpu_memory_allocated_mb": marker.gpu_allocated_bytes / (1024 * 1024),
                "gpu_memory_peak_mb": marker.gpu_peak_bytes / (1024 * 1024),
            }
        else:
            _logger.warning(
                f"Stage '{stage.name}': run_after_stage called without a preceding run_before_stage."
            )
            self._stage_durations[stage.name] = 0.0
            self._metrics[stage.name] = {}

        _logger.info(
            f"Stage '{stage.name}' completed in {self._stage_durations[stage.name]:.4f}s, "
            f"metrics: {self._metrics[stage.name]}"
        )

    def get_execution_times(self) -> dict[str, float]:
        """
        Return a copy of the wall-clock duration for all completed stages.

        Returns:
            Dict mapping stage name to elapsed duration in seconds.
            Example: ``{'model_loading': 1.23, 'quantization': 45.67}``
        """
        return self._stage_durations.copy()

    def get_metrics(self) -> dict[str, dict[str, Any]]:
        """
        Return a copy of the collected per-stage memory metrics.

        Returns:
            Dict mapping stage name to a dict of metric name to value.
            GPU metrics are always present; they are ``0.0`` when CUDA is unavailable.
            Example::

                {
                    'model_loading': {
                        'ram_pss_entry_mb': 512.0,
                        'ram_pss_mb': 128.5,
                        'gpu_memory_allocated_mb': 0.0,
                        'gpu_memory_peak_mb': 0.0,
                    },
                }
        """
        return self._metrics.copy()

    def get_report(self) -> dict[str, Any]:
        """Return timing and memory data as a dict (StageObserver interface).

        Returns:
            Dict with keys ``"execution_times"`` and ``"metrics"``.
        """
        return {
            "execution_times": self.get_execution_times(),
            "metrics": self.get_metrics(),
        }

    def get_observer_report(self) -> "Report":
        """Return a MemoryProfilingReport with full timing and memory event data."""
        return self._profiler.report()
