# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
Built-in Stage Observers

Provides ready-to-use StageObserver implementations for common requirements.
Import from this package for the cleanest import surface:

    from qairt.experimental.pipeline.common.observers import StageProfilerObserver

For the abstract base class used to build custom observers, import from:

    from qairt.experimental.pipeline.common.bases.stage_observer import StageObserver
"""

from qairt.experimental.pipeline.torch.common.observers.profiler_observer import StageProfilerObserver

__all__ = [
    "StageProfilerObserver",
]
