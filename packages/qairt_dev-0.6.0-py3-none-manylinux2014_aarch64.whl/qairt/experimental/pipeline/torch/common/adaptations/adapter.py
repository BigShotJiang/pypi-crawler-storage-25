# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
Adapter component for applying model adaptations.
"""

from __future__ import annotations

import inspect
from typing import Any, Callable, List, Optional, Union


class Adapter:
    """
    Component for applying model adaptations.
    """

    @staticmethod
    def apply_adaptations(
        model: Any,
        backend: Union[str] = "HTP",
        model_type: Optional[str] = None,
        adaptations: Optional[List[Callable]] = None,
        apply_default_adaptations: bool = True,
        validate_custom: bool = True,
        custom_validators: Optional[List[Callable]] = None,
        **kwargs: Any,
    ) -> Any:
        """
        Apply a list of adaptations to the model.

        Parameters
        ----------
        model : Any
            The model to adapt (typically a PyTorch model or pipeline).
        backend : str, optional
            Target backend (e.g., "HTP", "GPU", "CPU").
        model_type : str, optional
            Model type (e.g., "LLM", "LVM", "LMM"). Explicitly specifying is
            recommended; if omitted the (backend, None) fallback entry is used.
        adaptations : List[Callable], optional
            Custom adaptation functions. Applied AFTER defaults unless
            apply_default_adaptations=False, in which case ONLY these run.
        apply_default_adaptations : bool, optional
            Apply default and feature-specific adaptations (default: True).
        validate_custom : bool, optional
            Perform basic signature and return-value checks on custom adaptation
            functions (default: True).
        custom_validators : List[Callable], optional
            Validator functions called after each adaptation with signature
            ``validator(original_model, adapted_model, adaptation_fn)``.
            Raise an exception inside the validator to abort the adaptation process.
        **kwargs : Any
            Additional arguments forwarded to every adaptation function and
            used to detect feature-specific configs.

        Returns
        -------
        Any
            The adapted model.

        Raises
        ------
        TypeError
            If validate_custom=True and an adaptation function is not callable
            or has an incompatible signature.
        ValueError
            If validate_custom=True and an adaptation function returns None.

        Examples
        --------
        >>> # Use case 1: default backend adaptations
        >>> adapted = Adapter.apply_adaptations(model, backend="HTP", model_type="LLM")

        >>> # Use case 3: custom adaptation appended after defaults
        >>> adapted = Adapter.apply_adaptations(
        ...     model, backend="HTP", adaptations=[my_custom_fn]
        ... )

        >>> # Use case 2 (defaults disabled): only custom adaptation runs
        >>> adapted = Adapter.apply_adaptations(
        ...     model, backend="HTP",
        ...     adaptations=[my_custom_fn],
        ...     apply_default_adaptations=False,
        ... )

        >>> # Validation: abort if adaptation breaks output shape
        >>> def shape_validator(original, adapted, fn):
        ...     assert adapted.output_shape == original.output_shape
        >>> adapted = Adapter.apply_adaptations(
        ...     model, backend="HTP", custom_validators=[shape_validator]
        ... )
        """
        custom_adaptations = list(adaptations) if adaptations else []

        if not apply_default_adaptations:
            trusted_adaptations: List[Callable] = []
        else:
            default_adaptations = Adapter._get_default_adaptations(backend, model_type)
            feature_adaptations = Adapter._get_feature_adaptations(backend, model_type, kwargs)
            trusted_adaptations = default_adaptations + feature_adaptations

        original_model = model
        adapted_model = model

        for adaptation_fn in trusted_adaptations:
            adapted_model = adaptation_fn(adapted_model, **kwargs)

        for i, adaptation_fn in enumerate(custom_adaptations):
            if validate_custom:
                Adapter._validate_adaptation_function(adaptation_fn, i)

            result = adaptation_fn(adapted_model, **kwargs)

            if validate_custom:
                Adapter._validate_adaptation_result(result, adaptation_fn, i)

            if custom_validators:
                for validator in custom_validators:
                    validator(original_model, result, adaptation_fn)

            adapted_model = result

        return adapted_model

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_default_adaptations(
        backend: Union[str],
        model_type: Optional[str],
    ) -> List[Callable]:
        """Return the default adaptation list for (backend, model_type)."""
        from ._mappings import BACKEND_MODEL_ADAPTATIONS

        key = (str(backend), model_type)
        return list(BACKEND_MODEL_ADAPTATIONS.get(key, []))

    @staticmethod
    def _get_feature_adaptations(
        backend: Union[str],
        model_type: Optional[str],
        kwargs: dict,
    ) -> List[Callable]:
        """
        Detect feature configs in kwargs and return the corresponding
        feature-specific adaptation functions.
        """
        from ._mappings import FEATURE_ADAPTATIONS, FEATURE_CONFIG_MAPPING

        feature_adaptations: List[Callable] = []
        backend_str = str(backend)

        for config_param, feature_info in FEATURE_CONFIG_MAPPING.items():
            config_value = kwargs.get(config_param)
            if config_value is None:
                continue

            feature_name = feature_info["feature_name"]
            if "type_extractor" in feature_info:
                sub_type = feature_info["type_extractor"](config_value)
                feature_key = f"{feature_name}_{sub_type}"
            else:
                feature_key = feature_name

            key = (backend_str, model_type, feature_key)
            feature_adaptations.extend(FEATURE_ADAPTATIONS.get(key, []))

        return feature_adaptations

    @staticmethod
    def _validate_adaptation_function(adaptation_fn: Callable, index: int) -> None:
        """
        Check that an adaptation function is callable and accepts a model
        as its first positional argument.

        Parameters
        ----------
        adaptation_fn : Callable
            The function to validate.
        index : int
            Position in the adaptation list (used in error messages).

        Raises
        ------
        TypeError
            If the function is not callable or has an incompatible signature.
        """
        if not callable(adaptation_fn):
            raise TypeError(f"Adaptation at index {index} is not callable: {adaptation_fn!r}")

        try:
            sig = inspect.signature(adaptation_fn)
        except (ValueError, TypeError):
            # Cannot introspect (e.g. built-in); allow it through.
            return

        params = [
            p
            for p in sig.parameters.values()
            if p.kind
            not in (
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
            )
        ]
        if not params:
            name = getattr(adaptation_fn, "__name__", repr(adaptation_fn))
            raise TypeError(
                f"Adaptation '{name}' (index {index}) must accept at least one "
                "positional argument (the model)."
            )

    @staticmethod
    def _validate_adaptation_result(
        result: Any,
        adaptation_fn: Callable,
        index: int,
    ) -> None:
        """
        Check that an adaptation function returned a non-None value.

        Parameters
        ----------
        result : Any
            The value returned by the adaptation function.
        adaptation_fn : Callable
            The function that produced the result (used in error messages).
        index : int
            Position in the adaptation list (used in error messages).

        Raises
        ------
        ValueError
            If result is None.
        """
        if result is None:
            name = getattr(adaptation_fn, "__name__", repr(adaptation_fn))
            raise ValueError(
                f"Adaptation '{name}' (index {index}) returned None. "
                "Adaptation functions must return the (modified) model."
            )
