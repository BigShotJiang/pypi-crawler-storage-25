# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
Default adaptation mappings.

This module owns the lookup tables that drive Adapter.apply_adaptations().
Add new adaptations here as they are implemented.
"""

from .linears_to_conv import replace_linears_with_convs

# ---------------------------------------------------------------------------
# Default adaptations keyed by (backend, model_type).
# model_type values: "LLM", "LVM", "LMM", or None (generic fallback).
# ---------------------------------------------------------------------------
BACKEND_MODEL_ADAPTATIONS: dict = {
    # LLM
    ("HTP", "LLM"): [replace_linears_with_convs],
    # LVM (diffusers pipelines)
    ("HTP", "LVM"): [],
    # LMM (multimodal)
    ("HTP", "LMM"): [],
    # Generic fallback when model_type is None or unrecognised
    ("HTP", None): [replace_linears_with_convs],
}

# ---------------------------------------------------------------------------
# Feature config parameter mapping and feature-specific adaptations.
#
# Add entries here when a feature requires its own structural model changes.
# FEATURE_CONFIG_MAPPING maps a kwarg name to feature metadata; an optional
# "type_extractor" derives a sub-type so variants get distinct lookup keys
# (e.g. "speculative_decoding_eaglet").
# FEATURE_ADAPTATIONS is keyed by (backend, model_type, feature_key).
# ---------------------------------------------------------------------------
FEATURE_CONFIG_MAPPING: dict = {}

FEATURE_ADAPTATIONS: dict = {}
