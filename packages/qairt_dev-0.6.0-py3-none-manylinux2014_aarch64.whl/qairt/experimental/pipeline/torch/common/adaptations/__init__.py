# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
Adaptations building block.

Provides the Adapter class and the default adaptation functions.
"""

from ._mappings import BACKEND_MODEL_ADAPTATIONS
from .adapter import Adapter
from .linears_to_conv import replace_linears_with_convs

__all__ = [
    "Adapter",
    "replace_linears_with_convs",
    "BACKEND_MODEL_ADAPTATIONS",
]
