# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
Cache implementation for pipeline stages. Artifacts are stored on disk via
``stage.export()`` and restored on cache hits via ``load_from_cache()``.

Storage layout::

    {cache_dir}/.pipeline_state/
        manifest.json               # execution record used by Pipeline.load() to resume
        metrics.json                # per-stage runtime metrics (written at end of pipeline run)
        {stage_name}/{stage_name}_{key[:8]}/  # directory name uses first 8 chars of SHA-256 key
            metadata.json           # full key, stage_name, timestamp
            <stage artifacts>       # written by stage.export()

"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional, Type, Union

from qairt.experimental.pipeline.torch.common.bases.stage import Stage, StageConfig, StageOutput
from qairt.utils.loggers import get_logger

if TYPE_CHECKING:
    pass

_logger = get_logger("StageCache")


def _stable_json_default(obj: Any) -> Any:
    """
    Stable JSON serialization fallback for non-primitive types.

    Handles common non-serializable types deterministically so that cache keys
    remain consistent across Python sessions and environments.
    """
    if isinstance(obj, Path):
        return str(obj)
    type_name = type(obj).__module__ + "." + type(obj).__qualname__
    if type_name.startswith("torch."):
        return str(obj)
    return f"<{type_name}:{str(obj)}>"


class StageCache:
    """
    Cache store for pipeline stage outputs.

    Keys are SHA-256 digests of (stage_name, StageConfig). On a hit,
    ``get()`` calls ``stage_class.load_from_cache()``; on a miss, the caller runs
    the stage and calls ``put()`` to persist it.
    """

    def __init__(self, cache_dir: Union[str, Path]) -> None:
        self._cache_dir: Path = Path(cache_dir) / ".pipeline_state"
        # key → artifact directory path
        self._entries: dict[str, Path] = {}
        self._scan_disk()

    @property
    def cache_dir(self) -> Path:
        """Return the pipeline state directory (``{cache_dir}/.pipeline_state``)."""
        return self._cache_dir

    # ------------------------------------------------------------------
    # Key computation
    # ------------------------------------------------------------------

    @staticmethod
    def compute_key(
        stage_name: str,
        stage_config: StageConfig,
        stage_input: Optional[Any] = None,
    ) -> str:
        """
        Return a deterministic SHA-256 hex digest for the (name, config, input) tuple.

        Uses ``model_dump(mode="json")`` with ``sort_keys=True`` for stable serialization.
        Common non-serializable types (enums, Path, torch types) are handled by
        ``_stable_json_default``; raises ``TypeError`` if a field cannot be serialized.

        Args:
            stage_name:   Name of the stage (``Stage.name``).
            stage_config: The ``StageConfig`` instance for this run.
            stage_input:  The ``StageInput`` instance for this run, or ``None`` for
                          the first stage in the pipeline.

        Returns:
            A 64-character lowercase hex string.
        """
        config_bytes = StageCache._serialize_model(stage_config, "StageConfig")
        name_bytes = stage_name.encode()
        input_bytes = (
            StageCache._serialize_model(stage_input, "StageInput") if stage_input is not None else b""
        )
        digest = hashlib.sha256(name_bytes + b"|" + config_bytes + b"|" + input_bytes).hexdigest()
        return digest

    @staticmethod
    def _serialize_model(model: Any, label: str) -> bytes:
        """Serialize a stage model to stable JSON bytes for hashing (full dump, all fields)."""
        try:
            if hasattr(model, "model_dump"):
                data = model.model_dump(mode="json")
            elif dataclasses.is_dataclass(model) and not isinstance(model, type):
                data = dataclasses.asdict(model)
            else:
                data = dict(model)
            return json.dumps(data, sort_keys=True, default=_stable_json_default).encode()
        except Exception as e:
            raise TypeError(
                f"{label} contains fields that cannot be stably serialized for cache key "
                f"computation. Use only JSON-serializable types in "
                f"StageConfig to ensure reliable caching. Error type: {type(e).__name__}"
            ) from e

    # ------------------------------------------------------------------
    # Cache operations
    # ------------------------------------------------------------------

    def has(self, key: str) -> bool:
        """
        Return ``True`` if a valid cache entry exists for this key.

        Args:
            key: Cache key returned by ``compute_key()``.
        """
        return key in self._entries

    def get(self, key: str, stage_class: Type[Stage]) -> Optional[StageOutput]:
        """
        Return the cached ``StageOutput`` for ``key``, or ``None`` on a miss or corruption.

        Args:
            key:         Cache key returned by ``compute_key()``.
            stage_class: The ``Stage`` subclass whose ``load_from_cache()`` reconstructs the output.

        Returns:
            A ``StageOutput`` instance, or ``None`` on miss or corruption.
        """
        if not self.has(key):
            return None

        artifact_path = self._entries[key]
        try:
            return stage_class.load_from_cache(artifact_path)
        except Exception as e:
            _logger.warning(
                f"Cache entry '{key}' at '{artifact_path}' could not be loaded "
                f"({type(e).__name__}: {e}). Treating as cache miss."
            )
            return None

    def put(
        self,
        key: str,
        stage_output: StageOutput,
        stage: Stage,
        artifact_path: Path,
    ) -> None:
        """
        Persist a ``StageOutput`` to disk and register it in the cache.

        Calls ``stage.export()`` to write artifacts and writes ``metadata.json``.

        Args:
            key:           Cache key returned by ``compute_key()``.
            stage_output:  The output to cache.
            stage:         Stage instance used to call ``export()``.
            artifact_path: Directory to write artifacts into; created if absent.
        """
        artifact_path.mkdir(parents=True, exist_ok=True)

        # Write stage artifacts via the stage's own export mechanism
        stage.export(stage_output, artifact_path)

        # Write per-entry metadata
        metadata: dict[str, Any] = {
            "key": key,
            "stage_name": stage.name,
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "artifact_path": str(artifact_path),
        }
        with open(artifact_path / "metadata.json", "w") as f:
            json.dump(metadata, f, indent=2)

        self._entries[key] = artifact_path
        _logger.info(f"Cached stage '{stage.name}' at '{artifact_path}'")

    def write_metrics(self, metrics: dict[str, Any]) -> None:
        """
        Write per-stage runtime metrics to ``metrics.json`` in the cache directory.

        Args:
            metrics: Dict mapping stage name to a dict of metric name → value,
                     as returned by ``MetricsObserver.get_metrics()``.
        """
        metrics_path = self._cache_dir / "metrics.json"
        try:
            self._cache_dir.mkdir(parents=True, exist_ok=True)
            existing: dict[str, Any] = {}
            if metrics_path.exists():
                with open(metrics_path) as f:
                    existing = json.load(f)
            existing.update(metrics)
            with open(metrics_path, "w") as f:
                json.dump(existing, f, indent=2)
            _logger.info(f"Metrics written to '{metrics_path}'")
        except Exception as e:
            _logger.error(f"Failed to write metrics to '{metrics_path}': {e}")
            raise

    def clear(self, stage_name: Optional[str] = None) -> None:
        """
        Delete cached entries from disk and the in-memory index.

        Args:
            stage_name: If provided, delete only entries for this stage; otherwise clears all.
        """
        if stage_name is not None:
            stage_dir = self._cache_dir / stage_name
            if stage_dir.exists():
                shutil.rmtree(stage_dir)
                _logger.info(f"Cleared cache for stage '{stage_name}' at '{stage_dir}'")
            self._entries = {k: v for k, v in self._entries.items() if v.parent.name != stage_name}
        else:
            if self._cache_dir.exists():
                shutil.rmtree(self._cache_dir)
                _logger.info(f"Cleared entire cache at '{self._cache_dir}'")
            self._entries.clear()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _scan_disk(self) -> None:
        """Populate ``self._entries`` by scanning existing ``metadata.json`` files on disk."""
        if not self._cache_dir.exists():
            return

        for metadata_file in self._cache_dir.rglob("metadata.json"):
            try:
                with open(metadata_file) as f:
                    metadata = json.load(f)
                key = metadata.get("key")
                artifact_path = metadata.get("artifact_path")
                if key and artifact_path:
                    self._entries[key] = Path(artifact_path)
            except Exception as e:
                _logger.warning(f"Could not read cache metadata at '{metadata_file}': {e}")
