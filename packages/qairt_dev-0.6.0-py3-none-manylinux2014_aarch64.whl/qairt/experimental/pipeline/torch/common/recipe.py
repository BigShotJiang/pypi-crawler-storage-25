# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""
Recipe class for pipeline configuration.

A Recipe is a declarative specification that defines pipeline configuration,
including global settings, features, and per-stage parameters.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import yaml


class Recipe(dict):
    """
    Recipe class that stores pipeline configuration, allowing arbitrary keys and values
    while maintaining insertion order. It provides convenient methods for
    saving to and loading from YAML files, and supports schema validation.

    Example:
        >>> recipe = Recipe({
        ...     "model_id_or_path": "meta-llama/Llama-3.2-1B",
        ...     "backend": "HTP",
        ...     "stages": {"quantization": {"recipe": "lpbq_mse.yaml"}}
        ... })
        >>> recipe.to_yaml("my_recipe.yaml")
        >>> loaded = Recipe.from_yaml("my_recipe.yaml")
    """

    def __init__(self, *args, schema: Optional[dict[str, Any]] = None, **kwargs):
        """
        Initialize a Recipe instance.

        Args:
            *args: Positional arguments passed to dict
            schema: Optional schema dictionary for validation
            **kwargs: Keyword arguments passed to dict
        """
        super().__init__(*args, **kwargs)
        self._schema = schema

        # Validate against schema if provided
        if self._schema is not None:
            self.validate()

    def to_yaml(self, path: str | Path, **kwargs) -> None:
        """
        Save the recipe to a YAML file.

        Args:
            path: File path where the recipe should be saved
            **kwargs: Additional keyword arguments forwarded to ``yaml.dump``
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, "w") as f:
            yaml.safe_dump(self, f, default_flow_style=False, sort_keys=False, **kwargs)

    @classmethod
    def from_file(cls, path: str | Path, schema: Optional[dict[str, Any]] = None) -> "Recipe":
        """
        Load a recipe from a file, dispatching on the file extension.

        Supported extensions: ``.yaml``, ``.yml``

        Args:
            path: File path to the recipe file.
            schema: Optional schema dictionary for validation.

        Returns:
            Recipe instance loaded from the file.

        Raises:
            ValueError: If the file extension is not supported.
            FileNotFoundError: If the file does not exist.
        """
        path = Path(path)
        suffix = path.suffix.lower()
        if suffix in (".yaml", ".yml"):
            return cls.from_yaml(path, schema=schema)
        raise ValueError(f"Unsupported recipe file extension '{suffix}'. Expected .yaml or .yml.")

    @classmethod
    def from_yaml(cls, path: str | Path, schema: Optional[dict[str, Any]] = None) -> "Recipe":
        """
        Load a recipe from a YAML file.

        Args:
            path: File path to the YAML recipe file
            schema: Optional schema dictionary for validation

        Returns:
            Recipe instance loaded from the YAML file

        Raises:
            FileNotFoundError: If the file does not exist
            yaml.YAMLError: If the file is not valid YAML
        """
        path = Path(path)

        with open(path, "r") as f:
            data = yaml.safe_load(f)

        if not isinstance(data, dict):
            raise ValueError(f"Recipe file '{path}' is empty or does not contain a valid YAML mapping.")

        return cls(data, schema=schema)

    def validate(self, schema: Optional[dict[str, Any]] = None) -> None:
        """
        Validate the recipe against a schema.

        Args:
            schema: Schema dictionary to validate against. If None, uses the
                   schema provided during initialization.

        Raises:
            ValueError: If validation fails
        """
        schema = schema or self._schema

        if schema is None:
            return

        # Validate required keys
        required_keys = schema.get("required", [])
        for key in required_keys:
            if key not in self:
                raise ValueError(f"Required key '{key}' is missing from recipe")

        # Validate key types if specified
        properties = schema.get("properties", {})
        for key, value in self.items():
            if key in properties:
                expected_type = properties[key].get("type")
                if expected_type:
                    if not self._validate_type(value, expected_type):
                        raise ValueError(
                            f"Key '{key}' has invalid type. Expected {expected_type}, "
                            f"got {type(value).__name__}"
                        )

    def _validate_type(self, value: Any, expected_type: str) -> bool:
        """
        Validate that a value matches the expected type.

        Args:
            value: The value to validate
            expected_type: Expected type as a string (e.g., 'string', 'object', 'array')

        Returns:
            True if the type matches, False otherwise
        """
        type_mapping = {
            "string": str,
            "number": (int, float),
            "integer": int,
            "boolean": bool,
            "object": dict,
            "array": list,
            "null": type(None),
        }

        expected_python_type = type_mapping.get(expected_type)
        if expected_python_type is None:
            return True  # Unknown type, skip validation

        # bool is a subclass of int in Python, so isinstance(True, int) is True.
        # Treat booleans as their own type: reject them when "integer" is expected.
        if expected_type == "integer" and isinstance(value, bool):
            return False

        return isinstance(value, expected_python_type)  # type: ignore[arg-type]

    @property
    def schema(self) -> Optional[dict[str, Any]]:
        """Get the current schema for this recipe."""
        return self._schema

    @schema.setter
    def schema(self, value: dict[str, Any]) -> None:
        """Set or update the schema and re-validate."""
        self._schema = value
        self.validate()

    def __repr__(self) -> str:
        """Return a string representation of the Recipe."""
        items_str = ", ".join(f"'{k}': {repr(v)}" for k, v in list(self.items())[:3])
        if len(self) > 3:
            items_str += ", ..."
        return f"Recipe({{{items_str}}})"


def recipe_representer(dumper, data):
    """Represent a Recipe as a plain YAML mapping"""
    return dumper.represent_dict(data.items())


yaml.add_representer(Recipe, recipe_representer, Dumper=yaml.SafeDumper)
