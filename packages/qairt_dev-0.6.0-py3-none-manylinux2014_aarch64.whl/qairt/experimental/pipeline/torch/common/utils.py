# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

"""Common pipeline utilities."""

from __future__ import annotations

from typing import Generic, TypeVar

T = TypeVar("T")


class ConfigAccessor(Generic[T]):
    """
    Generic dict-proxy that provides both dot-notation and dict-style access
    to a named collection of objects.

    Example:
        pipe.stages.builder.multi_graph = True
        pipe.stages["builder"].multi_graph = True
    """

    def __init__(self, configs: dict[str, T]):
        self._configs = configs

    def __getattr__(self, name: str):
        if name.startswith("_"):
            return object.__getattribute__(self, name)
        if name in self._configs:
            return self._configs[name]
        raise AttributeError(f"No item named '{name}'")

    def __getitem__(self, name: str):
        return self._configs[name]

    def __setitem__(self, name: str, value: T):
        self._configs[name] = value

    def keys(self):
        return self._configs.keys()
