# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import hashlib
import json
import os
import pathlib
import shutil
import tempfile
from enum import Enum
from functools import wraps
from os import PathLike
from types import SimpleNamespace
from typing import Optional, Union

from tqdm import tqdm

from qairt.utils.loggers import get_logger
from qti.aisw.converters.gguf_builder import GGUFBuilder, GGUFParser
from qti.aisw.converters.gguf_builder.utils import (
    GGUF_TO_MAD_TENSOR_NAME_MAP,
    ModelSection,
    get_model_section_size_info,
)
from qti.aisw.graph_gen.mad.data_mha_to_sha import MHAtoSHAConverter
from qti.aisw.graph_gen.mad.loader import WeightLoader
from qti.aisw.graph_gen.mad.utils import load_encodings, save_encodings

_logger = get_logger(name="GGUFModule")


def load_pretrained_config(pretrained_model_path_dir: str | os.PathLike) -> SimpleNamespace:
    """
    Loads the configuration of a pre-trained model extracted from GGUF file and dumped into JSON file.

    If the provided path is a directory, the configuration is loaded from "config.json" within that directory.
    If the provided path is a file, it is loaded directly.
    The loaded configuration is augmented with a new attribute `_name_or_path` to be compliant with
    AutoConfig.from_pretrained behavior.

    Args:
        pretrained_model_path_dir (str | os.PathLike): The directory path or file path to the config.
            If directory: looks for "config.json" inside.
            If file: loads that file directly.

    Returns:
        SimpleNamespace: The loaded configuration as a SimpleNamespace object.

    Raises:
        FileNotFoundError: If the config file cannot be found.
    """
    path = pathlib.Path(pretrained_model_path_dir)

    # Determine the config file path
    if path.is_file():
        config_file = path
        # Use the parent directory as _name_or_path for consistency
        name_or_path = path.parent
    elif path.is_dir():
        config_file = path / "config.json"
        name_or_path = path
    else:
        raise FileNotFoundError(f"Config path '{pretrained_model_path_dir}' does not exist")

    if not config_file.exists():
        raise FileNotFoundError(f"Config file not found at '{config_file}'")

    with open(config_file, "r") as f:
        config = json.load(f, object_hook=lambda d: SimpleNamespace(**d))
        config._name_or_path = str(name_or_path)
    return config


def _hash(*args):
    """Generate a SHA256 hash from the provided arguments.

    Args:
        *args: Variable number of arguments to be hashed.

    Returns:
        str: SHA256 hash digest as a hexadecimal string.
    """
    args_str = ""
    for arg in args:
        args_str += f"{arg}"
    args_bytes: bytes = args_str.encode("utf-8")
    return hashlib.sha256(args_bytes).hexdigest()


def _move(source: Union[str | pathlib.Path], dest: Union[str | pathlib.Path]) -> pathlib.Path:
    """Move a file or directory from source to destination, handling overwrites.

    Args:
        source (Union[str, pathlib.Path]): Source file or directory path.
        dest (Union[str, pathlib.Path]): Destination file or directory path.

    Returns:
        pathlib.Path: Path to the moved file or directory.
    """
    source = pathlib.Path(source)
    dest = pathlib.Path(dest)
    if source.is_file() and not dest.is_file():
        dest = dest / source.name
    if dest.exists():
        if dest.is_file():
            os.remove(dest)
        else:
            shutil.rmtree(dest)

    if source.is_file():
        dest.parent.mkdir(parents=True, exist_ok=True)
    path = shutil.move(source, dest)
    return path


class GGUFTensorMode(Enum):
    """Enum representing tensor attention modes for GGUF models.

    Attributes:
        MHA (str): Multi-Head Attention mode.
        SHA (str): Single-Head Attention mode.
    """

    MHA = "MHA"
    SHA = "SHA"


class GGUFModule:
    """Module for handling GGUF model files.

    This class provides functionality to parse GGUF files, extract model configurations,
    weights, and encodings, and convert between MHA and SHA tensor modes.

    Attributes:
        model_path (str | PathLike): Path to the GGUF model file.
        cache_dir (Optional[str | PathLike]): Optional directory for caching extracted artifacts.
        tmp_path (str): Temporary directory path for intermediate files.
        config_folder_name (str): Name of the folder containing model configuration.
        config (SimpleNamespace): Loaded model configuration.
    """

    def __init__(self, model_path: str | PathLike, cache_dir: Optional[str | PathLike] = None):
        """Initialize GGUFModule with a model path and optional cache directory.

        Args:
            model_path (str | PathLike): Path to the GGUF model file.
            cache_dir (Optional[str | PathLike]): Optional directory for caching extracted artifacts.
        """

        self.model_path = model_path
        self.cache_dir = cache_dir
        self.tmp_path = os.getenv("QAIRT_TMP_DIR", default=tempfile.gettempdir())
        file_name = os.path.basename(model_path)
        self.config_folder_name = f"gguf_artifacts_{file_name.split('.gguf')[0]}"
        config_dir = self._extract_config()
        self.tokenizer_path = config_dir
        self.config = load_pretrained_config(config_dir)
        self.encoding_file_name = file_name + ".encodings"

    @staticmethod
    def cache_extract_config(func):
        """
        Cache utility for extracting config from GGUF file
        """

        @wraps(func)
        def extract_config(self) -> str | pathlib.Path:
            stat = os.stat(self.model_path)

            hash_dir = _hash(str(self.model_path), stat.st_size, stat.st_mtime, self.config_folder_name)
            cache_path = str(
                os.path.join(self.cache_dir, hash_dir)
                if self.cache_dir
                else os.path.join(self.tmp_path, self.config_folder_name)
            )
            _logger.debug(f"Cache Path used: {cache_path}")
            if not os.path.exists(cache_path):
                _logger.debug(f"Cache does not exists .. extracting config from file {self.model_path}")
                # If not already generated, extract the config from GGUF and store it.
                config_dir_path = func(self)
                if self.cache_dir:
                    _move(config_dir_path, cache_path)

            return cache_path

        return extract_config

    @cache_extract_config
    def _extract_config(self) -> str | pathlib.Path:
        """
        Extracts the config from GGUF file.

        :return: Returns path to the directory where config file is stored
        """

        GGUFBuilder(str(self.model_path), output_dir=self.tmp_path)._generate_config_from_gguf()
        return os.path.join(self.tmp_path, self.config_folder_name)

    @staticmethod
    def cache_parse_gguf(func):
        """
        Cache utility for parsing GGUF file.
        """

        @wraps(func)
        def parse(self, mode: GGUFTensorMode = GGUFTensorMode.MHA):
            weight_path = self._get_weight_path(mode)
            encoding_path = self._get_encoding_path(mode) / self.encoding_file_name

            if os.path.exists(weight_path) and os.path.exists(encoding_path):
                _logger.debug("Data already exists. Skipped parsing")
                return

            func(self, mode)

        return parse

    @staticmethod
    def cache_get_weights(func):
        """Cache utility for weights"""

        @wraps(func)
        def get_weights_wrapper(self, mode: GGUFTensorMode = GGUFTensorMode.MHA):
            """
            Retrieves weights from cache if available. If SHA mode is requested and MHA
            weights exist, converts them to SHA. Otherwise, parses the GGUF file.
            """

            # Check if the artifacts is available
            base_dir = self._get_weight_path(mode)
            if os.path.exists(base_dir):
                _logger.info(f"Using cached weights found at {base_dir}")
                return WeightLoader.from_directory(base_dir)

            # In case the MHA variant is available try converting it to SHA
            if mode == GGUFTensorMode.SHA:
                mha_base_dir = self._get_weight_path(GGUFTensorMode.MHA)
                if os.path.exists(mha_base_dir):
                    try:
                        return self._convert_to_sha_weights()
                    except Exception as e:
                        _logger.warning(
                            f"Conversion from MHA weights to SHA failed, will re-parse GGUF file.  :(\nError Message: {e}"
                        )

            return func(self, mode)

        return get_weights_wrapper

    @cache_get_weights
    def get_weights(self, mode: GGUFTensorMode = GGUFTensorMode.MHA):
        """Get model weights in the specified tensor mode.

        Args:
            mode (GGUFTensorMode): Tensor mode (MHA or SHA) for weights. Defaults to MHA.

        Returns:
            WeightLoader: Object containing the model weights.
        """

        base_dir = self._get_weight_path(mode)

        # Parse GGUF to extract artifacts
        self.parse(mode)
        return WeightLoader.from_directory(base_dir)

    @staticmethod
    def cache_get_encoding(func):
        """Cache utility for encoding"""

        @wraps(func)
        def get_encoding_wrapper(self, mode: GGUFTensorMode = GGUFTensorMode.MHA):
            """
            Retrieves encoding file from cache if available. If SHA mode is requested and
            MHA encodings exist, converts them to SHA. Otherwise, parses the GGUF file.
            """

            # Check if the artifacts is available
            base_dir = self._get_encoding_path(mode)
            if os.path.exists(base_dir):
                _logger.info(f"Using cached encoding found at {base_dir}")
                return base_dir / self.encoding_file_name

            # If the current mode is SHA and MHA encoding file exists, do MHAtoSHA and return the encoding file
            if mode == GGUFTensorMode.SHA:
                mha_base_dir = self._get_encoding_path(GGUFTensorMode.MHA)
                if os.path.exists(os.path.join(mha_base_dir, self.encoding_file_name)):
                    try:
                        return self._convert_to_sha_encodings()
                    except Exception as e:
                        _logger.warning(
                            f"Conversion from MHA encoding to SHA failed, will re-parse GGUF file.  :(\nError Message: {e}"
                        )

            return func(self, mode)

        return get_encoding_wrapper

    @cache_get_encoding
    def get_encoding_file(self, mode: GGUFTensorMode = GGUFTensorMode.MHA):
        """Get the path to the encoding file for the specified tensor mode.

        Args:
            mode (GGUFTensorMode): Tensor mode (MHA or SHA) for encodings. Defaults to MHA.

        Returns:
            pathlib.Path: Path to the encoding file.
        """
        base_dir = self._get_encoding_path(mode)

        # Parse GGUF to extract artifacts
        self.parse(mode)
        return base_dir / self.encoding_file_name

    @staticmethod
    def cache_model_section_size_info(func):
        @wraps(func)
        def wrapper(self):
            """
            Cache wrapper for retrieving the model section size info
            """
            stat = os.stat(self.model_path)
            hash_dir = _hash(
                str(self.model_path),
                stat.st_size,
                stat.st_mtime,
                self.config_folder_name,
                "MODEL_SECTION_SIZE_INFO",
            )

            try:
                if self.cache_dir:
                    cache_path = os.path.join(self.cache_dir, hash_dir, "model_size_info.json")
                    if os.path.exists(cache_path):
                        with open(cache_path, "r") as f:
                            model_section_info = json.load(f)
                            model_section_info = {ModelSection(k): v for k, v in model_section_info.items()}
                            if (
                                ModelSection.LM_HEAD in model_section_info
                                and ModelSection.EMBEDDING in model_section_info
                                and ModelSection.HIDDEN_LAYER in model_section_info
                            ):
                                return model_section_info

            except Exception as e:
                _logger.warning(f"Cache load failed :( | Error Message: {e}")

            model_section_size_info = func(self)
            # Cache the results
            if self.cache_dir:
                cache_path = os.path.join(self.cache_dir, hash_dir, "model_size_info.json")
                pathlib.Path(cache_path).parent.mkdir(parents=True, exist_ok=True)
                with open(cache_path, "w") as f:
                    json.dump({k.value: v for k, v in model_section_size_info.items()}, f)

            return model_section_size_info

        return wrapper

    @cache_model_section_size_info
    def get_model_section_size_info(self):
        """Get size information for different sections of the model.

        Retrieves size information for model sections (embedding, hidden layers, LM head).

        Returns:
            dict: Dictionary mapping ModelSection enum values to their sizes in bytes.
        """
        return get_model_section_size_info(self.model_path)

    @cache_parse_gguf
    def parse(self, mode: GGUFTensorMode = GGUFTensorMode.MHA):
        """
        Parse the GGUF file and extract weights and encodings.

        Internal method that performs the actual parsing of the GGUF file, updates
        tensor names to MAD naming convention, generates encodings, and optionally
        converts to SHA mode.

        Args:
            mode (GGUFTensorMode): Tensor mode (MHA or SHA) for parsing. Defaults to MHA.
        """
        parser = GGUFParser(
            input_model=self.model_path, filename_prefix="gguf_data", output_dir=self.tmp_path
        )
        parser.parse_gguf()

        # Step 2: Extract the model data and encodings
        self._update_tensor_names(parser)
        parser._generate_param_encodings()
        weights = parser.param_info["tensors"]

        if mode == GGUFTensorMode.SHA:
            converter = MHAtoSHAConverter(
                num_attention_heads=self.config.num_attention_heads,
                num_key_value_heads=self.config.num_key_value_heads,
            )
            weights = converter.split_data(weights)
            parser.param_encodings = converter.split_encoding_data(parser.param_encodings)

        # Store weights
        weight_path = self._get_weight_path(mode)
        _ = WeightLoader(weights, weight_path)

        # Store encodings
        enc_dir = self._get_encoding_path(mode)
        enc_dir.mkdir(parents=True, exist_ok=True)
        encoding_path = enc_dir / self.encoding_file_name
        encoding_data = {
            "version": "1.0.0",
            "activation_encodings": [],
            "param_encodings": parser.param_encodings,
            "excluded_layers": [],
        }
        save_encodings(encoding_data, encoding_path)

    def _convert_to_sha_encodings(self):
        """Convert MHA encodings to SHA encodings.

        Loads existing MHA encodings and converts them to SHA format using
        MHAtoSHAConverter, then saves the converted encodings.

        Returns:
            pathlib.Path: Path to the converted SHA encoding file.

        Raises:
            ValueError: If the MHA encoding file is invalid or missing param_encodings.
        """
        mha_encoding_path = self._get_encoding_path(GGUFTensorMode.MHA) / self.encoding_file_name
        mha_encodings = load_encodings(mha_encoding_path)
        if "param_encodings" not in mha_encodings:
            raise ValueError("Invalid encoding file, param_encodings fields not found :( ")

        converter = MHAtoSHAConverter(
            num_attention_heads=self.config.num_attention_heads,
            num_key_value_heads=self.config.num_key_value_heads,
        )
        sha_param_encodings = converter.split_encoding_data(mha_encodings["param_encodings"])

        # Store encodings
        enc_dir = self._get_encoding_path(GGUFTensorMode.SHA)
        enc_dir.mkdir(parents=True, exist_ok=True)
        encoding_path = enc_dir / self.encoding_file_name
        encoding_data = {
            "version": "1.0.0",
            "activation_encodings": [],
            "param_encodings": sha_param_encodings,
            "excluded_layers": [],
        }
        save_encodings(encoding_data, encoding_path)
        return encoding_path

    def _convert_to_sha_weights(self):
        """Convert MHA weights to SHA weights.

        Loads existing MHA weights and converts them to SHA format using
        MHAtoSHAConverter, then saves the converted weights.

        Returns:
            WeightLoader: Object containing the converted SHA weights.
        """
        weight_dir = self._get_weight_path(GGUFTensorMode.MHA)
        weights = WeightLoader.from_directory(weight_dir)
        converter = MHAtoSHAConverter(
            num_attention_heads=self.config.num_attention_heads,
            num_key_value_heads=self.config.num_key_value_heads,
        )
        weights = converter.split_data(weights)
        sha_weight_dir = self._get_weight_path(GGUFTensorMode.SHA)
        _ = WeightLoader(weights, cache_dir=sha_weight_dir)
        return weights

    def _get_weight_path(self, mode):
        """Get the directory path for storing weights in the specified mode.

        Args:
            mode (GGUFTensorMode): Tensor mode (MHA or SHA).

        Returns:
            pathlib.Path: Path to the weights directory.
        """
        stat = os.stat(self.model_path)
        dir_name = _hash(str(self.model_path), stat.st_size, stat.st_mtime, "WEIGHTS", mode)
        return pathlib.Path(os.path.join(self.cache_dir if self.cache_dir else self.tmp_path), dir_name)

    def _get_encoding_path(self, mode):
        """Get the directory path for storing encodings in the specified mode.

        Args:
            mode (GGUFTensorMode): Tensor mode (MHA or SHA).

        Returns:
            pathlib.Path: Path to the encodings directory.
        """
        stat = os.stat(self.model_path)
        dir_name = _hash(str(self.model_path), stat.st_size, stat.st_mtime, "ENCODINGS", mode)
        return pathlib.Path(
            os.path.join(self.cache_dir if self.cache_dir else self.tmp_path),
            dir_name,
        )

    @staticmethod
    def _update_tensor_names(parser_obj):
        """Update GGUF tensor names to MAD naming convention.

        Converts tensor names from GGUF format to MAD (Model Architecture Description)
        format, handles Linear to Conv transformations, and duplicates embedding weights
        as LM head weights if needed.

        Args:
            parser_obj (GGUFParser): GGUFParser object containing tensor and encoding information.
        """
        tensor = parser_obj.param_info["tensors"]
        updated_tensor = {}

        copy_embedding_weight = False
        if "output.weight" not in tensor:
            copy_embedding_weight = True

        for key, value in tqdm(tensor.items(), "Updating Parameter Names: "):
            # Update key
            key_splits = key.split(".")
            for i in range(len(key_splits)):
                if not key_splits[i].isdigit():
                    try:
                        key_splits[i] = GGUF_TO_MAD_TENSOR_NAME_MAP[key_splits[i]]
                    except KeyError as e:
                        _logger.error(
                            f"Unmapped tensor key component: {key} at position {i}\n Error Message: {str(e)}"
                        )
                        raise

            updated_key = ".".join(key_splits)

            # Update data if required Linear to Conv
            if len(value.shape) == 2:
                if updated_key == "model.embedding.weight":
                    updated_tensor[updated_key] = value
                    _logger.debug(f"{key} ==> {updated_key} || {updated_tensor[updated_key].shape}")
                    if copy_embedding_weight:
                        # Add duplicate of embedding weight as the output weight
                        updated_key = "model.lm_head.weight"
                    else:
                        continue

                shape = value.shape
                value = value.transpose(1, 0).reshape(1, 1, shape[1], shape[0])

            updated_tensor[updated_key] = value
            _logger.debug(f"{key} ==> {updated_key} || {updated_tensor[updated_key].shape}")

        parser_obj.param_info["tensors"] = updated_tensor

        encodings_map = parser_obj.param_info["encodings_map"]
        updated_enc_map = {}
        for key, value in tqdm(encodings_map.items(), "Updating Encoding Names: "):
            key_splits = key.split(".")
            for i in range(len(key_splits)):
                if not key_splits[i].isdigit():
                    key_splits[i] = GGUF_TO_MAD_TENSOR_NAME_MAP[key_splits[i]]

            updated_key = ".".join(key_splits)
            # Update name inside encoding value as well
            value["name"] = updated_key
            updated_enc_map[updated_key] = value
            if updated_key == "model.embedding.weight":
                if copy_embedding_weight:
                    updated_key = "model.lm_head.weight"
                    value["name"] = updated_key
                    updated_enc_map[updated_key] = value

        parser_obj.param_info["encodings_map"] = updated_enc_map
