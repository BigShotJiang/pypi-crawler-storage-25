# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import os
from functools import wraps
from pathlib import Path
from typing import Any, List, Optional

from qairt.utils.loggers import get_logger
from qti.aisw.graph_gen.architectures import AutoConfig, AutoModel
from qti.aisw.graph_gen.mad.graph.components import AllowedDtypes, TensorDataInfo
from qti.aisw.graph_gen.mad.utils import update_io_names

from .gguf_module import _hash, _move

_logger = get_logger(name="GGUFModule.graph_gen")


class GraphGenerator:
    """Generator for creating model graphs from GGUF configurations using MAD library.

    This class handles the generation of DLC files from model configurations,
    including caching of generated graphs for reuse.

    Attributes:
        cache_dir (Optional[str | os.PathLike]): Optional directory for caching generated graph artifacts.
    """

    def __init__(self, cache_dir: Optional[str | os.PathLike] = None):
        """Initialize GraphGenerator with an optional cache directory.

        Args:
            cache_dir (Optional[str | os.PathLike]): Optional directory for caching generated graph artifacts.
        """
        self.cache_dir = cache_dir

    @staticmethod
    def cache_generate_graph(func):
        @wraps(func)
        def generate_graph(
            self,
            config: AutoConfig,
            encoding_file: str,
            save_path: str,
            filename_prefix: str,
            weights: dict[Any, Any] | Any,
        ) -> List[str]:
            """
            Cache wrapper for generate graph method.
            """
            if encoding_file is not None:
                if not os.path.exists(encoding_file):
                    raise FileNotFoundError(f"Encoding file not found: {encoding_file}")
                stat = os.stat(encoding_file)
                hash_dir = _hash(
                    config.json(), encoding_file, stat.st_size, stat.st_mtime, save_path, filename_prefix
                )
            else:
                hash_dir = _hash(config.json(), save_path, filename_prefix)
            try:
                if self.cache_dir:
                    # Check if the artifacts are present or not
                    graph_cache_dir = Path(self.cache_dir) / hash_dir
                    artifacts_available = True
                    dlc_paths = GraphGenerator._get_dlc_paths(config.split, filename_prefix, graph_cache_dir)
                    for path in dlc_paths:
                        if not os.path.exists(path):
                            artifacts_available = False
                            break

                    if artifacts_available:
                        return dlc_paths

            except Exception as e:
                _logger.warning(f"Checking cached artifacts failed :(\nError Message: {e}")

            _logger.debug("Cache Miss! Generating Graphs...")
            dlc_paths = func(self, config, encoding_file, save_path, filename_prefix, weights)

            if self.cache_dir:
                # cache the results
                graph_cache_dir = Path(self.cache_dir) / hash_dir
                for path in dlc_paths:
                    _move(path, graph_cache_dir)

                dlc_paths = GraphGenerator._get_dlc_paths(config.split, filename_prefix, graph_cache_dir)

            return dlc_paths

        return generate_graph

    @cache_generate_graph
    def generate_graph(
        self,
        config: AutoConfig,
        encoding_file: str,
        save_path: str,
        filename_prefix: str,
        weights: dict[Any, Any] | Any,
    ) -> List[str]:
        """
        Generate model graphs and return paths to DLC files.

            Checks cache for existing graphs matching the configuration. If found,
            returns cached paths; otherwise, generates new graphs and caches them.

            Args:
                config (AutoConfig): Model configuration object containing architecture details.
                encoding_file (str): Path to the encoding file for quantization.
                save_path (str): Directory where DLC files will be saved.
                filename_prefix (str): Prefix for generated DLC filenames.
                weights (dict[Any, Any] | Any): Dictionary or object containing model weights.

            Returns:
                List[str]: List of paths to generated DLC files.
        """

        return self._generate_graph(config, encoding_file, save_path, filename_prefix, weights)

    @staticmethod
    def _generate_graph(
        config: AutoConfig,
        encoding_file: str,
        save_path: str,
        filename_prefix: str,
        weights: dict[Any, Any] | Any,
    ) -> List[str]:
        """
        Generate model graph using MAD Library and serialize to DLC files.

        Creates a model graph from the configuration, applies encodings for quantization,
        and exports the graph to DLC format. Handles both MHA (Multi-Head Attention)
        and SHA (Single-Head Attention) configurations.

        Args:
            config (AutoConfig): Model configuration containing architecture details (layers, heads, etc.).
            encoding_file (str): Path to encoding file for quantization parameters.
            save_path (str): Directory where generated DLC files will be saved.
            filename_prefix (str): Prefix for generated DLC filenames.
            weights (dict[Any, Any] | Any): Dictionary or object containing model tensor weights.

        Returns:
            List[str]: List of paths to generated DLC files (one per split if model is split).
        """
        model = AutoModel(config)
        input_ids = TensorDataInfo((config.batch, config.seq_length), AllowedDtypes.INT32)
        positional_ids_sin = TensorDataInfo((1, 1, config.seq_length, config.head_dim // 2))
        positional_ids_cos = TensorDataInfo((1, 1, config.seq_length, config.head_dim // 2))
        attention_mask = TensorDataInfo((1, 1, config.seq_length, config.max_position_embeddings))
        past_keys = [
            TensorDataInfo(
                (
                    config.batch,
                    config.num_key_value_heads,
                    config.head_dim,
                    config.max_position_embeddings - config.seq_length,
                )
            )
        ] * config.num_hidden_layers
        past_values = [
            TensorDataInfo(
                (
                    config.batch,
                    config.num_key_value_heads,
                    config.max_position_embeddings - config.seq_length,
                    config.head_dim,
                )
            )
        ] * config.num_hidden_layers
        if config.sha:
            past_keys = [
                TensorDataInfo(
                    (
                        config.num_key_value_heads,
                        config.batch,
                        config.head_dim,
                        config.max_position_embeddings - config.seq_length,
                    )
                )
            ] * config.num_hidden_layers
            past_values = [
                TensorDataInfo(
                    (
                        config.num_key_value_heads,
                        config.batch,
                        config.max_position_embeddings - config.seq_length,
                        config.head_dim,
                    )
                )
            ] * config.num_hidden_layers

        model.export(
            input_shapes=[
                input_ids,
                positional_ids_sin,
                positional_ids_cos,
                attention_mask,
                past_keys,
                past_values,
            ],
            weight_dict=weights,
            pre_serialization_callback=update_io_names,
            save_dir=save_path,
            filename_prefix=filename_prefix,
            encoding_file_path=encoding_file,
        )

        dlc_files = GraphGenerator._get_dlc_paths(config.split, filename_prefix, save_path)

        return dlc_files

    @staticmethod
    def _get_dlc_paths(split_cnt: int, filename_prefix: str, save_path: str) -> list[Any]:
        """
        Get paths to DLC files for the given configuration.

        Constructs file paths for DLC files based on the number of model splits.
        For split models, generates paths with split indices (e.g., model_1_of_4.dlc).
        For non-split models, generates a single path.

        Args:
            split_cnt (int): Number of splits in the model (1 for non-split models).
            filename_prefix (str): Prefix to use for DLC filenames.
            save_path (str): Directory path where DLC files are stored.

        Returns:
            list: List of paths to all DLC files for the configuration.
        """
        dlc_files = []
        if split_cnt > 1:
            for i in range(split_cnt):
                dlc_files.append(os.path.join(save_path, f"{filename_prefix}_{i + 1}_of_{split_cnt}.dlc"))
        else:
            dlc_files.append(os.path.join(save_path, filename_prefix + ".dlc"))
        return dlc_files
