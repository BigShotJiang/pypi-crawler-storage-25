# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

import os
import platform
from typing import Optional, Union, cast

from qairt.api.configs.common import BackendType
from qairt.api.configs.device import Device
from qairt.modules.genie_execution.genie_config import GenieConfig
from qairt.modules.genie_execution.genie_runner import GenieRunner
from qti.aisw.tools.core.utilities.devices.api.device_definitions import (
    DeviceInfo,
    DevicePlatformType,
)
from qti.aisw.tools.core.utilities.devices.api.device_interface import DeviceInterface


class GenieRunnerFactory:
    """Factory that selects and constructs the appropriate `GenieRunner` implementation.

    Encapsulates the platform-detection logic that determines whether native
    Python-binding execution is available and preferred for a given device
    configuration.
    """

    @staticmethod
    def _native_runner_available(device: Optional[Device]) -> bool:
        """Return True when native execution is available and preferred.

        Decision rules:

        - No device specified — assumes local execution; native runner is preferred.
        - Local device whose platform matches the current host — native runner is
          preferred (avoids subprocess overhead when running on the same machine).
        - Remote device, or local device whose platform does not match the host —
          native runner is not available; use the device (subprocess) runner.

        Args:
            device: The :class:`~qairt.api.configs.device.Device` to target, or
                ``None`` to indicate local execution.

        Returns:
            True if the native runner should be used.
        """
        if not device:
            return True

        # A device with no identifier is a local (same-machine) device.
        if device.identifier is None:
            device_type = device.type

            if (
                platform.system() == "Linux"
                and platform.machine() == "x86_64"
                and device_type == DevicePlatformType.X86_64_LINUX
            ):
                return True

            if platform.system() == "Windows":
                processor = platform.processor()
                if (
                    "AMD64" in processor or "Intel64" in processor
                ) and device_type == DevicePlatformType.X86_64_WINDOWS_MSVC:
                    return True
                if (
                    "ARM64" in processor or "AARCH64" in processor or "ARMv8" in processor
                ) and device_type == DevicePlatformType.WOS:
                    return True

        return False

    @staticmethod
    def create_t2t_runner(
        genie_config: GenieConfig,
        device: Optional[Device] = None,
        backend: Optional[BackendType] = None,
        qairt_sdk_root: Optional[Union[str, os.PathLike]] = None,
        clean_up: bool = True,
    ) -> GenieRunner:
        """Create and return the appropriate T2T runner for the given configuration.

        When native execution is available (see `_native_runner_available`), a
        `GenieNativeT2TRunner` is returned. Otherwise a `GenieT2TRunner`
        (device/subprocess runner) is returned.

        Args:
            genie_config: Genie configuration describing the model and execution
                parameters.
            device: Optional device object. When ``None`` or a local device matching
                the current platform, the native runner is used.
            backend: Backend type required by the device runner. Ignored when the
                native runner is selected.
            qairt_sdk_root: Path to the QAIRT SDK. Ignored when the native runner is
                selected.
            clean_up: Whether the device runner should remove on-device artifacts on
                destruction. Ignored when the native runner is selected.

        Returns:
            A concrete runner instance ready to be loaded via `GenieRunner.load`.
        """
        # Import here to avoid circular imports and to keep the factory lightweight
        # when only one runner type is needed.
        if GenieRunnerFactory._native_runner_available(device):
            from qairt.modules.genie_execution.native_t2t_module import GenieNativeT2TRunner

            return GenieNativeT2TRunner(genie_config=genie_config)
        else:
            from qairt.modules.genie_execution.genie_t2t_run_module import GenieT2TRunner

            backend_typed: BackendType = cast(BackendType, backend)
            assert device is not None  # guaranteed: _native_runner_available returns True when device is None
            device_info: Union[DeviceInfo, DeviceInterface] = cast(
                Union[DeviceInfo, DeviceInterface], device.info
            )
            return cast(
                GenieRunner,
                GenieT2TRunner(
                    genie_config,
                    backend_typed,
                    device_info,
                    qairt_sdk_root,
                    clean_up=clean_up,
                ),
            )
