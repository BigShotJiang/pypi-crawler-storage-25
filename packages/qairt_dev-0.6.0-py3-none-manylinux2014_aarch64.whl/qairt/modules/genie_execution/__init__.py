# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

import platform

from qairt.modules.genie_execution.genie_config import ExportFormat
from qairt.utils import loggers
from qairt.utils.os_utils import is_arm_64, is_windows

logger = loggers.get_logger(name=__name__)

if is_windows(platform.system()) and is_arm_64(platform.machine(), platform.processor()):
    raise ImportError(
        "Genie execution is temporarily disabled on Windows ARM due to a known issue. "
        "This will be resolved in an upcoming release."
    )

try:
    from qti.aisw.genai import genie
except ImportError as e:
    logger.warn(f'Failed to import libPyGenie. Exception: "{e}". Loading dummy stand-in instead.')
    from qairt.modules.genie_execution import dummy_lib_genie as genie
