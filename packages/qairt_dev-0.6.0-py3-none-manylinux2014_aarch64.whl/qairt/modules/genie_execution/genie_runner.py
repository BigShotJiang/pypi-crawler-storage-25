# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

import asyncio
from abc import ABC, abstractmethod
from typing import Optional

from qairt.gen_ai_api.executors.gen_ai_executable import GenerationExecutionResult
from qairt.modules.lora.lora_config import UseCaseRunConfig
from qti.aisw.tools.core.modules.api import AISWBaseModel


class GenieQueryConfig(AISWBaseModel):
    """Input configuration for `GenieRunner.query`.

    Wraps the pre-formatted prompt and an optional LoRA adapter configuration
    into an `AISWBaseModel` so that `GenieRunner.query` satisfies the module
    compliance requirement that all public methods consume a valid dataclass.

    Attributes:
        prompt: Pre-formatted prompt string ready for model inference.
        lora_config: Optional LoRA adapter configuration.
    """

    prompt: str
    lora_config: Optional[UseCaseRunConfig] = None


class GenieRunner(ABC):
    """Abstract base class for all Genie runners.

    Defines the minimal lifecycle interface shared by every runner:

    - `load`: prepare for execution (push artifacts to device, initialise
      bindings, etc.)
    - `query`: execute a prompt and return a :class:`GenerationExecutionResult`
    - `unload`: release resources

    Runners that maintain conversational state and support token streaming
    should extend `StreamableGenieRunner` instead.
    """

    @abstractmethod
    def load(self) -> None:
        """Prepare the runner for execution.

        For device-based runners this typically means pushing model artifacts
        and SDK libraries to the target. For native runners this is a no-op.
        """

    @abstractmethod
    def query(self, config: GenieQueryConfig) -> GenerationExecutionResult:
        """Execute a prompt and return the result.

        Args:
            config: Query configuration containing the pre-formatted prompt
                and an optional LoRA adapter configuration.

        Returns:
            A :class:`GenerationExecutionResult` (or subclass) containing the
            generated output and execution metrics.
        """

    @abstractmethod
    def unload(self) -> None:
        """Release resources held by the runner.

        For device-based runners this removes artifacts from the target device.
        For native runners this is a no-op.
        """


class StreamableGenieRunner(GenieRunner, ABC):
    """Extension of `GenieRunner` for runners that maintain conversational
    dialog state and support token-level streaming.

    Adds:

    - `stream_query`: stream generated tokens into an `asyncio.Queue`
    - `reset`: reset accumulated dialog context between conversations
    """

    @abstractmethod
    async def stream_query(
        self,
        prompt: str,
        streamer: asyncio.Queue,
    ) -> GenerationExecutionResult:
        """Execute a prompt in streaming mode.

        Pushes output tokens to `streamer` as they are generated. A `None`
        sentinel is placed on the queue to signal end-of-stream.

        Args:
            prompt: Pre-formatted prompt string.
            streamer: Queue that receives output chunks (`str`) and a final
                `None` sentinel.

        Returns:
            A :class:`GenerationExecutionResult` (or subclass) containing the
            full generated output and execution metrics.
        """

    @abstractmethod
    def reset(self) -> None:
        """Reset accumulated dialog context.

        Ensures the next call to `query` or `stream_query` starts a fresh
        conversation.
        """
