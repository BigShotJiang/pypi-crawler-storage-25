# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

from qairt.api.configs.common import AISWBaseModel, BackendType
from qairt.api.transforms.model_transformer_config import ModelTransformerConfig


class BuilderTransformerConfig(AISWBaseModel):
    model_transformer_config: ModelTransformerConfig = ModelTransformerConfig()
    """additional transformation-specific configurations"""
    backend: BackendType = BackendType.HTP
    """backend to use for the model"""
