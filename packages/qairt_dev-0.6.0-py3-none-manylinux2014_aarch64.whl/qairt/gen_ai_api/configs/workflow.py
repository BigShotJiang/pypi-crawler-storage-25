# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""Workflow graph types used by WorkflowBuilder to connect multiple models.

When a builder is provided multiple models it needs to know how to connect
them, if the expectation is to continue beyond preparing the model and into
generation.

This pipeline concept is intentionally kept free of Genie-specific details
(although it mirrors the structure closely). It informs the executor how to
assemble components and can be used to construct a Genie pipeline, a Genie
dialog, or a different runner entirely.

Note: Runtime details such as input/prompt are not represented here; this
module deals only with static composition.
"""

from __future__ import annotations

from enum import Enum
from os import PathLike
from typing import List, Optional, Tuple

from pydantic import BaseModel, ConfigDict, Field, model_validator


class WorkflowNodeRole(Enum):
    """Functional role of a node within a workflow pipeline."""

    # Input processing nodes
    TEXT_ENCODER = "textEncoder"
    """Processes text input into embeddings."""

    IMAGE_ENCODER = "imageEncoder"
    """Processes image input into features/embeddings."""

    LUT_ENCODER = "lutEncoder"
    """Lookup table encoding."""

    # Generation/transformation nodes
    DIFFUSION = "diffusion"
    """Applies diffusion-based generation/transformation."""

    LATENT_TRANSFORMER = "latentTransformer"
    """Transforms latent representations."""

    # Output generation nodes
    TEXT_GENERATOR = "textGenerator"
    """Produces text output."""

    IMAGE_DECODER = "imageDecoder"
    """Converts latents to images."""


class WorkflowNode(BaseModel):
    """A single node in a workflow graph.

    Carries the node's identity and functional role. The ``path``,
    ``tokenizer_path``, and ``config_path`` fields are optional: they are
    populated when constructing a graph for ``WorkflowBuilder.from_workflow``
    (so the builder knows where to find model artifacts) and left absent once
    the build phase is complete.
    """

    name: str = Field(..., description="Unique identifier for the node")
    role: WorkflowNodeRole = Field(
        ..., description="Functional role of the node (lutEncoder, textGenerator, …)"
    )
    output_callback_type: Optional[str] = Field(
        default=None,
        description="Optional callback type for node output",
    )
    path: Optional[PathLike] = Field(
        default=None,
        description="Path to model artifacts. Required for from_workflow(); absent post-build.",
    )
    tokenizer_path: Optional[PathLike] = Field(
        default=None,
        description=(
            "Explicit path to the tokenizer file or directory for this node. "
            "If omitted, convention-based discovery is used. "
            "Only relevant when using WorkflowBuilder.from_workflow()."
        ),
    )
    config_path: Optional[PathLike] = Field(
        default=None,
        description=(
            "Explicit path to the model config file or directory for this node. "
            "If omitted, convention-based discovery is used. "
            "Only relevant when using WorkflowBuilder.from_workflow()."
        ),
    )


class WorkflowGraph(BaseModel):
    """Directed graph describing the structure of a workflow pipeline.

    Holds the complete set of named, typed nodes and the directed edges
    (connections) that define how data flows between them.

    This is the single graph type used throughout the lifecycle:

    - **Pre-build** (``WorkflowBuilder.from_workflow``): nodes carry a ``path``
      so the builder can locate model artifacts.
    - **Post-build** (stored in ``WorkflowContainer``): paths are not needed and
      may be absent.

    The model is intentionally **frozen**: ``nodes`` and ``connections`` are
    stored as tuples and field reassignment is prohibited.  Any change to the
    graph requires constructing a new ``WorkflowGraph`` instance, which
    guarantees that ``validate_connections_reference_known_nodes`` always runs
    against the final state of the data.
    """

    model_config = ConfigDict(frozen=True)

    nodes: Tuple[WorkflowNode, ...] = Field(
        ..., description="Ordered tuple of node definitions in the pipeline"
    )
    connections: Tuple[Tuple[str, str], ...] = Field(
        ...,
        description=(
            "Tuple of directed edges defining data flow. Each entry is a two-element "
            "tuple ``(source_node, target_node)``."
        ),
    )

    @model_validator(mode="after")
    def validate_connections_reference_known_nodes(self) -> "WorkflowGraph":
        """Ensure every connection endpoint names a node that exists in *nodes*.

        Raises:
            ValueError: if any node name is duplicated, if any connection does
                not have exactly two elements, or if any connection endpoint
                does not match a declared node name.
        """
        node_names = [node.name for node in self.nodes]  # pylint: disable=not-an-iterable

        # Guard against duplicate node names so the set lookup below is sound.
        if len(node_names) != len(set(node_names)):
            seen: set[str] = set()
            duplicates: set[str] = set()
            for n in node_names:
                if n in seen:
                    duplicates.add(n)
                else:
                    seen.add(n)
            raise ValueError(f"Duplicate node name(s) in workflow graph: {sorted(duplicates)}")

        known = set(node_names)

        for i, connection in enumerate(self.connections):  # pylint: disable=not-an-iterable
            if len(connection) != 2:
                raise ValueError(
                    f"Connection at index {i} must have exactly 2 elements "
                    f"[source, target], got {len(connection)}: {connection}"
                )
            source, target = connection
            unknown = [n for n in (source, target) if n not in known]
            if unknown:
                raise ValueError(
                    f"Connection at index {i} references node(s) not declared in the graph: "
                    f"{unknown}. Declared nodes: {sorted(known)}"
                )

        return self
