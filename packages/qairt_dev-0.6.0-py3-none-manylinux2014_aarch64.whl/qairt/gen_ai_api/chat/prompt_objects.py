# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import json
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, overload


class BasePrompt(ABC):
    """Abstract base class for all prompt input types.

    Defines the common interface shared by :class:`PromptObject` (single-string
    prompts) and :class:`MessagesObject` (structured message-list prompts).
    Neither the ``prompt`` string attribute nor any other state is defined here;
    each concrete subclass owns only the data it actually needs.
    """

    @overload
    @abstractmethod
    def get_prompt(self, chat_template_config: None = ...) -> str: ...

    @overload
    @abstractmethod
    def get_prompt(self, chat_template_config: bool) -> List[Dict[str, Any]]: ...

    @abstractmethod
    def get_prompt(self, chat_template_config=None) -> Union[str, List[Dict[str, Any]]]:
        """Return the prompt in a form ready for execution.

        Args:
            chat_template_config: Optional chat template configuration.  When
                provided, implementations should return a structured form
                (e.g. a list of role/content dicts) suitable for template
                rendering.  When ``None``, a plain string should be returned
                where possible.
        """
        ...


class PromptObject(BasePrompt):
    """Handles string prompts with default fallback."""

    DEFAULT_SYSTEM_MESSAGE = "Be helpful but try to limit answers to 40 words."
    DEFAULT_USER_MESSAGE = "What can I do with a glass jar?"

    def __init__(self, prompt: Optional[str] = None):
        if prompt is not None and not isinstance(prompt, str):
            raise ValueError(f"Prompt must be a string or None, got {type(prompt)}")
        self.prompt = prompt or self.DEFAULT_USER_MESSAGE

    @overload
    def get_prompt(self, chat_template_config: None = ...) -> str: ...

    @overload
    def get_prompt(self, chat_template_config: bool) -> List[Dict[str, Any]]: ...

    def get_prompt(self, chat_template_config=None) -> Union[str, List[Dict[str, Any]]]:
        """Returns the final prompt ready for execution."""
        if chat_template_config:
            return [
                {"role": "system", "content": self.DEFAULT_SYSTEM_MESSAGE},
                {"role": "user", "content": self.prompt},
            ]

        # For default prompts, use legacy format
        if self.prompt == self.DEFAULT_USER_MESSAGE:
            return (
                "<|begin_of_text|>"
                f"<|start_header_id|>system<|end_header_id|>{self.DEFAULT_SYSTEM_MESSAGE}<|eot_id|>"
                f"<|start_header_id|>user<|end_header_id|>{self.prompt}<|eot_id|>"
                "<|start_header_id|>assistant<|end_header_id|>"
            )

        return self.prompt


class MessagesObject(BasePrompt):
    """Handles OpenAI/HuggingFace message format prompts.

    Each message must have a role and a content field. content may be either a
    plain string (text-only) or a list of typed content parts for multimodal
    inputs.

    Example:
        [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": "/path/to/image.raw"},
                    {"type": "text", "text": "Describe this image."},
                ],
            }
        ]
    """

    def __init__(self, messages: List[Dict[str, Any]]):
        super().__init__()
        # Validate messages format
        if not isinstance(messages, list) or len(messages) == 0:
            raise ValueError("Messages must be a non-empty list")

        for i, message in enumerate(messages):
            if not isinstance(message, dict):
                raise ValueError(f"Message {i} must be a dictionary")
            if "role" not in message or "content" not in message:
                raise ValueError(f"Message {i} must have 'role' and 'content' keys")
            if not isinstance(message["content"], (str, list)):
                raise ValueError(f"Message {i} 'content' must be a string or a list of content parts")

            if isinstance(message["content"], list):
                for j, part in enumerate(message["content"]):
                    if not isinstance(part, dict):
                        raise ValueError(f"Message {i}, content part {j} must be a dictionary")
                    if "type" not in part:
                        raise ValueError(f"Message {i}, content part {j} must have a 'type' key")
                    if part["type"] == "image" and "image" not in part:
                        raise ValueError(
                            f"Message {i}, content part {j} has type 'image' but is missing the 'image' key"
                        )
                    if part["type"] == "text" and "text" not in part:
                        raise ValueError(
                            f"Message {i}, content part {j} has type 'text' but is missing the 'text' key"
                        )

        self.messages = messages

    def get_image_path(self) -> Optional[str]:
        """Returns the first image path found in multimodal content parts, or None.

        Scans each message's content for a part with {"type": "image", "image": ...}
        and returns the value of the "image" key.

        Returns:
            The image path string, or None if no image part is found.
        """
        for message in self.messages:
            content = message.get("content")
            if isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "image":
                        return part.get("image")
        return None

    @classmethod
    def from_json(cls, messages_input: Union[str, Path]) -> "MessagesObject":
        """Creates a MessagesObject from a JSON string or file path.

        Args:
            messages_input: JSON string or path to a JSON file containing messages.

        Returns:
            Instance created from the parsed JSON.

        Raises:
            json.JSONDecodeError: If JSON parsing fails.
            IOError: If file reading fails.
            ValueError: If the messages format is invalid.
        """
        if isinstance(messages_input, Path) or os.path.isfile(messages_input):
            with open(messages_input, "r") as f:
                messages = json.load(f)
        else:
            messages = json.loads(messages_input)

        return cls(messages)

    @overload
    def get_prompt(self, chat_template_config: None = ...) -> str: ...

    @overload
    def get_prompt(self, chat_template_config: bool) -> List[Dict[str, Any]]: ...

    def get_prompt(self, chat_template_config=None) -> Union[str, List[Dict[str, Any]]]:
        """Returns messages as-is - requires chat template for processing."""
        if chat_template_config:
            return self.messages

        # Messages format requires a chat template - no fallback
        raise ValueError("Messages format input requires a chat template to be configured.")
