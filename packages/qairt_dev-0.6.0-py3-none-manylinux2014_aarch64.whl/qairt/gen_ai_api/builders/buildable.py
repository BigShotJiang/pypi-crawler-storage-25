# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
from abc import ABC, abstractmethod

from qairt.gen_ai_api.containers.gen_ai_containerable import GenAIContainerable


class Buildable(ABC):
    """
    Abstract base builder defining the build contract.
    """

    @abstractmethod
    def build(self) -> GenAIContainerable:
        """
        Build and return a GenAIContainer.
        """
        raise NotImplementedError("build must be implemented by subclasses")
