# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import os
import tempfile
from os import PathLike
from pathlib import Path
from typing import Any, List, Optional

from qairt import DlcModule, Model
from qairt.api.compiled_model import CompiledModel
from qairt.api.configs.common import BackendType
from qairt.api.converter.converter_config import CalibrationConfig, ConverterConfig
from qairt.api.profiler.resource_profiler.decorator import resource_profile
from qairt.api.transforms.model_transformer_config import (
    ARn_ContextLengthConfig,
    MhaConfig,
    ModelTransformerConfig,
    SplitModelConfig,
)
from qairt.gen_ai_api.builders.gen_ai_builder import GenAIBuilder
from qairt.gen_ai_api.builders.htp_mixin import HTPMixin
from qairt.gen_ai_api.configs.gen_ai_config import GenAIConfig
from qairt.gen_ai_api.containers.llm_container import LLMContainer
from qairt.modules.genie_execution.genie_config import PositionalEncoding
from qairt.modules.gguf_module import GGUFModule, GGUFTensorMode
from qairt.modules.gguf_module.graph_gen import GraphGenerator
from qairt.utils.loggers import get_logger
from qti.aisw.converters.gguf_builder.utils import (
    ModelSection,
)
from qti.aisw.graph_gen.architectures import AutoConfig
from qti.aisw.graph_gen.mad.data_mha_to_sha import MHAtoSHAConverter
from qti.aisw.graph_gen.mad.utils import namespace_to_dict

_logger = get_logger(name="GGUFBuilder.HTP")


USE_ORT_PATH = False

# TODO: Update the class inheritance once ONNX related code is separated from the GenAIBuilderHTP


@resource_profile
class GGUFBuilderHTP(GenAIBuilder, HTPMixin):
    """Builder for GGUF models targeting the HTP backend.

    This class provides functionality to compile and build GGUF format models
    for execution on Qualcomm HTP backend.

    Attributes:
        framework_model_path (Path): Resolved path to the GGUF model file.
        cache_dir (Optional[str | PathLike]): Directory for caching artifacts.
        pretrained_model_config: Configuration extracted from the GGUF file.
    """

    GRAPH_MODE = GGUFTensorMode.SHA

    def __init__(
        self,
        framework_model_path: str | PathLike,
        encoding_path: Optional[str | PathLike] = None,
        cache_dir: Optional[str | PathLike] = None,
        weight_sharing: bool = True,
        multi_graph: bool = False,
    ):
        """
        Initializes a GGUFBuilderHTP instance.

        This method initializes a GGUFBuilderHTP instance with the provided model path and configuration.
        It sets up the necessary attributes for the builder, including the transformation
        configuration, and compilation options.

        Args:
            framework_model_path (str | PathLike): The path to the gguf model path.
            encoding_path (str | PathLike), Optional: Path of the encoding path in case user wants to provide
                additional calibrated encoding information.
            cache_dir (str | PathLike), Optional: user-provided root directory where artifacts
                may be stored and referenced in subsequent builder operations.
            weight_sharing (bool): Flag to enable weight sharing during model compilation.
            multi_graph (bool): Flag to enable multi-graph with multiple context lengths.

        Raises:
            FileNotFoundError: If the model file does not exist.
        """

        if not os.path.exists(framework_model_path):
            raise FileNotFoundError(f"Input Model File not found: {framework_model_path}")

        self.framework_model_path = Path(framework_model_path).resolve()

        self._prompt_processing_arn = 128 if encoding_path else 64

        HTPMixin.__init__(self, cache_dir=cache_dir, weight_sharing=weight_sharing)

        self.cache_dir = cache_dir
        # Extract the pretrained model config from the GGUF File and create a gen_ai_config
        gguf = GGUFModule(self.framework_model_path, cache_dir)
        self.pretrained_model_config = gguf.config

        # Initializing the GenAIBuilder
        gen_ai_config: GenAIConfig = GenAIBuilder._create_config_from_pretrained(self.pretrained_model_config)  # type: ignore[arg-type]
        GenAIBuilder.__init__(self, framework_model_path, gen_ai_config, BackendType.HTP)

        model_section_size_info = gguf.get_model_section_size_info()

        # Based on the parameter count of a decoder block decide the number of splits.
        num_splits = GGUFBuilderHTP._get_split_count(
            gen_ai_config.n_layer, model_section_size_info[ModelSection.HIDDEN_LAYER]
        )
        _logger.info(f"Automatically decided number of model splits: {num_splits}")

        split_lm_head = False
        split_embedding = False

        # TODO: MAD config does not support split marker for Embedding layer and LM_HEAD as of now.
        #  Once the support is added. Uncomment the logic below to dynamically decide the values of these flags
        # split_embedding = self._should_split_embedding(model_section_size_info[ModelSection.EMBEDDING])
        # split_lm_head = split_embedding

        self.set_transformation_options(
            config=ModelTransformerConfig(
                arn_cl_options=ARn_ContextLengthConfig(
                    auto_regression_number=[1, self._prompt_processing_arn]
                ),
                split_model=SplitModelConfig(
                    num_splits=num_splits, split_lm_head=split_lm_head, split_embedding=split_embedding
                ),
                mha_config=MhaConfig(),
            ),
        )

        self.weight_sharing = weight_sharing
        self.multi_graph = multi_graph
        self.encodings_path = encoding_path

    @property
    def weight_sharing(self) -> bool:
        """
        Getter for weight_sharing.

        Returns:
            bool: Whether weight sharing is enabled.
        """
        return (
            len(self._transformation_config.model_transformer_config.arn_cl_options.auto_regression_number)
            > 1
        )

    @weight_sharing.setter
    def weight_sharing(self, value: bool):
        """
        Setter for weight_sharing.

        Args:
            value (bool): Whether to enable weight sharing.
        """
        _logger.debug(f"Enable weight sharing set to: {value}")

        # Reset AR config to [1, self._prompt_processing_arn] when weight sharing is updated to True
        if (
            value
            and len(
                self._transformation_config.model_transformer_config.arn_cl_options.auto_regression_number
            )
            <= 2
        ):
            self._transformation_config.model_transformer_config.arn_cl_options.auto_regression_number = [
                1,
                self._prompt_processing_arn,
            ]
            _logger.debug(f"AR config reset to [1, {self._prompt_processing_arn}].")

    @property
    def multi_graph(self) -> bool:
        """
        Getter for multi_graph.

        Returns:
            bool: Whether multi-graph (multiple context lengths) is enabled.
        """
        return len(self._transformation_config.model_transformer_config.arn_cl_options.context_length) > 1

    @multi_graph.setter
    def multi_graph(self, value: bool):
        """
        Setter for multi_graph.

        Args:
            value (bool): Whether to enable multi-graph with multiple context lengths.
        """
        _logger.debug(f"Multi-graph set to: {value}")

        if value:
            self._transformation_config.model_transformer_config.arn_cl_options.context_length = [
                512,
                1024,
                2048,
                3072,
                4096,
            ]
            _logger.debug("Context length set to multi-graph: [512, 1024, 2048, 3072, 4096]")
        else:
            self._transformation_config.model_transformer_config.arn_cl_options.context_length = [4096]
            _logger.debug("Context length set to single value: [4096]")

    @property
    def encodings_path(self) -> Optional[str | os.PathLike]:
        """
        Gets the path to the encodings.

        Returns:
            Optional[str | os.PathLike]: The path to the encodings, or None if not set.
        """
        return self._encodings_path

    @encodings_path.setter
    def encodings_path(self, encodings_path: Optional[str | os.PathLike] = None):
        """
        Sets the path to the encodings.

        Args:
            encodings_path (Optional[str | os.PathLike], optional): The path to the encodings. Defaults to None.
        """
        if encodings_path:
            if not os.path.exists(encodings_path):
                raise FileNotFoundError(f"Input Encoding File not found: {encodings_path}")
            self._prompt_processing_arn = 128
        else:
            self._prompt_processing_arn = 64

        if self.weight_sharing:
            self.weight_sharing = True  # To propagate the effect of updated ARN  value

        self._encodings_path = encodings_path

    def _assert_configurations_are_valid(self):
        """
        Validates the builder's configurations.

        For compilation: there must be at least one target DSP architecture.
        """
        if (
            not self._compilation_config
            or not self._compilation_config.device_custom_configs
            or not self._compilation_config.device_custom_configs[0].dsp_arch
        ):
            raise ValueError(
                "Target DSP architecture required.  Please set_compilation_options to "
                "include soc_details or add a device_custom_config to set the target DSP architecture."
            )
        if not self._transformation_config:
            raise ValueError(
                "Transofrmation Configuration required.  Please set options via set_transformation_options()."
            )
        for c in self._compilation_config.device_custom_configs:
            if c.dsp_arch == "v0":
                raise ValueError("Target DSP architecture undetected or unknown.")
        if (
            self._prepare_embedding_lut
            and not self._transformation_config.model_transformer_config.split_model.split_embedding
        ):
            _logger.warning("'split_embedding' not enabled - skipping embedding LUT preparation.")
            self._prepare_embedding_lut = False
        if self._prepare_embedding_lut and not self.config.n_embd:
            _logger.warning("'hidden_size' not set - skipping embedding LUT preparation.")
            self._prepare_embedding_lut = False

    @classmethod
    def from_pretrained(
        cls,
        pretrained_model_path: str | os.PathLike,
        encoding_path: Optional[str | os.PathLike] = None,
        cache_root: Optional[str | os.PathLike] = None,
    ) -> "GGUFBuilderHTP":
        """
        This method creates a GGUFBuilderHTP instance from a pretrained model by loading the model's
        configuration and creating a new instance with the loaded configuration.

        Args:
            pretrained_model_path (str | PathLike): The path to the pretrained model.
            encoding_path (str | PathLike), Optional: Path of the encoding path in case user wants to provide
                additional calibrated encoding information.
            cache_root (str | PathLike) Optional: user-provided root directory where artifacts
                may be stored and referenced in subsequent builder operations.

        Returns:
            GGUFBuilderHTP: An instance of GGUFBuilderHTP.

        Raises:
            FileNotFoundError: If the pretrained model path does not exist.
        """

        if not os.path.exists(pretrained_model_path):
            raise FileNotFoundError(f"Pretrained model path '{pretrained_model_path}' does not exist")

        builder = cls(pretrained_model_path, encoding_path=encoding_path, cache_dir=cache_root)

        return builder

    @staticmethod
    def _should_split_embedding(embedding_size: int) -> bool:
        """Determine whether the embedding layer should be a separate split.

        Uses a heuristic threshold of 1GB to decide if the embedding layer
        should be created as a separate split.

        Args:
            embedding_size (int): Size of the embedding layer in bytes.

        Returns:
            bool: True if embedding should be split, False otherwise.
        """
        return embedding_size >= 1024 * 1024 * 1024

    def set_conversion_options(
        self, config: ConverterConfig, calibration_config: Optional[CalibrationConfig] = None
    ):
        raise NotImplementedError("Conversion option is not implemented in GGUF Builder.")

    @staticmethod
    def _get_split_count(n_layers, hidden_layer_size):
        """Determine the number of splits required for the model.

        Split count is decided based on the heuristic that each split should be
        at most 2GB in size.

        Args:
            n_layers (int): Number of hidden layers present in the model.
            hidden_layer_size (int): Size of a single hidden layer in bytes.

        Returns:
            int: Number of splits required.
        """
        total_hidden_layer_size = n_layers * hidden_layer_size
        n_split = 1 + total_hidden_layer_size // (
            1024 * 1024 * 1024 * 2
        )  # To keep the per split size upto 2 GBs

        while n_split <= n_layers // 2:
            if n_layers % n_split == 0:
                return n_split
            n_split += 1
        return n_layers

    def build(self) -> LLMContainer:
        """Build a GenAIContainer instance from the GGUF file.

        The build process:
            - Extracts the weights and encodings from the GGUF file
            - Constructs the graph as per the model architecture info in GGUF metadata
            - Quantizes the weights as per the encoding
            - Compiles the model ahead-of-time into a compiled model instance

        Examples:
            .. code-block:: python

                from qairt.gen_ai_api.gen_ai_builder_factory import GenAIBuilderFactory

                # Create a gen AI builder instance and set the appropriate targets
                gen_ai_builder = GenAIBuilderFactory.create(
                    "model_dir/model_q4-0.gguf", "HTP", cache_root=CACHE_ROOT
                )
                gen_ai_builder.set_targets(["chipset:SC8380XP"])

                # Build the model
                gen_ai_container = gen_ai_builder.build()

        Returns:
            GenAIContainer: An instance of GenAIContainer, which can be used to create
                an executor to execute the model, or saved to disk as a directory of
                artifacts generated during build.
        """

        self._assert_configurations_are_valid()

        if not os.getenv("QAIRT_TMP_DIR"):
            _logger.warning(
                "QAIRT_TMP_DIR is not set. "
                "Be aware that building large models may require large amounts of temporary space. "
                "Set QAIRT_TMP_DIR to avoid default temporary space usage."
            )

        save_path = os.getenv("QAIRT_TMP_DIR", default=tempfile.gettempdir())
        os.makedirs(save_path, exist_ok=True)

        # Generate SHA graph for ARN(1, 128) based on the arn config with encoding applied.
        # transformed_models = [[arn1_split_1,.., arn1_split_n], [arn128_split_1,.., arn128_split_n]]

        # Step 1: Initialize the model config
        config = AutoConfig(**namespace_to_dict(self.pretrained_model_config))
        config.split = self._transformation_config.model_transformer_config.split_model.num_splits
        mode = self.GRAPH_MODE
        _logger.info(f"Graph Mode: {mode.name}")
        if mode == GGUFTensorMode.SHA:
            config.sha = True
        else:
            config.sha = False

        # Step 2: Instantiate the GGUFModule
        gguf = GGUFModule(self.framework_model_path, self.cache_dir)
        weights = gguf.get_weights(mode)
        if not self.encodings_path:
            encoding_file = gguf.get_encoding_file(mode)
        else:
            _logger.info("Calibration Encoding given.")
            encoding_file = self.encodings_path
            if config.sha:
                _logger.info("Converting calibration encoding into SHA format")
                encoding_file = os.path.join(save_path, "sha_processed_" + Path(self.encodings_path).name)
                converter = MHAtoSHAConverter.from_config(config)
                converter.generate_sha_encodings(self.encodings_path, encoding_file)

        # Step 3: Generate the required graphs
        graph_gen = GraphGenerator(self.cache_dir)
        dlc_files = []
        for arn in self._transformation_config.model_transformer_config.arn_cl_options.auto_regression_number:
            for cl in self._transformation_config.model_transformer_config.arn_cl_options.context_length:
                config.seq_length = arn
                config.max_position_embeddings = cl
                _logger.info(f"Generating Graph for ARN {arn} CL {cl}")
                build_type = f"{config.num_hidden_layers}_ar{config.seq_length}"
                filename_prefix = f"{mode.name}_{build_type}"
                dlc_files_per_arn = graph_gen.generate_graph(
                    config, encoding_file, save_path, filename_prefix, weights
                )
                dlc_files.append(dlc_files_per_arn)

        # Cleanup weights
        del weights

        # Step 4: Compile the generated graphs and create the LLMContainer Object
        # Update the gen_ai_config
        self.config.kv_dim = config.head_dim
        self.config.positional_encoding = PositionalEncoding(
            type="rope",
            rope_dim=config.head_dim // 2,
            rope_theta=config.rope_theta,
            rope_scaling=config.rope_scaling,
        )

        compiled_models = self._compile_dlc_files(dlc_files)
        return LLMContainer(
            compiled_models, self.config, BackendType.HTP, compile_config=self._compilation_config
        )

    def _compile_dlc_files(self, dlc_files):
        assert self._compilation_config is not None
        assert dlc_files is not None and len(dlc_files) > 0
        prepared_models: List[CompiledModel] = []

        if self._compilation_config and self._compilation_config.graph_custom_configs:
            for split_idx, dlc_path_per_split in enumerate(zip(*dlc_files)):
                _logger.debug(f"For split index: {split_idx}")
                _logger.debug("Models:  {dlc_path_per_split}")
                models_for_split = []
                for i, dlc_path in enumerate(dlc_path_per_split):
                    # Create Model object
                    dlc_module = DlcModule.load(dlc_path)
                    model = Model(module=dlc_module)

                    new_graph_config: Any = self._compilation_config.graph_custom_configs[0].model_copy()
                    new_graph_config.name = model.name
                    self._compilation_config.graph_custom_configs.append(new_graph_config)
                    _logger.debug(f"Created new graph config for model: {model.name}")

                    if self._compilation_config.graph_custom_configs[0].name == "placeholder":
                        self._compilation_config.graph_custom_configs.pop(0)

                    models_for_split.append(model)
                    _logger.debug(
                        f"Updated graph names for split {split_idx + 1}: {[model.name for model in models_for_split]}"
                    )

                compiled_model = self.compile(models_for_split, config=self._compilation_config)
                prepared_models.append(compiled_model)

        return prepared_models
