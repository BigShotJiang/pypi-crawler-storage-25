# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import json
import os
from datetime import datetime
from os import PathLike
from pathlib import Path
from typing import Any, List, Optional, Tuple, Union

import onnx

from qairt.api.compiled_model import CompiledModel
from qairt.api.compiler.config import CompilerModes
from qairt.api.configs.common import BackendType
from qairt.api.converter.converter_config import CalibrationConfig, ConverterConfig
from qairt.api.profiler.resource_profiler.decorator import _profiling_enabled, resource_profile
from qairt.api.profiler.resource_profiler.events import GenAIBuildEvents
from qairt.api.profiler.resource_profiler.resource_profiler import ResourceProfiler
from qairt.api.transforms.model_transformer_config import (
    ARn_ContextLengthConfig,
    MhaConfig,
    ModelTransformerConfig,
    SplitModelConfig,
)
from qairt.gen_ai_api.builders.gen_ai_builder import GenAIBuilder
from qairt.gen_ai_api.builders.gen_ai_utils import (
    _fix_missing_past_kv_out_encodings,
    adjust_split2_encodings_for_4bit_embedding,
    count_parameters,
    dump_embedding_table,
    gen_kv_format_config,
    get_embedding_length,
    get_embedding_node_proto,
    get_input_layout,
    get_kv_dim,
    get_pos_id_dim,
    get_positional_encodings_type,
    get_tensor_values,
    load_pretrained_config,
)
from qairt.gen_ai_api.builders.htp_mixin import HTPMixin
from qairt.gen_ai_api.chat.chat_templates import (
    ChatTemplate,
    CustomChatTemplate,
    HFChatTemplate,
    NullChatTemplate,
)
from qairt.gen_ai_api.configs.eaglet_config import EagletBuilderConfig, EagletRunConfig
from qairt.gen_ai_api.configs.gen_ai_config import EmbeddingConfig, GenAIConfig
from qairt.gen_ai_api.configs.lade_config import LadeBuilderConfig, LadeRunConfig
from qairt.gen_ai_api.configs.ssd_config import SsdBuilderConfig
from qairt.gen_ai_api.containers.llm_container import LLMContainer
from qairt.gen_ai_api.speculative_decoding.ssd_forecast_kvcache_prefix import process_ssd_param
from qairt.gen_ai_api.speculative_decoding.ssd_forecast_token_embedding import (
    add_forecast_token_embeddings,
)
from qairt.modules.genie_execution.genie_config import (
    EagletConfig,
    LadeConfig,
    PositionalEncoding,
    PositionalEncodingType,
    RopeScaling,
    Sampler,
    SsdRunConfig,
)
from qairt.modules.lora.lora_config import (
    LoraBuilderInputConfig,
    LoraBuilderOutputConfig,
    get_adapter_count_by_use_case,
)
from qairt.utils.loggers import get_logger
from qti.aisw.tools.core.utilities.framework.frameworks.onnx.onnx_model import ExportedFiles

_logger = get_logger(name="GenAIBuilder.HTP")


@resource_profile
class GenAIBuilderHTP(GenAIBuilder, HTPMixin):
    """
    GenAIBuilderHTP builds a GenAIContainer object for the HTP backend.

    Key Configuration Methods:
        - set_targets(): Configure target device/chipset
        - set_transformation_options(): Configure model splitting and transformations
        - set_conversion_options(): Configure model into the internal representation
        - set_compilation_options(): Configure compilation options for the model

    """

    def __init__(
        self,
        framework_model_path: str | PathLike,
        config: GenAIConfig,
        cache_dir: Optional[str | PathLike] = None,
        weight_sharing: bool = True,
        multi_graph: bool = False,
        native_kv: bool = False,
        skip_ar_conversion: bool = False,
    ):
        """
        Initializes a GenAIBuilderHTP instance.

        This method initializes a GenAIBuilderHTP instance with the provided model path and configuration.
        It sets up the necessary attributes for the builder, including the transformation
        configuration, and compilation options.

        Args:
            framework_model_path (str | PathLike): The path to the model to be prepared.
            config (GenAIConfig): The LLM configuration object.
            cache_dir (str | PathLike), Optional: user-provided root directory where artifacts
                may be stored and referenced in subsequent builder operations.
            weight_sharing (bool): Flag to enable weight sharing during model compilation.
            multi_graph (bool): Flag to enable multi-graph with multiple context lengths.
            native_kv (bool): Flag to enable native KV cache format optimization.
            skip_ar_conversion (bool): When True, AR conversion is skipped and only context
                length varies. Weight sharing is effectively disabled.

        Returns:
            None
        """

        GenAIBuilder.__init__(self, framework_model_path, config, BackendType.HTP)
        HTPMixin.__init__(self, cache_dir=cache_dir, weight_sharing=weight_sharing)
        self._confirm_framework_model_path()

        self._validate_config()

        self._chat_template: Union[NullChatTemplate, HFChatTemplate, CustomChatTemplate] = NullChatTemplate()

        params = count_parameters(self.framework_model_path)
        num_splits = 3 + params // (1024 * 1024 * 1024 * 2)

        self.set_transformation_options(
            config=ModelTransformerConfig(
                arn_cl_options=ARn_ContextLengthConfig(),
                split_model=SplitModelConfig(num_splits=num_splits, split_lm_head=True, split_embedding=True),
                mha_config=MhaConfig(),
            ),
        )

        # TODO: MoE can further impact transformation options. Possible that expert_subselection==false should set overridden
        # subselection to num_experts. Also, we may want to set ARN max to 256 if op-predication is enabled but
        # that needs extra confirmation from the HTP team.
        if self.config.expert_config:
            moe_kwargs: dict = {}
            self._transformation_config.model_transformer_config.adapt_moe = moe_kwargs
            _logger.debug(
                f"Identified expert configuration. "
                f"MoE transformations will be performed with this configuration: {moe_kwargs}"
            )
        # skip_ar_conversion must be set first so that other AR-dependent attributes are initialized correctly
        self.skip_ar_conversion = skip_ar_conversion
        self.weight_sharing = weight_sharing
        self.multi_graph = multi_graph
        self.native_kv = native_kv

        self.set_conversion_options(ConverterConfig(), CalibrationConfig(act_precision=16, bias_precision=32))
        self._encodings_path: Optional[str | PathLike] = None
        self._lora_config: Optional[LoraBuilderInputConfig] = None
        self._speculative_config: Optional[EagletBuilderConfig | LadeBuilderConfig | SsdBuilderConfig] = None

    @property
    def weight_sharing(self) -> bool:
        """
        Getter for weight_sharing.

        Returns:
            bool: Whether weight sharing is enabled.
        """
        return (
            len(self._transformation_config.model_transformer_config.arn_cl_options.auto_regression_number)
            > 1
        )

    @weight_sharing.setter
    def weight_sharing(self, value: bool):
        """
        Setter for weight_sharing.

        Args:
            value (bool): Whether to enable weight sharing.

        Raises:
            RuntimeError: If value is True, auto_regression_number has fewer than 2 values,
                and skip_ar_conversion is enabled (a new AR variant cannot be assigned).
            RuntimeError: If value is False and auto_regression_number has more than one value.
        """
        _logger.debug(f"Weight sharing set to: {value}")

        current_arn = (
            self._transformation_config.model_transformer_config.arn_cl_options.auto_regression_number
        )

        if value:
            if len(current_arn) >= 2:
                _logger.debug(f"AR config already set to {current_arn}, leaving unchanged.")
            else:
                if self.skip_ar_conversion:
                    raise RuntimeError(
                        "Cannot enable weight sharing: skip_ar_conversion is True so a new AR "
                        "variant cannot be assigned. Disable skip_ar_conversion first."
                    )
                self._transformation_config.model_transformer_config.arn_cl_options.auto_regression_number = [
                    1,
                    128,
                ]
                _logger.debug(f"AR config set to [1, 128]. Changing from previous arn {current_arn}")
        else:
            if len(current_arn) > 1:
                raise RuntimeError(
                    f"Cannot disable weight sharing: auto_regression_number has {len(current_arn)} values "
                    f"({current_arn}). Multiple models cannot be prepared unless weight sharing is enabled."
                )
            _logger.debug(f"AR config unchanged at {current_arn}.")

    @property
    def multi_graph(self) -> bool:
        """
        Getter for multi_graph.

        Returns:
            bool: Whether multi-graph (multiple context lengths) is enabled.
        """
        return len(self._transformation_config.model_transformer_config.arn_cl_options.context_length) > 1

    @multi_graph.setter
    def multi_graph(self, value: bool):
        """
        Setter for multi_graph.

        Args:
            value (bool): Whether to enable multi-graph with multiple context lengths.
        """
        _logger.debug(f"Multi-graph set to: {value}")

        if value:
            self._transformation_config.model_transformer_config.arn_cl_options.context_length = [
                512,
                1024,
                2048,
                3072,
                4096,
            ]
            _logger.debug("Context length set to multi-graph: [512, 1024, 2048, 3072, 4096]")
        else:
            self._transformation_config.model_transformer_config.arn_cl_options.context_length = [4096]
            _logger.debug("Context length set to single value: [4096]")

    @property
    def native_kv(self) -> bool:
        """
        Getter for native_kv.

        Returns:
            bool: Whether native KV cache format optimization is enabled.
        """
        return self._native_kv

    @native_kv.setter
    def native_kv(self, value: bool):
        """
        Setter for native_kv.

        Args:
            value (bool): Whether to enable native KV cache format optimization.
                Only supported with AR32, AR64, AR128, and AR256.

        Raises:
            ValueError: If value is True and the current AR configuration contains values
                other than 32, 64, 128 and 256.
        """
        _logger.debug(f"Native KV set to: {value}")
        self._native_kv = value
        if value:
            if self._transformation_config.model_transformer_config.mha_config is None:
                self._transformation_config.model_transformer_config.mha_config = MhaConfig()
            mha_config = self._transformation_config.model_transformer_config.mha_config
            if not mha_config.permute_kv_cache_io:
                mha_config.permute_kv_cache_io = True
                _logger.warning(
                    "native_kv enabled: automatically setting permute_kv_cache_io=True in MhaConfig."
                )
            supported_arns = {32, 64, 128, 256}
            current_arns = (
                self._transformation_config.model_transformer_config.arn_cl_options.auto_regression_number
            )
            unsupported_arns = [arn for arn in current_arns if arn not in supported_arns]
            if unsupported_arns:
                raise ValueError(
                    f"Native KV optimization only supports AR32, AR64, AR128, and AR256. "
                    f"Unsupported ARNs found: {unsupported_arns}. "
                    f"Please update the AR configuration to use only AR32, AR64, AR128, and/or AR256."
                )

    @property
    def skip_ar_conversion(self) -> bool:
        """
        Getter for skip_ar_conversion.

        Returns:
            bool: Whether AR conversion is skipped (only context length varies).
                Derived from the presence of sentinel value ``0`` in auto_regression_number.
        """
        return self._transformation_config.model_transformer_config.arn_cl_options.skip_ar_conversion

    @skip_ar_conversion.setter
    def skip_ar_conversion(self, value: bool) -> None:
        """
        Setter for skip_ar_conversion.

        Args:
            value (bool): When True, inserts sentinel ``0`` into auto_regression_number so that
                AR conversion is skipped and only context length varies.
                When False, removes ``0`` from auto_regression_number.
        """
        _logger.debug(f"skip_ar_conversion set to: {value}")
        arns = self._transformation_config.model_transformer_config.arn_cl_options.auto_regression_number
        if value:
            if len(arns) > 1:
                _logger.warning(
                    "skip_ar_conversion is True but multiple auto_regression_numbers are configured. "
                    "Only the original model will be used — weight sharing is effectively disabled."
                )
            self._transformation_config.model_transformer_config.arn_cl_options.auto_regression_number = [0]
        else:
            updated = [ar for ar in arns if ar != 0]
            self._transformation_config.model_transformer_config.arn_cl_options.auto_regression_number = (
                updated if updated else ARn_ContextLengthConfig().auto_regression_number
            )

    def _validate_config(self):
        onnxmodel = onnx.load(self.framework_model_path, load_external_data=False)
        cl, arn = get_tensor_values(onnxmodel)
        if self.config.context_length != cl:
            self.config.context_length = cl
        try:
            kv_dim = get_kv_dim(onnxmodel)
            self.config.kv_dim = kv_dim
            if not self.config.n_embd:
                self.config.n_embd = get_embedding_length(onnxmodel)

        except KeyError:
            pass
        try:
            positional_encoding_type = get_positional_encodings_type(onnxmodel, arn, cl)
            self.config.positional_encoding = PositionalEncoding(type=positional_encoding_type)
            self.config.positional_encoding.rope_dim = None
            self.config.positional_encoding.rope_theta = None
            if positional_encoding_type == PositionalEncodingType.ROPE:
                try:
                    pos_id_dim = get_pos_id_dim(onnxmodel)
                    self.config.positional_encoding.rope_dim = pos_id_dim
                    if self.config.rope_theta:
                        self.config.positional_encoding.rope_theta = self.config.rope_theta
                    if self.config.rope_scaling:
                        self.config.positional_encoding.rope_scaling = self.config.rope_scaling
                except KeyError:
                    pass

        except KeyError:
            pass

    @classmethod
    def from_pretrained(
        cls,
        pretrained_model_path: str | os.PathLike,
        cache_root: Optional[str | os.PathLike],
        *,
        tokenizer_path: Optional[str | os.PathLike] = None,
        config_path: Optional[str | os.PathLike] = None,
    ) -> "GenAIBuilderHTP":
        """
        This method creates a GenAIBuilderHTP instance from a pretrained model by loading the model's
        configuration and creating a new instance with the loaded configuration.

        Args:
            pretrained_model_path (str | PathLike): The path to the pretrained model.
            cache_root (str | PathLike) Optional: user-provided root directory where artifacts
                may be stored and referenced in subsequent builder operations.
            tokenizer_path (str | PathLike, optional): Explicit path to the tokenizer. If provided,
                this takes precedence over convention-based discovery. Can be a file or directory
                (will look for tokenizer.json inside). If not provided, defaults to looking in the
                model directory.
            config_path (str | PathLike, optional): Explicit path to the model config. If provided,
                this takes precedence over convention-based discovery. Can be a file or directory
                (will look for config.json inside). If not provided, defaults to looking in the
                model directory.

        Returns:
            GenAIBuilderHTP: An instance of GenAIBuilderHTP.

        Raises:
            FileNotFoundError: If the pretrained model path does not exist.

        """
        if not os.path.exists(pretrained_model_path):
            raise FileNotFoundError(f"Pretrained model path '{pretrained_model_path}' does not exist")
        pretrained_model_path_dir = pretrained_model_path
        if os.path.isfile(pretrained_model_path):
            pretrained_model_path_dir = os.path.dirname(pretrained_model_path)

        # Load config - use explicit path if provided, otherwise use model directory
        config = load_pretrained_config(config_path if config_path else pretrained_model_path_dir)

        # If tokenizer_path not explicitly provided, default to model directory
        # This ensures tokenizer is found in model directory even when config_path is explicit
        effective_tokenizer_path = tokenizer_path if tokenizer_path else pretrained_model_path_dir

        gen_ai_config = cls._create_config_from_pretrained(config, tokenizer_path=effective_tokenizer_path)

        builder = cls(pretrained_model_path, gen_ai_config, cache_root)

        return builder

    @property
    def encodings_path(self) -> Optional[str | os.PathLike]:
        """
        Gets the path to the encodings.

        Returns:
            Optional[str | os.PathLike]: The path to the encodings, or None if not set.
        """
        return self._encodings_path

    @encodings_path.setter
    def encodings_path(self, encodings_path: Optional[str | os.PathLike] = None):
        """
        Sets the path to the encodings.

        Args:
            encodings_path (Optional[str | os.PathLike], optional): The path to the encodings. Defaults to None.
        """
        self._encodings_path = encodings_path

    @property
    def lora_config(self) -> Optional[LoraBuilderInputConfig]:
        """
        Gets the lora config.

        Returns:
            Optional[LoraBuilderInputConfig]: The lora_config, or None if not set.
        """
        return self._lora_config

    @lora_config.setter
    def lora_config(self, lora_config: Optional[LoraBuilderInputConfig] = None):
        """
        Sets the lora_config which can be a LoraConfig class object or path to lora_config file.

        Args:
            lora_config (Optional[LoraBuilderInputConfig]): The lora_config. Defaults to None.
        """
        num_splits = self._transformation_config.model_transformer_config.split_model.num_splits
        if not self._transformation_config.model_transformer_config.split_model.split_embedding:
            self._transformation_config.model_transformer_config.split_model.split_embedding = True
            num_splits = num_splits + 1
        if not self._transformation_config.model_transformer_config.split_model.split_lm_head:
            self._transformation_config.model_transformer_config.split_model.split_lm_head = True
            num_splits = num_splits + 1
        self._transformation_config.model_transformer_config.split_model.num_splits = num_splits
        self._lora_config = lora_config

    @property
    def speculative_config(self) -> Optional[EagletBuilderConfig | LadeBuilderConfig | SsdBuilderConfig]:
        return self._speculative_config

    @speculative_config.setter
    def speculative_config(
        self, speculative_config: Optional[EagletBuilderConfig | LadeBuilderConfig | SsdBuilderConfig] = None
    ):
        if self._speculative_config and speculative_config:
            _logger.warning("Overwriting existing speculative config")
        self._speculative_config = speculative_config
        if isinstance(speculative_config, LadeBuilderConfig):
            if self._prepare_embedding_lut:
                self._prepare_embedding_lut = False
                _logger.warning(
                    f"Look-ahead decoding is incompatible with a prepared embedding Lookup Table.  Disabling LUT"
                )
        if isinstance(speculative_config, EagletBuilderConfig):
            target_config = self._transformation_config.model_transformer_config
            current_arns = sorted(target_config.arn_cl_options.auto_regression_number)
            if self.skip_ar_conversion and current_arns != [32, 128]:
                _logger.warning(
                    "EagletBuilderConfig requires specific AR values (32, 128) but skip_ar_conversion "
                    "is True. Speculative decoding may not function correctly."
                )
            target_config.arn_cl_options.auto_regression_number = [32, 128]
            self.set_transformation_options(target_config)

            self._prepare_embedding_lut = True
            original_sampler = self.config.sampler_params
            if original_sampler:
                if original_sampler.top_p != 1:
                    _logger.warning(f"top_p was {original_sampler.top_p} but is being set to 1 for eaglet")
                    original_sampler.top_p = 1
            else:
                self.config.sampler_params = Sampler(top_p=1)

    @property
    def chat_template(self) -> ChatTemplate:
        """
        Gets the chat template instance.

        Returns:
            ChatTemplate: The chat template instance.
        """
        return self._chat_template

    @chat_template.setter
    def chat_template(
        self, chat_template_instance: Union[NullChatTemplate, HFChatTemplate, CustomChatTemplate]
    ):
        """
        Sets the chat template instance. Configuration will be applied during build().

        Args:
            chat_template_instance (ChatTemplate): The ChatTemplate instance to assign.
        """
        self._chat_template = chat_template_instance

    def _assert_configurations_are_valid(self):
        """
        Validates the builder's configurations.

        For compilation: there must be at least one target DSP architecture.
        """
        if (
            not self._compilation_config
            or not self._compilation_config.device_custom_configs
            or not self._compilation_config.device_custom_configs[0].dsp_arch
        ):
            raise ValueError(
                "Target DSP architecture required.  Please set_compilation_options to "
                "include soc_details or add a device_custom_config to set the target DSP architecture."
            )
        if not self._transformation_config:
            raise ValueError(
                "Transofrmation Configuration required.  Please set options via set_transformation_options()."
            )
        for c in self._compilation_config.device_custom_configs:
            if c.dsp_arch == "v0":
                raise ValueError("Target DSP architecture undetected or unknown.")
        if (
            self._prepare_embedding_lut
            and not self._transformation_config.model_transformer_config.split_model.split_embedding
        ):
            _logger.warning("'split_embedding' not enabled - skipping embedding LUT preparation.")
            self._prepare_embedding_lut = False
        if self._prepare_embedding_lut and not self.config.n_embd:
            _logger.warning("'hidden_size' not set - skipping embedding LUT preparation.")
            self._prepare_embedding_lut = False

    def _confirm_framework_model_path(self):
        """
        If the user has provided a directory instead of a model, attempt to find an onnx model
        within that directory.  If multiple models are found, selection is arbitrary.
        """
        if self.framework_model_path.is_dir():
            matches = list(self.framework_model_path.glob("*.onnx"))
            if len(matches) == 0:
                raise FileNotFoundError(f"No onnx models found at {self.framework_model_path}")
            self.framework_model_path = matches[0]
            if len(matches) > 1:
                _logger.warning(
                    f"More than one model found.  Proceeding with {self.framework_model_path.name}."
                )

    def _confirm_encodings(self):
        """
        If the user has not explicitly provided an encodings path, attempt to find encodings within the
        same directory as the model, preferring (model_name).encodings if present, and then any
        .encodings file if there is exactly one.
        """
        if not self.encodings_path:
            base_name = Path(self.framework_model_path.name).stem
            possible_encodings_location = self.framework_model_path.parent / f"{base_name}.encodings"
            if possible_encodings_location.exists():
                _logger.warning(f"Using implicit encodings: {possible_encodings_location}")
                self.encodings_path = possible_encodings_location
            else:
                matches = list(self.framework_model_path.parent.glob("*.encodings"))
                if len(matches) == 1:
                    _logger.warning(f"Using implicit encodings: {matches[0]}")
                    self.encodings_path = matches[0]
                elif len(matches) > 1:
                    raise ValueError(
                        "Multiple/ambiguous encodings found.  Please set the builder encodings_path directly."
                    )
                else:
                    if self._calibration_config and not self._calibration_config.dataset:
                        raise ValueError("GenAIBuilder requires either calibration or encodings data.")
                    _logger.warning("Proceeding without encodings, but using calibration dataset")

    @resource_profile(scope="function", event=GenAIBuildEvents.PREPARE_EMBEDDING_LUT)
    def prepare_embedding_lut(self, embedding_split: ExportedFiles) -> Tuple[Path, Optional[Path]]:
        """
        Prepares the embedding lookup table for the model.

        Args:
            embedding_split: ExportedFiles object containing the embedding model files.

        Returns:
            Path to the embedding table file and path to the quantization parameters file (if present).
        """
        onnx_model_proto = onnx.load(embedding_split.onnx_path, load_external_data=True)
        if embedding_split.encodings_path:
            encodings_path = Path(embedding_split.encodings_path)
            with open(encodings_path, "r") as f:
                encodings = json.load(f)
        else:
            encodings = None

        embedding_dir = self.cache_dir if self.cache_dir else self.path_root

        embedding_table_path, quant_params_path = dump_embedding_table(
            onnxmodel=onnx_model_proto,
            base_dir=os.path.dirname(self.framework_model_path),
            encodings=encodings,
            output_dir=str(embedding_dir),
        )
        _logger.info(f"Embedding table dumped to {embedding_table_path}.")

        if quant_params_path:
            return Path(embedding_table_path), Path(quant_params_path)

        return Path(embedding_table_path), None

    def _build_embedding_config(self, embedding_table_path: Path, quant_params_path: Optional[Path] = None):
        """
        Build EmbeddingConfig as part of GenAIConfig.

        Args:
            embedding_table_path (Path): Path to the embedding table.
            quant_params_path (Optional[Path]): Path to the quantization parameters for the embedding table.

        Returns:
            None
        """
        # Non-quantized embedding table params
        embed_datatype = "float32"
        embed_quant_scale, embed_quant_offset = None, None

        # Quantized embedding table params
        if quant_params_path:
            with open(quant_params_path, "r") as file:
                data = json.load(file)
                embed_datatype = f"ufixed{data['bw']}"
                embed_quant_scale = data["scale"][0]
                embed_quant_offset = data["offset"][0]

        self.config.embedding_config = EmbeddingConfig(
            embed_path=embedding_table_path,
            embed_datatype=embed_datatype,
            embed_length=self.config.n_embd,
            embed_quant_scale=embed_quant_scale,
            embed_quant_offset=embed_quant_offset,
        )

    def build(self) -> LLMContainer:
        """
        Builds a GenAIContainer instance from the source framework model. The build process consumes the source
        framework model and its pre-computed quantization encodings, and performs the following steps:

         - For a LoRA use case, builds a max rank, concatenated LoRA configuration graph

         - Apply transformations to the model (necessary to run on HTP). These transformations improve
           model performance while executing on QAIRT. This may include:

           - Splitting the model based on the number of parameters

           - Additional transformations on each split such as Multi Head Attention to Single Head Attention.

         - For each split, the builder will:

          - Convert the model into a QAIRT model. This may include quantization using encodings, and/or calibration if sample inputs are provided.

          - Compile the model ahead-of-time into a compiled model instance.

        Examples:

            .. code-block:: python

                from qairt.gen_ai_api.gen_ai_builder_factory import GenAIBuilderFactory

                # Create a gen AI builder instance and set the appropriate targets
                gen_ai_builder: GenAIBuilder = GenAIBuilderFactory.create("model_dir/model.onnx", "HTP", cache_root=CACHE_ROOT)
                gen_ai_builder.set_targets([f"chipset:SC8380XP"])

                # Build the model
                gen_ai_container = gen_ai_builder.build()


        Returns:
            GenAIContainer: An instance of GenAIContainer, which can be used to create an executor to execute the model, or saved
            to disk as a directory of artifacts generated during build.

        """

        self._assert_configurations_are_valid()

        self.config.chat_template = self._chat_template

        # TODO: if it's a pytorch directory, load the model and export to onnx
        # see AISW-129859

        if not os.getenv("QAIRT_TMP_DIR"):
            _logger.warning(
                "QAIRT_TMP_DIR is not set. "
                "Be aware that building large models may require large amounts of temporary space. "
                "Set QAIRT_TMP_DIR to avoid default temporary space usage."
            )

        self._confirm_framework_model_path()

        self._confirm_encodings()
        # TODO - Remove once qairt fixes missing past_kv_out encodings
        if self.encodings_path:
            _fix_missing_past_kv_out_encodings(self.encodings_path)

        lora_output_config = None

        if self._lora_config:
            self.config.alpha_tensor_name = self._lora_config.alpha_tensor_name
            self.config.adapter_count_by_use_case = get_adapter_count_by_use_case(self._lora_config)
        if self._lora_config and self._lora_config.create_lora_graph:
            # These return parameters will be used by transform and convert APIs
            lora_output_config = self.build_lora_graph(self._lora_config, self.path_root)
            self.framework_model_path = lora_output_config.base_model_artifacts["onnx"]
            self.encodings_path = lora_output_config.base_model_artifacts["encodings"]
            # TODO - Remove once qairt fixes missing past_kv_out encodings
            _fix_missing_past_kv_out_encodings(self.encodings_path)
        if self._speculative_config:
            if isinstance(self._speculative_config, LadeBuilderConfig):
                common_fields = self._speculative_config.model_dump()
                self.config.speculative_run_config = LadeRunConfig(**common_fields)
            if isinstance(self._speculative_config, EagletBuilderConfig):
                draft_container_path = self._build_draft_container(self._speculative_config)
                common_fields = self._speculative_config.model_dump(
                    exclude={"draft_model_path", "draft_model_arn"}
                )
                self.config.speculative_run_config = EagletRunConfig(
                    **common_fields,
                    draft_container=draft_container_path,
                )

            if isinstance(self._speculative_config, SsdBuilderConfig):
                ssd_output_dir = Path(self.cache_dir if self.cache_dir else self.path_root) / "ssd_output"
                ssd_output_dir.mkdir(parents=True, exist_ok=True)

                original_model_name = Path(self.framework_model_path).stem
                new_model_with_extended_embedding = ssd_output_dir / f"{original_model_name}_ssd.onnx"

                self.framework_model_path = add_forecast_token_embeddings(
                    Path(self.framework_model_path),
                    Path(self._speculative_config.ssd_tensor_file),
                    new_model_with_extended_embedding,
                )
                forecast_prefix_name = process_ssd_param(
                    self.framework_model_path,
                    self.encodings_path,
                    output_dir=ssd_output_dir,
                    ssd_param_filename=self._speculative_config.ssd_tensor_file,
                )

                common_fields = self._speculative_config.model_dump(exclude={"ssd_tensor_file"})
                common_fields["forecast_prefix_name"] = forecast_prefix_name
                self.config.speculative_run_config = SsdRunConfig(**common_fields)

        transformed_models = self.transform(
            model_path=self.framework_model_path,
            config=self._transformation_config,
            encodings_path=self.encodings_path,
            lora_output_config=lora_output_config,
        )
        self.config.context_length = max(
            self._transformation_config.model_transformer_config.arn_cl_options.context_length
        )
        _logger.info(
            f"Updated GenAI config context_length to {self.config.context_length} "
            f"(longest from available options: {self._transformation_config.model_transformer_config.arn_cl_options.context_length})"
        )
        prepared_models: List[CompiledModel] = []

        _logger.debug(
            f"Transformed models: {[[m.model_dump_json() for m in split] for split in transformed_models]}"
        )

        for i, split_files in enumerate(zip(*transformed_models)):
            # If prepare_embedding_lut is set, prepare the embedding LUT in favor of the embedding context bin
            if self._prepare_embedding_lut and i == 0:
                embedding_split = transformed_models[0][0]
                embedding_table_path, quant_params_path = self.prepare_embedding_lut(embedding_split)
                self._build_embedding_config(embedding_table_path, quant_params_path)

                # LEQv2: Genie unpacks 4-bit embeddings to 8-bit before the second split,
                # so patch the second split's input encoding from bw=4 to bw=8.
                if quant_params_path:
                    with open(quant_params_path, "r") as f:
                        quant_params = json.load(f)
                    if quant_params.get("bw") == 4:
                        onnx_model_proto = onnx.load(embedding_split.onnx_path, load_external_data=False)
                        embedding_node = get_embedding_node_proto(onnx_model_proto)
                        embed_output_tensor_name = embedding_node.output[0]
                        _logger.info(
                            f"4-bit embedding (LEQv2) detected. Adjusting second split encodings "
                            f"for tensor '{embed_output_tensor_name}' from bw=4 to bw=8."
                        )
                        for ar_cl_variants in transformed_models:
                            if len(ar_cl_variants) > 1:
                                split2_files = ar_cl_variants[1]
                                if split2_files.encodings_path:
                                    adjust_split2_encodings_for_4bit_embedding(
                                        str(split2_files.encodings_path),
                                        embed_output_tensor_name,
                                    )
            else:
                models_for_split = []
                for split_idx, exported_files in enumerate(split_files):
                    self._conversion_config.input_tensor_config = get_input_layout(exported_files.onnx_path)
                    convert_kwargs = {}
                    if self._lora_config and exported_files.lora_importer_config:
                        convert_kwargs["quant_updatable_mode"] = self._lora_config.quant_updatable_mode
                    model = self.convert(
                        exported_files, self._conversion_config, self._calibration_config, **convert_kwargs
                    )
                    models_for_split.append(model)

                if self._compilation_config and self._compilation_config.graph_custom_configs:
                    for model in models_for_split:
                        new_graph_config: Any = self._compilation_config.graph_custom_configs[0].model_copy()
                        new_graph_config.name = model.name
                        self._compilation_config.graph_custom_configs.append(new_graph_config)
                        _logger.debug(f"Created new graph config for model: {model.name}")
                    _logger.debug(
                        f"Updated graph names for split {split_idx + 1}: {[model.name for model in models_for_split]}"
                    )
                    if self._compilation_config.graph_custom_configs[0].name == "placeholder":
                        self._compilation_config.graph_custom_configs.pop(0)

                if self.native_kv and self._compilation_config:
                    num_splits = self._transformation_config.model_transformer_config.split_model.num_splits
                    data_format_config = gen_kv_format_config(split_files)
                    data_format_config_path = (
                        Path(self.path_root) / f"data_format_config_{i + 1}_of_{num_splits}.json"
                    )
                    with open(data_format_config_path, "w") as f:
                        json.dump(data_format_config, f, indent=4)
                    self._compilation_config.data_format_config = data_format_config_path
                    _logger.debug(f"Native KV data format config written to: {data_format_config_path}")

                if self.weight_sharing and len(models_for_split) > 1:
                    _logger.info(
                        f"Models being compiled together: {[model.name for model in models_for_split]}"
                    )
                    assert self._compilation_config is not None
                    self._compilation_config.set_mode(CompilerModes.WEIGHT_SHARING.value)
                    compiled_model = self.compile(models_for_split, self._compilation_config)
                else:
                    _logger.info(f"No weight sharing: Compiling single model for split {i + 1}")
                    compiled_model = self.compile(models_for_split[0], self._compilation_config)

                prepared_models.append(compiled_model)

        if self.native_kv and self._compilation_config:
            self._compilation_config.data_format_config = None
            _logger.debug("Cleared data_format_config from compilation config after all splits processed.")

        # Capture profiling report
        profiling_report_data = None
        if _profiling_enabled():
            try:
                report = ResourceProfiler().report()
                profiling_report_data = report.serialize().get("data")

                # Also save to cache_dir (timestamped) for caching scenarios
                if self.cache_dir:
                    usage_logs_dir = Path(self.cache_dir) / "usage_logs"
                    usage_logs_dir.mkdir(parents=True, exist_ok=True)
                    report_path = (
                        usage_logs_dir
                        / f"gen_ai_htp_memory_profile_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                    )
                    report.dump(str(report_path))
                    _logger.info(f"Memory profiling report saved to: {report_path}")
            except Exception as e:
                _logger.warning(f"Failed to capture profiling report: {e}")

        container = LLMContainer(
            prepared_models,
            self.config,
            BackendType.HTP,
            compile_config=self._compilation_config,
            profiling_report=profiling_report_data,
        )

        return container

    def _build_draft_container(self, eaglet_builder_config: EagletBuilderConfig) -> Path:
        """Build a draft model container for speculative decoding and return its path.

        Args:
            draft_model_path: Path to the draft model

        Returns:
            Path: Path to the saved draft container
        """
        # get an instance of this type of builder to build the draft model
        draft_builder = type(self)(
            eaglet_builder_config.draft_model_path,
            config=self.config,
            cache_dir=self.cache_dir,
        )
        draft_builder._prepare_embedding_lut = True
        draft_config = draft_builder._transformation_config.model_transformer_config
        draft_config.split_model.split_embedding = True
        draft_config.split_model.num_splits = 3
        draft_config.split_model.split_lm_head = True
        draft_config.arn_cl_options.auto_regression_number = eaglet_builder_config.draft_model_arn
        draft_builder.set_transformation_options(draft_config)
        if self._compilation_config:
            draft_compilation_config = self._compilation_config.model_copy(deep=True)
            draft_builder.set_compilation_options(draft_compilation_config)

        draft_container = draft_builder.build()
        draft_container_path = (
            Path(self.cache_dir) / "draft" if self.cache_dir else Path(self.path_root) / "draft"
        )
        draft_container.save(draft_container_path, exist_ok=True)

        return draft_container_path
