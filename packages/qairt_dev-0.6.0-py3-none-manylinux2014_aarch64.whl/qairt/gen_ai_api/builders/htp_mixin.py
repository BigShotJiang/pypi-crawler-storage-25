# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import copy
import dataclasses
import functools
import hashlib
import os
import pathlib
import shutil
import tempfile
from typing import Any, Dict, List, Optional, Union

import yaml  # type: ignore
from pydantic import ValidationError

from qairt.api.common.backends.htp.config import HtpContextConfig, HtpDeviceConfig, HtpGraphConfig
from qairt.api.compiled_model import CompiledModel
from qairt.api.compiler._compile import compile
from qairt.api.compiler.config import CompileConfig
from qairt.api.configs.common import BackendType, PerfProfile
from qairt.api.configs.device import SocDetails
from qairt.api.converter._convert import convert
from qairt.api.converter.converter_config import CalibrationConfig, ConverterConfig
from qairt.api.model import Model
from qairt.api.profiler.resource_profiler.decorator import resource_profile
from qairt.api.profiler.resource_profiler.events import GenAIBuildEvents
from qairt.api.transforms._transform import transform
from qairt.api.transforms.model_transformer_config import (
    ARn_ContextLengthConfig,
    MhaConfig,
    ModelTransformerConfig,
    QuantizationStage,
)
from qairt.gen_ai_api.builders.gen_ai_utils import _fix_missing_past_kv_out_encodings, get_tensor_values
from qairt.gen_ai_api.configs.builder_transformer_config import BuilderTransformerConfig
from qairt.gen_ai_api.configs.gen_ai_config import ExpertConfig
from qairt.modules.lora.lora_config import (
    LoraBuilderInputConfig,
    LoraBuilderOutputConfig,
    UseCaseOutputConfig,
    load_use_case_config,
    serialize_lora_adapter_weight_config,
    serialize_lora_importer_config,
)
from qairt.modules.lora.lora_module import build_lora_graph
from qairt.optimizer.onnx import (
    GraphContext,
    change_context_length,
    change_seq_and_context_length,
)
from qairt.optimizer.onnx.passes.utilities import ComputeSeqAndContextLength
from qairt.utils import loggers
from qairt.utils.exceptions import InvalidCacheError
from qti.aisw.tools.core.utilities.framework.frameworks.onnx.onnx_model import ExportedFiles, ExportedUseCase

_logger = loggers.get_logger(name=__name__)


def _hash(source_artifact_path: str | os.PathLike, serialized_configuration: dict[str, Any]) -> str:
    return hashlib.sha256(f"{source_artifact_path}{serialized_configuration}".encode()).hexdigest()


def _move(source: pathlib.Path, dest: pathlib.Path) -> pathlib.Path:
    destination = dest / source.name
    if destination.exists():
        os.remove(destination)
    path = shutil.move(source, destination)
    assert isinstance(path, pathlib.Path)
    return path


def cache_build_lora_graph(func):
    @functools.wraps(func)
    def wrapper(
        self,
        lora_config: LoraBuilderInputConfig,
        output_dir: str | os.PathLike,
    ) -> LoraBuilderOutputConfig:
        def _all_patterns_exist(directory: pathlib.Path, patterns: List[str]) -> bool:
            for pattern in patterns:
                if not any(directory.glob(pattern)):
                    return False
            return True

        cache_dir = getattr(self, "cache_dir")
        if not cache_dir:
            return func(self, lora_config, output_dir)

        concurrency_names = []

        if lora_config.lora_config_path:
            # Load YAML file
            with open(lora_config.lora_config_path, "r") as f:
                data = yaml.safe_load(f)
                concurrency_names = [uc["name"] for uc in data.get("use-case", [])]
            hash = _hash(lora_config.lora_config_path, data)
        else:
            if lora_config.lora_config_obj is not None:
                lora_config_hash_obj = lora_config.lora_config_obj.model_dump()
                concurrency_names = [uc["name"] for uc in lora_config_hash_obj.get("use_cases", [])]
            else:
                raise ValueError("lora_config_obj is None")

            hash = _hash("", lora_config_hash_obj)

        # Build expected file patterns
        # NOTE: The "base" case does not have a safetensors file,
        # hence is excluded from the expected pattern
        expected_patterns = (
            [
                "*.onnx",
                "*.data",
                "*.yaml",
                "*.txt",
            ]
            + [f"{name}.safetensors" for name in concurrency_names if name != "base"]
            + [f"{name}_encodings.json" for name in concurrency_names]
        )

        working_directory = pathlib.Path(cache_dir) / str(hash)
        # Check if all expected files exist
        output_directory = working_directory / "lora_model_creator_output"

        if output_directory.exists() and _all_patterns_exist(output_directory, expected_patterns):
            _logger.debug(f"Cache Hit: Using cached files from {output_directory}")

            use_case_outputs: List[UseCaseOutputConfig] = load_use_case_config(
                pathlib.Path(output_directory) / "lora_importer_config.yaml"
            )

            lora_tensor_names_path = str(output_directory / "lora_tensor_names.txt")

            base_model_artifacts = {
                "onnx": str(next(output_directory.glob("*.onnx"))),
                "data": str(next(output_directory.glob("*.data"))),
                "encodings": str(output_directory / "base_encodings.json"),
            }

            lora_output_config: LoraBuilderOutputConfig = LoraBuilderOutputConfig(
                use_case=use_case_outputs,
                lora_tensor_names=lora_tensor_names_path,
                base_model_artifacts=base_model_artifacts,
            )

            return lora_output_config

        _logger.debug("Cache Miss: Running build_lora_graph")
        lora_output_config = func(self, lora_config, output_dir)

        os.makedirs(working_directory, exist_ok=True)

        # Clear the working directory if it already contains files
        for existing_file in pathlib.Path(working_directory).glob("*"):
            if existing_file.is_file():
                existing_file.unlink()
            elif existing_file.is_dir():
                shutil.rmtree(existing_file)

        shutil.move(
            pathlib.Path(output_dir) / "lora_model_creator_output",
            working_directory / "lora_model_creator_output",
        )

        # Update lora_tensor_names
        lora_output_config.lora_tensor_names = str(output_directory / lora_output_config.lora_tensor_names)
        # Update base_model_artifacts
        lora_output_config.base_model_artifacts = {
            key: str(output_directory / value)
            for key, value in lora_output_config.base_model_artifacts.items()
        }

        # Serialize updated config to YAML
        yaml_path = output_directory / "lora_importer_config.yaml"

        serialize_lora_importer_config(
            lora_uc_output_config=lora_output_config.use_case,
            yaml_path=str(yaml_path),
            base_dir=str(output_directory),
        )

        return lora_output_config

    return wrapper


def cache_transform(func):
    @functools.wraps(func)
    def wrapper(
        self,
        model_path: str | os.PathLike,
        config: BuilderTransformerConfig,
        encodings_path: str | os.PathLike,
        lora_output_config: Optional[LoraBuilderOutputConfig] = None,
        **kwargs,
    ) -> list[list[ExportedFiles]]:
        cache_dir = getattr(self, "cache_dir")
        if not cache_dir:
            return func(
                self,
                model_path,
                config,
                encodings_path,
                lora_output_config,
                **kwargs,
            )

        combined = {**config.model_dump(), "encodings_path": encodings_path}
        hash = _hash(model_path, combined)
        arn_cl_config = config.model_transformer_config.arn_cl_options

        cls = arn_cl_config.context_length
        arns = arn_cl_config.auto_regression_number

        n = config.model_transformer_config.split_model.num_splits

        working_directory = pathlib.Path(cache_dir) / str(hash)

        effective_arns = [self._infer_seq_length(model_path) if ar == 0 else ar for ar in arns]

        # Handle multiple AR cases
        cached_arn_split_files: list[list[ExportedFiles]] = []
        try:
            for cl in cls:
                for splits_for_arn in effective_arns:
                    exported_files_list = []
                    for exported_files_for_split in range(1, n + 1):
                        pattern = f"ar{splits_for_arn}_cl{cl}_{exported_files_for_split}_of_{n}"
                        exported_files = ExportedFiles(
                            onnx_path=working_directory / pattern / f"{pattern}.onnx",
                            data_path=working_directory / pattern / f"{pattern}.data",
                        )
                        if encodings_path:
                            exported_files.encodings_path = (
                                working_directory / pattern / f"{pattern}.encodings"
                            )
                        if lora_output_config:
                            if (
                                exported_files_for_split == 1
                                and config.model_transformer_config.split_model.split_embedding
                            ):
                                pass
                            elif (
                                exported_files_for_split == n
                                and config.model_transformer_config.split_model.split_lm_head
                            ):
                                pass
                            else:
                                exported_files.lora_tensor_names = (
                                    working_directory / pattern / "lora_tensor_names.txt"
                                )
                                exported_files.lora_importer_config = (
                                    working_directory / pattern / "lora_importer_config.yaml"
                                )
                                exported_files.use_cases = [
                                    ExportedUseCase(
                                        name=use_case.name,
                                        safetensors=working_directory / pattern / use_case.lora_weights,
                                        # we store as .encodings not _encodings.json
                                        encodings=working_directory / pattern / f"{use_case.name}.encodings",
                                    )
                                    for use_case in lora_output_config.use_case
                                ]

                        exported_files_list.append(exported_files)
                    cached_arn_split_files.append(exported_files_list)

            _logger.debug(f"Cache Hit: continuing with cached artifacts from {working_directory}")
            return cached_arn_split_files
        except ValidationError:
            _logger.debug(f"Cache Miss: Files not matching patterns for all ARs")

        split_transformed_files: list[list[ExportedFiles]] = func(
            self,
            model_path,
            config,
            encodings_path,
            lora_output_config,
            **kwargs,
        )

        os.makedirs(working_directory, exist_ok=True)

        # Move the transformed files to the cache
        for splits in split_transformed_files:
            for exported_files in splits:
                original_dir = exported_files.onnx_path.parent
                base = exported_files.onnx_path.parent.name
                os.makedirs(working_directory / base, exist_ok=True)

                exported_files.onnx_path = _move(exported_files.onnx_path, working_directory / base)
                exported_files.data_path = _move(exported_files.data_path, working_directory / base)
                if exported_files.encodings_path:
                    exported_files.encodings_path = _move(
                        exported_files.encodings_path, working_directory / base
                    )
                if exported_files.lora_tensor_names:
                    exported_files.lora_tensor_names = _move(
                        exported_files.lora_tensor_names, working_directory / base
                    )
                use_cases = []
                for uc in exported_files.use_cases:
                    uc.safetensors = _move(uc.safetensors, working_directory / base)
                    if uc.encodings:
                        uc.encodings = _move(uc.encodings, working_directory / base)
                    use_case = {
                        "name": uc.name,
                        "model_name": str(exported_files.onnx_path),
                        "lora_weights": str(uc.safetensors),
                    }
                    if uc.encodings:
                        use_case["quant_overrides"] = str(uc.encodings)
                    use_cases.append(use_case)

                # this moves the file and updates exported_files but the contents of this file
                # is absolute paths, which have not been updated.
                if exported_files.lora_importer_config:
                    exported_files.lora_importer_config = _move(
                        exported_files.lora_importer_config, working_directory / base
                    )
                    lora_config = {"use_case": use_cases}
                    with open(str(exported_files.lora_importer_config), "w") as f:
                        f.write(yaml.dump(lora_config))

                os.rmdir(original_dir)

        return split_transformed_files

    return wrapper


def cache_compile(func):
    @functools.wraps(func)
    def wrapper(self, model: Union[Model, List[Model]], config: CompileConfig) -> CompiledModel:
        cache_dir = getattr(self, "cache_dir")
        if not cache_dir:
            return func(self, model, config)
        working_directory = None
        _cached = None
        if isinstance(model, list):
            combined_model_info = "".join(f"{m.module.path}{m.name}" for m in model)
            hash = _hash(combined_model_info, config.model_dump())
            working_directory = os.path.join(cache_dir, hash)
            _cached = os.path.join(working_directory, model[0].name + ".bin")
        else:
            hash = _hash(f"{model.module.path}{model.name}", config.model_dump())
            working_directory = os.path.join(cache_dir, hash)
            _cached = os.path.join(working_directory, model.name + ".bin")

        if os.path.exists(_cached):
            try:
                _logger.debug(f"Cache Hit: {_cached} ")
                return CompiledModel.load(_cached, compile_config=config)
            except Exception as e:
                raise InvalidCacheError(f"Invalid cache compiled: {_cached}") from e
        else:
            _logger.debug(f"Cache Miss: {_cached}")
        # weird using positional arguments for config doesn't seem to work.  VSCode sees the signature but when I execute
        # it only sees the version with one positional and the other kwargs.
        os.makedirs(pathlib.Path(working_directory), exist_ok=True)
        compiled_model = func(self, model, config)

        compiled_model.save(_cached)
        return CompiledModel.load(_cached, compile_config=config)

    return wrapper


def cache_convert(func):
    @functools.wraps(func)
    def wrapper(
        self,
        exported_files: ExportedFiles,
        config: ConverterConfig,
        calibration_config: Optional[CalibrationConfig] = None,
        **extra_args,
    ) -> Model:
        cache_dir = getattr(self, "cache_dir")
        if not cache_dir:
            return func(self, exported_files, config, calibration_config)

        if calibration_config:
            serialized_configuration = {**config.model_dump(), **calibration_config.model_dump()}
        else:
            serialized_configuration = {**config.model_dump()}

        serialized_configuration.update(extra_args)

        if exported_files.lora_importer_config:
            serialized_configuration["lora_importer_config"] = exported_files.lora_importer_config
        if exported_files.lora_tensor_names:
            serialized_configuration["lora_tensor_names"] = exported_files.lora_tensor_names

        hash = _hash(exported_files.onnx_path, serialized_configuration)

        working_directory = pathlib.Path(cache_dir) / hash
        model_base_name = pathlib.Path(exported_files.onnx_path).stem
        _dlc = os.path.join(working_directory, f"{model_base_name}.dlc")
        if os.path.exists(_dlc):
            try:
                _logger.debug(f"Cache Hit: {_dlc}")
                return Model.load(_dlc)
            except Exception as e:
                raise InvalidCacheError(f"invalid cached convert: {_dlc}") from e
        else:
            _logger.debug(f"Cache Miss: {_dlc}")

        os.makedirs(pathlib.Path(_dlc).parent, exist_ok=True)
        model = func(self, exported_files, config, calibration_config, **extra_args)
        model.save(_dlc)

        # Serialize LoRA use cases to YAML with absolute paths
        if model.lora_use_cases and isinstance(model.lora_use_cases, list):
            yaml_path = working_directory / "lora_use_cases.yaml"
            for use_case in model.lora_use_cases:
                if use_case.lora_weights:
                    use_case.lora_weights = str((working_directory / use_case.lora_weights).resolve())
                if use_case.encodings:
                    use_case.encodings = str((working_directory / use_case.encodings).resolve())

            serialize_lora_adapter_weight_config(model.lora_use_cases, str(yaml_path), str(working_directory))
            _logger.debug(f"Serialized LoRA use cases to {yaml_path}")

        return Model.load(_dlc)

    return wrapper


def cache_arcl(func):
    @functools.wraps(func)
    def wrapper(self, model_path: str | os.PathLike, config: ARn_ContextLengthConfig) -> list[ExportedFiles]:
        cache_dir = getattr(self, "cache_dir")
        if not cache_dir:
            return func(self, model_path, config)
        hash = _hash(f"{model_path}", dataclasses.asdict(config))
        working_directory = pathlib.Path(cache_dir) / hash
        existing: list[ExportedFiles] = []
        try:
            effective_arns = [
                self._infer_seq_length(model_path) if ar == 0 else ar for ar in config.auto_regression_number
            ]
            for cl in config.context_length:
                for arn in effective_arns:
                    pattern = f"ar{arn}_cl{cl}"
                    exported_files = ExportedFiles(
                        onnx_path=working_directory / f"{pattern}.onnx",
                        data_path=working_directory / f"{pattern}.data",
                    )
                    if arn in config.arn_encodings_paths:
                        exported_files.encodings_path = pathlib.Path(config.arn_encodings_paths[arn])
                    existing.append(exported_files)
            _logger.debug(
                f"Cache Hit: ARn: {config.auto_regression_number} context length: {config.context_length}"
            )
            return existing
        except ValidationError:
            _logger.debug(f"Cache Miss: ARn/CL conversion not found")

        newly_created: list[ExportedFiles] = func(self, model_path, config)
        os.makedirs(working_directory, exist_ok=True)
        for files in newly_created:
            original_dir = files.onnx_path.parent
            files.onnx_path = _move(files.onnx_path, working_directory)
            files.data_path = _move(files.data_path, working_directory)
            os.rmdir(original_dir)

        return newly_created

    return wrapper


class HTPMixin:
    def __init__(self, cache_dir: Optional[str | os.PathLike] = None, weight_sharing: bool = True):
        """
        Initializes the HTP Mixin class. This class is utilized by the GenAIBuilderHTP class.

        Args:
            cache_dir (str | PathLike) Optional: A user-provided path that indicates the root
                directory to store artifacts for subsequent invocations.
            weight_sharing (bool): Flag to enable weight sharing during model compilation.

        """
        self.cache_dir = cache_dir
        self.path_root = os.getenv("QAIRT_TMP_DIR", default=tempfile.gettempdir())
        self._calibration_config: Optional[CalibrationConfig] = None
        self._compilation_config: Optional[CompileConfig] = None
        self._transformation_config: BuilderTransformerConfig = BuilderTransformerConfig()
        self._weight_sharing = weight_sharing

    @resource_profile(scope="function", event=GenAIBuildEvents.BUILD_LORA_GRAPH)
    @cache_build_lora_graph
    def build_lora_graph(
        self,
        lora_config: LoraBuilderInputConfig,
        output_dir: str | os.PathLike,
    ) -> LoraBuilderOutputConfig:
        """
        Builds a max rank, concatenated LoRA configuration graph by processing the input
        configuration through a mapper and model creator pipeline.

        Args:
        lora_config (LoraBuilderInputConfig): The input LoRA configuration, either as a
        configuration object or a path to a configuration file.
        output_dir (str | os.PathLike): Directory to store final outputs.

        Returns:
        LoraBuilderOutputConfig: The finalized LoRA configuration object.
        """

        return build_lora_graph(lora_config, output_dir=output_dir)

    @resource_profile(scope="function", event=GenAIBuildEvents.AR_CL_CONVERSION)
    @cache_arcl
    def ar_cl_conversion(
        self, model_path: str | os.PathLike, arn_cl_config: ARn_ContextLengthConfig
    ) -> list[ExportedFiles]:
        # Resolve sentinel 0: infer actual AR, update list, register base model path.
        # Track which ARs were resolved from sentinel 0 — only those skip AR conversion
        # since their model already has the correct AR. Explicitly attached models still
        # go through full AR+CL conversion using their attached path.
        sentinel_ars: set[int] = set()
        if arn_cl_config.skip_ar_conversion:
            actual_ar = self._infer_seq_length(model_path)
            arn_cl_config.auto_regression_number = [
                actual_ar if ar == 0 else ar for ar in arn_cl_config.auto_regression_number
            ]
            # Register base model for CL-only conversion at this AR
            arn_cl_config.arn_model_paths.setdefault(actual_ar, str(model_path))
            sentinel_ars.add(actual_ar)

        converted: list[ExportedFiles] = []
        for cl in arn_cl_config.context_length:
            for ar in arn_cl_config.auto_regression_number:
                if ar in sentinel_ars:
                    exported = self._convert_cl_only(arn_cl_config.arn_model_paths[ar], cl)
                elif ar in arn_cl_config.arn_model_paths:
                    exported = self._convert_single_ar_cl(arn_cl_config.arn_model_paths[ar], ar, cl)
                else:
                    exported = self._convert_single_ar_cl(str(model_path), ar, cl)
                if ar in arn_cl_config.arn_encodings_paths:
                    exported.encodings_path = pathlib.Path(arn_cl_config.arn_encodings_paths[ar])
                converted.append(exported)

        _logger.debug(
            f"Generated {len(converted)} AR/CL combinations: "
            f"ARs={arn_cl_config.auto_regression_number}, CLs={arn_cl_config.context_length}"
        )
        return converted

    @resource_profile(scope="function", event=lambda self, model_path, ar, cl: f"genai.ar_cl_ar{ar}_cl{cl}")
    def _convert_single_ar_cl(self, model_path: str | os.PathLike, ar: int, cl: int) -> ExportedFiles:
        """Convert a single AR/CL combination."""
        tmp_root_dir = os.getenv("QAIRT_TMP_DIR", default=tempfile.gettempdir())
        temp_working_dir = pathlib.Path(tempfile.mkdtemp(prefix="temp_working_dir_", dir=tmp_root_dir))
        proposed_name = f"ar{ar}_cl{cl}"
        arn_model_path = pathlib.Path(temp_working_dir) / f"{proposed_name}.onnx"
        arn_model_path.parent.mkdir(parents=True, exist_ok=True)

        if not arn_model_path.exists():
            ctx = GraphContext.from_files(model_path)
            change_seq_and_context_length(ctx, ar, cl)
            ctx.export(temp_working_dir, prefix=proposed_name)

        return ExportedFiles(
            onnx_path=arn_model_path,
            data_path=pathlib.Path(temp_working_dir) / f"{proposed_name}.data",
        )

    @resource_profile(scope="function", event=lambda self, model_path, cl: f"genai.cl_only_cl{cl}")
    def _convert_cl_only(self, model_path: str | os.PathLike, cl: int) -> ExportedFiles:
        """Convert context length only; reads AR from model metadata for output naming."""
        tmp_root_dir = os.getenv("QAIRT_TMP_DIR", default=tempfile.gettempdir())
        temp_working_dir = pathlib.Path(tempfile.mkdtemp(prefix="temp_working_dir_", dir=tmp_root_dir))
        temp_working_dir.mkdir(parents=True, exist_ok=True)

        ctx = GraphContext.from_files(model_path)
        change_context_length(ctx, cl)
        ar = ctx.graph_ir.meta["seq_length"]
        proposed_name = f"ar{ar}_cl{cl}"
        arn_model_path = pathlib.Path(temp_working_dir) / f"{proposed_name}.onnx"
        ctx.export(temp_working_dir, prefix=proposed_name)

        return ExportedFiles(
            onnx_path=arn_model_path,
            data_path=pathlib.Path(temp_working_dir) / f"{proposed_name}.data",
        )

    @functools.cached_property
    def _seq_length_cache(self) -> dict[str, int]:
        return {}

    def _infer_seq_length(self, model_path: str | os.PathLike) -> int:
        """Read seq_length from model via ComputeSeqAndContextLength (no file modification)."""
        key = str(model_path)
        if key not in self._seq_length_cache:
            ctx = GraphContext.from_files(model_path)
            ComputeSeqAndContextLength().apply(ctx)
            self._seq_length_cache[key] = int(ctx.graph_ir.meta["seq_length"])
        return self._seq_length_cache[key]

    @resource_profile(scope="function", event=GenAIBuildEvents.TRANSFORM)
    @cache_transform
    def transform(
        self,
        model_path: str | os.PathLike,
        config: BuilderTransformerConfig,
        encodings_path: Optional[str | os.PathLike] = None,
        lora_output_config: Optional[LoraBuilderOutputConfig] = None,
    ) -> list[list[ExportedFiles]]:
        """
        Performs quantization transformations to the model.

        Args:
            model_path (str | PathLike): The path to the model file to transform.
            config (BuilderTransformerConfig): The configuration for the transformation process.
            encodings_path (str | PathLike): The path to the encodings file.

        Returns:
            Tuple[List[pathlib.Path], ...]:
                - A tuple of lists of paths for the transformed model files for multiple or single ARs.

        .. note::

            if config.model_transformer_config.split_model.num_splits > 1, this will return
            a corresponding number of subdivided models
        """
        arn_cl_config = config.model_transformer_config.arn_cl_options
        transformed_splits: list[list[ExportedFiles]] = []
        arn_cl_converted_files = self.ar_cl_conversion(model_path, arn_cl_config)
        for exported_files in arn_cl_converted_files:
            kwargs: dict[str, Any] = {}

            kwargs["split_model"] = config.model_transformer_config.split_model
            kwargs["mha_config"] = config.model_transformer_config.mha_config
            if config.model_transformer_config.adapt_moe is not None:
                kwargs["adapt_moe"] = config.model_transformer_config.adapt_moe

            if lora_output_config and lora_output_config.use_case:
                kwargs["lora_tensor_names_path"] = lora_output_config.lora_tensor_names
                # Derive the path to lora_importer_config.yaml from lora_tensor_names path
                # The YAML file is created in the same directory by build_lora_graph
                lora_tensor_names_path = pathlib.Path(lora_output_config.lora_tensor_names)
                lora_importer_config_path = lora_tensor_names_path.parent / "lora_importer_config.yaml"
                kwargs["lora_adapters_path"] = str(lora_importer_config_path)

            if exported_files.encodings_path is not None:
                effective_encodings = exported_files.encodings_path
            elif encodings_path is not None:
                # AR model override present but no per-AR encodings attached — fall back to base
                _logger.info(
                    f"No encodings attached for AR model override '{exported_files.onnx_path.stem}'. "
                    "Defaulting to base encodings path."
                )
                effective_encodings = encodings_path
            else:
                effective_encodings = None

            splits = transform(
                model=exported_files.onnx_path,
                backend=config.backend,
                quantization_stage=QuantizationStage.POST_QUANT,
                encodings=effective_encodings,
                **kwargs,
            )
            proposed_name = exported_files.onnx_path.stem
            exported_splits: list[ExportedFiles] = [
                split.export(
                    pathlib.Path(self.path_root) / f"{proposed_name}_{idx + 1}_of_{len(splits)}",
                    f"{proposed_name}_{idx + 1}_of_{len(splits)}",
                )
                for idx, split in enumerate(splits)
            ]
            transformed_splits.append(exported_splits)

            assert len(exported_splits) == config.model_transformer_config.split_model.num_splits
        expected_combinations = len(arn_cl_converted_files)
        assert len(transformed_splits) == expected_combinations

        return transformed_splits

    def set_transformation_options(
        self,
        config: Optional[ModelTransformerConfig] = None,
        options: Optional[Dict] = None,
    ):
        """
        Provide instructions for applying transformations to the source framework model. This method updates
        the transformation configuration for the model, which will be used when transforming the model
        for execution on the target device.

        Args:
            config (ModelTransformerConfig): The transformation configuration options. Pass this config to override
                the entire config. Mutually exclusive with ``options``. One of ``config`` or ``options`` must be provided.
            options: Pass a dictionary of individual transformation options to override specific settings.
                Mutually exclusive with ``config``. One of ``config`` or ``options`` must be provided. Supported keys:

                - ``arn`` (List[int]): Auto-regression numbers to generate.
                  Sets ``arn_cl_options.auto_regression_number``.
                - ``context_length`` (List[int]): Context lengths to generate.
                  Sets ``arn_cl_options.context_length``.
                - ``mha2sha.permute_kv_cache_io`` (bool): Whether to permute the KV cache I/O for MHA2SHA layers.
                  Sets ``mha_config.permute_kv_cache_io``.
                - ``mha2sha.m2s_additional_start_points`` (List[M2sStartPoint]): Additional MHA2SHA start points.
                  Sets ``mha_config.m2s_additional_start_points``.
                - ``split.num_splits`` (int): Number of splits to divide the model into.
                  Sets ``split_model.num_splits``.
                - ``split.split_embedding`` (bool): Whether to split the embedding into its own subgraph.
                  Sets ``split_model.split_embedding``.
                - ``split.split_lm_head`` (bool): Whether to split the LM head into its own subgraph.
                  Sets ``split_model.split_lm_head``.
                - ``amoe.overridden_subselection`` (int): The number of subselected experts for MoE layers.
                  Sets ``adapt_moe["overridden_subselection"]``.
                - ``amoe.remove_op_predicate`` (bool): Whether to remove the op-predicate ``Where`` ops.
                  Sets ``adapt_moe["remove_op_predicate"]``.
                - ``mha2sha.m2s_additional_start_points`` (list[M2sStartPoint]): Additional start points
                  for the MHA2SHA conversion. Sets ``mha_config.m2s_additional_start_points``.
        """
        if config is None and options is None:
            raise ValueError("Pass either 'config' or 'options'.")
        if config is not None and options is not None:
            raise ValueError("Pass either 'config' or 'options', not both.")

        old_config = self._transformation_config.model_transformer_config

        if config is None:
            # Apply options on top of the existing config
            config = copy.deepcopy(self._transformation_config.model_transformer_config)
            assert options is not None  # for mypy

            remaining = dict(options)

            if "arn" in options:
                config.arn_cl_options.auto_regression_number = remaining.pop("arn")
            if "context_length" in options:
                config.arn_cl_options.context_length = remaining.pop("context_length")
            if "split.num_splits" in options:
                config.split_model.num_splits = remaining.pop("split.num_splits")
            if "split.split_embedding" in options:
                config.split_model.split_embedding = remaining.pop("split.split_embedding")
            if "split.split_lm_head" in options:
                config.split_model.split_lm_head = remaining.pop("split.split_lm_head")
            if "mha2sha.permute_kv_cache_io" in options:
                if config.mha_config is None:
                    raise AttributeError("MHA2SHA transformation is not enabled in the configuration.")
                config.mha_config.permute_kv_cache_io = remaining.pop("mha2sha.permute_kv_cache_io")
            if "mha2sha.m2s_additional_start_points" in options:
                if config.mha_config is None:
                    raise AttributeError("MHA2SHA transformation is not enabled in the configuration.")
                config.mha_config.m2s_additional_start_points = remaining.pop(
                    "mha2sha.m2s_additional_start_points"
                )
            if "amoe.overridden_subselection" in options:
                if config.adapt_moe is None:
                    raise AttributeError("MoE transformation is not enabled in the configuration.")
                config.adapt_moe["overridden_subselection"] = remaining.pop("amoe.overridden_subselection")
            if "amoe.remove_op_predicate" in options:
                if config.adapt_moe is None:
                    raise AttributeError("MoE transformation is not enabled in the configuration.")
                config.adapt_moe["remove_op_predicate"] = remaining.pop("amoe.remove_op_predicate")

            if remaining:
                raise ValueError(f"Unknown transformation options provided: {remaining}")

        if getattr(self, "_transformation_config", None) is not None:
            # Compare old and new configs
            for attr_name in dir(config):
                if not attr_name.startswith("_") and hasattr(old_config, attr_name):
                    old_value = getattr(old_config, attr_name)
                    new_value = getattr(config, attr_name)
                    if old_value != new_value:
                        _logger.debug(
                            f"Transformation option '{attr_name}' changed from {old_value} to {new_value}"
                        )

        # Warn if any existing arn_model_paths overrides are now orphaned
        old_ar_paths = old_config.arn_cl_options.arn_model_paths
        new_arns = config.arn_cl_options.auto_regression_number
        for ar_override in old_ar_paths:
            if ar_override not in new_arns:
                _logger.warning(
                    f"auto_regression_number changed: AR={ar_override} had an attached model path "
                    f"but is no longer in auto_regression_number={new_arns}. Override will be ignored."
                )
                del config.arn_cl_options.arn_model_paths[ar_override]
                config.arn_cl_options.arn_encodings_paths.pop(ar_override, None)

        config.validate()

        self._transformation_config = BuilderTransformerConfig(
            model_transformer_config=config, backend=BackendType.HTP
        )

    def attach_model_for_arn(
        self,
        arn: int,
        model_path: str | os.PathLike,
        encodings_path: str | os.PathLike | None = None,
    ) -> None:
        """
        Pin a specific ONNX model to a given auto-regression number i.e. for a particular
        sequence length.

        When ar_cl_conversion runs, the provided model_path is used as the source
        for this AR value instead of deriving it from the base framework model.
        Both models must share the same architecture and builder settings.

        Args:
            arn (int): The auto-regression number to override.
            model_path (str | PathLike): Path to the ONNX model to use for this AR.
            encodings_path (str | PathLike | None): Optional path to the encodings file to use
                for this AR during transform. If not provided, the base encodings_path is used.

        Raises:
            FileNotFoundError: If model_path does not exist.
            FileNotFoundError: If encodings_path is provided but does not exist.
        """
        resolved = pathlib.Path(model_path)
        if not resolved.exists():
            raise FileNotFoundError(f"Model path for AR={arn} not found: {resolved}")
        arn_cl_config = self._transformation_config.model_transformer_config.arn_cl_options
        if arn not in arn_cl_config.auto_regression_number:
            arn_cl_config.auto_regression_number.append(arn)
            _logger.debug(
                f"AR={arn} was not in auto_regression_number; added it. "
                f"Updated list: {arn_cl_config.auto_regression_number}"
            )
        arn_cl_config.arn_model_paths[arn] = str(resolved)
        _logger.debug(f"Attached model for AR={arn}: {resolved}")
        if encodings_path is not None:
            resolved_encodings = pathlib.Path(encodings_path)
            if not resolved_encodings.exists():
                raise FileNotFoundError(f"Encodings path for AR={arn} not found: {resolved_encodings}")
            # TODO - Remove once qairt fixes missing past_kv_out encodings
            _fix_missing_past_kv_out_encodings(resolved_encodings)
            arn_cl_config.arn_encodings_paths[arn] = str(resolved_encodings)
            _logger.debug(f"Attached encodings for AR={arn}: {resolved_encodings}")

    @resource_profile(scope="function", event=GenAIBuildEvents.CONVERT)
    @cache_convert
    def convert(
        self,
        exported_files: ExportedFiles,
        config: ConverterConfig,
        calibration_config: Optional[CalibrationConfig] = None,
        **extra_args,
    ) -> Model:
        """
        Converts an ONNX model to a QAIRT model.

        Args:
            exported_files (ExportedFiles): Collection of file paths and configuration data required for model conversion.
            config (ConverterConfig): Configuration for the conversion process.
            calibration_config (Optional[CalibrationConfig]): Configuration for the calibration process.
                                                              Defaults to None.
            **extra_args: Extra keyword arguments for conversion options.
                      See :class:`qairt.api.converter.converter_config.ConverterConfig` for details.

                      Additional supported arguments include:
                        - `lora_importer_config`: Optional configuration for LoRA Importer's
                            apply_lora_updates
                        - `lora_tensor_names`: Optional file specifying a list of tensor names
                            that should be updatable.
                        - `quant_updatable_mode`: Mode for quant-updatable tensors.

        Returns:
            Model: The converted QAIRT model.

        Raises:
            FileNotFoundError: If the encodings file corresponding to the ONNX model is not found.
        """
        onnx_file_path = exported_files.onnx_path
        split_encodings = exported_files.encodings_path
        lora_importer_config = exported_files.lora_importer_config
        lora_tensor_names = exported_files.lora_tensor_names

        if split_encodings and not split_encodings.exists():
            _logger.warning(f"Could not find encodings file {split_encodings}")
            matches = list(pathlib.Path(onnx_file_path).parent.glob("*.encodings"))
            if len(matches) == 1:
                _logger.warning(f"Expected {split_encodings} but proceeding with {matches[0]}")
                split_encodings = matches[0]
            else:
                split_encodings = None

        convert_args = config.model_dump()
        convert_args["lora_tensor_names"] = lora_tensor_names
        convert_args["lora_importer_config"] = lora_importer_config

        # Extract quant_updatable_mode from extra_args if present
        quant_updatable_mode = extra_args.get("quant_updatable_mode")
        if quant_updatable_mode is not None:
            convert_args["quant_updatable_mode"] = quant_updatable_mode

        model: Model = convert(
            onnx_file_path,
            split_encodings,
            calibration_config,
            **convert_args,
        )

        return model

    def set_conversion_options(
        self, config: ConverterConfig, calibration_config: Optional[CalibrationConfig] = None
    ):
        """
        Provide instructions for converting the framework model into the internal
        representation needed to run on Qualcomm devices.

        This method updates the conversion configuration for the model, which will be
        used when converting the model for execution on the target device.

        Args:
            config (ConverterConfig): A configuration object containing conversion options.
            calibration_config (Optional[CalibrationConfig]): Configuration for the calibration process.

        """
        self._conversion_config = config
        self._calibration_config = calibration_config
        if not self._conversion_config.input_tensor_config:
            self._conversion_config.input_tensor_config = []
        if not self._conversion_config.output_tensor_config:
            self._conversion_config.output_tensor_config = []

    @resource_profile(scope="function", event=GenAIBuildEvents.COMPILE)
    @cache_compile
    def compile(self, model: Union[Model, List[Model]], config: CompileConfig) -> CompiledModel:
        """
        Compile a converted QAIRT model into a compiled model.

        Args:
            model (Union[Model, List[Model]]): The converted QAIRT model(s) to compile.
            config (CompileConfig): The compilation configuration.

        Returns:
            CompiledModel: The compiled model.
        """
        return compile(model, config=config)

    def set_compilation_options(
        self,
        config: Optional[CompileConfig] = None,  # remove config
        options: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Sets the compilation options for the model.

        This method updates the compilation configuration for the model, which will be used when
        compiling the model for execution on the target device.

        Pass exactly one of ``config`` or ``options``.

        Args:
            config (CompileConfig): Full compilation configuration. Replaces any existing config.
            options (dict): Dictionary of individual compilation options to apply on top of the
                existing config (set via :meth:`set_targets`). Supported keys:

                - ``graphs.vtcm_size`` (int): VTCM size in bytes for each graph config.
                  ``0`` means use the device maximum.
                - ``graphs.vtcm_size_in_mb`` (int): VTCM size in megabytes for each graph config.
                  ``0`` means use the device maximum.
                - ``graphs.hvx_threads`` (int): Number of HVX threads to use per graph.
                  ``0`` means use the backend default.
                - ``graphs.optimization_type`` (int): Optimization level (1–3) for each graph
                  config.
                - ``devices.cores.perf_profile`` (PerfProfile | str): Performance profile applied
                  to every core in every device config. Valid string values are the members of
                  :class:`~qairt.api.configs.common.PerfProfile` (e.g. ``"burst"``,
                  ``"balanced"``, ``"high_performance"``).
                - ``context.extended_udma`` (bool): Enable extended UDMA on every context config
                  (requires HTP v81+).

        Raises:
            ValueError: If both ``config`` and ``options`` are provided, or if neither is
                provided.
            ValueError: If ``options`` is provided but no existing compilation config is present
                (call :meth:`set_targets` first).

        """
        if config is not None and options is not None:
            raise ValueError("Pass either config or options, not both.")
        if config is None and options is None:
            raise ValueError("Pass either config or options.")

        if options is not None:
            if self._compilation_config is None:
                raise ValueError(
                    "Cannot apply options: no compilation config exists. Call set_targets() first."
                )
            config = copy.deepcopy(self._compilation_config)

        assert config is not None  # guaranteed by the checks above
        if self._compilation_config:
            _logger.warning("Overriding existing compilation config (maybe set via set_targets)")
        self._compilation_config = config

        # Apply individual option overrides.
        if options is not None:
            remaining = dict(options)

            if "graphs.vtcm_size" in remaining:
                value = remaining.pop("graphs.vtcm_size")
                for g in self._compilation_config.graph_custom_configs or []:
                    if isinstance(g, HtpGraphConfig):
                        g.vtcm_size = value

            if "graphs.vtcm_size_in_mb" in remaining:
                value = remaining.pop("graphs.vtcm_size_in_mb")
                for g in self._compilation_config.graph_custom_configs or []:
                    if isinstance(g, HtpGraphConfig):
                        g.vtcm_size_in_mb = value

            if "graphs.hvx_threads" in remaining:
                value = remaining.pop("graphs.hvx_threads")
                for g in self._compilation_config.graph_custom_configs or []:
                    if isinstance(g, HtpGraphConfig):
                        g.hvx_threads = value

            if "graphs.optimization_type" in remaining:
                value = remaining.pop("graphs.optimization_type")
                for g in self._compilation_config.graph_custom_configs or []:
                    g.optimization_type = value

            if "devices.cores.perf_profile" in remaining:
                value = remaining.pop("devices.cores.perf_profile")
                for d in self._compilation_config.device_custom_configs or []:
                    if isinstance(d, HtpDeviceConfig):
                        for core in d.cores:
                            core.perf_profile = value

            if "context.extended_udma" in remaining:
                value = remaining.pop("context.extended_udma")
                if not self._compilation_config.context_custom_configs:
                    self._compilation_config.context_custom_configs = [HtpContextConfig()]
                for ctx in self._compilation_config.context_custom_configs:
                    if isinstance(ctx, HtpContextConfig):
                        ctx.extended_udma = value

            if remaining:
                raise ValueError(f"Unrecognized compile option(s): {sorted(remaining)}")

        builder_config = getattr(self, "config", None)
        expert_config: Optional[ExpertConfig] = getattr(builder_config, "expert_config", None)
        if expert_config and expert_config.enable_op_predication:
            for graph_config in self._compilation_config.graph_custom_configs or []:
                graph_config.finalize_config = {
                    **(graph_config.finalize_config or {}),
                    "enable_predication": True,
                }
            _logger.debug("enable_predication set in finalize_config for all graph configs.")

    # TODO: Support multiple chipsets, which would result in building a multiple context binaries
    # and let the resulting container build executors for the appropriate target.
    def set_targets(self, soc_details: list[Union[SocDetails, str]]):
        """
        Sets the target chipset for compilation.

        If a compilation config already exists (e.g. set via ``set_compilation_options``),
        only the ``soc_details`` field is updated and re-resolved; all other config
        settings are preserved.  A warning is logged when the existing config already
        has ``soc_details`` set.

        If no compilation config exists, a new ``CompileConfig`` is created with default
        graph and device custom configurations for the HTP backend.

        Args:
            soc_details: Device specification(s) to use for compilation. Each element
                can be a :class:`SocDetails` object or a spec string in the form
                ``"chipset:value;dsp_arch:value;soc_model:value|..."``.

        Raises:
            NotImplementedError: If more than one chipset is provided.
            ValueError: If a valid ``HtpDeviceConfig`` cannot be created from *soc_details*
                (only when creating a new config).

        """
        if len(soc_details) != 1:
            raise NotImplementedError("Current version supports targeting only one chipset.")

        if self._compilation_config is not None:
            if self._compilation_config.soc_details is not None:
                _logger.warning(
                    "Existing compilation config already has soc_details set to '%s'. "
                    "It will be updated to '%s'.",
                    self._compilation_config.soc_details,
                    soc_details[0],
                )
            self._compilation_config.soc_details = soc_details[0]
            self._compilation_config._set_soc_details()
            return

        config = CompileConfig(backend=BackendType.HTP, soc_details=soc_details[0], log_level="warn")
        if config.soc_details == "chipset:UNKNOWN":
            _logger.warning(
                "The chipset of the specified device was not recognized.  Please visit "
                "https://docs.qualcomm.com/bundle/publicresource/topics/80-63442-50/overview.html#supported-snapdragon-devices "
                "to identify the device and specify the target chipset."
            )
        config.graph_custom_configs = [
            HtpGraphConfig(
                name="placeholder",
                optimization_type=3,
            )
        ]
        # TODO: Guard around num_cores for 2.45 compatibility. Remove when 2.45 support is dropped.
        num_cores = (
            getattr(config._soc_details_resolved, "num_cores", None) if config._soc_details_resolved else None
        )
        if num_cores is not None:
            config.graph_custom_configs[0].num_cores = num_cores
        if (
            config.device_custom_configs
            and isinstance(config.device_custom_configs[0], HtpDeviceConfig)
            and config.device_custom_configs[0].cores
        ):
            for core in config.device_custom_configs[0].cores:
                core.perf_profile = PerfProfile.BURST
                core.rpc_control_latency = 100
        else:
            raise ValueError(f"Unable to create valid DevicHtpDeviceConfig for SocDetails: {soc_details[0]}")

        self.set_compilation_options(config)
