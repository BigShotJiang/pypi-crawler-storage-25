# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import json
import os
import pathlib
import re
import textwrap
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import onnx
import onnx_ir as ir
import torch
from onnx.numpy_helper import to_array
from transformers import AutoConfig
from transformers.configuration_utils import PretrainedConfig

from qairt.api.converter.converter_config import InputTensorConfig
from qairt.modules.genie_execution.genie_config import PositionalEncodingType
from qairt.optimizer.onnx.utils import (
    get_embedding_node,
    get_input_ids,
)
from qairt.optimizer.onnx.utils.encodings import deserialize_encodings
from qairt.utils import loggers
from qti.aisw.tools.core.utilities.framework.frameworks.onnx.onnx_model import ExportedFiles

_logger = loggers.get_logger(name=__name__)


def gen_kv_format_config(split_files: Sequence[ExportedFiles]) -> dict:
    """
    Generate a native KV data format config from the ONNX files for a given split.

    Identifies KV cache tensors (those with "key" or "value" in their names) across all
    AR/CL graph variants for the split, and marks them with
    QNN_TENSOR_DATA_FORMAT_HMX_WEIGHT_LAYOUT so the compiler stores them in the native
    HMX weight layout expected by the HTP backend's KV cache optimization.

    Args:
        split_files: Sequence of ExportedFiles for a given split, one entry per AR/CL combination.

    Returns:
        dict: Data format config dictionary suitable for serialisation to JSON and passing
            to the compiler via CompileConfig.data_format_config.
    """
    graphs_dict: dict = {"graphs": []}

    for exported_files in split_files:
        onnx_path = exported_files.onnx_path
        graph_name = onnx_path.stem

        input_names, output_names = get_onnx_input_output_names(str(onnx_path))

        tensors = [
            {
                "tensor_name": name,
                "dataFormat": "QNN_TENSOR_DATA_FORMAT_HMX_WEIGHT_LAYOUT",
            }
            for name in input_names + output_names
            if "key" in name or "value" in name
        ]

        if tensors:
            graphs_dict["graphs"].append(
                {
                    "graph_name": graph_name,
                    "tensors": tensors,
                }
            )

    return graphs_dict


def get_onnx_input_output_names(onnxfile) -> Tuple[List[str], List[str]]:
    """
    Retrieves the input and output tensor names from an ONNX model file.

    Args:
        onnxfile (str): Path to the ONNX model file.

    Returns:
        Tuple[List[str], List[str]]: A tuple of (input_names, output_names).
    """
    onnxmodel = onnx.load(onnxfile, load_external_data=False)
    return [i.name for i in onnxmodel.graph.input], [i.name for i in onnxmodel.graph.output]


def get_input_layout(onnxfile) -> List[InputTensorConfig]:
    """
    Retrieves the input layout configuration from an ONNX model file. The layout is set to "NONTRIVIAL" for
    all inputs, and the name and datatype are extracted from the ONNX model.

    Args:
        onnxfile (str): The path to the ONNX model file.

    Returns:
        List[InputTensorConfig]: A list of InputTensorConfig objects, each representing an input tensor
        in the ONNX model.

    """
    onnxmodel = onnx.load(onnxfile, load_external_data=False)
    input_info = [
        InputTensorConfig(
            layout="NONTRIVIAL",
            name=i.name,
            datatype=onnx.TensorProto.DataType.Name(i.type.tensor_type.elem_type).lower(),
        )
        for i in onnxmodel.graph.input
    ]

    return input_info


def get_kv_dim(onnxmodel: onnx.ModelProto) -> int:
    for x in onnxmodel.graph.input:
        if re.match(r"past_value_\d+_in", x.name):
            return x.type.tensor_type.shape.dim[-1].dim_value
    raise KeyError("past_value_[n]_in not found in graph.")


def get_pos_id_dim(onnxmodel: onnx.ModelProto) -> int:
    for x in onnxmodel.graph.input:
        if x.name == "position_ids_sin":
            return x.type.tensor_type.shape.dim[-1].dim_value
    raise KeyError("position_ids_sin not found in the graph.")


def get_embedding_node_proto(onnxmodel: onnx.ModelProto) -> onnx.NodeProto:
    """
    Retrieves the ONNX NodeProto corresponding to the embedding node in the model.

    Args:
        onnxmodel (onnx.ModelProto): The ONNX model containing the graph and nodes.

    Returns:
        onnx.NodeProto: The NodeProto object representing the embedding node.

    Raises:
        ValueError: If no matching NodeProto is found for the embedding node.
    """

    def _find_node_proto(model_proto: onnx.ModelProto, ir_node: ir.Node) -> onnx.NodeProto:
        for node_proto in model_proto.graph.node:
            if node_proto.name == ir_node.name:
                return node_proto
        raise ValueError(f"No NodeProto found with name: {ir_node.name}")

    model_ir: ir.Model = ir.serde.deserialize_model(onnxmodel)
    return _find_node_proto(onnxmodel, get_embedding_node(get_input_ids(model_ir)))


def get_embedding_length(onnxmodel: onnx.ModelProto) -> Optional[int]:
    """
    Determines the embedding length from an ONNX model.

    Args:
        onnxmodel (onnx.ModelProto): The ONNX model containing the embedding initializer.

    Returns:
        Optional[int]: The length of the embedding vector if found, otherwise None.
    """
    embedding_node = get_embedding_node_proto(onnxmodel)
    data_input_name = embedding_node.input[0]
    for initializer in onnxmodel.graph.initializer:
        if initializer.name == data_input_name:
            return initializer.dims[1]
    _logger.info("Unable to detect/determine embedding length in graph.")
    return None


def get_positional_encodings_type(onnxmodel: onnx.ModelProto, ar: int, cl: int) -> PositionalEncodingType:
    for x in onnxmodel.graph.input:
        if x.name == "position_ids_sin":
            return PositionalEncodingType.ROPE
        if x.name == "position_ids":
            # if it is 1 x ARn == absolute
            if (
                x.type.tensor_type.shape.dim[0].dim_value == 1
                and x.type.tensor_type.shape.dim[1].dim_value == ar
            ):
                return PositionalEncodingType.ABSOLUTE
            # if it is ARn x CL it is alibi
            if (
                x.type.tensor_type.shape.dim[0].dim_value == ar
                and x.type.tensor_type.shape.dim[1].dim_value == cl
            ):
                return PositionalEncodingType.ALIBI
    raise KeyError("Unable to detect/determine positional encoding in graph")


def get_tensor_values(onnxmodel: onnx.ModelProto) -> Tuple[int, int]:
    """
    Extracts the tensor values from an ONNX model, specifically the dimensions of the attention mask.
    This function assumes that the attention mask is the second input in the ONNX graph, or that it can be found by name.
    The function also assumes that the other dimensions of the attention mask are always 1.

    Args:
        onnxmodel (onnx.ModelProto): The onnx model to inspect

    Returns:
        Tuple[int, int]: A tuple containing the context length and the ARn of the attention mask.

    Raises:
        ValueError: If the input layers do not conform to the expected format and the attention mask is not found.
    """
    attention_mask = onnxmodel.graph.input[1]
    if attention_mask.name != "attention_mask":
        _logger.warning("Attention mask not found in expected location of input layers. Searching by name. ")
        attention_mask = next(
            (input for input in onnxmodel.graph.input if input.name == "attention_mask"), None
        )
        if not attention_mask:
            raise ValueError(
                "input layers do not conform to expected format: attention_mask not found in input layers"
            )
    dims = [dim.dim_value for dim in attention_mask.type.tensor_type.shape.dim]
    if len(dims) < 2:
        raise ValueError("Attention mask does not contain at least 2 dimensions")
    dims.sort()
    # ARn must be less than or equal to context length
    # The other dimensions are always 1 (?)
    _logger.debug(f"Extracted dims: {dims} from attention mask.  Presuming AR={dims[-2]} and CL={dims[-1]}")
    return (dims[-1], dims[-2])


def load_pretrained_config(pretrained_model_path_dir: str | os.PathLike) -> PretrainedConfig:
    """
    Loads the configuration of a pre-trained model from a JSON file.

    If the provided path is a directory, the configuration is loaded from "config.json" within that directory.
    If the provided path is a file, it is loaded directly.

    Unknown keys in the config file are preserved as extra attributes on the returned config object,
    matching the behavior of PretrainedConfig.from_dict.

    Args:
        pretrained_model_path_dir (str | os.PathLike): The directory path or file path to the config.
            If directory: looks for "config.json" inside.
            If file: loads that file directly.

    Returns:
        PretrainedConfig: The loaded configuration object.

    Raises:
        FileNotFoundError: If the config file cannot be found.
    """
    path = pathlib.Path(pretrained_model_path_dir)

    # Determine the config file path
    if path.is_file():
        config_file = path
        # Use the parent directory as _name_or_path for consistency
        name_or_path = path.parent
    elif path.is_dir():
        config_file = path / "config.json"
        name_or_path = path
    else:
        raise FileNotFoundError(f"Config path '{pretrained_model_path_dir}' does not exist")

    if not config_file.exists():
        raise FileNotFoundError(
            textwrap.dedent(f"""\
                Config file not found at '{config_file}'.
                To resolve this, either:
                  1. Place the 'config.json' from Hugging Face into the model directory '{path}'
                     (e.g. download it from https://huggingface.co/<model-id>/blob/main/config.json), or
                  2. Pass an explicit path to the config file instead of the model directory.""")
        )

    with open(config_file, "r") as f:
        raw_config: dict[str, Any] = json.load(f)

    # Ensure _name_or_path is set to be consistent with AutoConfig.from_pretrained behavior
    raw_config.setdefault("_name_or_path", str(name_or_path))

    # AutoConfig.for_model selects the right PretrainedConfig subclass based on model_type.
    # Unknown keys are preserved as extra attributes on the config object.
    model_type = raw_config.pop("model_type", "")
    try:
        config = AutoConfig.for_model(model_type, **raw_config)
    except (KeyError, ValueError):
        # Fallback for unrecognized model_type: use base PretrainedConfig
        raw_config["model_type"] = model_type
        config, _ = PretrainedConfig.from_dict(raw_config, return_unused_kwargs=True)

    return config


# TODO - Remove once qairt fixes missing past_kv_out encodings
def _detect_missing_past_kv_out_encodings(
    encodings_file: str | pathlib.Path | os.PathLike,
) -> list[tuple[str, str, int]]:
    """Scan an encodings JSON for past_key/value_N_in tensors missing a _out counterpart.

    Returns a list of ``(tensor_type, number, in_idx)`` tuples — one per missing
    ``_out`` tensor — or an empty list when the file is absent, unreadable, or
    already complete.
    """
    encodings_file = pathlib.Path(encodings_file)
    if not encodings_file.exists():
        return []
    try:
        with open(encodings_file, "r") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return []

    pattern = re.compile(r"^past_(key|value)_(\d+)_(in|out)$")
    tensor_map: dict[tuple, Any] = {}
    activation_encodings = data.get("activation_encodings", [])
    if isinstance(activation_encodings, dict):
        # Version 1.0.0 dict format: keys are tensor names
        for name in activation_encodings:
            m = pattern.match(name)
            if m:
                tensor_map[(m.group(1), m.group(2), m.group(3))] = name
    else:
        # Version 1.0.0 list format: each element is a dict with a "name" key
        for idx, encoding in enumerate(activation_encodings):
            name = encoding if isinstance(encoding, str) else encoding.get("name", "")
            m = pattern.match(name)
            if m:
                tensor_map[(m.group(1), m.group(2), m.group(3))] = idx

    return [
        (tensor_type, number, in_ref)
        for (tensor_type, number, direction), in_ref in tensor_map.items()
        if direction == "in" and (tensor_type, number, "out") not in tensor_map
    ]


# TODO - Remove once qairt fixes missing past_kv_out encodings
def _fix_missing_past_kv_out_encodings(
    encodings_file: str | pathlib.Path | os.PathLike,
) -> None:
    """Detect and repair missing past_kv_out activation encodings in-place.

    If any ``past_(key|value)_N_in`` tensors are found without a corresponding
    ``_out`` entry, a WARNING is logged and the missing entries are synthesised
    by deep-copying the ``_in`` encoding and renaming it to ``_out``.  A
    ``.orig`` backup is created on the first run.  No-ops when the file does
    not exist or no entries are missing.
    """
    import shutil
    from copy import deepcopy

    encodings_file = pathlib.Path(encodings_file)
    missing = _detect_missing_past_kv_out_encodings(encodings_file)
    if not missing:
        return

    _logger.warning(
        "Temporary workaround active: %d missing past_kv_out activation encoding(s) detected in %s. "
        "Affected tensors: %s. "
        "This patch will be removed once qairt emits the missing past_kv_out encodings.",
        len(missing),
        encodings_file,
        [f"past_{t}_{n}_out" for t, n, _ in missing],
    )

    backup = pathlib.Path(str(encodings_file) + ".orig")
    if not backup.exists():
        shutil.copy2(encodings_file, backup)
        _logger.debug("Encodings backup created: %s", backup)

    with open(encodings_file, "r") as f:
        data = json.load(f)

    activation_encodings = data["activation_encodings"]
    for tensor_type, number, in_ref in missing:
        out_name = f"past_{tensor_type}_{number}_out"
        if isinstance(activation_encodings, dict):
            # Dict format: in_ref is the tensor name string
            new_entry = deepcopy(activation_encodings[in_ref])
            activation_encodings[out_name] = new_entry
        else:
            # List format: in_ref is the integer index
            new_entry = deepcopy(activation_encodings[in_ref])
            new_entry["name"] = out_name
            activation_encodings.append(new_entry)
        _logger.debug("Synthesised encoding: %s", out_name)

    try:
        with open(encodings_file, "w") as f:
            json.dump(data, f, indent=4)
    except (OSError, IOError) as e:
        _logger.error("Failed to write patched encodings to %s: %s", encodings_file, e)
        # Attempt to restore from backup
        if backup.exists():
            shutil.copy2(backup, encodings_file)
            _logger.info("Restored original encodings from backup")
        raise

    _logger.info(
        "Encodings patched: added %d missing past_kv_out tensor(s) to %s",
        len(missing),
        encodings_file,
    )


def count_parameters(onnx_model_path):
    model = onnx.load(onnx_model_path)
    total_parameters = 0
    for initializer in model.graph.initializer:
        initializer_size = 1
        for dim in initializer.dims:
            initializer_size *= dim
        total_parameters += initializer_size
    return total_parameters


def _get_embedding_table(
    onnxmodel: onnx.ModelProto, embedding_node: onnx.NodeProto, base_dir: str
) -> np.ndarray:
    """
    Extracts the embedding table from an ONNX model initializer and converts it to a NumPy array.

    Args:
        onnxmodel (onnx.ModelProto): The ONNX model containing the graph and initializers.
        embedding_node (onnx.NodeProto): The node referencing the embedding table input.
        base_dir (str): Base directory used for resolving external data references.

    Returns:
        np.ndarray: The embedding table as a NumPy array.
    """
    embedding_table_name = embedding_node.input[0]
    (embedding_table_proto,) = [i for i in onnxmodel.graph.initializer if i.name == embedding_table_name]
    embedding_table = to_array(embedding_table_proto, base_dir=base_dir)

    return embedding_table


def _load_encoding(encodings_dict: dict) -> dict:
    """
    Loads and merges activation and parameter encodings from a given dictionary.

    Args:
        encodings_dict (dict): Dictionary containing 'activation_encodings' and 'param_encodings'.

    Returns:
        dict: A merged dictionary of all encodings.

    Raises:
        AssertionError: If 'param_encodings' is neither a dict nor a list.
    """
    all = {}
    encodings_version = encodings_dict.get("version")
    if encodings_version == "1.0.0":
        if isinstance(encodings_dict["param_encodings"], dict):
            all.update(encodings_dict["activation_encodings"])
            all.update(encodings_dict["param_encodings"])
        elif isinstance(encodings_dict["param_encodings"], list):
            all.update({enc["name"]: enc for enc in encodings_dict["activation_encodings"]})
            all.update({enc["name"]: enc for enc in encodings_dict["param_encodings"]})
        else:
            assert False, (
                f"Unknown encoding format : param_encodings type:{encodings_dict['param_encodings']}"
            )
    elif encodings_version == "2.0.0":
        all.update({enc["name"]: enc for enc in encodings_dict["encodings"]})
    else:
        raise ValueError(f"Unsupported encodings version: {encodings_version}")
    return all


def quantize(embedding_table, encoding: list | dict) -> np.ndarray:
    """
    Quantizes a floating-point embedding table using provided encoding parameters.

    Args:
        embedding_table (np.ndarray): The floating-point embedding table to quantize.
        encoding (list | dict): Encoding parameters containing scale, offset, and bitwidth.

    Returns:
        np.ndarray: Quantized embedding table as an unsigned integer array.

    Raises:
        TypeError: If encoding format is unknown
    """

    q, m = _quantize(embedding_table, encoding)
    return q


def _save_embedding_table(embedding_table, embedding_table_path) -> str:
    """
    Saves a NumPy embedding table to a binary file.

    Args:
        embedding_table (np.ndarray): The embedding table to save.
        embedding_table_path (str): Path to the output file.

    Returns:
        str: The path where the embedding table was saved.
    """
    embedding_table.tofile(embedding_table_path)
    return embedding_table_path


def dump_embedding_table(
    onnxmodel: onnx.ModelProto,
    base_dir: str,
    encodings: Optional[dict] = None,
    output_dir: str = ".",
) -> Tuple[str, Optional[str]]:
    """
    Extracts and saves the embedding table from an ONNX model for CPU usage.

    If quantization encodings are provided, the embedding table is quantized and saved in binary format,
    along with a JSON file containing the quantization parameters. Otherwise, the raw float embedding table
    is saved directly.

    Args:
        onnxmodel (onnx.ModelProto): The ONNX model containing the embedding node and initializers.
        base_dir (str): Base directory used to resolve external data references in the model.
        encodings (Optional[dict]): Optional dictionary of quantization encodings for the embedding table.
        output_dir (str): Directory where the embedding table files will be saved. Defaults to current directory.

    Returns:
        Tuple[str, Optional[str]]: Path to the saved embedding table file (quantized or float), and path to the
                                   quantization parameters JSON file (if quantized), otherwise None.

    Raises:
        AssertionError: If encoding format is unknown or required encoding is missing.
    """

    embedding_node = get_embedding_node_proto(onnxmodel)
    embedding_table = _get_embedding_table(onnxmodel, embedding_node, base_dir)
    embedding_output_name = embedding_node.output[0]

    # Dump quantized embedding table data
    if encodings:
        # Convert proto to IR for V1 encoding support
        model_ir = ir.serde.deserialize_model(onnxmodel)

        # Use Encoding adapters
        graph_enc = deserialize_encodings(encodings, model_ir=model_ir)

        # Get tensor encoding by name
        tensor_enc = graph_enc.get_tensor_encodings(embedding_output_name)

        # Extract quantization parameters from TensorEncodingInfo
        bw = tensor_enc.bw
        scale = float(tensor_enc.scale.flat[0])
        offset = int(tensor_enc.offset.flat[0])

        quant_params = {"bw": bw, "scale": [scale], "offset": [offset]}

        # Save quantization parameters
        quant_params_path = os.path.join(output_dir, "embedding_table_quant_param.json")
        with open(quant_params_path, "w") as f:
            json.dump(quant_params, f, indent=4)

        # Quantize and save
        quantized_embedding_table = quantize(embedding_table, quant_params)
        if bw == 4:
            embedding_table_path = _save_uint4_packed(
                quantized_embedding_table,
                os.path.join(output_dir, "quantized_embedding_table.bin"),
            )
        else:
            embedding_table_path = _save_embedding_table(
                quantized_embedding_table,
                os.path.join(output_dir, "quantized_embedding_table.bin"),
            )
    else:
        quant_params_path = None

        # Dump float embedding table data
        embedding_table_path = _save_embedding_table(
            embedding_table, os.path.join(output_dir, "embedding_table.bin")
        )

    return embedding_table_path, quant_params_path


def adjust_split2_encodings_for_4bit_embedding(
    encodings_path: str,
    embedding_output_tensor_name: str,
) -> None:
    """
    Adjusts the second split's encodings to change the embedding output tensor's
    bitwidth from 4 to 8, keeping the scale and offset unchanged.

    When a model uses 4-bit embedding (LEQv2), Genie handles the embedding lookup
    and unpacks 4-bit values to 8-bit before feeding them to the second split.
    HTP does not accept <8-bit inputs, so the second split's input encoding for
    the embedding output must be updated from bw=4 to bw=8.

    Args:
        encodings_path (str): Path to the encodings JSON file for the second split.
        embedding_output_tensor_name (str): Name of the embedding output tensor
            (which is an input to the second split).
    """
    with open(encodings_path, "r") as f:
        encodings = json.load(f)

    flat = _load_encoding(encodings)
    enc = flat.get(embedding_output_tensor_name)

    if enc is None:
        _logger.warning(
            f"Encoding for '{embedding_output_tensor_name}' not found in {encodings_path}. "
            f"The second split may fail to compile."
        )
        return

    if enc.get("bw") == 4:
        enc["bw"] = 8
    elif enc.get("output_dtype") == "uint4":
        enc["output_dtype"] = "uint8"
    elif enc.get("output_dtype") == "int4":
        enc["output_dtype"] = "int8"
    else:
        _logger.debug(
            f"No 4-bit encoding found for tensor '{embedding_output_tensor_name}' in {encodings_path}. "
            f"No adjustment needed."
        )
        return

    _logger.info(
        f"Adjusted embedding output tensor '{embedding_output_tensor_name}' "
        f"encoding from bw=4 to bw=8 in {encodings_path} for HTP compatibility."
    )
    with open(encodings_path, "w") as f:
        json.dump(encodings, f, indent=4)


def _round(x):
    """Round to nearest integer preserving sign."""
    sign = np.where(x < 0, -1, 1).astype(np.float32)
    return np.floor(np.abs(x) + 0.5) * sign


def _quantize_array(f: np.ndarray, scale: float, offset: float, bw: int) -> np.ndarray:
    _dtype: Union[type, np.dtype]
    if bw == 8:
        _dtype = np.uint8
    elif bw == 16:
        _dtype = np.uint16
    elif bw == 32:
        _dtype = np.uint32
    elif bw == 4:
        # use uint8 to hold values [0, 15] and let _save_uint4_packed handle bit-packing
        _dtype = np.uint8
    else:
        raise ValueError(f"Unsupported bitwidth: {bw}")
    q = _round(f / scale - offset)
    qmin, qmax = 0, (2**bw) - 1
    return np.clip(q, qmin, qmax).astype(_dtype)


def _dequantize_array(q: np.ndarray, scale: float, offset: float) -> np.ndarray:
    return (q.astype(np.float32) + offset) * scale


def _quantize(
    f: Union[np.ndarray, List[float]],
    encoding: Union[Dict[str, Any], List[Dict[str, Any]]],
) -> Tuple[np.ndarray, "Metric"]:
    """
    Quantise a floating-point embedding table.

    Parameters
    ----------
    f: np.ndarray | List[float]
        Float embedding table.
    encoding: dict | list
        Encoding description.  Supported formats:
        * ``{'scale': [s], 'offset': [o], 'bw': N}``
        * ``[{'scale': s, 'offset': o, 'bitwidth': N}]``

    Returns
    -------
    Tuple[np.ndarray, Metric]
        Quantised array and a ``Metric`` object describing quality.
    """

    if isinstance(encoding, list):
        enc = encoding[0]
        scale, offset = enc["scale"], enc["offset"]
        bw = enc.get("bw")
        if bw is None:
            raise ValueError("Bitwidth not found in encoding list")
    elif isinstance(encoding, dict):
        scale, offset = encoding["scale"][0], encoding["offset"][0]
        bw = encoding.get("bw")
        if bw is None:
            raise ValueError("Bitwidth not found in encoding dict")
    else:
        raise TypeError(f"Unsupported encoding type: {type(encoding)}")

    f_arr = np.asarray(f, dtype=np.float32)
    q = _quantize_array(f_arr, float(scale), float(offset), int(bw))
    dq = _dequantize_array(q, float(scale), float(offset))
    metric = Metric(f_arr, dq)
    return q, metric


def _save_uint4_packed(data: np.ndarray, path: str) -> str:
    """
    Save uint4 data to a binary file using bit packing (2 values per byte).

    Each pair of consecutive values is packed into a single byte:
    even-index value → low nibble, odd-index value → high nibble.

    Args:
        data (np.ndarray): Array with uint4 values in range [0, 15].
        path (str): Output file path.

    Returns:
        str: The path where the packed data was saved.
    """
    data = np.asarray(data, dtype=np.uint8)
    assert np.all((data >= 0) & (data <= 15)), "Quantized embedding values must be in range [0, 15] for uint4"

    # Pad with zero if odd length
    if len(data) % 2 == 1:
        data = np.append(data, 0)

    # Pack pairs: even-index → low nibble, odd-index → high nibble
    low = data[0::2] & 0x0F
    high = (data[1::2] & 0x0F) << 4
    packed = high | low

    packed.astype(np.uint8).tofile(path)
    return path


class Metric:
    """
    Compute simple quality metrics between two tensors.

    Attributes
    ----------
    sqnr : float
        Signal-to-Quantisation-Noise Ratio in dB.
    mse : float
        Mean-Squared Error.
    cossim : float
        Cosine similarity.
    """

    def __init__(self, a: Union[np.ndarray, List[float]], b: Union[np.ndarray, List[float]]):
        self.sqnr, self.mse, self.cossim = self._calc(a, b)

    def _calc(
        self, a: Union[np.ndarray, List[float], float], b: Union[np.ndarray, List[float], float]
    ) -> Tuple[float, float, float]:
        """
        Compute SQNR, MSE and cosine similarity.

        Returns
        -------
        Tuple[float, float, float]
            (sqnr, mse, cosine_similarity)
        """
        if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
            # Recursively compute metrics for each pair and average
            results = [self._calc(ai, bi) for ai, bi in zip(a, b)]
            return tuple(np.mean(results, axis=0))

        # Ensure tensors are float for accurate computation
        if isinstance(a, torch.Tensor) and not torch.is_floating_point(a):
            a = a.to(torch.float)
        if isinstance(b, torch.Tensor) and not torch.is_floating_point(b):
            b = b.to(torch.float)

        a_arr = np.asarray(a, dtype=np.float32)
        b_arr = np.asarray(b, dtype=np.float32)

        return (
            self._sqnr(a_arr, b_arr),
            self._mse(a_arr, b_arr),
            self._cosine_similarity(a_arr, b_arr),
        )

    def __repr__(self) -> str:
        return f"{self.sqnr:.1f}dB|{self.mse:.5f}|{self.cossim:.3f}"

    @staticmethod
    def _cosine_similarity(signal: np.ndarray, noisy: np.ndarray) -> float:
        """Cosine similarity between two vectors."""
        signal_flat = signal.reshape(-1)
        noisy_flat = noisy.reshape(-1)
        return float(
            np.dot(signal_flat, noisy_flat) / (np.linalg.norm(signal_flat) * np.linalg.norm(noisy_flat))
        )

    @staticmethod
    def _sqnr(org_out: np.ndarray, quant_out: np.ndarray, eps: float = 1e-20) -> float:
        """Signal-to-Quantisation-Noise Ratio in dB."""
        if org_out.shape != quant_out.shape:
            raise RuntimeError(
                f"Shapes mismatch, {org_out.shape} != {quant_out.shape}, Invalid SQNR measurement"
            )
        quant_error = org_out - quant_out
        exp_noise = (quant_error**2).mean() + eps
        exp_signal = (org_out**2).mean()
        sqnr = (exp_signal / exp_noise) + eps
        return float(10 * np.log10(sqnr))

    @staticmethod
    def _mse(signal: np.ndarray, noisy: np.ndarray) -> float:
        """Mean-Squared Error."""
        return float(np.mean((noisy - signal) ** 2))
