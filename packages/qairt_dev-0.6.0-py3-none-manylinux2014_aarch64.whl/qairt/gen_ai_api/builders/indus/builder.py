# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

from qairt.gen_ai_api.builders.gen_ai_builder_htp import GenAIBuilderHTP


class IndusBuilderHTP(GenAIBuilderHTP):
    pass
