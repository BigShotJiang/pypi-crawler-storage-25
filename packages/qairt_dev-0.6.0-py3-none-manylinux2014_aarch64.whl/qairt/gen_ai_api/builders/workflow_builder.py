# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

import os
from typing import Dict, Optional

from qairt.api.configs.common import BackendType
from qairt.gen_ai_api.builders.buildable import Buildable
from qairt.gen_ai_api.builders.gen_ai_builder import GenAIBuilder
from qairt.gen_ai_api.configs.workflow import WorkflowGraph, WorkflowNode, WorkflowNodeRole
from qairt.gen_ai_api.containers.gen_ai_container import GenAIContainer
from qairt.gen_ai_api.containers.gen_ai_containerable import GenAIContainerable
from qairt.gen_ai_api.containers.workflow_container import WorkflowContainer
from qairt.gen_ai_api.gen_ai_builder_factory import GenAIBuilderFactory


class WorkflowBuilder(Buildable):
    """Constructs a `WorkflowContainer` from `GenAIBuilder` instances and a `WorkflowGraph`.

    Use one of the two factory methods rather than calling ``__init__`` directly:

    - `from_builders`: use when you have already constructed `GenAIBuilder`
      instances and optionally a `WorkflowGraph`. If no graph is supplied and
      there is exactly one builder, a single-node ``TEXT_GENERATOR`` graph is
      created automatically.
    - `from_workflow`: use when you have a `WorkflowGraph` whose nodes each
      carry a ``path`` and want the builder to construct the `GenAIBuilder`
      instances automatically.
    """

    def __init__(
        self,
        builders: Dict[str, GenAIBuilder],
        workflow_graph: WorkflowGraph,
    ):
        self.builders = builders
        self._workflow_graph = workflow_graph

    @classmethod
    def from_builders(
        cls,
        builders: Dict[str, GenAIBuilder],
        workflow_graph: Optional[WorkflowGraph] = None,
    ) -> "WorkflowBuilder":
        """Creates a `WorkflowBuilder` from already-constructed `GenAIBuilder` instances.

        Args:
            builders: Mapping of node name to `GenAIBuilder` instance. The
                builders must already be fully configured; no path information
                is read here.
            workflow_graph: `WorkflowGraph` describing the directed graph structure (node
                names, roles, and connections). Node ``path`` fields are not
                required here — the builders have already been constructed.
                If omitted and ``builders`` contains exactly one entry, a
                single-node ``TEXT_GENERATOR`` graph is constructed automatically
                using the builder's key as the node name. If omitted and
                ``builders`` contains more than one entry, a ``ValueError`` is
                raised — multi-node workflows require an explicit graph.

        Returns:
            A `WorkflowBuilder` ready to call `build()` on.

        Raises:
            ValueError: If ``workflow_graph`` is omitted and ``builders`` has
                more than one entry.
        """
        if not builders:
            raise ValueError("builders must not be empty.")
        if workflow_graph is None:
            if len(builders) != 1:
                raise ValueError(
                    "workflow_graph must be provided when builders contains more than one entry. "
                    "There is no sensible default graph topology for multi-node workflows."
                )
            (node_name,) = builders.keys()
            workflow_graph = WorkflowGraph(
                nodes=(
                    WorkflowNode(
                        name=node_name,
                        role=WorkflowNodeRole.TEXT_GENERATOR,
                        output_callback_type="textCallback",
                    ),
                ),
                connections=(),
            )
        return cls(builders, workflow_graph)

    @classmethod
    def from_workflow(
        cls,
        workflow: WorkflowGraph,
        backend_type: BackendType = BackendType.HTP,
        cache_root: Optional[os.PathLike] = None,
    ) -> "WorkflowBuilder":
        """Creates a `WorkflowBuilder` by constructing `GenAIBuilder` instances from a `WorkflowGraph`.

        Each node in the graph must have its ``path`` field set, pointing to
        the model artifacts for that node. Per-node ``tokenizer_path`` and
        ``config_path`` can be set on each `WorkflowNode`; if omitted,
        convention-based discovery is used.

        Args:
            workflow: `WorkflowGraph` whose nodes each carry a ``path``
                pointing to the model artifacts. A `GenAIBuilder` is created
                for every node using `GenAIBuilderFactory`. Each node may
                also carry ``tokenizer_path`` and ``config_path`` to override
                convention-based artifact discovery for that node.
            backend_type: The backend to use when creating each `GenAIBuilder`.
                Defaults to `BackendType.HTP`.
            cache_root: Shared root directory for build caches. Applied to
                every node. Defaults to ``None`` (no caching).

        Returns:
            A `WorkflowBuilder` ready to call `build()` on.

        Raises:
            ValueError: If any node is missing a ``path``, or if a
                `GenAIBuilder` cannot be created for any node.
        """
        builders: Dict[str, GenAIBuilder] = {}
        for node in workflow.nodes:
            if node.path is None:
                raise ValueError(
                    f"Workflow node '{node.name}' is missing a path. "
                    "All nodes must have a path set when using from_workflow()."
                )
            try:
                builder = GenAIBuilderFactory.create(
                    pretrained_model_path=node.path,
                    backend_type=backend_type,
                    cache_root=cache_root,
                    tokenizer_path=node.tokenizer_path,
                    config_path=node.config_path,
                )
                builders[node.name] = builder
            except Exception as e:
                raise ValueError(
                    f"Failed to create builder for workflow node '{node.name}' at path '{node.path}': {str(e)}"
                ) from e
        return cls(builders, workflow)

    def build(self) -> WorkflowContainer:
        """Build and return a `WorkflowContainer` from the configured builders.

        Calls `build()` on each `GenAIBuilder` and assembles the resulting
        containers into a `WorkflowContainer` with the configured graph.

        Returns:
            A `WorkflowContainer` holding all built sub-containers and the
            workflow graph.
        """
        built_containers: dict[str, GenAIContainerable] = {}
        for name, builder in self.builders.items():
            container = builder.build()
            # GenAIBuilder(abstract) builds a GenAIContainerable, but GenAIBuilderHTP/GenAIBuilderCPU return a GenAIContainer.
            if not isinstance(container, GenAIContainer):
                raise TypeError(
                    f"Builder for node '{name}' returned {type(container)!r}, expected a GenAIContainer."
                )
            built_containers[name] = container

        return WorkflowContainer(
            built_containers,
            workflow_graph=self._workflow_graph,
        )
