# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

import os
import textwrap
from typing import TYPE_CHECKING, Optional

from qairt.api.compiler.config import CompileConfig, HtpGraphConfig
from qairt.gen_ai_api.builders.gen_ai_builder_htp import GenAIBuilderHTP
from qairt.gen_ai_api.configs.gen_ai_config import ExpertConfig, GenAIConfig
from qairt.optimizer.onnx.passes.config import M2sStartPoint
from qairt.utils.loggers import get_logger

_logger = get_logger(name=__name__)

if TYPE_CHECKING:
    from transformers.configuration_utils import PretrainedConfig


class QwenBuilderHTP(GenAIBuilderHTP):
    pass


class Qwen3_5BuilderHTP(GenAIBuilderHTP):
    _QWEN3_5_START_POINTS = [
        M2sStartPoint(name_pattern=r"/model_layers_(\d+)_linear_attn_norm_Mul_3/Mul_output_0", split_axis=1),
        # Tensor shape: [1, seq, 4096] where 4096 = num_key_value_heads(16) * head_dim(256).
        # split_map groups by head_dim so each group corresponds to one KV head.
        # Hardcoded because num_key_value_heads and head_dim are generally fixed.
        # Update if Qwen3.5 variants with different dimensions are added.
        M2sStartPoint(
            name_pattern=r"/model_layers_(\d+)_self_attn_Mul_8/Mul_output_0",
            split_axis=2,
            split_map={4096: 256},
        ),
        M2sStartPoint(name_pattern=r"recurrent_state_(\d+)_out", split_axis=1),
        M2sStartPoint(name_pattern=r"conv_state_(\d+)_out", split_axis=1),
    ]

    def __init__(
        self,
        framework_model_path: str | os.PathLike,
        config: GenAIConfig,
        cache_dir: Optional[str | os.PathLike] = None,
        weight_sharing: bool = False,
        multi_graph: bool = False,
        native_kv: bool = False,
        skip_ar_conversion: bool = True,
    ) -> None:
        super().__init__(
            framework_model_path,
            config,
            cache_dir=cache_dir,
            weight_sharing=weight_sharing,
            multi_graph=multi_graph,
            native_kv=native_kv,
            skip_ar_conversion=skip_ar_conversion,
        )
        if self._transformation_config.model_transformer_config.mha_config is None:
            self._logger.warning(
                "mha_config is None in model_transformer_config — skipping MHA2SHA start point configuration."
            )
        else:
            self.set_transformation_options(
                options={
                    "mha2sha.m2s_additional_start_points": self._QWEN3_5_START_POINTS,
                }
            )
            self._logger.debug("Using MHA2SHA start points: %s", self._QWEN3_5_START_POINTS)
            self._logger.debug(
                textwrap.dedent("""\
                    The MHA2SHA transformation may fail if the start points are not correctly configured.
                        To add or replace MHA2SHA start points, call set_transformation_options after construction:
                        builder.set_transformation_options({
                            "mha2sha.m2s_additional_start_points": [M2sStartPoint(...), ...]
                        })
                    See M2sStartPoint for the name_pattern, split_axis, and split_map arguments.""")
            )

    @GenAIBuilderHTP.weight_sharing.setter  # type: ignore[attr-defined]
    def weight_sharing(self, value: bool) -> None:
        transform_config = self._transformation_config.model_transformer_config
        if value and len(transform_config.arn_cl_options.auto_regression_number) < 2:
            raise RuntimeError(
                "Qwen3.5 uses a hybrid linear-attention architecture. To enable weight sharing "
                "separate prefill and decode graphs are required. Use attach_model_for_arn(arn=n, ...) to attach a suitable "
                "prefill or decode graph."
            )
        GenAIBuilderHTP.weight_sharing.fset(self, value)  # type: ignore[attr-defined]


class Qwen3MoeBuilderHTP(GenAIBuilderHTP):
    @classmethod
    def _create_config_from_pretrained(
        cls, config: "PretrainedConfig", tokenizer_path: Optional[str | os.PathLike] = None
    ) -> GenAIConfig:
        gen_ai_config = super()._create_config_from_pretrained(config, tokenizer_path=tokenizer_path)
        gen_ai_config.expert_config = ExpertConfig.from_pretrained_config(config)
        _logger.debug("Expert config: %s", gen_ai_config.expert_config)
        return gen_ai_config
