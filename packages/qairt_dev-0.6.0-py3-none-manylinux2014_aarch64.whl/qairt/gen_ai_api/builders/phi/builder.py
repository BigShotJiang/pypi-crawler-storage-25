# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

import logging

from qairt.gen_ai_api.builders.gen_ai_builder_htp import GenAIBuilderHTP
from qairt.modules.genie_execution.genie_config import Sampler

logger = logging.getLogger(__name__)

PHI_EOS_TOKEN_ID = 32007


class PhiBuilderHTP(GenAIBuilderHTP):
    """
    Phi model-specific builder that provides optimal sampler parameters for Phi models.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.config.sampler_params = Sampler(temp=0.6)

        # Add additional EOS token ID for Phi models
        if isinstance(self.config.eos_token, int) and self.config.eos_token != PHI_EOS_TOKEN_ID:
            logger.debug(
                f"Changing EOS token from {self.config.eos_token} to [{self.config.eos_token}, {PHI_EOS_TOKEN_ID}] for Phi model"
            )
            self.config.eos_token = [self.config.eos_token, PHI_EOS_TOKEN_ID]
        elif isinstance(self.config.eos_token, list):
            if PHI_EOS_TOKEN_ID not in self.config.eos_token:
                logger.debug(
                    f"Adding EOS token {PHI_EOS_TOKEN_ID} to existing list {self.config.eos_token} for Phi model"
                )
                self.config.eos_token.append(PHI_EOS_TOKEN_ID)
