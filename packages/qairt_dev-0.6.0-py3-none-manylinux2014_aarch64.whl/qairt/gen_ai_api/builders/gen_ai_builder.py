# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
GenAI Builder constructed to shepherd a model from source framework to being prepared to run.
GenAI Builder builds a GenAIContainer object with all of the prepared model artifacts.
"""

import os
import textwrap
from abc import abstractmethod
from os import PathLike
from pathlib import Path
from typing import Optional

from transformers.configuration_utils import PretrainedConfig

from qairt.api.configs.common import BackendType
from qairt.gen_ai_api.builders.buildable import Buildable
from qairt.gen_ai_api.configs.gen_ai_config import GenAIConfig
from qairt.gen_ai_api.containers.gen_ai_containerable import GenAIContainerable
from qairt.modules.genie_execution.genie_config import PositionalEncoding, PositionalEncodingType, RopeScaling
from qairt.utils.loggers import get_logger


class GenAIBuilder(Buildable):
    """
    Abstract class for Generative AI Builder.
    """

    _logger = get_logger(__name__)

    def __init__(self, framework_model_path: PathLike | str, config: GenAIConfig, backend: BackendType):
        self.framework_model_path = Path(framework_model_path).resolve()
        self.config = config
        self._backend: BackendType = backend
        self._prepare_embedding_lut: bool = True
        """
        Flag to determine if the embedding layer should be handled as a lookup table (instead of compiling for HTP)
        This flag is incompatible with some dialog types:  SPD, LADE and KV-Share.
        """

    @classmethod
    def _create_config_from_pretrained(
        cls, config: PretrainedConfig, tokenizer_path: Optional[str | os.PathLike] = None
    ) -> GenAIConfig:
        """
        Creates a GenAI configuration from a pretrained model configuration.

        Args:
            config: The config object from the Hugging Face transformers library.
            tokenizer_path: Optional explicit path to the tokenizer. If provided, this takes precedence
                over convention-based discovery. Can be a file or directory (will look for tokenizer.json inside).

        Returns:
            GenAI configuration object.
        """
        # Determine tokenizer path
        if tokenizer_path:
            # Explicit path provided - use it
            tokenizer_path_obj = Path(tokenizer_path)
            if tokenizer_path_obj.is_dir():
                # If directory, look for tokenizer.json inside
                final_tokenizer_path = tokenizer_path_obj / "tokenizer.json"
            else:
                # If file, use it directly
                final_tokenizer_path = tokenizer_path_obj

            tokenizer_path_str = str(final_tokenizer_path)
        else:
            # Use convention: look for tokenizer.json in the model directory
            tokenizer_path_str = os.path.join(config._name_or_path, "tokenizer.json")

        if not os.path.exists(tokenizer_path_str):
            raise FileNotFoundError(
                textwrap.dedent(f"""\
                    Tokenizer file not found at '{tokenizer_path_str}'.
                    To resolve this, either:
                        1. Place 'tokenizer.json' from Hugging Face into the model directory '{config._name_or_path}'
                            (e.g. download it from https://huggingface.co/<model-id>/blob/main/tokenizer.json), or
                        2. Pass an explicit tokenizer path via the tokenizer_path argument.""")
            )

        # Merge text_config fields for multimodal models (e.g. Qwen3.5) where LM fields
        # are nested under a sub-config rather than at the top level.
        _text_config = getattr(config, "text_config", None)
        if _text_config is not None:
            src = _text_config if isinstance(_text_config, dict) else vars(_text_config)
            for k, v in src.items():
                if not k.startswith("_"):
                    setattr(config, k, v)

        n_embd = getattr(config, "hidden_size", None)
        n_heads = getattr(config, "num_attention_heads", None)

        # Convert rope_scaling to RopeScaling object (may be dict or SimpleNamespace)
        rope_scaling_obj = None
        rope_scaling_raw = getattr(config, "rope_scaling", None)
        if rope_scaling_raw:
            rope_scaling_dict = (
                rope_scaling_raw if isinstance(rope_scaling_raw, dict) else vars(rope_scaling_raw)
            )
            rope_scaling_obj = RopeScaling(**rope_scaling_dict)

        # bos_token
        if not hasattr(config, "bos_token_id") or config.bos_token_id is None:
            bos_token_id = (
                config.eos_token_id[-1]
                if isinstance(config.eos_token_id, (list, tuple))
                else config.eos_token_id
            )
            cls._logger.debug(
                "bos_token_id not found in HF config, using eos_token_id as bos_token_id: %s", bos_token_id
            )
        else:
            bos_token_id = config.bos_token_id

        gen_ai_config = GenAIConfig(
            tokenizer_path=tokenizer_path_str,
            context_length=4096,
            n_vocab=getattr(config, "n_vocab", getattr(config, "vocab_size")),
            n_heads=n_heads,
            n_layer=getattr(config, "num_hidden_layers", None),
            n_embd=n_embd,
            bos_token=bos_token_id,
            eos_token=config.eos_token_id,
            eot_token=getattr(config, "eot_token_id", None),
            rope_theta=getattr(config, "rope_theta", None),
            rope_scaling=rope_scaling_obj,
        )
        return gen_ai_config

    @abstractmethod
    def build(self) -> GenAIContainerable:
        """
        Prepares and builds the model for execution.

        Returns:
            GenAIContainer object.
        """
        raise NotImplementedError("build must be defined")
