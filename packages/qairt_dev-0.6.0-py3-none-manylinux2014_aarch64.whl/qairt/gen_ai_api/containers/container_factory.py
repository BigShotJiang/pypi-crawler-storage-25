# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

import json
import os
from os import PathLike
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from qairt.gen_ai_api.containers.gen_ai_containerable import GenAIContainerable

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_METADATA_FILENAME = "metadata.json"


def _read_manifest_type(path: str | PathLike) -> str:
    """Return the ``container_type`` string stored in *path*/metadata.json.

    Falls back to ``"GenAIContainer"`` when the field is absent so that
    containers saved before the manifest was introduced continue to load
    correctly.

    Args:
        path: Path to the container directory containing ``metadata.json``.

    Returns:
        The ``container_type`` string from the manifest, or ``"GenAIContainer"``
        if the field is absent.
    """
    metadata_path = os.path.join(path, _METADATA_FILENAME)
    with open(metadata_path, "r") as f:
        data = json.load(f)
    return data.get("manifest", {}).get("container_type", "GenAIContainer")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def load_container(path: str | PathLike) -> "GenAIContainerable":
    """Load a container from *path* by inspecting its manifest.

    Reads ``metadata.json`` inside *path*, extracts ``manifest.container_type``
    (which is the ``__name__`` of the class that saved the container), and
    dispatches to the appropriate subclass ``load()`` method.

    This function is the single authoritative dispatch point for container
    loading. `GenAIContainerable.load` delegates here so that callers do not
    need to know the concrete container type in advance.

    Args:
        path: Directory produced by a previous call to a container's ``save()``.

    Returns:
        The appropriate `GenAIContainerable` subclass instance.

    Raises:
        FileNotFoundError: If ``metadata.json`` does not exist under *path*.
        NotADirectoryError: If *path* is not a directory.
    """
    if not os.path.isdir(path):
        raise NotADirectoryError(f"Path {path} is not a directory.")

    container_type = _read_manifest_type(path)

    if container_type == "WorkflowContainer":
        from qairt.gen_ai_api.containers.workflow_container import WorkflowContainer

        return WorkflowContainer.load(path)
    elif container_type == "LLMContainer":
        from qairt.gen_ai_api.containers.llm_container import LLMContainer

        return LLMContainer.load(path)
    else:
        # "GenAIContainer" (legacy / no manifest) and any future subclasses.
        from qairt.gen_ai_api.containers.gen_ai_container import GenAIContainer

        return GenAIContainer.load(path)
