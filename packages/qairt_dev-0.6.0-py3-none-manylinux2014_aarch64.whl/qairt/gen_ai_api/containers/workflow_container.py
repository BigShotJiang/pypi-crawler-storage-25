# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import json
import os
from os import PathLike
from typing import Dict, List, Optional, Type, TypeVar

from qairt.api.configs.common import AISWBaseModel
from qairt.api.configs.device import Device
from qairt.gen_ai_api.configs.workflow import WorkflowGraph, WorkflowNodeRole
from qairt.gen_ai_api.containers.gen_ai_container import GenAIContainer
from qairt.gen_ai_api.containers.gen_ai_containerable import ContainerManifest, GenAIContainerable
from qairt.gen_ai_api.containers.llm_container import LLMContainer
from qairt.gen_ai_api.executors.gen_ai_executable import GenAIExecutable
from qairt.gen_ai_api.executors.t2t_executor import T2TExecutor

T = TypeVar("T", bound="WorkflowContainer")


class WorkflowContainerManifest(ContainerManifest):
    """
    Manifest for a :class:`WorkflowContainer`.

    Extends the base :class:`~qairt.gen_ai_api.containers.gen_ai_containerable.ContainerManifest`
    with the list of sub-container directory names stored under the workflow
    root.  The concrete type of each sub-container is determined at load time
    by reading that sub-container's own ``metadata.json`` — it is not
    duplicated here.
    """

    containers: List[str]


class WorkflowContainerMetadata(AISWBaseModel):
    """Metadata written to ``metadata.json`` for a :class:`WorkflowContainer`."""

    manifest: WorkflowContainerManifest


class WorkflowContainer(GenAIContainerable):
    """
    Container that aggregates multiple GenAIContainer instances.
    """

    def __init__(self, containers: Dict[str, GenAIContainerable], workflow_graph: WorkflowGraph):
        # Store containers keyed by name for type-safe access
        self._containers = containers
        self._workflow_graph = workflow_graph

    @classmethod
    def _pipeline_config_file(cls, path: str | PathLike) -> str:
        return os.path.join(path, "pipeline_config_metadata.json")

    def save(self, dest: str | PathLike, *, exist_ok: bool = False):
        """Save all aggregated containers."""

        if not os.path.isdir(dest):
            os.makedirs(dest, exist_ok=exist_ok)

        for name, container in self._containers.items():
            subdest = os.path.join(dest, name)
            container.save(subdest, exist_ok=exist_ok)

        # Persist the pipeline configuration metadata in the root directory
        with open(self._pipeline_config_file(dest), "w") as f:
            f.write(self._workflow_graph.model_dump_json())

        # Write the manifest so the factory can identify this as a WorkflowContainer
        # and enumerate its sub-containers without scanning the directory.
        metadata = WorkflowContainerMetadata(
            manifest=WorkflowContainerManifest(
                container_type=type(self).__name__,
                containers=list(self._containers.keys()),
            )
        )
        with open(self._metadata_file(dest), "w") as f:
            f.write(metadata.model_dump_json())

    @classmethod
    def load(cls: Type[T], path: str | PathLike) -> T:
        """Load a WorkflowContainer from disk.

        Reads ``metadata.json`` to obtain the list of sub-container directory
        names, then uses the container factory to load each one.  Because the
        factory inspects each sub-container's own manifest, nested
        :class:`WorkflowContainer` instances are handled recursively without
        any additional logic here.
        """
        from qairt.gen_ai_api.containers.container_factory import load_container

        if not os.path.isdir(path):
            raise NotADirectoryError(f"{path} is not a directory")

        # Read the manifest to discover sub-container names.
        metadata_file = cls._metadata_file(path)
        if not os.path.isfile(metadata_file):
            raise FileNotFoundError(f"Container metadata file not found: {metadata_file}")

        with open(metadata_file, "r") as f:
            raw = json.load(f)

        manifest = WorkflowContainerManifest(**raw["manifest"])

        containers: Dict[str, GenAIContainerable] = {}
        for name in manifest.containers:
            subpath = os.path.join(path, name)
            # The factory reads each sub-container's own manifest to determine
            # its type, enabling transparent recursive loading.
            containers[name] = load_container(subpath)

        # Load the pipeline configuration metadata from the root directory
        pipeline_config_file = cls._pipeline_config_file(path)
        if not os.path.isfile(pipeline_config_file):
            raise FileNotFoundError(f"{pipeline_config_file} not found")
        with open(pipeline_config_file, "r") as f:
            pipeline_config_metadata = WorkflowGraph.model_validate_json(f.read())

        return cls(containers, pipeline_config_metadata)

    def get_executor(
        self,
        device: Optional[Device] = None,
        **kwargs,
    ) -> GenAIExecutable:
        """
        Determine and instantiate the appropriate executor.

        Parameters
        ----------
        device : Optional[Device]
            Optional device specification passed through to the executor.
        **kwargs :
            Additional keyword arguments forwarded to the concrete executor
            constructors (e.g., ``qairt_sdk_root``, ``clean_up``).

        Returns
        -------
        GenAIExecutable
            An instance of the concrete executor matching the workflow.
        """
        graph: WorkflowGraph = self._workflow_graph

        if not graph.nodes:
            raise ValueError("WorkflowGraph contains no nodes – cannot select executor")

        # Simple heuristic: look at the first node's role.
        # TODO: Resolve this in AISW-172889
        first_node = graph.nodes[0]
        first_role = first_node.role

        if first_role == WorkflowNodeRole.TEXT_GENERATOR:
            target = self._containers[first_node.name]
            assert isinstance(target, LLMContainer)
            return T2TExecutor(
                target._models,
                target._gen_ai_config,
                target._backend,
                device=device,
                backend_extensions_config=target._backend_extensions_config,
                qairt_sdk_root=kwargs.get("qairt_sdk_root"),
                clean_up=kwargs.get("clean_up", True),
                draft_models=None,
                draft_model_backend_extensions_config=None,
            )
        elif first_role == WorkflowNodeRole.IMAGE_ENCODER:
            # TODO: Implement image-encoder executor path (AISW-172889)
            raise NotImplementedError("IMAGE_ENCODER executor path is not yet implemented.")
        else:
            raise NotImplementedError(f"Unsupported node role: {first_role}")
