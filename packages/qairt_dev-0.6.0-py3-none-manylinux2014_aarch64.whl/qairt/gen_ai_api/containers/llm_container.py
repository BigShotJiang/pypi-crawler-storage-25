# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""LLM container — text-generator specific GenAI container."""

import json
import os
import shutil
import tempfile
import time
import warnings
from datetime import datetime
from os import PathLike
from pathlib import Path
from typing import Dict, List, Optional, Union

from typing_extensions import Self

from qairt import __sdk_version__ as sdk_version
from qairt.api.compiled_model import CompileConfig, CompiledModel
from qairt.api.configs.common import BackendType
from qairt.api.configs.device import Device
from qairt.gen_ai_api.configs.eaglet_config import EagletRunConfig
from qairt.gen_ai_api.configs.gen_ai_config import GenAIConfig
from qairt.gen_ai_api.containers.gen_ai_container import GenAIContainer
from qairt.gen_ai_api.executors.genie_dialog_factory import GenieDialogFactory
from qairt.gen_ai_api.executors.t2t_executor import T2TExecutor
from qairt.modules.cache_module import CacheModule
from qairt.modules.dlc_module import DlcModule
from qairt.modules.genie_execution.genie_config import BasicDialog, ExportFormat, GenieConfig
from qairt.modules.genie_execution.genie_t2t_runner_helper import GenieT2TRunnerHelper
from qairt.utils import loggers
from qti.aisw.tools.core.utilities.devices.api.device_factory import DeviceFactory
from qti.aisw.tools.core.utilities.devices.api.device_interface import DeviceInterface
from qti.aisw.tools.core.utilities.devices.x86_64_linux.x86_64_linux_device import X86LinuxDevice


class LLMContainer(GenAIContainer):
    """Container for text-generator (LLM) models.

    Produced by a :class:`~qairt.gen_ai_api.builders.gen_ai_builder_htp.GenAIBuilderHTP`
    and consumed by a :class:`~qairt.gen_ai_api.executors.t2t_executor.T2TExecutor`.

    Extends :class:`~qairt.gen_ai_api.containers.gen_ai_container.GenAIContainer`
    with LLM-specific artifacts:

    * tokenizer
    * :class:`~qairt.gen_ai_api.configs.gen_ai_config.GenAIConfig` (context length,
      vocabulary, chat template, embedding LUT, speculative-decoding config, …)
    * compiled model splits (context binaries or DLCs)
    * LoRA adapter binaries
    * Eaglet draft container and token map

    On-disk layout produced by :meth:`save`::

        dest/
          metadata.json              # ContainerMetadata (backend + manifest)
          backend_extensions.json    # optional
          tokenizer.json
          gen_ai_config.json
          models/
            split_0/
              model.bin              # context binary  (or model.dlc)
              <use_case>.bin         # LoRA adapter(s)
            split_1/ …
            use_cases.json
          chat_template/             # optional
          embedding_table.bin        # optional
          eaglet_draft_container/    # optional
          eaglet_token_map.json      # optional
    """

    _logger = loggers.get_logger(name=__name__)

    def __init__(
        self,
        models: List[CompiledModel],
        gen_ai_config: GenAIConfig,
        backend: BackendType,
        *,
        backend_extensions_config: Optional[Dict] = None,
        compile_config: Optional[CompileConfig] = None,
        profiling_report: Optional[Dict] = None,
    ):
        """Create an LLMContainer.

        Args:
            models: List of :class:`~qairt.api.compiled_model.CompiledModel` instances
                containing the LLM split(s) prepared for QAIRT execution.
            gen_ai_config: Configuration metadata for the GenAI model.
            backend: The backend the artifacts in this container were prepared for.
            backend_extensions_config: Backend extensions configuration for execution.
            compile_config: Compiled-model configuration metadata.  Ignored when
                *backend_extensions_config* is also provided.
            profiling_report: Serialized memory profiling report data. Defaults to None.
        """
        if not models:
            raise ValueError("LLMContainer must have at least one CompiledModel")

        # Resolve compile_config vs backend_extensions_config before calling super()
        if compile_config and backend_extensions_config:
            self._logger.warning(
                "Both a CompileConfig and backend extensions config were provided. Ignoring CompileConfig."
            )
        elif compile_config is not None:
            backend_extensions_config = compile_config.model_dump(context={"backend_extensions": True})

        super().__init__(backend, backend_extensions_config=backend_extensions_config)

        self._profiling_report: Dict | None = profiling_report
        self._models: List[CompiledModel] = models
        self._gen_ai_config: GenAIConfig = gen_ai_config

    # ------------------------------------------------------------------
    # LLM-specific file-path helpers
    # ------------------------------------------------------------------

    @classmethod
    def _gen_ai_config_file(cls, path: str | PathLike) -> str:
        return os.path.join(path, "gen_ai_config.json")

    @classmethod
    def _tokenizer_file(cls, path: str | PathLike) -> str:
        return os.path.join(path, "tokenizer.json")

    @classmethod
    def _model_dir(cls, path: str | PathLike) -> str:
        return os.path.join(path, "models")

    @classmethod
    def _create_split_dir(cls, path: Union[str, PathLike], index: int) -> str:
        split_dir = cls._split_dir(path, index)
        os.makedirs(split_dir, exist_ok=True)
        return split_dir

    @classmethod
    def _split_dir(cls, path: Union[str, PathLike], index: int) -> str:
        return os.path.join(cls._model_dir(path), f"split_{index}")

    @classmethod
    def _model_dlc(cls, path: str | PathLike, index: int) -> str:
        return os.path.join(cls._split_dir(path, index), "model.dlc")

    @classmethod
    def _model_ctx_bin(cls, path: str | PathLike, index: int) -> str:
        return os.path.join(cls._split_dir(path, index), "model.bin")

    @classmethod
    def _lora_dir(cls, path: str | PathLike) -> str:
        return os.path.join(path, "lora")

    @classmethod
    def _lora_bin(cls, path: str | PathLike, use_case_name: str, index: int) -> str:
        return os.path.join(cls._split_dir(path, index), f"{use_case_name}.bin")

    @classmethod
    def _chat_template_dir(cls, path: str | PathLike) -> str:
        return os.path.join(path, "chat_template")

    @classmethod
    def _embedding_table(cls, path: str | PathLike) -> str:
        return os.path.join(path, "embedding_table.bin")

    @classmethod
    def _draft_container(cls, path: str | PathLike) -> str:
        return os.path.join(path, "eaglet_draft_container")

    @classmethod
    def _eaglet_token_map(cls, path: str | PathLike) -> str:
        return os.path.join(path, "eaglet_token_map.json")

    @classmethod
    def _profiling_report_file(cls, path: str | PathLike) -> str:
        return os.path.join(path, "profiling_report.json")

    # ------------------------------------------------------------------
    # Save
    # ------------------------------------------------------------------

    def write_use_cases_json(self, dest: str | os.PathLike):
        """Write ``use_cases.json`` inside the models directory.

        Extracts all unique use-case names from the models'
        ``lora_use_case_binary_map`` and writes them to a JSON file so that
        :meth:`load` can reconstruct the LoRA adapter map.

        Args:
            dest: Base destination path where the models directory resides.
        """
        use_cases: set[str] = set()
        for model in self._models:
            if hasattr(model, "lora_use_case_binary_map"):
                use_cases.update(model.lora_use_case_binary_map.keys())

        if not use_cases:
            return

        models_dir = os.path.join(dest, "models")
        os.makedirs(models_dir, exist_ok=True)

        use_cases_path = os.path.join(models_dir, "use_cases.json")
        with open(use_cases_path, "w") as f:
            json.dump({"use_cases": sorted(use_cases)}, f, indent=2)

    def save(self, dest: str | PathLike, *, exist_ok: bool = False):
        """Save all artifacts to disk.

        Calls :meth:`GenAIContainer.save` to write the common files
        (``metadata.json``, ``backend_extensions.json``) and then writes the
        LLM-specific artifacts.

        Args:
            dest: Path to save the artifacts.
            exist_ok: When ``False`` (default) raise :exc:`ValueError` if
                *dest* already exists.
        """
        # Write common files (directory creation, metadata.json, backend_extensions.json)
        super().save(dest, exist_ok=exist_ok)

        # Copy tokenizer
        shutil.copyfile(self._gen_ai_config.tokenizer_path, self._tokenizer_file(dest))

        # Copy chat template if present
        if self._gen_ai_config.chat_template:
            self._gen_ai_config.chat_template.save(self._chat_template_dir(dest))

        # Copy embedding LUT if present
        if self._gen_ai_config.embedding_config:
            if not os.path.exists(self._gen_ai_config.embedding_config.embed_path):
                raise FileNotFoundError(
                    f"Embedding LUT file {self._gen_ai_config.embedding_config.embed_path} does not exist."
                )
            shutil.copyfile(self._gen_ai_config.embedding_config.embed_path, self._embedding_table(dest))

        # Save model splits
        if self._models:
            os.makedirs(self._model_dir(dest), exist_ok=True)

            for i, model in enumerate(self._models):
                self._create_split_dir(dest, i)

                if isinstance(model.module, CacheModule):
                    model.module.save(self._model_ctx_bin(dest, i))

                    if model.lora_use_case_binary_map:
                        for use_case_name, path in model.lora_use_case_binary_map.items():
                            if use_case_name == "base":
                                continue  # Already saved
                            shutil.copy2(path, self._lora_bin(dest, use_case_name, i))

                elif isinstance(model.module, DlcModule):
                    model.module.save(self._model_dlc(dest, i))
                else:
                    raise TypeError(f"Unsupported Compiled model module type {type(model.module)}")

            self.write_use_cases_json(dest)

        # Copy Eaglet draft container and token map if present
        if isinstance(self._gen_ai_config.speculative_run_config, EagletRunConfig):
            assert self._gen_ai_config.speculative_run_config.draft_container
            shutil.copytree(
                self._gen_ai_config.speculative_run_config.draft_container,
                self._draft_container(dest),
                dirs_exist_ok=True,
            )
            if self._gen_ai_config.speculative_run_config.draft_token_map:
                shutil.copyfile(
                    self._gen_ai_config.speculative_run_config.draft_token_map,
                    self._eaglet_token_map(dest),
                )

        # Write GenAI config
        with open(self._gen_ai_config_file(dest), "w") as f:
            f.write(self._gen_ai_config.model_dump_json(by_alias=True, exclude_none=True, indent=2))

        if self._profiling_report:
            with open(self._profiling_report_file(dest), "w") as f:
                json.dump(self._profiling_report, f, indent=4)

    @classmethod
    def _load_lora_binaries(
        cls, path: Union[str, PathLike], index: int, use_cases: List[str], base_filename: str
    ) -> dict:
        """Load LoRA binaries from the split directory for a given model index.

        Args:
            path: Base path to the container.
            index: Model index.
            base_filename: Name of the base model file to exclude.

        Returns:
            Mapping of use_case_name to :class:`~pathlib.Path` of LoRA binary.
        """
        lora_map = {}
        split_dir = Path(cls._split_dir(path, index))

        for use_case_name in use_cases:
            if use_case_name == "base":
                continue
            candidate = split_dir / f"{use_case_name}.bin"
            if candidate.exists():
                lora_map[use_case_name] = candidate

        return lora_map

    @classmethod
    def load(cls, path: str | PathLike) -> Self:
        """Load an :class:`LLMContainer` from disk.

        Args:
            path: Directory produced by a previous call to :meth:`save`.

        Returns:
            An :class:`LLMContainer` instance with the loaded artifacts.

        Raises:
            NotADirectoryError: If *path* is not a directory or the models
                sub-directory is missing.
            FileNotFoundError: If required files (tokenizer, gen_ai_config)
                are absent.
        """
        if not os.path.isdir(path):
            raise NotADirectoryError(
                f"Path {path} is not a directory.  This should be a directory containing (minimally) "
                f"a config file {cls._gen_ai_config_file('')}, "
                f"a tokenizer file ({cls._tokenizer_file('')}), and "
                f"a model directory ({cls._model_dir('')}). "
                "There may be other files and directories as well."
            )

        backend, backend_extensions_config = GenAIContainer._load_common(path)

        with open(cls._gen_ai_config_file(path), "r") as f:
            gen_ai_config = GenAIConfig(**json.load(f))

        gen_ai_config.tokenizer_path = str(Path(cls._tokenizer_file(path)).resolve())
        if not os.path.exists(gen_ai_config.tokenizer_path):
            raise FileNotFoundError(f"Tokenizer file not found at location: {gen_ai_config.tokenizer_path}")

        if gen_ai_config.embedding_config:
            gen_ai_config.embedding_config.embed_path = str(Path(cls._embedding_table(path)).resolve())
            if not os.path.exists(gen_ai_config.embedding_config.embed_path):
                raise FileNotFoundError(
                    f"Embedding LUT file not found at location: {gen_ai_config.embedding_config.embed_path}"
                )

        if isinstance(gen_ai_config.speculative_run_config, EagletRunConfig):
            gen_ai_config.speculative_run_config.draft_token_map = Path(cls._eaglet_token_map(path)).resolve()
            gen_ai_config.speculative_run_config.draft_container = Path(cls._draft_container(path)).resolve()

        profiling_report = None
        if os.path.exists(cls._profiling_report_file(path)):
            with open(cls._profiling_report_file(path), "r") as f:
                profiling_report = json.load(f)

        models = []
        if not os.path.isdir(cls._model_dir(path)):
            raise NotADirectoryError(f"Serialized model directory does not exist: {cls._model_dir(path)}")

        i = 0
        use_cases_path = os.path.join(cls._model_dir(path), "use_cases.json")
        try:
            with open(use_cases_path, "r") as f:
                use_cases = json.load(f)["use_cases"]
        except FileNotFoundError:
            use_cases = []

        while os.path.isfile(cls._model_ctx_bin(path, i)) or os.path.isfile(cls._model_dlc(path, i)):
            model = None
            lora_use_case_binary_map = {}

            if os.path.isfile(cls._model_ctx_bin(path, i)):
                base_path = Path(cls._model_ctx_bin(path, i))
                model = CompiledModel(CacheModule.load(path=base_path))
                lora_use_case_binary_map["base"] = base_path
                lora_use_case_binary_map.update(cls._load_lora_binaries(path, i, use_cases, f"model_{i}.bin"))

            elif os.path.isfile(cls._model_dlc(path, i)):
                base_path = Path(cls._model_dlc(path, i))
                model = CompiledModel(DlcModule.load(path=base_path))
                lora_use_case_binary_map["base"] = base_path
                lora_use_case_binary_map.update(cls._load_lora_binaries(path, i, use_cases, f"model_{i}.dlc"))

            if model is not None:
                model.lora_use_case_binary_map = lora_use_case_binary_map
                models.append(model)

            i += 1

        return cls(
            models,
            gen_ai_config,
            backend,
            backend_extensions_config=backend_extensions_config,
            profiling_report=profiling_report,
        )

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def get_executor(
        self,
        device: Optional[Device] = None,
        clean_up: bool = True,
        prepare_environment: bool = True,
        **kwargs,
    ) -> T2TExecutor:
        """Return a :class:`~qairt.gen_ai_api.executors.t2t_executor.T2TExecutor`.

        .. deprecated::
            Use ``WorkflowBuilder`` to construct a ``WorkflowContainer`` and
            call ``get_executor()`` on that instead::

                # Before
                container.get_executor(device=device)
                # After
                WorkflowBuilder.from_builders({'genai': builder}).build().get_executor(device=device)

        Args:
            device: Optional device to run the executor on.
            clean_up: Whether to clean up resources when the executor is done.
            prepare_environment: Whether to prepare the environment for the executor.
            **kwargs: Additional keyword arguments passed to the executor.

        Returns:
            A :class:`~qairt.gen_ai_api.executors.t2t_executor.T2TExecutor` instance.

        Raises:
            ValueError: If no models were loaded into the container.
        """
        warnings.warn(
            "LLMContainer.get_executor() is deprecated and will be removed in a future release. "
            "Use WorkflowBuilder to construct a WorkflowContainer and call get_executor() on that instead. "
            "Replace: container.get_executor(device=device) "
            "With:    WorkflowBuilder.from_builders({'genai': builder}).build().get_executor(device=device)",
            DeprecationWarning,
            stacklevel=2,
        )
        if not self._models:
            raise ValueError("No models were loaded into the container. Nothing to execute.")

        draft_models = None
        draft_model_backend_extensions_config = None
        if (
            self._gen_ai_config.speculative_run_config
            and isinstance(self._gen_ai_config.speculative_run_config, EagletRunConfig)
            and self._gen_ai_config.speculative_run_config.draft_container
        ):
            draft_container = LLMContainer.load(self._gen_ai_config.speculative_run_config.draft_container)
            draft_models = draft_container._models
            draft_model_backend_extensions_config = draft_container._backend_extensions_config

        executor = T2TExecutor(
            self._models,
            self._gen_ai_config,
            self._backend,
            device=device,
            backend_extensions_config=self._backend_extensions_config,
            qairt_sdk_root=kwargs.get("qairt_sdk_root"),
            clean_up=clean_up,
            draft_models=draft_models,
            draft_model_backend_extensions_config=draft_model_backend_extensions_config,
        )
        if prepare_environment:
            executor.prepare_environment()
        return executor

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def _extract_binary_info_from_cache(self, cache_module: CacheModule, binary_type: str = "target") -> dict:
        raise NotImplementedError("binary-info in the genie metadata isn't currently supported.")

    def _generate_genie_dlc_metadata(self, genie_config: GenieConfig) -> dict:
        """Generate Genie DLC metadata conforming to the schema.

        Args:
            genie_config: The :class:`~qairt.modules.genie_execution.genie_config.GenieConfig`
                object for this container.

        Returns:
            Metadata structure conforming to the Genie metadata schema.
        """
        header = {
            "version": {"major": 1, "minor": 0, "patch": 0},
            "timestamp": {"created": int(time.time()), "last-modified": int(time.time())},
            "createdBy": {"tool": "QAIRT", "version": sdk_version},
        }

        records = []
        dialog_obj = genie_config.dialog
        ctx_bins = []
        if isinstance(dialog_obj, BasicDialog):
            binary = dialog_obj.engine.model.binary
            if binary and getattr(binary, "ctx_bins", None):
                ctx_bins = list(binary.ctx_bins)

        for idx, model in enumerate(self._models):
            if isinstance(model.module, CacheModule) and model.module.path:
                rec_name = Path(str(ctx_bins[idx])).name
                records.append(
                    {
                        "name": rec_name,
                        "type": "context-binary",
                        "binary-info": None,  # TODO: AISW-171310 Extend Genie metadata support
                    }
                )

        records.append({"name": "genie_config.json", "type": "genie-config"})
        use_cases = [{"name": "default", "config": {"type": "node", "name": "genie_config.json"}}]

        return {"header": header, "records": records, "use-cases": use_cases}

    def _export_container_as_dlc(
        self,
        dest: str | PathLike,
        genie_config: GenieConfig,
    ) -> None:
        """Export the LLM container as a DLC with all files embedded as records.

        Args:
            dest: Destination path for the output DLC file.
            genie_config: Prepared :class:`~qairt.modules.genie_execution.genie_config.GenieConfig`.

        Raises:
            ImportError: If ``qti.aisw.dlc_utils`` cannot be imported.
        """
        try:
            import qti.aisw.dlc_utils as dlc
        except ImportError:
            raise ImportError("Unable to import qti.aisw.dlc_utils for exporting container as DLC.")

        seed_dlc_module: DlcModule = self._get_seed_dlc()
        genie_metadata = self._generate_genie_dlc_metadata(genie_config)
        exported_config = genie_config.export(ExportFormat.LM_EXECUTOR)

        with tempfile.TemporaryDirectory() as tmp_dir:
            metadata_path = os.path.join(tmp_dir, "genie_metadata.json")
            with open(metadata_path, "w") as f:
                json.dump(genie_metadata, f, indent=2)
            seed_dlc_module.updater.add_record(metadata_path, dlc.modeltools.DlcRecordType.GENAI_METADATA)

            config_path = os.path.join(tmp_dir, "genie_config.json")
            with open(config_path, "w") as f:
                json.dump(exported_config, f, indent=2)
            seed_dlc_module.updater.add_record(config_path, dlc.modeltools.DlcRecordType.GENAI_ARTIFACT)

            dialog_obj = genie_config.dialog
            if isinstance(dialog_obj, BasicDialog):
                binary = dialog_obj.engine.model.binary
                if binary:
                    for cb in binary.ctx_bins:
                        rec_path = os.path.join(dest, str(cb))
                        if not os.path.isfile(rec_path):
                            raise FileNotFoundError(f"Context binary not found for DLC export: {rec_path}")
                        seed_dlc_module.updater.add_record(
                            rec_path, dlc.modeltools.DlcRecordType.GENAI_ARTIFACT
                        )

            seed_dlc_module.updater.save()
            timestamped_name = f"model-{datetime.now().astimezone().strftime('%Y%m%d-%H%M')}.dlc"
            seed_dlc_module.save(os.path.join(dest, timestamped_name))

    def export(
        self,
        dest: str | PathLike,
        *,
        export_format: ExportFormat = ExportFormat.DIALOG,
        target_device: Optional[Device] = None,
        push_to_target: bool = False,
    ):
        """Export container artifacts to a destination directory on the host or on a target device.

        Container artifacts for the model are always included. If a
        *target_device* is specified, bin/lib files from the SDK for that
        target are included in the export. Further, if *push_to_target* is
        ``True``, *dest* should be a location on the *target_device* and all
        exported files will be placed at that location.

        The exported contents are identical to what is produced by the
        ``GenieT2TRunner.load()`` method.

        Args:
            dest: The path where the container contents will be exported.
                If *push_to_target* is ``True`` this is a path on the target device.
            export_format: The export format that should be used.
            target_device: The target device to collect SDK artifacts for.
            push_to_target: When ``True`` the export is performed directly on
                the device using the device interface; otherwise the export is
                performed locally.

        Raises:
            NotADirectoryError: If the destination path exists but is not a directory.
            ValueError: If *push_to_target* is ``True`` but no *target_device* is given.
        """
        qairt_sdk_root: str | os.PathLike = str(os.environ.get("QAIRT_SDK_ROOT", ""))

        if push_to_target and not target_device:
            raise ValueError("A target device must be specified to push to it.")

        dest_device_interface: DeviceInterface = X86LinuxDevice()
        if target_device:
            target_device_interface: DeviceInterface = (
                target_device.info
                if isinstance(target_device.info, DeviceInterface)
                else DeviceFactory.create_device(target_device.info)
            )
            if push_to_target:
                dest_device_interface = target_device_interface

        dest_device_interface.remove(dest)
        dest_device_interface.make_directory(dest)

        if target_device:
            target_bins, target_libs = GenieT2TRunnerHelper.get_sdk_artifacts(
                target_device_interface, qairt_sdk_root, self._backend
            )

            lib_dir = os.path.join(dest, "lib")
            dest_device_interface.make_directory(lib_dir)
            for lib in target_libs:
                dest_device_interface.push(lib, os.path.join(lib_dir, os.path.basename(lib)))

            bin_dir = os.path.join(dest, "bin")
            dest_device_interface.make_directory(bin_dir)
            for bin in target_bins:
                dest_device_interface.push(bin, os.path.join(bin_dir, os.path.basename(bin)))

        backend_extensions_path = None
        if self._backend_extensions_config:
            with tempfile.NamedTemporaryFile(delete=False, mode="w", suffix=".json") as tmp_cfg:
                tmp_cfg.write(json.dumps(self._backend_extensions_config, indent=2))
                backend_extensions_path = tmp_cfg.name

        draft_container_models = None
        draft_container_backend_extensions_path = None
        if (
            self._gen_ai_config.speculative_run_config
            and isinstance(self._gen_ai_config.speculative_run_config, EagletRunConfig)
            and self._gen_ai_config.speculative_run_config.draft_container
        ):
            draft_container = LLMContainer.load(self._gen_ai_config.speculative_run_config.draft_container)
            draft_container_models = draft_container._models if draft_container else None
            if draft_container._backend_extensions_config:
                with tempfile.NamedTemporaryFile(delete=False, mode="w", suffix=".json") as tmp_cfg:
                    tmp_cfg.write(json.dumps(draft_container._backend_extensions_config, indent=2))
                    draft_container_backend_extensions_path = tmp_cfg.name

        tmp_cfg_path = None
        try:
            dialog = GenieDialogFactory.create_dialog(
                self._backend,
                self._gen_ai_config,
                self._models,
                backend_extensions_path or "",
                draft_models=draft_container_models,
                draft_backend_extensions_path=draft_container_backend_extensions_path or "",
            )
            config = GenieConfig(dialog=dialog)
            _config, _config_artifacts = GenieT2TRunnerHelper.prepare_config(config)

            with tempfile.NamedTemporaryFile(delete=False, mode="w") as tmp_cfg:
                tmp_cfg.write(json.dumps(_config.export(export_format), indent=2))
                tmp_cfg_path = tmp_cfg.name
            dest_device_interface.push(tmp_cfg_path, os.path.join(dest, "genie_config.json"))

            artifacts_dir = os.path.join(dest, "artifacts")
            dest_device_interface.make_directory(artifacts_dir)
            for dst, src in _config_artifacts.items():
                dest_device_interface.push(src, os.path.join(artifacts_dir, os.path.basename(dst)))
        finally:
            if backend_extensions_path:
                os.unlink(backend_extensions_path)
            if draft_container_backend_extensions_path:
                os.unlink(draft_container_backend_extensions_path)
            if tmp_cfg_path and os.path.exists(tmp_cfg_path):
                os.unlink(tmp_cfg_path)

        if export_format == ExportFormat.LM_EXECUTOR:
            if isinstance(_config.dialog, BasicDialog):
                extensions_rel_path = getattr(_config.dialog.engine.backend, "extensions", None)
                if extensions_rel_path:
                    ext_name = os.path.basename(extensions_rel_path)
                    src_path = os.path.join(artifacts_dir, ext_name)
                    dst_path = os.path.join(dest, ext_name)
                    with tempfile.NamedTemporaryFile(delete=False) as tmp_local:
                        tmp_local_path = tmp_local.name
                    try:
                        dest_device_interface.pull(src_path, tmp_local_path)
                        dest_device_interface.push(tmp_local_path, dst_path)
                        dest_device_interface.remove(src_path)
                        _config.dialog.engine.backend.extensions = ext_name
                    finally:
                        if os.path.exists(tmp_local_path):
                            os.unlink(tmp_local_path)

            self._export_container_as_dlc(dest, _config)
            dest_device_interface.remove(artifacts_dir)
            dest_device_interface.remove(os.path.join(dest, "genie_config.json"))

    @staticmethod
    def _get_seed_dlc() -> DlcModule:
        """Create a minimal ONNX model and convert it to a DLC, returning a :class:`~qairt.modules.dlc_module.DlcModule`.

        Raises:
            ImportError: If converter dependencies are unavailable (not supported on OE-Linux).
        """
        try:
            from qairt.api.converter._convert import convert  # lazy import: build-time only
            from qti.aisw.tools.core.utilities.framework.frameworks.onnx.onnx_model_helper import (
                OnnxModelHelper,  # lazy import: build-time only
            )
        except ImportError as e:
            raise ImportError("Converter dependencies are not available.") from e

        model = OnnxModelHelper.create_minimal_onnx_model()

        with tempfile.NamedTemporaryFile(delete=False, suffix=".onnx") as tmp_onnx:
            OnnxModelHelper.save_model(model, tmp_onnx.name)
            onnx_path = tmp_onnx.name

        try:
            converted_model = convert(onnx_path)
        finally:
            os.unlink(onnx_path)

        return converted_model.module
