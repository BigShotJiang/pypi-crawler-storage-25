# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""Generic base class for GenAI model containers."""

import json
import os
from os import PathLike
from typing import Dict, Optional, Tuple

from qairt.api.configs.common import AISWBaseModel, BackendType
from qairt.gen_ai_api.containers.gen_ai_containerable import ContainerManifest, GenAIContainerable
from qairt.utils import loggers


class ContainerMetadata(AISWBaseModel):
    """Container metadata for serialization/deserialization.

    The ``manifest`` field identifies the concrete container class that
    produced this directory so that
    :func:`~qairt.gen_ai_api.containers.container_factory.load_container`
    can dispatch to the correct ``load()`` implementation without any
    caller-side knowledge of the container type.
    """

    backend: BackendType
    manifest: ContainerManifest


class GenAIContainer(GenAIContainerable):
    """Generic base class for GenAI model containers.

    Provides the common on-disk infrastructure shared by all container types:

    * ``metadata.json`` — :class:`ContainerMetadata` (backend + manifest)
    * ``backend_extensions.json`` — optional backend-extensions configuration

    Concrete subclasses (e.g.
    :class:`~qairt.gen_ai_api.containers.llm_container.LLMContainer`,
    :class:`~qairt.gen_ai_api.containers.vision_encoder_container.VisionEncoderContainer`)
    call ``super().save()`` to write the common files and then append their
    own model-specific artifacts.  For loading, subclasses call
    :meth:`_load_common` to retrieve the shared fields and then construct
    their own instance.
    """

    _logger = loggers.get_logger(name=__name__)

    def __init__(
        self,
        backend: BackendType,
        *,
        backend_extensions_config: Optional[Dict] = None,
    ):
        self._backend: BackendType = backend
        self._backend_extensions_config: Dict | None = backend_extensions_config

    # ------------------------------------------------------------------
    # Common file-path helpers
    # ------------------------------------------------------------------

    @classmethod
    def _backend_ext_file(cls, path: str | PathLike) -> str:
        return os.path.join(path, "backend_extensions.json")

    # ------------------------------------------------------------------
    # Common save / load infrastructure
    # ------------------------------------------------------------------

    def save(self, dest: str | PathLike, *, exist_ok: bool = False):
        """Write the common container files to *dest*.

        Creates the destination directory, writes ``metadata.json`` and
        (when present) ``backend_extensions.json``.  Subclasses should call
        ``super().save(dest, exist_ok=exist_ok)`` first and then write their
        own model-specific artifacts.

        Args:
            dest: Destination directory.  Created if it does not exist.
            exist_ok: When ``False`` (default) raise :exc:`ValueError` if
                *dest* already exists.

        Raises:
            NotADirectoryError: If *dest* exists but is not a directory.
            ValueError: If *dest* already exists and *exist_ok* is ``False``.
        """
        if os.path.exists(dest):
            if not os.path.isdir(dest):
                raise NotADirectoryError(f"Destination path {dest} exists but is not a directory")
            elif not exist_ok:
                raise ValueError(
                    f"Destination path {dest} already exists.  "
                    "To use an existing directory, specify exist_ok=True"
                )
        else:
            os.makedirs(dest, exist_ok=exist_ok)

        with open(self._metadata_file(dest), "w") as f:
            f.write(
                ContainerMetadata(
                    backend=self._backend,
                    manifest=ContainerManifest(container_type=type(self).__name__),
                ).model_dump_json()
            )

        if self._backend_extensions_config:
            with open(self._backend_ext_file(dest), "w") as f:
                f.write(json.dumps(self._backend_extensions_config, indent=2))

    @classmethod
    def _load_common(cls, path: str | PathLike) -> Tuple[BackendType, Optional[Dict]]:
        """Read the common fields from a saved container directory.

        Reads ``metadata.json`` to obtain the backend type and
        ``backend_extensions.json`` (if present) to obtain the
        backend-extensions configuration.

        Args:
            path: Directory produced by a previous call to :meth:`save`.

        Returns:
            A ``(backend, backend_extensions_config)`` tuple.

        Raises:
            NotADirectoryError: If *path* is not a directory.
        """
        if not os.path.isdir(path):
            raise NotADirectoryError(f"Path {path} is not a directory.")

        with open(cls._metadata_file(path), "r") as f:
            _raw = json.load(f)
        # Provide a default manifest for containers saved before the manifest
        # field was introduced (backward compatibility).
        if "manifest" not in _raw:
            _raw["manifest"] = {"container_type": "GenAIContainer"}
        backend = ContainerMetadata(**_raw).backend

        backend_extensions_config = None
        if os.path.exists(cls._backend_ext_file(path)):
            with open(cls._backend_ext_file(path), "r") as f:
                backend_extensions_config = json.load(f)

        return backend, backend_extensions_config

    @classmethod
    def load(cls, path: str | PathLike) -> "GenAIContainer":
        """Load a container from *path*.

        Subclasses must override this method.  The base implementation raises
        :exc:`NotImplementedError` to prevent accidental use of the generic
        base class for loading.

        Args:
            path: Directory produced by a previous call to :meth:`save`.

        Raises:
            NotImplementedError: Always — use a concrete subclass.
        """
        raise NotImplementedError(
            f"{cls.__name__}.load() is not implemented directly. "
            "Use a concrete subclass such as LLMContainer.load() or "
            "VisionEncoderContainer.load() instead."
        )
