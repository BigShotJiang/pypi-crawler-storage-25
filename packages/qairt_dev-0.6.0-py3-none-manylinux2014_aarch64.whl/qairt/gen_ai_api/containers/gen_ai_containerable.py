# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

from abc import ABC, abstractmethod
from os import PathLike, path

from qairt.api.configs.common import AISWBaseModel


class ContainerManifest(AISWBaseModel):
    """Minimal manifest embedded in every container's ``metadata.json``.

    ``container_type`` is written as ``type(self).__name__`` by each concrete
    `GenAIContainerable` subclass during `save`. Reading this field is
    sufficient to determine which subclass should be used to reload the
    container — the mapping from name to class is owned by the factory, not
    by this base class.

    Attributes:
        container_type: The class name of the container that produced this
            manifest.
    """

    container_type: str


class GenAIContainerable(ABC):
    """Final product of a GenAIBuilder constitutes all assets required for completing a generative AI task."""

    @classmethod
    def _metadata_file(cls, container_path: str | PathLike) -> str:
        """Return the path to the ``metadata.json`` file for a container directory.

        Args:
            container_path: Root directory of the container.

        Returns:
            Absolute or relative path to ``metadata.json`` inside
            *container_path*.
        """
        return path.join(container_path, "metadata.json")

    @abstractmethod
    def save(self, dest: str | PathLike, *, exist_ok: bool = False):
        """Serialize container to disk.

        Copies artifacts into the destination directory and updates any
        configurations accordingly.

        Args:
            dest: Path to save the artifacts.
            exist_ok: If True, raise an exception if an artifact already
                exists.
        """
        raise NotImplementedError(f"'save' has not been implemented for: {self.__class__.__name__}")

    @classmethod
    def load(cls, path: str | PathLike) -> "GenAIContainerable":
        """Load a container from disk by inspecting its manifest.

        Reads ``metadata.json`` inside *path* to determine the concrete
        container type, then delegates to the appropriate subclass via the
        container factory. Subclasses that override this method perform the
        actual deserialization; this base implementation acts as a
        manifest-aware dispatch entry point.

        Args:
            path: Path to load a previously serialized container from.

        Returns:
            Newly created instance of the appropriate subclass.
        """
        from qairt.gen_ai_api.containers.container_factory import load_container

        return load_container(path)
