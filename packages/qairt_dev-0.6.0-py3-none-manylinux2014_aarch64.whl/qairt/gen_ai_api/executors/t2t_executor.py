# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import asyncio
import json
import os
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Union, overload

from typing_extensions import Self

from qairt.api.compiled_model import CompiledModel
from qairt.api.configs.common import BackendType
from qairt.api.configs.device import Device
from qairt.gen_ai_api.configs.gen_ai_config import GenAIConfig
from qairt.gen_ai_api.executors.gen_ai_executable import (
    GenAIExecutable,
    GenerationExecutionResult,
    GenerationMetrics,
    GenerationRequest,
    TextGenerationResult,
    parse_genie_profile_record,
    process_prompt,
)
from qairt.gen_ai_api.executors.genie_dialog_factory import GenieDialogFactory
from qairt.modules.genie_execution.genie_config import (
    GenieConfig,
)
from qairt.modules.genie_execution.genie_runner import GenieQueryConfig, GenieRunner, StreamableGenieRunner
from qairt.modules.genie_execution.genie_runner_factory import GenieRunnerFactory
from qairt.modules.lora.lora_config import UseCaseRunConfig
from qairt.utils import loggers


class T2TExecutor(GenAIExecutable):
    """
    The T2TExecutor handles text-to-text generation on target via Genie. It supports two modes of execution:

    - Native: This is the default mode of execution on platforms with native python support if no device is
      specified. Execution is performed via native python bindings.
    - Device: This is the mode of execution when a device is specified. Execution is performed via subprocess.
      See :class:`qairt.api.configs.device.Device` for supported device types.

    The appropriate runner is selected automatically by :class:`GenieRunnerFactory` based on the device
    configuration.  Both modes are accessed through the unified :class:`GenieRunner` interface.
    """

    _logger = loggers.get_logger(name=__name__)

    def __init__(
        self,
        models: List[CompiledModel],
        genai_config: GenAIConfig,
        backend: BackendType,
        device: Optional[Device] = None,
        *,
        backend_extensions_config: Optional[Dict] = None,
        qairt_sdk_root: Optional[str | os.PathLike] = None,
        clean_up: bool = True,
        draft_models: Optional[List[CompiledModel]] = None,
        draft_model_backend_extensions_config: Optional[Dict] = None,
    ):
        """
        The executor has a compiled container and device to run it on. The GenAIExecutor will use the
        device to maintain an execution environment and run the compiled container

        Args:
            models (List[CompiledModel]): The compiled models to run
            genai_config (GenAIConfig): GenaiConfig to base GenieConfig on for genie-t2t-run execution
            backend (BackendType): Backend to use for genie-t2t-run execution.
            device (Device): Device to be used for execution. If set to none, native execution will be presumed.
            backend_extensions_config (Dict): Backend extensions configuration for genie-t2t-run execution
            qairt_sdk_root (str | os.PathLike): Path to QAIRT SDK with execution libraries (if different from installed QAIRT)
            clean_up (bool): Will delete artifacts pushed to device if True

        """
        self._clean_up = clean_up
        self._runner: GenieRunner | None = None

        self._environment_prepared = False
        self._work_dir: tempfile.TemporaryDirectory | None = None

        self._models: List[CompiledModel] = models
        self._draft_models: Optional[List[CompiledModel]] = draft_models
        if not self._models:
            raise ValueError("No models provided for execution")
        self._gen_ai_config = genai_config
        self._device: Optional[Device] = device
        self._backend: BackendType = backend
        self._backend_extensions_config: Optional[Dict] = backend_extensions_config
        self._draft_model_backend_extensions_config: Optional[Dict] = draft_model_backend_extensions_config
        self._qairt_sdk_root: str | os.PathLike = qairt_sdk_root or str(os.environ.get("QAIRT_SDK_ROOT", ""))

        if self._backend_extensions_config and self._backend == BackendType.CPU:
            self._logger.warning(
                f"Ignoring provided backend extensions as requested backend, {self._backend}, does not support extensions"
            )

    def prepare_environment(self) -> Self:
        """
        Prepares artifacts for execution on target
        """
        if not self._environment_prepared:
            self._work_dir = tempfile.TemporaryDirectory()

            backend_extensions_path = ""
            if self._backend_extensions_config:
                backend_extensions_path = os.path.join(self._work_dir.name, "backend_extensions.json")
                with open(backend_extensions_path, "w") as f:
                    f.write(json.dumps(self._backend_extensions_config, indent=2))

            draft_model_backend_extensions_path = ""
            if self._draft_model_backend_extensions_config:
                draft_model_backend_extensions_path = os.path.join(
                    self._work_dir.name, "draft_model_backend_extensions.json"
                )
                with open(draft_model_backend_extensions_path, "w") as f:
                    f.write(json.dumps(self._draft_model_backend_extensions_config, indent=2))

            genie_config = GenieConfig(
                dialog=GenieDialogFactory.create_dialog(
                    self._backend,
                    self._gen_ai_config,
                    self._models,
                    backend_extensions_path,
                    GenieRunnerFactory._native_runner_available(self._device),
                    self._draft_models,
                    draft_model_backend_extensions_path,
                )
            )

            self._runner = GenieRunnerFactory.create_t2t_runner(
                genie_config=genie_config,
                device=self._device,
                backend=self._backend,
                qairt_sdk_root=self._qairt_sdk_root,
                clean_up=self._clean_up,
            )
            self._runner.load()
            self._environment_prepared = True
        return self

    def clean_environment(self) -> Self:
        """
        Removes artifacts from target environment
        """
        self._logger.info("Cleaning environment")
        if self._runner:
            self._runner.unload()
            self._runner = None

        if self._work_dir:
            self._work_dir.cleanup()

        self._environment_prepared = False
        return self

    @overload
    def generate(
        self,
        prompt: GenerationRequest,
    ) -> TextGenerationResult: ...
    @overload
    def generate(
        self,
        prompt: Union[str, List[Dict[str, str]], Path],
        *,
        lora_config: Optional[UseCaseRunConfig] = None,
    ) -> TextGenerationResult: ...
    def generate(
        self,
        prompt: Union[GenerationRequest, str, List[Dict[str, str]], Path],
        *,
        lora_config: Optional[UseCaseRunConfig] = None,
    ) -> TextGenerationResult:
        if isinstance(prompt, GenerationRequest):
            return self._generate(prompt.messages, lora_config=lora_config)
        else:
            return self._generate(prompt, lora_config=lora_config)

    def _generate(
        self,
        prompt: Union[str, List[Dict[str, str]], Path],
        *,
        lora_config: Optional[UseCaseRunConfig] = None,
    ) -> TextGenerationResult:
        """
        Generates a response from a given prompt.

        Args:
            prompt (Union[str, List[Dict[str, str]], Path]): The prompt to be used for generation.
                Can be one of:

                - str: A raw text string prompt
                - Path: Path to a JSON file containing chat messages
                - List[Dict[str, str]]: A list of dicts with "role" and "content" keys. Each dict should contain:

                  - "role": The role of the message sender (e.g., "system", "user", "assistant")
                  - "content": The actual message content

                  Example::

                      [
                          {"role": "system", "content": "You are a helpful assistant."},
                          {"role": "user", "content": "What is the capital of France?"}
                      ]

            lora_config (UseCaseRunConfig): Configuration used to control how LoRA adapters
                are applied during model inference.

        Returns:
            TextGenerationResult: The result of the generation containing the output text and associated
            generation metrics.
        """
        if not self._environment_prepared:
            self.prepare_environment()

        assert self._runner is not None  # guaranteed by prepare_environment

        formatted_prompt = process_prompt(prompt, self._gen_ai_config)
        try:
            result = self._runner.query(GenieQueryConfig(prompt=formatted_prompt, lora_config=lora_config))
        finally:
            # Runners that maintain dialog state (StreamableGenieRunner) need an explicit
            # reset between independent generation calls so context does not accumulate.
            if isinstance(self._runner, StreamableGenieRunner):
                self._runner.reset()

        if not isinstance(result, TextGenerationResult):
            raise TypeError(f"Expected TextGenerationResult from runner, got {type(result).__name__}")
        return result

    def stream_generate(
        self, prompt: Union[str, List[Dict[str, str]], Path], streamer: asyncio.Queue
    ) -> asyncio.Task:
        """
        Starts streaming generation and returns the task that will produce the final result.

        Args:
            prompt (Union[str, List[Dict[str, str]], Path]): The prompt to be used for generation.
                Can be one of:

                - str: A raw text string prompt
                - Path: Path to a JSON file containing chat messages
                - List[Dict[str, str]]: A list of dicts with "role" and "content" keys. Each dict should contain:

                  - "role": The role of the message sender (e.g., "system", "user", "assistant")
                  - "content": The actual message content

            streamer (asyncio.Queue): An asyncio queue used to stream output chunks back to the caller.

        Returns:
            asyncio.Task: A task that will eventually return TextGenerationResult.

        Raises:
            NotImplementedError: If the active runner does not support streaming (i.e. it is not a
                :class:`~qairt.modules.genie_execution.genie_runner.StreamableGenieRunner`).
        """
        if not self._environment_prepared:
            self.prepare_environment()

        assert self._runner is not None  # guaranteed by prepare_environment

        formatted_prompt = process_prompt(prompt, self._gen_ai_config)

        if isinstance(self._runner, StreamableGenieRunner):
            try:
                return asyncio.create_task(self._runner.stream_query(formatted_prompt, streamer))
            except Exception as e:
                self._logger.warning(f"Streaming failed to start: {e}")
                raise
        else:
            raise NotImplementedError(
                f"The active runner ({type(self._runner).__name__}) does not support streaming. "
                "Streaming requires a StreamableGenieRunner (e.g. GenieNativeT2TRunner)."
            )

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._clean_up:
            self.clean_environment()
        return False

    def __del__(self):
        if getattr(self, "_clean_up", False):
            self.clean_environment()
