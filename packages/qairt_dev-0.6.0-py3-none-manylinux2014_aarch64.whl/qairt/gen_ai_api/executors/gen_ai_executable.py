# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import json
import warnings
from abc import ABC, abstractmethod
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, TypedDict, Union

from qairt.api.configs.common import AISWBaseModel
from qairt.gen_ai_api.chat.prompt_objects import BasePrompt, MessagesObject, PromptObject
from qairt.gen_ai_api.configs.gen_ai_config import GenAIConfig


class GenerationMetrics(AISWBaseModel):
    """Execution metrics produced by a single generation call.

    Attributes:
        init_time: Time to load the model, before prompt processing begins
            (microseconds).
        prompt_processing_time: Microseconds between init and token generation,
            while processing the prompt.
        prompt_processing_rate: Tokens per second — tokens in the prompt
            divided by prompt processing time.
        token_generation_time: Microseconds between prompt processing and the
            final response.
        token_generation_rate: Tokens per second — tokens in the response
            divided by token generation time.
        time_to_first_token: Microseconds from start of prompt processing to
            first token generated.
        token_acceptance_rate: Average tokens accepted per inference step.
        adapter_switch_time: Microseconds to switch between LoRA adapters.
    """

    init_time: Optional[int] = None
    prompt_processing_time: Optional[int] = None
    prompt_processing_rate: Optional[float] = None
    token_generation_time: Optional[int] = None
    token_generation_rate: Optional[float] = None
    time_to_first_token: Optional[int] = None
    token_acceptance_rate: Optional[float] = None
    adapter_switch_time: Optional[int] = None

    def get_metrics_dict(self) -> Dict[str, str]:
        """Returns an ordered dictionary of metric names to formatted values.

        Only includes metrics that are set (non-None and non-zero for optional
        metrics). The order of insertion is preserved.

        Returns:
            OrderedDict mapping metric names to their formatted string values.
        """
        metrics = OrderedDict()

        # Timing metrics (in desired display order)
        metrics["Init Time"] = f"{self.init_time or 0.0} us"
        metrics["Prompt Processing Time"] = f"{self.prompt_processing_time or 0.0} us"
        metrics["Time to First Token"] = f"{self.time_to_first_token or 0.0} us"
        metrics["Token Generation Time"] = f"{self.token_generation_time or 0.0} us"

        # Optional timing metric
        if self.adapter_switch_time and self.adapter_switch_time != 0.0:
            metrics["Adapter Switch Time"] = f"{self.adapter_switch_time} us"

        # Rate metrics
        metrics["Prompt Processing Rate"] = f"{self.prompt_processing_rate or 0} toks/sec"
        metrics["Token Generation Rate"] = f"{self.token_generation_rate or 0} toks/sec"

        # Optional per-inference metric
        if self.token_acceptance_rate and self.token_acceptance_rate != 0.0:
            metrics["Token Acceptance Rate"] = f"{self.token_acceptance_rate} toks/inference"

        return metrics

    def __str__(self):
        metrics_dict = self.get_metrics_dict()

        # Build metrics list in the order from get_metrics_dict()
        lines = []

        for key, value in metrics_dict.items():
            lines.append(f"  {key} = {value}\n")

        # Calculate the maximum line length
        if lines:
            max_length = max(len(line.rstrip()) for line in lines)
        else:
            max_length = 40  # Default minimum width

        # Create header that spans the full width
        header = f"{'-' * max_length}\n"
        title = "Metrics"
        title_line = f"{title.center(max_length)}\n"

        return header + title_line + header + "\n" + "".join(lines)

    def print(self, console: Optional[Any] = None) -> None:
        """Prints the metrics as a simple table.

        Args:
            console: A rich Console instance to print to. Defaults to None,
                which creates a Console writing to stdout.
        """
        # import here to avoid hard dependency on rich
        try:
            from rich.console import Console
            from rich.table import Table
        except ImportError:
            # print warning and fallback to simple print
            print("Warning: 'rich' library is not installed. Falling back to simple print.")
            print(self)
            return

        if console is None:
            console = Console()
        table = Table(show_header=True)

        table.add_column("Metric")
        table.add_column("Value", justify="right")

        # Get metrics and add rows in order
        metrics_dict = self.get_metrics_dict()
        for metric_name, metric_value in metrics_dict.items():
            table.add_row(metric_name, metric_value)

        console.print(table)


def _extract_metric_value(event: Dict[str, Any], metric_name: str) -> Optional[Union[int, float]]:
    """Helper to safely extract metric value from an event."""
    if metric_name in event and "value" in event[metric_name]:
        return event[metric_name]["value"]
    return None


def _parse_execution_metrics(execution_event: Dict[str, Any], metrics: GenerationMetrics) -> None:
    """Parse common execution metrics from either pipeline or dialog format."""
    prompt_rate = _extract_metric_value(execution_event, "prompt-processing-rate")
    if prompt_rate is not None:
        metrics.prompt_processing_rate = prompt_rate
        num_prompt_tokens = _extract_metric_value(execution_event, "num-prompt-tokens")
        if num_prompt_tokens is not None:
            # Calculate prompt processing time: tokens / (tokens/sec) * 1,000,000 us/sec
            metrics.prompt_processing_time = int(1000000 * num_prompt_tokens / prompt_rate)

    token_gen_time = _extract_metric_value(execution_event, "token-generation-time")
    if token_gen_time is not None:
        metrics.token_generation_time = int(token_gen_time)

    token_gen_rate = _extract_metric_value(execution_event, "token-generation-rate")
    if token_gen_rate is not None:
        metrics.token_generation_rate = token_gen_rate

    ttft = _extract_metric_value(execution_event, "time-to-first-token")
    if ttft is not None:
        metrics.time_to_first_token = int(ttft)

    # Token acceptance rate (typically only in dialog format)
    token_accept_rate = _extract_metric_value(execution_event, "token-acceptance-rate")
    if token_accept_rate is not None:
        metrics.token_acceptance_rate = token_accept_rate


class _FormatMapping(TypedDict):
    """Type definition for profile format mapping entries."""

    component_type: str
    create_event: str
    execute_event: str
    lora_event: str
    init_metric: str
    init_is_direct: bool


_PIPELINE_DIALOG_PROFILE_FORMAT_MAPPINGS: Dict[str, _FormatMapping] = {
    "pipeline": {
        "component_type": "pipeline",
        "create_event": "GeniePipeline_create",
        "execute_event": "GeniePipeline_execute",
        "lora_event": "GeniePipeline_applyLora",
        "init_metric": "duration",  # init time stored directly as duration
        "init_is_direct": True,  # duration is a direct field, not nested in an object
    },
    "dialog": {
        "component_type": "dialog",
        "create_event": "GenieDialog_create",
        "execute_event": "GenieDialog_query",
        "lora_event": "GenieDialog_applyLora",
        "init_metric": "init-time",  # init time stored in an object
        "init_is_direct": False,  # init time is nested in an object
    },
}


class GenerationRequest(AISWBaseModel):
    """Encapsulates all inputs required for a generation call.

    The messages field follows the standard multimodal messages format used by
    HuggingFace transformers and the OpenAI API. A plain string or a Path to a
    JSON messages file are also accepted for text-only requests. Additional
    execution controls (e.g. sampler parameters) will be added as further
    fields on this class.

    Attributes:
        messages: The prompt input. Accepts a raw string, a path to a JSON
            messages file, or a list of role/content dicts for chat format.

    Example:
        GenerationRequest(messages=[
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": "/path/to/image.raw"},
                    {"type": "text", "text": "Describe this image."},
                ],
            }
        ])
    """

    messages: Union[str, List[Dict[str, Any]], Path]


def parse_genie_profile_record(profile_record: Dict[str, Any]) -> GenerationMetrics:
    metrics = GenerationMetrics()
    if "components" not in profile_record:
        return metrics

    for format_name, mapping in _PIPELINE_DIALOG_PROFILE_FORMAT_MAPPINGS.items():
        components = [x for x in profile_record["components"] if x["type"] == mapping["component_type"]]
        if not components:
            continue

        events = components[0]["events"]

        create_events = [x for x in events if x["type"] == mapping["create_event"]]
        if create_events:
            if mapping["init_is_direct"]:
                if mapping["init_metric"] in create_events[0]:
                    metrics.init_time = int(create_events[0][mapping["init_metric"]])
            else:
                init_time = _extract_metric_value(create_events[0], mapping["init_metric"])
                if init_time is not None:
                    metrics.init_time = int(init_time)

        execute_events = [x for x in events if x["type"] == mapping["execute_event"]]
        if execute_events:
            _parse_execution_metrics(execute_events[-1], metrics)

        lora_events = [x for x in events if x["type"] == mapping["lora_event"]]
        if lora_events:
            adapter_switch = _extract_metric_value(lora_events[0], "lora-adapter-switching-time")
            if adapter_switch is not None:
                metrics.adapter_switch_time = int(adapter_switch)

        # return when a valid matching format is found
        return metrics

    return metrics


def build_prompt_object(
    messages: Union[str, List[Dict[str, Any]], Path, None],
) -> BasePrompt:
    """Construct the appropriate prompt object from raw input.

    Dispatches on the type of ``messages`` to produce either a
    :class:`~qairt.gen_ai_api.chat.prompt_objects.MessagesObject` (for
    structured / multimodal inputs) or a plain
    :class:`~qairt.gen_ai_api.chat.prompt_objects.PromptObject` (for raw
    strings and the ``None`` default).

    Args:
        messages: Raw prompt input — ``None``, a plain string, a
            ``Path`` to a JSON messages file, or a list of role/content
            dicts.

    Returns:
        A ``MessagesObject`` when the input is structured, otherwise a
        ``PromptObject``.
    """
    if messages is None:
        return PromptObject(None)
    elif isinstance(messages, list):
        return MessagesObject(messages)
    elif isinstance(messages, Path):
        return MessagesObject.from_json(messages)
    else:
        try:
            return MessagesObject.from_json(messages)
        except json.JSONDecodeError:
            return PromptObject(messages)


def process_prompt(prompt: Union[str, List[Dict[str, Any]], Path], genai_config: GenAIConfig) -> str:
    """Processes prompt input and returns a formatted prompt string.

    Args:
        prompt: Prompt input. Can be a raw string, file path, or list of dicts
            for chat format.
        genai_config: GenAI configuration containing chat template settings.

    Returns:
        Formatted prompt string ready for execution.
    """
    prompt_obj = build_prompt_object(prompt)

    chat_template = genai_config.chat_template
    if chat_template:
        return chat_template.apply_template(prompt_obj)
    else:
        return prompt_obj.get_prompt()


class GenerationExecutionResult(AISWBaseModel):
    """Base class for generation execution results.

    Attributes:
        output: Raw output from generation.
        error: Raw error response from generation (empty on success).
        metrics: Parsed metrics from the response.
    """

    output: str = ""
    error: str = ""
    metrics: Optional[GenerationMetrics] = None

    def _get_content_to_print(self) -> str:
        """Returns the content string to display in :meth:`print`.

        Subclasses should override this to return their specific content field
        (e.g. ``generated_text``). Defaults to the raw :attr:`output`.

        Returns:
            The content string to be rendered and printed.
        """
        return self.output

    def _get_panel_title(self) -> str:
        """Returns the Panel title to use in :meth:`print`.

        Subclasses should override this to return a more descriptive title.

        Returns:
            The title string for the rich Panel. Defaults to ``"Generated Content"``.
        """
        return "Generated Content"

    def print(self, metrics: bool = True, console: Optional[Any] = None) -> None:
        """Prints the result content rendered as Markdown, followed optionally by metrics.

        The content and panel title are supplied by :meth:`_get_content_to_print`
        and :meth:`_get_panel_title` respectively, which subclasses can override.

        Args:
            metrics: If True, prints generation metrics after the content.
                Defaults to True.
            console: A rich Console instance to print to. Defaults to None,
                which creates a Console writing to stdout. To route output to
                a file, pass ``Console(file=open("output.txt", "w"))``.
        """
        try:
            from rich.console import Console as RichConsole
            from rich.markdown import Markdown
            from rich.panel import Panel
        except ImportError:
            print("Warning: 'rich' library is not installed. Falling back to simple print.")
            print(self._get_content_to_print())
            if metrics and self.metrics:
                self.metrics.print()
            return

        if console is None:
            console = RichConsole()

        console.print(
            Panel(Markdown(self._get_content_to_print()), title=self._get_panel_title(), expand=False)
        )

        if metrics:
            if self.metrics:
                self.metrics.print(console=console)
            else:
                console.print("Metrics were not generated")


class TextGenerationResult(GenerationExecutionResult):
    """Result class specifically for text-to-text generation.

    Attributes:
        generated_text: Parsed response — the generated text minus metrics.
    """

    generated_text: str = ""

    def _get_content_to_print(self) -> str:
        """Returns the generated text as the content to print.

        Returns:
            The generated text string.
        """
        return self.generated_text

    def _get_panel_title(self) -> str:
        """Returns the panel title for text generation results.

        Returns:
            The string ``"Generated Text"``.
        """
        return "Generated Text"


class ImageGenerationResult(GenerationExecutionResult):
    """Result class for text-to-image generation.

    Attributes:
        image_path: Path to the generated image file.
    """

    image_path: str = ""


class GenAIExecutable(ABC):
    @abstractmethod
    def generate(
        self,
        prompt: "GenerationRequest",
    ) -> GenerationExecutionResult:
        """Executes a generation request.

        Concrete executors should return a subclass of `GenerationExecutionResult`
        (e.g., `TextGenerationResult`, `ImageGenerationResult`).

        Args:
            prompt: The generation request containing the input messages.

        Returns:
            A `GenerationExecutionResult` (or subclass) with the generation
            output.
        """
        pass

    @abstractmethod
    def prepare_environment(self) -> "GenAIExecutable":
        """Prepares artifacts for execution on target."""
        pass

    @abstractmethod
    def clean_environment(self) -> "GenAIExecutable":
        """Removes artifacts from target environment."""
        pass


def __getattr__(name: str) -> object:
    if name == "GenAIExecutor":
        warnings.warn(
            "GenAIExecutor has been renamed to GenAIExecutable. "
            "Importing GenAIExecutor from gen_ai_executable is deprecated and will be "
            "removed in a future release. Use GenAIExecutable instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return GenAIExecutable
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
