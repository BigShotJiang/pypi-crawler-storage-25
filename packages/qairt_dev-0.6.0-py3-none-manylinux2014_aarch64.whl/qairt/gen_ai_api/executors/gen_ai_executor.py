# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
"""
Deprecated: This module has been renamed to ``gen_ai_executable``.

Please update your imports::

    # Old (deprecated)
    from qairt.gen_ai_api.executors.gen_ai_executor import GenAIExecutor

    # New
    from qairt.gen_ai_api.executors.gen_ai_executable import GenAIExecutable

This compatibility shim will be removed in a future release.
"""

import warnings

warnings.warn(
    "qairt.gen_ai_api.executors.gen_ai_executor has been renamed to "
    "qairt.gen_ai_api.executors.gen_ai_executable. "
    "Please update your imports. This compatibility shim will be removed in a future release.",
    DeprecationWarning,
    stacklevel=2,
)

from qairt.gen_ai_api.executors.gen_ai_executable import *  # noqa: F401, F403
from qairt.gen_ai_api.executors.gen_ai_executable import (
    GenAIExecutable as GenAIExecutor,  # noqa: F401
)
