# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
import json
import os
import tempfile
from typing import Dict, Optional

from typing_extensions import Self

from qairt.api.configs.common import BackendType
from qairt.api.configs.device import Device
from qairt.gen_ai_api.chat.prompt_objects import MessagesObject
from qairt.gen_ai_api.configs.gen_ai_config import GenAIConfig
from qairt.gen_ai_api.configs.pipeline_config import GenieNodeType, GeniePipelineConfig, GeniePipelineNode
from qairt.gen_ai_api.executors.gen_ai_executable import (
    GenAIExecutable,
    GenerationExecutionResult,
    GenerationRequest,
    TextGenerationResult,
    build_prompt_object,
    parse_genie_profile_record,
)
from qairt.modules.genie_execution.genie_app_run_module import GenieAppRunExecutionConfig, GenieAppRunner
from qairt.utils import loggers


class ImageT2TExecutor(GenAIExecutable):
    """Handles Large Multimodal Model execution on target via Genie pipeline using Genie App.

    Supports both text and vision inputs and coordinates their processing.
    """

    _logger = loggers.get_logger(name=__name__)

    def __init__(
        self,
        genai_config: GenAIConfig,
        pipeline_config: GeniePipelineConfig,
        backend: BackendType,
        device: Optional[Device] = None,
        backend_extensions_config: Optional[Dict] = None,
        qairt_sdk_root: Optional[str | os.PathLike] = None,
        clean_up: bool = True,
    ):
        """Initialize the ImageT2TExecutor.

        Args:
            genai_config: GenAI configuration for model parameters.
            pipeline_config: Pipeline configuration for multimodal execution.
            backend: Backend to use for execution.
            device: Device to be used for execution.
            backend_extensions_config: Backend extensions configuration.
            qairt_sdk_root: Path to QAIRT SDK.
            clean_up: Whether to delete artifacts after execution.
        """
        self._clean_up = clean_up
        self._runner: GenieAppRunner | None = None

        self._environment_prepared = False
        self._work_dir: tempfile.TemporaryDirectory | None = None

        self._gen_ai_config: GenAIConfig = genai_config
        self._pipeline_config: GeniePipelineConfig = pipeline_config
        self._device: Optional[Device] = device
        self._backend: BackendType = backend
        self._backend_extensions_config: Optional[Dict] = backend_extensions_config
        self._qairt_sdk_root: str | os.PathLike = qairt_sdk_root or str(os.environ.get("QNN_SDK_ROOT", ""))

        if self._backend_extensions_config and self._backend == BackendType.CPU:
            self._logger.warning(
                f"Ignoring provided backend extensions as requested backend, {self._backend}, does not support extensions"
            )

    def prepare_environment(self) -> Self:
        """Prepares artifacts for Genie App execution on target.

        Returns:
            Self: The executor instance
        """
        if not self._environment_prepared:
            self._work_dir = tempfile.TemporaryDirectory()

            backend_extensions_path = ""
            if self._backend_extensions_config:
                backend_extensions_path = os.path.join(self._work_dir.name, "htp_backend_ext_config.json")
                with open(backend_extensions_path, "w") as f:
                    f.write(json.dumps(self._backend_extensions_config, indent=2))

            assert isinstance(self._device, Device)  # for mypy
            # The pipeline configuration contains all the node configurations
            # with their respective JSON config files specified in node_config_filename
            self._runner = GenieAppRunner(
                pipeline_config=self._pipeline_config,
                backend=self._backend,
                device=self._device.info,
                qairt_sdk_root=self._qairt_sdk_root,
                tokenizer_path=self._gen_ai_config.tokenizer_path,
                backend_extensions_config_path=backend_extensions_path,
                clean_up=self._clean_up,
            )
            self._runner.load()

        self._environment_prepared = True
        return self

    def clean_environment(self) -> Self:
        """Removes artifacts from target environment.

        Returns:
            Self: The executor instance
        """
        self._logger.info("Cleaning ImageText2Text environment")
        if self._runner:
            self._runner.unload()
            self._runner = None

        if self._work_dir:
            self._work_dir.cleanup()

        self._environment_prepared = False
        return self

    def generate(
        self,
        prompt: GenerationRequest,
    ) -> GenerationExecutionResult:
        """Generates a response from text and optionally image inputs.

        Args:
            prompt: Generation request whose ``messages`` field may contain
                text-only or multimodal (text + image) content. Image paths
                are extracted from content parts with ``{"type": "image"}``.

        Returns:
            Result containing the generated text and execution metadata.
        """
        if not self._environment_prepared:
            self.prepare_environment()

        # Build the prompt object to both format the text and extract any
        # embedded image path from multimodal content parts.
        prompt_obj = build_prompt_object(prompt.messages)

        chat_template = self._gen_ai_config.chat_template
        if chat_template:
            formatted_text = chat_template.apply_template(prompt_obj)
        else:
            formatted_text = prompt_obj.get_prompt()

        # TODO: Vision Processor will be built in builder and stored in container
        # which will be used here in executor eventually. For now, .raw image is expected.
        preprocessed_image_path = None
        if isinstance(prompt_obj, MessagesObject):
            preprocessed_image_path = prompt_obj.get_image_path()

        # Create the execution config
        run_config = GenieAppRunExecutionConfig(
            text=formatted_text,
            image=preprocessed_image_path,
            pipeline_config=self._pipeline_config,
            tokenizer_path=self._gen_ai_config.tokenizer_path,
        )

        # Execute the Genie App LMM pipeline
        if self._runner:
            run_result = self._runner.run(run_config)

            result = TextGenerationResult()
            result.output = run_result.stdout

            if run_result.return_code != 0:
                result.error = run_result.stderr
            else:
                result.output += "\n" + run_result.stderr

            # Parse generated text from output
            begin_idx = result.output.find("[BEGIN]:")
            end_idx = result.output.find("[END]", begin_idx)
            if begin_idx > -1 and end_idx > begin_idx:
                result.generated_text = result.output[begin_idx + len("[BEGIN]:") : end_idx].strip()

            if run_result.profile_record:
                result.metrics = parse_genie_profile_record(run_result.profile_record)

            return result

        raise RuntimeError("Genie App Runner not initialized")

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._clean_up:
            self.clean_environment()
        return False

    def __del__(self):
        if self._clean_up:
            self.clean_environment()
