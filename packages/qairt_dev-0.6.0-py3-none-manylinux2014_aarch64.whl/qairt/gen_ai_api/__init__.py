# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

import platform

from qairt.utils.os_utils import is_arm_64, is_windows

# TODO: Remove this guard once genie execution is fixed on Windows ARM.
if is_windows(platform.system()) and is_arm_64(platform.machine(), platform.processor()):
    raise ImportError(
        "qairt.gen_ai_api is temporarily disabled on Windows ARM due to a known issue. "
        "This will be resolved in an upcoming release."
    )

from qairt import is_oelinux_user
from qairt.gen_ai_api.configs.gen_ai_config import GenAIConfig
from qairt.gen_ai_api.containers.llm_container import LLMContainer
from qairt.gen_ai_api.executors.t2t_executor import T2TExecutor

if not is_oelinux_user():
    # Builder APIs require converter/compiler dependencies not available on OE-Linux
    from qairt.gen_ai_api.builders.gen_ai_builder import GenAIBuilder
    from qairt.gen_ai_api.builders.gen_ai_builder_htp import GenAIBuilderHTP
    from qairt.gen_ai_api.gen_ai_builder_factory import GenAIBuilderFactory, SupportedLLMs
