# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================

import json
from typing import TYPE_CHECKING, Dict

from pydantic import DirectoryPath

from qairt.api.common.backends.aic.config import AicConfigHelper
from qairt.api.common.backends.htp import HtpContextConfig, HtpDeviceConfig, HtpGraphConfig
from qairt.api.common.backends.htp.config import HtpConfigHelper
from qairt.api.configs.common import BackendType

if TYPE_CHECKING:
    from qairt.api.compiler.config import CompileConfig


def get_config_api_options_dict(config: "CompileConfig") -> Dict:
    """
    Converts the compile config to a dictionary encoded as a json string.
    """

    # Check for passthrough mode: raw backend config dict stored directly
    if config._raw_backend_config is not None:
        if config.backend != BackendType.HTP:
            raise ValueError("Passthrough mode is only supported for HTP backend")
        compile_config_dict = {
            "backend_extensions": {
                "shared_library_path": HtpConfigHelper.shared_library_path(),
                "config_file_path": "",
            }
        }
        compile_config_dict["backend_extensions"]["config_dict"] = config._raw_backend_config
        return compile_config_dict

    if config.backend == BackendType.HTP:
        # TODO: Remove once schema is incorporated
        ctx_custom_configs = config.context_custom_configs or []
        graph_custom_configs = config.graph_custom_configs or []
        device_custom_configs = config.device_custom_configs or []

        # Pass config objects directly to preserve _extras from populate_from_backend_extensions.
        # Only re-create if the config type doesn't match (e.g. HtpMcpContextConfig).
        htp_ctx = [
            cfg
            if isinstance(cfg, HtpContextConfig)
            else HtpContextConfig(**cfg.model_dump(exclude_unset=True, exclude_none=True))
            for cfg in ctx_custom_configs
        ]
        htp_graph = [
            cfg
            if isinstance(cfg, HtpGraphConfig)
            else HtpGraphConfig(**cfg.model_dump(exclude_unset=True, exclude_none=True))
            for cfg in graph_custom_configs
        ]
        htp_device = [
            cfg
            if isinstance(cfg, HtpDeviceConfig)
            else HtpDeviceConfig(**cfg.model_dump(exclude_unset=True, exclude_none=True))
            for cfg in device_custom_configs
        ]

        backend_extensions_dict = HtpConfigHelper.to_backend_extension_dict(
            htp_ctx,
            htp_graph,
            htp_device,
            config.memory_custom_config,
            config.group_context_config,
        )

        # Merge any unknown top-level sections from populate_from_backend_extensions
        if config._section_extras:
            backend_extensions_dict.update(config._section_extras)

        shared_library_path = HtpConfigHelper.shared_library_path()
    elif config.backend == BackendType.AIC:
        backend_extensions_dict = AicConfigHelper.to_backend_extension_dict(config.compiler_custom_configs)
        shared_library_path = AicConfigHelper.shared_library_path()
    else:
        backend_extensions_dict = {}
        shared_library_path = ""

    compile_config_dict = {
        "backend_extensions": {"shared_library_path": shared_library_path, "config_file_path": ""}
    }

    # add non-schema compliant value of config as a dictionary
    compile_config_dict["backend_extensions"]["config_dict"] = backend_extensions_dict

    return compile_config_dict


# TODO: Files could be avoided on local host
def _get_config_api_options_json_file(config, output_dir: DirectoryPath, prefix="") -> str:
    # save backend extension dict to a file
    if prefix:
        prefix = f"{prefix}_"

    compile_cfg_dict = get_config_api_options_dict(config)
    if backend_cfg := compile_cfg_dict["backend_extensions"]["config_dict"]:
        backend_ext_file_path = output_dir / f"{prefix}{config.backend.lower()}_extensions.json"
        with open(str(backend_ext_file_path), "w+") as fp:
            json.dump(backend_cfg, fp, indent=4)
        compile_cfg_dict["backend_extensions"]["config_file_path"] = str(backend_ext_file_path)

    # remove the config dict from the compile config dict before saving to file
    del compile_cfg_dict["backend_extensions"]["config_dict"]

    compile_config_file_path = output_dir / f"{prefix}compile_config.json"
    with open(str(compile_config_file_path), "w+") as fp:
        json.dump(compile_cfg_dict, fp, indent=4)

    return str(compile_config_file_path)
