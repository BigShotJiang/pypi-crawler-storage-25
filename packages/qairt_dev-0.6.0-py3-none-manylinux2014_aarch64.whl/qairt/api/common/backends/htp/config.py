# ==============================================================================
#
# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# All Rights Reserved.
# Confidential and Proprietary - Qualcomm Technologies, Inc.
#
# ==============================================================================
from typing import Any, Dict, List, Literal, Optional, Tuple, Type, Union

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, field_validator, model_validator

from qairt.api.configs.common import DspArchitecture, PerfProfile
from qairt.utils.loggers import get_logger
from qti.aisw.tools.core.modules.api.backend.htp_backend import HtpBackend

""" This module describes options that can be used to configure the HTP backend during
    compilation or execution only using this Python API. It is not intended as a reference for all
    QAIRT HTP Backend options. For information on QAIRT HTP Backend API, see QAIRT docs."""

logger = get_logger(__name__)


class HtpGraphConfig(BaseModel):
    """Graph configuration for HTP Backend"""

    _extras: Dict[str, Any] = PrivateAttr(default_factory=dict)

    name: str
    """
    Corresponds to the graph name provided to QnnGraph_create
    """

    vtcm_size_in_mb: int = Field(default=0, serialization_alias="vtcm_mb")
    """
    Provides performance infrastructure configuration options that are memory specific.
    To use a device's maximum VTCM amount, set the value to 0 (QNN_HTP_GRAPH_CONFIG_OPTION_MAX) and
    specify the target SoC through the device config.
    """

    vtcm_size: int = 0
    """
    0 means the MAX value of vtcm size by the soc_id or the current device
    """

    fp16_relaxed_precision: int = 0
    """
    Used to perform computation with half precision i.e. 16 bits
    """

    hvx_threads: int = 0
    """
    Corresponds to the number of HVX threads to use for a particular graph during an inference.
    """

    optimization_type: Union[int, float] = Field(default=2, serialization_alias="O")
    """
    Set graph optimization value in range 1 to 3. As numbers increase, there is a tradeoff between preparation
    times to graph optimality.

    1 implies fastest preparation time, least optimal graph.
    3. implies slowest preparation time, most optimal graph.
    """

    @field_validator("optimization_type", mode="after")
    @classmethod
    def _validate_optimization_type(cls, v: Union[int, float]) -> Union[int, float]:
        if isinstance(v, float) and not v.is_integer():
            raise ValueError(f"optimization_type must be a whole number (1, 2, or 3), got {v}")
        if not (1 <= v <= 3):
            raise ValueError(f"optimization_type must be between 1 and 3, got {v}")
        return v

    finalize_config: Optional[dict] = None
    """
    Field to set the finalize config dict for backend extension
    """

    dlbc: Literal[0, 1] = 0
    """
    Provide deep learning bandwidth compression value 0 or 1.
    """

    dlbc_weights: int = 0
    """
    Number of weights to use for compression. Only used when dlbc is set to 1.
    """

    weights_packing: bool = False
    """
    Specifies whether to enable weights packing.
    """

    num_cores: Optional[int] = None
    """
    Number of cores to use for this graph. Set from the cores: spec string entry.
    """

    short_depth_conv_on_hmx_off: bool = False
    """
    Specifies whether to configure short depth convolution for the graph.
    """

    fold_relu_activation_into_conv_off: bool = False
    """
    Specifies whether to configure fold relu activation for the graph.
    """

    advanced_activation_fusion: bool = True
    """
    Specifies whether to enable or disable fusion of convolution operations with advanced activation
    functions such as sigmoid, tanh, gelu, and swish. When enabled, it may improve performance in
    floating-point models. When disabled, it may improve accuracy at the cost of performance.
    Note that this option has no effect on quantized graphs.
    """

    use_high_precision_fp16_sigmoid: bool = False
    """
    Specifies whether to configure use high precision fp16 sigmoid for the graph.
    """

    monolithic_lstm: bool = False
    """
    Specifies whether to configure monolithic lstm for the graph.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True, arbitrary_types_allowed=True)


class HtpDeviceCoreConfig(BaseModel):
    """Core Configuration for HTP Backend"""

    _extras: Dict[str, Any] = PrivateAttr(default_factory=dict)

    id: int = Field(default=0, serialization_alias="core_id")
    """
    Unique identifier for the core configuration
    """

    perf_profile: PerfProfile = PerfProfile.BURST
    """
    Performance profile options. Use PerfProfile.list_options() for all
     available options
    """

    rpc_control_latency: int = 100
    """
    Rpc control latency value in micro second.
    """

    rpc_polling_time: int = 9999
    """
    Rpc polling time value in micro second.
    """

    hmx_timeout_us: int = 300000
    """
    Hmx timeout value in micro second.
    """

    adaptive_polling_time: int = 0
    """
    Adaptive polling time value in micro second.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True, arbitrary_types_allowed=True)


class HtpDeviceConfig(BaseModel):
    """Device Configuration for HTP Backend"""

    _extras: Dict[str, Any] = PrivateAttr(default_factory=dict)

    id: int = Field(default=0, serialization_alias="device_id")
    """
    An optional id for the device configuration.
    """

    soc_id: int = 0
    """
    Selection of the SoC.
    """

    soc_model: int = 0
    """
    The Snapdragon SOC family associated with the device. E.x. 69. The SOC model must be related to the dsp
    architecture below.
    """

    dsp_arch: Optional[DspArchitecture | str] = None
    """
    The DSP architecture version for this SOC. See DspArchitecture.list_options() for all
    available options
    """

    pd_session: Literal["signed", "unsigned"] = "unsigned"
    """
    Specifies the user process domain attribute
    """

    profiling_level: Optional[Literal["linting"]] = "linting"
    """
    Used for linting profiling level.
    """

    # Note: serialization_alias "core_id" is shared with HtpDeviceCoreConfig.id.
    # This is intentional — the backend JSON spec uses "core_id" at both nesting levels
    # with different semantics (device-level list vs. core-level scalar).
    core_ids: Optional[List[int]] = Field(default=None, serialization_alias="core_id")
    """
    Select the core ids. Used to select among the cores available in a device.
    """

    core_type: int = 0
    """
    Select the available core type. 0 - NSP, 1 - HPASS.
    """

    cores: List[HtpDeviceCoreConfig] = Field(default_factory=list)
    """
    List of core configurations.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True, arbitrary_types_allowed=True)


class HtpContextConfig(BaseModel):
    """Context Configuration for HTP Backend"""

    _extras: Dict[str, Any] = PrivateAttr(default_factory=dict)

    weight_sharing_enabled: bool = False
    """
    This feature allows common weights across graphs (max 64) to be shared and
    stored in a single context binary.
    """

    file_read_memory_budget_in_mb: int = 0
    """
    Allows users to configure the read memory budget of the deserialized binary in megabytes (Mb).
    It gives a hint to the backend to load the binary in chunks,
    instead of loading the entire binary to memory at once.
    """

    io_memory_estimation: bool = False
    """
    Enables I/O memory estimation when multiple PDs are available.
    It estimates the total size of the I/O tensors required by the context to ensure sufficient space
    on the PD before deserialization.
    """

    max_spill_fill_buffer_for_group: int = Field(default=0, ge=0)
    """
    Used to associate max spill-fill buffer size across multiple contexts within a group.
    Group_id value must be set to 0 for this option to be used.
    """

    group_id: int = 0
    """
    Specifies the group id to which contexts can be associated.
    """

    extended_udma: bool = False
    """
    Enables user direct memory access (UDMA). Only supported on HTP v81 and above.
    """

    init_acceleration: bool = False
    """
    Used to enable init acceleration when creating context from a serialized context binary.
    """

    lora_weight_sharing: bool = False
    """
    Used for enabling Lora Weight Sharing during offline preparation.
    """

    lora_weight_sharing_ram_preload: bool = False
    """
    Used for enabling Lora Weight Sharing Ram Preload when creating context from a serialized
    context binary.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True, arbitrary_types_allowed=True)

    @model_validator(mode="after")
    def validate_group_id_max_spill_fill_buffer_for_group(self):
        """Validate group_id vs max_spill_fill_buffer_for_group"""
        if self.max_spill_fill_buffer_for_group > 0 and self.group_id != 0:
            raise ValueError("group_id must be set to 0 when max_spill_fill_buffer_for_group is set")
        return self


class HtpMemoryConfig(BaseModel):
    """Memory Configuration for HTP Backend"""

    _extras: Dict[str, Any] = PrivateAttr(default_factory=dict)

    mem_type: Literal["shared_buffer"] = "shared_buffer"

    model_config = ConfigDict(extra="forbid", validate_assignment=True, arbitrary_types_allowed=True)


class HtpGroupContextConfig(BaseModel):
    """Group Context Configuration for HTP Backend"""

    _extras: Dict[str, Any] = PrivateAttr(default_factory=dict)

    share_resources: bool = False
    """
    Enables resource sharing across different contexts during binary generation.
    When enabled, it allows the backend to apply HTP virtual address space optimization.
    Note: This feature cannot be used with graph switching.
    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True, arbitrary_types_allowed=True)


class HtpConfigHelper:
    """
    Helper class to convert HTP config to backend extension config needed by QAIRT Tools.
    """

    _CONFIG_TYPES = frozenset({"context", "graphs", "devices", "memory", "groupContext"})

    @staticmethod
    def _merge_extras(dump: Dict[str, Any], extras: Dict[str, Any]) -> Dict[str, Any]:
        """Merge _extras into a model_dump dict, logging when extras overwrite known keys."""
        overlap = dump.keys() & extras.keys()
        if overlap:
            logger.debug(
                "_extras keys %s overlap with serialized fields and will overwrite them",
                overlap,
            )
        return {**dump, **extras}

    @staticmethod
    def to_backend_extension_dict(
        context_configs: List[HtpContextConfig] | None = None,
        graph_configs: List[HtpGraphConfig] | None = None,
        device_configs: List[HtpDeviceConfig] | None = None,
        memory_config: HtpMemoryConfig | None = None,
        group_context: HtpGroupContextConfig | None = None,
    ) -> Dict[str, Any]:
        """
        Builds the backend extension dictionary based on the provided configurations.

        Args:
            context_configs: List of context configurations.
            graph_configs: List of graph configurations.
            device_configs: List of device configurations.
            memory_config: Memory configuration.
            group_context: Group context configuration.

        Examples:
            >>> context_configs = [HtpContextConfig(weight_sharing_enabled=True)]
            >>> graph_configs = [HtpGraphConfig(name="graph1")]
            >>> HtpConfigHelper.to_backend_extension_dict(context_configs, graph_configs)

        Returns:
            Dictionary representing the backend extension.
        """
        backend_extension_dict: Dict[str, Any] = dict()
        merge = HtpConfigHelper._merge_extras
        if context_configs:
            backend_extension_dict["context"] = [
                merge(
                    cfg.model_dump(mode="json", by_alias=True, exclude_unset=True, exclude_none=True),
                    cfg._extras,
                )
                for cfg in context_configs
            ]
        if graph_configs:
            backend_extension_dict["graphs"] = []
            for cfg in graph_configs:
                cfg_model_dump = cfg.model_dump(
                    mode="json", by_alias=True, exclude_unset=True, exclude_none=True
                )

                # TODO: Currently required to pass a list of graph names for a single graph config.
                # This is a temporary workaround until the backend extension is supported to support a single
                # name per graph config.
                # For now set to graph_names and delete name
                cfg_model_dump["graph_names"] = [cfg_model_dump["name"]]
                del cfg_model_dump["name"]

                cfg_model_dump = merge(cfg_model_dump, cfg._extras)
                backend_extension_dict["graphs"].append(cfg_model_dump)
        if device_configs:
            device_list = []
            for device_cfg in device_configs:
                device_dump = device_cfg.model_dump(
                    mode="json", by_alias=True, exclude_unset=True, exclude_none=True
                )
                # Merge extras for cores
                if device_cfg.cores:
                    device_dump["cores"] = [
                        merge(
                            core.model_dump(
                                mode="json", by_alias=True, exclude_unset=True, exclude_none=True
                            ),
                            core._extras,
                        )
                        for core in device_cfg.cores
                    ]
                device_list.append(merge(device_dump, device_cfg._extras))
            backend_extension_dict["devices"] = device_list
        if memory_config:
            # Allow unset to be passed to allow for default values to be used
            backend_extension_dict["memory"] = merge(
                memory_config.model_dump(mode="json", by_alias=True, exclude_none=True),
                memory_config._extras,
            )
        if group_context:
            backend_extension_dict["groupContext"] = merge(
                group_context.model_dump(mode="json", by_alias=True, exclude_unset=True, exclude_none=True),
                group_context._extras,
            )
        return backend_extension_dict

    @classmethod
    def list_config_options(cls):
        return cls._CONFIG_TYPES

    @staticmethod
    def shared_library_path():
        return HtpBackend().backend_extensions_library

    @staticmethod
    def list_options():
        # List every option for each Htp Config
        config_classes = [
            HtpGraphConfig,
            HtpDeviceConfig,
            HtpContextConfig,
            HtpDeviceCoreConfig,
            HtpMemoryConfig,
            HtpGroupContextConfig,
        ]

        for config_class in config_classes:
            fields = getattr(config_class, "model_fields", {})
            for attr, info in fields.items():
                if not attr.startswith("__"):
                    print(f"{config_class.__name__}.{attr}: {info.annotation}")

    @staticmethod
    def _build_reverse_alias_map(model_class: Type[BaseModel]) -> Dict[str, str]:
        """Build a mapping from serialization alias -> field name for a Pydantic model.

        Also includes field_name -> field_name for direct matches.

        Args:
            model_class: The Pydantic model class to inspect.

        Returns:
            Dictionary mapping alias (or field name) to the canonical field name.
        """
        alias_map: Dict[str, str] = {}
        for field_name, field_info in model_class.model_fields.items():
            alias_map[field_name] = field_name
            if field_info.alias:
                alias_map[field_info.alias] = field_name
            if field_info.serialization_alias:
                alias_map[field_info.serialization_alias] = field_name
        return alias_map

    @staticmethod
    def _parse_config_section(
        model_class: Type[BaseModel], data: Dict[str, Any]
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """Split a JSON config section into known fields and extras.

        Uses the reverse alias map to translate JSON keys (which may be serialization aliases)
        into the canonical field names expected by the Pydantic model constructor.

        Args:
            model_class: The Pydantic model class to parse against.
            data: The raw JSON dictionary for this section.

        Returns:
            A tuple of (known_fields, extras) where known_fields uses canonical field names
            and extras contains unrecognized keys.
        """
        alias_map = HtpConfigHelper._build_reverse_alias_map(model_class)
        known_fields: Dict[str, Any] = {}
        extras: Dict[str, Any] = {}

        for key, value in data.items():
            if key in alias_map:
                known_fields[alias_map[key]] = value
            else:
                extras[key] = value

        return known_fields, extras

    @classmethod
    def from_backend_extension_dict(
        cls,
        backend_ext: Dict[str, Any],
    ) -> Tuple[
        List[HtpContextConfig],
        List[HtpGraphConfig],
        List[HtpDeviceConfig],
        Optional[HtpMemoryConfig],
        Optional[HtpGroupContextConfig],
        Dict[str, Any],
    ]:
        """Parse a backend extension dictionary into HTP config objects.

        Handles reverse alias mapping (e.g. ``"vtcm_mb"`` -> ``vtcm_size_in_mb``,
        ``"O"`` -> ``optimization_type``). Unknown fields within a known section are
        stored in the config object's ``_extras``. Unknown top-level sections are
        returned as ``section_extras``.

        For graph configs, ``graph_names`` lists with multiple entries are expanded
        into one ``HtpGraphConfig`` per name, each sharing the same options.

        Args:
            backend_ext: The raw backend extension dictionary (as loaded from JSON).

        Returns:
            A tuple of (context_configs, graph_configs, device_configs, memory_config,
            group_context_config, section_extras).
        """
        parse = HtpConfigHelper._parse_config_section
        section_extras: Dict[str, Any] = {k: v for k, v in backend_ext.items() if k not in cls._CONFIG_TYPES}

        # --- Context ---
        context_configs: List[HtpContextConfig] = []
        raw_context = backend_ext.get("context", [])
        if isinstance(raw_context, dict):
            raw_context = [raw_context]
        for ctx_data in raw_context:
            known, extras = parse(HtpContextConfig, ctx_data)
            ctx_cfg = HtpContextConfig(**known)
            ctx_cfg._extras = extras
            context_configs.append(ctx_cfg)

        # --- Graphs ---
        graph_configs: List[HtpGraphConfig] = []
        for graph_data in backend_ext.get("graphs", []):
            graph_names = graph_data.get("graph_names", [])
            remaining = {k: v for k, v in graph_data.items() if k != "graph_names"}
            known, extras = parse(HtpGraphConfig, remaining)

            # Expand: one HtpGraphConfig per graph name
            for gname in graph_names:
                graph_cfg = HtpGraphConfig(name=gname, **{k: v for k, v in known.items() if k != "name"})
                graph_cfg._extras = extras.copy()
                graph_configs.append(graph_cfg)

        # --- Devices ---
        device_configs: List[HtpDeviceConfig] = []
        for dev_data in backend_ext.get("devices", []):
            raw_cores = dev_data.get("cores", [])
            remaining = {k: v for k, v in dev_data.items() if k != "cores"}
            known, extras = parse(HtpDeviceConfig, remaining)

            # Parse nested cores
            core_configs: List[HtpDeviceCoreConfig] = []
            for core_data in raw_cores:
                core_known, core_extras = parse(HtpDeviceCoreConfig, core_data)
                core_cfg = HtpDeviceCoreConfig(**core_known)
                core_cfg._extras = core_extras
                core_configs.append(core_cfg)

            if core_configs:
                known["cores"] = core_configs
            dev_cfg = HtpDeviceConfig(**known)
            dev_cfg._extras = extras
            device_configs.append(dev_cfg)

        # --- Memory ---
        memory_config: Optional[HtpMemoryConfig] = None
        if "memory" in backend_ext:
            known, extras = parse(HtpMemoryConfig, backend_ext["memory"])
            memory_config = HtpMemoryConfig(**known)
            memory_config._extras = extras

        # --- Group Context ---
        group_context_config: Optional[HtpGroupContextConfig] = None
        if "groupContext" in backend_ext:
            known, extras = parse(HtpGroupContextConfig, backend_ext["groupContext"])
            group_context_config = HtpGroupContextConfig(**known)
            group_context_config._extras = extras

        return (
            context_configs,
            graph_configs,
            device_configs,
            memory_config,
            group_context_config,
            section_extras,
        )
