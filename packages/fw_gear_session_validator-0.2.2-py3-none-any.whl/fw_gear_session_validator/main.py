"""Main module."""

import json
import logging
from pathlib import Path
from typing import Tuple

import flywheel
from flywheel import Client as FWClient

from fw_gear_session_validator.parser import RunOptions
from fw_gear_session_validator.pdf_report import generate_pdf_report
from fw_gear_session_validator.session import build_session_dict
from fw_gear_session_validator.utils import (
    check_for_qc_tags,
    handle_existing_qc_tags,
    save_report,
    tag_session_qc_result,
)
from fw_gear_session_validator.validation import validate_json, validate_schema

log = logging.getLogger(__name__)


def run(
    destination: dict,
    output_dir: Path,
    schema_path: Path,
    client: FWClient,
    options: RunOptions,
) -> Tuple[int, list[dict], flywheel.Session]:
    """Run the session validation.

    Args:
        destination: The destination container information.
        output_dir: The output directory for saving reports.
        schema_path: Path to the validation schema file.
        client: The Flywheel client to interact with the API.
        options: RunOptions with configurations and optional PDF links.

    Returns:
        Tuple
            e_code (int): Exit code of the run.
            validation_report (list[dict]): The validation report.
            session_ (flywheel.Session): The Flywheel session object.

    """

    # Grab the destination container and parent to make sure we are at the
    # session level
    run_level = destination.parent["type"]
    if run_level != "session":
        raise RuntimeError(
            f"Cannot run at {run_level} level. Please run at session level."
        )

    session_id = destination.parent["id"]
    session_ = client.get_session(session_id)
    log.info(f"Checking if session {session_.label} needs validation.")

    # Check for existing session-validator tags
    qc_tags = check_for_qc_tags(session_)
    # If session is already validated, log and exit
    if not handle_existing_qc_tags(session_, qc_tags, options.force_rerun):
        return None, None, None

    # Check if schema is valid
    log.debug(f"Loading schema from {schema_path}")
    with open(schema_path, "r") as schema_file:
        schema = json.load(schema_file)
    log.info("Validating schema...")
    if not validate_schema(schema):
        raise ValueError("Invalid JSON schema. Please check the schema file.")

    log.info(f"Validating session {session_.label}.")

    # Build session dictionary for validation
    log.debug("Building session dictionary.")
    session_dict = build_session_dict(session_)

    validation_report, validation_report_meta = validate_json(session_dict, schema)

    if options.save_validation_report:
        log.info("Validation complete. Saving JSON report.")
        save_report(output_dir, validation_report)
    else:
        log.info("Validation complete. Not saving JSON report as per configuration.")

    if options.save_pdf_report:
        log.info("Generating PDF report.")
        generate_pdf_report(
            output_dir, session_.label, validation_report, options.pdf_links
        )
    else:
        log.info("Not generating PDF report as per configuration.")

    # Tag session as PASS or FAIL
    log.info("Tagging session with QC result.")
    tag_session_qc_result(session_, passed=not len(validation_report))

    # Return error code
    # Return validation_report and session container for creating
    # qc metadata object in run.py
    return 0, validation_report_meta, session_
