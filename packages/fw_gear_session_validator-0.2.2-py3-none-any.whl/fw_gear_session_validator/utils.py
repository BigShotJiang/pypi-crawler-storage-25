import json
import logging
from pathlib import Path

import flywheel

log = logging.getLogger(__name__)


def check_for_qc_tags(session: flywheel.Session) -> list[str]:
    """Check for QC tags in the session.

    Args:
        session (flywheel.Session): The session to check for QC tags.

    Returns:
        list: A list of QC tags found in the session.
    """

    qc_tags = [tag for tag in session.tags if tag.startswith("session-qc-")]

    return qc_tags


def save_report(output_dir: Path, validation_reports: list[dict]) -> None:
    """Save the validation report to a file.

    Args:
        output_dir: The output directory to save the report.
        validation_reports: The validation reports to save.

    Returns:
        None
    """
    report_path = output_dir / "validation_report.json"
    with open(report_path, "w") as f:
        json.dump(validation_reports, f, indent=2)
    log.info(f"Validation report saved to {report_path}")


def tag_session_qc_result(session: flywheel.Session, passed: bool) -> None:
    """
    Tag the session as PASS or FAIL for QC.

    Args:
        session: The session object to tag.
        passed (bool): True if validation passed, False otherwise.
    """
    if passed:
        log.info("Session validation passed. Tagging session with 'session-qc-PASS'.")
        if "session-qc-PASS" not in session.tags:
            session.tags.append("session-qc-PASS")
            session.update({"tags": session.tags})
    else:
        log.info("Session validation failed. Tagging session with 'session-qc-FAIL'.")
        if "session-qc-FAIL" not in session.tags:
            session.tags.append("session-qc-FAIL")
            session.update({"tags": session.tags})


def handle_existing_qc_tags(
    session: flywheel.Session, qc_tags: list[str], force_rerun: bool = False
) -> bool:
    """
    Handle logic for existing QC tags on a session.

    Args:
        session (flywheel.Session): The session object.
        qc_tags (list): List of QC tags.
        force_rerun (bool): If True, force re-validation even if session has already passed.

    Returns:
        bool: True if validation should continue, False if it should exit early.
    """
    if "session-qc-PASS" in qc_tags:
        if force_rerun:
            log.info(
                "Session has already been validated and passed. "
                "Force rerun is enabled, re-running validation."
            )
            session.update({"tags": session.tags})
            session.tags.remove("session-qc-PASS")
            return True
        else:
            log.info(
                "Session has already been validated and passed. Skipping re-validation."
            )
            return False
    elif "session-qc-FAIL" in qc_tags:
        log.info(
            "Session has already been validated and failed. Re-running validation."
        )
        session.update({"tags": session.tags})
        session.tags.remove("session-qc-FAIL")
        return True
    else:
        if not qc_tags:
            log.info("No QC tags found on session. Proceeding with validation.")
        else:
            log.info(
                f"Session has only other QC tags ({qc_tags}). Proceeding with validation."
            )
        return True
