"""Parser module to parse gear config.json."""

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

from fw_gear import GearContext as GearToolkitContext


@dataclass(frozen=True)
class PdfLinks:
    """PDF report link metadata."""

    session_path: str
    job_url: str
    session_url: str
    schema_url: str
    schema_filename: str
    schema_version: int


@dataclass(frozen=True)
class RunOptions:
    """Configuration options."""

    save_validation_report: bool = False
    save_pdf_report: bool = False
    force_rerun: bool = False
    pdf_links: Optional[PdfLinks] = None

    def validate(self) -> None:
        """Validate options."""
        if self.save_pdf_report and self.pdf_links is None:
            raise ValueError("save_pdf_report=True requires pdf_links.")


def build_pdf_links(gear_context: GearToolkitContext, destination: dict) -> PdfLinks:
    """Build all PDF report link metadata.

    Constructs session path, job URL, session URL, and schema info for PDF reports.

    Args:
        gear_context: The gear context containing client and config info.
        destination: The destination analysis container.

    Returns:
        PdfLinks dataclass with all link metadata.
    """
    client = gear_context.client
    session_id = destination.parent["id"]
    session = client.get_session(session_id)

    # Extract site URL (shared across all URL builders)
    api_host = client._fw.api_client.configuration.host
    site_url = api_host.rsplit("/api", 1)[0]

    # Build session path: fw://group/project/subject/session
    group = session.parents.group
    project = client.get_project(session.parents.project)
    subject = client.get_subject(session.parents.subject)
    session_path = f"fw://{group}/{project.label}/{subject.label}/{session.label}"

    # Build job URL
    job_id = gear_context.config.job.get("id")
    job_url = f"{site_url}/#/jobs/{job_id}" if job_id else ""

    # Build session URL
    session_url = (
        f"{site_url}/#/projects/{session.parents.project}/sessions/{session_id}"
    )

    # Build schema info
    schema_url, schema_filename, schema_version = "", "", 0
    schema_input = gear_context.config.get_input("validation_schema")
    if schema_input:
        container_type = schema_input.get("hierarchy", {}).get("type", "")
        container_id = schema_input.get("hierarchy", {}).get("id", "")
        schema_filename = schema_input.get("location", {}).get("name", "")
        file_id = schema_input.get("object", {}).get("file_id", "")

        if file_id and container_id:
            try:
                file_info = client.get_file(file_id)
                schema_version = getattr(file_info, "version", 0)
            except Exception:
                pass  # Version is optional

        if container_type and container_id:
            schema_url = f"{site_url}/#/{container_type}s/{container_id}"

    return PdfLinks(
        session_path=session_path,
        job_url=job_url,
        session_url=session_url,
        schema_url=schema_url,
        schema_filename=schema_filename,
        schema_version=schema_version,
    )


def parse_config(
    gear_context: GearToolkitContext,
) -> Tuple[dict, Path, Path, RunOptions]:
    """Parse context config.json object.

    Args:
        gear_context (GearToolkitContext): The gear context containing configuration.

    Returns:
        tuple:
            destination: The destination container information.
            output_dir: The output directory for saving reports.
            schema_path: Path to the validation schema file.
            options: RunOptions with flags and optional PDF links.
    """
    save_validation_report = gear_context.config.opts.get(
        "save_validation_report", False
    )
    force_rerun = gear_context.config.opts.get("force_rerun", False)
    save_pdf_report = gear_context.config.opts.get("save_pdf_report", False)
    schema_path = gear_context.config.get_input_path("validation_schema")
    if not schema_path:
        raise ValueError("Validation schema is required.")

    destination = gear_context.client.get_analysis(
        gear_context.config.destination["id"]
    )

    pdf_links = build_pdf_links(gear_context, destination) if save_pdf_report else None

    options = RunOptions(
        save_validation_report=save_validation_report,
        save_pdf_report=save_pdf_report,
        force_rerun=force_rerun,
        pdf_links=pdf_links,
    )

    return destination, Path(gear_context.output_dir), Path(schema_path), options
