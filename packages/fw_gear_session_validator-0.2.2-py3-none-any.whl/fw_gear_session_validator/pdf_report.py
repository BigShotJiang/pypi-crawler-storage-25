"""Module to generate PDF reports for validation errors."""

import html
import logging
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from fw_gear_session_validator.validation import ValidationErrorReport

if TYPE_CHECKING:
    from fw_gear_session_validator.parser import PdfLinks

log = logging.getLogger(__name__)


def _build_error_table(error: ValidationErrorReport, idx: int, cell_style) -> Table:
    """Build a table for a single validation error."""
    error_dict = asdict(error) if hasattr(error, "__dataclass_fields__") else error

    # Escape HTML to prevent reportlab from interpreting placeholders like <int> as tags
    description = html.escape(
        error_dict.get("description") or "No description available"
    )
    schema_definition = html.escape(error_dict.get("schema_definition") or "N/A")
    schema_path = html.escape(error_dict.get("schema_path", ""))
    error_message = html.escape(error_dict.get("error_message", ""))

    error_card_data = [
        ["Error Number", str(idx)],
        ["Description", Paragraph(description, cell_style)],
        ["Schema Definition", Paragraph(schema_definition, cell_style)],
        ["Schema Path", Paragraph(schema_path, cell_style)],
        ["Error Message", Paragraph(error_message, cell_style)],
    ]

    error_table = Table(error_card_data, colWidths=[1.8 * inch, 5 * inch])
    error_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#f5f5f5")),
                ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]
        )
    )
    return error_table


def generate_pdf_report(
    output_dir: Path,
    session_label: str,
    validation_errors: List[ValidationErrorReport],
    pdf_links: Optional["PdfLinks"] = None,
) -> Path:
    """Generate a PDF report summarizing validation errors.

    Args:
        output_dir: Directory to save the PDF report.
        session_label: Label of the session being validated.
        validation_errors: List of validation error reports.
        pdf_links: Optional PdfLinks with session path, job URL, session URL,
            schema URL, schema filename, and schema version.

    Returns:
        Path to the generated PDF file.
    """
    report_path = output_dir / "validation_report.pdf"
    doc = SimpleDocTemplate(
        str(report_path),
        pagesize=letter,
        rightMargin=0.5 * inch,
        leftMargin=0.5 * inch,
        topMargin=0.5 * inch,
        bottomMargin=0.5 * inch,
    )

    # Build the PDF content
    elements = []
    styles = getSampleStyleSheet()

    # Custom styles
    title_style = ParagraphStyle(
        "CustomTitle",
        parent=styles["Heading1"],
        fontSize=18,
        spaceAfter=12,
        textColor=colors.HexColor("#2c3e50"),
    )

    heading_style = ParagraphStyle(
        "CustomHeading",
        parent=styles["Heading2"],
        fontSize=14,
        spaceBefore=12,
        spaceAfter=6,
        textColor=colors.HexColor("#34495e"),
    )

    # Title
    elements.append(Paragraph("Session Validator Report", title_style))
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    elements.append(Paragraph(f"<i>Created: {timestamp}</i>", styles["Normal"]))
    if pdf_links and pdf_links.job_url:
        job_id = pdf_links.job_url.rsplit("/", 1)[-1]
        elements.append(
            Paragraph(
                f'<i>Job ID: <a href="{pdf_links.job_url}" color="blue">{job_id}</a></i>',
                styles["Normal"],
            )
        )
    elements.append(Spacer(1, 12))

    # Summary section
    elements.append(Paragraph("Summary", heading_style))

    passed = len(validation_errors) == 0
    status_text = "PASS" if passed else "FAIL"
    status_color = colors.HexColor("#27ae60") if passed else colors.HexColor("#e74c3c")

    # Build session location string (with hyperlink if session_url is provided)
    link_style = ParagraphStyle("LinkStyle", parent=styles["Normal"], fontSize=10)
    session_location = pdf_links.session_path if pdf_links else session_label
    if pdf_links and pdf_links.session_url:
        session_location_cell = Paragraph(
            f'<a href="{pdf_links.session_url}" color="blue">{session_location}</a>',
            link_style,
        )
    else:
        session_location_cell = session_location

    # Build schema filename cell (clickable hyperlink)
    if pdf_links and pdf_links.schema_filename:
        if pdf_links.schema_url:
            schema_filename_cell = Paragraph(
                f'<a href="{pdf_links.schema_url}" color="blue">'
                f"{pdf_links.schema_filename}</a>",
                link_style,
            )
        else:
            schema_filename_cell = pdf_links.schema_filename
    else:
        schema_filename_cell = "N/A"

    # Build schema file version cell
    schema_version_cell = str(pdf_links.schema_version) if pdf_links else "N/A"

    summary_data = [
        ["Number of Errors", str(len(validation_errors))],
        ["Status", status_text],
        ["Session Location", session_location_cell],
        ["Schema Filename", schema_filename_cell],
        ["Schema File Version", schema_version_cell],
    ]

    summary_table = Table(summary_data, colWidths=[1.8 * inch, 5 * inch])
    summary_table.setStyle(
        TableStyle(
            [
                # Header column styling
                ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#f5f5f5")),
                ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 10),
                # Status row coloring
                ("TEXTCOLOR", (1, 1), (1, 1), status_color),
                ("FONTNAME", (1, 1), (1, 1), "Helvetica-Bold"),
                # Padding
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 8),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                # Grid
                ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]
        )
    )
    elements.append(summary_table)
    elements.append(Spacer(1, 20))

    # List of Errors section
    if validation_errors:
        elements.append(Paragraph("List of Errors", heading_style))
        cell_style = ParagraphStyle(
            "CellStyle", parent=styles["Normal"], fontSize=9, leading=12
        )
        for idx, error in enumerate(validation_errors, start=1):
            elements.append(_build_error_table(error, idx, cell_style))
            elements.append(Spacer(1, 12))
    else:
        elements.append(
            Paragraph(
                "No validation errors found. The session passed all validation checks.",
                styles["Normal"],
            )
        )

    # Build the PDF
    doc.build(elements)
    log.info(f"PDF report saved to {report_path}")

    return report_path
