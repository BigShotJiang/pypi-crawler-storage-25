"""Module to build session dictionary for validation."""

import logging

import flywheel

log = logging.getLogger(__name__)


def build_session_dict(session: flywheel.Session) -> dict:
    """
    Build a session dict for validation.

        Args:
            session (flywheel.Session): The Flywheel session to build the dict for.

        Returns:
            dict: The nested session dictionary.
    """
    # Start with session fields
    session_dict = session.to_dict()

    # Add acquisitions (list of dicts)
    session_dict["acquisitions"] = []
    for acq in session.acquisitions.iter_find():
        acq = acq.reload()
        acq_dict = acq.to_dict()
        acq_dict["files"] = [f.to_dict() for f in acq.files]

        session_dict["acquisitions"].append(acq_dict)

    return session_dict
