"""Module to handle JSONschema validation"""

import logging
import typing as t
from dataclasses import dataclass
from typing import Optional, Tuple

from jsonschema import Draft202012Validator

from fw_gear_session_validator.errors import create_simple_error_message

log = logging.getLogger(__name__)


@dataclass
class ValidationErrorReport:
    error_message: str
    instance_path: str
    label: str
    schema_path: str
    validator_type: t.Dict[str, t.Any]  # Dict with 'type' and 'details'
    validator_value: t.Any
    schema_definition: Optional[str] = None  # Optional, only present if $ref exists
    description: Optional[str] = (
        None  # Description from schema, extracted by walking up schema path
    )


def validate_schema(schema: dict) -> bool:
    """Quick validator for input jsonschema.

    Args:
        schema (dict): json-loaded schema

    Returns:
        bool: True or False whether schema is valid
    """
    try:
        Draft202012Validator.check_schema(schema)
        return True
    except Exception as e:
        log.error(f"JSON template invalid: {e}")
        return False


def validate_json(data: dict, schema: dict) -> Tuple[list[dict], list[dict]]:
    """Validate a JSON data structure against a schema.

    Args:
        data (dict): The JSON data to validate.
        schema (dict): The JSON schema to validate against.

    Returns:
        tuple:
            list: A list of validation error report dictionaries.
            list: A list of validation error reports for Flywheel metadata.
    """

    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(data), key=lambda e: e.path)
    validation_report = []
    validation_report_meta = []
    for error in errors:
        error_dict = create_simple_error_message(error, schema_root=schema)

        # Create validation report for output file
        validation_report.append(
            ValidationErrorReport(
                error_message=error_dict["error_message"],
                instance_path=error_dict["instance_path"],
                label=error_dict["label"],
                schema_path=error_dict["schema_path"],
                validator_type=error_dict["validator_type"],
                validator_value=error_dict["validator_value"],
                schema_definition=error_dict.get("schema_definition"),
                description=error_dict.get("description"),
            )
        )

        # Create validation report for Flywheel metadata
        validation_report_meta.append(
            ValidationErrorReport(
                error_message=error_dict["error_message"],
                instance_path=error_dict["instance_path"],
                label=error_dict["label"],
                schema_path=error_dict["schema_path"],
                validator_type=error_dict["validator_type"],
                validator_value=error_dict["validator_value"],
                schema_definition=error_dict.get("schema_definition"),
                description=error_dict.get("description"),
            )
        )

    return validation_report, validation_report_meta
