"""
Simple JSONSchema Error Handler

A lightweight approach that extracts key error information

This approach:
1. Extracts validator type
2. Extracts schema path
3. Extracts instance path
4. Cleans error.message by removing instance representation
5. Extracts description from schema by walking up schema path

"""

from typing import Any, Dict, Optional, Sequence, Tuple

from jsonschema.exceptions import ValidationError


def _resolve_path(root: Any, path: Sequence[Any]) -> Any:
    """Resolve a path within a nested data structure.

    Args:
        root: The root data structure (dict/list)
        path: Sequence of keys/indices to traverse

    Returns:
        The value at the specified path
    """
    node = root
    for key in path:
        node = node[key]
    return node


def nearest_description(
    schema_root: dict, abs_schema_path: Sequence[Any]
) -> Tuple[Optional[str], Optional[Sequence[Any]]]:
    """Find the nearest description by walking up the schema path.

    JSONSchema validators may fail at a node that doesn't have a description,
    but a parent node (e.g., an allOf element) often does. This function
    walks up from the failing node to find the nearest description.

    Args:
        schema_root: The root schema dictionary
        abs_schema_path: The absolute schema path from the validation error

    Returns:
        Tuple of (description string or None, path where found or None)
    """
    # Start at the failing node and walk up to the root
    for i in range(len(abs_schema_path), -1, -1):
        sub_path = abs_schema_path[:i]
        try:
            node = _resolve_path(schema_root, sub_path)
        except (KeyError, IndexError, TypeError):
            continue

        if isinstance(node, dict):
            desc = node.get("description")
            if isinstance(desc, str) and desc.strip():
                return desc, sub_path

    return None, None


def create_simple_error_message(
    error: ValidationError, schema_root: Optional[dict] = None
) -> Dict[str, Any]:
    """
    Create a simple, clean error message from ValidationError.

    This extracts the essential information and cleans the error message
    by removing the instance representation that causes 1MB messages.

    Args:
        error: ValidationError from jsonschema
        schema_root: The root schema dictionary (optional, for description extraction)

    Returns:
        Dict with keys:
            - error_message: Cleaned error message without instance repr
            - instance_path: Path in the data where error occurred
            - label: Human-facing label (falls back to $ref)
            - description: Human-readable description from schema (if found)
            - schema_definition: Tail of validator_value[$ref] if present
            - schema_path: Path in the schema where error occurred
            - validator_type: Dict with 'type' and 'details' (details vary by type)
            - validator_value: The constraint value from schema
    """
    # 1. Extract validator type
    validator_type_str = error.validator

    # 2. Extract schema path (where in schema the error is defined)
    schema_path = list(error.absolute_schema_path)
    schema_path_str = ".".join(str(p) for p in schema_path) if schema_path else "root"

    # 3. Extract instance path (where in data the error occurred)
    instance_path = list(error.absolute_path)
    instance_path_str = (
        ".".join(str(p) for p in instance_path) if instance_path else "root"
    )

    # 4. Get error message
    original_message = error.message

    # 5. Clean the message by removing instance representation
    cleaned_message = clean_error_message(original_message, error.instance)

    # 6. Extract validator value
    validator_value = error.validator_value

    # 7. Extract $ref and schema_definition if present
    # NOTE: schema_definition is only populated when validator_value contains a $ref.
    # For direct constraints (e.g., maximum: -9, pattern: "^[A-Z]+$"), schema_definition
    # will remain None since they don't reference a definition.
    schema_definition = None
    label = None
    if isinstance(validator_value, dict) and "$ref" in validator_value:
        ref_value = validator_value["$ref"]
        # Extract definition name from $ref path (e.g., "#/$defs/T1_acquisition" -> "T1_acquisition")
        if "/" in ref_value:
            schema_definition = ref_value.split("/")[-1]
        else:
            schema_definition = ref_value
        label = schema_definition  # Use definition as label

    # 8. Generate label if not already set
    if label is None:
        label = _generate_label(validator_type_str, validator_value, instance_path)

    # 9. Build validator_type with details
    validator_type_obj = {
        "type": validator_type_str,
        "details": _extract_validator_details(error),
    }

    # 10. Extract description from schema by walking up the schema path
    description = None
    if schema_root is not None:
        description, _ = nearest_description(schema_root, schema_path)

    # 11. Build result
    result = {
        "error_message": cleaned_message,
        "instance_path": instance_path_str,
        "label": label,
        "schema_path": schema_path_str,
        "validator_type": validator_type_obj,
        "validator_value": validator_value,
    }

    # Add schema_definition if present
    if schema_definition is not None:
        result["schema_definition"] = schema_definition

    # Add description if found
    if description is not None:
        result["description"] = description

    return result


def clean_error_message(message: str, instance: Any) -> str:
    """
    Clean error message by removing the instance representation.

    JSONSchema error messages often follow patterns like:
        "<instance repr> <description>"
        "None of <instance repr> are valid under the given schema"

    This function removes the instance repr part.

    Args:
        message: Original error message from jsonschema
        instance: The instance value that failed validation

    Returns:
        Cleaned error message
    """
    # NEW SIMPLIFIED APPROACH: Remove instance repr from message
    instance_repr = repr(instance)

    # Check if instance repr is in the message
    if instance_repr in message:
        # Replace the instance repr with a placeholder
        if isinstance(instance, list):
            placeholder = f"[array of {len(instance)} items]"
        elif isinstance(instance, dict):
            placeholder = f"{{object with {len(instance)} keys}}"
        else:
            placeholder = f"<{type(instance).__name__}>"

        message = message.replace(instance_repr, placeholder)

    return message


def _extract_validator_details(error: ValidationError) -> Dict[str, Any]:  # noqa: PLR0912
    """
    Extract validator-specific details using a hybrid approach:
    - Custom logic for validators that need special handling
    - Dynamic extraction of all constraint keywords from schema

    Args:
        error: ValidationError from jsonschema

    Returns:
        Dict with details extracted from error and schema
    """
    validator_type = error.validator
    validator_value = error.validator_value
    instance = error.instance
    schema = error.schema

    details = {}

    # Step 1: Custom handling for validators that need special logic
    if validator_type == "required":
        # Calculate which specific fields are missing
        if isinstance(validator_value, list) and isinstance(instance, dict):
            missing = [field for field in validator_value if field not in instance]
            details["missing"] = missing

    elif validator_type == "type":
        # Show expected vs found type
        details["expected"] = validator_value
        details["found"] = type(instance).__name__

    elif validator_type == "pattern":
        # Show pattern and preview of actual value
        details["pattern"] = validator_value
        if isinstance(instance, str):
            details["preview"] = instance[:50]  # First 50 chars

    elif validator_type in ("anyOf", "oneOf", "allOf"):
        # Count number of alternatives
        if isinstance(validator_value, list):
            details["alternatives"] = len(validator_value)

    elif validator_type == "enum":
        # Show allowed values
        details["allowed_values"] = validator_value
        details["found"] = instance

    elif validator_type == "const":
        # Show expected constant value
        details["expected"] = validator_value
        details["found"] = instance

    # Step 2: Add instance size/length if applicable
    if isinstance(instance, (list, dict, str)):
        if "found" not in details:  # Don't overwrite if already set
            details["found"] = len(instance)

    # Step 3: DYNAMIC EXTRACTION - Get all constraint keywords from schema
    # Exclude structural/metadata keys that don't represent constraints
    metadata_keys = {
        "$schema",
        "$id",
        "$ref",
        "$defs",
        "definitions",
        "title",
        "description",
        "examples",
        "default",
        "comment",
        "type",
        "properties",
        "items",
        "additionalProperties",
        "patternProperties",
        "additionalItems",
        "required",
    }

    if isinstance(schema, dict):
        for key, value in schema.items():
            # Only add if:
            # 1. Not a metadata/structural key
            # 2. Not already in details (don't overwrite custom logic)
            # 3. Not the current validator's keyword (avoid duplication with validator_value)
            if (
                key not in metadata_keys
                and key not in details
                and key != validator_type
            ):
                details[key] = value

    return details


def _generate_label(
    validator_type: str, validator_value: Any, instance_path: list
) -> str:
    """
    Generate a human-facing label for the error.

    Args:
        validator_type: Type of validator that failed
        validator_value: The constraint value
        instance_path: Path to the instance that failed

    Returns:
        Human-readable label string
    """
    # Use the last element of instance_path if available
    if instance_path:
        return str(instance_path[-1])

    # Fallback to validator type
    if validator_type == "required":
        if isinstance(validator_value, list) and validator_value:
            return f"missing_{validator_value[0]}"
    elif validator_type == "type":
        return "type_mismatch"
    elif validator_type == "contains":
        return "contains_validation"

    return validator_type
