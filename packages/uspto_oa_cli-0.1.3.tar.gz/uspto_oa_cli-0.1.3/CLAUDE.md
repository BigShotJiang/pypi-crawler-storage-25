# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 프로젝트 개요

USPTO ODP(Open Data Portal) API를 통해 미국 특허 심사과정 문서를 다운로드하고, XML 파싱을 거쳐 구조화된 Markdown으로 변환하는 CLI 도구. AI 에이전트(Claude Code, Gemini CLI)가 생성된 MD 파일을 읽고 심사 전략을 분석하는 워크플로우를 목표로 한다. LLM API 직접 호출은 최소화하고 AI 코딩 에이전트에게 분석을 위임하는 방식을 지향한다.

## 실행 명령

```bash
# 의존성 설치
uv sync

# API 키 설정 (최초 1회) → ~/.oa-cli.toml 에 저장
uv run uspto-oa configure

# 문서 목록 조회 (다운로드 없이)
uv run uspto-oa list 16330077

# 문서 다운로드
uv run uspto-oa download 16330077

# XML 파싱 → MD 생성 (file/{app_num}/{app_num}_prosecution.md)
uv run uspto-oa extract 16330077

# JSON 형식으로 추출
uv run uspto-oa extract 16330077 --format json

# 특정 문서 코드만 다운로드
uv run uspto-oa download 16330077 --doc-codes CTNF,CTFR,NOA

# 강제 재다운로드
uv run uspto-oa download 16330077 --force

# 상세 로그
uv run uspto-oa -v download 16330077

# PyPI 배포 (빌드 → 업로드)
uv build && uv run twine upload dist/*
```

**API 키 우선순위**: `--api-key` 옵션 > `USPTO_API_KEY` 환경변수 > `~/.oa-cli.toml` (개발 시 `.env` 자동 로드)

## 소스 구조

```
src/oa_cli/                 # PyPI 배포 패키지 (hatchling wheel 타겟)
├── __init__.py             # __version__
├── __main__.py             # python -m oa_cli 지원
├── cli.py                  # click 진입점 (configure / list / download / extract 커맨드)
├── config.py               # API 키 우선순위 관리, ~/.oa-cli.toml 읽기/쓰기
├── uspto/                  # USPTO ODP API 저수준 클라이언트 (도메인 무관)
│   ├── client.py           # make_api_request() — GET + 재시도/백오프
│   ├── documents.py        # get_application_documents() — 문서 목록 API
│   └── download.py         # download_file() / download_bytes()
└── prosecution/            # 심사과정 분석 도메인 로직
    ├── collect.py          # 문서 필터링 + XML 우선 일괄 다운로드
    └── extract.py          # XML 파싱 → prosecution.md / prosecution.json 생성
file/
└── {app_num}/              # 다운로드 파일 + 생성된 MD/JSON 저장 위치
```

## 커맨드 맵

```
uspto-oa list {app_num}           # 1단계: API 조회, 다운로드 없이 문서 목록 확인
    └─ fetch_document_list() 재사용

uspto-oa download {app_num}       # 2단계: XML/PDF 파일을 file/{app_num}/ 에 저장
    └─ file/{app_num}/ 에 XML / PDF 저장

uspto-oa extract {app_num}        # 3단계: 저장된 파일 파싱
    └─ file/{app_num}/{app_num}_prosecution.md  (또는 .json)
         └─ AI 에이전트 (Claude Code / Gemini CLI)
              └─ 심사 전략 분석, 요약, 질의응답
```

## 아키텍처 핵심 사항

**레이어 분리**: `src/uspto/`는 API 통신만 담당(도메인 무관), `src/prosecution/`은 심사과정 비즈니스 로직 담당. `cli.py`는 두 레이어를 연결하는 진입점.

**서버사이드 필터 미사용**: USPTO API의 `documentCodes` 파라미터가 500 오류를 유발하므로, 전건 조회 후 클라이언트에서 필터링한다(`collect.py`의 `PROSECUTION_CODES_EXACT` / `PROSECUTION_CODE_PREFIXES`).

**파일명 규칙**: `{날짜}_{코드}_{문서ID}.{ext}` — 날짜 오름차순 정렬, 확장자는 실제 포맷 반영.

**다운로드 우선순위**: XML > PDF (MS_WORD 제외). XML은 tar 아카이브로 전달되므로 압축 해제 후 저장하며, tar 내 `.xml` 없거나 오류 시 PDF로 자동 폴백.

**XML 구조 (USPTO ST96 스키마)**:
- CTNF/CTFR: `FormParagraph[07-21-aia]`에 거절 항목, `FormParagraph[07-39]`에 Final 여부
- NOA/NACT: `FormParagraph[12-151-07]`에 허여 청구항, `FormParagraph[13-03]`에 Examiner's Statement
- Amendment(`A*`): `<CLM>` 섹션에 보정 청구항, `<REM>` 섹션에 의견서
- EXIN: 전체 텍스트 raw_text로 추출

**PDF 특이사항**: USPTO OA PDF는 전 페이지 이미지 구성 → pypdf 텍스트 추출 불가. PDF 전용 문서는 MD에 경로만 참조로 포함하고 AI 에이전트가 필요 시 직접 읽도록 한다.

**생성 MD 구조** (`{app_num}_prosecution.md`):
- 타임라인 표 (전체 문서, XML/PDF 형식 표시)
- Office Action 상세 (CTNF/CTFR 거절 항목 전문)
- Amendment 상세 (CLM 보정 청구항 + REM 의견서)
- Examiner Interview 상세 (EXIN raw_text)
- Notice of Allowance 상세 (허여 청구항 + Examiner's Statement)
- PDF 전용 문서 목록 (AI 에이전트 직접 전달용)

## 수집 대상 문서 코드

| 코드 | 의미 | XML 파싱 |
|------|------|:--------:|
| `CTNF` | Non-Final Office Action | ✓ (거절 항목) |
| `CTFR` | Final Office Action | ✓ (거절 항목) |
| `NOA` / `NACT` | Notice of Allowance | ✓ (허여 청구항 + 이유) |
| `A*` | Amendment 계열 전체 | ✓ (CLM + REM) |
| `EXIN` | Examiner Interview Summary | ✓ (전문) |
| `REM` | Remarks | - |
| `ABN` | Abandonment | - |
| `RCE` / `RCEX` | Request for Continued Examination | - |
| `CTAV` | Advisory Action | - |
| `SRNT` / `SRFW` | Search Report | - |
| `892` / `1449` / `IDS` | Prior Art / IDS | - |

## 함정 (Pitfalls)

- **잘못된 `--doc-codes` 입력**: 알 수 없는 코드를 입력하면 경고를 출력하지만 계속 진행한다. 결과가 0건이면 `uspto-oa list {app_num}`으로 실제 존재하는 코드를 확인하라.
- **pre-AIA 출원의 `rejections: []`**: FormParagraph 번호가 AIA 이후 표준과 다르면 거절 항목 파싱이 빈 배열이 된다. 이 경우 `raw_text` 필드에 전문이 담긴다. 2012년 이전 출원일을 가진 출원에서 발생할 수 있다.
- **PDF 전용 문서 본문**: USPTO OA PDF는 이미지 스캔이라 텍스트 추출 불가. 분석이 필요하면 파일 경로를 직접 Read해야 한다.
- **Amendment XML 파싱 실패**: `<CLM>` / `<REM>` 태그가 없거나 네임스페이스가 다르면 `claims`·`remarks`가 빈 문자열이 되고 `raw_text`로 폴백된다.
- **`list` vs `download`의 코드 목록 차이**: `list`는 API의 전체 목록 중 필터링된 심사 관련 코드를 보여준다. `download`도 동일 필터를 사용하지만, 실제 다운로드 가능 여부는 `downloadOptionBag`에 달려 있다.

## 워크플로우 레시피

**심사 이력 요약:**
```bash
uspto-oa download 16330077
uspto-oa extract 16330077
# 생성된 file/16330077/16330077_prosecution.md 를 Claude Code 에 전달
```

**거절 이유 분석 (JSON 파이프라인):**
```bash
uspto-oa download 16330077 --doc-codes CTNF,CTFR
uspto-oa extract 16330077 --format json
# prosecution.json 을 Claude Code 가 읽어 정량 분석
```

**다운로드 전 문서 확인:**
```bash
uspto-oa list 16330077               # 심사 관련 문서만
uspto-oa list 16330077 --all         # 전체 문서 (행정 문서 포함)
uspto-oa list 16330077 --format json # JSON 출력
```

## 다음 구현 단계

- `--step summary/detail/prior-art/strategy` — 생성된 prosecution.md를 AI 에이전트에 넘기는 분석 진입점 (LLM API 직접 호출 없이 Claude Code / Gemini CLI에 위임)
- `--no-download` — 이미 다운로드된 파일 기준으로 extract 바로 수행
