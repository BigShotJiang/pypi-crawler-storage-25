"""USPTO 특허 심사과정 분석 CLI."""

import logging
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table

from oa_cli import __version__
from oa_cli import config as cfg

console = Console()


@click.group(invoke_without_command=True)
@click.version_option(__version__, prog_name="uspto-oa")
@click.option("--verbose", "-v", is_flag=True, default=False, help="상세 로그 출력.")
@click.pass_context
def main(ctx: click.Context, verbose: bool) -> None:
    """USPTO 특허 심사과정 분석 CLI.

    \b
    빠른 시작:
      uspto-oa configure                    # API 키 저장
      uspto-oa list 16330077                # 문서 목록 조회
      uspto-oa download 16330077            # 문서 다운로드
      uspto-oa extract 16330077             # XML 파싱 → MD 생성
    """
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(stream=sys.stderr, level=level, format="%(levelname)s  %(message)s")
    if ctx.invoked_subcommand is None:
        click.echo(f"uspto-oa v{__version__}")
        click.echo(ctx.get_help())


# ── configure ────────────────────────────────────────────────────────────────

@main.command()
@click.option("--show", is_flag=True, default=False, help="현재 설정만 표시하고 종료.")
def configure(show: bool) -> None:
    """API 키와 기본 설정을 저장합니다.

    \b
    설정 파일: ~/.oa-cli.toml
    Enter 입력 시 기존 값 유지.
    """
    existing = cfg.load()
    auth_cfg = existing.get("auth", {})

    click.echo("OA CLI — 설정")
    click.echo("─" * 40)
    click.echo(f"설정 파일: {cfg.CONFIG_PATH}")
    click.echo()

    current_key = auth_cfg.get("api_key", "")

    if show:
        click.echo(f"  auth.api_key = {cfg.mask_key(current_key)}")
        return

    new_key = click.prompt(
        f"USPTO API 키 [{cfg.mask_key(current_key)}]",
        default="",
        show_default=False,
    ).strip()

    final_key = new_key if new_key else current_key
    if not final_key:
        click.echo("\n경고: API 키가 없습니다. 나중에 다시 실행하세요.", err=True)
        return

    cfg.save({"auth": {"api_key": final_key}})
    click.echo(f"\n설정 저장: {cfg.CONFIG_PATH}")
    click.echo(f"  auth.api_key = {cfg.mask_key(final_key)}")


# ── list ─────────────────────────────────────────────────────────────────────

@main.command("list")
@click.argument("application")
@click.option("--all", "show_all", is_flag=True, default=False, help="심사 관련 필터 없이 전체 문서 목록.")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "json"]),
              help="출력 형식 (기본: table).")
@click.option("--api-key", default=None, help="API 키.")
@click.pass_context
def list_docs(
    ctx: click.Context,
    application: str,
    show_all: bool,
    fmt: str,
    api_key: Optional[str],
) -> None:
    """다운로드 없이 문서 목록을 조회합니다.

    \b
    예시:
      uspto-oa list 16330077
      uspto-oa list 16330077 --all
      uspto-oa list 16330077 --format json
    """
    import json as _json
    from oa_cli.prosecution.collect import (
        fetch_document_list, normalize_app_number,
        PROSECUTION_CODES_EXACT, PROSECUTION_CODE_PREFIXES, MIME_PRIORITY,
    )
    from oa_cli.prosecution.extract import CODE_LABELS

    key = cfg.require_api_key(api_key)
    app_num = normalize_app_number(application)

    console.print(f"[dim]문서 목록 조회 중...[/dim]")
    all_docs = fetch_document_list(app_num, key)

    if show_all:
        docs = all_docs
    else:
        docs = [
            d for d in all_docs
            if (d.get("documentCode") or d.get("code") or "") in PROSECUTION_CODES_EXACT
            or any(
                (d.get("documentCode") or d.get("code") or "").startswith(p)
                for p in PROSECUTION_CODE_PREFIXES
            )
        ]

    if not docs:
        console.print("[yellow]문서가 없습니다.[/yellow]")
        return

    if fmt == "json":
        result = []
        for d in docs:
            code = d.get("documentCode") or d.get("code") or ""
            date = (d.get("officialDate") or d.get("mailDate") or "").split("T")[0]
            mimes = [
                o.get("mimeTypeIdentifier", "").upper()
                for o in d.get("downloadOptionBag") or []
                if o.get("mimeTypeIdentifier", "").upper() in MIME_PRIORITY
            ]
            result.append({"date": date, "code": code, "label": CODE_LABELS.get(code, ""), "formats": mimes})
        click.echo(_json.dumps(result, indent=2, ensure_ascii=False))
        return

    scope = "전체" if show_all else "심사 관련"
    table = Table(title=f"문서 목록 — {app_num}  ({scope} {len(docs)}건)", show_lines=False)
    table.add_column("날짜", style="cyan", no_wrap=True)
    table.add_column("코드", style="magenta")
    table.add_column("형식", justify="center")
    table.add_column("설명")

    for d in docs:
        code = d.get("documentCode") or d.get("code") or "?"
        date = (d.get("officialDate") or d.get("mailDate") or "").split("T")[0]
        mimes = [
            o.get("mimeTypeIdentifier", "").upper()
            for o in d.get("downloadOptionBag") or []
            if o.get("mimeTypeIdentifier", "").upper() in MIME_PRIORITY
        ]
        fmt_str = "/".join(mimes) if mimes else "PDF"
        label = CODE_LABELS.get(code, "")
        table.add_row(date, code, fmt_str, label)

    console.print(table)


# ── download ─────────────────────────────────────────────────────────────────

@main.command()
@click.argument("application")
@click.option("--doc-codes", default=None, metavar="CODES",
              help="쉼표 구분 문서 코드 (예: CTNF,CTFR,NOA). 생략 시 전체 수집 대상.")
@click.option("--output-dir", default=None, metavar="DIR", help="저장 경로 (기본: file/{app_num}/).")
@click.option("--force", is_flag=True, default=False, help="기존 파일도 재다운로드.")
@click.option("--api-key", default=None, help="API 키 (설정 파일·환경변수보다 우선).")
@click.pass_context
def download(
    ctx: click.Context,
    application: str,
    doc_codes: Optional[str],
    output_dir: Optional[str],
    force: bool,
    api_key: Optional[str],
) -> None:
    """심사과정 문서를 다운로드합니다 (XML 우선, PDF 폴백).

    \b
    예시:
      uspto-oa download 16330077
      uspto-oa download 16330077 --doc-codes CTNF,CTFR,NOA
      uspto-oa download 16330077 --force
    """
    from oa_cli.prosecution.collect import (
        download_docs, normalize_app_number,
        PROSECUTION_CODES_EXACT, PROSECUTION_CODE_PREFIXES,
    )

    key = cfg.require_api_key(api_key)
    app_num = normalize_app_number(application)
    out_dir = output_dir or str(Path.cwd() / "file" / app_num)
    codes = [c.strip() for c in doc_codes.split(",")] if doc_codes else None

    # 알 수 없는 문서 코드 경고
    if codes:
        unknown = [
            c for c in codes
            if c not in PROSECUTION_CODES_EXACT
            and not any(c.startswith(p) for p in PROSECUTION_CODE_PREFIXES)
        ]
        if unknown:
            console.print(f"[yellow]경고: 알 수 없는 문서 코드: {', '.join(unknown)}[/yellow]")
            console.print(f"[dim]사용 가능한 코드: {', '.join(sorted(PROSECUTION_CODES_EXACT))}[/dim]")
            console.print()

    console.print(f"[bold]출원번호[/] {app_num}  →  [bold]{out_dir}[/]")
    console.print()

    results = download_docs(
        app_number=app_num,
        api_key=key,
        doc_codes=codes,
        output_dir=out_dir,
        force=force,
    )

    if not results:
        if codes:
            console.print(f"[yellow]이 출원에서 {', '.join(codes)} 문서를 찾을 수 없습니다.[/yellow]")
            console.print(f"[dim]전체 목록 확인: uspto-oa list {app_num}[/dim]")
        else:
            console.print("[yellow]다운로드된 문서가 없습니다.[/yellow]")
        return

    table = Table(title=f"다운로드 결과 — {app_num}", show_lines=False)
    table.add_column("날짜", style="cyan", no_wrap=True)
    table.add_column("코드", style="magenta")
    table.add_column("형식", justify="center")
    table.add_column("파일명")
    table.add_column("상태", justify="center")

    downloaded = skipped = 0
    for r in results:
        status = "[dim]스킵[/dim]" if r["skipped"] else "[green]완료[/green]"
        skipped += r["skipped"]
        downloaded += not r["skipped"]
        fmt = r.get("fmt", "pdf").upper()
        fmt_display = f"[green]{fmt}[/green]" if fmt == "XML" else fmt
        table.add_row(r["date"], r["code"], fmt_display, Path(r["path"]).name, status)

    console.print(table)
    console.print(f"\n[bold green]{downloaded}개 다운로드[/] / [dim]{skipped}개 스킵[/]")


# ── extract ──────────────────────────────────────────────────────────────────

@main.command()
@click.argument("application")
@click.option("--output-dir", default=None, metavar="DIR", help="파일 디렉토리 (기본: file/{app_num}/).")
@click.option("--format", "fmt", default="md", type=click.Choice(["md", "json"]),
              help="출력 형식 (기본: md).")
def extract(application: str, output_dir: Optional[str], fmt: str) -> None:
    """다운로드된 XML 파일을 파싱해 prosecution.md / prosecution.json 을 생성합니다.

    \b
    예시:
      uspto-oa extract 16330077
      uspto-oa extract 16330077 --format json
      # 결과: file/16330077/16330077_prosecution.md
    """
    from oa_cli.prosecution.extract import extract as do_extract
    from oa_cli.prosecution.collect import normalize_app_number

    app_num = normalize_app_number(application)
    file_dir = output_dir or str(Path.cwd() / "file" / app_num)
    out_ext = "json" if fmt == "json" else "md"
    out_path = str(Path(file_dir) / f"{app_num}_prosecution.{out_ext}")

    console.print(f"[bold]출원번호[/] {app_num}  →  [bold]{out_path}[/]")
    do_extract(app_num, file_dir=file_dir, output_path=out_path, fmt=fmt)
    console.print(f"[bold green]완료[/] {out_path}")
