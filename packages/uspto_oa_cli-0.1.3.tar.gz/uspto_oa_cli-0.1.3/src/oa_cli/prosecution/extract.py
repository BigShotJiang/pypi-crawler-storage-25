"""다운로드된 XML 파일 파싱 → 심사과정 분석 MD/JSON 생성."""

import json
import re
import logging
from pathlib import Path
from typing import Optional
import xml.etree.ElementTree as ET

logger = logging.getLogger(__name__)

USCOM = "{urn:us:gov:doc:uspto:common}"

CODE_LABELS = {
    "CTNF": "Non-Final Rejection",
    "CTFR": "Final Rejection",
    "NOA":  "Notice of Allowance",
    "NACT": "Notice of Allowance",
    "IDS":  "Information Disclosure Statement",
    "REM":  "Remarks",
    "ABST": "Abstract",
    "CLM":  "Claims",
    "SPEC": "Specification",
    "EXIN": "Examiner Interview Summary",
    "RCE":  "Request for Continued Examination",
    "RCEX": "Request for Continued Examination",
    "CTAV": "Advisory Action",
    "ABN":  "Abandonment",
    "892":  "Prior Art Reference",
    "1449": "Information Disclosure Statement",
    "SRNT": "Search Report (National)",
    "SRFW": "Search Report (Foreign)",
    "N271": "271 Notice",
}

# FormParagraph 번호 분류 (AIA 이후 표준)
_FP_REJECTION      = "07-21-aia"   # 거절 항목 (CTNF/CTFR)
_FP_FINAL_FLAG     = "07-39"       # Final Action 선언
_FP_ALLOWED_CLAIMS = "12-151-07"   # 허여 청구항
_FP_ALLOW_REASON   = "13-03"       # 허여 이유 (Examiner's Statement)


# ── 텍스트 정규화 ─────────────────────────────────────────────────

def _fp_text(fp_el) -> str:
    raw = " ".join(fp_el.itertext())
    text = re.sub(r"\s+", " ", raw).strip()
    text = re.sub(r"^[\w\.\-]+ (?:AIA )?", "", text, count=1)
    return text


def _all_text(root) -> str:
    return re.sub(r"\s+", " ", " ".join(root.itertext())).strip()


def _section_text(root, tag: str) -> str:
    """특정 섹션(CLM, REM 등) 텍스트 추출 — 네임스페이스 유무 모두 시도."""
    for prefix in (USCOM, ""):
        el = root.find(f".//{prefix}{tag}")
        if el is not None:
            return re.sub(r"\s+", " ", " ".join(el.itertext())).strip()
    return ""


# ── 문서 타입별 파서 ──────────────────────────────────────────────

def _fp_iter(root, number: str):
    for fp in root.iter(f"{USCOM}FormParagraph"):
        num_el = fp.find(f"{USCOM}FormParagraphNumber")
        if num_el is not None and (num_el.text or "").strip() == number:
            yield fp


def _parse_oa(root) -> dict:
    """CTNF / CTFR: 거절 항목 파싱. 파싱 실패(pre-AIA 등) 시 raw_text fallback."""
    rejections = [_fp_text(fp) for fp in _fp_iter(root, _FP_REJECTION)]
    is_final = any(True for _ in _fp_iter(root, _FP_FINAL_FLAG))
    raw_text = "" if rejections else _all_text(root)
    return {
        "is_final":   is_final,
        "rejections": rejections,
        "raw_text":   raw_text,
    }


def _parse_noa(root) -> dict:
    """NOA / NACT: 허여 청구항 + 허여 이유 파싱."""
    allowed = next((_fp_text(fp) for fp in _fp_iter(root, _FP_ALLOWED_CLAIMS)), "")
    reason  = next((_fp_text(fp) for fp in _fp_iter(root, _FP_ALLOW_REASON)),   "")
    return {
        "allowed_claims": allowed,
        "reason":         reason,
    }


def _parse_amendment(root) -> dict:
    """Amendment: CLM(보정 청구항) + REM(의견서) 파싱. 실패 시 raw_text fallback."""
    claims  = _section_text(root, "CLM")
    remarks = _section_text(root, "REM")
    raw_text = "" if (claims or remarks) else _all_text(root)
    return {
        "claims":   claims,
        "remarks":  remarks,
        "raw_text": raw_text,
    }


# ── 파일 단위 파서 ────────────────────────────────────────────────

def parse_xml_file(xml_path: Path) -> Optional[dict]:
    stem_parts = xml_path.stem.split("_", 2)
    if len(stem_parts) < 2:
        return None
    date, code = stem_parts[0], stem_parts[1]
    doc_id = stem_parts[2] if len(stem_parts) > 2 else ""

    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
    except ET.ParseError as e:
        logger.warning(f"XML 파싱 실패 {xml_path.name}: {e}")
        return None

    base = {
        "date":   date,
        "code":   code,
        "doc_id": doc_id,
        "label":  CODE_LABELS.get(code, code),
        "path":   str(xml_path),
        "fmt":    "xml",
    }

    if code in ("CTNF", "CTFR"):
        return {**base, **_parse_oa(root)}
    if code in ("NOA", "NACT"):
        return {**base, **_parse_noa(root)}
    if code.startswith("A"):
        return {**base, **_parse_amendment(root)}
    if code == "EXIN":
        return {**base, "raw_text": _all_text(root)}

    return None


# ── 타임라인 조합 ─────────────────────────────────────────────────

def build_timeline(app_number: str, file_dir: Optional[str] = None) -> list[dict]:
    if file_dir is None:
        file_dir = str(Path.cwd() / "file" / app_number)

    base_dir = Path(file_dir)
    entries: dict[str, dict] = {}

    for f in sorted(base_dir.glob("*.pdf")):
        stem_parts = f.stem.split("_", 2)
        if len(stem_parts) < 2:
            continue
        date, code = stem_parts[0], stem_parts[1]
        doc_id = stem_parts[2] if len(stem_parts) > 2 else ""
        key = f"{date}_{code}_{doc_id}"
        entries[key] = {
            "date": date, "code": code, "doc_id": doc_id,
            "label": CODE_LABELS.get(code, code),
            "path": str(f), "fmt": "pdf",
        }

    for f in sorted(base_dir.glob("*.xml")):
        stem_parts = f.stem.split("_", 2)
        if len(stem_parts) < 2:
            continue
        date, code = stem_parts[0], stem_parts[1]
        doc_id = stem_parts[2] if len(stem_parts) > 2 else ""
        key = f"{date}_{code}_{doc_id}"
        parsed = parse_xml_file(f)
        if parsed:
            entries[key] = parsed
        else:
            entries[key] = {
                "date": date, "code": code, "doc_id": doc_id,
                "label": CODE_LABELS.get(code, code),
                "path": str(f), "fmt": "xml",
            }

    return sorted(entries.values(), key=lambda x: x["date"])


# ── MD 렌더러 ─────────────────────────────────────────────────────

def render_md(app_number: str, timeline: list[dict]) -> str:
    lines: list[str] = []

    lines += [f"# 심사과정 분석 — {app_number}", ""]

    lines += ["## 타임라인", ""]
    lines += ["| 날짜 | 문서 | 형식 | 파일 |"]
    lines += ["|------|------|:----:|------|"]
    for e in timeline:
        lines.append(
            f"| {e['date']} | {e['label']} (`{e['code']}`) "
            f"| {e['fmt'].upper()} | `{Path(e['path']).name}` |"
        )
    lines += [""]

    oa_docs = [e for e in timeline if e["code"] in ("CTNF", "CTFR") and "rejections" in e]
    if oa_docs:
        lines += ["---", "## Office Action 상세", ""]
        for doc in oa_docs:
            oa_type = "Final Rejection" if doc.get("is_final") else "Non-Final Rejection"
            lines += [f"### {oa_type} — {doc['date']}", ""]
            if doc["rejections"]:
                for i, rej in enumerate(doc["rejections"], 1):
                    lines += [f"**거절 {i}**", "", rej, ""]
            elif doc.get("raw_text"):
                lines += [
                    "> ⚠️ FormParagraph 번호 불일치 (pre-AIA 출원 가능성). 전문을 직접 참조하세요.",
                    "",
                    "**전문 (raw)**", "",
                    doc["raw_text"], "",
                ]

    amendment_docs = [
        e for e in timeline
        if e["code"].startswith("A") and ("claims" in e or "remarks" in e)
    ]
    if amendment_docs:
        lines += ["---", "## Amendment 상세", ""]
        for doc in amendment_docs:
            lines += [f"### Amendment — {doc['date']} (`{doc['code']}`)", ""]
            if doc.get("claims"):
                lines += ["**보정 청구항**", "", doc["claims"], ""]
            if doc.get("remarks"):
                lines += ["**의견서 (Remarks)**", "", doc["remarks"], ""]
            if doc.get("raw_text") and not doc.get("claims") and not doc.get("remarks"):
                lines += ["**전문 (raw)**", "", doc["raw_text"], ""]

    exin_docs = [e for e in timeline if e["code"] == "EXIN" and "raw_text" in e]
    if exin_docs:
        lines += ["---", "## Examiner Interview 상세", ""]
        for doc in exin_docs:
            lines += [f"### {doc['date']}", "", doc.get("raw_text", ""), ""]

    noa_docs = [e for e in timeline if e["code"] in ("NOA", "NACT") and "allowed_claims" in e]
    if noa_docs:
        lines += ["---", "## Notice of Allowance 상세", ""]
        for doc in noa_docs:
            lines += [f"### {doc['date']}", ""]
            if doc.get("allowed_claims"):
                lines += ["**허여 청구항**", "", doc["allowed_claims"], ""]
            if doc.get("reason"):
                lines += ["**허여 이유 (Examiner's Statement)**", "", doc["reason"], ""]

    pdf_only = [
        e for e in timeline
        if e["fmt"] == "pdf"
        and "rejections" not in e
        and "allowed_claims" not in e
        and "claims" not in e
        and "raw_text" not in e
    ]
    if pdf_only:
        lines += ["---", "## PDF 전용 문서 (텍스트 추출 불가)", ""]
        lines += ["아래 파일은 이미지 PDF로 구성되어 자동 파싱이 불가합니다. AI 에이전트에 직접 전달하세요.", ""]
        lines += ["| 날짜 | 문서 | 파일 |"]
        lines += ["|------|------|------|"]
        for e in pdf_only:
            lines.append(f"| {e['date']} | {e['label']} (`{e['code']}`) | `{Path(e['path']).name}` |")
        lines += [""]

    return "\n".join(lines)


# ── JSON 렌더러 ───────────────────────────────────────────────────

def render_json(app_number: str, timeline: list[dict]) -> str:
    data = {
        "application_number": app_number,
        "timeline": [
            {k: v for k, v in e.items()}
            for e in timeline
        ],
    }
    return json.dumps(data, indent=2, ensure_ascii=False)


# ── 진입점 ────────────────────────────────────────────────────────

def extract(
    app_number: str,
    file_dir: Optional[str] = None,
    output_path: Optional[str] = None,
    fmt: str = "md",
) -> str:
    """다운로드된 파일을 파싱해 MD 또는 JSON 문자열을 반환하고, output_path가 지정되면 파일로 저장."""
    timeline = build_timeline(app_number, file_dir)
    content = render_json(app_number, timeline) if fmt == "json" else render_md(app_number, timeline)

    if output_path:
        Path(output_path).write_text(content, encoding="utf-8")
        logger.info(f"저장 완료: {output_path}")

    return content
