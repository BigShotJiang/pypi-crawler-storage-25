"""출원 문서 목록 필터링 및 일괄 다운로드 (XML 우선, PDF 폴백)."""

import io
import logging
import tarfile
from pathlib import Path
from typing import Optional

from oa_cli.uspto.client import make_api_request
from oa_cli.uspto.download import download_file, download_bytes

logger = logging.getLogger(__name__)

BASE_URL = "https://api.uspto.gov/api/v1/patent"
DOWNLOAD_BASE = "https://api.uspto.gov"

# 심사 과정 분석에 필요한 문서 코드 (정확 일치)
PROSECUTION_CODES_EXACT = {
    "CTNF",   # Non-Final Rejection
    "CTFR",   # Final Rejection
    "REM",    # Remarks
    "NACT",   # Notice of Allowance (구형식)
    "NOA",    # Notice of Allowance (신형식)
    "ABN",    # Abandonment
    "SRNT",   # Search Report (National)
    "SRFW",   # Search Report (Foreign)
    "N271",   # 271 Notice
    "EXIN",   # Examiner Interview
    "RCE",    # Request for Continued Examination (구형식)
    "RCEX",   # Request for Continued Examination (신형식)
    "CTAV",   # Advisory Action
    "892",    # Prior Art reference (Examiner)
    "1449",   # Information Disclosure Statement
    "IDS",    # Information Disclosure Statement
}

# 이 접두사로 시작하는 코드는 모두 포함 (Amendment 변형들)
# 실제 응답 예: A, A..., A.NE, A.NE.AFCP, A.NE.AFCP.D, A.PE, AMSB, ANE.I
PROSECUTION_CODE_PREFIXES = ("A",)


def normalize_app_number(raw: str) -> str:
    """출원번호 정규화 — 하이픈·슬래시·공백 제거."""
    return raw.replace("/", "").replace("-", "").replace(" ", "")



def fetch_document_list(app_number: str, api_key: str) -> list[dict]:
    """전체 문서 목록 조회 (서버사이드 필터 미사용 — 500 오류 유발)."""
    url = f"{BASE_URL}/applications/{app_number}/documents"
    data = make_api_request(url, api_key)
    return (
        data.get("documentBag")
        or data.get("patentDocumentFiles")
        or data.get("documents")
        or []
    )


MIME_PRIORITY = ["XML", "PDF"]  # MS_WORD 제외


def _is_prosecution_doc(code: str, allowed: set[str] | None) -> bool:
    if allowed is not None:
        return code in allowed
    if code in PROSECUTION_CODES_EXACT:
        return True
    return any(code.startswith(p) for p in PROSECUTION_CODE_PREFIXES)


def _best_option(doc: dict, app_number: str) -> tuple[str, str] | None:
    """우선순위(XML > PDF)에 따라 (url, ext) 반환."""
    options: dict[str, str] = {}
    for opt in doc.get("downloadOptionBag") or []:
        mime = (opt.get("mimeTypeIdentifier") or "").upper()
        url = opt.get("downloadUrl") or opt.get("url") or ""
        if mime in MIME_PRIORITY and url:
            options[mime] = url if url.startswith("http") else DOWNLOAD_BASE + url

    for mime in MIME_PRIORITY:
        if mime in options:
            ext = mime.lower()
            return options[mime], ext

    doc_id = doc.get("documentIdentifier")
    if doc_id:
        return f"{DOWNLOAD_BASE}/api/v1/download/applications/{app_number}/{doc_id}.pdf", "pdf"

    return None


def _pdf_fallback_url(doc: dict, app_number: str) -> Optional[str]:
    """PDF 다운로드 URL만 추출 (XML 실패 시 폴백용)."""
    for opt in doc.get("downloadOptionBag") or []:
        if (opt.get("mimeTypeIdentifier") or "").upper() == "PDF":
            url = opt.get("downloadUrl") or opt.get("url") or ""
            if url:
                return url if url.startswith("http") else DOWNLOAD_BASE + url
    doc_id = doc.get("documentIdentifier")
    if doc_id:
        return f"{DOWNLOAD_BASE}/api/v1/download/applications/{app_number}/{doc_id}.pdf"
    return None


def _save_xml_from_tar(raw: bytes, save_path: str):
    """tar 아카이브에서 첫 번째 .xml 파일을 꺼내 save_path에 저장."""
    with tarfile.open(fileobj=io.BytesIO(raw)) as tf:
        for member in tf.getmembers():
            if member.name.endswith(".xml"):
                f = tf.extractfile(member)
                if f:
                    Path(save_path).write_bytes(f.read())
                    return
    raise ValueError("tar 아카이브에 .xml 파일이 없습니다.")


def download_docs(
    app_number: str,
    api_key: str,
    doc_codes: Optional[list[str]] = None,
    output_dir: Optional[str] = None,
    force: bool = False,
) -> list[dict]:
    """
    심사 관련 문서를 XML 우선(없으면 PDF)으로 다운로드하고 메타데이터 목록을 반환.

    Returns:
        [{"code": str, "date": str, "doc_id": str, "fmt": str, "path": str, "skipped": bool}, ...]
    """
    allowed = set(doc_codes) if doc_codes else None
    if output_dir is None:
        output_dir = str(Path.cwd() / "file" / app_number)
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    all_docs = fetch_document_list(app_number, api_key)
    if not all_docs:
        logger.warning(f"{app_number}: 문서 없음")
        return []

    docs = [d for d in all_docs
            if _is_prosecution_doc(d.get("documentCode") or d.get("code") or "", allowed)]
    logger.info(f"전체 {len(all_docs)}개 중 심사 관련 {len(docs)}개")

    results = []
    for doc in docs:
        code = doc.get("documentCode") or doc.get("code") or "UNKNOWN"
        date = (doc.get("officialDate") or doc.get("mailDate") or "").split("T")[0]
        doc_id = doc.get("documentIdentifier") or doc.get("documentId") or ""

        option = _best_option(doc, app_number)
        if not option:
            logger.warning(f"  {code} ({date}): 다운로드 URL 없음")
            continue
        url, ext = option

        filename = f"{date}_{code}_{doc_id}.{ext}".replace(" ", "_")
        save_path = str(Path(output_dir) / filename)
        entry = {"code": code, "date": date, "doc_id": doc_id, "fmt": ext, "path": save_path, "skipped": False}

        if not force and Path(save_path).exists():
            entry["skipped"] = True
            results.append(entry)
            continue

        try:
            if ext == "xml":
                try:
                    raw = download_bytes(url, api_key)
                    _save_xml_from_tar(raw, save_path)
                except (ValueError, Exception) as xml_err:
                    logger.warning(f"  {code} ({date}) XML 실패({xml_err}), PDF로 폴백")
                    pdf_url = _pdf_fallback_url(doc, app_number)
                    if not pdf_url:
                        logger.error(f"  {code} ({date}) PDF 폴백 URL도 없음")
                        continue
                    save_path = save_path.removesuffix(".xml") + ".pdf"
                    entry["fmt"] = "pdf"
                    entry["path"] = save_path
                    download_file(pdf_url, api_key, save_path)
            else:
                download_file(url, api_key, save_path)
            results.append(entry)
        except Exception as e:
            logger.error(f"  {code} ({date}) 다운로드 실패: {e}")

    return results
