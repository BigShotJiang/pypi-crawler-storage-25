# odp-oa-cli

USPTO ODP(Open Data Portal) API를 통해 미국 특허 심사과정 문서를 다운로드하고, XML 파싱을 거쳐 구조화된 Markdown으로 변환하는 CLI 도구.

생성된 MD 파일을 Claude Code, Gemini CLI 등 AI 에이전트에게 전달하여 심사 전략 분석을 수행하는 워크플로우를 지원한다.

## 요구사항

- Python 3.13+
- [uv](https://docs.astral.sh/uv/)
- USPTO API 키 ([ODP 포털](https://developer.uspto.gov/)에서 발급)

## 설치

```bash
# pip
pip install uspto-oa-cli

# uv (글로벌 설치)
uv tool install uspto-oa-cli

# uv (프로젝트 의존성으로 추가)
uv add uspto-oa-cli

# 로컬 개발
uv sync
```

## API 키 설정

```bash
# 대화형 설정 (권장) — ~/.oa-cli.toml 에 저장
uspto-oa configure

# 현재 설정 확인
uspto-oa configure --show
```

또는 환경변수로 지정:

```bash
export USPTO_API_KEY=your_api_key_here
```

## 사용법

```bash
# 1. 문서 다운로드 (file/{app_num}/ 에 저장)
uspto-oa download 16330077

# 2. XML 파싱 → prosecution.md 생성
uspto-oa extract 16330077
# 결과: file/16330077/16330077_prosecution.md

# 특정 문서 코드만 다운로드
uspto-oa download 16330077 --doc-codes CTNF,CTFR,NOA

# 강제 재다운로드 (기존 파일 덮어쓰기)
uspto-oa download 16330077 --force

# 상세 로그
uspto-oa -v download 16330077

# 일회성 API 키 지정
uspto-oa download 16330077 --api-key YOUR_KEY
```

### 커맨드 옵션

**`uspto-oa download <application>`**

| 옵션 | 설명 |
|------|------|
| `--doc-codes CODES` | 쉼표 구분 문서 코드 (예: `CTNF,CTFR,NOA`). 생략 시 전체 수집 대상 |
| `--output-dir DIR` | 저장 경로 (기본: `file/{app_num}/`) |
| `--force` | 기존 파일도 재다운로드 |
| `--api-key TEXT` | API 키 (설정 파일·환경변수보다 우선) |

**`uspto-oa extract <application>`**

| 옵션 | 설명 |
|------|------|
| `--output-dir DIR` | 파일 디렉토리 (기본: `file/{app_num}/`) |

## 워크플로우

```
uspto-oa download {app_num}
    └─ file/{app_num}/ 에 XML / PDF 저장

uspto-oa extract {app_num}
    └─ file/{app_num}/{app_num}_prosecution.md 생성
         └─ AI 에이전트 (Claude Code / Gemini CLI)
              └─ 심사 전략 분석, 요약, 질의응답
```

## 수집 대상 문서 코드

| 코드 | 의미 |
|------|------|
| `CTNF` | Non-Final Office Action |
| `CTFR` | Final Office Action |
| `NOA` / `NACT` | Notice of Allowance |
| `REM` | Remarks (의견서) |
| `ABN` | Abandonment |
| `SRNT` / `SRFW` | Search Report |
| `EXIN` | Examiner Interview |
| `RCE` / `RCEX` | Request for Continued Examination |
| `CTAV` | Advisory Action |
| `892` / `1449` / `IDS` | Prior Art / IDS |
| `A*` | Amendment 계열 전체 |

## 생성 파일 구조

`file/{app_num}/{app_num}_prosecution.md`:

| 섹션 | 내용 |
|------|------|
| 타임라인 | 전체 문서 날짜순 표 (XML/PDF 형식 표시) |
| Office Action 상세 | CTNF/CTFR 거절 항목 전문 |
| Notice of Allowance 상세 | 허여 청구항 + Examiner's Statement |
| PDF 전용 문서 | Amendment 등 이미지 PDF 목록 (AI 에이전트 직접 전달용) |

## PyPI 배포

```bash
uv build
uv run twine upload dist/*
```
