from __future__ import annotations

import importlib
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

import tomllib


def _load_module(module_name: str, relative_path: str):
    module_path = Path(relative_path)
    importlib.invalidate_caches()
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


pipeline_editor = _load_module("agilab.pipeline_editor", "src/agilab/pipeline_editor.py")


class _State(dict):
    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError as exc:
            raise AttributeError(name) from exc

    def __setattr__(self, name, value):
        self[name] = value


def test_save_step_roundtrip_writes_toml_and_notebook(monkeypatch, tmp_path):
    fake_env = SimpleNamespace(home_abs=tmp_path, AGILAB_EXPORT_ABS=tmp_path, envars={"OPENAI_MODEL": "gpt-x"})
    fake_st = SimpleNamespace(
        session_state={"_experiment_last_save_skipped": False, "env": fake_env},
        error=lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(pipeline_editor, "_module_keys", lambda _module: ["flight_project"])
    monkeypatch.setattr(pipeline_editor, "_ensure_primary_module_key", lambda *_args, **_kwargs: None)

    steps_file = tmp_path / "lab_steps.toml"
    nsteps, entry = pipeline_editor.save_step(
        tmp_path / "flight_project",
        ["", "Describe step", "", "print('ok')"],
        current_step=0,
        nsteps=0,
        steps_file=steps_file,
        venv_map={0: str(tmp_path / "flight_project")},
        engine_map={0: "agi.run"},
    )

    stored = tomllib.loads(steps_file.read_text(encoding="utf-8"))
    notebook = json.loads(steps_file.with_suffix(".ipynb").read_text(encoding="utf-8"))

    assert nsteps == 1
    assert entry["Q"] == "Describe step"
    assert entry["M"] == "gpt-x"
    assert stored["flight_project"][0]["R"] == "agi.run"
    assert notebook["cells"][0]["source"] == ["print('ok')"]


def test_remove_step_reindexes_state_and_sequence(monkeypatch, tmp_path):
    steps_file = tmp_path / "lab_steps.toml"
    steps_file.write_text(
        """
[[flight_project]]
Q = "First"
C = "print(1)"
[[flight_project]]
Q = "Second"
C = "print(2)"
""".strip()
        + "\n",
        encoding="utf-8",
    )

    fake_env = SimpleNamespace(home_abs=tmp_path, AGILAB_EXPORT_ABS=tmp_path, envars={})
    fake_st = SimpleNamespace(
        session_state={
            "env": fake_env,
            "idx": [1, "", "", "", "", "", 2],
            "idx__details": {0: "d0", 1: "d1"},
            "idx__venv_map": {0: "/tmp/a", 1: "/tmp/b"},
            "idx__engine_map": {0: "runpy", 1: "agi.run"},
            "idx__run_sequence": [1, 0],
        },
        error=lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(pipeline_editor, "_bump_history_revision", lambda: None)
    monkeypatch.setattr(pipeline_editor, "_module_keys", lambda _module: ["flight_project"])
    monkeypatch.setattr(pipeline_editor, "_ensure_primary_module_key", lambda *_args, **_kwargs: None)

    remaining = pipeline_editor.remove_step(tmp_path / "flight_project", "0", steps_file, "idx")

    stored = tomllib.loads(steps_file.read_text(encoding="utf-8"))
    assert remaining == 1
    assert stored["flight_project"][0]["Q"] == "Second"
    assert fake_st.session_state["idx__details"] == {0: "d1"}
    assert fake_st.session_state["idx__venv_map"] == {0: "/tmp/b"}
    assert fake_st.session_state["idx__engine_map"] == {0: "agi.run"}
    assert fake_st.session_state["idx__run_sequence"] == [0]


def test_remove_step_out_of_range_preserves_state_and_reports_save_error(monkeypatch, tmp_path):
    steps_file = tmp_path / "lab_steps.toml"
    steps_file.write_text(
        "[[flight_project]]\nQ = 'First'\nC = 'print(1)'\n",
        encoding="utf-8",
    )

    errors: list[str] = []
    fake_st = SimpleNamespace(
        session_state={
            "idx": [3, "", "", "", "", "", 1],
            "idx__details": {0: "d0"},
            "idx__venv_map": {0: "/tmp/a"},
            "idx__engine_map": {0: "runpy"},
            "idx__run_sequence": [0, 4],
        },
        error=lambda message, *args, **kwargs: errors.append(message),
    )
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(pipeline_editor, "_bump_history_revision", lambda: None)
    monkeypatch.setattr(pipeline_editor, "_module_keys", lambda _module: ["flight_project"])
    monkeypatch.setattr(
        pipeline_editor,
        "tomli_w",
        SimpleNamespace(dump=lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("boom"))),
    )

    remaining = pipeline_editor.remove_step(tmp_path / "flight_project", "7", steps_file, "idx")

    assert remaining == 1
    assert fake_st.session_state["idx"][0] == 0
    assert fake_st.session_state["idx__venv_map"] == {0: "/tmp/a"}
    assert fake_st.session_state["idx__engine_map"] == {0: "runpy"}
    assert fake_st.session_state["idx__run_sequence"] == [0]
    assert errors == ["Failed to save steps file: boom"]


def test_notebook_to_toml_imports_code_cells(monkeypatch, tmp_path):
    fake_st = SimpleNamespace(error=lambda *args, **kwargs: None)
    monkeypatch.setattr(pipeline_editor, "st", fake_st)

    notebook = {
        "cells": [
            {"cell_type": "markdown", "source": ["ignore"]},
            {"cell_type": "code", "source": ["print('a')\n"]},
            {"cell_type": "code", "source": ["print('b')\n"]},
        ]
    }
    uploaded = SimpleNamespace(read=lambda: json.dumps(notebook).encode("utf-8"))

    count = pipeline_editor.notebook_to_toml(uploaded, "lab_steps.toml", tmp_path / "flight_project")

    stored = tomllib.loads((tmp_path / "flight_project" / "lab_steps.toml").read_text(encoding="utf-8"))
    assert count == 2
    assert stored["flight_project"][0]["C"] == "print('a')\n"
    assert stored["flight_project"][1]["C"] == "print('b')\n"


def test_capture_and_restore_pipeline_snapshot(monkeypatch, tmp_path):
    fake_st = SimpleNamespace(
        session_state={
            "idx__details": {0: "detail0", 1: "detail1", "bad": "skip"},
            "idx__venv_map": {0: str(tmp_path / "venv0"), 1: "", 9: "/skip"},
            "idx__engine_map": {0: "runpy", 1: "agi.run"},
            "idx__run_sequence": [1, 0, 99, "bad"],
            "idx": [1, "", "", "", "", "", 2],
            "lab_selected_venv": str(tmp_path / "venv0"),
            "lab_selected_engine": "agi.run",
            "idx__clear_q": True,
            "idx__force_blank_q": True,
            "idx__q_rev": 2,
            "idx_confirm_delete_all": True,
            "idx_sequence_widget": [1, 0],
        }
    )
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(pipeline_editor, "normalize_runtime_path", lambda value: str(value) if value else "")

    steps = [
        {"D": "d0", "Q": "q0", "M": "m0", "C": "c0", "E": str(tmp_path / "venv0"), "R": "runpy"},
        {"D": "d1", "Q": "q1", "M": "m1", "C": "c1", "E": str(tmp_path / "venv1"), "R": "agi.run"},
    ]
    snapshot = pipeline_editor._capture_pipeline_snapshot("idx", steps)

    writes = {}
    def _write_steps(module, steps_file, module_steps):
        writes["steps"] = module_steps
        return len(module_steps)

    monkeypatch.setattr(
        pipeline_editor,
        "_write_steps_for_module",
        _write_steps,
    )
    monkeypatch.setattr(pipeline_editor, "_persist_sequence_preferences", lambda *args, **kwargs: writes.setdefault("sequence", args[2]))
    monkeypatch.setattr(pipeline_editor, "_bump_history_revision", lambda: writes.setdefault("bumped", True))
    monkeypatch.setattr(pipeline_editor, "_is_valid_runtime_root", lambda path: path.endswith("venv0"))

    error = pipeline_editor._restore_pipeline_snapshot(
        tmp_path / "flight_project",
        tmp_path / "lab_steps.toml",
        "idx",
        "idx_sequence_widget",
        snapshot,
    )

    assert error is None
    assert fake_st.session_state["idx__details"] == {0: "detail0", 1: "detail1"}
    assert fake_st.session_state["idx__run_sequence"] == [1, 0]
    assert fake_st.session_state["lab_selected_venv"].endswith("venv0")
    assert fake_st.session_state["lab_selected_engine"] == "agi.run"
    assert fake_st.session_state["idx"][0] == 1
    assert fake_st.session_state["idx"][-1] == 2
    assert "idx_sequence_widget" not in fake_st.session_state
    assert writes["bumped"] is True


def test_capture_pipeline_snapshot_falls_back_to_default_sequence_and_active_step(monkeypatch, tmp_path):
    fake_st = SimpleNamespace(
        session_state={
            "idx__details": {"bad": "skip"},
            "idx__venv_map": {"bad": str(tmp_path / "venv")},
            "idx__engine_map": {"bad": "agi.run"},
            "idx__run_sequence": ["bad", 99],
            "idx": ["oops"],
            "lab_selected_venv": "",
            "lab_selected_engine": "",
        }
    )
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(pipeline_editor, "normalize_runtime_path", lambda value: str(value) if value else "")

    snapshot = pipeline_editor._capture_pipeline_snapshot(
        "idx",
        [{"D": "", "Q": "", "M": "", "C": "print(1)"}],
    )

    assert snapshot["details"] == {}
    assert snapshot["venv_map"] == {}
    assert snapshot["engine_map"] == {}
    assert snapshot["sequence"] == [0]
    assert snapshot["active_step"] == 0


def test_reset_pipeline_editor_state_clears_editor_widget_keys(monkeypatch):
    fake_st = SimpleNamespace(
        session_state={
            "demo_q_step_0": "q",
            "demo_code_step_0": "c",
            "demo_venv_0": "v",
            "demo_keep": "ok",
            "demoa": "drop",
        }
    )
    monkeypatch.setattr(pipeline_editor, "st", fake_st)

    pipeline_editor._reset_pipeline_editor_state("demo")

    assert fake_st.session_state == {"demo_keep": "ok"}


def test_get_steps_list_and_dict_handle_invalid_files_and_alias_keys(monkeypatch, tmp_path):
    steps_file = tmp_path / "lab_steps.toml"
    steps_file.write_text(
        "[[flight_project]]\nQ = 'first'\n"
        "[[flight]]\nQ = 'alias'\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(pipeline_editor, "_module_keys", lambda _module: ["flight_project", "flight"])

    steps = pipeline_editor.get_steps_list(tmp_path / "flight_project", steps_file)
    stored = pipeline_editor.get_steps_dict(tmp_path / "flight_project", steps_file)

    assert steps[0]["Q"] == "first"
    assert "flight" not in stored

    invalid_file = tmp_path / "broken.toml"
    invalid_file.write_text("[[flight_project]\n", encoding="utf-8")
    assert pipeline_editor.get_steps_list(tmp_path / "flight_project", invalid_file) == []


def test_convert_paths_to_strings_and_query_validation():
    converted = pipeline_editor.convert_paths_to_strings({"paths": [Path("/tmp/demo"), {"nested": Path("rel")}]})
    assert converted == {"paths": ["/tmp/demo", {"nested": "rel"}]}
    assert pipeline_editor.is_query_valid([0, "desc", "question"]) is True
    assert pipeline_editor.is_query_valid([0, "desc", ""]) is False
    assert pipeline_editor.is_query_valid("not-a-query") is False


def test_save_query_invalid_still_exports_dataframe(monkeypatch, tmp_path):
    calls = {"exported": 0, "saved": 0}
    fake_st = SimpleNamespace(session_state={})
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(pipeline_editor, "export_df", lambda: calls.__setitem__("exported", calls["exported"] + 1))
    monkeypatch.setattr(
        pipeline_editor,
        "save_step",
        lambda *_args, **_kwargs: calls.__setitem__("saved", calls["saved"] + 1),
    )

    pipeline_editor.save_query(tmp_path / "flight_project", [0, "desc", ""], tmp_path / "lab_steps.toml", "idx")

    assert calls == {"exported": 1, "saved": 0}


def test_force_persist_step_merges_existing_content(tmp_path):
    module_dir = tmp_path / "flight_project"
    steps_file = tmp_path / "lab_steps.toml"
    steps_file.write_text(
        "[[flight_project]]\nQ = 'first'\nC = 'print(1)'\n",
        encoding="utf-8",
    )

    with patch.object(pipeline_editor, "_module_keys", return_value=["flight_project"]):
        pipeline_editor._force_persist_step(
        module_dir,
        steps_file,
        0,
        {"D": "detail", "E": Path("/tmp/runtime")},
        )

    stored = tomllib.loads(steps_file.read_text(encoding="utf-8"))
    assert stored["flight_project"][0]["Q"] == "first"
    assert stored["flight_project"][0]["D"] == "detail"
    assert stored["flight_project"][0]["E"] == "/tmp/runtime"


def test_write_steps_for_module_normalizes_runtime_and_exports_notebook(monkeypatch, tmp_path):
    steps_file = tmp_path / "lab_steps.toml"
    notebook_calls: list[dict[str, object]] = []

    monkeypatch.setattr(pipeline_editor, "_module_keys", lambda _module: ["flight_project"])
    monkeypatch.setattr(
        pipeline_editor,
        "normalize_runtime_path",
        lambda value: f"normalized::{value}" if value else "",
    )
    monkeypatch.setattr(
        pipeline_editor,
        "toml_to_notebook",
        lambda steps, path: notebook_calls.append({"steps": steps, "path": path}),
    )

    count = pipeline_editor._write_steps_for_module(
        tmp_path / "flight_project",
        steps_file,
        [
            {"D": "demo", "Q": "q1", "M": "m1", "C": "print(1)", "E": tmp_path / "venv", "R": "agi.run"},
            {"D": "", "Q": "", "M": "", "C": ""},
        ],
    )

    stored = tomllib.loads(steps_file.read_text(encoding="utf-8"))
    assert count == 1
    assert stored["flight_project"] == [
        {
            "D": "demo",
            "Q": "q1",
            "M": "m1",
            "C": "print(1)",
            "E": f"normalized::{tmp_path / 'venv'}",
            "R": "agi.run",
        }
    ]
    assert notebook_calls == [{"steps": stored, "path": steps_file}]


def test_save_step_preserves_existing_runtime_and_extra_fields(monkeypatch, tmp_path):
    steps_file = tmp_path / "lab_steps.toml"
    steps_file.write_text(
        """
[[flight_project]]
Q = "first"
M = "model-a"
C = "print(1)"
E = "/tmp/runtime"
R = "agi.run"
LOCKED = true
""".strip()
        + "\n",
        encoding="utf-8",
    )

    fake_st = SimpleNamespace(session_state={"_experiment_last_save_skipped": False}, error=lambda *args, **kwargs: None)
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(pipeline_editor, "_module_keys", lambda _module: ["flight_project"])
    monkeypatch.setattr(pipeline_editor, "toml_to_notebook", lambda *_args, **_kwargs: None)

    nsteps, entry = pipeline_editor.save_step(
        tmp_path / "flight_project",
        ["detail", "updated question", "updated-model", "print(2)"],
        current_step=0,
        nsteps=1,
        steps_file=steps_file,
        extra_fields={"LOCKED": None, "SOURCE": "copied"},
    )

    stored = tomllib.loads(steps_file.read_text(encoding="utf-8"))
    assert nsteps == 1
    assert entry["E"] == "/tmp/runtime"
    assert entry["R"] == "agi.run"
    assert "LOCKED" not in entry
    assert entry["SOURCE"] == "copied"
    assert stored["flight_project"][0]["SOURCE"] == "copied"
    assert stored["flight_project"][0]["E"] == "/tmp/runtime"
    assert stored["flight_project"][0]["R"] == "agi.run"


def test_save_step_merges_alias_entries_and_reports_dump_failure(monkeypatch, tmp_path):
    steps_file = tmp_path / "lab_steps.toml"
    steps_file.write_text(
        """
[[flight]]
Q = "alias only"
C = "print('alias')"
[[flight]]
Q = "alias second"
C = "print('second')"
[[flight_project]]
Q = "short"
C = "print('short')"
""".strip()
        + "\n",
        encoding="utf-8",
    )

    errors: list[str] = []
    fake_st = SimpleNamespace(
        session_state={"_experiment_last_save_skipped": False},
        error=lambda message, *args, **kwargs: errors.append(message),
    )
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(pipeline_editor, "_module_keys", lambda _module: ["flight_project", "flight"])
    monkeypatch.setattr(
        pipeline_editor,
        "tomli_w",
        SimpleNamespace(dump=lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("save boom"))),
    )

    nsteps, entry = pipeline_editor.save_step(
        tmp_path / "flight_project",
        ["detail", "question", "model", "print(3)"],
        current_step=1,
        nsteps=2,
        steps_file=steps_file,
    )

    assert nsteps == 2
    assert entry["Q"] == "question"
    assert fake_st.session_state["_experiment_last_save_skipped"] is True
    assert errors == ["Failed to save steps file: save boom"]


def test_save_query_valid_uses_runtime_and_engine_maps(monkeypatch, tmp_path):
    fake_st = SimpleNamespace(
        session_state={
            "idx__venv_map": {0: "/tmp/runtime"},
            "idx__engine_map": {0: "agi.run"},
        }
    )
    calls: dict[str, object] = {}
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(
        pipeline_editor,
        "save_step",
        lambda module, query, current_step, nsteps, steps_file, venv_map=None, engine_map=None: (
            calls.setdefault("query", query),
            calls.setdefault("venv_map", venv_map),
            calls.setdefault("engine_map", engine_map),
            (4, {"Q": query[1]}),
        )[-1],
    )
    monkeypatch.setattr(pipeline_editor, "export_df", lambda: calls.setdefault("exported", True))
    monkeypatch.setattr(pipeline_editor, "_bump_history_revision", lambda: calls.setdefault("bumped", True))

    pipeline_editor.save_query(
        tmp_path / "flight_project",
        [0, "detail", "question", "model", "print(1)", 2],
        tmp_path / "lab_steps.toml",
        "idx",
    )

    assert calls["query"] == ["detail", "question", "model", "print(1)"]
    assert calls["venv_map"] == {0: "/tmp/runtime"}
    assert calls["engine_map"] == {0: "agi.run"}
    assert calls["bumped"] is True
    assert calls["exported"] is True


def test_restore_pipeline_snapshot_reports_write_failure(monkeypatch, tmp_path):
    fake_st = SimpleNamespace(session_state={"idx": [0, "", "", "", "", "", 0]})
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(
        pipeline_editor,
        "_write_steps_for_module",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("write boom")),
    )

    error = pipeline_editor._restore_pipeline_snapshot(
        tmp_path / "flight_project",
        tmp_path / "lab_steps.toml",
        "idx",
        "sequence_widget",
        {"steps": []},
    )

    assert error == "write boom"


def test_restore_pipeline_snapshot_resets_empty_state(monkeypatch, tmp_path):
    fake_st = SimpleNamespace(session_state={"idx": [4, "stale", "stale", "stale", "stale", "stale", 9]})
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(pipeline_editor, "_write_steps_for_module", lambda *_args, **_kwargs: 0)
    monkeypatch.setattr(pipeline_editor, "_persist_sequence_preferences", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(pipeline_editor, "_bump_history_revision", lambda: None)

    error = pipeline_editor._restore_pipeline_snapshot(
        tmp_path / "flight_project",
        tmp_path / "lab_steps.toml",
        "idx",
        "sequence_widget",
        {"steps": [], "sequence": []},
    )

    assert error is None
    assert fake_st.session_state["idx"] == [0, "", "", "", "", "", 0]
    assert fake_st.session_state["lab_selected_venv"] == ""
    assert fake_st.session_state["lab_selected_engine"] == "runpy"


def test_on_import_notebook_ignores_non_ipynb(monkeypatch, tmp_path):
    fake_st = SimpleNamespace(session_state={"upload": SimpleNamespace(type="text/plain")})
    monkeypatch.setattr(pipeline_editor, "st", fake_st)

    pipeline_editor.on_import_notebook("upload", tmp_path, tmp_path / "lab_steps.toml", "idx")

    assert "page_broken" not in fake_st.session_state


def test_on_import_notebook_imports_ipynb_and_marks_page_broken(monkeypatch, tmp_path):
    uploaded = SimpleNamespace(type="application/x-ipynb+json")
    fake_st = SimpleNamespace(session_state=_State({"upload": uploaded, "idx": [0, "", "", "", "", "", 0]}))
    calls: dict[str, object] = {}
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    def _fake_notebook_to_toml(uploaded_file, toml_name, module_dir):
        calls["args"] = (uploaded_file, toml_name, module_dir)
        return 3

    monkeypatch.setattr(pipeline_editor, "notebook_to_toml", _fake_notebook_to_toml)

    pipeline_editor.on_import_notebook("upload", tmp_path, tmp_path / "lab_steps.toml", "idx")

    assert calls["args"][0] is uploaded
    assert fake_st.session_state["idx"][-1] == 3
    assert fake_st.session_state["page_broken"] is True


def test_display_history_tab_filters_and_saves_editor_content(monkeypatch, tmp_path):
    steps_file = tmp_path / "lab_steps.toml"
    steps_file.write_text(
        "[[demo_project]]\nQ = 'kept'\nC = 'print(1)'\n",
        encoding="utf-8",
    )

    fake_st = SimpleNamespace(session_state={}, error=lambda *args, **kwargs: None)
    monkeypatch.setattr(pipeline_editor, "st", fake_st)
    monkeypatch.setattr(pipeline_editor, "get_custom_buttons", lambda: [])
    monkeypatch.setattr(pipeline_editor, "get_info_bar", lambda: {})
    monkeypatch.setattr(pipeline_editor, "get_css_text", lambda: "")
    monkeypatch.setattr(
        pipeline_editor,
        "code_editor",
        lambda *_args, **_kwargs: {
            "type": "save",
            "text": json.dumps(
                {
                    "demo_project": [
                        {"Q": "visible", "C": "print(2)"},
                        {"Q": "", "C": ""},
                    ]
                }
            ),
        },
    )
    revisions: list[bool] = []
    monkeypatch.setattr(pipeline_editor, "_bump_history_revision", lambda: revisions.append(True))

    pipeline_editor.display_history_tab(steps_file, tmp_path / "demo_project")

    stored = tomllib.loads(steps_file.read_text(encoding="utf-8"))
    assert stored["demo_project"] == [{"Q": "visible", "C": "print(2)"}]
    assert revisions == [True]


def test_toml_and_notebook_exports_report_errors(monkeypatch, tmp_path):
    errors: list[str] = []
    fake_st = SimpleNamespace(session_state={}, error=lambda message, *args, **kwargs: errors.append(message))
    monkeypatch.setattr(pipeline_editor, "st", fake_st)

    monkeypatch.setattr(
        pipeline_editor.json,
        "dump",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("nb boom")),
    )
    pipeline_editor.toml_to_notebook({"demo_project": [{"C": "print(1)"}]}, tmp_path / "lab_steps.toml")

    uploaded = SimpleNamespace(
        read=lambda: json.dumps({"cells": [{"cell_type": "code", "source": ["print(2)"]}]}).encode("utf-8")
    )
    monkeypatch.setattr(
        pipeline_editor,
        "tomli_w",
        SimpleNamespace(dump=lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("toml boom"))),
    )
    count = pipeline_editor.notebook_to_toml(uploaded, "lab_steps.toml", tmp_path / "demo_project")

    assert count == 1
    assert errors == [
        "Failed to save notebook: nb boom",
        "Failed to save TOML file: toml boom",
    ]
