# Large Letters

This module allows you to easily generate large text for use in python. After importing, run print(largeLetters.gen("hello world!"))