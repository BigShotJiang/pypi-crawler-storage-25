"""Rubrik policy enforcement for AI agent frameworks.

Core client:
    from rubrik_policy import RubrikPolicyClient, ToolCall, PolicyResult

ADK adapter (requires `pip install rubrik-policy-plugin[adk]`):
    from rubrik_policy.adk import RubrikPolicyPlugin

Auto-instrumentation:
    from rubrik_policy.auto_instrument import auto_instrument
"""

from rubrik_policy.client import PolicyResult, RubrikPolicyClient, ToolCall

__all__ = ["RubrikPolicyClient", "ToolCall", "PolicyResult"]
