class OneLakeError(Exception):
    """Base exception for the onelake library."""


class ResolutionError(OneLakeError):
    """Raised when workspace/lakehouse resolution fails."""


class TableIdentifierError(OneLakeError):
    """Raised when a table identifier is malformed."""


class SparkRequiredError(OneLakeError):
    """Raised when Spark is required but unavailable."""
