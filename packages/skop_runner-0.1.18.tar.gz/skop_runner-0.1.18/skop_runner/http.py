"""
Centralised TLS configuration for outbound connections to Skop infrastructure.

WHY THIS MODULE EXISTS

The runner makes outbound HTTPS / WSS calls in several places:

    - auth.py        — registration + token validation
    - client.py      — heartbeat (httpx) + relay WS (websockets)
    - log_shipper.py — local-runner log shipping

httpx happens to use `certifi` for TLS verification by default, so any path
built on httpx works on python.org Python without the user having run
`Install Certificates.command`. The `websockets` library has no such default
— it falls back to the system trust store, which is empty on python.org
Python until that script is run. Jessica Archibald hit this on 2026-05-05:
heartbeat (httpx) succeeded, relay WS (websockets) silently failed for
~17 minutes before we identified it.

The asymmetry is the real bug, not any one missing line. As long as new
code can casually pick a non-httpx client (urllib3, requests, raw stdlib
ssl, websockets, websocket-client, ...) it can silently reintroduce the
same failure mode.

Every outbound call to Skop infrastructure should go through one of these
two factories. New paths inherit correct TLS behaviour by construction,
not by accident.
"""

from __future__ import annotations

import ssl
import certifi
import httpx


def make_ssl_context() -> ssl.SSLContext:
    """SSL context backed by certifi's CA bundle.

    Use for libraries that don't pick up certifi automatically — most
    notably the `websockets` package, which falls back to the system
    trust store and breaks on python.org Python until the user runs
    `Install Certificates.command`.
    """
    return ssl.create_default_context(cafile=certifi.where())


def make_http_client(timeout: float = 30.0) -> httpx.AsyncClient:
    """httpx AsyncClient pinned to certifi's CA bundle.

    httpx already does this by default, but stating it explicitly here
    makes the intent visible at the construction site and means a future
    change to httpx defaults can't silently regress us.
    """
    return httpx.AsyncClient(timeout=timeout, verify=certifi.where())
