"""Skop Runner - Local execution client for Skop Labs."""

__version__ = "0.1.18"
