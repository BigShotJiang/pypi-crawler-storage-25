"""AdminStore — cross-org query layer for super-admin operations."""

from __future__ import annotations

import asyncio
import contextlib
import logging
from collections.abc import Awaitable, Callable

import asyncpg

from .models import BlockedOrg

logger = logging.getLogger(__name__)


# Advisory lock key serializing every `delete_user_atomic` call that
# requests the in-transaction sole-admin recheck. Per-row `FOR UPDATE`
# isn't enough — two concurrent admin self-deletes lock different rows
# and the plain SELECT COUNT(*) recheck sees the other admin as still
# active in both transactions. pg_advisory_xact_lock blocks the second
# txn until the first commits, so the second's COUNT(*) sees the post-
# delete state and SoleAdminBlockedError fires.
#
# Postgres bigint is signed 64-bit, so any fixed value within that range
# works. Value derived from the bytes of "CN.ADMIN" to make the lock
# greppable in pg_locks (~ 4.86e18, well within signed bigint range).
_SOLE_ADMIN_LOCK_KEY: int = int.from_bytes(b"CN.ADMIN", "big")


class SoleAdminBlockedError(Exception):
    """Raised by ``delete_user_atomic`` when the in-transaction sole-admin
    recheck (``block_if_sole_admin=True``) finds the user is the last
    remaining admin in the deployment.

    Carries a typed ``list[BlockedOrg]`` matching the gate's return shape
    (``AdminStore.check_sole_admin_orgs``), so the caller can hand it
    straight to the response model without re-validating.
    """

    def __init__(self, blocked_orgs: list[BlockedOrg]) -> None:
        super().__init__("Cannot delete the last remaining admin")
        self.blocked_orgs = blocked_orgs


class AdminStore:
    """Data access layer for cross-org super-admin queries."""

    def __init__(self, pool: asyncpg.Pool, *, provider=None, cache=None) -> None:
        self._pool = pool
        self._provider = provider
        self._cache = cache

    # ------------------------------------------------------------------
    # Organisations
    # ------------------------------------------------------------------

    async def list_orgs(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        search: str | None = None,
    ) -> list[dict]:
        """Return all GitHub installations (orgs)."""
        conditions: list[str] = []
        params: list = []

        if search:
            params.append(f"%{search}%")
            conditions.append(f"org_login ILIKE ${len(params)}")

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""

        params.append(limit)
        limit_ph = f"${len(params)}"
        params.append(offset)
        offset_ph = f"${len(params)}"

        sql = f"""
            SELECT DISTINCT ON (org_login)
                org_login AS login,
                installation_id::text AS installation_id,
                installed_at AS created_at,
                status,
                repos_count,
                oidc_org_id
            FROM gh_installations
            {where}
            ORDER BY org_login, installed_at DESC
        """
        # DISTINCT ON requires the ORDER BY to start with org_login, so we
        # wrap in a subquery for final ordering + pagination.
        sql = f"""
            SELECT * FROM ({sql}) AS deduped
            ORDER BY created_at DESC
            LIMIT {limit_ph}
            OFFSET {offset_ph}
        """

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        results = [dict(r) for r in rows]

        # Enrich with Auth0 org display_name if provider is configured
        if self._provider is not None:
            cache_key = "auth0:orgs"
            auth0_orgs: list[dict] = []
            if self._cache is not None:
                auth0_orgs = self._cache.get(cache_key) or []
            if not auth0_orgs:
                try:
                    auth0_orgs = await self._provider.list_organizations()
                    if self._cache is not None and auth0_orgs:
                        self._cache.set_with_ttl(cache_key, auth0_orgs, 3600)
                except Exception:
                    logger.warning("Auth0 list_organizations failed — skipping enrichment")
            # Build a lookup map: auth0 org name -> display_name
            auth0_map = {o.get("name", ""): o for o in auth0_orgs}
            for record in results:
                a0 = auth0_map.get(record.get("login", ""), {})
                record["display_name"] = a0.get("display_name", "")
                # Backfill oidc_org_id from Auth0 if the DB column is empty
                if not record.get("oidc_org_id") and a0.get("id"):
                    record["oidc_org_id"] = a0["id"]

            # Fetch member counts concurrently (semaphore avoids Auth0 rate limits)
            sem = asyncio.Semaphore(5)

            async def _fetch_count(rec: dict) -> None:
                oidc_id = rec.get("oidc_org_id")
                if not oidc_id:
                    rec["member_count"] = None
                    return
                ck = f"auth0:org_members:{oidc_id}"
                members: list[dict] | None = None
                if self._cache is not None:
                    members = self._cache.get(ck)
                if members is None:
                    async with sem:
                        try:
                            members = await self._provider.get_org_members(oidc_id)
                            if self._cache is not None and members is not None:
                                self._cache.set_with_ttl(ck, members, 600)
                        except Exception:
                            logger.warning(
                                "Auth0 get_org_members failed for %s — skipping",
                                oidc_id,
                            )
                rec["member_count"] = len(members) if members is not None else None

            await asyncio.gather(*[_fetch_count(r) for r in results])

        return results

    async def get_org(self, org: str) -> dict | None:
        """Return a single org by login, or None if not found."""
        sql = """
            SELECT
                gi.org_login AS login,
                gi.installation_id::text AS installation_id,
                gi.installed_at AS created_at,
                gi.status,
                gi.repos_count,
                gi.oidc_org_id,
                om.primary_contact_email,
                om.primary_contact_name,
                om.support_notes
            FROM gh_installations gi
            LEFT JOIN organizations_meta om ON om.org_login = gi.org_login
            WHERE gi.org_login = $1
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, org)
        if row is None:
            return None
        result = dict(row)

        # Enrich with Auth0 member list if provider is configured
        if self._provider is not None:
            oidc_org_id = result.get("oidc_org_id", "")
            if oidc_org_id:
                cache_key = f"auth0:org_members:{oidc_org_id}"
                members: list[dict] = []
                if self._cache is not None:
                    members = self._cache.get(cache_key) or []
                if not members:
                    try:
                        members = await self._provider.get_org_members(oidc_org_id)
                        if self._cache is not None and members:
                            self._cache.set_with_ttl(cache_key, members, 600)
                    except Exception:
                        logger.warning(
                            "Auth0 get_org_members failed for %s — skipping", oidc_org_id
                        )
                result["members"] = members
            else:
                result["members"] = []

            # Also enrich display_name from cached org list
            try:
                cache_key = "auth0:orgs"
                auth0_orgs: list[dict] = []
                if self._cache is not None:
                    auth0_orgs = self._cache.get(cache_key) or []
                if not auth0_orgs:
                    auth0_orgs = await self._provider.list_organizations()
                    if self._cache is not None and auth0_orgs:
                        self._cache.set_with_ttl(cache_key, auth0_orgs, 3600)
                auth0_map = {o.get("name", ""): o for o in auth0_orgs}
                a0 = auth0_map.get(result.get("login", ""), {})
                result["display_name"] = a0.get("display_name", "")
            except Exception:
                logger.warning("Auth0 org enrichment failed for %s — skipping", org)
                result.setdefault("display_name", "")
                result["_auth0_enriched"] = False

        return result

    # ------------------------------------------------------------------
    # Users
    # ------------------------------------------------------------------

    async def list_users(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        org: str | None = None,
        role: str | None = None,
        search: str | None = None,
    ) -> list[dict]:
        """Return users with optional filters.

        Note: the users table has oidc_sub, email, name, picture, role,
        created_at, last_login_at. There is no org_login column on users —
        org association is handled through sessions.
        """
        conditions: list[str] = []
        params: list = []

        if role is not None:
            params.append(role)
            conditions.append(f"role = ${len(params)}")
        if search is not None:
            params.append(f"%{search}%")
            conditions.append(f"(email ILIKE ${len(params)} OR name ILIKE ${len(params)})")

        # org filter is not supported — users table has no org_login column

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""

        params.append(limit)
        limit_ph = f"${len(params)}"
        params.append(offset)
        offset_ph = f"${len(params)}"

        sql = f"""
            SELECT id, oidc_sub, email, name, role, status, created_at, last_login_at
            FROM users
            {where}
            ORDER BY last_login_at DESC NULLS LAST
            LIMIT {limit_ph}
            OFFSET {offset_ph}
        """

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        results = [
            {
                "id": r["id"],
                "oidc_sub": r["oidc_sub"],
                "login": r["name"] or r["email"],
                "email": r["email"],
                "role": r["role"],
                "status": r.get("status", "active"),
                "org_login": "",
                "created_at": r["created_at"],
                "last_login_at": r["last_login_at"],
            }
            for r in rows
        ]

        # Enrich with Auth0 user data if provider is configured
        if self._provider is not None:
            for record in results:
                sub = record.get("oidc_sub", "")
                if not sub:
                    continue
                cache_key = f"auth0:users:{sub}"
                a0_user: dict | None = None
                if self._cache is not None:
                    a0_user = self._cache.get(cache_key)
                if a0_user is None:
                    try:
                        a0_user = await self._provider.get_user(sub)
                        if self._cache is not None and a0_user:
                            self._cache.set_with_ttl(cache_key, a0_user, 600)
                    except Exception:
                        logger.warning("Auth0 get_user failed for %s — skipping", sub)
                if a0_user:
                    record["last_login"] = a0_user.get("last_login")
                    record["login_count"] = a0_user.get("logins_count")
                    record["email_verified"] = a0_user.get("email_verified")
                    record["picture"] = a0_user.get("picture")
                    record["identities"] = a0_user.get("identities")

        return results

    async def get_user(self, user_id: int) -> dict | None:
        """Return a single user by id, or None if not found."""
        sql = """
            SELECT id, oidc_sub, email, name, role, status, created_at, last_login_at
            FROM users
            WHERE id = $1
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, user_id)
        if row is None:
            return None
        result = {
            "id": row["id"],
            "oidc_sub": row["oidc_sub"],
            "login": row["name"] or row["email"],
            "email": row["email"],
            "role": row["role"],
            "status": row.get("status", "active"),
            "org_login": "",
            "created_at": row["created_at"],
            "last_login_at": row["last_login_at"],
        }

        # Enrich with full Auth0 profile if provider is configured
        if self._provider is not None:
            sub = result.get("oidc_sub", "")
            if sub:
                cache_key = f"auth0:users:{sub}"
                a0_user: dict | None = None
                if self._cache is not None:
                    a0_user = self._cache.get(cache_key)
                if a0_user is None:
                    try:
                        a0_user = await self._provider.get_user(sub)
                        if self._cache is not None and a0_user:
                            self._cache.set_with_ttl(cache_key, a0_user, 600)
                    except Exception:
                        logger.warning("Auth0 get_user failed for %s — skipping", sub)
                if a0_user:
                    result["last_login"] = a0_user.get("last_login")
                    result["login_count"] = a0_user.get("logins_count")
                    result["email_verified"] = a0_user.get("email_verified")
                    result["identities"] = a0_user.get("identities")
                    result["picture"] = a0_user.get("picture")
                    result["app_metadata"] = a0_user.get("app_metadata")

        return result

    async def update_user_role(self, user_id: int, new_role: str) -> dict | None:
        """Update a user's role, returning the updated record."""
        sql = """
            UPDATE users
            SET role = $1
            WHERE id = $2
            RETURNING id, oidc_sub, email, name, role, created_at, last_login_at
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, new_role, user_id)
        if row is None:
            return None
        return {
            "id": row["id"],
            "login": row["name"] or row["email"],
            "email": row["email"],
            "role": row["role"],
            "org_login": "",
            "created_at": row["created_at"],
        }

    async def deactivate_user(self, user_id: int) -> dict | None:
        """Set user status to deactivated.  Returns updated record or None.

        Guards against deactivating super_admin at the SQL level (atomic with
        the status update), closing the TOCTOU window between the route-level
        role check and this update.
        """
        sql = """
            UPDATE users
            SET status = 'deactivated'
            WHERE id = $1 AND status = 'active' AND role != 'super_admin'
            RETURNING id, oidc_sub, email, name, role, status, created_at, last_login_at
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, user_id)
        if row is None:
            return None
        return {
            "id": row["id"],
            "login": row["name"] or row["email"],
            "email": row["email"],
            "role": row["role"],
            "status": row["status"],
            "org_login": "",
            "created_at": row["created_at"],
        }

    async def reactivate_user(self, user_id: int) -> dict | None:
        """Set user status back to active.  Returns updated record or None."""
        sql = """
            UPDATE users
            SET status = 'active'
            WHERE id = $1 AND status = 'deactivated'
            RETURNING id, oidc_sub, email, name, role, status, created_at, last_login_at
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, user_id)
        if row is None:
            return None
        return {
            "id": row["id"],
            "login": row["name"] or row["email"],
            "email": row["email"],
            "role": row["role"],
            "status": row["status"],
            "org_login": "",
            "created_at": row["created_at"],
        }

    async def _check_sole_admin_on_conn(self, conn, user_id: int) -> list[BlockedOrg]:
        """Connection-bound implementation of ``check_sole_admin_orgs``.

        Extracted so the same query can run either against a freshly
        acquired connection (the public helper, for the pre-delete UI gate)
        or inside an existing transaction (the in-transaction recheck in
        ``delete_user_atomic``, to close the TOCTOU race between the gate
        and the delete).

        Callers using the in-transaction form must already hold a
        ``FOR UPDATE`` lock on the target user row — otherwise the recheck
        is no stronger than the public helper.
        """
        own_role = await conn.fetchval(
            "SELECT role FROM users WHERE id = $1",
            user_id,
        )
        if own_role not in ("admin", "super_admin"):
            return []

        other_admin_count = await conn.fetchval(
            """
            SELECT COUNT(*)
            FROM users
            WHERE id != $1
              AND status = 'active'
              AND role IN ('admin', 'super_admin')
            """,
            user_id,
        )
        if other_admin_count and other_admin_count > 0:
            return []

        # User is an admin and no other admins remain — block the delete.
        # See `check_sole_admin_orgs` docstring for the single-tenant
        # assumption that drives the empty `org_login` here.
        return [
            BlockedOrg(
                org_login="",
                reason=(
                    "You are the only active admin in this deployment. "
                    "Promote another user to admin before deleting your account."
                ),
            )
        ]

    async def check_sole_admin_orgs(self, user_id: int) -> list[BlockedOrg]:
        """Return orgs where ``user_id`` is the only remaining admin.

        Used as the safety gate for self-serve account delete (§8.2). The
        result is the UI's pre-delete signal; it is **not** a sufficient
        safety check by itself — two concurrent admin self-deletes could
        both pass this gate and both commit. ``delete_user_atomic`` re-runs
        the same check inside its transaction when
        ``block_if_sole_admin=True``; callers performing a delete should
        always set that flag in addition to surfacing this pre-check.

        # TODO(multi-tenant): today Canon runs single-tenant — the ``users``
        # table holds the whole org's admin set and there is at most one
        # logical org per deployment, so we return a single blocker with an
        # empty ``org_login``. When per-(user, org) membership lands, this
        # helper will query the auth provider's organization API and check
        # admin-role membership per org; the list return shape is
        # forward-compatible.
        """
        async with self._pool.acquire() as conn:
            return await self._check_sole_admin_on_conn(conn, user_id)

    async def delete_user_atomic(
        self,
        user_id: int,
        *,
        auth0_delete: Callable[[str], Awaitable[None]] | None = None,
        block_if_sole_admin: bool = False,
    ) -> dict | None:
        """Hard-delete a user from Canon and then Auth0.

        Order of operations:

        1. (if ``block_if_sole_admin``) Acquire a transaction-scoped
           Postgres advisory lock so all concurrent admin-self-delete
           transactions serialize on the same key. Per-row ``FOR UPDATE``
           is insufficient — two concurrent deletes lock different rows
           and the sole-admin ``SELECT COUNT(*)`` sees the other admin as
           still active in both transactions, letting both commit and
           leaving zero admins. The advisory lock forces strict ordering
           so the second transaction's count reflects the first's delete.
           Lock auto-releases at txn end (commit or rollback).
        2. SELECT the full user row inside the transaction so we have a
           snapshot for the audit trail. ``FOR UPDATE`` protects against
           concurrent direct modification of this user's row (e.g. an
           admin demote during self-delete).
        3. (if ``block_if_sole_admin``) Re-run the sole-admin count and
           raise :class:`SoleAdminBlockedError` if the user is the last
           admin. The advisory lock from step 1 guarantees this count is
           consistent with any concurrent admin delete.
        4. DELETE FROM users (cascades to sessions and api_keys via ON
           DELETE CASCADE; audit_events.actor_id is set to NULL by the
           0008 migration)
        5. COMMIT — Canon no longer holds the data (GDPR-safe), and the
           advisory lock auto-releases so the next queued txn unblocks.
        6. Call ``auth0_delete`` with the user's oidc_sub.  If this
           fails the caller receives the exception; the Canon deletion
           is already committed.  A retry will succeed in Auth0 (it
           treats 404 as success).

        Returns the snapshot dict on success or None if the user wasn't
        found. The snapshot is the caller's only handle on the deleted
        identity once this returns.

        Note: admin-route deletes that don't pass ``block_if_sole_admin``
        do not acquire the advisory lock. This is intentional — the admin
        operator is explicitly authorizing the delete and doesn't need
        the sole-admin guard. A super-admin who manually deletes the
        last admin via the admin route gets exactly the outcome they
        asked for.
        """
        async with self._pool.acquire() as conn, conn.transaction():
            if block_if_sole_admin:
                # Must run before any other query in the transaction so
                # the lock orders the entire critical section, including
                # the FOR UPDATE that follows.
                await conn.execute("SELECT pg_advisory_xact_lock($1)", _SOLE_ADMIN_LOCK_KEY)

            row = await conn.fetchrow(
                """
                SELECT id, oidc_sub, email, name, role, status,
                       created_at, last_login_at
                FROM users
                WHERE id = $1
                FOR UPDATE
                """,
                user_id,
            )
            if row is None:
                return None
            snapshot = dict(row)

            if block_if_sole_admin:
                blocked = await self._check_sole_admin_on_conn(conn, user_id)
                if blocked:
                    # Abort the transaction by raising; the FOR UPDATE row
                    # lock is released without DELETE having run.
                    raise SoleAdminBlockedError(blocked)

            deleted = await conn.execute("DELETE FROM users WHERE id = $1", user_id)
            if deleted != "DELETE 1":
                # Concurrent delete — abort the transaction
                return None

        # Auth0 deletion runs after the DB commit so the connection and
        # row lock are not held during the network round-trip.
        if auth0_delete is not None and snapshot.get("oidc_sub"):
            await auth0_delete(snapshot["oidc_sub"])

        return snapshot

    async def suspend_org(self, org: str) -> dict | None:
        """Suspend an org.  Returns updated record or None."""
        sql = """
            UPDATE gh_installations
            SET status = 'suspended'
            WHERE org_login = $1 AND status = 'active'
            RETURNING installation_id, org_login, status, installed_at, repos_count
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, org)
        if row is None:
            return None
        return dict(row)

    async def reactivate_org(self, org: str) -> dict | None:
        """Reactivate a suspended org.  Returns updated record or None."""
        sql = """
            UPDATE gh_installations
            SET status = 'active'
            WHERE org_login = $1 AND status = 'suspended'
            RETURNING installation_id, org_login, status, installed_at, repos_count
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, org)
        if row is None:
            return None
        return dict(row)

    async def get_org_metadata(self, org: str) -> dict:
        """Return organizations_meta row for an org, or empty dict if none."""
        sql = """
            SELECT primary_contact_email, primary_contact_name, support_notes,
                   updated_at, updated_by_sub
            FROM organizations_meta
            WHERE org_login = $1
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, org)
        return dict(row) if row is not None else {}

    async def update_org_metadata(
        self,
        org: str,
        *,
        primary_contact_email: str | None = None,
        primary_contact_name: str | None = None,
        support_notes: str | None = None,
        updated_by_sub: str | None = None,
    ) -> dict:
        """Upsert organizations_meta. None fields are left unchanged via COALESCE.

        Returns the post-update row. Callers that want to clear a field should
        pass an empty string; only a true ``None`` is treated as "no change".
        """
        sql = """
            INSERT INTO organizations_meta (
                org_login, primary_contact_email, primary_contact_name,
                support_notes, updated_at, updated_by_sub
            )
            VALUES ($1, $2, $3, $4, now(), $5)
            ON CONFLICT (org_login) DO UPDATE SET
                primary_contact_email = COALESCE($2, organizations_meta.primary_contact_email),
                primary_contact_name  = COALESCE($3, organizations_meta.primary_contact_name),
                support_notes         = COALESCE($4, organizations_meta.support_notes),
                updated_at            = now(),
                updated_by_sub        = $5
            RETURNING primary_contact_email, primary_contact_name, support_notes,
                      updated_at, updated_by_sub
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                sql,
                org,
                primary_contact_email,
                primary_contact_name,
                support_notes,
                updated_by_sub,
            )
        return dict(row) if row is not None else {}

    # ------------------------------------------------------------------
    # Aggregate stats
    # ------------------------------------------------------------------

    async def get_kpis(self) -> dict:
        """Return platform-wide KPI aggregates."""
        async with self._pool.acquire() as conn:
            org_count = await conn.fetchval(
                "SELECT COUNT(DISTINCT org_login) FROM gh_installations"
            )
            user_count = await conn.fetchval("SELECT COUNT(*) FROM users")
            # spec_count and coverage depend on tables that may not exist in all environments
            spec_count = 0
            avg_coverage = 0.0
            with contextlib.suppress(Exception):
                spec_count = (
                    await conn.fetchval("""
                        SELECT COALESCE(SUM(latest.specs_indexed), 0) FROM (
                            SELECT DISTINCT ON (installation_id, repo)
                                specs_indexed
                            FROM index_jobs
                            WHERE status = 'completed'
                            ORDER BY installation_id, repo, completed_at DESC
                        ) latest
                    """)
                    or 0
                )
            with contextlib.suppress(Exception):
                avg_coverage = (
                    await conn.fetchval("""
                    SELECT COALESCE(AVG(latest.coverage_pct), 0.0) FROM (
                        SELECT DISTINCT ON (org, repo)
                            CASE WHEN total_ac > 0
                                 THEN done_ac::float / total_ac * 100
                                 ELSE 0.0
                            END AS coverage_pct
                        FROM coverage_snapshots
                        ORDER BY org, repo, snapshot_date DESC
                    ) latest
                """)
                    or 0.0
                )
        return {
            "org_count": int(org_count or 0),
            "user_count": int(user_count or 0),
            "spec_count": int(spec_count),
            "avg_coverage_pct": float(avg_coverage),
        }

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    async def get_health_summary(self) -> list[dict]:
        """Return a list of subsystem health check results."""
        results: list[dict] = []

        async with self._pool.acquire() as conn:
            # Indexing: check for recent failed index jobs
            try:
                count = await conn.fetchval(
                    """
                    SELECT COUNT(*)
                    FROM index_jobs
                    WHERE status = 'failed'
                      AND started_at > now() - INTERVAL '24 hours'
                    """
                )
                results.append(
                    {
                        "name": "indexing",
                        "healthy": (count or 0) == 0,
                        "detail": f"{count} failure(s) in last 24h"
                        if count
                        else "No failures in last 24h",
                    }
                )
            except Exception as exc:
                logger.warning("Health check failed for indexing: %s", exc)
                results.append({"name": "indexing", "healthy": False, "detail": str(exc)})

            # Database: simple connectivity check
            try:
                await conn.fetchval("SELECT 1")
                results.append({"name": "database", "healthy": True, "detail": "Connection OK"})
            except Exception as exc:
                logger.warning("Health check failed for database: %s", exc)
                results.append({"name": "database", "healthy": False, "detail": str(exc)})

            # Search: check for recently completed index jobs
            try:
                count = await conn.fetchval(
                    """
                    SELECT COUNT(*)
                    FROM index_jobs
                    WHERE status = 'completed'
                      AND completed_at > now() - INTERVAL '24 hours'
                    """
                )
                results.append(
                    {
                        "name": "search",
                        "healthy": True,
                        "detail": f"{count or 0} job(s) completed in last 24h",
                    }
                )
            except Exception as exc:
                logger.warning("Health check failed for search: %s", exc)
                results.append({"name": "search", "healthy": False, "detail": str(exc)})

            # Cron jobs: check for recent coverage snapshots
            try:
                count = await conn.fetchval(
                    """
                    SELECT COUNT(*)
                    FROM coverage_snapshots
                    WHERE created_at > now() - INTERVAL '48 hours'
                    """
                )
                results.append(
                    {
                        "name": "cron",
                        "healthy": True,
                        "detail": f"{count or 0} snapshot(s) in last 48h",
                    }
                )
            except Exception as exc:
                logger.warning("Health check failed for cron: %s", exc)
                results.append({"name": "cron", "healthy": False, "detail": str(exc)})

            # Sync: check for recent sync_state activity
            try:
                count = await conn.fetchval(
                    """
                    SELECT COUNT(*)
                    FROM sync_state
                    WHERE last_synced_at > now() - INTERVAL '24 hours'
                    """
                )
                results.append(
                    {
                        "name": "sync",
                        "healthy": True,
                        "detail": f"{count or 0} sync(s) in last 24h",
                    }
                )
            except Exception as exc:
                logger.warning("Health check failed for sync: %s", exc)
                results.append({"name": "sync", "healthy": False, "detail": str(exc)})

        return results

    # ------------------------------------------------------------------
    # Billing
    # ------------------------------------------------------------------

    async def list_subscriptions(self, *, limit: int = 50, offset: int = 0) -> list[dict]:
        """List all subscriptions from the subscriptions table."""
        sql = """
            SELECT org_login, plan, billing_cycle, status, seat_count,
                   stripe_customer_id, current_period_start, current_period_end,
                   created_at
            FROM subscriptions
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
        """
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, limit, offset)
        return [dict(r) for r in rows]

    async def get_org_billing(self, org: str) -> dict | None:
        """Get billing details for a specific org."""
        async with self._pool.acquire() as conn:
            sub = await conn.fetchrow("SELECT * FROM subscriptions WHERE org_login = $1", org)
            usage = await conn.fetchrow(
                "SELECT * FROM ai_op_monthly_summary WHERE org_login = $1 ORDER BY period_start DESC LIMIT 1",
                org,
            )
        if sub is None:
            return None
        result = dict(sub)
        if usage:
            result["ai_ops_used"] = usage.get("ops_used", 0)
            result["ai_ops_included"] = usage.get("ops_included", 0)
        return result

    # ------------------------------------------------------------------
    # AI Operations
    # ------------------------------------------------------------------

    async def get_ai_ops_summary(self) -> dict:
        """Get aggregate AI operations metrics."""
        async with self._pool.acquire() as conn:
            today_ops = (
                await conn.fetchval(
                    "SELECT COUNT(*) FROM ai_op_usage WHERE recorded_at > CURRENT_DATE"
                )
                or 0
            )
            month_ops = (
                await conn.fetchval(
                    "SELECT COUNT(*) FROM ai_op_usage WHERE recorded_at > date_trunc('month', CURRENT_DATE)"
                )
                or 0
            )
            rows = await conn.fetch("""
                SELECT org_login, COUNT(*) as ops_count
                FROM ai_op_usage
                WHERE recorded_at > date_trunc('month', CURRENT_DATE)
                GROUP BY org_login
                ORDER BY ops_count DESC
                LIMIT 20
            """)
        return {
            "ops_today": int(today_ops),
            "ops_this_month": int(month_ops),
            "orgs": [dict(r) for r in rows],
        }

    async def get_org_ai_usage(self, org: str) -> dict:
        """Get AI usage for a specific org."""
        async with self._pool.acquire() as conn:
            today = (
                await conn.fetchval(
                    "SELECT COUNT(*) FROM ai_op_usage WHERE org_login = $1 AND recorded_at > CURRENT_DATE",
                    org,
                )
                or 0
            )
            month = (
                await conn.fetchval(
                    "SELECT COUNT(*) FROM ai_op_usage WHERE org_login = $1 AND recorded_at > date_trunc('month', CURRENT_DATE)",
                    org,
                )
                or 0
            )
            summary = await conn.fetchrow(
                "SELECT * FROM ai_op_monthly_summary WHERE org_login = $1 ORDER BY period_start DESC LIMIT 1",
                org,
            )
        result: dict = {"org": org, "ops_today": int(today), "ops_this_month": int(month)}
        if summary:
            result["ops_included"] = summary.get("ops_included", 0)
            result["ops_used"] = summary.get("ops_used", 0)
        return result

    # ------------------------------------------------------------------
    # Integrations
    # ------------------------------------------------------------------

    async def list_integrations(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        provider: str | None = None,
    ) -> list[dict]:
        """List all org integrations."""
        conditions: list[str] = []
        params: list = []

        if provider:
            params.append(provider)
            conditions.append(f"provider = ${len(params)}")

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
        params.extend([limit, offset])

        sql = f"""
            SELECT org_login, provider, display_name, status,
                   connected_by::text AS connected_by, connected_at,
                   updated_at,
                   provider_metadata->>'error' AS last_error
            FROM org_integrations
            {where}
            ORDER BY connected_at DESC NULLS LAST
            LIMIT ${len(params) - 1} OFFSET ${len(params)}
        """
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        return [dict(r) for r in rows]
