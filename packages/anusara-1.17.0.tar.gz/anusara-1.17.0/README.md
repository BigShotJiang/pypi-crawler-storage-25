# Anusara

**Deterministic execution runtime for agent workflows.**

---

## What is Anusara?

**Anusara is a deterministic runtime for executing agent workflows.**

Anusara makes agent workflows deterministic, observable, and replayable by design.

It executes graphs of agents using:

- deterministic scheduling  
- event-sourced execution history  
- replay-driven state reconstruction  

Every execution becomes:

- replayable  
- inspectable  
- debuggable  
- reproducible  

---

## 🚀 Quickstart (Docker)

### Run Anusara

```bash
docker run -d --name anusara -p 8000:8000 navasoftsolutions/anusara:latest
```

### Verify

```bash
curl http://localhost:8000/health && echo
curl http://localhost:8000/agents/available && echo
```

---

## The Mental Model

```
Agent Graph
     ↓
Deterministic Execution Engine
     ↓
Event Log (source of truth)
     ↓
Replay • Debug • Observability
```

---

## Why Anusara?

Anusara enforces:

- deterministic execution  
- event log authority  
- replay-based debugging  
- explicit lifecycle guarantees  

---

## Key Features

- deterministic execution  
- event-sourced execution history  
- replayable workflows  
- HTTP + CLI + Python runtime  
- agent lifecycle management  
- built-in observability  
- controlled workflow mutation  

---

## Project Status

Anusara is under active development.

---

## License

MIT License
