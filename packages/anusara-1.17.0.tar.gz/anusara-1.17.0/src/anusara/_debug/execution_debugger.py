from __future__ import annotations

import copy

from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState


class ExecutionDebugger:
    """
    Time-travel debugger for Anusara executions.

    Provides:
    - deterministic execution timeline
    - step forward / backward navigation
    - random access (seek)
    - partial state reconstruction (replay)

    This is a read-only utility and does not mutate original state.
    """

    def __init__(self, state: ExecutionState):
        self._original_state = state

        self._records: list[ExecutionRecord] = []

        for records in state._records.values():
            if not records:
                continue

            latest = records[-1]  # 🔥 enforce aggregation
            self._records.append(latest)

        # Safe deterministic ordering
        self._records.sort(key=self._seq_key)

        self._cursor = -1

        self._sequence_index: dict[int, int] = {}

        for idx, record in enumerate(self._records):
            seq = record.sequence_number

            if seq not in self._sequence_index:
                self._sequence_index[seq] = idx

    # ------------------------------------------------
    # Timeline
    # ------------------------------------------------

    def _seq_key(self, r: ExecutionRecord) -> int:
        return r.sequence_number if r.sequence_number is not None else 0

    def timeline(self) -> list[ExecutionRecord]:
        return list(self._records)

    # ------------------------------------------------
    # Cursor navigation
    # ------------------------------------------------

    def has_next(self) -> bool:
        return self._cursor + 1 < len(self._records)

    def has_prev(self) -> bool:
        return self._cursor > 0

    def step(self) -> ExecutionRecord:
        if not self.has_next():
            raise StopIteration("No more execution steps")

        self._cursor += 1
        return self._records[self._cursor]

    def step_back(self) -> ExecutionRecord:
        if not self.has_prev():
            raise StopIteration("Already at start")

        self._cursor -= 1
        return self._records[self._cursor]

    # ------------------------------------------------
    # Random access
    # ------------------------------------------------

    def seek(self, sequence_number: int) -> ExecutionRecord:
        if sequence_number not in self._sequence_index:
            raise ValueError(f"No record with sequence_number={sequence_number}")

        self._cursor = self._sequence_index[sequence_number]
        return self._records[self._cursor]

    # ------------------------------------------------
    # Cursor helpers
    # ------------------------------------------------

    def current(self) -> ExecutionRecord | None:
        if self._cursor < 0:
            return None

        return self._records[self._cursor]

    def reset(self) -> None:
        self._cursor = -1

    # ------------------------------------------------
    # Time-travel replay
    # ------------------------------------------------

    def replay_state(self) -> ExecutionState:
        """
        Reconstruct execution state up to the current cursor.

        Produces a partial state snapshot as if execution stopped
        at the current step.
        """

        graph = self._original_state._graph
        request = self._original_state.execution_request  # ✅ FIXED

        state = ExecutionState(graph, request)

        for i in range(self._cursor + 1):
            record = self._records[i]

            state._records.setdefault(record.node_id, []).append(copy.copy(record))

        return state
