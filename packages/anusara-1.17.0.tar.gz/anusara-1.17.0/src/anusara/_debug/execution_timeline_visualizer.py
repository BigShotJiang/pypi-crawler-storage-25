from __future__ import annotations

from datetime import datetime

from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState


def _started_at_key(r: ExecutionRecord) -> datetime:
    return r.started_at or datetime.min


class ExecutionTimelineVisualizer:
    """
    Terminal profiler-style timeline for Anusara execution.

    Displays:
    - relative start offsets
    - execution durations
    - coarse time axis (ms)
    """

    SCALE_MS = 10

    def __init__(self, state: ExecutionState):
        self.state = state

    # -----------------------------------------------------

    def render_ascii(self) -> str:
        records: list[ExecutionRecord] = self.state.all_records()

        # Filter only valid timed records
        records = [
            r
            for r in records
            if r.started_at is not None and r.completed_at is not None
        ]

        if not records:
            return "No execution records."

        start = min(r.started_at for r in records)
        end = max(r.completed_at for r in records)

        total_ms = int((end - start).total_seconds() * 1000)

        axis = self._render_axis(total_ms)

        lines: list[str] = []

        for r in sorted(records, key=_started_at_key):
            offset = int((r.started_at - start).total_seconds() * 1000)
            duration = int((r.completed_at - r.started_at).total_seconds() * 1000)

            prefix = " " * (offset // self.SCALE_MS)
            bar = "█" * max(1, duration // self.SCALE_MS)

            lines.append(f"{r.node_id}: {prefix}{bar}")

        return "\n".join([axis, *lines])

    # -----------------------------------------------------

    def _render_axis(self, total_ms: int) -> str:
        ticks = list(range(0, total_ms + 1, 20))

        axis_numbers = " ".join(f"{t:>4}" for t in ticks)
        axis_line = " ".join("│" for _ in ticks)

        return f"Timeline (ms)\n{axis_numbers}\n{axis_line}"
