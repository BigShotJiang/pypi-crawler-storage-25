from __future__ import annotations

from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.graph_definition import GraphDefinition
from anusara._routing.execution_state import ExecutionState


class ExecutionGraphAnimation:
    """
    Lightweight ASCII animation of execution progress.

    Symbols:
    ○ → Pending
    ▶ → Running
    ● → Completed
    """

    PENDING = "○"
    RUNNING = "▶"
    COMPLETE = "●"

    def __init__(self, request: ExecutionRequest, state: ExecutionState):
        self.request = request
        self.state = state

    # -----------------------------------------------------

    def _node_state(self, node_id: str, current_node: str | None) -> str:
        records = self.state._records.get(node_id)

        if current_node == node_id:
            return self.RUNNING

        if records:
            return self.COMPLETE

        return self.PENDING

    # -----------------------------------------------------

    def render(self, current_node: str | None = None) -> str:
        graph: GraphDefinition | None = self.request.graph_definition

        if not graph:
            return ""

        nodes = graph.get("nodes") or []
        edges = graph.get("edges") or []

        node_ids = [n["id"] for n in nodes]

        node_symbols = {
            node_id: self._node_state(node_id, current_node) for node_id in node_ids
        }

        lines: list[str] = []

        for edge in edges:
            if isinstance(edge, tuple):
                src, dst = edge
            else:
                src = edge["source"]
                dst = edge["target"]

            s = node_symbols.get(src, self.PENDING)
            d = node_symbols.get(dst, self.PENDING)

            lines.append(f"{src} {s} → {dst} {d}")

        return "\n".join(lines)

    # -----------------------------------------------------

    def render_waves(self, current_node: str | None = None) -> str:
        graph: GraphDefinition | None = self.request.graph_definition

        if not graph:
            return ""

        from anusara._debug.execution_graph_visualizer import (
            ExecutionGraphVisualizer,
        )

        waves = ExecutionGraphVisualizer(self.request, self.state).compute_waves()

        grouped: dict[int, list[str]] = {}

        for node, wave in waves.items():
            grouped.setdefault(wave, []).append(node)

        lines: list[str] = []

        for wave in sorted(grouped):
            parts: list[str] = []

            for node in sorted(grouped[wave]):
                symbol = self._node_state(node, current_node)
                parts.append(f"{node} {symbol}")

            lines.append(f"Wave {wave}  " + "   ".join(parts))

        return "\n".join(lines)
