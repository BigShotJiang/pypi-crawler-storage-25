"""
Anusara Debug & Inspection Utilities

This package provides tools for inspecting, visualizing, and debugging
execution behavior without modifying runtime state.

Typical capabilities include:
- execution timeline inspection
- step-by-step debugging
- graph visualization (e.g., DOT format)

Design principles:
- read-only interaction with execution state
- no mutation of ExecutionState or event log
- deterministic and reproducible views of execution
"""
