from __future__ import annotations

from anusara import Agent, AgentResult
from anusara._contracts.execution_input import ExecutionInput


class EchoAgent(Agent):
    """
    Built-in system agent.

    Purpose:
    - Provide a safe default agent for runtime
    - Validate execution pipeline end-to-end
    - Help debugging and observability

    Behavior:
    - Echoes propagated upstream message when present
    - Falls back to a default message otherwise
    """

    async def execute(self, execution_input: ExecutionInput) -> AgentResult:
        upstream_message = execution_input.payload.get("message")

        if isinstance(upstream_message, str) and upstream_message.strip():
            message = f"Echo: {upstream_message}"
        else:
            message = "EchoAgent executed successfully"

        return AgentResult(
            success=True,
            output={
                "message": message,
                "request_id": execution_input.request_id,
                "scenario_name": execution_input.scenario_name(),
                "data": execution_input.data,
                "raw_payload": execution_input.payload,
                "scenario": execution_input.scenario.to_dict(),
            },
            confidence=1.0,
        )
