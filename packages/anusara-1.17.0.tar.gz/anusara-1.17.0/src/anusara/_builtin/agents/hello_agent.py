from anusara import Agent, AgentResult
from anusara._contracts.execution_input import ExecutionInput


class HelloAgent(Agent):
    """
    A minimal agent that returns a greeting message.

    Behavior is driven by scenario parameters (control-plane),
    not scenario identity.
    """

    async def execute(self, execution_input: ExecutionInput) -> AgentResult:
        # -----------------------------------------------------
        # Scenario-driven behavior
        # -----------------------------------------------------
        mode = execution_input.param("response_mode", "default")

        if execution_input.flag("force_fail"):
            return AgentResult(
                success=False,
                output={
                    "error": "Forced failure",
                    "scenario": execution_input.scenario_name(),
                    "request_id": execution_input.request_id,
                },
                confidence=0.0,
            )

        # -----------------------------------------------------
        # Behavior selection (parameter-driven, not name-driven)
        # -----------------------------------------------------
        if isinstance(mode, str) and mode == "alternate":
            message = "Hello from alternate path 👋"
        elif isinstance(mode, str) and mode == "formal":
            message = "Greetings from Anusara."
        else:
            message = "Hello from Anusara 👋"

        # -----------------------------------------------------
        # Response
        # -----------------------------------------------------
        return AgentResult(
            success=True,
            output={
                "message": message,
                "scenario": execution_input.scenario_name(),
                "request_id": execution_input.request_id,
                "data": execution_input.data,
                # Optional but useful for observability/debugging
                "mode": mode,
            },
            confidence=1.0,
        )
