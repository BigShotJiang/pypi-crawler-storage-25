from __future__ import annotations

from anusara._builtin.agents.echo_agent import EchoAgent
from anusara._builtin.agents.hello_agent import HelloAgent
from anusara._registry.agent_registry import AgentRegistry


def register_builtin_agents(registry: AgentRegistry) -> None:
    registry.register("core.hello", HelloAgent(), is_builtin=True)
    registry.register("hello", HelloAgent(), is_builtin=True)

    registry.register("core.echo", EchoAgent(), is_builtin=True)
    registry.register("echo", EchoAgent(), is_builtin=True)
