from anusara._contracts.agent_result import AgentResult
from anusara._contracts.mesh_result import MeshResult
from anusara._core.execution_policy import ExecutionPolicy
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_state import ExecutionState


class ResultAggregator:
    """
    Responsible for transforming execution state into final MeshResult.
    """

    def aggregate(
        self,
        graph: ExecutionGraph,
        state: ExecutionState,
        policy: ExecutionPolicy,
    ) -> MeshResult:

        results: dict[str, AgentResult] = {}
        errors: list[str] = []

        overall_success = True
        total_confidence = 0.0
        counted_nodes = 0

        # ---------------------------------------------------------
        # Aggregate per node
        # ---------------------------------------------------------
        for node_id, node in graph.nodes.items():
            # Skip structural nodes
            if node.agent is None:
                continue

            agent_result = state.aggregate_node(
                node_id=node_id,
                mode=policy.aggregation_mode,
            )

            if agent_result is None:
                # 🔥 Node not executed → DO NOT treat as failure
                continue

            results[node.agent] = agent_result

            if not agent_result.success:
                overall_success = False

            if agent_result.errors:
                errors.extend(agent_result.errors)

            total_confidence += agent_result.confidence
            counted_nodes += 1

        avg_confidence = total_confidence / counted_nodes if counted_nodes else 0.0

        return MeshResult(
            success=overall_success,
            results=results,
            errors=errors or None,
            confidence=avg_confidence,
            metadata={
                "total_nodes": counted_nodes,
                "aggregation_mode": policy.aggregation_mode,
            },
        )
