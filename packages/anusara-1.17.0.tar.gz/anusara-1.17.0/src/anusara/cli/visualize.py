from __future__ import annotations

from pathlib import Path

from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.graph_definition import GraphDefinition
from anusara._debug.execution_analyzer import ExecutionAnalyzer
from anusara._debug.execution_flame_graph import ExecutionFlameGraph
from anusara._debug.execution_graph_visualizer import ExecutionGraphVisualizer
from anusara._debug.execution_replay_visualizer import ExecutionReplayVisualizer
from anusara._debug.execution_timeline_visualizer import ExecutionTimelineVisualizer
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_state import ExecutionState


class CLIVisualizer:
    """
    CLI visualization utilities for Anusara.

    Provides lightweight, deterministic visualization helpers for:

    - Graph structure (Mermaid)
    - Execution timeline (ASCII)
    - Flame graphs (ASCII / Speedscope)
    - Execution analysis reports
    - Replay visualization

    Design:
    - No mutation of execution state
    - Purely observational
    - CLI-friendly rendering (stdout / files)
    """

    # ---------------------------------------------------------
    # Graph (Mermaid)
    # ---------------------------------------------------------

    def generate_mermaid_graph(self) -> str:
        """
        Generate a simple deterministic Mermaid graph.

        Used for CLI demonstration and quick validation.
        """

        graph_definition: GraphDefinition = {
            "nodes": [
                {"id": "A"},
                {"id": "B"},
                {"id": "C"},
            ],
            "edges": [
                {"source": "A", "target": "B"},
                {"source": "A", "target": "C"},
            ],
        }

        request = ExecutionRequest(
            request_id="cli-example",
            graph_definition=graph_definition,
            entry_nodes=["A"],
        )

        # NOTE:
        # Empty state is sufficient for static graph rendering
        graph = ExecutionGraph()
        state = ExecutionState(graph)

        visualizer = ExecutionGraphVisualizer(request, state)

        return visualizer.to_mermaid()

    # ---------------------------------------------------------

    def visualize_graph(self, output_dir: str) -> None:
        """
        Write Mermaid graph to output directory.
        """

        output = Path(output_dir)
        mermaid = self.generate_mermaid_graph()

        mermaid_file = output / "execution.mermaid"
        mermaid_file.write_text(mermaid)

        print(f"Mermaid graph written to {mermaid_file}")

    # ---------------------------------------------------------
    # Timeline
    # ---------------------------------------------------------

    def visualize_timeline(self, state: ExecutionState) -> None:
        """
        Render execution timeline as ASCII.
        """

        visualizer = ExecutionTimelineVisualizer(state)
        print(visualizer.render_ascii())

    # ---------------------------------------------------------
    # Combined Run View
    # ---------------------------------------------------------

    def visualize_run(
        self,
        state: ExecutionState,
        request: ExecutionRequest,
    ) -> None:
        """
        Render combined execution view (graph + timeline).
        """

        graph_viz = ExecutionGraphVisualizer(request, state)
        timeline_viz = ExecutionTimelineVisualizer(state)

        print("\nAnusara Execution Report")
        print("=" * 40)

        print("\nExecution Graph")
        print("-" * 40)
        print(graph_viz.to_mermaid())

        print("\nExecution Timeline")
        print("-" * 40)
        print(timeline_viz.render_ascii())

    # ---------------------------------------------------------
    # Flame Graph
    # ---------------------------------------------------------

    def visualize_flame_graph(self, state: ExecutionState) -> None:
        """
        Render execution flame graph (ASCII).
        """

        flame = ExecutionFlameGraph(state)
        print(flame.render_ascii())

    # ---------------------------------------------------------

    def export_speedscope(self, state: ExecutionState, output_file: str) -> None:
        """
        Export flame graph in Speedscope format.
        """

        flame = ExecutionFlameGraph(state)
        flame.export_speedscope(output_file)

        print(f"Speedscope profile written to {output_file}")

    # ---------------------------------------------------------
    # Analysis
    # ---------------------------------------------------------

    def visualize_analysis(
        self,
        state: ExecutionState,
        request: ExecutionRequest,
    ) -> None:
        """
        Render execution analysis report.
        """

        analyzer = ExecutionAnalyzer(request, state)
        print(analyzer.render_report())

    # ---------------------------------------------------------
    # Replay
    # ---------------------------------------------------------

    def visualize_replay(
        self,
        state: ExecutionState,
        request: ExecutionRequest,
    ) -> None:
        """
        Replay execution timeline in CLI.
        """

        replay = ExecutionReplayVisualizer(request, state)
        replay.replay()
