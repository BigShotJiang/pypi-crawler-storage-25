from __future__ import annotations

from pathlib import Path


def inspect_graph(graph_path: str) -> None:
    """
    Inspect a graph definition file.

    Prints the raw contents of the graph file to stdout.

    Intended for quick inspection and debugging of
    graph definitions used in execution.
    """

    path = Path(graph_path)

    if not path.exists():
        raise FileNotFoundError(f"Graph file not found: {graph_path}")

    if not path.is_file():
        raise ValueError(f"Path is not a file: {graph_path}")

    print(f"\nInspecting graph: {path.resolve()}")
    print("=" * 40)

    try:
        content = path.read_text(encoding="utf-8")
    except Exception as exc:
        raise RuntimeError(f"Failed to read file: {graph_path}") from exc

    if not content.strip():
        print("(empty file)")
        return

    print(content)
