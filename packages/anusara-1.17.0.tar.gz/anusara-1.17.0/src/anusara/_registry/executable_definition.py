from __future__ import annotations

from dataclasses import dataclass

from anusara._registry.executable_kind import ExecutableKind
from anusara._registry.invocation_spec import (
    InvocationSpec,
    PythonPluginInvocationSpec,
)


@dataclass(frozen=True)
class ExecutableDefinition:
    agent_id: str
    namespace: str | None
    version: str | None
    is_builtin: bool
    kind: ExecutableKind
    source_ref: str
    invocation: InvocationSpec

    legacy_source_kind: str | None = None

    @property
    def source_kind(self) -> str:
        if self.legacy_source_kind is not None:
            return self.legacy_source_kind

        if self.kind == ExecutableKind.REMOTE_HTTP:
            return "remote_http"

        if isinstance(self.invocation, PythonPluginInvocationSpec):
            if self.invocation.module == "__instance__":
                return "instance"
            return "python_import"

        return self.kind.value

    @property
    def factory_type(self) -> str:
        if self.kind == ExecutableKind.REMOTE_HTTP:
            return "RemoteHttpInvoker"

        if isinstance(self.invocation, PythonPluginInvocationSpec):
            if self.invocation.module == "__instance__":
                return "InstanceAgentFactory"
            return "ClassAgentFactory"

        return "Unknown"

    @property
    def legacy_source_ref(self) -> str:
        if isinstance(self.invocation, PythonPluginInvocationSpec):
            if self.invocation.module == "__instance__":
                return self.invocation.symbol
        return self.source_ref
