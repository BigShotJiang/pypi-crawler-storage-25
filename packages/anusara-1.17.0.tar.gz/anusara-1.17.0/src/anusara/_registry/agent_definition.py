from __future__ import annotations

from dataclasses import dataclass

from anusara._contracts.agent import Agent


@dataclass(frozen=True)
class AgentDefinition:
    """
    First-class registration record for an agent.

    Separates stable runtime identity from concrete implementation.

    Fields:
    - agent_id: stable identifier used in workflow definitions and execution
    - implementation: concrete agent implementation
    - namespace: optional namespace (e.g. "core", "nirvaha")
    - version: optional version metadata for future extensibility
    - is_builtin: whether the agent is owned/shipped by Anusara
    """

    agent_id: str
    implementation: Agent
    namespace: str | None = None
    version: str | None = None
    is_builtin: bool = False
