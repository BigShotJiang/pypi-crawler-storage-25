from __future__ import annotations

from dataclasses import dataclass

from anusara._registry.factory_protocol import AgentFactory


@dataclass(frozen=True)
class ResolvedAgentDefinition:
    """
    Runtime-authoritative agent registration record.

    This is the validated form stored in the registry after registration
    input has been normalized and resolved into executable factory-backed
    metadata.
    """

    agent_id: str
    namespace: str | None
    version: str | None
    is_builtin: bool
    source_kind: str
    source_ref: str
    factory: AgentFactory


__all__ = ["ResolvedAgentDefinition"]
