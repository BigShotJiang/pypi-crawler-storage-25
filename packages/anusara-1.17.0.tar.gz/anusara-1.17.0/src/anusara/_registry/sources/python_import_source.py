from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PythonImportAgentSource:
    """
    Typed source specification for resolving an agent from a Python module.

    Fields:
    - module: importable module path
    - symbol: exported class or factory symbol inside the module
    """

    module: str
    symbol: str


__all__ = ["PythonImportAgentSource"]
