from __future__ import annotations

from typing import Protocol

from anusara._contracts.agent import Agent


class AgentFactory(Protocol):
    def create(self) -> Agent: ...


__all__ = ["AgentFactory"]
