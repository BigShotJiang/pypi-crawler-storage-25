from __future__ import annotations

from dataclasses import dataclass

from anusara._registry.sources.python_import_source import PythonImportAgentSource


@dataclass(frozen=True)
class AgentRegistrationSpec:
    """
    Durable registration input for an agent.

    This is the explicit registration boundary used to describe how an
    agent should be resolved into a runtime-authoritative factory-backed
    definition.

    Fields:
    - agent_id: stable identifier used in workflow definitions and execution
    - source: typed source specification describing how to resolve the agent
    - namespace: optional logical namespace (for example: "core", "nirvaha")
    - version: optional version metadata for audit/debugging/replay visibility
    - is_builtin: whether the agent is owned/shipped by Anusara
    """

    agent_id: str
    source: PythonImportAgentSource
    namespace: str | None = None
    version: str | None = None
    is_builtin: bool = False


__all__ = ["AgentRegistrationSpec"]
