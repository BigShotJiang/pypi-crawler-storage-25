from __future__ import annotations

import re
from typing import Protocol, runtime_checkable

from anusara._contracts.agent import Agent
from anusara._contracts.agent_schema_descriptor import AgentSchemaDescriptor
from anusara._registry.factory_protocol import AgentFactory
from anusara._registry.resolved_definition import ResolvedAgentDefinition

_AGENT_ID_PATTERN = re.compile(r"^[a-z0-9_]+(?:\.[a-z0-9_]+)*$")


@runtime_checkable
class _SchemaDeclarer(Protocol):
    @classmethod
    def describe_schema(cls) -> AgentSchemaDescriptor: ...


def validate_agent_id(agent_id: str) -> None:
    """
    Validate a stable agent identifier.

    Accepted format:
    - lowercase letters
    - digits
    - underscores
    - optional dot-separated namespaces

    Examples:
    - core.hello
    - app.order.validate
    - model_v1
    """
    if not isinstance(agent_id, str) or not agent_id:
        raise ValueError("Agent identifier must be a non-empty string.")

    if not _AGENT_ID_PATTERN.fullmatch(agent_id):
        raise ValueError(
            "Invalid agent identifier. Expected lowercase identifier using "
            "letters, numbers, or underscores, with optional dot-separated "
            "namespaces (examples: 'core.hello', 'app.order.validate', or 'model_v1')."
        )


def validate_agent_instance(agent: Agent, *, agent_id: str) -> None:
    """
    Validate that a created object satisfies the runtime Agent contract.
    """
    if not isinstance(agent, Agent):
        raise TypeError(f"Agent '{agent_id}' must implement the Agent contract.")


def validate_factory(factory: AgentFactory, *, agent_id: str) -> None:
    """
    Validate that a runtime factory can create a valid Agent instance.

    This performs eager validation so that bad registrations fail before the
    registry is mutated.
    """
    created = factory.create()
    validate_agent_instance(created, agent_id=agent_id)
    validate_agent_schema_descriptor(created, agent_id=agent_id)


def validate_resolved_definition(definition: ResolvedAgentDefinition) -> None:
    """
    Validate a resolved runtime definition before it is stored in the registry.
    """
    if not isinstance(definition, ResolvedAgentDefinition):
        raise TypeError("definition must be a ResolvedAgentDefinition.")

    validate_agent_id(definition.agent_id)

    if definition.namespace is not None:
        if not isinstance(definition.namespace, str) or not definition.namespace:
            raise ValueError("namespace must be a non-empty string when provided.")

    if definition.version is not None:
        if not isinstance(definition.version, str) or not definition.version:
            raise ValueError("version must be a non-empty string when provided.")

    if not isinstance(definition.source_kind, str) or not definition.source_kind:
        raise ValueError("source_kind must be a non-empty string.")

    if not isinstance(definition.source_ref, str):
        raise ValueError("source_ref must be a string.")

    validate_factory(definition.factory, agent_id=definition.agent_id)


def validate_agent_schema_descriptor(
    agent: Agent, *, agent_id: str
) -> AgentSchemaDescriptor | None:
    """
    Validate an agent's declared schema descriptor, if present.

    Returns:
        AgentSchemaDescriptor when describe_schema() is declared and valid,
        otherwise None.

    Raises:
        TypeError: If describe_schema() returns an invalid type.
    """
    if not isinstance(agent, _SchemaDeclarer):
        return None

    descriptor = agent.describe_schema()

    if not isinstance(descriptor, AgentSchemaDescriptor):
        raise TypeError(
            f"Agent '{agent_id}' describe_schema() must return AgentSchemaDescriptor."
        )

    return descriptor


__all__ = [
    "validate_agent_id",
    "validate_agent_instance",
    "validate_agent_schema_descriptor",
    "validate_factory",
    "validate_resolved_definition",
]
