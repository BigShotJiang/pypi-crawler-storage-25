from __future__ import annotations

from enum import StrEnum


class ExecutableKind(StrEnum):
    """
    Runtime invocation mode for a registered executable.

    Notes:
    - PYTHON_PLUGIN preserves same-runtime plugin behavior.
    - REMOTE_HTTP is the default standalone/container-safe external mode.
    """

    PYTHON_PLUGIN = "python_plugin"
    REMOTE_HTTP = "remote_http"


__all__ = ["ExecutableKind"]
