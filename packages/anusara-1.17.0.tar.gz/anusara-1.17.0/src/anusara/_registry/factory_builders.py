from __future__ import annotations

from dataclasses import dataclass

from anusara._contracts.agent import Agent
from anusara._registry.factory_protocol import AgentFactory


@dataclass(frozen=True)
class InstanceAgentFactory(AgentFactory):
    agent: Agent

    def create(self) -> Agent:
        return self.agent


@dataclass(frozen=True)
class ClassAgentFactory(AgentFactory):
    agent_cls: type[Agent]

    def create(self) -> Agent:
        return self.agent_cls()


__all__ = ["InstanceAgentFactory", "ClassAgentFactory"]
