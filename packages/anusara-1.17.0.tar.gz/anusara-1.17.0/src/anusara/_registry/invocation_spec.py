from __future__ import annotations

from dataclasses import dataclass
from typing import TypeAlias


@dataclass(frozen=True)
class PythonPluginInvocationSpec:
    """
    Invocation metadata for same-runtime Python plugin execution.
    """

    module: str
    symbol: str


@dataclass(frozen=True)
class RemoteHttpInvocationSpec:
    """
    Invocation metadata for remote HTTP worker execution.
    """

    url: str
    method: str = "POST"
    timeout_ms: int = 5000


InvocationSpec: TypeAlias = PythonPluginInvocationSpec | RemoteHttpInvocationSpec


__all__ = [
    "PythonPluginInvocationSpec",
    "RemoteHttpInvocationSpec",
    "InvocationSpec",
]
