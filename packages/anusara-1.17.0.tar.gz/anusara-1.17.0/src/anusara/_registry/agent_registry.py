from __future__ import annotations

import builtins
import importlib
import inspect
from typing import cast

from anusara._contracts.agent import Agent
from anusara._contracts.agent_schema_descriptor import AgentSchemaDescriptor
from anusara._registry.errors import AgentNotFoundError
from anusara._registry.executable_definition import ExecutableDefinition
from anusara._registry.executable_kind import ExecutableKind
from anusara._registry.invocation_spec import (
    PythonPluginInvocationSpec,
    RemoteHttpInvocationSpec,
)
from anusara._registry.registration_spec import AgentRegistrationSpec
from anusara._registry.resolved_definition import ResolvedAgentDefinition
from anusara._registry.validation import (
    validate_agent_id,
    validate_agent_instance,
    validate_agent_schema_descriptor,
)


class AgentRegistry:
    """
    Registry for managing executable definitions.

    Phase 1 behavior:
    - Supports same-runtime Python plugin execution
    - Supports remote HTTP executable registration
    - Preserves compatibility for instance-based built-in registration

    Design principles:
    - Explicit registration only
    - Deterministic lookup
    - Stable identifier-based resolution
    - Runtime-agnostic executable model
    """

    def __init__(self, strict: bool = True) -> None:
        self._agents: dict[str, ExecutableDefinition] = {}
        self._strict = strict
        self._schema_cache: dict[str, AgentSchemaDescriptor | None] = {}

        # Transitional compatibility:
        # preserve direct instance registration for built-ins / tests
        self._plugin_instances: dict[str, Agent] = {}

    # ---------------------------------------------------------
    # REGISTRATION
    # ---------------------------------------------------------
    def register(
        self,
        name: str,
        agent: Agent,
        *,
        replace: bool = False,
        is_builtin: bool = False,
    ) -> None:
        """
        Backward-compatible registration API for concrete in-process agent instances.

        This is retained in Phase 1 primarily for:
        - built-in runtime registration
        - tests
        - transitional compatibility

        In strict mode:
        - duplicate registration without replace=True must raise KeyError

        In non-strict mode:
        - later registrations overwrite earlier ones
        """
        validate_agent_id(name)
        validate_agent_instance(agent, agent_id=name)

        if not replace and name in self._agents and self._strict:
            raise KeyError(f"Agent '{name}' already registered")

        executable = ExecutableDefinition(
            agent_id=name,
            namespace=self._infer_namespace(name),
            version=None,
            is_builtin=is_builtin,
            kind=ExecutableKind.PYTHON_PLUGIN,
            source_ref=type(agent).__name__,
            invocation=PythonPluginInvocationSpec(
                module="__instance__",
                symbol=type(agent).__name__,
            ),
            legacy_source_kind="instance",
        )

        self._plugin_instances[name] = agent
        self._store_definition(executable, instance_agent=agent)

    def register_external(
        self,
        name: str,
        module: str,
        symbol: str,
        *,
        namespace: str | None = None,
        version: str | None = None,
        is_builtin: bool = False,
        replace: bool = False,
    ) -> None:
        """
        Legacy/plugin registration path.

        In Phase 1 this remains supported as explicit same-runtime Python plugin
        registration, not as the preferred standalone/container integration path.
        """
        validate_agent_id(name)

        definition = self._build_plugin_definition(
            agent_id=name,
            namespace=(
                namespace if namespace is not None else self._infer_namespace(name)
            ),
            version=version,
            is_builtin=is_builtin,
            module=module,
            symbol=symbol,
        )

        self._validate_plugin_definition(definition)

        if definition.agent_id in self._agents:
            existing = self._agents[definition.agent_id]

            if self._definitions_match(definition, existing):
                return

            if replace:
                self._plugin_instances.pop(definition.agent_id, None)
                self._store_definition(definition)
                return

            if self._strict:
                raise KeyError(f"Agent '{definition.agent_id}' is already registered.")

        self._plugin_instances.pop(definition.agent_id, None)
        self._store_definition(definition)

    def register_remote_http(
        self,
        *,
        agent_id: str,
        url: str,
        namespace: str | None = None,
        version: str | None = None,
        is_builtin: bool = False,
        method: str = "POST",
        timeout_ms: int = 5000,
        replace: bool = False,
    ) -> None:
        """
        Register a remote HTTP executable.

        This is the preferred standalone/container-safe registration path.
        """
        validate_agent_id(agent_id)

        definition = ExecutableDefinition(
            agent_id=agent_id,
            namespace=namespace,
            version=version,
            is_builtin=is_builtin,
            kind=ExecutableKind.REMOTE_HTTP,
            source_ref=url,
            invocation=RemoteHttpInvocationSpec(
                url=url,
                method=method,
                timeout_ms=timeout_ms,
            ),
        )

        if agent_id in self._agents:
            existing = self._agents[agent_id]

            if self._definitions_match(definition, existing):
                return

            if replace:
                self._plugin_instances.pop(agent_id, None)
                self._store_definition(definition)
                return

            if self._strict:
                raise KeyError(f"Agent '{agent_id}' is already registered.")

        self._plugin_instances.pop(agent_id, None)
        self._store_definition(definition)

    def register_resolved_definition(
        self,
        definition: ExecutableDefinition | ResolvedAgentDefinition,
    ) -> None:
        executable, instance_agent = self._coerce_definition(definition)

        if self._strict and executable.agent_id in self._agents:
            raise KeyError(f"Agent '{executable.agent_id}' is already registered.")

        if instance_agent is not None:
            self._plugin_instances[executable.agent_id] = instance_agent

        self._store_definition(executable, instance_agent=instance_agent)

    # ---------------------------------------------------------
    # LOOKUP / RESOLUTION
    # ---------------------------------------------------------

    def get(self, name: str) -> Agent:
        """
        Transitional compatibility API.

        Returns a local Agent instance only for Python plugin executables.
        Remote HTTP executables cannot be resolved as in-process Agent objects.
        """
        definition = self.get_definition(name)

        if definition.kind != ExecutableKind.PYTHON_PLUGIN:
            raise TypeError(
                f"Executable '{name}' is not a local Python plugin and cannot be resolved as Agent."
            )

        return self._create_plugin_agent(definition)

    def get_definition(self, agent_id: str) -> ExecutableDefinition:
        """
        Retrieve the runtime-authoritative executable definition.
        """
        try:
            return self._agents[agent_id]
        except KeyError as exc:
            raise AgentNotFoundError(agent_id) from exc

    # ---------------------------------------------------------
    # LIFECYCLE
    # ---------------------------------------------------------

    def unregister(self, name: str) -> None:
        if name not in self._agents:
            raise AgentNotFoundError(name)

        del self._agents[name]
        self._schema_cache.pop(name, None)
        self._plugin_instances.pop(name, None)

    def exists(self, name: str) -> bool:
        return name in self._agents

    def clear(self) -> None:
        self._agents.clear()
        self._schema_cache.clear()
        self._plugin_instances.clear()

    def reset(self) -> None:
        self.clear()

    # ---------------------------------------------------------
    # COLLECTION HELPERS
    # ---------------------------------------------------------

    def __contains__(self, name: str) -> bool:
        return name in self._agents

    def __len__(self) -> int:
        return len(self._agents)

    def list(self) -> list[str]:
        return list(self._agents.keys())

    def list_definitions(self) -> builtins.list[ExecutableDefinition]:
        return list(self._agents.values())

    # ---------------------------------------------------------
    # SCHEMA CACHE
    # ---------------------------------------------------------

    def get_schema_descriptor(
        self,
        agent_id: str,
    ) -> AgentSchemaDescriptor | None:
        self.get_definition(agent_id)
        return self._schema_cache.get(agent_id)

    def get_cached_capabilities(
        self,
        agent_id: str,
    ) -> builtins.list[str]:
        descriptor = self.get_schema_descriptor(agent_id)
        return list(descriptor.capabilities) if descriptor is not None else []

    def get_cached_description(
        self,
        agent_id: str,
    ) -> str | None:
        descriptor = self.get_schema_descriptor(agent_id)
        return descriptor.description if descriptor is not None else None

    # ---------------------------------------------------------
    # INTERNALS
    # ---------------------------------------------------------

    def _infer_namespace(self, agent_id: str) -> str | None:
        if "." not in agent_id:
            return None

        namespace, _ = agent_id.split(".", 1)
        return namespace or None

    def _definitions_match(
        self,
        left: ExecutableDefinition,
        right: ExecutableDefinition,
    ) -> bool:
        return (
            left.agent_id == right.agent_id
            and left.namespace == right.namespace
            and left.version == right.version
            and left.is_builtin == right.is_builtin
            and left.kind == right.kind
            and left.source_ref == right.source_ref
            and left.invocation == right.invocation
        )

    def _build_plugin_definition(
        self,
        *,
        agent_id: str,
        namespace: str | None,
        version: str | None,
        is_builtin: bool,
        module: str,
        symbol: str,
    ) -> ExecutableDefinition:
        return ExecutableDefinition(
            agent_id=agent_id,
            namespace=namespace,
            version=version,
            is_builtin=is_builtin,
            kind=ExecutableKind.PYTHON_PLUGIN,
            source_ref=f"{module}:{symbol}",
            invocation=PythonPluginInvocationSpec(
                module=module,
                symbol=symbol,
            ),
        )

    def _validate_plugin_definition(
        self,
        definition: ExecutableDefinition,
    ) -> None:
        spec = definition.invocation

        if not isinstance(spec, PythonPluginInvocationSpec):
            raise TypeError("Plugin definition must use PythonPluginInvocationSpec")

        # Instance-backed compatibility path
        if definition.agent_id in self._plugin_instances:
            agent = self._plugin_instances[definition.agent_id]
            validate_agent_instance(agent, agent_id=definition.agent_id)
            return

        module = importlib.import_module(spec.module)
        namespace = cast(dict[str, object], module.__dict__)

        if spec.symbol not in namespace:
            raise AttributeError(
                f"Module '{spec.module}' does not define symbol '{spec.symbol}'."
            )

        symbol_object = namespace[spec.symbol]

        if not inspect.isclass(symbol_object):
            raise TypeError(
                f"Resolved symbol '{spec.module}:{spec.symbol}' must be a class."
            )

        candidate_cls = cast(type[object], symbol_object)

        if not issubclass(candidate_cls, Agent):
            raise TypeError(
                f"Resolved symbol '{spec.module}:{spec.symbol}' must be an Agent class."
            )

        agent_cls = candidate_cls
        agent = agent_cls()
        validate_agent_instance(agent, agent_id=definition.agent_id)

    def _build_plugin_schema_cache_entry(
        self,
        definition: ExecutableDefinition,
        instance_agent: Agent | None = None,
    ) -> AgentSchemaDescriptor | None:
        spec = definition.invocation

        if not isinstance(spec, PythonPluginInvocationSpec):
            raise TypeError("Plugin definition must use PythonPluginInvocationSpec")

        if instance_agent is not None:
            validate_agent_instance(instance_agent, agent_id=definition.agent_id)
            return validate_agent_schema_descriptor(
                instance_agent,
                agent_id=definition.agent_id,
            )

        if definition.agent_id in self._plugin_instances:
            agent = self._plugin_instances[definition.agent_id]
            validate_agent_instance(agent, agent_id=definition.agent_id)
            return validate_agent_schema_descriptor(
                agent,
                agent_id=definition.agent_id,
            )

        module = importlib.import_module(spec.module)
        namespace = cast(dict[str, object], module.__dict__)

        if spec.symbol not in namespace:
            raise AttributeError(
                f"Module '{spec.module}' does not define symbol '{spec.symbol}'."
            )

        symbol_object = namespace[spec.symbol]

        if not inspect.isclass(symbol_object):
            raise TypeError(
                f"Resolved symbol '{spec.module}:{spec.symbol}' must be a class."
            )

        candidate_cls = cast(type[object], symbol_object)

        if not issubclass(candidate_cls, Agent):
            raise TypeError(
                f"Resolved symbol '{spec.module}:{spec.symbol}' must be an Agent class."
            )

        agent_cls = candidate_cls
        agent = agent_cls()

        validate_agent_instance(agent, agent_id=definition.agent_id)
        return validate_agent_schema_descriptor(agent, agent_id=definition.agent_id)

    def _create_plugin_agent(
        self,
        definition: ExecutableDefinition,
    ) -> Agent:
        spec = definition.invocation

        if not isinstance(spec, PythonPluginInvocationSpec):
            raise TypeError("Plugin definition must use PythonPluginInvocationSpec")

        if definition.agent_id in self._plugin_instances:
            agent = self._plugin_instances[definition.agent_id]
            validate_agent_instance(agent, agent_id=definition.agent_id)
            return agent

        module = importlib.import_module(spec.module)
        namespace = cast(dict[str, object], module.__dict__)

        if spec.symbol not in namespace:
            raise AttributeError(
                f"Module '{spec.module}' does not define symbol '{spec.symbol}'."
            )

        symbol_object = namespace[spec.symbol]

        if not inspect.isclass(symbol_object):
            raise TypeError(
                f"Resolved symbol '{spec.module}:{spec.symbol}' must be a class."
            )

        candidate_cls = cast(type[object], symbol_object)

        if not issubclass(candidate_cls, Agent):
            raise TypeError(
                f"Resolved symbol '{spec.module}:{spec.symbol}' must be an Agent class."
            )

        agent_cls = candidate_cls
        agent = agent_cls()
        validate_agent_instance(agent, agent_id=definition.agent_id)
        return agent

    def _store_definition(
        self,
        definition: ExecutableDefinition,
        *,
        instance_agent: Agent | None = None,
    ) -> None:
        descriptor = self._validate_and_build_schema_cache_entry(
            definition,
            instance_agent=instance_agent,
        )
        self._agents[definition.agent_id] = definition
        self._schema_cache[definition.agent_id] = descriptor

    def _validate_and_build_schema_cache_entry(
        self,
        definition: ExecutableDefinition,
        *,
        instance_agent: Agent | None = None,
    ) -> AgentSchemaDescriptor | None:
        """
        Validates a definition and builds its schema cache entry.

        Phase 1 behavior:
        - Python plugins -> full validation + schema cache entry
        - Remote HTTP -> no schema cache yet (None)
        """
        validate_agent_id(definition.agent_id)

        if definition.namespace is not None:
            if not isinstance(definition.namespace, str) or not definition.namespace:
                raise ValueError("namespace must be a non-empty string when provided.")

        if definition.version is not None:
            if not isinstance(definition.version, str) or not definition.version:
                raise ValueError("version must be a non-empty string when provided.")

        if definition.kind == ExecutableKind.PYTHON_PLUGIN:
            return self._build_plugin_schema_cache_entry(
                definition,
                instance_agent=instance_agent,
            )

        if definition.kind == ExecutableKind.REMOTE_HTTP:
            # Phase 1: remote schemas are not yet registered/cached
            return None

        raise ValueError(f"Unsupported executable kind: {definition.kind}")

    def _coerce_definition(
        self,
        definition: ExecutableDefinition | ResolvedAgentDefinition,
    ) -> tuple[ExecutableDefinition, Agent | None]:
        if isinstance(definition, ExecutableDefinition):
            return definition, None

        if definition.source_kind == "instance":
            agent = definition.factory.create()
            validate_agent_instance(agent, agent_id=definition.agent_id)

            executable = ExecutableDefinition(
                agent_id=definition.agent_id,
                namespace=definition.namespace,
                version=definition.version,
                is_builtin=definition.is_builtin,
                kind=ExecutableKind.PYTHON_PLUGIN,
                source_ref=definition.source_ref,
                invocation=PythonPluginInvocationSpec(
                    module="__instance__",
                    symbol=definition.source_ref,
                ),
                legacy_source_kind="instance",
            )
            return executable, agent

        if definition.source_kind in {"class", "python_import"}:
            source_ref = definition.source_ref
            module, symbol = source_ref.split(":", 1)

            executable = ExecutableDefinition(
                agent_id=definition.agent_id,
                namespace=definition.namespace,
                version=definition.version,
                is_builtin=definition.is_builtin,
                kind=ExecutableKind.PYTHON_PLUGIN,
                source_ref=source_ref,
                invocation=PythonPluginInvocationSpec(
                    module=module,
                    symbol=symbol,
                ),
                legacy_source_kind=definition.source_kind,
            )
            return executable, None

        raise ValueError(f"Unsupported legacy source_kind: {definition.source_kind}")

    def register_spec(self, spec: AgentRegistrationSpec) -> None:
        validate_agent_id(spec.agent_id)

        source = spec.source

        definition = ExecutableDefinition(
            agent_id=spec.agent_id,
            namespace=spec.namespace,
            version=spec.version,
            is_builtin=spec.is_builtin,
            kind=ExecutableKind.PYTHON_PLUGIN,
            source_ref=f"{source.module}:{source.symbol}",
            invocation=PythonPluginInvocationSpec(
                module=source.module,
                symbol=source.symbol,
            ),
        )

        self._validate_plugin_definition(definition)

        if self._strict and definition.agent_id in self._agents:
            raise KeyError(f"Agent '{definition.agent_id}' is already registered.")

        self._store_definition(definition)

    def _compat_source_kind(self, definition: ExecutableDefinition) -> str:
        if definition.kind == ExecutableKind.REMOTE_HTTP:
            return "remote_http"

        spec = definition.invocation
        if isinstance(spec, PythonPluginInvocationSpec):
            if definition.legacy_source_kind == "instance":
                return "instance"
            return "python_import"

        return definition.kind.value

    def _compat_factory_type(self, definition: ExecutableDefinition) -> str:
        if definition.kind == ExecutableKind.REMOTE_HTTP:
            return "RemoteHttpInvoker"

        if definition.legacy_source_kind == "instance":
            return "InstanceAgentFactory"

        return "ClassAgentFactory"

    # ---------------------------------------------------------
    # METADATA
    # ---------------------------------------------------------
    def metadata(self, name: str) -> dict[str, str]:
        definition = self.get_definition(name)

        return {
            "agent_id": definition.agent_id,
            "namespace": definition.namespace or "",
            "version": definition.version or "",
            "is_builtin": str(definition.is_builtin),
            "source_kind": definition.source_kind,
            "source_ref": definition.legacy_source_ref,
            "factory_type": definition.factory_type,
        }
