from __future__ import annotations

import asyncio
import time

from anusara._contracts.agent import Agent
from anusara._contracts.agent_result import AgentResult
from anusara._contracts.execution_input import ExecutionInput
from anusara.api.errors import SimulatedHardKillError


class TestAgent(Agent):
    """
    Configurable test agent for deterministic execution scenarios.

    Supports simulation of:
    - success / failure outcomes
    - exceptions (soft failures)
    - hard kills (engine-level failures)
    - execution delays (timing / concurrency testing)

    Design:
    - Deterministic behavior controlled via constructor
    - Sync execution wrapped via asyncio.to_thread
    - Used extensively in unit and integration tests
    """

    def __init__(
        self,
        *,
        success: bool = True,
        output: str | None = None,
        errors: list[str] | None = None,
        confidence: float = 1.0,
        raise_error: bool = False,
        hard_kill: bool = False,
        delay: float = 0.0,
    ) -> None:
        self._success = success
        self._output = output
        self._errors = errors or []
        self._confidence = confidence
        self._raise_error = raise_error
        self._hard_kill = hard_kill
        self._delay = delay

    # ---------------------------------------------------------

    def _run(self, execution_input: ExecutionInput) -> AgentResult:
        """
        Internal synchronous execution path.

        This method is executed inside a thread when using the async interface.
        """

        if self._delay:
            time.sleep(self._delay)

        if self._hard_kill:
            raise SimulatedHardKillError("simulated crash")

        if self._raise_error:
            raise RuntimeError("boom")

        return AgentResult(
            success=self._success,
            output=self._output,
            errors=self._errors,
            confidence=self._confidence,
        )

    # ---------------------------------------------------------

    async def execute(self, execution_input: ExecutionInput) -> AgentResult:
        """
        Async execution entrypoint.

        Uses thread offloading to preserve deterministic blocking behavior
        while maintaining async compatibility.
        """
        return await asyncio.to_thread(self._run, execution_input)


# ============================================================
# Async Variant
# ============================================================


class AsyncTestAgent(TestAgent):
    """
    Fully async version of TestAgent.

    Avoids thread usage and uses asyncio-native delay.
    """

    async def execute(self, execution_input: ExecutionInput) -> AgentResult:
        if self._delay:
            await asyncio.sleep(self._delay)

        if self._hard_kill:
            raise SimulatedHardKillError("simulated crash")

        if self._raise_error:
            raise RuntimeError("boom")

        return AgentResult(
            success=self._success,
            output=self._output,
            errors=self._errors,
            confidence=self._confidence,
        )


# ============================================================
# Preconfigured Agents
# ============================================================


class SuccessAgent(TestAgent):
    """Always succeeds."""

    def __init__(self) -> None:
        super().__init__(success=True)


class FailureAgent(TestAgent):
    """Always fails."""

    def __init__(self) -> None:
        super().__init__(success=False)


class ExceptionAgent(TestAgent):
    """Raises a standard exception (soft failure)."""

    def __init__(self) -> None:
        super().__init__(raise_error=True)


class HardKillAgent(TestAgent):
    """Simulates engine-level hard kill."""

    def __init__(self) -> None:
        super().__init__(hard_kill=True)


class SlowAgent(TestAgent):
    """Synchronous delay-based agent."""

    def __init__(self, delay: float) -> None:
        super().__init__(success=True, delay=delay)


class AsyncSlowAgent(AsyncTestAgent):
    """Async delay-based agent."""

    def __init__(self, delay: float) -> None:
        super().__init__(success=True, delay=delay)


class HttpSlowAgent(SlowAgent):
    """
    Simulates HTTP-like latency with slightly reduced confidence.
    """

    def __init__(self, delay: float) -> None:
        super().__init__(delay)
        self._confidence = 0.9


class NamedAgent(TestAgent):
    """
    Agent with deterministic name-based output.

    Useful for:
    - validating execution ordering
    - asserting output propagation
    """

    def __init__(self, name: str, *, success: bool = True) -> None:
        output = f"{name}-ok" if success else f"{name}-failed"
        errors = [] if success else [f"{name}-failed"]

        super().__init__(
            success=success,
            output=output,
            errors=errors,
        )
