"""
Anusara testing utilities.

Provides deterministic test agents and helpers used across:

- Unit tests
- Integration tests
- Execution validation scenarios

Design Principles:
- Fully deterministic behavior
- Explicit simulation of success, failure, delay, and crash modes
- Support for both sync and async execution paths

These utilities form the foundation for validating
execution engine correctness, retry behavior,
and failure handling.
"""
