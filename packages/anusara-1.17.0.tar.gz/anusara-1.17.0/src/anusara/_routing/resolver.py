# anusara/_routing/resolver.py

from __future__ import annotations

from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_state import ExecutionState


class RoutingResolver:
    """
    Determines whether a node is eligible for execution.

    Responsibilities:
    - Evaluate dependency completion
    - Ensure upstream success conditions are met

    This is a pure read-only component:
    - No mutation
    - No side effects
    - Deterministic behavior
    """

    # ---------------------------------------------------------

    def dependencies_satisfied(
        self,
        graph: ExecutionGraph,
        state: ExecutionState,
        node_id: str,
    ) -> bool:
        """
        Check whether all dependencies of a node have completed successfully.
        """

        dependencies = graph.dependencies_of(node_id)

        for dep in dependencies:
            record = state.latest_record(dep)

            if record is None:
                return False

            if not record.result.success:
                return False

        return True
