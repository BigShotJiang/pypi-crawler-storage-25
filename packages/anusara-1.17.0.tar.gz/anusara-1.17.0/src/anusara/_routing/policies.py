# anusara/_routing/policies.py

from __future__ import annotations

from collections.abc import Sequence

from anusara._core.errors import MaxHopExceededError
from anusara._routing.context import ExecutionContext
from anusara._routing.errors import CircularRoutingError


class RoutingPolicy:
    """
    Base routing policy enforcing execution safety constraints.

    Responsibilities:
    - Prevent infinite traversal (max_hops)
    - Detect cycles (if disallowed)

    Design principles:
    - Deterministic evaluation
    - Stateless (derives decisions purely from context)
    """

    def __init__(
        self,
        allow_cycles: bool = False,
        max_hops: int = 100,
    ) -> None:
        if max_hops <= 0:
            raise ValueError("max_hops must be greater than 0.")

        self.allow_cycles = allow_cycles
        self.max_hops = max_hops

    # ---------------------------------------------------------

    def validate(self, context: ExecutionContext) -> None:
        """
        Validate routing constraints against the current context.

        Raises:
            MaxHopExceededError
            CircularRoutingError
        """

        # Max hops guard
        if context.current_hop >= self.max_hops:
            raise MaxHopExceededError(self.max_hops)

        # Cycle detection
        if not self.allow_cycles:
            if len(context.trace) != len(set(context.trace)):
                node_id = context.trace[-1] if context.trace else "unknown"
                raise CircularRoutingError(node_id)


# ============================================================
# Composite Policy
# ============================================================


class CompositeRoutingPolicy(RoutingPolicy):
    """
    Composes multiple routing policies.

    Each policy is evaluated independently in sequence.
    All must pass for validation to succeed.
    """

    def __init__(
        self,
        policies: Sequence[RoutingPolicy] | None = None,
    ) -> None:
        # No need to inherit base config (composite delegates)
        self.policies: list[RoutingPolicy] = list(policies) if policies else []

    # ---------------------------------------------------------

    def validate(self, context: ExecutionContext) -> None:
        for policy in self.policies:
            policy.validate(context)
