# anusara/_routing/graph_compiler.py

from __future__ import annotations

from typing import TYPE_CHECKING

from anusara._contracts.graph_definition import GraphDefinition
from anusara._routing.errors import ResolutionError
from anusara._routing.execution_graph import ExecutionGraph, ExecutionNode

if TYPE_CHECKING:
    from anusara._contracts.execution_request import ExecutionRequest


# =========================================================
# Graph Compiler
# =========================================================


class GraphCompiler:
    """
    Compiles ExecutionRequest into a validated ExecutionGraph.

    Responsibilities:
    - Normalize graph definition (implicit + explicit nodes)
    - Inject synthetic root
    - Ensure entry node connectivity
    - Enforce structural invariants
    - Produce deterministic topological ordering

    Output is a frozen, execution-ready graph.
    """

    SYNTHETIC_ROOT = "__root__"

    # ---------------------------------------------------------

    def compile(self, request: ExecutionRequest) -> ExecutionGraph:
        graph = ExecutionGraph()

        # ---------------------------------------------------------
        # 1️⃣ Synthetic root
        # ---------------------------------------------------------
        graph.add_node(
            ExecutionNode(
                id=self.SYNTHETIC_ROOT,
                agent=None,
            )
        )

        # ---------------------------------------------------------
        # 2️⃣ Declarative graph
        # ---------------------------------------------------------
        if request.graph_definition is not None:
            self._compile_declarative(graph, request.graph_definition)

        # ---------------------------------------------------------
        # 3️⃣ Entry nodes
        # ---------------------------------------------------------
        for entry in request.entry_nodes:
            if entry not in graph.nodes:
                graph.add_node(
                    ExecutionNode(
                        id=entry,
                        agent=entry,
                    )
                )

            graph.add_edge(self.SYNTHETIC_ROOT, entry)

        # ---------------------------------------------------------
        # 4️⃣ Structural validation (centralized)
        # ---------------------------------------------------------
        graph.validate_structure(self.SYNTHETIC_ROOT)

        # ---------------------------------------------------------
        # 5️⃣ Deterministic ordering + freeze
        # ---------------------------------------------------------
        graph.assign_topological_order()
        graph.freeze()

        return graph

    # ---------------------------------------------------------
    # Declarative Graph Compilation
    # ---------------------------------------------------------

    def _compile_declarative(
        self,
        graph: ExecutionGraph,
        definition: GraphDefinition,
    ) -> None:

        # -----------------------------
        # Nodes
        # -----------------------------
        for node_def in definition.get("nodes", []):
            node_id: str = node_def["id"]
            agent: str = node_def.get("agent", node_id)
            metadata: dict[str, object] = node_def.get("metadata", {})

            graph.add_node(
                ExecutionNode(
                    id=node_id,
                    agent=agent,
                    metadata=metadata,
                )
            )

        # -----------------------------
        # Edges
        # -----------------------------
        for edge in definition.get("edges", []):
            if isinstance(edge, (tuple, list)):
                from_node, to_node = edge

            elif isinstance(edge, dict):
                try:
                    from_node = edge["source"]
                    to_node = edge["target"]
                except KeyError as err:
                    raise ResolutionError(
                        str(edge),
                        "Invalid edge definition (missing source/target)",
                    ) from err
            else:
                raise ResolutionError(
                    str(edge),
                    "Unsupported edge format",
                )

            # Implicit node creation
            if from_node not in graph.nodes:
                graph.add_node(ExecutionNode(id=from_node, agent=from_node))

            if to_node not in graph.nodes:
                graph.add_node(ExecutionNode(id=to_node, agent=to_node))

            graph.add_edge(from_node, to_node)
