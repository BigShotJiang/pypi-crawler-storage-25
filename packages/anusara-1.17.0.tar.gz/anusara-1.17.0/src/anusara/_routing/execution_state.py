# anusara/_routing/execution_state.py

from __future__ import annotations

import pickle
import threading
import uuid
from datetime import datetime
from typing import TypedDict, cast

from anusara._aggregation.mode import AggregationMode
from anusara._contracts.agent_result import AgentResult
from anusara._contracts.execution_request import ExecutionRequest
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_record import ExecutionRecord
from anusara._utils.time import utc_now


class _ExecutionStateSnapshot(TypedDict):
    _graph: ExecutionGraph
    execution_request: ExecutionRequest | None
    request_id: str
    _records: dict[str, list[ExecutionRecord]]
    _started_at: datetime | None
    _completed_at: datetime | None
    paused_at: datetime | None
    _open_attempts: dict[tuple[str, int], datetime]


class ExecutionState:
    """
    Runtime state container for a single execution.

    Responsibilities:
    - Track execution lifecycle (start, pause, complete)
    - Maintain per-node execution records
    - Support deterministic aggregation
    - Enable snapshot/restore for replay and persistence

    Design guarantees:
    - Thread-safe mutations
    - Append-only record history
    - Replay-safe serialization
    """

    execution_request: ExecutionRequest | None
    request_id: str

    def __init__(
        self,
        graph: ExecutionGraph,
        execution_request: ExecutionRequest | None = None,
    ) -> None:
        self._graph = graph

        if execution_request is not None:
            self.execution_request = execution_request
            self.request_id = execution_request.request_id
        else:
            self.execution_request = None
            self.request_id = f"test-{uuid.uuid4()}"

        self._records: dict[str, list[ExecutionRecord]] = {}
        self._lock = threading.Lock()

        self._started_at: datetime | None = None
        self._completed_at: datetime | None = None
        self.paused_at: datetime | None = None
        self._sequence_counter: int = 0

        self._open_attempts: dict[tuple[str, int], datetime] = {}

    # ---------------------------------------------------------
    # Execution lifecycle
    # ---------------------------------------------------------

    @property
    def started_at(self) -> datetime | None:
        return self._started_at

    @property
    def completed_at(self) -> datetime | None:
        return self._completed_at

    def mark_started(self, at: datetime | None = None) -> None:
        with self._lock:
            if self._started_at is not None:
                return
            self._started_at = at or utc_now()

    def mark_completed(self, at: datetime | None = None) -> None:
        with self._lock:
            if self._completed_at is not None:
                return
            if self.paused_at is not None:
                raise RuntimeError("Cannot complete while paused")
            self._completed_at = at or utc_now()

    def mark_paused(self, at: datetime | None = None) -> None:
        with self._lock:
            if self._started_at is None:
                raise RuntimeError("Cannot pause before execution starts")
            if self._completed_at is not None:
                raise RuntimeError("Cannot pause after completion")
            self.paused_at = at or utc_now()

    # ---------------------------------------------------------
    # Record management (internal only)
    # ---------------------------------------------------------

    def _append_internal(self, record: ExecutionRecord) -> None:
        with self._lock:
            existing = self._records.get(record.node_id, [])

            for prior in existing:
                if prior.attempt != record.attempt:
                    continue

                if prior == record:
                    return

                raise RuntimeError(
                    f"Conflicting execution record for node '{record.node_id}' "
                    f"attempt {record.attempt}"
                )

            self._records.setdefault(record.node_id, []).append(record)

    # ---------------------------------------------------------

    def latest_record(self, node_id: str) -> ExecutionRecord | None:
        with self._lock:
            records = self._records.get(node_id)
            return records[-1] if records else None

    def records_for(self, node_id: str) -> list[ExecutionRecord]:
        with self._lock:
            return list(self._records.get(node_id, []))

    def all_records(self) -> list[ExecutionRecord]:
        with self._lock:
            records: list[ExecutionRecord] = []
            for node_records in self._records.values():
                records.extend(node_records)
            return records

    # ---------------------------------------------------------
    # Aggregation
    # ---------------------------------------------------------

    def aggregate_node(
        self,
        node_id: str,
        mode: AggregationMode,
    ) -> AgentResult | None:
        records = self.records_for(node_id)

        if not records:
            return None

        latest = records[-1]

        if mode == AggregationMode.LATEST_ONLY:
            return latest.result

        if mode == AggregationMode.STRICT_ATTEMPT:
            ever_failed = any(not r.result.success for r in records)

            return AgentResult(
                success=not ever_failed,
                output=latest.result.output,
                errors=latest.result.errors,
                confidence=latest.result.confidence,
                metadata={
                    **(latest.result.metadata or {}),
                    "strict_attempt": True,
                    "attempts": len(records),
                    "had_failures": ever_failed,
                },
            )

        if mode == AggregationMode.SUCCESS_ONLY:
            for r in reversed(records):
                if r.result.success:
                    return r.result
            return latest.result

        if mode == AggregationMode.ALL_ATTEMPTS:
            return latest.result

        if mode == AggregationMode.EXCLUDE_FORCED:
            filtered = [r for r in records if not r.forced]
            return filtered[-1].result if filtered else latest.result

        raise ValueError(f"Unsupported aggregation mode: {mode}")

    # ---------------------------------------------------------
    # Attempt tracking (used by reducer)
    # ---------------------------------------------------------

    def _register_attempt_start(
        self,
        node_id: str,
        attempt: int,
        timestamp: datetime,
    ) -> None:
        with self._lock:
            self._open_attempts[(node_id, attempt)] = timestamp

    def _pop_attempt_start(
        self,
        node_id: str,
        attempt: int,
    ) -> datetime | None:
        with self._lock:
            return self._open_attempts.pop((node_id, attempt), None)

    # ---------------------------------------------------------

    @property
    def is_paused(self) -> bool:
        with self._lock:
            return self.paused_at is not None and self._completed_at is None

    # ---------------------------------------------------------
    # Snapshot / Restore
    # ---------------------------------------------------------

    def snapshot(self) -> bytes:
        """
        Serialize execution state for persistence.

        Note:
        Uses pickle — safe only for trusted environments.
        """
        return pickle.dumps(self)

    @staticmethod
    def restore(snapshot: bytes) -> ExecutionState:
        return cast(ExecutionState, pickle.loads(snapshot))

    # ---------------------------------------------------------
    # Pickle lifecycle hooks
    # ---------------------------------------------------------

    def __getstate__(self) -> _ExecutionStateSnapshot:
        return {
            "_graph": self._graph,
            "execution_request": self.execution_request,
            "request_id": self.request_id,
            "_records": self._records,
            "_started_at": self._started_at,
            "_completed_at": self._completed_at,
            "paused_at": self.paused_at,
            "_open_attempts": self._open_attempts,
        }

    def __setstate__(self, state: _ExecutionStateSnapshot) -> None:
        self._graph = state["_graph"]
        self.execution_request = state["execution_request"]
        self.request_id = state["request_id"]
        self._records = state["_records"]
        self._started_at = state["_started_at"]
        self._completed_at = state["_completed_at"]
        self.paused_at = state["paused_at"]
        self._open_attempts = state["_open_attempts"]
        self._lock = threading.Lock()

    def add_record(self, node_id: str, record: ExecutionRecord) -> None:
        self._append_internal(record)

    def next_sequence_number(self) -> int:
        self._sequence_counter += 1
        return self._sequence_counter

    def append_root_reexecution(self) -> None:
        records = self._records.setdefault("root", [])
        attempt = len(records) + 1

        record = ExecutionRecord(
            node_id="root",
            attempt=attempt,
            sequence_number=attempt,
            result=AgentResult(
                success=True,
                output=None,
                errors=[],
                confidence=1.0,
                metadata={},
            ),
            started_at=utc_now(),
            completed_at=utc_now(),
            forced=True,
        )

        records.append(record)

    def clear_paused(self) -> None:
        with self._lock:
            self.paused_at = None
