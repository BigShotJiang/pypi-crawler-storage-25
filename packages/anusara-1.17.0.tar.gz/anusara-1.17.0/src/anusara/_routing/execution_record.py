# anusara/_routing/execution_record.py

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

# ✅ FIX: add this import
from anusara._contracts.agent_result import AgentResult


@dataclass(frozen=True)
class ExecutionRecord:
    """
    Immutable record of a single node execution attempt.

    Responsibilities:
    - Capture outcome (AgentResult)
    - Preserve deterministic ordering (sequence_number)
    - Provide timing information for observability

    Design guarantees:
    - Immutable (safe for replay and sharing)
    - Deterministic ordering via sequence_number
    - Timing data is observational (not used for logic)

    Notes:
    - sequence_number is assigned from ExecutionGraph.topo_index
    - forced=True indicates execution outside normal scheduling
    """

    node_id: str
    result: AgentResult
    attempt: int

    # Deterministic logical ordering (compile-time)
    sequence_number: int

    # Runtime observability
    started_at: datetime
    completed_at: datetime

    forced: bool = False

    # -----------------------------------------------------

    @property
    def duration_seconds(self) -> float:
        """
        Execution duration in seconds.
        """
        return (self.completed_at - self.started_at).total_seconds()

    @property
    def duration_ms(self) -> float:
        """
        Execution duration in milliseconds.
        """
        return self.duration_seconds * 1000
