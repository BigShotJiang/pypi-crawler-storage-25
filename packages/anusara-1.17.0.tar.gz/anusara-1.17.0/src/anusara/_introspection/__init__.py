"""
Execution introspection utilities for Anusara.

This module provides read-only access to execution state and lifecycle data,
enabling inspection, analysis, and visualization of orchestration behavior.

It includes:
- execution snapshots
- projection and transformation utilities
- introspection modes and views

Design principles:
- strictly read-only (no mutation of execution state)
- deterministic and replay-safe
- decoupled from execution engine internals

This layer powers debugging, observability, and developer tooling.

⚠️ Not part of the core execution path.
⚠️ Intended for inspection and analysis only.
"""
