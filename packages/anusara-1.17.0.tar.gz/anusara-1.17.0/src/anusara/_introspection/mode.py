from enum import StrEnum


class SnapshotMode(StrEnum):
    """
    Controls how execution history is represented
    in an ExecutionSnapshot.

    Modes:
    - FULL_HISTORY: includes all attempts for each node
    - FINAL_ONLY: includes only the final attempt per node
    """

    FULL_HISTORY = "full_history"
    FINAL_ONLY = "final_only"
