from typing import cast

from anusara._contracts.json_types import JSONValue
from anusara._introspection.execution_snapshot import ExecutionSnapshot

SNAPSHOT_PROJECTION_VERSION = "1.0"


def snapshot_to_projection(snapshot: ExecutionSnapshot) -> dict[str, JSONValue]:
    records_list: list[dict[str, JSONValue]] = []

    for node_id, attempts in snapshot.records.items():
        for attempt in attempts:
            records_list.append(
                {
                    "node_id": node_id,
                    "attempt": attempt.attempt,
                    "sequence_number": attempt.sequence_number,
                    "success": attempt.result.success,
                    "confidence": attempt.result.confidence,
                    "metadata": cast(JSONValue, attempt.result.metadata),
                    "forced": attempt.forced,
                }
            )

    # preserve deterministic ordering for projection consumers
    records_list.sort(
        key=lambda r: (
            cast(str, r["node_id"]),
            cast(int, r["attempt"]),
        )
    )

    return {
        "schema_version": SNAPSHOT_PROJECTION_VERSION,
        "request_id": snapshot.request_id,
        "overall_success": snapshot.overall_success,
        "confidence": snapshot.confidence,
        "started_at": (
            snapshot.started_at.isoformat() if snapshot.started_at else None
        ),
        "completed_at": (
            snapshot.completed_at.isoformat() if snapshot.completed_at else None
        ),
        "records": cast(JSONValue, records_list),
    }
