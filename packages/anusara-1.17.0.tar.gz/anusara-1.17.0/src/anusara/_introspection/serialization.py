from dataclasses import asdict
from datetime import datetime
from typing import cast

from typing_extensions import TypedDict

from anusara._contracts.agent_result import AgentResult
from anusara._contracts.events import EventRegistry, OrchestrationEvent
from anusara._contracts.json_types import JSONValue
from anusara._introspection.execution_snapshot import (
    AttemptSnapshot,
    ExecutionSnapshot,
)


# =========================================================
# Serialized Contracts
# =========================================================
class SerializedAgentResult(TypedDict):
    success: bool
    output: JSONValue | None
    errors: list[str]
    confidence: float
    metadata: dict[str, JSONValue] | None


class SerializedAttemptSnapshot(TypedDict):
    attempt: int
    sequence_number: int
    forced: bool
    started_at: str | None
    completed_at: str | None
    result: SerializedAgentResult


class SerializedSnapshot(TypedDict):
    schema_version: str
    request_id: str
    overall_success: bool
    confidence: float
    started_at: str | None
    completed_at: str | None
    records: dict[str, list[SerializedAttemptSnapshot]]
    scenario: dict[str, JSONValue] | None


# =========================================================
# Snapshot Serializer
# =========================================================


class ExecutionSnapshotSerializer:
    @staticmethod
    def _serialize_datetime(value: datetime | None) -> str | None:
        return value.isoformat() if value else None

    @staticmethod
    def _deserialize_datetime(value: str | None) -> datetime | None:
        if not value:
            return None
        try:
            return datetime.fromisoformat(value)
        except ValueError:
            return None

    # -----------------------------------------------------
    # AgentResult
    # -----------------------------------------------------

    @staticmethod
    def _serialize_result(result: AgentResult) -> SerializedAgentResult:
        return {
            "success": result.success,
            "output": result.output,
            "errors": result.errors,
            "confidence": result.confidence,
            "metadata": result.metadata,
        }

    @staticmethod
    def _deserialize_result(
        data: SerializedAgentResult,
    ) -> AgentResult:
        return AgentResult(
            success=data["success"],
            output=data.get("output"),
            errors=data["errors"],
            confidence=data["confidence"],
            metadata=data["metadata"] or {},
        )

    # -----------------------------------------------------
    # Snapshot Serialization
    # -----------------------------------------------------

    @classmethod
    def snapshot_to_dict(
        cls,
        snapshot: ExecutionSnapshot,
    ) -> SerializedSnapshot:
        return {
            "schema_version": "1.0",
            "request_id": snapshot.request_id,
            "started_at": cls._serialize_datetime(snapshot.started_at),
            "completed_at": cls._serialize_datetime(snapshot.completed_at),
            "overall_success": snapshot.overall_success,
            "confidence": snapshot.confidence,
            "records": {
                node_id: [
                    {
                        "attempt": attempt.attempt,
                        "sequence_number": attempt.sequence_number,
                        "forced": attempt.forced,
                        "started_at": cls._serialize_datetime(attempt.started_at),
                        "completed_at": cls._serialize_datetime(attempt.completed_at),
                        "result": cls._serialize_result(attempt.result),
                    }
                    for attempt in attempts
                ]
                for node_id, attempts in snapshot.records.items()
                if node_id != "__root__"
            },
            "scenario": snapshot.scenario.to_dict() if snapshot.scenario else None,
        }

    # -----------------------------------------------------
    # Snapshot Deserialization
    # -----------------------------------------------------

    @classmethod
    def snapshot_from_dict(
        cls,
        data: SerializedSnapshot,
    ) -> ExecutionSnapshot:
        records: dict[str, list[AttemptSnapshot]] = {}

        for node_id, attempts_data in data["records"].items():
            attempts: list[AttemptSnapshot] = []

            for attempt_data in attempts_data:
                attempts.append(
                    AttemptSnapshot(
                        attempt=attempt_data["attempt"],
                        sequence_number=attempt_data["sequence_number"],
                        forced=attempt_data["forced"],
                        started_at=cls._deserialize_datetime(
                            attempt_data["started_at"]
                        ),
                        completed_at=cls._deserialize_datetime(
                            attempt_data["completed_at"]
                        ),
                        result=cls._deserialize_result(attempt_data["result"]),
                    )
                )

            records[node_id] = attempts

        return ExecutionSnapshot(
            request_id=data["request_id"],
            started_at=cls._deserialize_datetime(data["started_at"]),
            completed_at=cls._deserialize_datetime(data["completed_at"]),
            records=records,
            overall_success=data["overall_success"],
            confidence=data["confidence"],
        )


# =========================================================
# Event Serializer (Controlled Dynamic Boundary)
# =========================================================


class EventSerializer:
    """
    Generic event serializer.
    Produces JSON-safe dictionaries.
    """

    @staticmethod
    def _serialize(value: object) -> JSONValue:
        if isinstance(value, datetime):
            return value.isoformat()

        if isinstance(value, Exception):
            return str(value)

        if isinstance(value, dict):
            return {
                str(k): EventSerializer._serialize(v)
                for k, v in cast(dict[object, object], value).items()
            }

        if isinstance(value, list):
            return [EventSerializer._serialize(v) for v in value]

        if isinstance(value, tuple):
            return [EventSerializer._serialize(v) for v in value]

        return cast(JSONValue, value)

    @staticmethod
    def to_dict(event: OrchestrationEvent) -> dict[str, JSONValue]:
        raw = cast(dict[str, object], asdict(event))
        serialized = EventSerializer._serialize(raw)

        if not isinstance(serialized, dict):
            raise TypeError("Serialized event must be dict")

        serialized["event_type"] = event.event_type
        return serialized

    @staticmethod
    def _deserialize(value: JSONValue) -> object:
        if isinstance(value, str):
            try:
                return datetime.fromisoformat(value)
            except ValueError:
                return value

        if isinstance(value, dict):
            return {k: EventSerializer._deserialize(v) for k, v in value.items()}

        if isinstance(value, list):
            return [EventSerializer._deserialize(v) for v in value]

        return value

    @staticmethod
    def from_dict(data: dict[str, JSONValue]) -> OrchestrationEvent:
        event_type_obj = data.get("event_type")

        if not isinstance(event_type_obj, str):
            raise ValueError("Invalid or missing event_type")

        event_cls: type[OrchestrationEvent] = EventRegistry.resolve(event_type_obj)

        payload_raw = {k: v for k, v in data.items() if k != "event_type"}

        payload = EventSerializer._deserialize(payload_raw)

        return event_cls(**payload)  # type: ignore[arg-type]
