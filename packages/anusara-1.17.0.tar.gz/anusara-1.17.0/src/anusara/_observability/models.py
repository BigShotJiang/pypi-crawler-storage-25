# anusara/_observability/models.py

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol

from anusara._utils.time import utc_now

# ---------------------------------------------------------
# Internal helper
# ---------------------------------------------------------


def _utc_now() -> datetime:
    return utc_now()


# ---------------------------------------------------------
# Metric Model
# ---------------------------------------------------------


@dataclass
class Metric:
    """
    Represents a single numeric measurement.

    Examples:
    - execution_duration_ms
    - node_success_count
    - failure_rate
    """

    name: str
    value: float

    timestamp: datetime = field(default_factory=_utc_now)
    tags: dict[str, str] = field(default_factory=dict)


# ---------------------------------------------------------
# Trace Model
# ---------------------------------------------------------


@dataclass
class Trace:
    """
    Represents a trace event in execution flow.

    Typically used for:
    - node lifecycle tracking
    - execution tracing
    - debugging timelines

    `event` should be a semantic label
    (e.g., "node_started", "node_completed")
    """

    request_id: str
    node_id: str
    event: str

    timestamp: datetime = field(default_factory=_utc_now)
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------
# Exporter Contracts
# ---------------------------------------------------------


class MetricsExporter(Protocol):
    """
    Contract for exporting metrics to external systems.
    """

    def export(self, metric: Metric) -> None: ...


class TraceExporter(Protocol):
    """
    Contract for exporting traces to external systems.
    """

    def export(self, trace: Trace) -> None: ...
