# anusara/_observability/diagnostics_observer.py

from typing import Any

from anusara._contracts.events import (
    ExecutionCompleted,
    ExecutionFailed,
    ExecutionStarted,
    NodeExecutionCompleted,
    OrchestrationEvent,
)
from anusara._observability.diagnostics import ExecutionDiagnostics
from anusara._observability.observer import ExecutionObserver


class DiagnosticsObserver(ExecutionObserver):
    """
    Tracks execution-level diagnostics using typed events.

    Responsibilities:
    - track success/failure counts per execution
    - maintain lightweight execution summary
    - provide snapshot view for observability

    Characteristics:
    - event-driven
    - non-intrusive (read-only)
    - best-effort tracking (tolerates missing events)
    """

    def __init__(self) -> None:
        self._executions: dict[str, ExecutionDiagnostics] = {}

    # ---------------------------------------------------------

    def on_event(self, event: OrchestrationEvent) -> None:

        # -------------------------------------------------
        # Execution start
        # -------------------------------------------------

        if isinstance(event, ExecutionStarted):
            self._executions[event.request_id] = ExecutionDiagnostics(
                request_id=event.request_id
            )

        # -------------------------------------------------
        # Node completion
        # -------------------------------------------------

        elif isinstance(event, NodeExecutionCompleted):
            diag = self._executions.get(event.request_id)
            if not diag:
                return

            if event.success:
                diag.record_success()
            else:
                diag.record_failure()

        # -------------------------------------------------
        # Execution completed / failed
        # -------------------------------------------------

        elif isinstance(event, (ExecutionCompleted, ExecutionFailed)):
            diag = self._executions.get(event.request_id)
            if not diag:
                return

            diag.mark_completed()

    # ---------------------------------------------------------

    def snapshot(self, request_id: str) -> dict[str, Any] | None:
        """
        Returns diagnostic snapshot for a given execution.
        """
        diag = self._executions.get(request_id)
        return diag.snapshot() if diag else None
