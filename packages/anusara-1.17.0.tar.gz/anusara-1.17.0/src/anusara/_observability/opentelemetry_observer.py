# anusara/_observability/opentelemetry_observer.py

from __future__ import annotations

from typing import Any

# ---------------------------------------------------------
# Optional OpenTelemetry imports (guarded)
# ---------------------------------------------------------

try:
    from opentelemetry import trace
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import (
        ConsoleSpanExporter,
        SimpleSpanProcessor,
        SpanExporter,
    )
    from opentelemetry.semconv.resource import ResourceAttributes
    from opentelemetry.trace import Status, StatusCode

    OTEL_AVAILABLE = True

except ImportError:  # pragma: no cover - optional dependency
    OTEL_AVAILABLE = False


# ---------------------------------------------------------
# Internal imports
# ---------------------------------------------------------

from anusara._contracts.events import (
    ExecutionCompleted,
    ExecutionFailed,
    ExecutionStarted,
    NodeExecutionCompleted,
    NodeExecutionStarted,
    OrchestrationEvent,
)
from anusara._observability.observer import ExecutionObserver

# ---------------------------------------------------------
# Observer Implementation
# ---------------------------------------------------------


class OpenTelemetryObserver(ExecutionObserver):
    """
    OpenTelemetry-based execution observer.

    Emits:
    - execution spans (root)
    - node spans (child)

    Supports:
    - OTLP exporter (production)
    - Console exporter (local/debug)
    """

    def __init__(
        self,
        service_name: str = "anusara",
        otlp_endpoint: str | None = None,
    ) -> None:

        # ---------------------------------------------------------
        # Define attributes ONCE (typed)
        # ---------------------------------------------------------

        self._enabled: bool = False
        self._tracer: Any = None
        self._execution_spans: dict[str, Any] = {}
        self._node_spans: dict[tuple[str, str], Any] = {}

        # ---------------------------------------------------------
        # Optional dependency handling
        # ---------------------------------------------------------

        if not OTEL_AVAILABLE:
            return

        self._enabled = True

        # ---------------------------------------------------------
        # Setup OpenTelemetry
        # ---------------------------------------------------------

        resource = Resource.create(
            {
                ResourceAttributes.SERVICE_NAME: service_name,
            }
        )

        provider = TracerProvider(resource=resource)

        if otlp_endpoint:
            exporter: SpanExporter = OTLPSpanExporter(
                endpoint=otlp_endpoint,
                insecure=True,
            )
        else:
            exporter = ConsoleSpanExporter()

        provider.add_span_processor(SimpleSpanProcessor(exporter))

        # Avoid overriding global provider if already set
        if not isinstance(trace.get_tracer_provider(), TracerProvider):
            trace.set_tracer_provider(provider)

        self._tracer = trace.get_tracer("anusara.tracer")

    # ---------------------------------------------------------

    def on_event(self, event: OrchestrationEvent) -> None:
        if not self._enabled:
            return

        if isinstance(event, ExecutionStarted):
            self._on_execution_started(event)

        elif isinstance(event, ExecutionCompleted):
            self._on_execution_completed(event)

        elif isinstance(event, ExecutionFailed):
            self._on_execution_failed(event)

        elif isinstance(event, NodeExecutionStarted):
            self._on_node_execution_started(event)

        elif isinstance(event, NodeExecutionCompleted):
            self._on_node_execution_completed(event)

    # ---------------------------------------------------------

    def _on_execution_started(self, event: ExecutionStarted) -> None:
        if not self._enabled or self._tracer is None:
            return

        span = self._tracer.start_span(name=f"Execution:{event.request_id}")

        span.set_attribute("request_id", event.request_id)

        entry_nodes = event.execution_request.get("entry_nodes", [])
        span.set_attribute("entry_nodes", str(entry_nodes))

        self._execution_spans[event.request_id] = span

    # ---------------------------------------------------------

    def _on_execution_completed(self, event: ExecutionCompleted) -> None:
        span = self._execution_spans.pop(event.request_id, None)
        if not span:
            return

        span.set_attribute("success", event.success)
        span.set_attribute("total_nodes", event.total_nodes)

        span.end()

    # ---------------------------------------------------------

    def _on_execution_failed(self, event: ExecutionFailed) -> None:
        span = self._execution_spans.pop(event.request_id, None)
        if not span:
            return

        span.record_exception(Exception(event.error))
        span.set_status(Status(StatusCode.ERROR))

        span.end()

    # ---------------------------------------------------------

    def _on_node_execution_started(self, event: NodeExecutionStarted) -> None:
        if not self._enabled or self._tracer is None:
            return

        parent_span = self._execution_spans.get(event.request_id)
        if not parent_span:
            return

        span = self._tracer.start_span(
            name=f"Node:{event.node_id}",
            context=trace.set_span_in_context(parent_span),
        )

        span.set_attribute("node_id", event.node_id)
        span.set_attribute("agent", event.agent)
        span.set_attribute("attempt", event.attempt)

        self._node_spans[(event.request_id, event.node_id)] = span

    # ---------------------------------------------------------

    def _on_node_execution_completed(self, event: NodeExecutionCompleted) -> None:
        key = (event.request_id, event.node_id)

        span = self._node_spans.pop(key, None)
        if not span:
            return

        span.set_attribute("success", event.success)
        span.set_attribute("confidence", event.confidence)

        if not event.success:
            span.set_status(Status(StatusCode.ERROR))

        span.end()
