# anusara/_observability/file_event_log.py

import json
from collections.abc import Iterator
from pathlib import Path

from anusara._contracts.event_log import ExecutionEventLog
from anusara._contracts.events import OrchestrationEvent
from anusara._introspection.serialization import EventSerializer


class FileExecutionEventLog(ExecutionEventLog):
    """
    File-backed event log using JSON Lines format.

    Characteristics:
    - append-only (immutable history)
    - replay-safe
    - human-readable
    - resilient to partial/corrupt lines (best-effort)

    Each line = one serialized event.
    """

    def __init__(self, file_path: str) -> None:
        self._file_path = Path(file_path)

        # Ensure file exists
        self._file_path.touch(exist_ok=True)

    # ---------------------------------------------------------

    def append(self, event: OrchestrationEvent) -> None:
        """
        Append a single event to the log.
        """
        with self._file_path.open("a", encoding="utf-8") as f:
            json.dump(EventSerializer.to_dict(event), f)
            f.write("\n")
            f.flush()

    # ---------------------------------------------------------

    def read_all(self) -> list[OrchestrationEvent]:
        """
        Read all events into memory.
        """
        return list(self.stream())

    # ---------------------------------------------------------

    def read_by_request(self, request_id: str) -> list[OrchestrationEvent]:
        """
        Filter events by request_id.
        """
        return [
            event
            for event in self.stream()
            if getattr(event, "request_id", None) == request_id
        ]

    # ---------------------------------------------------------

    def stream(self) -> Iterator[OrchestrationEvent]:
        """
        Stream events lazily from file.

        Skips invalid/corrupt lines (best-effort resilience).
        """
        with self._file_path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()

                if not line:
                    continue

                try:
                    data = json.loads(line)
                    yield EventSerializer.from_dict(data)
                except Exception:
                    # Skip corrupt lines (important for durability)
                    continue

    # ---------------------------------------------------------

    def iter(self) -> Iterator[OrchestrationEvent]:
        """
        Alias for stream() (contract compatibility).
        """
        return self.stream()

    # ---------------------------------------------------------

    def clear(self) -> None:
        """
        Clear the log (destructive operation).
        """
        self._file_path.write_text("", encoding="utf-8")
