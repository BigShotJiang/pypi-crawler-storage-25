"""
Internal module: cli_internal.

Provides developer-oriented inspection and debugging utilities
used by CLI and tooling layers.

Not part of the public API.
"""
