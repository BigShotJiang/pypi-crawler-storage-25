from anusara._routing.execution_state import ExecutionState
from anusara.api import ExecutionRequest


def inspect_execution(
    request: ExecutionRequest,
    state: ExecutionState,
) -> None:

    from anusara._debug.execution_debugger import ExecutionDebugger
    from anusara._debug.execution_graph_visualizer import ExecutionGraphVisualizer

    visualizer = ExecutionGraphVisualizer(request, state)

    print("Execution Graph (DOT)")
    print("---------------------")
    print(visualizer.to_dot())

    debugger = ExecutionDebugger(state)

    print("\nExecution Timeline")
    print("------------------")

    while debugger.has_next():
        r = debugger.step()
        print(r.sequence_number, r.node_id, r.result.success)
