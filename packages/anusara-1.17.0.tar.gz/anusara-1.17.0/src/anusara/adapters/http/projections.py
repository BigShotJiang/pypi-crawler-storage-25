from __future__ import annotations

from datetime import datetime
from typing import cast

from anusara._contracts.agent_schema_descriptor import AgentSchemaDescriptor
from anusara._contracts.json_types import JSONValue
from anusara._registry.executable_definition import ExecutableDefinition
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState
from anusara._routing.graph_compiler import GraphCompiler
from anusara._runtime.circuit_breaker_event import CircuitBreakerEvent
from anusara._runtime.circuit_breaker_state import CircuitBreakerState
from anusara.adapters.http.schemas import (
    AgentSchemaDescriptorSchema,
    RegisteredAgentSchema,
    RegisteredAgentsData,
)
from anusara.adapters.http.schemas_observability import (
    CircuitBreakerEventSchema,
    CircuitBreakerEventsResponse,
    CircuitBreakerStateSchema,
    CircuitBreakerStatesResponse,
)
from anusara.adapters.http.schemas_trace import (
    ExecutionTraceResponse,
    TraceNodeSchema,
)


def _descriptor_fields(
    descriptor: AgentSchemaDescriptor | None,
) -> tuple[str | None, dict[str, object] | None, dict[str, object] | None, list[str]]:
    if descriptor is None:
        return None, None, None, []

    return (
        descriptor.description,
        cast(dict[str, object] | None, descriptor.input_schema),
        cast(dict[str, object] | None, descriptor.output_schema),
        list(descriptor.capabilities),
    )


def to_agent_schema_descriptor_schema(
    definition: ExecutableDefinition,
    descriptor: AgentSchemaDescriptor | None,
) -> AgentSchemaDescriptorSchema:
    description, input_schema, output_schema, capabilities = _descriptor_fields(
        descriptor
    )

    return AgentSchemaDescriptorSchema(
        agent_id=definition.agent_id,
        version=definition.version,
        description=description,
        input_schema=input_schema,
        output_schema=output_schema,
        capabilities=capabilities,
    )


def to_registered_agent_schema(
    definition: ExecutableDefinition,
    descriptor: AgentSchemaDescriptor | None,
) -> RegisteredAgentSchema:
    description, _, _, capabilities = _descriptor_fields(descriptor)

    return RegisteredAgentSchema(
        agent_id=definition.agent_id,
        namespace=definition.namespace,
        version=definition.version,
        is_builtin=definition.is_builtin,
        source_kind=definition.source_kind,
        source_ref=definition.legacy_source_ref,
        factory_type=definition.factory_type,
        description=description,
        capabilities=capabilities,
    )


def to_registered_agents_data(
    definitions: list[ExecutableDefinition],
    descriptors: dict[str, AgentSchemaDescriptor | None],
) -> RegisteredAgentsData:
    return RegisteredAgentsData(
        registered=[
            to_registered_agent_schema(d, descriptors.get(d.agent_id))
            for d in definitions
        ]
    )


def to_circuit_breaker_state_schema(
    key: str,
    state: CircuitBreakerState,
) -> CircuitBreakerStateSchema:
    return CircuitBreakerStateSchema(
        key=key,
        state=state.state.value,
        consecutive_failures=state.consecutive_failures,
        opened_at_monotonic=state.opened_at_monotonic,
        half_open_in_flight=state.half_open_in_flight,
    )


def to_circuit_breaker_states_response(
    snapshot: dict[str, CircuitBreakerState],
) -> CircuitBreakerStatesResponse:
    ordered = sorted(snapshot.items(), key=lambda item: item[0])

    return CircuitBreakerStatesResponse(
        circuits=[to_circuit_breaker_state_schema(key, state) for key, state in ordered]
    )


def to_circuit_breaker_event_schema(
    event: CircuitBreakerEvent,
) -> CircuitBreakerEventSchema:
    return CircuitBreakerEventSchema(
        key=event.key,
        from_state=event.from_state.value,
        to_state=event.to_state.value,
        reason=event.reason,
    )


def to_circuit_breaker_events_response(
    events: list[CircuitBreakerEvent],
) -> CircuitBreakerEventsResponse:
    return CircuitBreakerEventsResponse(
        events=[to_circuit_breaker_event_schema(event) for event in events]
    )


def _duration_ms(
    started_at: datetime | None,
    completed_at: datetime | None,
) -> int | None:
    if started_at is None or completed_at is None:
        return None

    delta = completed_at - started_at
    return int(delta.total_seconds() * 1000)


def _trace_sort_key(record: ExecutionRecord) -> tuple[int, int, str]:
    return (
        record.sequence_number if record.sequence_number is not None else 0,
        record.attempt,
        record.node_id,
    )


def _transport_metadata(
    metadata: dict[str, JSONValue],
) -> dict[str, object] | None:
    raw_transport = metadata.get("transport")
    if not isinstance(raw_transport, dict):
        return None

    transport: dict[str, object] = {}

    for key, value in raw_transport.items():
        if isinstance(key, str):
            transport[key] = cast(object, value)

    return transport


def _validation_warnings(
    metadata: dict[str, JSONValue],
) -> list[dict[str, object]]:
    raw_warnings = metadata.get("validation_warnings")
    if not isinstance(raw_warnings, list):
        return []

    warnings_list: list[dict[str, object]] = []

    for item in raw_warnings:
        if isinstance(item, dict):
            warning: dict[str, object] = {}
            for key, value in item.items():
                if isinstance(key, str):
                    warning[key] = cast(object, value)
            warnings_list.append(warning)

    return warnings_list


def _error_metadata(
    metadata: dict[str, JSONValue],
) -> str | None:
    raw_error = metadata.get("error")
    return raw_error if isinstance(raw_error, str) else None


def to_execution_trace_response(
    *,
    request_id: str,
    status: str,
    state: ExecutionState,
    graph: ExecutionGraph,
) -> ExecutionTraceResponse:
    trace_nodes: list[TraceNodeSchema] = []
    latest_by_node: dict[str, ExecutionRecord] = {}

    for node_id, records in state._records.items():
        if node_id == GraphCompiler.SYNTHETIC_ROOT:
            continue

        sorted_records = sorted(records, key=_trace_sort_key)

        for record in sorted_records:
            latest_by_node[node_id] = record

            result = record.result
            metadata = result.metadata or {}
            agent = graph.nodes[node_id].agent if node_id in graph.nodes else None

            trace_nodes.append(
                TraceNodeSchema(
                    node_id=node_id,
                    agent=agent,
                    attempt=record.attempt,
                    sequence_number=record.sequence_number,
                    started_at=record.started_at,
                    completed_at=record.completed_at,
                    duration_ms=_duration_ms(record.started_at, record.completed_at),
                    success=result.success,
                    confidence=result.confidence,
                    error=_error_metadata(metadata),
                    transport=_transport_metadata(metadata),
                    validation_warnings=_validation_warnings(metadata),
                )
            )

    trace_nodes.sort(
        key=lambda node: (
            node.sequence_number if node.sequence_number is not None else 0,
            node.attempt,
            node.node_id,
        )
    )

    overall_success = (
        status == "COMPLETED"
        and bool(latest_by_node)
        and all(record.result.success for record in latest_by_node.values())
    )

    return ExecutionTraceResponse(
        request_id=request_id,
        started_at=state.started_at,
        completed_at=state.completed_at,
        duration_ms=_duration_ms(state.started_at, state.completed_at),
        status=status,
        overall_success=overall_success,
        nodes=trace_nodes,
    )
