from __future__ import annotations

import os
from collections.abc import Callable
from pathlib import Path
from typing import Final

from anusara._contracts.agent import Agent
from anusara._core.execution_engine import ExecutionEngine
from anusara._observability.file_event_log import FileExecutionEventLog
from anusara._registry.agent_registry import AgentRegistry
from anusara._runtime.config import RuntimeConfig

# ---------------------------------------------------------
# Constants
# ---------------------------------------------------------

DEFAULT_EVENT_LOG_PATH: Final[str] = ".runtime/events.jsonl"

# ---------------------------------------------------------
# Runtime Container
# ---------------------------------------------------------


class RuntimeContainer:
    """
    Holds long-lived runtime dependencies.

    Responsibilities:
    - Own execution engine
    - Own event log
    - Own agent registry

    This acts as a lightweight dependency container
    for HTTP adapters.
    """

    def __init__(self, config: RuntimeConfig) -> None:
        event_log_path = Path(config.event_log_path)
        event_log_path.parent.mkdir(parents=True, exist_ok=True)

        self.event_log = FileExecutionEventLog(str(event_log_path))
        self.engine = ExecutionEngine(event_log=self.event_log)
        self.registry = AgentRegistry()

        # Controlled agent factory
        self._agent_factories: dict[str, Callable[[], Agent]] = {}

    def register_factory(self, name: str, factory: Callable[[], Agent]) -> None:
        if name in self._agent_factories:
            raise ValueError(f"Factory already registered for '{name}'")

        self._agent_factories[name] = factory

    def create_and_register(self, name: str) -> None:
        if name not in self._agent_factories:
            raise ValueError(f"No factory registered for agent '{name}'")

        if self.registry.exists(name):
            raise ValueError(f"Agent '{name}' is already registered")

        agent = self._agent_factories[name]()
        self.registry.register(name, agent)

    def list_factories(self) -> list[str]:
        return list(self._agent_factories.keys())


# ---------------------------------------------------------
# Singleton Runtime
# ---------------------------------------------------------

_container: RuntimeContainer | None = None


def initialize_runtime(
    config: RuntimeConfig | str | None = None,
    *,
    reset: bool = False,
) -> RuntimeContainer:
    """
    Initialize (or reset) the global runtime container.

    Accepts:
    - RuntimeConfig (preferred)
    - str (event_log_path for convenience)
    - None (loads from env)
    """
    global _container

    if isinstance(config, str):
        config = RuntimeConfig(event_log_path=config)

    if reset:
        _container = None  # 🔥 explicit reset

    if _container is None:
        if config is None:
            config = RuntimeConfig.from_env()

        _container = RuntimeContainer(config)

    return _container


def _require_container() -> RuntimeContainer:
    if _container is None:
        raise RuntimeError(
            "Runtime not initialized. Call initialize_runtime() during app startup."
        )
    return _container


def get_engine() -> ExecutionEngine:
    """
    Dependency provider for ExecutionEngine.
    """
    return _require_container().engine


def get_registry() -> AgentRegistry:
    """
    Dependency provider for AgentRegistry.
    """
    return _require_container().registry


def get_container() -> RuntimeContainer:
    if _container is None:
        raise RuntimeError("Runtime not initialized")
    return _container


# ---------------------------------------------------------
# Internal Helpers
# ---------------------------------------------------------


def _resolve_event_log_path() -> str:
    path = os.getenv("ANUSARA_EVENT_LOG")

    if path is not None:
        return path

    return DEFAULT_EVENT_LOG_PATH
