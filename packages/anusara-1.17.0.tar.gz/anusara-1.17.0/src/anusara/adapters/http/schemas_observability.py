from __future__ import annotations

from pydantic import BaseModel


class CircuitBreakerStateSchema(BaseModel):
    key: str
    state: str
    consecutive_failures: int
    opened_at_monotonic: float | None
    half_open_in_flight: bool


class CircuitBreakerStatesResponse(BaseModel):
    circuits: list[CircuitBreakerStateSchema]


class CircuitBreakerEventSchema(BaseModel):
    key: str
    from_state: str
    to_state: str
    reason: str


class CircuitBreakerEventsResponse(BaseModel):
    events: list[CircuitBreakerEventSchema]
