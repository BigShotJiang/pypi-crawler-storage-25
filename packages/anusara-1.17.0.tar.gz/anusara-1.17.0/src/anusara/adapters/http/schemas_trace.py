from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel


class TraceNodeSchema(BaseModel):
    node_id: str
    agent: str | None
    attempt: int
    sequence_number: int | None
    started_at: datetime | None
    completed_at: datetime | None
    duration_ms: int | None
    success: bool
    confidence: float
    error: str | None
    transport: dict[str, object] | None
    validation_warnings: list[dict[str, object]]


class ExecutionTraceResponse(BaseModel):
    request_id: str
    started_at: datetime | None
    completed_at: datetime | None
    duration_ms: int | None
    status: str
    overall_success: bool
    nodes: list[TraceNodeSchema]
