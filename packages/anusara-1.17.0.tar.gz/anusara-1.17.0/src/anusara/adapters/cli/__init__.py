"""
Command-line interface (CLI) adapter for Anusara.

Provides tools to:
- Execute workflows from the terminal
- Trigger replay and inspection flows
- Load inputs from files or inline parameters

Responsibilities:
- Parse CLI arguments into structured requests
- Invoke runtime execution or replay
- Present results in a human-readable format

Design principles:
- Minimal logic (delegates to core/runtime)
- Deterministic invocation
- Developer-friendly ergonomics

Intended for local usage, testing, and debugging workflows.
"""
