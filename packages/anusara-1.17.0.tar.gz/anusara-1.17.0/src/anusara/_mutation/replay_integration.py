# anusara/_mutation/replay_integration.py

from __future__ import annotations

from anusara._contracts.events import EventRegistry
from anusara._mutation.registry import MutationEventRegistry, register_with_core


def enable_mutation_replay(
    *,
    global_registry: EventRegistry,
    mutation_registry: MutationEventRegistry,
) -> None:
    """
    Enables replay support for mutation events.

    This function integrates mutation-domain events into the global
    orchestration event registry, allowing them to be:

    - deserialized during replay
    - processed by reducers
    - included in execution reconstruction

    Usage:
    - Must be called during ReplayCoordinator or engine setup
    - Should be invoked exactly once per registry lifecycle

    Notes:
    - relies on core EventRegistry duplicate protection
    - mutation events must be registered in mutation_registry beforehand
    """

    register_with_core(
        mutation_registry=mutation_registry,
        core_registry=global_registry,
    )


__all__ = [
    "enable_mutation_replay",
]
