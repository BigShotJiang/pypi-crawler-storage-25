from __future__ import annotations

import threading
from typing import cast

from anusara._mutation.event import MutationEvent


class InMemoryMutationEventLog:
    """
    In-memory mutation event log.

    Characteristics:
    - append-only
    - preserves order
    - request-aware filtering
    - thread-safe

    Notes:
    - used primarily for testing / local execution
    - not suitable for distributed persistence
    """

    def __init__(self) -> None:
        self._events: list[MutationEvent] = []
        self._lock = threading.Lock()

    # -----------------------------------------------------

    def append(self, event: MutationEvent) -> None:
        with self._lock:
            self._events.append(event)

    # -----------------------------------------------------

    def read_by_request(self, request_id: str) -> list[MutationEvent]:
        """
        Returns all mutation events associated with a request.

        Includes:
        - direct events (request_id)
        - derived events (base_request_id)
        """

        result: list[MutationEvent] = []

        with self._lock:
            for e in self._events:
                rid = cast(str | None, getattr(e, "request_id", None))
                base = cast(str | None, getattr(e, "base_request_id", None))

                if rid == request_id or base == request_id:
                    result.append(e)

        return result

    # -----------------------------------------------------

    def read_all(self) -> list[MutationEvent]:
        """
        Returns all events in insertion order.
        """
        with self._lock:
            return list(self._events)
