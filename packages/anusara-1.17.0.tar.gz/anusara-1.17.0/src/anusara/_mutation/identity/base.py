from __future__ import annotations

from typing import Protocol

from anusara._mutation.contracts import CanonicalIdentityInput

# ============================================================
# Mutation Identity Strategy
# ============================================================


class MutationIdentityStrategy(Protocol):
    """
    Strategy interface for mutation identity derivation.

    Implementations define how mutation-related entities are
    uniquely and deterministically identified.

    Design requirements:
    - Deterministic (same input → same output)
    - Pure (no time, randomness, or external state)
    - JSON-boundary safe
    - Replay-stable across executions

    Identity outputs must be:
    - stable across environments
    - collision-resistant for practical use
    - suitable for logging, auditing, and comparison
    """

    # ---------------------------------------------------------
    # Evaluation Identity
    # ---------------------------------------------------------

    def build_evaluation_id(
        self,
        canonical_input: CanonicalIdentityInput,
    ) -> str:
        """
        Produce deterministic evaluation ID.

        Represents a mutation evaluation lifecycle instance.
        """
        ...

    # ---------------------------------------------------------
    # Proposal Identity
    # ---------------------------------------------------------

    def build_proposal_id(
        self,
        canonical_input: CanonicalIdentityInput,
    ) -> str:
        """
        Produce deterministic proposal ID.

        Represents a mutation proposal uniquely.
        """
        ...

    # ---------------------------------------------------------
    # Conflict Identity
    # ---------------------------------------------------------

    def build_conflict_hash(
        self,
        canonical_input: CanonicalIdentityInput,
    ) -> str:
        """
        Produce deterministic conflict hash.

        Used to detect logical conflicts between mutation proposals.

        Scope:
            Evaluation-only (not globally unique across all systems).
        """
        ...
