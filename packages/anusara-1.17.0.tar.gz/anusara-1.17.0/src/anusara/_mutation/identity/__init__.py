"""
Mutation Identity Strategies

Defines how mutation proposals are uniquely identified and compared.

This module provides pluggable identity strategies used to:
- generate deterministic identifiers for mutation proposals
- detect duplicate or conflicting mutations
- support auditability and traceability of mutation lifecycle

Identity strategies must be:
- deterministic (same input → same identity)
- stable across executions
- collision-resistant for practical use

Included strategies:
- Base identity strategy (interface/contract)
- SHA256-based salted identity strategy

This is an internal subsystem used by mutation governance and
compliance layers.
"""
