from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field

from anusara._contracts.events import OrchestrationEvent
from anusara._mutation.event import (
    GraphMutationAccepted,
    GraphMutationConflictDetected,
    GraphMutationExecuted,
    GraphMutationProposed,
    GraphMutationRejected,
    MutationEvaluationRequested,
)

# ============================================================
# Mutation Proposal Record
# ============================================================


@dataclass
class MutationProposalRecord:
    proposal_id: str
    schema_version: str
    accepted: bool = False
    rejected: bool = False
    executed: bool = False
    reason: str = ""


# ============================================================
# Mutation Evaluation Record
# ============================================================


@dataclass
class MutationEvaluationRecord:
    evaluation_id: str
    request_id: str
    observer_id: str
    policy_version: str
    proposals: dict[str, MutationProposalRecord] = field(default_factory=dict)
    conflict_hash: str | None = None


# ============================================================
# Mutation Snapshot
# ============================================================


@dataclass
class MutationSnapshot:
    """
    Derived mutation projection from event history.

    Characteristics:
    - deterministic
    - replay-safe
    - tolerant to partial ordering issues
    """

    evaluations: dict[str, MutationEvaluationRecord]


# ============================================================
# Projection Builder
# ============================================================


class MutationSnapshotBuilder:
    """
    Builds mutation snapshot from event stream.

    Pure projection.
    No side effects.
    """

    @staticmethod
    def build(events: Sequence[OrchestrationEvent]) -> MutationSnapshot:
        evaluations: dict[str, MutationEvaluationRecord] = {}

        for event in events:
            # -------------------------------------------------
            # Evaluation Created
            # -------------------------------------------------

            if isinstance(event, MutationEvaluationRequested):
                if event.evaluation_id not in evaluations:
                    evaluations[event.evaluation_id] = MutationEvaluationRecord(
                        evaluation_id=event.evaluation_id,
                        request_id=event.request_id,
                        observer_id=event.observer_id,
                        policy_version=event.policy_version,
                    )

            # -------------------------------------------------
            # Proposal Created
            # -------------------------------------------------

            elif isinstance(event, GraphMutationProposed):
                record = evaluations.get(event.evaluation_id)
                if record is None:
                    continue

                if event.proposal_id not in record.proposals:
                    record.proposals[event.proposal_id] = MutationProposalRecord(
                        proposal_id=event.proposal_id,
                        schema_version=event.proposal_schema_version,
                    )

            # -------------------------------------------------
            # Conflict Detected
            # -------------------------------------------------

            elif isinstance(event, GraphMutationConflictDetected):
                record = evaluations.get(event.evaluation_id)
                if record is None:
                    continue

                record.conflict_hash = event.conflict_hash

            # -------------------------------------------------
            # Accepted
            # -------------------------------------------------

            elif isinstance(event, GraphMutationAccepted):
                record = evaluations.get(event.evaluation_id)
                if record is None:
                    continue

                proposal = record.proposals.get(event.proposal_id)

                if proposal is None:
                    # Self-healing: create missing proposal
                    proposal = MutationProposalRecord(
                        proposal_id=event.proposal_id,
                        schema_version="unknown",
                    )
                    record.proposals[event.proposal_id] = proposal

                proposal.accepted = True
                if event.reason:
                    proposal.reason = event.reason

            # -------------------------------------------------
            # Rejected
            # -------------------------------------------------

            elif isinstance(event, GraphMutationRejected):
                record = evaluations.get(event.evaluation_id)
                if record is None:
                    continue

                proposal = record.proposals.get(event.proposal_id)

                if proposal is None:
                    proposal = MutationProposalRecord(
                        proposal_id=event.proposal_id,
                        schema_version="unknown",
                    )
                    record.proposals[event.proposal_id] = proposal

                proposal.rejected = True
                if event.reason:
                    proposal.reason = event.reason

            # -------------------------------------------------
            # Executed
            # -------------------------------------------------

            elif isinstance(event, GraphMutationExecuted):
                record = evaluations.get(event.evaluation_id)
                if record is None:
                    continue

                proposal = record.proposals.get(event.proposal_id)

                if proposal is None:
                    proposal = MutationProposalRecord(
                        proposal_id=event.proposal_id,
                        schema_version="unknown",
                    )
                    record.proposals[event.proposal_id] = proposal

                proposal.executed = True

        return MutationSnapshot(evaluations=evaluations)
