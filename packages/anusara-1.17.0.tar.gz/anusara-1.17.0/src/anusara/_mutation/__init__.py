"""
Mutation Subsystem

Provides controlled graph mutation capabilities for dynamic workflows.

This module enables:
- mutation proposal and evaluation
- conflict detection and resolution
- governed execution of graph changes
- auditability of mutation lifecycle

Mutation is an advanced, opt-in feature and is NOT required
for standard execution flows.

Design principles:
- explicit governance (no implicit mutation)
- deterministic execution with mutation boundaries
- full audit trail via event logging
- policy-driven mutation control

This package is considered advanced API surface.
Consumers should use it only when dynamic graph evolution
is required.
"""
