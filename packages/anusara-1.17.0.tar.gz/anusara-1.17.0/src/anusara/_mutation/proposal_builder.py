from __future__ import annotations

from collections.abc import Sequence

from anusara._contracts.json_types import JSONValue
from anusara._mutation.artifact import (
    MutationArtifactStore,
    MutationProposalArtifact,
)
from anusara._mutation.contracts import CanonicalIdentityInput
from anusara._mutation.event import GraphMutationProposed
from anusara._mutation.identity.base import MutationIdentityStrategy
from anusara._utils.hashing import sha256_hex
from anusara._utils.serialization import canonical_json
from anusara._utils.time import utc_now


class MutationProposalBuilder:
    """
    Builds mutation proposals.

    Responsibilities:
    - derive deterministic proposal_id
    - persist mutation artifact
    - emit GraphMutationProposed event

    Guarantees:
    - deterministic identity generation
    - replay-safe proposal construction
    - no implicit side effects beyond artifact storage

    Notes:
    - proposal identity is derived from canonicalized operations
    - artifact persistence is idempotent (same proposal_id → same artifact)
    """

    def __init__(
        self,
        *,
        artifact_store: MutationArtifactStore,
        identity_strategy: MutationIdentityStrategy,
        schema_version: str = "v1",
    ) -> None:
        self._store = artifact_store
        self._identity = identity_strategy
        self._schema_version = schema_version

    # -------------------------------------------------------

    def build_and_store(
        self,
        *,
        request_id: str,
        evaluation_id: str,
        observer_id: str,
        policy_version: str,
        context_hash: str,
        operations: Sequence[dict[str, JSONValue]],
        metadata: dict[str, JSONValue],
    ) -> GraphMutationProposed:

        # -------------------------------------------------
        # Deterministic operations hash
        # -------------------------------------------------

        # NOTE:
        # operations must already be deterministic and ordered
        operations_hash = sha256_hex(canonical_json(list(operations)))

        canonical_input = CanonicalIdentityInput(
            proposal_content_hash=operations_hash,
            evaluation_id=evaluation_id,
            schema_version=self._schema_version,
            policy_version=policy_version,
            salt="",
        )

        proposal_id = self._identity.build_proposal_id(canonical_input)

        # -------------------------------------------------
        # Persist artifact (idempotent)
        # -------------------------------------------------

        if not self._store.exists(proposal_id):
            artifact = MutationProposalArtifact(
                proposal_id=proposal_id,
                evaluation_id=evaluation_id,
                observer_id=observer_id,
                schema_version=self._schema_version,
                operations=operations,
                metadata=metadata,
            )

            self._store.save(artifact)

        # -------------------------------------------------
        # Emit proposal event
        # -------------------------------------------------

        return GraphMutationProposed(
            request_id=request_id,
            timestamp=utc_now(),
            evaluation_id=evaluation_id,
            observer_id=observer_id,
            proposal_id=proposal_id,
            proposal_schema_version=self._schema_version,
            context_hash=context_hash,
            policy_version=policy_version,
        )
