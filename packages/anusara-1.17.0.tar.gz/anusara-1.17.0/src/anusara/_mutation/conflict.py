from __future__ import annotations

from collections.abc import Sequence
from typing import cast

from anusara._contracts.json_types import JSONValue
from anusara._mutation.contracts import CanonicalIdentityInput
from anusara._mutation.event import GraphMutationConflictDetected
from anusara._mutation.identity.base import MutationIdentityStrategy
from anusara._utils.hashing import sha256_hex
from anusara._utils.serialization import canonical_json


class MutationConflictDetector:
    """
    Detects conflicts between mutation proposals within the same evaluation.

    Conflict identity is derived from the full set of proposal IDs,
    ensuring deterministic and order-independent conflict detection.

    Scope:
        Evaluation-only (conflicts are not global across executions).
    """

    def __init__(
        self,
        *,
        identity_strategy: MutationIdentityStrategy,
        schema_version: str = "v1",
    ) -> None:
        self._identity = identity_strategy
        self._schema_version = schema_version

    # -----------------------------------------------------

    def detect(
        self,
        *,
        request_id: str,
        evaluation_id: str,
        observer_id: str,
        proposal_ids: Sequence[str],
        reason: str,
    ) -> GraphMutationConflictDetected:

        # -------------------------------------------------
        # Deterministic hash of proposal set
        # -------------------------------------------------

        sorted_ids = sorted(proposal_ids)

        proposal_set_hash = sha256_hex(canonical_json(cast(JSONValue, sorted_ids)))

        # -------------------------------------------------
        # Build canonical identity input
        # -------------------------------------------------

        canonical_input = CanonicalIdentityInput(
            proposal_content_hash=proposal_set_hash,
            evaluation_id=evaluation_id,
            schema_version=self._schema_version,
            policy_version="conflict",
            salt="",
        )

        # -------------------------------------------------
        # Generate conflict hash via identity strategy
        # -------------------------------------------------

        conflict_hash = self._identity.build_conflict_hash(canonical_input)

        # -------------------------------------------------
        # Emit conflict event
        # -------------------------------------------------

        return GraphMutationConflictDetected(
            request_id=request_id,
            evaluation_id=evaluation_id,
            observer_id=observer_id,
            conflicting_proposal_ids=proposal_ids,
            conflict_hash=conflict_hash,
            reason=reason,
        )
