from __future__ import annotations

from collections.abc import Sequence
from typing import Literal, Protocol

from anusara._contracts.execution_request import ExecutionRequest
from anusara._introspection.execution_snapshot import ExecutionSnapshot
from anusara._mutation.event import MutationEvent


class MutationObserver(Protocol):
    """
    Mutation observer contract.

    Defines how mutation logic is injected into the system.

    Responsibilities:
    - analyze execution snapshot
    - produce mutation lifecycle events (evaluation / proposals / decisions)

    Constraints:
    - must be deterministic (no randomness, no time-based logic)
    - must not mutate execution state
    - must not trigger execution
    - must only emit mutation events
    - must be replay-safe

    Invocation:
    - explicitly triggered by orchestration layer
    - not automatically invoked by engine
    """

    def evaluate(
        self,
        *,
        request: ExecutionRequest,
        snapshot: ExecutionSnapshot,
        trigger_source: Literal["policy", "human", "external"],
        reason: str | None,
    ) -> Sequence[MutationEvent]: ...
