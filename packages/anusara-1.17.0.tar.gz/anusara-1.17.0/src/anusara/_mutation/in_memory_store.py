from __future__ import annotations

import threading

from anusara._mutation.artifact import (
    MutationArtifactStore,
    MutationProposalArtifact,
)


class InMemoryMutationArtifactStore(MutationArtifactStore):
    """
    Deterministic in-memory artifact store.

    Characteristics:
    - append/overwrite store (by proposal_id)
    - thread-safe
    - constant-time access

    Notes:
    - intended for testing and embedded environments
    - stored artifacts are assumed immutable (caller responsibility)
    - overwrite behavior is allowed (latest write wins)
    """

    def __init__(self) -> None:
        self._store: dict[str, MutationProposalArtifact] = {}
        self._lock = threading.Lock()

    # -----------------------------------------------------

    def save(self, artifact: MutationProposalArtifact) -> None:
        """
        Store artifact by proposal_id.

        If proposal_id already exists, it will be overwritten.
        """
        with self._lock:
            self._store[artifact.proposal_id] = artifact

    # -----------------------------------------------------

    def load(self, proposal_id: str) -> MutationProposalArtifact:
        with self._lock:
            if proposal_id not in self._store:
                raise KeyError(f"Proposal artifact not found: {proposal_id}")

            return self._store[proposal_id]

    # -----------------------------------------------------

    def exists(self, proposal_id: str) -> bool:
        with self._lock:
            return proposal_id in self._store
