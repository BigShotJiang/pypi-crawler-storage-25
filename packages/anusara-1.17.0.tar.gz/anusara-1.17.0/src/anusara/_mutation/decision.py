from __future__ import annotations

from anusara._mutation.event import (
    GraphMutationAccepted,
    GraphMutationRejected,
)


class MutationDecisionService:
    """
    Explicit mutation decision service.

    Responsible for producing mutation decision events
    (accept / reject) without executing any mutations.

    Design principles:
    - event-only (no side effects)
    - deterministic and replay-safe
    - audit-friendly (all decisions are explicit events)

    This service forms the governance boundary between:
    - decision-making (human or automated)
    - execution (handled elsewhere)
    """

    # -----------------------------------------------------

    @staticmethod
    def accept(
        *,
        request_id: str,
        evaluation_id: str,
        observer_id: str,
        proposal_id: str,
        accepted_by: str,
        reason: str | None,
    ) -> GraphMutationAccepted:
        """
        Emit an acceptance decision for a mutation proposal.
        """

        return GraphMutationAccepted(
            request_id=request_id,
            evaluation_id=evaluation_id,
            observer_id=observer_id,
            proposal_id=proposal_id,
            accepted_by=accepted_by,
            reason=reason or "",
        )

    # -----------------------------------------------------

    @staticmethod
    def reject(
        *,
        request_id: str,
        evaluation_id: str,
        observer_id: str,
        proposal_id: str,
        rejected_by: str,
        reason: str,
    ) -> GraphMutationRejected:
        """
        Emit a rejection decision for a mutation proposal.
        """

        return GraphMutationRejected(
            request_id=request_id,
            evaluation_id=evaluation_id,
            observer_id=observer_id,
            proposal_id=proposal_id,
            rejected_by=rejected_by,
            reason=reason,
        )
