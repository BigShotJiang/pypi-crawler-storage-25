from dataclasses import dataclass

from anusara._core.execution_status import ExecutionStatus


@dataclass(frozen=True)
class ExecutionSummary:
    """
    Lightweight summary of an execution.

    Used for:
    - listing executions
    - CLI / UI display
    - quick status checks without full state reconstruction
    """

    request_id: str
    status: ExecutionStatus
