from enum import StrEnum


class ValidationMode(StrEnum):
    STRICT = "strict"
    WARN = "warn"
