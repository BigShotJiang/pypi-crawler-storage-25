class AnusaraError(Exception):
    """
    Base exception for all Anusara errors.
    """

    pass


# ---------------------------------------------------------
# Execution-Level Errors
# ---------------------------------------------------------


class ExecutionError(AnusaraError):
    """
    Base exception for execution-phase failures.
    """

    pass


class MaxHopExceededError(ExecutionError):
    """
    Raised when execution exceeds maximum allowed hops.
    """

    def __init__(self, max_hops: int | None = None):

        if max_hops is None:
            message = "Maximum execution hops exceeded."
        else:
            message = f"Maximum execution hops exceeded ({max_hops})."

        super().__init__(message)


class RetryExhaustedError(ExecutionError):
    """
    Raised when retry attempts are exhausted for a node.
    """

    def __init__(self, node_id: str | None = None, attempts: int | None = None):

        if node_id is None or attempts is None:
            message = "Retry attempts exhausted."
        else:
            message = f"Retry attempts exhausted for node '{node_id}' after {attempts} attempts."

        super().__init__(message)


# ---------------------------------------------------------
# Concurrency / Control Flow Errors
# ---------------------------------------------------------
class CircuitBreakerOpenError(RuntimeError):
    def __init__(self, circuit_key: str) -> None:
        super().__init__(f"Circuit breaker is open for '{circuit_key}'")
        self.circuit_key = circuit_key


class ExecutionAlreadyRunningError(ExecutionError):
    """
    Raised when an execution operation (execute/resume/replay)
    is invoked concurrently for the same request_id.
    """

    def __init__(self, request_id: str):
        super().__init__(f"Execution already running for request_id '{request_id}'.")
        self.request_id = request_id


class ApprovalRequiredError(ExecutionError):
    """
    Raised to indicate execution requires external approval before continuing.
    """

    pass


class SimulatedHardKillError(ExecutionError):
    """
    Raised to indicate abrupt termination of an ongoing execution cycle.
    """

    pass


__all__ = [
    "AnusaraError",
    "ExecutionError",
    "MaxHopExceededError",
    "RetryExhaustedError",
    "ExecutionAlreadyRunningError",
    "ApprovalRequiredError",
    "SimulatedHardKillError",
    "CircuitBreakerOpenError",
]
