from enum import Enum


class ExecutionStatus(Enum):
    """
    Represents the lifecycle status of an execution.

    Derived from event log projection and used for:
    - execution inspection
    - resume decisions
    - validation of execution state
    """

    NOT_FOUND = "not_found"
    COMPLETED = "completed"
    INCOMPLETE = "incomplete"
    CORRUPTED = "corrupted"
    PAUSED = "paused"
    FAILED = "failed"
