from __future__ import annotations

import asyncio
from datetime import datetime

from anusara._contracts.agent_result import AgentResult
from anusara._contracts.events import (
    NodeExecutionFinished,
    NodeExecutionRetried,
    NodeExecutionStarted,
)
from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.json_types import JSONValue
from anusara._core.errors import ApprovalRequiredError, SimulatedHardKillError
from anusara._core.execute_node_command import ExecuteNodeCommand
from anusara._core.middleware.retry_middleware import RetryMiddleware
from anusara._core.orchestration_event_emitter import OrchestrationEventEmitter
from anusara._core.validation_mode import ValidationMode
from anusara._registry.agent_registry import AgentRegistry
from anusara._registry.errors import AgentNotFoundError
from anusara._registry.executable_definition import ExecutableDefinition
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_state import ExecutionState
from anusara._runtime.invokers.registry import InvokerRegistry
from anusara._runtime.retry_policy import RetryPolicy
from anusara._runtime.schema_validation import validate_payload_against_schema
from anusara._runtime.worker_invocation import WorkerInvocationRequest
from anusara._utils.time import utc_now


# -----------------------------------------------------------------------------
# ARCHITECTURAL INVARIANT
#
# NodeExecutor is responsible ONLY for:
#   - resolving registered executables
#   - invoking executables
#   - emitting execution lifecycle events
#
# NodeExecutor MUST NOT:
#   - create ExecutionRecord
#   - mutate ExecutionState
#   - assign authoritative execution ordering
#
# ExecutionState mutations remain owned by ExecutionEngine.
# -----------------------------------------------------------------------------
class NodeExecutor:
    """
    Responsible for executing a single orchestration node.

    Invariant:
    - Emits events only.
    - Does NOT mutate ExecutionState directly.
    - Returns AgentResult from a runtime-agnostic executable boundary.
    """

    def __init__(
        self,
        registry: AgentRegistry,
        retry_policy: RetryPolicy,
        event_emitter: OrchestrationEventEmitter,
        graph: ExecutionGraph,
        invokers: InvokerRegistry,
    ) -> None:
        self._registry = registry
        self._retry = RetryMiddleware(retry_policy)
        self._emitter = event_emitter
        self._graph = graph
        self._invokers = invokers

    # ---------------------------------------------------------
    # PUBLIC ENTRY
    # ---------------------------------------------------------

    async def execute(
        self,
        node_id: str,
        agent_name: str,
        request: ExecutionRequest,
        state: ExecutionState,
        sequence_number: int,
    ) -> AgentResult:
        previous_attempts = len(state.records_for(node_id))
        attempt = previous_attempts + 1

        command = ExecuteNodeCommand(
            request_id=request.request_id,
            node_id=node_id,
            agent=agent_name,
            attempt=attempt,
            payload=request.payload,
        )

        return await self._execute_command(
            command,
            request,
            state,
            sequence_number=sequence_number,
        )

    # ---------------------------------------------------------
    # COMMAND EXECUTION
    # ---------------------------------------------------------

    async def _execute_command(
        self,
        command: ExecuteNodeCommand,
        request: ExecutionRequest,
        state: ExecutionState,
        sequence_number: int,
    ) -> AgentResult:
        definition = self._get_executable_definition(command.agent)
        base_attempt = command.attempt

        max_attempts = self._retry.max_attempts()
        total_attempts = 1 if not request.policy.enable_retry else max_attempts

        if total_attempts <= 0:
            raise RuntimeError("Retry policy must allow at least one attempt")

        for retry_offset in range(total_attempts):
            attempt = base_attempt + retry_offset
            started_at = utc_now()

            self._emitter.emit(
                NodeExecutionStarted(
                    request_id=request.request_id,
                    timestamp=started_at,
                    node_id=command.node_id,
                    agent=command.agent,
                    attempt=attempt,
                )
            )

            try:
                result = await self._invoke(
                    node_id=command.node_id,
                    definition=definition,
                    request=request,
                    state=state,
                    attempt=attempt,
                )
            except SimulatedHardKillError:
                raise
            except ApprovalRequiredError:
                raise
            except Exception as exc:
                result = AgentResult(
                    success=False,
                    output=None,
                    confidence=0.0,
                    metadata={"error": str(exc)},
                )

            completed_at = utc_now()

            self._emit_finished(
                request_id=request.request_id,
                node_id=command.node_id,
                agent=command.agent,
                attempt=attempt,
                result=result,
                sequence_number=sequence_number,
                completed_at=completed_at,
            )

            if result.success:
                return result

            is_last_attempt = retry_offset == total_attempts - 1
            if is_last_attempt:
                return result

            delay = self._retry.compute_delay(attempt)

            self._emitter.emit(
                NodeExecutionRetried(
                    request_id=request.request_id,
                    timestamp=utc_now(),
                    node_id=command.node_id,
                    agent=command.agent,
                    attempt=attempt,
                    delay_seconds=delay,
                )
            )

            await asyncio.sleep(delay)

        raise RuntimeError("Execution produced no result")

    # ---------------------------------------------------------
    # EXECUTABLE RESOLUTION
    # ---------------------------------------------------------

    def _get_executable_definition(self, agent_name: str) -> ExecutableDefinition:
        try:
            return self._registry.get_definition(agent_name)
        except KeyError as exc:
            raise AgentNotFoundError(agent_name) from exc

    # ---------------------------------------------------------
    # INVOCATION CORE
    # ---------------------------------------------------------

    async def _invoke(
        self,
        node_id: str,
        definition: ExecutableDefinition,
        request: ExecutionRequest,
        state: ExecutionState,
        attempt: int,
    ) -> AgentResult:
        payload: dict[str, JSONValue] = {}

        deps = self._graph.dependencies_of(node_id)

        for dep in deps:
            dep_record = state.latest_record(dep)

            if dep_record is None:
                continue

            output = dep_record.result.output

            if isinstance(output, dict):
                payload[dep] = output

        # Fallback for entry nodes / nodes without resolved dependency outputs
        if not payload:
            payload = request.payload

        validation_mode = self._validation_mode_for_node(node_id, request)

        input_errors = self._validate_input_schema(
            agent_id=definition.agent_id,
            payload=payload,
        )

        if input_errors and validation_mode == ValidationMode.STRICT:
            return self._schema_failure_result(
                stage="input",
                errors=input_errors,
            )

        # ---------------------------------------------------------
        # Scenario-driven failure injection (fail_nodes)
        # ---------------------------------------------------------
        scenario = request.resolve_scenario()
        raw_fail_nodes = scenario.param("fail_nodes", None)

        should_fail = False
        if isinstance(raw_fail_nodes, list):
            for value in raw_fail_nodes:
                if isinstance(value, str) and value == node_id:
                    should_fail = True
                    break

        if should_fail:
            return AgentResult(
                success=False,
                output={
                    "error": "Injected failure (fail_nodes)",
                    "node_id": node_id,
                    "request_id": request.request_id,
                },
                confidence=0.0,
                metadata={"non_blocking": True},
            )

        invocation_request = WorkerInvocationRequest(
            request_id=request.request_id,
            node_id=node_id,
            agent_id=definition.agent_id,
            attempt=attempt,
            payload=payload,
            metadata=request.metadata,
            scenario=scenario,
        )

        result = await self._invokers.invoke(definition, invocation_request)

        if not isinstance(result, AgentResult):
            raise TypeError(
                f"Executable '{definition.agent_id}' returned invalid result type: "
                f"{type(result).__name__}"
            )

        if input_errors and validation_mode == ValidationMode.WARN:
            result = self._attach_validation_warning(
                result=result,
                stage="input",
                errors=input_errors,
            )

        output_errors = self._validate_output_schema(
            agent_id=definition.agent_id,
            output=result.output,
        )

        if output_errors and validation_mode == ValidationMode.STRICT:
            return self._schema_failure_result(
                stage="output",
                errors=output_errors,
            )

        if output_errors and validation_mode == ValidationMode.WARN:
            result = self._attach_validation_warning(
                result=result,
                stage="output",
                errors=output_errors,
            )

        return result

    # ---------------------------------------------------------
    # EVENT EMISSION
    # ---------------------------------------------------------

    def _emit_finished(
        self,
        *,
        request_id: str,
        node_id: str,
        agent: str,
        attempt: int,
        result: AgentResult,
        sequence_number: int,
        completed_at: datetime,
    ) -> None:
        raw_error = result.metadata.get("error") if result.metadata else None
        error_str = raw_error if isinstance(raw_error, str) else None

        output: dict[str, JSONValue] | None = None
        if isinstance(result.output, dict):
            output = result.output

        self._emitter.emit(
            NodeExecutionFinished(
                request_id=request_id,
                timestamp=completed_at,
                node_id=node_id,
                agent=agent,
                attempt=attempt,
                success=result.success,
                confidence=result.confidence,
                metadata=result.metadata or {},
                output=output,
                error=error_str,
                sequence_number=sequence_number,
            )
        )

    # ---------------------------------------------------------
    # SCHEMA VALIDATION
    # ---------------------------------------------------------

    def _validate_input_schema(
        self,
        *,
        agent_id: str,
        payload: dict[str, JSONValue],
    ) -> list[str]:
        descriptor = self._registry.get_schema_descriptor(agent_id)

        if descriptor is None or descriptor.input_schema is None:
            return []

        return validate_payload_against_schema(payload, descriptor.input_schema)

    def _validate_output_schema(
        self,
        *,
        agent_id: str,
        output: JSONValue | None,
    ) -> list[str]:
        descriptor = self._registry.get_schema_descriptor(agent_id)

        if descriptor is None or descriptor.output_schema is None:
            return []

        if not isinstance(output, dict):
            return ["Output must be a JSON object to satisfy declared output schema."]

        return validate_payload_against_schema(output, descriptor.output_schema)

    def _validation_mode_for_node(
        self,
        node_id: str,
        request: ExecutionRequest,
    ) -> str:
        node = self._graph.nodes[node_id]
        raw = node.metadata.get("validation_mode")

        if raw == ValidationMode.WARN.value:
            return ValidationMode.WARN.value

        if raw == ValidationMode.STRICT.value:
            return ValidationMode.STRICT.value

        if request.policy.validation_mode == ValidationMode.WARN:
            return ValidationMode.WARN.value

        return ValidationMode.STRICT.value

    def _schema_failure_result(
        self,
        *,
        stage: str,
        errors: list[str],
    ) -> AgentResult:
        return AgentResult(
            success=False,
            output=None,
            confidence=0.0,
            metadata={
                "error": f"{stage.capitalize()} schema validation failed",
                "validation_stage": stage,
                "validation_errors": [error for error in errors],
                "validation_severity": "error",
            },
        )

    def _attach_validation_warning(
        self,
        *,
        result: AgentResult,
        stage: str,
        errors: list[str],
    ) -> AgentResult:
        metadata = dict(result.metadata or {})
        existing = metadata.get("validation_warnings")

        warnings_list: list[JSONValue]
        if isinstance(existing, list):
            warnings_list = list(existing)
        else:
            warnings_list = []

        warnings_list.append(
            {
                "stage": stage,
                "severity": "warning",
                "errors": [error for error in errors],
            }
        )

        metadata["validation_warnings"] = warnings_list

        return AgentResult(
            success=result.success,
            output=result.output,
            errors=result.errors,
            confidence=result.confidence,
            metadata=metadata,
        )
