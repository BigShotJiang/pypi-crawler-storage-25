from collections.abc import Iterator

from anusara._contracts.event_log import ExecutionEventLog
from anusara._contracts.event_types import ExecutionEventTypes
from anusara._core.execution_status import ExecutionStatus
from anusara._core.execution_summary import ExecutionSummary


class ExecutionLogInspector:
    def __init__(self, event_log: ExecutionEventLog):
        self._event_log = event_log

    def stream_summaries(self) -> Iterator[ExecutionSummary]:
        counters: dict[str, dict[str, int]] = {}
        last_lifecycle: dict[str, str | None] = {}
        seen_completed: dict[str, bool] = {}
        seen_failed: dict[str, bool] = {}
        is_corrupted: dict[str, bool] = {}

        for event in self._event_log.iter():
            request_id = event.request_id

            if request_id not in counters:
                counters[request_id] = {
                    "started": 0,
                    "completed": 0,
                    "paused": 0,
                    "failed": 0,
                }
                last_lifecycle[request_id] = None
                seen_completed[request_id] = False
                seen_failed[request_id] = False
                is_corrupted[request_id] = False

            event_type = event.EVENT_TYPE

            if event_type == ExecutionEventTypes.MAIN_EXECUTION_STARTED:
                counters[request_id]["started"] += 1
                last_lifecycle[request_id] = event_type

            elif event_type == ExecutionEventTypes.MAIN_EXECUTION_COMPLETED:
                if seen_completed[request_id]:
                    is_corrupted[request_id] = True

                counters[request_id]["completed"] += 1
                last_lifecycle[request_id] = event_type
                seen_completed[request_id] = True

            elif event_type == ExecutionEventTypes.MAIN_EXECUTION_PAUSED:
                counters[request_id]["paused"] += 1
                last_lifecycle[request_id] = event_type

                if seen_completed[request_id] or seen_failed[request_id]:
                    is_corrupted[request_id] = True

            elif event_type == ExecutionEventTypes.MAIN_EXECUTION_FAILED:
                counters[request_id]["failed"] += 1
                last_lifecycle[request_id] = event_type

                if seen_completed[request_id]:
                    is_corrupted[request_id] = True

                seen_failed[request_id] = True

        for request_id, counts in counters.items():
            yield ExecutionSummary(
                request_id=request_id,
                status=self._resolve_status(
                    counts=counts,
                    last_lifecycle_event=last_lifecycle[request_id],
                    is_corrupted=is_corrupted[request_id],
                ),
            )

    def _resolve_status(
        self,
        *,
        counts: dict[str, int],
        last_lifecycle_event: str | None,
        is_corrupted: bool,
    ) -> ExecutionStatus:
        started = counts["started"]
        completed = counts["completed"]
        paused = counts["paused"]
        failed = counts["failed"]

        if started == 0 and completed == 0 and paused == 0 and failed == 0:
            return ExecutionStatus.NOT_FOUND

        if is_corrupted:
            return ExecutionStatus.CORRUPTED

        if started == 0:
            return ExecutionStatus.CORRUPTED

        if started > 1:
            return ExecutionStatus.CORRUPTED

        if completed > 1 or paused > 1 or failed > 1:
            return ExecutionStatus.CORRUPTED

        if last_lifecycle_event == ExecutionEventTypes.MAIN_EXECUTION_COMPLETED:
            return ExecutionStatus.COMPLETED

        if last_lifecycle_event == ExecutionEventTypes.MAIN_EXECUTION_FAILED:
            return ExecutionStatus.FAILED

        if last_lifecycle_event == ExecutionEventTypes.MAIN_EXECUTION_PAUSED:
            return ExecutionStatus.PAUSED

        if last_lifecycle_event == ExecutionEventTypes.MAIN_EXECUTION_STARTED:
            return ExecutionStatus.INCOMPLETE

        return ExecutionStatus.CORRUPTED
