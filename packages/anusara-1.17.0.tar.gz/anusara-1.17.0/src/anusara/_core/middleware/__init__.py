"""
Anusara Core Middleware Layer

This package contains reusable execution middleware components that
extend or modify runtime behavior in a composable and isolated manner.

Typical responsibilities include:
- retry handling
- backoff strategies
- cross-cutting execution concerns

Design principles:
- middleware must not mutate ExecutionState directly
- middleware must remain deterministic and side-effect controlled
- middleware should be composable and independently testable
"""
