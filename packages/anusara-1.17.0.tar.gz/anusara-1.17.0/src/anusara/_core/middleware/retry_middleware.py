from anusara._runtime.retry_policy import RetryPolicy


class RetryMiddleware:
    """
    Pure retry policy helper.

    Responsibilities:
    - expose retry limits
    - compute retry delays

    Non-responsibilities:
    - does NOT control execution flow
    - does NOT perform retries itself
    - does NOT mutate execution state

    This keeps retry behavior declarative and deterministic.
    """

    def __init__(self, retry_policy: RetryPolicy) -> None:
        self._policy = retry_policy

    def max_attempts(self) -> int:
        """
        Return the maximum number of attempts.

        Always returns at least 1 to guarantee execution.
        """
        return max(1, self._policy.max_attempts)

    def compute_delay(self, attempt: int) -> float:
        """
        Compute delay before next retry attempt.
        """
        return self._policy.compute_delay_seconds(attempt)
