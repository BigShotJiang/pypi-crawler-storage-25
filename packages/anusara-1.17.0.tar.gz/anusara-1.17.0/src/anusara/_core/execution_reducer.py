from typing import cast

from anusara._contracts.agent_result import AgentResult
from anusara._contracts.events import (
    ExecutionCompleted,
    ExecutionFailed,
    ExecutionPaused,
    ExecutionStarted,
    NodeExecutionFinished,
    NodeExecutionRetried,
    NodeExecutionStarted,
    OrchestrationEvent,
)
from anusara._contracts.json_types import JSONValue
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState
from anusara._routing.graph_compiler import GraphCompiler


class ExecutionReducer:
    """
    Applies orchestration events to reconstruct execution state.

    Guarantees:
    - Deterministic reconstruction
    - Event-log driven state projection
    - No implicit conflict resolution
    """

    def apply(
        self,
        event: OrchestrationEvent,
        state: ExecutionState,
        _graph: ExecutionGraph,
    ) -> None:
        if event.request_id != state.request_id:
            return

        if isinstance(event, ExecutionStarted):
            state.mark_started(event.timestamp)
            return

        if isinstance(event, ExecutionCompleted):
            if state.is_paused:
                state.clear_paused()
            state.mark_completed(event.timestamp)

        if isinstance(event, ExecutionPaused):
            state.mark_paused(event.timestamp)

        if isinstance(event, ExecutionFailed):
            return

        if isinstance(event, NodeExecutionStarted):
            state._register_attempt_start(
                event.node_id,
                event.attempt,
                event.timestamp,
            )
            return

        if isinstance(event, NodeExecutionFinished):
            if event.node_id == GraphCompiler.SYNTHETIC_ROOT:
                return

            started_ts = state._pop_attempt_start(
                event.node_id,
                event.attempt,
            )

            if started_ts is None:
                started_ts = event.timestamp

            metadata: dict[str, JSONValue] = {}
            if event.metadata is not None:
                metadata = event.metadata.copy()

            if event.error is not None:
                metadata["error"] = event.error

            output: JSONValue | None = None
            if event.output is not None:
                output = cast(JSONValue, event.output.copy())

            record = ExecutionRecord(
                node_id=event.node_id,
                result=AgentResult(
                    success=event.success,
                    output=output,
                    confidence=event.confidence,
                    metadata=metadata,
                ),
                attempt=event.attempt,
                sequence_number=event.sequence_number,
                started_at=started_ts,
                completed_at=event.timestamp,
                forced=False,
            )

            state.add_record(event.node_id, record)
            return

        # -----------------------------------------------------
        # Node RETRIED (no-op)
        # -----------------------------------------------------
        if isinstance(event, NodeExecutionRetried):
            return
