from __future__ import annotations

from dataclasses import dataclass

from anusara._runtime.circuit_breaker_state import CircuitState


@dataclass(frozen=True)
class CircuitBreakerEvent:
    key: str
    from_state: CircuitState
    to_state: CircuitState
    reason: str
