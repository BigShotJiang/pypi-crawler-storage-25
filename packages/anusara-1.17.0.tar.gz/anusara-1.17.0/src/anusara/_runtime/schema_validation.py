from __future__ import annotations

from anusara._contracts.json_types import JSONValue


def validate_payload_against_schema(
    payload: dict[str, JSONValue],
    schema: dict[str, JSONValue] | None,
) -> list[str]:
    """
    Validate a payload against a minimal object-schema subset.

    Supported schema fields:
    - type: "object"
    - properties: mapping of property names to property schemas
    - required: list[str]

    Supported property types:
    - string
    - integer
    - number
    - boolean
    - object
    - array

    Returns:
        A list of validation error messages. Empty means valid.
    """
    if schema is None:
        return []

    errors: list[str] = []

    schema_type = schema.get("type")
    if schema_type != "object":
        errors.append("Only object input_schema is currently supported.")
        return errors

    properties_raw = schema.get("properties")
    required_raw = schema.get("required")

    properties: dict[str, JSONValue]
    if isinstance(properties_raw, dict):
        properties = properties_raw
    else:
        properties = {}

    required_fields: list[str] = []
    if isinstance(required_raw, list):
        required_fields = [value for value in required_raw if isinstance(value, str)]

    for field_name in required_fields:
        if field_name not in payload:
            errors.append(f"Missing required field: {field_name}")

    for field_name, property_schema_raw in properties.items():
        if field_name not in payload:
            continue

        if not isinstance(property_schema_raw, dict):
            continue

        value = payload[field_name]
        expected_type = property_schema_raw.get("type")

        type_error = _validate_value_type(field_name, value, expected_type)
        if type_error is not None:
            errors.append(type_error)

    return errors


def _validate_value_type(
    field_name: str,
    value: JSONValue,
    expected_type: JSONValue,
) -> str | None:
    if expected_type == "string":
        if not isinstance(value, str):
            return f"Field '{field_name}' must be a string."
        return None

    if expected_type == "integer":
        if not isinstance(value, int) or isinstance(value, bool):
            return f"Field '{field_name}' must be an integer."
        return None

    if expected_type == "number":
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            return f"Field '{field_name}' must be a number."
        return None

    if expected_type == "boolean":
        if not isinstance(value, bool):
            return f"Field '{field_name}' must be a boolean."
        return None

    if expected_type == "object":
        if not isinstance(value, dict):
            return f"Field '{field_name}' must be an object."
        return None

    if expected_type == "array":
        if not isinstance(value, list):
            return f"Field '{field_name}' must be an array."
        return None

    return None


__all__ = ["validate_payload_against_schema"]
