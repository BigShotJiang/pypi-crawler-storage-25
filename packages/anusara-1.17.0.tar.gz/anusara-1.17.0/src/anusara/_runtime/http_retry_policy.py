from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class HttpRetryPolicy:
    max_attempts: int = 2
    base_delay_ms: int = 200
    max_delay_ms: int = 1000

    def compute_delay_seconds(self, attempt_number: int) -> float:
        if attempt_number <= 1:
            return 0.0

        delay_ms = min(
            self.base_delay_ms * (2 ** (attempt_number - 2)),
            self.max_delay_ms,
        )
        return delay_ms / 1000.0
