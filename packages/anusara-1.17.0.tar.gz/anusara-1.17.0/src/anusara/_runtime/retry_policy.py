# anusara/_runtime/retry_policy.py

from __future__ import annotations

import hashlib
from dataclasses import dataclass

from typing_extensions import TypedDict


class RetryPolicyDict(TypedDict):
    max_attempts: int
    base_delay: float
    max_delay: float
    jitter: bool


@dataclass(frozen=True)
class RetryPolicy:
    """
    Governs retry behavior for node execution.

    - max_attempts includes the first attempt
    - attempt is 1-based
    - delays are in seconds

    Determinism:
    - Jitter is deterministic (hash-based), not random
    """

    max_attempts: int = 1
    base_delay: float = 0.1
    max_delay: float = 2.0
    jitter: bool = True

    # ---------------------------------------------------------

    def compute_delay_seconds(
        self,
        attempt: int,
        *,
        request_id: str = "",
        node_id: str = "",
    ) -> float:
        """
        Compute exponential backoff delay.

        Deterministic jitter is derived from request_id + node_id + attempt.
        """

        power = attempt - 1
        delay = self.base_delay * (2**power)
        delay = min(delay, self.max_delay)

        if self.jitter:
            jitter_factor = self._deterministic_jitter(
                request_id=request_id,
                node_id=node_id,
                attempt=attempt,
            )
            delay *= jitter_factor

        return float(delay)

    # ---------------------------------------------------------

    def _deterministic_jitter(
        self,
        *,
        request_id: str,
        node_id: str,
        attempt: int,
    ) -> float:
        """
        Generate deterministic jitter in range [0.5, 1.0].
        """

        key = f"{request_id}:{node_id}:{attempt}".encode()
        digest = hashlib.sha256(key).hexdigest()

        # Convert first 8 hex chars to float
        value = int(digest[:8], 16) / 0xFFFFFFFF

        # Scale to [0.5, 1.0]
        return 0.5 + (value * 0.5)

    # ---------------------------------------------------------

    def to_dict(self) -> RetryPolicyDict:
        return {
            "max_attempts": self.max_attempts,
            "base_delay": self.base_delay,
            "max_delay": self.max_delay,
            "jitter": self.jitter,
        }

    @classmethod
    def from_dict(cls, data: RetryPolicyDict) -> RetryPolicy:
        return cls(
            max_attempts=data["max_attempts"],
            base_delay=data["base_delay"],
            max_delay=data["max_delay"],
            jitter=data["jitter"],
        )
