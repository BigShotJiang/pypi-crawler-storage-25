from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CircuitBreakerPolicy:
    failure_threshold: int = 3
    recovery_timeout_seconds: float = 30.0

    def __post_init__(self) -> None:
        if self.failure_threshold < 1:
            raise ValueError("failure_threshold must be >= 1")

        if self.recovery_timeout_seconds < 0:
            raise ValueError("recovery_timeout_seconds must be >= 0")
