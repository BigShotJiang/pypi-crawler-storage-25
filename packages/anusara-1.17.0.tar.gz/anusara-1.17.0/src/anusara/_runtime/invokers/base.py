from __future__ import annotations

from typing import Protocol

from anusara._contracts.agent_result import AgentResult
from anusara._registry.executable_definition import ExecutableDefinition
from anusara._runtime.worker_invocation import WorkerInvocationRequest


class ExecutableInvoker(Protocol):
    """
    Defines how an executable is invoked at runtime.

    Implementations:
    - PythonPluginInvoker (same-runtime execution)
    - RemoteHttpInvoker (external worker execution)
    """

    async def invoke(
        self,
        definition: ExecutableDefinition,
        request: WorkerInvocationRequest,
    ) -> AgentResult: ...
