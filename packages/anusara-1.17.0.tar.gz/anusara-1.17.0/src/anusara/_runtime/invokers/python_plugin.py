from __future__ import annotations

import asyncio
import inspect
from collections.abc import Callable
from typing import cast

from anusara._contracts.agent import Agent
from anusara._contracts.agent_result import AgentResult
from anusara._contracts.execution_input import ExecutionInput
from anusara._registry.executable_definition import ExecutableDefinition
from anusara._registry.invocation_spec import PythonPluginInvocationSpec
from anusara._runtime.worker_invocation import WorkerInvocationRequest


class PythonPluginInvoker:
    """
    Invokes executables implemented as in-process Python agents.
    """

    def __init__(
        self,
        agent_loader: Callable[[ExecutableDefinition], Agent],
    ) -> None:
        self._agent_loader = agent_loader

    async def invoke(
        self,
        definition: ExecutableDefinition,
        request: WorkerInvocationRequest,
    ) -> AgentResult:
        spec = definition.invocation

        if not isinstance(spec, PythonPluginInvocationSpec):
            raise TypeError("Invalid invocation spec for PythonPluginInvoker")

        agent = self._agent_loader(definition)

        execution_input = ExecutionInput(
            request_id=request.request_id,
            payload=request.payload,
            metadata=request.metadata,
            scenario=request.scenario,
        )

        if inspect.iscoroutinefunction(agent.execute):
            result = await agent.execute(execution_input)
        else:
            result = await asyncio.to_thread(
                cast(Callable[[ExecutionInput], AgentResult], agent.execute),
                execution_input,
            )

        if not isinstance(result, AgentResult):
            raise TypeError("Plugin executable returned invalid result type")

        return result
