from __future__ import annotations

import asyncio

import httpx

from anusara._contracts.agent_result import AgentResult
from anusara._registry.executable_definition import ExecutableDefinition
from anusara._registry.invocation_spec import RemoteHttpInvocationSpec
from anusara._runtime.circuit_breaker_registry import CircuitBreakerRegistry
from anusara._runtime.http_retry_policy import HttpRetryPolicy
from anusara._runtime.worker_invocation import WorkerInvocationRequest


class RemoteHttpInvoker:
    """
    Invokes executables exposed via HTTP endpoints.

    Responsibilities:
    - bounded transport retry for transient failures
    - endpoint-scoped circuit breaker protection
    - transport observability metadata

    Does NOT replace orchestration-level node retry.
    """

    def __init__(
        self,
        retry_policy: HttpRetryPolicy | None = None,
        circuit_breakers: CircuitBreakerRegistry | None = None,
    ) -> None:
        self._retry_policy = retry_policy or HttpRetryPolicy()
        self._circuit_breakers = circuit_breakers or CircuitBreakerRegistry()

    async def invoke(
        self,
        definition: ExecutableDefinition,
        request: WorkerInvocationRequest,
    ) -> AgentResult:
        spec = definition.invocation

        if not isinstance(spec, RemoteHttpInvocationSpec):
            raise TypeError("Invalid invocation spec for RemoteHttpInvoker")

        circuit_key = f"{spec.method.upper()} {spec.url}"
        state_before_call = self._circuit_breakers.before_call(circuit_key)

        payload = {
            "request_id": request.request_id,
            "node_id": request.node_id,
            "agent_id": request.agent_id,
            "attempt": request.attempt,
            "payload": request.payload,
            "metadata": request.metadata,
            "scenario": (
                request.scenario.to_dict() if request.scenario is not None else None
            ),
        }

        invocation_key = f"{request.request_id}:{request.node_id}:{request.attempt}"
        timeout_seconds = spec.timeout_ms / 1000.0

        attempt_count = 0
        retry_reasons: list[str] = []
        total_backoff_ms = 0
        final_status_code: int | None = None
        last_exception: Exception | None = None

        for transport_attempt in range(1, self._retry_policy.max_attempts + 1):
            attempt_count += 1

            try:
                async with httpx.AsyncClient(timeout=timeout_seconds) as client:
                    response = await client.request(
                        method=spec.method,
                        url=spec.url,
                        json=payload,
                        headers={
                            "X-Anusara-Invocation-Key": invocation_key,
                        },
                    )

                final_status_code = response.status_code

                if response.status_code >= 400:
                    if self._is_retryable_status(response.status_code):
                        retry_reasons.append(
                            self._retry_reason_from_status(response.status_code)
                        )

                        if transport_attempt < self._retry_policy.max_attempts:
                            delay_seconds = self._retry_policy.compute_delay_seconds(
                                transport_attempt + 1
                            )
                            total_backoff_ms += int(delay_seconds * 1000)
                            await asyncio.sleep(delay_seconds)
                            continue

                        self._circuit_breakers.record_failure(circuit_key)

                    response.raise_for_status()

                data = response.json()

                if not isinstance(data, dict):
                    raise TypeError("Remote worker response must be a JSON object")

                raw_success = data.get("success", False)
                if not isinstance(raw_success, bool):
                    raise TypeError("Remote worker field 'success' must be a boolean")

                raw_output = data.get("output")
                raw_errors = data.get("errors", [])
                raw_confidence = data.get("confidence", 0.0)
                raw_metadata = data.get("metadata", {})

                if not isinstance(raw_errors, list) or not all(
                    isinstance(e, str) for e in raw_errors
                ):
                    raise TypeError("Remote worker field 'errors' must be a list[str]")

                if not isinstance(raw_confidence, (int, float)):
                    raise TypeError("Remote worker field 'confidence' must be numeric")

                if not isinstance(raw_metadata, dict):
                    raise TypeError("Remote worker field 'metadata' must be an object")

                self._circuit_breakers.record_success(circuit_key)
                circuit_state = self._circuit_breakers.snapshot(circuit_key)

                metadata = dict(raw_metadata)
                metadata["transport"] = {
                    "kind": "remote_http",
                    "attempts": attempt_count,
                    "retries": attempt_count - 1,
                    "final_status_code": final_status_code,
                    "total_backoff_ms": total_backoff_ms,
                    "retry_reasons": retry_reasons,
                    "circuit": {
                        "key": circuit_key,
                        "state": circuit_state.state.value,
                        "state_before_call": state_before_call.value,
                    },
                }

                return AgentResult(
                    success=raw_success,
                    output=raw_output,
                    errors=list(raw_errors),
                    confidence=float(raw_confidence),
                    metadata=metadata,
                )

            except Exception as exc:
                if self._is_retryable_exception(exc):
                    last_exception = exc
                    retry_reasons.append(self._retry_reason_from_exception(exc))

                    if transport_attempt < self._retry_policy.max_attempts:
                        delay_seconds = self._retry_policy.compute_delay_seconds(
                            transport_attempt + 1
                        )
                        total_backoff_ms += int(delay_seconds * 1000)
                        await asyncio.sleep(delay_seconds)
                        continue

                    self._circuit_breakers.record_failure(circuit_key)

                raise

        if last_exception is not None:
            raise last_exception

        raise RuntimeError("Remote HTTP invocation failed without result or exception")

    def _is_retryable_exception(self, exc: Exception) -> bool:
        return isinstance(
            exc,
            (
                httpx.ConnectError,
                httpx.ConnectTimeout,
                httpx.ReadTimeout,
            ),
        )

    def _is_retryable_status(self, status_code: int) -> bool:
        return status_code in {429, 502, 503, 504}

    def _retry_reason_from_exception(self, exc: Exception) -> str:
        return type(exc).__name__

    def _retry_reason_from_status(self, status_code: int) -> str:
        return f"HTTP_{status_code}"
