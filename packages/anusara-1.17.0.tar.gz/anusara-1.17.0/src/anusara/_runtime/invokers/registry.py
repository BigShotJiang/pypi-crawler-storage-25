from __future__ import annotations

from anusara._contracts.agent_result import AgentResult
from anusara._registry.executable_definition import ExecutableDefinition
from anusara._registry.executable_kind import ExecutableKind
from anusara._runtime.invokers.base import ExecutableInvoker
from anusara._runtime.invokers.python_plugin import PythonPluginInvoker
from anusara._runtime.invokers.remote_http import RemoteHttpInvoker
from anusara._runtime.worker_invocation import WorkerInvocationRequest


class InvokerRegistry:
    """
    Resolves the correct invoker for a given executable definition.
    """

    def __init__(
        self,
        plugin_invoker: PythonPluginInvoker,
        remote_http_invoker: RemoteHttpInvoker,
    ) -> None:
        self._plugin_invoker = plugin_invoker
        self._remote_http_invoker = remote_http_invoker

    def get(self, definition: ExecutableDefinition) -> ExecutableInvoker:
        if definition.kind == ExecutableKind.PYTHON_PLUGIN:
            return self._plugin_invoker

        if definition.kind == ExecutableKind.REMOTE_HTTP:
            return self._remote_http_invoker

        raise ValueError(f"Unsupported executable kind: {definition.kind}")

    async def invoke(
        self,
        definition: ExecutableDefinition,
        request: WorkerInvocationRequest,
    ) -> AgentResult:
        invoker = self.get(definition)
        return await invoker.invoke(definition, request)
