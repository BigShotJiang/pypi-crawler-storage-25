from __future__ import annotations

from dataclasses import dataclass

from anusara._contracts.execution_scenario import ExecutionScenario
from anusara._contracts.json_types import JSONValue


@dataclass(frozen=True)
class WorkerInvocationRequest:
    """
    Internal runtime DTO used by executable invokers.

    This is intentionally execution-boundary oriented:
    - suitable for remote serialization
    - suitable for adaptation into local in-process ExecutionInput
    - independent of specific invoker implementation
    """

    request_id: str
    node_id: str
    agent_id: str
    attempt: int
    payload: dict[str, JSONValue]
    metadata: dict[str, JSONValue]
    scenario: ExecutionScenario


__all__ = ["WorkerInvocationRequest"]
