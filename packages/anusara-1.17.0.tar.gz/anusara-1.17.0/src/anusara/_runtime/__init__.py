"""
Runtime execution layer for Anusara.

This package is responsible for driving actual workflow execution
based on compiled graphs and execution state.

Key responsibilities:
- Scheduling and orchestrating node execution
- Enforcing execution policies (fail-fast, retries, etc.)
- Coordinating agent invocation
- Managing concurrency and execution flow
- Emitting lifecycle events during execution

Design principles:
- Deterministic behavior aligned with event sourcing
- Clear separation between routing (what can run) and runtime (what runs)
- Explicit execution lifecycle with no hidden side effects
- Extensible for different execution strategies (sequential, parallel, etc.)

This layer consumes:
- ExecutionGraph (compiled structure)
- ExecutionState (runtime truth)
- AgentRegistry (execution units)

And produces:
- Orchestration events
- Updated execution state
- Final execution results
"""
