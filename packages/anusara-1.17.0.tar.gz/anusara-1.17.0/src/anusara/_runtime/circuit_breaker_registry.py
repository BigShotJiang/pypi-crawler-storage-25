from __future__ import annotations

import threading
import time
from collections.abc import Callable
from dataclasses import replace

from anusara._core.errors import CircuitBreakerOpenError
from anusara._runtime.circuit_breaker_event import CircuitBreakerEvent
from anusara._runtime.circuit_breaker_policy import CircuitBreakerPolicy
from anusara._runtime.circuit_breaker_state import CircuitBreakerState, CircuitState


class CircuitBreakerRegistry:
    """
    In-memory circuit breaker registry keyed by remote endpoint identity.

    Thread-safe for concurrent runtime access.
    """

    def __init__(
        self,
        policy: CircuitBreakerPolicy | None = None,
        *,
        now_provider: Callable[[], float] | None = None,
    ) -> None:
        self._policy = policy or CircuitBreakerPolicy()
        self._now = now_provider or time.monotonic
        self._states: dict[str, CircuitBreakerState] = {}
        self._events: list[CircuitBreakerEvent] = []
        self._lock = threading.Lock()

    def before_call(self, key: str) -> CircuitState:
        with self._lock:
            state = self._states.get(key)
            if state is None:
                state = CircuitBreakerState()
                self._states[key] = state

            if state.state == CircuitState.CLOSED:
                return CircuitState.CLOSED

            if state.state == CircuitState.OPEN:
                if self._recovery_timeout_elapsed(state):
                    self._record_transition(
                        key=key,
                        state=state,
                        to_state=CircuitState.HALF_OPEN,
                        reason="recovery_timeout_elapsed",
                    )
                    state.half_open_in_flight = True
                    return CircuitState.HALF_OPEN

                raise CircuitBreakerOpenError(key)

            if state.state == CircuitState.HALF_OPEN:
                if state.half_open_in_flight:
                    raise CircuitBreakerOpenError(key)

                state.half_open_in_flight = True
                return CircuitState.HALF_OPEN

            raise ValueError(f"Unsupported circuit state: {state.state}")

    def record_success(self, key: str) -> None:
        with self._lock:
            state = self._states.get(key)
            if state is None:
                self._states[key] = CircuitBreakerState()
                return

            if state.state == CircuitState.HALF_OPEN:
                self._record_transition(
                    key=key,
                    state=state,
                    to_state=CircuitState.CLOSED,
                    reason="probe_succeeded",
                )
                return

            state.consecutive_failures = 0
            state.opened_at_monotonic = None
            state.half_open_in_flight = False

    def record_failure(self, key: str) -> None:
        with self._lock:
            state = self._states.get(key)
            if state is None:
                state = CircuitBreakerState()
                self._states[key] = state

            if state.state == CircuitState.HALF_OPEN:
                self._record_transition(
                    key=key,
                    state=state,
                    to_state=CircuitState.OPEN,
                    reason="probe_failed",
                )
                state.consecutive_failures = self._policy.failure_threshold
                state.opened_at_monotonic = self._now()
                state.half_open_in_flight = False
                return

            if state.state == CircuitState.CLOSED:
                state.consecutive_failures += 1

                if state.consecutive_failures >= self._policy.failure_threshold:
                    self._record_transition(
                        key=key,
                        state=state,
                        to_state=CircuitState.OPEN,
                        reason="failure_threshold_reached",
                    )
                    state.opened_at_monotonic = self._now()
                    state.half_open_in_flight = False
                return

            if state.state == CircuitState.OPEN:
                state.opened_at_monotonic = self._now()
                state.half_open_in_flight = False
                return

            raise ValueError(f"Unsupported circuit state: {state.state}")

    def snapshot(self, key: str) -> CircuitBreakerState:
        with self._lock:
            state = self._states.get(key)
            if state is None:
                return CircuitBreakerState()

            return replace(state)

    def snapshot_all(self) -> dict[str, CircuitBreakerState]:
        with self._lock:
            return {key: replace(state) for key, state in self._states.items()}

    def list_events(self) -> list[CircuitBreakerEvent]:
        with self._lock:
            return list(self._events)

    def clear_events(self) -> None:
        with self._lock:
            self._events.clear()

    def _recovery_timeout_elapsed(self, state: CircuitBreakerState) -> bool:
        if state.opened_at_monotonic is None:
            return False

        elapsed = self._now() - state.opened_at_monotonic
        return elapsed >= self._policy.recovery_timeout_seconds

    def _record_transition(
        self,
        *,
        key: str,
        state: CircuitBreakerState,
        to_state: CircuitState,
        reason: str,
    ) -> None:
        from_state = state.state

        if from_state == to_state:
            return

        self._events.append(
            CircuitBreakerEvent(
                key=key,
                from_state=from_state,
                to_state=to_state,
                reason=reason,
            )
        )

        state.state = to_state

        if to_state == CircuitState.CLOSED:
            state.consecutive_failures = 0
            state.opened_at_monotonic = None
            state.half_open_in_flight = False
        elif to_state == CircuitState.OPEN:
            state.half_open_in_flight = False
        elif to_state == CircuitState.HALF_OPEN:
            state.half_open_in_flight = False
