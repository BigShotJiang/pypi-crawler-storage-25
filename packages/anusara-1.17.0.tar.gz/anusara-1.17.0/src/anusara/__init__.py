"""
Anusara

A deterministic execution engine built on event-sourced state,
replay integrity, and explicit lifecycle guarantees.

Public API surface.

Modules prefixed with `_` are internal and not stable.
Optional integrations and advanced APIs should be imported explicitly.
"""

from importlib.metadata import PackageNotFoundError, version

# ---------------------------------------------------------
# Execution Contract
# ---------------------------------------------------------
from anusara.api import (
    AgentResult,
    ExecutionRequest,
    ExecutionScenario,
    GraphDefinition,
    MeshResult,
)

# ---------------------------------------------------------
# Core
# ---------------------------------------------------------
from anusara.api.core import (
    Agent,
    AgentRegistry,
    ExecutionEngine,
    ExecutionPolicy,
    FailureMode,
    RetryPolicy,
)

# ---------------------------------------------------------
# Errors
# ---------------------------------------------------------
from anusara.api.errors import (
    ApprovalRequiredError,
    MaxHopExceededError,
    MutationComplianceError,
    SimulatedHardKillError,
)

# ---------------------------------------------------------
# Helper
# ---------------------------------------------------------
from anusara.api.helper import JSONValue, utc_now

# ---------------------------------------------------------
# Introspection
# ---------------------------------------------------------
from anusara.api.introspection import (
    ExecutionInput,
    ExecutionStatus,
    SnapshotMode,
)

# ---------------------------------------------------------
# Logging
# ---------------------------------------------------------
from anusara.api.logging import (
    ExecutionEventLog,
    FileExecutionEventLog,
    InMemoryExecutionEventLog,
)

# ---------------------------------------------------------
# Observability (safe exports only)
# ---------------------------------------------------------
from anusara.api.observability import (
    DiagnosticsObserver,
    ExecutionDebugger,
    ExecutionGraphVisualizer,
    ExecutionObserver,
    MetricsObserver,
    StructuredConsoleObserver,
)

# ---------------------------------------------------------
# Version
# ---------------------------------------------------------

try:
    __version__ = version("anusara")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

__all__ = [
    # Core
    "ExecutionEngine",
    "ExecutionPolicy",
    "RetryPolicy",
    "FailureMode",
    "Agent",
    "AgentRegistry",
    # Execution Contract
    "ExecutionRequest",
    "AgentResult",
    "GraphDefinition",
    "MeshResult",
    "ExecutionScenario",
    # Introspection
    "ExecutionStatus",
    "SnapshotMode",
    "ExecutionInput",
    # Logging
    "ExecutionEventLog",
    "FileExecutionEventLog",
    "InMemoryExecutionEventLog",
    # Observability
    "ExecutionObserver",
    "StructuredConsoleObserver",
    "MetricsObserver",
    "DiagnosticsObserver",
    "ExecutionDebugger",
    "ExecutionGraphVisualizer",
    # Errors
    "ApprovalRequiredError",
    "MutationComplianceError",
    "SimulatedHardKillError",
    "MaxHopExceededError",
    # Helper
    "utc_now",
    "JSONValue",
    # Version
    "__version__",
]
