"""
Anusara Mutation (Advanced API)

Provides governance and mutation lifecycle controls.
Intended for advanced orchestration scenarios.

This API surface is stable.
"""

from anusara._mutation.event import (
    GraphMutationAccepted,
    GraphMutationConflictDetected,
    GraphMutationConflictResolved,
    GraphMutationExecuted,
    GraphMutationExecutionFailed,
    GraphMutationNoProposal,
    GraphMutationProposed,
    GraphMutationRejected,
    MutationEvaluationRequested,
)
from anusara._mutation.execution_builder import MutationExecutionBuilder
from anusara._mutation.execution_runner import MutationExecutionRunner
from anusara._mutation.identity.base import MutationIdentityStrategy
from anusara._mutation.identity.sha256 import SHA256SaltedIdentityStrategy
from anusara._mutation.in_memory_event_log import InMemoryMutationEventLog
from anusara._mutation.in_memory_store import InMemoryMutationArtifactStore
from anusara._mutation.policy import MutationExecutionPolicy, MutationFailureStrategy
from anusara._mutation.proposal_builder import MutationProposalBuilder

__all__ = [
    "MutationEvaluationRequested",
    "GraphMutationProposed",
    "GraphMutationNoProposal",
    "GraphMutationAccepted",
    "GraphMutationRejected",
    "GraphMutationConflictDetected",
    "GraphMutationConflictResolved",
    "GraphMutationExecuted",
    "GraphMutationExecutionFailed",
    "MutationExecutionBuilder",
    "MutationExecutionRunner",
    "MutationProposalBuilder",
    "MutationIdentityStrategy",
    "InMemoryMutationEventLog",
    "InMemoryMutationArtifactStore",
    "SHA256SaltedIdentityStrategy",
    "MutationExecutionPolicy",
    "MutationFailureStrategy",
]
