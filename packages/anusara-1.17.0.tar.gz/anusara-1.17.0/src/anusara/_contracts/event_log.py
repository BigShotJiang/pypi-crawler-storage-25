"""
Execution Event Log Contract

Defines the append-only contract for orchestration event storage.

The event log is the authoritative temporal record of execution.
State must be reconstructible solely by replaying events from the log.

Invariants:
- Append-only
- Ordering preserved
- Events immutable once appended
- No filtering or mutation inside the log
"""

from collections.abc import Iterator
from typing import Protocol

from anusara._contracts.events import OrchestrationEvent


class ExecutionEventLog(Protocol):
    """
    Append-only event log interface.

    Implementations may be:
    - In-memory
    - File-backed (JSONL)
    - Database-backed
    - Distributed storage

    Contract:
    - Events must be stored in emission order.
    - read_all() must return events in original append order.
    - clear() removes all stored events.
    """

    def append(self, event: OrchestrationEvent) -> None:
        """
        Append an event to the log.

        Must preserve order.
        Must not mutate the event.
        """
        ...

    def read_all(self) -> list[OrchestrationEvent]:
        """
        Return all events in append order.

        Must return a copy (not internal storage reference).
        """
        ...

    def read_by_request(self, request_id: str) -> list[OrchestrationEvent]:
        """
        Return all events for a given request_id in append order.
        """
        ...

    def clear(self) -> None:
        """
        Remove all stored events.
        Primarily used for testing or controlled resets.
        """
        ...

    def iter(self) -> Iterator[OrchestrationEvent]:
        """
        Stream events in append order.
        """
        ...


__all__ = ["ExecutionEventLog"]
