from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

from anusara._contracts.json_types import JSONValue


@dataclass(frozen=True)
class ExecutionScenario:
    """
    Represents execution-time behavioral controls.

    This is part of the control plane and must remain:
    - deterministic
    - serializable
    - replay-safe
    """

    name: str = "default"
    flags: dict[str, bool] = field(default_factory=dict)
    parameters: dict[str, JSONValue] = field(default_factory=dict)

    # ---------------------------------------------------------
    # Helpers
    # ---------------------------------------------------------

    def flag(self, name: str) -> bool:
        """
        Check if a boolean flag is enabled.
        """
        return self.flags.get(name, False)

    # ---------------------------------------------------------
    # Access helpers
    # ---------------------------------------------------------

    def param(self, key: str, default: JSONValue | None = None) -> JSONValue | None:
        """
        Retrieve a parameter value with optional default.
        """
        return self.parameters.get(key, default)

    def fail_nodes(self) -> set[str]:
        raw = self.parameters.get("fail_nodes")

        if isinstance(raw, list):
            return {v for v in raw if isinstance(v, str)}

        return set()

    # ---------------------------------------------------------
    # Serialization
    # ---------------------------------------------------------

    def to_dict(self) -> dict[str, JSONValue]:
        flags_json: dict[str, JSONValue] = {
            key: value for key, value in self.flags.items()
        }

        return {
            "name": self.name,
            "flags": flags_json,
            "parameters": self.parameters,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, JSONValue]) -> ExecutionScenario:
        name_raw = data.get("name")
        flags_raw = data.get("flags")
        params_raw = data.get("parameters")

        name = name_raw if isinstance(name_raw, str) else "default"

        flags: dict[str, bool] = {}
        if isinstance(flags_raw, dict):
            for k, v in flags_raw.items():
                if isinstance(k, str) and isinstance(v, bool):
                    flags[k] = v

        parameters: dict[str, JSONValue] = {}
        if isinstance(params_raw, dict):
            for k, v in params_raw.items():
                if isinstance(k, str):
                    parameters[k] = v

        return cls(
            name=name,
            flags=flags,
            parameters=parameters,
        )
