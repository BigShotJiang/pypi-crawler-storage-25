from __future__ import annotations

from dataclasses import dataclass

from anusara._contracts.execution_scenario import ExecutionScenario
from anusara._contracts.json_types import JSONValue


@dataclass(frozen=True)
class ExecutionInput:
    request_id: str
    payload: dict[str, JSONValue]
    metadata: dict[str, JSONValue]
    scenario: ExecutionScenario

    # ---------------------------------------------------------
    # Scenario helpers (control-plane access)
    # ---------------------------------------------------------

    def scenario_name(self) -> str:
        return self.scenario.name

    def flag(self, key: str, default: bool = False) -> bool:
        return self.scenario.flags.get(key, default)

    def param(self, key: str, default: JSONValue | None = None) -> JSONValue | None:
        return self.scenario.param(key, default)

    # 🔥 Typed helpers (mypy-safe, agent-friendly)

    def param_str(self, key: str, default: str = "") -> str:
        value = self.param(key, default)
        return value if isinstance(value, str) else default

    def param_int(self, key: str, default: int = 0) -> int:
        value = self.param(key, default)
        return value if isinstance(value, int) else default

    def param_float(self, key: str, default: float = 0.0) -> float:
        value = self.param(key, default)
        return value if isinstance(value, float) else default

    def param_bool(self, key: str, default: bool = False) -> bool:
        value = self.param(key, default)
        return value if isinstance(value, bool) else default

    def param_dict(self, key: str) -> dict[str, JSONValue]:
        value = self.param(key)
        return value if isinstance(value, dict) else {}

    def should_fail_node(self, node_id: str) -> bool:
        return node_id in self.scenario.fail_nodes()

    # ---------------------------------------------------------
    # Data (data-plane access)
    # ---------------------------------------------------------

    @property
    def data(self) -> dict[str, JSONValue]:
        raw = self.payload.get("data")

        if isinstance(raw, dict):
            return raw

        return self.payload
