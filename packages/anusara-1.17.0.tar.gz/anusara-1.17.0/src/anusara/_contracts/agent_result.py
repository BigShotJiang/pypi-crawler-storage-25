from dataclasses import dataclass, field

from anusara._contracts.json_types import JSONValue


@dataclass
class AgentResult:
    """
    Result produced by an agent execution.
    """

    success: bool
    output: JSONValue | None = None
    errors: list[str] = field(default_factory=list)
    confidence: float = 0.0
    metadata: dict[str, JSONValue] = field(default_factory=dict)
