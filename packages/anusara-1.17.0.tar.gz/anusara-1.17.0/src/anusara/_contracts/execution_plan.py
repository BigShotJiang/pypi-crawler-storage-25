from dataclasses import dataclass

from anusara._routing.execution_graph import ExecutionGraph


@dataclass
class ExecutionPlan:
    """
    Internal compiled representation of an execution request.
    """

    graph: ExecutionGraph


__all__ = ["ExecutionPlan"]
