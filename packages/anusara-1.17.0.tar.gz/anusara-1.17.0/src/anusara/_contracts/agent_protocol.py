from collections.abc import Awaitable
from typing import Protocol

from anusara._contracts.agent_result import AgentResult  # ✅ FIX
from anusara._contracts.execution_input import ExecutionInput


class AgentProtocol(Protocol):
    def execute(
        self,
        execution_input: ExecutionInput,
    ) -> Awaitable[AgentResult]: ...


__all__ = ["AgentProtocol"]
