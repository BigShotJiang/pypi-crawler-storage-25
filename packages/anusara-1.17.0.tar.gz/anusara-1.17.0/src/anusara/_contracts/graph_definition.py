from typing import NotRequired, TypedDict

# =========================================================
# Graph Definition Contracts
# =========================================================


class NodeDefinition(TypedDict):
    id: str
    agent: NotRequired[str]
    metadata: NotRequired[dict[str, object]]


class EdgeDict(TypedDict):
    source: str
    target: str


EdgeDefinition = tuple[str, str] | EdgeDict


class GraphDefinition(TypedDict):
    nodes: NotRequired[list[NodeDefinition]]
    edges: NotRequired[list[EdgeDefinition]]


__all__ = [
    "NodeDefinition",
    "EdgeDict",
    "EdgeDefinition",
    "GraphDefinition",
]
