from dataclasses import dataclass
from datetime import datetime
from typing import ClassVar

from anusara._contracts.event_types import (
    CoreEventTypes,
    ExecutionEventTypes,
)
from anusara._contracts.json_types import JSONValue

# =========================================================
# Event Registry
# =========================================================


class EventRegistry:
    _registry: ClassVar[dict[str, type["OrchestrationEvent"]]] = {}

    @classmethod
    def register(
        cls,
        event_cls: type["OrchestrationEvent"],
    ) -> type["OrchestrationEvent"]:

        event_type = event_cls.EVENT_TYPE

        if event_type in cls._registry:
            raise ValueError(f"Duplicate event_type registration: {event_type}")

        cls._registry[event_type] = event_cls
        return event_cls

    @classmethod
    def resolve(
        cls,
        event_type: str,
    ) -> type["OrchestrationEvent"]:

        if event_type not in cls._registry:
            raise ValueError(f"Unknown event_type: {event_type}")

        return cls._registry[event_type]


# =========================================================
# Base Event
# =========================================================


@dataclass(kw_only=True)
class OrchestrationEvent:
    request_id: str
    timestamp: datetime
    is_replay: bool = False

    EVENT_TYPE: ClassVar[str] = CoreEventTypes.ORCHESTRATION_EVENT

    @property
    def event_type(self) -> str:
        return self.EVENT_TYPE


# =========================================================
# Execution-Level Events
# =========================================================


@EventRegistry.register
@dataclass
class ExecutionStarted(OrchestrationEvent):
    execution_request: dict[str, JSONValue]

    EVENT_TYPE: ClassVar[str] = ExecutionEventTypes.MAIN_EXECUTION_STARTED


@EventRegistry.register
@dataclass
class ExecutionCompleted(OrchestrationEvent):
    success: bool
    total_nodes: int

    EVENT_TYPE: ClassVar[str] = ExecutionEventTypes.MAIN_EXECUTION_COMPLETED


@EventRegistry.register
@dataclass
class ExecutionFailed(OrchestrationEvent):
    error: str  # JSON-safe

    EVENT_TYPE: ClassVar[str] = ExecutionEventTypes.MAIN_EXECUTION_FAILED


@EventRegistry.register
@dataclass
class ExecutionPaused(OrchestrationEvent):
    reason: str

    EVENT_TYPE: ClassVar[str] = ExecutionEventTypes.MAIN_EXECUTION_PAUSED


# =========================================================
# Node-Level Events
# =========================================================


@EventRegistry.register
@dataclass
class NodeExecutionStarted(OrchestrationEvent):
    node_id: str
    agent: str
    attempt: int

    EVENT_TYPE: ClassVar[str] = ExecutionEventTypes.NODE_EXECUTION_STARTED


@EventRegistry.register
@dataclass(kw_only=True)
class NodeExecutionCompleted(OrchestrationEvent):
    node_id: str
    agent: str
    attempt: int

    success: bool
    confidence: float
    sequence_number: int

    metadata: dict[str, JSONValue] | None = None
    output: dict[str, JSONValue] | None = None

    EVENT_TYPE: ClassVar[str] = ExecutionEventTypes.NODE_EXECUTION_COMPLETED


@EventRegistry.register
@dataclass
class NodeExecutionRetried(OrchestrationEvent):
    node_id: str
    agent: str
    attempt: int
    delay_seconds: float

    EVENT_TYPE: ClassVar[str] = ExecutionEventTypes.NODE_EXECUTION_RETRIED


@EventRegistry.register
@dataclass
class NodeExecutionFailed(OrchestrationEvent):
    node_id: str
    agent: str
    attempt: int
    sequence_number: int
    error: str  # JSON-safe
    metadata: dict[str, JSONValue] | None = None  # 🔥 ADD THIS

    EVENT_TYPE: ClassVar[str] = ExecutionEventTypes.NODE_EXECUTION_FAILED


@EventRegistry.register
@dataclass(kw_only=True)
class NodeExecutionFinished(OrchestrationEvent):
    node_id: str
    agent: str
    attempt: int

    success: bool
    confidence: float
    sequence_number: int

    metadata: dict[str, JSONValue] | None = None
    output: dict[str, JSONValue] | None = None
    error: str | None = None

    EVENT_TYPE: ClassVar[str] = ExecutionEventTypes.NODE_EXECUTION_FINISHED


# =========================================================
# Mutation / Edge Cases
# =========================================================


@dataclass
class MutationEvaluationMissing(OrchestrationEvent):
    policy_mode: str
    reason: str


__all__ = [
    "EventRegistry",
    "OrchestrationEvent",
    "ExecutionStarted",
    "ExecutionCompleted",
    "ExecutionFailed",
    "ExecutionPaused",
    "NodeExecutionStarted",
    "NodeExecutionCompleted",
    "NodeExecutionRetried",
    "NodeExecutionFailed",
    "NodeExecutionFinished",
    "MutationEvaluationMissing",
]
