from __future__ import annotations

from typing import Protocol, runtime_checkable

from anusara._contracts.agent_schema_descriptor import AgentSchemaDescriptor


@runtime_checkable
class AgentSchemaProvider(Protocol):
    """
    Optional class-level schema provider for agent introspection.
    """

    @classmethod
    def describe_schema(cls) -> AgentSchemaDescriptor: ...


__all__ = ["AgentSchemaProvider"]
