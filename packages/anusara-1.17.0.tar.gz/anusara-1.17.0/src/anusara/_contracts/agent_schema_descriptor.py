from __future__ import annotations

from dataclasses import dataclass, field

from anusara._contracts.json_types import JSONValue


@dataclass(frozen=True)
class AgentSchemaDescriptor:
    """
    Optional descriptive schema metadata for an agent.

    This metadata is intended for introspection, UI support, API discovery,
    and future tooling. It must remain deterministic and serializable.
    """

    description: str | None = None
    input_schema: dict[str, JSONValue] | None = None
    output_schema: dict[str, JSONValue] | None = None
    capabilities: list[str] = field(default_factory=list)


__all__ = ["AgentSchemaDescriptor"]
