# anusara/_utils/time.py

from __future__ import annotations

from datetime import UTC, datetime


def utc_now() -> datetime:
    """
    Return current UTC timestamp (timezone-aware).

    Guarantees:
    - Always timezone-aware (UTC)
    - Safe for serialization (ISO 8601)
    - Consistent across the system

    Notes:
    - Avoid using datetime.now() without timezone
    - All timestamps in Anusara should originate from this function
    """
    return datetime.now(UTC)
