"""
Utility primitives for Anusara.

This package provides foundational helpers used across all layers
(core, routing, runtime, mutation, and observability).

Responsibilities:
- JSON-safe typing and serialization helpers
- Deterministic hashing and canonicalization utilities
- Event validation and structural guarantees
- Time utilities with consistent timezone handling
- Lightweight logging abstractions

Design principles:
- Deterministic and side-effect free wherever possible
- JSON-boundary safety for all external-facing data
- Minimal dependencies and high reuse across modules
- No business logic — only shared primitives

These utilities form the lowest layer of the system and are
intentionally simple, stable, and dependency-light.
"""
