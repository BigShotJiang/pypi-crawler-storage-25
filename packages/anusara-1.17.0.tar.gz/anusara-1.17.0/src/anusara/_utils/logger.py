# agentmesh/utils/logger.py

import logging


def get_logger(name: str) -> logging.Logger:
    """
    Return a configured logger instance.

    Does not modify the logger name.
    """

    if not name or not isinstance(name, str):
        raise ValueError("Logger name must be a non-empty string.")

    logger = logging.getLogger(name)

    # Prevent duplicate handlers if called multiple times
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)

    return logger
