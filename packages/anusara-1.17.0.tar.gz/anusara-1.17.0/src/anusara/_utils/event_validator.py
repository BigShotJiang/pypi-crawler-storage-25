# anusara/_utils/event_validator.py

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable

from anusara._contracts.events import (
    NodeExecutionFinished,
    NodeExecutionStarted,
    OrchestrationEvent,
)
from anusara._routing.execution_graph import ExecutionGraph


class EventInvariantError(Exception):
    """Raised when event stream violates execution invariants."""


class EventInvariantValidator:
    """
    Validates execution event stream invariants.

    Ensures:
    - Attempt lifecycle integrity
    - Monotonic attempt ordering per node
    - Start-before-finish guarantees
    - Topological execution correctness

    This is a read-only, deterministic validator.
    """

    def __init__(self, events: Iterable[OrchestrationEvent]) -> None:
        self.events = list(events)

    def validate_attempt_integrity(self) -> None:
        starts: list[tuple[int, NodeExecutionStarted]] = []
        finishes: list[tuple[int, NodeExecutionFinished]] = []

        for idx, event in enumerate(self.events):
            if isinstance(event, NodeExecutionStarted):
                starts.append((idx, event))
            elif isinstance(event, NodeExecutionFinished):
                finishes.append((idx, event))

        if len(starts) != len(finishes):
            raise EventInvariantError("Mismatch between start and finished events.")

        per_node_attempts: dict[str, list[int]] = defaultdict(list)

        for _, event in starts:
            per_node_attempts[event.node_id].append(event.attempt)

        for node_id, attempts in per_node_attempts.items():
            if attempts != sorted(attempts):
                raise EventInvariantError(
                    f"Non-monotonic attempts for node '{node_id}'."
                )

        for (start_idx, start_evt), (finish_idx, finish_evt) in zip(
            starts,
            finishes,
            strict=False,
        ):
            if start_idx >= finish_idx:
                raise EventInvariantError(
                    f"Finish before start for node '{start_evt.node_id}'."
                )

            if (
                start_evt.node_id != finish_evt.node_id
                or start_evt.attempt != finish_evt.attempt
            ):
                raise EventInvariantError("Mismatched start/finished pairing detected.")

    def validate_topology(self, graph: ExecutionGraph) -> None:
        """
        Ensures that:
        - Parent node finishes before child node starts
        """
        final_finish_index: dict[str, int] = {}

        for idx, event in enumerate(self.events):
            if isinstance(event, NodeExecutionFinished):
                final_finish_index[event.node_id] = idx

        for parent in graph.nodes:
            parent_finish = final_finish_index.get(parent)

            if parent_finish is None:
                continue

            for child in graph.children_of(parent):
                child_start_idx = next(
                    (
                        i
                        for i, e in enumerate(self.events)
                        if isinstance(e, NodeExecutionStarted) and e.node_id == child
                    ),
                    None,
                )

                if child_start_idx is None:
                    continue

                if parent_finish >= child_start_idx:
                    raise EventInvariantError(
                        f"Topology violation: '{parent}' finished after '{child}' started."
                    )
